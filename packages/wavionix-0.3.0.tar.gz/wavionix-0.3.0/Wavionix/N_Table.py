from copy import deepcopy
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Table:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is None:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')
            return
        self._Type = 'Table'
        try:
            self._Main = Main
            self._Config = {
                'Name': False,
                'Background': '#ffffff',
                'Foreground': '#000000',
                'Border_Color': '#000000',
                'Border_Size': 0,
                'Border_Radius': 0,
                'Display': True,
                'Left': None,
                'Top': None,
                'Right': None,
                'Bottom': None,
                'Width': None,
                'Height': 260,
                'Animate_Left': 0,
                'Animate_Top': 0,
                'Animate_Width': 0,
                'Animate_Height': 0,
                'Animate_Time': 1.0,
                'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                'Rows': 5,
                'Columns': 5,
                'Column_Heading': True,
                'Row_Heading': False,
                'Cell_Width': 120,
                'Cell_Height': 32,
                'Heading_Width': 120,
                'Heading_Height': 32,
                'Cell_Background': '#ffffff',
                'Cell_Foreground': '#000000',
                'Cell_Font_Size': 12,
                'Cell_Font_Weight': 'normal',
                'Cell_Font_Family': 'Helvetica',
                'Cell_Disable_Background': '#e5e7eb',
                'Cell_Disable_Foreground': '#7b7d7d',
                'Cell_Disable_Opacity': 0.65,
                'Heading_Background': '#f3f4f6',
                'Heading_Foreground': '#000000',
                'Heading_Font_Size': 12,
                'Heading_Font_Weight': '700',
                'Heading_Font_Family': 'Helvetica',
                'Selected_Background': '#d0e4f5',
                'Selected_Foreground': False,
                'Edit_Background': '#ffffff',
                'Edit_Foreground': '#000000',
                'Grid_Color': '#d9d9d9',
                'Grid_Size': 1,
                'Editable': True,
                'Disable': False,
                'Tooltip_Delay': 0.5,
                'Padding': 0,
                'Margin': 0,
                'Mode': 'Flow',
                'Classes': '',
                'Style': '',
                'Z_Index': None,
                'Shadow_X': 0,
                'Shadow_Y': 0,
                'Shadow_Blur': 0,
                'Shadow_Spread': 0,
                'Shadow_Color': 'transparent',
                'Scrollbar_Active': True,
                'Scrollbar_Size': 10,
            }
            for Each, Value in self._Config.items():
                setattr(self, '_' + Each, deepcopy(Value))
            self._Initialized = False
            self._Widget = None
            self._Frame = None
            self._Body = None
            self._Name = False
            self._Last_Name = False
            self._Data = {}
            self._Headings = {}
            self._Cell_Styles = {}
            self._Clipboard_Text = ''
            self._Clipboard_Cell_Styles = {}
            self._Clipboard_Visual_Ready = False
            self._Heading_Styles = {}
            self._Disabled_Cells = set()
            self._Selected = None
            self._Selected_Cells = set()
            self._Select_Start = None
            self._Dragging = False
            self._Editing = None
            self._Edit_Input = None
            self._Click_Timer = None
            self._Cell_Widgets = {}
            self._Cell_Text_Widgets = {}
            self._On_Undo = False
            self._On_Redo = False
            self._Undo_Stack = []
            self._Redo_Stack = []
            self._History_Limit = 100
            self._History_Block = False
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Key_Event_Timer = None
            self._On_Show = False
            self._On_Hide = False
            self._On_Select = False
            self._On_Change = False
            self._On_Copy = False
            self._On_Cut = False
            self._On_Paste = False
            self._On_Delete = False
            self._On_Edit_Start = False
            self._On_Edit_Finish = False
            self._On_Animate = False
            if kwargs:
                self.Config(**kwargs)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Init -> {E}')

    def __str__(self):
        try:
            return 'Nucleon_Wavionix_Table[]'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Str -> {E}')
            return 'Nucleon_Wavionix_Table[]'

    def __repr__(self):
        try:
            return 'Nucleon_Wavionix_Table[]'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Repr -> {E}')
            return 'Nucleon_Wavionix_Table[]'

    def _Hive_Color(self, Value):
        try:
            Hive = {
                'Hive_Yellow': '#F4C430',
                'Hive_Gold': '#D4A017',
                'Hive_Honey': '#FFBF00',
                'Hive_Amber': '#FFB000',
                'Hive_Orange': '#F28C28',
                'Hive_Brown': '#6B4F1D',
                'Hive_Dark': '#1F1B16',
                'Hive_Light': '#FFF8E1',
                'Hive_Cream': '#FFF3BF',
                'Hive_White': '#FFFFFF',
                'Hive_Black': '#000000',
            }
            if isinstance(Value, str) and Value in Hive:
                return Hive[Value]
            return Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hive_Color -> {E}')
            return Value

    def _Unit(self, Value):
        try:
            if Value in [None, False, '']:
                return None
            if isinstance(Value, (int, float)):
                return f'{Value}px'
            return str(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Unit -> {E}')
            return None

    def _Pixel(self, Value, Default=0):
        try:
            if Value in [None, False, '']:
                return f'{Default}px'
            if isinstance(Value, (int, float)):
                return f'{Value}px'
            Text = str(Value).strip()
            if Text.endswith('px'):
                return Text
            return f'{float(Text)}px'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Pixel -> {E}')
            return f'{Default}px'

    def _Get_Parent(self):
        try:
            if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
                return self._Main.Widget()
            if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
                return self._Main._Frame
            if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
                return self._Main._Widget
            return self._Main
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Parent -> {E}')
            return None

    def _Get_Shadow_Color(self):
        try:
            return self._Hive_Color(self._Shadow_Color)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Shadow_Color -> {E}')
            return 'transparent'

    def _Build_Shadow(self):
        try:
            return f'{self._Unit(self._Shadow_X) or "0px"} {self._Unit(self._Shadow_Y) or "0px"} {self._Unit(self._Shadow_Blur) or "0px"} {self._Unit(self._Shadow_Spread) or "0px"} {self._Get_Shadow_Color() or "transparent"}'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Shadow -> {E}')
            return '0px 0px 0px 0px transparent'

    def _Event_Arg(self, E, Index=0, Default=None):
        try:
            if not hasattr(E, 'args'):
                return Default
            Args = E.args
            if isinstance(Args, list) or isinstance(Args, tuple):
                if len(Args) > Index:
                    return Args[Index]
                return Default
            if isinstance(Args, dict):
                Keys = list(Args.keys())
                if len(Keys) > Index:
                    return Args[Keys[Index]]
                return Default
            return Default
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Event_Arg -> {E}')
            return Default

    def _Selected_Cell_Set(self):
        try:
            if not hasattr(self, '_Selected_Cells'):
                self._Selected_Cells = set()
            if len(self._Selected_Cells) > 0:
                return set(self._Selected_Cells)
            if self._Selected is not None:
                return {self._Selected}
            return set()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selected_Cell_Set -> {E}')
            return set()

    def _Cell_Is_Selected(self, Row, Column):
        try:
            Key = self._Data_Key(Row, Column)
            return Key in self._Selected_Cell_Set()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Cell_Is_Selected -> {E}')
            return False

    def _Selection_Rect(self, Start, End):
        try:
            Cells = set()
            if Start is None or End is None:
                return Cells
            Start_Row, Start_Column = Start
            End_Row, End_Column = End
            Row_1 = min(Start_Row, End_Row)
            Row_2 = max(Start_Row, End_Row)
            Column_1 = min(Start_Column, End_Column)
            Column_2 = max(Start_Column, End_Column)
            for Row in range(Row_1, Row_2 + 1):
                for Column in range(Column_1, Column_2 + 1):
                    if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                        Cells.add(self._Data_Key(Row, Column))
            return Cells
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_Rect -> {E}')
            return set()

    def _Set_Selected_Cells(self, Cells, Anchor=None, Fire=False):
        try:
            Old = self._Selected_Cell_Set()
            self._Selected_Cells = set(Cells)
            if Anchor is not None:
                self._Selected = Anchor
            elif len(self._Selected_Cells) > 0:
                self._Selected = sorted(list(self._Selected_Cells))[0]
            else:
                self._Selected = None
            New = self._Selected_Cell_Set()
            Changed = Old.symmetric_difference(New)
            for Key in Changed:
                self._Update_Cell_Visual(Key)
            if Fire:
                self._Fire_Select()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Set_Selected_Cells -> {E}')
            return False

    def _Selection_Bounds(self):
        try:
            Cells = self._Selected_Cell_Set()
            if len(Cells) == 0:
                return None
            Rows = [Each[0] for Each in Cells]
            Columns = [Each[1] for Each in Cells]
            return [min(Rows), min(Columns), max(Rows), max(Columns)]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_Bounds -> {E}')
            return None

    def _Selection_Text(self):
        try:
            Bounds = self._Selection_Bounds()
            if Bounds is None:
                return ''
            Row_1, Column_1, Row_2, Column_2 = Bounds
            Cells = self._Selected_Cell_Set()
            Lines = []
            for Row in range(Row_1, Row_2 + 1):
                Values = []
                for Column in range(Column_1, Column_2 + 1):
                    Key = self._Data_Key(Row, Column)
                    Values.append(self.Get(Row=Row, Column=Column) if Key in Cells else '')
                Lines.append('\t'.join(Values))
            return '\n'.join(Lines)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_Text -> {E}')
            return ''

    def _Fire_Select(self):
        try:
            Cells = sorted(list(self._Selected_Cell_Set()))
            if len(Cells) == 0:
                return
            Row, Column = self._Selected if self._Selected is not None else Cells[0]
            Value = self.Get(Row=Row, Column=Column)
            Text = self._Selection_Text()
            Values = self._Selection_List()
            if self._On_Select:
                self._On_Select(self._Make_Event(Row=Row, Column=Column, Value=Value, Name='select', Cells=Cells, Text=Text, List=Values))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Fire_Select -> {E}')

    def _Start_Select(self, Row, Column):
        try:
            if self._Disable or self._Cell_Is_Disabled(Row, Column):
                return
            if not self._Valid_Cell(Row, Column):
                return
            self._Cancel_Click_Timer()
            self._Dragging = True
            self._Select_Start = self._Data_Key(Row, Column)
            self._Set_Selected_Cells({self._Select_Start}, Anchor=self._Select_Start, Fire=False)
            if self._Frame is not None:
                try:
                    self._Frame.run_method('focus')
                except Exception:
                    pass
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Start_Select -> {E}')

    def _Drag_Select(self, Row, Column):
        try:
            if not self._Dragging:
                return
            if self._Disable or self._Cell_Is_Disabled(Row, Column):
                return
            if not self._Valid_Cell(Row, Column):
                return
            End = self._Data_Key(Row, Column)
            Cells = self._Selection_Rect(self._Select_Start, End)
            self._Set_Selected_Cells(Cells, Anchor=End, Fire=False)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Drag_Select -> {E}')

    def _End_Select(self, Row=None, Column=None):
        try:
            if not self._Dragging:
                return
            self._Dragging = False
            if Row is not None and Column is not None and self._Valid_Cell(Row, Column):
                End = self._Data_Key(Row, Column)
                Cells = self._Selection_Rect(self._Select_Start, End)
                self._Set_Selected_Cells(Cells, Anchor=End, Fire=False)
            self._Fire_Select()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _End_Select -> {E}')

    def _Selection_Visuals(self):
        try:
            Bounds = self._Selection_Bounds()
            if Bounds is None:
                return {}
            Row_1, Column_1, Row_2, Column_2 = Bounds
            Cells = self._Selected_Cell_Set()
            Styles = {}
            for Row in range(Row_1, Row_2 + 1):
                for Column in range(Column_1, Column_2 + 1):
                    Key = self._Data_Key(Row, Column)
                    if Key in Cells and Key in self._Cell_Styles:
                        Styles[(Row - Row_1, Column - Column_1)] = deepcopy(self._Cell_Styles[Key])
            return Styles
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_Visuals -> {E}')
            return {}
            
    def _Apply_Cell_Visual(self, Key, Style):
        try:
            if Style is None:
                if Key in self._Cell_Styles:
                    del self._Cell_Styles[Key]
                return True
            self._Cell_Styles[Key] = deepcopy(Style)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_Cell_Visual -> {E}')
            return False
            
    def _Refresh_Changed_Cells(self, Cells, Content=True):
        try:
            if not self._Initialized:
                return True
            if hasattr(self, '_Update_Cells'):
                if self._Update_Cells(Cells, Content=Content):
                    return True
            self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_Changed_Cells -> {E}')
            return False
            
    def _Apply_Paste_Visuals(self, Text, Cells, Row_1, Column_1, Data, Selected):
        try:
            if not getattr(type(self), '_Global_Clipboard_Visual_Ready', False):
                return []
            if not self._Clipboard_Text_Match(Text):
                return []
            Styles = getattr(type(self), '_Global_Clipboard_Cell_Styles', {})
            Changed = []
            Copy_Row_Count = max(1, int(getattr(type(self), '_Global_Clipboard_Row_Count', len(Data))))
            Copy_Column_Count = max(1, int(getattr(type(self), '_Global_Clipboard_Column_Count', max([len(Line) for Line in Data] + [1]))))
            Single_Fill = Copy_Row_Count == 1 and Copy_Column_Count == 1 and len(Selected) > 1
            if Single_Fill:
                Style = Styles.get((0, 0), None)
                for Key in Selected:
                    if not self._Valid_Cell(Key[0], Key[1]) or self._Cell_Is_Disabled(Key[0], Key[1]):
                        continue
                    self._Apply_Cell_Visual(Key, Style)
                    Changed.append(Key)
                return Changed
            Target_Cells = sorted(list(set(Selected))) if len(Selected) > 1 else sorted(list(set(Cells)))
            for Key in Target_Cells:
                Row, Column = Key
                if not self._Valid_Cell(Row, Column) or self._Cell_Is_Disabled(Row, Column):
                    continue
                Relative_Row = Row - Row_1
                Relative_Column = Column - Column_1
                Style_Key = (Relative_Row % Copy_Row_Count, Relative_Column % Copy_Column_Count)
                Style = Styles.get(Style_Key, None)
                self._Apply_Cell_Visual(Key, Style)
                Changed.append(Key)
            return Changed
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_Paste_Visuals -> {E}')
            return []

    def _Clipboard_Set(self, Text='', Styles=None, Row_Count=1, Column_Count=1):
        try:
            type(self)._Global_Clipboard_Text = '' if Text is None else str(Text)
            type(self)._Global_Clipboard_Cell_Styles = deepcopy({} if Styles is None else Styles)
            type(self)._Global_Clipboard_Row_Count = max(1, int(Row_Count))
            type(self)._Global_Clipboard_Column_Count = max(1, int(Column_Count))
            type(self)._Global_Clipboard_Visual_Ready = True
            self._Clipboard_Text = type(self)._Global_Clipboard_Text
            self._Clipboard_Cell_Styles = deepcopy(type(self)._Global_Clipboard_Cell_Styles)
            self._Clipboard_Visual_Ready = True
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Clipboard_Set -> {E}')
            return False

    def _Clipboard_Text_Match(self, Text):
        try:
            Text_Value = '' if Text is None else str(Text)
            Clipboard_Text = getattr(type(self), '_Global_Clipboard_Text', '')
            Text_Value = Text_Value.replace('\r\n', '\n').replace('\r', '\n')
            Clipboard_Text = Clipboard_Text.replace('\r\n', '\n').replace('\r', '\n')
            return Text_Value == Clipboard_Text
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Clipboard_Text_Match -> {E}')
            return False

    def _Selection_Size(self):
        try:
            Bounds = self._Selection_Bounds()
            if Bounds is None:
                return [1, 1]
            Row_1, Column_1, Row_2, Column_2 = Bounds
            return [max(1, Row_2 - Row_1 + 1), max(1, Column_2 - Column_1 + 1)]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_Size -> {E}')
            return [1, 1]

    def _Copy_Selected(self):
        try:
            Text = self._Selection_Text()
            Values = self._Selection_List()
            Cells = sorted(list(self._Selected_Cell_Set()))
            Row_Count, Column_Count = self._Selection_Size()
            self._Clipboard_Set(Text=Text, Styles=self._Selection_Visuals(), Row_Count=Row_Count, Column_Count=Column_Count)
            ui.run_javascript(f'navigator.clipboard.writeText({Text!r})')
            if self._On_Copy:
                self._On_Copy(self._Make_Event(Row=None, Column=None, Value=Text, Name='copy', Cells=Cells, Text=Text, List=Values))
            return Text
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Copy_Selected -> {E}')
            return ''

    def _Cut_Selected(self):
        try:
            if self._Disable:
                return ''
            Text = self._Selection_Text()
            Values = self._Selection_List()
            Cells = sorted(list(self._Selected_Cell_Set()))
            if len(Cells) == 0:
                return ''
            Row_Count, Column_Count = self._Selection_Size()
            self._Clipboard_Set(Text=Text, Styles=self._Selection_Visuals(), Row_Count=Row_Count, Column_Count=Column_Count)
            ui.run_javascript(f'navigator.clipboard.writeText({Text!r})')
            self._Push_Undo()
            Changed = []
            for Row, Column in Cells:
                Key = self._Data_Key(Row, Column)
                if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                    self._Data[Key] = ''
                    self._Apply_Cell_Visual(Key, None)
                    Changed.append(Key)
            if len(Changed) == 0:
                return ''
            self._Refresh_Changed_Cells(Changed, Content=True)
            if self._On_Cut:
                self._On_Cut(self._Make_Event(Row=None, Column=None, Value=Text, Name='cut', Cells=Changed, Text=Text, List=Values))
            return Text
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Cut_Selected -> {E}')
            return ''

    def _Paste_Text(self, Text=''):
        try:
            if self._Disable:
                return False
            if Text in [None, False]:
                Text = ''
            Text = str(Text)
            Internal_Visual = getattr(type(self), '_Global_Clipboard_Visual_Ready', False) and self._Clipboard_Text_Match(Text)
            if Text == '' and not Internal_Visual:
                return False
            Bounds = self._Selection_Bounds()
            if Bounds is None:
                return False
            Row_1, Column_1, Row_2, Column_2 = Bounds
            Data = self._Text_List(Text)
            Selected = sorted(list(self._Selected_Cell_Set()))
            Changed = []
            self._Push_Undo()
            Single_Fill = len(Data) == 1 and len(Data[0]) == 1 and len(Selected) > 1
            Multi_Target = len(Selected) > 1
            if Single_Fill:
                for Row, Column in Selected:
                    Key = self._Data_Key(Row, Column)
                    if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                        self._Data[Key] = Data[0][0]
                        Changed.append(Key)
            elif Multi_Target:
                Row_Count = len(Data)
                Column_Count = max([len(Line) for Line in Data] + [1])
                for Row, Column in Selected:
                    Key = self._Data_Key(Row, Column)
                    if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                        Relative_Row = Row - Row_1
                        Relative_Column = Column - Column_1
                        Data_Row = Relative_Row % Row_Count
                        Data_Column = Relative_Column % Column_Count
                        Value = ''
                        if Data_Row < len(Data) and Data_Column < len(Data[Data_Row]):
                            Value = Data[Data_Row][Data_Column]
                        self._Data[Key] = Value
                        Changed.append(Key)
            else:
                for Row_Index, Line in enumerate(Data):
                    for Column_Index, Value in enumerate(Line):
                        Row = Row_1 + Row_Index
                        Column = Column_1 + Column_Index
                        Key = self._Data_Key(Row, Column)
                        if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                            self._Data[Key] = Value
                            Changed.append(Key)
            if len(Changed) == 0:
                return False
            Cells = sorted(list(set(Changed)))
            Visual_Changed = self._Apply_Paste_Visuals(Text, Cells, Row_1, Column_1, Data, Selected)
            Refresh_Cells = sorted(list(set(Cells + Visual_Changed)))
            if self._Editing is not None:
                self._Render()
            else:
                self._Refresh_Changed_Cells(Refresh_Cells, Content=True)
            if self._On_Paste:
                self._On_Paste(self._Make_Event(Row=Row_1, Column=Column_1, Value=Text, Name='paste', Cells=Cells, Text=Text, List=Data))
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Paste_Text -> {E}')
            return False

    def _Delete_Selected(self):
        try:
            if self._Disable:
                return False
            Cells = sorted(list(self._Selected_Cell_Set()))
            Values = self._Selection_List()
            self._Push_Undo()
            Changed = []
            for Row, Column in Cells:
                Key = self._Data_Key(Row, Column)
                if self._Valid_Cell(Row, Column) and not self._Cell_Is_Disabled(Row, Column):
                    self._Data[Key] = ''
                    self._Apply_Cell_Visual(Key, None)
                    Changed.append(Key)
            if len(Changed) == 0:
                return False
            if self._Editing is not None:
                self._Render()
            else:
                self._Refresh_Changed_Cells(Changed, Content=True)
            if self._On_Delete:
                self._On_Delete(self._Make_Event(Row=None, Column=None, Value='', Name='delete', Cells=Changed, Text='', List=Values))
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Delete_Selected -> {E}')
            return False

    def _Move_Selected(self, Row_Change=0, Column_Change=0, Extend=False):
        try:
            if self._Disable:
                return False
            Current = self._Selected
            if Current is None:
                Current = (0, 0)
            Row = Current[0] + int(Row_Change)
            Column = Current[1] + int(Column_Change)
            Row = max(0, min(int(self._Rows) - 1, Row))
            Column = max(0, min(int(self._Columns) - 1, Column))
            Attempts = max(1, int(self._Rows) * int(self._Columns))
            while Attempts > 0 and self._Cell_Is_Disabled(Row, Column):
                Row = max(0, min(int(self._Rows) - 1, Row + int(Row_Change)))
                Column = max(0, min(int(self._Columns) - 1, Column + int(Column_Change)))
                Attempts -= 1
            if not self._Valid_Cell(Row, Column) or self._Cell_Is_Disabled(Row, Column):
                return False
            New_Key = self._Data_Key(Row, Column)
            if Extend:
                if self._Select_Start is None:
                    self._Select_Start = Current
                Cells = self._Selection_Rect(self._Select_Start, New_Key)
                self._Set_Selected_Cells(Cells, Anchor=New_Key, Fire=True)
            else:
                self._Select_Start = New_Key
                self._Set_Selected_Cells({New_Key}, Anchor=New_Key, Fire=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Move_Selected -> {E}')
            return False

    def _Handle_Edit_Key(self, E, Row, Column):
        try:
            Key = str(self._Event_Arg(E, 0, '') or '')
            if Key == 'Enter':
                self._Finish_Edit(Row, Column)
                return
            if Key == 'Escape':
                self._Cancel_Edit()
                return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Edit_Key -> {E}')

    async def _Handle_Key(self, E):
        try:
            if not self._Input_Allowed():
                return
            Detail = self._Key_Detail(E)
            if Detail:
                if not bool(Detail.get('focused', False)):
                    return
                if not bool(Detail.get('visible', True)):
                    return
                Key = str(Detail.get('key', '') or '')
                Ctrl = bool(Detail.get('ctrlKey', False)) or bool(Detail.get('metaKey', False))
                Shift = bool(Detail.get('shiftKey', False))
                Target = str(Detail.get('target', '') or '').lower()
            else:
                Key = str(self._Event_Arg(E, 0, '') or '')
                Ctrl = bool(self._Event_Arg(E, 1, False)) or bool(self._Event_Arg(E, 2, False))
                Shift = bool(self._Event_Arg(E, 3, False))
                Target = str(self._Event_Arg(E, 4, '') or '').lower()
            Lower = Key.lower()
            if self._Editing is not None:
                if Key == 'Enter':
                    Row, Column = self._Editing
                    self._Finish_Edit(Row, Column)
                    return
                if Key == 'Escape':
                    self._Cancel_Edit()
                    return
                return
            if Target in ['input', 'textarea', 'select']:
                return
            if Ctrl and Lower == 'z':
                self.Undo()
                return
            if Ctrl and Lower == 'y':
                self.Redo()
                return
            if Ctrl and Lower == 'c':
                Text = self._Copy_Selected()
                self._GUI.Notify('Copied' if Text != '' else 'Nothing To Copy')
                return
            if Ctrl and Lower == 'x':
                Text = self._Cut_Selected()
                self._GUI.Notify('Cut' if Text != '' else 'Nothing To Cut')
                return
            if Ctrl and Lower == 'v':
                try:
                    self._Paste_Block = True
                    ui.timer(0.75, lambda: setattr(self, '_Paste_Block', False), once=True)
                    Text = await ui.run_javascript('navigator.clipboard.readText()')
                    if self._Paste_Text(Text):
                        self._GUI.Notify('Pasted')
                    else:
                        self._GUI.Notify('Nothing To Paste')
                except Exception:
                    self._GUI.Notify('Paste Failed')
                return
            if Key == 'Delete':
                if self._Delete_Selected():
                    self._GUI.Notify('Deleted')
                else:
                    self._GUI.Notify('Nothing To Delete')
                return
            if Key == 'Enter':
                self._Edit_Selected()
                return
            if Key == 'ArrowUp':
                self._Move_Selected(Row_Change=-1, Column_Change=0, Extend=Shift)
                return
            if Key == 'ArrowDown':
                self._Move_Selected(Row_Change=1, Column_Change=0, Extend=Shift)
                return
            if Key == 'ArrowLeft':
                self._Move_Selected(Row_Change=0, Column_Change=-1, Extend=Shift)
                return
            if Key == 'ArrowRight':
                self._Move_Selected(Row_Change=0, Column_Change=1, Extend=Shift)
                return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Key -> {E}')

    def _Handle_Paste(self, E):
        try:
            if not self._Input_Allowed():
                return
            Detail = self._Key_Detail(E)
            if Detail:
                if not bool(Detail.get('focused', False)):
                    return
                if not bool(Detail.get('visible', True)):
                    return
                Text = Detail.get('text', '')
            else:
                Text = self._Event_Arg(E, 0, '')
            if getattr(self, '_Paste_Block', False):
                return
            if Text in [None, False, '']:
                return
            if self._Paste_Text(Text):
                self._GUI.Notify('Pasted')
            else:
                self._GUI.Notify('Nothing To Paste')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Paste -> {E}')

    def _Text_List(self, Text=''):
        try:
            if Text in [None, False]:
                Text = ''
            Lines = str(Text).splitlines()
            if len(Lines) == 0:
                Lines = ['']
            return [Line.split('\t') for Line in Lines]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Text_List -> {E}')
            return []

    def _Selection_List(self):
        try:
            Bounds = self._Selection_Bounds()
            if Bounds is None:
                return []
            Row_1, Column_1, Row_2, Column_2 = Bounds
            Cells = self._Selected_Cell_Set()
            Values = []
            for Row in range(Row_1, Row_2 + 1):
                Line = []
                for Column in range(Column_1, Column_2 + 1):
                    Key = self._Data_Key(Row, Column)
                    Line.append(self.Get(Row=Row, Column=Column) if Key in Cells else '')
                Values.append(Line)
            return Values
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Selection_List -> {E}')
            return []

    def _Begin_Edit(self, Row, Column):
        try:
            self._Cancel_Click_Timer()
            if not self._Editable or self._Disable or self._Cell_Is_Disabled(Row, Column):
                return False
            if not self._Valid_Cell(Row, Column):
                return False
            Old_Cells = self._Selected_Cell_Set()
            self._Selected = self._Data_Key(Row, Column)
            self._Selected_Cells = {self._Selected}
            for Key in Old_Cells:
                self._Update_Cell_Visual(Key)
            self._Update_Cell_Visual(self._Selected)
            self._Editing = self._Data_Key(Row, Column)
            Value = self.Get(Row=Row, Column=Column)
            self._Render()
            if self._On_Edit_Start:
                self._On_Edit_Start(self._Make_Event(Row=Row, Column=Column, Value=Value, Name='edit_start', Cells=[self._Selected], Text=str(Value), List=[[Value]]))
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Begin_Edit -> {E}')
            return False

    def _Edit_Selected(self):
        try:
            if self._Selected is None:
                return False
            Row, Column = self._Selected
            return self._Begin_Edit(Row, Column)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Edit_Selected -> {E}')
            return False

    def _State_Value(self, State, Section, Key):
        try:
            Data = State.get(Section, {})
            Text_Key = self._Table_Key_To_Text(Key)
            return deepcopy(Data.get(Text_Key, None))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _State_Value -> {E}')
            return None
            
    def _State_Key_Set(self, Before, After, Section):
        try:
            Keys = set()
            for Key in Before.get(Section, {}).keys():
                Keys.add(self._Dict_To_Table_Key(Key))
            for Key in After.get(Section, {}).keys():
                Keys.add(self._Dict_To_Table_Key(Key))
            return Keys
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _State_Key_Set -> {E}')
            return set()
            
    def _State_Disabled_Set(self, State):
        try:
            Result = set()
            for Key in State.get('Disabled_Cells', []):
                Result.add(self._Dict_To_Table_Key(Key))
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _State_Disabled_Set -> {E}')
            return set()
            
    def _State_Changes(self, Before, After):
        try:
            Changes = []
            Cells = set()
            for Key in sorted(list(self._State_Key_Set(Before, After, 'Data'))):
                Old_Value = self._State_Value(Before, 'Data', Key)
                New_Value = self._State_Value(After, 'Data', Key)
                if Old_Value != New_Value:
                    Cells.add(Key)
                    Changes.append({'Type': 'Cell', 'Row': Key[0], 'Column': Key[1], 'Old_Value': '' if Old_Value is None else Old_Value, 'New_Value': '' if New_Value is None else New_Value})
            for Key in sorted(list(self._State_Key_Set(Before, After, 'Cell_Styles'))):
                Old_Value = self._State_Value(Before, 'Cell_Styles', Key)
                New_Value = self._State_Value(After, 'Cell_Styles', Key)
                if Old_Value != New_Value:
                    Cells.add(Key)
                    Changes.append({'Type': 'Cell_Style', 'Row': Key[0], 'Column': Key[1], 'Old_Value': Old_Value, 'New_Value': New_Value})
            Before_Disabled = self._State_Disabled_Set(Before)
            After_Disabled = self._State_Disabled_Set(After)
            for Key in sorted(list(Before_Disabled.symmetric_difference(After_Disabled))):
                Cells.add(Key)
                Changes.append({'Type': 'Cell_Disabled', 'Row': Key[0], 'Column': Key[1], 'Old_Value': Key in Before_Disabled, 'New_Value': Key in After_Disabled})
            for Key in sorted(list(self._State_Key_Set(Before, After, 'Headings'))):
                Old_Value = self._State_Value(Before, 'Headings', Key)
                New_Value = self._State_Value(After, 'Headings', Key)
                if Old_Value != New_Value:
                    Changes.append({'Type': 'Heading', 'Row': Key[0], 'Column': Key[1], 'Old_Value': '' if Old_Value is None else Old_Value, 'New_Value': '' if New_Value is None else New_Value})
            for Key in sorted(list(self._State_Key_Set(Before, After, 'Heading_Styles'))):
                Old_Value = self._State_Value(Before, 'Heading_Styles', Key)
                New_Value = self._State_Value(After, 'Heading_Styles', Key)
                if Old_Value != New_Value:
                    Changes.append({'Type': 'Heading_Style', 'Row': Key[0], 'Column': Key[1], 'Old_Value': Old_Value, 'New_Value': New_Value})
            Before_Size = Before.get('Size', {})
            After_Size = After.get('Size', {})
            for Name in sorted(list(set(list(Before_Size.keys()) + list(After_Size.keys())))):
                Old_Value = Before_Size.get(Name, None)
                New_Value = After_Size.get(Name, None)
                if Old_Value != New_Value:
                    Changes.append({'Type': 'Size', 'Name': Name, 'Old_Value': Old_Value, 'New_Value': New_Value})
            return [sorted(list(Cells)), Changes]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _State_Changes -> {E}')
            return [[], []]

    def _Make_Event(self, Row=None, Column=None, Value=None, Old_Value=None, Name=None, Cells=None, Text=None, List=None, Changes=None):
        try:
            Payload = {
                'row': Row,
                'column': Column,
                'value': Value,
                'old_value': Old_Value,
                'name': Name,
                'cells': Cells,
                'text': Text,
                'list': List,
                'values': List,
                'changes': Changes,
                'Changes': Changes,
                'table': self,
            }
            return type('Table_Event', (), Payload)()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Make_Event -> {E}')
            return type('Table_Event', (), {})()

    def _Valid_Cell(self, Row, Column):
        try:
            return Row >= 0 and Column >= 0 and Row < int(self._Rows) and Column < int(self._Columns)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Valid_Cell -> {E}')
            return False

    def _Valid_Heading(self, Row, Column):
        try:
            if Row < 0 or Column < 0:
                return False
            if Row != 0 and Column != 0:
                return False
            if Row == 0 and Column == 0:
                return True
            if Row == 0:
                return Column <= int(self._Columns)
            return Row <= int(self._Rows)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Valid_Heading -> {E}')
            return False

    def _Data_Key(self, Row, Column):
        try:
            return (int(Row), int(Column))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Data_Key -> {E}')
            return (0, 0)

    def _Heading_Key(self, Row, Column):
        try:
            return (int(Row), int(Column))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Heading_Key -> {E}')
            return (0, 0)

    def _Get_Cell_Style_Data(self, Row, Column):
        try:
            Key = self._Data_Key(Row, Column)
            Data = {
                'Background': self._Cell_Background,
                'Foreground': self._Cell_Foreground,
                'Font_Size': self._Cell_Font_Size,
                'Font_Weight': self._Cell_Font_Weight,
                'Font_Family': self._Cell_Font_Family,
            }
            if Key in self._Cell_Styles:
                Data.update(self._Cell_Styles[Key])
            return Data
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Cell_Style_Data -> {E}')
            return {}

    def _Get_Heading_Style_Data(self, Row, Column):
        try:
            Key = self._Heading_Key(Row, Column)
            Data = {
                'Background': self._Heading_Background,
                'Foreground': self._Heading_Foreground,
                'Font_Size': self._Heading_Font_Size,
                'Font_Weight': self._Heading_Font_Weight,
                'Font_Family': self._Heading_Font_Family,
            }
            if Key in self._Heading_Styles:
                Data.update(self._Heading_Styles[Key])
            return Data
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Heading_Style_Data -> {E}')
            return {}

    def _Cell_Is_Disabled(self, Row, Column):
        try:
            return self._Data_Key(Row, Column) in self._Disabled_Cells
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Cell_Is_Disabled -> {E}')
            return False

    def _Cancel_Click_Timer(self):
        try:
            if self._Click_Timer is not None:
                try:
                    self._Click_Timer.cancel()
                except Exception:
                    try:
                        self._Click_Timer.deactivate()
                    except Exception:
                        pass
            self._Click_Timer = None
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Cancel_Click_Timer -> {E}')
            return False

    def _Run_Click_Cell(self, Row, Column):
        try:
            self._Click_Timer = None
            if self._Disable or self._Cell_Is_Disabled(Row, Column):
                return
            if not self._Valid_Cell(Row, Column):
                return
            self._Selected = self._Data_Key(Row, Column)
            Value = self.Get(Row=Row, Column=Column)
            self._Render()
            if self._On_Select:
                self._On_Select(self._Make_Event(Row=Row, Column=Column, Value=Value, Name='select'))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Run_Click_Cell -> {E}')

    def _Edit_Class_Name(self):
        try:
            if not hasattr(self, '_Edit_Class') or not self._Edit_Class:
                self._Edit_Class = f'wavionix-table-edit-{id(self)}'
            return self._Edit_Class
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Edit_Class_Name -> {E}')
            return f'wavionix-table-edit-{id(self)}'

    def _Apply_Edit_CSS(self):
        try:
            CSS_Class = self._Edit_Class_Name()
            Cell_Height = self._Pixel(self._Cell_Height, 32)
            CSS = f'.{CSS_Class}.q-field {{ width:100% !important; height:100% !important; min-height:0 !important; margin:0 !important; padding:0 !important; display:block !important; }} .{CSS_Class} .q-field__inner {{ width:100% !important; height:100% !important; min-height:0 !important; margin:0 !important; padding:0 !important; display:block !important; }} .{CSS_Class} .q-field__control {{ width:100% !important; height:100% !important; min-height:0 !important; margin:0 !important; padding:0 8px !important; display:flex !important; align-items:center !important; background:transparent !important; }} .{CSS_Class} .q-field__control-container {{ width:100% !important; height:100% !important; min-height:0 !important; display:flex !important; align-items:center !important; }} .{CSS_Class} .q-field__control:before {{ display:none !important; }} .{CSS_Class} .q-field__control:after {{ display:none !important; }} .{CSS_Class} .q-field__native {{ width:100% !important; height:{Cell_Height} !important; min-height:0 !important; margin:0 !important; padding:0 !important; line-height:{Cell_Height} !important; display:block !important; }} .{CSS_Class} input {{ width:100% !important; height:{Cell_Height} !important; min-height:0 !important; margin:0 !important; padding:0 !important; line-height:{Cell_Height} !important; display:block !important; }}'
            Safe_CSS = CSS.replace('`', '')
            Safe_ID = f'{CSS_Class}-style'
            ui.add_head_html(f'''<script>
                (() => {{
                let Style_Tag = document.getElementById('{Safe_ID}');
                if (!Style_Tag) {{
                Style_Tag = document.createElement('style');
                Style_Tag.id = '{Safe_ID}';
                document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_CSS}`;
                }})();
                </script>''')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_Edit_CSS -> {E}')
            return False

    def _Update_Cell_Visual(self, Key):
        try:
            if Key is None:
                return True
            if not hasattr(self, '_Cell_Widgets'):
                self._Cell_Widgets = {}
            if Key not in self._Cell_Widgets:
                return False
            Row, Column = Key
            Cell = self._Cell_Widgets[Key]
            if Cell is None:
                return False
            if hasattr(Cell, '_style'):
                Cell._style.clear()
            Cell.style(self._Build_Cell_Style(Row, Column))
            Cell.update()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Cell_Visual -> {E}')
            return False

    def _Build_Frame_Style(self):
        try:
            Box = self._Animate_Current_Box()
            Transition = 'all 0.2s ease'
            if self._Animate_Transition:
                Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
            Style = []
            Style.append('box-sizing: border-box')
            Style.append(f'display: {"block" if self._Display or self._Animating else "none"}')
            Style.append('position: relative')
            Style.append('overflow: hidden')
            Style.append('outline: none')
            Style.append('user-select: none')
            Style.append(f'background: {self._Hive_Color(self._Background)}')
            Style.append(f'color: {self._Hive_Color(self._Foreground)}')
            Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Hive_Color(self._Border_Color)}')
            Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
            Style.append(f'box-shadow: {self._Build_Shadow()}')
            Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
            Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
            Style.append(f'transition: {Transition}')
            if self._Mode == 'Place':
                Style.append('position: absolute')
                if Box['Left'] is not None:
                    Style.append(f'left: {self._Unit(Box["Left"])}')
                if Box['Top'] is not None:
                    Style.append(f'top: {self._Unit(Box["Top"])}')
                if self._Right is not None:
                    Style.append(f'right: {self._Unit(self._Right)}')
                if self._Bottom is not None:
                    Style.append(f'bottom: {self._Unit(self._Bottom)}')
            if Box['Width'] is not None:
                Style.append(f'width: {self._Unit(Box["Width"])}')
            if Box['Height'] is not None:
                Style.append(f'height: {self._Unit(Box["Height"])}')
                Style.append(f'min-height: {self._Unit(Box["Height"])}')
            if self._Z_Index is not None:
                Style.append(f'z-index: {self._Z_Index}')
            if self._Disable:
                Style.append('opacity: 0.55')
            if self._Style:
                Style.append(str(self._Style))
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Frame_Style -> {E}')
            return ''

    def _Build_Body_Style(self):
        try:
            Style = []
            Style.append('box-sizing: border-box')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('overflow: auto' if self._Scrollbar_Active else 'overflow: hidden')
            Style.append(f'scrollbar-width: {"thin" if int(self._Scrollbar_Size) <= 10 else "auto"}')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Body_Style -> {E}')
            return 'width:100%; height:100%; overflow:auto'

    def _Build_Grid_Style(self):
        try:
            Columns = []
            Rows = []
            if self._Row_Heading:
                Columns.append(self._Pixel(self._Heading_Width, 120))
            for Each in range(int(self._Columns)):
                Columns.append(self._Pixel(self._Cell_Width, 120))
            if self._Column_Heading:
                Rows.append(self._Pixel(self._Heading_Height, 32))
            for Each in range(int(self._Rows)):
                Rows.append(self._Pixel(self._Cell_Height, 32))
            Style = []
            Style.append('display: grid')
            Style.append(f'grid-template-columns: {" ".join(Columns)}')
            Style.append(f'grid-template-rows: {" ".join(Rows)}')
            Style.append('width: max-content')
            Style.append('height: max-content')
            Style.append('box-sizing: border-box')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Grid_Style -> {E}')
            return ''

    def _Build_Cell_Style(self, Row, Column):
        try:
            Key = self._Data_Key(Row, Column)
            Data = self._Get_Cell_Style_Data(Row, Column)
            Selected = self._Cell_Is_Selected(Row, Column)
            Editing = self._Editing == Key
            Disabled = self._Disable or self._Cell_Is_Disabled(Row, Column)
            Background = self._Hive_Color(self._Selected_Background if Selected and not Disabled else Data.get('Background'))
            Foreground = self._Hive_Color(self._Selected_Foreground if Selected and self._Selected_Foreground and not Disabled else Data.get('Foreground'))
            if Disabled:
                Background = self._Hive_Color(self._Cell_Disable_Background)
                Foreground = self._Hive_Color(self._Cell_Disable_Foreground)
            Style = []
            Style.append('box-sizing: border-box')
            Style.append('display: flex')
            Style.append('align-items: center')
            Style.append('justify-content: flex-start')
            Style.append('overflow: hidden')
            Style.append('white-space: nowrap')
            Style.append('text-overflow: ellipsis')
            Style.append('user-select: none')
            Style.append('cursor: not-allowed' if Disabled else 'cursor: pointer')
            Style.append(f'background: {Background}')
            Style.append(f'color: {Foreground}')
            Style.append(f'font-size: {self._Unit(Data.get("Font_Size")) or "12px"}')
            Style.append(f'font-weight: {Data.get("Font_Weight")}')
            Style.append(f'font-family: {Data.get("Font_Family")}')
            Style.append(f'border: {self._Unit(self._Grid_Size) or "1px"} solid {self._Hive_Color(self._Grid_Color)}')
            Style.append('padding: 0' if Editing else 'padding: 0 8px')
            Style.append('min-width: 0')
            Style.append('min-height: 0')
            Style.append('transition: background 0.04s ease, color 0.04s ease')
            if Disabled:
                Style.append(f'opacity: {self._Cell_Disable_Opacity}')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Cell_Style -> {E}')
            return ''

    def _Build_Heading_Style(self, Row, Column):
        try:
            Data = self._Get_Heading_Style_Data(Row, Column)
            Style = []
            Style.append('box-sizing: border-box')
            Style.append('display: flex')
            Style.append('align-items: center')
            Style.append('justify-content: center')
            Style.append('overflow: hidden')
            Style.append('white-space: nowrap')
            Style.append('text-overflow: ellipsis')
            Style.append('user-select: none')
            Style.append(f'background: {self._Hive_Color(Data.get("Background"))}')
            Style.append(f'color: {self._Hive_Color(Data.get("Foreground"))}')
            Style.append(f'font-size: {self._Unit(Data.get("Font_Size")) or "12px"}')
            Style.append(f'font-weight: {Data.get("Font_Weight")}')
            Style.append(f'font-family: {Data.get("Font_Family")}')
            Style.append(f'border: {self._Unit(self._Grid_Size) or "1px"} solid {self._Hive_Color(self._Grid_Color)}')
            Style.append('padding: 0 8px')
            Style.append('min-width: 0')
            Style.append('min-height: 0')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Heading_Style -> {E}')
            return ''

    def _Build_Edit_Style(self):
        try:
            Style = []
            Style.append('box-sizing: border-box')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('min-height: 0')
            Style.append('margin: 0')
            Style.append('padding: 0')
            Style.append('display: block')
            Style.append(f'background: {self._Hive_Color(self._Edit_Background)}')
            Style.append(f'color: {self._Hive_Color(self._Edit_Foreground)}')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Edit_Style -> {E}')
            return ''

    def _Click_Cell(self, Row, Column):
        try:
            if self._Disable or self._Cell_Is_Disabled(Row, Column):
                return
            if not self._Valid_Cell(Row, Column):
                return
            self._Start_Select(Row, Column)
            self._End_Select(Row, Column)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Click_Cell -> {E}')

    def _Double_Click_Cell(self, Row, Column):
        try:
            self._Begin_Edit(Row, Column)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Double_Click_Cell -> {E}')

    def _Focus_Frame(self):
        try:
            if self._Frame is None:
                return False
            ui.run_javascript(f'''setTimeout(() => {{
                const Element = document.getElementById('c{self._Frame.id}');
                if (!Element) return;
                Element.focus();
            }}, 30);''')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Focus_Frame -> {E}')
            return False

    def _Finish_Edit(self, Row, Column):
        try:
            if self._Disable or self._Cell_Is_Disabled(Row, Column):
                self._Cancel_Edit()
                return
            Key = self._Data_Key(Row, Column)
            if self._Editing != Key:
                return
            Old_Value = self.Get(Row=Row, Column=Column)
            New_Value = '' if self._Edit_Input is None or self._Edit_Input.value is None else str(self._Edit_Input.value)
            if Old_Value != New_Value:
                self._Push_Undo()
            self._Data[Key] = New_Value
            self._Selected = Key
            self._Selected_Cells = {Key}
            self._Select_Start = Key
            self._Editing = None
            self._Edit_Input = None
            self._Render()
            self._Focus_Frame()
            if self._On_Edit_Finish:
                self._On_Edit_Finish(self._Make_Event(Row=Row, Column=Column, Value=New_Value, Old_Value=Old_Value, Name='edit_finish', Cells=[Key], Text=New_Value, List=[[New_Value]]))
            if self._On_Change:
                self._On_Change(self._Make_Event(Row=Row, Column=Column, Value=New_Value, Old_Value=Old_Value, Name='change', Cells=[Key], Text=New_Value, List=[[New_Value]]))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Finish_Edit -> {E}')

    def _Cancel_Edit(self):
        try:
            Key = self._Editing
            self._Editing = None
            self._Edit_Input = None
            if Key is not None:
                self._Selected = Key
                self._Selected_Cells = {Key}
                self._Select_Start = Key
            self._Render()
            self._Focus_Frame()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Cancel_Edit -> {E}')

    def _Render_Heading(self, Parent, Row, Column, Value):
        try:
            with Parent:
                Cell = ui.element('div').style(self._Build_Heading_Style(Row, Column))
                with Cell:
                    ui.label(str(Value))
            return Cell
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Heading -> {E}')

    def _Render_Cell_Content(self, Cell, Row, Column):
        try:
            Key = self._Data_Key(Row, Column)
            Value = self.Get(Row=Row, Column=Column)
            Editing = self._Editing == Key
            with Cell:
                if Editing:
                    self._Apply_Edit_CSS()
                    Data = self._Get_Cell_Style_Data(Row, Column)
                    Input_Box = ui.input(value=str(Value))
                    Input_Box.classes(self._Edit_Class_Name())
                    Input_Box.props(f'borderless dense autofocus input-style="height:{self._Pixel(self._Cell_Height, 32)};min-height:0;padding:0;margin:0;line-height:{self._Pixel(self._Cell_Height, 32)};color:{self._Hive_Color(self._Edit_Foreground)};font-size:{self._Unit(Data.get("Font_Size")) or "12px"};font-weight:{Data.get("Font_Weight")};font-family:{Data.get("Font_Family")};"')
                    Input_Box.style(self._Build_Edit_Style())
                    Input_Box.on('keydown', lambda E=None, Row=Row, Column=Column: self._Handle_Edit_Key(E, Row, Column), ['key'])
                    Input_Box.on('blur', lambda E=None, Row=Row, Column=Column: self._Finish_Edit(Row, Column))
                    self._Edit_Input = Input_Box
                    Class_Name = self._Edit_Class_Name()
                    ui.run_javascript(f'''setTimeout(() => {{
                            const Input = document.querySelector('.{Class_Name} input');
                            if (!Input) return;
                            Input.focus();
                            Input.select();
                        }}, 30);''')
                else:
                    Label = ui.label(str(Value)).style('overflow:hidden; text-overflow:ellipsis; white-space:nowrap; width:100%;')
                    if not hasattr(self, '_Cell_Text_Widgets'):
                        self._Cell_Text_Widgets = {}
                    self._Cell_Text_Widgets[Key] = Label
                    if str(Value) != '':
                        ui.tooltip(str(Value)).props(f'delay={int(float(self._Tooltip_Delay) * 1000)}')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Cell_Content -> {E}')

    def _Render_Cell(self, Parent, Row, Column):
        try:
            Key = self._Data_Key(Row, Column)
            Editing = self._Editing == Key
            with Parent:
                Cell = ui.element('div').style(self._Build_Cell_Style(Row, Column))
                if not hasattr(self, '_Cell_Widgets'):
                    self._Cell_Widgets = {}
                self._Cell_Widgets[Key] = Cell
                if not Editing:
                    Cell.on('mousedown', lambda E=None, Row=Row, Column=Column: self._Start_Select(Row, Column))
                    Cell.on('mouseenter', lambda E=None, Row=Row, Column=Column: self._Drag_Select(Row, Column))
                    Cell.on('mouseup', lambda E=None, Row=Row, Column=Column: self._End_Select(Row, Column))
                    Cell.on('dblclick', lambda E=None, Row=Row, Column=Column: self._Double_Click_Cell(Row, Column))
                self._Render_Cell_Content(Cell, Row, Column)
            return Cell
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Cell -> {E}')

    def _Update_Cell(self, Key, Content=True):
        try:
            if Key is None:
                return False
            if not hasattr(self, '_Cell_Widgets'):
                self._Cell_Widgets = {}
            if not hasattr(self, '_Cell_Text_Widgets'):
                self._Cell_Text_Widgets = {}
            if Key not in self._Cell_Widgets:
                return False
            Row, Column = Key
            Cell = self._Cell_Widgets[Key]
            if Cell is None:
                return False
            if hasattr(Cell, '_style'):
                Cell._style.clear()
            Cell.style(self._Build_Cell_Style(Row, Column))
            if Content:
                Cell.clear()
                if Key in self._Cell_Text_Widgets:
                    del self._Cell_Text_Widgets[Key]
                self._Render_Cell_Content(Cell, Row, Column)
            Cell.update()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Cell -> {E}')
            return False

    def _Update_Cells(self, Cells, Content=True):
        try:
            if Cells is None:
                return False
            Updated = False
            for Key in sorted(list(set(Cells))):
                if self._Update_Cell(Key, Content=Content):
                    Updated = True
            return Updated
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Cells -> {E}')
            return False

    def _Render(self):
        try:
            if self._Body is None:
                return
            self._Cell_Widgets = {}
            self._Cell_Text_Widgets = {}
            self._Body.clear()
            with self._Body:
                Grid = ui.element('div').style(self._Build_Grid_Style())
                with Grid:
                    if self._Column_Heading:
                        if self._Row_Heading:
                            self._Render_Heading(Grid, 0, 0, self.Get_Heading(Row=0, Column=0))
                        for Column in range(int(self._Columns)):
                            self._Render_Heading(Grid, 0, Column + 1, self.Get_Heading(Row=0, Column=Column + 1))
                    for Row in range(int(self._Rows)):
                        if self._Row_Heading:
                            self._Render_Heading(Grid, Row + 1, 0, self.Get_Heading(Row=Row + 1, Column=0))
                        for Column in range(int(self._Columns)):
                            self._Render_Cell(Grid, Row, Column)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None:
                return
            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()
            self._Frame.style(self._Build_Frame_Style())
            if self._Classes not in [False, None, '']:
                self._Frame.classes(str(self._Classes))
            if self._Body is not None:
                if hasattr(self._Body, '_style'):
                    self._Body._style.clear()
                self._Body.style(self._Build_Body_Style())
                self._Body.update()
            self._Frame.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Time_CSS -> {E}')
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Time_MS -> {E}')
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def _Input_Allowed(self):
        try:
            if not self._Display:
                return False
            if self._Frame is None:
                return False
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Input_Allowed -> {E}')
            return False
            
    def _Key_Detail(self, E):
        try:
            Args = getattr(E, 'args', None)
            if isinstance(Args, dict):
                if 'key' in Args or 'text' in Args:
                    return Args
                if 'detail' in Args and isinstance(Args['detail'], dict):
                    return Args['detail']
            if isinstance(Args, list) or isinstance(Args, tuple):
                if len(Args) > 0 and isinstance(Args[0], dict):
                    return Args[0]
            return {}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Key_Detail -> {E}')
            return {}
            
    async def _Install_Key_Events(self):
        try:
            self._Key_Event_Timer = None
            if self._Frame is None:
                return False
            Element_Id = f'c{self._Frame.id}'
            JavaScript = f'''
                const Element = document.getElementById("{Element_Id}");
                if (!Element || Element.__Wavionix_Table_Key_Ready) return;
                Element.__Wavionix_Table_Key_Ready = true;
                const Visible = () => {{
                    if (!Element.isConnected) return false;
                    const Style = window.getComputedStyle(Element);
                    const Box = Element.getBoundingClientRect();
                    if (Style.display === "none" || Style.visibility === "hidden" || Style.pointerEvents === "none") return false;
                    if (Box.width <= 0 || Box.height <= 0) return false;
                    return true;
                }};
                const Focused = () => document.activeElement === Element || Element.contains(document.activeElement);
                Element.addEventListener("keydown", Event => {{
                    if (!Visible()) return;
                    if (!Focused()) return;
                    const Target = Event.target && Event.target.tagName ? Event.target.tagName : "";
                    Element.dispatchEvent(new CustomEvent("table-key", {{detail: {{
                        key: Event.key,
                        ctrlKey: Event.ctrlKey,
                        metaKey: Event.metaKey,
                        shiftKey: Event.shiftKey,
                        target: Target,
                        focused: Focused(),
                        visible: Visible()
                    }}, bubbles: true}}));
                }});
                Element.addEventListener("paste", Event => {{
                    if (!Visible()) return;
                    if (!Focused()) return;
                    const Text = Event.clipboardData ? Event.clipboardData.getData("text") : "";
                    Element.dispatchEvent(new CustomEvent("table-paste", {{detail: {{
                        text: Text,
                        focused: Focused(),
                        visible: Visible()
                    }}, bubbles: true}}));
                }});
                '''
            Result = ui.run_javascript(JavaScript)
            if hasattr(Result, '__await__'):
                await Result
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Install_Key_Events -> {E}')
            return False

    def _Queue_Key_Events(self):
        try:
            if self._Frame is None:
                return False
            if getattr(self, '_Key_Event_Timer', None) is not None:
                return True
            self._Key_Event_Timer = ui.timer(0.05, self._Install_Key_Events, once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Queue_Key_Events -> {E}')
            return False

    def _Dict_To_Table_Key(self, Key):
        try:
            if isinstance(Key, tuple) and len(Key) == 2:
                return (int(Key[0]), int(Key[1]))
            if isinstance(Key, list) and len(Key) == 2:
                return (int(Key[0]), int(Key[1]))
            Text = str(Key)
            if ',' in Text:
                Row, Column = Text.split(',', 1)
                return (int(Row), int(Column))
            return (0, 0)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dict_To_Table_Key -> {E}')
            return (0, 0)

    def _Table_Key_To_Text(self, Key):
        try:
            return f'{int(Key[0])},{int(Key[1])}'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Table_Key_To_Text -> {E}')
            return '0,0'

    def _Snapshot(self):
        try:
            return self.Export()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Snapshot -> {E}')
            return {}
            
    def _Push_Undo(self):
        try:
            if getattr(self, '_History_Block', False):
                return False
            if not hasattr(self, '_Undo_Stack'):
                self._Undo_Stack = []
            if not hasattr(self, '_Redo_Stack'):
                self._Redo_Stack = []
            self._Undo_Stack.append(self._Snapshot())
            Limit = int(getattr(self, '_History_Limit', 100))
            if Limit > 0 and len(self._Undo_Stack) > Limit:
                self._Undo_Stack = self._Undo_Stack[-Limit:]
            self._Redo_Stack = []
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Push_Undo -> {E}')
            return False

    def _Import_State(self, Data):
        try:
            if not isinstance(Data, dict):
                return False
            Size = Data.get('Size', {})
            if isinstance(Size, dict):
                self._Rows = int(Size.get('Rows', self._Rows))
                self._Columns = int(Size.get('Columns', self._Columns))
                self._Column_Heading = bool(Size.get('Column_Heading', self._Column_Heading))
                self._Row_Heading = bool(Size.get('Row_Heading', self._Row_Heading))
                self._Cell_Width = Size.get('Cell_Width', self._Cell_Width)
                self._Cell_Height = Size.get('Cell_Height', self._Cell_Height)
                self._Heading_Width = Size.get('Heading_Width', self._Heading_Width)
                self._Heading_Height = Size.get('Heading_Height', self._Heading_Height)
            self._Data = {}
            for Key, Value in Data.get('Data', {}).items():
                self._Data[self._Dict_To_Table_Key(Key)] = '' if Value is None else str(Value)
            self._Headings = {}
            for Key, Value in Data.get('Headings', {}).items():
                self._Headings[self._Dict_To_Table_Key(Key)] = '' if Value is None else str(Value)
            self._Cell_Styles = {}
            for Key, Value in Data.get('Cell_Styles', {}).items():
                if isinstance(Value, dict):
                    self._Cell_Styles[self._Dict_To_Table_Key(Key)] = deepcopy(Value)
            self._Heading_Styles = {}
            for Key, Value in Data.get('Heading_Styles', {}).items():
                if isinstance(Value, dict):
                    self._Heading_Styles[self._Dict_To_Table_Key(Key)] = deepcopy(Value)
            self._Disabled_Cells = set()
            for Key in Data.get('Disabled_Cells', []):
                self._Disabled_Cells.add(self._Dict_To_Table_Key(Key))
            self._Selected = None
            self._Selected_Cells = set()
            self._Select_Start = None
            self._Dragging = False
            self._Editing = None
            self._Edit_Input = None
            self._Cancel_Click_Timer()
            if self._Initialized:
                self._Apply()
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Import_State -> {E}')
            return False

    def Export(self):
        try:
            Data = {
                'Type': self._Type,
                'Version': 1,
                'Size': {
                    'Rows': int(self._Rows),
                    'Columns': int(self._Columns),
                    'Column_Heading': bool(self._Column_Heading),
                    'Row_Heading': bool(self._Row_Heading),
                    'Cell_Width': deepcopy(self._Cell_Width),
                    'Cell_Height': deepcopy(self._Cell_Height),
                    'Heading_Width': deepcopy(self._Heading_Width),
                    'Heading_Height': deepcopy(self._Heading_Height),
                },
                'Data': {},
                'Headings': {},
                'Cell_Styles': {},
                'Heading_Styles': {},
                'Disabled_Cells': [],
            }
            for Key, Value in self._Data.items():
                Data['Data'][self._Table_Key_To_Text(Key)] = deepcopy(Value)
            for Key, Value in self._Headings.items():
                Data['Headings'][self._Table_Key_To_Text(Key)] = deepcopy(Value)
            for Key, Value in self._Cell_Styles.items():
                Data['Cell_Styles'][self._Table_Key_To_Text(Key)] = deepcopy(Value)
            for Key, Value in self._Heading_Styles.items():
                Data['Heading_Styles'][self._Table_Key_To_Text(Key)] = deepcopy(Value)
            Data['Disabled_Cells'] = [self._Table_Key_To_Text(Key) for Key in sorted(list(self._Disabled_Cells))]
            return Data
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Export -> {E}')
            return {}
            
    def Create(self):
        try:
            if self._Frame is None:
                Parent = self._Get_Parent()
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'
                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div').props('tabindex=0')
                        self._Frame.props('tabindex=0')
                        self._Frame.on('table-key', self._Handle_Key, ['detail'])
                        self._Frame.on('table-paste', self._Handle_Paste, ['detail'])
                        self._Frame.on('mouseup', lambda E=None: self._End_Select())
                        self._Frame.on('mouseleave', lambda E=None: self._End_Select())
                        with self._Frame:
                            self._Body = ui.element('div')
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div').props('tabindex=0')
                    self._Frame.props('tabindex=0')
                    self._Frame.on('table-key', self._Handle_Key, ['detail'])
                    self._Frame.on('table-paste', self._Handle_Paste, ['detail'])
                    self._Frame.on('mouseup', lambda E=None: self._End_Select())
                    self._Frame.on('mouseleave', lambda E=None: self._End_Select())
                    with self._Frame:
                        self._Body = ui.element('div')
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            self._Render()
            self._Queue_Key_Events()
            if self._Name != self._Last_Name:
                if self._Last_Name and self._Last_Name in self._Main.__dict__:
                    del self._Main.__dict__[self._Last_Name]
                if self._Name:
                    self._Main.__dict__[self._Name] = self
                self._Last_Name = self._Name
            if not self._Display:
                self.Hide()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
            self._Widget = None
            self._Frame = None
            self._Body = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if self._Disable:
                return False
            if self._Frame is None:
                return False
            self._Frame.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Disable_Cell(self, Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Cell(Row, Column):
                return False
            Key = self._Data_Key(Row, Column)
            if Key in self._Disabled_Cells:
                return True
            self._Push_Undo()
            self._Disabled_Cells.add(Key)
            if self._Initialized:
                self._Update_Cell(Key, Content=False)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Disable_Cell -> {E}')
            return False

    def Enable_Cell(self, Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            Key = self._Data_Key(Row, Column)
            if Key not in self._Disabled_Cells:
                return True
            self._Push_Undo()
            self._Disabled_Cells.remove(Key)
            if self._Initialized:
                self._Update_Cell(Key, Content=False)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enable_Cell -> {E}')
            return False

    def Disable(self):
        try:
            self._Disable = True
            self._Editing = None
            self._Edit_Input = None
            self._Cancel_Click_Timer()
            self._Apply()
            self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Disable -> {E}')
            return False

    def Enable(self):
        try:
            self._Disable = False
            self._Apply()
            self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enable -> {E}')
            return False

    def Set(self, Value='', Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Cell(Row, Column):
                return False
            Key = self._Data_Key(Row, Column)
            New_Value = '' if Value is None else str(Value)
            if self._Data.get(Key, '') == New_Value:
                return True
            self._Push_Undo()
            self._Data[Key] = New_Value
            if self._Initialized:
                if self._Editing == Key:
                    self._Render()
                else:
                    self._Update_Cell(Key, Content=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')
            return False

    def Get(self, Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Cell(Row, Column):
                return ''
            return self._Data.get(self._Data_Key(Row, Column), '')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')
            return ''

    def Set_Heading(self, Value='', Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Heading(Row, Column):
                return False
            Key = self._Heading_Key(Row, Column)
            New_Value = '' if Value is None else str(Value)
            if self._Headings.get(Key, '') == New_Value:
                return True
            self._Push_Undo()
            self._Headings[Key] = New_Value
            if self._Initialized:
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set_Heading -> {E}')
            return False

    def Get_Heading(self, Row=0, Column=0):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Heading(Row, Column):
                return ''
            return self._Headings.get(self._Heading_Key(Row, Column), '')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get_Heading -> {E}')
            return ''

    def Config_Cell(self, Row=0, Column=0, Background=None, Foreground=None, Font_Size=None, Font_Weight=None, Font_Family=None, Disable=None):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Cell(Row, Column):
                return False
            Key = self._Data_Key(Row, Column)
            self._Push_Undo()
            if Key not in self._Cell_Styles:
                self._Cell_Styles[Key] = {}
            if Background is not None:
                self._Cell_Styles[Key]['Background'] = Background
            if Foreground is not None:
                self._Cell_Styles[Key]['Foreground'] = Foreground
            if Font_Size is not None:
                self._Cell_Styles[Key]['Font_Size'] = Font_Size
            if Font_Weight is not None:
                self._Cell_Styles[Key]['Font_Weight'] = Font_Weight
            if Font_Family is not None:
                self._Cell_Styles[Key]['Font_Family'] = Font_Family
            if Disable is not None:
                if Disable:
                    self._Disabled_Cells.add(Key)
                elif Key in self._Disabled_Cells:
                    self._Disabled_Cells.remove(Key)
            if self._Initialized:
                self._Update_Cell(Key, Content=False)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Cell -> {E}')
            return False

    def Config_Heading(self, Row=0, Column=0, Background=None, Foreground=None, Font_Size=None, Font_Weight=None, Font_Family=None):
        try:
            Row = int(Row)
            Column = int(Column)
            if not self._Valid_Heading(Row, Column):
                return False
            Key = self._Heading_Key(Row, Column)
            self._Push_Undo()
            if Key not in self._Heading_Styles:
                self._Heading_Styles[Key] = {}
            if Background is not None:
                self._Heading_Styles[Key]['Background'] = Background
            if Foreground is not None:
                self._Heading_Styles[Key]['Foreground'] = Foreground
            if Font_Size is not None:
                self._Heading_Styles[Key]['Font_Size'] = Font_Size
            if Font_Weight is not None:
                self._Heading_Styles[Key]['Font_Weight'] = Font_Weight
            if Font_Family is not None:
                self._Heading_Styles[Key]['Font_Family'] = Font_Family
            if self._Initialized:
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Heading -> {E}')
            return False

    def Shape(self, Rows=None, Columns=None):
        try:
            Changed = False
            New_Rows = self._Rows
            New_Columns = self._Columns
            if Rows is not None:
                New_Rows = max(0, int(Rows))
            if Columns is not None:
                New_Columns = max(0, int(Columns))
            if New_Rows != self._Rows or New_Columns != self._Columns:
                Changed = True
            if Changed:
                self._Push_Undo()
                self._Rows = New_Rows
                self._Columns = New_Columns
                if self._Initialized:
                    self._Render()
            return [self._Rows, self._Columns]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape -> {E}')
            return [self._Rows, self._Columns]

    def Clear(self):
        try:
            self._Data = {}
            self._Headings = {}
            self._Selected = None
            self._Editing = None
            if self._Initialized:
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')
            return False

    def Widget(self):
        try:
            return self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
            if 'On_Select' in Input:
                self._On_Select = Input['On_Select']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
            if 'On_Copy' in Input:
                self._On_Copy = Input['On_Copy']
            if 'On_Cut' in Input:
                self._On_Cut = Input['On_Cut']
            if 'On_Paste' in Input:
                self._On_Paste = Input['On_Paste']
            if 'On_Delete' in Input:
                self._On_Delete = Input['On_Delete']
            if 'On_Edit_Start' in Input:
                self._On_Edit_Start = Input['On_Edit_Start']
            if 'On_Edit_Finish' in Input:
                self._On_Edit_Finish = Input['On_Edit_Finish']
            if 'On_Undo' in Input:
                self._On_Undo = Input['On_Undo']
            if 'On_Redo' in Input:
                self._On_Redo = Input['On_Redo']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
            if self._Frame is not None:
                Skip = ['On_Show', 'On_Hide', 'On_Select', 'On_Change', 'On_Copy', 'On_Cut', 'On_Paste', 'On_Delete', 'On_Edit_Start', 'On_Edit_Finish', 'On_Undo', 'On_Redo', 'On_Animate']
                Forward = {K: V for K, V in Input.items() if K not in Skip}
                if len(Forward) > 0:
                    Event_Bind(self._Frame, **Forward)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Selected(self):
        try:
            return sorted(list(self._Selected_Cell_Set()))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Selected -> {E}')
            return []

    def Copy(self):
        try:
            return self._Copy_Selected()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')
            return ''

    def Cut(self):
        try:
            return self._Cut_Selected()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Cut -> {E}')
            return ''

    def Paste(self, Text=''):
        try:
            return self._Paste_Text(Text)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Paste -> {E}')
            return False

    def Delete_Selected(self):
        try:
            return self._Delete_Selected()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete_Selected -> {E}')
            return False

    def Import(self, Data):
        try:
            if not isinstance(Data, dict):
                return False
            self._Push_Undo()
            self._History_Block = True
            self._Data = {}
            self._Headings = {}
            self._Cell_Styles = {}
            self._Heading_Styles = {}
            self._Disabled_Cells = set()
            self._Selected = None
            self._Selected_Cells = set()
            self._Select_Start = None
            self._Dragging = False
            self._Editing = None
            self._Edit_Input = None
            Result = self._Import_State(Data)
            self._History_Block = False
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Import -> {E}')
            return False

    def Clear(self, Reset_Headings=False):
        try:
            self._Push_Undo()
            self._Data = {}
            self._Cell_Styles = {}
            self._Disabled_Cells = set()
            self._Selected = None
            self._Selected_Cells = set()
            self._Select_Start = None
            self._Dragging = False
            self._Editing = None
            self._Edit_Input = None
            self._Cancel_Click_Timer()
            if Reset_Headings:
                self._Headings = {}
                self._Heading_Styles = {}
            if self._Initialized:
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')
            return False

    def Undo(self):
        try:
            if not hasattr(self, '_Undo_Stack') or len(self._Undo_Stack) == 0:
                return False
            Before = self._Snapshot()
            State = self._Undo_Stack.pop()
            Cells, Changes = self._State_Changes(Before, State)
            if not hasattr(self, '_Redo_Stack'):
                self._Redo_Stack = []
            self._Redo_Stack.append(Before)
            self._History_Block = True
            Result = self._Import_State(State)
            self._History_Block = False
            if Result and self._On_Undo:
                self._On_Undo(self._Make_Event(Row=None, Column=None, Value=None, Name='undo', Cells=Cells, Text='', List=[], Changes=Changes))
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Undo -> {E}')
            return False

    def Redo(self):
        try:
            if not hasattr(self, '_Redo_Stack') or len(self._Redo_Stack) == 0:
                return False
            Before = self._Snapshot()
            State = self._Redo_Stack.pop()
            Cells, Changes = self._State_Changes(Before, State)
            if not hasattr(self, '_Undo_Stack'):
                self._Undo_Stack = []
            self._Undo_Stack.append(Before)
            self._History_Block = True
            Result = self._Import_State(State)
            self._History_Block = False
            if Result and self._On_Redo:
                self._On_Redo(self._Make_Event(Row=None, Column=None, Value=None, Name='redo', Cells=Cells, Text='', List=[], Changes=Changes))
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Redo -> {E}')
            return False

    def Config_Get(self, *Input):
        try:
            Return = {}
            if len(Input) == 0:
                for Each in self._Config:
                    Return[Each] = getattr(self, '_' + Each)
                return Return
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')
            return {}

    def Config(self, **Input):
        try:
            Run = False
            Render = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Rows' in Input or 'Columns' in Input or 'Column_Heading' in Input or 'Row_Heading' in Input or 'Cell_Width' in Input or 'Cell_Height' in Input or 'Heading_Width' in Input or 'Heading_Height' in Input:
                Render = True
            if self._Initialized and Run:
                self._Apply()
                if Render:
                    self._Render()
                else:
                    self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')
            return False

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return f'{Number}px'
            return f'{Number}px'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Format -> {E}')
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, **Input):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if 'Classes' in Input:
                self._Classes = Input['Classes']
            if 'Style' in Input:
                self._Style = Input['Style']
            if 'Margin' in Input:
                self._Margin = Input['Margin']
            if 'Padding' in Input:
                self._Padding = Input['Padding']
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Colors(self, Background=None, Foreground=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Foreground is not None:
                self._Foreground = Foreground
            if Border_Color is not None:
                self._Border_Color = Border_Color
            self._Apply()
            return [self._Background, self._Foreground, self._Border_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color
            self._Apply()
            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')