from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Variable:

    def __init__(self, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Variable'
            self._Variable = False
            self._Widget = []
        else:
            print('Error: GUI Create Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_GUI_Radio_Value[]'

    def __repr__(self):
        return 'Nucleon_GUI_Radio_Value[]'

    def Get(self):
        try:
            return self._Variable
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            self._Variable = Value
            for Each in list(self._Widget):
                Each.Refresh()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')


class Radio:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Radio'
            try:
                self._Config = {
                    'Name': False,
                    'Background': False,
                    'Foreground': '#000000',
                    'Border_Color': 'transparent',
                    'Border_Size': 0,
                    'Border_Radius': 9999,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': None,
                    'Animate_Left': 0,
                    'Animate_Top': 0,
                    'Animate_Width': 0,
                    'Animate_Height': 0,
                    'Animate_Time': 1.0,
                    'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                    'Text': '',
                    'Value': False,
                    'Variable': False,
                    'Disable': False,
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Padding': 0,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Name = False
                self._Background = False
                self._Foreground = '#000000'
                self._Border_Color = 'transparent'
                self._Border_Size = 0
                self._Border_Radius = 9999
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = None
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Text = ''
                self._Value = False
                self._Variable = False
                self._Disable = False
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Padding = 0
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Change = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Radio[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Radio[]'

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False:
            return 0
        try:
            return float(Value)
        except Exception:
            return 0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Selected(self):
        try:
            return bool(self._Variable and self._Variable.Get() == self._Value)
        except Exception:
            return False

    def _Get_Background(self):
        if self._Selected():
            if self._Background in [False, None, '']:
                return self._Hive_Color('Hive_Honey')
            return self._Hive_Color(self._Background)
        if self._Background in [False, None, '']:
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return 'transparent'
        return self._Hive_Color(self._Background)

    def _Get_Foreground(self):
        return self._Hive_Color(self._Foreground)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Get_Shadow_Color() or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Radio_Size_Mode(self, Box):
        try:
            if Box['Width'] is not None and Box['Width'] is not False and Box['Width'] != '':
                return ['Width', Box['Width']]
            if Box['Height'] is not None and Box['Height'] is not False and Box['Height'] != '':
                return ['Height', Box['Height']]
            return ['Width', 18]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Radio_Size_Mode -> {E}')
            return ['Width', 18]

    def _Radio_Name(self):
        try:
            if self._Variable:
                return f'Nucleon_Radio_{id(self._Variable)}'
            return f'Nucleon_Radio_{id(self)}'
        except Exception:
            return 'Nucleon_Radio'

    def _Radio_Border_Color(self):
        try:
            if self._Border_Color not in [False, None, '', 'transparent']:
                return self._Get_Border_Color()
            if self._Selected():
                return self._Hive_Color('Hive_Amber')
            return self._Hive_Color('Hive_Brown')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Radio_Border_Color -> {E}')
            return self._Get_Border_Color()

    def _Radio_Dot(self):
        try:
            if self._Selected():
                return f'radial-gradient(circle, {self._Get_Foreground()} 0 42%, transparent 45%)'
            return 'none'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Radio_Dot -> {E}')
            return 'none'

    def _Build_Style(self):
        Box = self._Animate_Current_Box()
        Size_Mode, Size_Value = self._Radio_Size_Mode(Box)
        Transition = 'all 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"inline-block" if self._Display or self._Animating else "none"}')
        Style.append('appearance: none')
        Style.append('-webkit-appearance: none')
        Style.append('outline: none')
        Style.append(f'background-color: {self._Get_Background()}')
        Style.append(f'background-image: {self._Radio_Dot()}')
        Style.append('background-repeat: no-repeat')
        Style.append('background-position: center')
        Style.append('background-size: 100% 100%')
        Style.append(f'border: {self._Unit(self._Border_Size) or "2px"} solid {self._Radio_Border_Color()}')
        Style.append('border-radius: 9999px')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append(f'transition: {Transition}')
        Style.append('aspect-ratio: 1 / 1')
        Style.append('vertical-align: middle')
        Style.append('user-select: none')
        if Size_Mode == 'Width':
            Style.append(f'width: {self._Unit(Size_Value)}')
            Style.append('height: auto')
        else:
            Style.append(f'height: {self._Unit(Size_Value)}')
            Style.append('width: auto')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
            Style.append('cursor: default')
        else:
            Style.append('cursor: pointer')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Click(self, E=None):
        try:
            if self._Disable:
                return
            if not self._Variable:
                return
            Value = getattr(E, 'value', None)
            Args = getattr(E, 'args', None)
            if Value is None and isinstance(Args, list) and len(Args) > 0:
                Value = Args[0]
            if Value is None and isinstance(Args, dict):
                if 'value' in Args:
                    Value = Args['value']
                elif 'checked' in Args:
                    Value = Args['checked']
            if Value is False:
                return
            if self._Variable.Get() != self._Value:
                self._Variable._Variable = self._Value
                for Each in list(self._Variable._Widget):
                    Each.Refresh()
                if self._On_Change:
                    self._On_Change(E)
        except Exception as E2:
            self._GUI.Error(f'{self._Type} -> _Click -> {E2}')

    def _Apply(self):
        try:
            if self._Widget is None:
                return
            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()
            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()
            if hasattr(self._Widget, '_props'):
                self._Widget._props['type'] = 'radio'
                self._Widget._props['name'] = self._Radio_Name()
                self._Widget._props['checked'] = bool(self._Selected())
                self._Widget._props['disabled'] = bool(self._Disable)
                self._Widget._props['aria-label'] = str(self._Text)
                self._Widget._props['title'] = str(self._Text)
                self._Widget.update()
            self._Widget.style(self._Build_Style())
            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if self._Hover_Background and not self._Disable:
                Classes.append(f'hover:!bg-[{self._Hive_Color(self._Hover_Background)}]')
            if self._Hover_Border_Color and not self._Disable:
                Classes.append(f'hover:!border-[{self._Hive_Color(self._Hover_Border_Color)}]')
            if len(Classes) > 0:
                self._Widget.classes(' '.join(Classes))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if self._Variable and self in self._Variable._Widget:
                self._Variable._Widget.remove(self)
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if hasattr(self, '_Disable') and self._Disable:
                return False
            if self._Widget is None:
                return False
            self._Widget.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Widget is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Widget is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Get(self):
        try:
            return self._Selected()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self):
        try:
            if self._Variable:
                self._Variable.Set(self._Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Reset(self):
        try:
            self.Refresh()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Refresh(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Widget is not None and len(Input) > 0:
                Event_Bind(self._Widget, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Colors(self, Background=None, Foreground=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Foreground is not None:
                self._Foreground = Foreground
            if Border_Color is not None:
                self._Border_Color = Border_Color
            self._Apply()
            return [self._Background, self._Foreground, self._Border_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Radius(self, Value=None):
        try:
            if Value is not None:
                self._Border_Radius = Value
                self._Apply()
            return self._Border_Radius
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Radius -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color
            self._Apply()
            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')

    def Disable(self, Value=True):
        try:
            self._Disable = Value
            self._Apply()
            return self._Disable
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Disable -> {E}')

    def Enable(self):
        try:
            self._Disable = False
            self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enable -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'
                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('input')
                else:
                    self._Widget = ui.element('input')
                self._Widget.on('change', lambda E: self._Click(E), ['target.checked'])
                if self._Variable and self not in self._Variable._Widget:
                    self._Variable._Widget.append(self)
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            if self._Name:
                self._Main.__dict__[self._Name] = self
            if not self._Display:
                self.Hide()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')