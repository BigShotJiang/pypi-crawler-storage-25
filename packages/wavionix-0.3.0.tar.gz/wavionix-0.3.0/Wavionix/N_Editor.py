from copy import deepcopy
from math import atan2, cos, pi, radians, sin, sqrt
from nicegui import ui
from .N_Dynamic import Dynamic

class Editor(Dynamic):

    def __init__(self, Main, *args, **kwargs):
        super().__init__(Main)
        if self._GUI is None:
            return
        try:
            self._Type = 'Editor'
            self._Config.update({
                'Draw_Enabled': False,
                'Shape_Mode': 'Rectangle',
                'Shape_Color': '#ef4444',
                'Shape_Fill_Color': '#22c55e',
                'Shape_Fill_Alpha': 0.25,
                'Shape_Thickness': 3,
                'Active_Border_Color': '#38bdf8',
                'Default_Angle': 0,
                'Min_Draw_Size': 8,
                'Handle_Offset': 5,
                'Rotate_Handle_Offset': 28,
                'Click_Reset_Threshold': 4,
                'Pan_View_Enabled': False,
                'Clamp_Pan': False,
            })
            self._Widget_ID = self._Build_Widget_Id()
            self._Shape_Layer = None
            self._Tool_Controls = {}
            self._Status_Label = None
            self._Draw_Enabled = False
            self._Shape_Mode = 'Rectangle'
            self._Shape_Color = '#ef4444'
            self._Shape_Fill_Color = '#22c55e'
            self._Shape_Fill_Alpha = 0.25
            self._Shape_Thickness = 3
            self._Active_Border_Color = '#38bdf8'
            self._Default_Angle = 0
            self._Min_Draw_Size = 8
            self._Handle_Offset = 5
            self._Rotate_Handle_Offset = 28
            self._Click_Reset_Threshold = 4
            self._Pan_View_Enabled = False
            self._Clamp_Pan = False
            self._Shapes = []
            self._Active_Shape_Index = -1
            self._Drag_Mode = ''
            self._Cursor = 'crosshair'
            self._View_Dragging = False
            self._View_Drag_Start_X = 0.0
            self._View_Drag_Start_Y = 0.0
            self._Original_Shape = None
            self._Active_Handle = ''
            self._Draft_Points = []
            self._Draft_Hover_X = None
            self._Draft_Hover_Y = None
            self._Draft_Type = ''
            self._Key_Event_Timer = None
            self._On_Copy = False
            self._On_Cut = False
            self._On_Paste = False
            self._On_Undo = False
            self._On_Redo = False
            self._On_Import = False
            self._On_Export = False
            self._On_Select = False
            self._On_Draw = False
            self._On_Move = False
            self._On_Resize = False
            self._On_Rotate = False
            self._On_Delete = False
            self._On_Change = False
            self._Wheel_Event_Timer = None
            self._Undo_Stack = []
            self._Redo_Stack = []
            self._History_Limit = 100
            self._History_Block = False
            if kwargs:
                self.Config(**kwargs)
        except Exception as E:
            if self._GUI is not None:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')

    def __str__(self):
        return 'Nucleon_Wavionix_Editor[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Editor[]'

    def _Set_Status(self, Text):
        try:
            if self._Status_Label is not None:
                self._Status_Label.set_text(Text)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Set_Status -> {E}')

    def _Set_Cursor(self, Cursor):
        try:
            if Cursor == self._Cursor:
                return
            self._Cursor = Cursor
            self._Update_Transform()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Set_Cursor -> {E}')

    def _Clamp_Editor_Pan(self):
        try:
            if not self._Clamp_Pan:
                return
            View_Width = float(max(1, self._View_Width))
            View_Height = float(max(1, self._View_Height))
            Image_Width = float(max(1, self._Image_Width))
            Image_Height = float(max(1, self._Image_Height))
            Fit_Scale = min(View_Width / Image_Width, View_Height / Image_Height) if self._Aspect_Ratio else max(View_Width / Image_Width, View_Height / Image_Height)
            Render_Width = Image_Width * Fit_Scale * self._Zoom
            Render_Height = Image_Height * Fit_Scale * self._Zoom
            Limit_X = max(0.0, (Render_Width - View_Width) / 2)
            Limit_Y = max(0.0, (Render_Height - View_Height) / 2)
            self._Pan_X = max(-Limit_X, min(Limit_X, self._Pan_X))
            self._Pan_Y = max(-Limit_Y, min(Limit_Y, self._Pan_Y))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Clamp_Editor_Pan -> {E}')

    def _Update_Transform(self):
        try:
            if self._Image is None or not self._Pan_Zoom:
                return
            self._Clamp_Editor_Pan()
            View_Width = float(max(1, self._View_Width))
            View_Height = float(max(1, self._View_Height))
            Image_Width = float(max(1, self._Image_Width))
            Image_Height = float(max(1, self._Image_Height))
            self._Fit_Scale = min(View_Width / Image_Width, View_Height / Image_Height) if self._Aspect_Ratio else max(View_Width / Image_Width, View_Height / Image_Height)
            Base_Width = Image_Width * self._Fit_Scale
            Base_Height = Image_Height * self._Fit_Scale
            Render_Width = Base_Width * self._Zoom
            Render_Height = Base_Height * self._Zoom
            self._Display_Offset_X = (View_Width - Render_Width) / 2 + self._Pan_X
            self._Display_Offset_Y = (View_Height - Render_Height) / 2 + self._Pan_Y
            Cursor_Value = self._Cursor
            if self._Should_Pan_View():
                Cursor_Value = 'grabbing' if self._View_Dragging else 'grab'
            Image_Style = f'position: absolute; left: 0px; top: 0px; width: {round(Render_Width, 2)}px; height: {round(Render_Height, 2)}px; transform: translate3d({round(self._Display_Offset_X, 2)}px, {round(self._Display_Offset_Y, 2)}px, 0px) rotate({self._Rotate + self._Angle}deg); transform-origin: 0 0; user-select: none; -webkit-user-drag: none; pointer-events: none; will-change: transform; transition: none !important; image-rendering: auto;'
            Layer_Style = f'position: absolute; left: 0px; top: 0px; width: {round(Render_Width, 2)}px; height: {round(Render_Height, 2)}px; transform: translate3d({round(self._Display_Offset_X, 2)}px, {round(self._Display_Offset_Y, 2)}px, 0px) rotate({self._Rotate + self._Angle}deg); transform-origin: 0 0; pointer-events: none; user-select: none; will-change: transform; transition: none !important;'
            Stage_Style = f'position: absolute; inset: 0; overflow: hidden; touch-action: none; cursor: {Cursor_Value}; transition: none !important;'
            self._Image.style(Image_Style)
            if self._Shape_Layer is not None:
                self._Shape_Layer.style(Layer_Style)
            if self._Stage is not None:
                self._Stage.style(Stage_Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Transform -> {E}')

    def _Input_Allowed(self):
        try:
            if not self._Display:
                return False
            if self._Widget is None or self._Stage is None:
                return False
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Input_Allowed -> {E}')
            return False

    def _Key_Detail(self, E):
        try:
            Args = getattr(E, 'args', None)
            if isinstance(Args, dict):
                if 'key' in Args:
                    return Args
                if 'detail' in Args and isinstance(Args['detail'], dict):
                    return Args['detail']
            if isinstance(Args, list) or isinstance(Args, tuple):
                if len(Args) > 0 and isinstance(Args[0], dict):
                    return Args[0]
            return {}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Key_Detail -> {E}')
            return {}

    async def _Install_Key_Events(self):
        try:
            self._Key_Event_Timer = None
            if self._Stage is None:
                return False
            Element_Id = f'c{self._Stage.id}'
            JavaScript = f'''
                const Element = document.getElementById("{Element_Id}");
                if (!Element || Element.__Wavionix_Editor_Key_Ready) return;
                Element.__Wavionix_Editor_Key_Ready = true;
                const Visible = () => {{
                    if (!Element.isConnected) return false;
                    const Style = window.getComputedStyle(Element);
                    const Box = Element.getBoundingClientRect();
                    if (Style.display === "none" || Style.visibility === "hidden" || Style.pointerEvents === "none") return false;
                    if (Box.width <= 0 || Box.height <= 0) return false;
                    return true;
                }};
                const Focused = () => document.activeElement === Element;
                Element.addEventListener("keydown", Event => {{
                    if (!Visible()) return;
                    if (!Focused()) return;
                    const Target = Event.target && Event.target.tagName ? Event.target.tagName : "";
                    Element.dispatchEvent(new CustomEvent("editor-key", {{detail: {{
                        key: Event.key,
                        ctrlKey: Event.ctrlKey,
                        metaKey: Event.metaKey,
                        shiftKey: Event.shiftKey,
                        target: Target,
                        focused: Focused(),
                        visible: Visible()
                    }}, bubbles: true}}));
                }});
                '''
            Result = ui.run_javascript(JavaScript)
            if hasattr(Result, '__await__'):
                await Result
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Install_Key_Events -> {E}')
            return False

    def _Queue_Key_Events(self):
        try:
            if self._Stage is None:
                return False
            if getattr(self, '_Key_Event_Timer', None) is not None:
                return True
            self._Key_Event_Timer = ui.timer(0.05, self._Install_Key_Events, once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Queue_Key_Events -> {E}')
            return False

    def _Wheel_Detail(self, E):
        try:
            Args = getattr(E, 'args', None)
            if isinstance(Args, dict):
                if 'deltaY' in Args:
                    return Args
                if 'detail' in Args and isinstance(Args['detail'], dict):
                    return Args['detail']
            if isinstance(Args, list) or isinstance(Args, tuple):
                if len(Args) > 0 and isinstance(Args[0], dict):
                    return Args[0]
            return {}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Wheel_Detail -> {E}')
            return {}
            
    async def _Install_Wheel_Events(self):
        try:
            self._Wheel_Event_Timer = None
            if self._Stage is None:
                return False
            Element_Id = f'c{self._Stage.id}'
            JavaScript = f'''
                const Element = document.getElementById("{Element_Id}");
                if (!Element || Element.__Wavionix_Editor_Wheel_Ready) return;
                Element.__Wavionix_Editor_Wheel_Ready = true;
                const Visible = () => {{
                    if (!Element.isConnected) return false;
                    const Style = window.getComputedStyle(Element);
                    const Box = Element.getBoundingClientRect();
                    if (Style.display === "none" || Style.visibility === "hidden" || Style.pointerEvents === "none") return false;
                    if (Box.width <= 0 || Box.height <= 0) return false;
                    return true;
                }};
                const Focused = () => document.activeElement === Element;
                Element.addEventListener("mousedown", Event => {{
                    if (!Visible()) return;
                    Element.focus();
                }});
                Element.addEventListener("wheel", Event => {{
                    if (!Visible()) return;
                    if (!Focused()) return;
                    Event.preventDefault();
                    Element.dispatchEvent(new CustomEvent("editor-wheel", {{detail: {{
                        deltaY: Event.deltaY || 0,
                        focused: Focused(),
                        visible: Visible()
                    }}, bubbles: true}}));
                }}, {{passive: false}});
                '''
            Result = ui.run_javascript(JavaScript)
            if hasattr(Result, '__await__'):
                await Result
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Install_Wheel_Events -> {E}')
            return False

    def _Queue_Wheel_Events(self):
        try:
            if self._Stage is None:
                return False
            if getattr(self, '_Wheel_Event_Timer', None) is not None:
                return True
            self._Wheel_Event_Timer = ui.timer(0.05, self._Install_Wheel_Events, once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Queue_Wheel_Events -> {E}')
            return False

    def _Handle_Wheel(self, E):
        try:
            if not self._Input_Allowed():
                return
            if not self._Pan_Zoom:
                return
            Detail = self._Wheel_Detail(E)
            if Detail:
                if not bool(Detail.get('focused', False)):
                    return
                if not bool(Detail.get('visible', True)):
                    return
                Delta = float(Detail.get('deltaY', 0) or 0)
            else:
                Delta = float(self._Event_Arg(E, 0, 0) or 0)
            if Delta < 0:
                self.Zoom_In()
                return
            if Delta > 0:
                self.Zoom_Out()
                return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Wheel -> {E}')

    def _Rebuild_Image(self):
        try:
            if self._Widget is None:
                return
            self._Load_Image_Metadata()
            self._Source_Url = self._Resolve_Source(self._Path)
            if not self._Source_Url:
                return
            if self._Stage is None or self._Image is None or self._Shape_Layer is None:
                self._Widget.clear()
                with self._Widget:
                    self._Stage = ui.element('div').props('tabindex=0').style('position: absolute; inset: 0; overflow: hidden; touch-action: none; outline: none;')
                    self._Stage.on('editor-key', self._Handle_Key, args=['detail'])
                    self._Stage.on('editor-wheel', self._Handle_Wheel, args=['detail'])
                    with self._Stage:
                        self._Image = ui.image(self._Source_Url).props('fit=fill position="center center" no-spinner no-transition').style('position: absolute; left: 0; top: 0; user-select: none; -webkit-user-drag: none; pointer-events: none; will-change: transform; image-rendering: auto; transition: none !important;')
                        self._Shape_Layer = ui.html('').style('position: absolute; left: 0; top: 0; pointer-events: none; user-select: none; transition: none !important;')
                        self._Stage.on('pointerdown', self._Handle_Editor_Pointer, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'])
                        self._Stage.on('pointermove', self._Handle_Editor_Move_Shape_Event, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'], throttle=0.03)
                        self._Stage.on('pointermove', self._Handle_Editor_Move_Pan_Event, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'], throttle=0.03)
                        self._Stage.on('pointerup', self._Handle_Editor_Pointer, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'])
                        self._Stage.on('pointerleave', self._Handle_Editor_Pointer, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'])
                        self._Stage.on('pointercancel', self._Handle_Editor_Pointer, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY', 'buttons'])
                        self._Stage.on('dblclick', self._Handle_Editor_Pointer, args=['type', 'clientX', 'clientY', 'offsetX', 'offsetY'])
                        ui.element('q-resize-observer').on('resize', self._Handle_Resize)
            else:
                if hasattr(self._Image, 'set_source'):
                    self._Image.set_source(self._Source_Url)
                elif hasattr(self._Image, '_props'):
                    self._Image._props['src'] = self._Source_Url
                    self._Image.update()
                else:
                    self._Image.delete()
                    with self._Stage:
                        self._Image = ui.image(self._Source_Url).props('fit=fill position="center center" no-spinner no-transition').style('position: absolute; left: 0; top: 0; user-select: none; -webkit-user-drag: none; pointer-events: none; will-change: transform; image-rendering: auto; transition: none !important;')
            self._Zoom = max(self._Zoom_Min, min(self._Zoom_Max, self._Zoom))
            self._Dragging = False
            self._View_Dragging = False
            self._Update_Transform()
            self._Render_Shapes()
            self._Queue_Key_Events()
            self._Queue_Wheel_Events()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Rebuild_Image -> {E}')

    def _Handle_Editor_Move_Shape_Event(self, Event):
        try:
            if self._View_Dragging:
                return
            Args = Event.args if isinstance(getattr(Event, 'args', None), dict) else {}
            View_X, View_Y = self._Get_View_Position(Args)
            Client_X = float(Args.get('clientX', View_X))
            Client_Y = float(Args.get('clientY', View_Y))
            X_Value, Y_Value = self._Get_Image_Position(View_X, View_Y)
            self._Handle_Editor_Move(X_Value, Y_Value, Client_X, Client_Y, Args.get('buttons', 1))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Editor_Move_Shape_Event -> {E}')

    def _Handle_Editor_Move_Pan_Event(self, Event):
        try:
            if not self._View_Dragging:
                return
            Args = Event.args if isinstance(getattr(Event, 'args', None), dict) else {}
            View_X, View_Y = self._Get_View_Position(Args)
            Client_X = float(Args.get('clientX', View_X))
            Client_Y = float(Args.get('clientY', View_Y))
            X_Value, Y_Value = self._Get_Image_Position(View_X, View_Y)
            self._Handle_Editor_Move(X_Value, Y_Value, Client_X, Client_Y, Args.get('buttons', 1))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Editor_Move_Pan_Event -> {E}')

    def _Get_View_Position(self, Args):
        try:
            View_X = Args.get('offsetX', Args.get('x', None))
            View_Y = Args.get('offsetY', Args.get('y', None))
            if View_X is not None and View_Y is not None:
                return float(View_X), float(View_Y)
            return 0.0, 0.0
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_View_Position -> {E}')
            return 0.0, 0.0

    def _Get_Image_Position(self, View_X, View_Y):
        try:
            Scale_Value = self._Fit_Scale * self._Zoom
            if Scale_Value <= 0:
                Scale_Value = 1
            X_Value = (View_X - self._Display_Offset_X) / Scale_Value
            Y_Value = (View_Y - self._Display_Offset_Y) / Scale_Value
            return X_Value, Y_Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Image_Position -> {E}')
            return 0.0, 0.0

    def _Should_Pan_View(self):
        try:
            if self._Pan_View_Enabled:
                return True
            return self._View_Dragging
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Should_Pan_View -> {E}')
            return False

    def _Distance(self, X1, Y1, X2, Y2):
        return sqrt((X1 - X2) ** 2 + (Y1 - Y2) ** 2)

    def _To_Degrees(self, Angle_Radians):
        return Angle_Radians * 180 / pi

    def _Rotate_Vector(self, X_Value, Y_Value, Angle_Value):
        Angle_Radians = radians(Angle_Value)
        return X_Value * cos(Angle_Radians) - Y_Value * sin(Angle_Radians), X_Value * sin(Angle_Radians) + Y_Value * cos(Angle_Radians)

    def _Rotate_Point(self, X_Value, Y_Value, Center_X, Center_Y, Angle_Value):
        Local_X = X_Value - Center_X
        Local_Y = Y_Value - Center_Y
        Rotated_X, Rotated_Y = self._Rotate_Vector(Local_X, Local_Y, Angle_Value)
        return Center_X + Rotated_X, Center_Y + Rotated_Y

    def _Normalize_Vector(self, X_Value, Y_Value):
        Length_Value = sqrt(X_Value ** 2 + Y_Value ** 2)
        if Length_Value <= 0:
            return 0, -1
        return X_Value / Length_Value, Y_Value / Length_Value

    def _Offset_Point(self, Point_X, Point_Y, Center_X, Center_Y, Offset_Value):
        Direction_X, Direction_Y = self._Normalize_Vector(Point_X - Center_X, Point_Y - Center_Y)
        return Point_X + Direction_X * Offset_Value, Point_Y + Direction_Y * Offset_Value

    def _Deep_Copy_Shape(self, Shape):
        return deepcopy(Shape)

    def _Get_Active_Shape(self):
        Index = self._Active_Shape_Index
        if Index < 0 or Index >= len(self._Shapes):
            return None
        return self._Shapes[Index]

    def _Get_Shape_Center(self, Shape):
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle', 'Circle', 'Ellipse'):
            return Shape['CX'], Shape['CY']
        if Shape['Type'] == 'Line':
            return (Shape['X1'] + Shape['X2']) / 2, (Shape['Y1'] + Shape['Y2']) / 2
        Point_List = Shape['Points']
        if not Point_List:
            return 0, 0
        Sum_X = 0
        Sum_Y = 0
        for Point_X, Point_Y in Point_List:
            Sum_X += Point_X
            Sum_Y += Point_Y
        return Sum_X / len(Point_List), Sum_Y / len(Point_List)

    def _Get_Box_Points(self, Shape):
        Half_W = Shape['W'] / 2
        Half_H = Shape['H'] / 2
        Point_List = [(-Half_W, -Half_H), (Half_W, -Half_H), (Half_W, Half_H), (-Half_W, Half_H)]
        Result_List = []
        for Local_X, Local_Y in Point_List:
            Rotated_X, Rotated_Y = self._Rotate_Vector(Local_X, Local_Y, Shape['Angle'])
            Result_List.append((Shape['CX'] + Rotated_X, Shape['CY'] + Rotated_Y))
        return Result_List

    def _Get_Ellipse_Axis_Point(self, Shape, Axis_Name):
        if Axis_Name == 'Top':
            Local_X, Local_Y = 0, -Shape['RY']
        elif Axis_Name == 'Right':
            Local_X, Local_Y = Shape['RX'], 0
        elif Axis_Name == 'Bottom':
            Local_X, Local_Y = 0, Shape['RY']
        else:
            Local_X, Local_Y = -Shape['RX'], 0
        Rotated_X, Rotated_Y = self._Rotate_Vector(Local_X, Local_Y, Shape['Angle'])
        return Shape['CX'] + Rotated_X, Shape['CY'] + Rotated_Y

    def _Get_Rectangle_Handle_Locals(self, Shape):
        Half_W = Shape['W'] / 2
        Half_H = Shape['H'] / 2
        return [{'Name': 'P0', 'Kind': 'Resize', 'Cursor': 'nwse-resize', 'LX': -Half_W, 'LY': -Half_H}, {'Name': 'Top', 'Kind': 'Resize', 'Cursor': 'ns-resize', 'LX': 0, 'LY': -Half_H}, {'Name': 'P1', 'Kind': 'Resize', 'Cursor': 'nesw-resize', 'LX': Half_W, 'LY': -Half_H}, {'Name': 'Right', 'Kind': 'Resize', 'Cursor': 'ew-resize', 'LX': Half_W, 'LY': 0}, {'Name': 'P2', 'Kind': 'Resize', 'Cursor': 'nwse-resize', 'LX': Half_W, 'LY': Half_H}, {'Name': 'Bottom', 'Kind': 'Resize', 'Cursor': 'ns-resize', 'LX': 0, 'LY': Half_H}, {'Name': 'P3', 'Kind': 'Resize', 'Cursor': 'nesw-resize', 'LX': -Half_W, 'LY': Half_H}, {'Name': 'Left', 'Kind': 'Resize', 'Cursor': 'ew-resize', 'LX': -Half_W, 'LY': 0}]

    def _Get_Top_Vector(self, Shape):
        Center_X, Center_Y = self._Get_Shape_Center(Shape)
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle', 'Ellipse'):
            Top_X, Top_Y = self._Rotate_Vector(0, -1, Shape['Angle'])
            return Top_X, Top_Y
        if Shape['Type'] == 'Line':
            Direction_X = Shape['X2'] - Shape['X1']
            Direction_Y = Shape['Y2'] - Shape['Y1']
            Normal_X, Normal_Y = self._Normalize_Vector(-Direction_Y, Direction_X)
            if Normal_Y > 0:
                return -Normal_X, -Normal_Y
            return Normal_X, Normal_Y
        Top_Point_X = Center_X
        Top_Point_Y = Center_Y - 1
        for Point_X, Point_Y in Shape['Points']:
            if Point_Y < Top_Point_Y:
                Top_Point_X = Point_X
                Top_Point_Y = Point_Y
        return self._Normalize_Vector(Top_Point_X - Center_X, Top_Point_Y - Center_Y)

    def _Get_Point_Text(self, Point_List):
        return '; '.join([f'{round(Point_X, 2)},{round(Point_Y, 2)}' for Point_X, Point_Y in Point_List])

    def _Get_Fill_Values(self, Shape):
        if Shape['Type'] in ('Line', 'Polyline'):
            return 'none', 0
        return Shape.get('Fill_Color', self._Shape_Fill_Color), Shape.get('Fill_Alpha', self._Shape_Fill_Alpha)

    def _Get_Handle_Base_Size(self, Shape):
        return max(6, 4 + int(Shape.get('Thickness', self._Shape_Thickness)))

    def _Get_Handle_Tolerance(self, Shape, Handle_Item):
        Base_Size = self._Get_Handle_Base_Size(Shape)
        if Handle_Item['Kind'] == 'Rotate':
            return max(18, Base_Size + 10)
        if Handle_Item['Kind'] == 'Move':
            return max(16, Base_Size + 8)
        return max(18, Base_Size + 8)

    def _Get_Handle_Items(self, Shape):
        Handle_List = []
        Center_X, Center_Y = self._Get_Shape_Center(Shape)
        Handle_List.append({'Name': 'Move', 'Kind': 'Move', 'Cursor': 'move', 'X': Center_X, 'Y': Center_Y})
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
            for Handle_Item in self._Get_Rectangle_Handle_Locals(Shape):
                Rotated_X, Rotated_Y = self._Rotate_Vector(Handle_Item['LX'], Handle_Item['LY'], Shape['Angle'])
                Point_X = Shape['CX'] + Rotated_X
                Point_Y = Shape['CY'] + Rotated_Y
                Handle_X, Handle_Y = self._Offset_Point(Point_X, Point_Y, Center_X, Center_Y, self._Handle_Offset)
                Handle_List.append({'Name': Handle_Item['Name'], 'Kind': 'Resize', 'Cursor': Handle_Item['Cursor'], 'X': Handle_X, 'Y': Handle_Y})
            Top_Mid_X, Top_Mid_Y = self._Rotate_Vector(0, -Shape['H'] / 2, Shape['Angle'])
            Top_Direction_X, Top_Direction_Y = self._Normalize_Vector(Top_Mid_X, Top_Mid_Y)
            Handle_List.append({'Name': 'Rotate', 'Kind': 'Rotate', 'Cursor': 'alias', 'X': Shape['CX'] + Top_Mid_X + Top_Direction_X * self._Rotate_Handle_Offset, 'Y': Shape['CY'] + Top_Mid_Y + Top_Direction_Y * self._Rotate_Handle_Offset})
            return Handle_List
        if Shape['Type'] == 'Ellipse':
            for Axis_Name, Cursor_Name in [('Top', 'ns-resize'), ('Right', 'ew-resize'), ('Bottom', 'ns-resize'), ('Left', 'ew-resize')]:
                Point_X, Point_Y = self._Get_Ellipse_Axis_Point(Shape, Axis_Name)
                Handle_X, Handle_Y = self._Offset_Point(Point_X, Point_Y, Center_X, Center_Y, self._Handle_Offset)
                Handle_List.append({'Name': Axis_Name, 'Kind': 'Resize', 'Cursor': Cursor_Name, 'X': Handle_X, 'Y': Handle_Y})
            Top_X, Top_Y = self._Get_Ellipse_Axis_Point(Shape, 'Top')
            Top_Direction_X, Top_Direction_Y = self._Normalize_Vector(Top_X - Center_X, Top_Y - Center_Y)
            Handle_List.append({'Name': 'Rotate', 'Kind': 'Rotate', 'Cursor': 'alias', 'X': Top_X + Top_Direction_X * self._Rotate_Handle_Offset, 'Y': Top_Y + Top_Direction_Y * self._Rotate_Handle_Offset})
            return Handle_List
        if Shape['Type'] == 'Circle':
            Handle_List.append({'Name': 'Radius', 'Kind': 'Resize', 'Cursor': 'ew-resize', 'X': Shape['CX'] + Shape['R'] + self._Handle_Offset, 'Y': Shape['CY']})
            return Handle_List
        if Shape['Type'] == 'Line':
            Handle_List.append({'Name': 'P1', 'Kind': 'Resize', 'Cursor': 'pointer', 'X': Shape['X1'], 'Y': Shape['Y1']})
            Handle_List.append({'Name': 'P2', 'Kind': 'Resize', 'Cursor': 'pointer', 'X': Shape['X2'], 'Y': Shape['Y2']})
            Direction_X, Direction_Y = self._Get_Top_Vector(Shape)
            Handle_List.append({'Name': 'Rotate', 'Kind': 'Rotate', 'Cursor': 'alias', 'X': Center_X + Direction_X * self._Rotate_Handle_Offset, 'Y': Center_Y + Direction_Y * self._Rotate_Handle_Offset})
            return Handle_List
        if Shape['Type'] in ('Quadrilateral', 'Polygon', 'Polyline'):
            for Index, (Point_X, Point_Y) in enumerate(Shape['Points']):
                Handle_List.append({'Name': f'Point_{Index}', 'Kind': 'Resize', 'Cursor': 'pointer', 'X': Point_X, 'Y': Point_Y})
            Direction_X, Direction_Y = self._Get_Top_Vector(Shape)
            Handle_List.append({'Name': 'Rotate', 'Kind': 'Rotate', 'Cursor': 'alias', 'X': Center_X + Direction_X * self._Rotate_Handle_Offset, 'Y': Center_Y + Direction_Y * self._Rotate_Handle_Offset})
            return Handle_List
        return Handle_List

    def _Find_Selected_Handle(self, X_Value, Y_Value):
        Shape = self._Get_Active_Shape()
        if Shape is None or not Shape['Visible']:
            return None
        for Handle_Item in reversed(self._Get_Handle_Items(Shape)):
            if self._Distance(X_Value, Y_Value, Handle_Item['X'], Handle_Item['Y']) <= self._Get_Handle_Tolerance(Shape, Handle_Item):
                return Handle_Item
        return None

    def _Point_In_Polygon(self, Point_List, X_Value, Y_Value):
        Inside_Value = False
        Last_Index = len(Point_List) - 1
        for Index, (Point_X_1, Point_Y_1) in enumerate(Point_List):
            Point_X_2, Point_Y_2 = Point_List[Last_Index]
            Crosses_Value = ((Point_Y_1 > Y_Value) != (Point_Y_2 > Y_Value)) and (X_Value < (Point_X_2 - Point_X_1) * (Y_Value - Point_Y_1) / ((Point_Y_2 - Point_Y_1) if Point_Y_2 != Point_Y_1 else 1) + Point_X_1)
            if Crosses_Value:
                Inside_Value = not Inside_Value
            Last_Index = Index
        return Inside_Value

    def _Project_Point_To_Segment(self, X_Value, Y_Value, X1, Y1, X2, Y2):
        Length_Value = (X2 - X1) ** 2 + (Y2 - Y1) ** 2
        if Length_Value <= 0:
            return X1, Y1, self._Distance(X_Value, Y_Value, X1, Y1)
        Ratio_Value = ((X_Value - X1) * (X2 - X1) + (Y_Value - Y1) * (Y2 - Y1)) / Length_Value
        Ratio_Value = max(0, min(1, Ratio_Value))
        Closest_X = X1 + Ratio_Value * (X2 - X1)
        Closest_Y = Y1 + Ratio_Value * (Y2 - Y1)
        return Closest_X, Closest_Y, self._Distance(X_Value, Y_Value, Closest_X, Closest_Y)

    def _Distance_Point_To_Segment(self, X_Value, Y_Value, X1, Y1, X2, Y2):
        Closest_X, Closest_Y, Distance_Value = self._Project_Point_To_Segment(X_Value, Y_Value, X1, Y1, X2, Y2)
        return Distance_Value

    def _Distance_Point_To_Polyline(self, Point_List, X_Value, Y_Value, Closed=False):
        if len(Point_List) < 2:
            return 10 ** 9
        Best_Value = 10 ** 9
        Max_Index = len(Point_List) if Closed else len(Point_List) - 1
        for Index in range(Max_Index):
            Point_X_1, Point_Y_1 = Point_List[Index]
            Point_X_2, Point_Y_2 = Point_List[(Index + 1) % len(Point_List)]
            Best_Value = min(Best_Value, self._Distance_Point_To_Segment(X_Value, Y_Value, Point_X_1, Point_Y_1, Point_X_2, Point_Y_2))
        return Best_Value

    def _Point_In_Ellipse(self, Shape, X_Value, Y_Value):
        Local_X, Local_Y = self._Rotate_Vector(X_Value - Shape['CX'], Y_Value - Shape['CY'], -Shape['Angle'])
        if Shape['RX'] <= 0 or Shape['RY'] <= 0:
            return False
        return (Local_X / Shape['RX']) ** 2 + (Local_Y / Shape['RY']) ** 2 <= 1

    def _Point_In_Shape(self, Shape, X_Value, Y_Value):
        if not Shape['Visible']:
            return False
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
            return self._Point_In_Polygon(self._Get_Box_Points(Shape), X_Value, Y_Value)
        if Shape['Type'] == 'Circle':
            return self._Distance(X_Value, Y_Value, Shape['CX'], Shape['CY']) <= Shape['R']
        if Shape['Type'] == 'Ellipse':
            return self._Point_In_Ellipse(Shape, X_Value, Y_Value)
        if Shape['Type'] == 'Line':
            return self._Distance_Point_To_Segment(X_Value, Y_Value, Shape['X1'], Shape['Y1'], Shape['X2'], Shape['Y2']) <= max(6, Shape['Thickness'] + 4)
        if Shape['Type'] == 'Quadrilateral':
            return self._Point_In_Polygon(Shape['Points'], X_Value, Y_Value)
        if Shape['Type'] == 'Polygon':
            return self._Point_In_Polygon(Shape['Points'], X_Value, Y_Value) or self._Distance_Point_To_Polyline(Shape['Points'], X_Value, Y_Value, True) <= max(6, Shape['Thickness'] + 4)
        if Shape['Type'] == 'Polyline':
            return self._Distance_Point_To_Polyline(Shape['Points'], X_Value, Y_Value, False) <= max(6, Shape['Thickness'] + 4)
        return False

    def _Find_Shape(self, X_Value, Y_Value):
        for Index in range(len(self._Shapes) - 1, -1, -1):
            if self._Point_In_Shape(self._Shapes[Index], X_Value, Y_Value):
                return Index
        return -1

    def _Build_Move_Icon(self, X_Value, Y_Value, Shape):
        Radius_Value = max(7, self._Get_Handle_Base_Size(Shape) + 1)
        Arm_Value = Radius_Value + 2
        Inner_Width = max(1.5, Radius_Value / 3)
        Color_Value = self._Active_Border_Color
        return f'<g><circle cx="{round(X_Value, 2)}" cy="{round(Y_Value, 2)}" r="{round(Radius_Value, 2)}" fill="{Color_Value}" stroke="white" stroke-width="2" /><path d="M {round(X_Value - Arm_Value, 2)} {round(Y_Value, 2)} L {round(X_Value + Arm_Value, 2)} {round(Y_Value, 2)} M {round(X_Value, 2)} {round(Y_Value - Arm_Value, 2)} L {round(X_Value, 2)} {round(Y_Value + Arm_Value, 2)}" stroke="white" stroke-width="{round(Inner_Width, 2)}" /></g>'

    def _Build_Resize_Icon(self, X_Value, Y_Value, Shape):
        Half_Size = max(6, self._Get_Handle_Base_Size(Shape))
        Corner_Value = max(2, int(Half_Size / 3))
        Color_Value = self._Active_Border_Color
        return f'<rect x="{round(X_Value - Half_Size, 2)}" y="{round(Y_Value - Half_Size, 2)}" width="{round(Half_Size * 2, 2)}" height="{round(Half_Size * 2, 2)}" fill="{Color_Value}" stroke="white" stroke-width="2" rx="{Corner_Value}" />'

    def _Build_Rotate_Icon(self, X_Value, Y_Value, Shape):
        Radius_Value = max(8, self._Get_Handle_Base_Size(Shape) + 2)
        Inner_Radius = max(3, Radius_Value / 2.3)
        Color_Value = self._Active_Border_Color
        return f'<g><circle cx="{round(X_Value, 2)}" cy="{round(Y_Value, 2)}" r="{round(Radius_Value, 2)}" fill="{Color_Value}" stroke="white" stroke-width="2" /><circle cx="{round(X_Value, 2)}" cy="{round(Y_Value, 2)}" r="{round(Inner_Radius, 2)}" fill="white" /></g>'

    def _Render_Shape(self, Index, Shape):
        if not Shape['Visible']:
            return ''
        Svg_List = []
        Selected_Value = (not self._Draw_Enabled) and Index == self._Active_Shape_Index
        Stroke_Color = self._Active_Border_Color if Selected_Value else Shape['Color']
        Thickness_Value = max(Shape['Thickness'] + 2, Shape['Thickness'] * 2) if Selected_Value else Shape['Thickness']
        Fill_Color, Fill_Alpha = self._Get_Fill_Values(Shape)
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
            Point_Text = ' '.join([f'{round(Point_X, 2)},{round(Point_Y, 2)}' for Point_X, Point_Y in self._Get_Box_Points(Shape)])
            Svg_List.append(f'<polygon points="{Point_Text}" fill="{Fill_Color}" fill-opacity="{Fill_Alpha}" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" />')
        elif Shape['Type'] == 'Circle':
            Svg_List.append(f'<circle cx="{round(Shape["CX"], 2)}" cy="{round(Shape["CY"], 2)}" r="{round(Shape["R"], 2)}" fill="{Fill_Color}" fill-opacity="{Fill_Alpha}" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" />')
        elif Shape['Type'] == 'Ellipse':
            Svg_List.append(f'<ellipse cx="{round(Shape["CX"], 2)}" cy="{round(Shape["CY"], 2)}" rx="{round(Shape["RX"], 2)}" ry="{round(Shape["RY"], 2)}" transform="rotate({round(Shape["Angle"], 2)} {round(Shape["CX"], 2)} {round(Shape["CY"], 2)})" fill="{Fill_Color}" fill-opacity="{Fill_Alpha}" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" />')
        elif Shape['Type'] == 'Line':
            Svg_List.append(f'<line x1="{round(Shape["X1"], 2)}" y1="{round(Shape["Y1"], 2)}" x2="{round(Shape["X2"], 2)}" y2="{round(Shape["Y2"], 2)}" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" stroke-linecap="round" />')
        elif Shape['Type'] == 'Polyline':
            Point_Text = ' '.join([f'{round(Point_X, 2)},{round(Point_Y, 2)}' for Point_X, Point_Y in Shape['Points']])
            Svg_List.append(f'<polyline points="{Point_Text}" fill="none" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" stroke-linecap="round" stroke-linejoin="round" />')
        elif Shape['Type'] in ('Quadrilateral', 'Polygon'):
            Point_Text = ' '.join([f'{round(Point_X, 2)},{round(Point_Y, 2)}' for Point_X, Point_Y in Shape['Points']])
            Svg_List.append(f'<polygon points="{Point_Text}" fill="{Fill_Color}" fill-opacity="{Fill_Alpha}" stroke="{Stroke_Color}" stroke-width="{Thickness_Value}" stroke-linejoin="round" />')
        if Selected_Value:
            for Handle_Item in self._Get_Handle_Items(Shape):
                if Handle_Item['Kind'] == 'Move':
                    Svg_List.append(self._Build_Move_Icon(Handle_Item['X'], Handle_Item['Y'], Shape))
                elif Handle_Item['Kind'] == 'Resize':
                    Svg_List.append(self._Build_Resize_Icon(Handle_Item['X'], Handle_Item['Y'], Shape))
                elif Handle_Item['Kind'] == 'Rotate':
                    Svg_List.append(self._Build_Rotate_Icon(Handle_Item['X'], Handle_Item['Y'], Shape))
        return ''.join(Svg_List)

    def _Render_Draft(self):
        if self._Draft_Type == '' or not self._Draft_Points:
            return ''
        Point_List = list(self._Draft_Points)
        if self._Draft_Hover_X is not None and self._Draft_Hover_Y is not None:
            Point_List.append((self._Draft_Hover_X, self._Draft_Hover_Y))
        Point_Text = ' '.join([f'{round(Point_X, 2)},{round(Point_Y, 2)}' for Point_X, Point_Y in Point_List])
        return f'<polyline points="{Point_Text}" fill="none" stroke="{self._Shape_Color}" stroke-width="{self._Shape_Thickness}" stroke-dasharray="6 4" stroke-linecap="round" stroke-linejoin="round" />'

    def _Render_Shapes(self):
        try:
            if self._Shape_Layer is None:
                return
            Svg_List = []
            for Index, Shape in enumerate(self._Shapes):
                Svg_List.append(self._Render_Shape(Index, Shape))
            Svg_List.append(self._Render_Draft())
            Svg_Content = ''.join(Svg_List)
            Width_Value = int(max(1, self._Image_Width))
            Height_Value = int(max(1, self._Image_Height))
            self._Shape_Layer.content = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Width_Value} {Height_Value}" width="100%" height="100%" preserveAspectRatio="none">{Svg_Content}</svg>'
            self._Shape_Layer.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Shapes -> {E}')

    def _Get_Shape_Label(self, Index, Shape):
        Display_Text = 'Shown' if Shape['Visible'] else 'Hidden'
        Lock_Text = 'Locked' if Shape['Locked'] else 'Free'
        return f'{Index + 1}: {Shape["Name"]} [{Shape["Type"]}] {Display_Text}/{Lock_Text}'

    def _Control(self, Name):
        return self._Tool_Controls.get(Name)

    def _Refresh_Shape_List(self):
        try:
            Control = self._Control('Shape_Select')
            if Control is None:
                return
            Control.options = {str(Index): self._Get_Shape_Label(Index, Shape) for Index, Shape in enumerate(self._Shapes)}
            Control.value = None if self._Active_Shape_Index < 0 else str(self._Active_Shape_Index)
            Control.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_Shape_List -> {E}')

    def _Refresh_Info(self):
        try:
            Mode_Label = self._Control('Mode_Label')
            Shape_Info_Label = self._Control('Shape_Info_Label')
            Draft_Info_Label = self._Control('Draft_Info_Label')
            if Mode_Label is not None:
                Mode_Label.set_text(f'Mode: {"Draw" if self._Draw_Enabled else "Manipulate"}')
            if Shape_Info_Label is not None:
                Shape = self._Get_Active_Shape()
                Shape_Info_Label.set_text('Active Shape: none' if Shape is None else f'Active Shape: {self._Active_Shape_Index + 1} ({Shape["Type"]})')
            if Draft_Info_Label is not None:
                Draft_Info_Label.set_text(f'Draft: {self._Draft_Type} with {len(self._Draft_Points)} point(s)' if len(self._Draft_Points) > 0 else 'Draft: none')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_Info -> {E}')

    def _Refresh_Editor(self):
        try:
            Shape = self._Get_Active_Shape()
            Value_Map = {'CX': 0, 'CY': 0, 'W': 0, 'H': 0, 'Angle': 0, 'R': 0, 'RX': 0, 'RY': 0, 'X1': 0, 'Y1': 0, 'X2': 0, 'Y2': 0}
            if Shape is not None:
                if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
                    Value_Map.update({'CX': Shape['CX'], 'CY': Shape['CY'], 'W': Shape['W'], 'H': Shape['H'], 'Angle': Shape['Angle']})
                elif Shape['Type'] == 'Circle':
                    Value_Map.update({'CX': Shape['CX'], 'CY': Shape['CY'], 'R': Shape['R']})
                elif Shape['Type'] == 'Ellipse':
                    Value_Map.update({'CX': Shape['CX'], 'CY': Shape['CY'], 'RX': Shape['RX'], 'RY': Shape['RY'], 'Angle': Shape['Angle']})
                elif Shape['Type'] == 'Line':
                    Value_Map.update({'X1': Shape['X1'], 'Y1': Shape['Y1'], 'X2': Shape['X2'], 'Y2': Shape['Y2']})
            for Key_Name, Value_Item in Value_Map.items():
                Control = self._Control(f'Field_{Key_Name}')
                if Control is not None:
                    Control.value = round(Value_Item, 2)
                    Control.update()
            Shape_Name_Input = self._Control('Shape_Name_Input')
            Shape_Visible_Switch = self._Control('Shape_Visible_Switch')
            Shape_Locked_Switch = self._Control('Shape_Locked_Switch')
            Points_Textarea = self._Control('Points_Textarea')
            if Shape_Name_Input is not None:
                Shape_Name_Input.value = '' if Shape is None else Shape['Name']
                Shape_Name_Input.update()
            if Shape_Visible_Switch is not None:
                Shape_Visible_Switch.value = True if Shape is None else Shape['Visible']
                Shape_Visible_Switch.update()
            if Shape_Locked_Switch is not None:
                Shape_Locked_Switch.value = False if Shape is None else Shape['Locked']
                Shape_Locked_Switch.update()
            if Points_Textarea is not None:
                Points_Textarea.value = '' if Shape is None or Shape['Type'] not in ('Quadrilateral', 'Polygon', 'Polyline') else self._Get_Point_Text(Shape['Points'])
                Points_Textarea.update()
            self._Refresh_Style_Controls()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_Editor -> {E}')

    def _Refresh_Style_Controls(self):
        try:
            Value_Map = {'Shape_Color_Input': self._Shape_Color, 'Shape_Fill_Color_Input': self._Shape_Fill_Color, 'Shape_Fill_Alpha_Slider': self._Shape_Fill_Alpha, 'Shape_Thickness_Slider': self._Shape_Thickness, 'Active_Border_Color_Input': self._Active_Border_Color, 'Default_Angle_Number': self._Default_Angle, 'Draw_Mode_Switch': self._Draw_Enabled, 'Pan_View_Switch': self._Pan_View_Enabled}
            for Name, Value in Value_Map.items():
                Control = self._Control(Name)
                if Control is not None:
                    Control.value = Value
                    Control.update()
            Label_Map = {'Shape_Color_Label': f'Stroke: {self._Shape_Color}', 'Shape_Fill_Color_Label': f'Fill: {self._Shape_Fill_Color}', 'Shape_Fill_Alpha_Label': f'Fill Alpha: {round(float(self._Shape_Fill_Alpha), 2)}', 'Shape_Thickness_Label': f'Thickness: {int(self._Shape_Thickness)}', 'Active_Border_Color_Label': f'Active Border: {self._Active_Border_Color}'}
            for Name, Text in Label_Map.items():
                Control = self._Control(Name)
                if Control is not None:
                    Control.set_text(Text)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_Style_Controls -> {E}')

    def _Refresh_All(self):
        try:
            self._Refresh_Info()
            self._Refresh_Shape_List()
            self._Refresh_Editor()
            self._Render_Shapes()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Refresh_All -> {E}')

    def _Apply_Default_Style(self, Shape):
        Shape['Color'] = self._Shape_Color
        Shape['Thickness'] = self._Shape_Thickness
        Shape['Fill_Color'] = self._Shape_Fill_Color
        Shape['Fill_Alpha'] = self._Shape_Fill_Alpha
        Shape['Visible'] = True
        Shape['Locked'] = False

    def _Build_New_Shape(self, X_Value, Y_Value):
        Shape_Mode = self._Shape_Mode
        if Shape_Mode == 'Rectangle':
            Shape = {'Type': 'Rectangle', 'Name': 'Rectangle', 'CX': X_Value, 'CY': Y_Value, 'W': 1, 'H': 1, 'Angle': 0}
        elif Shape_Mode == 'Rotated_Rectangle':
            Shape = {'Type': 'Rotated_Rectangle', 'Name': 'Rotated Rectangle', 'CX': X_Value, 'CY': Y_Value, 'W': 1, 'H': 1, 'Angle': self._Default_Angle}
        elif Shape_Mode == 'Circle':
            Shape = {'Type': 'Circle', 'Name': 'Circle', 'CX': X_Value, 'CY': Y_Value, 'R': 1}
        elif Shape_Mode == 'Ellipse':
            Shape = {'Type': 'Ellipse', 'Name': 'Ellipse', 'CX': X_Value, 'CY': Y_Value, 'RX': 1, 'RY': 1, 'Angle': self._Default_Angle}
        elif Shape_Mode == 'Line':
            Shape = {'Type': 'Line', 'Name': 'Line', 'X1': X_Value, 'Y1': Y_Value, 'X2': X_Value + 1, 'Y2': Y_Value + 1}
        elif Shape_Mode == 'Quadrilateral':
            Shape = {'Type': 'Quadrilateral', 'Name': 'Quadrilateral', 'Points': [(X_Value, Y_Value)] * 4}
        elif Shape_Mode == 'Polygon':
            Shape = {'Type': 'Polygon', 'Name': 'Polygon', 'Points': [(X_Value, Y_Value)] * 3}
        else:
            Shape = {'Type': 'Polyline', 'Name': 'Polyline', 'Points': [(X_Value, Y_Value)] * 2}
        self._Apply_Default_Style(Shape)
        return Shape

    def _Start_New_Shape(self, X_Value, Y_Value):
        self._Shapes.append(self._Build_New_Shape(X_Value, Y_Value))
        self._Active_Shape_Index = len(self._Shapes) - 1

    def _Update_Draw(self, Shape, X_Value, Y_Value):
        Start_X = self._Drag_Start_X
        Start_Y = self._Drag_Start_Y
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
            Shape['CX'] = (Start_X + X_Value) / 2
            Shape['CY'] = (Start_Y + Y_Value) / 2
            Shape['W'] = max(1, abs(X_Value - Start_X))
            Shape['H'] = max(1, abs(Y_Value - Start_Y))
            return
        if Shape['Type'] == 'Circle':
            Shape['CX'] = Start_X
            Shape['CY'] = Start_Y
            Shape['R'] = max(1, self._Distance(Start_X, Start_Y, X_Value, Y_Value))
            return
        if Shape['Type'] == 'Ellipse':
            Shape['CX'] = (Start_X + X_Value) / 2
            Shape['CY'] = (Start_Y + Y_Value) / 2
            Shape['RX'] = max(1, abs(X_Value - Start_X) / 2)
            Shape['RY'] = max(1, abs(Y_Value - Start_Y) / 2)
            return
        if Shape['Type'] == 'Line':
            Shape['X1'] = Start_X
            Shape['Y1'] = Start_Y
            Shape['X2'] = X_Value
            Shape['Y2'] = Y_Value

    def _Move_Shape(self, Shape, Original_Shape, Delta_X, Delta_Y):
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle', 'Circle', 'Ellipse'):
            Shape['CX'] = Original_Shape['CX'] + Delta_X
            Shape['CY'] = Original_Shape['CY'] + Delta_Y
            return
        if Shape['Type'] == 'Line':
            Shape['X1'] = Original_Shape['X1'] + Delta_X
            Shape['Y1'] = Original_Shape['Y1'] + Delta_Y
            Shape['X2'] = Original_Shape['X2'] + Delta_X
            Shape['Y2'] = Original_Shape['Y2'] + Delta_Y
            return
        Shape['Points'] = [(Point_X + Delta_X, Point_Y + Delta_Y) for Point_X, Point_Y in Original_Shape['Points']]

    def _Resize_Box(self, Shape, Original_Shape, Handle_Name, X_Value, Y_Value):
        Center_X = Original_Shape['CX']
        Center_Y = Original_Shape['CY']
        Local_X, Local_Y = self._Rotate_Vector(X_Value - Center_X, Y_Value - Center_Y, -Original_Shape['Angle'])
        Half_W = Original_Shape['W'] / 2
        Half_H = Original_Shape['H'] / 2
        Min_Size = 1
        if Handle_Name == 'Top':
            Anchor_Y = Half_H
            Move_Y = min(Local_Y, Anchor_Y - Min_Size)
            Center_Delta_X, Center_Delta_Y = self._Rotate_Vector(0, (Anchor_Y + Move_Y) / 2, Original_Shape['Angle'])
            Shape.update({'CX': Center_X + Center_Delta_X, 'CY': Center_Y + Center_Delta_Y, 'W': Original_Shape['W'], 'H': max(Min_Size, abs(Move_Y - Anchor_Y)), 'Angle': Original_Shape['Angle']})
            return
        if Handle_Name == 'Bottom':
            Anchor_Y = -Half_H
            Move_Y = max(Local_Y, Anchor_Y + Min_Size)
            Center_Delta_X, Center_Delta_Y = self._Rotate_Vector(0, (Anchor_Y + Move_Y) / 2, Original_Shape['Angle'])
            Shape.update({'CX': Center_X + Center_Delta_X, 'CY': Center_Y + Center_Delta_Y, 'W': Original_Shape['W'], 'H': max(Min_Size, abs(Move_Y - Anchor_Y)), 'Angle': Original_Shape['Angle']})
            return
        if Handle_Name == 'Right':
            Anchor_X = -Half_W
            Move_X = max(Local_X, Anchor_X + Min_Size)
            Center_Delta_X, Center_Delta_Y = self._Rotate_Vector((Anchor_X + Move_X) / 2, 0, Original_Shape['Angle'])
            Shape.update({'CX': Center_X + Center_Delta_X, 'CY': Center_Y + Center_Delta_Y, 'W': max(Min_Size, abs(Move_X - Anchor_X)), 'H': Original_Shape['H'], 'Angle': Original_Shape['Angle']})
            return
        if Handle_Name == 'Left':
            Anchor_X = Half_W
            Move_X = min(Local_X, Anchor_X - Min_Size)
            Center_Delta_X, Center_Delta_Y = self._Rotate_Vector((Anchor_X + Move_X) / 2, 0, Original_Shape['Angle'])
            Shape.update({'CX': Center_X + Center_Delta_X, 'CY': Center_Y + Center_Delta_Y, 'W': max(Min_Size, abs(Move_X - Anchor_X)), 'H': Original_Shape['H'], 'Angle': Original_Shape['Angle']})
            return
        Anchor_Map = {'P0': (Half_W, Half_H), 'P1': (-Half_W, Half_H), 'P2': (-Half_W, -Half_H), 'P3': (Half_W, -Half_H)}
        Anchor_X, Anchor_Y = Anchor_Map.get(Handle_Name, (-Half_W, -Half_H))
        if Anchor_X < 0:
            Move_X = max(Local_X, Anchor_X + Min_Size)
        else:
            Move_X = min(Local_X, Anchor_X - Min_Size)
        if Anchor_Y < 0:
            Move_Y = max(Local_Y, Anchor_Y + Min_Size)
        else:
            Move_Y = min(Local_Y, Anchor_Y - Min_Size)
        Center_Local_X = (Anchor_X + Move_X) / 2
        Center_Local_Y = (Anchor_Y + Move_Y) / 2
        Center_Delta_X, Center_Delta_Y = self._Rotate_Vector(Center_Local_X, Center_Local_Y, Original_Shape['Angle'])
        Shape['CX'] = Center_X + Center_Delta_X
        Shape['CY'] = Center_Y + Center_Delta_Y
        Shape['W'] = max(Min_Size, abs(Move_X - Anchor_X))
        Shape['H'] = max(Min_Size, abs(Move_Y - Anchor_Y))
        Shape['Angle'] = Original_Shape['Angle']

    def _Resize_Ellipse(self, Shape, Original_Shape, Handle_Name, X_Value, Y_Value):
        Local_X, Local_Y = self._Rotate_Vector(X_Value - Original_Shape['CX'], Y_Value - Original_Shape['CY'], -Original_Shape['Angle'])
        Shape['CX'] = Original_Shape['CX']
        Shape['CY'] = Original_Shape['CY']
        Shape['Angle'] = Original_Shape['Angle']
        Shape['RX'] = max(1, abs(Local_X)) if Handle_Name in ('Right', 'Left') else Original_Shape['RX']
        Shape['RY'] = max(1, abs(Local_Y)) if Handle_Name in ('Top', 'Bottom') else Original_Shape['RY']

    def _Resize_Circle(self, Shape, Original_Shape, X_Value, Y_Value):
        Shape['CX'] = Original_Shape['CX']
        Shape['CY'] = Original_Shape['CY']
        Shape['R'] = max(1, self._Distance(Original_Shape['CX'], Original_Shape['CY'], X_Value, Y_Value))

    def _Resize_Line(self, Shape, Original_Shape, Handle_Name, X_Value, Y_Value):
        Shape.update(Original_Shape)
        if Handle_Name == 'P1':
            Shape['X1'] = X_Value
            Shape['Y1'] = Y_Value
            return
        if Handle_Name == 'P2':
            Shape['X2'] = X_Value
            Shape['Y2'] = Y_Value

    def _Resize_Point_Shape(self, Shape, Original_Shape, Handle_Name, X_Value, Y_Value):
        Shape['Points'] = list(Original_Shape['Points'])
        if Handle_Name.startswith('Point_'):
            Index = int(Handle_Name.split('_', 1)[1])
            if 0 <= Index < len(Shape['Points']):
                Shape['Points'][Index] = (X_Value, Y_Value)

    def _Apply_Resize(self, Shape, Original_Shape, Handle_Name, X_Value, Y_Value):
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
            self._Resize_Box(Shape, Original_Shape, Handle_Name, X_Value, Y_Value)
            return
        if Shape['Type'] == 'Ellipse':
            self._Resize_Ellipse(Shape, Original_Shape, Handle_Name, X_Value, Y_Value)
            return
        if Shape['Type'] == 'Circle':
            self._Resize_Circle(Shape, Original_Shape, X_Value, Y_Value)
            return
        if Shape['Type'] == 'Line':
            self._Resize_Line(Shape, Original_Shape, Handle_Name, X_Value, Y_Value)
            return
        if Shape['Type'] in ('Quadrilateral', 'Polygon', 'Polyline'):
            self._Resize_Point_Shape(Shape, Original_Shape, Handle_Name, X_Value, Y_Value)

    def _Rotate_Point_List(self, Point_List, Center_X, Center_Y, Angle_Delta):
        Result_List = []
        for Point_X, Point_Y in Point_List:
            Result_List.append(self._Rotate_Point(Point_X, Point_Y, Center_X, Center_Y, Angle_Delta))
        return Result_List

    def _Apply_Rotate(self, Shape, Original_Shape, X_Value, Y_Value):
        Center_X, Center_Y = self._Get_Shape_Center(Original_Shape)
        Start_Angle = atan2(self._Drag_Start_Y - Center_Y, self._Drag_Start_X - Center_X)
        New_Angle = atan2(Y_Value - Center_Y, X_Value - Center_X)
        Angle_Delta = self._To_Degrees(New_Angle - Start_Angle)
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle', 'Ellipse'):
            Shape.update(Original_Shape)
            Shape['Angle'] = Original_Shape['Angle'] + Angle_Delta
            return
        if Shape['Type'] == 'Line':
            Shape['X1'], Shape['Y1'] = self._Rotate_Point(Original_Shape['X1'], Original_Shape['Y1'], Center_X, Center_Y, Angle_Delta)
            Shape['X2'], Shape['Y2'] = self._Rotate_Point(Original_Shape['X2'], Original_Shape['Y2'], Center_X, Center_Y, Angle_Delta)
            return
        if Shape['Type'] in ('Quadrilateral', 'Polygon', 'Polyline'):
            Shape['Points'] = self._Rotate_Point_List(Original_Shape['Points'], Center_X, Center_Y, Angle_Delta)

    def _Delete_Tiny_Shape_If_Needed(self):
        Shape = self._Get_Active_Shape()
        if Shape is None:
            return
        Delete_Value = False
        if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle') and (Shape['W'] < self._Min_Draw_Size or Shape['H'] < self._Min_Draw_Size):
            Delete_Value = True
        elif Shape['Type'] == 'Circle' and Shape['R'] < self._Min_Draw_Size:
            Delete_Value = True
        elif Shape['Type'] == 'Ellipse' and (Shape['RX'] < self._Min_Draw_Size or Shape['RY'] < self._Min_Draw_Size):
            Delete_Value = True
        elif Shape['Type'] == 'Line' and self._Distance(Shape['X1'], Shape['Y1'], Shape['X2'], Shape['Y2']) < self._Min_Draw_Size:
            Delete_Value = True
        if Delete_Value:
            del self._Shapes[self._Active_Shape_Index]
            self._Active_Shape_Index = -1
            self._Set_Status('Tiny shape removed')

    def _Clear_Draft(self):
        self._Draft_Points = []
        self._Draft_Hover_X = None
        self._Draft_Hover_Y = None
        self._Draft_Type = ''

    def _Disable_Draw_Mode_After_Create(self):
        self._Draw_Enabled = False
        self._Pan_View_Enabled = False
        self._Set_Status('Shape created and edit mode enabled')

    def _Deduplicate_Draft_Point_List(self, Point_List):
        Result_List = []
        for Point in Point_List:
            if not Result_List or self._Distance(Result_List[-1][0], Result_List[-1][1], Point[0], Point[1]) > 0.0001:
                Result_List.append(Point)
        return Result_List

    def _Add_Draft_Point(self, X_Value, Y_Value):
        if self._Draft_Type == '':
            self._Draft_Type = self._Shape_Mode
            self._Draft_Points = []
        if self._Draft_Type != self._Shape_Mode:
            self._Clear_Draft()
            self._Draft_Type = self._Shape_Mode
        self._Draft_Points.append((X_Value, Y_Value))
        self._Draft_Hover_X = X_Value
        self._Draft_Hover_Y = Y_Value
        if self._Shape_Mode == 'Quadrilateral' and len(self._Draft_Points) >= 4:
            self._Finish_Draft_Shape()
            return
        self._Refresh_All()
        self._Set_Status(f'Draft point added: {len(self._Draft_Points)}')

    def _Finish_Draft_Shape(self):
        if self._Draft_Type == '' or not self._Draft_Points:
            self._Set_Status('No draft shape to finish')
            return
        Point_List = self._Deduplicate_Draft_Point_List(list(self._Draft_Points))
        if self._Draft_Type == 'Quadrilateral':
            if len(Point_List) < 4:
                self._Set_Status('Quadrilateral needs 4 points')
                return
            Point_List = Point_List[:4]
        elif self._Draft_Type == 'Polygon':
            if len(Point_List) < 3:
                self._Set_Status('Polygon needs at least 3 points')
                return
        elif self._Draft_Type == 'Polyline':
            if len(Point_List) < 2:
                self._Set_Status('Polyline needs at least 2 points')
                return
        self._Push_Undo()
        Shape = {'Type': self._Draft_Type, 'Name': self._Draft_Type.replace('_', ' '), 'Points': Point_List}
        self._Apply_Default_Style(Shape)
        if Shape['Type'] == 'Quadrilateral':
            Shape['Name'] = 'Quadrilateral'
        elif Shape['Type'] == 'Polygon':
            Shape['Name'] = 'Polygon'
        elif Shape['Type'] == 'Polyline':
            Shape['Name'] = 'Polyline'
        self._Shapes.append(Shape)
        self._Active_Shape_Index = len(self._Shapes) - 1
        self._Clear_Draft()
        self._Disable_Draw_Mode_After_Create()
        self._Refresh_All()
        self._Fire_Shape_Event('draw', Index=self._Active_Shape_Index, Old_Shape=None, New_Shape=deepcopy(Shape))

    def _Cancel_Draft_Shape(self):
        self._Clear_Draft()
        self._Refresh_All()
        self._Set_Status('Draft canceled')

    def _Insert_Point_On_Selected_Shape(self, X_Value, Y_Value):
        Shape = self._Get_Active_Shape()
        if Shape is None or Shape['Locked'] or Shape['Type'] not in ('Polygon', 'Polyline'):
            return
        Point_List = list(Shape['Points'])
        if len(Point_List) < 2:
            return
        Closed_Value = Shape['Type'] == 'Polygon'
        Best_Distance = None
        Best_Index = None
        Best_Point = None
        Last_Count = len(Point_List) if Closed_Value else len(Point_List) - 1
        for Index in range(Last_Count):
            X1, Y1 = Point_List[Index]
            X2, Y2 = Point_List[(Index + 1) % len(Point_List)]
            Closest_X, Closest_Y, Distance_Value = self._Project_Point_To_Segment(X_Value, Y_Value, X1, Y1, X2, Y2)
            if Best_Distance is None or Distance_Value < Best_Distance:
                Best_Distance = Distance_Value
                Best_Index = Index + 1
                Best_Point = (Closest_X, Closest_Y)
        if Best_Distance is None or Best_Distance > max(10, Shape['Thickness'] + 6):
            return
        self._Push_Undo()
        Old_Shape = deepcopy(Shape)
        Shape['Points'].insert(Best_Index, Best_Point)
        New_Shape = deepcopy(Shape)
        self._Refresh_All()
        self._Set_Status('Point inserted on side')
        self._Fire_Shape_Event('resize', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)

    def _Update_Hover_Cursor(self, X_Value, Y_Value):
        if self._Draw_Enabled:
            self._Set_Cursor('crosshair')
            return
        Handle_Item = self._Find_Selected_Handle(X_Value, Y_Value)
        if Handle_Item is not None:
            self._Set_Cursor(Handle_Item['Cursor'])
            return
        Shape_Index = self._Find_Shape(X_Value, Y_Value)
        if Shape_Index >= 0:
            Shape = self._Shapes[Shape_Index]
            self._Set_Cursor('not-allowed' if Shape['Locked'] else 'move')
            return
        Shape = self._Get_Active_Shape()
        if Shape is not None and not Shape['Locked'] and not bool(Shape.get('Disable_Rotation', False)):
            self._Set_Cursor('alias')
            return
        if self._Pan_View_Enabled:
            self._Set_Cursor('grab')
            return
        self._Set_Cursor('default')

    def _Handle_Editor_Pointer(self, Event):
        try:
            Args = Event.args if isinstance(getattr(Event, 'args', None), dict) else {}
            Event_Type = Args.get('type', getattr(Event, 'type', ''))
            View_X, View_Y = self._Get_View_Position(Args)
            Client_X = float(Args.get('clientX', View_X))
            Client_Y = float(Args.get('clientY', View_Y))
            X_Value, Y_Value = self._Get_Image_Position(View_X, View_Y)
            if Event_Type == 'pointerdown':
                self._Handle_Editor_Down(X_Value, Y_Value, Client_X, Client_Y)
                return
            if Event_Type == 'pointermove':
                self._Handle_Editor_Move(X_Value, Y_Value, Client_X, Client_Y, Args.get('buttons', 1))
                return
            if Event_Type in ('pointerup', 'pointerleave', 'pointercancel'):
                self._Handle_Editor_Up(X_Value, Y_Value, Event_Type)
                return
            if Event_Type == 'dblclick':
                self._Handle_Editor_Double_Click(X_Value, Y_Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Editor_Pointer -> {E}')

    def _Handle_Editor_Double_Click(self, X_Value, Y_Value):
        if self._Draw_Enabled and self._Shape_Mode in ('Polygon', 'Polyline', 'Quadrilateral'):
            self._Finish_Draft_Shape()
            return
        if not self._Draw_Enabled:
            self._Insert_Point_On_Selected_Shape(X_Value, Y_Value)

    def _Make_Event(self, Name=None, Shape=None, Index=None, Old_Shape=None, New_Shape=None, Old_Shapes=None, New_Shapes=None, Data=None):
        try:
            Payload = {
                'name': Name,
                'shape': Shape,
                'index': Index,
                'old_shape': Old_Shape,
                'new_shape': New_Shape,
                'old_shapes': Old_Shapes,
                'new_shapes': New_Shapes,
                'data': Data,
                'editor': self,
            }
            return type('Editor_Event', (), Payload)()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Make_Event -> {E}')
            return type('Editor_Event', (), {})()
            
    def _Snapshot(self):
        try:
            return self.Export()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Snapshot -> {E}')
            return {}
            
    def _Push_Undo(self):
        try:
            if getattr(self, '_History_Block', False):
                return False
            if not hasattr(self, '_Undo_Stack'):
                self._Undo_Stack = []
            if not hasattr(self, '_Redo_Stack'):
                self._Redo_Stack = []
            self._Undo_Stack.append(self._Snapshot())
            Limit = int(getattr(self, '_History_Limit', 100))
            if Limit > 0 and len(self._Undo_Stack) > Limit:
                self._Undo_Stack = self._Undo_Stack[-Limit:]
            self._Redo_Stack = []
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Push_Undo -> {E}')
            return False
            
    def _Import_State(self, Data):
        try:
            if not isinstance(Data, dict):
                return False
            Shapes = Data.get('Shapes', [])
            if not isinstance(Shapes, list):
                Shapes = []
            self._Shapes = deepcopy(Shapes)
            self._Active_Shape_Index = int(Data.get('Active_Shape_Index', -1))
            if self._Active_Shape_Index >= len(self._Shapes):
                self._Active_Shape_Index = len(self._Shapes) - 1
            if self._Active_Shape_Index < -1:
                self._Active_Shape_Index = -1
            self._Draw_Enabled = bool(Data.get('Draw_Enabled', False))
            self._Pan_View_Enabled = bool(Data.get('Pan_View_Enabled', False))
            self._Drag_Mode = ''
            self._Original_Shape = None
            self._Active_Handle = ''
            self._View_Dragging = False
            self._Clear_Draft()
            self._Refresh_All()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Import_State -> {E}')
            return False
            
    def _Copy_Shape_To_Clipboard(self, Shape):
        try:
            type(self)._Global_Shape_Clipboard = deepcopy(Shape)
            type(self)._Global_Shape_Clipboard_Ready = True
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Copy_Shape_To_Clipboard -> {E}')
            return False
            
    def _Get_Clipboard_Shape(self):
        try:
            if not getattr(type(self), '_Global_Shape_Clipboard_Ready', False):
                return None
            return deepcopy(getattr(type(self), '_Global_Shape_Clipboard', None))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Get_Clipboard_Shape -> {E}')
            return None
            
    def _Offset_Shape_Copy(self, Shape, Offset_X=10, Offset_Y=10):
        try:
            if Shape is None:
                return None
            Result = deepcopy(Shape)
            if Result['Type'] in ('Rectangle', 'Rotated_Rectangle', 'Circle', 'Ellipse'):
                Result['CX'] = Result.get('CX', 0) + Offset_X
                Result['CY'] = Result.get('CY', 0) + Offset_Y
                return Result
            if Result['Type'] == 'Line':
                Result['X1'] = Result.get('X1', 0) + Offset_X
                Result['Y1'] = Result.get('Y1', 0) + Offset_Y
                Result['X2'] = Result.get('X2', 0) + Offset_X
                Result['Y2'] = Result.get('Y2', 0) + Offset_Y
                return Result
            if Result['Type'] in ('Quadrilateral', 'Polygon', 'Polyline'):
                Result['Points'] = [(Point_X + Offset_X, Point_Y + Offset_Y) for Point_X, Point_Y in Result.get('Points', [])]
                return Result
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Offset_Shape_Copy -> {E}')
            return Shape
            
    def _Shape_Changes(self, Before, After):
        try:
            return {
                'Old_Shapes': deepcopy(Before.get('Shapes', [])),
                'New_Shapes': deepcopy(After.get('Shapes', [])),
            }
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Shape_Changes -> {E}')
            return {'Old_Shapes': [], 'New_Shapes': []}
            
    def _Event_Arg(self, E, Index=0, Default=None):
        try:
            if not hasattr(E, 'args'):
                return Default
            Args = E.args
            if isinstance(Args, list) or isinstance(Args, tuple):
                if len(Args) > Index:
                    return Args[Index]
                return Default
            if isinstance(Args, dict):
                Keys = list(Args.keys())
                if len(Keys) > Index:
                    return Args[Keys[Index]]
                return Default
            return Default
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Event_Arg -> {E}')
            return Default
            
    def _Handle_Key(self, E):
        try:
            if not self._Input_Allowed():
                return
            Detail = self._Key_Detail(E)
            if Detail:
                if not bool(Detail.get('focused', False)):
                    return
                if not bool(Detail.get('visible', True)):
                    return
                Key = str(Detail.get('key', '') or '')
                Ctrl = bool(Detail.get('ctrlKey', False)) or bool(Detail.get('metaKey', False))
                Target = str(Detail.get('target', '') or '').lower()
            else:
                Key = str(self._Event_Arg(E, 0, '') or '')
                Ctrl = bool(self._Event_Arg(E, 1, False)) or bool(self._Event_Arg(E, 2, False))
                Target = str(self._Event_Arg(E, 4, '') or '').lower()
            Lower = Key.lower()
            if Target in ['input', 'textarea', 'select']:
                return
            if Ctrl and Lower == 'z':
                self.Undo()
                return
            if Ctrl and Lower == 'y':
                self.Redo()
                return
            if Ctrl and Lower == 'c':
                self.Copy()
                return
            if Ctrl and Lower == 'x':
                self.Cut()
                return
            if Ctrl and Lower == 'v':
                self.Paste()
                return
            if Key == 'Delete':
                self.Delete_Selected()
                return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Key -> {E}')
            
    def _Handle_Editor_Down(self, X_Value, Y_Value, View_X, View_Y):
        if self._Stage is not None:
            try:
                self._Stage.run_method('focus')
            except Exception:
                pass
        if self._Draw_Enabled:
            if self._Shape_Mode in ('Quadrilateral', 'Polygon', 'Polyline'):
                self._Add_Draft_Point(X_Value, Y_Value)
                return
            self._Push_Undo()
            self._Drag_Mode = 'Draw'
            self._Drag_Start_X = X_Value
            self._Drag_Start_Y = Y_Value
            self._Start_New_Shape(X_Value, Y_Value)
            self._Original_Shape = self._Deep_Copy_Shape(self._Get_Active_Shape())
            self._Active_Handle = ''
            self._Refresh_All()
            self._Set_Cursor('crosshair')
            self._Set_Status(f'Start draw {self._Shape_Mode.lower()}')
            return
        Handle_Item = self._Find_Selected_Handle(X_Value, Y_Value)
        if Handle_Item is not None:
            Shape = self._Get_Active_Shape()
            if Shape is None or Shape['Locked']:
                self._Set_Status('Selected shape is locked')
                return
            self._Push_Undo()
            self._Pan_View_Enabled = False
            self._View_Dragging = False
            self._Drag_Mode = Handle_Item['Kind']
            self._Drag_Start_X = X_Value
            self._Drag_Start_Y = Y_Value
            self._View_Drag_Start_X = View_X
            self._View_Drag_Start_Y = View_Y
            self._Original_Shape = self._Deep_Copy_Shape(Shape)
            self._Active_Handle = Handle_Item['Name']
            self._Set_Cursor(Handle_Item['Cursor'])
            self._Set_Status(f'{Handle_Item["Kind"]} shape')
            return
        Shape_Index = self._Find_Shape(X_Value, Y_Value)
        if Shape_Index >= 0:
            self._Pan_View_Enabled = False
            self._Active_Shape_Index = Shape_Index
            Shape = self._Shapes[Shape_Index]
            if Shape['Locked']:
                self._View_Dragging = False
                self._Drag_Mode = ''
                self._Original_Shape = None
                self._Refresh_All()
                self._Set_Cursor('not-allowed')
                self._Set_Status('Selected shape is locked')
                return
            self._Push_Undo()
            self._View_Dragging = False
            self._Drag_Mode = 'Move'
            self._Drag_Start_X = X_Value
            self._Drag_Start_Y = Y_Value
            self._View_Drag_Start_X = View_X
            self._View_Drag_Start_Y = View_Y
            self._Original_Shape = self._Deep_Copy_Shape(Shape)
            self._Active_Handle = 'Move'
            self._Refresh_All()
            self._Set_Cursor('move')
            self._Set_Status('Move shape')
            return
        Shape = self._Get_Active_Shape()
        if Shape is not None and not Shape['Locked'] and not bool(Shape.get('Disable_Rotation', False)):
            self._Push_Undo()
            self._Pan_View_Enabled = False
            self._View_Dragging = False
            self._Drag_Mode = 'Outside'
            self._Drag_Start_X = X_Value
            self._Drag_Start_Y = Y_Value
            self._View_Drag_Start_X = View_X
            self._View_Drag_Start_Y = View_Y
            self._Original_Shape = self._Deep_Copy_Shape(Shape)
            self._Active_Handle = 'Rotate'
            self._Set_Cursor('alias')
            self._Set_Status('Outside drag rotates shape')
            return
        self._Active_Shape_Index = -1
        self._Drag_Mode = ''
        self._Original_Shape = None
        self._Active_Handle = ''
        self._View_Dragging = True
        self._View_Drag_Start_X = View_X
        self._View_Drag_Start_Y = View_Y
        self._Pan_Start_X = self._Pan_X
        self._Pan_Start_Y = self._Pan_Y
        self._Refresh_All()
        self._Set_Cursor('grabbing')
        self._Set_Status('Pan image')
        self._Update_Transform()

    def _Handle_Editor_Move(self, X_Value, Y_Value, View_X, View_Y, Buttons):
        if Buttons == 0:
            self._Handle_Editor_Up(X_Value, Y_Value, 'pointerup')
            return
        if self._View_Dragging:
            Delta_View_X = View_X - self._View_Drag_Start_X
            Delta_View_Y = View_Y - self._View_Drag_Start_Y
            self._Pan_X = self._Pan_Start_X + Delta_View_X
            self._Pan_Y = self._Pan_Start_Y + Delta_View_Y
            self._Update_Transform()
            return
        if self._Draft_Type != '':
            self._Draft_Hover_X = X_Value
            self._Draft_Hover_Y = Y_Value
        if self._Drag_Mode == '':
            self._Update_Hover_Cursor(X_Value, Y_Value)
            if self._Draft_Type != '':
                self._Render_Shapes()
            return
        Shape = self._Get_Active_Shape()
        if Shape is None:
            return
        if self._Drag_Mode == 'Outside':
            Delta_View_X = View_X - self._View_Drag_Start_X
            Delta_View_Y = View_Y - self._View_Drag_Start_Y
            Distance_Value = sqrt((Delta_View_X ** 2) + (Delta_View_Y ** 2))
            if Distance_Value < self._Click_Reset_Threshold:
                return
            self._Drag_Mode = 'Rotate'
            self._Apply_Rotate(Shape, self._Original_Shape, X_Value, Y_Value)
            self._Render_Shapes()
            self._Set_Cursor('alias')
            return
        if self._Drag_Mode == 'Draw':
            self._Update_Draw(Shape, X_Value, Y_Value)
            self._Render_Shapes()
            return
        if self._Drag_Mode == 'Move':
            Delta_X = X_Value - self._Drag_Start_X
            Delta_Y = Y_Value - self._Drag_Start_Y
            self._Move_Shape(Shape, self._Original_Shape, Delta_X, Delta_Y)
            self._Render_Shapes()
            return
        if self._Drag_Mode == 'Resize':
            self._Apply_Resize(Shape, self._Original_Shape, self._Active_Handle, X_Value, Y_Value)
            self._Render_Shapes()
            return
        if self._Drag_Mode == 'Rotate':
            self._Apply_Rotate(Shape, self._Original_Shape, X_Value, Y_Value)
            self._Render_Shapes()

    def _Fire_Shape_Event(self, Name, Index=None, Old_Shape=None, New_Shape=None, Data=None):
        try:
            Shape = New_Shape if New_Shape is not None else Old_Shape
            Event = self._Make_Event(Name=Name, Shape=deepcopy(Shape), Index=Index, Old_Shape=deepcopy(Old_Shape), New_Shape=deepcopy(New_Shape), Data=Data)
            Callback = False
            if Name == 'select':
                Callback = self._On_Select
            elif Name == 'draw':
                Callback = self._On_Draw
            elif Name == 'move':
                Callback = self._On_Move
            elif Name == 'resize':
                Callback = self._On_Resize
            elif Name == 'rotate':
                Callback = self._On_Rotate
            elif Name == 'delete':
                Callback = self._On_Delete
            if Callback:
                Callback(Event)
            if Name != 'select' and self._On_Change:
                self._On_Change(Event)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Fire_Shape_Event -> {E}')
            return False
            
    def _Drag_Event_Name(self, Drag_Mode):
        try:
            if Drag_Mode == 'Draw':
                return 'draw'
            if Drag_Mode == 'Move':
                return 'move'
            if Drag_Mode == 'Resize':
                return 'resize'
            if Drag_Mode == 'Rotate':
                return 'rotate'
            return ''
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Drag_Event_Name -> {E}')
            return ''

    def _Handle_Editor_Up(self, X_Value, Y_Value, Event_Type):
        if self._View_Dragging:
            self._View_Dragging = False
            self._Update_Transform()
            if Event_Type == 'pointerleave':
                self._Set_Cursor('crosshair')
            else:
                self._Update_Hover_Cursor(X_Value, Y_Value)
            return
        Full_Refresh = False
        Event_Name = self._Drag_Event_Name(self._Drag_Mode)
        Event_Index = self._Active_Shape_Index
        Old_Shape = deepcopy(self._Original_Shape) if self._Original_Shape is not None else None
        if self._Drag_Mode == 'Outside':
            Delta_View_X = 0
            Delta_View_Y = 0
            try:
                Scale_Value = self._Fit_Scale * self._Zoom
                Delta_View_X = (X_Value - self._Drag_Start_X) * Scale_Value
                Delta_View_Y = (Y_Value - self._Drag_Start_Y) * Scale_Value
            except Exception:
                Delta_View_X = X_Value - self._Drag_Start_X
                Delta_View_Y = Y_Value - self._Drag_Start_Y
            Distance_Value = sqrt((Delta_View_X ** 2) + (Delta_View_Y ** 2))
            if Distance_Value < self._Click_Reset_Threshold and Event_Type != 'pointerleave':
                self._Active_Shape_Index = -1
                self._Pan_View_Enabled = True
                self._Drag_Mode = ''
                self._Original_Shape = None
                self._Active_Handle = ''
                self._Refresh_All()
                self._Set_Cursor('grab')
                self._Set_Status('Pan mode enabled')
                self._Update_Transform()
                return
        if self._Drag_Mode == 'Draw':
            Shape_Count = len(self._Shapes)
            self._Delete_Tiny_Shape_If_Needed()
            if len(self._Shapes) != Shape_Count:
                Full_Refresh = True
                Event_Name = ''
            elif self._Active_Shape_Index >= 0:
                self._Disable_Draw_Mode_After_Create()
                Full_Refresh = True
        New_Shape = deepcopy(self._Get_Active_Shape()) if self._Active_Shape_Index >= 0 else None
        Changed = Event_Name != '' and Old_Shape != New_Shape and New_Shape is not None
        self._Drag_Mode = ''
        self._Original_Shape = None
        self._Active_Handle = ''
        if Full_Refresh:
            self._Refresh_All()
        else:
            self._Refresh_Info()
            self._Refresh_Editor()
            self._Render_Shapes()
        if Changed:
            self._Fire_Shape_Event(Event_Name, Index=Event_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)
        if Event_Type == 'pointerleave':
            self._Set_Cursor('crosshair')
        else:
            self._Update_Hover_Cursor(X_Value, Y_Value)

    def _Parse_Point_Text(self, Text):
        Point_List = []
        for Part in str(Text).replace('\n', ';').split(';'):
            Part = Part.strip()
            if not Part:
                continue
            if ',' in Part:
                X_Text, Y_Text = Part.split(',', 1)
            else:
                Pieces = Part.split()
                if len(Pieces) < 2:
                    continue
                X_Text, Y_Text = Pieces[0], Pieces[1]
            try:
                Point_List.append((float(X_Text), float(Y_Text)))
            except Exception:
                continue
        return Point_List

    def _Geometry_Changed(self, Event=None):
        try:
            Shape = self._Get_Active_Shape()
            if Shape is None or Shape['Locked']:
                return
            Values = {}
            for Key_Name in ('CX', 'CY', 'W', 'H', 'Angle', 'R', 'RX', 'RY', 'X1', 'Y1', 'X2', 'Y2'):
                Control = self._Control(f'Field_{Key_Name}')
                Values[Key_Name] = 0 if Control is None or Control.value is None else float(Control.value)
            if Shape['Type'] in ('Rectangle', 'Rotated_Rectangle'):
                Shape['CX'] = Values['CX']
                Shape['CY'] = Values['CY']
                Shape['W'] = max(1, Values['W'])
                Shape['H'] = max(1, Values['H'])
                Shape['Angle'] = Values['Angle']
            elif Shape['Type'] == 'Circle':
                Shape['CX'] = Values['CX']
                Shape['CY'] = Values['CY']
                Shape['R'] = max(1, Values['R'])
            elif Shape['Type'] == 'Ellipse':
                Shape['CX'] = Values['CX']
                Shape['CY'] = Values['CY']
                Shape['RX'] = max(1, Values['RX'])
                Shape['RY'] = max(1, Values['RY'])
                Shape['Angle'] = Values['Angle']
            elif Shape['Type'] == 'Line':
                Shape['X1'] = Values['X1']
                Shape['Y1'] = Values['Y1']
                Shape['X2'] = Values['X2']
                Shape['Y2'] = Values['Y2']
            elif Shape['Type'] == 'Quadrilateral':
                Point_List = self._Parse_Point_Text(self._Control('Points_Textarea').value if self._Control('Points_Textarea') is not None else '')
                if len(Point_List) == 4:
                    Shape['Points'] = Point_List
            elif Shape['Type'] == 'Polygon':
                Point_List = self._Parse_Point_Text(self._Control('Points_Textarea').value if self._Control('Points_Textarea') is not None else '')
                if len(Point_List) >= 3:
                    Shape['Points'] = Point_List
            elif Shape['Type'] == 'Polyline':
                Point_List = self._Parse_Point_Text(self._Control('Points_Textarea').value if self._Control('Points_Textarea') is not None else '')
                if len(Point_List) >= 2:
                    Shape['Points'] = Point_List
            self._Render_Shapes()
            self._Set_Status('Shape geometry updated')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Geometry_Changed -> {E}')

    def _Draw_Mode_Changed(self, Event):
        self.Draw(bool(Event.value))

    def _Pan_View_Changed(self, Event):
        self.Pan_View(bool(Event.value))

    def _Shape_Mode_Changed(self, Event):
        self.Shape_Mode(Event.value)

    def _Default_Angle_Changed(self, Event):
        self.Default_Angle(Event.value)

    def _Shape_Color_Changed(self, Event):
        self.Shape_Color(Event.value)

    def _Shape_Fill_Color_Changed(self, Event):
        self.Shape_Fill(Event.value, None)

    def _Shape_Fill_Alpha_Changed(self, Event):
        self.Shape_Fill(None, Event.value)

    def _Shape_Thickness_Changed(self, Event):
        self.Shape_Thickness(Event.value)

    def _Active_Border_Color_Changed(self, Event):
        self.Active_Border_Color(Event.value)

    def _Shape_Select_Changed(self, Event):
        try:
            self.Select(None if Event.value is None else int(Event.value))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Shape_Select_Changed -> {E}')

    def _Shape_Name_Changed(self, Event):
        Shape = self._Get_Active_Shape()
        if Shape is not None and not Shape['Locked']:
            self._Push_Undo()
            Old_Shape = deepcopy(Shape)
            Shape['Name'] = str(Event.value)
            New_Shape = deepcopy(Shape)
            self._Refresh_All()
            self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)

    def _Shape_Visible_Changed(self, Event):
        Shape = self._Get_Active_Shape()
        if Shape is not None:
            self._Push_Undo()
            Old_Shape = deepcopy(Shape)
            Shape['Visible'] = bool(Event.value)
            New_Shape = deepcopy(Shape)
            self._Refresh_All()
            self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)

    def _Shape_Locked_Changed(self, Event):
        Shape = self._Get_Active_Shape()
        if Shape is not None:
            self._Push_Undo()
            Old_Shape = deepcopy(Shape)
            Shape['Locked'] = bool(Event.value)
            New_Shape = deepcopy(Shape)
            self._Refresh_All()
            self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)

    def Tools(self, Main=None):
        try:
            Parent = Main
            if Parent is not None and hasattr(Parent, 'Widget') and callable(Parent.Widget):
                Parent = Parent.Widget()
            if Parent is not None:
                with Parent:
                    return self._Build_Tools()
            return self._Build_Tools()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Tools -> {E}')

    def _Build_Tools(self):
        with ui.card().classes('w-full'):
            ui.label('Editor Image Shape Tool').classes('text-h5')
            ui.label('Use Draw Mode to create shapes. Use Manipulate Mode to select, move, resize, rotate, and double-click polygon or polyline sides to insert points.')
            with ui.row().classes('gap-4 items-center wrap'):
                self._Tool_Controls['Draw_Mode_Switch'] = ui.switch('Draw Mode', value=self._Draw_Enabled, on_change=self._Draw_Mode_Changed)
                self._Tool_Controls['Pan_View_Switch'] = ui.switch('Pan View', value=self._Pan_View_Enabled, on_change=self._Pan_View_Changed)
                ui.button('Zoom In', on_click=self.Zoom_In)
                ui.button('Zoom Out', on_click=self.Zoom_Out)
                ui.button('Reset View', on_click=self.Reset_View)
                ui.radio(['Rectangle', 'Rotated_Rectangle', 'Circle', 'Ellipse', 'Line', 'Quadrilateral', 'Polygon', 'Polyline'], value=self._Shape_Mode, on_change=self._Shape_Mode_Changed)
                self._Tool_Controls['Shape_Color_Input'] = ui.color_input('Stroke', value=self._Shape_Color, on_change=self._Shape_Color_Changed)
                self._Tool_Controls['Shape_Fill_Color_Input'] = ui.color_input('Fill', value=self._Shape_Fill_Color, on_change=self._Shape_Fill_Color_Changed)
                self._Tool_Controls['Shape_Fill_Alpha_Slider'] = ui.slider(min=0, max=1, step=0.05, value=self._Shape_Fill_Alpha, on_change=self._Shape_Fill_Alpha_Changed).classes('w-40')
                self._Tool_Controls['Shape_Thickness_Slider'] = ui.slider(min=1, max=12, value=self._Shape_Thickness, on_change=self._Shape_Thickness_Changed).classes('w-48')
                self._Tool_Controls['Active_Border_Color_Input'] = ui.color_input('Active Border', value=self._Active_Border_Color, on_change=self._Active_Border_Color_Changed)
                self._Tool_Controls['Default_Angle_Number'] = ui.number('Default Angle', value=self._Default_Angle, on_change=self._Default_Angle_Changed).classes('w-32')
                ui.button('Finish Draft', on_click=self._Finish_Draft_Shape, color='primary')
                ui.button('Cancel Draft', on_click=self._Cancel_Draft_Shape, color='secondary')
                ui.button('Delete Selected', on_click=self.Delete_Selected, color='warning')
                ui.button('Clear Shapes', on_click=self.Clear_Shapes, color='negative')
                ui.button('Show All', on_click=self.Show_All)
                ui.button('Hide All', on_click=self.Hide_All)
                ui.button('Lock All', on_click=self.Lock_All)
                ui.button('Unlock All', on_click=self.Unlock_All)
            with ui.row().classes('gap-6 items-center wrap'):
                self._Tool_Controls['Mode_Label'] = ui.label('Mode: Draw')
                self._Tool_Controls['Shape_Color_Label'] = ui.label(f'Stroke: {self._Shape_Color}')
                self._Tool_Controls['Shape_Fill_Color_Label'] = ui.label(f'Fill: {self._Shape_Fill_Color}')
                self._Tool_Controls['Shape_Fill_Alpha_Label'] = ui.label(f'Fill Alpha: {round(float(self._Shape_Fill_Alpha), 2)}')
                self._Tool_Controls['Shape_Thickness_Label'] = ui.label(f'Thickness: {self._Shape_Thickness}')
                self._Tool_Controls['Active_Border_Color_Label'] = ui.label(f'Active Border: {self._Active_Border_Color}')
                self._Tool_Controls['Shape_Info_Label'] = ui.label('Active Shape: none')
                self._Tool_Controls['Draft_Info_Label'] = ui.label('Draft: none')
                self._Status_Label = ui.label('Ready')
            with ui.column().classes('w-full gap-2'):
                self._Tool_Controls['Shape_Select'] = ui.select(options={}, label='Shapes', on_change=self._Shape_Select_Changed).classes('w-full')
                self._Tool_Controls['Shape_Name_Input'] = ui.input('Name', on_change=self._Shape_Name_Changed).classes('w-full')
                self._Tool_Controls['Shape_Visible_Switch'] = ui.switch('Display', value=True, on_change=self._Shape_Visible_Changed)
                self._Tool_Controls['Shape_Locked_Switch'] = ui.switch('Lock', value=False, on_change=self._Shape_Locked_Changed)
                with ui.grid(columns=4).classes('w-full gap-2'):
                    for Key_Name in ('CX', 'CY', 'W', 'H', 'Angle', 'R', 'RX', 'RY', 'X1', 'Y1', 'X2', 'Y2'):
                        self._Tool_Controls[f'Field_{Key_Name}'] = ui.number(Key_Name, value=0, on_change=self._Geometry_Changed)
                self._Tool_Controls['Points_Textarea'] = ui.textarea('Points', value='', on_change=self._Geometry_Changed).classes('w-full')
        self._Refresh_All()
        return self

    def Export(self):
        try:
            Data = {
                'Type': self._Type,
                'Version': 1,
                'Image_Width': int(self._Image_Width),
                'Image_Height': int(self._Image_Height),
                'Active_Shape_Index': int(self._Active_Shape_Index),
                'Draw_Enabled': bool(self._Draw_Enabled),
                'Pan_View_Enabled': bool(self._Pan_View_Enabled),
                'Shapes': deepcopy(self._Shapes),
            }
            if self._On_Export:
                self._On_Export(self._Make_Event(Name='export', Shape=None, Index=self._Active_Shape_Index, Data=Data))
            return Data
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Export -> {E}')
            return {}

    def Import(self, Data):
        try:
            if not isinstance(Data, dict):
                return False
            self._Push_Undo()
            self._History_Block = True
            Result = self._Import_State(Data)
            self._History_Block = False
            if Result and self._On_Import:
                self._On_Import(self._Make_Event(Name='import', Shape=None, Index=self._Active_Shape_Index, Data=Data))
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Import -> {E}')
            return False
            
    def Copy(self):
        try:
            Shape = self._Get_Active_Shape()
            if Shape is None:
                self._Set_Status('No active shape to copy')
                return None
            Copy_Value = deepcopy(Shape)
            self._Copy_Shape_To_Clipboard(Copy_Value)
            self._Set_Status('Shape copied')
            if self._On_Copy:
                self._On_Copy(self._Make_Event(Name='copy', Shape=deepcopy(Copy_Value), Index=self._Active_Shape_Index))
            return Copy_Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')
            return None
            
    def Cut(self):
        try:
            Shape = self._Get_Active_Shape()
            if Shape is None:
                self._Set_Status('No active shape to cut')
                return None
            self._Push_Undo()
            Index = self._Active_Shape_Index
            Cut_Value = deepcopy(Shape)
            self._Copy_Shape_To_Clipboard(Cut_Value)
            del self._Shapes[Index]
            self._Active_Shape_Index = -1
            self._Refresh_All()
            self._Set_Status('Shape cut')
            if self._On_Cut:
                self._On_Cut(self._Make_Event(Name='cut', Shape=deepcopy(Cut_Value), Index=Index))
            return Cut_Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Cut -> {E}')
            return None
            
    def Paste(self, Offset_X=10, Offset_Y=10):
        try:
            Shape = self._Get_Clipboard_Shape()
            if Shape is None:
                self._Set_Status('No copied shape to paste')
                return None
            self._Push_Undo()
            Paste_Value = self._Offset_Shape_Copy(Shape, Offset_X, Offset_Y)
            self._Shapes.append(Paste_Value)
            self._Active_Shape_Index = len(self._Shapes) - 1
            self._Draw_Enabled = False
            self._Pan_View_Enabled = False
            self._Refresh_All()
            self._Set_Status('Shape pasted')
            if self._On_Paste:
                self._On_Paste(self._Make_Event(Name='paste', Shape=deepcopy(Paste_Value), Index=self._Active_Shape_Index))
            return Paste_Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Paste -> {E}')
            return None
            
    def Undo(self):
        try:
            if not hasattr(self, '_Undo_Stack') or len(self._Undo_Stack) == 0:
                return False
            Before = self._Snapshot()
            State = self._Undo_Stack.pop()
            if not hasattr(self, '_Redo_Stack'):
                self._Redo_Stack = []
            self._Redo_Stack.append(Before)
            Changes = self._Shape_Changes(Before, State)
            self._History_Block = True
            Result = self._Import_State(State)
            self._History_Block = False
            if Result and self._On_Undo:
                self._On_Undo(self._Make_Event(Name='undo', Shape=None, Index=self._Active_Shape_Index, Old_Shapes=Changes['Old_Shapes'], New_Shapes=Changes['New_Shapes']))
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Undo -> {E}')
            return False
            
    def Redo(self):
        try:
            if not hasattr(self, '_Redo_Stack') or len(self._Redo_Stack) == 0:
                return False
            Before = self._Snapshot()
            State = self._Redo_Stack.pop()
            if not hasattr(self, '_Undo_Stack'):
                self._Undo_Stack = []
            self._Undo_Stack.append(Before)
            Changes = self._Shape_Changes(Before, State)
            self._History_Block = True
            Result = self._Import_State(State)
            self._History_Block = False
            if Result and self._On_Redo:
                self._On_Redo(self._Make_Event(Name='redo', Shape=None, Index=self._Active_Shape_Index, Old_Shapes=Changes['Old_Shapes'], New_Shapes=Changes['New_Shapes']))
            return Result
        except Exception as E:
            self._History_Block = False
            self._GUI.Error(f'{self._Type} -> Redo -> {E}')
            return False

    def Draw(self, Value=True):
        try:
            self._Draw_Enabled = bool(Value)
            self._Drag_Mode = ''
            self._Original_Shape = None
            self._Active_Handle = ''
            self._Set_Cursor('crosshair' if self._Draw_Enabled else 'default')
            self._Set_Status('Draw mode enabled' if self._Draw_Enabled else 'Manipulate mode enabled')
            self._Refresh_All()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Draw -> {E}')

    def Edit(self):
        return self.Draw(False)

    def Active_Border_Color(self, Value=None):
        try:
            if Value is not None:
                self._Active_Border_Color = Value
                self._Refresh_Style_Controls()
                self._Render_Shapes()
            return self._Active_Border_Color
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Active_Border_Color -> {E}')

    def Pan_View(self, Value=True):
        try:
            self._Pan_View_Enabled = bool(Value)
            self._View_Dragging = False
            self._Update_Transform()
            self._Refresh_Style_Controls()
            self._Set_Status('Pan view enabled' if self._Pan_View_Enabled else 'Pan view disabled')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pan_View -> {E}')

    def Shape_Mode(self, Value=None):
        try:
            if Value is not None:
                self._Shape_Mode = Value
                self._Set_Status(f'Shape mode set to {Value}')
                self._Refresh_All()
            return self._Shape_Mode
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape_Mode -> {E}')

    def Default_Angle(self, Value=None):
        try:
            if Value is not None:
                self._Default_Angle = float(Value)
                self._Refresh_Style_Controls()
            return self._Default_Angle
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Default_Angle -> {E}')

    def Shape_Color(self, Value=None):
        try:
            if Value is not None:
                self._Shape_Color = Value
                Shape = self._Get_Active_Shape()
                if Shape is not None and not Shape['Locked']:
                    self._Push_Undo()
                    Old_Shape = deepcopy(Shape)
                    Shape['Color'] = Value
                    New_Shape = deepcopy(Shape)
                    self._Refresh_All()
                    self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)
                    return self._Shape_Color
                self._Refresh_All()
            return self._Shape_Color
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape_Color -> {E}')

    def Shape_Fill(self, Color=None, Alpha=None):
        try:
            Shape = self._Get_Active_Shape()
            Changed = False
            Old_Shape = deepcopy(Shape) if Shape is not None else None
            if Color is not None:
                self._Shape_Fill_Color = Color
                if Shape is not None and not Shape['Locked']:
                    Shape['Fill_Color'] = Color
                    Changed = True
            if Alpha is not None:
                self._Shape_Fill_Alpha = float(Alpha)
                if Shape is not None and not Shape['Locked']:
                    Shape['Fill_Alpha'] = float(Alpha)
                    Changed = True
            if Changed:
                self._Push_Undo()
            self._Refresh_All()
            if Changed:
                self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=deepcopy(Shape))
            return [self._Shape_Fill_Color, self._Shape_Fill_Alpha]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape_Fill -> {E}')

    def Shape_Thickness(self, Value=None):
        try:
            if Value is not None:
                self._Shape_Thickness = int(Value)
                Shape = self._Get_Active_Shape()
                if Shape is not None and not Shape['Locked']:
                    self._Push_Undo()
                    Old_Shape = deepcopy(Shape)
                    Shape['Thickness'] = int(Value)
                    New_Shape = deepcopy(Shape)
                    self._Refresh_All()
                    self._Fire_Shape_Event('change', Index=self._Active_Shape_Index, Old_Shape=Old_Shape, New_Shape=New_Shape)
                    return self._Shape_Thickness
                self._Refresh_All()
            return self._Shape_Thickness
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape_Thickness -> {E}')

    def Select(self, Index=None):
        try:
            if Index is None:
                self._Active_Shape_Index = -1
            else:
                Index = int(Index)
                self._Active_Shape_Index = Index if 0 <= Index < len(self._Shapes) else -1
            self._Refresh_All()
            Shape = self._Get_Active_Shape()
            self._Fire_Shape_Event('select', Index=self._Active_Shape_Index, Old_Shape=None, New_Shape=deepcopy(Shape))
            return Shape
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Select -> {E}')

    def Selected(self):
        try:
            return self._Get_Active_Shape()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Selected -> {E}')

    def Shapes(self):
        try:
            return deepcopy(self._Shapes)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shapes -> {E}')

    def Shapes_Set(self, Shapes):
        try:
            self._Shapes = deepcopy(Shapes) if Shapes is not None else []
            self._Active_Shape_Index = -1
            self._Clear_Draft()
            self._Refresh_All()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shapes_Set -> {E}')

    def Shape_Add(self, Shape, Select=True):
        try:
            self._Push_Undo()
            New_Shape = deepcopy(Shape)
            self._Shapes.append(New_Shape)
            if Select:
                self._Active_Shape_Index = len(self._Shapes) - 1
            self._Refresh_All()
            self._Fire_Shape_Event('draw', Index=len(self._Shapes) - 1, Old_Shape=None, New_Shape=deepcopy(New_Shape))
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shape_Add -> {E}')

    def Delete_Selected(self):
        try:
            Shape = self._Get_Active_Shape()
            if Shape is None:
                self._Set_Status('No active shape to delete')
                return self
            self._Push_Undo()
            Deleted = deepcopy(Shape)
            Index = self._Active_Shape_Index
            del self._Shapes[self._Active_Shape_Index]
            self._Active_Shape_Index = -1
            self._Refresh_All()
            self._Set_Status('Selected shape deleted')
            self._Fire_Shape_Event('delete', Index=Index, Old_Shape=Deleted, New_Shape=None)
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete_Selected -> {E}')

    def Clear_Shapes(self):
        try:
            self._Push_Undo()
            self._Shapes.clear()
            self._Active_Shape_Index = -1
            self._Drag_Mode = ''
            self._Original_Shape = None
            self._Active_Handle = ''
            self._Clear_Draft()
            self._Refresh_All()
            self._Set_Cursor('crosshair')
            self._Set_Status('Shapes cleared')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear_Shapes -> {E}')

    def Show_All(self):
        try:
            self._Push_Undo()
            for Shape in self._Shapes:
                Shape['Visible'] = True
            self._Refresh_All()
            self._Set_Status('Visibility updated for all shapes')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show_All -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if self._Stage is None:
                return False
            self._Stage.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Hide_All(self):
        try:
            self._Push_Undo()
            for Shape in self._Shapes:
                Shape['Visible'] = False
            self._Refresh_All()
            self._Set_Status('Visibility updated for all shapes')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide_All -> {E}')

    def Lock_All(self):
        try:
            self._Push_Undo()
            for Shape in self._Shapes:
                Shape['Locked'] = True
            self._Refresh_All()
            self._Set_Status('Lock state updated for all shapes')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Lock_All -> {E}')

    def Unlock_All(self):
        try:
            self._Push_Undo()
            for Shape in self._Shapes:
                Shape['Locked'] = False
            self._Refresh_All()
            self._Set_Status('Lock state updated for all shapes')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Unlock_All -> {E}')

    def Finish_Draft(self):
        try:
            self._Finish_Draft_Shape()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Finish_Draft -> {E}')

    def Cancel_Draft(self):
        try:
            self._Cancel_Draft_Shape()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Cancel_Draft -> {E}')

    def _Zoom_To_View_Center(self, Zoom_Value):
        try:
            if not self._Pan_Zoom:
                return
            Old_Zoom = float(max(self._Zoom_Min, min(self._Zoom_Max, self._Zoom)))
            New_Zoom = float(max(self._Zoom_Min, min(self._Zoom_Max, Zoom_Value)))
            View_Width = float(max(1, self._View_Width))
            View_Height = float(max(1, self._View_Height))
            Image_Width = float(max(1, self._Image_Width))
            Image_Height = float(max(1, self._Image_Height))
            Fit_Scale = min(View_Width / Image_Width, View_Height / Image_Height) if self._Aspect_Ratio else max(View_Width / Image_Width, View_Height / Image_Height)
            Old_Render_Width = Image_Width * Fit_Scale * Old_Zoom
            Old_Render_Height = Image_Height * Fit_Scale * Old_Zoom
            Old_Display_Offset_X = (View_Width - Old_Render_Width) / 2 + self._Pan_X
            Old_Display_Offset_Y = (View_Height - Old_Render_Height) / 2 + self._Pan_Y
            View_Center_X = View_Width / 2
            View_Center_Y = View_Height / 2
            Old_Scale = Fit_Scale * Old_Zoom
            New_Scale = Fit_Scale * New_Zoom
            if Old_Scale <= 0 or New_Scale <= 0:
                self._Zoom = New_Zoom
                self._Update_Transform()
                return
            Image_Center_X = (View_Center_X - Old_Display_Offset_X) / Old_Scale
            Image_Center_Y = (View_Center_Y - Old_Display_Offset_Y) / Old_Scale
            New_Render_Width = Image_Width * Fit_Scale * New_Zoom
            New_Render_Height = Image_Height * Fit_Scale * New_Zoom
            New_Base_Offset_X = (View_Width - New_Render_Width) / 2
            New_Base_Offset_Y = (View_Height - New_Render_Height) / 2
            self._Zoom = New_Zoom
            self._Pan_X = View_Center_X - Image_Center_X * New_Scale - New_Base_Offset_X
            self._Pan_Y = View_Center_Y - Image_Center_Y * New_Scale - New_Base_Offset_Y
            self._Update_Transform()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Zoom_To_View_Center -> {E}')

    def Zoom_Set(self, Value=1.0):
        try:
            self._Zoom_To_View_Center(Value)
            self._Set_Status(f'Zoom set to {round(self._Zoom, 2)}')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Zoom_Set -> {E}')

    def Zoom_In(self, Factor=None):
        try:
            if Factor is None:
                Factor = self._Zoom_Step
            self.Zoom_Set(self._Zoom * float(Factor))
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Zoom_In -> {E}')

    def Zoom_Out(self, Factor=None):
        try:
            if Factor is None:
                Factor = self._Zoom_Step
            self.Zoom_Set(self._Zoom / float(Factor))
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Zoom_Out -> {E}')

    def Reset_View(self):
        try:
            self._Zoom = 1.0
            self._Pan_X = 0.0
            self._Pan_Y = 0.0
            self._View_Dragging = False
            self._Dragging = False
            self._Update_Transform()
            self._Set_Status('View reset')
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset_View -> {E}')

    def Reset(self):
        try:
            self._Angle = 0
            self.Reset_View()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Set(self, Path):
        try:
            self._Path = Path
            if not self._Path_Initial:
                self._Path_Initial = Path
            if self._Initialized:
                self._Rebuild_Image()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')
            
    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
            if 'On_Copy' in Input:
                self._On_Copy = Input['On_Copy']
            if 'On_Cut' in Input:
                self._On_Cut = Input['On_Cut']
            if 'On_Paste' in Input:
                self._On_Paste = Input['On_Paste']
            if 'On_Undo' in Input:
                self._On_Undo = Input['On_Undo']
            if 'On_Redo' in Input:
                self._On_Redo = Input['On_Redo']
            if 'On_Import' in Input:
                self._On_Import = Input['On_Import']
            if 'On_Export' in Input:
                self._On_Export = Input['On_Export']
            if 'On_Delete' in Input:
                self._On_Delete = Input['On_Delete']
            if 'On_Select' in Input:
                self._On_Select = Input['On_Select']
            if 'On_Draw' in Input:
                self._On_Draw = Input['On_Draw']
            if 'On_Move' in Input:
                self._On_Move = Input['On_Move']
            if 'On_Resize' in Input:
                self._On_Resize = Input['On_Resize']
            if 'On_Rotate' in Input:
                self._On_Rotate = Input['On_Rotate']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
            if self._Widget is not None:
                Skip = ['On_Show', 'On_Hide', 'On_Animate', 'On_Copy', 'On_Cut', 'On_Paste', 'On_Undo', 'On_Redo', 'On_Import', 'On_Export', 'On_Delete', 'On_Select', 'On_Draw', 'On_Move', 'On_Resize', 'On_Rotate', 'On_Change']
                Forward = {K: V for K, V in Input.items() if K not in Skip}
                if len(Forward) > 0:
                    from .N_Custom import Event_Bind
                    Event_Bind(self._Widget, **Forward)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config(self, **Input):
        try:
            Result = super().Config(**Input)
            if self._Initialized and 'Active_Border_Color' in Input:
                self._Refresh_Style_Controls()
                self._Render_Shapes()
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')