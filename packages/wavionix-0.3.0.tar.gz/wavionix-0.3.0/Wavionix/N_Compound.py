from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Compound:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Compound'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': None,
                    'Animate_Left': 0,
                    'Animate_Top': 0,
                    'Animate_Width': 0,
                    'Animate_Height': 0,
                    'Animate_Time': 1.0,
                    'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Value': '',
                    'Path': False,
                    'Rotate': 0,
                    'Transparent': True,
                    'Compound': 'center',
                    'Aspect_Ratio': True,
                    'Gap': 8,
                    'Padding': 5,
                    'Margin': 5,
                    'Image_Width': None,
                    'Image_Height': None,
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Canvas = None
                self._Frame = None
                self._Inner = None
                self._Image = None
                self._Label = None
                self._Name = False
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = None
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Value = ''
                self._Path = False
                self._Rotate = 0
                self._Transparent = True
                self._Compound = 'center'
                self._Aspect_Ratio = True
                self._Gap = 8
                self._Padding = 8
                self._Margin = 0
                self._Image_Width = None
                self._Image_Height = None
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._Image_Box = None
                self._On_Show = False
                self._On_Hide = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Compound[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Compound[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Current_Background(self, Hover=False):
        if Hover and self._Hover_Background:
            return self._Hover_Background
        return self._Background

    def _Current_Foreground(self, Hover=False):
        if Hover and self._Hover_Foreground:
            return self._Hover_Foreground
        return self._Foreground

    def _Current_Border_Color(self, Hover=False):
        if Hover and self._Hover_Border_Color:
            return self._Hover_Border_Color
        return self._Border_Color

    def _Has_Image(self):
        try:
            return self._Path not in [False, None, '']
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Has_Image -> {E}')
            return False

    def _Compound_Mode(self):
        try:
            Value = str(self._Compound).strip().lower()
            if Value not in ['left', 'right', 'top', 'bottom', 'center', 'none']:
                Value = 'center'
            return Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Compound_Mode -> {E}')
            return 'center'

    def _Build_Frame_Style(self, Hover=False):
        Box = self._Animate_Current_Box()
        Transition = 'all 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display or self._Animating else "none"}')
        Style.append('overflow: hidden')
        Style.append(f'background: {self._Current_Background(Hover)}')
        Style.append(f'color: {self._Current_Foreground(Hover)}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Current_Border_Color(Hover)}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "8px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append(f'transition: {Transition}')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if Box['Width'] is not None:
            Style.append(f'width: {self._Unit(Box["Width"])}')
        if Box['Height'] is not None:
            Style.append(f'height: {self._Unit(Box["Height"])}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Image_Width_Value(self):
        try:
            return self._Unit(self._Image_Width) if self._Image_Width is not None else None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Image_Width_Value -> {E}')
            return None

    def _Image_Height_Value(self):
        try:
            return self._Unit(self._Image_Height) if self._Image_Height is not None else None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Image_Height_Value -> {E}')
            return None

    def _Build_Inner_Style(self):
        Mode = self._Compound_Mode()
        Style = []
        Style.append('width: 100%')
        Style.append('height: 100%')
        Style.append('box-sizing: border-box')
        Style.append('position: relative')
        Style.append('overflow: hidden')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        if Mode in ['left', 'right']:
            Style.append('display: flex')
            if Mode == 'left':
                Style.append('flex-direction: row')
            else:
                Style.append('flex-direction: row-reverse')
            Style.append('align-items: stretch')
            Style.append('justify-content: stretch')
            Style.append(f'gap: {self._Unit(self._Gap) or "8px"}')
        elif Mode in ['top', 'bottom']:
            Style.append('display: flex')
            if Mode == 'top':
                Style.append('flex-direction: column')
            else:
                Style.append('flex-direction: column-reverse')
            Style.append('align-items: stretch')
            Style.append('justify-content: stretch')
            Style.append(f'gap: {self._Unit(self._Gap) or "8px"}')
        else:
            Style.append('display: grid')
            Style.append('grid-template-columns: 1fr')
            Style.append('grid-template-rows: 1fr')
            Style.append('align-items: stretch')
            Style.append('justify-items: stretch')
        return '; '.join(Style)

    def _Build_Image_Box_Style(self):
        Mode = self._Compound_Mode()
        Has_Image = self._Has_Image()
        Image_Width = self._Image_Width_Value()
        Image_Height = self._Image_Height_Value()
        Style = []
        Style.append('box-sizing: border-box')
        Style.append('display: flex' if Has_Image else 'display: none')
        Style.append('align-items: center')
        Style.append('justify-content: center')
        Style.append('overflow: hidden')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        Style.append('position: relative')
        if Mode in ['left', 'right']:
            Style.append('height: 100%')
            Style.append('aspect-ratio: 1 / 1')
            Style.append('flex: 0 0 auto')
            if Image_Width is not None:
                Style.append(f'width: {Image_Width}')
                Style.append(f'height: {Image_Width}')
            elif Image_Height is not None:
                Style.append(f'width: {Image_Height}')
                Style.append(f'height: {Image_Height}')
            else:
                Style.append('width: auto')
        elif Mode in ['top', 'bottom']:
            Style.append('width: 100%')
            Style.append('aspect-ratio: 1 / 1')
            Style.append('flex: 0 0 auto')
            if Image_Height is not None:
                Style.append(f'height: {Image_Height}')
            elif Image_Width is not None:
                Style.append(f'height: {Image_Width}')
            else:
                Style.append('height: 40%')
                Style.append('max-height: 50%')
        else:
            Style.append('grid-area: 1 / 1')
            Style.append('z-index: 1')
            Style.append('width: 100%')
            Style.append('height: 100%')
        return '; '.join(Style)

    def _Build_Image_Style(self):
        Mode = self._Compound_Mode()
        Style = []
        Style.append('display: block')
        Style.append('box-sizing: border-box')
        Style.append('object-fit: contain' if self._Aspect_Ratio else 'object-fit: fill')
        Style.append(f'transform: rotate({self._Rotate}deg)')
        if Mode in ['left', 'right', 'top', 'bottom']:
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('max-width: 100%')
            Style.append('max-height: 100%')
        else:
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('max-width: 100%')
            Style.append('max-height: 100%')
        return '; '.join(Style)

    def _Build_Canvas_Style(self):
        Mode = self._Compound_Mode()
        Has_Image = self._Has_Image()
        Style = []
        Style.append('box-sizing: border-box')
        Style.append('position: relative')
        Style.append('overflow: hidden')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        if Mode in ['left', 'right']:
            Style.append('flex: 1 1 auto')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('display: flex')
            Style.append('align-items: center')
            Style.append('justify-content: center')
        elif Mode in ['top', 'bottom']:
            Style.append('flex: 1 1 auto')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('display: flex')
            Style.append('align-items: center')
            Style.append('justify-content: center')
        else:
            Style.append('grid-area: 1 / 1')
            Style.append('z-index: 2')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('display: flex')
            Style.append('align-items: center')
            Style.append('justify-content: center')
        if Mode == 'none' and Has_Image:
            Style.append('display: none')
        return '; '.join(Style)

    def _Build_Label_Style(self):
        Mode = self._Compound_Mode()
        Has_Image = self._Has_Image()
        Has_Text = str(self._Value) != ''
        Show_Text = Has_Text and not (Mode == 'none' and Has_Image)
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if Show_Text else "none"}')
        Style.append('align-items: center')
        Style.append('justify-content: center')
        Style.append('text-align: center')
        Style.append('pointer-events: none')
        Style.append('padding: 4px 8px')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "12px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append('white-space: pre-wrap')
        Style.append('word-break: break-word')
        Style.append('overflow: hidden')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        if Mode in ['left', 'right', 'top', 'bottom']:
            Style.append('position: relative')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('flex: 1 1 auto')
        else:
            Style.append('position: absolute')
            Style.append('left: 0')
            Style.append('top: 0')
            Style.append('width: 100%')
            Style.append('height: 100%')
            Style.append('z-index: 3')
        return '; '.join(Style)

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self, Hover=False):
        try:
            if self._Frame is None or self._Inner is None or self._Canvas is None or self._Label is None:
                return
            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()
            if hasattr(self._Inner, '_style'):
                self._Inner._style.clear()
            if hasattr(self._Inner, '_classes'):
                self._Inner._classes.clear()
            if self._Image_Box is not None:
                if hasattr(self._Image_Box, '_style'):
                    self._Image_Box._style.clear()
                if hasattr(self._Image_Box, '_classes'):
                    self._Image_Box._classes.clear()
            if hasattr(self._Canvas, '_style'):
                self._Canvas._style.clear()
            if hasattr(self._Canvas, '_classes'):
                self._Canvas._classes.clear()
            if hasattr(self._Label, '_style'):
                self._Label._style.clear()
            if hasattr(self._Label, '_classes'):
                self._Label._classes.clear()
            if self._Image is not None:
                if hasattr(self._Image, '_style'):
                    self._Image._style.clear()
                if hasattr(self._Image, '_classes'):
                    self._Image._classes.clear()
            self._Frame.style(self._Build_Frame_Style(Hover))
            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))
            self._Inner.style(self._Build_Inner_Style())
            if self._Image_Box is not None:
                self._Image_Box.style(self._Build_Image_Box_Style())
            self._Canvas.style(self._Build_Canvas_Style())
            self._Label.set_text(str(self._Value))
            self._Label.style(self._Build_Label_Style())
            self._Label.update()
            if self._Image is not None:
                self._Image.style(self._Build_Image_Style())
                self._Image.props(f'fit={"contain" if self._Aspect_Ratio else "fill"} no-spinner')
                if self._Path not in [False, None, '']:
                    self._Image.set_source(self._Path)
                    self._Image.set_visibility(True)
                else:
                    self._Image.set_visibility(False)
                self._Image.update()
            self._Frame.update()
            self._Inner.update()
            self._Canvas.update()
            if self._Image_Box is not None:
                self._Image_Box.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def _Hover_In(self):
        try:
            self._Apply(Hover=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Apply(Hover=False)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Inner = None
                self._Canvas = None
                self._Image_Box = None
                self._Image = None
                self._Label = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Clear(self):
        try:
            self._Path = False
            self._Value = ''
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Set(self, Value='', Path=''):
        try:
            self._Value = '' if Value is None else str(Value)
            if Path not in ['', None, False]:
                self._Path = Path
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Get(self):
        try:
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Compound(self, Value=None):
        try:
            if Value is not None:
                self._Compound = Value
                self._Apply()
            return self._Compound
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Compound -> {E}')

    def Refresh(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Canvas if self._Canvas is not None else self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')

                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Inner = ui.element('div')
                            with self._Inner:
                                self._Image_Box = ui.element('div')
                                with self._Image_Box:
                                    self._Image = ui.image(self._Path if self._Path else '')
                                    self._Image.props('fit=scale-down no-spinner')

                                self._Canvas = ui.element('div')
                                with self._Canvas:
                                    self._Label = ui.label(self._Value)
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')

                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Inner = ui.element('div')
                        with self._Inner:
                            self._Image_Box = ui.element('div')
                            with self._Image_Box:
                                self._Image = ui.image(self._Path if self._Path else '')
                                self._Image.props('fit=scale-down no-spinner')

                            self._Canvas = ui.element('div')
                            with self._Canvas:
                                self._Label = ui.label(self._Value)

                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if self._Path in [False, None, '']:
                    self._Image.set_visibility(False)

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')