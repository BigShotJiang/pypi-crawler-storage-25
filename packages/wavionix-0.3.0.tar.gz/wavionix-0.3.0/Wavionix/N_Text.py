from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Text:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Text'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': 160,
                    'Animate_Left': 0,
                    'Animate_Top': 0,
                    'Animate_Width': 0,
                    'Animate_Height': 0,
                    'Animate_Time': 1.0,
                    'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Placeholder': '',
                    'Value': '',
                    'Text_Margin': 8,
                    'Padding': 0,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Textarea = None
                self._Name = False
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = 160
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Placeholder = ''
                self._Value = ''
                self._Text_Margin = 8
                self._Padding = 0
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Text[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Text[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Text_Margin_Value(self):
        try:
            Value = self._Text_Margin
            if Value in [False, None, '']:
                Value = self._Padding
            if isinstance(Value, str):
                Text = Value.strip()
                if ' ' in Text:
                    Text = Text.split()[0]
                if Text.endswith('%'):
                    Number = float(Text[:-1])
                    return f'min({Number}cqw, {Number}cqh)'
                return Text
            return self._Unit(Value) or '0px'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Text_Margin_Value -> {E}')
            return '0px'

    def _Build_Frame_Style(self):
        Box = self._Animate_Current_Box()
        Transition = 'all 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"block" if self._Display or self._Animating else "none"}')
        Style.append('position: relative')
        Style.append('container-type: size')
        Style.append(f'background: {self._Background}')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append('padding: 0')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('overflow: hidden')
        Style.append(f'transition: {Transition}')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if Box['Width'] is not None:
            Style.append(f'width: {self._Unit(Box["Width"])}')
        if Box['Height'] is not None:
            Style.append(f'height: {self._Unit(Box["Height"])}')
            Style.append(f'min-height: {self._Unit(Box["Height"])}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('opacity: 0.55')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _CSS_Class_Name(self):
        try:
            if not hasattr(self, '_CSS_Class') or not self._CSS_Class:
                self._CSS_Class = f'wavionix-text-{id(self)}'
            return self._CSS_Class
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Class_Name -> {E}')
            return f'wavionix-text-{id(self)}'

    def _Apply_CSS(self):
        try:
            CSS_Class = self._CSS_Class_Name()
            CSS = f'.{CSS_Class}.q-field {{ box-sizing: border-box !important; }} .{CSS_Class} .q-field__inner {{ height: 100% !important; min-height: 100% !important; padding: 0 !important; }} .{CSS_Class} .q-field__control {{ height: 100% !important; min-height: 100% !important; padding: 0 !important; background: transparent !important; }} .{CSS_Class} .q-field__control:before {{ display: none !important; }} .{CSS_Class} .q-field__control:after {{ display: none !important; }} .{CSS_Class} .q-field__native {{ height: 100% !important; min-height: 100% !important; padding: 0 !important; margin: 0 !important; line-height: 1.4 !important; }} .{CSS_Class} textarea {{ height: 100% !important; min-height: 100% !important; padding: 0 !important; margin: 0 !important; overflow-y: auto !important; resize: none !important; }}'
            Safe_CSS = CSS.replace('`', '')
            Safe_ID = f'{CSS_Class}-style'
            ui.add_head_html(f'''<script>
                (() => {{
                let Style_Tag = document.getElementById('{Safe_ID}');
                if (!Style_Tag) {{
                Style_Tag = document.createElement('style');
                Style_Tag.id = '{Safe_ID}';
                document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_CSS}`;
                }})();
                </script>''')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_CSS -> {E}')
            return False

    def _Build_Textarea_Props(self):
        Props = []
        Props.append('borderless')
        if self._Disable:
            Props.append('disable')
        if self._Placeholder:
            Props.append(f'placeholder="{self._Placeholder}"')
        Props.append(
            f'input-style="'
            f'color:{self._Foreground};'
            f'font-size:{self._Unit(self._Font_Size) or "12px"};'
            f'font-weight:{self._Font_Weight};'
            f'font-family:{self._Font_Family};'
            f'line-height:1.4;'
            f'height:100%;'
            f'min-height:100%;'
            f'padding:0;'
            f'margin:0;'
            f'overflow-y:auto;'
            f'resize:none;'
            f'"'
        )
        return ' '.join(Props)

    def _Build_Textarea_Style(self):
        Gap = self._Text_Margin_Value()
        Style = []
        Style.append('box-sizing: border-box')
        Style.append('position: absolute')
        Style.append(f'left: {Gap}')
        Style.append(f'right: {Gap}')
        Style.append(f'top: {Gap}')
        Style.append(f'bottom: {Gap}')
        Style.append('width: auto')
        Style.append('height: auto')
        Style.append('min-height: 0')
        Style.append('background: transparent')
        Style.append(f'color: {self._Foreground}')
        Style.append('padding: 0')
        Style.append('margin: 0')
        Style.append('overflow: hidden')
        return '; '.join(Style)

    def _Handle_Change(self, Event):
        try:
            self._Value = Event.value
            if self._On_Change:
                self._On_Change(Event)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Change -> {E}')

    def _Hover_In(self):
        try:
            if self._Disable or self._Frame is None:
                return
            Background = self._Hover_Background if self._Hover_Background else self._Background
            Foreground = self._Hover_Foreground if self._Hover_Foreground else self._Foreground
            Border = self._Hover_Border_Color if self._Hover_Border_Color else self._Border_Color
            self._Frame.style(self._Build_Frame_Style() + f'; background: {Background}; color: {Foreground}; border-color: {Border}')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
                self._Text_Margin = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Textarea is None:
                return
            self._Apply_CSS()
            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()
            if hasattr(self._Textarea, '_style'):
                self._Textarea._style.clear()
            if hasattr(self._Textarea, '_classes'):
                self._Textarea._classes.clear()
            self._Frame.style(self._Build_Frame_Style())
            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))
            self._Textarea.classes(self._CSS_Class_Name())
            self._Textarea.value = self._Value
            self._Textarea.style(self._Build_Textarea_Style())
            self._Textarea.props(self._Build_Textarea_Props())
            self._Textarea.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance._Value = self._Value
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Textarea = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if self._Disable:
                return False
            if self._Textarea is not None:
                self._Textarea.run_method('focus')
                return True
            if self._Frame is not None:
                self._Frame.run_method('focus')
                return True
            return False
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Get(self):
        try:
            if self._Textarea is not None:
                self._Value = self._Textarea.value
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            self._Value = '' if Value is None else str(Value)
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Add(self, Value):
        try:
            Value = '' if Value is None else str(Value)
            self._Value = f'{self._Value}{Value}'
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add -> {E}')

    def Clear(self):
        try:
            self._Value = ''
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Widget(self):
        try:
            return self._Textarea
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Textarea is not None and len(Input) > 0:
                Event_Bind(self._Textarea, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Padding' in Input and 'Text_Margin' not in Input:
                self._Text_Margin = Input['Padding']
                Run = True
            if 'Value' in Input:
                self._Value = '' if Input['Value'] is None else str(Input['Value'])
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Textarea = ui.textarea(
                                value=self._Value,
                                on_change=lambda E: self._Handle_Change(E),
                            )
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Textarea = ui.textarea(
                            value=self._Value,
                            on_change=lambda E: self._Handle_Change(E),
                        )

                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')