import os
import time
import datetime
import json
import uuid
import base64
import mimetypes
import logging
from nicegui import ui, app
from fastapi.responses import Response, FileResponse, JSONResponse
from .N_Custom import Event_Bind


class GUI():

    _Instance = None

    def __new__(Class, *Args, **KArgs):
        if Class._Instance is None:
            Class._Instance = super().__new__(Class)
        return Class._Instance

    def __init__(self, *Args, **KArgs):
        if hasattr(self, '_Initialized'):
            if KArgs:
                self.Config(**KArgs)
            return
        self._Config = {
            'Error_Display': True,
            'Error_Log': False,
            'Title': 'Nucleon Wavionix',
            'Icon': '',
            'IP': '0.0.0.0',
            'Port': 8080,
            'Reload': False,
            'Show': True,
            'Background': '#F0F0F0',
            'Foreground': '#111111',
            'Width': '100%',
            'Height': '100%',
            'Min_Height': '100vh',
            'Max_Width': 'none',
            'Padding': '0',
            'Gap': '0',
            'Classes': '',
            'Style': '',
            'Body_Classes': 'w-full h-full',
            'Body_Style': '',
            'Visible': True,
            'Full_Screen': False,
            'Scroll': True,
            'Scroll_X': None,
            'Scroll_Y': None,
            'Welcome_Message': False,
            'NiceGUI_Log_Level': 'error',
        }
        self._Initialized = True
        self._Type = 'GUI'
        self._Error_Display = self._Config['Error_Display']
        self._Error_Log = self._Config['Error_Log']
        self._Log_Folder = './Log'
        self._Log_File = 'Wavionix_Error.log'
        self._Error = []
        self._Title = self._Config['Title']
        self._Icon = self._Config['Icon']
        self._Icon_Source = ''
        self._IP = self._Config['IP']
        self._Port = self._Config['Port']
        self._Reload = self._Config['Reload']
        self._Show = self._Config['Show']
        self._Background = self._Config['Background']
        self._Foreground = self._Config['Foreground']
        self._Width = self._Config['Width']
        self._Height = self._Config['Height']
        self._Min_Height = self._Config['Min_Height']
        self._Max_Width = self._Config['Max_Width']
        self._Padding = self._Config['Padding']
        self._Gap = self._Config['Gap']
        self._Classes = self._Config['Classes']
        self._Style = self._Config['Style']
        self._Body_Classes = self._Config['Body_Classes']
        self._Body_Style = self._Config['Body_Style']
        self._Visible = self._Config['Visible']
        self._Full_Screen = self._Config['Full_Screen']
        self._Scroll = self._Config['Scroll']
        self._Scroll_X = self._Config['Scroll_X']
        self._Scroll_Y = self._Config['Scroll_Y']
        self._Widget = []
        self._Popup = []
        self._Body = None
        self._Binding = {}
        self._Page_Function = None
        self._Page_Args = []
        self._Page_KArgs = {}
        self._Page_Route = '/'
        self._Page_Registered = False
        self._Start_Function = None
        self._Start_Args = []
        self._Start_KArgs = {}
        self._After_Queue = []
        self._Ready_Function = []
        self._Welcome_Message = self._Config['Welcome_Message']
        self._NiceGUI_Log_Level = self._Config['NiceGUI_Log_Level']
        self._Loading_Bar = True
        self._Created = False
        
        if KArgs:
            self.Config(**KArgs)

    def __str__(self):
        return 'GUI[' + str(self._Title) + ']'

    def __repr__(self):
        return 'GUI[' + str(self._Title) + ']'

    def Error(self, E):
        Error_Time = int(time.time())
        self._Error.append([E, Error_Time])

        if len(self._Error) > 1000:
            self._Error.pop(0)

        if self._Error_Display:
            print(E)

        if self._Error_Log:
            if not os.path.exists(self._Log_Folder):
                os.makedirs(self._Log_Folder)

            Log_Path = os.path.join(self._Log_Folder, self._Log_File)
            Date_Str = datetime.datetime.fromtimestamp(Error_Time).strftime('%Y-%m-%d %H:%M:%S')
            Line = f'{Date_Str} - {E}\n'

            try:
                with open(Log_Path, 'a', encoding='utf-8') as File:
                    File.write(Line)
            except Exception as Error_Value:
                print(f'Wavionix -> Critical Logging Error: {Error_Value}')

    def Nothing(self):
        return False
        
    def Page(self, Function=None, *Args, **KArgs):
        try:
            Route = KArgs.pop('Route', '/')
            self._Page_Function = Function
            self._Page_Args = Args
            self._Page_KArgs = KArgs
            self._Page_Route = Route
            self._Page_Registered = False
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Page -> {E}')

    def Loading_Bar(self, Value=None):
        try:
            if Value is None:
                return self._Loading_Bar
            Css = '' if self._Loading_Bar else '.q-loading-bar{display:none!important;}'
            Safe_Css = Css.replace('`', '')
            ui.add_head_html(f'''<script>
                (() => {{
                let Style_Tag = document.getElementById('nucleon-loading-bar-style');
                if (!Style_Tag) {{
                Style_Tag = document.createElement('style');
                Style_Tag.id = 'nucleon-loading-bar-style';
                document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_Css}`;
                }})();
                </script>''', shared=True)
            self._Loading_Bar = bool(Value)
            return self._Loading_Bar
        except Exception as E:
            self.Error(f'{self._Type} -> Loading_Bar -> {E}')
            return False

    def _Flush_After(self):
        try:
            Queue = list(self._After_Queue)
            self._After_Queue = []
            for Delay, Function in Queue:
                ui.timer(float(Delay) / 1000.0, Function, once=True)
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> _Flush_After -> {E}')
            
    def Ready(self, Function=None):
        try:
            if Function is not None:
                self._Ready_Function.append(Function)
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Ready -> {E}')

    def _Run_Ready(self):
        try:
            Ready_Function = list(self._Ready_Function)
            for Function in Ready_Function:
                Function()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> _Run_Ready -> {E}')

    def _Build_Page(self):
        try:
            self._Body = None
            self._Created = False
            self._Widget = []
            self._Popup = []
            self._Icon_Source = ''
            Result = None
            if self._Page_Function is not None:
                Result = self._Page_Function(*self._Page_Args, **self._Page_KArgs)
            self._Flush_After()
            self._Run_Ready()
            return Result
        except Exception as E:
            self.Error(f'{self._Type} -> _Build_Page -> {E}')
            
    def _Root_Style(self):
        try:
            Style = []
            Style.append('position: relative')
            Style.append(f'width: {self._Width}')
            Style.append(f'height: {self._Height}')
            Style.append(f'min-height: {self._Min_Height}')
            Style.append(f'max-width: {self._Max_Width}')
            Style.append(f'padding: {self._Padding}')
            Style.append(f'gap: {self._Gap}')
            Style.append(f'background: {self._Background}')
            Style.append(f'color: {self._Foreground}')
            Style.append('box-sizing: border-box')
            Style.append('display: flex' if self._Visible else 'display: none')
            Style.append('flex-direction: column')
            Style.append('align-items: stretch')
            Overflow = self._Scroll_Mode(self._Scroll, 'auto')
            Style.append(f'overflow: {Overflow}')
            if self._Scroll_X is not None:
                Style.append(f'overflow-x: {self._Scroll_Mode(self._Scroll_X, Overflow)}')
            if self._Scroll_Y is not None:
                Style.append(f'overflow-y: {self._Scroll_Mode(self._Scroll_Y, Overflow)}')
            if self._Style:
                Style.append(self._Style)
            return '; '.join(Style)
        except Exception as E:
            self.Error(f'{self._Type} -> _Root_Style -> {E}')

    def _Scroll_Mode(self, Value, Default='auto'):
        try:
            if Value is None:
                return Default
            if Value is True:
                return 'auto'
            if Value is False:
                return 'hidden'
            return str(Value)
        except Exception as E:
            self.Error(f'{self._Type} -> _Scroll_Mode -> {E}')
            return Default

    def _Page_Scroll_CSS(self):
        try:
            Overflow = self._Scroll_Mode(self._Scroll, 'auto')
            Overflow_X = None if self._Scroll_X is None else self._Scroll_Mode(self._Scroll_X, Overflow)
            Overflow_Y = None if self._Scroll_Y is None else self._Scroll_Mode(self._Scroll_Y, Overflow)
            Style = []
            Style.append('html, body {')
            Style.append('margin: 0 !important;')
            Style.append('padding: 0 !important;')
            Style.append('width: 100% !important;')
            Style.append('height: 100% !important;')
            Style.append(f'overflow: {Overflow} !important;')
            if Overflow_X is not None:
                Style.append(f'overflow-x: {Overflow_X} !important;')
            if Overflow_Y is not None:
                Style.append(f'overflow-y: {Overflow_Y} !important;')
            Style.append('}')
            Style.append('#app, .nicegui-content, .nicegui-layout, .q-page-container, .q-page {')
            Style.append('margin: 0 !important;')
            Style.append('padding: 0 !important;')
            Style.append('width: 100% !important;')
            Style.append('max-width: none !important;')
            Style.append('height: 100% !important;')
            Style.append('min-height: 100% !important;')
            Style.append(f'overflow: {Overflow} !important;')
            if Overflow_X is not None:
                Style.append(f'overflow-x: {Overflow_X} !important;')
            if Overflow_Y is not None:
                Style.append(f'overflow-y: {Overflow_Y} !important;')
            Style.append('}')
            Style.append('.q-pa-md, .q-px-md, .q-py-md, .q-ma-md, .q-mx-md, .q-my-md {')
            Style.append('padding: 0 !important;')
            Style.append('margin: 0 !important;')
            Style.append('}')
            return '\n'.join(Style)
        except Exception as E:
            self.Error(f'{self._Type} -> _Page_Scroll_CSS -> {E}')
            return ''

    def _Apply_Page_Scroll(self):
        try:
            Css = self._Page_Scroll_CSS()
            if not Css:
                return
            Safe_Css = Css.replace('`', '')
            ui.add_head_html(f'''<script>
                (() => {{
                let Style_Tag = document.getElementById('wavionix-page-scroll-style');
                if (!Style_Tag) {{
                Style_Tag = document.createElement('style');
                Style_Tag.id = 'wavionix-page-scroll-style';
                document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_Css}`;
                }})();
                </script>''', shared=True)
        except Exception as E:
            self.Error(f'{self._Type} -> _Apply_Page_Scroll -> {E}')

    def _Resolve_Icon(self, Value=None):
        try:
            if Value is None:
                Value = self._Icon
            if Value is False or Value is None or Value == '':
                return ['', '']
            if isinstance(Value, os.PathLike):
                Value = os.fspath(Value)
            if isinstance(Value, bytes):
                Mime = 'image/png'
                Encoded = base64.b64encode(Value).decode('utf-8')
                return [f'data:{Mime};base64,{Encoded}', Mime]
            if isinstance(Value, str):
                if Value.startswith('data:'):
                    Mime = Value.split(';', 1)[0].replace('data:', '')
                    return [Value, Mime]
                if Value.startswith('http://') or Value.startswith('https://'):
                    Mime = mimetypes.guess_type(Value.split('?', 1)[0])[0] or 'image/x-icon'
                    return [Value, Mime]
                if os.path.exists(Value):
                    Mime = mimetypes.guess_type(Value)[0] or 'image/x-icon'
                    with open(Value, 'rb') as File:
                        Data = File.read()
                    Encoded = base64.b64encode(Data).decode('utf-8')
                    return [f'data:{Mime};base64,{Encoded}', Mime]
                Mime = mimetypes.guess_type(Value)[0] or 'image/x-icon'
                return [Value, Mime]
            return ['', '']
        except Exception as E:
            self.Error(f'{self._Type} -> _Resolve_Icon -> {E}')
            return ['', '']

    def _Apply_Icon(self):
        try:
            Icon_Source, Icon_Mime = self._Resolve_Icon(self._Icon)
            if not Icon_Source:
                return
            if self._Icon_Source == Icon_Source:
                return
            self._Icon_Source = Icon_Source
            Safe_Source = Icon_Source.replace('`', '').replace('\\', '\\\\')
            Safe_Mime = Icon_Mime.replace('`', '')
            ui.add_head_html(f'''<script>
                (() => {{
                let Icon_Link = document.getElementById('wavionix-icon-link');
                if (!Icon_Link) {{
                Icon_Link = document.createElement('link');
                Icon_Link.id = 'wavionix-icon-link';
                Icon_Link.rel = 'icon';
                document.head.appendChild(Icon_Link);
                }}
                Icon_Link.href = `{Safe_Source}`;
                Icon_Link.type = `{Safe_Mime}`;
                }})();
                </script>''', shared=True)
        except Exception as E:
            self.Error(f'{self._Type} -> _Apply_Icon -> {E}')
            
    def _Ensure_File_System(self):
        try:
            if not hasattr(self, '_File_Picker'):
                self._File_Picker = {}
            if not hasattr(self, '_Upload_Target'):
                self._Upload_Target = {}
            if not hasattr(self, '_Upload_Route_Registered'):
                self._Upload_Route_Registered = False
            if self._Upload_Route_Registered:
                return self
            @app.post('/_nucleon_upload/{Picker_Id}')
            async def _Nucleon_Upload_Route(Picker_Id: str, Request: Request):
                try:
                    Target = self._Upload_Target.get(Picker_Id, '')
                    Saved = []
                    async with Request.form() as Form:
                        for Key, Upload_File in Form.items():
                            if not hasattr(Upload_File, 'filename'):
                                continue
                            Name = self._Safe_Upload_Name(Upload_File.filename)
                            Path = ''
                            Size = 0
                            if Target:
                                Path = os.path.join(Target, Name)
                                Folder = os.path.dirname(Path)
                                if Folder:
                                    os.makedirs(Folder, exist_ok=True)
                                with open(Path, 'wb') as File:
                                    while True:
                                        Chunk = await Upload_File.read(1024 * 1024)
                                        if not Chunk:
                                            break
                                        Size += len(Chunk)
                                        File.write(Chunk)
                            else:
                                while True:
                                    Chunk = await Upload_File.read(1024 * 1024)
                                    if not Chunk:
                                        break
                                    Size += len(Chunk)
                            Saved.append({'Name': Name, 'Path': Path, 'Size': Size, 'Type': getattr(Upload_File, 'content_type', '')})
                    return {'Status': 'Done', 'Files': Saved}
                except Exception as E:
                    self.Error(f'{self._Type} -> _Nucleon_Upload_Route -> {E}')
                    return {'Status': 'Error', 'Error': str(E), 'Files': []}
            self._Upload_Route_Registered = True
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> _Ensure_File_System -> {E}')
            return self

    def _Safe_Upload_Name(self, Name):
        try:
            Name = str(Name or 'File').replace('\\', '/').replace(':', '')
            Part = []
            for Each in Name.split('/'):
                Each = Each.strip()
                if Each not in ['', '.', '..']:
                    Part.append(Each)
            if not Part:
                return 'File'
            return '/'.join(Part)
        except Exception as E:
            self.Error(f'{self._Type} -> _Safe_Upload_Name -> {E}')
            return 'File'

    async def _Maybe_Call(self, Function, *Args, **KArgs):
        try:
            if Function is None:
                return None
            Result = Function(*Args, **KArgs)
            if hasattr(Result, '__await__'):
                return await Result
            return Result
        except Exception as E:
            self.Error(f'{self._Type} -> _Maybe_Call -> {E}')

    def _Register_File_Data(self, Picker_Id, Data):
        try:
            self._File_Picker[Picker_Id] = Data
            for Item in Data.get('Files', []):
                Path = str(Item.get('Path', ''))
                Fake_Path = str(Item.get('Fake_Path', ''))
                Relative_Path = str(Item.get('Relative_Path', ''))
                if Path:
                    self._File_Picker[Path] = Data
                if Fake_Path:
                    self._File_Picker[Fake_Path] = Data
                if Relative_Path:
                    self._File_Picker[Relative_Path] = Data
            return Data
        except Exception as E:
            self.Error(f'{self._Type} -> _Register_File_Data -> {E}')
            return Data

    def _Resolve_File_Data(self, Input=None):
        try:
            if isinstance(Input, dict):
                if 'Files' in Input and 'Id' in Input:
                    return Input
                if 'Id' in Input:
                    return self._File_Picker.get(str(Input['Id']), Input)
            if isinstance(Input, (list, tuple)) and Input:
                return self._Resolve_File_Data(Input[0])
            if Input is None:
                return {}
            return self._File_Picker.get(str(Input), {})
        except Exception as E:
            self.Error(f'{self._Type} -> _Resolve_File_Data -> {E}')
            return {}

    def _Run_File_Picker(self, Picker_Id, Select_Event, Multiple=False, Accept='', Folder=False):
        try:
            Picker_Value = json.dumps(Picker_Id)
            Event_Value = json.dumps(Select_Event)
            Accept_Value = json.dumps(str(Accept or ''))
            Multiple_Value = 'true' if Multiple or Folder else 'false'
            Folder_Value = 'true' if Folder else 'false'
            Script = f'''
                (() => {{
                    if (!window.Nucleon_File_Pickers) window.Nucleon_File_Pickers = {{}};
                    const Picker_Id = {Picker_Value};
                    const Select_Event = {Event_Value};
                    const Input = document.createElement('input');
                    Input.type = 'file';
                    Input.multiple = {Multiple_Value};
                    Input.accept = {Accept_Value};
                    Input.style.position = 'fixed';
                    Input.style.left = '-10000px';
                    Input.style.top = '-10000px';
                    Input.style.opacity = '0';
                    if ({Folder_Value}) {{
                        Input.setAttribute('webkitdirectory', '');
                        Input.setAttribute('directory', '');
                        Input.setAttribute('multiple', '');
                    }}
                    Input.onchange = () => {{
                        const Files = Array.from(Input.files || []);
                        const Items = Files.map((File, Index) => {{
                            const Relative_Path = File.webkitRelativePath || '';
                            const Fake_Path = 'C:\\\\fakepath\\\\' + (File.name || '');
                            const Path = Relative_Path || Fake_Path;
                            return {{
                                Id: Picker_Id,
                                Index: Index,
                                Name: File.name || '',
                                Path: Path,
                                Fake_Path: Fake_Path,
                                Relative_Path: Relative_Path,
                                Type: File.type || '',
                                Size: File.size || 0,
                                Last_Modified: File.lastModified || 0
                            }};
                        }});
                        const Total_Size = Items.reduce((Total, File) => Total + File.Size, 0);
                        window.Nucleon_File_Pickers[Picker_Id] = {{
                            Input: Input,
                            Files: Files,
                            Metadata: Items
                        }};
                        emitEvent(Select_Event, {{
                            Id: Picker_Id,
                            Files: Items,
                            Count: Items.length,
                            Total_Size: Total_Size
                        }});
                    }};
                    document.body.appendChild(Input);
                    Input.click();
                }})();
            '''
            ui.run_javascript(Script)
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> _Run_File_Picker -> {E}')
            return False

    def _Run_Upload(self, Picker_Id, Progress_Event):
        try:
            Picker_Value = json.dumps(Picker_Id)
            Event_Value = json.dumps(Progress_Event)
            Upload_Url = json.dumps(f'/_nucleon_upload/{Picker_Id}')
            Script = f'''
                (() => {{
                    const Picker_Id = {Picker_Value};
                    const Progress_Event = {Event_Value};
                    const Upload_Url = {Upload_Url};
                    const Entry = window.Nucleon_File_Pickers ? window.Nucleon_File_Pickers[Picker_Id] : null;
                    if (!Entry || !Entry.Files || Entry.Files.length <= 0) {{
                        emitEvent(Progress_Event, {{
                            Id: Picker_Id,
                            Status: 'Error',
                            Percentage: 0,
                            Total_Size: 0,
                            Uploaded_Size: 0,
                            Time_Spent: 0,
                            Time_Left: null,
                            Speed: 0,
                            Error: 'No selected files found'
                        }});
                        return;
                    }}
                    const Files = Entry.Files;
                    const Metadata = Entry.Metadata || [];
                    const Total_Size = Files.reduce((Total, File) => Total + (File.size || 0), 0);
                    const Started = Date.now();
                    const Form = new FormData();
                    Files.forEach((File, Index) => {{
                        const Name = File.webkitRelativePath || File.name || ('File_' + Index);
                        Form.append('Files', File, Name);
                    }});
                    const Send = (Status, Uploaded_Size, Response, Error) => {{
                        const Time_Spent = Math.max(0.001, (Date.now() - Started) / 1000);
                        const Speed = Uploaded_Size / Time_Spent;
                        const Time_Left = Speed > 0 ? Math.max(0, (Total_Size - Uploaded_Size) / Speed) : null;
                        const Percentage = Total_Size > 0 ? Math.max(0, Math.min(100, (Uploaded_Size / Total_Size) * 100)) : 0;
                        emitEvent(Progress_Event, {{
                            Id: Picker_Id,
                            Status: Status,
                            Percentage: Percentage,
                            Total_Size: Total_Size,
                            Uploaded_Size: Uploaded_Size,
                            Time_Spent: Time_Spent,
                            Time_Left: Time_Left,
                            Speed: Speed,
                            Count: Files.length,
                            Files: Metadata,
                            Response: Response || null,
                            Error: Error || ''
                        }});
                    }};
                    const Request = new XMLHttpRequest();
                    Request.open('POST', Upload_Url, true);
                    Request.upload.onprogress = Event => {{
                        Send('Progress', Event.loaded || 0, null, '');
                    }};
                    Request.onload = () => {{
                        let Response = null;
                        try {{
                            Response = JSON.parse(Request.responseText);
                        }} catch (Error) {{
                            Response = Request.responseText;
                        }}
                        if (Request.status >= 200 && Request.status < 300) {{
                            Send('Done', Total_Size, Response, '');
                        }} else {{
                            Send('Error', Total_Size, Response, 'HTTP ' + Request.status);
                        }}
                    }};
                    Request.onerror = () => Send('Error', 0, null, 'Upload failed');
                    Request.onabort = () => Send('Error', 0, null, 'Upload aborted');
                    Send('Start', 0, null, '');
                    Request.send(Form);
                }})();
            '''
            ui.run_javascript(Script)
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> _Run_Upload -> {E}')
            return False

    async def File(self, Multiple=False, Accept='', Timeout=300):
        try:
            self._Ensure_File_System()
            Picker_Id = 'File_' + uuid.uuid4().hex
            Picker_Value = json.dumps(Picker_Id)
            Accept_Value = json.dumps(str(Accept or ''))
            Multiple_Value = 'true' if Multiple else 'false'
            Script = f'''
                return await new Promise((Resolve) => {{
                    if (!window.Nucleon_File_Pickers) window.Nucleon_File_Pickers = {{}};
                    const Picker_Id = {Picker_Value};
                    const Input = document.createElement('input');
                    Input.type = 'file';
                    Input.multiple = {Multiple_Value};
                    Input.accept = {Accept_Value};
                    Input.style.position = 'fixed';
                    Input.style.left = '-10000px';
                    Input.style.top = '-10000px';
                    Input.style.opacity = '0';
                    Input.onchange = () => {{
                        const Files = Array.from(Input.files || []);
                        const Items = Files.map((File, Index) => {{
                            const Relative_Path = File.webkitRelativePath || '';
                            const Fake_Path = 'C:\\\\fakepath\\\\' + (File.name || '');
                            const Path = Relative_Path || Fake_Path;
                            return {{
                                Id: Picker_Id,
                                Index: Index,
                                Name: File.name || '',
                                Path: Path,
                                Fake_Path: Fake_Path,
                                Relative_Path: Relative_Path,
                                Type: File.type || '',
                                Size: File.size || 0,
                                Last_Modified: File.lastModified || 0
                            }};
                        }});
                        const Total_Size = Items.reduce((Total, File) => Total + File.Size, 0);
                        window.Nucleon_File_Pickers[Picker_Id] = {{
                            Input: Input,
                            Files: Files,
                            Metadata: Items
                        }};
                        Resolve({{
                            Id: Picker_Id,
                            Type: 'File',
                            Files: Items,
                            Count: Items.length,
                            Total_Size: Total_Size
                        }});
                    }};
                    Input.oncancel = () => {{
                        Resolve({{
                            Id: Picker_Id,
                            Type: 'File',
                            Files: [],
                            Count: 0,
                            Total_Size: 0
                        }});
                    }};
                    document.body.appendChild(Input);
                    Input.click();
                }});
            '''
            Data = await ui.run_javascript(Script, timeout=Timeout)
            self._Register_File_Data(Picker_Id, Data)
            return Data
        except Exception as E:
            self.Error(f'{self._Type} -> File -> {E}')
            return {'Id': '', 'Type': 'File', 'Files': [], 'Count': 0, 'Total_Size': 0}

    async def Folder(self, Accept='', Timeout=300):
        try:
            self._Ensure_File_System()
            Picker_Id = 'Folder_' + uuid.uuid4().hex
            Picker_Value = json.dumps(Picker_Id)
            Accept_Value = json.dumps(str(Accept or ''))
            Script = f'''
                return await new Promise((Resolve) => {{
                    if (!window.Nucleon_File_Pickers) window.Nucleon_File_Pickers = {{}};
                    const Picker_Id = {Picker_Value};
                    const Input = document.createElement('input');
                    Input.type = 'file';
                    Input.multiple = true;
                    Input.accept = {Accept_Value};
                    Input.setAttribute('webkitdirectory', '');
                    Input.setAttribute('directory', '');
                    Input.style.position = 'fixed';
                    Input.style.left = '-10000px';
                    Input.style.top = '-10000px';
                    Input.style.opacity = '0';
                    Input.onchange = () => {{
                        const Files = Array.from(Input.files || []);
                        const Items = Files.map((File, Index) => {{
                            const Relative_Path = File.webkitRelativePath || '';
                            const Fake_Path = 'C:\\\\fakepath\\\\' + (File.name || '');
                            const Path = Relative_Path || Fake_Path;
                            return {{
                                Id: Picker_Id,
                                Index: Index,
                                Name: File.name || '',
                                Path: Path,
                                Fake_Path: Fake_Path,
                                Relative_Path: Relative_Path,
                                Type: File.type || '',
                                Size: File.size || 0,
                                Last_Modified: File.lastModified || 0
                            }};
                        }});
                        const Total_Size = Items.reduce((Total, File) => Total + File.Size, 0);
                        window.Nucleon_File_Pickers[Picker_Id] = {{
                            Input: Input,
                            Files: Files,
                            Metadata: Items
                        }};
                        Resolve({{
                            Id: Picker_Id,
                            Type: 'Folder',
                            Files: Items,
                            Count: Items.length,
                            Total_Size: Total_Size
                        }});
                    }};
                    Input.oncancel = () => {{
                        Resolve({{
                            Id: Picker_Id,
                            Type: 'Folder',
                            Files: [],
                            Count: 0,
                            Total_Size: 0
                        }});
                    }};
                    document.body.appendChild(Input);
                    Input.click();
                }});
            '''
            Data = await ui.run_javascript(Script, timeout=Timeout)
            self._Register_File_Data(Picker_Id, Data)
            return Data
        except Exception as E:
            self.Error(f'{self._Type} -> Folder -> {E}')
            return {'Id': '', 'Type': 'Folder', 'Files': [], 'Count': 0, 'Total_Size': 0}
            
    def Clear_File(self, Input=None):
        try:
            if not hasattr(self, '_File_Picker'):
                self._File_Picker = {}
            if not hasattr(self, '_Upload_Target'):
                self._Upload_Target = {}
            if Input is None:
                self._File_Picker = {}
                self._Upload_Target = {}
                ui.run_javascript('''(() => {
                if (window.Nucleon_File_Pickers) {
                window.Nucleon_File_Pickers = {};
                }
                })();''')
                return True
            Data = self._Resolve_File_Data(Input)
            Picker_Id = str(Data.get('Id', '')) if isinstance(Data, dict) else str(Input or '')
            if not Picker_Id:
                return False
            Remove_Key = []
            for Key, Value in self._File_Picker.items():
                if Key == Picker_Id:
                    Remove_Key.append(Key)
                elif isinstance(Value, dict) and str(Value.get('Id', '')) == Picker_Id:
                    Remove_Key.append(Key)
            for Key in Remove_Key:
                if Key in self._File_Picker:
                    del self._File_Picker[Key]
            if Picker_Id in self._Upload_Target:
                del self._Upload_Target[Picker_Id]
            Picker_Value = json.dumps(Picker_Id)
            ui.run_javascript(f'''
                (() => {{
                const Picker_Id = {Picker_Value};
                if (window.Nucleon_File_Pickers && window.Nucleon_File_Pickers[Picker_Id]) {{
                delete window.Nucleon_File_Pickers[Picker_Id];
                }}
                }})();
            ''')
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> Clear_File -> {E}')
            return False

    def Upload(self, Input=None, Function=None, Save_To='', Loading_Bar=False):
        try:
            self._Ensure_File_System()
            Old_Loading_Bar = self.Loading_Bar()
            self.Loading_Bar(Loading_Bar)
            Data = self._Resolve_File_Data(Input)
            Picker_Id = str(Data.get('Id', '')) if isinstance(Data, dict) else ''
            if not Picker_Id:
                self.Loading_Bar(Old_Loading_Bar)
                return False
            Progress_Event = 'Upload_Progress_' + uuid.uuid4().hex
            self._Upload_Target[Picker_Id] = Save_To
            async def _Progress(E):
                try:
                    Progress_Data = E.args or {}
                    await self._Maybe_Call(Function, Progress_Data)
                    if Progress_Data.get('Status') in ['Done', 'Error']:
                        self.Loading_Bar(Old_Loading_Bar)
                except Exception as Error_Value:
                    self.Error(f'{self._Type} -> Upload -> _Progress -> {Error_Value}')
                    self.Loading_Bar(Old_Loading_Bar)
            ui.on(Progress_Event, _Progress)
            return self._Run_Upload(Picker_Id, Progress_Event)
        except Exception as E:
            self.Error(f'{self._Type} -> Upload -> {E}')
            return False

    def _Ensure_Download_System(self):
        try:
            if not hasattr(self, '_Download_Target'):
                self._Download_Target = {}
            if not hasattr(self, '_Download_Route_Registered'):
                self._Download_Route_Registered = False
            if self._Download_Route_Registered:
                return self
            @app.get('/_nucleon_download/{Download_Id}')
            async def _Nucleon_Download_Route(Download_Id: str):
                try:
                    Data = self._Download_Target.get(Download_Id, {})
                    Path = Data.get('Path', '')
                    Name = Data.get('Name', '')
                    Once = Data.get('Once', True)
                    if not Path or not os.path.exists(Path) or not os.path.isfile(Path):
                        return JSONResponse({'Status': 'Error', 'Error': 'File not found'}, status_code=404)
                    Safe_Name = str(Name or os.path.basename(Path)).replace('"', '')
                    Headers = {'Content-Disposition': f'attachment; filename="{Safe_Name}"', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}
                    Response = FileResponse(Path, filename=Safe_Name, media_type='application/octet-stream', headers=Headers)
                    if Once and Download_Id in self._Download_Target:
                        del self._Download_Target[Download_Id]
                    return Response
                except Exception as E:
                    self.Error(f'{self._Type} -> _Nucleon_Download_Route -> {E}')
                    return JSONResponse({'Status': 'Error', 'Error': str(E)}, status_code=500)
            self._Download_Route_Registered = True
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> _Ensure_Download_System -> {E}')
            return self
            
    def _Run_Progress_Download(self, Download_Id, Name, Size, Progress_Event):
        try:
            Download_Value = json.dumps(Download_Id)
            Name_Value = json.dumps(str(Name))
            Event_Value = json.dumps(Progress_Event)
            Url_Value = json.dumps(f'/_nucleon_download/{Download_Id}')
            Size_Value = int(Size)
            Script = f'''
                (() => {{
                const Download_Id = {Download_Value};
                const Name = {Name_Value};
                const Progress_Event = {Event_Value};
                const Url = {Url_Value};
                const Expected_Size = {Size_Value};
                const Started = Date.now();
                let Last_Loaded = 0;
                const Request = new XMLHttpRequest();
                const Send = (Status, Downloaded_Size, Total_Size, Error) => {{
                const Real_Total = Total_Size > 0 ? Total_Size : Expected_Size;
                const Time_Spent = Math.max(0.001, (Date.now() - Started) / 1000);
                const Speed = Downloaded_Size / Time_Spent;
                const Time_Left = Speed > 0 && Real_Total > 0 ? Math.max(0, (Real_Total - Downloaded_Size) / Speed) : null;
                const Percentage = Real_Total > 0 ? Math.max(0, Math.min(100, (Downloaded_Size / Real_Total) * 100)) : 0;
                emitEvent(Progress_Event, {{
                Id: Download_Id,
                Name: Name,
                Status: Status,
                Percentage: Percentage,
                Total_Size: Real_Total,
                Downloaded_Size: Downloaded_Size,
                Time_Spent: Time_Spent,
                Time_Left: Time_Left,
                Speed: Speed,
                Error: Error || ''
                }});
                }};
                Request.open('GET', Url, true);
                Request.responseType = 'blob';
                Request.onprogress = Event => {{
                Last_Loaded = Event.loaded || 0;
                const Total_Size = Event.lengthComputable ? Event.total : Expected_Size;
                Send('Progress', Last_Loaded, Total_Size, '');
                }};
                Request.onload = () => {{
                if (Request.status >= 200 && Request.status < 300) {{
                const Blob_Size = Request.response && Request.response.size ? Request.response.size : Expected_Size;
                const Blob_Url = window.URL.createObjectURL(Request.response);
                const Link = document.createElement('a');
                Link.href = Blob_Url;
                Link.download = Name;
                document.body.appendChild(Link);
                Link.click();
                Link.remove();
                setTimeout(() => window.URL.revokeObjectURL(Blob_Url), 1000);
                Send('Done', Blob_Size, Blob_Size, '');
                }} else {{
                Send('Error', Last_Loaded, Expected_Size, 'HTTP ' + Request.status);
                }}
                }};
                Request.onerror = () => Send('Error', Last_Loaded, Expected_Size, 'Download failed');
                Request.onabort = () => Send('Error', Last_Loaded, Expected_Size, 'Download aborted');
                Send('Start', 0, Expected_Size, '');
                Request.send();
                }})();
            '''
            ui.run_javascript(Script)
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> _Run_Progress_Download -> {E}')
            return False

    def _Run_Browser_Download(self, Download_Id, Name):
        try:
            Url_Value = json.dumps(f'/_nucleon_download/{Download_Id}')
            Name_Value = json.dumps(str(Name))
            ui.run_javascript(f'''
                (() => {{
                const Link = document.createElement('a');
                Link.href = {Url_Value};
                Link.download = {Name_Value};
                document.body.appendChild(Link);
                Link.click();
                Link.remove();
                }})();
            ''')
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> _Run_Browser_Download -> {E}')
            return False

    def Download(self, Path, Name=None, Progress=False, Function=None, Loading_Bar=False, Once=True):
        try:
            self._Ensure_Download_System()
            if not os.path.exists(Path) or not os.path.isfile(Path):
                return False
            if Name is None:
                Name = os.path.basename(Path)
            Download_Id = 'Download_' + uuid.uuid4().hex
            Size = os.path.getsize(Path)
            self._Download_Target[Download_Id] = {'Path': Path, 'Name': Name, 'Size': Size, 'Once': Once}
            if not Progress:
                return self._Run_Browser_Download(Download_Id, Name)
            Old_Loading_Bar = self.Loading_Bar() if hasattr(self, 'Loading_Bar') else True
            if hasattr(self, 'Loading_Bar'):
                self.Loading_Bar(Loading_Bar)
            Progress_Event = 'Download_Progress_' + uuid.uuid4().hex
            async def _Progress(E):
                try:
                    Progress_Data = E.args or {}
                    await self._Maybe_Call(Function, Progress_Data)
                    if Progress_Data.get('Status') in ['Done', 'Error']:
                        if Download_Id in self._Download_Target:
                            del self._Download_Target[Download_Id]
                        if hasattr(self, 'Loading_Bar'):
                            self.Loading_Bar(Old_Loading_Bar)
                except Exception as Error_Value:
                    self.Error(f'{self._Type} -> Download -> _Progress -> {Error_Value}')
                    if hasattr(self, 'Loading_Bar'):
                        self.Loading_Bar(Old_Loading_Bar)
            ui.on(Progress_Event, _Progress)
            return self._Run_Progress_Download(Download_Id, Name, Size, Progress_Event)
        except Exception as E:
            self.Error(f'{self._Type} -> Download -> {E}')
            return False

    def Icon(self, Value=None):
        try:
            if Value is not None:
                self._Icon = Value
                self._Icon_Source = ''
                if self._Created:
                    self._Apply_Icon()
            return self._Icon
        except Exception as E:
            self.Error(f'{self._Type} -> Icon -> {E}')
            return self._Icon

    def _Refresh(self):
        try:
            self._Apply_Page_Scroll()
            self._Apply_Icon()
            if self._Body is not None:
                Body_Classes = 'w-full'
                if self._Classes:
                    Body_Classes += ' ' + self._Classes
                if self._Body_Classes:
                    Body_Classes += ' ' + self._Body_Classes
                self._Body.classes(replace=Body_Classes)
                Body_Style = self._Root_Style()
                if self._Body_Style:
                    Body_Style += '; ' + self._Body_Style
                self._Body.style(replace=Body_Style)
            ui.page_title(self._Title)
        except Exception as E:
            self.Error(f'{self._Type} -> _Refresh -> {E}')

    def Create(self):
        try:
            self._Apply_Page_Scroll()
            self._Apply_Icon()
            Body_Classes = 'w-full'
            if self._Classes:
                Body_Classes += ' ' + self._Classes
            if self._Body_Classes:
                Body_Classes += ' ' + self._Body_Classes
            Body_Style = self._Root_Style()
            if self._Body_Style:
                Body_Style += '; ' + self._Body_Style
            self._Body = None
            with ui.element('div').classes(Body_Classes).style(Body_Style) as self._Body:
                pass
            if self._Binding:
                Event_Bind(self._Body, **self._Binding)
            ui.page_title(self._Title)
            self._Created = True
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Create -> {E}')

    def After(self, Delay, Function):
        try:
            if self._Page_Function is not None and not self._Created:
                self._After_Queue.append([Delay, Function])
                return self
            return ui.timer(float(Delay) / 1000.0, Function, once=True)
        except Exception as E:
            self.Error(f'{self._Type} -> After -> {E}')

    def Timer(self, Delay, Function):
        try:
            return ui.timer(float(Delay) / 1000.0, Function)
        except Exception as E:
            self.Error(f'{self._Type} -> After -> {E}')

    def Widget(self):
        try:
            return self._Body
        except Exception as E:
            self.Error(f'{self._Type} -> Widget -> {E}')

    def Body(self):
        try:
            return self._Body
        except Exception as E:
            self.Error(f'{self._Type} -> Body -> {E}')

    def Bind(self, **Input):
        try:
            for Key, Value in Input.items():
                self._Binding[Key] = Value
            if self._Body is not None:
                Event_Bind(self._Body, **Input)
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Bind -> {E}')

    def Title(self, Value=None):
        try:
            if Value is not None:
                self._Title = Value
                if self._Created:
                    ui.page_title(self._Title)
            return self._Title
        except Exception as E:
            self.Error(f'{self._Type} -> Title -> {E}')
            return self._Title

    def IP(self, Value=None):
        try:
            if Value is not None:
                self._IP = str(Value)
            return self._IP
        except Exception as E:
            self.Error(f'{self._Type} -> IP -> {E}')
            return self._IP

    def Port(self, Value=None):
        try:
            if Value is not None:
                self._Port = int(Value)
            return self._Port
        except Exception as E:
            self.Error(f'{self._Type} -> Port -> {E}')
            return self._Port

    def Address(self, IP=None, Port=None):
        try:
            if IP is not None:
                self._IP = str(IP)
            if Port is not None:
                self._Port = int(Port)
            return {'IP': self._IP, 'Port': self._Port}
        except Exception as E:
            self.Error(f'{self._Type} -> Address -> {E}')
            return {'IP': self._IP, 'Port': self._Port}

    def Scroll(self, Value=None, X=None, Y=None):
        try:
            if Value is not None:
                self._Scroll = Value
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y

            self._Apply_Page_Scroll()

            if self._Created:
                self._Refresh()

            return {
                'Scroll': self._Scroll,
                'Scroll_X': self._Scroll_X,
                'Scroll_Y': self._Scroll_Y,
            }
        except Exception as E:
            self.Error(f'{self._Type} -> Scroll -> {E}')
            return {
                'Scroll': self._Scroll,
                'Scroll_X': self._Scroll_X,
                'Scroll_Y': self._Scroll_Y,
            }

    async def Page_Scroll(self, Value=True, X=None, Y=None):
        try:
            self._Scroll = Value if Value is not None else self._Scroll
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y
            Css = self._Page_Scroll_CSS()
            Safe_Css = Css.replace('`', '')
            await ui.run_javascript(f'''
                let Style_Tag = document.getElementById('wavionix-page-scroll-style');
                if (!Style_Tag) {{
                    Style_Tag = document.createElement('style');
                    Style_Tag.id = 'wavionix-page-scroll-style';
                    document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_Css}`;
            ''')
            if self._Created:
                self._Refresh()
            return {'Scroll': self._Scroll, 'Scroll_X': self._Scroll_X, 'Scroll_Y': self._Scroll_Y}
        except Exception as E:
            self.Error(f'{self._Type} -> Page_Scroll -> {E}')
            return {'Scroll': self._Scroll, 'Scroll_X': self._Scroll_X, 'Scroll_Y': self._Scroll_Y}

    async def Full_Screen(self, Toggle=None):
        try:
            if Toggle is None:
                Toggle = not self._Full_Screen

            self._Full_Screen = bool(Toggle)

            if self._Full_Screen:
                await ui.run_javascript('if (!document.fullscreenElement) { await document.documentElement.requestFullscreen(); }')
            else:
                await ui.run_javascript('if (document.fullscreenElement) { await document.exitFullscreen(); }')

            return self._Full_Screen
        except Exception as E:
            self.Error(f'{self._Type} -> Full_Screen -> {E}')
            return self._Full_Screen

    async def Full_Screen_Toggle(self):
        try:
            return await self.Full_Screen()
        except Exception as E:
            self.Error(f'{self._Type} -> Full_Screen_Toggle -> {E}')
            return self._Full_Screen

    def Show(self):
        try:
            self._Visible = True
            self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Show -> {E}')

    def Hide(self):
        try:
            self._Visible = False
            self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Hide -> {E}')

    def Notify(self, Message):
        try:
            ui.notify(str(Message))
            return True
        except Exception as E:
            self.Error(f'{self._Type} -> _Notify -> {E}')
            return False

    def Config_Get(self, *Input):
        try:
            if not Input:
                Return = {}
                for Each in self._Config:
                    Return[Each] = getattr(self, '_' + Each)
                return Return

            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self.Error(f'{self._Type} -> Config_Get -> {E}')
            return {}

    def Config(self, **Input):
        try:
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
            if 'Icon' in Input:
                self._Icon_Source = ''
            if self._Created:
                self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Config -> {E}')

    def _Apply_Log_Config(self):
        try:
            if self._NiceGUI_Log_Level in [False, None, '']:
                return self
            Level = getattr(logging, str(self._NiceGUI_Log_Level).upper(), logging.ERROR)
            logging.getLogger('nicegui').setLevel(Level)
            logging.getLogger('nicegui.element').setLevel(Level)
            logging.getLogger('nicegui.client').setLevel(Level)
            logging.getLogger('nicegui.outbox').setLevel(Level)
            logging.getLogger('uvicorn').setLevel(Level)
            logging.getLogger('uvicorn.error').setLevel(Level)
            logging.getLogger('uvicorn.access').setLevel(Level)
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> _Apply_Log_Config -> {E}')

    def Start_Config(self, Function=None, *Args, **KArgs):
        try:
            self._Start_Function = Function
            self._Start_Args = Args
            self._Start_KArgs = KArgs
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Start_Config -> {E}')

    def Start(self):
        try:
            self._Apply_Log_Config()
            if self._Start_Function is not None:
                self._Start_Function(*self._Start_Args, **self._Start_KArgs)
            if self._Page_Function is not None and not self._Page_Registered:
                ui.page(self._Page_Route)(self._Build_Page)
                self._Page_Registered = True
            Run_Input = {
                'host': self._IP,
                'port': self._Port,
                'title': self._Title,
                'reload': self._Reload,
                'show': self._Show,
                'show_welcome_message': self._Welcome_Message,
                'uvicorn_logging_level': str(self._NiceGUI_Log_Level).lower() if self._NiceGUI_Log_Level not in [False, None, ''] else 'warning',
            }
            Icon_Source, _ = self._Resolve_Icon(self._Icon)
            if Icon_Source:
                Run_Input['favicon'] = Icon_Source
            ui.run(**Run_Input)
        except Exception as E:
            self.Error(f'{self._Type} -> Start -> {E}')