from types import SimpleNamespace
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Switch:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Switch'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#c9ced6',
                    'Foreground': '#ffffff',
                    'Active_Background': '#22c55e',
                    'Active_Foreground': '#ffffff',
                    'Knob_Background': '#ffffff',
                    'Border_Color': 'transparent',
                    'Border_Size': 0,
                    'Border_Radius': 999,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': 58,
                    'Height': 30,
                    'Animate_Left': 0,
                    'Animate_Top': 0,
                    'Animate_Width': 0,
                    'Animate_Height': 0,
                    'Animate_Time': 1.0,
                    'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                    'Dot_Margin': 3,
                    'Dot_Speed': 30,
                    'Font_Size': 10,
                    'Font_Weight': '700',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Value': False,
                    'Text_On': '',
                    'Text_Off': '',
                    'Hover_Background': False,
                    'Hover_Border_Color': False,
                    'Padding': 3,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 2,
                    'Shadow_Blur': 8,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'rgba(0,0,0,0.18)',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Text = None
                self._Knob = None
                self._Name = False
                self._Background = '#c9ced6'
                self._Foreground = '#ffffff'
                self._Active_Background = '#22c55e'
                self._Active_Foreground = '#ffffff'
                self._Knob_Background = '#ffffff'
                self._Border_Color = 'transparent'
                self._Border_Size = 0
                self._Border_Radius = 999
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = 58
                self._Height = 30
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Dot_Margin = 3
                self._Dot_Speed = 30
                self._Font_Size = 10
                self._Font_Weight = '700'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Value = False
                self._Text_On = ''
                self._Text_Off = ''
                self._Hover_Background = False
                self._Hover_Border_Color = False
                self._Padding = 3
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 2
                self._Shadow_Blur = 8
                self._Shadow_Spread = 0
                self._Shadow_Color = 'rgba(0,0,0,0.18)'
                self._Hover = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Switch[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Switch[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False or Value == '':
            return 0.0
        if isinstance(Value, (int, float)):
            return float(Value)
        try:
            Text = str(Value).strip().lower().replace('px', '')
            return float(Text)
        except Exception:
            return 0.0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Current_Background(self):
        if self._Value:
            return self._Active_Background
        if self._Hover and self._Hover_Background:
            return self._Hover_Background
        return self._Background

    def _Current_Foreground(self):
        if self._Value:
            return self._Active_Foreground
        return self._Foreground

    def _Current_Border_Color(self):
        if self._Hover and self._Hover_Border_Color:
            return self._Hover_Border_Color
        return self._Border_Color

    def _Dot_Margin_Value(self):
        try:
            if isinstance(self._Dot_Margin, str):
                Text = self._Dot_Margin.strip()
                if Text.endswith('%'):
                    Number = float(Text[:-1])
                    return f'min({Number}cqw, {Number}cqh)'
            return self._Unit(self._Dot_Margin) or '0px'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Margin_Value -> {E}')
            return '0px'

    def _Dot_Margin_Double(self):
        try:
            if isinstance(self._Dot_Margin, str):
                Text = self._Dot_Margin.strip()
                if Text.endswith('%'):
                    Number = round(float(Text[:-1]) * 2, 3)
                    return f'min({Number}cqw, {Number}cqh)'
            Number, Unit = self._CSS_Number_Unit(self._Dot_Margin)
            if Number is not None:
                Value = round(float(Number) * 2, 3)
                if Unit == '%':
                    return f'min({Value}cqw, {Value}cqh)'
                return f'{Value}px'
            Margin = self._Dot_Margin_Value()
            return f'calc({Margin} + {Margin})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Margin_Double -> {E}')
            return '0px'

    def _Dot_Size(self):
        try:
            return f'max(4px, calc(min(100cqw, 100cqh) - {self._Dot_Margin_Double()}))'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Size -> {E}')
            return '100%'

    def _Dot_Left(self):
        try:
            Margin = self._Dot_Margin_Value()
            if self._Value:
                return f'calc(100% - {Margin})'
            return Margin
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Left -> {E}')
            return '0px'

    def _Dot_Transform(self):
        try:
            if self._Value:
                return 'translateX(-100%)'
            return 'translateX(0)'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Transform -> {E}')
            return 'translateX(0)'

    def _Dot_Speed_Value(self):
        try:
            Speed = float(self._Dot_Speed)
            if Speed < 1:
                Speed = 1
            if Speed > 100:
                Speed = 100
            return Speed
        except Exception:
            return 70

    def _Switch_Time_CSS(self):
        try:
            Speed = self._Dot_Speed_Value()
            Time = 0.85 - ((Speed - 1) / 99) * 0.78
            return f'{round(Time, 3)}s'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Switch_Time_CSS -> {E}')
            return '0.22s'

    def _Dot_Time_CSS(self):
        try:
            if self._Animate_Transition:
                return '0s'
            return self._Switch_Time_CSS()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Dot_Time_CSS -> {E}')
            return '0.22s'

    def _Bool(self, Value=False):
        try:
            if isinstance(Value, bool):
                return Value
            if isinstance(Value, (int, float)):
                return Value != 0
            if isinstance(Value, str):
                Text = Value.strip().lower()
                if Text in ['1', 'true', 'yes', 'on', 'active', 'checked']:
                    return True
                if Text in ['0', 'false', 'no', 'off', 'none', '', 'inactive', 'unchecked']:
                    return False
            return bool(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Bool -> {E}')
            return False

    def _Build_Frame_Style(self):
        Box = self._Animate_Current_Box()
        Width = self._Unit(Box['Width']) or '58px'
        Height = self._Unit(Box['Height']) or '30px'
        Switch_Time = self._Switch_Time_CSS()
        Transition = f'background {Switch_Time} ease, border-color {Switch_Time} ease, box-shadow {Switch_Time} ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}, background {Switch_Time} ease, border-color {Switch_Time} ease, box-shadow {Switch_Time} ease'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"block" if self._Display or self._Animating else "none"}')
        Style.append('position: relative')
        Style.append('container-type: size')
        Style.append('overflow: hidden')
        Style.append('user-select: none')
        Style.append('outline: none')
        Style.append('touch-action: manipulation')
        Style.append(f'background: {self._Current_Background()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Current_Border_Color()}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "999px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append('padding: 0')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append(f'width: {Width}')
        Style.append(f'height: {Height}')
        Style.append(f'min-width: {Width}')
        Style.append(f'min-height: {Height}')
        Style.append(f'transition: {Transition}')
        Style.append('cursor: not-allowed' if self._Disable else 'cursor: pointer')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Current_Text(self):
        try:
            Text = self._Text_On if self._Value else self._Text_Off
            if Text in [None, False]:
                return ''
            return str(Text)
        except Exception:
            return ''

    def _Build_Text_Style(self):
        Margin = self._Dot_Margin_Value()
        Align = 'flex-start' if self._Value else 'flex-end'
        Current_Text = self._Current_Text()
        Time = self._Switch_Time_CSS()
        Style = []
        Style.append('position: absolute')
        Style.append('inset: 0')
        Style.append(f'display: {"flex" if Current_Text != "" else "none"}')
        Style.append('align-items: center')
        Style.append(f'justify-content: {Align}')
        Style.append(f'padding-left: calc({Margin} + 8px)')
        Style.append(f'padding-right: calc({Margin} + 8px)')
        Style.append('pointer-events: none')
        Style.append('user-select: none')
        Style.append('white-space: nowrap')
        Style.append('overflow: hidden')
        Style.append('text-overflow: ellipsis')
        Style.append(f'color: {self._Current_Foreground()}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "10px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append('letter-spacing: 0.06em')
        Style.append('line-height: 1')
        Style.append('text-transform: uppercase')
        Style.append(f'transition: color {Time} ease')
        return '; '.join(Style)

    def _Build_Knob_Style(self):
        Margin = self._Dot_Margin_Value()
        Size = self._Dot_Size()
        Time = self._Dot_Time_CSS()
        Style = []
        Style.append('position: absolute')
        Style.append(f'left: {self._Dot_Left()}')
        Style.append(f'top: {Margin}')
        Style.append(f'height: {Size}')
        Style.append(f'width: {Size}')
        Style.append(f'background: {self._Knob_Background}')
        Style.append('border-radius: 999px')
        Style.append('box-shadow: 0 1px 4px rgba(0,0,0,0.22)')
        Style.append(f'transform: {self._Dot_Transform()}')
        Style.append(f'transition: left {Time} ease, top {Time} ease, width {Time} ease, height {Time} ease, transform {Time} ease, background {Time} ease, box-shadow {Time} ease')
        Style.append('will-change: left, width, height, transform')
        Style.append('z-index: 2')
        return '; '.join(Style)

    def _Emit_Change(self):
        try:
            if self._On_Change:
                self._On_Change(SimpleNamespace(value=self._Value, sender=self))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Emit_Change -> {E}')

    def _Hover_In(self):
        try:
            self._Hover = True
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Hover = False
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def _Toggle_Click(self):
        try:
            if self._Disable:
                return
            self._Animate_Transition = False
            self._Animate_Box = None
            self._Value = not self._Bool(self._Value)
            self._Apply()
            self._Emit_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Toggle_Click -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Text is None or self._Knob is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            if hasattr(self._Text, '_style'):
                self._Text._style.clear()
            if hasattr(self._Text, '_classes'):
                self._Text._classes.clear()

            if hasattr(self._Knob, '_style'):
                self._Knob._style.clear()
            if hasattr(self._Knob, '_classes'):
                self._Knob._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            self._Frame.props(
                f'tabindex={"-1" if self._Disable else "0"} '
                f'role=switch '
                f'aria-checked={"true" if self._Value else "false"} '
                f'aria-disabled={"true" if self._Disable else "false"}'
            )

            self._Text.set_text(self._Current_Text())
            self._Text.style(self._Build_Text_Style())

            self._Knob.style(self._Build_Knob_Style())

            self._Text.update()
            self._Knob.update()
            self._Frame.update()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Text = None
                self._Knob = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if hasattr(self, '_Disable') and self._Disable:
                return False
            if self._Frame is None:
                return False
            self._Frame.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Get(self):
        try:
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value=False):
        try:
            self._Value = self._Bool(Value)
            self._Apply()
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Toggle(self):
        try:
            self._Toggle_Click()
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Toggle -> {E}')

    def Set_On_Click(self):
        try:
            self._Toggle_Click()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set_On_Click -> {E}')

    def Refresh(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Focus(self):
        try:
            if self._Frame is not None:
                self._Frame.run_method('focus')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')

    def Widget(self):
        try:
            return self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Padding' in Input and 'Dot_Margin' not in Input:
                self._Dot_Margin = Input['Padding']
                Run = True
            if 'Value' in Input:
                self._Value = self._Bool(Input['Value'])
            if 'Check' in Input:
                self._Value = self._Bool(Input['Check'])
            if self._Initialized and Run:
                self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')

                        self._Frame = ui.element('div').props('tabindex=0')
                        with self._Frame:
                            self._Text = ui.label('')
                            self._Knob = ui.element('div')
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')

                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Text = ui.label('')
                        self._Knob = ui.element('div')

                self._Frame.on('click', lambda E: self._Toggle_Click())
                self._Frame.on('keydown.enter', lambda E: self._Toggle_Click())
                self._Frame.on('keydown.space', lambda E: self._Toggle_Click())
                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')