from setuptools import setup, find_packages

setup(
    name="Wavionix",
    version="0.3.0",
    description="A Web GUI lib based on nicegui.",
    author="Nucleon Automation",
    author_email="jagroop@nucleonautomation.com",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "pillow>=6.0.0",
        "nicegui>=3.10.0"
    ],
)

'''
python -m build --sdist
twine upload dist/*
pip install dist/wavionix-0.3.0.tar.gz
'''