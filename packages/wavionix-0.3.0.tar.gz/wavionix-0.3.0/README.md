# Wavionix V(0.3.0)

- Wavionix is a lightweight Python utility built on top of NiceGUI, designed to simplify the implementation of user interfaces through structured, class-based components. Instead of a visual designer, Wavionix focuses on making GUI development more readable, reusable, and maintainable in code.

## Feedback
- We hope you find Wavionix useful and intuitive. If you have any thoughts or suggestions, we’d love to hear from you at feedback@nucleonautomation.com. Your input helps us continue improving the project.

## Features
- Class-Based Design: Build interfaces using clean, reusable Python classes.
- Built on NiceGUI: Leverages the power and flexibility of NiceGUI while improving developer ergonomics.
- Simplified Implementation: Reduces boilerplate and streamlines UI creation.
- Component Abstraction: Encapsulates common UI patterns into easy-to-use structures.
- Customization: Easily extend and customize components to fit your application needs.

## Installation Pypi
```
# Requires Python >=3.6
pip install Wavionix
```

## Requirements
```
pip install -r requirements.txt
```

## License
- This project is licensed under BSD 4-Clause License. See the [LICENSE](https://github.com/nucleonautomation/Web-Designer/blob/main/LICENSE.md) file for details.

## Change Log
- See the [LOG](https://github.com/nucleonautomation/Web-Designer/blob/main/LOG.md) file for details.
