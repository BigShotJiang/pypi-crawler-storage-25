from __future__ import annotations

import functools
import re
from collections import defaultdict
from typing import Any, Generator, Literal

from valkit.common import valid_bool, valid_string_list

from annet.annlib.rbparser import syntax
from annet.annlib.rbparser.exceptions import RulebookSyntaxError
from annet.rulebook.common import get_merged_params, raw_param_to_bool, validate_context_compatibility
from annet.rulebook.types import (
    AnchorData,
    AnchorsData,
    Group,
    GroupData,
    GroupRows,
    OrderingText,
    OrderPreMerge,
    OrderPreMergeData,
    OrderRuleAttrs,
    OrderRulebook,
    ParamsScheme,
    RawParams,
    RawRow,
    Row,
)
from annet.vendors import registry_connector


# ===RULE===
RULES: Literal["rules"] = "rules"
ATTRS: Literal["attrs"] = "attrs"
CHILDREN: Literal["children"] = "children"
TYPE: Literal["type"] = "type"
NORMAL: Literal["normal"] = "normal"

# ===PARAMS===
PARAMS: Literal["params"] = "params"
ORDER_REVERSE: Literal["order_reverse"] = "order_reverse"
GLOBAL: Literal["global"] = "global"
SCOPE: Literal["scope"] = "scope"
SPLIT: Literal["split"] = "split"
DIRECT_REGEXP: Literal["direct_regexp"] = "direct_regexp"
REVERSE_REGEXP: Literal["reverse_regexp"] = "reverse_regexp"
CONTEXT: Literal["context"] = "context"
RAW_RULE: Literal["raw_rule"] = "raw_rule"
ROW: Literal["row"] = "row"
NOT_INHERIT: Literal["not_inherit"] = "not_inherit"
INSERT_TO_END_GROUP: Literal["insert_to_end_group"] = "insert_to_end_group"

# ===GROUP===
ROWS: Literal["rows"] = "rows"
ANCHOR: Literal["anchor"] = "anchor"
COUNT: Literal["count"] = "count"


def get_params_scheme() -> ParamsScheme:
    """Returning the params scheme"""
    return {
        ORDER_REVERSE: {
            "validator": valid_bool,
            "default": False,
        },
        GLOBAL: {
            "validator": valid_bool,
            "default": False,
        },
        SCOPE: {
            "validator": valid_string_list,
            "default": None,
        },
        SPLIT: {
            "validator": valid_bool,
            "default": False,
        },
        CONTEXT: {
            "validator": str,
            "default": None,
        },
    }


@functools.lru_cache()
def compile_ordering_text(text: OrderingText, vendor: str) -> OrderRulebook:
    return _compile_ordering(
        tree=syntax.parse_text_multi(
            text,
            params_scheme=get_params_scheme(),
        ),
        reverse_prefix=registry_connector.get()[vendor].reverse,
    )


def _compile_ordering(tree: syntax.ParsedTree, reverse_prefix: str) -> OrderRulebook:
    ordering: OrderRulebook = []
    for rule_id, attrs in tree:
        if attrs[TYPE] == NORMAL:
            ordering.append(
                (
                    rule_id,
                    {
                        ATTRS: OrderRuleAttrs(
                            {
                                DIRECT_REGEXP: syntax.compile_row_regexp(attrs[ROW]),
                                REVERSE_REGEXP: (
                                    syntax.compile_row_regexp(reverse_prefix + " " + attrs[ROW])
                                    if not attrs[ROW].startswith(reverse_prefix + " ")
                                    else syntax.compile_row_regexp(re.sub(r"^%s\s+" % (reverse_prefix), "", attrs[ROW]))
                                ),
                                ORDER_REVERSE: attrs[PARAMS][ORDER_REVERSE],
                                GLOBAL: attrs[PARAMS][GLOBAL],
                                SCOPE: attrs[PARAMS][SCOPE],
                                RAW_RULE: attrs[RAW_RULE],
                                CONTEXT: attrs[CONTEXT],
                                SPLIT: attrs[PARAMS][SPLIT],
                            }
                        ),
                        CHILDREN: _compile_ordering(attrs[CHILDREN], reverse_prefix),
                    },
                )
            )
    return ordering


def merge_order_rulebooks(
    parent_rulebook: OrderRulebook, child_rulebook: OrderRulebook, vendor: str, parent_scopes: list[str] | None = None
) -> OrderRulebook:
    """Merges the parent rulebook with the child rulebook"""
    merged_rulebook: OrderRulebook = []

    parent_pre_merge = _get_pre_merge(parent_rulebook)
    child_pre_merge = _get_pre_merge(child_rulebook)
    parent_pre_merge, child_pre_merge = _apply_not_inherit_to_pre_merges(parent_pre_merge, child_pre_merge)
    _check_pre_merge_for_duplicate_rules(child_pre_merge, "children")
    _check_pre_merge_for_duplicate_rules(parent_pre_merge, "parent")

    child_groups = _get_child_groups(parent_pre_merge, child_pre_merge)
    group_anchor, group_data = _get_next_group(child_groups)

    # Stores rules with %insert_to_end_group and anchor, rules to be added before the next anchor
    anchor_queue: GroupRows = []
    # Stores rules without %insert_to_end_group and anchor, rules to be added at the very end
    non_anchor_queue: GroupRows = []

    if group_anchor is None:
        start_group_rows, end_group_rows = _split_rows_by_insert_to_end_group_param(group_data[ROWS])
        _add_group_to_merged_rulebook(merged_rulebook, start_group_rows, parent_scopes)
        non_anchor_queue = end_group_rows
        group_anchor, group_data = _get_next_group(child_groups)

    start_group_rows, end_group_rows = _split_rows_by_insert_to_end_group_param(group_data[ROWS])

    for row, parent_data in parent_pre_merge:
        if (group_anchor is None and _is_empty_child_group_data(group_data)) or row != group_anchor:
            node = (parent_data[RAW_RULE], parent_data[RULES])
            check_rulebook_scope_compatibility([node], parent_scopes)
            merged_rulebook.append(node)
            continue

        anchor_data = group_data[ANCHOR]

        # for mypy: anchor_data cannot be None due to prior if-condition check
        assert anchor_data is not None

        _add_group_to_merged_rulebook(merged_rulebook, anchor_queue, parent_scopes)

        merged_row = _get_merged_row(parent_data[PARAMS], anchor_data[PARAMS], row)
        merged_attrs = _merge_attrs(
            parent_data[RULES][ATTRS], anchor_data[RULES][ATTRS], anchor_data[PARAMS], merged_row
        )

        curr_scopes = merged_attrs[SCOPE]
        if parent_scopes is not None and curr_scopes is not None:
            check_scope_compatibility(curr_scopes, parent_scopes, merged_row)

        merged_children = merge_order_rulebooks(
            parent_data[RULES][CHILDREN],
            anchor_data[RULES][CHILDREN],
            vendor,
            get_effective_scopes(curr_scopes, parent_scopes),
        )

        merged_rulebook.append((merged_row, {ATTRS: merged_attrs, CHILDREN: merged_children}))

        _add_group_to_merged_rulebook(merged_rulebook, start_group_rows, parent_scopes)

        anchor_queue = end_group_rows

        group_anchor, group_data = _get_next_group(child_groups)
        start_group_rows, end_group_rows = _split_rows_by_insert_to_end_group_param(group_data[ROWS])

    _add_group_to_merged_rulebook(merged_rulebook, anchor_queue, parent_scopes)

    _add_group_to_merged_rulebook(merged_rulebook, non_anchor_queue, parent_scopes)

    if start_group_rows or end_group_rows or group_anchor is not None:
        anchor_data = group_data.get(ANCHOR)
        if anchor_data is not None:
            rule = anchor_data[RAW_RULE]
        else:
            rule = None
        raise RulebookSyntaxError(
            "The relative order of rules must stay the same in both parent and child rulebooks.\n"
            f"Rule in child rulebook '{rule}'.\n"
            f"Group anchor '{group_anchor}'.\n"
            f"Rules with insert_to_end_group param in group:\n\t{[row[RAW_RULE] for row in end_group_rows]}\n"
            f"Rules without insert_to_end_group param in group:\n\t{[row[RAW_RULE] for row in start_group_rows]}\n"
            "To fix this:\n"
            "\t1. Check the order of rules in the parent rulebook.\n"
            "\t2. Make sure they appear in exactly the same relative order in the child rulebook.\n"
            "\t3. Try again."
        )
    return merged_rulebook


def dump_order_rulebook(rulebook: OrderRulebook, level: int = 0) -> OrderingText:
    """Parses the rulebook into a text format"""
    lines = []
    for row, data in rulebook:
        lines.append(f"{'    ' * level}{row}")
        children_lines = dump_order_rulebook(data[CHILDREN], level + 1)
        if children_lines:
            lines.append(children_lines)
    return "\n".join(lines)


def _apply_not_inherit_to_pre_merges(
    parent_pre_merge: OrderPreMerge, child_pre_merge: OrderPreMerge
) -> tuple[OrderPreMerge, OrderPreMerge]:
    """Applies the not_inherit logic to parent_pre_merge and child_pre_merge"""
    ignored_rules = set()
    applied_child_pre_merge = []
    for child_row, child_data in child_pre_merge:
        if not raw_param_to_bool(child_data[PARAMS].get(NOT_INHERIT)):
            applied_child_pre_merge.append((child_row, child_data))
            continue

        ignored_rules.add(child_row)
        if child_data[RULES][CHILDREN]:
            applied_child_pre_merge.append((child_row, child_data))

    applied_parent_pre_merge = []
    for parent_row, parent_data in parent_pre_merge:
        if parent_row in ignored_rules:
            continue
        applied_parent_pre_merge.append((parent_row, parent_data))
    return applied_parent_pre_merge, applied_child_pre_merge


def _apply_not_inherit_to_rulebook(rulebook: OrderRulebook) -> OrderRulebook:
    """Applies the not_inherit logic to the rulebook"""
    applied_rulebook: OrderRulebook = []
    for raw_row, data in rulebook:
        row, raw_params = syntax.get_row_and_raw_params(raw_row)
        not_inherit = raw_params.pop(NOT_INHERIT, None)
        raw_row = syntax.get_row_with_params(row, raw_params, get_params_scheme())
        data[ATTRS][RAW_RULE] = raw_row
        if not raw_param_to_bool(not_inherit):
            pass
        elif not data[CHILDREN]:
            continue
        data[CHILDREN] = _apply_not_inherit_to_rulebook(data[CHILDREN])
        applied_rulebook.append((raw_row, data))
    return applied_rulebook


def _split_rows_by_insert_to_end_group_param(rows: GroupRows) -> tuple[GroupRows, GroupRows]:
    """
    Splits rows into two groups based on the insert_to_end_group param

    Group 1 (without insert_to_end_group): rows to insert after the current anchor
    Group 2 (with insert_to_end_group): rows to insert before the next anchor
    """
    start_group = []
    end_group = []
    for row_data in rows:
        if row_data[INSERT_TO_END_GROUP]:
            end_group.append(row_data)
        else:
            start_group.append(row_data)
    return start_group, end_group


def _get_merged_row(parent_params: RawParams, child_params: RawParams, row: Row) -> RawRow:
    """Concatenates the rule string with the merged raw params"""
    merged_params = get_merged_params(
        parent_params,
        child_params,
    )
    return syntax.get_row_with_params(row, merged_params, get_params_scheme())


def _merge_attrs(
    parent_attrs: OrderRuleAttrs, child_attrs: OrderRuleAttrs, child_params: RawParams, raw_row: RawRow
) -> OrderRuleAttrs:
    """Merges parent_attrs and child_attrs"""
    merged_attrs = parent_attrs.copy()

    validate_context_compatibility(parent_attrs, child_attrs, raw_row)

    for param in child_params.keys():
        if param in child_attrs:
            # A dynamic key cannot be recognized by mypy as a string literal
            merged_attrs[param] = child_attrs[param]  # type: ignore[literal-required]

    merged_attrs[RAW_RULE] = raw_row

    return merged_attrs


def _get_pre_merge(rulebook: OrderRulebook) -> OrderPreMerge:
    """Created pre_merge object for merge rulebook"""
    pre_merge = []
    for raw_row, rules in rulebook:
        row, raw_params = syntax.get_row_and_raw_params(raw_row)
        insert_to_end_group = raw_params.pop(INSERT_TO_END_GROUP, None)
        raw_params.pop(SCOPE, None)
        scope = rules[ATTRS].get(SCOPE)
        if scope is not None:
            raw_scope_value = ",".join(scope)
            row = f"{row} %{SCOPE}={raw_scope_value}"
        data = OrderPreMergeData(
            params=raw_params,
            rules=rules,
            raw_rule=raw_row,
            insert_to_end_group=raw_param_to_bool(insert_to_end_group),
        )
        pre_merge.append((row, data))
    return pre_merge


def _get_next_group(child_groups: Generator[Group, None, None]) -> Group:
    """
    Retrieves the next group from child_groups
    Returns an empty group if no more groups are available
    """
    try:
        return next(child_groups)
    except StopIteration:
        return None, _get_empty_child_group_data()


def _get_empty_child_group_data() -> GroupData:
    """Return empty child group data"""
    return GroupData(anchor=None, rows=[])


def _get_empty_anchor_data() -> AnchorData:
    """Return empty anchor data"""
    return AnchorData(count=0, split=False)


def _is_empty_child_group_data(group_data: GroupData) -> bool:
    """Checks whether the provided group is empty"""
    return group_data[ANCHOR] is None and not group_data[ROWS]


def _get_child_groups(parent_pre_merge: OrderPreMerge, child_pre_merge: OrderPreMerge) -> Generator[Group, None, None]:
    """
    Collects rules from `child_pre_merge` into groups based on `parent_pre_merge`
    """
    group_data = _get_empty_child_group_data()
    anchor = None
    anchors_data = _get_anchors_data(parent_pre_merge)
    for row, data in child_pre_merge:
        if row not in anchors_data:
            group_data[ROWS].append(data)
            continue

        count = anchors_data[row][COUNT]
        split = anchors_data[row][SPLIT]
        child_split = data[RULES][ATTRS][SPLIT]

        if child_split != split and split:
            raise RulebookSyntaxError(
                f"Rule '{row}' has different %split parameters in the parent and children rulebooks. "
                f"In parent rulebook: {split}, in children rulebook: {data[RULES][ATTRS][SPLIT]}."
            )
        if count == 0:
            if not split and not child_split:
                raise RulebookSyntaxError(
                    f"Rule '{row}' has no %split parameter but is listed multiple times in the children rulebook."
                )
            group_data[ROWS].append(data)
        else:
            anchors_data[row][COUNT] -= 1
            if not _is_empty_child_group_data(group_data):
                yield anchor, group_data
                group_data = _get_empty_child_group_data()
            anchor = row
            group_data[ANCHOR] = data

    if not _is_empty_child_group_data(group_data):
        yield anchor, group_data


def _get_anchors_data(parent_pre_merge: OrderPreMerge) -> AnchorsData:
    """
    Returns the number of anchors for each rule
    (i.e., how many times the rule appears in the parent rulebook)
    """
    anchors_data: AnchorsData = {}
    for row, data in parent_pre_merge:
        anchor_data: AnchorData = anchors_data.get(row, _get_empty_anchor_data())
        anchor_data[COUNT] = anchor_data[COUNT] + 1
        anchor_data[SPLIT] = data[RULES][ATTRS][SPLIT]
        anchors_data[row] = anchor_data
        if anchors_data[row][COUNT] > 1 and not anchors_data[row][SPLIT]:
            raise RulebookSyntaxError(
                f"Rule '{row}' has no %split parameter but is listed multiple times in the parent rulebook."
            )
    return anchors_data


def _add_group_to_merged_rulebook(
    merged_rulebook: OrderRulebook, rows: GroupRows, parent_scopes: list[str] | None
) -> None:
    """Adds rules from the group to merged_rulebook"""
    rulebook: OrderRulebook = [(row_data[RAW_RULE], row_data[RULES]) for row_data in rows]
    applied_rulebook = _apply_not_inherit_to_rulebook(rulebook)
    check_rulebook_scope_compatibility(applied_rulebook, parent_scopes)
    merged_rulebook.extend(applied_rulebook)


def check_rulebook_scope_compatibility(rulebook: OrderRulebook, parent_scopes: list[str] | None) -> None:
    """Checks compatibility of rulebook scope"""
    for row, rules in rulebook:
        curr_scopes = rules[ATTRS][SCOPE]
        if curr_scopes is not None and parent_scopes is not None:
            check_scope_compatibility(curr_scopes, parent_scopes, row)
        check_rulebook_scope_compatibility(rules[CHILDREN], get_effective_scopes(curr_scopes, parent_scopes))


def get_effective_scopes(curr_scopes: list[str] | None, parent_scopes: list[str] | None) -> list[str] | None:
    """Returns current scope if curr_scopes is not None, otherwise returns parent_scopes"""
    return curr_scopes if curr_scopes is not None else parent_scopes


def check_scope_compatibility(curr_scopes: list[str], parent_scopes: list[str], row: RawRow) -> None:
    """Checks compatibility of rule scope"""
    if set(curr_scopes) - set(parent_scopes):
        raise RulebookSyntaxError(
            f"The rule {row} specifies a %scope not present in the parent rules. "
            f"Current rule %scope: {curr_scopes}, parent rules %scope: {parent_scopes}."
        )


def _check_pre_merge_for_duplicate_rules(pre_merge: OrderPreMerge, context: Literal["children", "parent"]) -> None:
    """
    Checks pre_merge for duplicate rules

    Rules without the %split parameter may appear only once
    Rules with the %split parameter may appear multiple times
    Identical rules at the same level cannot exist with different %split values
    context (Literal["children", "parent"]): Used to format the error message
    """
    count: defaultdict[str, Any] = defaultdict(dict)
    for row, data in pre_merge:
        split = data[RULES][ATTRS][SPLIT]
        count[row][COUNT] = count[row].get(COUNT, 0) + 1
        if count[row].get(SPLIT) is None:
            count[row][SPLIT] = split
        elif count[row][SPLIT] != split:
            raise RulebookSyntaxError(f"Rule '{row}' has different %split parameters in the {context} rulebook.")
        if not split and count[row][COUNT] > 1:
            raise RulebookSyntaxError(
                f"Rule '{row}' has no %split parameter but is listed multiple times in the {context} rulebook."
            )
