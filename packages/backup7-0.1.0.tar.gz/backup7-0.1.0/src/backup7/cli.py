import argparse
import os
import sys

from . import sync
from .config import CONFIG_DIR


SAMPLE_CONFIG = """# Remote Server Configuration
USERNAME=ubuntu
IP=
PORT=22

# Password Authentication (NOT RECOMMENDED)
# Uncomment and set password to use password-based SSH authentication
PASSWORD=your_password_here

# OR Use SSH Key Authentication (RECOMMENDED)
# If set, this path is relative to the current working directory
# where the command is executed. Use absolute path for consistency.
# SSH_KEY_PATH=~/.ssh/id_rsa

# Local backup output directory (relative or absolute)
OUTPUT_DIR=./backup

# =============================================================================
# FILE MAPPINGS
# =============================================================================
# Format: /remote/path -> /local/path
# - Remote paths MUST be absolute (start with /)
# - Local paths are relative to OUTPUT_DIR
# =============================================================================
map_start
# /home/ubuntu/documents -> ./documents
# /home/ubuntu/pictures -> ./pictures
"""


def generate(args):
    filename = args.filename
    filepath = os.path.join(CONFIG_DIR, filename)

    if os.path.exists(filepath):
        print(f"Config already exists: {filepath}")
        print("Delete it first or choose a different filename.")
        sys.exit(1)

    os.makedirs(CONFIG_DIR, exist_ok=True)

    with open(filepath, "w") as f:
        f.write(SAMPLE_CONFIG)

    print(f"Generated config: {filepath}")
    print(f"Edit this file and run 'backup7 sync' to start backup.")


def sync_to_host():
    pass


def main():
    parser = argparse.ArgumentParser(prog="backup7")
    subparsers = parser.add_subparsers(dest="command", required=True)

    gen_parser = subparsers.add_parser("generate", help="Generate sample config file")
    gen_parser.add_argument("filename", help="Name of config file to create")
    gen_parser.set_defaults(func=generate)

    sync_parser = subparsers.add_parser("sync", help="Sync backups from remote server")
    sync_parser.set_defaults(func=lambda args: sync.sync_to_host())

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
