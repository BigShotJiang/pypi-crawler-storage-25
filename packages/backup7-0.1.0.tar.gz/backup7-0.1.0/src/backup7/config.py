CONFIG_DIR = "/etc/backup7/backup-configs/"
