import sys
import platform
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor
import traceback
import time

from pathlib import Path

from . import config

if platform.system() != "Linux":
    print("❌ Only Linux is supported.")
    exit(1)


def create_config_dir(dir):
    if os.path.exists(dir):
        return

    def run(cmd):
        if not is_root:
            cmd.insert(0, "sudo")
        subprocess.run(cmd, check=True)

    is_root = (os.geteuid() == 0)
    try:
        # create directory
        run(["mkdir", "-p", dir])
        # set permissions (rwxr-xr-x = 755)
        run(["chmod", "777", dir])
    except subprocess.CalledProcessError:
        print(f"❌ Failed to setup directory: {dir}")
        sys.exit(1)


CONFIG_DIR = config.CONFIG_DIR

create_config_dir(CONFIG_DIR)

# -----------------------------
# CONFIG PARSER (STRICT + DEBUG)
# -----------------------------
def parse_config(path):
    config = {}
    mappings = []

    with open(path, "r") as f:
        lines = f.readlines()

    map_mode = False

    for i, raw_line in enumerate(lines, 1):
        line = raw_line.strip()

        if not line or line.startswith("#"):
            continue

        try:
            # start mapping section
            if line == "map_start":
                map_mode = True
                continue

            # ---------------- CONFIG ----------------
            if not map_mode:
                if "=" not in line:
                    raise ValueError("Missing '=' in config line")

                k, v = line.split("=", 1)

                k = k.strip()
                v = v.strip()

                if not k:
                    raise ValueError("Empty key")

                if not v:
                    raise ValueError(f"Empty or not {k}")

                config[k] = v

            # ---------------- MAPPING ----------------
            else:
                if "->" not in line:
                    raise ValueError("Missing '->' in mapping")

                src, dst = line.split("->", 1)

                src = src.strip()
                dst = dst.strip()

                if not src or not dst:
                    raise ValueError("Empty source or destination")

                if not src.startswith("/"):
                    raise ValueError("Remote path must be absolute")

                mappings.append((src, dst))

        except Exception as e:
            print("\n❌ CONFIG ERROR")
            print(f"File   : {path}")
            print(f"Line   : {i}")
            print(f"Content: {raw_line.strip()}")
            print(f"Error  : {e}\n")
            raise

    return config, mappings


# -----------------------------
# BUILD RSYNC COMMAND
# -----------------------------
def build_rsync(cfg, src, dst):
    user = cfg["USERNAME"]
    ip = cfg["IP"]
    port = cfg.get("PORT", "22")

    ssh_cmd = f"ssh -p {port}"
    os.makedirs(dst, exist_ok=True)
    dst_parent = Path(dst).parent # rsync copies dirs again

    return [
        "rsync",
        "-azP",
        "--info=progress2",
        "-e",
        ssh_cmd,
        f"{user}@{ip}:{src}",  # REMOTE
        dst_parent             # LOCAL
    ]


# -----------------------------
# RUN RSYNC JOB
# -----------------------------
def run_rsync(cmd, password, job_id, src, dst):
    try:
        print(f"\n[JOB {job_id}] START")
        print(f"FROM (REMOTE): {src}")
        print(f"TO   (LOCAL) : {dst}")

        full_cmd = cmd

        # optional password mode (NOT recommended)
        if password:
            full_cmd = ["sshpass", "-p", password] + cmd

        start = time.time()
        process = subprocess.Popen(
            full_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        for line in process.stdout:
            print(line, end="")

        duration = round(time.time() - start, 2)
        print(f"\n✅ JOB {job_id} DONE in {duration}s")

    except Exception:
        print(f"\n🔥 JOB {job_id} EXCEPTION")
        print(traceback.format_exc())


# -----------------------------
# PROCESS PROFILE
# -----------------------------
def process_profile(file_path):
    cfg, mappings = parse_config(file_path)

    output_dir = cfg.get("OUTPUT_DIR", ".")
    output_dir = os.path.abspath(output_dir)

    password = cfg.get("PASSWORD", "").strip()
    if password == "#":
        password = ""

    # ---------------- DEBUG INFO ----------------
    print("\n==============================")
    print("📦 PROFILE LOADED")
    print("==============================")

    print("📄 File       :", file_path)
    print("👤 USERNAME   :", cfg.get("USERNAME"))
    print("🌐 IP         :", cfg.get("IP"))
    print("🔌 PORT       :", cfg.get("PORT", "22"))
    print("📁 OUTPUT_DIR :", output_dir)
    print("🔑 PASSWORD   :", "SET" if password else "NOT SET")

    print("\n📌 MAPPINGS:")
    for i, (src, dst) in enumerate(mappings, 1):
        print(f"  {i}. {src}  ->  {dst}")

    print("==============================\n")

    # ---------------- BUILD JOBS ----------------
    jobs = []

    for idx, (remote_src, local_dst) in enumerate(mappings, 1):
        local_dst = os.path.join(output_dir, local_dst.lstrip("./"))

        cmd = build_rsync(cfg, remote_src, local_dst)

        jobs.append((cmd, password, idx, remote_src, local_dst))

    # ---------------- EXECUTE PARALLEL ----------------
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [
            executor.submit(run_rsync, cmd, pwd, job_id, src, dst)
            for cmd, pwd, job_id, src, dst in jobs
        ]

        for f in futures:
            f.result()


# -----------------------------
# MAIN ENTRY
# -----------------------------
def sync_to_host():
    if not os.path.exists(CONFIG_DIR):
        print("❌ Config folder not found:", CONFIG_DIR)
        return

    configs = os.listdir(CONFIG_DIR)

    if not configs:
        print(f"🚫 No config files found at {CONFIG_DIR}")
        return

    print("🚀 BACKUP ENGINE STARTED\n")

    for file in configs:
        path = os.path.join(CONFIG_DIR, file)

        if os.path.isfile(path):
            process_profile(path)
