# backup7

CLI tool to sync backups from remote servers via rsync.

## Installation

```bash
pip install backup7 --break-system-package
```

For system-wide installation:

```bash
sudo pip install backup7 --break-system-package
```

## Usage

### Generate Config

Create a new configuration file:

```bash
backup7 generate 
```

Example:

```bash
backup7 generate server1.conf
```

Edit the generated config file to set your server details.

### Sync Backups

```bash
backup7 sync
```

## Configuration Format

```
# Remote Server Configuration
USERNAME=ubuntu
IP=
PORT=22

# Password Authentication (NOT RECOMMENDED)
# Uncomment and set password to use password-based SSH authentication
PASSWORD=your_password_here

# OR Use SSH Key Authentication (RECOMMENDED)
# If set, this path is relative to the current working directory
# where the command is executed. Use absolute path for consistency.
# SSH_KEY_PATH=~/.ssh/id_rsa

# Local backup output directory (relative or absolute)
OUTPUT_DIR=./backup

# =============================================================================
# FILE MAPPINGS
# =============================================================================
# Format: /remote/path -> /local/path
# - Remote paths MUST be absolute (start with /)
# - Local paths are relative to OUTPUT_DIR
# =============================================================================
map_start
# /home/ubuntu/documents -> ./documents
# /home/ubuntu/pictures -> ./pictures
```

## Config Location

Config files are stored in `/etc/backup7/backup-configs/`

## Requirements

- rsync
- ssh
- SSH key or password access to remote server
