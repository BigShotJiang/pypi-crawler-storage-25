"""Shared mutable state for the daemon process."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import aiohttp.web
    from meeting_helper.buffer import SentenceBuffer


class AppState:
    """Thread-safe shared state for the running daemon."""

    def __init__(self) -> None:
        self.asyncio_loop: asyncio.AbstractEventLoop | None = None
        self.sentence_buffer: SentenceBuffer | None = None
        self.ws_clients: set[aiohttp.web.WebSocketResponse] = set()

        # Processing status (drives tray icon + overlay status dot)
        self.status: Literal["idle", "listening", "processing"] = "idle"

        # Last full AI response (sent to late-joining viewers)
        self.last_response: str = ""

        # Conversation history: list of {"role": "user"|"assistant", "content": ...}
        # Cleared between meetings, kept within a meeting across queries.
        self.conversation_history: list = []

        self.started_at: float = 0.0
        self.audio_active: bool = False
        self.shutdown_event: asyncio.Event | None = None

        # Meeting-specific
        self.meeting_info: object | None = None  # MeetingInfo from meeting_detector
        self.session_active: bool = False
        self.overlay_proc: object | None = None  # subprocess.Popen
        self.overlay_visible: bool = False

        # Current system prompt (can be rebuilt mid-session via workspace change)
        self.system_prompt: str = ""

        # When non-None, a past Claude Code conversation is attached as primary context.
        # AutoContextSelector skips while this is set; cleared on session stop.
        # Shape: {"session_id", "title", "repo", "attached_at", "chars", "truncated"}
        self.attached_conversation: dict | None = None

        # Proactive monitor + auto-context selector (set during active session, None otherwise)
        self.proactive_monitor: object | None = None
        self.auto_context_selector: object | None = None

        # Auto-context: low-level index + accumulated selection for current meeting
        self.auto_context_index: str = ""
        self.auto_context_selection: dict = {"repos": [], "knowledge": []}

        # MeetingSession instance (for manual start/stop)
        self.meeting_session: object | None = None

        # Current AI streaming task (for query cancellation)
        self.active_query: asyncio.Task | None = None

        # Info bar state (broadcast to overlay via "info" messages)
        self.transcriber_name: str = ""
        self.ai_model: str = ""


# Module-level singleton
state = AppState()
