"""Tests for neuroprobe.wrapper"""

import numpy as np
import pytest
import torch

from neuroprobe.wrapper import SyntheticEncoder


class TestSyntheticEncoder:
    def test_init(self):
        enc = SyntheticEncoder(feature_dim=64, n_vertices=128)
        assert enc.feature_dim == 64
        assert enc.n_vertices == 128

    def test_encode_numpy(self):
        enc = SyntheticEncoder(feature_dim=64)
        x = np.random.randn(5, 64).astype(np.float32)
        t = enc.encode_stimulus(x)
        assert isinstance(t, torch.Tensor)
        assert t.shape == (5, 64)

    def test_encode_tensor(self):
        enc = SyntheticEncoder(feature_dim=64)
        x = torch.randn(5, 64)
        t = enc.encode_stimulus(x)
        assert t.shape == (5, 64)

    def test_encode_bad_type(self):
        enc = SyntheticEncoder()
        with pytest.raises(TypeError):
            enc.encode_stimulus("not_a_tensor")

    def test_predict_shape(self):
        enc = SyntheticEncoder(feature_dim=64, n_vertices=128)
        x = torch.randn(5, 64)
        pred = enc.predict_from_features(x)
        assert pred.shape == (5, 128)

    def test_predict_differentiable(self):
        enc = SyntheticEncoder(feature_dim=64, n_vertices=128)
        x = torch.randn(5, 64, requires_grad=True)
        pred = enc.predict_from_features(x)
        loss = pred.sum()
        loss.backward()
        assert x.grad is not None
        assert x.grad.shape == (5, 64)

    def test_deterministic(self):
        enc = SyntheticEncoder(feature_dim=64, n_vertices=128, seed=0)
        x = torch.randn(3, 64)
        p1 = enc.predict_from_features(x)
        p2 = enc.predict_from_features(x)
        assert torch.allclose(p1, p2)

    def test_end_to_end(self):
        enc = SyntheticEncoder(feature_dim=64, n_vertices=128)
        x = np.random.randn(5, 64).astype(np.float32)
        pred = enc.predict(x)
        assert pred.shape == (5, 128)
