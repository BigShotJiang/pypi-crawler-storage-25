"""Tests for neuroprobe.regions"""

import numpy as np
import pytest

from neuroprobe.regions import N_VERTICES, roi_mask, roi_names


class TestRoiMask:
    def test_whole_brain(self):
        m = roi_mask("whole_brain")
        assert m.shape == (N_VERTICES,)
        assert m.all()

    def test_v1_is_subset(self):
        m = roi_mask("V1")
        assert m.shape == (N_VERTICES,)
        assert 0 < m.sum() < N_VERTICES

    def test_a1_is_subset(self):
        m = roi_mask("A1")
        assert 0 < m.sum() < N_VERTICES

    def test_v1_and_a1_dont_overlap(self):
        v1 = roi_mask("V1")
        a1 = roi_mask("A1")
        assert not np.any(v1 & a1)

    def test_unknown_region_raises(self):
        with pytest.raises(ValueError, match="Unknown region"):
            roi_mask("DOESNOTEXIST")

    def test_custom_n_vertices(self):
        m = roi_mask("whole_brain", n_vertices=100)
        assert m.shape == (100,)

    def test_small_mesh_clamps(self):
        # If n_vertices is smaller than ROI ranges, should not crash
        m = roi_mask("V1", n_vertices=100)
        assert m.shape == (100,)

    def test_bilateral(self):
        """Each ROI should have vertices in both hemispheres."""
        m = roi_mask("V1")
        left = m[:N_VERTICES // 2]
        right = m[N_VERTICES // 2:]
        assert left.sum() > 0
        assert right.sum() > 0


class TestRoiNames:
    def test_returns_list(self):
        names = roi_names()
        assert isinstance(names, list)
        assert "V1" in names
        assert "whole_brain" in names

    def test_at_least_10(self):
        assert len(roi_names()) >= 10
