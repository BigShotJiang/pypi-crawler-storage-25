"""Tests for neuroprobe.media and neuroprobe.stimulus_attacks."""

import numpy as np
import pytest
import torch

from neuroprobe._types import AttackResult, PerturbationBudget
from neuroprobe.media import (
    VideoEncoder,
    AudioEncoder,
    TextEncoder,
    MultiModalBrainModel,
    build_brain_model,
    synthesize_video,
    synthesize_audio,
    save_audio,
    load_audio,
    compute_psnr,
    compute_snr,
)
from neuroprobe.stimulus_attacks import VideoPGD, AudioPGD, TextPGD


N_V = 256
FEAT = 64


# ═══════════════════════════════════════════════════════════════════════════
# Encoders
# ═══════════════════════════════════════════════════════════════════════════


class TestVideoEncoder:
    def test_output_shape(self):
        enc = VideoEncoder(feature_dim=FEAT, seed=0)
        frames = torch.rand(5, 3, 32, 32)
        out = enc(frames)
        assert out.shape == (5, FEAT)

    def test_differentiable(self):
        enc = VideoEncoder(feature_dim=FEAT, seed=0)
        frames = torch.rand(3, 3, 32, 32, requires_grad=True)
        out = enc(frames)
        out.sum().backward()
        assert frames.grad is not None


class TestAudioEncoder:
    def test_output_shape(self):
        enc = AudioEncoder(feature_dim=FEAT, frame_size=160, hop_size=80, seed=0)
        wav = torch.rand(1600)
        out = enc(wav)
        assert out.shape[1] == FEAT
        assert out.shape[0] > 0

    def test_differentiable(self):
        enc = AudioEncoder(feature_dim=FEAT, frame_size=160, hop_size=80, seed=0)
        wav = torch.rand(800, requires_grad=True)
        out = enc(wav)
        out.sum().backward()
        assert wav.grad is not None

    def test_short_waveform(self):
        enc = AudioEncoder(feature_dim=FEAT, frame_size=400, hop_size=160, seed=0)
        wav = torch.rand(100)
        out = enc(wav)
        assert out.shape[1] == FEAT
        assert out.shape[0] >= 1


class TestTextEncoder:
    def test_output_shape(self):
        enc = TextEncoder(vocab_size=200, feature_dim=FEAT, seed=0)
        ids = torch.tensor([1, 5, 10, 3], dtype=torch.long)
        out = enc(ids)
        assert out.shape == (4, FEAT)

    def test_nearest_tokens(self):
        enc = TextEncoder(vocab_size=200, feature_dim=FEAT, seed=0)
        ids = torch.tensor([5, 10], dtype=torch.long)
        emb = enc(ids)
        recovered = enc.nearest_tokens(emb)
        assert recovered.tolist() == [5, 10]


# ═══════════════════════════════════════════════════════════════════════════
# End-to-end model
# ═══════════════════════════════════════════════════════════════════════════


class TestMultiModalBrainModel:
    def test_video_end_to_end(self):
        model = build_brain_model("video", feature_dim=FEAT, n_vertices=N_V, seed=0)
        frames = torch.rand(3, 3, 32, 32)
        pred = model.predict(frames)
        assert pred.shape == (3, N_V)

    def test_audio_end_to_end(self):
        model = build_brain_model("audio", feature_dim=FEAT, n_vertices=N_V, seed=0)
        wav = torch.rand(1600)
        pred = model.predict(wav)
        assert pred.shape[1] == N_V

    def test_text_end_to_end(self):
        model = build_brain_model(
            "text", feature_dim=FEAT, n_vertices=N_V, seed=0, vocab_size=200
        )
        ids = torch.tensor([1, 5, 10], dtype=torch.long)
        pred = model.predict(ids)
        assert pred.shape == (3, N_V)

    def test_video_differentiable(self):
        model = build_brain_model("video", feature_dim=FEAT, n_vertices=N_V, seed=0)
        frames = torch.rand(2, 3, 32, 32, requires_grad=True)
        pred = model.predict(frames)
        pred.sum().backward()
        assert frames.grad is not None


# ═══════════════════════════════════════════════════════════════════════════
# Media helpers
# ═══════════════════════════════════════════════════════════════════════════


class TestSynthesizeMedia:
    def test_video_shape(self):
        v = synthesize_video(5, 32, 32, seed=0)
        assert v.shape == (5, 3, 32, 32)
        assert v.min() >= 0 and v.max() <= 1

    def test_audio_shape(self):
        a = synthesize_audio(0.5, 16000, seed=0)
        assert a.shape == (8000,)
        assert a.min() >= -1 and a.max() <= 1


class TestAudioIO:
    def test_round_trip(self, tmp_path):
        wav = synthesize_audio(0.1, 16000, seed=0)
        path = str(tmp_path / "test.wav")
        save_audio(wav, path, 16000)
        loaded, sr = load_audio(path)
        assert sr == 16000
        assert loaded.shape == wav.shape
        # int16 quantisation → small error
        assert (loaded - wav).abs().max() < 0.001


class TestMetrics:
    def test_psnr_identical(self):
        x = torch.rand(10)
        assert compute_psnr(x, x) == float("inf")

    def test_psnr_finite(self):
        x = torch.rand(100)
        y = x + 0.01 * torch.randn(100)
        p = compute_psnr(x, y)
        assert 10 < p < 100

    def test_snr(self):
        sig = torch.rand(100)
        noise = 0.001 * torch.randn(100)
        s = compute_snr(sig, noise)
        assert s > 20


# ═══════════════════════════════════════════════════════════════════════════
# Stimulus attacks
# ═══════════════════════════════════════════════════════════════════════════


class TestVideoPGD:
    @pytest.fixture
    def model(self):
        return build_brain_model("video", feature_dim=FEAT, n_vertices=N_V, seed=0)

    def test_produces_adversarial_video(self, model):
        frames = synthesize_video(3, 32, 32, seed=0)
        adv, result = VideoPGD(model, n_steps=5).attack(frames)
        assert adv.shape == frames.shape
        assert isinstance(result, AttackResult)
        assert result.brain_shift > 0

    def test_pixels_in_range(self, model):
        frames = synthesize_video(3, 32, 32, seed=0)
        adv, _ = VideoPGD(model, n_steps=5).attack(frames)
        assert adv.min() >= 0.0
        assert adv.max() <= 1.0

    def test_within_budget(self, model):
        budget = PerturbationBudget(epsilon=0.02, norm="linf")
        frames = synthesize_video(3, 32, 32, seed=0)
        adv, result = VideoPGD(model, budget=budget, n_steps=5).attack(frames)
        assert result.linf_distance <= budget.epsilon + 1e-5

    def test_with_target_regions(self, model):
        frames = synthesize_video(3, 32, 32, seed=0)
        adv, result = VideoPGD(
            model, n_steps=5, target_regions=["FFA"]
        ).attack(frames)
        assert result.brain_shift > 0

    def test_psnr_high(self, model):
        frames = synthesize_video(3, 32, 32, seed=0)
        adv, _ = VideoPGD(
            model, budget=PerturbationBudget(epsilon=0.01), n_steps=5
        ).attack(frames)
        psnr = compute_psnr(frames, adv)
        assert psnr > 30


class TestAudioPGD:
    @pytest.fixture
    def model(self):
        return build_brain_model("audio", feature_dim=FEAT, n_vertices=N_V, seed=0)

    def test_produces_adversarial_audio(self, model):
        wav = synthesize_audio(0.1, 16000, seed=0)
        adv, result = AudioPGD(model, n_steps=5).attack(wav)
        assert adv.shape == wav.shape
        assert isinstance(result, AttackResult)
        assert result.brain_shift > 0

    def test_waveform_in_range(self, model):
        wav = synthesize_audio(0.1, 16000, seed=0)
        adv, _ = AudioPGD(model, n_steps=5).attack(wav)
        assert adv.min() >= -1.0
        assert adv.max() <= 1.0

    def test_within_budget(self, model):
        budget = PerturbationBudget(epsilon=0.01, norm="linf")
        wav = synthesize_audio(0.1, 16000, seed=0)
        _, result = AudioPGD(model, budget=budget, n_steps=5).attack(wav)
        assert result.linf_distance <= budget.epsilon + 1e-5

    def test_with_target_regions(self, model):
        wav = synthesize_audio(0.1, 16000, seed=0)
        adv, result = AudioPGD(
            model, n_steps=5, target_regions=["V1"]
        ).attack(wav)
        assert result.brain_shift > 0

    def test_snr_high(self, model):
        wav = synthesize_audio(0.1, 16000, seed=0)
        adv, _ = AudioPGD(
            model, budget=PerturbationBudget(epsilon=0.005), n_steps=5
        ).attack(wav)
        snr = compute_snr(wav, adv - wav)
        assert snr > 20


class TestTextPGD:
    @pytest.fixture
    def vocabulary(self):
        return ["pad", "the", "cat", "sat", "on", "mat", "dog", "ran",
                "big", "small", "red", "blue", "in", "by", "is", "was",
                "hot", "cold", "old", "new", "up", "down", "here", "there"]

    @pytest.fixture
    def model(self, vocabulary):
        return build_brain_model(
            "text", feature_dim=FEAT, n_vertices=N_V, seed=0,
            vocab_size=len(vocabulary),
        )

    def test_produces_adversarial_text(self, model, vocabulary):
        ids = torch.tensor([1, 2, 3, 4, 1, 5], dtype=torch.long)
        adv_ids, result, text = TextPGD(
            model, budget=PerturbationBudget(epsilon=5.0, norm="l2"), n_steps=30,
        ).attack(ids, vocabulary)
        assert adv_ids.shape == ids.shape
        assert isinstance(result, AttackResult)
        assert text is not None

    def test_tokens_in_vocab(self, model, vocabulary):
        ids = torch.tensor([1, 2, 3], dtype=torch.long)
        adv_ids, _, _ = TextPGD(model, n_steps=5).attack(ids, vocabulary)
        assert all(0 <= t < len(vocabulary) for t in adv_ids.tolist())

    def test_with_target_regions(self, model, vocabulary):
        ids = torch.tensor([1, 2, 3, 4], dtype=torch.long)
        _, result, _ = TextPGD(
            model, budget=PerturbationBudget(epsilon=5.0, norm="l2"),
            n_steps=20, target_regions=["motor"]
        ).attack(ids, vocabulary)
        assert isinstance(result, AttackResult)

    def test_without_vocabulary(self, model):
        ids = torch.tensor([1, 2, 3], dtype=torch.long)
        adv_ids, result, text = TextPGD(
            model, budget=PerturbationBudget(epsilon=5.0, norm="l2"), n_steps=20,
        ).attack(ids)
        assert text is None
        assert isinstance(result, AttackResult)
