"""Tests for neuroprobe.attacks — all five attack types."""

import numpy as np
import pytest
import torch

from neuroprobe._types import AttackResult, PerturbationBudget
from neuroprobe.attacks import (
    BrainFGSM,
    BrainPGD,
    CrossModalConfusion,
    RegionTargeted,
    UniversalBrainPerturbation,
)
from neuroprobe.wrapper import SyntheticEncoder


@pytest.fixture
def model():
    return SyntheticEncoder(feature_dim=64, n_vertices=256, seed=0)


@pytest.fixture
def features():
    rng = np.random.RandomState(0)
    return torch.tensor(rng.randn(5, 64).astype(np.float32))


@pytest.fixture
def budget():
    return PerturbationBudget(epsilon=0.05, norm="linf")


# ═══════════════════════════════════════════════════════════════════════════
# FGSM
# ═══════════════════════════════════════════════════════════════════════════


class TestBrainFGSM:
    def test_returns_attack_result(self, model, features, budget):
        attacker = BrainFGSM(model, budget=budget)
        result = attacker.attack(features)
        assert isinstance(result, AttackResult)

    def test_brain_shift_positive(self, model, features, budget):
        result = BrainFGSM(model, budget=budget).attack(features)
        assert result.brain_shift > 0

    def test_perturbation_within_budget(self, model, features, budget):
        result = BrainFGSM(model, budget=budget).attack(features)
        assert result.linf_distance <= budget.epsilon + 1e-6

    def test_attack_name(self, model, features, budget):
        result = BrainFGSM(model, budget=budget).attack(features)
        assert result.attack_name == "BrainFGSM"

    def test_iterations_is_one(self, model, features, budget):
        result = BrainFGSM(model, budget=budget).attack(features)
        assert result.iterations == 1

    def test_with_target_regions(self, model, features, budget):
        attacker = BrainFGSM(model, budget=budget, target_regions=["V1"])
        result = attacker.attack(features)
        assert result.brain_shift > 0

    def test_l2_norm(self, model, features):
        budget_l2 = PerturbationBudget(epsilon=1.0, norm="l2")
        result = BrainFGSM(model, budget=budget_l2).attack(features)
        assert result.brain_shift > 0


# ═══════════════════════════════════════════════════════════════════════════
# PGD
# ═══════════════════════════════════════════════════════════════════════════


class TestBrainPGD:
    def test_returns_attack_result(self, model, features, budget):
        result = BrainPGD(model, budget=budget, n_steps=5).attack(features)
        assert isinstance(result, AttackResult)

    def test_stronger_than_fgsm(self, model, features, budget):
        fgsm_result = BrainFGSM(model, budget=budget).attack(features)
        pgd_result = BrainPGD(model, budget=budget, n_steps=20).attack(features)
        # PGD should generally find better adversarial examples
        assert pgd_result.brain_shift >= fgsm_result.brain_shift * 0.5

    def test_within_budget(self, model, features, budget):
        result = BrainPGD(model, budget=budget, n_steps=10).attack(features)
        assert result.linf_distance <= budget.epsilon + 1e-6

    def test_no_random_start(self, model, features, budget):
        result = BrainPGD(model, budget=budget, n_steps=5, random_start=False).attack(features)
        assert result.brain_shift > 0

    def test_iterations_tracked(self, model, features, budget):
        result = BrainPGD(model, budget=budget, n_steps=7).attack(features)
        assert result.iterations == 7

    def test_region_shifts_populated(self, model, features, budget):
        result = BrainPGD(model, budget=budget, n_steps=5).attack(features)
        assert len(result.region_shifts) > 0

    def test_l2_budget(self, model, features):
        budget_l2 = PerturbationBudget(epsilon=2.0, norm="l2")
        result = BrainPGD(model, budget=budget_l2, n_steps=5).attack(features)
        assert result.brain_shift > 0

    def test_larger_epsilon_larger_shift(self, model, features):
        small = BrainPGD(model, budget=PerturbationBudget(epsilon=0.01), n_steps=10).attack(features)
        large = BrainPGD(model, budget=PerturbationBudget(epsilon=0.1), n_steps=10).attack(features)
        # With more budget, attack should be stronger
        assert large.brain_shift >= small.brain_shift * 0.8


# ═══════════════════════════════════════════════════════════════════════════
# Region-Targeted
# ═══════════════════════════════════════════════════════════════════════════


class TestRegionTargeted:
    def test_returns_result(self, model, features):
        attacker = RegionTargeted(
            model, target_region="V1",
            budget=PerturbationBudget(epsilon=0.1),
            n_steps=10,
        )
        result = attacker.attack(features)
        assert isinstance(result, AttackResult)

    def test_attack_name_includes_region(self, model, features):
        attacker = RegionTargeted(model, target_region="FFA", n_steps=5)
        result = attacker.attack(features)
        assert "FFA" in result.attack_name

    def test_brain_shift_positive(self, model, features):
        attacker = RegionTargeted(model, target_region="A1", n_steps=10)
        result = attacker.attack(features)
        assert result.brain_shift > 0

    def test_with_suppress_regions(self, model, features):
        attacker = RegionTargeted(
            model, target_region="V1",
            suppress_regions=["A1", "STG"],
            n_steps=5,
        )
        result = attacker.attack(features)
        assert isinstance(result, AttackResult)


# ═══════════════════════════════════════════════════════════════════════════
# Cross-Modal Confusion
# ═══════════════════════════════════════════════════════════════════════════


class TestCrossModalConfusion:
    def test_visual_to_auditory(self, model, features):
        attacker = CrossModalConfusion(model, source_modality="visual", n_steps=10)
        result = attacker.attack(features)
        assert isinstance(result, AttackResult)
        assert "visual" in result.attack_name

    def test_auditory_to_visual(self, model, features):
        attacker = CrossModalConfusion(model, source_modality="auditory", n_steps=10)
        result = attacker.attack(features)
        assert "auditory" in result.attack_name

    def test_with_target_pattern(self, model, features):
        target = torch.zeros(5, 256)
        attacker = CrossModalConfusion(model, n_steps=5)
        result = attacker.attack(features, target_pattern=target)
        assert result.brain_shift > 0


# ═══════════════════════════════════════════════════════════════════════════
# Universal Adversarial Perturbation
# ═══════════════════════════════════════════════════════════════════════════


class TestUniversalBrainPerturbation:
    def test_fit_and_attack(self, model, features):
        uap = UniversalBrainPerturbation(model, n_epochs=2)
        stimuli = [features, features + 0.1 * torch.randn_like(features)]
        delta = uap.fit(stimuli)
        assert delta.shape == (1, 64)

        result = uap.attack(features)
        assert isinstance(result, AttackResult)

    def test_attack_before_fit_raises(self, model, features):
        uap = UniversalBrainPerturbation(model)
        with pytest.raises(RuntimeError, match="Call .fit"):
            uap.attack(features)

    def test_empty_stimuli_raises(self, model):
        uap = UniversalBrainPerturbation(model)
        with pytest.raises(ValueError, match="at least one"):
            uap.fit([])

    def test_transfers_to_unseen(self, model):
        rng = np.random.RandomState(42)
        train = [torch.tensor(rng.randn(5, 64).astype(np.float32)) for _ in range(3)]
        test = torch.tensor(rng.randn(5, 64).astype(np.float32))

        uap = UniversalBrainPerturbation(model, n_epochs=3)
        uap.fit(train)
        result = uap.attack(test)
        # Universal perturbation should cause *some* shift on unseen data
        assert result.brain_shift > 0

    def test_perturbation_within_budget(self, model, features):
        budget = PerturbationBudget(epsilon=0.05)
        uap = UniversalBrainPerturbation(model, budget=budget, n_epochs=2)
        uap.fit([features])
        delta = uap.universal_delta
        assert delta is not None
        assert delta.abs().max().item() <= budget.epsilon + 1e-5
