"""Tests for neuroprobe.analysis"""

import numpy as np
import pytest
import torch

from neuroprobe._types import PerturbationBudget
from neuroprobe.analysis import (
    robustness_curve,
    region_vulnerability_map,
    transferability_matrix,
)
from neuroprobe.wrapper import SyntheticEncoder


@pytest.fixture
def model():
    return SyntheticEncoder(feature_dim=32, n_vertices=128, seed=0)


@pytest.fixture
def stimuli():
    rng = np.random.RandomState(0)
    return [torch.tensor(rng.randn(3, 32).astype(np.float32)) for _ in range(3)]


class TestRobustnessCurve:
    def test_returns_dict(self, model, stimuli):
        result = robustness_curve(model, stimuli, epsilons=[0.01, 0.05], n_steps=3)
        assert isinstance(result, dict)
        assert len(result) == 2

    def test_shift_increases_with_epsilon(self, model, stimuli):
        result = robustness_curve(model, stimuli, epsilons=[0.01, 0.1], n_steps=5)
        shifts = [r.mean_brain_shift for r in result.values()]
        # Larger epsilon should generally cause more shift
        assert shifts[1] >= shifts[0] * 0.5

    def test_reports_have_regions(self, model, stimuli):
        result = robustness_curve(model, stimuli, epsilons=[0.05], n_steps=3)
        report = list(result.values())[0]
        assert report.most_vulnerable_region != ""


class TestRegionVulnerabilityMap:
    def test_returns_dict(self, model, stimuli):
        result = region_vulnerability_map(model, stimuli[:1], n_steps=3)
        assert isinstance(result, dict)
        assert len(result) > 0

    def test_sorted_descending(self, model, stimuli):
        result = region_vulnerability_map(model, stimuli[:1], n_steps=3)
        values = list(result.values())
        # Should be sorted descending
        for i in range(len(values) - 1):
            assert values[i] >= values[i + 1] - 1e-6


class TestTransferabilityMatrix:
    def test_shape(self, stimuli):
        m1 = SyntheticEncoder(feature_dim=32, n_vertices=128, seed=0)
        m2 = SyntheticEncoder(feature_dim=32, n_vertices=128, seed=99)
        models = {"m1": m1, "m2": m2}
        mat = transferability_matrix(models, stimuli[:2], n_steps=3)
        assert mat.shape == (2, 2)

    def test_diagonal_strongest(self, stimuli):
        m1 = SyntheticEncoder(feature_dim=32, n_vertices=128, seed=0)
        m2 = SyntheticEncoder(feature_dim=32, n_vertices=128, seed=99)
        models = {"m1": m1, "m2": m2}
        mat = transferability_matrix(models, stimuli[:2], n_steps=5)
        # Attacks should be strongest on the source model (diagonal)
        for i in range(len(models)):
            assert mat[i, i] >= 0
