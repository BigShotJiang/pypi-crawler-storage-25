"""Tests for neuroprobe._types"""

import pytest
from neuroprobe._types import (
    AttackResult,
    BrainRegion,
    PerturbationBudget,
    RobustnessReport,
)


class TestPerturbationBudget:
    def test_defaults(self):
        b = PerturbationBudget()
        assert b.epsilon == 0.03
        assert b.norm == "linf"
        assert b.step_size == 0.03 / 4.0

    def test_custom_step_size(self):
        b = PerturbationBudget(epsilon=0.1, step_size=0.01)
        assert b.step_size == 0.01

    def test_auto_step_size(self):
        b = PerturbationBudget(epsilon=0.08)
        assert b.step_size == pytest.approx(0.02)

    def test_bad_norm(self):
        with pytest.raises(ValueError, match="Unsupported norm"):
            PerturbationBudget(norm="l42")

    def test_l2_norm(self):
        b = PerturbationBudget(norm="l2")
        assert b.norm == "l2"

    def test_l1_norm(self):
        b = PerturbationBudget(norm="l1")
        assert b.norm == "l1"


class TestBrainRegion:
    def test_all_regions(self):
        assert len(BrainRegion) >= 14

    def test_v1(self):
        assert BrainRegion.V1.value == "V1"

    def test_whole_brain(self):
        assert BrainRegion.WHOLE_BRAIN.value == "whole_brain"


class TestAttackResult:
    def test_defaults(self):
        ar = AttackResult(
            original_prediction=None,
            adversarial_prediction=None,
            perturbation=None,
            original_input=None,
            adversarial_input=None,
        )
        assert ar.brain_shift == 0.0
        assert ar.region_shifts == {}
        assert ar.attack_name == ""

    def test_with_values(self):
        ar = AttackResult(
            original_prediction="a",
            adversarial_prediction="b",
            perturbation="c",
            original_input="d",
            adversarial_input="e",
            brain_shift=1.5,
            region_shifts={"V1": 2.0},
            attack_name="test",
        )
        assert ar.brain_shift == 1.5
        assert ar.region_shifts["V1"] == 2.0


class TestRobustnessReport:
    def test_summary(self):
        budget = PerturbationBudget(epsilon=0.05)
        report = RobustnessReport(
            model_name="TestModel",
            n_stimuli=10,
            attack_name="PGD",
            budget=budget,
            mean_brain_shift=0.05,
            max_brain_shift=0.12,
            most_vulnerable_region="V1",
            most_robust_region="PFC",
        )
        s = report.summary()
        assert "TestModel" in s
        assert "0.05" in s
        assert "V1" in s
