"""neuroprobe — Adversarial robustness testing for neural encoding models."""

__version__ = "0.2.0"

from neuroprobe._types import (
    AttackResult,
    BrainRegion,
    PerturbationBudget,
    RobustnessReport,
)
from neuroprobe.attacks import (
    BrainPGD,
    BrainFGSM,
    RegionTargeted,
    CrossModalConfusion,
    UniversalBrainPerturbation,
)
from neuroprobe.analysis import (
    robustness_curve,
    region_vulnerability_map,
    transferability_matrix,
)
from neuroprobe.media import (
    VideoEncoder,
    AudioEncoder,
    TextEncoder,
    MultiModalBrainModel,
    build_brain_model,
    synthesize_video,
    synthesize_audio,
    save_audio,
    load_audio,
    compute_psnr,
    compute_snr,
)
from neuroprobe.stimulus_attacks import (
    VideoPGD,
    AudioPGD,
    TextPGD,
)
from neuroprobe.wrapper import SyntheticEncoder

__all__ = [
    "AttackResult",
    "BrainRegion",
    "PerturbationBudget",
    "RobustnessReport",
    "BrainPGD",
    "BrainFGSM",
    "RegionTargeted",
    "CrossModalConfusion",
    "UniversalBrainPerturbation",
    "robustness_curve",
    "region_vulnerability_map",
    "transferability_matrix",
    "VideoEncoder",
    "AudioEncoder",
    "TextEncoder",
    "MultiModalBrainModel",
    "build_brain_model",
    "synthesize_video",
    "synthesize_audio",
    "save_audio",
    "load_audio",
    "compute_psnr",
    "compute_snr",
    "VideoPGD",
    "AudioPGD",
    "TextPGD",
    "SyntheticEncoder",
]
