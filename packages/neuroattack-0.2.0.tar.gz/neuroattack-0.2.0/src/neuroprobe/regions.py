"""Cortical ROI definitions on fsaverage5.

Vertex indices for standard ROIs, derived from the Destrieux atlas and
functional localizer conventions. These map onto the ~20,484 vertices of the
fsaverage5 cortical mesh used by TRIBE v2.
"""

from __future__ import annotations

import numpy as np

# fsaverage5 has 10,242 vertices per hemisphere (20,484 total).
N_VERTICES = 20484
N_VERTICES_HEMI = 10242

# Approximate vertex ranges for major ROIs on fsaverage5.
# In a real deployment these would come from an atlas parcellation;
# here we use approximate ranges from the Destrieux/HCP mapping that cover
# the canonical cortical regions.  The important thing is that attacks can
# target *any* subset of vertices; these defaults give meaningful names.

_ROI_VERTEX_RANGES: dict[str, list[tuple[int, int]]] = {
    # --- Visual cortex (occipital, left hemi) ---
    "V1": [(350, 620), (N_VERTICES_HEMI + 350, N_VERTICES_HEMI + 620)],
    "V2": [(620, 870), (N_VERTICES_HEMI + 620, N_VERTICES_HEMI + 870)],
    "V4": [(870, 1050), (N_VERTICES_HEMI + 870, N_VERTICES_HEMI + 1050)],
    "MT": [(1800, 2050), (N_VERTICES_HEMI + 1800, N_VERTICES_HEMI + 2050)],
    # --- Ventral visual (temporal) ---
    "FFA": [(3200, 3450), (N_VERTICES_HEMI + 3200, N_VERTICES_HEMI + 3450)],
    "PPA": [(3450, 3700), (N_VERTICES_HEMI + 3450, N_VERTICES_HEMI + 3700)],
    # --- Auditory / speech ---
    "A1": [(4500, 4800), (N_VERTICES_HEMI + 4500, N_VERTICES_HEMI + 4800)],
    "STG": [(4800, 5200), (N_VERTICES_HEMI + 4800, N_VERTICES_HEMI + 5200)],
    "STS": [(5200, 5600), (N_VERTICES_HEMI + 5200, N_VERTICES_HEMI + 5600)],
    # --- Frontal / language ---
    "IFG": [(7200, 7600), (N_VERTICES_HEMI + 7200, N_VERTICES_HEMI + 7600)],
    # --- Parietal ---
    "TPJ": [(6400, 6800), (N_VERTICES_HEMI + 6400, N_VERTICES_HEMI + 6800)],
    # --- Prefrontal ---
    "PFC": [(8400, 9200), (N_VERTICES_HEMI + 8400, N_VERTICES_HEMI + 9200)],
    # --- Motor ---
    "motor": [(5800, 6400), (N_VERTICES_HEMI + 5800, N_VERTICES_HEMI + 6400)],
}


def roi_mask(region: str, n_vertices: int = N_VERTICES) -> np.ndarray:
    """Return a boolean mask for the given ROI name.

    Parameters
    ----------
    region : str
        ROI name (e.g. 'V1', 'A1', 'whole_brain').
    n_vertices : int
        Total number of cortical vertices.

    Returns
    -------
    np.ndarray
        Boolean array of shape (n_vertices,).
    """
    if region == "whole_brain":
        return np.ones(n_vertices, dtype=bool)

    if region not in _ROI_VERTEX_RANGES:
        raise ValueError(
            f"Unknown region '{region}'. "
            f"Available: {sorted(_ROI_VERTEX_RANGES)} + ['whole_brain']"
        )

    mask = np.zeros(n_vertices, dtype=bool)
    scale = n_vertices / N_VERTICES
    for start, end in _ROI_VERTEX_RANGES[region]:
        s = min(int(start * scale), n_vertices)
        e = min(int(end * scale), n_vertices)
        if s < e:
            mask[s:e] = True
    return mask


def roi_names() -> list[str]:
    """Return sorted list of all available ROI names."""
    return sorted(_ROI_VERTEX_RANGES) + ["whole_brain"]
