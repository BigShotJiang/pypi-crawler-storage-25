"""End-to-end adversarial attacks that produce actual media files.

Unlike the feature-space attacks in ``attacks.py``, these operate directly
on raw stimuli (video frames, audio waveforms, text tokens) and produce
adversarial media that can be played, viewed, or read.

Gradient flows through the full pipeline::

    stimulus → encoder → features → brain head → BOLD prediction
    ← ← ← ← ← ← ← ← gradients ← ← ← ← ← ← ← ← ← ← ←
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
import torch

from neuroprobe._types import AttackResult, PerturbationBudget
from neuroprobe.attacks import (
    _project_perturbation,
    _compute_brain_shift,
    _compute_region_shifts,
)
from neuroprobe.media import MultiModalBrainModel, TextEncoder
from neuroprobe.regions import roi_mask


def _build_roi_weight(
    target_regions: Sequence[str] | None,
    n_v: int,
    device: torch.device,
) -> torch.Tensor:
    if not target_regions:
        return torch.ones(n_v, device=device)
    combined = np.zeros(n_v, dtype=np.float32)
    for r in target_regions:
        combined += roi_mask(r, n_v).astype(np.float32)
    return torch.tensor(np.clip(combined, 0, 1), device=device)


def _make_stimulus_result(
    clean_input: torch.Tensor,
    adv_input: torch.Tensor,
    clean_pred: torch.Tensor,
    adv_pred: torch.Tensor,
    delta: torch.Tensor,
    iterations: int,
    converged: bool,
    attack_name: str,
    n_vertices: int,
) -> AttackResult:
    flat = delta.detach().cpu().numpy().ravel()
    return AttackResult(
        original_prediction=clean_pred.detach().cpu().numpy(),
        adversarial_prediction=adv_pred.detach().cpu().numpy(),
        perturbation=delta.detach().cpu().numpy(),
        original_input=clean_input.detach().cpu().numpy(),
        adversarial_input=adv_input.detach().cpu().numpy(),
        l2_distance=float(np.linalg.norm(flat)),
        linf_distance=float(np.max(np.abs(flat))),
        brain_shift=_compute_brain_shift(clean_pred, adv_pred),
        region_shifts=_compute_region_shifts(clean_pred, adv_pred, n_vertices),
        iterations=iterations,
        converged=converged,
        attack_name=attack_name,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Video PGD
# ═══════════════════════════════════════════════════════════════════════════


class VideoPGD:
    """PGD on raw video frames → adversarial video with imperceptible
    pixel perturbations that cause the brain model to predict dramatically
    different cortical activity.

    Parameters
    ----------
    model : MultiModalBrainModel
        End-to-end video → BOLD model.
    budget : PerturbationBudget
        Pixel-space budget.  ε=0.02 ≈ 5/255 pixel change (imperceptible).
    n_steps : int
        PGD iterations.
    target_regions : list of str, optional
        Cortical ROIs to maximally disrupt (e.g. ``['FFA']``).
    """

    def __init__(
        self,
        model: MultiModalBrainModel,
        budget: PerturbationBudget | None = None,
        n_steps: int = 100,
        target_regions: Sequence[str] | None = None,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget(epsilon=0.02, norm="linf")
        self.n_steps = n_steps
        self.target_regions = target_regions

    def attack(
        self, frames: torch.Tensor
    ) -> tuple[torch.Tensor, AttackResult]:
        """Attack video frames (T, 3, H, W) in [0, 1].

        Returns (adversarial_frames, AttackResult).
        """
        x = frames.detach().clone()
        with torch.no_grad():
            clean_pred = self.model.predict(x)

        n_v = clean_pred.shape[-1]
        w = _build_roi_weight(self.target_regions, n_v, clean_pred.device)

        delta = torch.empty_like(x).uniform_(
            -self.budget.epsilon, self.budget.epsilon
        )
        delta = _project_perturbation(delta, self.budget)
        step = self.budget.step_size or self.budget.epsilon * 2.5 / max(self.n_steps, 1)
        best_shift = 0.0
        best_delta = delta.clone()

        for _ in range(self.n_steps):
            delta.requires_grad_(True)
            pred = self.model.predict((x + delta).clamp(0, 1))
            loss = ((pred - clean_pred) * w.unsqueeze(0)).pow(2).mean()
            loss.backward()

            with torch.no_grad():
                delta = delta + step * delta.grad.sign()
                delta = _project_perturbation(delta, self.budget)
                delta = torch.max(delta, -x)
                delta = torch.min(delta, 1.0 - x)

                shift = _compute_brain_shift(
                    clean_pred,
                    self.model.predict((x + delta).clamp(0, 1)),
                )
                if shift > best_shift:
                    best_shift = shift
                    best_delta = delta.clone()

        adv = (x + best_delta).clamp(0, 1).detach()
        with torch.no_grad():
            adv_pred = self.model.predict(adv)
        result = _make_stimulus_result(
            x, adv, clean_pred, adv_pred, best_delta,
            self.n_steps, best_shift > 0, "VideoPGD", n_v,
        )
        return adv, result


# ═══════════════════════════════════════════════════════════════════════════
# Audio PGD
# ═══════════════════════════════════════════════════════════════════════════


class AudioPGD:
    """PGD on raw audio waveform → adversarial WAV with inaudible
    perturbations that cause targeted brain activation changes.

    Parameters
    ----------
    model : MultiModalBrainModel
        End-to-end audio → BOLD model.
    budget : PerturbationBudget
        Waveform-space budget.  ε=0.01 → ~-40 dB perturbation.
    """

    def __init__(
        self,
        model: MultiModalBrainModel,
        budget: PerturbationBudget | None = None,
        n_steps: int = 100,
        target_regions: Sequence[str] | None = None,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget(epsilon=0.03, norm="linf")
        self.n_steps = n_steps
        self.target_regions = target_regions

    def attack(
        self, waveform: torch.Tensor
    ) -> tuple[torch.Tensor, AttackResult]:
        """Attack waveform (samples,) in [-1, 1].

        Returns (adversarial_waveform, AttackResult).
        """
        x = waveform.detach().clone()
        with torch.no_grad():
            clean_pred = self.model.predict(x)

        n_v = clean_pred.shape[-1]
        w = _build_roi_weight(self.target_regions, n_v, clean_pred.device)

        delta = torch.empty_like(x).uniform_(
            -self.budget.epsilon, self.budget.epsilon
        )
        delta = _project_perturbation(delta, self.budget)
        step = self.budget.step_size or self.budget.epsilon * 2.5 / max(self.n_steps, 1)
        best_shift = 0.0
        best_delta = delta.clone()

        for _ in range(self.n_steps):
            delta.requires_grad_(True)
            pred = self.model.predict((x + delta).clamp(-1, 1))
            loss = ((pred - clean_pred) * w.unsqueeze(0)).pow(2).mean()
            loss.backward()

            with torch.no_grad():
                delta = delta + step * delta.grad.sign()
                delta = _project_perturbation(delta, self.budget)
                delta = torch.max(delta, -1.0 - x)
                delta = torch.min(delta, 1.0 - x)

                shift = _compute_brain_shift(
                    clean_pred,
                    self.model.predict((x + delta).clamp(-1, 1)),
                )
                if shift > best_shift:
                    best_shift = shift
                    best_delta = delta.clone()

        adv = (x + best_delta).clamp(-1, 1).detach()
        with torch.no_grad():
            adv_pred = self.model.predict(adv)
        result = _make_stimulus_result(
            x, adv, clean_pred, adv_pred, best_delta,
            self.n_steps, best_shift > 0, "AudioPGD", n_v,
        )
        return adv, result


# ═══════════════════════════════════════════════════════════════════════════
# Text PGD (embedding-space → nearest tokens)
# ═══════════════════════════════════════════════════════════════════════════


class TextPGD:
    """Adversarial text generation via greedy token substitution guided
    by gradient signals from the brain model.

    For each token position, computes gradient-based scores over the
    vocabulary, then greedily substitutes tokens that maximally shift
    predicted brain activity in target regions.

    Parameters
    ----------
    model : MultiModalBrainModel
        Must use a ``TextEncoder`` as its encoder.
    budget : PerturbationBudget
        Controls max number of tokens changed: ``int(epsilon)`` positions.
    n_steps : int
        Number of greedy substitution rounds.
    target_regions : list of str, optional
        Cortical ROIs to target.
    """

    def __init__(
        self,
        model: MultiModalBrainModel,
        budget: PerturbationBudget | None = None,
        n_steps: int = 50,
        target_regions: Sequence[str] | None = None,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget(epsilon=5.0, norm="l2")
        self.n_steps = n_steps
        self.target_regions = target_regions

    def attack(
        self,
        token_ids: torch.Tensor,
        vocabulary: list[str] | None = None,
    ) -> tuple[torch.Tensor, AttackResult, str | None]:
        """Attack token sequence (T,) of integer IDs.

        Returns (adversarial_token_ids, AttackResult, adversarial_text).
        ``adversarial_text`` is ``None`` if *vocabulary* is not provided.
        """
        enc = self.model.encoder
        if not isinstance(enc, TextEncoder):
            raise TypeError("TextPGD requires a TextEncoder in the model")

        orig_ids = token_ids.detach().clone()
        best_ids = orig_ids.clone()

        with torch.no_grad():
            clean_pred = self.model.predict_from_features(enc(orig_ids))

        n_v = clean_pred.shape[-1]
        w = _build_roi_weight(self.target_regions, n_v, clean_pred.device)
        best_shift = 0.0
        max_changes = max(1, int(self.budget.epsilon))

        current_ids = orig_ids.clone()

        for _round in range(self.n_steps):
            # Gradient pass: find which position and token maximise loss
            emb = enc(current_ids)
            emb_d = emb.detach().requires_grad_(True)
            pred = self.model.predict_from_features(emb_d)
            loss = ((pred - clean_pred) * w.unsqueeze(0)).pow(2).mean()
            loss.backward()

            grad = emb_d.grad  # (T, D)
            if grad is None:
                break

            # Score each vocab token at each position using gradient direction
            with torch.no_grad():
                weight = enc.embedding.weight  # (V, D)
                # For each position, score = (token_emb - current_emb) · grad
                # Pick the token with highest score (steepest ascent direction)
                improved = False
                # Prioritize by gradient magnitude per position
                pos_priority = grad.norm(dim=-1).argsort(descending=True)

                for pos in pos_priority.tolist():
                    if (current_ids != orig_ids).sum().item() >= max_changes:
                        if current_ids[pos] == orig_ids[pos]:
                            continue  # Can't change more positions

                    current_emb = enc.embedding.weight[current_ids[pos]]
                    scores = (weight - current_emb) @ grad[pos]
                    top_k = scores.topk(min(10, enc.vocab_size)).indices

                    for cand in top_k.tolist():
                        if cand == current_ids[pos].item():
                            continue
                        trial = current_ids.clone()
                        trial[pos] = cand
                        trial_pred = self.model.predict_from_features(enc(trial))
                        shift = _compute_brain_shift(clean_pred, trial_pred)
                        if shift > best_shift:
                            best_shift = shift
                            best_ids = trial.clone()
                            current_ids = trial.clone()
                            improved = True
                            break
                    if improved:
                        break

                if not improved:
                    break  # No single substitution improves — converged

        with torch.no_grad():
            adv_pred = self.model.predict_from_features(enc(best_ids))

        # Compute embedding-space delta for the result
        delta = enc(best_ids).detach() - enc(orig_ids).detach()

        adv_text = None
        if vocabulary:
            adv_text = " ".join(
                vocabulary[tid.item()] if tid.item() < len(vocabulary) else f"[{tid.item()}]"
                for tid in best_ids
            )

        result = _make_stimulus_result(
            orig_ids, best_ids, clean_pred, adv_pred, delta,
            self.n_steps, best_shift > 0, "TextPGD", n_v,
        )
        return best_ids, result, adv_text
