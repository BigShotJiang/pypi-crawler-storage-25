"""Adversarial attack algorithms for brain encoding models.

Implements gradient-based and optimization-based attacks that craft minimal
perturbations to stimulus representations causing maximal disruption (or
targeted manipulation) of predicted cortical activity.

All attacks operate on the *feature space* of the model: they perturb the
``(T, D)`` representation that the model maps to ``(T, V)`` BOLD predictions.
This is both more tractable (differentiable by construction) and more
general than pixel/waveform-level attacks.
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np
import torch

from neuroprobe._types import AttackResult, BrainRegion, PerturbationBudget
from neuroprobe.regions import N_VERTICES, roi_mask
from neuroprobe.wrapper import BrainEncoderWrapper


# ═══════════════════════════════════════════════════════════════════════════
# Utility helpers
# ═══════════════════════════════════════════════════════════════════════════


def _project_perturbation(
    delta: torch.Tensor,
    budget: PerturbationBudget,
) -> torch.Tensor:
    """Project *delta* onto the Lp ball defined by *budget*."""
    eps = budget.epsilon
    if budget.norm == "linf":
        return delta.clamp(-eps, eps)
    elif budget.norm == "l2":
        norms = delta.flatten(1).norm(dim=1, keepdim=True).clamp(min=1e-12)
        factor = torch.clamp(norms / eps, min=1.0)
        return delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    elif budget.norm == "l1":
        # Approximate L1 projection via soft-thresholding
        flat = delta.flatten(1)
        abs_flat = flat.abs()
        l1_norms = abs_flat.sum(dim=1, keepdim=True)
        factor = torch.clamp(l1_norms / eps, min=1.0)
        return delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    else:
        raise ValueError(f"Unsupported norm: {budget.norm}")


def _compute_brain_shift(
    clean_pred: torch.Tensor,
    adv_pred: torch.Tensor,
) -> float:
    """Mean absolute change in predicted BOLD across all vertices and timesteps."""
    return (clean_pred - adv_pred).abs().mean().item()


def _compute_region_shifts(
    clean_pred: torch.Tensor,
    adv_pred: torch.Tensor,
    n_vertices: int = N_VERTICES,
) -> dict[str, float]:
    """Per-ROI mean absolute brain shift."""
    shifts: dict[str, float] = {}
    diff = (clean_pred - adv_pred).abs()  # (T, V)
    for name in ["V1", "V2", "A1", "STG", "STS", "IFG", "FFA", "PPA", "PFC", "motor"]:
        mask = roi_mask(name, n_vertices)
        mask_t = torch.tensor(mask, dtype=torch.bool, device=diff.device)
        if mask_t.sum() == 0:
            continue
        shifts[name] = diff[:, mask_t].mean().item()
    return shifts


def _make_result(
    clean_input: torch.Tensor,
    adv_input: torch.Tensor,
    clean_pred: torch.Tensor,
    adv_pred: torch.Tensor,
    delta: torch.Tensor,
    iterations: int,
    converged: bool,
    attack_name: str,
    n_vertices: int = N_VERTICES,
) -> AttackResult:
    flat_delta = delta.detach().cpu().numpy().ravel()
    return AttackResult(
        original_prediction=clean_pred.detach().cpu().numpy(),
        adversarial_prediction=adv_pred.detach().cpu().numpy(),
        perturbation=delta.detach().cpu().numpy(),
        original_input=clean_input.detach().cpu().numpy(),
        adversarial_input=adv_input.detach().cpu().numpy(),
        l2_distance=float(np.linalg.norm(flat_delta)),
        linf_distance=float(np.max(np.abs(flat_delta))),
        brain_shift=_compute_brain_shift(clean_pred, adv_pred),
        region_shifts=_compute_region_shifts(clean_pred, adv_pred, n_vertices),
        iterations=iterations,
        converged=converged,
        attack_name=attack_name,
    )


# ═══════════════════════════════════════════════════════════════════════════
# FGSM — Fast Gradient Sign Method for brain encoding
# ═══════════════════════════════════════════════════════════════════════════


class BrainFGSM:
    """Single-step FGSM attack on brain encoding models.

    Maximises the L2 distance between clean and adversarial predicted BOLD
    signals by perturbing the input feature representation in the direction
    of the gradient sign.

    Parameters
    ----------
    model : BrainEncoderWrapper
        The target brain encoding model.
    budget : PerturbationBudget
        Perturbation magnitude and norm constraint.
    target_regions : list of str, optional
        If provided, only maximise disruption in these ROIs.
    """

    def __init__(
        self,
        model: BrainEncoderWrapper,
        budget: PerturbationBudget | None = None,
        target_regions: Sequence[str] | None = None,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget()
        self.target_regions = target_regions

    def attack(self, features: torch.Tensor) -> AttackResult:
        """Run FGSM on feature tensor ``(T, D)``.

        Returns
        -------
        AttackResult
        """
        features = features.detach().clone().requires_grad_(True)
        clean_pred = self.model.predict_from_features(features)

        # Build ROI weight mask
        n_v = clean_pred.shape[-1]
        if self.target_regions:
            combined = np.zeros(n_v, dtype=np.float32)
            for r in self.target_regions:
                combined += roi_mask(r, n_v).astype(np.float32)
            combined = np.clip(combined, 0, 1)
            weight = torch.tensor(combined, device=clean_pred.device)
        else:
            weight = torch.ones(n_v, device=clean_pred.device)

        # Maximise weighted variance of BOLD prediction
        loss = -(clean_pred * weight.unsqueeze(0)).pow(2).mean()
        loss.backward()

        assert features.grad is not None
        grad_sign = features.grad.sign()
        delta = self.budget.epsilon * grad_sign
        delta = _project_perturbation(delta, self.budget)

        adv_features = (features + delta).detach()
        with torch.no_grad():
            adv_pred = self.model.predict_from_features(adv_features)

        return _make_result(
            clean_input=features.detach(),
            adv_input=adv_features,
            clean_pred=clean_pred.detach(),
            adv_pred=adv_pred,
            delta=delta,
            iterations=1,
            converged=True,
            attack_name="BrainFGSM",
            n_vertices=n_v,
        )


# ═══════════════════════════════════════════════════════════════════════════
# PGD — Projected Gradient Descent (iterative) attack
# ═══════════════════════════════════════════════════════════════════════════


class BrainPGD:
    """Iterative PGD attack on brain encoding models.

    Unlike FGSM, PGD takes multiple gradient steps with projection,
    producing stronger attacks within the same Lp budget.

    Parameters
    ----------
    model : BrainEncoderWrapper
        The target brain encoding model.
    budget : PerturbationBudget
        Perturbation magnitude and norm constraint.
    n_steps : int
        Number of PGD iterations (default 40).
    random_start : bool
        If True, initialise perturbation from uniform noise within the ball.
    target_regions : list of str, optional
        If provided, only maximise disruption in these ROIs.
    """

    def __init__(
        self,
        model: BrainEncoderWrapper,
        budget: PerturbationBudget | None = None,
        n_steps: int = 40,
        random_start: bool = True,
        target_regions: Sequence[str] | None = None,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget()
        self.n_steps = n_steps
        self.random_start = random_start
        self.target_regions = target_regions

    def attack(self, features: torch.Tensor) -> AttackResult:
        """Run PGD on feature tensor ``(T, D)``."""
        x_clean = features.detach().clone()

        with torch.no_grad():
            clean_pred = self.model.predict_from_features(x_clean)

        n_v = clean_pred.shape[-1]
        if self.target_regions:
            combined = np.zeros(n_v, dtype=np.float32)
            for r in self.target_regions:
                combined += roi_mask(r, n_v).astype(np.float32)
            combined = np.clip(combined, 0, 1)
            weight = torch.tensor(combined, device=clean_pred.device)
        else:
            weight = torch.ones(n_v, device=clean_pred.device)

        # Initialise perturbation
        if self.random_start:
            delta = torch.empty_like(x_clean).uniform_(
                -self.budget.epsilon, self.budget.epsilon
            )
            delta = _project_perturbation(delta, self.budget)
        else:
            delta = 1e-7 * torch.randn_like(x_clean)

        step_size = self.budget.step_size or self.budget.epsilon / 4.0
        best_shift = 0.0
        best_delta = delta.clone()

        for _ in range(self.n_steps):
            delta.requires_grad_(True)
            x_adv = x_clean + delta
            pred = self.model.predict_from_features(x_adv)

            # Maximise L2 distance from clean BOLD in target regions
            diff = (pred - clean_pred) * weight.unsqueeze(0)
            loss = diff.pow(2).mean()
            loss.backward()

            assert delta.grad is not None
            with torch.no_grad():
                if self.budget.norm == "linf":
                    delta = delta + step_size * delta.grad.sign()
                else:
                    # Normalised gradient step for L2/L1
                    grad_norm = delta.grad.flatten(1).norm(dim=1, keepdim=True).clamp(min=1e-12)
                    delta = delta + step_size * delta.grad / grad_norm.view(
                        -1, *([1] * (delta.dim() - 1))
                    )
                delta = _project_perturbation(delta, self.budget)

                # Track best perturbation
                with torch.no_grad():
                    curr_pred = self.model.predict_from_features(x_clean + delta)
                    shift = _compute_brain_shift(clean_pred, curr_pred)
                    if shift > best_shift:
                        best_shift = shift
                        best_delta = delta.clone()

        adv_features = x_clean + best_delta
        with torch.no_grad():
            adv_pred = self.model.predict_from_features(adv_features)

        return _make_result(
            clean_input=x_clean,
            adv_input=adv_features,
            clean_pred=clean_pred,
            adv_pred=adv_pred,
            delta=best_delta,
            iterations=self.n_steps,
            converged=best_shift > 0,
            attack_name="BrainPGD",
            n_vertices=n_v,
        )


# ═══════════════════════════════════════════════════════════════════════════
# Region-Targeted Attack
# ═══════════════════════════════════════════════════════════════════════════


class RegionTargeted:
    """Craft perturbations that selectively activate a target brain region
    while minimally affecting others.

    This is the most neuroscience-relevant attack: it tests whether an
    adversary can surgically manipulate the predicted activity in a specific
    cortical area (e.g., FFA for face processing) through small stimulus
    changes.

    Parameters
    ----------
    model : BrainEncoderWrapper
    target_region : str
        ROI to activate (e.g. 'FFA', 'V1', 'A1').
    suppress_regions : list of str, optional
        ROIs to suppress (keep unchanged). If None, all non-target regions.
    budget : PerturbationBudget
    n_steps : int
    target_activation : float
        Desired mean activation in the target region (in BOLD units).
    """

    def __init__(
        self,
        model: BrainEncoderWrapper,
        target_region: str = "FFA",
        suppress_regions: Sequence[str] | None = None,
        budget: PerturbationBudget | None = None,
        n_steps: int = 100,
        target_activation: float = 2.0,
    ) -> None:
        self.model = model
        self.target_region = target_region
        self.suppress_regions = suppress_regions
        self.budget = budget or PerturbationBudget(epsilon=0.05)
        self.n_steps = n_steps
        self.target_activation = target_activation

    def attack(self, features: torch.Tensor) -> AttackResult:
        x_clean = features.detach().clone()
        with torch.no_grad():
            clean_pred = self.model.predict_from_features(x_clean)

        n_v = clean_pred.shape[-1]
        target_mask_np = roi_mask(self.target_region, n_v)
        target_mask = torch.tensor(target_mask_np, dtype=torch.bool, device=clean_pred.device)

        # Build suppression mask
        if self.suppress_regions:
            suppress_np = np.zeros(n_v, dtype=bool)
            for r in self.suppress_regions:
                suppress_np |= roi_mask(r, n_v)
        else:
            suppress_np = ~target_mask_np
        suppress_mask = torch.tensor(suppress_np, dtype=torch.bool, device=clean_pred.device)

        delta = torch.zeros_like(x_clean, requires_grad=True)
        optimizer = torch.optim.Adam([delta], lr=self.budget.step_size or 0.01)

        for _ in range(self.n_steps):
            optimizer.zero_grad()
            pred = self.model.predict_from_features(x_clean + delta)

            # Maximise target region activation
            target_loss = -(pred[:, target_mask].mean() - self.target_activation).abs()
            # This pushes target region to self.target_activation
            target_loss = (pred[:, target_mask].mean() - self.target_activation).pow(2)

            # Minimise change in suppressed regions
            suppress_loss = (pred[:, suppress_mask] - clean_pred[:, suppress_mask]).pow(2).mean()

            loss = target_loss + 5.0 * suppress_loss
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                delta.data = _project_perturbation(delta.data, self.budget)

        with torch.no_grad():
            adv_features = x_clean + delta
            adv_pred = self.model.predict_from_features(adv_features)

        return _make_result(
            clean_input=x_clean,
            adv_input=adv_features,
            clean_pred=clean_pred,
            adv_pred=adv_pred,
            delta=delta.detach(),
            iterations=self.n_steps,
            converged=True,
            attack_name=f"RegionTargeted({self.target_region})",
            n_vertices=n_v,
        )


# ═══════════════════════════════════════════════════════════════════════════
# Cross-Modal Confusion Attack
# ═══════════════════════════════════════════════════════════════════════════


class CrossModalConfusion:
    """Craft a perturbation to visual features that makes the model predict
    brain activity typical of *auditory* processing (or vice versa).

    This tests whether the model's multi-modal integration is robust:
    can a small perturbation to visual input features cause the model to
    predict auditory-cortex-like activation patterns?

    Parameters
    ----------
    model : BrainEncoderWrapper
    source_modality : str
        'visual' or 'auditory' — which modality the input belongs to.
    budget : PerturbationBudget
    n_steps : int
    """

    def __init__(
        self,
        model: BrainEncoderWrapper,
        source_modality: str = "visual",
        budget: PerturbationBudget | None = None,
        n_steps: int = 80,
    ) -> None:
        self.model = model
        self.source_modality = source_modality
        self.budget = budget or PerturbationBudget(epsilon=0.05)
        self.n_steps = n_steps

    def attack(
        self,
        features: torch.Tensor,
        target_pattern: torch.Tensor | None = None,
    ) -> AttackResult:
        """
        Parameters
        ----------
        features : torch.Tensor
            Source stimulus features (T, D).
        target_pattern : torch.Tensor, optional
            Desired brain activity pattern (T, V) from the other modality.
            If None, a synthetic auditory (or visual) pattern is created by
            amplifying the respective cortical regions.
        """
        x_clean = features.detach().clone()
        with torch.no_grad():
            clean_pred = self.model.predict_from_features(x_clean)

        n_v = clean_pred.shape[-1]

        # Define target pattern: amplify opposite-modality regions
        if target_pattern is None:
            target_pattern = clean_pred.clone()
            if self.source_modality == "visual":
                # Amplify auditory regions, suppress visual
                for r in ["A1", "STG", "STS"]:
                    m = torch.tensor(roi_mask(r, n_v), dtype=torch.bool, device=clean_pred.device)
                    target_pattern[:, m] = clean_pred[:, m].abs().mean() + 2.0
                for r in ["V1", "V2", "V4", "MT"]:
                    m = torch.tensor(roi_mask(r, n_v), dtype=torch.bool, device=clean_pred.device)
                    target_pattern[:, m] = 0.0
            else:
                for r in ["V1", "V2", "V4", "FFA"]:
                    m = torch.tensor(roi_mask(r, n_v), dtype=torch.bool, device=clean_pred.device)
                    target_pattern[:, m] = clean_pred[:, m].abs().mean() + 2.0
                for r in ["A1", "STG", "STS"]:
                    m = torch.tensor(roi_mask(r, n_v), dtype=torch.bool, device=clean_pred.device)
                    target_pattern[:, m] = 0.0

        delta = torch.zeros_like(x_clean, requires_grad=True)
        optimizer = torch.optim.Adam([delta], lr=self.budget.step_size or 0.01)

        for _ in range(self.n_steps):
            optimizer.zero_grad()
            pred = self.model.predict_from_features(x_clean + delta)
            loss = (pred - target_pattern).pow(2).mean()
            loss.backward()
            optimizer.step()
            with torch.no_grad():
                delta.data = _project_perturbation(delta.data, self.budget)

        with torch.no_grad():
            adv_features = x_clean + delta
            adv_pred = self.model.predict_from_features(adv_features)

        return _make_result(
            clean_input=x_clean,
            adv_input=adv_features,
            clean_pred=clean_pred,
            adv_pred=adv_pred,
            delta=delta.detach(),
            iterations=self.n_steps,
            converged=True,
            attack_name=f"CrossModalConfusion({self.source_modality})",
            n_vertices=n_v,
        )


# ═══════════════════════════════════════════════════════════════════════════
# Universal (input-agnostic) Adversarial Perturbation
# ═══════════════════════════════════════════════════════════════════════════


class UniversalBrainPerturbation:
    """Learn a single perturbation vector that disrupts brain predictions
    across many different stimuli.

    This is the most dangerous attack class: if a universal perturbation
    exists, it means the model has a systematic vulnerability exploitable
    without per-stimulus optimization.

    Parameters
    ----------
    model : BrainEncoderWrapper
    budget : PerturbationBudget
    n_epochs : int
        Number of passes over the stimulus set.
    """

    def __init__(
        self,
        model: BrainEncoderWrapper,
        budget: PerturbationBudget | None = None,
        n_epochs: int = 10,
    ) -> None:
        self.model = model
        self.budget = budget or PerturbationBudget(epsilon=0.03)
        self.n_epochs = n_epochs
        self.universal_delta: torch.Tensor | None = None

    def fit(self, stimuli: list[torch.Tensor]) -> torch.Tensor:
        """Learn a universal perturbation from a set of stimuli.

        Parameters
        ----------
        stimuli : list of torch.Tensor
            Each tensor has shape ``(T_i, D)`` (variable lengths OK).

        Returns
        -------
        torch.Tensor
            The universal perturbation of shape ``(1, D)`` (broadcast over T).
        """
        if not stimuli:
            raise ValueError("Need at least one stimulus")

        D = stimuli[0].shape[-1]
        torch.manual_seed(0)
        delta = 1e-7 * torch.randn(1, D)

        fgsm_budget = PerturbationBudget(
            epsilon=self.budget.epsilon / self.n_epochs,
            norm=self.budget.norm,
        )

        for _epoch in range(self.n_epochs):
            for x in stimuli:
                x_clean = x.detach().clone()
                x_adv = x_clean + delta
                x_adv.requires_grad_(True)

                with torch.no_grad():
                    clean_pred = self.model.predict_from_features(x_clean)

                # Need gradients through adv prediction
                delta_expanded = delta.expand_as(x_clean)
                delta_expanded = delta_expanded.detach().requires_grad_(True)
                adv_pred = self.model.predict_from_features(x_clean + delta_expanded)
                loss = (adv_pred - clean_pred).pow(2).mean()
                loss.backward()

                assert delta_expanded.grad is not None
                with torch.no_grad():
                    # Aggregate gradient across time steps
                    grad_mean = delta_expanded.grad.mean(dim=0, keepdim=True)
                    delta = delta + fgsm_budget.epsilon * grad_mean.sign()
                    delta = _project_perturbation(delta, self.budget)

        self.universal_delta = delta.detach()
        return self.universal_delta

    def attack(self, features: torch.Tensor) -> AttackResult:
        """Apply the learned universal perturbation to a new stimulus."""
        if self.universal_delta is None:
            raise RuntimeError("Call .fit() first to learn the universal perturbation")

        x_clean = features.detach().clone()
        delta = self.universal_delta.expand_as(x_clean)

        with torch.no_grad():
            clean_pred = self.model.predict_from_features(x_clean)
            adv_pred = self.model.predict_from_features(x_clean + delta)

        n_v = clean_pred.shape[-1]
        return _make_result(
            clean_input=x_clean,
            adv_input=x_clean + delta,
            clean_pred=clean_pred,
            adv_pred=adv_pred,
            delta=delta,
            iterations=0,
            converged=True,
            attack_name="UniversalBrainPerturbation",
            n_vertices=n_v,
        )
