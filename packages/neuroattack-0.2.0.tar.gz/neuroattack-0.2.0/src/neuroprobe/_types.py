"""Core data types for neuroprobe."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class BrainRegion(Enum):
    """Standard cortical ROIs on fsaverage5."""

    V1 = "V1"
    V2 = "V2"
    V4 = "V4"
    MT = "MT"
    FFA = "FFA"  # fusiform face area
    PPA = "PPA"  # parahippocampal place area
    STS = "STS"  # superior temporal sulcus (speech)
    STG = "STG"  # superior temporal gyrus (auditory)
    A1 = "A1"  # primary auditory cortex
    IFG = "IFG"  # inferior frontal gyrus (Broca's)
    TPJ = "TPJ"  # temporo-parietal junction
    PFC = "PFC"  # prefrontal cortex
    MOTOR = "motor"
    WHOLE_BRAIN = "whole_brain"


@dataclass
class PerturbationBudget:
    """Defines the allowed perturbation magnitude."""

    epsilon: float = 0.03  # Lp-norm budget (relative to input range)
    norm: str = "linf"  # 'linf', 'l2', 'l1'
    step_size: float | None = None  # per-iteration step; defaults to eps/4

    def __post_init__(self) -> None:
        if self.step_size is None:
            self.step_size = self.epsilon / 4.0
        if self.norm not in ("linf", "l2", "l1"):
            raise ValueError(f"Unsupported norm: {self.norm}")


@dataclass
class AttackResult:
    """Result of an adversarial attack on a brain encoding model."""

    original_prediction: object  # (T, V) array — clean brain prediction
    adversarial_prediction: object  # (T, V) array — brain prediction under attack
    perturbation: object  # the perturbation tensor/array
    original_input: object  # clean stimulus representation
    adversarial_input: object  # perturbed stimulus representation
    l2_distance: float = 0.0  # L2 norm of perturbation
    linf_distance: float = 0.0  # Linf norm of perturbation
    brain_shift: float = 0.0  # mean change in predicted BOLD across cortex
    region_shifts: dict[str, float] = field(default_factory=dict)  # per-ROI shift
    iterations: int = 0
    converged: bool = False
    attack_name: str = ""


@dataclass
class RobustnessReport:
    """Aggregate robustness analysis across multiple stimuli."""

    model_name: str = ""
    n_stimuli: int = 0
    attack_name: str = ""
    budget: PerturbationBudget | None = None
    mean_brain_shift: float = 0.0
    max_brain_shift: float = 0.0
    most_vulnerable_region: str = ""
    most_robust_region: str = ""
    region_vulnerability: dict[str, float] = field(default_factory=dict)
    per_stimulus: list[AttackResult] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"Robustness Report: {self.model_name}",
            f"  Attack: {self.attack_name} (ε={self.budget.epsilon if self.budget else '?'})",
            f"  Stimuli tested: {self.n_stimuli}",
            f"  Mean brain shift: {self.mean_brain_shift:.4f}",
            f"  Max brain shift:  {self.max_brain_shift:.4f}",
            f"  Most vulnerable:  {self.most_vulnerable_region}",
            f"  Most robust:      {self.most_robust_region}",
        ]
        return "\n".join(lines)
