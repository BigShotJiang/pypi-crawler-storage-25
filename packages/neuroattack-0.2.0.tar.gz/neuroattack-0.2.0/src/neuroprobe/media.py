"""Differentiable media encoders and I/O for end-to-end adversarial attacks.

These encoders map raw stimuli (video frames, audio waveforms, text tokens)
into the feature space that brain encoding models operate on.  Combined with
a brain prediction head, they enable gradient-based attacks that produce
actual adversarial media files — not just perturbed feature vectors.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from neuroprobe.regions import N_VERTICES
from neuroprobe.wrapper import BrainEncoderWrapper


# ═══════════════════════════════════════════════════════════════════════════
# Media encoders
# ═══════════════════════════════════════════════════════════════════════════


class VideoEncoder(nn.Module):
    """Lightweight CNN video encoder: (T, 3, H, W) → (T, D).

    Strided convolutions + global average pooling, applied per-frame.
    """

    def __init__(self, feature_dim: int = 768, seed: int = 42) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.feature_dim = feature_dim
        self.conv = nn.Sequential(
            nn.Conv2d(3, 32, 5, stride=2, padding=2),
            nn.GELU(),
            nn.GroupNorm(8, 32),
            nn.Conv2d(32, 64, 3, stride=2, padding=1),
            nn.GELU(),
            nn.GroupNorm(8, 64),
            nn.Conv2d(64, 128, 3, stride=2, padding=1),
            nn.GELU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Linear(128, feature_dim)

    def forward(self, frames: torch.Tensor) -> torch.Tensor:
        """frames: (T, 3, H, W) in [0, 1] → features (T, D)."""
        T = frames.shape[0]
        x = self.conv(frames)  # (T, 128, 1, 1)
        x = x.view(T, -1)
        return self.fc(x)


class AudioEncoder(nn.Module):
    """1D-conv audio encoder: waveform (samples,) → (T, D).

    Processes the full waveform through strided 1D convolutions that
    reduce temporal resolution while preserving gradient flow.
    """

    def __init__(
        self,
        feature_dim: int = 768,
        frame_size: int = 400,
        hop_size: int = 160,
        seed: int = 42,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.feature_dim = feature_dim
        self.frame_size = frame_size
        self.hop_size = hop_size
        # Process full waveform — strided convs reduce temporal dim
        self.conv = nn.Sequential(
            nn.Conv1d(1, 32, 25, stride=4, padding=12),
            nn.GELU(),
            nn.Conv1d(32, 64, 9, stride=4, padding=4),
            nn.GELU(),
            nn.Conv1d(64, 128, 5, stride=4, padding=2),
            nn.GELU(),
        )
        self.fc = nn.Linear(128, feature_dim)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        """waveform: (samples,) in [-1, 1] → features (T, D)."""
        # Process full waveform in one pass for better gradient flow
        x = waveform.unsqueeze(0).unsqueeze(0)  # (1, 1, S)
        x = self.conv(x)  # (1, 128, T')
        x = x.squeeze(0).permute(1, 0)  # (T', 128)
        return self.fc(x)  # (T', D)


class TextEncoder(nn.Module):
    """Token embedding encoder: token_ids (T,) → (T, D).

    For adversarial text attacks the perturbation is applied in
    continuous embedding space, then projected back to the nearest
    discrete tokens via cosine similarity.
    """

    def __init__(
        self,
        vocab_size: int = 5000,
        feature_dim: int = 768,
        seed: int = 42,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.vocab_size = vocab_size
        self.feature_dim = feature_dim
        self.embedding = nn.Embedding(vocab_size, feature_dim)
        # Normalize embeddings to unit sphere so perturbations cross
        # token boundaries more easily
        with torch.no_grad():
            self.embedding.weight.div_(
                self.embedding.weight.norm(dim=-1, keepdim=True).clamp(min=1e-8)
            )

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        return self.embedding(token_ids)

    def nearest_tokens(self, embeddings: torch.Tensor) -> torch.Tensor:
        """Project continuous embeddings to nearest vocabulary tokens."""
        weight = self.embedding.weight.detach()
        emb_n = embeddings / embeddings.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        w_n = weight / weight.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        return (emb_n @ w_n.T).argmax(dim=-1)


# ═══════════════════════════════════════════════════════════════════════════
# End-to-end brain model
# ═══════════════════════════════════════════════════════════════════════════


class MultiModalBrainModel(BrainEncoderWrapper):
    """End-to-end differentiable model: raw media → predicted BOLD.

    Combines a media encoder (video/audio/text) with a brain prediction
    head so gradients flow from cortical predictions all the way back to
    raw stimulus pixels, waveform samples, or token embeddings.
    """

    def __init__(
        self,
        encoder: nn.Module,
        brain_head: nn.Module,
        vertex_scale: torch.Tensor | None = None,
    ) -> None:
        self.encoder = encoder
        self.brain_head = brain_head
        self._vertex_scale = vertex_scale

    def encode_stimulus(self, stimulus: torch.Tensor) -> torch.Tensor:
        return self.encoder(stimulus)

    def predict_from_features(self, features: torch.Tensor) -> torch.Tensor:
        raw = self.brain_head(features)
        if self._vertex_scale is not None:
            scale = self._vertex_scale.to(features.device)
            raw = raw * scale.unsqueeze(0)
        return raw

    def predict(self, stimulus: torch.Tensor) -> torch.Tensor:
        return self.predict_from_features(self.encode_stimulus(stimulus))


def build_brain_model(
    modality: str = "video",
    feature_dim: int = 768,
    n_vertices: int = 2048,
    hidden_dim: int = 512,
    seed: int = 42,
    **encoder_kwargs,
) -> MultiModalBrainModel:
    """Factory: create an end-to-end brain model for a given modality.

    Parameters
    ----------
    modality : str
        'video', 'audio', or 'text'.
    """
    torch.manual_seed(seed)

    if modality == "video":
        encoder = VideoEncoder(feature_dim=feature_dim, seed=seed)
    elif modality == "audio":
        encoder = AudioEncoder(feature_dim=feature_dim, seed=seed, **encoder_kwargs)
    elif modality == "text":
        encoder = TextEncoder(feature_dim=feature_dim, seed=seed, **encoder_kwargs)
    else:
        raise ValueError(f"Unknown modality: {modality}")

    brain_head = nn.Sequential(
        nn.Linear(feature_dim, hidden_dim),
        nn.GELU(),
        nn.LayerNorm(hidden_dim),
        nn.Linear(hidden_dim, hidden_dim),
        nn.GELU(),
        nn.Linear(hidden_dim, n_vertices),
    )

    rng = np.random.RandomState(seed)
    vertex_scale = torch.tensor(
        rng.exponential(1.0, size=n_vertices), dtype=torch.float32
    )
    return MultiModalBrainModel(encoder, brain_head, vertex_scale)


# ═══════════════════════════════════════════════════════════════════════════
# Media I/O helpers
# ═══════════════════════════════════════════════════════════════════════════


def synthesize_video(
    n_frames: int = 10,
    height: int = 64,
    width: int = 64,
    seed: int = 42,
) -> torch.Tensor:
    """Synthetic video (T, 3, H, W) in [0, 1]: moving circle + gradient."""
    rng = np.random.RandomState(seed)
    frames = rng.rand(n_frames, 3, height, width).astype(np.float32) * 0.3
    for t in range(n_frames):
        grad = np.linspace(0, 0.5, width, dtype=np.float32)
        frames[t, 0] += grad[None, :]
        cy = height // 2 + int(8 * np.sin(2 * np.pi * t / n_frames))
        cx = width // 2
        yy, xx = np.ogrid[:height, :width]
        circle = ((yy - cy) ** 2 + (xx - cx) ** 2) < (height // 8) ** 2
        frames[t, 1] += circle.astype(np.float32) * 0.4
    return torch.tensor(np.clip(frames, 0, 1))


def synthesize_audio(
    duration: float = 1.0,
    sample_rate: int = 16000,
    seed: int = 42,
) -> torch.Tensor:
    """Synthetic waveform (samples,) in [-1, 1]: tones + noise."""
    rng = np.random.RandomState(seed)
    n = int(duration * sample_rate)
    t = np.linspace(0, duration, n, dtype=np.float32)
    wav = (
        0.3 * np.sin(2 * np.pi * 440 * t)
        + 0.2 * np.sin(2 * np.pi * 880 * t)
        + 0.1 * rng.randn(n).astype(np.float32)
    )
    wav = wav / np.abs(wav).max()
    return torch.tensor(wav, dtype=torch.float32)


def save_audio(
    waveform: torch.Tensor | np.ndarray, path: str, sample_rate: int = 16000
) -> None:
    """Save waveform as 16-bit WAV."""
    from scipy.io import wavfile

    if isinstance(waveform, torch.Tensor):
        waveform = waveform.detach().cpu().numpy()
    wavfile.write(path, sample_rate, (waveform * 32767).astype(np.int16))


def load_audio(path: str) -> tuple[torch.Tensor, int]:
    """Load WAV → float tensor in [-1, 1] + sample_rate."""
    from scipy.io import wavfile

    sr, data = wavfile.read(path)
    if data.dtype == np.int16:
        data = data.astype(np.float32) / 32767.0
    return torch.tensor(data, dtype=torch.float32), sr


def compute_psnr(original: torch.Tensor, perturbed: torch.Tensor) -> float:
    """Peak Signal-to-Noise Ratio (dB). Higher = more similar."""
    mse = (original - perturbed).pow(2).mean().item()
    if mse < 1e-10:
        return float("inf")
    return 10 * np.log10(1.0 / mse)


def compute_snr(signal: torch.Tensor, noise: torch.Tensor) -> float:
    """Signal-to-Noise Ratio (dB). Higher = less perceptible."""
    sp = signal.pow(2).mean().item()
    np_ = noise.pow(2).mean().item()
    if np_ < 1e-10:
        return float("inf")
    return 10 * np.log10(sp / np_)
