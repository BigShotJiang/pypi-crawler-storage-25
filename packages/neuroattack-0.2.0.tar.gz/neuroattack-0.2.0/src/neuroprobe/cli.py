"""CLI entry point for neuroprobe."""

from __future__ import annotations

import argparse
import json
import sys

import numpy as np
import torch


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="neuroprobe",
        description="Adversarial robustness testing for brain encoding models",
    )
    sub = parser.add_subparsers(dest="command")

    # --- demo command ---
    demo_p = sub.add_parser("demo", help="Run a quick demo with the SyntheticEncoder")
    demo_p.add_argument("--epsilon", type=float, default=0.03)
    demo_p.add_argument("--steps", type=int, default=20)
    demo_p.add_argument("--attack", choices=["fgsm", "pgd", "targeted", "crossmodal", "universal"], default="pgd")

    # --- audit command ---
    audit_p = sub.add_parser("audit", help="Full robustness audit on SyntheticEncoder")
    audit_p.add_argument("--n-stimuli", type=int, default=10)
    audit_p.add_argument("--output", type=str, default=None)

    args = parser.parse_args(argv)

    if args.command == "demo":
        _run_demo(args)
    elif args.command == "audit":
        _run_audit(args)
    else:
        parser.print_help()


def _run_demo(args: argparse.Namespace) -> None:
    from neuroprobe.wrapper import SyntheticEncoder
    from neuroprobe.attacks import BrainFGSM, BrainPGD, RegionTargeted, CrossModalConfusion, UniversalBrainPerturbation
    from neuroprobe._types import PerturbationBudget

    print("neuroprobe demo — adversarial attacks on SyntheticEncoder")
    print("=" * 60)

    model = SyntheticEncoder(feature_dim=768, n_vertices=2048)
    budget = PerturbationBudget(epsilon=args.epsilon)

    # Generate a synthetic stimulus
    rng = np.random.RandomState(0)
    x = torch.tensor(rng.randn(10, 768).astype(np.float32))

    attack_map = {
        "fgsm": lambda: BrainFGSM(model, budget=budget).attack(x),
        "pgd": lambda: BrainPGD(model, budget=budget, n_steps=args.steps).attack(x),
        "targeted": lambda: RegionTargeted(model, target_region="V1", budget=budget, n_steps=args.steps).attack(x),
        "crossmodal": lambda: CrossModalConfusion(model, budget=budget, n_steps=args.steps).attack(x),
        "universal": lambda: _demo_universal(model, budget, x),
    }

    result = attack_map[args.attack]()
    print(f"\nAttack: {result.attack_name}")
    print(f"  L2 perturbation:  {result.l2_distance:.4f}")
    print(f"  Linf perturbation: {result.linf_distance:.6f}")
    print(f"  Brain shift:      {result.brain_shift:.4f}")
    print(f"  Iterations:       {result.iterations}")
    if result.region_shifts:
        print("  Per-region shifts:")
        for rname, rshift in sorted(result.region_shifts.items(), key=lambda kv: -kv[1])[:5]:
            print(f"    {rname:8s}: {rshift:.4f}")


def _demo_universal(model, budget, x):
    from neuroprobe.attacks import UniversalBrainPerturbation
    uap = UniversalBrainPerturbation(model, budget=budget, n_epochs=3)
    stimuli = [x, x + 0.1 * torch.randn_like(x), x - 0.1 * torch.randn_like(x)]
    uap.fit(stimuli)
    return uap.attack(x)


def _run_audit(args: argparse.Namespace) -> None:
    from neuroprobe.wrapper import SyntheticEncoder
    from neuroprobe.analysis import robustness_curve, region_vulnerability_map
    from neuroprobe._types import PerturbationBudget

    print("neuroprobe audit — full robustness assessment")
    print("=" * 60)

    model = SyntheticEncoder(feature_dim=768, n_vertices=2048)

    rng = np.random.RandomState(42)
    stimuli = [
        torch.tensor(rng.randn(10, 768).astype(np.float32))
        for _ in range(args.n_stimuli)
    ]

    # Robustness curve
    print("\n[1/2] Computing robustness curve...")
    epsilons = [0.001, 0.005, 0.01, 0.02, 0.05, 0.1]
    curve = robustness_curve(model, stimuli, epsilons=epsilons, n_steps=10)

    print("\n  ε         Brain Shift   Most Vulnerable")
    print("  " + "-" * 45)
    for eps, report in curve.items():
        print(f"  {eps:<10.3f}{report.mean_brain_shift:<14.4f}{report.most_vulnerable_region}")

    # Region vulnerability
    print("\n[2/2] Computing region vulnerability map...")
    budget = PerturbationBudget(epsilon=0.05)
    vuln = region_vulnerability_map(model, stimuli[:3], budget=budget, n_steps=10)

    print("\n  Region      Vulnerability")
    print("  " + "-" * 30)
    for rname, v in list(vuln.items())[:8]:
        bar = "█" * int(v * 20)
        print(f"  {rname:10s}  {v:.4f} {bar}")

    if args.output:
        out = {
            "robustness_curve": {str(e): r.mean_brain_shift for e, r in curve.items()},
            "region_vulnerability": vuln,
        }
        with open(args.output, "w") as f:
            json.dump(out, f, indent=2)
        print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
