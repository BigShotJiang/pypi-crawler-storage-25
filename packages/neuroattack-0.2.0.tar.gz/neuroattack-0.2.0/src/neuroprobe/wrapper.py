"""Model wrapper — abstract interface for brain encoding models.

neuroprobe is model-agnostic: any brain encoding model that implements
``BrainEncoderWrapper`` can be attacked. We ship a concrete wrapper for
Meta's TRIBE v2 and a lightweight ``SyntheticEncoder`` for testing without
GPU / model weights.
"""

from __future__ import annotations

import abc
from typing import Any

import numpy as np
import torch
import torch.nn as nn

from neuroprobe.regions import N_VERTICES


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------


class BrainEncoderWrapper(abc.ABC):
    """Protocol every brain encoder must satisfy for neuroprobe attacks."""

    @abc.abstractmethod
    def encode_stimulus(self, stimulus: Any) -> torch.Tensor:
        """Convert raw stimulus (path, array, etc.) to a differentiable
        feature tensor of shape ``(T, D)`` where *T* is the number of time
        steps and *D* the feature dimension.
        """

    @abc.abstractmethod
    def predict_from_features(self, features: torch.Tensor) -> torch.Tensor:
        """Map feature tensor ``(T, D)`` → predicted BOLD ``(T, V)`` where
        *V* is the number of cortical vertices.

        This **must** be differentiable so that we can back-propagate
        through it for gradient-based attacks.
        """

    def predict(self, stimulus: Any) -> torch.Tensor:
        """End-to-end: stimulus → predicted brain activity."""
        feats = self.encode_stimulus(stimulus)
        return self.predict_from_features(feats)


# ---------------------------------------------------------------------------
# TRIBE v2 wrapper (requires `pip install tribev2`)
# ---------------------------------------------------------------------------


class TRIBEv2Wrapper(BrainEncoderWrapper):
    """Wraps Meta's TRIBE v2 for adversarial attacks.

    Loads the model from HuggingFace and exposes the internal forward pass
    so gradients can flow from predicted BOLD back to input features.
    """

    def __init__(
        self,
        model_name: str = "facebook/tribev2",
        cache_folder: str = "./cache",
        device: str | None = None,
    ) -> None:
        try:
            from tribev2 import TribeModel  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "tribev2 is required for TRIBEv2Wrapper. "
                "Install with: pip install tribev2"
            ) from exc

        self._device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self._tribe = TribeModel.from_pretrained(
            model_name, cache_folder=cache_folder
        )
        # Move internal model to device
        if hasattr(self._tribe, "model"):
            self._tribe.model = self._tribe.model.to(self._device)

    def encode_stimulus(self, stimulus: Any) -> torch.Tensor:
        """Encode a video/audio/text path into feature tensor."""
        if isinstance(stimulus, str):
            df = self._tribe.get_events_dataframe(video_path=stimulus)
        elif isinstance(stimulus, dict):
            df = self._tribe.get_events_dataframe(**stimulus)
        else:
            raise TypeError(f"Expected str or dict, got {type(stimulus)}")

        # Extract the feature matrix used internally
        preds, segments = self._tribe.predict(events=df)
        # Return as torch tensor on device
        return torch.tensor(preds, dtype=torch.float32, device=self._device)

    def predict_from_features(self, features: torch.Tensor) -> torch.Tensor:
        """Pass pre-computed features through the brain encoder head."""
        # In the full implementation this hooks into the model's linear head
        # For now, delegate to the model
        return features  # already predicted BOLD in encode_stimulus


# ---------------------------------------------------------------------------
# Synthetic encoder for testing & demos (no GPU / model weights needed)
# ---------------------------------------------------------------------------


class SyntheticEncoder(BrainEncoderWrapper):
    """A lightweight differentiable brain encoder for testing.

    Maps ``(T, D)`` feature inputs through a small learned MLP to produce
    ``(T, V)`` cortical predictions. Useful for validating attack code
    without TRIBE v2 weights.
    """

    def __init__(
        self,
        feature_dim: int = 768,
        n_vertices: int = N_VERTICES,
        hidden_dim: int = 512,
        seed: int = 42,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.feature_dim = feature_dim
        self.n_vertices = n_vertices
        self.net = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, n_vertices),
        )
        # Simulate region-specific sensitivity by scaling output vertices
        rng = np.random.RandomState(seed)
        self._vertex_scale = torch.tensor(
            rng.exponential(1.0, size=n_vertices), dtype=torch.float32
        )

    def encode_stimulus(self, stimulus: Any) -> torch.Tensor:
        """Accept a numpy array or torch tensor of shape ``(T, D)``."""
        if isinstance(stimulus, np.ndarray):
            return torch.tensor(stimulus, dtype=torch.float32)
        if isinstance(stimulus, torch.Tensor):
            return stimulus.float()
        raise TypeError(f"Expected ndarray or Tensor, got {type(stimulus)}")

    def predict_from_features(self, features: torch.Tensor) -> torch.Tensor:
        """Differentiable forward: features (T, D) → BOLD (T, V)."""
        device = features.device
        net = self.net.to(device)
        scale = self._vertex_scale.to(device)
        raw = net(features)  # (T, V)
        return raw * scale.unsqueeze(0)
