"""Analysis functions for adversarial robustness of brain encoding models.

Three core analyses:
1. **Robustness curve**: brain shift as a function of perturbation budget ε
2. **Region vulnerability map**: which cortical ROIs are most affected
3. **Transferability matrix**: do adversarial examples transfer across subjects
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
import torch
from tqdm import tqdm

from neuroprobe._types import AttackResult, PerturbationBudget, RobustnessReport
from neuroprobe.attacks import BrainPGD
from neuroprobe.regions import roi_mask, roi_names
from neuroprobe.wrapper import BrainEncoderWrapper


def robustness_curve(
    model: BrainEncoderWrapper,
    stimuli: list[torch.Tensor],
    epsilons: Sequence[float] = (0.001, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2),
    norm: str = "linf",
    n_steps: int = 20,
    target_regions: Sequence[str] | None = None,
) -> dict[float, RobustnessReport]:
    """Compute brain shift at increasing perturbation budgets.

    Returns a dict mapping ε → RobustnessReport.  Useful for plotting
    robustness curves (ε on x-axis, brain shift on y-axis).

    Parameters
    ----------
    model : BrainEncoderWrapper
    stimuli : list of torch.Tensor
        Feature tensors, each of shape (T, D).
    epsilons : sequence of float
        Perturbation budgets to test.
    norm : str
        'linf', 'l2', or 'l1'.
    n_steps : int
        PGD iterations per epsilon.
    target_regions : list of str, optional
        ROIs to target.
    """
    results: dict[float, RobustnessReport] = {}

    for eps in tqdm(epsilons, desc="Robustness curve"):
        budget = PerturbationBudget(epsilon=eps, norm=norm)
        attacker = BrainPGD(
            model, budget=budget, n_steps=n_steps, target_regions=target_regions
        )

        attack_results: list[AttackResult] = []
        for x in stimuli:
            ar = attacker.attack(x)
            attack_results.append(ar)

        shifts = [ar.brain_shift for ar in attack_results]
        region_agg: dict[str, list[float]] = {}
        for ar in attack_results:
            for rname, rshift in ar.region_shifts.items():
                region_agg.setdefault(rname, []).append(rshift)

        mean_region = {k: float(np.mean(v)) for k, v in region_agg.items()}
        most_vulnerable = max(mean_region, key=mean_region.get) if mean_region else ""
        most_robust = min(mean_region, key=mean_region.get) if mean_region else ""

        report = RobustnessReport(
            model_name=type(model).__name__,
            n_stimuli=len(stimuli),
            attack_name="BrainPGD",
            budget=budget,
            mean_brain_shift=float(np.mean(shifts)),
            max_brain_shift=float(np.max(shifts)) if shifts else 0.0,
            most_vulnerable_region=most_vulnerable,
            most_robust_region=most_robust,
            region_vulnerability=mean_region,
            per_stimulus=attack_results,
        )
        results[eps] = report

    return results


def region_vulnerability_map(
    model: BrainEncoderWrapper,
    stimuli: list[torch.Tensor],
    budget: PerturbationBudget | None = None,
    n_steps: int = 20,
) -> dict[str, float]:
    """Attack each ROI independently and report per-region vulnerability.

    For each region, runs a targeted attack that maximises disruption in
    *only* that region. Returns a dict of region → mean brain shift in that
    region.
    """
    from neuroprobe.attacks import RegionTargeted

    budget = budget or PerturbationBudget(epsilon=0.05)
    vuln: dict[str, float] = {}

    regions = [r for r in roi_names() if r != "whole_brain"]
    for rname in tqdm(regions, desc="Region vulnerability"):
        shifts: list[float] = []
        for x in stimuli:
            attacker = RegionTargeted(
                model, target_region=rname, budget=budget, n_steps=n_steps
            )
            ar = attacker.attack(x)
            # Get shift *in the target region*
            shift = ar.region_shifts.get(rname, ar.brain_shift)
            shifts.append(shift)
        vuln[rname] = float(np.mean(shifts))

    return dict(sorted(vuln.items(), key=lambda kv: -kv[1]))


def transferability_matrix(
    models: dict[str, BrainEncoderWrapper],
    stimuli: list[torch.Tensor],
    budget: PerturbationBudget | None = None,
    n_steps: int = 20,
) -> np.ndarray:
    """Compute transferability of adversarial examples across models/subjects.

    Generates adversarial examples on each source model and evaluates brain
    shift when applied to every target model.

    Parameters
    ----------
    models : dict mapping name → BrainEncoderWrapper
        E.g. different subject-specific models or different model variants.
    stimuli : list of torch.Tensor
    budget : PerturbationBudget
    n_steps : int

    Returns
    -------
    np.ndarray
        Matrix of shape (N, N) where entry [i, j] is the mean brain shift
        when adversarial examples crafted on model i are applied to model j.
        Row = source, column = target.
    """
    budget = budget or PerturbationBudget()
    names = list(models.keys())
    n = len(names)
    matrix = np.zeros((n, n), dtype=np.float64)

    for i, src_name in enumerate(tqdm(names, desc="Transfer source")):
        src_model = models[src_name]
        attacker = BrainPGD(src_model, budget=budget, n_steps=n_steps)

        # Generate adversarial perturbations on source model
        deltas: list[torch.Tensor] = []
        for x in stimuli:
            ar = attacker.attack(x)
            deltas.append(torch.tensor(ar.perturbation))

        # Evaluate on all target models
        for j, tgt_name in enumerate(names):
            tgt_model = models[tgt_name]
            shifts: list[float] = []
            for x, d in zip(stimuli, deltas):
                with torch.no_grad():
                    clean = tgt_model.predict_from_features(x)
                    adv = tgt_model.predict_from_features(x + d)
                    shift = (clean - adv).abs().mean().item()
                    shifts.append(shift)
            matrix[i, j] = float(np.mean(shifts))

    return matrix
