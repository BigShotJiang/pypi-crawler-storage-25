#!/usr/bin/env python
"""neuroprobe example: Full adversarial audit of a brain encoding model.

This script demonstrates ALL five attack types on the SyntheticEncoder
(no GPU or TRIBE v2 weights required). Replace SyntheticEncoder with
TRIBEv2Wrapper to attack the real model.

Usage:
    python examples/full_audit.py
    python examples/full_audit.py --output results.json
"""

from __future__ import annotations

import json
import sys
import time

import numpy as np
import torch

from neuroprobe._types import PerturbationBudget
from neuroprobe.attacks import (
    BrainFGSM,
    BrainPGD,
    CrossModalConfusion,
    RegionTargeted,
    UniversalBrainPerturbation,
)
from neuroprobe.analysis import robustness_curve, region_vulnerability_map
from neuroprobe.wrapper import SyntheticEncoder


def main() -> None:
    output_path = sys.argv[1] if len(sys.argv) > 1 else None

    print("╔══════════════════════════════════════════════════════════════╗")
    print("║  neuroprobe — Adversarial Brain Attack Audit                ║")
    print("║  Target: SyntheticEncoder (768-dim → 2048 vertices)        ║")
    print("╚══════════════════════════════════════════════════════════════╝\n")

    model = SyntheticEncoder(feature_dim=768, n_vertices=2048, seed=42)
    rng = np.random.RandomState(42)

    # Generate diverse synthetic stimuli (simulating different visual scenes)
    stimuli = [
        torch.tensor(rng.randn(10, 768).astype(np.float32)) * (1 + 0.5 * i)
        for i in range(8)
    ]

    results = {}

    # ── 1. FGSM (single-step baseline) ──────────────────────────────────
    print("━━━ Attack 1: BrainFGSM (ε=0.03, Linf) ━━━")
    t0 = time.time()
    budget = PerturbationBudget(epsilon=0.03, norm="linf")
    fgsm = BrainFGSM(model, budget=budget)
    ar = fgsm.attack(stimuli[0])
    elapsed = time.time() - t0
    print(f"  Brain shift:      {ar.brain_shift:.4f}")
    print(f"  L2 perturbation:  {ar.l2_distance:.4f}")
    print(f"  Time:             {elapsed:.2f}s")
    results["fgsm"] = {"brain_shift": ar.brain_shift, "l2": ar.l2_distance}

    # ── 2. PGD (iterative, stronger) ────────────────────────────────────
    print("\n━━━ Attack 2: BrainPGD (ε=0.03, 40 steps, Linf) ━━━")
    t0 = time.time()
    pgd = BrainPGD(model, budget=budget, n_steps=40)
    ar = pgd.attack(stimuli[0])
    elapsed = time.time() - t0
    print(f"  Brain shift:      {ar.brain_shift:.4f}")
    print(f"  L2 perturbation:  {ar.l2_distance:.4f}")
    print(f"  Time:             {elapsed:.2f}s")
    print("  Top 5 affected regions:")
    for rname, rshift in sorted(ar.region_shifts.items(), key=lambda kv: -kv[1])[:5]:
        print(f"    {rname:8s}: {rshift:.4f}")
    results["pgd"] = {"brain_shift": ar.brain_shift, "l2": ar.l2_distance,
                       "region_shifts": ar.region_shifts}

    # ── 3. Region-Targeted (surgical: activate FFA) ─────────────────────
    print("\n━━━ Attack 3: RegionTargeted → FFA (ε=0.05, 50 steps) ━━━")
    t0 = time.time()
    targeted = RegionTargeted(
        model, target_region="FFA",
        budget=PerturbationBudget(epsilon=0.05),
        n_steps=50, target_activation=3.0,
    )
    ar = targeted.attack(stimuli[0])
    elapsed = time.time() - t0
    print(f"  Brain shift:      {ar.brain_shift:.4f}")
    print(f"  FFA shift:        {ar.region_shifts.get('FFA', 0):.4f}")
    print(f"  V1 shift:         {ar.region_shifts.get('V1', 0):.4f}  (should be low)")
    print(f"  Time:             {elapsed:.2f}s")
    results["targeted_ffa"] = {"brain_shift": ar.brain_shift,
                                "ffa_shift": ar.region_shifts.get("FFA", 0)}

    # ── 4. Cross-Modal Confusion (visual → auditory-like) ───────────────
    print("\n━━━ Attack 4: CrossModalConfusion (visual → auditory) ━━━")
    t0 = time.time()
    xmodal = CrossModalConfusion(
        model, source_modality="visual",
        budget=PerturbationBudget(epsilon=0.05),
        n_steps=60,
    )
    ar = xmodal.attack(stimuli[0])
    elapsed = time.time() - t0
    print(f"  Brain shift:      {ar.brain_shift:.4f}")
    print(f"  A1 shift:         {ar.region_shifts.get('A1', 0):.4f}  (auditory — should increase)")
    print(f"  V1 shift:         {ar.region_shifts.get('V1', 0):.4f}  (visual — should decrease)")
    print(f"  Time:             {elapsed:.2f}s")
    results["crossmodal"] = {"brain_shift": ar.brain_shift,
                              "a1_shift": ar.region_shifts.get("A1", 0),
                              "v1_shift": ar.region_shifts.get("V1", 0)}

    # ── 5. Universal Adversarial Perturbation ───────────────────────────
    print("\n━━━ Attack 5: Universal Brain Perturbation (ε=0.03) ━━━")
    t0 = time.time()
    uap = UniversalBrainPerturbation(
        model, budget=PerturbationBudget(epsilon=0.03), n_epochs=5
    )
    uap.fit(stimuli[:5])
    elapsed_fit = time.time() - t0

    # Evaluate on held-out stimuli
    shifts = []
    for x in stimuli[5:]:
        ar = uap.attack(x)
        shifts.append(ar.brain_shift)
    mean_transfer = float(np.mean(shifts)) if shifts else 0.0

    print(f"  Fit time:         {elapsed_fit:.2f}s")
    print(f"  Transfer shift:   {mean_transfer:.4f} (on 3 unseen stimuli)")
    print(f"  Perturbation L2:  {float(np.linalg.norm(uap.universal_delta.numpy())):.4f}")
    results["universal"] = {"transfer_shift": mean_transfer}

    # ── 6. Robustness Curve ─────────────────────────────────────────────
    print("\n━━━ Robustness Curve (ε from 0.001 to 0.1) ━━━")
    curve = robustness_curve(
        model, stimuli[:4],
        epsilons=[0.001, 0.005, 0.01, 0.02, 0.05, 0.1],
        n_steps=10,
    )
    print(f"\n  {'ε':>8s}  {'Brain Shift':>12s}  {'Most Vulnerable':>18s}")
    print("  " + "─" * 42)
    curve_data = {}
    for eps, report in curve.items():
        print(f"  {eps:>8.3f}  {report.mean_brain_shift:>12.4f}  {report.most_vulnerable_region:>18s}")
        curve_data[str(eps)] = report.mean_brain_shift

    results["robustness_curve"] = curve_data

    # ── 7. Region Vulnerability Map ──────────────────────────────────────
    print("\n━━━ Region Vulnerability Map ━━━")
    vuln = region_vulnerability_map(model, stimuli[:3], n_steps=10)
    print(f"\n  {'Region':>10s}  {'Vulnerability':>14s}")
    print("  " + "─" * 30)
    for rname, v in list(vuln.items())[:10]:
        bar = "█" * min(int(v * 40), 30)
        print(f"  {rname:>10s}  {v:>10.4f}    {bar}")

    results["region_vulnerability"] = vuln

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  AUDIT COMPLETE                                            ║")
    print("╠══════════════════════════════════════════════════════════════╣")
    print(f"║  FGSM brain shift:        {results['fgsm']['brain_shift']:<8.4f}                     ║")
    print(f"║  PGD brain shift:         {results['pgd']['brain_shift']:<8.4f}  ({results['pgd']['brain_shift']/results['fgsm']['brain_shift']:.1f}x FGSM)       ║")
    print(f"║  Targeted FFA shift:      {results['targeted_ffa']['ffa_shift']:<8.4f}                     ║")
    print(f"║  Cross-modal shift:       {results['crossmodal']['brain_shift']:<8.4f}                     ║")
    print(f"║  Universal transfer:      {results['universal']['transfer_shift']:<8.4f}                     ║")
    print(f"║  Most vulnerable region:  {list(vuln.keys())[0] if vuln else 'N/A':18s}           ║")
    print("╚══════════════════════════════════════════════════════════════╝")

    if output_path:
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\nResults saved to {output_path}")


if __name__ == "__main__":
    main()
