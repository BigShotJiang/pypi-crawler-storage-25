#!/usr/bin/env python
"""Generate actual adversarial video, audio, and text files.

Demonstrates end-to-end attacks that produce real media with imperceptible
perturbations causing the brain model to predict targeted cortical activation.

Usage:
    python examples/generate_adversarial_media.py
    python examples/generate_adversarial_media.py --output-dir ./output
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import torch

from neuroprobe._types import PerturbationBudget
from neuroprobe.media import (
    build_brain_model,
    synthesize_video,
    synthesize_audio,
    save_audio,
    compute_psnr,
    compute_snr,
)
from neuroprobe.stimulus_attacks import VideoPGD, AudioPGD, TextPGD
from neuroprobe.regions import roi_mask


VOCABULARY = [
    "<pad>", "the", "a", "an", "in", "on", "at", "by", "to", "of",
    "and", "or", "but", "is", "was", "are", "were", "be", "been",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "must", "can", "need",
    "I", "you", "he", "she", "it", "we", "they", "me", "him", "her",
    "us", "them", "my", "your", "his", "its", "our", "their",
    "this", "that", "these", "those", "what", "which", "who", "whom",
    "cat", "dog", "bird", "fish", "horse", "mouse", "rabbit", "fox",
    "tree", "flower", "grass", "leaf", "root", "branch", "seed",
    "house", "door", "window", "wall", "floor", "roof", "room",
    "hand", "eye", "face", "head", "body", "arm", "leg", "foot",
    "water", "fire", "earth", "air", "light", "dark", "sun", "moon",
    "red", "blue", "green", "yellow", "white", "black", "bright", "dim",
    "big", "small", "tall", "short", "long", "wide", "deep", "thin",
    "fast", "slow", "hot", "cold", "warm", "cool", "wet", "dry",
    "good", "bad", "new", "old", "young", "strong", "weak",
    "run", "walk", "sit", "stand", "jump", "swim", "fly", "climb",
    "see", "hear", "feel", "touch", "smell", "taste", "think", "know",
    "say", "tell", "ask", "give", "take", "make", "put", "get",
    "come", "go", "move", "stop", "start", "turn", "open", "close",
    "eat", "drink", "sleep", "wake", "play", "work", "read", "write",
    "sing", "dance", "laugh", "cry", "smile", "dream", "watch", "listen",
    "above", "below", "near", "far", "here", "there", "up", "down",
    "left", "right", "front", "back", "inside", "outside", "through",
    "under", "over", "across", "along", "around", "between", "among",
    "morning", "evening", "night", "day", "time", "hour", "minute",
    "spring", "summer", "autumn", "winter", "rain", "snow", "wind",
    "happy", "sad", "angry", "calm", "quiet", "loud", "soft", "hard",
    "many", "few", "some", "all", "each", "every", "any", "no",
    "very", "quite", "rather", "just", "still", "also", "only", "even",
    "now", "then", "soon", "later", "before", "after", "while", "since",
    "mountain", "river", "ocean", "forest", "field", "garden", "path",
    "stone", "cloud", "star", "sky", "wave", "shore", "sand", "dust",
    "child", "mother", "father", "friend", "home", "love", "hope",
    "music", "sound", "voice", "song", "word", "story", "picture",
    "paper", "book", "pen", "table", "chair", "bed", "lamp",
    "food", "bread", "fruit", "heart", "mind", "soul", "spirit",
    "road", "bridge", "gate", "tower", "castle", "church", "market",
    "king", "queen", "lord", "knight", "farmer", "sailor", "hunter",
    "sword", "shield", "crown", "ring", "bell", "key", "flag",
    "silver", "golden", "iron", "wooden", "ancient", "modern", "simple",
    "beautiful", "strange", "wild", "gentle", "fierce", "brave", "wise",
    "sat", "stood", "lay", "fell", "rose", "grew", "kept", "found",
    "lost", "held", "brought", "caught", "spoke", "sang", "wore",
    "beneath", "beside", "within", "without", "beyond",
    "anything", "everything", "nothing", "something", "someone",
    "always", "never", "often", "sometimes", "together", "alone",
    "slowly", "quickly", "gently", "silently", "carefully", "suddenly",
    "village", "valley", "harbor", "meadow", "hill", "plain", "cliff",
    "stream", "pond", "lake", "island", "cave", "trail", "peak",
    "ice", "frost", "dew", "mist", "fog", "haze", "storm",
    "eagle", "owl", "crow", "swan", "dove", "sparrow", "hawk",
    "wolf", "bear", "deer", "lion", "tiger", "snake", "turtle",
    "boat", "ship", "wheel", "rope", "sail", "anchor", "compass",
    "dawn", "dusk", "twilight", "midnight", "noon", "sunrise", "sunset",
    "echo", "shadow", "flame", "spark", "smoke", "ash", "ember",
    "orchard", "vineyard", "harvest", "season", "blossom", "petal",
]


def _roi_stats(pred: torch.Tensor, region: str, n_v: int) -> float:
    m = torch.tensor(roi_mask(region, n_v), dtype=torch.bool)
    return pred[:, m].abs().mean().item()


def _roi_shift(orig: torch.Tensor, adv: torch.Tensor, region: str, n_v: int) -> float:
    m = torch.tensor(roi_mask(region, n_v), dtype=torch.bool)
    return (adv[:, m] - orig[:, m]).abs().mean().item()


def main() -> None:
    out = Path(sys.argv[2] if len(sys.argv) > 2 else "adversarial_output")
    out.mkdir(parents=True, exist_ok=True)

    torch.manual_seed(42)
    np.random.seed(42)
    N_V = 2048

    # ═════════════════════════════════════════════════════════════════
    # 1. ADVERSARIAL VIDEO → target FFA (face area)
    # ═════════════════════════════════════════════════════════════════
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║  1. ADVERSARIAL VIDEO — target FFA (face perception)       ║")
    print("╚══════════════════════════════════════════════════════════════╝")

    vm = build_brain_model("video", n_vertices=N_V, seed=42)
    video = synthesize_video(n_frames=10, height=64, width=64, seed=42)

    print(f"  Input:  {video.shape[0]} frames × {video.shape[2]}×{video.shape[3]} RGB")
    print(f"  Budget: ε=0.02 L∞ (~5/255 pixel change, imperceptible)")
    print(f"  Target: FFA — fusiform face area")
    print(f"  Running VideoPGD, 100 steps...", flush=True)

    t0 = time.time()
    adv_video, vr = VideoPGD(
        vm,
        budget=PerturbationBudget(epsilon=0.02),
        n_steps=100,
        target_regions=["FFA"],
    ).attack(video)
    dt = time.time() - t0

    psnr = compute_psnr(video, adv_video)
    o, a = torch.tensor(vr.original_prediction), torch.tensor(vr.adversarial_prediction)
    clean_mean = o.abs().mean().item()

    np.save(str(out / "original_video.npy"), video.numpy())
    np.save(str(out / "adversarial_video.npy"), adv_video.numpy())
    np.save(str(out / "video_perturbation.npy"), vr.perturbation)

    print(f"\n  ✓ PSNR: {psnr:.1f} dB  (>40 = visually identical)")
    print(f"  ✓ Brain shift: {vr.brain_shift / clean_mean * 100:.1f}%")
    print(f"  ✓ FFA shift: {_roi_shift(o, a, 'FFA', N_V):.4f}  (target region)")
    print(f"  ✓ A1 shift:  {_roi_shift(o, a, 'A1', N_V):.4f}  (non-target)")
    print(f"  ✓ FFA |BOLD|: {_roi_stats(o, 'FFA', N_V):.3f} → {_roi_stats(a, 'FFA', N_V):.3f}")
    print(f"  ✓ Time: {dt:.1f}s")
    print(f"  ✓ Saved: {out}/original_video.npy, adversarial_video.npy")
    print()
    print("  → A human viewing this video would appear (to the model)")
    print("    to have face-processing areas active from non-face content.")

    # ═════════════════════════════════════════════════════════════════
    # 2. ADVERSARIAL AUDIO → target V1/V2 (visual cortex)
    # ═════════════════════════════════════════════════════════════════
    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  2. ADVERSARIAL AUDIO — target V1/V2 (visual cortex)      ║")
    print("╚══════════════════════════════════════════════════════════════╝")

    am = build_brain_model("audio", n_vertices=N_V, seed=42)
    audio = synthesize_audio(duration=1.0, sample_rate=16000, seed=42)

    print(f"  Input:  {audio.shape[0]} samples ({audio.shape[0] / 16000:.1f}s @ 16kHz)")
    print(f"  Budget: ε=0.03 L∞ (~8/255 pixel change, imperceptible)")
    print(f"  Target: V1 + V2 — primary visual cortex")
    print(f"  Running AudioPGD, 100 steps...", flush=True)

    t0 = time.time()
    adv_audio, ar = AudioPGD(
        am,
        budget=PerturbationBudget(epsilon=0.03),
        n_steps=100,
        target_regions=["V1", "V2"],
    ).attack(audio)
    dt = time.time() - t0

    snr = compute_snr(audio, adv_audio - audio)
    o, a = torch.tensor(ar.original_prediction), torch.tensor(ar.adversarial_prediction)
    clean_mean = o.abs().mean().item()

    save_audio(audio, str(out / "original_audio.wav"), 16000)
    save_audio(adv_audio, str(out / "adversarial_audio.wav"), 16000)

    print(f"\n  ✓ SNR: {snr:.1f} dB  (>30 = imperceptible)")
    print(f"  ✓ Brain shift: {ar.brain_shift / clean_mean * 100:.1f}%")
    print(f"  ✓ V1 shift: {_roi_shift(o, a, 'V1', N_V):.4f}  (target)")
    print(f"  ✓ V2 shift: {_roi_shift(o, a, 'V2', N_V):.4f}  (target)")
    print(f"  ✓ A1 shift: {_roi_shift(o, a, 'A1', N_V):.4f}  (non-target)")
    print(f"  ✓ Time: {dt:.1f}s")
    print(f"  ✓ Saved: {out}/original_audio.wav, adversarial_audio.wav")
    print()
    print("  → A human hearing this audio would appear (to the model)")
    print("    to have visual cortex activation — cross-modal confusion.")

    # ═════════════════════════════════════════════════════════════════
    # 3. ADVERSARIAL TEXT → target motor cortex
    # ═════════════════════════════════════════════════════════════════
    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  3. ADVERSARIAL TEXT — target motor cortex                 ║")
    print("╚══════════════════════════════════════════════════════════════╝")

    tm = build_brain_model("text", n_vertices=N_V, seed=42, vocab_size=len(VOCABULARY))

    sentence = "the cat sat on the wall by the window watching birds"
    words = sentence.split()
    w2i = {w: i for i, w in enumerate(VOCABULARY)}
    token_ids = torch.tensor([w2i.get(w, 0) for w in words], dtype=torch.long)

    print(f'  Input:  "{sentence}"')
    print(f"  Budget: L2=8.0 in embedding space")
    print(f"  Target: motor cortex")
    print(f"  Running TextPGD, 100 steps...", flush=True)

    t0 = time.time()
    adv_tokens, tr, adv_text = TextPGD(
        tm,
        budget=PerturbationBudget(epsilon=8.0, norm="l2"),
        n_steps=100,
        target_regions=["motor"],
    ).attack(token_ids, vocabulary=VOCABULARY)
    dt = time.time() - t0

    n_changed = sum(1 for a, b in zip(token_ids.tolist(), adv_tokens.tolist()) if a != b)
    o, a = torch.tensor(tr.original_prediction), torch.tensor(tr.adversarial_prediction)
    clean_mean = o.abs().mean().item()

    with open(out / "adversarial_text.txt", "w") as f:
        f.write(f"Original:    {sentence}\n")
        f.write(f"Adversarial: {adv_text}\n")
        f.write(f"Changed:     {n_changed}/{len(words)} words\n")

    print(f'\n  ✓ Original:    "{sentence}"')
    print(f'  ✓ Adversarial: "{adv_text}"')
    print(f"  ✓ Words changed: {n_changed}/{len(words)}")
    print(f"  ✓ Brain shift: {tr.brain_shift / clean_mean * 100:.1f}%")
    print(f"  ✓ Motor shift: {_roi_shift(o, a, 'motor', N_V):.4f}  (target)")
    print(f"  ✓ V1 shift:    {_roi_shift(o, a, 'V1', N_V):.4f}  (non-target)")
    print(f"  ✓ Time: {dt:.1f}s")
    print(f"  ✓ Saved: {out}/adversarial_text.txt")
    print()
    print("  → A human reading this text would appear (to the model)")
    print("    to have elevated motor cortex activity.")

    # ═════════════════════════════════════════════════════════════════
    # Summary
    # ═════════════════════════════════════════════════════════════════
    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  ALL ADVERSARIAL MEDIA GENERATED                           ║")
    print("╠══════════════════════════════════════════════════════════════╣")
    print(f"║  Output: {str(out) + '/':50s}║")
    print("║                                                            ║")
    print("║  • adversarial_video.npy — looks identical, activates FFA  ║")
    print("║  • adversarial_audio.wav — sounds identical, activates V1  ║")
    print("║  • adversarial_text.txt  — reads similar, activates motor  ║")
    print("║                                                            ║")
    print("║  These are real adversarial stimuli.  When presented to    ║")
    print("║  a brain encoding model, they cause it to predict          ║")
    print("║  targeted cortical activation in specific brain regions.   ║")
    print("╚══════════════════════════════════════════════════════════════╝")


if __name__ == "__main__":
    main()
