#!/usr/bin/env python
"""neuroprobe example: Attack Meta's TRIBE v2 (requires GPU + model weights).

This script loads the real TRIBE v2 model from HuggingFace and runs
adversarial attacks on its predicted brain responses.

Prerequisites:
    pip install neuroprobe[tribe]
    # or: pip install tribev2

Usage:
    python examples/attack_tribev2.py --video path/to/video.mp4
    python examples/attack_tribev2.py --video path/to/video.mp4 --target-region FFA
"""

from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np
import torch

from neuroprobe._types import PerturbationBudget
from neuroprobe.attacks import BrainPGD, RegionTargeted, CrossModalConfusion
from neuroprobe.wrapper import TRIBEv2Wrapper


def main() -> None:
    parser = argparse.ArgumentParser(description="Attack TRIBE v2")
    parser.add_argument("--video", required=True, help="Path to input video")
    parser.add_argument("--model", default="facebook/tribev2")
    parser.add_argument("--cache", default="./cache")
    parser.add_argument("--epsilon", type=float, default=0.03)
    parser.add_argument("--steps", type=int, default=40)
    parser.add_argument("--target-region", default=None)
    parser.add_argument("--output", default="tribev2_attack_results.json")
    args = parser.parse_args()

    print("Loading TRIBE v2...")
    model = TRIBEv2Wrapper(model_name=args.model, cache_folder=args.cache)

    print(f"Encoding stimulus: {args.video}")
    features = model.encode_stimulus(args.video)
    print(f"  Feature shape: {features.shape}")

    budget = PerturbationBudget(epsilon=args.epsilon)

    if args.target_region:
        print(f"\nRunning RegionTargeted attack → {args.target_region}")
        attacker = RegionTargeted(
            model, target_region=args.target_region,
            budget=budget, n_steps=args.steps,
        )
    else:
        print("\nRunning BrainPGD attack (untargeted)")
        attacker = BrainPGD(model, budget=budget, n_steps=args.steps)

    t0 = time.time()
    result = attacker.attack(features)
    elapsed = time.time() - t0

    print(f"\nResults:")
    print(f"  Brain shift:      {result.brain_shift:.6f}")
    print(f"  L2 perturbation:  {result.l2_distance:.6f}")
    print(f"  Linf perturbation: {result.linf_distance:.6f}")
    print(f"  Time:             {elapsed:.1f}s")

    if result.region_shifts:
        print("\n  Per-region shifts (top 10):")
        for rname, rshift in sorted(result.region_shifts.items(), key=lambda kv: -kv[1])[:10]:
            print(f"    {rname:10s}: {rshift:.6f}")

    out = {
        "video": args.video,
        "epsilon": args.epsilon,
        "attack": result.attack_name,
        "brain_shift": result.brain_shift,
        "l2_distance": result.l2_distance,
        "region_shifts": result.region_shifts,
        "time_seconds": elapsed,
    }
    with open(args.output, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved to {args.output}")


if __name__ == "__main__":
    main()
