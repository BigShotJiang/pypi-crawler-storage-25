import httpx
import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis_jsonschema import from_schema
from pydantic import ValidationError

from tokenlists import TokenList

TOKENLISTS_SCHEMA = "https://uniswap.org/tokenlist.schema.json"
TOKENLISTS_SCHEMA_JSON = httpx.get(TOKENLISTS_SCHEMA, follow_redirects=True).json()


def clean_data(tl: dict) -> dict:
    # NOTE: Timestamps can be in any format, and our processing handles it okay
    #       However, for testing purposes, we want the output format to line up,
    #       and unfortunately there is some ambiguity in ISO timestamp formats.
    tl["timestamp"] = tl["timestamp"].replace("Z", "+00:00")

    # NOTE: We do not implement `tokenMap` schema version yet
    if "tokenMap" in tl:
        del tl["tokenMap"]

    return tl


def comparable_data(tl: dict) -> dict:
    return clean_data(dict(tl))


@pytest.mark.fuzzing
@given(token_list=from_schema(TOKENLISTS_SCHEMA_JSON))
@settings(suppress_health_check=(HealthCheck.too_slow,))
def test_schema(token_list):
    try:
        validated = TokenList.model_validate(token_list).model_dump(mode="json")
        assert comparable_data(validated) == comparable_data(token_list)

    except (ValidationError, ValueError):
        pass  # Expect these kinds of errors
