from .base import ArgsOnlyFn, Literal, KwargsOnlyFn, NodeBase
from typing import ClassVar, Any
import polars as pl
import string
from .types import DATE_TIME_TYPES


class StringInterpolate(ArgsOnlyFn):
    """This non-terminal node represents an f-string interpolation.

    The arguments passed upon construction are (1) the pattern string and (2) the fields used to fill that
    pattern string. Note that during normal construction, the fields cannot be inferred from the pattern
    string; however, this can be done when parsing from a string via the `from_lark` class method used for
    string -> dictionary form conversion.

    Example:
        >>> from dftly.nodes import Literal, Column
        >>> df = pl.DataFrame({"name": ["Alice", "Bob"]})
        >>> df
        shape: (2, 1)
        ┌───────┐
        │ name  │
        │ ---   │
        │ str   │
        ╞═══════╡
        │ Alice │
        │ Bob   │
        └───────┘
        >>> df.select(StringInterpolate(Literal("hello {}"), Column("name")).polars_expr)
        shape: (2, 1)
        ┌─────────────┐
        │ literal     │
        │ ---         │
        │ str         │
        ╞═════════════╡
        │ hello Alice │
        │ hello Bob   │
        └─────────────┘

    The pattern string can also be constructed from other nodes that evaluate to strings:

        >>> from dftly.nodes import Add
        >>> df.select(StringInterpolate(Add(Literal("hello "), Literal("{}")), Column("name")).polars_expr)
        shape: (2, 1)
        ┌─────────────┐
        │ literal     │
        │ ---         │
        │ str         │
        ╞═════════════╡
        │ hello Alice │
        │ hello Bob   │
        └─────────────┘

    At least two arguments (pattern + fields) are required:

        >>> StringInterpolate(Literal("hello {}"))
        Traceback (most recent call last):
            ...
        ValueError: StringInterpolate requires more than one argument; ...

    A pattern that cannot be evaluated as a literal raises an error:

        >>> StringInterpolate(Column("x"), Column("name"))
        Traceback (most recent call last):
            ...
        ValueError: The pattern argument must be a string, Literal, or Literal-evaluatable instance. ...

    A non-string pattern raises an error:

        >>> StringInterpolate(Literal(42), Column("name"))
        Traceback (most recent call last):
            ...
        ValueError: The pattern argument must be a string, ...

    The ``from_lark`` method requires exactly one argument:

        >>> StringInterpolate.from_lark(["a", "b"])
        Traceback (most recent call last):
            ...
        ValueError: StringInterpolate.from_lark only accepts a single argument...

    A non-literal dict in ``from_lark`` raises an error:

        >>> StringInterpolate.from_lark([{"column": "x"}])
        Traceback (most recent call last):
            ...
        ValueError: When using `from_lark` with a dictionary, the dictionary must resolve to a Literal node.
    """

    KEY = "string_interpolate"

    def __post_init__(self):
        super().__post_init__()

        if len(self.args) <= 1:
            raise ValueError(
                "StringInterpolate requires more than one argument; it takes both the pattern string (first) "
                "and the fields to interpolate into the pattern (subsequent). "
                f"Got {len(self.args)} argument(s): {self.args}. "
                'If you want to infer the fields from the pattern, use a string (e.g., \'f"foo{$bar}" and '
                "the fields will be inferred automatically."
            )

        pattern = self.args[0]

        try:
            pattern = pl.select(pattern.polars_expr).item()
        except Exception as e:
            raise ValueError(
                "The pattern argument must be a string, Literal, or Literal-evaluatable instance. "
                "This `NodeBase` instance can't be evaluated to a string literal."
            ) from e

        if not isinstance(pattern, str):
            raise ValueError(
                "The pattern argument must be a string, Literal, or Literal-evaluatable instance that "
                f"evaluates to a string. This `NodeBase` instance evaluates to a {type(pattern)} instead."
            )

        self.pattern = pattern
        self.fields = [a.polars_expr for a in self.args[1:]]

    @classmethod
    def from_lark(cls, items: list[str | dict]) -> dict[str, list]:
        if len(items) != 1:
            raise ValueError(
                "StringInterpolate.from_lark only accepts a single argument, which is the pattern string. "
                f"Got {len(items)} arguments instead: {items}"
            )

        pattern = items[0]
        if isinstance(pattern, dict):
            if not Literal.matches(pattern):
                raise ValueError(
                    "When using `from_lark` with a dictionary, the dictionary must resolve to a Literal node."
                )
            pattern = Literal.args_from_value(pattern)[0][0]
        fields = []
        fmt_parts = []
        for literal, field, _, _ in string.Formatter().parse(pattern):
            fmt_parts.append(literal)
            if field is not None:
                fmt_parts.append("{}")
                fields.append(field)

        pattern = "".join(fmt_parts)
        pattern_lit = {"literal": pattern}

        return {cls.KEY: [pattern_lit] + fields}

    @property
    def polars_expr(self) -> pl.Expr:
        return pl.format(self.pattern, *self.fields)


class RegexExtract(KwargsOnlyFn):
    """This node extracts a regex pattern from a target node.

    This node only accepts keyword arguments, and requires "pattern" and "source" keys, with an optional
    "group_index" key. The "pattern" key is the regex pattern to extract, the "source" key is the target node to
    extract from, and the "group_index" key is the index of the regex group to extract. If not provided, the
    entire match is extracted.

    The group_index, if provided, must be or evaluate (outside of a polars context) to a non-negative integer.

    Example:
        >>> from dftly.nodes import Literal, Column
        >>> df = pl.DataFrame({"text": ["foo123bar", "baz456qux"]})
        >>> df
        shape: (2, 1)
        ┌───────────┐
        │ text      │
        │ ---       │
        │ str       │
        ╞═══════════╡
        │ foo123bar │
        │ baz456qux │
        └───────────┘
        >>> pattern = Literal(r"([a-z]+)([0-9]+)([a-z]+)")
        >>> df.select(RegexExtract(pattern=pattern, source=Column("text")).polars_expr)
        shape: (2, 1)
        ┌───────────┐
        │ text      │
        │ ---       │
        │ str       │
        ╞═══════════╡
        │ foo123bar │
        │ baz456qux │
        └───────────┘
        >>> group = Literal(1)
        >>> df.select(RegexExtract(pattern=pattern, source=Column("text"), group_index=group).polars_expr)
        shape: (2, 1)
        ┌──────┐
        │ text │
        │ ---  │
        │ str  │
        ╞══════╡
        │ foo  │
        │ baz  │
        └──────┘

    A negative group index raises an error:

        >>> RegexExtract(pattern=Literal(r"\\d+"), source=Literal("abc"), group_index=Literal(-1))
        Traceback (most recent call last):
            ...
        ValueError: The group_index argument must be a non-negative integer.

    A non-integer group index raises an error:

        >>> RegexExtract(pattern=Literal(r"\\d+"), source=Literal("abc"), group_index=Literal("x"))
        Traceback (most recent call last):
            ...
        ValueError: The group_index argument must be an integer...

    A non-NodeBase group index raises an error:

        >>> RegexExtract(pattern=Literal(r"\\d+"), source=Literal("abc"), group_index="bad")
        Traceback (most recent call last):
            ...
        TypeError: all keyword arguments to regex_extract must be str:NodeBase pairs

    The group_index property validates its input type and evaluatability:

        >>> node = RegexExtract(pattern=Literal(r"\\d+"), source=Literal("abc"))
        >>> node.kwargs["group_index"] = "not_a_node"
        >>> node.group_index
        Traceback (most recent call last):
            ...
        ValueError: The group_index argument must be an integer or a NodeBase instance ...Got <class 'str'>...
        >>> node.kwargs["group_index"] = Column("x")
        >>> node.group_index
        Traceback (most recent call last):
            ...
        ValueError: The group_index argument must be an integer or a NodeBase instance ...can't be evaluated...
    """

    KEY = "regex_extract"
    REQUIRED_KWARGS = {"pattern", "source"}
    OPTIONAL_KWARGS = {"group_index"}

    def __post_init__(self):
        super().__post_init__()

        if not isinstance(self.group_index, int):
            raise ValueError(
                "The group_index argument must be an integer or a NodeBase instance that evaluates "
                f"to an integer. This `NodeBase` instance evaluates to a {type(self.group_index)} instead."
            )
        if self.group_index < 0:
            raise ValueError("The group_index argument must be a non-negative integer.")

    @property
    def group_index(self) -> int:
        group_index = self.kwargs.get("group_index", 0)

        if isinstance(group_index, int):
            return group_index

        if not isinstance(group_index, NodeBase):
            raise ValueError(
                "The group_index argument must be an integer or a NodeBase instance that evaluates "
                f"to an integer. Got {type(group_index)} instead."
            )

        try:
            return pl.select(group_index.polars_expr).item()
        except Exception as e:
            raise ValueError(
                "The group_index argument must be an integer or a NodeBase instance that evaluates "
                "to an integer. This `NodeBase` instance can't be evaluated to an integer."
            ) from e

    @property
    def polars_expr(self) -> pl.Expr:
        source_expr = self.kwargs["source"].polars_expr
        pattern = self.kwargs["pattern"].polars_expr
        return source_expr.str.extract(pattern, self.group_index)

    @classmethod
    def from_lark(cls, items: list[Any]) -> dict[str, Any]:
        if len(items) == 2:
            kwargs = {"pattern": items[0], "source": items[1]}
        elif len(items) == 3:
            kwargs = {"pattern": items[1], "source": items[2], "group_index": items[0]}

        return {cls.KEY: kwargs}


class RegexMatch(KwargsOnlyFn):
    """This node matches a regex pattern against a target node.

    This node only accepts keyword arguments, and requires "pattern" and "source" keys. The "pattern" key is
    the regex pattern to match, and the "source" key is the target node to match against. The result is a
    boolean indicating whether the pattern matches the target.

    Example:
        >>> from dftly.nodes import Literal, Column
        >>> df = pl.DataFrame({"text": ["foo123bar", "baz456qux", "no_digits"]})
        >>> df
        shape: (3, 1)
        ┌───────────┐
        │ text      │
        │ ---       │
        │ str       │
        ╞═══════════╡
        │ foo123bar │
        │ baz456qux │
        │ no_digits │
        └───────────┘
        >>> pattern = Literal(r"[0-9]+")
        >>> df.select(RegexMatch(pattern=pattern, source=Column("text")).polars_expr)
        shape: (3, 1)
        ┌───────┐
        │ text  │
        │ ---   │
        │ bool  │
        ╞═══════╡
        │ true  │
        │ true  │
        │ false │
        └───────┘
    """

    KEY = "regex_match"
    REQUIRED_KWARGS = {"pattern", "source"}

    @property
    def polars_expr(self) -> pl.Expr:
        source_expr = self.kwargs["source"].polars_expr
        pattern = self.kwargs["pattern"].polars_expr
        return source_expr.str.contains(pattern, literal=False)

    @classmethod
    def from_lark(cls, items: list[Any]) -> dict[str, Any]:
        pattern, source = items

        return {cls.KEY: {"pattern": pattern, "source": source}}


class Strptime(KwargsOnlyFn):
    """This node parses a string into a datetime using a specified format.

    This node only accepts keyword arguments, and requires "format" and "source" keys. The "format" key is the
    datetime format string, and the "source" key is the target node to parse. The result will be either a
    date, time, or datetime type, depending on the format string.

    Example:
        >>> from dftly.nodes import Literal
        >>> date = Strptime(format=Literal("%Y-%m-%d"), source=Literal("2023-01-01"))
        >>> pl.select(date.polars_expr).item()
        datetime.date(2023, 1, 1)
        >>> time = Strptime(format=Literal("%H:%M:%S"), source=Literal("12:34:56"))
        >>> pl.select(time.polars_expr).item()
        datetime.time(12, 34, 56)
        >>> datetime = Strptime(format=Literal("%Y-%m-%d %H:%M:%S"), source=Literal("2023-01-01 12:34:56"))
        >>> pl.select(datetime.polars_expr).item()
        datetime.datetime(2023, 1, 1, 12, 34, 56)

    Note that this can result in ambiguous values given the format string. For example, the example below
    parses a year followed by an hour, which means the resulting datetime will have inferred months and days.

        >>> pl.select(Strptime(format=Literal("%Y %H:%M"), source=Literal("2023 12:11")).polars_expr).item()
        datetime.datetime(2023, 1, 1, 12, 11)

    Non-strict parsing produces null instead of raising on format mismatch:

        >>> non_strict = Strptime(
        ...     format=Literal("%Y-%m-%d %H:%M:%S"),
        ...     source=Literal("2020-06-20"),
        ...     strict=Literal(False),
        ... )
        >>> print(pl.select(non_strict.polars_expr).item())
        None

    A non-string format raises an error:

        >>> Strptime(format=Literal(42), source=Literal("2023-01-01"))
        Traceback (most recent call last):
            ...
        ValueError: The format argument must be a NodeBase instance that evaluates to a string. ...

    A format with no date or time components raises an error:

        >>> Strptime(format=Literal("hello"), source=Literal("world")).polars_expr
        Traceback (most recent call last):
            ...
        ValueError: The format string must contain at least one date or time component. ...

    A non-boolean strict value raises an error:

        >>> Strptime(format=Literal("%Y-%m-%d"), source=Literal("2023-01-01"), strict=Literal("yes")).polars_expr
        Traceback (most recent call last):
            ...
        ValueError: The strict argument must be a boolean, ...

    The format_str and strict properties validate their input types:

        >>> from dftly.nodes import Column
        >>> node = Strptime(format=Literal("%Y-%m-%d"), source=Literal("2023-01-01"))
        >>> node.kwargs["format"] = "not_a_node"
        >>> node.format_str
        Traceback (most recent call last):
            ...
        ValueError: The format argument must be a NodeBase instance ...Got <class 'str'>...
        >>> node.kwargs["format"] = Column("x")
        >>> node.format_str
        Traceback (most recent call last):
            ...
        ValueError: The format argument must be a NodeBase instance ...can't be evaluated...
        >>> node.kwargs["strict"] = "not_a_node"
        >>> node.strict
        Traceback (most recent call last):
            ...
        ValueError: The strict argument must be a NodeBase instance ...
        >>> node.kwargs["strict"] = Column("x")
        >>> node.strict
        Traceback (most recent call last):
            ...
        ValueError: The strict argument must evaluate to a boolean.
    """

    KEY = "strptime"
    REQUIRED_KWARGS = {"format", "source"}
    OPTIONAL_KWARGS = {"strict"}

    # See https://docs.rs/chrono/latest/chrono/format/strftime/index.html
    DATE_PARTS: ClassVar[set[str]] = {
        "Y",  # Year with century
        "G",  # ISO 8601 year with century
        "C",  # Century
        "q",  # Quarter
        "y",  # Year without century
        "g",  # ISO 8601 year without century
        "m",  # Month as a zero-padded decimal number
        "b",  # Abbreviated month name
        "B",  # Full month name
        "h",  # Abbreviated month name
        "d",  # Day of the month as a zero-padded decimal number
        "e",  # Day of the month as a decimal number
        "a",  # Abbreviated weekday name
        "A",  # Full weekday name
        "w",  # Weekday as a decimal number (0=Sunday, 6=Saturday)
        "u",  # Weekday as a decimal number (1=Monday, 7=Sunday)
        "j",  # Day of the year as a zero-padded decimal number
        "U",  # Week number of the year (Sunday as the first day of the week)
        "W",  # Week number of the year (Monday as the first day of the week)
        "V",  # ISO 8601 week number of the year (Monday as the first day of the week)
        "D",  # Equivalent to %m/%d/%y
        "x",  # Locale's appropriate date representation
        "F",  # Equivalent to %Y-%m-%d
        "v",  # VMS date format (%e-%b-%Y)
    }

    TIME_PARTS: ClassVar[set[str]] = {
        "H",  # Hour (24-hour clock) as a zero-padded decimal number
        "k",  # Hour (24-hour clock) as a decimal number
        "I",  # Hour (12-hour clock) as a zero-padded decimal number
        "l",  # Hour (12-hour clock) as a decimal number
        "M",  # Minute as a zero-padded decimal number
        "S",  # Second as a zero-padded decimal number
        "f",  # Microsecond as a decimal number, zero-padded on the left
        "3f",  # Millisecond as a decimal number, zero-padded on the left
        "6f",  # Microsecond as a decimal number, zero-padded on the left
        "9f",  # Nanosecond as a decimal number, zero-padded on the left
        "p",  # AM or PM
        "P",  # am or pm
        "r",  # Equivalent to %I:%M:%S %p
        "R",  # Equivalent to %H:%M
        "T",  # Equivalent to %H:%M:%S
        "X",  # Locale's appropriate time representation
        "z",  # UTC offset in the form +HHMM or -HHMM
        ":z",  # UTC offset in the form +HH:MM or -HH:MM
        "::z",  # UTC offset in the form +HH:MM:SS or -HH:MM:SS
        ":::z",  # UTC offset in the form +HH
        "Z",  # Time zone name
    }

    DATETIME_PARTS: ClassVar[set[str]] = {
        "c",  # Locale's appropriate date and time representation
        "+",  # Equivalent to %Y-%m-%dT%H:%M:%S%:z
        "s",  # Unix timestamp (seconds since January 1, 1970 0:00:00 UTC)
    }

    def __post_init__(self):
        super().__post_init__()

        if not isinstance(self.format_str, str):
            raise ValueError(
                "The format argument must be a NodeBase instance that evaluates to a string. "
                f"This `NodeBase` instance evaluates to a {type(self.format_str)} instead."
            )

    @property
    def format_str(self) -> str:
        fmt = self.kwargs["format"]

        if not isinstance(fmt, NodeBase):
            raise ValueError(
                "The format argument must be a NodeBase instance that evaluates to a string. "
                f"Got {type(fmt)} instead."
            )

        try:
            return pl.select(fmt.polars_expr).item()
        except Exception as e:
            raise ValueError(
                "The format argument must be a NodeBase instance that evaluates to a string. "
                "This `NodeBase` instance can't be evaluated to a string."
            ) from e

    @property
    def output_type(self) -> str:
        fmt = self.format_str
        has_date = any(f"%{part}" in fmt for part in self.DATE_PARTS)
        has_time = any(f"%{part}" in fmt for part in self.TIME_PARTS)
        has_datetime = any(f"%{part}" in fmt for part in self.DATETIME_PARTS)

        if has_datetime or (has_date and has_time):
            return "datetime"
        elif has_date:
            return "date"
        elif has_time:
            return "time"
        else:
            raise ValueError(
                "The format string must contain at least one date or time component. The format string "
                "should be in the syntax used by the `chrono` crate: "
                "https://docs.rs/chrono/latest/chrono/format/strftime/index.html"
            )

    @property
    def strict(self) -> bool:
        strict_node = self.kwargs.get("strict", None)
        if strict_node is None:
            return True  # default: strict=True for backwards compatibility
        if not isinstance(strict_node, NodeBase):
            raise ValueError(
                "The strict argument must be a NodeBase instance that evaluates to a boolean."
            )
        try:
            val = pl.select(strict_node.polars_expr).item()
        except Exception as e:
            raise ValueError("The strict argument must evaluate to a boolean.") from e
        if not isinstance(val, bool):
            raise ValueError(f"The strict argument must be a boolean, got {type(val)}")
        return val

    @property
    def polars_expr(self) -> pl.Expr:
        source_expr = self.kwargs["source"].polars_expr
        strict = self.strict

        return source_expr.str.strptime(
            dtype=DATE_TIME_TYPES[self.output_type],
            format=self.format_str,
            strict=strict,
        )

    @classmethod
    def from_lark(cls, items: list[Any]) -> dict[str, Any]:
        source, format = items

        return {cls.KEY: {"format": format, "source": source}}


class LenChars(ArgsOnlyFn):
    """This non-terminal node returns the character length of a string expression.

    The result is a ``UInt32`` count of Unicode characters (not bytes). Name matches Polars'
    ``pl.Expr.str.len_chars()``. This node is function-only (no operator form), so it subclasses
    :class:`ArgsOnlyFn` with a single-arg check rather than :class:`UnaryOp` (which requires
    a ``SYM`` for operator-form registration).

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(LenChars(Literal("hello")).polars_expr).item()
        5
        >>> pl.select(LenChars(Literal("")).polars_expr).item()
        0
        >>> pl.select(LenChars(Literal("café")).polars_expr).item()
        4

    It parses from string form via the function-call grammar:

        >>> from dftly import Parser
        >>> df = pl.DataFrame({"code": ["12345", "1"]})
        >>> df.select(Parser.expr_to_polars("len_chars($code)"))
        shape: (2, 1)
        ┌──────┐
        │ code │
        │ ---  │
        │ u32  │
        ╞══════╡
        │ 5    │
        │ 1    │
        └──────┘

    Parsing a function call yields a node whose short-form argument is a list containing the
    inner column node:

        >>> from dftly.str_form.parser import DftlyGrammar
        >>> DftlyGrammar.parse_str("len_chars($code)")
        {'len_chars': [{'column': 'code'}]}

    Only one argument is accepted:

        >>> LenChars(Literal("a"), Literal("b"))
        Traceback (most recent call last):
            ...
        ValueError: len_chars requires exactly one argument; got 2
    """

    KEY = "len_chars"

    def __post_init__(self):
        super().__post_init__()
        if len(self.args) != 1:
            raise ValueError(
                f"{self.KEY} requires exactly one argument; got {len(self.args)}"
            )

    @classmethod
    def from_lark(cls, items):
        if not isinstance(items, list):
            items = [items]
        return {cls.KEY: items}

    @property
    def polars_expr(self) -> pl.Expr:
        return self.args[0].polars_expr.str.len_chars()


class Substring(KwargsOnlyFn):
    """This non-terminal node extracts a substring from a string expression.

    Uses Python-style ``[start, stop)`` semantics: inclusive start, exclusive stop. An omitted
    ``stop`` means "to end of string". Negative indices are honored (they count from the end).

    Arguments:
        source: the string expression to slice.
        start: the index at which the substring begins (inclusive).
        stop: optional index at which the substring ends (exclusive). If omitted, slices to end.

    Example:
        >>> from dftly.nodes import Literal
        >>> substr = Substring(source=Literal("abcdef"), start=Literal(1), stop=Literal(4))
        >>> pl.select(substr.polars_expr).item()
        'bcd'
        >>> to_end = Substring(source=Literal("abcdef"), start=Literal(2))
        >>> pl.select(to_end.polars_expr).item()
        'cdef'
        >>> empty = Substring(source=Literal("abc"), start=Literal(0), stop=Literal(0))
        >>> pl.select(empty.polars_expr).item()
        ''

    Negative indices count from the end of the string, matching Python's slice
    semantics even for mixed-sign and out-of-range bounds:

        >>> tail = Substring(source=Literal("abcdef"), start=Literal(-2))
        >>> pl.select(tail.polars_expr).item()
        'ef'
        >>> middle = Substring(source=Literal("abcdef"), start=Literal(-4), stop=Literal(-1))
        >>> pl.select(middle.polars_expr).item()
        'cde'
        >>> mixed_neg_pos = Substring(source=Literal("abcdef"), start=Literal(-4), stop=Literal(2))
        >>> pl.select(mixed_neg_pos.polars_expr).item()
        ''
        >>> mixed_pos_neg = Substring(source=Literal("abcdef"), start=Literal(2), stop=Literal(-1))
        >>> pl.select(mixed_pos_neg.polars_expr).item()
        'cde'
        >>> out_of_range = Substring(source=Literal("abcdef"), start=Literal(-100), stop=Literal(200))
        >>> pl.select(out_of_range.polars_expr).item()
        'abcdef'
        >>> backward = Substring(source=Literal("abcdef"), start=Literal(5), stop=Literal(2))
        >>> pl.select(backward.polars_expr).item()
        ''

    It parses from string form via the function-call grammar, with 2 or 3 positional args:

        >>> from dftly.str_form.parser import DftlyGrammar
        >>> DftlyGrammar.parse_str("substring($code, 0, 3)")
        {'substring': {'source': {'column': 'code'},
                       'start': {'literal': 0},
                       'stop': {'literal': 3}}}
        >>> DftlyGrammar.parse_str("substring($code, 3)")
        {'substring': {'source': {'column': 'code'}, 'start': {'literal': 3}}}

    Python-style ``[start:stop]`` postfix shorthand produces the same AST as the function
    form. All four Python slice shapes are supported; omitted endpoints default to 0 for
    ``start`` and "to end of string" for ``stop``:

        >>> DftlyGrammar.parse_str("$code[0:3]")
        {'substring': {'source': {'column': 'code'},
                       'start': {'literal': 0},
                       'stop': {'literal': 3}}}
        >>> DftlyGrammar.parse_str("$code[3:]")
        {'substring': {'source': {'column': 'code'}, 'start': {'literal': 3}}}
        >>> DftlyGrammar.parse_str("$code[:3]")
        {'substring': {'source': {'column': 'code'},
                       'start': {'literal': 0},
                       'stop': {'literal': 3}}}
        >>> DftlyGrammar.parse_str("$code[:]")
        {'substring': {'source': {'column': 'code'}, 'start': {'literal': 0}}}

    Negative indices and expression-valued bounds work identically to the functional form:

        >>> DftlyGrammar.parse_str("$code[-3:-1]")
        {'substring': {'source': {'column': 'code'},
                       'start': {'negate': [{'literal': 3}]},
                       'stop': {'negate': [{'literal': 1}]}}}

    The shorthand binds tighter than unary, so ``-$col[0:3]`` is ``-($col[0:3])`` (matching
    Python). Chained subscripts apply left-to-right: ``$col[0:5][1:3]`` substrings the
    substring.

        >>> DftlyGrammar.parse_str("$code[0:5][1:3]")
        {'substring': {'source': {'substring': {'source': {'column': 'code'},
                                                'start': {'literal': 0},
                                                'stop': {'literal': 5}}},
                       'start': {'literal': 1},
                       'stop': {'literal': 3}}}

    The shorthand also applies to arbitrary parenthesized expressions, not just columns:

        >>> DftlyGrammar.parse_str("($a + $b)[0:3]")
        {'substring': {'source': {'add': [{'column': 'a'}, {'column': 'b'}]},
                       'start': {'literal': 0},
                       'stop': {'literal': 3}}}

    Bounds that form a ``HH:MM`` pattern (e.g. ``[10:30]``) would otherwise be lexed as
    a TIME literal by Lark's longest-match lexer; they're decomposed back into integer
    bounds so the intuitive meaning holds:

        >>> DftlyGrammar.parse_str("$code[10:30]")
        {'substring': {'source': {'column': 'code'},
                       'start': {'literal': 10},
                       'stop': {'literal': 30}}}

    Slice step is not supported (Polars' ``str.slice`` has no step); ``HH:MM:SS``-shaped
    bounds with non-zero seconds raise a clear error pointing at the functional form:

        >>> DftlyGrammar.parse_str("$code[10:30:45]")
        Traceback (most recent call last):
            ...
        lark.exceptions.VisitError: ... Slice shorthand does not support step ...

    End-to-end: the MIMIC ICD dot-insertion pattern (``add_dot($code, 3)``) combines
    :class:`LenChars` and :class:`Substring` to produce a declarative equivalent of the
    Python guard-and-splice idiom. Both the function and shorthand forms produce the same
    result:

        >>> from dftly import Parser
        >>> df = pl.DataFrame({"code": ["12345", "1", "A420"]})
        >>> func_expr = Parser.expr_to_polars(
        ...     'f"{substring($code, 0, 3)}.{substring($code, 3)}" '
        ...     'if len_chars($code) > 3 else $code'
        ... )
        >>> df.select(func_expr).to_series().to_list()
        ['123.45', '1', 'A42.0']
        >>> short_expr = Parser.expr_to_polars(
        ...     'f"{$code[0:3]}.{$code[3:]}" if len_chars($code) > 3 else $code'
        ... )
        >>> df.select(short_expr).to_series().to_list()
        ['123.45', '1', 'A42.0']

    Missing required kwargs raise an error:

        >>> Substring(source=Literal("abc"))
        Traceback (most recent call last):
            ...
        ValueError: Missing required keys for substring: {'start'}

    Extra kwargs raise an error:

        >>> Substring(source=Literal("abc"), start=Literal(0), step=Literal(2))
        Traceback (most recent call last):
            ...
        ValueError: Extra unallowed keys for substring: {'step'}
    """

    KEY = "substring"
    REQUIRED_KWARGS = {"source", "start"}
    OPTIONAL_KWARGS = {"stop"}

    @property
    def polars_expr(self) -> pl.Expr:
        source_expr = self.kwargs["source"].polars_expr
        start_expr = self.kwargs["start"].polars_expr
        if "stop" not in self.kwargs:
            # Open stop: polars' ``.str.slice(offset)`` matches Python's ``a[i:]``
            # for both positive and negative offsets with no normalization needed.
            return source_expr.str.slice(start_expr)
        stop_expr = self.kwargs["stop"].polars_expr
        # Python slice semantics: normalize negative bounds against ``len``, clip
        # both to ``[0, len]``, then take ``length = stop - start``. Polars'
        # ``.str.slice(offset, length)`` takes a signed offset (negative counts
        # from end) but a non-negative length starting at that offset, so a naive
        # ``stop - start`` is wrong for mixed-sign or out-of-range bounds — e.g.
        # ``"abcdef"[-4:2]`` is ``""`` in Python but would ask polars for offset
        # ``-4``, length ``6``, returning ``"cdef"``. We normalize first.
        str_len = source_expr.str.len_chars().cast(pl.Int64)
        norm_start = (
            pl.when(start_expr < 0).then(start_expr + str_len).otherwise(start_expr)
        ).clip(0, str_len)
        norm_stop = (
            pl.when(stop_expr < 0).then(stop_expr + str_len).otherwise(stop_expr)
        ).clip(0, str_len)
        length = (norm_stop - norm_start).clip(0)
        return source_expr.str.slice(norm_start, length)

    @classmethod
    def from_lark(cls, items: list[Any]) -> dict[str, Any]:
        if len(items) == 2:
            kwargs = {"source": items[0], "start": items[1]}
        elif len(items) == 3:
            kwargs = {
                "source": items[0],
                "start": items[1],
                "stop": items[2],
            }
        else:
            raise ValueError(
                f"substring expects 2 or 3 positional arguments; got {len(items)}"
            )
        return {cls.KEY: kwargs}
