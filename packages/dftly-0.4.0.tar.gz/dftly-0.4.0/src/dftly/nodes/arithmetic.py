"""This module defines arithmetic non-terminal nodes.

As non-terminals, all args and kwargs to these nodes must be other nodes.
"""

from .base import ArgsOnlyFn, BinaryOp, UnaryOp
import polars as pl


class Hash(ArgsOnlyFn):
    """This non-terminal node computes a hash of the input expression.

    The result is a UInt64 value (Polars' native hash type). For schemas requiring Int64 (e.g.
    MEDS ``subject_id``), use :class:`SignedHash` instead — a plain ``::int64`` cast silently
    nulls values above ``i64.max``.

    Example:
        >>> from dftly.nodes import Literal
        >>> result = pl.select(Hash(Literal("hello")).polars_expr).item()
        >>> isinstance(result, int) and result >= 0
        True
        >>> pl.select(Hash(Literal("hello")).polars_expr).dtypes
        [UInt64]
        >>> pl.select(Hash(Literal("hello")).polars_expr).item() == pl.select(Hash(Literal("hello")).polars_expr).item()
        True
        >>> pl.select(Hash(Literal("hello")).polars_expr).item() != pl.select(Hash(Literal("world")).polars_expr).item()
        True

    Only one argument is accepted:

        >>> Hash(Literal("a"), Literal("b"))
        Traceback (most recent call last):
            ...
        ValueError: hash requires exactly one argument; got 2
    """

    KEY = "hash"

    def __post_init__(self):
        super().__post_init__()
        if len(self.args) != 1:
            raise ValueError(
                f"{self.KEY} requires exactly one argument; got {len(self.args)}"
            )

    @classmethod
    def from_lark(cls, items):
        """Wrap single-argument lark results in a list for consistent handling.

        Examples:
            >>> Hash.from_lark([{"literal": 42}])
            {'hash': [{'literal': 42}]}
            >>> Hash.from_lark({"literal": 42})
            {'hash': [{'literal': 42}]}
        """
        if not isinstance(items, list):
            items = [items]
        return {cls.KEY: items}

    @property
    def polars_expr(self) -> pl.Expr:
        return self.args[0].polars_expr.hash()


class SignedHash(ArgsOnlyFn):
    """This non-terminal node computes a signed (Int64) hash of the input expression.

    The result is an Int64 value produced by reinterpreting Polars' native UInt64 hash as a
    two's-complement signed integer. This preserves the full bit pattern — unlike a
    ``::int64`` cast, which silently nulls values above ``i64.max`` — at the cost of changing
    the numeric value for roughly half of inputs. Downstream consumers that compute hashes
    outside dftly will only get bit-compatible values if they also reinterpret.

    Use this when landing into an Int64-typed column (e.g. MEDS ``subject_id``).

    This node is a sibling of :class:`Hash` rather than a subclass: subclassing would cause
    a class-form ``SignedHash(...)`` instance to match ``Hash`` as well (via
    ``isinstance``-based form detection) and raise a multiple-matches error in the parser.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(SignedHash(Literal("hello")).polars_expr).dtypes
        [Int64]
        >>> unsigned = pl.select(Hash(Literal("hello")).polars_expr).item()
        >>> signed = pl.select(SignedHash(Literal("hello")).polars_expr).item()
        >>> signed == (unsigned - (1 << 64) if unsigned >= (1 << 63) else unsigned)
        True

    It parses from string form via the function-call grammar:

        >>> from dftly import Parser
        >>> df = pl.DataFrame({"mrn": ["abc", "def"]})
        >>> df.select(**Parser.to_polars({"subject_id": "signed_hash($mrn)"})).dtypes
        [Int64]

    Class-form inputs (including prebuilt and nested instances) round-trip unambiguously
    — a ``SignedHash`` is not mistaken for a ``Hash``:

        >>> Parser()(SignedHash(Literal("hello")))
        SignedHash(Literal('hello'))
        >>> Parser()({"add": [Literal(1), SignedHash(Literal("hello"))]})
        Add(Literal(1), SignedHash(Literal('hello')))

    Only one argument is accepted:

        >>> SignedHash(Literal("a"), Literal("b"))
        Traceback (most recent call last):
            ...
        ValueError: signed_hash requires exactly one argument; got 2
    """

    KEY = "signed_hash"

    def __post_init__(self):
        super().__post_init__()
        if len(self.args) != 1:
            raise ValueError(
                f"{self.KEY} requires exactly one argument; got {len(self.args)}"
            )

    @classmethod
    def from_lark(cls, items):
        """Wrap single-argument lark results in a list for consistent handling.

        Examples:
            >>> SignedHash.from_lark([{"literal": 42}])
            {'signed_hash': [{'literal': 42}]}
            >>> SignedHash.from_lark({"literal": 42})
            {'signed_hash': [{'literal': 42}]}
        """
        if not isinstance(items, list):
            items = [items]
        return {cls.KEY: items}

    @property
    def polars_expr(self) -> pl.Expr:
        return self.args[0].polars_expr.hash().reinterpret(signed=True)


class Not(UnaryOp):
    """This non-terminal node represents the logical NOT of an expression.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Not(Literal(True)).polars_expr).item()
        False
        >>> pl.select(Not(Literal(False)).polars_expr).item()
        True
    """

    KEY = "not"
    SYM = ("!", "not")
    pl_fn = pl.Expr.not_


class Negate(UnaryOp):
    """This non-terminal node represents the negation of an expression.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Negate(Literal(5)).polars_expr).item()
        -5
        >>> pl.select(Negate(Literal(-3)).polars_expr).item()
        3
    """

    KEY = "negate"
    SYM = "-"

    @classmethod
    def pl_fn(cls, arg: pl.Expr) -> pl.Expr:
        return -arg


class And(ArgsOnlyFn):
    """This non-terminal node represents the logical AND of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(And(Literal(True), Literal(False), Literal(True)).polars_expr).item()
        False
    """

    KEY = "and"
    SYM = ("&&", "and")
    pl_fn = pl.all_horizontal


class Or(ArgsOnlyFn):
    """This non-terminal node represents the logical OR of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Or(Literal(True), Literal(False), Literal(True)).polars_expr).item()
        True
    """

    KEY = "or"
    SYM = ("||", "or")
    pl_fn = pl.any_horizontal


class Add(ArgsOnlyFn):
    """This non-terminal node represents the addition of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Add(Literal(1), Literal(2), Literal(3)).polars_expr).item()
        6
        >>> pl.select(Add(Literal("hello "), Literal("world")).polars_expr).item()
        'hello world'
    """

    KEY = "add"
    SYM = "+"
    pl_fn = pl.sum_horizontal


class Subtract(BinaryOp):
    """This non-terminal node represents the difference between the two inputs x, y -> x - y.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Subtract(Literal(5), Literal(3)).polars_expr).item()
        2
    """

    KEY = "subtract"
    SYM = "-"
    pl_fn = pl.Expr.sub


class Multiply(ArgsOnlyFn):
    """This non-terminal node represents the multiplication of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Multiply(Literal(2), Literal(3), Literal(4)).polars_expr).item()
        24
    """

    KEY = "multiply"
    SYM = "*"

    @classmethod
    def pl_fn(cls, *args: pl.Expr) -> pl.Expr:
        result = args[0]
        for expr in args[1:]:
            result = result * expr
        return result


class Divide(BinaryOp):
    """This non-terminal node represents the division of two expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Divide(Literal(6), Literal(3)).polars_expr).item()
        2.0
    """

    KEY = "divide"
    SYM = "/"
    pl_fn = pl.Expr.truediv


class Power(BinaryOp):
    """This non-terminal node represents exponentiation: ``base ** exponent``.

    Compiles to ``base.polars_expr.pow(exponent.polars_expr)``. Accepts arbitrary expressions
    on either side — ``$x ** 2``, ``$x ** $y``, ``2 ** $n`` all work.

    In the string-form grammar, ``**`` binds tighter than ``*`` / ``/`` and is right-associative
    (``2 ** 3 ** 2`` parses as ``2 ** (3 ** 2) = 512``). Unary minus binds tighter on the left,
    so ``-2 ** 2`` parses as ``(-2) ** 2 = 4`` — this differs from Python (which gives ``-4``)
    but falls out of the existing grammar without restructuring cast/unary precedence. Use
    explicit parens (``-(x ** 2)``) if you want the Python interpretation.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Power(Literal(2), Literal(10)).polars_expr).item()
        1024
        >>> pl.select(Power(Literal(9), Literal(0.5)).polars_expr).item()
        3.0

    String form via the grammar:

        >>> from dftly import Parser
        >>> df = pl.DataFrame({"x": [2, 3, 4]})
        >>> df.select(squared=Parser.expr_to_polars("$x ** 2"))["squared"].to_list()
        [4, 9, 16]

    Precedence: ``**`` binds tighter than ``*`` and ``/``:

        >>> pl.select(Parser.expr_to_polars("2 * 3 ** 2")).item()
        18
        >>> pl.select(Parser.expr_to_polars("2 ** 3 * 2")).item()
        16

    Right-associative (``2 ** 3 ** 2 == 2 ** 9``, not ``8 ** 2``):

        >>> pl.select(Parser.expr_to_polars("2 ** 3 ** 2")).item()
        512

    Unary minus binds tighter than ``**``, attaching to the adjacent literal rather than
    the whole power. This applies wherever unary minus appears, including inside chained
    exponents:

        >>> pl.select(Parser.expr_to_polars("-2 ** 2")).item()
        4
        >>> pl.select(Parser.expr_to_polars("-(2 ** 2)")).item()
        -4
        >>> pl.select(Parser.expr_to_polars("2.0 ** -3 ** 2")).item()
        512.0
        >>> pl.select(Parser.expr_to_polars("2.0 ** -(3 ** 2)")).item()
        0.001953125

    Right-associativity of ``**`` itself is preserved — ``2 ** 3 ** 2`` is ``2 ** (3 ** 2)
    == 512``. In ``2 ** -3 ** 2``, ``-3`` is consumed by unary minus before ``**``
    associates, so it parses as ``2 ** ((-3) ** 2) == 2 ** 9 == 512``. Python's rule binds
    unary minus less tightly than ``**`` and would give ``2 ** -(3**2) == 1/512``; use
    explicit parens if you want that interpretation. The parse tree makes the precedence
    decision explicit:

        >>> from dftly.str_form.parser import DftlyGrammar
        >>> DftlyGrammar.parse_str("2 ** -3 ** 2")
        {'power': [{'literal': 2},
                   {'power': [{'negate': [{'literal': 3}]}, {'literal': 2}]}]}

    A variance/stddev formula — the motivating example from #63:

        >>> df = pl.DataFrame({"sum": [10.0, 20.0], "sum_sqd": [30.0, 110.0], "n": [4, 4]})
        >>> stddev = Parser.expr_to_polars(
        ...     "($sum_sqd / $n - ($sum / $n) ** 2) ** 0.5"
        ... )
        >>> df.select(stddev=stddev)["stddev"].to_list()
        [1.118033988749895, 1.5811388300841898]
    """

    KEY = "power"
    SYM = "**"
    pl_fn = pl.Expr.pow


class Mean(ArgsOnlyFn):
    """This non-terminal node represents the mean of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Mean(Literal(1), Literal(2), Literal(3)).polars_expr).item()
        2.0
    """

    KEY = "mean"
    pl_fn = pl.mean_horizontal


class Min(ArgsOnlyFn):
    """This non-terminal node represents the min of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Min(Literal(1), Literal(2), Literal(3)).polars_expr).item()
        1
    """

    KEY = "min"
    pl_fn = pl.min_horizontal


class Max(ArgsOnlyFn):
    """This non-terminal node represents the max of multiple expressions.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Max(Literal(1), Literal(2), Literal(3)).polars_expr).item()
        3
    """

    KEY = "max"
    pl_fn = pl.max_horizontal


class Coalesce(ArgsOnlyFn):
    """This non-terminal node returns the first non-null value among its arguments.

    Example:
        >>> from dftly.nodes import Literal
        >>> pl.select(Coalesce(Literal(None), Literal(1), Literal(2)).polars_expr).item()
        1
        >>> pl.select(Coalesce(Literal(3), Literal(None)).polars_expr).item()
        3
    """

    KEY = "coalesce"
    pl_fn = pl.coalesce
