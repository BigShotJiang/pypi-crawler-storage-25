"""
Lifecycle management for the tdfs4ds feature store.

Contains setup() and connect() — the two initialization functions that must
be called once at the start of every session.
"""

import tdfs4ds
import teradataml as tdml

from tdfs4ds.dataset.dataset_catalog import DatasetCatalog


def setup(database, if_exists='fail'):
    """
    Initialize the feature store environment by creating catalog tables and views.
    """

    from tdfs4ds.feature_store.feature_store_management import feature_store_catalog_creation
    from tdfs4ds.process_store.process_store_catalog_management import process_store_catalog_creation

    tdfs4ds.SCHEMA = database
    tdfs4ds.logger_safe("info", "Setting up feature store in database: %s", database)

    if if_exists == 'replace':
        tdfs4ds.logger_safe("info", "Replacing existing catalog tables if they exist.")
        for table in [tdfs4ds.FEATURE_CATALOG_NAME, tdfs4ds.PROCESS_CATALOG_NAME, tdfs4ds.DATA_DISTRIBUTION_NAME]:
            try:
                tdml.db_drop_table(table_name=table, schema_name=database)
                tdfs4ds.logger_safe("info", "Dropped table %s.%s", database, table)
            except Exception as e:
                tdfs4ds.logger_safe("warning", "Could not drop table %s.%s: %s", database, table, str(e).split('\n')[0])

        DatasetCatalog(schema_name=database, name=tdfs4ds.DATASET_CATALOG_NAME).drop_catalog()

    try:
        tdfs4ds.FEATURE_CATALOG_NAME = feature_store_catalog_creation()
        tdfs4ds.logger_safe("info", "Feature catalog table created: %s in database %s", tdfs4ds.FEATURE_CATALOG_NAME, database)
    except Exception as e:
        tdfs4ds.logger_safe("error", "Feature catalog creation failed: %s", str(e).split('\n')[0])

    try:
        (tdfs4ds.PROCESS_CATALOG_NAME,
         tdfs4ds.DATA_DISTRIBUTION_NAME,
         tdfs4ds.FILTER_MANAGER_NAME) = process_store_catalog_creation()

        tdfs4ds.logger_safe("info", "Process catalog table created: %s", tdfs4ds.PROCESS_CATALOG_NAME)
        tdfs4ds.logger_safe("info", "Data distribution table created: %s", tdfs4ds.DATA_DISTRIBUTION_NAME)
        tdfs4ds.logger_safe("info", "Filter manager table created: %s", tdfs4ds.FILTER_MANAGER_NAME)
    except Exception as e:
        tdfs4ds.logger_safe("error", "Process catalog creation failed: %s", str(e).split('\n')[0])

    try:
        tdfs4ds.process_store.process_followup.follow_up_table_creation()
        tdfs4ds.logger_safe("info", "Follow-up table created successfully.")
    except Exception as e:
        tdfs4ds.logger_safe("error", "Follow-up table creation failed: %s", str(e).split('\n')[0])

    tdfs4ds.feature_store.feature_store_management.feature_store_catalog_view_creation()
    tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_view_creation()

    dataset_catalog = DatasetCatalog(schema_name=database, name=tdfs4ds.DATASET_CATALOG_NAME)
    if not dataset_catalog._exists():
        dataset_catalog.create_catalog()
        tdfs4ds.logger_safe("info", "Dataset catalog created: %s", tdfs4ds.DATASET_CATALOG_NAME)

    tdfs4ds.logger_safe("info", "Setup complete.")
    try:
        tdfs4ds.genai.documentation_tables_creation()
        tdfs4ds.logger_safe("info", "Documentation tables created successfully.")
    except Exception as e:
        tdfs4ds.logger_safe("error", "Documentation tables creation failed: %s", str(e).split('\n')[0])
    return


def connect(
    database                  = None,
    feature_catalog_name      = None,
    process_catalog_name      = None,
    data_distribution_name    = None,
    filter_manager_name       = None,
    followup_name             = None,
    feature_catalog_name_view = None,
    process_catalog_name_view = None,
    dataset_catalog_name      = None,
    documentation_process_business_logic      = None,
    documentation_process_features            = None,
    documentation_process_explain             = None,
    documentation_business_dictionary_objects  = None,
    documentation_business_dictionary_columns  = None,
    documentation_business_dictionary_sections = None,
    create_if_missing         = False
):
    # Apply defaults from package globals
    if database is None:
        database = tdfs4ds.SCHEMA
    if feature_catalog_name is None:
        feature_catalog_name = tdfs4ds.FEATURE_CATALOG_NAME
    if process_catalog_name is None:
        process_catalog_name = tdfs4ds.PROCESS_CATALOG_NAME
    if data_distribution_name is None:
        data_distribution_name = tdfs4ds.DATA_DISTRIBUTION_NAME
    if filter_manager_name is None:
        filter_manager_name = tdfs4ds.FILTER_MANAGER_NAME
    if followup_name is None:
        followup_name = tdfs4ds.FOLLOW_UP_NAME
    if feature_catalog_name_view is None:
        feature_catalog_name_view = tdfs4ds.FEATURE_CATALOG_NAME_VIEW
    if process_catalog_name_view is None:
        process_catalog_name_view = tdfs4ds.PROCESS_CATALOG_NAME_VIEW
    if dataset_catalog_name is None:
        dataset_catalog_name = tdfs4ds.DATASET_CATALOG_NAME
    if documentation_process_business_logic is None:
        documentation_process_business_logic = tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC
    if documentation_process_features is None:
        documentation_process_features = tdfs4ds.DOCUMENTATION_PROCESS_FEATURES
    if documentation_process_explain is None:
        documentation_process_explain = tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN
    if documentation_business_dictionary_objects is None:
        documentation_business_dictionary_objects = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS
    if documentation_business_dictionary_columns is None:
        documentation_business_dictionary_columns = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS
    if documentation_business_dictionary_sections is None:
        documentation_business_dictionary_sections = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS

    if database is None:
        raise ValueError("database parameter is None.")
    tdfs4ds.SCHEMA = database
    tdfs4ds.logger_safe("info", "Connecting to feature store in database: %s", database)

    # Targeted DBC.TablesV query — only fetches the specific objects we need instead
    # of listing every object in the schema.  DatasetCatalog objects are included so
    # the constructor can reuse the result without a second round-trip.
    # Falls back to db_list_tables() when DBC access is restricted.
    _ds_objects = [
        f"FS_{dataset_catalog_name}_CATALOG",
        f"FS_{dataset_catalog_name}_ENTITY",
        f"FS_{dataset_catalog_name}_FEATURES",
        f"FS_V_{dataset_catalog_name}_CATALOG",
        f"FS_V_{dataset_catalog_name}_ENTITY",
        f"FS_V_{dataset_catalog_name}_FEATURES",
    ]
    _names_to_check = [
        feature_catalog_name, process_catalog_name, data_distribution_name,
        filter_manager_name, followup_name,
        documentation_process_business_logic, documentation_process_features,
        documentation_process_explain,
        documentation_business_dictionary_objects, documentation_business_dictionary_columns,
        documentation_business_dictionary_sections,
    ] + _ds_objects
    _names_csv = ', '.join(f"'{n.upper()}'" for n in _names_to_check)
    tdfs4ds.logger_safe("info", "connect [1/4] Checking table existence...")
    try:
        tables = set(
            tdml.DataFrame.from_query(
                f"SELECT LOWER(TableName) AS TableName FROM DBC.TablesV "
                f"WHERE DatabaseName = '{database}' "
                f"AND UPPER(TableName) IN ({_names_csv})"
            ).to_pandas()['TableName'].tolist()
        )
        tdfs4ds.logger_safe("info", "connect [1/4] Table existence check complete (%d objects found).", len(tables))
    except Exception:
        tdfs4ds.logger_safe(
            "warning",
            "DBC.TablesV query failed (restricted access?); falling back to db_list_tables()."
        )
        # Fetch both tables and views so DatasetCatalog views are also covered.
        tables = set(
            x.lower() for x in tdml.db_list_tables(schema_name=database).TableName.values
        )

    feature_exists = feature_catalog_name.lower() in tables
    process_exists = process_catalog_name.lower() in tables
    distrib_exists = data_distribution_name.lower() in tables
    filter_manager_exists = filter_manager_name.lower() in tables
    followup_name_exists = followup_name.lower() in tables
    documentation_process_business_logic_exist = documentation_process_business_logic.lower() in tables
    documentation_process_features_exist = documentation_process_features.lower() in tables
    documentation_process_explain_exist = documentation_process_explain.lower() in tables
    documentation_business_dictionary_objects_exist = documentation_business_dictionary_objects.lower() in tables
    documentation_business_dictionary_columns_exist = documentation_business_dictionary_columns.lower() in tables
    documentation_business_dictionary_sections_exist = documentation_business_dictionary_sections.lower() in tables


    if not (feature_exists and process_exists and distrib_exists and filter_manager_exists
            and documentation_process_business_logic_exist and documentation_process_features_exist
            and documentation_process_explain_exist
            and documentation_business_dictionary_objects_exist
            and documentation_business_dictionary_columns_exist
            and documentation_business_dictionary_sections_exist):
        if not create_if_missing:
            tdfs4ds.logger_safe("warning", "Feature store components missing and create_if_missing=False")
            return False
        tdfs4ds.logger_safe("info", "Missing components detected; creating missing parts...")
        if not feature_exists:
            tdfs4ds.logger_safe("info", "Creating feature catalog: %s", feature_catalog_name)
            tdfs4ds.feature_store.feature_store_management.feature_store_catalog_creation()
        if not process_exists:
            tdfs4ds.logger_safe("info", "Creating process catalog: %s", process_catalog_name)
            tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_creation()
        if not distrib_exists:
            tdfs4ds.logger_safe("info", "Creating data distribution table: %s", data_distribution_name)
            tdfs4ds.data_distribution.data_distribution_catalog_creation()
        if not filter_manager_exists:
            tdfs4ds.logger_safe("info", "Creating filter manager table: %s", filter_manager_name)
            tdfs4ds.filter_manager.filter_manager_catalog_creation()
        if not (documentation_process_business_logic_exist and documentation_process_features_exist
                and documentation_process_explain_exist
                and documentation_business_dictionary_objects_exist
                and documentation_business_dictionary_columns_exist
                and documentation_business_dictionary_sections_exist):
            tdfs4ds.logger_safe("info", "Creating documentation tables.")
            tdfs4ds.genai.documentation_tables_creation()

    if not followup_name_exists:
        tdfs4ds.logger_safe("info", "Creating follow-up table: %s", followup_name)
        tdfs4ds.process_store.process_followup.follow_up_table_creation()
    tdfs4ds.FOLLOW_UP_NAME = followup_name

    # Schema migration (USER_SCORE, N_STEPS, N_SPOOL_OBJECTS columns) is applied inside
    # documentation_tables_creation() when the explain table is first created or upgraded.
    # No additional migration is needed here.

    # Set catalog names
    tdfs4ds.FEATURE_CATALOG_NAME = feature_catalog_name
    tdfs4ds.PROCESS_CATALOG_NAME = process_catalog_name
    tdfs4ds.DATA_DISTRIBUTION_NAME = data_distribution_name
    tdfs4ds.FILTER_MANAGER_NAME = filter_manager_name
    tdfs4ds.PROCESS_CATALOG_NAME_VIEW = process_catalog_name_view
    tdfs4ds.FEATURE_CATALOG_NAME_VIEW = feature_catalog_name_view
    tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC = documentation_process_business_logic
    tdfs4ds.DOCUMENTATION_PROCESS_FEATURES = documentation_process_features
    tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN = documentation_process_explain
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS = documentation_business_dictionary_objects
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS = documentation_business_dictionary_columns
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS = documentation_business_dictionary_sections

    # Combined DBC.ColumnsV query replacing two separate round-trips:
    #   - DataFrame(in_schema(...)).columns  → check ENTITY_NULL_SUBSTITUTE exists
    #   - get_ddl() / SHOW TABLE            → detect PERIOD column for temporal flag
    # Falls back to the original approaches when DBC access is restricted.
    try:
        _col_rows = tdml.DataFrame.from_query(
            f"SELECT UPPER(TableName) AS TN, UPPER(ColumnName) AS CN, ColumnType "
            f"FROM DBC.ColumnsV "
            f"WHERE DatabaseName = '{database}' "
            f"AND ((UPPER(TableName) = '{process_catalog_name.upper()}' "
            f"      AND UPPER(ColumnName) = 'ENTITY_NULL_SUBSTITUTE') "
            f"  OR  (UPPER(TableName) = '{data_distribution_name.upper()}' "
            f"      AND ColumnType LIKE 'P%'))"
        ).to_pandas()
        _has_entity_null_sub = (
            (_col_rows['TN'] == process_catalog_name.upper()) &
            (_col_rows['CN'] == 'ENTITY_NULL_SUBSTITUTE')
        ).any()
        tdfs4ds.DATA_DISTRIBUTION_TEMPORAL = bool(
            ((_col_rows['TN'] == data_distribution_name.upper()) &
             _col_rows['ColumnType'].str.startswith('P')).any()
        )
        tdfs4ds.logger_safe("debug", "Column metadata checked via DBC.ColumnsV.")
    except Exception:
        tdfs4ds.logger_safe(
            "warning",
            "DBC.ColumnsV query failed (restricted access?); falling back to schema introspection."
        )
        _process_df = tdml.DataFrame(tdml.in_schema(database, process_catalog_name))
        _has_entity_null_sub = 'ENTITY_NULL_SUBSTITUTE' in _process_df.columns
        tdfs4ds.DATA_DISTRIBUTION_TEMPORAL = 'PERIOD' in tdfs4ds.utils.lineage.get_ddl(
            view_name=tdfs4ds.DATA_DISTRIBUTION_NAME,
            schema_name=tdfs4ds.SCHEMA,
            object_type='table'
        )

    if process_exists and not _has_entity_null_sub:
        tdfs4ds.logger_safe("warning", "ENTITY_NULL_SUBSTITUTE column missing. Upgrading catalog.")
        tdfs4ds.process_store.process_store_catalog_management.upgrade_process_catalog()

    tdfs4ds.logger_safe("info", "connect [2/4] Refreshing catalog views...")
    tdfs4ds.feature_store.feature_store_management.feature_store_catalog_view_creation()
    tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_view_creation()
    tdfs4ds.logger_safe("info", "connect [2/4] Catalog views refreshed.")

    # Dataset Catalog — pass precomputed table set so DatasetCatalog.__init__ skips
    # its own db_list_tables() call.  The explicit _exists() check here is also
    # removed because DatasetCatalog.__init__ already handles creation internally.
    tdfs4ds.logger_safe("info", "connect [3/4] Initializing dataset catalog...")
    tdfs4ds.DATASET_CATALOG_NAME = dataset_catalog_name
    dataset_catalog = DatasetCatalog(schema_name=database, name=dataset_catalog_name,
                                     existing_objects=tables)
    tdfs4ds.logger_safe("info", "connect [3/4] Dataset catalog ready.")

    tdfs4ds.logger_safe("info", "connect [4/4] Querying data domains...")
    query_data_domain = f"""
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW}
    UNION
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME_VIEW}
    """
    data_domains = tdml.DataFrame.from_query(query_data_domain).to_pandas()['DATA_DOMAIN'].tolist()
    tdfs4ds.logger_safe("info", "connect [4/4] %d data domain(s) found.", len(data_domains))
    tdfs4ds.logger_safe("debug", "Data domains: %s", data_domains)

    tdfs4ds.logger_safe("info", "Connected to feature store successfully.")
    return True
