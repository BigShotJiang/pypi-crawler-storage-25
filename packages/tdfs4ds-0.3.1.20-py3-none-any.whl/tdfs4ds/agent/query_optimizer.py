"""
Query Optimizer Agent — structured multi-step pipeline built around a self-contained skill.

Architecture
------------
The optimization logic lives entirely in ``skill_optimize_query``, a synchronous function
following the same pattern as the consumer agent skills (``skill_search``, ``skill_definition``
etc.).  The LangGraph StateGraph is a thin multi-turn wrapper that calls the skill and
persists conversation state across turns sharing the same ``thread_id``.

Process-aware entry point
~~~~~~~~~~~~~~~~~~~~~~~~~
When a ``process_id`` is supplied, the skill calls
``tdfs4ds.process_store.process_store_catalog_management.get_process_info`` to retrieve:
  - The registered SQL view (``PROCESS_SQL``)
  - Pre-existing EXPLAIN documentation (``EXPLAIN_ANALYSIS``, ``USER_SCORE``,
    ``OPTIMIZATION_SCORE``, ``EXPLAIN_WARNINGS``, ``EXPLAIN_RECOMMENDATIONS``)
  - Entity and feature column metadata

This avoids re-running the EXPLAIN LLM chain when an up-to-date analysis is already stored.

EXPLAIN analysis responsibility split
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``tdfs4ds.genai.documentation.document_sql_query_explain`` returns a structured dict:
  - ``explanation``   — plain-language plan description
  - ``user_score``    — 1–5, quality of *what the SQL author controls*
  - ``global_score``  — 1–5, overall execution quality including infrastructure
  - ``warnings``      — prefixed ``[You]`` or ``[Data Engineer / DBA]``
  - ``recommendations``— same prefixes

Only the ``[You]``-prefixed items are actionable by the SQL author.  The optimizer
uses this split to focus candidate rewrites on author-controllable improvements.

Native Teradata tools (no MCP required)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Seven read-only metadata functions replicate the tools exposed by the
``teradata-mcp-minimal`` server as direct Python calls over the active teradataml
connection.  No subprocess, no extra dependencies beyond teradataml.

Pipeline (strategy-based, executed inside ``skill_optimize_query``)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  1. Gather process context          (get_process_info — skipped if no process_id)
  2. Analyze original EXPLAIN        (document_sql_query_explain — or reuse stored)
  3. Build lineage graph             (tdfs4ds.build_teradata_dependency_graph)
     → Primary Index + partition columns per underlying object
  4. Fetch DDL for referenced objects (_td_get_table_ddl / _td_get_view_ddl)
  5. **Plan strategies** — combinatorial with technique variants (no LLM call):
     For each [You] item, extracts technique hints from the recommendation text
     (e.g. "CTE", "scalar subquery" → precompute category → CTE, CROSS JOIN,
     and scalar variants).  Then adds pairwise/group combinations.
     Capped at ``QUERY_OPTIMIZER_MAX_CANDIDATES`` (default 10).
  6. **Execute each strategy** — For each strategy sequentially:
     a. Generate 1 candidate implementing the strategy (``_generate_for_strategy_sync``)
     b. Analyze EXPLAIN → extract remaining ``[You]`` items
     c. Refinement loop (up to ``QUERY_OPTIMIZER_MAX_REFINE_ROUNDS``, default 3):
        each round asks the LLM to fix the remaining ``[You]`` items from the
        previous round (``_refine_candidate_sync``)
     d. **Early stop** the entire pipeline when no ``[You]`` items remain (5/5 score)
     e. **Compaction pass** (on 5/5): asks the LLM to flatten unnecessary nesting
        and simplify the SQL structure; accepts only if the score holds.
  7. LLM selects best plan           (structured output: PlanComparison)
  8. FilterManager check             (pure Python, tdfs4ds.FilterManager)

Quick start::

    import tdfs4ds
    tdfs4ds.INSTRUCT_MODEL_PROVIDER = "vllm"
    tdfs4ds.INSTRUCT_MODEL_MODEL    = "..."

    # requires an active tdml.create_context() connection
    result = tdfs4ds.query_optimizer(
        "SELECT * FROM dw.orders o JOIN dw.customers c ON o.cust_id = c.id",
        thread_id="session-01",
    )
    print(result["answer"])
    print("Best SQL:", result["best_sql"])

    # Process-aware: pull SQL + stored analysis from the process catalog
    result = tdfs4ds.query_optimizer(
        process_id="550e8400-...",
        thread_id="session-02",
    )
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import re
from typing import Annotated, Any, Optional

from langchain_core.messages import AIMessage, HumanMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from pydantic import BaseModel, Field
from typing_extensions import TypedDict

import tdfs4ds
from tdfs4ds.cli import skill_prompt

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# Pydantic models for structured LLM outputs
# ═══════════════════════════════════════════════════════════════════════════════

class CandidateRewrite(BaseModel):
    sql: str = Field(..., description="Full rewritten SQL, semantically equivalent to the original")
    strategy: str = Field(
        ...,
        description=(
            "Short label for the strategy applied, e.g. 'partition_pruning', "
            "'join_reorder', 'pi_equality_filter', 'cast_removal', 'cte_pre_filter'"
        ),
    )
    rationale: str = Field(..., description="Why this rewrite should reduce execution cost")
    business_assumptions: str = Field(
        default="",
        description=(
            "Describe any domain assumption your rewrite makes about the data or business rules "
            "(e.g. 'Assumes transactions older than 2 years are not relevant to current analysis', "
            "'Assumes the ACTIVE_FLAG column reliably filters inactive records'). "
            "Leave EMPTY for purely structural rewrites that make no assumption about data scope or "
            "business meaning."
        ),
    )


class CandidatesOutput(BaseModel):
    candidates: list[CandidateRewrite] = Field(
        default_factory=list,
        description=(
            "Candidate rewrites ordered from most to least promising. "
            "Return an empty list if the original query is already optimal."
        ),
    )


class PlanComparison(BaseModel):
    best_index: int = Field(
        ...,
        description=(
            "0-based LIST position of the best candidate as shown in the prompt "
            "(0 = first candidate listed, 1 = second, …). "
            "Set to -1 if the original query has the best plan."
        ),
    )
    reasoning: str = Field(..., description="Which plan indicators led to this choice")
    business_logic_preserved: bool = Field(
        ..., description="True only if the selected SQL produces the same result set as the original"
    )
    business_logic_notes: str = Field(..., description="Brief semantic-equivalence notes")


class StrategySpec(BaseModel):
    name: str = Field(..., description="Short kebab-case label, e.g. 'single-pass-with-cte'")
    description: str = Field(..., description="What this strategy does and why it should help")
    targets: list[str] = Field(
        default_factory=list,
        description="[You] warning or recommendation items this strategy addresses (quoted verbatim from the EXPLAIN analysis)"
    )

class StrategiesOutput(BaseModel):
    strategies: list[StrategySpec] = Field(
        default_factory=list,
        description="Ordered list of distinct strategies, most to least promising. Empty if the query is already optimal."
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Token usage tracking
# ═══════════════════════════════════════════════════════════════════════════════

from langchain_core.callbacks import BaseCallbackHandler


class TokenUsageTracker(BaseCallbackHandler):
    """Accumulates token usage across LLM calls within a skill run."""

    def __init__(self):
        super().__init__()
        self.prompt_tokens: int = 0
        self.completion_tokens: int = 0
        self.total_tokens: int = 0
        self.llm_calls: int = 0

    def on_llm_end(self, response, **kwargs):
        self.llm_calls += 1
        llm_output = getattr(response, "llm_output", None) or {}
        usage = llm_output.get("token_usage", {})
        self.prompt_tokens += usage.get("prompt_tokens", 0)
        self.completion_tokens += usage.get("completion_tokens", 0)
        self.total_tokens += usage.get("total_tokens", 0)

    def snapshot(self) -> dict:
        return {
            "llm_calls": self.llm_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
        }


_token_tracker: Optional[TokenUsageTracker] = None


def _tracked_llm(max_tokens=None):
    """Wrapper around ``_get_llm`` that attaches the active token tracker."""
    from tdfs4ds.agent.consumer_agent import _get_llm
    cbs = [_token_tracker] if _token_tracker else None
    return _get_llm(max_tokens=max_tokens, callbacks=cbs)


# ═══════════════════════════════════════════════════════════════════════════════
# Module-level singletons
# ═══════════════════════════════════════════════════════════════════════════════

_checkpointer: Optional[MemorySaver] = None
_optimizer_graph: Optional[Any] = None


def _get_checkpointer() -> MemorySaver:
    global _checkpointer
    if _checkpointer is None:
        _checkpointer = MemorySaver()
    return _checkpointer


# ═══════════════════════════════════════════════════════════════════════════════
# LangGraph state
# ═══════════════════════════════════════════════════════════════════════════════

class OptimizerState(TypedDict):
    messages: Annotated[list, add_messages]
    answer: Optional[str]
    steps: Optional[list]
    best_sql: Optional[str]
    filtermanager_applicable: Optional[bool]
    process_id: Optional[str]
    original_analysis: Optional[dict]
    candidates: Optional[list]
    comparison: Optional[dict]
    process_info: Optional[dict]
    score_delta: Optional[dict]


# ═══════════════════════════════════════════════════════════════════════════════
# Native Teradata tools  (mirror of teradata-mcp-minimal, no MCP required)
# ═══════════════════════════════════════════════════════════════════════════════

def _q(ident: str) -> str:
    """Double-quote a Teradata identifier, escaping embedded quotes."""
    return '"' + ident.replace('"', '""') + '"'


def _td_run(sql: str) -> list:
    """Execute *sql* and return all rows as a list of tuples."""
    import teradataml as tdml
    return tdml.execute_sql(sql).fetchall()


def _td_list_databases() -> list[str]:
    """Return the names of all databases visible to the connected user."""
    try:
        rows = _td_run("SELECT DatabaseName FROM DBC.DatabasesV ORDER BY 1")
        return [r[0].strip() for r in rows if r[0]]
    except Exception as exc:
        logger.debug("list_databases failed: %s", exc)
        return []


def _td_list_tables(database: str) -> list[str]:
    """Return the table names in *database*."""
    try:
        rows = _td_run(
            f"SELECT TableName FROM DBC.TablesV "
            f"WHERE DatabaseName = {_q(database)} AND TableKind = 'T' "
            f"ORDER BY 1"
        )
        return [r[0].strip() for r in rows if r[0]]
    except Exception as exc:
        logger.debug("list_tables failed: %s", exc)
        return []


def _td_list_views(database: str) -> list[str]:
    """Return the view names in *database*."""
    try:
        rows = _td_run(
            f"SELECT TableName FROM DBC.TablesV "
            f"WHERE DatabaseName = {_q(database)} AND TableKind = 'V' "
            f"ORDER BY 1"
        )
        return [r[0].strip() for r in rows if r[0]]
    except Exception as exc:
        logger.debug("list_views failed: %s", exc)
        return []


def _td_get_object_type(database: str, object_name: str) -> str:
    """Return ``'TABLE'``, ``'VIEW'``, or ``'UNKNOWN'``."""
    try:
        rows = _td_run(
            f"SELECT TableKind FROM DBC.TablesV "
            f"WHERE DatabaseName = {_q(database)} AND TableName = {_q(object_name)}"
        )
        if not rows:
            return "UNKNOWN"
        kind = rows[0][0].strip().upper()
        return "TABLE" if kind == "T" else "VIEW" if kind == "V" else kind
    except Exception as exc:
        logger.debug("get_object_type failed: %s", exc)
        return "UNKNOWN"


def _td_get_table_ddl(database: str, table_name: str) -> str:
    """Return the ``CREATE TABLE`` DDL for *database*.*table_name*."""
    try:
        rows = _td_run(f"SHOW TABLE {_q(database)}.{_q(table_name)}")
        if not rows:
            return f"[No DDL returned for {database}.{table_name}]"
        return rows[0][0].replace("\r", "\n")
    except Exception as exc:
        return f"[get_table_ddl error for {database}.{table_name}: {exc}]"


def _td_get_view_ddl(database: str, view_name: str) -> str:
    """Return the ``CREATE VIEW`` DDL for *database*.*view_name*."""
    try:
        rows = _td_run(f"SHOW VIEW {_q(database)}.{_q(view_name)}")
        if not rows:
            return f"[No DDL returned for {database}.{view_name}]"
        return rows[0][0].replace("\r", "\n")
    except Exception as exc:
        return f"[get_view_ddl error for {database}.{view_name}: {exc}]"


def _td_get_query_explain(query: str) -> str:
    """Return the Teradata EXPLAIN plan for *query* as a single text block."""
    try:
        rows = _td_run(f"EXPLAIN {query}")
        return "\n".join(str(r[0]) for r in rows if r[0])
    except Exception as exc:
        return f"[EXPLAIN error: {exc}]"


# ═══════════════════════════════════════════════════════════════════════════════
# Teradata SQL compliance guide
# ═══════════════════════════════════════════════════════════════════════════════

def _teradata_sql_guide() -> str:
    """Return a compact Teradata SQL compliance guide for injection into LLM prompts.

    This is the single place to add new syntax rules when a recurring class of
    EXPLAIN error is observed.  Keep entries short — one ✓ / ✗ line per pattern.
    Group by topic so it stays scannable.
    """
    return (
        "TERADATA SQL — REQUIRED SYNTAX RULES:\n\n"

        "Date arithmetic:\n"
        "  ✓  CURRENT_DATE - 365              (integer subtraction, returns DATE)\n"
        "  ✓  DATE '2020-01-01'               (date literal)\n"
        "  ✓  CAST('2020-01-01' AS DATE FORMAT 'YYYY-MM-DD')\n"
        "  ✗  CURRENT_DATE - INTERVAL '365' DAY(4)  → Error 3706\n"
        "  ✗  CURRENT_DATE - INTERVAL '365 days'    → ANSI, not Teradata\n"
        "  ✗  DATEADD(DAY, n, date)   → Error 3706 — DAY is a reserved word; '(' then 'DAY' is always illegal\n"
        "  ✗  DATEDIFF(DAY, d1, d2)   → Error 3706 — same reason; use d1 - d2 instead\n"
        "  ✗  DATEADD() / DATEDIFF()  → SQL Server functions, do not exist in Teradata\n\n"

        "DATE minus DATE:\n"
        "  In Teradata, DATE - DATE already returns an INTEGER (number of days).\n"
        "  NEVER add a DAY qualifier or wrap in INTERVAL — it causes Error 3706.\n"
        "  ✓  date1 - date2                               → integer days, use as-is\n"
        "  ✓  CAST(date1 - date2 AS FLOAT)                → for ratio / division\n"
        "  ✗  (date1 - date2) DAY                         → Error 3706\n"
        "  ✗  INTERVAL (date1 - date2) DAY               → Error 3706\n"
        "  ✗  CAST(date1 - date2 AS INTERVAL DAY(4))      → Error 3706\n\n"

        "Percentile / ordered-set aggregates:\n"
        "  ✓  PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY col)  (correct Teradata form)\n"
        "  ✓  PERCENTILE_DISC(0.5)  WITHIN GROUP (ORDER BY col)\n"
        "  ✓  MEDIAN(col)                                         (alias for 0.5 percentile)\n"
        "  ✓  QUANTILE(25, col)                                   (Teradata extension)\n"
        "  ✗  PERCENTILE_CONT(0.25) OVER (...)  → Error 3707 — OVER not valid here\n"
        "  ✗  PERCENTILE_DISC(0.25) OVER (...)  → same Error 3707\n"
        "  NOTE: ordered-set aggregates cannot be combined with a GROUP BY directly;\n"
        "        wrap in a derived table or use a separate aggregation step.\n\n"

        "INTERVAL literals (only when the original SQL uses them — copy verbatim):\n"
        "  ✓  INTERVAL '1' DAY\n"
        "  ✓  INTERVAL '1:00' HOUR TO MINUTE\n"
        "  ✗  INTERVAL '1 day'  → ANSI form, causes syntax error in Teradata\n\n"

        "NULL / conditional:\n"
        "  ✓  COALESCE, NULLIF, ZEROIFNULL, NULLIFZERO\n"
        "  ✗  ISNULL()  → SQL Server, not Teradata\n\n"

        "String / numeric:\n"
        "  ✓  TRIM, CHARACTERS, SUBSTR, INDEX\n"
        "  ✗  LEN(), CHARINDEX()  → SQL Server, not Teradata\n\n"

        "Derived table / CTE column references:\n"
        "  ✓  CASE WHEN t.col > avg_t.threshold_val THEN 1 ELSE 0 END\n"
        "       (reference derived-table or CTE column DIRECTLY by its alias)\n"
        "  ✗  CASE WHEN t.col > (SELECT threshold_val FROM avg_t) THEN 1 ELSE 0 END\n"
        "       → Error 3807: inside a scalar subquery, Teradata resolves 'avg_t' in the FROM\n"
        "         clause against the database catalog, NOT against outer FROM aliases.\n"
        "  RULE: never wrap a derived-table or CTE column in a scalar subquery (SELECT col FROM alias).\n"
        "        Always reference it directly in the expression: alias.column_name.\n\n"
        "  Example — correct CTE pattern for a precomputed threshold:\n"
        "       REPLACE VIEW v AS\n"
        "       WITH avg_t AS (SELECT AVG(col) * 2.0 AS threshold_val FROM src)\n"
        "       SELECT t.id,\n"
        "              SUM(CASE WHEN t.col > avg_t.threshold_val THEN 1 ELSE 0 END) AS cnt\n"
        "       FROM src t CROSS JOIN avg_t\n"
        "       GROUP BY t.id\n\n"

        "Common Error 3807 causes:\n"
        "  • A scalar subquery references a derived-table alias from an outer FROM clause\n"
        "    as if it were a real database table → fix: reference the column directly.\n\n"

        "Reserved words as column aliases:\n"
        "  Teradata reserves many English words as SQL keywords.  Using them as bare\n"
        "  column aliases causes Error 3706 ('expected something between … and the\n"
        "  '<WORD>' keyword').  ALWAYS suffix aliases with _val or _col.\n"
        "  ✗  AS threshold        → Error 3706 (THRESHOLD is reserved)\n"
        "  ✗  AS value            → Error 3706 (VALUE is reserved)\n"
        "  ✗  AS count            → Error 3706 (COUNT is reserved)\n"
        "  ✗  AS date             → Error 3706 (DATE is reserved)\n"
        "  ✗  AS position         → Error 3706 (POSITION is reserved)\n"
        "  ✓  AS threshold_val    → safe\n"
        "  ✓  AS total_count      → safe\n"
        "  ✓  AS event_date       → safe\n"
        "  RULE: never use a single English word as a column alias without a suffix.\n\n"

        "Common Error 3707 causes:\n"
        "  • 'expected EXCEPT/UNION/MINUS between a string literal and ;'\n"
        "    → a string literal appears where Teradata expects a set operator;\n"
        "      check for unclosed subqueries, misplaced closing parentheses,\n"
        "      or a stray string constant after the final SELECT.\n"
        "  • 'expected something between ) and OVER'\n"
        "    → PERCENTILE_CONT/PERCENTILE_DISC used with OVER — use WITHIN GROUP instead.\n\n"

        "Error 5480 — Ordered Analytical Functions cannot be nested:\n"
        "  Window functions (RANK, ROW_NUMBER, SUM OVER, etc.) cannot be nested inside\n"
        "  another window function in Teradata.  Compute the inner window in a derived\n"
        "  table first, then reference the result in the outer query.\n"
        "  ✗  RANK() OVER (ORDER BY SUM(col) OVER (...))     → Error 5480\n"
        "  ✓  SELECT ..., RANK() OVER (ORDER BY inner_sum)\n"
        "     FROM (SELECT ..., SUM(col) OVER (...) AS inner_sum FROM t) dt\n\n"

        "Error 3504 — Non-aggregate column not in GROUP BY:\n"
        "  Every column in a SELECT with GROUP BY must be either in the GROUP BY list\n"
        "  or wrapped in an aggregate function (SUM, COUNT, MAX, MIN, AVG, etc.).\n"
        "  Window functions (OVER (...)) are NOT aggregates — mixing them with GROUP BY\n"
        "  in the same SELECT level causes this error.  Use a derived table to separate\n"
        "  the aggregation pass from the window function pass.\n"
        "  ✗  SELECT id, SUM(x), ROW_NUMBER() OVER (...) FROM t GROUP BY id  → Error 3504\n"
        "  ✓  SELECT id, sum_x, ROW_NUMBER() OVER (ORDER BY sum_x)\n"
        "     FROM (SELECT id, SUM(x) AS sum_x FROM t GROUP BY id) dt\n"
    )




# ═══════════════════════════════════════════════════════════════════════════════
# Pipeline helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _get_lineage_info(sql_query: str) -> dict:
    """
    Build the dependency graph via ``tdfs4ds.build_teradata_dependency_graph`` and return
    a flat dict of per-object metadata keyed by canonical node name::

        {'"db"."tbl"': {
            "object_type": str,
            "primary_index_columns": list[str],
            "partition_columns": list[str],
            "database": str,
            "object": str,
        }}

    Requires the active teradataml connection. Returns ``{}`` on failure.
    """
    try:
        from tdfs4ds.lineage.network import build_teradata_dependency_graph

        graph = build_teradata_dependency_graph(
            sql_query=sql_query,
            default_database=getattr(tdfs4ds, "SCHEMA", "") or "",
            max_depth=5,
            store_ddl=False,
            stop_at_feature_store_datasets=False,
            expand_datasets_via_process_catalog=False,
        )
        info: dict = {}
        for name, node in graph.get("nodes", {}).items():
            ti = getattr(node, "table_info", None) or {}
            info[name] = {
                "object_type": getattr(node, "object_type", "unknown"),
                "primary_index_columns": ti.get("primary_index_columns", []),
                "partition_columns": ti.get("partition_columns", []),
                "database": getattr(node, "database", "") or "",
                "object": getattr(node, "object", "") or "",
            }
        return info
    except Exception as exc:
        logger.warning("Lineage build failed (non-fatal): %s", str(exc).splitlines()[0])
        return {}


def _extract_table_refs(sql: str) -> list[dict]:
    """Extract unique ``(database, name)`` pairs from FROM / JOIN clauses."""
    seen: set = set()
    refs: list = []
    for db, tbl in re.findall(
        r'(?:FROM|JOIN)\s+"?(\w+)"?\."?(\w+)"?', sql, re.IGNORECASE
    ):
        key = (db.upper(), tbl.upper())
        if key not in seen:
            seen.add(key)
            refs.append({"database": db, "name": tbl})
    return refs


def _fetch_ddl(database: str, name: str) -> str:
    """Try TABLE DDL first, fall back to VIEW DDL."""
    ddl = _td_get_table_ddl(database, name)
    if "error" in ddl.lower():
        ddl = _td_get_view_ddl(database, name)
    return ddl


def _check_filtermanager(sql_query: str, lineage_info: dict) -> dict:
    """
    Determine whether ``tdfs4ds.FilterManager`` would benefit this query.

    An object is flagged when it has ``partition_columns`` in the lineage graph but
    none of those columns appear (case-insensitively) in the query text.

    Returns::

        {
          "applicable": bool,
          "objects": {node_name: {"database", "object_name", "partition_columns"}},
          "suggestion": str  (Markdown, empty when not applicable),
        }
    """
    sql_upper = sql_query.upper()
    unfiltered: dict = {}

    for name, info in lineage_info.items():
        part_cols: list = info.get("partition_columns", [])
        if not part_cols:
            continue
        missing = [c for c in part_cols if c.upper() not in sql_upper]
        if missing:
            obj_short = (info.get("object") or name.split(".")[-1]).strip('"')
            unfiltered[name] = {
                "database": info.get("database", ""),
                "object_name": obj_short,
                "partition_columns": missing,
            }

    if not unfiltered:
        return {"applicable": False, "objects": {}, "suggestion": ""}

    lines: list[str] = [
        "### FilterManager Recommendation\n\n",
        "The following objects are **partitioned** but their partition columns are "
        "**not** used as filters — every run performs a full scan across all partitions:\n\n",
    ]
    for name, meta in unfiltered.items():
        cols_md = ", ".join(f"`{c}`" for c in meta["partition_columns"])
        lines.append(f"- **`{name}`** — partition columns: {cols_md}\n")

    lines += [
        "\n`tdfs4ds.FilterManager` lets you iterate over partitions one at a time, "
        "reducing per-iteration spool and enabling full partition elimination per run. "
        "It integrates with the feature-store process execution model so each iteration "
        "is tracked in the process follow-up catalog.\n\n",
        "**Compatible** when the computation can be applied independently per partition "
        "(e.g. per-date or per-region aggregations stored incrementally). "
        "**Not suitable** when aggregates must span all partitions simultaneously "
        "(e.g. a global `AVG` over all dates).\n",
    ]

    first = next(iter(unfiltered.values()))
    cols_repr = repr(first["partition_columns"])
    lines += [
        "\n```python\n",
        "import tdfs4ds\n\n",
        "fm = tdfs4ds.FilterManager(\n",
        f"    schema_name = tdfs4ds.SCHEMA,\n",
        f"    view_name   = '{first['object_name']}',\n",
        f"    col_names   = {cols_repr},\n",
        ")\n\n",
        "for filter_id in range(fm.nb_filters):\n",
        "    fm.update(filter_id)\n",
        "    current_partition = fm.display()   # active partition row\n",
        "    tdfs4ds.run(process_id)            # or: tdml.execute_sql(optimised_sql)\n",
        "```\n",
    ]

    return {"applicable": True, "objects": unfiltered, "suggestion": "".join(lines)}


def _format_history(messages: list) -> str:
    """Summarise the last 3 exchanges for LLM prompt context."""
    snippets: list[str] = []
    for msg in messages[-6:]:
        role = getattr(msg, "type", None) or getattr(msg, "role", "")
        content = str(getattr(msg, "content", ""))
        if role in ("human", "user"):
            snippets.append(f"User: {content[:400]}")
        elif role in ("ai", "assistant"):
            snippets.append(f"Assistant: {content[:600]}")
    return "\n".join(snippets) if snippets else "(no prior context)"


def _looks_like_sql(text: str) -> bool:
    return bool(re.match(
        r"^\s*(SELECT|WITH|INSERT|UPDATE|DELETE|MERGE|EXPLAIN)\b",
        text, re.IGNORECASE,
    ))


def _last_sql_from_history(messages: list) -> str:
    for msg in reversed(messages):
        if getattr(msg, "type", None) in ("human", "user"):
            content = str(getattr(msg, "content", ""))
            if _looks_like_sql(content):
                return content.strip()
    return ""


def _reindent_cte_blocks(formatted: str) -> str:
    """Re-indent CTE body blocks to use consistent 4-space indentation.

    Detects lines ending with ``AS`` (CTE header) followed by a ``(`` on the
    next line.  The body between ``(`` and the matching ``)`` is re-indented
    to 4 spaces while preserving relative indentation within the block
    (e.g. CASE/WHEN nesting).

    Non-CTE queries pass through unchanged.
    """
    import re
    lines = formatted.splitlines()
    result: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Detect CTE header: line ends with AS, next line starts with (
        is_cte_header = (
            re.search(r'\bAS\s*$', stripped, re.IGNORECASE)
            and i + 1 < len(lines)
            and lines[i + 1].lstrip().startswith('(')
        )

        if not is_cte_header:
            result.append(line)
            i += 1
            continue

        # Keep the header line as-is
        result.append(line)

        # Collect the CTE body (everything inside the outermost parens)
        j = i + 1
        depth = 0
        body_lines: list[str] = []
        while j < len(lines):
            for ch in lines[j]:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            body_lines.append(lines[j])
            if depth <= 0:
                break
            j += 1

        # Re-indent: shift to 4-space base while preserving relative indentation
        if body_lines:
            min_indent = min(
                (len(bl) - len(bl.lstrip()) for bl in body_lines if bl.strip()),
                default=0,
            )
            for bl in body_lines:
                if bl.strip():
                    relative = len(bl) - len(bl.lstrip()) - min_indent
                    result.append(' ' * (4 + max(0, relative)) + bl.strip())
                else:
                    result.append('')

        i = j + 1

    return '\n'.join(result)


def _format_sql(sql: str) -> str:
    """Pretty-print SQL using sqlparse with post-processing for CTE readability.

    ``sqlparse`` produces poor CTE formatting: deep alignment for continuation
    CTEs, ``REPLACE VIEW ... AS WITH`` on a single line.  Post-processing fixes:

    1. Newline after ``*/`` block comments.
    2. ``REPLACE VIEW ... AS WITH`` \u2192 ``... AS\\nWITH``.
    3. Deep CTE alignment (50+ spaces) collapsed to root level.
    4. CTE body blocks re-indented to consistent 4-space indent while
       preserving relative indentation within each block (e.g. CASE/WHEN).
    """
    try:
        import re
        import sqlparse
        formatted = sqlparse.format(sql.strip(), reindent=True, keyword_case="upper")
        # 1. Newline after closing block comments
        formatted = re.sub(r'\*/[ \t]*(?!\n)', '*/\n', formatted)
        # 2. AS WITH on separate lines
        formatted = re.sub(r'(?i)(AS)\s+(WITH)\b', r'\1\n\2', formatted)
        # 3. Fix deep CTE alignment
        formatted = re.sub(r',\n\s{5,}(\w+\s+AS)\b', r',\n\1', formatted)
        # 4. Re-indent CTE body blocks
        formatted = _reindent_cte_blocks(formatted)
        return formatted
    except Exception:
        return sql


def _fix_answer_fences(text: str) -> str:
    """Close any fenced code block the LLM forgot to close before a new section.

    Some LLMs write prose text (Key Changes, section headings) inside the
    opening ```sql ... ``` block instead of after it.  This function inserts
    a closing ``` whenever a Markdown section heading (``## `` / ``# ``) is
    encountered while a fence is still open, and appends a final closing
    fence if the text ends inside one.
    """
    lines = text.splitlines()
    in_fence = False
    fence_marker = "```"
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not in_fence:
            if stripped.startswith("```"):
                in_fence = True
                fence_marker = stripped[:3]
            out.append(line)
        else:
            if stripped.startswith(fence_marker) and stripped == stripped[:len(fence_marker)] * (len(stripped) // len(fence_marker)):
                # Closing fence
                in_fence = False
                out.append(line)
            elif stripped.startswith("## ") or stripped.startswith("# "):
                # Section heading inside a fence — close the fence first
                out.append(fence_marker)
                in_fence = False
                out.append(line)
            else:
                out.append(line)
    if in_fence:
        out.append(fence_marker)
    return "\n".join(out)


def _first_sentence(text: str, max_chars: int = 180) -> str:
    """Return the first sentence of *text*, capped at *max_chars*."""
    if not text:
        return ""
    for sep in (". ", ".\n", "! ", "? "):
        idx = text.find(sep)
        if 0 < idx < max_chars:
            return text[:idx + 1].strip()
    return text[:max_chars].rstrip() + ("…" if len(text) > max_chars else "")


def _fmt_score_display(v) -> str:
    """Format a score value for display, returning '—' for None."""
    return f"{v}/5" if v is not None else "—"


def _fmt_metric(v, label: str) -> str:
    """Format an integer metric for display, returning '—' for None."""
    return f"{label}: {v}" if v is not None else f"{label}: —"


def _format_analysis_for_prompt(analysis: dict) -> str:
    """Format a ``document_sql_query_explain`` result dict for use in LLM prompts."""
    you_warnings = [w for w in analysis.get("warnings", []) if w.startswith("[You]")]
    you_recs = [r for r in analysis.get("recommendations", []) if r.startswith("[You]")]
    u = analysis.get('user_score')
    g = analysis.get('global_score')
    n_st = analysis.get('n_steps')
    n_sp = analysis.get('n_spool_objects')
    lines = [
        f"Explanation: {analysis.get('explanation', '(unavailable)')}",
        f"User score (SQL quality): {u}/5" if u is not None else "User score (SQL quality): —",
        f"Global score (incl. infra): {g}/5" if g is not None else "Global score (incl. infra): —",
        _fmt_metric(n_st, "EXPLAIN steps"),
        _fmt_metric(n_sp, "Spool objects"),
    ]
    if you_warnings:
        lines.append("Author-actionable warnings:\n  " + "\n  ".join(you_warnings))
    if you_recs:
        lines.append("Author-actionable recommendations:\n  " + "\n  ".join(you_recs))
    return "\n".join(lines)


def _compute_score_delta(
    original_analysis: dict,
    candidate_analyses: list,
    comparison: "PlanComparison",
) -> dict:
    """Compute score improvement between the original query and the best rewrite.

    Returns a dict with score deltas for ``user_score``, ``global_score``,
    ``n_steps``, and ``n_spool_objects`` between original and best rewrite.
    """
    orig_user = original_analysis.get("user_score")
    orig_global = original_analysis.get("global_score")
    orig_steps = original_analysis.get("n_steps")
    orig_spools = original_analysis.get("n_spool_objects")

    best_analysis: Optional[dict] = None
    best_strategy = "original (no improvement found)"
    optimized = False

    if 0 <= comparison.best_index < len(candidate_analyses):
        best_ca = candidate_analyses[comparison.best_index]
        best_analysis = best_ca.get("analysis", {})
        best_strategy = best_ca.get("strategy", "")
        optimized = True

    best_user = best_analysis.get("user_score") if best_analysis else orig_user
    best_global = best_analysis.get("global_score") if best_analysis else orig_global
    best_steps = best_analysis.get("n_steps") if best_analysis else orig_steps
    best_spools = best_analysis.get("n_spool_objects") if best_analysis else orig_spools

    # Flag as optimized when the rewrite improves or equals the user score.
    # Equal scores are valid — the rewrite may be structurally better (fewer
    # steps, fewer spool objects, etc.) even when the EXPLAIN score is unchanged.
    if optimized and orig_user is not None and best_user is not None:
        optimized = best_user >= orig_user

    def _delta(before: Optional[float], after: Optional[float]) -> Optional[float]:
        if before is None or after is None:
            return None
        return round(float(after) - float(before), 2)

    return {
        "optimized":                optimized,
        "best_strategy":            best_strategy,
        "original_user_score":      orig_user,
        "original_global_score":    orig_global,
        "best_user_score":          best_user,
        "best_global_score":        best_global,
        "user_score_delta":         _delta(orig_user, best_user),
        "global_score_delta":       _delta(orig_global, best_global),
        "original_n_steps":         orig_steps,
        "best_n_steps":             best_steps,
        "steps_delta":              _delta(orig_steps, best_steps),
        "original_n_spools":        orig_spools,
        "best_n_spools":            best_spools,
        "spools_delta":             _delta(orig_spools, best_spools),
        "business_logic_preserved": comparison.business_logic_preserved,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Synchronous LLM helpers  (same pattern as consumer_agent skills)
# ═══════════════════════════════════════════════════════════════════════════════

def _analyze_explain(sql_query: str, classify: bool = False) -> dict:
    """
    Run ``document_sql_query_explain`` for structured EXPLAIN analysis.
    Falls back to raw EXPLAIN text on any error.

    ``classify=False`` by default: the optimizer uses raw [You] counts so
    that structural issues (redundant scans, nesting) drive simplification
    and candidate strategies.  The LLM classification runs only on the
    final public-facing score (via ``document_process_incremental``).
    """
    try:
        from tdfs4ds.genai.documentation import document_sql_query_explain
        return document_sql_query_explain(sql_query, classify=classify)
    except Exception as exc:
        logger.warning("document_sql_query_explain failed (non-fatal): %s", str(exc).splitlines()[0])
        raw = _td_get_query_explain(sql_query)
        return {
            "explanation": raw,
            "user_score": None,
            "global_score": None,
            "warnings": [],
            "recommendations": [],
            "n_steps": None,
            "n_spool_objects": None,
        }


def _generate_candidates_sync(
    sql_query: str,
    user_request: str,
    original_analysis: dict,
    ddls: dict[str, str],
    lineage_info: dict,
    history: list,
    extra_context: str = "",
    max_override: Optional[int] = None,
) -> CandidatesOutput:
    """Synchronous candidate generation via structured output.

    ``history`` is accepted for API compatibility but intentionally ignored here:
    candidate generation is a self-contained step and including prior conversation
    messages (which may contain full SQL rewrites) only bloats the prompt.
    """
    from langchain_core.messages import SystemMessage

    import tdfs4ds as _tds
    max_candidates = max_override if max_override is not None else getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATES", 5)

    ddl_block = (
        "\n\n".join(f"-- {k}\n{v}" for k, v in ddls.items())
        or "(DDL unavailable)"
    )
    lineage_block = (
        "\n".join(
            "  {}: PI=[{}]  PARTITION=[{}]".format(
                name,
                ", ".join(info.get("primary_index_columns", [])) or "unknown",
                ", ".join(info.get("partition_columns", [])) or "none",
            )
            for name, info in lineage_info.items()
        )
        or "  (lineage unavailable)"
    )
    explain_block = _format_analysis_for_prompt(original_analysis)

    system = skill_prompt("qo-candidates").format(
        max_candidates=max_candidates,
        teradata_sql_guide=_teradata_sql_guide(),
    )

    user_content = (
        f"User request: {user_request}\n\n"
        f"Original SQL:\n```sql\n{sql_query}\n```\n\n"
        f"EXPLAIN analysis:\n{explain_block}\n\n"
        f"DDL (PI + partitioning):\n{ddl_block}\n\n"
        f"Lineage metadata:\n{lineage_block}"
    )
    if extra_context:
        user_content += f"\n\n{extra_context}"

    max_tokens = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
    llm = _tracked_llm(max_tokens=max_tokens).with_structured_output(CandidatesOutput)
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])


def _compare_plans_sync(
    original_analysis: dict,
    candidate_analyses: list[dict],
) -> PlanComparison:
    """Synchronous plan comparison via structured output."""
    from langchain_core.messages import SystemMessage

    original_block = f"ORIGINAL:\n{_format_analysis_for_prompt(original_analysis)}\n\n"
    candidates_block = ""
    for list_pos, ca in enumerate(candidate_analyses):
        analysis = ca.get("analysis", {})
        candidates_block += (
            f"CANDIDATE {list_pos} — {ca['strategy']}\n"
            f"Rationale: {ca.get('rationale', '')}\n"
            f"{_format_analysis_for_prompt(analysis)}\n\n"
        )

    system = skill_prompt("qo-compare")

    llm = _tracked_llm().with_structured_output(PlanComparison)
    return llm.invoke([
        SystemMessage(content=system),
        HumanMessage(content=original_block + candidates_block),
    ])


def _generate_summary_sync(
    user_request: str,
    original_analysis: dict,
    comparison: "PlanComparison",
    score_delta: Optional[dict],
    candidate_count: int,
) -> str:
    """Generate a 2-4 sentence executive summary via a short LLM call."""
    from langchain_core.messages import SystemMessage

    has_improvement = bool(score_delta and score_delta.get("optimized", False))

    system = skill_prompt("qo-summary")
    user_content = (
        f"Request: {user_request}\n"
        f"Candidates generated: {candidate_count}\n"
        f"Optimized: {has_improvement}\n"
    )
    if score_delta:
        user_content += (
            f"User score: {score_delta.get('original_user_score')}/5 → "
            f"{score_delta.get('best_user_score')}/5\n"
            f"Steps: {score_delta.get('original_n_steps', 'N/A')} → "
            f"{score_delta.get('best_n_steps', 'N/A')}\n"
            f"Spool objects: {score_delta.get('original_n_spools', 'N/A')} → "
            f"{score_delta.get('best_n_spools', 'N/A')}\n"
            f"Strategy: {score_delta.get('best_strategy', 'N/A')}\n"
        )
    user_content += (
        f"Reasoning: {comparison.reasoning[:400]}\n"
        f"Original EXPLAIN: {original_analysis.get('explanation', '')[:200]}"
    )

    try:
        llm = _tracked_llm()
        result = llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])
        return getattr(result, "content", None) or str(result)
    except Exception as exc:
        logger.warning("Summary generation failed (non-fatal): %s", exc)
        return (
            "Query optimisation completed with improvements."
            if has_improvement
            else "Query optimisation found no improvements over the original."
        )


def _plan_strategies_sync(
    sql_query: str,
    user_request: str,
    original_analysis: dict,
    ddls: dict[str, str],
    lineage_info: dict,
    max_strategies: int,
) -> StrategiesOutput:
    from langchain_core.messages import SystemMessage

    you_items = [
        w for w in original_analysis.get("warnings", []) + original_analysis.get("recommendations", [])
        if w.startswith("[You]")
    ]
    if not you_items:
        return StrategiesOutput(strategies=[])

    ddl_block = "\n\n".join(f"-- {k}\n{v}" for k, v in ddls.items()) or "(DDL unavailable)"
    lineage_block = "\n".join(
        "  {}: PI=[{}]  PARTITION=[{}]".format(
            name,
            ", ".join(info.get("primary_index_columns", [])) or "unknown",
            ", ".join(info.get("partition_columns", [])) or "none",
        )
        for name, info in lineage_info.items()
    ) or "  (lineage unavailable)"

    you_block = "\n".join(f"  {item}" for item in you_items)

    system = skill_prompt("qo-strategies").format(
        max_strategies=max_strategies,
        teradata_sql_guide=_teradata_sql_guide(),
    )
    user_content = (
        f"User request: {user_request}\n\n"
        f"Original SQL:\n```sql\n{sql_query}\n```\n\n"
        f"Author-actionable [You] items:\n{you_block}\n\n"
        f"DDL:\n{ddl_block}\n\n"
        f"Lineage:\n{lineage_block}"
    )

    import tdfs4ds as _tds
    max_tokens = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
    llm = _tracked_llm(max_tokens=max_tokens).with_structured_output(StrategiesOutput)
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])


def _generate_for_strategy_sync(
    sql_query: str,
    strategy: "StrategySpec",
    user_request: str,
    original_analysis: dict,
    ddls: dict[str, str],
    lineage_info: dict,
) -> CandidateRewrite:
    """Generate exactly one candidate SQL rewrite for a specific strategy.

    Unlike ``_generate_candidates_sync`` (generic prompt, up to N candidates),
    this function constrains the LLM to produce one rewrite that strictly
    follows the given strategy description and targets.
    """
    from langchain_core.messages import SystemMessage

    ddl_block = (
        "\n\n".join(f"-- {k}\n{v}" for k, v in ddls.items())
        or "(DDL unavailable)"
    )
    lineage_block = (
        "\n".join(
            "  {}: PI=[{}]  PARTITION=[{}]".format(
                name,
                ", ".join(info.get("primary_index_columns", [])) or "unknown",
                ", ".join(info.get("partition_columns", [])) or "none",
            )
            for name, info in lineage_info.items()
        )
        or "  (lineage unavailable)"
    )
    explain_block = _format_analysis_for_prompt(original_analysis)
    targets_block = "\n".join(f"  - {t}" for t in strategy.targets) if strategy.targets else "  (general improvement)"

    # ── Extract technique constraint from strategy name suffix ────────────
    # Strategy names like "fix-you-1-cte" carry the technique after the last
    # numeric segment.  Map the suffix to an explicit instruction block.
    _suffix_map = {
        "cte":        "Use a CTE (WITH clause) as the PRIMARY technique for precomputing values.",
        "crossjoin":  "Use a CROSS JOIN to a single-row scalar subquery as the PRIMARY technique for precomputing values.",
        "scalar":     "Use an inline scalar subquery inside the expression as the PRIMARY technique.",
        "window":     "Use window/analytical functions (e.g., AVG() OVER()) as the PRIMARY technique.",
        "singlepass": (
            "Combine all aggregations into a single GROUP BY pass with conditional expressions (CASE WHEN). "
            "STRUCTURE RULE: place the single-pass aggregation in a CTE (e.g. `agg`), "
            "then compute ALL derived expressions (ratios, date arithmetic, any expression "
            "that references an aggregated alias) in the outer SELECT that reads from the CTE. "
            "Do NOT inline everything into one flat SELECT — aliases defined in a GROUP BY SELECT "
            "cannot be referenced in the same SELECT list, so duplicating expressions is WRONG. "
            "The correct pattern is: WITH agg AS (SELECT ..., SUM(CASE WHEN ...) AS hv_count "
            "FROM t GROUP BY key) SELECT ..., hv_count / count AS ratio FROM agg. "
            "If the CASE WHEN contains a scalar subquery, it appears only once inside the CTE "
            "and is referenced by alias in the outer SELECT — never repeated."
        ),
    }
    import re as _re_tech
    _tech_match = _re_tech.search(r"fix-you-\d+-([\w]+)$", strategy.name)
    _technique_block = ""
    if _tech_match:
        _suffix = _tech_match.group(1)
        _constraint = _suffix_map.get(_suffix, "")
        if _constraint:
            _technique_block = (
                f"\n\n**TECHNIQUE CONSTRAINT**:\n{_constraint}\n"
                "You MAY also apply additional structural improvements "
                "(e.g., merging multiple scans into a single GROUP BY pass, "
                "removing redundant subquery layers) as long as the primary "
                "technique above is used.\n"
            )

    system = skill_prompt("qo-generate").format(
        strategy_name=strategy.name,
        strategy_description=strategy.description,
        targets_block=targets_block,
        technique_block=_technique_block,
        teradata_sql_guide=_teradata_sql_guide(),
    )

    user_content = (
        f"User request: {user_request}\n\n"
        f"Original SQL:\n```sql\n{sql_query}\n```\n\n"
        f"EXPLAIN analysis:\n{explain_block}\n\n"
        f"DDL (PI + partitioning):\n{ddl_block}\n\n"
        f"Lineage metadata:\n{lineage_block}"
    )

    import tdfs4ds as _tds
    max_tokens = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
    llm = _tracked_llm(max_tokens=max_tokens).with_structured_output(CandidateRewrite)
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])


def _refine_candidate_sync(
    sql_query: str,
    remaining_you_items: list[str],
    strategy_name: str,
    user_request: str,
    ddls: dict[str, str],
    lineage_info: Optional[dict] = None,
) -> Optional[CandidateRewrite]:
    """Refine a candidate SQL to fix remaining [You] items without changing the strategy.

    *remaining_you_items* should already have the ``[You]`` prefix stripped.
    *lineage_info* provides PI + partition columns so the LLM can make
    informed fixes for index-related warnings.
    """
    from langchain_core.messages import SystemMessage

    if not remaining_you_items:
        return None

    ddl_block = "\n\n".join(f"-- {k}\n{v}" for k, v in ddls.items()) or "(DDL unavailable)"
    items_block = "\n".join(f"  - {item}" for item in remaining_you_items)

    lineage_block = ""
    if lineage_info:
        lineage_block = "\n\nLineage metadata:\n" + (
            "\n".join(
                "  {}: PI=[{}]  PARTITION=[{}]".format(
                    name,
                    ", ".join(info.get("primary_index_columns", [])) or "unknown",
                    ", ".join(info.get("partition_columns", [])) or "none",
                )
                for name, info in lineage_info.items()
            )
            or "  (lineage unavailable)"
        )

    system = skill_prompt("qo-refine").format(
        strategy_name=strategy_name,
        teradata_sql_guide=_teradata_sql_guide(),
    )
    user_content = (
        f"User request: {user_request}\n\n"
        f"Current SQL (strategy `{strategy_name}`, needs refinement):\n```sql\n{sql_query}\n```\n\n"
        f"[You] issues STILL present after previous round \u2014 fix these:\n{items_block}\n\n"
        f"DDL context:\n{ddl_block}"
        f"{lineage_block}"
    )

    import tdfs4ds as _tds
    max_tokens = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
    llm = _tracked_llm(max_tokens=max_tokens).with_structured_output(CandidateRewrite)
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])


def _simplify_sql_sync(
    sql_query: str,
    ddls: dict[str, str],
) -> Optional[CandidateRewrite]:
    """Ask the LLM to produce the most compact, readable form of the SQL.

    Flattens unnecessary nesting, merges derived-table layers into CTEs,
    inlines date arithmetic, and removes identity wrappers \u2014 while
    preserving exact business logic (same result set).

    Used as the LLM pass in ``skill_simplify_query``.
    Returns ``None`` if the LLM cannot simplify further.
    """
    from langchain_core.messages import SystemMessage

    ddl_block = "\n\n".join(f"-- {k}\n{v}" for k, v in ddls.items()) or "(DDL unavailable)"

    system = skill_prompt("qo-simplify").format(
        teradata_sql_guide=_teradata_sql_guide(),
    )
    user_content = (
        f"SQL to simplify:\n```sql\n{sql_query}\n```\n\n"
        f"DDL context:\n{ddl_block}"
    )

    import tdfs4ds as _tds
    max_tokens = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
    llm = _tracked_llm(max_tokens=max_tokens).with_structured_output(CandidateRewrite)
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user_content)])


def _generate_report_sync(
    sql_query: str,
    user_request: str,
    original_analysis: dict,
    lineage_info: dict,
    candidate_analyses: list[dict],
    comparison: PlanComparison,
    best_sql: str,
    fm_suggestion: dict,
    process_info: Optional[dict],
    score_delta: Optional[dict] = None,
    strategy_plan: Optional[StrategiesOutput] = None,
    simplify_result: Optional[dict] = None,
    original_raw_sql: Optional[str] = None,
    token_usage: Optional[dict] = None,
) -> str:
    """Assemble the Markdown optimisation report from structured data.

    Only the ## Summary section uses a short LLM call (~100 tokens output).
    All other sections are built deterministically from the pipeline outputs,
    avoiding the token-limit failures that occur when the full report is LLM-generated.
    """
    def _fmt_score(v: Optional[float]) -> str:
        return f"{v}/5" if v is not None else "N/A"

    def _fmt_int(v) -> str:
        return str(int(v)) if v is not None else "N/A"

    def _fmt_delta(d: Optional[float]) -> str:
        if d is None:
            return "—"
        return f"+{d}" if d > 0 else ("—" if d == 0 else str(d))

    def _fmt_int_delta(d: Optional[float]) -> str:
        """Format an integer delta where negative is good (fewer steps/spools)."""
        if d is None:
            return "—"
        d_int = int(d)
        if d_int < 0:
            return str(d_int)  # e.g. "-3" — improvement
        if d_int == 0:
            return "—"
        return f"+{d_int}"

    selected_idx = comparison.best_index

    # ── ## Summary (short LLM call) ──────────────────────────────────────────
    summary_text = _generate_summary_sync(
        user_request, original_analysis, comparison,
        score_delta, len(candidate_analyses),
    )

    # ── ## Score Summary ─────────────────────────────────────────────────────
    _was_simplified = simplify_result and simplify_result.get("simplified")
    # Extract pre-simplification (input) metrics from the baseline analysis
    _baseline = (simplify_result.get("_baseline_analysis") or {}) if _was_simplified else {}
    if score_delta:
        _input_u = simplify_result.get("original_score") if _was_simplified else None
        _input_g = _baseline.get("global_score")
        _input_st = _baseline.get("n_steps")
        _input_sp = _baseline.get("n_spool_objects")
        _simp_u = score_delta.get("original_user_score")    # after simplification = optimizer baseline
        _simp_g = score_delta.get("original_global_score")
        _best_u = score_delta.get("best_user_score")
        _best_g = score_delta.get("best_global_score")
        _simp_st = score_delta.get("original_n_steps")
        _best_st = score_delta.get("best_n_steps")
        _simp_sp = score_delta.get("original_n_spools")
        _best_sp = score_delta.get("best_n_spools")

        if _was_simplified and _input_u is not None:
            # 3-stage table: Input → Simplified → Optimized
            score_section = (
                "| Metric | Input | Simplified | Optimized |\n"
                "|--------|-------|------------|----------|\n"
                f"| User score (SQL quality) | {_fmt_score(_input_u)} | {_fmt_score(_simp_u)} | {_fmt_score(_best_u)} |\n"
                f"| Global score (incl. infra) | {_fmt_score(_input_g)} | {_fmt_score(_simp_g)} | {_fmt_score(_best_g)} |\n"
                f"| EXPLAIN steps | {_fmt_int(_input_st)} | {_fmt_int(_simp_st)} | {_fmt_int(_best_st)} |\n"
                f"| Spool objects | {_fmt_int(_input_sp)} | {_fmt_int(_simp_sp)} | {_fmt_int(_best_sp)} |\n\n"
            )
        else:
            # 2-stage table: Before → After
            score_section = (
                "| Metric | Before | After | \u0394 Change |\n"
                "|--------|--------|-------|----------|\n"
                f"| User score (SQL quality) | {_fmt_score(_simp_u)} | "
                f"{_fmt_score(_best_u)} | "
                f"{_fmt_delta(score_delta.get('user_score_delta'))} |\n"
                f"| Global score (incl. infra) | {_fmt_score(_simp_g)} | "
                f"{_fmt_score(_best_g)} | "
                f"{_fmt_delta(score_delta.get('global_score_delta'))} |\n"
                f"| EXPLAIN steps | {_fmt_int(_simp_st)} | "
                f"{_fmt_int(_best_st)} | "
                f"{_fmt_int_delta(score_delta.get('steps_delta'))} |\n"
                f"| Spool objects | {_fmt_int(_simp_sp)} | "
                f"{_fmt_int(_best_sp)} | "
                f"{_fmt_int_delta(score_delta.get('spools_delta'))} |\n\n"
            )
        # Detect when the score improved but steps/spools increased — explain the trade-off.
        # Compare against the simplification baseline (or original when no simplification).
        _score_improved = (
            _best_u is not None and _simp_u is not None and _best_u > _simp_u
        )
        _steps_increased = (
            _best_st is not None and _simp_st is not None and _best_st > _simp_st
        )
        _spools_increased = (
            _best_sp is not None and _simp_sp is not None and _best_sp > _simp_sp
        )
        if _score_improved and (_steps_increased or _spools_increased):
            _extra_steps = (_best_st or 0) - (_simp_st or 0)
            _extra_spools = (_best_sp or 0) - (_simp_sp or 0)
            score_section += (
                "\n\n> **Note:** The optimized query has "
            )
            parts = []
            if _steps_increased:
                parts.append(f"{_extra_steps} more step{'s' if _extra_steps != 1 else ''}")
            if _spools_increased:
                parts.append(f"{_extra_spools} more spool object{'s' if _extra_spools != 1 else ''}")
            score_section += " and ".join(parts)
            score_section += (
                f" than the baseline, but the SQL quality score improved "
                f"({_fmt_score(_simp_u)} \u2192 {_fmt_score(_best_u)}). "
                "The additional spool objects are typically single-row materializations "
                "(e.g. a precomputed threshold via CTE or CROSS JOIN) with negligible "
                "I/O and memory cost. The score improvement reflects a genuine structural "
                "fix in the SQL logic."
            )

        score_section += (
            "\n\nStrategy applied: {}  \n".format(
                (score_delta.get('best_strategy') or 'N/A')[:120]
            ) +
            f"Business logic preserved: {score_delta.get('business_logic_preserved', True)}"
        )
    else:
        score_section = "_Score data unavailable._"

    # ── ## Lineage & Partition Analysis ──────────────────────────────────────
    lineage_md = "\n".join(
        "- `{}`: PI=[{}], PARTITION=[{}]".format(
            n,
            ", ".join(i.get("primary_index_columns", [])) or "unknown",
            ", ".join(i.get("partition_columns", [])) or "none",
        )
        for n, i in lineage_info.items()
    ) or "_Lineage unavailable._"

    # ── ## Original EXPLAIN Analysis ─────────────────────────────────────────
    _u = original_analysis.get("user_score")
    _g = original_analysis.get("global_score")
    _orig_st = original_analysis.get("n_steps")
    _orig_sp = original_analysis.get("n_spool_objects")
    _you_w = [w[len("[You]"):].lstrip(" -–:") for w in original_analysis.get("warnings", []) if w.startswith("[You]")]
    _you_r = [r[len("[You]"):].lstrip(" -–:") for r in original_analysis.get("recommendations", []) if r.startswith("[You]")]
    _steps_str = f"**Steps:** {_orig_st}" if _orig_st is not None else "**Steps:** —"
    _spools_str = f"**Spool objects:** {_orig_sp}" if _orig_sp is not None else "**Spool objects:** —"
    explain_text = (
        f"- **User score:** {_fmt_score_display(_u)}  |  **Global score:** {_fmt_score_display(_g)}"
        f"  |  {_steps_str}  |  {_spools_str}\n\n"
        f"{original_analysis.get('explanation', '_(unavailable)_')}"
    )
    if _you_w:
        explain_text += "\n\n**Warnings:**\n" + "\n".join(f"- {w}" for w in _you_w)
    if _you_r:
        explain_text += "\n\n**Recommendations:**\n" + "\n".join(f"- {r}" for r in _you_r)

    # ── ## Simplification ────────────────────────────────────────────────────
    if simplify_result and simplify_result.get("simplified"):
        _s_orig = simplify_result.get("original_score")
        _s_simp = simplify_result.get("simplified_score")
        simplification_section = (
            f"SQL was simplified before optimization "
            f"(input score: {_fmt_score_display(_s_orig)} \u2192 simplified score: {_fmt_score_display(_s_simp)}). "
            f"See the 3-stage query comparison below."
        )
    else:
        simplification_section = "_No structural simplification applied (SQL already compact or LLM could not simplify)._"

    # ── ## Strategy Plan ──────────────────────────────────────────────────────
    if strategy_plan and strategy_plan.strategies:
        plan_parts: list[str] = []
        for i, s in enumerate(strategy_plan.strategies):
            targets_md = "\n".join(f"  - {t}" for t in s.targets) if s.targets else "  - _(general improvement)_"
            plan_parts.append(
                f"**{i + 1}. `{s.name}`** \u2014 {s.description}\n\n"
                f"  Targets:\n{targets_md}"
            )
        strategy_plan_section = "\n\n".join(plan_parts)
    else:
        strategy_plan_section = "_No strategies planned (query already optimal or no [You] items found)._"

    # ── ## Strategy Results ──────────────────────────────────────────────────
    if candidate_analyses:
        cand_parts: list[str] = []
        for list_pos, ca in enumerate(candidate_analyses):
            analysis = ca.get("analysis", {})
            tag = " \u2190 **SELECTED**" if list_pos == selected_idx else ""
            u = analysis.get("user_score")
            strat_desc = ca.get("strategy_description") or ""
            strat_targets = ca.get("strategy_targets") or []

            # Full rationale (strip [You] prefix the model may echo)
            rationale_raw = (ca.get("rationale") or "").lstrip()
            if rationale_raw.upper().startswith("[YOU]"):
                rationale_raw = rationale_raw[5:].lstrip(" -\u2013:")

            part = f"### Strategy {ca['index'] + 1}: `{ca['strategy']}`{tag}\n\n"
            if strat_desc:
                part += f"{strat_desc}\n\n"
            if rationale_raw:
                part += f"_{rationale_raw}_\n\n"

            # ── Round progression ─────────────────────────────────────────
            rounds = ca.get("rounds", [])
            if rounds:
                for rnd in rounds:
                    rnd_num = rnd.get("round", 0)
                    rnd_custom_label = rnd.get("label")
                    rnd_label = rnd_custom_label if rnd_custom_label else ("Initial" if rnd_num == 0 else f"Refine {rnd_num}")
                    rnd_score = rnd.get("user_score")
                    rnd_n_steps = rnd.get("n_steps")
                    rnd_n_spools = rnd.get("n_spool_objects")
                    rnd_remaining = rnd.get("remaining_you_items", [])
                    score_str = f"**{rnd_score}/5**" if rnd_score is not None else "**FAIL**"
                    metrics_parts = []
                    if rnd_n_steps is not None:
                        metrics_parts.append(f"Steps: {rnd_n_steps}")
                    if rnd_n_spools is not None:
                        metrics_parts.append(f"Spools: {rnd_n_spools}")
                    metrics_str = f"  |  {', '.join(metrics_parts)}" if metrics_parts else ""

                    part += f"**{rnd_label}** \u2014 User score: {score_str}{metrics_str}\n\n"

                    if rnd_score is not None and not rnd_remaining:
                        part += "_No remaining [You] items \u2014 all resolved._\n\n"
                    elif rnd_remaining:
                        part += "Remaining [You] items:\n"
                        for item in rnd_remaining:
                            part += f"- {item}\n"
                        part += "\n"
                    else:
                        rnd_expl = rnd.get("analysis", {}).get("explanation", "")
                        first_err = (rnd_expl.splitlines()[0] if rnd_expl else "N/A").strip()
                        part += f"EXPLAIN error: {first_err}\n\n"
            else:
                # No rounds recorded — show final analysis directly
                if u is not None:
                    _ca_st = analysis.get("n_steps")
                    _ca_sp = analysis.get("n_spool_objects")
                    _ca_metrics = ""
                    if _ca_st is not None or _ca_sp is not None:
                        _ca_metrics = f"  |  Steps: {_ca_st or '—'}, Spools: {_ca_sp or '—'}"
                    remaining_items = _extract_you_items(analysis)
                    remaining_md = (
                        "**Remaining [You] items:**\n"
                        + "\n".join(f"- {item}" for item in remaining_items)
                    ) if remaining_items else "**Remaining [You] items:** _none \u2014 all resolved._"
                    part += f"User score: {_fmt_score_display(u)}{_ca_metrics}\n\n{remaining_md}\n\n"
                else:
                    expl = analysis.get("explanation", "")
                    first_err = (expl.splitlines()[0] if expl else "no details").strip()
                    part += f"EXPLAIN failed \u2014 {first_err}\n\n"

            # ── Final SQL ────────────────────────────────────────────────────
            sql_full = (ca.get("sql") or "").strip()
            if sql_full:
                part += (
                    f"<details><summary>View Final SQL</summary>\n\n"
                    f"```sql\n{sql_full}\n```\n\n</details>"
                )

            cand_parts.append(part)
        candidates_section = "\n\n---\n\n".join(cand_parts)
    else:
        candidates_section = "_No rewrite candidates were generated._"

    # ── ## Selected Optimisation ──────────────────────────────────────────────
    import re as _re
    def _strip_sql_blocks(text: str) -> str:
        """Remove ```sql ... ``` and ``` ... ``` fences from reasoning text.

        The comparison LLM sometimes hallucinates a 'Final SQL' block inside its
        reasoning that differs from the actual selected candidate SQL.  Since the
        real SQL is already shown in ## Rewritten Query, we strip any code blocks
        from the reasoning to avoid confusion.
        """
        return _re.sub(r'```(?:sql)?\s*.*?```', '', text, flags=_re.DOTALL).strip()

    if 0 <= selected_idx < len(candidate_analyses):
        ca = candidate_analyses[selected_idx]
        rounds = ca.get("rounds", [])
        total_rounds = len(rounds)
        final_score = ca.get("analysis", {}).get("user_score")
        selected_section = (
            f"Strategy `{ca['strategy']}` was selected"
            f" (reached {_fmt_score_display(final_score)} after {total_rounds} round{'s' if total_rounds != 1 else ''}).\n\n"
            f"**Reasoning:** {_strip_sql_blocks(comparison.reasoning)}\n\n"
            f"Business logic preserved: {comparison.business_logic_preserved}  \n"
            f"Notes: {comparison.business_logic_notes}"
        )
    else:
        selected_section = (
            "Original query is already optimal.\n\n"
            f"**Reasoning:** {_strip_sql_blocks(comparison.reasoning)}"
        )

    # ── ## Recommendations (non-selected candidates with business assumptions) ──
    # Surface rewrites that were not retained because they make a domain assumption
    # the optimizer cannot verify, but that could be valid in the right business context.
    rec_parts: list[str] = []
    for list_pos, ca in enumerate(candidate_analyses):
        if list_pos == selected_idx:
            continue
        assumptions = (ca.get("business_assumptions") or "").strip()
        if not assumptions:
            continue
        if ca.get("analysis", {}).get("user_score") is None:
            continue  # skip EXPLAIN failures — we can't confirm the rewrite is safe
        rationale_raw = (ca.get("rationale") or "").strip()
        rec_parts.append(
            f"**`{ca['strategy']}`** — {rationale_raw}\n\n"
            f"> **Assumption:** {assumptions}"
        )
    if rec_parts:
        recommendations_md = (
            "## Recommendations\n\n"
            "_These rewrites were not retained because they rely on a business assumption "
            "that the optimizer cannot verify. Review them with your domain knowledge — "
            "if the assumption holds, the rewrite can be applied manually._\n\n"
            + "\n\n---\n\n".join(rec_parts)
            + "\n\n"
        )
    else:
        recommendations_md = ""

    # ── ## FilterManager Recommendation ──────────────────────────────────────
    fm_section = (
        fm_suggestion["suggestion"]
        if fm_suggestion.get("applicable")
        else "_FilterManager not applicable: partition columns are already filtered._"
    )

    # ── Optional process-context header ──────────────────────────────────────
    process_header = ""
    if process_info:
        entity_cols = ", ".join(process_info.get("ENTITY_COLUMNS", []))
        feature_cols = ", ".join(process_info.get("FEATURE_COLUMNS", []) or [])
        process_header = (
            f"_Process context — Entity: [{entity_cols}] | Features: [{feature_cols}]_\n\n"
        )

    # ── ## Query section (3-stage: input → simplified → optimized) ────────────
    query_changed = 0 <= selected_idx < len(candidate_analyses)
    _was_simplified = simplify_result and simplify_result.get("simplified")
    _raw_sql = _format_sql(original_raw_sql) if original_raw_sql else None

    if query_changed:
        if _was_simplified and _raw_sql and _raw_sql.strip() != sql_query.strip():
            # All 3 stages differ
            _s_orig = simplify_result.get("original_score")
            _s_simp = simplify_result.get("simplified_score")
            _s_best = score_delta.get('best_user_score') if score_delta else None
            query_section = (
                f"## Input Query (score: {_fmt_score_display(_s_orig)})\n\n"
                f"<details><summary>View SQL</summary>\n\n```sql\n{_raw_sql}\n```\n\n</details>\n\n"
                f"## After Simplification (score: {_fmt_score_display(_s_simp)})\n\n"
                f"<details><summary>View SQL</summary>\n\n```sql\n{sql_query}\n```\n\n</details>\n\n"
                f"## After Optimization (score: {_fmt_score_display(_s_best)})\n\n"
                f"<details open><summary>View SQL</summary>\n\n```sql\n{best_sql}\n```\n\n</details>\n\n"
            )
        else:
            query_section = (
                f"## Original Query\n\n"
                f"<details><summary>View SQL</summary>\n\n```sql\n{sql_query}\n```\n\n</details>\n\n"
                f"## Rewritten Query\n\n"
                f"<details open><summary>View SQL</summary>\n\n```sql\n{best_sql}\n```\n\n</details>\n\n"
            )
    else:
        # No optimization candidate selected — check if simplification changed the SQL
        if _was_simplified and _raw_sql and _raw_sql.strip() != sql_query.strip():
            _s_simp = simplify_result.get("simplified_score")
            _s_orig = simplify_result.get("original_score")
            query_section = (
                f"## Input Query (score: {_fmt_score_display(_s_orig)})\n\n"
                f"<details><summary>View SQL</summary>\n\n```sql\n{_raw_sql}\n```\n\n</details>\n\n"
                f"## After Simplification (score: {_fmt_score_display(_s_simp)})\n\n"
                f"_No optimization candidate improved upon the simplified query._\n\n"
                f"<details open><summary>View SQL</summary>\n\n```sql\n{best_sql}\n```\n\n</details>\n\n"
            )
        else:
            query_section = (
                f"## Query (Unchanged)\n\n"
                f"<details open><summary>View SQL</summary>\n\n```sql\n{best_sql}\n```\n\n</details>\n\n"
            )

    # ── ## Remaining Issues ────────────────────────────────────────────────
    remaining_issues_md = ""
    if 0 <= selected_idx < len(candidate_analyses):
        sel_analysis = candidate_analyses[selected_idx].get("analysis", {})
        sel_score = sel_analysis.get("user_score")
        if sel_score is not None and sel_score < 5:
            remaining = _extract_you_items(sel_analysis)
            if remaining:
                remaining_issues_md = (
                    "## Remaining Issues\n\n"
                    f"_The optimized query scored {sel_score}/5. "
                    f"The following [You] items were not resolved:_\n\n"
                    + "\n".join(f"- {item}" for item in remaining)
                    + "\n\n"
                )
    else:
        # No candidate selected — show remaining issues from original_analysis
        orig_score = original_analysis.get("user_score")
        if orig_score is not None and orig_score < 5:
            remaining = _extract_you_items(original_analysis)
            if remaining:
                remaining_issues_md = (
                    "## Remaining Issues\n\n"
                    f"_The current query scored {orig_score}/5. "
                    f"The following [You] items were not resolved:_\n\n"
                    + "\n".join(f"- {item}" for item in remaining)
                    + "\n\n"
                )

    # ── ## Token Usage ──────────────────────────────────────────────────────
    if token_usage and token_usage.get("llm_calls", 0) > 0:
        _calls = token_usage["llm_calls"]
        _in = token_usage["prompt_tokens"]
        _out = token_usage["completion_tokens"]
        _tot = token_usage["total_tokens"]
        token_section = (
            f"| Metric | Value |\n"
            f"|--------|------:|\n"
            f"| LLM calls | {_calls:,} |\n"
            f"| Input tokens | {_in:,} |\n"
            f"| Output tokens | {_out:,} |\n"
            f"| **Total tokens** | **{_tot:,}** |\n"
        )
    else:
        token_section = "_Token usage data unavailable._"

    return (
        f"{process_header}"
        f"## Summary\n\n{summary_text}\n\n"
        f"## Score Summary\n\n{score_section}\n\n"
        f"## Lineage & Partition Analysis\n\n{lineage_md}\n\n"
        f"## Original EXPLAIN Analysis\n\n{explain_text}\n\n"
        f"## Simplification\n\n{simplification_section}\n\n"
        f"## Strategy Plan\n\n{strategy_plan_section}\n\n"
        f"## Strategy Results\n\n{candidates_section}\n\n"
        f"## Selected Optimisation\n\n{selected_section}\n\n"
        f"{recommendations_md}"
        f"{query_section}"
        f"{remaining_issues_md}"
        f"## FilterManager Recommendation\n\n{fm_section}\n\n"
        f"## Token Usage\n\n{token_section}\n"
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Strategy-based candidate generation  (plan → execute → refine per strategy)
# ═══════════════════════════════════════════════════════════════════════════════

def _normalize_sql(sql: str) -> str:
    """Collapse whitespace and lowercase for similarity comparison."""
    import re
    return re.sub(r"\s+", " ", sql).strip().lower()


def _split_select_items(col_str: str) -> list:
    """Split a comma-separated SELECT column list, respecting paren depth and quotes."""
    items: list = []
    depth = 0
    in_quote = None
    buf: list = []
    for ch in col_str:
        if in_quote:
            buf.append(ch)
            if ch == in_quote:
                in_quote = None
        elif ch in ('"', "'"):
            in_quote = ch
            buf.append(ch)
        elif ch == '(':
            depth += 1
            buf.append(ch)
        elif ch == ')':
            depth -= 1
            buf.append(ch)
        elif ch == ',' and depth == 0:
            items.append(''.join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf:
        items.append(''.join(buf).strip())
    return items


def _is_from_keyword(text: str, pos: int) -> bool:
    """Return True when position *pos* in *text* is the start of a standalone FROM keyword."""
    if text[pos:pos + 4].upper() != 'FROM':
        return False
    # Must not be preceded by a word character (avoid matching mid-identifier)
    if pos > 0 and (text[pos - 1].isalnum() or text[pos - 1] == '_'):
        return False
    # Must be followed by whitespace or '('
    nxt = text[pos + 4:pos + 5]
    return nxt in (' ', '\t', '\n', '\r', '(', '')


def _walk_to_from(text: str, start: int) -> int:
    """Return the index of the first depth-0 FROM keyword starting at *start*, or -1."""
    pos = start
    depth = 0
    in_sq = in_dq = False
    while pos < len(text):
        ch = text[pos]
        if in_sq:
            if ch == "'":
                in_sq = False
        elif in_dq:
            if ch == '"':
                in_dq = False
        elif ch == "'":
            in_sq = True
        elif ch == '"':
            in_dq = True
        elif ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif depth == 0 and _is_from_keyword(text, pos):
            return pos
        pos += 1
    return -1


def _sanitize_sql_identifiers(sql: str) -> str:
    """Replace MySQL/generic backtick identifiers with Teradata double-quote identifiers.

    LLMs occasionally produce `` `column_name` `` style quoting (MySQL habit) which
    Teradata rejects with Error 3707.  A simple regex substitution is safe here because
    we never generate SQL that contains backtick characters for any other purpose.
    """
    import re
    return re.sub(r'`([^`]+)`', r'"\1"', sql)


def _fix_scalar_subquery_to_direct_ref(sql: str) -> str:
    """Replace (SELECT col FROM derived_alias) → derived_alias.col.

    Teradata resolves the FROM clause of a scalar subquery against the database
    catalog, not against derived-table aliases visible in the enclosing FROM clause.
    The correct pattern is to reference the column directly: derived_alias.col_name.

    Algorithm:
      1. Collect all derived-table alias names defined in the SQL
         (pattern: ``) alias_name`` followed by whitespace or a SQL keyword).
      2. Replace every ``(SELECT single_col FROM alias)`` where alias is a known
         derived-table alias with ``alias.single_col``.

    Complements ``_fix_reserved_word_alias``: both are applied together so that
    e.g. ``(SELECT threshold FROM hvt)`` is first rewritten to ``hvt.threshold``
    and then ``threshold`` as a reserved-word alias is renamed if needed.
    """
    import re

    _KW = {
        'SELECT', 'FROM', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'JOIN',
        'INNER', 'OUTER', 'LEFT', 'RIGHT', 'FULL', 'CROSS', 'ON',
        'AND', 'OR', 'NOT', 'AS', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END',
        'WITH', 'UNION', 'INTERSECT', 'EXCEPT', 'INSERT', 'UPDATE',
        'DELETE', 'MERGE', 'INTO', 'SET', 'BY', 'DISTINCT', 'ALL',
        'OVER', 'PARTITION', 'ROWS', 'RANGE', 'BETWEEN', 'UNBOUNDED',
        'PRECEDING', 'FOLLOWING', 'CURRENT', 'ROW', 'NULL', 'IS',
        'LIKE', 'IN', 'EXISTS', 'ANY', 'SOME',
    }

    # Collect derived-table aliases: ) alias_name (not a SQL keyword)
    derived_aliases: set = set()
    for m in re.finditer(r'\)\s+(\w+)\b', sql, re.IGNORECASE):
        alias = m.group(1)
        if alias.upper() not in _KW:
            derived_aliases.add(alias.upper())

    if not derived_aliases:
        return sql

    def _repl(m: re.Match) -> str:
        col = m.group(1).strip()
        alias = m.group(2).strip()
        if alias.upper() in derived_aliases:
            return f'{alias}.{col}'
        return m.group(0)

    # Match scalar subqueries with a single unqualified column and unqualified FROM target
    return re.sub(
        r'\(\s*SELECT\s+(\w+)\s+FROM\s+(\w+)\s*\)',
        _repl,
        sql,
        flags=re.IGNORECASE,
    )


def _fix_reserved_word_alias(sql: str, error_message: str) -> Optional[str]:
    """Deterministically rename a Teradata reserved word used as a column alias.

    Teradata Error 3706 sometimes reads:
        "Syntax error: expected something between '<token>' and the '<WORD>' keyword."
    when a reserved word (e.g. THRESHOLD, DATE, PERIOD) is used as a bare alias.

    This function extracts the offending word from the error message and renames
    every occurrence (alias definition AND bare column references) to ``<word>_col``.
    The rename is a global word-boundary substitution so it covers both
    ``... AS threshold`` and ``Transaction_Amount > threshold``.

    Returns the repaired SQL, or None if the error pattern does not match.
    """
    import re
    m = re.search(
        r"between\s+'[^']*'\s+and\s+the\s+'(\w+)'\s+keyword",
        error_message,
        re.IGNORECASE,
    )
    if not m:
        return None
    reserved = m.group(1)          # e.g. "threshold"
    new_name = f"{reserved.lower()}_col"
    fixed = re.sub(rf'\b{re.escape(reserved)}\b', new_name, sql, flags=re.IGNORECASE)
    return fixed if fixed != sql else None


def _fix_syntax_error_sync(
    sql: str,
    error_message: str,
    llm,
    max_fix_attempts: int = 3,
) -> Optional[str]:
    """Repair a Teradata SQL syntax error, first with deterministic checks then via LLM.

    Deterministic pass (no LLM cost):
      1. Reserved-word alias — detects the "expected … and the '<WORD>' keyword" pattern
         and renames the offending alias globally.

    LLM pass (up to *max_fix_attempts* retries):
      Asks the LLM to fix only the syntax, not the optimization logic.
      The deterministic post-processing (backtick sanitization, alias injection) is
      applied to the LLM's output before returning so the caller can go straight to EXPLAIN.

    Returns the repaired SQL string, or None if all attempts fail or raise.
    """
    import re as _re
    from langchain_core.messages import HumanMessage, SystemMessage

    # ── 1. Deterministic: chain scalar-subquery fix + reserved-word alias ───────
    # Apply both in sequence: the scalar-subquery fix converts (SELECT col FROM alias)
    # → alias.col, and the reserved-word fix renames e.g. AS threshold → AS threshold_col
    # (including the now-direct reference alias.threshold → alias.threshold_col).
    # Both are applied regardless of which error triggered the call.
    det_fixed = _fix_scalar_subquery_to_direct_ref(sql)
    word_fixed = _fix_reserved_word_alias(det_fixed, error_message)
    if word_fixed:
        det_fixed = word_fixed
    if det_fixed != sql:
        logger.info("Syntax fix: deterministic fix applied (scalar-subquery ref and/or reserved-word alias).")
        det_fixed = _sanitize_sql_identifiers(det_fixed)
        det_fixed = _add_missing_derived_table_aliases(det_fixed)
        return det_fixed

    # ── 2. LLM retry loop ─────────────────────────────────────────────────────
    system = skill_prompt("qo-syntax-fix")

    current_sql = sql
    for fix_attempt in range(max_fix_attempts):
        user_content = (
            f"This Teradata SQL failed with:\n{error_message}\n\n"
            f"Corrected SQL:\n{current_sql}"
        )
        try:
            response = llm.invoke([
                SystemMessage(content=system),
                HumanMessage(content=user_content),
            ])
            fixed = (response.content or "").strip()
            # Strip markdown fences the model may still produce
            fixed = _re.sub(r'```(?:sql)?\s*', '', fixed).strip('`').strip()
            if not fixed:
                continue
            # Apply deterministic fixes before returning
            fixed = _sanitize_sql_identifiers(fixed)
            fixed = _add_missing_derived_table_aliases(fixed)
            return fixed
        except Exception as _e:
            logger.warning("Syntax fix attempt %d/%d failed: %s", fix_attempt + 1, max_fix_attempts, _e)

    return None


def _add_missing_derived_table_aliases(sql: str) -> str:
    """Add missing aliases to unaliased derived tables in FROM/JOIN clauses.

    Teradata requires every inline view (subquery used as a derived table) to have
    an alias immediately after the closing parenthesis.  The LLM sometimes omits
    the alias when simplifying nested queries, causing Error 3707:
    "expected something like a name … between ')' and ';'".

    Algorithm: walk the SQL tracking parenthesis depth (skipping string literals),
    record every ``(`` that immediately follows FROM or JOIN, then when the matching
    ``)`` is found check whether it is followed by an SQL keyword or end-of-input
    instead of an identifier.  If so, inject ``_dt0``, ``_dt1``, … as the alias.
    """
    import re

    n = len(sql)

    # Positions of '(' that immediately follow FROM or JOIN (with optional whitespace)
    dt_opens: set = {m.end() - 1 for m in re.finditer(r'(?<!\w)(FROM|JOIN)\s*\(', sql, re.IGNORECASE)}

    stack: list = []        # each entry: (open_pos, is_derived_table: bool)
    insertions: list = []   # (insert_after_pos, alias_text)
    alias_idx = 0
    i = 0

    while i < n:
        ch = sql[i]
        # Skip single-quoted string literals to avoid false positives
        if ch == "'":
            i += 1
            while i < n and sql[i] != "'":
                if sql[i] == '\\':
                    i += 1  # skip escaped character
                i += 1
            i += 1  # skip closing quote
            continue

        if ch == '(':
            stack.append((i, i in dt_opens))
        elif ch == ')' and stack:
            _, is_dt = stack.pop()
            if is_dt:
                # Peek at what follows the closing paren (skip whitespace)
                j = i + 1
                while j < n and sql[j] in ' \t\n\r':
                    j += 1
                rest = sql[j: j + 15]
                # If a SQL keyword follows (instead of an alias identifier), alias is missing
                keyword_follows = re.match(
                    r'(WHERE|GROUP|ORDER|HAVING|UNION|INTERSECT|EXCEPT|ON|;)',
                    rest, re.IGNORECASE,
                )
                if keyword_follows or j >= n:
                    insertions.append((i + 1, f' _dt{alias_idx}'))
                    alias_idx += 1
        i += 1

    # Apply insertions in reverse order so earlier positions are not shifted
    for pos, text in sorted(insertions, reverse=True):
        sql = sql[:pos] + text + sql[pos:]

    return sql


def _try_flatten_identity_wrapper(sql: str) -> str:
    """Deterministically collapse a redundant identity-wrapper SELECT.

    Targets the pattern::

        [DDL] SELECT col1 [AS "col1"], ..., 'lit' AS extra
              FROM ( <inner_query> ) AS <alias>

    where the outer SELECT has no WHERE / GROUP BY / HAVING / ORDER BY and every
    column is either a same-name alias (``"x" AS "x"``) or a literal constant
    (``'v' AS extra``).

    Literal injection into an aggregation query is safe: SQL constants do not
    belong in GROUP BY and injecting them at the END of the SELECT list does not
    shift the positional indices used by any GROUP BY 1, 2, … already present in
    the inner query.

    Returns the original SQL unchanged when the pattern is not clearly recognized.
    """
    import re

    body = sql.strip()

    # ── 1. Split DDL prefix ──────────────────────────────────────────────────
    ddl_prefix = ""
    ddl_m = re.match(
        r"^((?:REPLACE|CREATE(?:\s+OR\s+REPLACE)?)\s+VIEW\s+\S+\s+AS\s+)",
        body, re.IGNORECASE,
    )
    if ddl_m:
        ddl_prefix = ddl_m.group(1)
        body = body[ddl_m.end():]

    # ── 2. Must open with SELECT ─────────────────────────────────────────────
    sel_m = re.match(r"^SELECT\s+", body, re.IGNORECASE)
    if not sel_m:
        return sql

    # ── 3. Find "FROM (" at depth 0 (outer query) ───────────────────────────
    from_kw_pos = _walk_to_from(body, sel_m.end())
    if from_kw_pos < 0:
        return sql

    # Verify the FROM is followed by a subquery, not a table name
    rest_after_from = body[from_kw_pos + 4:].lstrip()
    if not rest_after_from.startswith('('):
        return sql

    outer_cols_str = body[sel_m.end():from_kw_pos].strip().rstrip(',')

    # ── 4. Find matching closing paren of the subquery ───────────────────────
    paren_start = body.index('(', from_kw_pos + 4)
    depth = 0
    paren_close = -1
    for i in range(paren_start, len(body)):
        if body[i] == '(':
            depth += 1
        elif body[i] == ')':
            depth -= 1
            if depth == 0:
                paren_close = i
                break
    if paren_close < 0:
        return sql

    inner_query = body[paren_start + 1:paren_close].strip()

    # ── 5. Nothing meaningful after ") AS alias" ─────────────────────────────
    after = body[paren_close + 1:].strip()
    if after and not re.match(r"^AS\s+\w+\s*$", after, re.IGNORECASE):
        return sql  # outer WHERE / GROUP BY / etc. — cannot flatten safely

    # ── 6. Classify every outer column ───────────────────────────────────────
    outer_items = _split_select_items(outer_cols_str)
    literals: list = []
    for item in outer_items:
        item = item.strip()
        # String literal:  'value' AS alias
        if re.match(r"^'[^']*'\s+AS\s+\S+$", item, re.IGNORECASE):
            literals.append(item)
            continue
        # Numeric literal: 42 AS alias
        if re.match(r"^\d[\d.]*\s+AS\s+\S+$", item, re.IGNORECASE):
            literals.append(item)
            continue
        # Identity alias:  "col" AS "col"  /  col AS col  /  bare col
        id_m = re.match(r'^"?(\w+)"?(?:\s+AS\s+"?(\w+)"?)?$', item, re.IGNORECASE)
        if id_m:
            col, alias = id_m.group(1), id_m.group(2)
            if alias is None or col.lower() == alias.lower():
                continue
        return sql  # complex expression — abort

    # ── 7. Find depth-0 FROM in the inner query ───────────────────────────────
    inner_sel_m = re.match(r"^SELECT\s+", inner_query, re.IGNORECASE)
    if not inner_sel_m:
        return sql

    inner_from_pos = _walk_to_from(inner_query, inner_sel_m.end())
    if inner_from_pos < 0:
        return sql

    # ── 8. Inject literals at the END of the inner SELECT ────────────────────
    # Injecting at the end is safe even for aggregation queries:
    #   • Constants never need to appear in GROUP BY.
    #   • Appending new columns does not shift positions 1…N already used by
    #     GROUP BY 1, 2, … in the inner query.
    inner_select_part = inner_query[:inner_from_pos].rstrip()
    inner_from_part   = inner_query[inner_from_pos:]

    if not literals:
        return ddl_prefix + inner_query

    lit_str = ",\n       " + ",\n       ".join(literals)
    return ddl_prefix + inner_select_part + lit_str + "\n" + inner_from_part


def _is_near_duplicate(sql_a: str, sql_b: str, threshold: float = 0.97) -> bool:
    """Return True when two SQL strings are essentially the same query.

    Uses exact match after normalisation first (fast path), then falls back to
    difflib similarity ratio so cosmetic reformats (added aliases, re-indented
    subqueries) are also detected.
    """
    import difflib
    na, nb = _normalize_sql(sql_a), _normalize_sql(sql_b)
    if na == nb:
        return True
    return difflib.SequenceMatcher(None, na, nb).ratio() >= threshold


def _sql_structure_preview(sql: str, max_chars: int = 400) -> str:
    """Return the structural skeleton of a SQL string for context feedback.

    Skips the SELECT column list (which is identical across all candidates and
    wastes tokens) and returns instead:
    - The WITH block if present (CTE names + first line of each CTE body)
    - Everything from the first top-level FROM keyword onwards

    This makes the preview directly comparable across candidates at the level
    where structural differences actually exist.
    """
    import re
    s = sql.strip()

    # If it starts with WITH, extract CTE names and show the rest
    if re.match(r'(?i)^\s*WITH\b', s):
        # Show from WITH up to max_chars — the CTE structure is the key info
        return s[:max_chars]

    # Otherwise, find the first FROM that is at top-level (not inside parens)
    depth = 0
    in_string = False
    str_char = None
    i = 0
    while i < len(s):
        ch = s[i]
        if in_string:
            if ch == str_char:
                in_string = False
            i += 1
            continue
        if ch in ("'", '"'):
            in_string = True
            str_char = ch
            i += 1
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif depth == 0 and s[i:i+4].upper() == 'FROM':
            return s[i:i + max_chars]
        i += 1

    # Fallback: just return the tail of the SQL
    return s[-max_chars:] if len(s) > max_chars else s


def _build_attempt_context(
    attempt_history: list[dict],
    original_user_score: Optional[int] = None,
) -> str:
    """Format per-attempt feedback lines into a compact context block.

    Improving candidates (score > original) are NOT added to the forbidden list —
    instead they are surfaced as 'current best' with their remaining [You] issues
    so the next attempt can build on them rather than abandoning the approach.

    Non-improving candidates (score <= original), near-duplicates, and EXPLAIN
    failures ARE added to the forbidden list.
    """
    if not attempt_history:
        return ""

    lines = ["Previous attempts:"]
    forbidden_strategies: list[str] = []
    best_improving: Optional[dict] = None  # highest-scoring candidate that beat original

    for h in attempt_history:
        score    = h.get("user_score")
        snippet  = h.get("explain_snippet", "")
        strategy = h.get("strategy", "unknown")
        is_dup   = h.get("near_duplicate", False)

        sql_raw  = (h.get("sql_preview") or "").strip()
        sql_prev = _sql_structure_preview(sql_raw) if sql_raw else ""
        sql_hint = f"\n    SQL structure:\n      {sql_prev}" if sql_prev else ""

        improved = (
            score is not None
            and (original_user_score is None or score > original_user_score)
        )

        if is_dup:
            if strategy and strategy != "none" and strategy not in forbidden_strategies:
                forbidden_strategies.append(strategy)
            lines.append(
                f"  [{strategy}] NEAR-DUPLICATE — your SQL was structurally identical "
                f"to a previous candidate. Do NOT generate the same logical rewrite again.{sql_hint}"
            )
        elif score is None:
            if strategy and strategy != "none" and strategy not in forbidden_strategies:
                forbidden_strategies.append(strategy)
            first_line = (snippet.splitlines()[0] if snippet else "").strip()
            lines.append(
                f"  [{strategy}] EXPLAIN syntax error — {first_line}\n"
                "    → Copy ALL complex expressions (INTERVAL, PERIOD, temporal qualifiers, "
                f"custom CASTs) VERBATIM from the original SQL.{sql_hint}"
            )
        elif improved:
            # Keep improving candidates OUT of the forbidden list — guide the model
            # to extend this approach rather than abandon it.
            recs = h.get("remaining_recommendations") or []
            line = f"  [{strategy}] user_score={score}/5 (IMPROVED){sql_hint}"
            if recs:
                line += "\n    Remaining [You] issues: " + " | ".join(recs)
            lines.append(line)
            # Track the best improving candidate for the closing guidance block
            if best_improving is None or score > (best_improving.get("user_score") or 0):
                best_improving = h
        else:
            # Non-improving scored candidate — forbid it
            if strategy and strategy != "none" and strategy not in forbidden_strategies:
                forbidden_strategies.append(strategy)
            recs = h.get("remaining_recommendations") or []
            line = f"  [{strategy}] user_score={score}/5 — {snippet}{sql_hint}"
            if recs:
                line += "\n    Still flagged by EXPLAIN: " + " | ".join(recs)
            lines.append(line)

    # ── Closing guidance ──────────────────────────────────────────────────────
    if best_improving:
        recs = best_improving.get("remaining_recommendations") or []
        best_score = best_improving.get("user_score")
        best_strat = best_improving.get("strategy", "")
        if recs:
            lines.append(
                f"\nCurrent best: {best_score}/5 via `{best_strat}`. "
                f"Your next candidate MUST address these remaining [You] issues to push further: "
                + " | ".join(recs)
            )
        else:
            lines.append(
                f"\nCurrent best: {best_score}/5 via `{best_strat}`. "
                "No remaining [You] issues found — try a different structural improvement."
            )

    if forbidden_strategies:
        forbidden = ", ".join(f"`{s}`" for s in forbidden_strategies)
        lines.append(
            f"\nStrategies that did NOT improve the score: {forbidden}. "
            "Do NOT reuse any of these."
        )

    return "\n".join(lines)


def _extract_you_items(analysis: dict) -> list[str]:
    """Extract [You]-prefixed warnings + recommendations, with the prefix stripped."""
    items: list[str] = []
    for w in analysis.get("warnings", []):
        if w.startswith("[You]"):
            items.append(w[len("[You]"):].lstrip(" -\u2013:"))
    for r in analysis.get("recommendations", []):
        if r.startswith("[You]"):
            items.append(r[len("[You]"):].lstrip(" -\u2013:"))
    return items


def _deduplicate_you_items(items: list[str], threshold: float = 0.50) -> list[str]:
    """Remove near-duplicate [You] items using token-overlap similarity.

    EXPLAIN warnings and recommendations often describe the same issue in
    slightly different wording (e.g. a warning says "correlated subquery
    forces recomputation" and the recommendation says "replace the correlated
    subquery with a CTE").  Keeping both produces duplicate strategies that
    waste LLM calls.

    For each pair, strip SQL code blocks (which add noise), tokenize the
    prose, and compute the **overlap coefficient** (|A∩B| / min(|A|, |B|)).
    This metric works well for short-vs-long pairs (a brief warning vs. a
    detailed recommendation).  When two items exceed *threshold*, the shorter
    one is dropped (the longer one typically carries more context).
    """
    import re

    _STOP = frozenset(
        "a an the is are was were be been being have has had do does did "
        "will would shall should may might can could of in to for on with "
        "by at from as into through this that it and or not no".split()
    )
    _SQL_KW = frozenset(
        "select from where join on group by order having insert update "
        "delete create replace view table as case when then else end".split()
    )
    ignore = _STOP | _SQL_KW

    def _strip_sql(text: str) -> str:
        """Remove fenced SQL blocks and inline SQL-like fragments."""
        text = re.sub(r"```(?:sql)?.*?```", "", text, flags=re.DOTALL)
        text = re.sub(r"`[^`]+`", "", text)
        return text

    def _tokens(text: str) -> set[str]:
        prose = _strip_sql(text)
        words = set(re.findall(r"[a-z_][a-z0-9_]*", prose.lower()))
        return words - ignore

    if len(items) <= 1:
        return items

    token_sets = [_tokens(item) for item in items]
    drop: set[int] = set()

    for i in range(len(items)):
        if i in drop:
            continue
        for j in range(i + 1, len(items)):
            if j in drop:
                continue
            a, b = token_sets[i], token_sets[j]
            if not a or not b:
                continue
            # Overlap coefficient: fraction of the smaller set covered
            overlap = len(a & b) / min(len(a), len(b))
            if overlap >= threshold:
                # Drop the shorter item (keep the more detailed one)
                victim = i if len(items[i]) < len(items[j]) else j
                drop.add(victim)

    return [item for idx, item in enumerate(items) if idx not in drop]


def _strip_sql_comments(sql: str) -> str:
    """Remove block comments (``/* ... */``) and line comments (``-- ...``) from SQL.

    The LLM is instructed to produce comment-free SQL but sometimes ignores
    that rule.  Stripping comments prevents formatting issues (``sqlparse``
    jams ``*/`` onto the same line as the next token) and avoids polluting
    the EXPLAIN analysis with irrelevant text.
    """
    import re
    # Block comments (non-greedy, may span lines)
    result = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    # Line comments (-- to end-of-line)
    result = re.sub(r'--[^\n]*', '', result)
    # Collapse runs of blank lines left behind
    result = re.sub(r'\n{3,}', '\n\n', result)
    return result.strip()


# Words that Teradata treats as reserved and rejects as bare column aliases.
# When the LLM generates e.g. ``AS threshold``, we proactively rename it to
# ``threshold_val`` (and propagate globally) BEFORE the SQL reaches EXPLAIN,
# avoiding a wasted round-trip.
_RESERVED_ALIAS_WORDS: set = {
    'threshold', 'value', 'count', 'date', 'position', 'type', 'name',
    'time', 'period', 'year', 'month', 'day', 'hour', 'minute', 'second',
    'result', 'default', 'key', 'index', 'check', 'grant', 'role',
}


def _fix_reserved_aliases_proactive(sql: str) -> str:
    """Rename Teradata reserved words used as bare identifiers.

    Detects reserved words in three contexts:
    - Column alias:       ``AS threshold``
    - CTE name:           ``WITH threshold AS``
    - Derived-table alias: ``) threshold``  (after closing paren)

    When found, renames every occurrence of that word globally (word-boundary
    safe) to ``<word>_val``.

    Word-boundary matching ensures compound identifiers (e.g. ``Date_transaction``,
    ``CURRENT_DATE``) are not affected.
    """
    import re
    for word in _RESERVED_ALIAS_WORDS:
        # Check all three contexts where the word could be used as an identifier
        is_col_alias = re.search(rf'\bAS\s+{re.escape(word)}\b', sql, re.IGNORECASE)
        is_cte_name = re.search(rf'\bWITH\s+{re.escape(word)}\b', sql, re.IGNORECASE)
        is_dt_alias = re.search(rf'\)\s+{re.escape(word)}\b', sql, re.IGNORECASE)
        if is_col_alias or is_cte_name or is_dt_alias:
            new_name = f"{word}_val"
            sql = re.sub(rf'\b{re.escape(word)}\b', new_name, sql, flags=re.IGNORECASE)
            ctx = "column alias" if is_col_alias else ("CTE name" if is_cte_name else "table alias")
            logger.info("Proactive reserved-word fix (%s): '%s' \u2192 '%s'.", ctx, word, new_name)
    return sql


def _sanitize_candidate_sql(sql: str, label: str) -> str:
    """Apply all deterministic SQL sanitization passes in sequence.

    0. Strip block/line comments (LLM sometimes adds them despite the prompt)
    1. Proactively rename reserved-word aliases (``AS threshold`` \u2192 ``AS threshold_val``)
    2. Backtick identifiers \u2192 double-quote (Teradata-safe)
    3. Missing derived-table aliases injected
    4. Identity wrapper flattened
    5. Scalar subquery \u2192 direct derived-table reference
    """
    result = _strip_sql_comments(sql)
    result = _fix_reserved_aliases_proactive(result)
    result = _sanitize_sql_identifiers(result)
    result = _add_missing_derived_table_aliases(result)
    result = _try_flatten_identity_wrapper(result)
    result = _fix_scalar_subquery_to_direct_ref(result)
    if result != sql:
        logger.info("%s: deterministic sanitization applied.", label)
    return result


def _attempt_explain_with_fix(
    sql: str,
    label: str,
) -> tuple[str, dict]:
    """Analyze EXPLAIN; if syntax error, attempt repair and re-analyze.

    Returns ``(final_sql, analysis)`` — ``analysis["user_score"]`` is ``None``
    when both the original and the repaired SQL failed.
    """
    analysis = _analyze_explain(sql)
    if analysis.get("user_score") is not None:
        return sql, analysis

    # EXPLAIN failed — try deterministic + LLM syntax repair
    error_msg = (analysis.get("explanation") or "").splitlines()[0]
    fixed_sql = None
    try:
        fixed_sql = _fix_syntax_error_sync(
            sql=sql,
            error_message=error_msg,
            llm=_tracked_llm(),
            max_fix_attempts=3,
        )
    except Exception as _fe:
        logger.warning("%s: syntax-fix helper failed: %s", label, _fe)

    if fixed_sql and fixed_sql != sql:
        fix_analysis = _analyze_explain(fixed_sql)
        if fix_analysis.get("user_score") is not None:
            logger.info("%s: syntax fixed, EXPLAIN now valid.", label)
            return fixed_sql, fix_analysis
        logger.info("%s: syntax fix produced another EXPLAIN error.", label)

    return sql, analysis


# ── Technique-variant strategy helpers ──────────────────────────────────────

# Categories of SQL techniques that the EXPLAIN scorer's recommendations may
# suggest.  When a [You] item mentions a technique in a category, ALL
# techniques in that category are offered as variants — this maximises SQL
# diversity without hardwiring a preference for any single pattern.
_TECHNIQUE_CATEGORIES: dict[str, list[tuple[str, str]]] = {
    "precompute": [
        ("cte", "precompute the value as a CTE (WITH clause)"),
        ("crossjoin", "precompute via CROSS JOIN to a single-row scalar subquery"),
        ("scalar", "embed as an inline scalar subquery in the expression"),
    ],
    "window": [
        ("window", "use window/analytical functions (e.g., AVG() OVER()) to avoid self-join"),
    ],
    "singlepass": [
        ("singlepass", "combine into a single aggregation pass with conditional expressions (CASE WHEN)"),
    ],
}

# Regex patterns that map recommendation text → technique category
_TECHNIQUE_DETECTORS: list[tuple[str, str]] = [
    # precompute category
    (r"\bCTE\b|\bWITH\s+clause\b|\bcommon\s+table\s+expression\b", "precompute"),
    (r"\bscalar\s+subquery\b|\binline\s+scalar\b", "precompute"),
    (r"\bCROSS\s+JOIN\b", "precompute"),
    (r"\bprecompute[d]?\b|\bcompute.{0,15}once\b", "precompute"),
    # window category
    (r"\bwindow\s+function\b|\banalytical?\s+function\b", "window"),
    # single-pass category — also detect two-pass / redundant-scan patterns
    (r"\bsingle[\s-]pass\b|\bcombine.{0,20}aggregat|\bone[\s-]pass\b", "singlepass"),
    (r"\btable\s+twice\b|\bredundant\s+(work|scan)\b|\btwo\b.{0,20}\bscan", "singlepass"),
    (r"\brecompute\b.{0,30}\bevery\s+row\b", "singlepass"),
]


def _extract_technique_hints(text: str) -> list[tuple[str, str]]:
    """Extract SQL technique variants from a [You] item's text.

    When the text mentions a technique in a category (e.g. "CTE" triggers
    the *precompute* category), all techniques in that category are returned
    so the strategy generator can offer multiple structural approaches.

    Returns a list of ``(suffix, hint_description)`` tuples.  An empty list
    means no actionable technique was detected — the strategy should be
    generated without a technique constraint.
    """
    import re

    matched_categories: set[str] = set()
    for pattern, category in _TECHNIQUE_DETECTORS:
        if re.search(pattern, text, re.IGNORECASE):
            matched_categories.add(category)

    hints: list[tuple[str, str]] = []
    seen: set[str] = set()
    for cat in matched_categories:
        for suffix, desc in _TECHNIQUE_CATEGORIES.get(cat, []):
            if suffix not in seen:
                hints.append((suffix, desc))
                seen.add(suffix)

    return hints


def _generate_combinatorial_strategies(
    you_items: list[str],
    max_strategies: int,
) -> list["StrategySpec"]:
    """Build strategies by combinatorially addressing [You] items.

    Produces strategies in three tiers:

    - **Tier 1 — technique variants** (singles): for each [You] item, extract
      technique hints from its text (e.g. "CTE", "CROSS JOIN", "scalar
      subquery").  When hints are found, generate one strategy per technique so
      the LLM produces structurally diverse SQL.  When no hints are detected,
      one unconstrained strategy is generated.
    - **Tier 2 — pairwise**: one strategy per pair of [You] items — fix two
      simultaneously.
    - **Tier 3+ — groups**: triplets, quads, … up to ``fix-all``.

    The function stops as soon as *max_strategies* is reached, prioritising
    technique diversity in the singles tier.

    Refinement rounds within each strategy will address any remaining [You]
    items that don't disappear after the targeted fix.
    """
    from itertools import combinations

    strategies: list[StrategySpec] = []
    n = len(you_items)

    # ── Tier 1: Singles with technique variants ─────────────────────────────
    for i, item in enumerate(you_items):
        if len(strategies) >= max_strategies:
            return strategies

        hints = _extract_technique_hints(item)

        if hints:
            for suffix, hint_desc in hints:
                if len(strategies) >= max_strategies:
                    break
                strategies.append(StrategySpec(
                    name=f"fix-you-{i + 1}-{suffix}",
                    description=(
                        f"Address [You] item #{i + 1} — approach: {hint_desc}. "
                        f"Issue: {item}"
                    ),
                    targets=[item],
                ))
        else:
            # No technique hints detected — unconstrained strategy
            strategies.append(StrategySpec(
                name=f"fix-you-{i + 1}",
                description=(
                    f"Address [You] item #{i + 1} in isolation: {item}"
                ),
                targets=[item],
            ))

    # ── Tier 2+: Pairwise and group combinations ───────────────────────────
    for size in range(2, n + 1):
        for combo in combinations(range(n), size):
            if len(strategies) >= max_strategies:
                return strategies

            targets = [you_items[i] for i in combo]
            indices = [str(i + 1) for i in combo]

            if size == n:
                name = "fix-all"
                description = (
                    f"Simultaneously address all {n} [You] items in a single rewrite."
                )
            else:
                name = f"fix-you-{'-and-'.join(indices)}"
                description = (
                    f"Simultaneously address {size} [You] items: "
                    + "; ".join(targets)
                )

            strategies.append(StrategySpec(
                name=name,
                description=description,
                targets=targets,
            ))

    return strategies


def skill_generate_candidates(
    sql_query: str,
    user_request: str,
    original_analysis: dict,
    ddls: dict,
    lineage_info: dict,
    history: Optional[list],
) -> tuple[list[dict], list[dict], Optional["StrategiesOutput"]]:
    """Strategy-based candidate generation with multi-round refinement.

    Pipeline
    --------
    1. **Plan strategies** \u2014 combinatorial: one strategy per [You] item
       (sequential), then one per pair (simultaneous), then triplets, etc.
       No LLM call needed; capped at ``QUERY_OPTIMIZER_MAX_CANDIDATES``.
    2. **Execute each strategy** \u2014 For each strategy sequentially:
       a. Generate one candidate implementing that strategy.
       b. EXPLAIN the candidate \u2192 extract remaining ``[You]`` items.
       c. If ``[You]`` items remain, refine the candidate (up to
          ``QUERY_OPTIMIZER_MAX_REFINE_ROUNDS`` rounds), each round
          targeting the ``[You]`` items from the previous round.
       d. **Early stop** the entire pipeline when a strategy achieves
          user_score = 5/5 (no ``[You]`` items remaining).

    Returns
    -------
    candidate_analyses : list[dict]
        One entry per strategy executed.  Each has ``index``, ``sql``,
        ``strategy``, ``strategy_description``, ``strategy_targets``,
        ``rationale``, ``analysis``, and ``rounds`` (list of per-round dicts).
    steps : list[dict]
        Pipeline step records for ``skill_optimize_query``.
    strategy_plan : StrategiesOutput | None
        The raw plan returned by the strategy-planning LLM call (``None``
        when the query was already optimal and no strategies were generated).
    """
    import tdfs4ds as _tds
    max_strategies    = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATES", 5)
    max_refine_rounds = getattr(_tds, "QUERY_OPTIMIZER_MAX_REFINE_ROUNDS", 3)
    max_failures      = getattr(_tds, "QUERY_OPTIMIZER_MAX_FAILURES", max_strategies)

    steps: list[dict] = []
    candidate_analyses: list[dict] = []

    # ── Phase 1: Combinatorial strategy planning (no LLM call) ───────────────
    you_items = _deduplicate_you_items(_extract_you_items(original_analysis))
    strategies = _generate_combinatorial_strategies(you_items, max_strategies)
    strategy_plan = StrategiesOutput(strategies=strategies) if strategies else None

    steps.append({
        "step": "plan_strategies",
        "count": len(strategies),
        "you_items_count": len(you_items),
        "names": [s.name for s in strategies],
    })

    if not strategies:
        return [], steps, strategy_plan

    # ── Phase 2: Execute each strategy with refinement rounds ────────────────
    failure_count = 0
    global_early_stop = False

    for strat_idx, strategy in enumerate(strategies):
        if global_early_stop:
            break

        strat_label = f"Strategy {strat_idx} [{strategy.name}]"
        rounds: list[dict] = []

        # ── Initial candidate generation ─────────────────────────────────────
        cand = None
        try:
            cand = _generate_for_strategy_sync(
                sql_query, strategy, user_request,
                original_analysis, ddls, lineage_info,
            )
        except Exception as exc:
            logger.warning(
                "%s: generation failed (non-fatal): %s",
                strat_label, str(exc).splitlines()[0],
            )

        if cand is None:
            failure_count += 1
            steps.append({
                "step": "strategy_generation_failure",
                "strategy_index": strat_idx,
                "strategy": strategy.name,
                "failure_count": failure_count,
            })
            if failure_count >= max_failures:
                steps.append({"step": "failure_cap_reached", "failure_count": failure_count})
                break
            continue

        # ── Sanitize + near-duplicate check ──────────────────────────────────
        current_sql = _sanitize_candidate_sql(cand.sql, f"{strat_label} R0")
        already_seen = [sql_query] + [c["sql"] for c in candidate_analyses]
        if any(_is_near_duplicate(current_sql, ref) for ref in already_seen):
            logger.info("%s: initial candidate is a near-duplicate \u2014 skipped.", strat_label)
            failure_count += 1
            steps.append({
                "step": "strategy_near_duplicate",
                "strategy_index": strat_idx,
                "strategy": strategy.name,
            })
            if failure_count >= max_failures:
                steps.append({"step": "failure_cap_reached", "failure_count": failure_count})
                break
            continue

        # ── EXPLAIN with syntax-error recovery ───────────────────────────────
        current_sql, analysis = _attempt_explain_with_fix(current_sql, f"{strat_label} R0")
        user_score = analysis.get("user_score")
        remaining = _extract_you_items(analysis) if user_score is not None else None

        rounds.append({
            "round": 0,
            "sql": current_sql,
            "analysis": analysis,
            "user_score": user_score,
            "n_steps": analysis.get("n_steps"),
            "n_spool_objects": analysis.get("n_spool_objects"),
            "remaining_you_items": remaining or [],
        })
        steps.append({
            "step": "strategy_round",
            "strategy_index": strat_idx,
            "strategy": strategy.name,
            "round": 0,
            "user_score": user_score,
            "remaining_count": len(remaining) if remaining else None,
        })

        if user_score is None:
            # Initial EXPLAIN failed even after repair \u2014 skip this strategy
            failure_count += 1
            candidate_analyses.append({
                "index":                strat_idx,
                "sql":                  current_sql,
                "strategy":             strategy.name,
                "strategy_description": strategy.description,
                "strategy_targets":     strategy.targets,
                "rationale":            cand.rationale,
                "business_assumptions": cand.business_assumptions,
                "analysis":             analysis,
                "rounds":               rounds,
            })
            if failure_count >= max_failures:
                steps.append({"step": "failure_cap_reached", "failure_count": failure_count})
                break
            continue

        # ── Early stop: perfect score on initial candidate ───────────────────
        if user_score == 5 or not remaining:
            steps.append({
                "step": "early_stop", "reason": "perfect_score",
                "strategy_index": strat_idx, "strategy": strategy.name,
                "round": 0, "user_score": user_score,
            })
            candidate_analyses.append({
                "index":                strat_idx,
                "sql":                  current_sql,
                "strategy":             strategy.name,
                "strategy_description": strategy.description,
                "strategy_targets":     strategy.targets,
                "rationale":            cand.rationale,
                "business_assumptions": cand.business_assumptions,
                "analysis":             analysis,
                "rounds":               rounds,
            })
            global_early_stop = True
            continue

        # ── Baseline guard: skip refinement when initial score is too low ────
        # Allow refinement when the candidate is within 1 point of the baseline
        # (refinement often recovers 1 point).  Hard-skip only when the gap is
        # ≥ 2 points — those candidates are unlikely to recover.
        orig_u = original_analysis.get("user_score")
        if orig_u is not None and user_score < orig_u - 1:
            logger.info(
                "%s: initial score %s/5 << baseline %s/5 — skipping refinement.",
                strat_label, user_score, orig_u,
            )
            rounds[-1]["label"] = f"Initial (below baseline {orig_u}/5 — skipped)"
            candidate_analyses.append({
                "index":                strat_idx,
                "sql":                  current_sql,
                "strategy":             strategy.name,
                "strategy_description": strategy.description,
                "strategy_targets":     strategy.targets,
                "rationale":            cand.rationale,
                "business_assumptions": cand.business_assumptions,
                "analysis":             analysis,
                "rounds":               rounds,
            })
            steps.append({
                "step": "baseline_skip",
                "strategy_index": strat_idx,
                "strategy": strategy.name,
                "user_score": user_score,
                "baseline_score": orig_u,
            })
            continue

        # ── Refinement rounds ────────────────────────────────────────────────
        for rnd in range(1, max_refine_rounds + 1):
            refined = None
            try:
                refined = _refine_candidate_sync(
                    current_sql, remaining, strategy.name,
                    user_request, ddls, lineage_info=lineage_info,
                )
            except Exception as exc:
                logger.warning(
                    "%s R%d: refinement failed (non-fatal): %s",
                    strat_label, rnd, str(exc).splitlines()[0],
                )

            if refined is None:
                steps.append({
                    "step": "refinement_no_change",
                    "strategy_index": strat_idx,
                    "strategy": strategy.name,
                    "round": rnd,
                })
                break

            refined_sql = _sanitize_candidate_sql(refined.sql, f"{strat_label} R{rnd}")
            # If refinement produced a near-duplicate of current, stop refining
            if _is_near_duplicate(refined_sql, current_sql):
                logger.info("%s R%d: refinement produced near-duplicate \u2014 stopping.", strat_label, rnd)
                steps.append({
                    "step": "refinement_near_duplicate",
                    "strategy_index": strat_idx,
                    "strategy": strategy.name,
                    "round": rnd,
                })
                break

            refined_sql, ref_analysis = _attempt_explain_with_fix(
                refined_sql, f"{strat_label} R{rnd}",
            )
            ref_score = ref_analysis.get("user_score")
            ref_remaining = _extract_you_items(ref_analysis) if ref_score is not None else None

            rounds.append({
                "round": rnd,
                "sql": refined_sql,
                "analysis": ref_analysis,
                "user_score": ref_score,
                "n_steps": ref_analysis.get("n_steps"),
                "n_spool_objects": ref_analysis.get("n_spool_objects"),
                "remaining_you_items": ref_remaining or [],
            })
            steps.append({
                "step": "strategy_round",
                "strategy_index": strat_idx,
                "strategy": strategy.name,
                "round": rnd,
                "user_score": ref_score,
                "remaining_count": len(ref_remaining) if ref_remaining else None,
            })

            if ref_score is None:
                # Refinement produced invalid SQL — revert to previous round
                logger.info("%s R%d: EXPLAIN failed, reverting to R%d.", strat_label, rnd, rnd - 1)
                break

            # Reject refinement if it regresses below the current best
            if user_score is not None and ref_score < user_score:
                logger.info(
                    "%s R%d: score regressed (%s/5 → %s/5), keeping R%d.",
                    strat_label, rnd, user_score, ref_score, rnd - 1,
                )
                break

            # When scores are equal, only accept if steps/spools did not increase.
            # This ensures we retain the structurally lightest SQL at each score tier.
            if ref_score == user_score:
                cur_cost = (
                    analysis.get("n_steps") or float('inf'),
                    analysis.get("n_spool_objects") or float('inf'),
                )
                ref_cost = (
                    ref_analysis.get("n_steps") or float('inf'),
                    ref_analysis.get("n_spool_objects") or float('inf'),
                )
                if ref_cost > cur_cost:
                    logger.info(
                        "%s R%d: same score %s/5 but steps/spools regressed "
                        "(%s/%s → %s/%s), keeping R%d.",
                        strat_label, rnd, ref_score,
                        analysis.get("n_steps"), analysis.get("n_spool_objects"),
                        ref_analysis.get("n_steps"), ref_analysis.get("n_spool_objects"),
                        rnd - 1,
                    )
                    break

            # Accept the refinement as the new current SQL
            current_sql = refined_sql
            analysis = ref_analysis
            user_score = ref_score
            remaining = ref_remaining

            # ── Early stop: perfect score after refinement ───────────────────
            if user_score == 5 or not remaining:
                steps.append({
                    "step": "early_stop", "reason": "perfect_score",
                    "strategy_index": strat_idx, "strategy": strategy.name,
                    "round": rnd, "user_score": user_score,
                })
                global_early_stop = True
                break

        # ── Record final result for this strategy ────────────────────────────
        candidate_analyses.append({
            "index":                strat_idx,
            "sql":                  current_sql,
            "strategy":             strategy.name,
            "strategy_description": strategy.description,
            "strategy_targets":     strategy.targets,
            "rationale":            cand.rationale,
            "business_assumptions": cand.business_assumptions,
            "analysis":             analysis,
            "rounds":               rounds,
        })

    return candidate_analyses, steps, strategy_plan


# ═══════════════════════════════════════════════════════════════════════════════
# Simplification skill  (standalone, also used as Step 0.5 in the optimizer)
# ═══════════════════════════════════════════════════════════════════════════════

def skill_simplify_query(
    sql_query: Optional[str] = None,
    process_id: Optional[str] = None,
    max_fix_attempts: int = 3,
) -> dict:
    """Simplify a Teradata SQL query by removing unnecessary nesting.

    Applies deterministic passes (comment stripping, identity-wrapper
    flattening, reserved-word alias fixes) followed by an LLM pass that
    merges derived-table layers into CTEs and inlines date arithmetic.

    The simplified SQL is validated with EXPLAIN; if the score regresses
    below the original, the deterministic-only version is returned.

    Can be used standalone or as a pre-step in ``skill_optimize_query``.

    Args:
        sql_query:  Raw Teradata SQL to simplify.
        process_id: UUID of a registered tdfs4ds process (fetches SQL from catalog).
        max_fix_attempts: Max syntax-error repair retries for the LLM output.

    Returns:
        dict with keys ``simplified_sql``, ``original_sql``, ``simplified``,
        ``original_score``, ``simplified_score``.
    """
    if not sql_query and not process_id:
        raise ValueError("Provide either sql_query or process_id.")

    # ── Token tracking (nested-aware: reuse parent tracker if active) ────
    global _token_tracker
    _owns_tracker = _token_tracker is None
    if _owns_tracker:
        _token_tracker = TokenUsageTracker()

    def _finalize(result: dict) -> dict:
        global _token_tracker
        if _owns_tracker and _token_tracker:
            result["token_usage"] = _token_tracker.snapshot()
            _token_tracker = None
        return result

    # ── Resolve SQL from process catalog if needed ───────────────────────
    if process_id and not sql_query:
        try:
            from tdfs4ds.process_store.process_store_catalog_management import get_process_info
            pinfo = get_process_info(process_id)
            if pinfo and pinfo.get("PROCESS_SQL"):
                sql_query = pinfo["PROCESS_SQL"]
        except Exception as exc:
            logger.warning("Could not retrieve process SQL (non-fatal): %s", str(exc).splitlines()[0])

    if not sql_query:
        raise ValueError(
            f"process_id={process_id!r} found but PROCESS_SQL is empty — "
            "supply sql_query explicitly."
        )

    original_sql = sql_query

    # ── Phase A: Deterministic passes ────────────────────────────────────
    sanitized = _sanitize_candidate_sql(sql_query, "simplify-det")

    # ── Phase B: Baseline EXPLAIN ────────────────────────────────────────
    baseline_sql, baseline_analysis = _attempt_explain_with_fix(sanitized, "simplify-baseline")
    original_score = baseline_analysis.get("user_score")

    if original_score is None:
        # Cannot validate — return deterministic-only version
        logger.warning("Simplification: baseline EXPLAIN failed, returning deterministic-only version.")
        return _finalize({
            "simplified_sql": baseline_sql,
            "original_sql": original_sql,
            "simplified": baseline_sql != original_sql,
            "original_score": None,
            "simplified_score": None,
            "_analysis": baseline_analysis,
            "_baseline_analysis": baseline_analysis,
        })

    # ── Phase C: LLM structural simplification ───────────────────────────
    ddls: dict[str, str] = {}
    for ref in _extract_table_refs(baseline_sql):
        db, tbl = ref["database"], ref["name"]
        ddls[f"{db}.{tbl}"] = _fetch_ddl(db, tbl)

    llm_result = None
    try:
        llm_result = _simplify_sql_sync(baseline_sql, ddls)
    except Exception as exc:
        logger.warning("Simplification: LLM call failed (non-fatal): %s", str(exc).splitlines()[0])

    if llm_result is None or _is_near_duplicate(llm_result.sql, baseline_sql):
        # LLM couldn't simplify — return deterministic-only version
        logger.info("Simplification: LLM produced no change or near-duplicate.")
        return _finalize({
            "simplified_sql": baseline_sql,
            "original_sql": original_sql,
            "simplified": baseline_sql != original_sql,
            "original_score": original_score,
            "simplified_score": original_score,
            "_analysis": baseline_analysis,
            "_baseline_analysis": baseline_analysis,
        })

    # ── Phase D: Validate LLM output with syntax-error retry loop ────────
    simplified_sql = _sanitize_candidate_sql(llm_result.sql, "simplify-llm")

    for attempt in range(max_fix_attempts):
        candidate_sql, candidate_analysis = _attempt_explain_with_fix(
            simplified_sql, f"simplify-validate-{attempt}",
        )
        candidate_score = candidate_analysis.get("user_score")

        if candidate_score is not None:
            # EXPLAIN succeeded — check score
            if candidate_score >= original_score:
                logger.info(
                    "Simplification accepted: score %s/5 → %s/5, more compact SQL.",
                    original_score, candidate_score,
                )
                return _finalize({
                    "simplified_sql": _format_sql(candidate_sql),
                    "original_sql": original_sql,
                    "simplified": True,
                    "original_score": original_score,
                    "simplified_score": candidate_score,
                    "_analysis": candidate_analysis,
                    "_baseline_analysis": baseline_analysis,
                })
            else:
                logger.info(
                    "Simplification rejected: score regressed %s/5 → %s/5.",
                    original_score, candidate_score,
                )
                break  # score regression — stop trying

        # EXPLAIN failed — try to fix syntax
        error_msg = (candidate_analysis.get("explanation") or "").splitlines()[0]
        logger.info("Simplification attempt %d EXPLAIN failed (%s), retrying...", attempt, error_msg[:80])

        if attempt < max_fix_attempts - 1:
            try:
                from langchain_core.messages import SystemMessage as _Sys, HumanMessage as _Hum

                import tdfs4ds as _tds
                _max_tok = getattr(_tds, "QUERY_OPTIMIZER_MAX_CANDIDATE_TOKENS", None)
                _llm = _tracked_llm(max_tokens=_max_tok).with_structured_output(CandidateRewrite)

                _sys = (
                    "You are a Teradata SQL expert. Output ONLY a JSON object \u2014 no preamble.\n"
                    "The SQL below was a simplification attempt that failed with a syntax error. "
                    "Fix ONLY the syntax error while keeping the simplified structure. "
                    "Do NOT revert to the original nested form.\n\n"
                    f"{_teradata_sql_guide()}"
                )
                _usr = (
                    f"Failed SQL:\n```sql\n{candidate_sql}\n```\n\n"
                    f"Error: {error_msg}\n\n"
                    "Set strategy to 'simplification'. Leave business_assumptions empty."
                )
                fixed = _llm.invoke([_Sys(content=_sys), _Hum(content=_usr)])
                if fixed and fixed.sql:
                    simplified_sql = _sanitize_candidate_sql(fixed.sql, f"simplify-fix-{attempt + 1}")
                    continue
            except Exception as _fe:
                logger.warning("Simplification fix attempt failed: %s", _fe)

    # All attempts failed or score regressed — return deterministic-only version
    logger.info("Simplification: LLM pass failed, returning deterministic-only version.")
    return _finalize({
        "simplified_sql": _format_sql(baseline_sql),
        "original_sql": original_sql,
        "simplified": baseline_sql != original_sql,
        "original_score": original_score,
        "simplified_score": original_score,
        "_analysis": baseline_analysis,
        "_baseline_analysis": baseline_analysis,
    })


def simplify_query(
    sql_query: Optional[str] = None,
    process_id: Optional[str] = None,
) -> dict:
    """Synchronous entry point for SQL simplification.

    Convenience wrapper around ``skill_simplify_query`` for scripts and
    notebooks.  No LangGraph — single-shot operation.

    Args:
        sql_query:  Raw Teradata SQL to simplify.
        process_id: UUID of a registered tdfs4ds process.

    Returns:
        dict with keys ``simplified_sql``, ``original_sql``, ``simplified``,
        ``original_score``, ``simplified_score``.
    """
    return skill_simplify_query(sql_query=sql_query, process_id=process_id)


# ═══════════════════════════════════════════════════════════════════════════════
# Optimization skill  (self-contained, synchronous — mirrors consumer agent skills)
# ═══════════════════════════════════════════════════════════════════════════════

def skill_optimize_query(
    sql_query: Optional[str] = None,
    process_id: Optional[str] = None,
    user_request: str = "Optimize this Teradata SQL query for performance.",
    history: Optional[list] = None,
) -> dict:
    """Analyse and rewrite a Teradata SQL query for better performance.

    Either *sql_query* or *process_id* must be provided.  When *process_id* is
    given, the SQL and any existing EXPLAIN documentation are pulled from the
    tdfs4ds process catalog, avoiding a redundant LLM call.

    Args:
        sql_query:    Raw Teradata SELECT statement to optimise.
        process_id:   UUID of a registered tdfs4ds process.  When supplied, the
                      SQL view DDL and stored EXPLAIN analysis are fetched from the
                      catalog.  If ``sql_query`` is also given it takes precedence.
        user_request: Optional context sentence describing the optimisation goal
                      (surfaced in the report and fed to the LLM).
        history:      Prior LangGraph messages for multi-turn context.

    Returns:
        dict with keys:
          ``answer``                    — Structured Markdown optimisation report.
          ``best_sql``                  — Recommended SQL (original if already optimal).
          ``steps``                     — List of ``{step, ...}`` dicts for each pipeline step.
          ``filtermanager_applicable``  — True if a FilterManager loop was recommended.
          ``original_analysis``         — Structured EXPLAIN analysis of the original query.
          ``candidates``                — List of candidate dicts (sql, strategy, analysis).
          ``comparison``                — Plan comparison result.
          ``process_info``              — Process catalog info dict (or None).

    Raises:
        ValueError: If neither *sql_query* nor *process_id* is provided.
    """
    if not sql_query and not process_id:
        raise ValueError("Provide either sql_query or process_id.")

    # ── Token tracking ──────────────────────────────────────────────────────
    global _token_tracker
    _owns_tracker = _token_tracker is None
    if _owns_tracker:
        _token_tracker = TokenUsageTracker()

    history = history or []
    steps: list[dict] = []

    # ── Step 0: Gather process context ───────────────────────────────────────
    process_info: Optional[dict] = None
    stored_analysis: Optional[dict] = None

    if process_id:
        try:
            from tdfs4ds.process_store.process_store_catalog_management import get_process_info
            process_info = get_process_info(process_id)
            if process_info:
                # Use stored SQL if no explicit sql_query was provided
                if not sql_query and process_info.get("PROCESS_SQL"):
                    sql_query = process_info["PROCESS_SQL"]
                # Reuse stored EXPLAIN analysis when available
                if process_info.get("EXPLAIN_ANALYSIS"):
                    stored_analysis = {
                        "explanation":    process_info.get("EXPLAIN_ANALYSIS", ""),
                        "user_score":     process_info.get("USER_SCORE"),
                        "global_score":   process_info.get("OPTIMIZATION_SCORE"),
                        "warnings":       process_info.get("EXPLAIN_WARNINGS", []) or [],
                        "recommendations": process_info.get("EXPLAIN_RECOMMENDATIONS", []) or [],
                        "n_steps":        process_info.get("EXPLAIN_N_STEPS"),
                        "n_spool_objects": process_info.get("EXPLAIN_N_SPOOL_OBJECTS"),
                    }
                steps.append({
                    "step": "process_info",
                    "view_name": process_info.get("VIEW_NAME"),
                    "entity_columns": process_info.get("ENTITY_COLUMNS", []),
                    "feature_columns": process_info.get("FEATURE_COLUMNS", []),
                    "stored_explain_available": stored_analysis is not None,
                })
        except Exception as exc:
            logger.warning("Could not retrieve process info (non-fatal): %s", str(exc).splitlines()[0])

    if not sql_query:
        raise ValueError(
            f"process_id={process_id!r} found but PROCESS_SQL is empty — "
            "supply sql_query explicitly."
        )

    # ── Step 0.5: Simplify SQL before optimization ──────────────────────────
    original_raw_sql = sql_query
    simplify_result: Optional[dict] = None
    try:
        simplify_result = skill_simplify_query(sql_query=sql_query)
        if simplify_result.get("simplified"):
            sql_query = simplify_result["simplified_sql"]
            logger.info(
                "Simplification applied: score %s/5 → %s/5.",
                simplify_result.get("original_score"),
                simplify_result.get("simplified_score"),
            )
        steps.append({
            "step": "simplification",
            "simplified": simplify_result.get("simplified", False),
            "original_score": simplify_result.get("original_score"),
            "simplified_score": simplify_result.get("simplified_score"),
        })
    except Exception as exc:
        logger.warning("Simplification failed (non-fatal): %s", str(exc).splitlines()[0])
        steps.append({"step": "simplification", "simplified": False, "error": str(exc).splitlines()[0]})

    # ── Step 1: Analyze original EXPLAIN ─────────────────────────────────────
    # Priority: simplification analysis > stored analysis > live EXPLAIN.
    # When simplification changed the SQL, the stored analysis is stale (it was
    # for the pre-simplification SQL).  The simplification's analysis matches
    # the actual SQL that strategies will optimize.
    _simplify_analysis = (
        simplify_result.get("_analysis")
        if simplify_result and simplify_result.get("simplified")
        else None
    )
    if _simplify_analysis is not None:
        # Simplification changed the SQL — use its fresh analysis
        original_analysis = _simplify_analysis
        steps.append({
            "step": "explain_analysis",
            "source": "simplification",
            "user_score": original_analysis.get("user_score"),
            "global_score": original_analysis.get("global_score"),
        })
    elif stored_analysis is not None:
        # No simplification change — stored analysis is still valid
        original_analysis = stored_analysis
        steps.append({
            "step": "explain_analysis",
            "source": "catalog",
            "user_score": original_analysis.get("user_score"),
            "global_score": original_analysis.get("global_score"),
        })
    else:
        original_analysis = _analyze_explain(sql_query)
        steps.append({
            "step": "explain_analysis",
            "source": "live",
            "user_score": original_analysis.get("user_score"),
            "global_score": original_analysis.get("global_score"),
        })

    # ── Step 2: Lineage → PI + partition columns per node ────────────────────
    lineage_info = _get_lineage_info(sql_query)

    # ── Step 3: Fetch DDL for every table / view referenced in the SQL ───────
    ddls: dict[str, str] = {}
    for ref in _extract_table_refs(sql_query):
        db, tbl = ref["database"], ref["name"]
        ddl = _fetch_ddl(db, tbl)
        ddls[f"{db}.{tbl}"] = ddl
        steps.append({"step": "fetch_ddl", "object": f"{db}.{tbl}", "ddl_preview": ddl[:200]})

    # ── Steps 4+5: Plan strategies → generate + refine candidates ─────────────
    candidate_analyses, candidate_steps, strategy_plan = skill_generate_candidates(
        sql_query, user_request, original_analysis, ddls, lineage_info, history
    )
    steps.extend(candidate_steps)

    # ── Step 6: LLM selects best plan ────────────────────────────────────────
    if candidate_analyses:
        try:
            comparison = _compare_plans_sync(original_analysis, candidate_analyses)
        except Exception as exc:
            logger.warning("Plan comparison failed (non-fatal): %s", str(exc).splitlines()[0])
            comparison = PlanComparison(
                best_index=-1,
                reasoning=f"Comparison failed: {exc}",
                business_logic_preserved=True,
                business_logic_notes="Falling back to original SQL.",
            )
    else:
        comparison = PlanComparison(
            best_index=-1,
            reasoning="No rewrite candidates generated — original retained.",
            business_logic_preserved=True,
            business_logic_notes="Original SQL unchanged.",
        )

    # Safeguard: override the LLM's choice when the selected candidate does not
    # beat the original user score.  The LLM sometimes picks a regressing candidate;
    # a deterministic check here prevents surfacing worse SQL as "the best".
    # Also reverts when the selected candidate's EXPLAIN failed (sel_u is None)
    # and the original was valid — a broken rewrite must never replace working SQL.
    # Equal scores are ACCEPTED — the comparison LLM already judged the candidate
    # to be structurally better (fewer nesting levels, cleaner access paths, etc.).
    # If the LLM made a bad choice but a better candidate exists, rescue it by
    # deterministically selecting the highest-scoring candidate that beats or equals the original.
    orig_u = original_analysis.get("user_score")
    if 0 <= comparison.best_index < len(candidate_analyses):
        sel_u = candidate_analyses[comparison.best_index]["analysis"].get("user_score")
        # Revert when: selected EXPLAIN failed, OR original is valid and selected strictly regresses
        should_revert = (sel_u is None and orig_u is not None) or (
            orig_u is not None and sel_u is not None and sel_u < orig_u
        )
        if should_revert:
            # Before giving up, scan all candidates for one that beats or equals the original
            best_rescue_idx = -1
            best_rescue_score = (orig_u - 1) if orig_u is not None else -1
            for i, ca in enumerate(candidate_analyses):
                ca_u = ca["analysis"].get("user_score")
                if ca_u is not None and (orig_u is None or ca_u > best_rescue_score):
                    best_rescue_score = ca_u
                    best_rescue_idx = i

            if best_rescue_idx >= 0:
                logger.info(
                    "Safeguard: LLM picked candidate %d (score %s) but candidate %d scores "
                    "%s/5 — overriding with the better candidate.",
                    comparison.best_index, sel_u, best_rescue_idx, best_rescue_score,
                )
                comparison = PlanComparison(
                    best_index=best_rescue_idx,
                    reasoning=(
                        f"LLM selected a sub-optimal candidate; deterministic safeguard "
                        f"overrides with candidate {best_rescue_idx} "
                        f"(user_score={best_rescue_score}/5 > original={orig_u}/5)."
                    ),
                    business_logic_preserved=True,
                    business_logic_notes="Best available candidate selected by score.",
                )
            else:
                reason = (
                    f"Selected candidate EXPLAIN failed — original ({orig_u}/5) retained."
                    if sel_u is None
                    else f"All candidates scored ≤ original ({orig_u}/5). Original SQL retained — no regression introduced."
                )
                comparison = PlanComparison(
                    best_index=-1,
                    reasoning=reason,
                    business_logic_preserved=True,
                    business_logic_notes="Original SQL unchanged.",
                )

    # ── Deterministic tiebreaker: among candidates with equal user_score,
    #    prefer the one with fewest EXPLAIN steps + Spool objects. ─────────────
    if 0 <= comparison.best_index < len(candidate_analyses):
        sel_a = candidate_analyses[comparison.best_index]["analysis"]
        sel_u = sel_a.get("user_score")
        sel_steps = sel_a.get("n_steps") or float('inf')
        sel_spools = sel_a.get("n_spool_objects") or float('inf')
        sel_cost = (sel_steps, sel_spools)

        better_idx = comparison.best_index
        for i, ca in enumerate(candidate_analyses):
            if i == comparison.best_index:
                continue
            a = ca["analysis"]
            ca_u = a.get("user_score")
            if ca_u is None or ca_u != sel_u:
                continue  # only tiebreak among equal user_score
            ca_steps = a.get("n_steps") or float('inf')
            ca_spools = a.get("n_spool_objects") or float('inf')
            ca_cost = (ca_steps, ca_spools)
            if ca_cost < sel_cost:
                sel_cost = ca_cost
                better_idx = i

        if better_idx != comparison.best_index:
            old_a = candidate_analyses[comparison.best_index]["analysis"]
            new_a = candidate_analyses[better_idx]["analysis"]
            logger.info(
                "Tiebreaker: candidate %d and %d both score %s/5; "
                "candidate %d has fewer steps/spools (%s/%s vs %s/%s) — overriding.",
                comparison.best_index, better_idx, sel_u,
                better_idx,
                new_a.get("n_steps"), new_a.get("n_spool_objects"),
                old_a.get("n_steps"), old_a.get("n_spool_objects"),
            )
            comparison = PlanComparison(
                best_index=better_idx,
                reasoning=(
                    f"Deterministic tiebreaker: candidate {better_idx} has the same "
                    f"user_score ({sel_u}/5) but fewer EXPLAIN steps/Spool objects "
                    f"({new_a.get('n_steps')}/{new_a.get('n_spool_objects')} vs "
                    f"{old_a.get('n_steps')}/{old_a.get('n_spool_objects')})."
                ),
                business_logic_preserved=comparison.business_logic_preserved,
                business_logic_notes=comparison.business_logic_notes,
            )

    best_sql = (
        candidate_analyses[comparison.best_index]["sql"]
        if 0 <= comparison.best_index < len(candidate_analyses)
        else sql_query
    )

    # ── Score delta (before vs. after) ────────────────────────────────────────
    score_delta = _compute_score_delta(original_analysis, candidate_analyses, comparison)

    # ── Step 7: FilterManager check ───────────────────────────────────────────
    fm = _check_filtermanager(sql_query, lineage_info)

    # Format SQL outputs before building the report
    sql_query = _format_sql(sql_query)
    best_sql = _format_sql(best_sql)
    for ca in candidate_analyses:
        ca["sql"] = _format_sql(ca["sql"])

    # ── Token usage snapshot ────────────────────────────────────────────────
    token_usage = _token_tracker.snapshot() if _token_tracker else {}
    if _owns_tracker:
        _token_tracker = None

    # ── Step 8: Final Markdown report ─────────────────────────────────────────
    try:
        answer = _generate_report_sync(
            sql_query, user_request, original_analysis,
            lineage_info, candidate_analyses, comparison, best_sql, fm, process_info,
            score_delta=score_delta,
            strategy_plan=strategy_plan,
            simplify_result=simplify_result,
            original_raw_sql=original_raw_sql,
            token_usage=token_usage,
        )
    except Exception as exc:
        logger.warning("Report generation failed: %s", str(exc).splitlines()[0])
        answer = f"Optimization pipeline completed.\n\nBest SQL:\n```sql\n{best_sql}\n```"

    answer = _fix_answer_fences(answer)

    return {
        "answer":                  answer,
        "best_sql":                best_sql,
        "steps":                   steps,
        "filtermanager_applicable": fm["applicable"],
        "original_analysis":       original_analysis,
        "candidates":              candidate_analyses,
        "comparison":              comparison.model_dump(),
        "process_info":            process_info,
        "score_delta":             score_delta,
        "token_usage":             token_usage,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LangGraph node and graph  (thin multi-turn wrapper around skill_optimize_query)
# ═══════════════════════════════════════════════════════════════════════════════

async def _node_optimize(state: OptimizerState) -> dict:
    messages: list = state.get("messages", [])
    process_id: Optional[str] = state.get("process_id")

    last_human = next(
        (m for m in reversed(messages) if getattr(m, "type", None) in ("human", "user")),
        None,
    )
    if not last_human:
        return {
            "messages": [AIMessage(content="No message received.")],
            "answer": "No message received.", "steps": [],
            "best_sql": None, "filtermanager_applicable": False,
            "score_delta": None,
        }

    user_request = str(getattr(last_human, "content", "")).strip()
    history = messages[:-1]

    # Determine SQL: from current message, from history, or from process_id
    if _looks_like_sql(user_request):
        sql_query = user_request
        pid = process_id
    else:
        sql_query = _last_sql_from_history(history)
        pid = process_id
        if not sql_query and not pid:
            # Pure follow-up question with no SQL in history — answer directly
            from langchain_core.messages import SystemMessage
            llm = _tracked_llm()
            resp = llm.invoke([
                SystemMessage(content="You are a Teradata SQL optimisation expert."),
                HumanMessage(content=(
                    f"Conversation so far:\n{_format_history(history)}\n\nUser: {user_request}"
                )),
            ])
            answer = getattr(resp, "content", str(resp))
            return {
                "messages": [AIMessage(content=answer)], "answer": answer,
                "steps": [], "best_sql": None, "filtermanager_applicable": False,
                "score_delta": None,
            }

    # Run the skill in a thread pool to avoid blocking the event loop
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        lambda: skill_optimize_query(
            sql_query=sql_query or None,
            process_id=pid,
            user_request=user_request,
            history=history,
        ),
    )

    return {
        "messages": [AIMessage(content=result["answer"])],
        "answer":                  result["answer"],
        "best_sql":                result["best_sql"],
        "steps":                   result["steps"],
        "filtermanager_applicable": result["filtermanager_applicable"],
        "original_analysis":       result.get("original_analysis"),
        "candidates":              result.get("candidates"),
        "comparison":              result.get("comparison"),
        "process_info":            result.get("process_info"),
        "score_delta":             result.get("score_delta"),
    }


def _get_optimizer_graph():
    global _optimizer_graph
    if _optimizer_graph is None:
        builder = StateGraph(OptimizerState)
        builder.add_node("optimize", _node_optimize)
        builder.set_entry_point("optimize")
        builder.add_edge("optimize", END)
        _optimizer_graph = builder.compile(checkpointer=_get_checkpointer())
    return _optimizer_graph


# ═══════════════════════════════════════════════════════════════════════════════
# Core async runner
# ═══════════════════════════════════════════════════════════════════════════════

async def _run_optimizer(
    sql_query: Optional[str],
    thread_id: str,
    process_id: Optional[str] = None,
) -> dict:
    graph = _get_optimizer_graph()
    config = {"configurable": {"thread_id": thread_id}}
    input_content = sql_query or f"Optimize process {process_id}"
    raw = await graph.ainvoke(
        {
            "messages": [HumanMessage(content=input_content)],
            "process_id": process_id,
        },
        config=config,
    )
    return {
        "answer":                  raw.get("answer", ""),
        "best_sql":                raw.get("best_sql") or sql_query or "",
        "steps":                   raw.get("steps", []),
        "filtermanager_applicable": raw.get("filtermanager_applicable", False),
        "original_analysis":       raw.get("original_analysis"),
        "candidates":              raw.get("candidates"),
        "comparison":              raw.get("comparison"),
        "process_info":            raw.get("process_info"),
        "score_delta":             raw.get("score_delta"),
        "messages":                raw.get("messages", []),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Notebook display helper
# ═══════════════════════════════════════════════════════════════════════════════

def _render_score_delta_html(score_delta: dict) -> str:
    """Build an HTML score-comparison widget from a ``score_delta`` dict."""

    def _fmt(v: Optional[float]) -> str:
        return f"{v}/5" if v is not None else "N/A"

    def _delta_cell(d: Optional[float]) -> str:
        if d is None:
            return '<td style="color:#888;text-align:center;">—</td>'
        if d > 0:
            return f'<td style="color:#1e8449;font-weight:bold;text-align:center;">+{d}</td>'
        if d < 0:
            return f'<td style="color:#c0392b;font-weight:bold;text-align:center;">{d}</td>'
        return '<td style="color:#888;text-align:center;">—</td>'

    u_before  = _fmt(score_delta.get("original_user_score"))
    u_after   = _fmt(score_delta.get("best_user_score"))
    g_before  = _fmt(score_delta.get("original_global_score"))
    g_after   = _fmt(score_delta.get("best_global_score"))
    u_delta   = score_delta.get("user_score_delta")
    g_delta   = score_delta.get("global_score_delta")

    strategy  = score_delta.get("best_strategy") or "—"
    optimized = score_delta.get("optimized", False)
    bl_ok     = score_delta.get("business_logic_preserved", True)

    status_color  = "#1e8449" if optimized else "#888"
    status_label  = "Optimized" if optimized else "No improvement found"
    bl_label      = "preserved" if bl_ok else "NOT preserved"
    bl_color      = "#1e8449" if bl_ok else "#c0392b"

    _TH = (
        "background:#1f618d;color:#fff;padding:8px 14px;"
        "text-align:left;font-size:0.9em;white-space:nowrap;"
    )
    _TD = "padding:8px 14px;border-bottom:1px solid #ddd;font-size:0.9em;"
    _TD_C = _TD + "text-align:center;"

    return (
        '<div style="font-family:Arial,sans-serif;max-width:960px;'
        'margin-bottom:18px;border:1px solid #3498db;border-radius:6px;overflow:hidden;">'
        '<div style="background:#1f618d;color:#fff;padding:10px 16px;font-weight:bold;">'
        "Optimization Score Summary"
        "</div>"
        '<table style="border-collapse:collapse;width:100%;">'
        "<thead><tr>"
        f'<th style="{_TH}">Metric</th>'
        f'<th style="{_TH}text-align:center;">Before</th>'
        f'<th style="{_TH}text-align:center;">After</th>'
        f'<th style="{_TH}text-align:center;">\u0394 Change</th>'
        "</tr></thead>"
        "<tbody>"
        "<tr>"
        f'<td style="{_TD}">User score <span style="color:#888;font-size:0.85em;">(SQL quality you control)</span></td>'
        f'<td style="{_TD_C}">{u_before}</td>'
        f'<td style="{_TD_C}">{u_after}</td>'
        + _delta_cell(u_delta) +
        "</tr>"
        '<tr style="background:#f9f9f9;">'
        f'<td style="{_TD}">Global score <span style="color:#888;font-size:0.85em;">(incl. infrastructure)</span></td>'
        f'<td style="{_TD_C}">{g_before}</td>'
        f'<td style="{_TD_C}">{g_after}</td>'
        + _delta_cell(g_delta) +
        "</tr>"
        "</tbody>"
        "</table>"
        f'<div style="padding:8px 16px;font-size:0.85em;color:#555;border-top:1px solid #ddd;">'
        f'Strategy: <strong style="color:#1a5276;">{strategy}</strong>'
        f' &nbsp;|&nbsp; Status: <strong style="color:{status_color};">{status_label}</strong>'
        f' &nbsp;|&nbsp; Business logic: <strong style="color:{bl_color};">{bl_label}</strong>'
        "</div>"
        "</div>"
    )


def display_optimization_result(result: dict) -> None:
    """Render an optimization result dict in a Jupyter notebook cell.

    Displays a score comparison widget (before vs. after user/global scores) at
    the top, then converts the Markdown ``answer`` to HTML using the ``markdown``
    package (with ``fenced_code``, ``tables``, and ``sane_lists`` extensions) and
    renders it inside a styled container via ``IPython.display.HTML``.

    Args:
        result: Dict returned by ``query_optimizer`` / ``aquery_optimizer`` /
                ``skill_optimize_query``.
    """
    from IPython.display import display, HTML

    answer = result.get("answer", "")

    try:
        import markdown as _md
    except ImportError:
        raise ImportError(
            "The 'markdown' package is required for display_optimization_result. "
            "Install it with: pip install markdown"
        )

    html_body = _md.markdown(
        answer,
        extensions=["fenced_code", "tables", "sane_lists"],
    )

    # Score comparison widget (rendered before the full report)
    score_delta = result.get("score_delta")
    score_widget = _render_score_delta_html(score_delta) if score_delta else ""

    # CSS is a plain string — no .format() / f-string so CSS braces are literal.
    _CSS = (
        "<style>"
        ".tdo-report pre { background: #f4f4f4; padding: 12px 16px; border-radius: 5px;"
        " overflow-x: auto; border: 1px solid #ddd; margin: 8px 0; }"
        ".tdo-report code { font-family: 'Courier New', monospace; font-size: 0.88em; color: #c0392b; }"
        ".tdo-report pre code { color: #2c3e50; background: transparent; }"
        ".tdo-report p { margin: 6px 0; }"
        ".tdo-report table { border-collapse: collapse; width: 100%; margin: 10px 0; }"
        ".tdo-report th, .tdo-report td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }"
        ".tdo-report th { background-color: #eaf3fb; font-weight: bold; }"
        ".tdo-report tr:nth-child(even) { background-color: #f9f9f9; }"
        ".tdo-report h2 { color: #1f618d; border-bottom: 2px solid #3498db;"
        " padding-bottom: 4px; margin-top: 20px; }"
        ".tdo-report h3 { color: #2471a3; margin-top: 16px; }"
        ".tdo-report blockquote { border-left: 4px solid #3498db; margin: 0; padding: 4px 12px;"
        " background: #eaf3fb; color: #555; }"
        ".tdo-report strong { color: #1a5276; }"
        ".tdo-report ul, .tdo-report ol { margin: 6px 0; padding-left: 24px; }"
        ".tdo-report li { margin: 2px 0; }"
        "</style>"
    )
    styled = (
        '<div style="font-family: Arial, sans-serif; line-height: 1.65;'
        ' max-width: 960px; color: #2c3e50;">'
        + score_widget
        + '<div class="tdo-report">'
        + _CSS
        + html_body
        + "</div>"
        + "</div>"
    )
    display(HTML(styled))


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

async def aquery_optimizer(
    sql_query: Optional[str] = None,
    thread_id: str = "default",
    process_id: Optional[str] = None,
) -> dict:
    """Async entry point — recommended inside Jupyter notebooks and async frameworks.

    Args:
        sql_query:  A Teradata SQL statement to optimise, **or** a follow-up question
                    referencing a previously optimised query in the same ``thread_id``.
                    Can be ``None`` when *process_id* is provided.
        thread_id:  Conversation thread identifier for multi-turn memory.
        process_id: UUID of a registered tdfs4ds process.  When supplied, the SQL and
                    any stored EXPLAIN documentation are fetched from the catalog.

    Returns:
        dict with keys ``answer``, ``best_sql``, ``steps``,
        ``filtermanager_applicable``, ``original_analysis``, ``candidates``,
        ``comparison``, ``process_info``, ``score_delta``, ``messages``.
    """
    return await _run_optimizer(sql_query, thread_id, process_id=process_id)


def query_optimizer(
    sql_query: Optional[str] = None,
    thread_id: str = "default",
    process_id: Optional[str] = None,
) -> dict:
    """Synchronous entry point — safe to call from scripts and Jupyter notebooks.

    When an event loop is already running (Jupyter / IPython) the pipeline executes
    in a background thread to avoid event-loop conflicts.

    Args:
        sql_query:  A Teradata SQL statement to optimise, **or** a follow-up question
                    referencing a previously optimised query in the same ``thread_id``.
                    Can be ``None`` when *process_id* is provided.
        thread_id:  Conversation thread identifier for multi-turn memory.
        process_id: UUID of a registered tdfs4ds process.  When supplied, the SQL and
                    any stored EXPLAIN documentation are fetched from the catalog.

    Returns:
        dict with keys:
          ``answer``                    — Structured Markdown optimisation report.
          ``best_sql``                  — Recommended SQL (original if already optimal).
          ``steps``                     — List of ``{step, ...}`` dicts.
          ``filtermanager_applicable``  — True if a FilterManager loop was recommended.
          ``original_analysis``         — Scored EXPLAIN analysis of the original query.
          ``candidates``                — List of candidate dicts (sql, strategy, analysis).
          ``comparison``                — Plan comparison result dict.
          ``process_info``              — Full process catalog record (when process_id given).
          ``messages``                  — Full LangGraph message list.
    """
    coro = _run_optimizer(sql_query, thread_id, process_id=process_id)
    try:
        asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    except RuntimeError:
        return asyncio.run(coro)
