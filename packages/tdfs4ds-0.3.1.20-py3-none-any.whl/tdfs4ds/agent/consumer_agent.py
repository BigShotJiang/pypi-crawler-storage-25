"""
Consumer agent skills, intent classifier, and answer synthesizer.

Business consumers (data managers, study managers, regulatory affairs) interact
with the feature store in natural language. This module provides:
- ``intent_classifier`` — routes questions to the right skill
- Five skills: search, definition, usage, freshness, summary
- ``synthesize_answer`` — converts structured skill output to plain language
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Literal, Optional

import pandas as pd
import teradataml as tdml
from pydantic import BaseModel, Field

import tdfs4ds
from tdfs4ds import logger_safe
from tdfs4ds.process_store.process_followup import follow_up_report

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# LLM helper
# ═══════════════════════════════════════════════════════════════════════════

def list_instruct_models() -> pd.DataFrame:
    """List available instruct/chat models from the configured provider.

    Returns:
        DataFrame with columns: MODEL_ID, OWNED_BY (OpenAI-compatible) or
        MODEL_ID, PROVIDER, MODALITY (Bedrock).

    Raises:
        ValueError: If the provider is not recognized or not configured.
    """
    provider = (tdfs4ds.INSTRUCT_MODEL_PROVIDER or "").lower()

    if provider in ("openai", "vllm", "openai-compatible", "azure", "mistralai"):
        import httpx

        base = (tdfs4ds.INSTRUCT_MODEL_URL or "https://api.openai.com/v1").rstrip("/")
        url = f"{base}/models" if base.endswith("/v1") else f"{base}/v1/models"
        headers = {"Authorization": f"Bearer {tdfs4ds.INSTRUCT_MODEL_API_KEY}"}
        resp = httpx.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json().get("data", [])
        rows = [{"MODEL_ID": m["id"], "OWNED_BY": m.get("owned_by", "")} for m in data]
        return pd.DataFrame(rows).sort_values("MODEL_ID").reset_index(drop=True)

    if provider == "bedrock":
        import boto3

        client = boto3.client("bedrock")
        response = client.list_foundation_models(byOutputModality="TEXT")
        rows = [
            {
                "MODEL_ID": m["modelId"],
                "PROVIDER": m.get("providerName", ""),
                "MODEL_NAME": m.get("modelName", ""),
            }
            for m in response["modelSummaries"]
        ]
        return pd.DataFrame(rows).sort_values("MODEL_ID").reset_index(drop=True)

    raise ValueError(
        f"INSTRUCT_MODEL_PROVIDER is '{tdfs4ds.INSTRUCT_MODEL_PROVIDER}'. "
        f"Set it to 'openai', 'vllm', 'azure', or 'bedrock'."
    )


def _get_llm(max_tokens: Optional[int] = None, callbacks=None):
    """Return a LangChain chat model based on the active provider.

    Args:
        max_tokens: Optional cap on completion tokens.  Useful when the model has a
                    small total context window and the caller knows the expected output
                    is short (e.g. structured candidate generation).
        callbacks:  Optional list of LangChain callback handlers (e.g. for token
                    usage tracking).  Passed through to the model constructor.

    Returns:
        A LangChain BaseChatModel instance.

    Raises:
        ValueError: If the provider is not recognized.
    """
    provider = (tdfs4ds.INSTRUCT_MODEL_PROVIDER or "").lower()

    if provider in ("openai", "vllm", "openai-compatible", "azure", "mistralai"):
        from langchain_openai import ChatOpenAI

        kwargs = dict(
            model=tdfs4ds.INSTRUCT_MODEL_MODEL,
            api_key=tdfs4ds.INSTRUCT_MODEL_API_KEY,
            temperature=0.0,
            timeout=getattr(tdfs4ds, "INSTRUCT_MODEL_TIMEOUT", 60),
            max_retries=getattr(tdfs4ds, "INSTRUCT_MODEL_MAX_RETRIES", 3),
        )
        # Mistral API rejects the seed parameter
        if provider != "mistralai":
            kwargs["seed"] = 42
        if tdfs4ds.INSTRUCT_MODEL_URL:
            kwargs["base_url"] = tdfs4ds.INSTRUCT_MODEL_URL
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if callbacks:
            kwargs["callbacks"] = callbacks
        return ChatOpenAI(**kwargs)

    if provider == "bedrock":
        from langchain_aws import ChatBedrock

        model_kwargs: dict = {"temperature": 0.0}
        if max_tokens is not None:
            model_kwargs["max_tokens"] = max_tokens
        return ChatBedrock(
            model_id=tdfs4ds.INSTRUCT_MODEL_MODEL,
            model_kwargs=model_kwargs,
            callbacks=callbacks or None,
        )

    raise ValueError(
        f"Unsupported INSTRUCT_MODEL_PROVIDER '{tdfs4ds.INSTRUCT_MODEL_PROVIDER}'. "
        f"Must be 'openai', 'mistralai', 'bedrock', 'vllm', or 'azure'."
    )


def _llm_call(system_prompt: str, user_prompt: str) -> str:
    """Execute a single LLM chat completion.

    Args:
        system_prompt: System message content.
        user_prompt: User message content.

    Returns:
        The assistant's response text.
    """
    from langchain_core.messages import SystemMessage, HumanMessage

    llm = _get_llm()
    messages = [SystemMessage(content=system_prompt), HumanMessage(content=user_prompt)]
    response = llm.invoke(messages)
    return response.content


# ═══════════════════════════════════════════════════════════════════════════
# Data domain discovery
# ═══════════════════════════════════════════════════════════════════════════

def get_data_domain() -> pd.DataFrame:
    """List all DATA_DOMAINs available in the feature store.

    Returns:
        DataFrame with columns ``DATA_DOMAIN`` and ``FEATURE_COUNT``.
    """
    try:
        all_features = tdfs4ds.feature_catalog(all_data_domains=True).to_pandas()
        if all_features.empty or "DATA_DOMAIN" not in all_features.columns:
            return pd.DataFrame(columns=["DATA_DOMAIN", "FEATURE_COUNT"])
        summary = (
            all_features.groupby("DATA_DOMAIN")
            .size()
            .reset_index(name="FEATURE_COUNT")
        )
        return summary
    except Exception as exc:
        logger.warning("get_data_domain failed: %s", exc)
        return pd.DataFrame(columns=["DATA_DOMAIN", "FEATURE_COUNT"])


def detect_data_domain_for_object(object_name: str) -> Optional[str]:
    """Return the DATA_DOMAIN that contains *object_name* as a feature name.

    Searches the full feature catalog (all data domains).  Falls back to the
    process catalog (VIEW_NAME) if the feature is not found by name.

    Args:
        object_name: Feature or view name to locate.

    Returns:
        Matching DATA_DOMAIN string, or ``None`` if not found.
    """
    try:
        all_features = tdfs4ds.feature_catalog(all_data_domains=True).to_pandas()
        if not all_features.empty and "FEATURE_NAME" in all_features.columns:
            match = all_features[
                all_features["FEATURE_NAME"].str.upper() == object_name.upper()
            ]
            if not match.empty:
                return str(match.iloc[0]["DATA_DOMAIN"])
    except Exception as exc:
        logger.warning("detect_data_domain_for_object (feature_catalog): %s", exc)

    try:
        all_processes = tdfs4ds.process_catalog(all_data_domains=True).to_pandas()
        if not all_processes.empty and "VIEW_NAME" in all_processes.columns:
            match = all_processes[
                all_processes["VIEW_NAME"].str.upper() == object_name.upper()
            ]
            if not match.empty and "DATA_DOMAIN" in all_processes.columns:
                return str(match.iloc[0]["DATA_DOMAIN"])
    except Exception as exc:
        logger.warning("detect_data_domain_for_object (process_catalog): %s", exc)

    # Fallback: check if object_name is a dataset, then derive domain from its first feature
    try:
        ds = _resolve_dataset(object_name)
        if ds:
            ds_features_df = tdfs4ds.get_dataset_features(ds["dataset_id"]).to_pandas()
            if not ds_features_df.empty and "FEATURE_NAME" in ds_features_df.columns:
                first_feature = str(ds_features_df.iloc[0]["FEATURE_NAME"])
                return detect_data_domain_for_object(first_feature)
    except Exception as exc:
        logger.warning("detect_data_domain_for_object (dataset_catalog): %s", exc)

    return None


# ═══════════════════════════════════════════════════════════════════════════
# Intent classifier
# ═══════════════════════════════════════════════════════════════════════════

class IntentResult(BaseModel):
    """Structured output for intent classification (hardwired fallback — all 8 intents)."""

    intent: Literal["SEARCH", "DEFINITION", "USAGE", "FRESHNESS", "SUMMARY", "LINEAGE", "EXPLAIN", "DATASET", "BUILD_DATASET"]
    object_name: Optional[str] = Field(None, description="Feature or dataset name if mentioned")
    domain: Optional[str] = Field(None, description="Therapeutic domain if mentioned")


def _build_intent_model(intents: list):
    """Build a dynamic Pydantic model for intent classification from a list of intent names.

    Uses ``Union[Literal["A"], Literal["B"], ...]`` which equals ``Literal["A", "B", ...]``
    per PEP 586, constructed at runtime via ``pydantic.create_model``.

    Args:
        intents: List of uppercase intent names (e.g. ``["SEARCH", "DEFINITION"]``).

    Returns:
        A Pydantic BaseModel subclass with an ``intent`` field constrained to
        the provided values, plus ``object_name`` and ``domain`` optional fields.
    """
    from typing import Union
    from pydantic import create_model

    if not intents:
        raise ValueError("At least one intent is required to build the intent model.")

    lit_types = tuple(Literal[i] for i in intents)
    combined = Union[lit_types] if len(lit_types) > 1 else lit_types[0]
    return create_model(
        "IntentResult",
        intent=(combined, ...),
        object_name=(Optional[str], Field(default=None, description="Feature or dataset name if mentioned")),
        domain=(Optional[str], Field(default=None, description="Therapeutic domain if mentioned")),
    )


class SourceColumnRef(BaseModel):
    """A column referenced in a feature formula and its source table/view."""

    column_name: str = Field(description="Column or alias name as it appears in the SQL expression (bare name, no schema)")
    source_table: str = Field(description="Source table or view the column comes from (bare name, no schema prefix)")


class ExplainOutput(BaseModel):
    """Structured output for the EXPLAIN skill."""

    explanation: str = Field(
        description=(
            "Plain business language explanation of the feature: data sources (by purpose, "
            "not table name), filters in business terms, how the value is computed, and what "
            "it represents. Maximum 6 sentences. No SQL syntax, no column names, no table names."
        )
    )
    calculation_sql: Optional[str] = Field(
        None,
        description=(
            "The SQL expression that computes this specific feature, extracted verbatim from "
            "the SELECT list. If the outer SELECT merely passes through an alias defined in a "
            "subquery, drill down into that subquery to find the real computation — repeat for "
            "every nesting level until the actual arithmetic or aggregation is found. Include "
            "only the expression itself (e.g. 'CAST(CURRENT_DATE - MAX(transaction_date) AS INT)'), "
            "never the full query. Return null only when the expression genuinely cannot be "
            "resolved at any nesting level."
        )
    )
    calculation_latex: Optional[str] = Field(
        None,
        description=(
            "LaTeX representation of the calculation in display-math notation, WITHOUT "
            "surrounding delimiters. Populate ONLY when the user explicitly requested a "
            "formula, equation, or LaTeX. Use \\text{} for business names and standard LaTeX "
            "for operators (\\max, \\sum, \\frac, \\cdot, etc.). "
            "Example: r'\\text{nb\\_days} = \\text{TODAY} - \\max(\\text{transaction\\_date})'. "
            "Return null when not requested or when the expression is too complex to render "
            "meaningfully as a single formula."
        )
    )
    source_columns: Optional[list[SourceColumnRef]] = Field(
        None,
        description=(
            "For every distinct column or alias referenced in the feature's calculation expression, "
            "provide its bare name and the source table or view it originates from (resolve through "
            "subquery aliases to the real base table/view wherever possible). Bare names only — no "
            "schema prefix. Omit entity-key columns (e.g. primary-key columns). Return null if the "
            "formula contains no identifiable column references."
        )
    )


def _build_classifier_examples() -> str:
    """Build the few-shot classifier examples string from ca-* SKILL.md files.

    Examples are read from the '## Classifier Examples' section of each skill's
    SKILL.md file, making the SKILL.md files the single source of truth.
    Plugin skills loaded from TDFS4DS_SKILLS_FOLDER are included automatically.
    """
    from tdfs4ds.cli import consumer_agent_skill_catalog
    catalog = consumer_agent_skill_catalog()
    lines = ["Examples:"]
    for meta in catalog.values():
        for ex in meta.get("examples", []):
            lines.append(f"- {ex}")
    return "\n".join(lines) + "\n" if len(lines) > 1 else ""


def intent_classifier(question: str, intent_model=None, intent_descriptions: dict = None):
    """Classify a user question into one of the available intents.

    Args:
        question: User question in natural language (French or English).
        intent_model: Pydantic model for structured output. When ``None``, falls
            back to the hardwired :class:`IntentResult` covering all 8 intents.
        intent_descriptions: ``{intent_name: description}`` dict used to build
            the system-prompt intent list. When ``None``, falls back to the
            hardwired descriptions.

    Returns:
        An instance of ``intent_model`` (or :class:`IntentResult`) with
        ``intent``, ``object_name``, and ``domain`` fields.
    """
    from langchain_core.prompts import ChatPromptTemplate

    model = intent_model if intent_model is not None else IntentResult

    if intent_descriptions:
        intent_lines = "\n".join(
            f"- {intent}: {desc}" for intent, desc in intent_descriptions.items()
        )
    else:
        intent_lines = (
            "- SEARCH: user is looking for features or datasets matching a business need (e.g. 'what datasets can I use for anomaly detection?')\n"
            "- DEFINITION: user asks what a specific feature or dataset means\n"
            "- USAGE: user asks how to use a specific feature (Tableau, Excel, regulatory)\n"
            "- FRESHNESS: user asks whether a feature/dataset is up to date or reliable\n"
            "- SUMMARY: user asks for an overview of available features for a domain or a specific dataset (e.g. 'what are the features of db.dataset_name?')\n"
            "- LINEAGE: user asks where data comes from, what a feature depends on, upstream sources\n"
            "- EXPLAIN: user asks how one or more features are calculated, computed, or what logic produces them; object_name may be comma-separated for multiple features\n"
            "- DATASET: user asks whether one or more features are available in a dataset, or which datasets expose them; object_name may be comma-separated for multiple features"
        )

    system_msg = (
        "You are an intent classifier for a clinical feature store assistant.\n"
        "Classify the user question into exactly one intent and extract any mentioned "
        "feature/dataset name and therapeutic domain.\n\n"
        "IMPORTANT: Copy the feature/dataset name AND the domain name EXACTLY as they "
        "appear in the user's question — do NOT correct spelling, pluralization, "
        "capitalization, or modify them in any way. All catalog lookups are "
        "case-insensitive, so preserve the original strings character for character.\n\n"
        f"Intents:\n{intent_lines}\n\n"
        + _build_classifier_examples()
    )

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_msg),
        ("human", "{question}"),
    ])

    llm = _get_llm()
    chain = prompt | llm.with_structured_output(model)

    try:
        return chain.invoke({"question": question})
    except Exception as exc:
        raise RuntimeError(f"Intent classification failed: {exc}") from exc


# ═══════════════════════════════════════════════════════════════════════════
# Data fetching helpers
# ═══════════════════════════════════════════════════════════════════════════

def _query_bd_sections(
    section_names: Optional[list[str]] = None,
    object_name: Optional[str] = None,
) -> pd.DataFrame:
    """Query FS_BUSINESS_DICTIONARY_SECTIONS with optional filters.

    Uses execute_sql (not from_query) because CURRENT VALIDTIME must be at
    the outermost level — from_query wraps in a subquery which breaks it.
    """
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, OBJECT_NAME, SECTION_NAME, SECTION_CONTENT "
        f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}"
    )
    clauses = []
    if section_names:
        in_list = ", ".join(f"'{s}'" for s in section_names)
        clauses.append(f"SECTION_NAME IN ({in_list})")
    if object_name:
        clauses.append(f"UPPER(OBJECT_NAME) = '{object_name.upper()}'")
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    try:
        rows = tdml.execute_sql(query).fetchall()
        return pd.DataFrame(rows, columns=["DATABASE_NAME", "OBJECT_NAME", "SECTION_NAME", "SECTION_CONTENT"])
    except Exception:
        return pd.DataFrame(columns=["DATABASE_NAME", "OBJECT_NAME", "SECTION_NAME", "SECTION_CONTENT"])


def _query_bd_objects(object_name: Optional[str] = None) -> pd.DataFrame:
    """Query FS_BUSINESS_DICTIONARY_OBJECTS with optional filter."""
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, OBJECT_NAME, OBJECT_TYPE, BUSINESS_DESCRIPTION "
        f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}"
    )
    if object_name:
        query += f" WHERE UPPER(OBJECT_NAME) = '{object_name.upper()}'"
    try:
        rows = tdml.execute_sql(query).fetchall()
        return pd.DataFrame(rows, columns=["DATABASE_NAME", "OBJECT_NAME", "OBJECT_TYPE", "BUSINESS_DESCRIPTION"])
    except Exception:
        return pd.DataFrame(columns=["DATABASE_NAME", "OBJECT_NAME", "OBJECT_TYPE", "BUSINESS_DESCRIPTION"])


def _query_bd_columns(
    table_name: Optional[str] = None,
    column_name: Optional[str] = None,
) -> pd.DataFrame:
    """Query FS_BUSINESS_DICTIONARY_COLUMNS with optional filter."""
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, TABLE_NAME, COLUMN_NAME, BUSINESS_DESCRIPTION "
        f"FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}"
    )
    clauses = []
    if table_name:
        clauses.append(f"UPPER(TABLE_NAME) = '{table_name.upper()}'")
    if column_name:
        clauses.append(f"UPPER(COLUMN_NAME) = '{column_name.upper()}'")
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    try:
        rows = tdml.execute_sql(query).fetchall()
        return pd.DataFrame(rows, columns=["DATABASE_NAME", "TABLE_NAME", "COLUMN_NAME", "BUSINESS_DESCRIPTION"])
    except Exception:
        return pd.DataFrame(columns=["DATABASE_NAME", "TABLE_NAME", "COLUMN_NAME", "BUSINESS_DESCRIPTION"])


# ═══════════════════════════════════════════════════════════════════════════
# Feature documentation resolver
# ═══════════════════════════════════════════════════════════════════════════

def _get_feature_catalog_with_docs(
    feature_filter: Optional[str] = None,
    entity_filter: Optional[str] = None,
) -> pd.DataFrame:
    """Return a DataFrame of features enriched with their process-level documentation.

    Resolution chain per feature:
    1. ``get_list_entity()`` → distinct entity names in the active domain
    2. ``get_list_features(entity_name)`` → feature names per entity
    3. ``get_feature_versions(entity_name, features)`` → process_id per feature
    4. Process catalog → VIEW_NAME for each process_id
    5. ``FS_BUSINESS_DICTIONARY_COLUMNS`` → BUSINESS_DESCRIPTION where
       TABLE_NAME = VIEW_NAME AND COLUMN_NAME = FEATURE_NAME

    Args:
        feature_filter: If given, only return rows for this exact feature name
            (case-insensitive).
        entity_filter: If given, only process this exact entity name
            (case-insensitive). Speeds up entity-scoped lookups.

    Returns:
        DataFrame with columns:
        FEATURE_NAME, ENTITY_NAME, PROCESS_ID, VIEW_NAME, BUSINESS_DESCRIPTION
    """
    from tdfs4ds.feature_store.feature_query_retrieval import (
        get_list_entity,
        get_list_features,
        get_feature_versions,
    )

    rows: list[dict] = []

    # ── Step 1: entities ──────────────────────────────────────────────────
    try:
        entities = get_list_entity().to_pandas()["ENTITY_NAME"].dropna().tolist()
    except Exception as exc:
        logger.warning("_get_feature_catalog_with_docs: get_list_entity failed — %s", exc)
        return pd.DataFrame(columns=["FEATURE_NAME", "ENTITY_NAME", "PROCESS_ID", "VIEW_NAME", "BUSINESS_DESCRIPTION"])

    # ── Process catalog cache (used to map process_id → VIEW_NAME) ────────
    try:
        proc_df = tdfs4ds.process_catalog(all_data_domains=True).to_pandas()
    except Exception:
        proc_df = pd.DataFrame()

    def _process_id_to_view(pid: str) -> Optional[str]:
        if proc_df.empty or "PROCESS_ID" not in proc_df.columns:
            return None
        match = proc_df[proc_df["PROCESS_ID"].astype(str) == str(pid)]
        if not match.empty and "VIEW_NAME" in match.columns:
            return str(match.iloc[0]["VIEW_NAME"])
        return None

    # Apply entity filter
    if entity_filter:
        entities = [e for e in entities if e.upper() == entity_filter.upper()]

    # ── Steps 2-5 per entity ──────────────────────────────────────────────
    for entity_name in entities:
        try:
            features_df = get_list_features(entity_name).to_pandas()
            feature_names = features_df["FEATURE_NAME"].dropna().tolist()
        except Exception as exc:
            logger.warning("get_list_features(%s) failed — %s", entity_name, exc)
            continue

        if not feature_names:
            continue

        # Optional filter
        if feature_filter:
            feature_names = [f for f in feature_names if f.upper() == feature_filter.upper()]
        if not feature_names:
            continue

        try:
            versions = get_feature_versions(entity_name, feature_names)
        except Exception as exc:
            logger.warning("get_feature_versions(%s) failed — %s", entity_name, exc)
            versions = {f: None for f in feature_names}

        for feat_name, version_val in versions.items():
            # Normalise version_val to a single process_id string
            if version_val is None:
                process_id = None
            elif isinstance(version_val, list):
                process_id = version_val[0]["process_id"]
            else:
                process_id = str(version_val)

            view_name = _process_id_to_view(process_id) if process_id else None

            # Strip schema prefix if present ('"schema"."view"' → 'view')
            bare_view = None
            if view_name:
                bare_view = view_name.strip('"').split('"."')[-1] if '"."' in view_name else view_name.strip('"')

            # Query business dictionary columns
            description = ""
            if bare_view:
                col_df = _query_bd_columns(table_name=bare_view, column_name=feat_name)
                if not col_df.empty:
                    description = str(col_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or "")

            rows.append({
                "FEATURE_NAME": feat_name,
                "ENTITY_NAME": entity_name,
                "PROCESS_ID": process_id,
                "VIEW_NAME": bare_view,
                "BUSINESS_DESCRIPTION": description,
            })

    return pd.DataFrame(rows, columns=["FEATURE_NAME", "ENTITY_NAME", "PROCESS_ID", "VIEW_NAME", "BUSINESS_DESCRIPTION"])


def _build_multi_object_context(
    feature_names: list,
    hint_entity_name: Optional[str] = None,
) -> dict:
    """Build a shared context graph for multiple features in one pass.

    Calls _get_feature_catalog_with_docs() once (no filter) then:
    - Resolves each name to (entity, process_id, view_name, description)
    - Fetches BD_SECTIONS + all BD_COLUMNS for each unique VIEW_NAME (once each)
    - Fetches dataset membership for each feature via get_dataset_features()
    - Fetches BD_OBJECTS + BD_SECTIONS for each unique dataset (once each)

    Returns:
        {
          "features": [{name, entity_name, process_id, view_name, description,
                        found_in_catalog, has_description, dataset_names}],
          "shared_views": {view_name: {"sections": [...], "columns": [...]}},
          "shared_datasets": {ds_name: {"database", "bd_description", "sections"}},
          "entity_names": [str],
        }
    """
    catalog_df = _get_feature_catalog_with_docs()
    if not catalog_df.empty:
        catalog_upper = catalog_df.copy()
        catalog_upper["_KEY"] = catalog_upper["FEATURE_NAME"].str.upper()
    else:
        catalog_upper = pd.DataFrame(
            columns=["_KEY", "FEATURE_NAME", "ENTITY_NAME", "PROCESS_ID", "VIEW_NAME", "BUSINESS_DESCRIPTION"]
        )

    features = []
    unique_views: dict = {}
    entity_set: list = []

    for name in feature_names:
        match = catalog_upper[catalog_upper["_KEY"] == name.upper()]
        if len(match) > 1 and hint_entity_name:
            narrowed = match[match["ENTITY_NAME"].str.upper() == hint_entity_name.upper()]
            if not narrowed.empty:
                match = narrowed
        if match.empty:
            features.append({
                "name": name, "entity_name": "", "process_id": "", "view_name": "",
                "description": "", "found_in_catalog": False, "has_description": False,
                "dataset_names": [],
            })
            continue
        row = match.iloc[0]
        desc = str(row.get("BUSINESS_DESCRIPTION") or "").strip()
        entity = str(row.get("ENTITY_NAME") or "")
        view = str(row.get("VIEW_NAME") or "")
        if entity and entity not in entity_set:
            entity_set.append(entity)
        if view:
            unique_views[view] = True
        features.append({
            "name": name,
            "entity_name": entity,
            "process_id": str(row.get("PROCESS_ID") or ""),
            "view_name": view,
            "description": desc,
            "found_in_catalog": True,
            "has_description": bool(desc),
            "dataset_names": [],
        })

    shared_views: dict = {}
    for view_name in unique_views:
        view_bare = view_name.split(".")[-1] if "." in view_name else view_name
        try:
            secs_df = _query_bd_sections(object_name=view_bare)
            sections = secs_df[["SECTION_NAME", "SECTION_CONTENT"]].to_dict("records") if not secs_df.empty else []
        except Exception:
            sections = []
        try:
            cols_df = _query_bd_columns(table_name=view_bare)
            columns = cols_df[["COLUMN_NAME", "BUSINESS_DESCRIPTION"]].to_dict("records") if not cols_df.empty else []
        except Exception:
            columns = []
        shared_views[view_name] = {"sections": sections, "columns": columns}

    try:
        all_ds_features = tdfs4ds.get_dataset_features().to_pandas()
        ds_catalog = tdfs4ds.dataset_catalog().to_pandas()
    except Exception:
        all_ds_features = pd.DataFrame()
        ds_catalog = pd.DataFrame()

    shared_datasets: dict = {}
    for feat in features:
        if all_ds_features.empty or "FEATURE_NAME" not in all_ds_features.columns:
            break
        f_match = all_ds_features[
            all_ds_features["FEATURE_NAME"].str.upper() == feat["name"].upper()
        ]
        dataset_ids = f_match["DATASET_ID"].dropna().unique().tolist() if not f_match.empty else []
        for did in dataset_ids:
            if ds_catalog.empty or "DATASET_ID" not in ds_catalog.columns:
                continue
            cat_row = ds_catalog[ds_catalog["DATASET_ID"].astype(str) == str(did)]
            if cat_row.empty:
                continue
            ds_name = str(cat_row.iloc[0].get("DATASET_NAME", did))
            feat["dataset_names"].append(ds_name)
            if ds_name not in shared_datasets:
                try:
                    bd_obj = _query_bd_objects(object_name=ds_name)
                    bd_desc = str(bd_obj.iloc[0]["BUSINESS_DESCRIPTION"]) if not bd_obj.empty else ""
                except Exception:
                    bd_desc = ""
                try:
                    bd_secs = _query_bd_sections(object_name=ds_name)
                    ds_secs = bd_secs[["SECTION_NAME", "SECTION_CONTENT"]].to_dict("records") if not bd_secs.empty else []
                except Exception:
                    ds_secs = []
                ds_database = str(cat_row.iloc[0].get("DATASET_DATABASE", "")) if not cat_row.empty else ""
                shared_datasets[ds_name] = {
                    "database": ds_database,
                    "bd_description": bd_desc,
                    "sections": ds_secs,
                }

    return {
        "features": features,
        "shared_views": shared_views,
        "shared_datasets": shared_datasets,
        "entity_names": entity_set,
    }


def _recognize_object_type(name: str) -> dict:
    """Identify what type of object *name* is by querying catalogs.

    Returns a dict with keys: type ("feature"|"dataset"|"process"|"unknown"),
    entity_name, view_name, process_id.
    """
    result = {"type": "unknown", "entity_name": "", "view_name": "", "process_id": ""}
    if not name:
        return result
    try:
        feat_doc = _get_feature_catalog_with_docs(feature_filter=name)
        if not feat_doc.empty:
            row = feat_doc.iloc[0]
            result["type"] = "feature"
            result["entity_name"] = str(row.get("ENTITY_NAME", "") or "")
            result["view_name"] = str(row.get("VIEW_NAME", "") or "")
            result["process_id"] = str(row.get("PROCESS_ID", "") or "")
            return result
    except Exception:
        pass
    try:
        ds_cat = tdfs4ds.dataset_catalog().to_pandas()
        if not ds_cat.empty:
            name_col = next((c for c in ds_cat.columns if "DATASET_NAME" in c.upper()), None)
            if name_col and (ds_cat[name_col].astype(str).str.upper() == name.upper()).any():
                result["type"] = "dataset"
                return result
    except Exception:
        pass
    return result


# ═══════════════════════════════════════════════════════════════════════════
# Vector search fallback
# ═══════════════════════════════════════════════════════════════════════════

def _vector_search_context(query: str, top_k: int = 5) -> tuple[str, Optional[str]]:
    """Build LLM context from vector search results when SQL exact match fails.

    Args:
        query: Free-text search query (object name or natural language question).
        top_k: Maximum results per collection.

    Returns:
        Tuple of (context_string, resolved_object_name). Both may be empty/None.
    """
    try:
        from tdfs4ds.agent.vector_index import search_vector_index

        results = search_vector_index(query, sources=["objects", "sections", "columns"], top_k=top_k)
        if results.empty:
            return "", None
        parts: list[str] = []
        resolved_name: Optional[str] = None
        for _, row in results.iterrows():
            source = row["SOURCE"]
            name = row.get("OBJECT_NAME") or ""
            text = row.get("TEXT") or ""
            if not text.strip():
                continue
            if resolved_name is None and name:
                resolved_name = name
            if source == "columns":
                col = row.get("COLUMN_NAME", "")
                parts.append(f"Column {col} (in {name}): {text}")
            elif source == "sections":
                sec = row.get("SECTION_NAME", "")
                parts.append(f"{name} [{sec}]: {text}")
            else:
                parts.append(f"Object {name}: {text}")
        return "\n".join(parts), resolved_name
    except Exception:
        return "", None


# ═══════════════════════════════════════════════════════════════════════════
# Dataset resolution helpers
# ═══════════════════════════════════════════════════════════════════════════

def _resolve_dataset(object_name: str) -> Optional[dict]:
    """Look up *object_name* in the dataset catalog.

    Accepts ``"database.name"`` or ``"name"`` (case-insensitive).

    Returns ``{dataset_id, dataset_name, dataset_database}`` or ``None``.
    """
    if not object_name:
        return None
    try:
        ds_cat = tdfs4ds.dataset_catalog().to_pandas()
    except Exception as exc:
        logger.warning("_resolve_dataset: catalog query failed — %s", exc)
        return None
    if ds_cat.empty or "DATASET_NAME" not in ds_cat.columns:
        return None

    parts = object_name.strip().split(".", 1)
    if len(parts) == 2:
        db_filter, name_filter = parts[0].strip().upper(), parts[1].strip().upper()
        mask = (
            ds_cat["DATASET_NAME"].str.upper() == name_filter
        ) & (
            ds_cat["DATASET_DATABASE"].str.upper() == db_filter
        )
    else:
        name_filter = parts[0].strip().upper()
        mask = ds_cat["DATASET_NAME"].str.upper() == name_filter

    matches = ds_cat[mask]
    if matches.empty:
        return None
    row = matches.iloc[0]
    return {
        "dataset_id": str(row["DATASET_ID"]),
        "dataset_name": str(row["DATASET_NAME"]),
        "dataset_database": str(row.get("DATASET_DATABASE", "")),
    }


def _get_dataset_with_features(dataset_id: str) -> list:
    """Return a list of feature dicts for *dataset_id*, enriched with process view and docs.

    Each item: ``{feature_name, entity_name, view_name, feature_type, description}``.
    """
    try:
        ds_features = tdfs4ds.get_dataset_features(dataset_id).to_pandas()
    except Exception as exc:
        logger.warning("_get_dataset_with_features: feature query failed — %s", exc)
        return []
    if ds_features.empty or "FEATURE_NAME" not in ds_features.columns:
        return []

    dataset_feature_names = set(ds_features["FEATURE_NAME"].str.upper().tolist())
    feature_types = {
        str(r["FEATURE_NAME"]).upper(): str(r.get("FEATURE_TYPE", ""))
        for _, r in ds_features.iterrows()
    }

    # One call to get all registered features with process views and BD docs
    try:
        feat_doc = _get_feature_catalog_with_docs()
    except Exception as exc:
        logger.warning("_get_dataset_with_features: feat_doc failed — %s", exc)
        feat_doc = pd.DataFrame()

    result = []
    if not feat_doc.empty:
        for _, row in feat_doc.iterrows():
            fname = str(row.get("FEATURE_NAME", "")).upper()
            if fname in dataset_feature_names:
                result.append({
                    "feature_name": str(row.get("FEATURE_NAME", "")),
                    "entity_name": str(row.get("ENTITY_NAME", "")),
                    "view_name": str(row.get("VIEW_NAME", "")),
                    "feature_type": feature_types.get(fname, ""),
                    "description": str(row.get("BUSINESS_DESCRIPTION", "") or ""),
                })
                dataset_feature_names.discard(fname)

    # Features in the dataset catalog but not in the feature catalog (no process view)
    for fname_upper in sorted(dataset_feature_names):
        result.append({
            "feature_name": fname_upper,
            "entity_name": "",
            "view_name": "",
            "feature_type": feature_types.get(fname_upper, ""),
            "description": "",
        })
    return result


# ═══════════════════════════════════════════════════════════════════════════
# Skills
# ═══════════════════════════════════════════════════════════════════════════

def skill_search(question: str) -> dict:
    """Find features or datasets matching a business need expressed in natural language.

    Args:
        question: User question describing the business need.

    Returns:
        Dict with key ``matches``: list of ``{name, type, justification}``.
    """
    sections_df = _query_bd_sections(section_names=["FEATURE_THEMES", "BUSINESS_QUESTIONS"])
    objects_df = _query_bd_objects()

    try:
        feature_cat = tdfs4ds.feature_catalog().to_pandas()
    except Exception:
        feature_cat = pd.DataFrame(columns=["FEATURE_NAME", "DATA_DOMAIN"])

    if sections_df.empty and objects_df.empty and feature_cat.empty:
        return {"error": "documentation_not_available"}

    # Build context for the LLM
    context_parts = []
    _docs_used: list[str] = []

    # Prioritise vector search results (most relevant to the question)
    vector_ctx, _ = _vector_search_context(question, top_k=5)
    if vector_ctx:
        context_parts.append(f"Most relevant results:\n{vector_ctx}")
        _docs_used.append("VECTOR_INDEX")

    if not objects_df.empty:
        _docs_used.append("BD_OBJECTS")
        for _, row in objects_df.iterrows():
            desc = row.get("BUSINESS_DESCRIPTION", "")
            if desc:
                context_parts.append(f"Object: {row['OBJECT_NAME']} — {desc}")

    if not sections_df.empty:
        _used_secs = sorted(sections_df["SECTION_NAME"].dropna().unique().tolist())
        _docs_used.append(f"BD_SECTIONS[{', '.join(_used_secs)}]")
        for _, row in sections_df.iterrows():
            content = row.get("SECTION_CONTENT", "")
            if content:
                context_parts.append(
                    f"Object: {row['OBJECT_NAME']} [{row['SECTION_NAME']}] — {content}"
                )

    if not feature_cat.empty:
        _docs_used.append("FEATURE_CATALOG")
        for _, row in feature_cat.iterrows():
            context_parts.append(f"Feature: {row['FEATURE_NAME']} (domain: {row.get('DATA_DOMAIN', 'N/A')})")

    # Include registered datasets so semantic dataset searches can match them
    try:
        ds_cat = tdfs4ds.dataset_catalog().to_pandas()
        if not ds_cat.empty and "DATASET_NAME" in ds_cat.columns:
            _docs_used.append("DATASET_CATALOG")
            for _, row in ds_cat.iterrows():
                db = row.get("DATASET_DATABASE", "")
                name = row.get("DATASET_NAME", "")
                fq = f"{db}.{name}" if db else name
                context_parts.append(f"Dataset: {fq} — registered dataset")
    except Exception:
        pass

    context = "\n".join(context_parts)

    system_prompt = (
        "You are a feature store search assistant. Given the available features and datasets below, "
        "return a JSON array of the best matches for the user's question.\n"
        "Each match must have: name (string), type ('feature' or 'dataset'), justification (one sentence).\n"
        "Return at most 10 matches, ranked by relevance. Return only the JSON array, no other text.\n\n"
        f"Available data:\n{context}"
    )

    try:
        raw = _llm_call(system_prompt, question)
        import json, re

        # Strip markdown code fences (```json ... ``` or ``` ... ```)
        cleaned = re.sub(r"^```(?:json)?\s*\n?", "", raw.strip(), flags=re.IGNORECASE)
        cleaned = re.sub(r"\n?```\s*$", "", cleaned).strip()

        matches = json.loads(cleaned) if cleaned.startswith("[") else []
    except Exception as exc:
        raise RuntimeError(f"skill_search failed: {exc}") from exc

    # When JSON parsing returned nothing but we had context, pass the raw
    # context to the synthesizer so it can still produce a useful answer.
    if not matches and context:
        return {"matches": [], "available_context": context, "docs_sources": _docs_used}

    return {"matches": matches, "docs_sources": _docs_used}


def skill_definition(
    question: str,
    object_name: str,
    hint_entity_name: Optional[str] = None,
    hint_table_name: Optional[str] = None,
) -> dict:
    """Explain what a feature, column, or dataset is in plain business language.

    Args:
        question: User question.
        object_name: Name of the feature, column, or dataset to define.
        hint_entity_name: Entity name remembered from a previous turn — used to
            auto-disambiguate when the same feature name exists across entities.
        hint_table_name: Source table/view remembered from a prior EXPLAIN turn —
            used to narrow column-level BD lookups to the right table when the
            column is not a registered feature.

    Returns:
        Dict with ``object_name``, ``explanation``, and ``columns``.
    """
    context_parts = []
    _docs_used: list[str] = []
    _resolved_triplet: Optional[dict] = None

    # ── Primary path: resolve via process documentation ───────────────────
    # Feature description lives in FS_BUSINESS_DICTIONARY_COLUMNS keyed by
    # (VIEW_NAME, FEATURE_NAME) where VIEW_NAME is the process view.
    feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
    if not feat_doc.empty and len(feat_doc) > 1:
        if hint_entity_name:
            filtered = feat_doc[
                feat_doc["ENTITY_NAME"].str.upper() == hint_entity_name.upper()
            ]
            if len(filtered) == 1:
                feat_doc = filtered
            elif not filtered.empty:
                feat_doc = filtered
        if len(feat_doc) > 1:
            entities = feat_doc["ENTITY_NAME"].dropna().unique().tolist()
            return {"error": "ambiguous_feature", "object_name": object_name, "entities": entities}
    if not feat_doc.empty:
        _docs_used.append("FEATURE_CATALOG")
        row = feat_doc.iloc[0]
        entity = row.get("ENTITY_NAME", "")
        view_name = row.get("VIEW_NAME", "")
        _resolved_triplet = {
            "feature_name": str(row.get("FEATURE_NAME") or object_name),
            "entity_name": str(entity or ""),
            "process_id": str(row.get("PROCESS_ID") or ""),
            "view_name": str(view_name or ""),
        }
        desc = row.get("BUSINESS_DESCRIPTION", "") or ""
        feat_name_str = str(row.get("FEATURE_NAME") or object_name)
        if not desc:
            # Docs may be stored against a dataset view or different table — broad column-name search
            _col_any = _query_bd_columns(column_name=feat_name_str)
            if not _col_any.empty:
                _non_empty = _col_any[
                    _col_any["BUSINESS_DESCRIPTION"].notna()
                    & (_col_any["BUSINESS_DESCRIPTION"].astype(str).str.strip() != "")
                ]
                if not _non_empty.empty:
                    desc = str(_non_empty.iloc[0]["BUSINESS_DESCRIPTION"])
        if desc:
            context_parts.append(f"Feature description: {desc}")
            _docs_used.append("BD_COLUMNS")
        if entity:
            context_parts.append(f"Entity (granularity): {entity}")
        if view_name:
            # Also pull all other features documented on the same process view
            # to give the LLM broader context about sibling features
            sibling_df = _query_bd_columns(table_name=view_name)
            col_list = []
            for _, crow in sibling_df.iterrows():
                col_desc = crow.get("BUSINESS_DESCRIPTION", "") or ""
                col_list.append({"name": crow["COLUMN_NAME"], "description": col_desc})
                if crow["COLUMN_NAME"].upper() != object_name.upper() and col_desc:
                    context_parts.append(f"Related feature {crow['COLUMN_NAME']}: {col_desc}")
            if not sibling_df.empty and "BD_COLUMNS" not in _docs_used:
                _docs_used.append("BD_COLUMNS")
            # Process-level overview from objects table
            objects_df = _query_bd_objects(object_name=view_name)
            if not objects_df.empty:
                proc_desc = objects_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or ""
                if proc_desc:
                    context_parts.append(f"Process overview: {proc_desc}")
                    _docs_used.append("BD_OBJECTS")
            # Sections (OVERVIEW, etc.) for this process view
            sections_df = _query_bd_sections(object_name=view_name)
            if not sections_df.empty:
                _used_secs = sorted(sections_df["SECTION_NAME"].dropna().unique().tolist())
                _docs_used.append(f"BD_SECTIONS[{', '.join(_used_secs)}]")
            for _, srow in sections_df.iterrows():
                content = srow.get("SECTION_CONTENT", "") or ""
                if content:
                    context_parts.append(f"[{srow['SECTION_NAME']}]: {content}")
        else:
            col_list = []
    else:
        col_list = []

    # ── Secondary path: column-name lookup across all registered tables/views ──
    # Handles columns that are NOT features (e.g. dimension columns, keys, derived
    # columns documented in BD_COLUMNS but not registered in the feature catalog).
    # hint_table_name (populated from a prior EXPLAIN turn) narrows the search to
    # the specific source table so the right description is returned immediately.
    if not context_parts:
        col_matches = _query_bd_columns(column_name=object_name)
        # Prefer rows from the hinted table when provided
        if hint_table_name and not col_matches.empty:
            filtered = col_matches[col_matches["TABLE_NAME"].str.upper() == hint_table_name.upper()]
            if not filtered.empty:
                col_matches = filtered
        if not col_matches.empty:
            if "BD_COLUMNS" not in _docs_used:
                _docs_used.append("BD_COLUMNS")
            for _, crow in col_matches.iterrows():
                col_desc = crow.get("BUSINESS_DESCRIPTION", "") or ""
                table_name = crow.get("TABLE_NAME", "") or ""
                db_name = crow.get("DATABASE_NAME", "") or ""
                fq_table = f"{db_name}.{table_name}" if db_name and table_name else table_name
                if col_desc:
                    context_parts.append(f"Column '{object_name}' in {fq_table}: {col_desc}")
                col_list.append({"name": object_name, "table": fq_table, "description": col_desc})
                # Pull parent table/view description for extra context
                if table_name:
                    obj_df = _query_bd_objects(object_name=table_name)
                    if not obj_df.empty:
                        obj_desc = obj_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or ""
                        if obj_desc:
                            context_parts.append(f"Parent table/view '{fq_table}': {obj_desc}")
                            if "BD_OBJECTS" not in _docs_used:
                                _docs_used.append("BD_OBJECTS")

    # ── Quaternary path: dataset-level lookup (object_name is a dataset/view) ──
    if not context_parts:
        objects_df = _query_bd_objects(object_name=object_name)
        sections_df = _query_bd_sections(object_name=object_name)
        if not objects_df.empty:
            desc = objects_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or ""
            if desc:
                context_parts.append(f"Business description: {desc}")
                _docs_used.append("BD_OBJECTS")
        if not sections_df.empty:
            _used_secs = sorted(sections_df["SECTION_NAME"].dropna().unique().tolist())
            _docs_used.append(f"BD_SECTIONS[{', '.join(_used_secs)}]")
        for _, srow in sections_df.iterrows():
            content = srow.get("SECTION_CONTENT", "") or ""
            if content:
                context_parts.append(f"[{srow['SECTION_NAME']}]: {content}")
        col_df = _query_bd_columns(table_name=object_name)
        if not col_df.empty and "BD_COLUMNS" not in _docs_used:
            _docs_used.append("BD_COLUMNS")
        for _, crow in col_df.iterrows():
            col_desc = crow.get("BUSINESS_DESCRIPTION", "") or ""
            col_list.append({"name": crow["COLUMN_NAME"], "description": col_desc})
            if col_desc:
                context_parts.append(f"Column {crow['COLUMN_NAME']}: {col_desc}")

    # ── Quinary path: vector search fallback ──────────────────────────────
    if not context_parts:
        vector_ctx, resolved_name = _vector_search_context(object_name)
        if not vector_ctx:
            # ── Senary path: catalog-only fallback ────────────────────────
            # Feature IS registered but has no documentation anywhere.
            # Surface what the catalog knows rather than returning an opaque error.
            if _resolved_triplet and (_resolved_triplet.get("entity_name") or _resolved_triplet.get("view_name")):
                _entity_fb = _resolved_triplet.get("entity_name", "")
                _view_fb   = _resolved_triplet.get("view_name", "")
                context_parts.append(f"This is a registered feature in entity '{_entity_fb}'." if _entity_fb
                                     else "This is a registered feature.")
                if _view_fb:
                    context_parts.append(f"It is produced by the process view '{_view_fb}'.")
                context_parts.append("No business documentation has been generated yet.")
                _docs_used.append("FEATURE_CATALOG_ONLY")
            else:
                return {
                    "object_name": object_name,
                    "explanation": f"No documentation found for **{object_name}**.",
                    "columns": col_list,
                    "docs_sources": [],
                }
        else:
            context_parts.append(vector_ctx)
            _docs_used.append("VECTOR_INDEX")
            if resolved_name:
                object_name = resolved_name
                _resolved_triplet = {"feature_name": resolved_name, "entity_name": "", "process_id": "", "view_name": ""}

    context = "\n".join(context_parts)

    # Guard: skip the LLM when no real documentation was found.
    # Structural-only entries (entity name, view name, catalog boilerplate) do not
    # justify an LLM explanation — it would hallucinate from the feature name alone.
    # We check context_parts rather than _docs_used because _docs_used["BD_COLUMNS"]
    # fires even when all sibling columns have empty BUSINESS_DESCRIPTION.
    _STRUCTURAL_PREFIXES = (
        "Entity (granularity):",
        "This is a registered feature",
        "It is produced by",
        "No business documentation has been generated yet.",
    )
    _has_real_docs = any(
        not p.startswith(_STRUCTURAL_PREFIXES)
        for p in context_parts
    )
    if not _has_real_docs:
        if _resolved_triplet:
            _entity_fb = _resolved_triplet.get("entity_name", "")
            _view_fb   = _resolved_triplet.get("view_name", "")
            _msg = f"**{object_name}** is a registered feature"
            if _entity_fb:
                _msg += f" in entity *{_entity_fb}*"
            if _view_fb:
                _msg += f" (process: `{_view_fb}`)"
            _msg += ", but no business documentation has been written for it yet."
        else:
            _msg = f"No documentation found for **{object_name}**."
        result = {"object_name": object_name, "explanation": _msg, "columns": col_list, "docs_sources": _docs_used}
        if _resolved_triplet and _resolved_triplet.get("feature_name"):
            result["resolved_triplet"] = _resolved_triplet
        return result

    catalog_only = "FEATURE_CATALOG_ONLY" in _docs_used
    if catalog_only:
        system_prompt = (
            "You are a feature store assistant. Only catalog registration metadata is available — "
            "no business documentation has been written yet for this feature. "
            "State what you know from the catalog (entity, process view) and clearly note that "
            "documentation is pending. Do NOT invent descriptions or business logic. "
            "Answer in the same language as the user's question.\n\n"
            f"Catalog information for '{object_name}':\n{context}"
        )
    else:
        system_prompt = (
        "You are a feature store documentation assistant. Explain the following feature, column, or dataset "
        "in plain business language. Cover: what it measures or represents, how it is computed (no SQL or "
        "technical details), inclusion/exclusion criteria, how to interpret values.\n"
        "Answer in the same language as the user's question.\n\n"
        f"Documentation for '{object_name}':\n{context}"
    )

    try:
        explanation = _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"skill_definition failed: {exc}") from exc

    result = {"object_name": object_name, "explanation": explanation, "columns": col_list, "docs_sources": _docs_used}
    if _resolved_triplet and _resolved_triplet.get("feature_name"):
        result["resolved_triplet"] = _resolved_triplet
    return result


def skill_definition_multi(
    question: str,
    feature_names: list,
    hint_entity_name: Optional[str] = None,
) -> dict:
    """Unified multi-feature definition using a shared context graph.

    Calls _build_multi_object_context() once to resolve all features and fetch
    shared documentation (process views, datasets, entities), then makes a single
    LLM call with the full unified context.  No consolidation pass needed.
    """
    shared = _build_multi_object_context(feature_names, hint_entity_name)

    context_parts: list = []

    for entity in shared["entity_names"]:
        context_parts.append(f"Entity (granularity): {entity}")

    for view_name, view_data in shared["shared_views"].items():
        view_bare = view_name.split(".")[-1] if "." in view_name else view_name
        if view_data["sections"]:
            context_parts.append(f"Process documentation for '{view_bare}':")
            for sec in view_data["sections"]:
                context_parts.append(f"  [{sec['SECTION_NAME']}] {sec['SECTION_CONTENT']}")

    for feat in shared["features"]:
        if not feat["found_in_catalog"]:
            context_parts.append(f"Feature '{feat['name']}': not found in feature catalog.")
        elif feat["has_description"]:
            context_parts.append(f"Feature '{feat['name']}': {feat['description']}")
        else:
            line = f"Feature '{feat['name']}': registered"
            if feat["entity_name"]:
                line += f" under entity {feat['entity_name']}"
            if feat["view_name"]:
                line += f", computed by process view {feat['view_name']}"
            line += " — no business description documented yet."
            context_parts.append(line)
        for ds_name in feat.get("dataset_names") or []:
            context_parts.append(f"  -> present in dataset: {ds_name}")

    for ds_name, ds_data in shared["shared_datasets"].items():
        if ds_data["bd_description"]:
            context_parts.append(f"Dataset '{ds_name}': {ds_data['bd_description']}")
        for sec in ds_data.get("sections") or []:
            context_parts.append(f"  [{sec['SECTION_NAME']}] {sec['SECTION_CONTENT']}")

    _UNDOCUMENTED_MARKERS = (
        "no business description documented yet",
        "not found in feature catalog",
    )
    _has_real_docs = any(
        not any(m in p for m in _UNDOCUMENTED_MARKERS)
        and not p.startswith(("Entity (granularity):", "Process documentation"))
        and not p.startswith("  ")   # indented continuation lines
        and p.strip()
        for p in context_parts
    )

    _context_graph = {
        "features": [
            {
                "name": f["name"],
                "found": f["found_in_catalog"],
                "entity": f["entity_name"],
                "view": f["view_name"],
                "has_description": f["has_description"],
                "datasets": f.get("dataset_names") or [],
            }
            for f in shared["features"]
        ],
        "shared_views": list(shared["shared_views"].keys()),
        "shared_datasets": list(shared["shared_datasets"].keys()),
    }

    if not _has_real_docs:
        lines = []
        for feat in shared["features"]:
            if not feat["found_in_catalog"]:
                lines.append(f"No documentation found for **{feat['name']}**.")
            else:
                msg = f"**{feat['name']}** is a registered feature"
                if feat["entity_name"]:
                    msg += f" in entity *{feat['entity_name']}*"
                if feat["view_name"]:
                    msg += f" (process: `{feat['view_name']}`)"
                msg += ", but no business documentation has been written for it yet."
                lines.append(msg)
        return {
            "object_name": ", ".join(feature_names),
            "explanation": "\n\n".join(lines),
            "_multi_object": True,
            "docs_sources": [],
            "context_graph": _context_graph,
        }

    context = "\n".join(context_parts)
    system_prompt = (
        "You are a data science assistant helping business users understand features in a "
        "feature store. You have been given shared context about multiple features: their "
        "entities, the processes that compute them, and the datasets they belong to.\n\n"
        "Write ONE coherent answer that:\n"
        "- Defines each feature using its documented description when available\n"
        "- Cross-references shared structure explicitly — e.g. 'both features are computed "
        "by the same process' or 'both appear in dataset DS_SCORING'\n"
        "- For features with no business description, clearly states they are not documented "
        "yet; you may mention their entity or process but must NOT invent a business meaning\n"
        "- Does NOT infer or guess business meaning from feature names or sibling names\n"
        "- Uses plain business language and is concise"
    )
    question_with_context = f"Context:\n{context}\n\nUser question: {question}"
    try:
        explanation = _llm_call(system_prompt, question_with_context)
    except Exception as exc:
        raise RuntimeError(f"skill_definition_multi failed: {exc}") from exc

    resolved_triplet = None
    for feat in reversed(shared["features"]):
        if feat["found_in_catalog"] and feat["process_id"]:
            resolved_triplet = {
                "feature_name": feat["name"],
                "entity_name": feat["entity_name"],
                "process_id": feat["process_id"],
                "view_name": feat["view_name"],
            }
            break

    result = {
        "object_name": ", ".join(feature_names),
        "explanation": explanation,
        "_multi_object": True,
        "docs_sources": ["SHARED_GRAPH"],
        "context_graph": _context_graph,
    }
    if resolved_triplet:
        result["resolved_triplet"] = resolved_triplet
    return result


def skill_usage(question: str, object_name: str) -> dict:
    """Advise a consumer on how to safely use a feature in their work.

    Args:
        question: User question about usage (Tableau, Excel, regulatory, etc.).
        object_name: Name of the feature or dataset.

    Returns:
        Dict with ``object_name`` and ``guidance``.
    """
    audience_df = _query_bd_sections(
        section_names=["INTENDED_AUDIENCE"], object_name=object_name
    )
    overview_df = _query_bd_sections(
        section_names=["OVERVIEW"], object_name=object_name
    )

    try:
        feature_cat = tdfs4ds.feature_catalog().to_pandas()
        feature_info = feature_cat[
            feature_cat["FEATURE_NAME"].str.upper() == object_name.upper()
        ]
    except Exception:
        feature_info = pd.DataFrame()

    context_parts = []
    _docs_used: list[str] = []
    if not overview_df.empty:
        content = overview_df.iloc[0].get("SECTION_CONTENT", "")
        if content:
            context_parts.append(f"Overview: {content}")
            _docs_used.append("BD_SECTIONS[OVERVIEW]")
    if not audience_df.empty:
        content = audience_df.iloc[0].get("SECTION_CONTENT", "")
        if content:
            context_parts.append(f"Intended audience: {content}")
            _docs_used.append("BD_SECTIONS[INTENDED_AUDIENCE]")
    if not feature_info.empty:
        _docs_used.append("FEATURE_CATALOG")
        row = feature_info.iloc[0]
        context_parts.append(f"Granularity (entity): {row.get('ENTITY_ID', 'N/A')}")
        context_parts.append(f"Domain: {row.get('DATA_DOMAIN', 'N/A')}")

    # Vector search fallback when SQL yields no context
    if not context_parts and feature_info.empty:
        vector_ctx, resolved_name = _vector_search_context(object_name)
        if not vector_ctx:
            return {"error": "documentation_not_available"}
        context_parts.append(vector_ctx)
        _docs_used.append("VECTOR_INDEX")
        if resolved_name:
            object_name = resolved_name

    context = "\n".join(context_parts)

    system_prompt = (
        "You are a feature store usage advisor. Help the user understand how to safely use "
        "this feature in their work (Tableau, Excel, regulatory reports, etc.).\n"
        "Cover: recommended granularity, usage limits, suitability for regulatory reporting, "
        "how to filter or aggregate.\n"
        "Answer in the same language as the user's question. No SQL or technical jargon.\n\n"
        f"Context for '{object_name}':\n{context}"
    )

    try:
        guidance = _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"skill_usage failed: {exc}") from exc

    return {"object_name": object_name, "guidance": guidance, "docs_sources": _docs_used}


def skill_freshness(question: str, object_name: str, hint_entity_name: Optional[str] = None) -> dict:
    """Tell the consumer whether a feature or dataset is up to date and reliable.

    Args:
        question: User question about freshness / reliability.
        object_name: Name of the feature or dataset.
        hint_entity_name: Entity name remembered from a previous turn — used to
            auto-disambiguate when the same feature name exists across entities.

    Returns:
        Dict with ``object_name``, ``last_successful_run``, ``days_since_update``,
        ``has_recent_failure``, and ``reliability_assessment``.
    """
    # Find the process_id linked to this object_name
    process_id = None
    diagnostic_steps: list[str] = []
    _docs_used: list[str] = []
    _resolved_triplet: Optional[dict] = None

    # Step 1: feature_catalog_with_docs chain — correct path to PROCESS_ID
    # (the raw feature catalog table has no PROCESS_ID column; the join with
    # the process catalog is done inside _get_feature_catalog_with_docs)
    try:
        feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
        if not feat_doc.empty:
            if len(feat_doc) > 1:
                # Auto-disambiguate using the entity remembered from a previous turn
                if hint_entity_name:
                    filtered = feat_doc[
                        feat_doc["ENTITY_NAME"].str.upper() == hint_entity_name.upper()
                    ]
                    if len(filtered) == 1:
                        feat_doc = filtered
                        diagnostic_steps.append(
                            f"feature_catalog_with_docs: disambiguated to entity "
                            f"'{hint_entity_name}' from context"
                        )
                    elif filtered.empty:
                        pass  # fall through to ambiguous_feature error below
                    else:
                        feat_doc = filtered  # still multiple, will be caught below
                if len(feat_doc) > 1:
                    entities = feat_doc["ENTITY_NAME"].dropna().unique().tolist()
                    return {
                        "error": "ambiguous_feature",
                        "object_name": object_name,
                        "entities": entities,
                    }
            _docs_used.append("FEATURE_CATALOG")
            process_id = str(feat_doc.iloc[0].get("PROCESS_ID") or "")
            _resolved_triplet = {
                "feature_name": str(feat_doc.iloc[0].get("FEATURE_NAME") or object_name),
                "entity_name": str(feat_doc.iloc[0].get("ENTITY_NAME") or ""),
                "process_id": str(process_id or ""),
                "view_name": str(feat_doc.iloc[0].get("VIEW_NAME") or ""),
            }
            if process_id:
                diagnostic_steps.append(
                    f"feature_catalog_with_docs: resolved process_id for '{object_name}'"
                )
            else:
                diagnostic_steps.append(
                    f"feature_catalog_with_docs: found feature but PROCESS_ID is null"
                )
        else:
            diagnostic_steps.append(
                f"feature_catalog_with_docs: no match for '{object_name}'"
            )
    except Exception as exc:
        diagnostic_steps.append(f"feature_catalog_with_docs: failed — {exc}")

    # Step 2: fall back to process catalog by VIEW_NAME
    if not process_id:
        try:
            process_cat = tdfs4ds.process_catalog().to_pandas()
            if "VIEW_NAME" not in process_cat.columns:
                diagnostic_steps.append(
                    f"process_catalog: VIEW_NAME column not found — columns are: {list(process_cat.columns)}"
                )
            else:
                match = process_cat[process_cat["VIEW_NAME"].str.upper() == object_name.upper()]
                if not match.empty:
                    process_id = match.iloc[0].get("PROCESS_ID")
                    _docs_used.append("PROCESS_CATALOG")
                    diagnostic_steps.append(
                        f"process_catalog: found '{object_name}' as VIEW_NAME, "
                        f"process_id={'set' if process_id else 'null'}"
                    )
                else:
                    available_views = sorted(process_cat["VIEW_NAME"].str.upper().dropna().tolist())
                    diagnostic_steps.append(
                        f"process_catalog: no match for '{object_name}' as VIEW_NAME "
                        f"— available: {available_views}"
                    )
        except Exception as exc:
            diagnostic_steps.append(f"process_catalog: query failed — {exc}")

    if not process_id:
        candidates = _fuzzy_match_feature(object_name)
        if candidates:
            return {
                "error": "feature_not_found_did_you_mean",
                "object_name": object_name,
                "candidates": candidates,
            }
        return {
            "error": "no_execution_history",
            "diagnostic": "; ".join(diagnostic_steps),
        }

    # Step 3: retrieve execution history
    try:
        followup = follow_up_report(process_id=process_id).to_pandas()
        _docs_used.append("PROCESS_FOLLOWUP")
        diagnostic_steps.append(f"follow_up_report: {len(followup)} row(s) returned")
    except Exception as exc:
        diagnostic_steps.append(f"follow_up_report: query failed — {exc}")
        return {
            "error": "no_execution_history",
            "diagnostic": "; ".join(diagnostic_steps),
        }

    if followup.empty:
        return {
            "error": "no_execution_history",
            "diagnostic": "; ".join(diagnostic_steps),
        }

    # Compute freshness metrics
    completed = followup[followup["STATUS"] == "COMPLETED"]
    last_successful_run = None
    days_since_update = None
    if not completed.empty:
        last_ts = pd.to_datetime(completed["START_DATETIME"]).max()
        last_successful_run = str(last_ts)
        days_since_update = (datetime.now(timezone.utc) - last_ts.to_pydatetime().replace(
            tzinfo=timezone.utc if last_ts.tzinfo is None else last_ts.tzinfo
        )).days

    has_recent_failure = bool(followup["STATUS"].str.startswith("FAIL").any())

    # Get overview for context
    overview_df = _query_bd_sections(section_names=["OVERVIEW"], object_name=object_name)
    overview_text = ""
    if not overview_df.empty:
        overview_text = overview_df.iloc[0].get("SECTION_CONTENT", "")
        if overview_text:
            _docs_used.append("BD_SECTIONS[OVERVIEW]")

    context = (
        f"Last successful run: {last_successful_run or 'never'}\n"
        f"Days since last update: {days_since_update if days_since_update is not None else 'N/A'}\n"
        f"Recent failures: {'yes' if has_recent_failure else 'no'}\n"
    )
    if overview_text:
        context += f"Overview: {overview_text}\n"

    system_prompt = (
        "You are a data reliability advisor. Based on the execution history below, "
        "provide a plain-language assessment of whether this feature is up to date and reliable.\n"
        "Answer in the same language as the user's question. No SQL or technical jargon.\n\n"
        f"Execution history for '{object_name}':\n{context}"
    )

    try:
        assessment = _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"skill_freshness failed: {exc}") from exc

    result = {
        "object_name": object_name,
        "last_successful_run": last_successful_run,
        "days_since_update": days_since_update,
        "has_recent_failure": has_recent_failure,
        "reliability_assessment": assessment,
        "docs_sources": _docs_used,
    }
    if _resolved_triplet and _resolved_triplet.get("feature_name"):
        result["resolved_triplet"] = _resolved_triplet
    return result


def skill_summary(question: str, domain: str = None, object_name: str = None) -> dict:
    """Give a high-level summary of available features for a domain or a specific dataset.

    When *object_name* resolves to a registered dataset, the response is scoped to that
    dataset's feature list and the resolved dataset context is returned in the result so
    the caller can persist it in agent state for follow-up EXPLAIN turns.

    Args:
        question: User question.
        domain: Therapeutic domain to filter by (optional).
        object_name: Dataset or feature name mentioned by the user (optional).

    Returns:
        Dict with ``domain``, ``total_features``, ``by_granularity``, ``themes_summary``.
    """
    # ── Dataset-specific branch ───────────────────────────────────────────
    if object_name:
        ds_info = _resolve_dataset(object_name)
        if ds_info:
            features = _get_dataset_with_features(ds_info["dataset_id"])
            total_features = len(features)
            _docs_used: list[str] = ["DATASET_CATALOG"]

            by_granularity: dict = {}
            feature_names_by_entity: dict = {}
            feature_names: list = []
            feature_lines: list[str] = []
            for f in features:
                fname = f["feature_name"]
                entity = f["entity_name"] or "N/A"
                desc = f["description"] or ""
                ftype = f["feature_type"] or ""
                feature_names.append(fname)
                feature_names_by_entity.setdefault(entity, []).append(fname)
                by_granularity[entity] = by_granularity.get(entity, 0) + 1
                line = f"- {fname} (entity: {entity}"
                if ftype:
                    line += f", type: {ftype}"
                line += ")"
                if desc:
                    line += f": {desc}"
                feature_lines.append(line)

            if any(f["description"] for f in features):
                _docs_used.append("BD_COLUMNS")

            # Dataset-level description from the business dictionary
            ds_name = ds_info["dataset_name"]
            ds_db = ds_info["dataset_database"]
            doc_parts: list[str] = []
            try:
                ds_obj_df = _query_bd_objects(object_name=ds_name)
                if not ds_obj_df.empty:
                    _docs_used.append("BD_OBJECTS")
                    for _, row in ds_obj_df.iterrows():
                        desc = row.get("BUSINESS_DESCRIPTION", "")
                        if desc:
                            doc_parts.append(f"Dataset description: {desc}")
                ds_sec_df = _query_bd_sections(object_name=ds_name,
                                               section_names=["OVERVIEW", "FEATURE_THEMES"])
                if not ds_sec_df.empty:
                    _used_secs = sorted(ds_sec_df["SECTION_NAME"].dropna().unique().tolist())
                    _docs_used.append(f"BD_SECTIONS[{', '.join(_used_secs)}]")
                    for _, row in ds_sec_df.iterrows():
                        content = row.get("SECTION_CONTENT", "")
                        if content:
                            doc_parts.append(f"{row['SECTION_NAME']}: {content}")
            except Exception:
                pass

            feature_list_block = "\n".join(feature_lines) if feature_lines else "(no features registered)"
            doc_block = "\n".join(doc_parts) if doc_parts else "(no dataset documentation)"
            granularity_str = ", ".join(f"{k}: {v}" for k, v in by_granularity.items()) or "N/A"

            system_prompt = (
                "You are a feature store summary assistant. The user wants to know what features "
                f"are in the dataset **{ds_db}.{ds_name}**.\n"
                "List ALL features by name and entity, grouped by entity if helpful.\n"
                "Include the description and type of each feature when available.\n"
                "Then add a brief thematic summary if documentation is available.\n"
                "Answer in the same language as the user's question. No SQL or technical jargon.\n\n"
                f"Dataset: {ds_db}.{ds_name}\n"
                f"Total features: {total_features}\n"
                f"Granularity breakdown: {granularity_str}\n\n"
                f"Feature list (name + entity + type + description):\n{feature_list_block}\n\n"
                f"Dataset documentation:\n{doc_block}"
            )
            try:
                themes_summary = _llm_call(system_prompt, question)
            except Exception as exc:
                raise RuntimeError(f"skill_summary (dataset) failed: {exc}") from exc

            return {
                "dataset_id": ds_info["dataset_id"],
                "dataset_name": ds_name,
                "dataset_database": ds_db,
                "domain": domain or "all",
                "total_features": total_features,
                "by_granularity": by_granularity,
                "feature_names": feature_names,
                "feature_names_by_entity": feature_names_by_entity,
                "themes_summary": themes_summary,
                # State-propagation fields consumed by node_skill_summary
                "resolved_dataset_id": ds_info["dataset_id"],
                "resolved_dataset_features": features,
                "docs_sources": _docs_used,
            }

    # ── Feature list with documentation from process business dictionary ──
    feat_doc = _get_feature_catalog_with_docs()
    total_features = len(feat_doc)
    _docs_used: list[str] = []

    by_granularity: dict = {}
    feature_names_by_entity: dict = {}
    feature_names: list = []
    feature_lines: list[str] = []
    if not feat_doc.empty:
        _docs_used.append("FEATURE_CATALOG")
        by_granularity = feat_doc["ENTITY_NAME"].value_counts().to_dict()
        for _, row in feat_doc.iterrows():
            name = row.get("FEATURE_NAME", "")
            entity = row.get("ENTITY_NAME", "N/A")
            desc = row.get("BUSINESS_DESCRIPTION", "") or ""
            if name:
                feature_names.append(name)
                feature_names_by_entity.setdefault(entity, []).append(name)
                line = f"- {name} (entity: {entity})"
                if desc:
                    line += f": {desc}"
                feature_lines.append(line)
        if feat_doc["BUSINESS_DESCRIPTION"].notna().any() and feat_doc["BUSINESS_DESCRIPTION"].ne("").any():
            _docs_used.append("BD_COLUMNS")

    # ── Business dictionary context (dataset themes + process overviews) ──
    sections_df = _query_bd_sections(section_names=["FEATURE_THEMES", "OVERVIEW"])
    objects_df = _query_bd_objects()

    if total_features == 0 and sections_df.empty and objects_df.empty:
        return {"error": "documentation_not_available"}

    doc_parts: list[str] = []
    if not sections_df.empty:
        _used_secs = sorted(sections_df["SECTION_NAME"].dropna().unique().tolist())
        _docs_used.append(f"BD_SECTIONS[{', '.join(_used_secs)}]")
        for _, row in sections_df.iterrows():
            content = row.get("SECTION_CONTENT", "")
            if content:
                doc_parts.append(f"{row['OBJECT_NAME']} [{row['SECTION_NAME']}]: {content}")
    if not objects_df.empty:
        _docs_used.append("BD_OBJECTS")
        for _, row in objects_df.iterrows():
            desc = row.get("BUSINESS_DESCRIPTION", "")
            if desc:
                doc_parts.append(f"{row['OBJECT_NAME']}: {desc}")

    feature_list_block = "\n".join(feature_lines) if feature_lines else "(no features registered)"
    doc_block = "\n".join(doc_parts) if doc_parts else "(no additional documentation)"
    granularity_str = ", ".join(f"{k}: {v}" for k, v in by_granularity.items()) or "N/A"

    system_prompt = (
        "You are a feature store summary assistant. The user wants to know what features "
        "are available. List ALL features by name and entity, grouped by entity if helpful.\n"
        "Include the description of each feature when available.\n"
        "Then add a brief thematic summary if documentation is available.\n"
        "Answer in the same language as the user's question. No SQL or technical jargon.\n\n"
        f"Domain: {domain or 'all'}\n"
        f"Total features: {total_features}\n"
        f"Granularity breakdown: {granularity_str}\n\n"
        f"Feature list (name + entity + description):\n{feature_list_block}\n\n"
        f"Additional documentation:\n{doc_block}"
    )

    try:
        themes_summary = _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"skill_summary failed: {exc}") from exc

    return {
        "domain": domain or "all",
        "total_features": total_features,
        "by_granularity": by_granularity,
        "feature_names": feature_names,
        "feature_names_by_entity": feature_names_by_entity,
        "themes_summary": themes_summary,
        "docs_sources": _docs_used,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Lineage & Explain helpers
# ═══════════════════════════════════════════════════════════════════════════

def _get_process_view(object_name: str):
    """Return the process VIEW_NAME registered for *object_name* (feature or view).

    Resolution order:
    1. _get_feature_catalog_with_docs chain (join feature → process catalog) → VIEW_NAME
    2. process_catalog (all domains) → FEATURE_NAMES comma list match → VIEW_NAME
    3. process_catalog (all domains) → exact VIEW_NAME match

    Args:
        object_name: Feature name or view name.

    Returns:
        - ``str`` VIEW_NAME on a unique match.
        - ``list[str]`` of ENTITY_NAME values when the feature matches multiple
          entities (caller must handle as an ambiguous-feature error).
        - ``None`` if not found at all.
    """
    # Guard: empty name would scan the entire catalog — bail out immediately.
    if not object_name:
        return None

    # ── Step 1: feature_catalog_with_docs chain → VIEW_NAME ──────────────
    # The feature catalog table has no PROCESS_ID column; the correct path is
    # get_list_entity → get_list_features → get_feature_versions (joins with
    # process catalog) which is already implemented in _get_feature_catalog_with_docs.
    try:
        feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
        if not feat_doc.empty:
            if len(feat_doc) > 1:
                # Feature exists for multiple entities — signal ambiguity to caller
                return feat_doc["ENTITY_NAME"].dropna().unique().tolist()
            view_name = feat_doc.iloc[0].get("VIEW_NAME")
            if view_name:
                return str(view_name)
    except Exception as exc:
        logger.warning("_get_process_view (step 1): %s", exc)

    # ── Step 2: process_catalog FEATURE_NAMES comma list ──────────────────
    try:
        proc_df = tdfs4ds.process_catalog(all_data_domains=True).to_pandas()
        if not proc_df.empty:
            if "FEATURE_NAMES" in proc_df.columns:
                upper = object_name.upper()
                mask = proc_df["FEATURE_NAMES"].apply(
                    lambda v: upper in [f.strip().upper() for f in str(v).split(",")]
                    if pd.notna(v) else False
                )
                match = proc_df[mask]
                if not match.empty:
                    return str(match.iloc[0]["VIEW_NAME"])

            # ── Step 3: exact VIEW_NAME match ──────────────────────────────
            if "VIEW_NAME" in proc_df.columns:
                match = proc_df[proc_df["VIEW_NAME"].str.upper() == object_name.upper()]
                if not match.empty:
                    return str(match.iloc[0]["VIEW_NAME"])
    except Exception as exc:
        logger.warning("_get_process_view (steps 2-3): %s", exc)

    return None


def _fuzzy_match_feature(object_name: str) -> list:
    """Return catalog feature names that are close (fuzzy) matches for *object_name*.

    Uses :func:`difflib.get_close_matches` against the full feature catalog
    (all data domains).  Only names with a similarity score >= 0.75 are returned,
    which catches single-character differences (missing/extra letter, transposition)
    without being too permissive.

    Args:
        object_name: The name as typed by the user (may contain a typo).

    Returns:
        List of up to 3 feature names from the catalog in their original case,
        ordered by similarity.  Empty list when no close match is found.
    """
    import difflib

    if not object_name:
        return []
    try:
        all_features = tdfs4ds.feature_catalog(all_data_domains=True).to_pandas()
        if all_features.empty or "FEATURE_NAME" not in all_features.columns:
            return []
        names = all_features["FEATURE_NAME"].dropna().unique().tolist()
        upper_to_orig = {n.upper(): n for n in names}
        matches = difflib.get_close_matches(
            object_name.upper(), list(upper_to_orig.keys()), n=3, cutoff=0.75
        )
        return [upper_to_orig[m] for m in matches]
    except Exception as exc:
        logger.warning("_fuzzy_match_feature(%s): %s", object_name, exc)
        return []


def _fetch_view_ddl(view_name: str) -> Optional[str]:
    """Fetch the DDL of a view via ``SHOW VIEW``.

    Args:
        view_name: Bare view name (no schema prefix needed — uses ``tdfs4ds.SCHEMA``).

    Returns:
        DDL text, or ``None`` on failure.
    """
    qualified = f'"{tdfs4ds.SCHEMA}"."{view_name}"'
    try:
        rows = tdml.execute_sql(f"SHOW VIEW {qualified};").fetchall()
        if rows:
            return rows[0][0].replace("\r", "\n")
    except Exception as exc:
        logger.warning("_fetch_view_ddl(%s) failed: %s", view_name, exc)
    return None


def skill_lineage(question: str, object_name: str, hint_view_name: Optional[str] = None) -> dict:
    """Return the upstream data dependencies of a feature or process view.

    Walks the dependency graph starting from the registered process view,
    and returns a structured list of upstream nodes (tables and views) with
    their types. Does not require LLM — the graph is deterministic.

    Args:
        question: User question (used to determine response language).
        object_name: Feature or view name.
        hint_view_name: Pre-resolved view name from a prior turn (skips catalog lookup).

    Returns:
        Dict with ``object_name``, ``process_view``, ``dependencies`` (list of
        ``{name, type, depth}``), ``plain_summary`` (LLM plain-language answer),
        and ``resolved_triplet`` when resolution succeeded.
    """
    from tdfs4ds.lineage.network import build_teradata_dependency_graph

    _resolved_triplet: Optional[dict] = None
    _correction_note: Optional[str] = None

    # Resolve process view — use hint from previous turn, or re-resolve
    if hint_view_name:
        process_view = hint_view_name
    else:
        try:
            feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
            if not feat_doc.empty and len(feat_doc) > 1:
                return {"error": "ambiguous_feature", "object_name": object_name, "entities": feat_doc["ENTITY_NAME"].dropna().unique().tolist()}
            if not feat_doc.empty:
                row = feat_doc.iloc[0]
                process_view = str(row.get("VIEW_NAME") or "")
                if process_view:
                    _resolved_triplet = {
                        "feature_name": str(row.get("FEATURE_NAME") or object_name),
                        "entity_name": str(row.get("ENTITY_NAME") or ""),
                        "process_id": str(row.get("PROCESS_ID") or ""),
                        "view_name": process_view,
                    }
            else:
                process_view = _get_process_view(object_name)
        except Exception as exc:
            logger.warning("skill_lineage: feat_doc lookup failed — %s", exc)
            process_view = _get_process_view(object_name)

    if isinstance(process_view, list):
        return {"error": "ambiguous_feature", "object_name": object_name, "entities": process_view}
    if not process_view:
        candidates = _fuzzy_match_feature(object_name)
        if not candidates:
            return {"error": "process_view_not_found", "object_name": object_name}
        if len(candidates) == 1:
            corrected = candidates[0]
            process_view = _get_process_view(corrected)
            if not process_view or isinstance(process_view, list):
                return {"error": "feature_not_found_did_you_mean", "object_name": object_name, "candidates": candidates}
            _correction_note = f"'{object_name}' was not found — answered for the closest match '{corrected}'."
            object_name = corrected
        else:
            return {"error": "feature_not_found_did_you_mean", "object_name": object_name, "candidates": candidates}

    # Strip schema prefix if present (view_name may be '"schema"."view"')
    bare_view = process_view.strip('"').split('"."')[-1] if '"."' in process_view else process_view

    seed_sql = f'SELECT * FROM "{tdfs4ds.SCHEMA}"."{bare_view}"'

    try:
        graph = build_teradata_dependency_graph(
            seed_sql,
            default_database=tdfs4ds.SCHEMA,
            store_ddl=False,
            stop_at_feature_store_datasets=False,
            expand_datasets_via_process_catalog=False,
        )
    except Exception as exc:
        return {"error": f"lineage_failed: {exc}", "object_name": object_name}

    _docs_used: list[str] = ["FEATURE_CATALOG", "LINEAGE_GRAPH (SHOW VIEW)"]
    nodes = graph.get("nodes", {})
    edges = graph.get("edges", [])

    # BFS to assign depth levels starting from the root view
    root = bare_view.upper()
    depth_map: dict[str, int] = {}
    queue = [(bare_view, 0)]
    visited: set[str] = set()
    while queue:
        node, d = queue.pop(0)
        key = node.upper()
        if key in visited:
            continue
        visited.add(key)
        depth_map[key] = d
        for parent, child in edges:
            if parent.upper() == key:
                queue.append((child, d + 1))

    # Build dependency list (exclude the root itself)
    dependencies = []
    for node_name, node_info in nodes.items():
        key = node_name.upper()
        if key == root or bare_view.upper() in key:
            continue
        obj_part = node_name.strip('"').split('"."')[-1] if '"."' in node_name else node_name
        dependencies.append({
            "name": obj_part,
            "type": node_info.get("object_type", "unknown") if isinstance(node_info, dict) else getattr(node_info, "object_type", "unknown"),
            "depth": depth_map.get(key, -1),
            "description": "",  # filled below after business dictionary lookup
        })

    dependencies.sort(key=lambda x: x["depth"])

    # Enrich each dependency node with its business description from the dictionary
    dep_descriptions: dict[str, str] = {}
    _bd_objects_hit = False
    _bd_sections_hit = False
    for dep in dependencies:
        node_name = dep["name"]
        desc = ""
        try:
            obj_df = _query_bd_objects(object_name=node_name)
            if not obj_df.empty:
                desc = str(obj_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or "")
                if desc:
                    _bd_objects_hit = True
            if not desc:
                sec_df = _query_bd_sections(section_names=["OVERVIEW"], object_name=node_name)
                if not sec_df.empty:
                    overview = str(sec_df.iloc[0].get("SECTION_CONTENT", "") or "")
                    if overview:
                        desc = overview[:400]
                        _bd_sections_hit = True
        except Exception:
            pass
        dep_descriptions[node_name] = desc

    # Also look up the process view's own documentation for context
    process_view_desc = ""
    try:
        pv_df = _query_bd_objects(object_name=bare_view)
        if not pv_df.empty:
            process_view_desc = str(pv_df.iloc[0].get("BUSINESS_DESCRIPTION", "") or "")
            if process_view_desc:
                _bd_objects_hit = True
        if not process_view_desc:
            pv_sec = _query_bd_sections(section_names=["OVERVIEW"], object_name=bare_view)
            if not pv_sec.empty:
                process_view_desc = str(pv_sec.iloc[0].get("SECTION_CONTENT", "") or "")[:400]
                if process_view_desc:
                    _bd_sections_hit = True
    except Exception:
        pass

    if _bd_objects_hit:
        _docs_used.append("BD_OBJECTS")
    if _bd_sections_hit:
        _docs_used.append("BD_SECTIONS[OVERVIEW]")

    # Backfill descriptions into the dependency list (also surfaced in trace panel)
    for d in dependencies:
        d["description"] = dep_descriptions.get(d["name"], "")

    # Build enriched dependency lines
    dep_line_parts = []
    for d in dependencies:
        node_name = d["name"]
        line = f"  {'  ' * d['depth']}- {node_name} ({d['type']})"
        node_desc = dep_descriptions.get(node_name, "")
        if node_desc:
            line += f": {node_desc}"
        dep_line_parts.append(line)
    dep_lines = "\n".join(dep_line_parts) or "  (no upstream dependencies found)"

    process_view_context = (
        f"Process description: {process_view_desc}\n" if process_view_desc else ""
    )

    system_prompt = (
        "You are a data lineage advisor for business users. Explain in plain language "
        "where a feature's data comes from, based on the dependency tree below.\n"
        "When business descriptions are available for upstream sources, use them to explain "
        "the data provenance in meaningful business terms rather than technical names.\n"
        "Answer in the same language as the user's question.\n\n"
        f"Feature: {object_name}\n"
        f"Process view: {bare_view}\n"
        f"{process_view_context}"
        f"Upstream dependencies:\n{dep_lines}"
    )

    try:
        plain_summary = _llm_call(system_prompt, question)
    except Exception as exc:
        plain_summary = f"(LLM summary failed: {exc})"

    result = {
        "object_name": object_name,
        "process_view": bare_view,
        "dependencies": dependencies,
        "plain_summary": plain_summary,
        "docs_sources": _docs_used,
    }
    if _correction_note:
        result["correction_note"] = _correction_note
    if _resolved_triplet:
        result["resolved_triplet"] = _resolved_triplet
    elif bare_view:
        result["resolved_triplet"] = {"feature_name": object_name, "entity_name": "", "process_id": "", "view_name": bare_view}
    return result


def _skill_explain_multi(question: str, features_list: list) -> dict:
    """Explain how multiple features are calculated in a single LLM call.

    Args:
        question: User question.
        features_list: List of ``{feature_name, entity_name, view_name, description}`` dicts.

    Returns:
        Dict with ``explanation`` (plain-text multi-feature answer) and ``features_explained``.
    """
    ddl_blocks: list[str] = []
    features_explained: list[str] = []
    _docs_used = ["FEATURE_CATALOG"]

    for f in features_list:
        fname = f.get("feature_name", "")
        view = f.get("view_name", "")
        entity = f.get("entity_name", "")
        if not view:
            continue
        bare = view.strip('"').split('"."')[-1] if '"."' in view else view
        ddl = _fetch_view_ddl(bare)
        if not ddl:
            continue
        header = f"### {fname}"
        if entity:
            header += f" (entity: {entity})"
        ddl_blocks.append(f"{header}\n```sql\n{ddl}\n```")
        features_explained.append(fname)

    if not ddl_blocks:
        return {"error": "ddl_not_available", "features_explained": []}

    _docs_used.append("SHOW_VIEW (DDL)")
    feature_block = "\n\n".join(ddl_blocks)

    system_prompt = (
        "You are a feature engineering advisor. You are given the SQL definitions of several "
        "feature engineering process views.\n\n"
        "For each feature, provide:\n"
        "1. A plain business-language explanation (no SQL, no table/column names), max 4 sentences.\n"
        "2. The SQL expression that computes the feature (drill down through nested subqueries if needed).\n\n"
        "Format your response as a structured list, one section per feature, using the feature name as a header.\n"
        "Answer in the same language as the user's question.\n\n"
        f"Features to explain:\n{feature_block}"
    )
    try:
        explanation = _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"_skill_explain_multi failed: {exc}") from exc

    return {
        "explanation": explanation,
        "features_explained": features_explained,
        "docs_sources": _docs_used,
    }


def skill_explain(question: str, object_name: str, hint_view_name: Optional[str] = None,
                  hint_dataset_features: Optional[list] = None) -> dict:
    """Explain how a feature is calculated by reading its process view DDL.

    Fetches the SQL definition of the registered process view and asks the LLM
    to translate the logic into plain business language — no SQL jargon.

    When *hint_dataset_features* is provided and *object_name* is empty, explains
    all features from the current dataset context (up to 10) in a single LLM call.

    When *object_name* contains comma-separated feature names, explains each one.

    Args:
        question: User question.
        object_name: Feature or view name. May be comma-separated for multiple features.
        hint_view_name: Pre-resolved view name from a prior turn (skips catalog lookup).
        hint_dataset_features: Feature list from a prior SUMMARY turn on a dataset.

    Returns:
        Dict with ``object_name``, ``process_view``, ``explanation``, and ``resolved_triplet``.
    """
    # ── Multi-feature branch ──────────────────────────────────────────────
    features_to_explain: list = []
    if not object_name and hint_dataset_features:
        features_to_explain = hint_dataset_features[:10]
    elif object_name and "," in object_name:
        names = [n.strip() for n in object_name.split(",") if n.strip()]
        try:
            feat_doc = _get_feature_catalog_with_docs()
        except Exception:
            feat_doc = pd.DataFrame()
        for name in names:
            if not feat_doc.empty:
                match = feat_doc[feat_doc["FEATURE_NAME"].str.upper() == name.upper()]
                if not match.empty:
                    r = match.iloc[0]
                    features_to_explain.append({
                        "feature_name": str(r.get("FEATURE_NAME", name)),
                        "entity_name": str(r.get("ENTITY_NAME", "")),
                        "view_name": str(r.get("VIEW_NAME", "")),
                        "description": str(r.get("BUSINESS_DESCRIPTION", "") or ""),
                    })
    if features_to_explain:
        return _skill_explain_multi(question, features_to_explain)
    _resolved_triplet: Optional[dict] = None
    _correction_note: Optional[str] = None

    # Resolve process view — use hint from previous turn, or re-resolve
    if hint_view_name:
        process_view = hint_view_name
    else:
        try:
            feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
            if not feat_doc.empty and len(feat_doc) > 1:
                return {"error": "ambiguous_feature", "object_name": object_name, "entities": feat_doc["ENTITY_NAME"].dropna().unique().tolist()}
            if not feat_doc.empty:
                row = feat_doc.iloc[0]
                process_view = str(row.get("VIEW_NAME") or "")
                if process_view:
                    _resolved_triplet = {
                        "feature_name": str(row.get("FEATURE_NAME") or object_name),
                        "entity_name": str(row.get("ENTITY_NAME") or ""),
                        "process_id": str(row.get("PROCESS_ID") or ""),
                        "view_name": process_view,
                    }
            else:
                process_view = _get_process_view(object_name)
        except Exception as exc:
            logger.warning("skill_explain: feat_doc lookup failed — %s", exc)
            process_view = _get_process_view(object_name)

    if isinstance(process_view, list):
        return {"error": "ambiguous_feature", "object_name": object_name, "entities": process_view}
    if not process_view:
        candidates = _fuzzy_match_feature(object_name)
        if not candidates:
            return {"error": "process_view_not_found", "object_name": object_name}
        if len(candidates) == 1:
            corrected = candidates[0]
            process_view = _get_process_view(corrected)
            if not process_view or isinstance(process_view, list):
                return {"error": "feature_not_found_did_you_mean", "object_name": object_name, "candidates": candidates}
            _correction_note = f"'{object_name}' was not found — answered for the closest match '{corrected}'."
            object_name = corrected
        else:
            return {"error": "feature_not_found_did_you_mean", "object_name": object_name, "candidates": candidates}

    bare_view = process_view.strip('"').split('"."')[-1] if '"."' in process_view else process_view

    ddl = _fetch_view_ddl(bare_view)
    if not ddl:
        return {"error": "ddl_not_available", "object_name": object_name, "process_view": bare_view}

    _docs_used: list[str] = ["FEATURE_CATALOG", "SHOW_VIEW (DDL)"]

    # Detect explicit user requests
    _SQL_KEYWORDS = {"sql", "query", "code", "script", "requête", "syntax", "select"}
    _FORMULA_KEYWORDS = {"formula", "formule", "latex", "equation", "équation", "math", "mathématique"}
    _wants_sql = any(kw in question.lower() for kw in _SQL_KEYWORDS)
    _wants_latex = any(kw in question.lower() for kw in _FORMULA_KEYWORDS)

    system_prompt = (
        "You are a feature engineering advisor. You are given the SQL definition of a "
        "feature engineering process view.\n\n"
        "Your response must fill four fields:\n"
        "1. explanation — plain business language (no SQL, no table/column names), max 6 sentences, "
        "in the same language as the user's question\n"
        "2. calculation_sql — the SQL expression that computes this specific feature (drill down "
        "through nested subqueries if needed; return null only if truly unresolvable)\n"
        f"3. calculation_latex — LaTeX formula WITHOUT delimiters; populate {'YES, the user asked for it' if _wants_latex else 'NO, return null'}\n"
        "4. source_columns — for every distinct column referenced in the calculation expression, "
        "provide its bare name and the source table/view it comes from (resolve subquery aliases to "
        "the real base table wherever possible; bare names only, no schema prefix; omit primary-key "
        "columns; return null if no columns can be identified)\n\n"
        f"Feature: {object_name}\n"
        f"Process view SQL:\n{ddl}"
    )

    try:
        from langchain_core.messages import SystemMessage, HumanMessage as HMsg
        llm = _get_llm()
        output: ExplainOutput = llm.with_structured_output(ExplainOutput).invoke(
            [SystemMessage(content=system_prompt), HMsg(content=question)]
        )
    except Exception as exc:
        raise RuntimeError(f"skill_explain failed: {exc}") from exc

    result = {
        "object_name": object_name,
        "process_view": bare_view,
        "explanation": output.explanation,
        "docs_sources": _docs_used,
    }
    if _correction_note:
        result["correction_note"] = _correction_note
    if output.calculation_sql:
        result["calculation_sql"] = output.calculation_sql
    if output.calculation_latex:
        result["calculation_latex"] = output.calculation_latex
    if _wants_sql:
        result["process_view_sql"] = ddl.strip()
    if output.source_columns:
        result["source_columns"] = [
            {"column_name": sc.column_name, "source_table": sc.source_table}
            for sc in output.source_columns
        ]
    if _resolved_triplet:
        result["resolved_triplet"] = _resolved_triplet
    elif bare_view:
        result["resolved_triplet"] = {"feature_name": object_name, "entity_name": "", "process_id": "", "view_name": bare_view}
    return result


# ═══════════════════════════════════════════════════════════════════════════
# Dataset availability skill
# ═══════════════════════════════════════════════════════════════════════════

def skill_dataset(question: str, object_name: str) -> dict:
    """Find datasets that expose one or more features.

    When *object_name* contains comma-separated feature names, returns per-feature
    dataset lists plus an intersection of datasets that contain **all** features.

    Args:
        question: User question.
        object_name: Feature name(s) to look up, comma-separated for multi-feature.

    Returns:
        Single-feature: ``{status, object_name, datasets}`` as before.
        Multi-feature:  ``{status, object_names, per_feature, intersection}``.
        Status values: ``'found'``, ``'partial'`` (some features have no dataset),
        ``'no_dataset'``.
    """
    feature_names = [f.strip() for f in object_name.split(",") if f.strip()]

    if len(feature_names) <= 1:
        return _skill_dataset_single(object_name.strip())

    # ── Multi-feature path ────────────────────────────────────────────────
    try:
        all_features = tdfs4ds.get_dataset_features().to_pandas()
        cat = tdfs4ds.dataset_catalog().to_pandas()
    except Exception as exc:
        logger.warning("skill_dataset (multi): catalog query failed — %s", exc)
        return {"status": "no_dataset", "object_names": feature_names}

    def _ids_for_feature(fname: str) -> set:
        if all_features.empty or "FEATURE_NAME" not in all_features.columns:
            return set()
        match = all_features[all_features["FEATURE_NAME"].str.upper() == fname.upper()]
        return set(match["DATASET_ID"].dropna().unique().tolist())

    def _datasets_for_ids(ids) -> list:
        result = []
        for did in ids:
            row = cat[cat["DATASET_ID"] == did]
            if not row.empty:
                result.append({
                    "dataset_name": str(row.iloc[0].get("DATASET_NAME", "")),
                    "database": str(row.iloc[0].get("DATASET_DATABASE", tdfs4ds.SCHEMA)),
                    "dataset_id": str(did),
                })
        return result

    per_feature = []
    all_id_sets = []
    any_found = False
    for fname in feature_names:
        ids = _ids_for_feature(fname)
        datasets = _datasets_for_ids(ids)
        per_feature.append({
            "feature_name": fname,
            "datasets": datasets,
            "found": bool(datasets),
        })
        all_id_sets.append(ids)
        if datasets:
            any_found = True

    intersection_ids = all_id_sets[0].intersection(*all_id_sets[1:]) if all_id_sets else set()
    intersection = _datasets_for_ids(intersection_ids)

    all_found = all(pf["found"] for pf in per_feature)
    status = "found" if all_found else ("partial" if any_found else "no_dataset")

    return {
        "status": status,
        "object_names": feature_names,
        "per_feature": per_feature,
        "intersection": intersection,
    }


def _skill_dataset_single(object_name: str) -> dict:
    """Single-feature dataset lookup (original logic)."""
    try:
        all_features = tdfs4ds.get_dataset_features().to_pandas()
        if all_features.empty or "FEATURE_NAME" not in all_features.columns:
            return {"status": "no_dataset", "object_name": object_name}

        match = all_features[all_features["FEATURE_NAME"].str.upper() == object_name.upper()]
        if match.empty:
            return _skill_dataset_no_match(object_name)

        dataset_ids = match["DATASET_ID"].dropna().unique().tolist()
        cat = tdfs4ds.dataset_catalog().to_pandas()
        datasets = []
        for did in dataset_ids:
            row = cat[cat["DATASET_ID"] == did]
            if not row.empty:
                datasets.append({
                    "dataset_name": str(row.iloc[0].get("DATASET_NAME", "")),
                    "database": str(row.iloc[0].get("DATASET_DATABASE", tdfs4ds.SCHEMA)),
                    "dataset_id": str(did),
                })

        if not datasets:
            return _skill_dataset_no_match(object_name)

        return {"status": "found", "object_name": object_name, "datasets": datasets}
    except Exception as exc:
        logger.warning("skill_dataset(%s): %s", object_name, exc)
        return _skill_dataset_no_match(object_name)


def _skill_dataset_no_match(object_name: str) -> dict:
    """Build the 'no_dataset' result, enriched with entity and sibling features."""
    entity_name = ""
    all_features: list = []
    try:
        feat_doc = _get_feature_catalog_with_docs(feature_filter=object_name)
        if not feat_doc.empty:
            entity_name = str(feat_doc.iloc[0].get("ENTITY_NAME", "") or "")
        if entity_name:
            entity_features = _get_feature_catalog_with_docs(entity_filter=entity_name)
            for _, row in entity_features.iterrows():
                name = str(row.get("FEATURE_NAME", "") or "")
                desc = str(row.get("BUSINESS_DESCRIPTION", "") or "")
                if name:
                    all_features.append({"name": name, "description": desc})
    except Exception as exc:
        logger.warning("_skill_dataset_no_match(%s): entity lookup failed — %s", object_name, exc)
    return {
        "status": "no_dataset",
        "object_name": object_name,
        "entity_name": entity_name,
        "all_features": all_features,
        "feature_count": len(all_features),
    }


def skill_propose_features(
    use_case: str,
    entity_name: str,
    all_features: list,
    top_n: int = 20,
) -> dict:
    """Propose the most relevant features for a given use case.

    When ``all_features`` has more than ``top_n`` entries the LLM selects the
    most relevant ones.  When there are ``top_n`` or fewer, all are returned
    directly without an LLM call.

    Args:
        use_case: Free-text description of the business need (user's message).
        entity_name: Entity the features belong to (context for the LLM).
        all_features: Full list of ``{name, description}`` dicts.
        top_n: Maximum features to propose.

    Returns:
        Dict with ``status='features_proposed'``, ``proposed_features``,
        ``feature_count`` (total available), and ``include_all_offered`` (bool).
    """
    import json, re

    if len(all_features) <= top_n:
        return {
            "status": "features_proposed",
            "proposed_features": all_features,
            "feature_count": len(all_features),
            "include_all_offered": False,
        }

    feature_list_str = "\n".join(
        f"- {f['name']}: {f['description'] or '(no description)'}"
        for f in all_features
    )
    system_prompt = (
        f"You are a feature selection advisor for the entity '{entity_name}'.\n"
        f"Select the {top_n} most relevant features for the following use case.\n"
        f"Return ONLY a valid JSON array of feature name strings, no explanation.\n\n"
        f"Use case: {use_case}\n\n"
        f"Available features:\n{feature_list_str}"
    )
    try:
        raw = _llm_call(system_prompt, use_case)
        clean = re.sub(r"```[a-z]*\n?", "", raw).strip().strip("`").strip()
        selected_names = json.loads(clean)
        if not isinstance(selected_names, list):
            raise ValueError("expected list")
    except Exception as exc:
        logger.warning("skill_propose_features: LLM selection failed (%s) — falling back to first %d", exc, top_n)
        selected_names = [f["name"] for f in all_features[:top_n]]

    name_to_feature = {f["name"].upper(): f for f in all_features}
    proposed = [
        name_to_feature[n.upper()]
        for n in selected_names
        if n.upper() in name_to_feature
    ][:top_n]

    # Guarantee the originally requested feature is always included
    if all_features and not any(f["name"].upper() == all_features[0]["name"].upper() for f in proposed):
        proposed = [all_features[0]] + proposed[: top_n - 1]

    return {
        "status": "features_proposed",
        "proposed_features": proposed,
        "feature_count": len(all_features),
        "include_all_offered": True,
    }


def skill_check_dataset_name(proposed_name: str, feature_name: str) -> dict:
    """Check whether a proposed dataset name is already taken in the catalog.

    Args:
        proposed_name: Dataset name proposed by the user.
        feature_name: Feature for which the dataset is to be created (context only).

    Returns:
        Dict with ``status`` (``'name_available'`` or ``'name_taken'``),
        ``proposed_name``, and ``feature_name``.  When taken, also includes
        ``existing`` (list of ``{database, name}``).
    """
    try:
        cat = tdfs4ds.dataset_catalog().to_pandas()
        if cat.empty or "DATASET_NAME" not in cat.columns:
            return {
                "status": "name_available",
                "proposed_name": proposed_name,
                "feature_name": feature_name,
                "schema": tdfs4ds.SCHEMA,
            }

        match = cat[cat["DATASET_NAME"].str.upper() == proposed_name.strip().upper()]
        if not match.empty:
            existing = [
                {
                    "database": str(r.get("DATASET_DATABASE", "")),
                    "name": str(r.get("DATASET_NAME", "")),
                }
                for _, r in match.iterrows()
            ]
            return {"status": "name_taken", "proposed_name": proposed_name, "existing": existing}

        return {
            "status": "name_available",
            "proposed_name": proposed_name.strip(),
            "feature_name": feature_name,
            "schema": tdfs4ds.SCHEMA,
        }
    except Exception as exc:
        logger.warning("skill_check_dataset_name(%s): %s", proposed_name, exc)
        return {
            "status": "name_available",
            "proposed_name": proposed_name.strip(),
            "feature_name": feature_name,
            "schema": tdfs4ds.SCHEMA,
        }


def resolve_features_for_dataset(
    entity_name: str,
    feature_list: list,
) -> tuple:
    """Resolve a list of {name, description} feature dicts to the selected_features format.

    Calls get_feature_versions() and splits results into clean (single-version)
    and conflict (multi-version) groups.

    Args:
        entity_name: Entity the features belong to.
        feature_list: List of {name, description} dicts (as produced by skill_propose_features).

    Returns:
        Tuple of (selected_features_dict, conflicts_list).
        selected_features_dict: {feature_name: uuid_str} ready for build_dataset().
        conflicts_list: [{feature_name, versions: [{process_id, process_view_name}]}].
    """
    from tdfs4ds.feature_store.feature_query_retrieval import get_feature_versions

    feature_names = [f["name"] for f in feature_list]
    if not feature_names:
        return {}, []

    try:
        versions = get_feature_versions(entity_name, feature_names)
    except Exception as exc:
        logger.warning("resolve_features_for_dataset: get_feature_versions failed — %s", exc)
        return {}, []

    selected: dict = {}
    conflicts: list = []

    for feat_name, val in versions.items():
        if val is None:
            logger.debug("resolve_features_for_dataset: no version for %s — skipped", feat_name)
        elif isinstance(val, list):
            conflicts.append({"feature_name": feat_name, "versions": val})
        else:
            selected[feat_name] = val

    return selected, conflicts


def skill_build_dataset(
    entity_name: str,
    selected_features: dict,
    dataset_name: str,
    schema_name: Optional[str] = None,
    return_query: bool = False,
) -> dict:
    """Create a Teradata dataset view and auto-document it.

    Args:
        entity_name: Entity ID string (e.g. ``'CUSTOMER_ID'``).
        selected_features: ``{feature_name: uuid_str}`` from resolve_features_for_dataset.
        dataset_name: Validated, available view name for the new dataset.
        schema_name: Target schema. Defaults to ``tdfs4ds.SCHEMA``.
        return_query: When True, return the SQL string without executing (dry-run).

    Returns:
        Dict with ``status`` (``'dataset_created'``, ``'creation_failed'``, or
        ``'query_returned'``), ``dataset_name``, ``schema``, ``feature_count``,
        and ``doc_status`` (``'success'``, ``'failed'``, or ``'skipped'``).
    """
    if schema_name is None:
        schema_name = tdfs4ds.SCHEMA

    feature_count = len(selected_features)

    try:
        result = tdfs4ds.build_dataset(
            entity_id=entity_name,
            selected_features=selected_features,
            view_name=dataset_name,
            schema_name=schema_name,
            return_query=return_query,
        )
        if return_query:
            return {
                "status": "query_returned",
                "query": result,
                "dataset_name": dataset_name,
                "schema": schema_name,
                "feature_count": feature_count,
                "doc_status": "skipped",
            }
    except Exception as exc:
        logger.error("skill_build_dataset: build_dataset failed — %s", exc)
        return {
            "status": "creation_failed",
            "dataset_name": dataset_name,
            "schema": schema_name,
            "feature_count": feature_count,
            "error": str(exc),
        }

    doc_status = "skipped"
    if (tdfs4ds.INSTRUCT_MODEL_PROVIDER or "").strip():
        try:
            cat = tdfs4ds.dataset_catalog().to_pandas()
            row = cat[cat["DATASET_NAME"].str.upper() == dataset_name.upper()]
            if not row.empty:
                dataset_id = str(row.iloc[0]["DATASET_ID"])
                import tdfs4ds.genai
                tdfs4ds.genai.document_dataset_incremental(dataset_id, display=False, upload=True)
                doc_status = "success"
            else:
                logger.warning(
                    "skill_build_dataset: dataset '%s' not found in catalog after creation", dataset_name
                )
                doc_status = "failed"
        except Exception as exc:
            logger.warning("skill_build_dataset: document_dataset_incremental failed — %s", exc)
            doc_status = "failed"

    return {
        "status": "dataset_created",
        "dataset_name": dataset_name,
        "schema": schema_name,
        "feature_count": feature_count,
        "doc_status": doc_status,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Answer synthesizer
# ═══════════════════════════════════════════════════════════════════════════

def synthesize_answer(question: str, skill_result: dict, intent: str) -> str:
    """Convert structured skill output into a plain-language response.

    Args:
        question: Original user question.
        skill_result: Dict returned by the skill function.
        intent: The classified intent (SEARCH, DEFINITION, etc.).

    Returns:
        A natural language answer suitable for a non-technical business user.
    """
    import json

    # Handle errors
    if skill_result.get("error") == "documentation_not_available":
        error_system = (
            "The user asked about a feature or object that was not found in any catalog "
            "(feature store, dataset catalog, or business dictionary) and the vector index "
            "returned no results either. "
            "Respond in the same language as the user's question. "
            "Tell them this object name was not found in the feature store. "
            "Suggest verifying the name spelling or using a SEARCH query to find related features. "
            "Do not say 'contact the data team'. Be concise and factual."
        )
        return _llm_call(error_system, question)

    if skill_result.get("error") == "no_execution_history":
        error_system = (
            "The user asked about data freshness but no execution history exists. "
            "Respond in the same language as the user's question. "
            "Tell them that no execution records were found and suggest contacting the data team."
        )
        return _llm_call(error_system, question)

    if skill_result.get("error") == "process_view_not_found":
        obj = skill_result.get("object_name", "")
        error_system = (
            f"The user asked about the feature '{obj}' but no registered process view was found for it. "
            "Respond in the same language as the user's question. "
            f"Tell them that '{obj}' (exactly as provided) could not be located in the process catalog. "
            "Do NOT suggest alternative spellings or guess what the correct name might be — "
            "you do not know the catalog contents. Suggest verifying the exact feature name "
            "(including case and pluralisation) using the SEARCH intent, or contacting the data team."
        )
        return _llm_call(error_system, question)

    if skill_result.get("error") == "feature_not_found_did_you_mean":
        obj = skill_result.get("object_name", "")
        candidates = skill_result.get("candidates", [])
        candidate_list = ", ".join(f"'{c}'" for c in candidates)
        error_system = (
            f"The feature '{obj}' was not found in the catalog. "
            f"However, these similar feature name(s) exist in the catalog: {candidate_list}. "
            "Respond in the same language as the user's question. "
            f"Tell the user that '{obj}' was not found and list the similar name(s) found exactly as provided above. "
            "Do NOT explain what those features do — only list the names and ask the user to confirm."
        )
        return _llm_call(error_system, question)

    if skill_result.get("error") == "ddl_not_available":
        obj = skill_result.get("object_name", "")
        error_system = (
            f"The user asked how the feature '{obj}' is calculated but the view definition "
            "could not be retrieved. "
            "Respond in the same language as the user's question. "
            "Tell them the calculation logic is not accessible and suggest contacting the data team."
        )
        return _llm_call(error_system, question)

    if skill_result.get("error") == "ambiguous_feature":
        obj = skill_result.get("object_name", "")
        entities = skill_result.get("entities", [])
        entity_list = "\n".join(f"  - {e}" for e in entities)
        error_system = (
            f"The user asked about feature '{obj}' but it exists for multiple entity types "
            f"(different levels of granularity):\n{entity_list}\n"
            "Respond in the same language as the user's question. "
            "Do NOT guess or pick one entity. "
            "Ask the user to clarify which entity type they are interested in, "
            "and present the available options clearly."
        )
        return _llm_call(error_system, question)

    # ── DATASET skill responses ───────────────────────────────────────────────
    if intent == "DATASET":
        status = skill_result.get("status", "")

        # ── Multi-feature path ────────────────────────────────────────────
        if "per_feature" in skill_result:
            per_feature = skill_result.get("per_feature", [])
            intersection = skill_result.get("intersection", [])
            feature_names = skill_result.get("object_names", [])

            per_lines = []
            for pf in per_feature:
                fname = pf["feature_name"]
                if pf["found"]:
                    ds_str = ", ".join(f"{d['database']}.{d['dataset_name']}" for d in pf["datasets"])
                    per_lines.append(f"  - **{fname}**: found in {ds_str}")
                else:
                    per_lines.append(f"  - **{fname}**: not found in any registered dataset")

            intersection_str = (
                "\n".join(f"  - {d['database']}.{d['dataset_name']}" for d in intersection)
                if intersection else "  (none — no single dataset contains all requested features)"
            )
            per_str = "\n".join(per_lines)
            return _llm_call(
                f"The user asked about datasets containing these features: {', '.join(feature_names)}.\n\n"
                f"Per-feature results:\n{per_str}\n\n"
                f"Datasets containing ALL requested features:\n{intersection_str}\n\n"
                "Respond in the same language as the user's question. "
                "Present the per-feature results first, then the intersection. "
                "Use fully qualified dataset names (database.view_name). "
                "If no dataset contains all features together, say so clearly and suggest "
                "contacting the data team to create a combined dataset.",
                question,
            )

        # ── Single-feature path ───────────────────────────────────────────
        obj = skill_result.get("object_name", "")

        if status == "found":
            datasets = skill_result.get("datasets", [])
            dataset_list = "\n".join(
                f"  - {d['database']}.{d['dataset_name']}" for d in datasets
            )
            return _llm_call(
                f"The feature '{obj}' is exposed by the following dataset(s):\n{dataset_list}\n"
                "Respond in the same language as the user's question. "
                "Present each dataset as its fully qualified name (database.view_name). "
                "Tell the user they can use any of these datasets to access the feature.",
                question,
            )

        if status == "no_dataset":
            entity = skill_result.get("entity_name", "")
            feature_count = skill_result.get("feature_count", 0)
            entity_note = f" It belongs to the **{entity}** entity, which has {feature_count} registered features." if entity else ""
            return _llm_call(
                f"The feature '{obj}' is not currently exposed by any registered dataset.{entity_note} "
                "Respond in the same language as the user's question. "
                "Tell the user no dataset was found, mention the entity and how many features are available for it, "
                "and ask them to describe their use case so you can suggest the most relevant features to include.",
                question,
            )

        if status == "features_proposed":
            proposed = skill_result.get("proposed_features", [])
            total = skill_result.get("feature_count", len(proposed))
            include_all_offered = skill_result.get("include_all_offered", False)
            feature_lines = "\n".join(
                f"- **{f['name']}**" + (f": {f['description']}" if f.get("description") else "")
                for f in proposed
            )
            all_note = (
                f" I can also include all {total} features for this entity without listing them — "
                "just reply **'all'** instead of confirming."
            ) if include_all_offered else ""
            return _llm_call(
                f"Based on the use case, here are the {len(proposed)} suggested features:\n{feature_lines}\n"
                f"{all_note}\n"
                "Respond in the same language as the user's question. "
                "Present the feature list clearly. Ask the user to reply 'ok' to confirm this selection"
                + (" or 'all' to include all features instead." if include_all_offered else "."),
                question,
            )

        if status == "features_confirmed":
            include_all = skill_result.get("include_all", False)
            feature_count = skill_result.get("feature_count", 0)
            proposed = skill_result.get("proposed_features", [])
            if include_all:
                selection_note = f"all {feature_count} features for this entity"
            else:
                names = ", ".join(f["name"] for f in proposed)
                selection_note = f"the {len(proposed)} selected features ({names})"
            return _llm_call(
                f"The user confirmed they want {selection_note} in the dataset. "
                "Respond in the same language as the user's question. "
                "Confirm the selection briefly and ask what name they would like to give the dataset.",
                question,
            )

        if status == "name_available":
            name = skill_result.get("proposed_name", "")
            schema = skill_result.get("schema", "")
            include_all = skill_result.get("include_all", False)
            feature_count = skill_result.get("feature_count", 0)
            proposed = skill_result.get("proposed_features", [])
            if include_all:
                selection_note = f"all {feature_count} features for this entity"
            else:
                names = ", ".join(f["name"] for f in proposed)
                selection_note = f"{len(proposed)} features: {names}"
            doc_snippet = (
                f"dataset_id = tdfs4ds.dataset_catalog().to_pandas()"
                f".query(\"DATASET_NAME == '{name}'\").iloc[0]['DATASET_ID']\n"
                f"tdfs4ds.genai.document_dataset_incremental(dataset_id)"
            )
            return _llm_call(
                f"The dataset name '{name}' is available in schema '{schema}'. "
                f"It will contain {selection_note}. "
                "Respond in the same language as the user's question. "
                f"Confirm the name is available, recap the features that will be included, "
                f"and tell the user to ask their data team to:\n"
                f"1. Create the dataset using view_name='{name}' in schema '{schema}'.\n"
                f"2. Immediately after creation, document it with:\n{doc_snippet}\n"
                "Emphasise that the documentation step makes the dataset discoverable by the agent "
                "and by other business users.",
                question,
            )

        if status == "name_taken":
            name = skill_result.get("proposed_name", "")
            existing = skill_result.get("existing", [])
            existing_str = ", ".join(f"{e['database']}.{e['name']}" for e in existing)
            return _llm_call(
                f"The dataset name '{name}' is already taken ({existing_str}). "
                "Respond in the same language as the user's question. "
                "Tell the user the name is already in use and ask them to choose a different name.",
                question,
            )

        # fallback
        return _llm_call(
            "A dataset lookup encountered an unexpected issue. "
            "Respond in the same language as the user's question. "
            "Tell the user something went wrong and suggest contacting the data team.",
            question,
        )

    # ── BUILD_DATASET skill responses ─────────────────────────────────────────
    if intent == "BUILD_DATASET":
        status = skill_result.get("status", "")

        if status == "awaiting_entity_clarification":
            return (
                "I couldn't find any features in the feature catalog for the active domain. "
                "Could you tell me which entity or subject area you are working on? "
                "(e.g. **Customer**, **Transaction**, **Account**, …)"
            )

        if status == "no_features_found":
            entity_hint = skill_result.get("entity_hint", "")
            hint_clause = f" matching **{entity_hint}**" if entity_hint else ""
            return (
                f"I couldn't find any features{hint_clause} in the feature catalog. "
                "The feature store may not have been set up yet for this entity — "
                "please contact your data team to register the relevant feature engineering processes."
            )

        if status == "features_proposed":
            proposed = skill_result.get("proposed_features", [])
            total = skill_result.get("feature_count", len(proposed))
            include_all_offered = skill_result.get("include_all_offered", False)
            feature_lines = "\n".join(
                f"- **{f['name']}**" + (f": {f['description']}" if f.get("description") else "")
                for f in proposed
            )
            all_note = (
                f" I can also include all {total} features for this entity — "
                "just reply **'all'** instead of confirming."
            ) if include_all_offered else ""
            return _llm_call(
                f"Based on the use case, here are the {len(proposed)} suggested features:\n{feature_lines}\n"
                f"{all_note}\n"
                "Respond in the same language as the user's question. "
                "Present the feature list clearly. Ask the user to reply 'ok' to confirm this selection"
                + (" or 'all' to include all features instead." if include_all_offered else "."),
                question,
            )

        if status == "features_confirmed":
            include_all = skill_result.get("include_all", False)
            feature_count = skill_result.get("feature_count", 0)
            proposed = skill_result.get("proposed_features", [])
            if include_all:
                selection_note = f"all {feature_count} features for this entity"
            else:
                names = ", ".join(f["name"] for f in proposed)
                selection_note = f"the {len(proposed)} selected features ({names})"
            return _llm_call(
                f"The user confirmed they want {selection_note} in the dataset. "
                "Respond in the same language as the user's question. "
                "Confirm the selection briefly and ask what name they would like to give the dataset.",
                question,
            )

        if status == "version_conflict":
            conflicts = skill_result.get("conflicts", [])
            lines = []
            for c in conflicts:
                feat = c["feature_name"]
                options = "\n".join(
                    f"  {i + 1}. {v['process_view_name']}"
                    for i, v in enumerate(c["versions"])
                )
                lines.append(f"Feature **{feat}**:\n{options}")
            conflict_str = "\n\n".join(lines)
            return _llm_call(
                f"Some features have multiple registered versions — the user must choose one for each:\n\n"
                f"{conflict_str}\n\n"
                "Respond in the same language as the user's question. "
                "For each conflicting feature, list the available view names and ask the user "
                "to reply with the number (1, 2 …) or the view name. "
                "Do NOT proceed without user confirmation.",
                question,
            )

        if status == "name_available":
            name = skill_result.get("proposed_name", "")
            schema = skill_result.get("schema", "")
            feature_count = skill_result.get("feature_count", 0)
            return _llm_call(
                f"The dataset name '{name}' is available in schema '{schema}'. "
                f"It will contain {feature_count} feature(s). "
                "Respond in the same language as the user's question. "
                "Confirm the name is free, recap the number of features, and tell the user "
                "you are about to create the dataset now — they do not need to do anything else.",
                question,
            )

        if status == "name_taken":
            name = skill_result.get("proposed_name", "")
            existing = skill_result.get("existing", [])
            existing_str = ", ".join(f"{e['database']}.{e['name']}" for e in existing)
            return _llm_call(
                f"The dataset name '{name}' is already taken ({existing_str}). "
                "Respond in the same language as the user's question. "
                "Tell the user the name is already in use and ask them to choose a different name.",
                question,
            )

        if status == "dataset_created":
            dataset_name = skill_result.get("dataset_name", "")
            schema = skill_result.get("schema", "")
            feature_count = skill_result.get("feature_count", 0)
            doc_status = skill_result.get("doc_status", "skipped")
            doc_note = {
                "success": "Documentation was automatically generated and the dataset is now discoverable by the agent.",
                "failed": "Automatic documentation failed — ask the data team to run document_dataset_incremental() manually.",
                "skipped": "Documentation was not generated (no LLM provider configured).",
            }.get(doc_status, "")
            return _llm_call(
                f"The dataset '{dataset_name}' has been successfully created in schema '{schema}' "
                f"with {feature_count} feature(s). {doc_note} "
                "Respond in the same language as the user's question. "
                "Announce the success clearly, mention the schema and feature count, and include the documentation note.",
                question,
            )

        if status == "creation_failed":
            return _llm_call(
                "The dataset creation failed due to a technical error. "
                "Respond in the same language as the user's question. "
                "Tell the user the creation failed (do not expose raw error details), "
                "suggest contacting the data team, and offer to retry with a different dataset name.",
                question,
            )

        # fallback
        return _llm_call(
            "A BUILD_DATASET operation encountered an unexpected issue. "
            "Respond in the same language as the user's question. "
            "Tell the user something went wrong and suggest contacting the data team.",
            question,
        )

    # Skills that already produce a final answer — return it directly
    _direct_answer_key = {
        "LINEAGE": "plain_summary",
        "EXPLAIN": "explanation",
        "SUMMARY": "themes_summary",
        "FRESHNESS": "reliability_assessment",
        "DEFINITION": "explanation",
        "USAGE": "guidance",
    }
    if intent in _direct_answer_key:
        key = _direct_answer_key[intent]
        direct = skill_result.get(key)
        if direct:
            if skill_result.get("correction_note"):
                direct = f"_{skill_result['correction_note']}_\n\n" + direct
            if intent == "EXPLAIN":
                calc_sql = skill_result.get("calculation_sql")
                if calc_sql:
                    direct = direct + f"\n\n**Calculation:** `{calc_sql}`"
                calc_latex = skill_result.get("calculation_latex")
                if calc_latex:
                    direct = direct + f"\n\n$$\n{calc_latex}\n$$"
                sql_block = skill_result.get("process_view_sql")
                if sql_block:
                    direct = direct + f"\n\n**Full SQL query:**\n```sql\n{sql_block}\n```"
                # Show source variables so the user knows what they can drill into
                source_cols = skill_result.get("source_columns") or []
                if source_cols:
                    lines = []
                    for sc in source_cols:
                        col = sc.get("column_name", "")
                        tbl = sc.get("source_table", "")
                        if col and tbl:
                            lines.append(f"- `{col}` (from `{tbl}`)")
                        elif col:
                            lines.append(f"- `{col}`")
                    if lines:
                        direct = direct + "\n\n**Variables involved** _(ask me to define any of them)_:\n" + "\n".join(lines)
            return direct

    # DATA_QUERY / MCP_TOOLS — answer already synthesized by the react sub-agent
    if intent in ("MCP_TOOLS", "DATA_QUERY"):
        if skill_result.get("error_type") == "mcp_error":
            return (
                "An error occurred while calling the MCP server: "
                + skill_result.get("details", "unknown error")
            )
        return skill_result.get("answer", "The MCP tools returned no answer.")

    # Plugin / unknown intents — return "answer" directly to avoid a redundant LLM call
    if skill_result.get("answer"):
        return skill_result["answer"]

    # Build the result payload for the LLM; include available_context when
    # the structured matches list is empty but we have raw documentation.
    result_payload = {k: v for k, v in skill_result.items() if k != "available_context"}
    extra_context = skill_result.get("available_context", "")

    system_prompt = (
        "You are a feature store assistant for business users (data managers, study managers, "
        "regulatory affairs). Convert the structured data below into a clear, actionable "
        "natural language response.\n\n"
        "Rules:\n"
        "- Answer in the same language as the question (French or English)\n"
        "- No technical jargon: no SQL, no UUIDs, no table names, no process IDs\n"
        "- Concise: maximum 5 sentences for simple questions, structured list for summaries\n"
        "- If the data contains no useful information, say so clearly\n\n"
        f"Intent: {intent}\n"
        f"Skill result:\n{json.dumps(result_payload, ensure_ascii=False, default=str)}"
    )
    if extra_context:
        system_prompt += f"\n\nAdditional documentation:\n{extra_context}"

    try:
        return _llm_call(system_prompt, question)
    except Exception as exc:
        raise RuntimeError(f"synthesize_answer failed: {exc}") from exc


# ═══════════════════════════════════════════════════════════════════════════
# MCP skill
# ═══════════════════════════════════════════════════════════════════════════

def _get_forbidden_objects() -> tuple:
    """Return (forbidden_set, dataset_list) from the live feature store catalogs.

    forbidden_set contains uppercase bare names and DATABASE.TABLE forms for:
    - all registered process views
    - all feature storage tables

    dataset_list contains dataset names the MCP sub-agent is allowed to query.
    Returns (set(), []) on any catalog error.
    """
    forbidden: set = set()
    datasets: list = []

    try:
        proc = tdfs4ds.process_catalog(all_data_domains=True).to_pandas()
        if not proc.empty and "VIEW_NAME" in proc.columns:
            for v in proc["VIEW_NAME"].dropna().unique():
                forbidden.add(str(v).strip().upper())
    except Exception as exc:
        logger.warning("_get_forbidden_objects (process_catalog): %s", exc)

    try:
        feat = tdfs4ds.feature_catalog(all_data_domains=True).to_pandas()
        if not feat.empty:
            for col in ("FEATURE_TABLE",):
                if col in feat.columns:
                    for v in feat[col].dropna().unique():
                        forbidden.add(str(v).strip().upper())
            if "FEATURE_TABLE" in feat.columns and "FEATURE_DATABASE" in feat.columns:
                for _, row in feat[["FEATURE_TABLE", "FEATURE_DATABASE"]].drop_duplicates().iterrows():
                    tbl = str(row["FEATURE_TABLE"]).strip().upper()
                    db = str(row["FEATURE_DATABASE"]).strip().upper()
                    if tbl and db:
                        forbidden.add(f"{db}.{tbl}")
    except Exception as exc:
        logger.warning("_get_forbidden_objects (feature_catalog): %s", exc)

    try:
        ds_cat = tdfs4ds.dataset_catalog().to_pandas()
        if not ds_cat.empty and "DATASET_NAME" in ds_cat.columns:
            datasets = ds_cat["DATASET_NAME"].dropna().tolist()
    except Exception as exc:
        logger.warning("_get_forbidden_objects (dataset_catalog): %s", exc)

    return forbidden, datasets


def _rewrite_select_top20(sql: str) -> str:
    """Rewrite SELECT/SEL to SELECT TOP 20 / SEL TOP 20 when no TOP N is present."""
    import re
    return re.sub(
        r'\b(SELECT|SEL)\b(?!\s+TOP\s+\d+)',
        lambda m: m.group(0) + ' TOP 20',
        sql,
        flags=re.IGNORECASE,
    )


def _make_guarded_tools(tools: list, forbidden_objects: set) -> list:
    """Wrap MCP tools with feature-store query guards and a TOP 20 row cap.

    Returns new StructuredTool objects — StructuredTool is a Pydantic model so
    monkey-patching invoke/ainvoke is not possible; we create proper wrappers.

    Guards applied on every tool invocation:
    1. Reject inputs that reference forbidden feature store objects.
    2. Rewrite SELECT queries to SELECT TOP 20 when not already limited.
    3. Append a notice when the result appears to hit the 20-row limit.
    """
    import re
    from langchain_core.tools import StructuredTool

    forbidden_upper = frozenset(o.upper() for o in forbidden_objects)

    def _check_forbidden(input_str: str) -> str:
        upper = input_str.upper()
        for obj in forbidden_upper:
            if obj in upper:
                return (
                    f"REFUSED: Querying '{obj}' is not permitted. "
                    "Use a registered dataset from the dataset catalog instead."
                )
        return ""

    def _input_str(tool_input) -> str:
        if isinstance(tool_input, dict):
            return ' '.join(str(v) for v in tool_input.values())
        return str(tool_input)

    def _post(result: str) -> str:
        non_empty = [ln for ln in result.split('\n') if ln.strip()]
        if len(non_empty) >= 20:
            result += "\n\n⚠ Result limited to 20 rows. There may be additional rows."
        return result

    def _make_sync_fn(t):
        def guarded(**kwargs):
            s = _input_str(kwargs)
            refused = _check_forbidden(s)
            if refused:
                return refused
            if re.search(r'\b(SELECT|SEL)\b', s, re.IGNORECASE):
                kwargs = {k: (_rewrite_select_top20(v) if isinstance(v, str) else v)
                          for k, v in kwargs.items()}
            return _post(str(t.run(kwargs)))
        return guarded

    def _make_async_fn(t):
        async def guarded(**kwargs):
            s = _input_str(kwargs)
            refused = _check_forbidden(s)
            if refused:
                return refused
            if re.search(r'\b(SELECT|SEL)\b', s, re.IGNORECASE):
                kwargs = {k: (_rewrite_select_top20(v) if isinstance(v, str) else v)
                          for k, v in kwargs.items()}
            return _post(str(await t.arun(kwargs)))
        return guarded

    guarded_tools = []
    for tool in tools:
        guarded_tools.append(
            StructuredTool(
                name=tool.name,
                description=tool.description,
                args_schema=tool.args_schema,
                func=_make_sync_fn(tool),
                coroutine=_make_async_fn(tool),
            )
        )
    return guarded_tools


async def _skill_mcp_tools_async(
    question: str,
    server_url: str,
    forbidden_set: set,
    dataset_list: list,
    transport: str = "streamable_http",
) -> dict:
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langgraph.prebuilt import create_react_agent

    system_prompt = (
        "You are a data assistant with access to external tools.\n\n"
        "Hard rules:\n"
        "- NEVER issue SELECT statements against feature store process views or "
        "feature storage tables. If you detect such a request, refuse and explain.\n"
        "- When feature data is needed, ONLY query datasets registered in the "
        f"dataset catalog: {', '.join(dataset_list) if dataset_list else '(none available)'}.\n"
        "- ALWAYS limit SELECT queries to at most 20 rows (SELECT TOP 20). "
        "If the tool returns a row-limit warning, inform the user that only "
        "the first 20 rows are shown and there may be more."
    )

    client = MultiServerMCPClient(
        {"mcp_server": {"url": server_url, "transport": transport}}
    )
    tools = _make_guarded_tools(await client.get_tools(), forbidden_set)
    llm = _get_llm()
    agent = create_react_agent(llm, tools, prompt=system_prompt)
    from langchain_core.messages import HumanMessage
    result = await agent.ainvoke({"messages": [HumanMessage(content=question)]})
    answer = result["messages"][-1].content

    return {"answer": answer, "error_type": None}


def skill_mcp_tools(question: str, server_url: str, transport: str = "streamable_http") -> dict:
    """Delegate a question to external MCP server tools.

    Enforces feature-store query guards:
    - process views and feature storage tables are forbidden
    - SELECT queries are automatically capped to TOP 20
    - dataset catalog is offered as the approved data source

    Args:
        question: User question.
        server_url: MCP server endpoint URL.
        transport: MCP transport protocol — ``'streamable_http'`` (default, modern) or ``'sse'``.

    Returns:
        Dict with ``answer`` (str) and ``error_type`` (None or 'mcp_error').
    """
    import asyncio

    forbidden_set, dataset_list = _get_forbidden_objects()

    async def _run():
        return await _skill_mcp_tools_async(question, server_url, forbidden_set, dataset_list, transport=transport)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    try:
        if loop is not None and loop.is_running():
            # Jupyter / existing event loop — run in a worker thread
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(lambda: asyncio.run(_run())).result(timeout=120)
        else:
            return asyncio.run(_run())
    except Exception as exc:
        return {"answer": None, "error_type": "mcp_error", "details": str(exc)}


def node_skill_mcp_tools(state: dict) -> dict:
    """LangGraph node: delegate to MCP server tools."""
    server_url = tdfs4ds.MCP_SERVER_URL
    if not server_url:
        return {"skill_result": {"answer": None, "error_type": "mcp_error", "details": "MCP_SERVER_URL is not configured."}}
    transport = getattr(tdfs4ds, "MCP_SERVER_TRANSPORT", "streamable_http") or "streamable_http"
    try:
        result = skill_mcp_tools(state["question"], server_url, transport=transport)
    except Exception as exc:
        result = {"answer": None, "error_type": "mcp_error", "details": str(exc)}
    return {"skill_result": result}
