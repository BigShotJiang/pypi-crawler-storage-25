"""
LangGraph-based orchestration for the tdfs4ds query optimizer agent.

Flow::

    START -> node_classify -> [conditional on intent] -> node_skill_* -> node_synthesize -> END
"""

from __future__ import annotations

from typing import Annotated, Optional, Union

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from typing_extensions import TypedDict


# ═══════════════════════════════════════════════════════════════════════════
# State
# ═══════════════════════════════════════════════════════════════════════════

class QOState(TypedDict):
    question: str
    sql_query: Optional[str]
    process_id: Optional[str]
    intent: Optional[str]
    skill_result: Optional[dict]
    answer: Optional[str]
    messages: Annotated[list, add_messages]
    resolved_sql: Optional[str]         # persisted across turns
    resolved_process_id: Optional[str]  # persisted across turns


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _effective_sql(state: QOState) -> Optional[str]:
    return state.get("sql_query") or state.get("resolved_sql")


def _effective_process_id(state: QOState) -> Optional[str]:
    return state.get("process_id") or state.get("resolved_process_id")


def _persist_inputs(state: QOState) -> dict:
    """Build state update that remembers sql_query and process_id for next turns."""
    updates: dict = {}
    if state.get("sql_query"):
        updates["resolved_sql"] = state["sql_query"]
    if state.get("process_id"):
        updates["resolved_process_id"] = state["process_id"]
    return updates


# ═══════════════════════════════════════════════════════════════════════════
# Nodes
# ═══════════════════════════════════════════════════════════════════════════

def node_skill_explain(state: QOState) -> dict:
    """Execute the EXPLAIN analysis skill."""
    from tdfs4ds.genai.documentation import document_sql_query_explain

    sql = _effective_sql(state)
    pid = _effective_process_id(state)

    if not sql and pid:
        from tdfs4ds.process_store.process_store_catalog_management import get_process_info
        pinfo = get_process_info(pid)
        if pinfo:
            sql = pinfo.get("PROCESS_SQL")

    if not sql:
        result = {"error": "No SQL query or process_id provided. Pass sql_query or process_id."}
    else:
        result = document_sql_query_explain(sql_query=sql, classify=True)

    return {**_persist_inputs(state), "skill_result": result}


def node_skill_simplify(state: QOState) -> dict:
    """Execute the SQL simplification skill."""
    from tdfs4ds.agent.query_optimizer import skill_simplify_query

    result = skill_simplify_query(
        sql_query=_effective_sql(state),
        process_id=_effective_process_id(state),
    )
    return {**_persist_inputs(state), "skill_result": result}


def node_skill_optimize(state: QOState) -> dict:
    """Execute the full optimization pipeline skill."""
    from tdfs4ds.agent.query_optimizer import skill_optimize_query

    result = skill_optimize_query(
        sql_query=_effective_sql(state),
        process_id=_effective_process_id(state),
        user_request=state["question"],
    )
    return {**_persist_inputs(state), "skill_result": result}


def node_synthesize(state: QOState) -> dict:
    """Format the skill result as a human-readable answer."""
    result = state.get("skill_result") or {}
    intent = state.get("intent", "")

    if "error" in result:
        return {"answer": f"**Error**: {result['error']}"}

    if intent == "OPTIMIZE":
        answer = result.get("answer", "_No optimization report available._")

    elif intent == "SIMPLIFY":
        if result.get("simplified"):
            delta = (result.get("simplified_score") or 0) - (result.get("original_score") or 0)
            sign = "+" if delta > 0 else ""
            answer = (
                f"**Simplified**: yes — score {result.get('original_score')}/5 "
                f"→ {result.get('simplified_score')}/5 ({sign}{delta})\n\n"
                "The simplified SQL is available in `skill_result['simplified_sql']`."
            )
        else:
            answer = (
                f"**Simplified**: no — no structurally simpler form was found "
                f"(score {result.get('original_score')}/5 unchanged)."
            )

    elif intent == "EXPLAIN":
        parts: list[str] = []
        u = result.get("user_score")
        g = result.get("global_score")
        n_steps = result.get("n_steps")
        n_spool = result.get("n_spool_objects")
        if u is not None or g is not None:
            score_line = f"**Scores** — SQL quality: {u}/5 | Overall plan: {g}/5"
            if n_steps is not None:
                score_line += f" | Steps: {n_steps} | Spool objects: {n_spool}"
            parts.append(score_line)
        if result.get("explanation"):
            parts.append(f"\n{result['explanation']}")
        warnings = result.get("warnings") or []
        if warnings:
            parts.append("\n**Warnings**")
            for w in warnings:
                parts.append(f"- {w}")
        recs = result.get("recommendations") or []
        if recs:
            parts.append("\n**Recommendations**")
            for r in recs:
                parts.append(f"- {r}")
        answer = "\n".join(parts) if parts else "_No EXPLAIN analysis available._"

    else:
        answer = str(result)

    return {"answer": answer}


# ═══════════════════════════════════════════════════════════════════════════
# Routing
# ═══════════════════════════════════════════════════════════════════════════

_QO_INTENT_NODE_MAP = {
    "EXPLAIN":  node_skill_explain,
    "SIMPLIFY": node_skill_simplify,
    "OPTIMIZE": node_skill_optimize,
}


# ═══════════════════════════════════════════════════════════════════════════
# Graph builder
# ═══════════════════════════════════════════════════════════════════════════

def build_qo_graph():
    """Build and compile the LangGraph StateGraph for the query optimizer agent.

    The skill set is loaded from the ``qo-skill-*`` SKILL.md files bundled with
    the package (via :func:`tdfs4ds.query_optimizer_skill_catalog`).  Only skills
    whose ``intent`` is in ``_QO_INTENT_NODE_MAP`` are registered as graph nodes.

    Returns:
        A compiled LangGraph with MemorySaver checkpointer for multi-turn support.

    Raises:
        ValueError: When no query-optimizer skills are found in the package.
    """
    from tdfs4ds.cli import query_optimizer_skill_catalog
    from tdfs4ds.agent.consumer_agent import _build_intent_model, intent_classifier

    qo_skills = query_optimizer_skill_catalog()
    qo_skills = {k: v for k, v in qo_skills.items() if v.get("intent") in _QO_INTENT_NODE_MAP}

    if not qo_skills:
        raise ValueError(
            "No query-optimizer skills found. Ensure tdfs4ds/skills/qo-skill-*/SKILL.md "
            "files are present in the installed package."
        )

    available_intents   = [v["intent"] for v in qo_skills.values()]
    intent_descriptions = {v["intent"]: v["description"] for v in qo_skills.values() if "description" in v}
    IntentResultModel   = _build_intent_model(available_intents)

    node_names = {intent: f"skill_{intent.lower()}" for intent in available_intents}
    fallback   = node_names[available_intents[0]]

    def _node_classify(state: QOState) -> dict:
        result = intent_classifier(
            state["question"],
            intent_model=IntentResultModel,
            intent_descriptions=intent_descriptions,
        )
        return {"intent": result.intent}

    def _route_intent(state: QOState) -> str:
        return node_names.get(state.get("intent"), fallback)

    graph = StateGraph(QOState)
    graph.add_node("classify",   _node_classify)
    graph.add_node("synthesize", node_synthesize)

    for intent, node_name in node_names.items():
        graph.add_node(node_name, _QO_INTENT_NODE_MAP[intent])

    graph.set_entry_point("classify")
    graph.add_conditional_edges(
        "classify",
        _route_intent,
        {v: v for v in node_names.values()},
    )
    for node_name in node_names.values():
        graph.add_edge(node_name, "synthesize")
    graph.add_edge("synthesize", END)

    return graph.compile(checkpointer=MemorySaver())


# ═══════════════════════════════════════════════════════════════════════════
# Graph singleton
# ═══════════════════════════════════════════════════════════════════════════

_qo_graph_instance = None


def _get_qo_graph():
    """Return the shared compiled query optimizer graph, building it once."""
    global _qo_graph_instance
    if _qo_graph_instance is None:
        _qo_graph_instance = build_qo_graph()
    return _qo_graph_instance


def reset_query_optimizer_agent():
    """Clear the graph singleton cache.

    Call this after adding or removing ``qo-skill-*`` SKILL.md files so that
    the next :func:`query_optimizer_agent` call picks up the new skill set.
    """
    global _qo_graph_instance
    _qo_graph_instance = None


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

def query_optimizer_agent(
    question: str,
    sql_query: Optional[str] = None,
    process_id: Optional[str] = None,
    thread_id: str = "default",
    return_trace: bool = False,
) -> Union[str, tuple]:
    """Run the LangGraph query optimizer agent for a single conversational turn.

    The agent classifies the question into one of three intents (EXPLAIN /
    SIMPLIFY / OPTIMIZE) and routes to the corresponding skill.  Multi-turn
    context (``sql_query``, ``process_id``) is persisted across calls that
    share the same ``thread_id``.

    Args:
        question: Natural language description of the desired action, e.g.
            'Analyze this query for performance issues' or 'Optimize this SQL'.
        sql_query: Optional SQL string.  When provided it is remembered for
            follow-up turns on the same ``thread_id``.
        process_id: Optional process UUID (looked up in the process catalog to
            retrieve the SQL automatically).  Remembered across turns.
        thread_id: Conversation thread ID for multi-turn memory.
        return_trace: When True, returns ``(answer, skill_result)`` instead of
            just the answer string.

    Returns:
        Answer string, or ``(answer, skill_result)`` tuple when
        ``return_trace=True``.
    """
    graph = _get_qo_graph()
    result = graph.invoke(
        {
            "question": question,
            "sql_query": sql_query,
            "process_id": process_id,
            "messages": [HumanMessage(content=question)],
        },
        config={"configurable": {"thread_id": thread_id}},
    )
    answer = result.get("answer", "")
    if return_trace:
        return answer, result.get("skill_result")
    return answer
