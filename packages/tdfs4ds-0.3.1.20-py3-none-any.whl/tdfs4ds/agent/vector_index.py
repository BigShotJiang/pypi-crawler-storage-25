"""
Chroma-backed vector index for the tdfs4ds business dictionary.

Three collections mirror the three business dictionary tables:
- ``tdfs4ds_objects``  -> ``FS_BUSINESS_DICTIONARY_OBJECTS``
- ``tdfs4ds_sections`` -> ``FS_BUSINESS_DICTIONARY_SECTIONS``
- ``tdfs4ds_columns``  -> ``FS_BUSINESS_DICTIONARY_COLUMNS``
"""

from __future__ import annotations

import logging
from typing import List, Optional

import pandas as pd
import teradataml as tdml
from langchain_core.documents import Document
from langchain_chroma import Chroma

import chromadb

import tdfs4ds
from tdfs4ds.agent.embedding import get_embeddings

logger = logging.getLogger(__name__)

# ── Collection name constants ──────────────────────────────────────────────

_COLLECTION_OBJECTS = "tdfs4ds_objects"
_COLLECTION_SECTIONS = "tdfs4ds_sections"
_COLLECTION_COLUMNS = "tdfs4ds_columns"

_VALID_SOURCES = {"objects", "sections", "columns"}

_SOURCE_TO_COLLECTION = {
    "objects": _COLLECTION_OBJECTS,
    "sections": _COLLECTION_SECTIONS,
    "columns": _COLLECTION_COLUMNS,
}


# ── Chroma store factory ──────────────────────────────────────────────────

def _get_chroma_store(collection_name: str) -> Chroma:
    """Return a LangChain Chroma vector store for the given collection.

    Args:
        collection_name: Name of the Chroma collection.

    Returns:
        Chroma: A configured LangChain Chroma vector store.
    """
    embedding_fn = get_embeddings()
    metadata = {"hnsw:space": "cosine"}

    mode = (tdfs4ds.CHROMA_MODE or "local").lower()

    if mode == "server":
        client = chromadb.HttpClient(
            host=tdfs4ds.CHROMA_HOST,
            port=tdfs4ds.CHROMA_PORT,
        )
        return Chroma(
            collection_name=collection_name,
            embedding_function=embedding_fn,
            client=client,
            collection_metadata=metadata,
        )

    # Default: local persistent store
    return Chroma(
        collection_name=collection_name,
        embedding_function=embedding_fn,
        persist_directory=tdfs4ds.CHROMA_PATH,
        collection_metadata=metadata,
    )


# ── Helpers: fetch business dictionary rows ────────────────────────────────

def _fetch_objects() -> pd.DataFrame:
    """Fetch all rows from the business dictionary objects table.

    Uses execute_sql because CURRENT VALIDTIME must be at the outermost level.
    """
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, OBJECT_NAME, OBJECT_TYPE, "
        f"BUSINESS_DESCRIPTION FROM {tdfs4ds.SCHEMA}."
        f"{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}"
    )
    rows = tdml.execute_sql(query).fetchall()
    return pd.DataFrame(rows, columns=["DATABASE_NAME", "OBJECT_NAME", "OBJECT_TYPE", "BUSINESS_DESCRIPTION"])


def _fetch_sections() -> pd.DataFrame:
    """Fetch all rows from the business dictionary sections table."""
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, OBJECT_NAME, SECTION_NAME, "
        f"SECTION_CONTENT FROM {tdfs4ds.SCHEMA}."
        f"{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS}"
    )
    rows = tdml.execute_sql(query).fetchall()
    return pd.DataFrame(rows, columns=["DATABASE_NAME", "OBJECT_NAME", "SECTION_NAME", "SECTION_CONTENT"])


def _fetch_columns() -> pd.DataFrame:
    """Fetch all rows from the business dictionary columns table."""
    query = (
        f"CURRENT VALIDTIME SELECT DATABASE_NAME, TABLE_NAME, COLUMN_NAME, "
        f"BUSINESS_DESCRIPTION FROM {tdfs4ds.SCHEMA}."
        f"{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS}"
    )
    rows = tdml.execute_sql(query).fetchall()
    return pd.DataFrame(rows, columns=["DATABASE_NAME", "TABLE_NAME", "COLUMN_NAME", "BUSINESS_DESCRIPTION"])


# ── Document builders ──────────────────────────────────────────────────────

def _objects_to_docs(df: pd.DataFrame) -> tuple[list[Document], list[str]]:
    docs, ids = [], []
    for _, row in df.iterrows():
        text = row.get("BUSINESS_DESCRIPTION") or ""
        if not text.strip():
            continue
        doc_id = f"{row['DATABASE_NAME']}__{row['OBJECT_NAME']}"
        docs.append(Document(
            page_content=text,
            metadata={
                "database_name": row["DATABASE_NAME"],
                "object_name": row["OBJECT_NAME"],
                "object_type": row.get("OBJECT_TYPE", ""),
            },
        ))
        ids.append(doc_id)
    return docs, ids


def _sections_to_docs(df: pd.DataFrame) -> tuple[list[Document], list[str]]:
    docs, ids = [], []
    for _, row in df.iterrows():
        text = row.get("SECTION_CONTENT") or ""
        if not text.strip():
            continue
        doc_id = f"{row['DATABASE_NAME']}__{row['OBJECT_NAME']}__{row['SECTION_NAME']}"
        docs.append(Document(
            page_content=text,
            metadata={
                "database_name": row["DATABASE_NAME"],
                "object_name": row["OBJECT_NAME"],
                "section_name": row["SECTION_NAME"],
            },
        ))
        ids.append(doc_id)
    return docs, ids


def _columns_to_docs(df: pd.DataFrame) -> tuple[list[Document], list[str]]:
    docs, ids = [], []
    for _, row in df.iterrows():
        text = row.get("BUSINESS_DESCRIPTION") or ""
        if not text.strip():
            continue
        doc_id = f"{row['DATABASE_NAME']}__{row['TABLE_NAME']}__{row['COLUMN_NAME']}"
        docs.append(Document(
            page_content=text,
            metadata={
                "database_name": row["DATABASE_NAME"],
                "table_name": row["TABLE_NAME"],
                "column_name": row["COLUMN_NAME"],
            },
        ))
        ids.append(doc_id)
    return docs, ids


# ── Batched insert (respects embedding API batch size limits) ──────────────

_EMBED_BATCH_SIZE = 8


def _add_documents_batched(store: Chroma, docs: list[Document], ids: list[str]) -> None:
    """Add documents to a Chroma store in batches to respect embedding API limits."""
    for i in range(0, len(docs), _EMBED_BATCH_SIZE):
        batch_docs = docs[i : i + _EMBED_BATCH_SIZE]
        batch_ids = ids[i : i + _EMBED_BATCH_SIZE]
        store.add_documents(batch_docs, ids=batch_ids)


# ── Public API ─────────────────────────────────────────────────────────────

def build_vector_index(force_rebuild: bool = False) -> None:
    """Build or refresh the three Chroma collections from the business dictionary tables.

    Args:
        force_rebuild: If True, delete existing collections and re-index from scratch.
            If False, only add rows whose document ID is not yet present (incremental).
    """
    fetchers = [
        (_COLLECTION_OBJECTS, _fetch_objects, _objects_to_docs),
        (_COLLECTION_SECTIONS, _fetch_sections, _sections_to_docs),
        (_COLLECTION_COLUMNS, _fetch_columns, _columns_to_docs),
    ]

    for coll_name, fetch_fn, to_docs_fn in fetchers:
        logger.info("build_vector_index: processing collection '%s'", coll_name)

        if force_rebuild:
            store = _get_chroma_store(coll_name)
            try:
                store.delete_collection()
            except Exception:
                pass  # collection may not exist yet
            store = _get_chroma_store(coll_name)
        else:
            store = _get_chroma_store(coll_name)

        df = fetch_fn()
        all_docs, all_ids = to_docs_fn(df)

        if not all_docs:
            logger.info("  no documents to index for '%s'", coll_name)
            continue

        if force_rebuild:
            _add_documents_batched(store, all_docs, all_ids)
            logger.info("  indexed %d documents (full rebuild)", len(all_docs))
        else:
            existing_ids = set(store._collection.get(include=[])["ids"])
            new_docs = [d for d, i in zip(all_docs, all_ids) if i not in existing_ids]
            new_ids = [i for i in all_ids if i not in existing_ids]
            if new_docs:
                _add_documents_batched(store, new_docs, new_ids)
                logger.info("  indexed %d new documents (incremental)", len(new_docs))
            else:
                logger.info("  collection up to date, nothing to add")


def search_vector_index(
    query: str,
    sources: list[str] = ("objects", "sections", "columns"),
    section_names: Optional[List[str]] = None,
    top_k: int = 10,
) -> pd.DataFrame:
    """Search the requested Chroma collections using similarity search.

    Args:
        query: Natural language search query.
        sources: Which collections to search (subset of 'objects', 'sections', 'columns').
        section_names: If provided and 'sections' is in sources, filter by SECTION_NAME.
        top_k: Number of results per collection.

    Returns:
        DataFrame with columns: SOURCE, OBJECT_NAME, SECTION_NAME, COLUMN_NAME, TEXT, SCORE.
    """
    results = []

    for source in sources:
        if source not in _VALID_SOURCES:
            logger.warning("search_vector_index: unknown source '%s', skipping", source)
            continue

        coll_name = _SOURCE_TO_COLLECTION[source]
        store = _get_chroma_store(coll_name)

        filter_dict = None
        if source == "sections" and section_names is not None:
            filter_dict = {"section_name": {"$in": section_names}}

        try:
            hits = store.similarity_search_with_score(
                query, k=top_k, filter=filter_dict
            )
        except Exception as exc:
            logger.warning(
                "search_vector_index: collection '%s' query failed (%s), skipping",
                coll_name, exc,
            )
            continue

        for doc, score in hits:
            meta = doc.metadata
            results.append({
                "SOURCE": source,
                "OBJECT_NAME": meta.get("object_name", meta.get("table_name")),
                "SECTION_NAME": meta.get("section_name"),
                "COLUMN_NAME": meta.get("column_name"),
                "TEXT": doc.page_content,
                "SCORE": score,
            })

    if not results:
        return pd.DataFrame(columns=["SOURCE", "OBJECT_NAME", "SECTION_NAME", "COLUMN_NAME", "TEXT", "SCORE"])

    df = pd.DataFrame(results)
    # Deduplicate on OBJECT_NAME keeping highest score (lowest distance for cosine)
    df = df.sort_values("SCORE", ascending=True).drop_duplicates(subset=["OBJECT_NAME"], keep="first")
    return df.reset_index(drop=True)
