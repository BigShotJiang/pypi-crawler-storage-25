"""
Embedding model factory for the tdfs4ds consumer agent.

Uses dedicated ``EMBEDDING_MODEL_*`` configuration when set, otherwise
falls back to ``INSTRUCT_MODEL_*`` variables:

- ``'openai'``  -> ``langchain_openai.OpenAIEmbeddings``
- ``'bedrock'`` -> ``langchain_aws.BedrockEmbeddings`` (amazon.titan-embed-text-v2:0)

Typical LiteLLM setup (vLLM for instruct, TEI for embeddings behind a proxy)::

    tdfs4ds.INSTRUCT_MODEL_URL  = 'https://my-proxy/v1'       # chat completions
    tdfs4ds.EMBEDDING_MODEL_URL = 'https://my-proxy/v1/e5'    # embeddings (custom sub-path)
"""

from __future__ import annotations

import tdfs4ds
from langchain_core.embeddings import Embeddings


def get_embeddings() -> Embeddings:
    """Return a LangChain Embeddings instance based on the active provider.

    Resolution order for each setting:
    - ``EMBEDDING_MODEL_PROVIDER`` -> falls back to ``INSTRUCT_MODEL_PROVIDER``
    - ``EMBEDDING_MODEL_API_KEY``  -> falls back to ``INSTRUCT_MODEL_API_KEY``
    - ``EMBEDDING_MODEL_URL``      -> falls back to ``INSTRUCT_MODEL_URL``
    - ``EMBEDDING_MODEL_MODEL``    -> used as-is (default: ``text-embedding-3-small``)

    Returns:
        Embeddings: A configured LangChain embedding model.

    Raises:
        ValueError: If the resolved provider is not supported.
    """
    provider = (tdfs4ds.EMBEDDING_MODEL_PROVIDER or tdfs4ds.INSTRUCT_MODEL_PROVIDER or "").lower()
    api_key = tdfs4ds.EMBEDDING_MODEL_API_KEY or tdfs4ds.INSTRUCT_MODEL_API_KEY
    base_url = tdfs4ds.EMBEDDING_MODEL_URL or tdfs4ds.INSTRUCT_MODEL_URL

    if provider in ("openai", "vllm", "openai-compatible", "azure"):
        from langchain_openai import OpenAIEmbeddings

        return OpenAIEmbeddings(
            model=tdfs4ds.EMBEDDING_MODEL_MODEL,
            openai_api_key=api_key,
            **({"openai_api_base": base_url} if base_url else {}),
        )

    if provider == "bedrock":
        from langchain_aws import BedrockEmbeddings

        return BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v2:0",
        )

    raise ValueError(
        f"Unsupported embedding provider '{provider}'. "
        f"Set EMBEDDING_MODEL_PROVIDER (or INSTRUCT_MODEL_PROVIDER) to 'openai', 'vllm', 'azure', or 'bedrock'."
    )


def list_embedding_models(sub_paths: list[str] | None = None) -> "pd.DataFrame":
    """List available embedding models from the configured provider.

    For LiteLLM setups with multiple TEI backends (e.g. ``/v1/e5``, ``/v1/code``),
    pass the sub-path names to query each one::

        list_embedding_models(sub_paths=['e5', 'code'])

    Each sub-path is appended to ``INSTRUCT_MODEL_URL`` and queried for ``/models``.
    Results are merged into a single DataFrame with a ``SUB_PATH`` column.

    When ``sub_paths`` is ``None``, the function derives the sub-path from
    ``EMBEDDING_MODEL_URL`` (if set) or queries ``INSTRUCT_MODEL_URL`` directly.

    Args:
        sub_paths: List of LiteLLM route prefixes to query (e.g. ``['e5', 'code']``).

    Returns:
        DataFrame with columns: MODEL_ID, OWNED_BY, SUB_PATH (OpenAI-compatible) or
        MODEL_ID, PROVIDER, MODEL_NAME (Bedrock).

    Raises:
        ValueError: If the provider is not recognized or not configured.
    """
    import pandas as pd

    provider = (tdfs4ds.EMBEDDING_MODEL_PROVIDER or tdfs4ds.INSTRUCT_MODEL_PROVIDER or "").lower()
    api_key = tdfs4ds.EMBEDDING_MODEL_API_KEY or tdfs4ds.INSTRUCT_MODEL_API_KEY

    if provider in ("openai", "vllm", "openai-compatible", "azure"):
        import httpx

        base = (tdfs4ds.INSTRUCT_MODEL_URL or "https://api.openai.com/v1").rstrip("/")
        headers = {"Authorization": f"Bearer {api_key}"}

        def _models_url(base_url: str) -> str:
            return f"{base_url}/models" if base_url.endswith("/v1") else f"{base_url}/v1/models"

        # Build list of (url, sub_path_label) to query
        targets = []
        if sub_paths:
            for sp in sub_paths:
                sp_clean = sp.strip("/")
                targets.append((f"{base}/{sp_clean}/models", sp_clean))
        elif tdfs4ds.EMBEDDING_MODEL_URL:
            emb_base = tdfs4ds.EMBEDDING_MODEL_URL.rstrip("/")
            targets.append((_models_url(emb_base), emb_base.split("/")[-1]))
        else:
            targets.append((_models_url(base), ""))

        all_rows = []
        for url, label in targets:
            try:
                resp = httpx.get(url, headers=headers, timeout=30)
                resp.raise_for_status()
                data = resp.json().get("data", [])
                for m in data:
                    all_rows.append({
                        "MODEL_ID": m["id"],
                        "OWNED_BY": m.get("owned_by", ""),
                        "SUB_PATH": label,
                    })
            except (httpx.HTTPStatusError, httpx.ConnectError) as exc:
                import logging
                logging.getLogger(__name__).warning(
                    "list_embedding_models: %s returned %s, skipping", url, exc
                )
                continue

        if not all_rows:
            urls = [u for u, _ in targets]
            raise RuntimeError(f"Could not list models from any endpoint. Tried: {urls}")

        return pd.DataFrame(all_rows).sort_values("MODEL_ID").reset_index(drop=True)

    if provider == "bedrock":
        import boto3

        client = boto3.client("bedrock")
        response = client.list_foundation_models(byOutputModality="EMBEDDING")
        rows = [
            {
                "MODEL_ID": m["modelId"],
                "PROVIDER": m.get("providerName", ""),
                "MODEL_NAME": m.get("modelName", ""),
            }
            for m in response["modelSummaries"]
        ]
        return pd.DataFrame(rows).sort_values("MODEL_ID").reset_index(drop=True)

    raise ValueError(
        f"Embedding provider is '{provider}'. "
        f"Set EMBEDDING_MODEL_PROVIDER (or INSTRUCT_MODEL_PROVIDER) to 'openai', 'vllm', 'azure', or 'bedrock'."
    )
