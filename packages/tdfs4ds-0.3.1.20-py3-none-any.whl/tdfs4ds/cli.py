"""
Command-line interface and programmatic skill management for tdfs4ds.

Entry points registered in setup.py:
  tdfs4ds-install-skills   ->  cli.install_skills_cmd

Programmatic API (re-exported from ``tdfs4ds``):
  - tdfs4ds.list_skills()         List bundled skill names.
  - tdfs4ds.skill_path(name)      Path to a bundled SKILL.md.
  - tdfs4ds.install_skills(dir)   Copy SKILL.md files into a target directory.
  - tdfs4ds.export_skills(dir)    Alias of ``install_skills`` (clearer intent
                                   when used outside Claude Code).
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Union


# Canonical location of bundled skills inside the installed package
_SKILLS_SRC = Path(__file__).parent / "skills"


def _read_frontmatter(md_path: Path) -> Dict[str, str]:
    """Parse the leading ``---`` frontmatter block of a SKILL.md file."""
    try:
        text = md_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return {}
    if not text or text[0].strip() != "---":
        return {}
    meta: Dict[str, str] = {}
    for line in text[1:]:
        stripped = line.strip()
        if stripped == "---":
            break
        if ":" in stripped and not stripped.startswith("#"):
            key, _, value = stripped.partition(":")
            meta[key.strip()] = value.strip().strip("'\"")
    return meta


def _iter_skill_dirs():
    """Yield each ``<skill>/`` directory under ``tdfs4ds/skills/`` that contains a ``SKILL.md``."""
    if not _SKILLS_SRC.exists():
        return
    for skill_dir in sorted(_SKILLS_SRC.iterdir()):
        if not skill_dir.is_dir():
            continue
        if (skill_dir / "SKILL.md").is_file():
            yield skill_dir


def _iter_plugin_skill_dirs():
    """Yield skill dirs from the ``TDFS4DS_SKILLS_FOLDER`` environment variable (if set)."""
    import os
    folder = os.environ.get("TDFS4DS_SKILLS_FOLDER", "").strip()
    if not folder:
        return
    root = Path(folder)
    if not root.is_dir():
        return
    for skill_dir in sorted(root.iterdir()):
        if skill_dir.is_dir() and (skill_dir / "SKILL.md").is_file():
            yield skill_dir


def list_skills() -> List[str]:
    """
    Return the sorted list of bundled skill names.

    Returns
    -------
    list[str]
        Skill identifiers (the directory names under ``tdfs4ds/skills/``).

    Examples
    --------
    >>> import tdfs4ds
    >>> tdfs4ds.list_skills()
    ['fs-agent', 'fs-analyze', 'fs-dataset', ...]
    """
    return [d.name for d in _iter_skill_dirs()]


def skill_path(name: str) -> Path:
    """
    Return the absolute path to the bundled ``SKILL.md`` (or prompt ``.md``) for *name*.

    Searches in two locations:

    1. ``tdfs4ds/skills/<name>/SKILL.md`` — top-level skill directory (``ca-*``, ``qo-skill-*``, etc.)
    2. ``tdfs4ds/skills/<skill>/prompts/<name>.md`` — flat prompt file nested inside a skill's
       ``prompts/`` subfolder (e.g. ``qo-skill-optimize/prompts/qo-strategies.md``).

    Parameters
    ----------
    name : str
        Skill or prompt identifier (e.g. ``'fs-upload'``, ``'qo-strategies'``).

    Returns
    -------
    pathlib.Path
        Path to the ``.md`` file.

    Raises
    ------
    FileNotFoundError
        If no bundled skill or prompt with that name exists.
    """
    # 1. Top-level skill directory (existing behaviour)
    candidate = _SKILLS_SRC / name / "SKILL.md"
    if candidate.is_file():
        return candidate
    # 2. Flat prompt file inside <skill>/prompts/<name>.md
    for skill_dir in _SKILLS_SRC.iterdir():
        if not skill_dir.is_dir():
            continue
        nested = skill_dir / "prompts" / f"{name}.md"
        if nested.is_file():
            return nested
    available = ", ".join(list_skills())
    raise FileNotFoundError(
        f"No bundled skill named {name!r}. Available: {available}"
    )


def _read_skill_body(md_path: Path) -> str:
    """Return everything after the YAML frontmatter block of a SKILL.md file."""
    text = md_path.read_text(encoding="utf-8")
    if text.startswith("---"):
        end = text.index("---", 3) + 3
        return text[end:].lstrip("\n")
    return text


def _read_skill_classifier_examples(md_path: Path) -> list:
    """Return lines from the '## Classifier Examples' section of a SKILL.md file.

    Each returned string is a raw example line (the leading '- ' prefix is stripped)
    ready to be formatted as ``f"- {ex}"`` in the classifier prompt.
    """
    examples = []
    in_section = False
    for line in _read_skill_body(md_path).splitlines():
        if line.strip() == "## Classifier Examples":
            in_section = True
            continue
        if in_section:
            if line.startswith("## "):
                break
            stripped = line.strip()
            if stripped.startswith("- "):
                examples.append(stripped[2:])
    return examples


def skill_prompt(name: str) -> str:
    """Return the prompt template body (after frontmatter) for skill *name*.

    The returned string may contain ``{variable}`` placeholders intended for
    use with :py:meth:`str.format` (pure-Python prompts) or passed directly to
    ``ChatPromptTemplate.from_template`` (LangChain prompts).

    Parameters
    ----------
    name : str
        Skill identifier, e.g. ``'qo-candidates'``.

    Returns
    -------
    str
        Prompt body with frontmatter stripped.
    """
    return _read_skill_body(skill_path(name))


def install_skills(
    target_dir: Optional[Union[str, Path]] = None,
    *,
    overwrite: bool = True,
    skills: Optional[List[str]] = None,
    verbose: bool = True,
) -> List[Path]:
    """
    Copy bundled ``SKILL.md`` files to *target_dir*.

    Parameters
    ----------
    target_dir : str or Path, optional
        Destination root. Defaults to ``~/.claude/skills/`` (Claude Code
        user-level skills directory).
    overwrite : bool, default True
        Replace existing ``SKILL.md`` files. Set to ``False`` to skip skills
        that already exist at the destination.
    skills : list[str], optional
        Subset of skill names to install. Defaults to all bundled skills.
    verbose : bool, default True
        Print one line per installed skill plus a final summary.

    Returns
    -------
    list[pathlib.Path]
        Destination paths of every ``SKILL.md`` that was written (skipped
        files are not included).

    Notes
    -----
    The destination directory layout mirrors the package source — one
    directory per skill, each containing a ``SKILL.md``::

        target_dir/
          fs-setup/SKILL.md
          fs-upload/SKILL.md
          ...
    """
    if target_dir is None:
        target_dir = Path.home() / ".claude" / "skills"

    target_dir = Path(target_dir)
    requested = set(skills) if skills is not None else None
    installed: List[Path] = []
    skipped: List[str] = []

    for skill_dir in _iter_skill_dirs():
        if requested is not None and skill_dir.name not in requested:
            continue
        src_md = skill_dir / "SKILL.md"
        dest_dir = target_dir / skill_dir.name
        dest_md = dest_dir / "SKILL.md"
        if dest_md.exists() and not overwrite:
            skipped.append(skill_dir.name)
            if verbose:
                print(f"  skipped  {skill_dir.name} (already exists)")
            continue
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_md, dest_md)
        src_prompts = skill_dir / "prompts"
        if src_prompts.is_dir():
            dest_prompts = dest_dir / "prompts"
            if dest_prompts.exists():
                shutil.rmtree(dest_prompts)
            shutil.copytree(src_prompts, dest_prompts)
        installed.append(dest_md)
        if verbose:
            print(f"  installed {skill_dir.name} -> {dest_md}")

    if verbose:
        if installed:
            print(f"\n{len(installed)} skill(s) installed to {target_dir}")
        if skipped:
            print(f"{len(skipped)} skill(s) skipped (use overwrite=True to replace).")

    return installed


# ---------------------------------------------------------------------------
# Public alias — ``export_skills`` reads more naturally when the destination
# is **not** Claude Code (e.g. a custom agent framework).
# ---------------------------------------------------------------------------

def export_skills(
    target_dir: Union[str, Path],
    *,
    overwrite: bool = False,
    skills: Optional[List[str]] = None,
    verbose: bool = True,
) -> List[Path]:
    """
    Export bundled ``SKILL.md`` files to *target_dir*, skipping any that
    already exist there.

    Same behaviour as :func:`install_skills` but with a mandatory destination
    and ``overwrite=False`` by default — use this when copying skills into a
    target directory and you only want to add missing ones.

    Parameters
    ----------
    target_dir : str or Path
        Destination root.
    overwrite : bool, default False
        When ``False`` (default), skills already present at the destination
        are left untouched. Pass ``True`` to replace them unconditionally.
    skills, verbose
        See :func:`install_skills`.

    Returns
    -------
    list[pathlib.Path]
        Destination paths of every ``SKILL.md`` that was written (skipped
        files are not included).

    Examples
    --------
    >>> import tdfs4ds
    >>> tdfs4ds.export_skills('./my_agent/skills')          # skip existing
    >>> tdfs4ds.export_skills('./my_agent/skills', overwrite=True)  # replace all
    >>> tdfs4ds.export_skills('/srv/skills', skills=['fs-setup', 'fs-upload'])
    """
    return install_skills(
        target_dir=target_dir,
        overwrite=overwrite,
        skills=skills,
        verbose=verbose,
    )


def install_skills_global(
    *,
    overwrite: bool = True,
    skills: Optional[List[str]] = None,
    verbose: bool = True,
) -> List[Path]:
    """
    Install bundled ``SKILL.md`` files to the global Claude Code skills directory.

    Convenience wrapper around :func:`install_skills` that targets
    ``~/.claude/skills/`` — the default Claude Code user-level skills location
    shared across all local projects.

    Use this when you want to make tdfs4ds skills available to Claude Code
    globally (in your home directory), so they appear in the IDE extensions,
    CLI, and web app without repeating the installation per project.

    Parameters
    ----------
    overwrite : bool, default True
        Replace existing ``SKILL.md`` files. Set to ``False`` to skip skills
        that have already been installed.
    skills : list[str], optional
        Subset of skill names to install. Defaults to all bundled skills.
        Example: ``skills=['fs-upload', 'fs-dataset']``.
    verbose : bool, default True
        Print progress — one line per installed skill and a final summary.

    Returns
    -------
    list[pathlib.Path]
        Destination paths of every ``SKILL.md`` file that was written.
        Skipped files (when ``overwrite=False`` and already present) are
        not included in the return value.

    Notes
    -----
    This is equivalent to calling:

    .. code-block:: python

        install_skills(
            target_dir=Path.home() / ".claude" / "skills",
            overwrite=overwrite,
            skills=skills,
            verbose=verbose,
        )

    Examples
    --------
    Install all bundled skills globally (one-time setup):

    >>> import tdfs4ds
    >>> tdfs4ds.install_skills_global()
    installed fs-agent -> /Users/you/.claude/skills/fs-agent/SKILL.md
    installed fs-analyze -> /Users/you/.claude/skills/fs-analyze/SKILL.md
    ...
    19 skill(s) installed to /Users/you/.claude/skills

    Install only a few specific skills:

    >>> tdfs4ds.install_skills_global(
    ...     skills=['fs-upload', 'fs-dataset', 'ca-search'],
    ...     verbose=True
    ... )

    Reinstall a skill (replace if already present):

    >>> tdfs4ds.install_skills_global(
    ...     skills=['fs-upload'],
    ...     overwrite=True
    ... )

    See Also
    --------
    install_skills_local : Install to a local project directory instead.
    install_skills : Lower-level function accepting arbitrary target paths.
    """
    global_skills_dir = Path.home() / ".claude" / "skills"
    return install_skills(
        target_dir=global_skills_dir,
        overwrite=overwrite,
        skills=skills,
        verbose=verbose,
    )


def install_skills_local(
    *,
    overwrite: bool = True,
    skills: Optional[List[str]] = None,
    verbose: bool = True,
) -> List[Path]:
    """
    Install bundled ``SKILL.md`` files to the local project's Claude Code directory.

    Convenience wrapper around :func:`install_skills` that targets
    ``./.claude/skills/`` — the project-level skills directory for Claude Code
    in the current working directory.

    Use this when you want to version-control tdfs4ds skills alongside your
    project code (e.g. in a monorepo or framework where custom agents may
    modify or extend the skill set). Skills installed locally override the
    global installation for this project.

    Parameters
    ----------
    overwrite : bool, default True
        Replace existing ``SKILL.md`` files. Set to ``False`` to skip skills
        that have already been installed locally.
    skills : list[str], optional
        Subset of skill names to install. Defaults to all bundled skills.
        Example: ``skills=['fs-upload', 'ca-explain']``.
    verbose : bool, default True
        Print progress — one line per installed skill and a final summary.

    Returns
    -------
    list[pathlib.Path]
        Destination paths of every ``SKILL.md`` file that was written.
        Skipped files (when ``overwrite=False`` and already present) are
        not included in the return value.

    Notes
    -----
    This is equivalent to calling:

    .. code-block:: python

        install_skills(
            target_dir=Path.cwd() / ".claude" / "skills",
            overwrite=overwrite,
            skills=skills,
            verbose=verbose,
        )

    The local skills directory is created automatically if it does not exist.

    Examples
    --------
    Install all bundled skills locally (one-time setup in a project):

    >>> import tdfs4ds
    >>> import os
    >>> os.chdir('/path/to/my/project')
    >>> tdfs4ds.install_skills_local()
    installed fs-agent -> /path/to/my/project/.claude/skills/fs-agent/SKILL.md
    installed fs-analyze -> /path/to/my/project/.claude/skills/fs-analyze/SKILL.md
    ...
    19 skill(s) installed to /path/to/my/project/.claude/skills

    Install only consumer-agent reference skills locally:

    >>> tdfs4ds.install_skills_local(
    ...     skills=[
    ...         'ca-search', 'ca-definition', 'ca-explain', 'ca-lineage',
    ...         'ca-summary', 'ca-usage', 'ca-freshness', 'ca-dataset'
    ...     ]
    ... )

    Add new skills to an existing local installation:

    >>> tdfs4ds.install_skills_local(
    ...     skills=['fs-new-workflow'],
    ...     overwrite=False  # skip if already installed
    ... )

    See Also
    --------
    install_skills_global : Install to the global Claude Code directory instead.
    install_skills : Lower-level function accepting arbitrary target paths.
    """
    local_skills_dir = Path.cwd() / ".claude" / "skills"
    return install_skills(
        target_dir=local_skills_dir,
        overwrite=overwrite,
        skills=skills,
        verbose=verbose,
    )


def skill_catalog() -> Dict[str, Dict[str, str]]:
    """
    Return a mapping of every bundled skill to its frontmatter metadata.

    Each value contains ``description`` (one-line summary used by agent
    dispatchers) and ``path`` (absolute ``SKILL.md`` path). Frontmatter is
    parsed without a YAML dependency — only top-level ``key: value`` lines
    inside a leading ``---`` block are extracted.

    Returns
    -------
    dict[str, dict[str, str]]

    Examples
    --------
    >>> import tdfs4ds
    >>> tdfs4ds.skill_catalog()['fs-upload']['description'][:60]
    'Generate Python code to engineer features ...'
    """
    catalog: Dict[str, Dict[str, str]] = {}
    for skill_dir in _iter_skill_dirs():
        md = skill_dir / "SKILL.md"
        metadata: Dict[str, str] = {"path": str(md)}
        metadata.update(_read_frontmatter(md))
        metadata["examples"] = _read_skill_classifier_examples(md)
        catalog[skill_dir.name] = metadata
    return catalog


def consumer_agent_skill_catalog() -> Dict[str, Dict[str, str]]:
    """
    Return metadata for all consumer-agent skills, keyed by skill name.

    Consumer-agent skills are identified by the ``ca-`` name prefix convention.
    They are installed to ``~/.claude/skills/`` alongside other skills and are
    also used by the LangGraph consumer agent to build its intent classifier and
    skill registry dynamically.

    Returns
    -------
    dict[str, dict[str, str]]
        Skill name → frontmatter metadata (includes ``intent``, ``description``,
        and ``path``).

    Examples
    --------
    >>> import tdfs4ds
    >>> tdfs4ds.consumer_agent_skill_catalog().keys()
    dict_keys(['ca-dataset', 'ca-definition', 'ca-explain', ...])
    """
    catalog = {
        name: meta
        for name, meta in skill_catalog().items()
        if name.startswith("ca-")
    }
    for skill_dir in _iter_plugin_skill_dirs():
        md = skill_dir / "SKILL.md"
        metadata: Dict[str, str] = {"path": str(md), "plugin": "true"}
        metadata.update(_read_frontmatter(md))
        catalog[skill_dir.name] = metadata
    return catalog


def query_optimizer_skill_catalog() -> Dict[str, Dict[str, str]]:
    """
    Return metadata for all query-optimizer skills, keyed by skill name.

    Query-optimizer skills are identified by the ``qo-skill-`` name prefix and
    must have an ``intent`` field in their frontmatter.  They are used by the
    LangGraph query optimizer agent to build its intent classifier and skill
    registry dynamically.

    Returns
    -------
    dict[str, dict[str, str]]
        Skill name → frontmatter metadata (includes ``intent``, ``description``,
        and ``path``).

    Examples
    --------
    >>> import tdfs4ds
    >>> tdfs4ds.query_optimizer_skill_catalog().keys()
    dict_keys(['qo-skill-explain', 'qo-skill-optimize', 'qo-skill-simplify'])
    """
    return {
        name: meta
        for name, meta in skill_catalog().items()
        if name.startswith("qo-skill-") and "intent" in meta
    }


# ---------------------------------------------------------------------------
# CLI entry points
# ---------------------------------------------------------------------------

def install_skills_cmd():
    """Entry point: ``tdfs4ds-install-skills``."""
    parser = argparse.ArgumentParser(
        prog="tdfs4ds-install-skills",
        description="Install tdfs4ds agent skills to a target directory.",
    )
    parser.add_argument(
        "--target",
        metavar="DIR",
        default=None,
        help=(
            "Destination directory for SKILL.md files "
            "(default: ~/.claude/skills/)."
        ),
    )
    parser.add_argument(
        "--skill",
        action="append",
        metavar="NAME",
        default=None,
        help="Install a single skill (repeat for multiple). Default: all.",
    )
    parser.add_argument(
        "--no-overwrite",
        action="store_true",
        help="Skip skills that already exist at the destination.",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List bundled skill names and exit.",
    )
    args = parser.parse_args()

    if args.list:
        for name in list_skills():
            print(name)
        return

    install_skills(
        target_dir=args.target,
        overwrite=not args.no_overwrite,
        skills=args.skill,
    )


if __name__ == "__main__":
    install_skills_cmd()
