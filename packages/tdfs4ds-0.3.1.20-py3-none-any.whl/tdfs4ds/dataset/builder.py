"""
Dataset construction functions for the tdfs4ds feature store.

Provides build_dataset(), build_dataset_opt(), and augment_source_with_features()
for generating Teradata views that join feature tables with source data.
"""

import re

import tdfs4ds
import teradataml as tdml

from tdfs4ds.dataset.dataset_catalog import DatasetCatalog, Dataset
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_available_entity_id_records,
    get_feature_location,
)


def _build_dataset_multijoin(entity_id, selected_features, view_name, schema_name,
                              feature_store_time, join_type):
    """
    Build the REPLACE VIEW DDL using one sub-query per feature (classic approach).

    Each feature gets its own sub-query; the outer query chains them with JOINs.
    Teradata pushes a PI-equality filter on the entity column directly into every
    sub-query, making single-entity lookups single-AMP.

    Returns the full DDL string, or None when no features are available.
    """
    use_time_travel = feature_store_time and tdfs4ds.FEATURE_STORE_TIME is not None
    if use_time_travel:
        outer_validtime = ''
        sub_temporal_qualifier = f"VALIDTIME AS OF TIMESTAMP '{tdfs4ds.FEATURE_STORE_TIME}'"
    else:
        outer_validtime = 'CURRENT VALIDTIME'
        sub_temporal_qualifier = 'SEQUENCED VALIDTIME'
    tdfs4ds.logger.info(
        f"Temporal qualifier: {'sub-query VALIDTIME AS OF ' + tdfs4ds.FEATURE_STORE_TIME if use_time_travel else 'CURRENT VALIDTIME / SEQUENCED VALIDTIME'}"
    )

    tdfs4ds.logger.info("Retrieving the tables where the features are located.")
    list_features = get_feature_location(entity_id, selected_features)

    if isinstance(entity_id, list):
        list_entity_id = entity_id
    elif isinstance(entity_id, dict):
        list_entity_id = list(entity_id.keys())
    else:
        list_entity_id = [entity_id]
    list_entity_id.sort()

    def _sanitize_identifier(name: str) -> str:
        return re.sub(r'[^0-9A-Za-z_]', '_', name)

    used_alias_counts = {}

    def _unique_alias(base: str) -> str:
        if base not in used_alias_counts:
            used_alias_counts[base] = 1
            return base
        used_alias_counts[base] += 1
        return f"{base}_{used_alias_counts[base]}"

    tdfs4ds.logger.info("Generating the sub-queries for feature retrieval.")
    sub_queries = []
    txt_entity = '\n ,'.join(['B1.' + e for e in list_entity_id])

    for k, v in list_features.items():
        for feature_id, feature_version, feature_name in v:
            if isinstance(feature_version, list):
                for item in feature_version:
                    process_id = item.get("process_id")
                    process_view_name = item.get("process_view_name") or "PROCESS"
                    base_alias = _sanitize_identifier(f"{feature_name}_{process_view_name}")
                    alias = _unique_alias(base_alias)
                    txt_where = f"(FEATURE_ID = {feature_id} AND FEATURE_VERSION='{process_id}')"
                    feature_str = ',B1.FEATURE_VALUE AS ' + alias
                    sub_queries.append(
                        {
                            'feature_name': alias,
                            'query': f"""
                            {sub_temporal_qualifier}
                            SELECT
                               {txt_entity}
                              {feature_str}
                            FROM {k} B1
                            WHERE {txt_where}
                            """
                        }
                    )
            else:
                base_alias = _sanitize_identifier(feature_name)
                alias = _unique_alias(base_alias)
                txt_where = f"(FEATURE_ID = {feature_id} AND FEATURE_VERSION='{feature_version}')"
                feature_str = ',B1.FEATURE_VALUE AS ' + alias
                sub_queries.append(
                    {
                        'feature_name': alias,
                        'query': f"""
                        {sub_temporal_qualifier}
                        SELECT
                           {txt_entity}
                          {feature_str}
                        FROM {k} B1
                        WHERE {txt_where}
                        """
                    }
                )

    if len(sub_queries) == 0:
        tdfs4ds.logger.warning("No features available for the specified entity IDs.")
        return None

    if join_type == 'INNER':
        txt_entity = '\n ,'.join(['A1.' + e for e in list_entity_id])
    elif join_type == 'FULL OUTER':
        txt_entity = '\n ,'.join(
            [f"COALESCE({','.join(['A' + str(i) + '.' + e for i, _ in enumerate(sub_queries, 1)])}) AS {e}"
             for e in list_entity_id])

    select_query = f"""
          {txt_entity}
        , A1.{sub_queries[0]['feature_name']}
    """

    from_query = f"""
    FROM ({sub_queries[0]['query']}) A1
    """

    for i, query_ in enumerate(sub_queries[1:], 2):
        select_query += f"\t, A{i}.{query_['feature_name']}\n"
        on_clause = ' AND '.join(['A1.' + c + '= A' + str(i) + '.' + c for c in list_entity_id])
        from_query += f"""
        {join_type} JOIN ({query_['query']}) A{i}
        ON {on_clause}
        """

    return f"""
    REPLACE VIEW {schema_name}.{view_name} AS
    LOCK ROW FOR ACCESS
        {outer_validtime}
        SELECT {select_query}
        {from_query}
    """


def _build_dataset_grouped(entity_id, selected_features, view_name, schema_name,
                            feature_store_time, join_type):
    """
    Build the REPLACE VIEW DDL using one sub-query per (table, version) group.

    Features sharing the same storage table and process version are pivoted into a
    single sub-query with MAX(CASE WHEN FEATURE_ID=X THEN FEATURE_VALUE END) per
    feature and GROUP BY on the entity columns.  This reduces the number of JOINs
    from N_features down to N_distinct_(table, version) pairs.

    For INNER JOIN a HAVING clause filters out entities missing any feature in the
    group, preserving the same strict semantics as the per-feature approach.
    For FULL OUTER no HAVING is added so partial entities survive with NULLs.

    PI-equality filters on the entity column are pushed through the GROUP BY into
    the base-table scan when the outer WHERE references the entity column directly.
    For INNER JOIN the outer SELECT uses A1.entity (enables push-down); for FULL
    OUTER it uses COALESCE (push-down is not possible, same as classic approach).

    Returns the full DDL string, or None when no features are available.
    """
    use_time_travel = feature_store_time and tdfs4ds.FEATURE_STORE_TIME is not None
    if use_time_travel:
        outer_validtime = ''
        sub_temporal_qualifier = f"VALIDTIME AS OF TIMESTAMP '{tdfs4ds.FEATURE_STORE_TIME}'"
    else:
        outer_validtime = 'CURRENT VALIDTIME'
        sub_temporal_qualifier = 'SEQUENCED VALIDTIME'
    tdfs4ds.logger.info(
        f"Temporal qualifier: {'sub-query VALIDTIME AS OF ' + tdfs4ds.FEATURE_STORE_TIME if use_time_travel else 'CURRENT VALIDTIME / SEQUENCED VALIDTIME'}"
    )

    tdfs4ds.logger.info("Retrieving the tables where the features are located.")
    list_features = get_feature_location(entity_id, selected_features)

    if isinstance(entity_id, list):
        list_entity_id = entity_id
    elif isinstance(entity_id, dict):
        list_entity_id = list(entity_id.keys())
    else:
        list_entity_id = [entity_id]
    list_entity_id.sort()

    def _sanitize_identifier(name: str) -> str:
        return re.sub(r'[^0-9A-Za-z_]', '_', name)

    used_alias_counts = {}

    def _unique_alias(base: str) -> str:
        if base not in used_alias_counts:
            used_alias_counts[base] = 1
            return base
        used_alias_counts[base] += 1
        return f"{base}_{used_alias_counts[base]}"

    # Group features by (table, version): one sub-query per group instead of per feature.
    groups = {}  # (table, version) -> {'table': str, 'version': str, 'features': [(fid, alias)]}
    for k, v in list_features.items():
        for feature_id, feature_version, feature_name in v:
            if isinstance(feature_version, list):
                for item in feature_version:
                    process_id = item.get("process_id")
                    process_view_name = item.get("process_view_name") or "PROCESS"
                    alias = _unique_alias(_sanitize_identifier(f"{feature_name}_{process_view_name}"))
                    group_key = (k, process_id)
                    if group_key not in groups:
                        groups[group_key] = {'table': k, 'version': process_id, 'features': []}
                    groups[group_key]['features'].append((feature_id, alias))
            else:
                alias = _unique_alias(_sanitize_identifier(feature_name))
                group_key = (k, feature_version)
                if group_key not in groups:
                    groups[group_key] = {'table': k, 'version': feature_version, 'features': []}
                groups[group_key]['features'].append((feature_id, alias))

    if not groups:
        tdfs4ds.logger.warning("No features available for the specified entity IDs.")
        return None

    n_features = sum(len(g['features']) for g in groups.values())
    n_pivoted = sum(1 for g in groups.values() if len(g['features']) > 1)
    tdfs4ds.logger.info(
        f"Generating {len(groups)} sub-queries for {n_features} features "
        f"({n_pivoted} pivoted groups, {len(groups) - n_pivoted} plain single-feature scans)."
    )

    entity_select = '\n  ,'.join(['B1.' + e for e in list_entity_id])
    group_by_clause = ', '.join(['B1.' + e for e in list_entity_id])

    sub_queries = []
    for (table, version), group in groups.items():
        fid, alias = group['features'][0]

        if len(group['features']) == 1:
            # Single-feature group: plain scan, no aggregation needed.
            sub_queries.append({
                'feature_names': [alias],
                'query': f"""
            {sub_temporal_qualifier}
            SELECT
               {entity_select}
              ,B1.FEATURE_VALUE AS {alias}
            FROM {table} B1
            WHERE FEATURE_VERSION='{version}' AND FEATURE_ID = {fid}
            """
            })
        else:
            # Multi-feature group: pivot with MAX(CASE WHEN) + GROUP BY.
            case_exprs = '\n  ,'.join(
                f"MAX(CASE WHEN FEATURE_ID={fid} THEN FEATURE_VALUE END) AS {alias}"
                for fid, alias in group['features']
            )
            feature_id_list = ', '.join(str(fid) for fid, _ in group['features'])

            # INNER: require every feature in the group to be non-NULL, same as chained
            # INNER JOINs in the classic approach.
            if join_type == 'INNER':
                having_parts = '\n   AND '.join(
                    f"MAX(CASE WHEN FEATURE_ID={fid} THEN FEATURE_VALUE END) IS NOT NULL"
                    for fid, _ in group['features']
                )
                having_clause = f"HAVING {having_parts}"
            else:
                having_clause = ''

            sub_queries.append({
                'feature_names': [alias for _, alias in group['features']],
                'query': f"""
            {sub_temporal_qualifier}
            SELECT
               {entity_select}
              ,{case_exprs}
            FROM {table} B1
            WHERE FEATURE_VERSION='{version}' AND FEATURE_ID IN ({feature_id_list})
            GROUP BY {group_by_clause}
            {having_clause}
            """
            })

    # INNER: use A1.entity directly so PI-equality push-down works through GROUP BY.
    # FULL OUTER: COALESCE is necessary; PI push-down is not possible.
    if join_type == 'INNER':
        txt_entity = '\n ,'.join(['A1.' + e for e in list_entity_id])
    else:
        txt_entity = '\n ,'.join(
            [f"COALESCE({','.join(['A' + str(i) + '.' + e for i, _ in enumerate(sub_queries, 1)])}) AS {e}"
             for e in list_entity_id])

    select_query = f"      {txt_entity}\n"
    for i, sq in enumerate(sub_queries, 1):
        for fname in sq['feature_names']:
            select_query += f"\t, A{i}.{fname}\n"

    from_query = f"\n    FROM ({sub_queries[0]['query']}) A1\n"
    for i, sq in enumerate(sub_queries[1:], 2):
        on_clause = ' AND '.join(['A1.' + c + '= A' + str(i) + '.' + c for c in list_entity_id])
        from_query += f"""
        {join_type} JOIN ({sq['query']}) A{i}
        ON {on_clause}
        """

    return f"""
    REPLACE VIEW {schema_name}.{view_name} AS
    LOCK ROW FOR ACCESS
        {outer_validtime}
        SELECT {select_query}
        {from_query}
    """


def build_dataset(entity_id, selected_features, view_name, schema_name=None, comment=None,
                  return_query=False, feature_store_time=False, join_type='INNER',
                  grouped=False):
    """
    Generate a SQL query and create a Teradata view to retrieve records for the specified
    entity IDs based on selected features.

    Parameters:
    ----------
    entity_id : list, dict, or str
        The entity IDs for which records are needed. Can be a list, dictionary, or string.
        - If list: contains multiple entity IDs.
        - If dict: keys are the entity IDs.
        - If str: a single entity ID.

    selected_features : dict
        A dictionary where the keys are feature table names, and the values are lists of tuples
        (feature_id, feature_version, feature_name) specifying the features to retrieve.
        NOTE: feature_version may be either:
          - a single UUID string, or
          - a list of dicts like:
              {"process_id": <UUID>, "process_view_name": <str>}

    view_name : str
        The name of the view to be created in the database.

    schema_name : str, optional
        The name of the database schema where the view will be created.
        Defaults to the global `tdfs4ds.SCHEMA` if not provided.

    comment : str, optional
        A comment to attach to the created view for documentation purposes. Defaults to None.

    return_query : bool, optional
        If True, the function will return the SQL query string instead of executing it.
        Defaults to False.

    feature_store_time : bool, optional
        If True, the query will use a specific `VALIDTIME` based on `tdfs4ds.FEATURE_STORE_TIME`.
        If False, the query will use `CURRENT VALIDTIME`. Defaults to False.

    join_type : str, optional
        Specifies the type of join to use between features: 'INNER' (default) or 'FULL OUTER'.

    grouped : bool, optional
        If False (default), uses one sub-query per feature joined together — the classic
        multi-join approach.  Every individual feature sub-query can be targeted by a
        PI-equality filter pushed from the outer WHERE, making single-entity lookups
        single-AMP.
        If True, groups features that share the same storage table and process version
        into a single sub-query with MAX(CASE WHEN …) pivoting, reducing the number of
        JOINs from N_features to N_distinct_(table, version) pairs.  A HAVING clause
        enforces non-NULL for every feature in the group when join_type='INNER',
        preserving the same missing-feature semantics as the classic approach.
        PI push-down is preserved for INNER JOIN (outer SELECT uses A1.entity); for
        FULL OUTER the COALESCE in the outer SELECT prevents push-down, same as the
        classic approach.

    Returns:
    -------
    str or tdml.DataFrame
        - If `return_query` is True, returns the generated SQL query as a string.
        - Otherwise, returns a Teradata DataFrame containing the results.

    Raises:
    ------
    ValueError
        If an invalid `join_type` is provided.
    """
    if join_type not in ['INNER', 'FULL OUTER']:
        tdfs4ds.logger.error(f"{join_type} is not valid. Only 'INNER' and 'FULL OUTER' are authorized.")
        raise ValueError("Invalid join type. Use 'INNER' or 'FULL OUTER'.")

    if schema_name is None:
        schema_name = tdfs4ds.SCHEMA

    builder = _build_dataset_grouped if grouped else _build_dataset_multijoin
    query = builder(entity_id, selected_features, view_name, schema_name,
                    feature_store_time, join_type)

    if query is None:
        return

    if return_query:
        tdfs4ds.logger.info("Returning the generated dataset query.")
        return query

    tdfs4ds.logger.info(f"Creating the view {view_name} in the {schema_name} database.")
    tdml.execute_sql(query)

    if comment:
        tdfs4ds.logger.info(f"Adding a comment to the view {view_name} in the {schema_name} database.")
        tdml.execute_sql(f"COMMENT ON VIEW {schema_name}.{view_name} IS '{comment}'")

    tdfs4ds.logger.info(f"Creation of the dataset object.")
    dataset = Dataset(view_name=view_name, schema_name=schema_name)
    tdfs4ds.logger.info(f"Registering of the dataset in the dataset catalog.")
    DatasetCatalog(schema_name=tdfs4ds.SCHEMA, name=tdfs4ds.DATASET_CATALOG_NAME).add_dataset(dataset=dataset)

    tdfs4ds.logger.info("Returning the dataset as a Teradata DataFrame.")
    return tdml.DataFrame.from_table(tdml.in_schema(schema_name, view_name))


def build_dataset_opt(entity_id, selected_features, view_name=None, schema_name=None,
                      comment='dataset', no_temporal=False, time_manager=None, query_only=False,
                      entity_null_substitute={}, other=None, time_column=None,
                      filtermanager=None, filter_conditions=None):
    if schema_name is None:
        schema_name = tdfs4ds.SCHEMA
    dataset = augment_source_with_features(
        source_schema      = None,
        source_name        = None,
        entity_id          = entity_id,
        feature_selection  = selected_features,
        output_view_name   = view_name,
        output_view_schema = schema_name
    )
    return dataset


def augment_source_with_features(source_schema, source_name, entity_id, feature_selection,
                                  output_view_schema, output_view_name, join_type='LEFT JOIN'):
    """
    Augment a source table with selected features by creating a view that joins the source data
    with feature tables based on specified entity identifiers and feature selections.

    The join type can be specified as either 'LEFT JOIN' or 'INNER JOIN':
    - 'LEFT JOIN': Retains all rows from the source table, with missing values for unmatched features.
    - 'INNER JOIN': Returns only rows where all specified features have matching, non-missing values.

    Parameters:
    source_schema (str): The schema of the source table to augment.
    source_name (str): The name of the source table to augment.
    entity_id (str or list of str): The entity ID(s) for joining the source data with feature tables.
    feature_selection (list): A list of features to select and join with the source data.
    output_view_schema (str): The schema in which to create the output view.
    output_view_name (str): The name of the output view to create with augmented features.
    join_type (str, optional): 'LEFT JOIN' or 'INNER JOIN'. Defaults to 'LEFT JOIN'.

    Returns:
    tdml.DataFrame: A DataFrame object that references the newly created view.
    """

    if isinstance(entity_id, str):
        entity_id = [entity_id]

    locations = get_feature_location(entity_id=entity_id, selected_features=feature_selection)

    query_select = f"""
    REPLACE VIEW {output_view_schema}.{output_view_name}
    AS LOCK ROW FOR ACCESS
    SELECT
        SOURCE.*
    """
    query_join = []
    counter = 1

    for feature_store_view, list_features in locations.items():
        for feature in list_features:
            table_name = 'A' + str(counter)
            query_select += '\n, ' + table_name + '.' + feature[2]

            on_clause = ' AND '.join(['SOURCE.' + c + '=' + table_name + '.' + c for c in entity_id])

            query_join.append(
                f"""
                {join_type}
                (CURRENT VALIDTIME
                SEL
                    A.*
                  , A.FEATURE_VALUE AS {feature[2]}
                  FROM {feature_store_view} A
                  WHERE FEATURE_ID = {feature[0]} AND FEATURE_VERSION = '{feature[1]}'
                ) {table_name}
                ON {on_clause}
                """
            )
            counter += 1

    if source_schema is None and source_name is None:
        query_available_features, list_features = get_available_entity_id_records(entity_id, feature_selection)
        query = query_select + '\n' + f'FROM ({query_available_features}) SOURCE \n' + '\n'.join(query_join)
    else:
        query = query_select + '\n' + f'FROM {source_schema}.{source_name} SOURCE \n' + '\n'.join(query_join)

    tdml.execute_sql(query)

    try:
        return tdml.DataFrame.from_table(tdml.in_schema(output_view_schema, output_view_name))
    except Exception as e:
        print(str(e))
        return None
