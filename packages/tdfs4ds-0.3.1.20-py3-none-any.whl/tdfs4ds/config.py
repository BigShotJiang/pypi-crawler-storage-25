"""
Configuration loading for tdfs4ds.

Three external configuration sources are supported, applied in this order so
that higher-priority sources always win:

1. **JSON config file** — project defaults, searched in order:
   - ``./tdfs4ds.json``  (project-local)
   - ``~/.tdfs4ds/config.json``  (user-global)

2. **``.env`` file** — local environment overrides, searched in order:
   - ``./.env``  (project-local)
   - ``~/.tdfs4ds/.env``  (user-global)
   Only ``TDFS4DS_*`` variables are read; the file is parsed without touching
   ``os.environ``.  Unlike the JSON config, credentials are accepted here
   (add ``.env`` to ``.gitignore`` to keep secrets out of source control).

3. **OS environment variables** — prefix ``TDFS4DS_``, e.g.
   ``TDFS4DS_SCHEMA``, ``TDFS4DS_DATA_DOMAIN``.

Credentials (``INSTRUCT_MODEL_API_KEY``) are rejected from the JSON config
file to prevent accidental commits; use a ``.env`` file or an OS env var.

Full priority chain (highest first):
  programmatic  >  OS env var  >  .env file  >  JSON config  >  built-in defaults
"""

import os
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Variable metadata
# ---------------------------------------------------------------------------

_BOOL_VARS = frozenset({
    'DISPLAY_LOGS',
    'DEBUG_MODE',
    'USE_VOLATILE_TABLE',
    'BUILD_DATASET_AT_UPLOAD',
})

_INT_VARS = frozenset({
    'VARCHAR_SIZE',
    'FEATURE_PARTITION_N',
    'FEATURE_PARTITION_EACH',
    'EMBEDDING_MODEL_DIM',
    'CHROMA_PORT',
})

# Accepted in JSON config files (no credentials)
_FILE_VARS = frozenset({
    'SCHEMA',
    'DATA_DOMAIN',
    'FEATURE_STORE_TIME',
    'DISPLAY_LOGS',
    'DEBUG_MODE',
    'STORE_FEATURE',
    'REGISTER_FEATURE',
    'REGISTER_PROCESS',
    'USE_VOLATILE_TABLE',
    'BUILD_DATASET_AT_UPLOAD',
    'VARCHAR_SIZE',
    'FEATURE_PARTITION_N',
    'FEATURE_PARTITION_EACH',
    'INSTRUCT_MODEL_PROVIDER',
    'INSTRUCT_MODEL_URL',
    'INSTRUCT_MODEL_MODEL',
    'EMBEDDING_MODEL_PROVIDER',
    'EMBEDDING_MODEL_URL',
    'EMBEDDING_MODEL_MODEL',
    'EMBEDDING_MODEL_DIM',
    'CHROMA_MODE',
    'CHROMA_PATH',
    'CHROMA_HOST',
    'CHROMA_PORT',
    'MCP_SERVER_URL',
    'MCP_SERVER_TRANSPORT',
})

# Credentials: accepted in .env and OS env vars, rejected from JSON config
_CREDENTIAL_VARS = frozenset({'INSTRUCT_MODEL_API_KEY', 'EMBEDDING_MODEL_API_KEY'})

# Everything accepted via .env or OS env var
_ALL_ENV_VARS = _FILE_VARS | _CREDENTIAL_VARS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _coerce(name, value):
    """Cast *value* to the correct Python type for *name*."""
    if name in _BOOL_VARS:
        if isinstance(value, bool):
            return value
        return str(value).lower() in ('1', 'true', 'yes')
    if name in _INT_VARS:
        return int(value)
    if isinstance(value, str) and value.lower() in ('none', 'null', ''):
        return None
    return value


# ---------------------------------------------------------------------------
# Source loaders
# ---------------------------------------------------------------------------

def _apply_file(module, path):
    """Read *path* (JSON) and apply matching keys to *module*."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except OSError:
        return  # absent or unreadable — skip silently
    except json.JSONDecodeError as exc:
        logger.warning("tdfs4ds: invalid JSON in config file %s: %s", path, exc)
        return

    for key, value in data.items():
        attr = key.upper()
        if attr in _FILE_VARS:
            setattr(module, attr, _coerce(attr, value))
        elif attr in _CREDENTIAL_VARS:
            logger.warning(
                "tdfs4ds: '%s' is a credential — use a .env file or the "
                "TDFS4DS_%s environment variable instead of a JSON config "
                "file to avoid committing secrets. Ignored.",
                key, attr,
            )
        else:
            logger.warning(
                "tdfs4ds: unknown config key '%s' in %s — ignored.", key, path
            )


def _parse_dotenv(path):
    """
    Parse *path* as a ``.env`` file and return a ``{ATTR: raw_value}`` dict
    for every ``TDFS4DS_*`` variable found.

    Handles:
    - ``KEY=VALUE``
    - ``KEY="VALUE"`` / ``KEY='VALUE'``
    - ``export KEY=VALUE``
    - ``# comments`` and blank lines
    """
    result = {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except OSError:
        return result

    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.lower().startswith('export '):
            line = line[7:].strip()
        if '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        value = value.strip()
        # Strip surrounding matching quotes
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        if key.startswith('TDFS4DS_'):
            attr = key[len('TDFS4DS_'):]
            result[attr] = value

    return result


def _apply_dotenv(module, path):
    """Parse *path* as a ``.env`` file and apply ``TDFS4DS_*`` entries to *module*."""
    entries = _parse_dotenv(path)
    for attr, value in entries.items():
        if attr in _ALL_ENV_VARS:
            setattr(module, attr, _coerce(attr, value))
        else:
            logger.warning(
                "tdfs4ds: unknown .env variable 'TDFS4DS_%s' in %s — ignored.",
                attr, path,
            )


def _apply_env(module):
    """Apply ``TDFS4DS_*`` OS environment variables to *module*."""
    for attr in _ALL_ENV_VARS:
        env_val = os.environ.get(f'TDFS4DS_{attr}')
        if env_val is not None:
            setattr(module, attr, _coerce(attr, env_val))


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------

_JSON_CANDIDATES = [
    Path('tdfs4ds.json'),
    Path.home() / '.tdfs4ds' / 'config.json',
]

_DOTENV_CANDIDATES = [
    Path('.env'),
    Path.home() / '.tdfs4ds' / '.env',
]


def _load_config(module):
    """
    Called automatically during ``import tdfs4ds``.

    Load order (lowest → highest priority):
      JSON config file → .env file → OS env vars
    """
    for candidate in _JSON_CANDIDATES:
        if candidate.exists():
            _apply_file(module, candidate)
            break

    for candidate in _DOTENV_CANDIDATES:
        if candidate.exists():
            _apply_dotenv(module, candidate)
            break

    _apply_env(module)


def load_config(path=None, dotenv_path=None):
    """
    (Re-)load configuration from external sources.

    Useful for pointing at non-default config files or refreshing values
    mid-session.  Applies sources in priority order (lowest first):

    1. JSON config file (at *path* or auto-discovered)
    2. ``.env`` file (at *dotenv_path* or auto-discovered)
    3. OS ``TDFS4DS_*`` environment variables (always applied)

    Parameters
    ----------
    path : str or pathlib.Path, optional
        Explicit path to a JSON config file.  Skips auto-discovery when given.
    dotenv_path : str or pathlib.Path, optional
        Explicit path to a ``.env`` file.  Skips auto-discovery when given.

    Examples
    --------
    Auto-discover all sources::

        import tdfs4ds
        tdfs4ds.load_config()

    Explicit paths::

        tdfs4ds.load_config(
            path='/project/configs/feature_store.json',
            dotenv_path='/project/.env.local',
        )

    **JSON config format** (``tdfs4ds.json``)::

        {
            "schema": "MY_DATABASE",
            "data_domain": "MY_PROJECT",
            "display_logs": true,
            "store_feature": "MERGE",
            "varchar_size": 1024,
            "instruct_model_provider": "openai",
            "instruct_model_model": "gpt-4o"
        }

    Keys are case-insensitive.  ``instruct_model_api_key`` is rejected from
    JSON config — use a ``.env`` file or OS env var instead.

    **``.env`` file format**::

        TDFS4DS_SCHEMA=MY_DATABASE
        TDFS4DS_DATA_DOMAIN=MY_PROJECT
        TDFS4DS_INSTRUCT_MODEL_API_KEY=sk-...

    Only ``TDFS4DS_*`` variables are read from the ``.env`` file.
    Add ``.env`` to ``.gitignore`` to keep secrets out of source control.
    """
    import tdfs4ds as _mod

    # JSON config
    if path is not None:
        _apply_file(_mod, Path(path))
    else:
        for candidate in _JSON_CANDIDATES:
            if candidate.exists():
                _apply_file(_mod, candidate)
                break

    # .env file
    if dotenv_path is not None:
        _apply_dotenv(_mod, Path(dotenv_path))
    else:
        for candidate in _DOTENV_CANDIDATES:
            if candidate.exists():
                _apply_dotenv(_mod, candidate)
                break

    # OS env vars (always last — highest external priority)
    _apply_env(_mod)
