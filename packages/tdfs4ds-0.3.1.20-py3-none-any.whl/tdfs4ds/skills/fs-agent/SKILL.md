---
name: Feature Store: Agent
description: Launch the tdfs4ds consumer agent chatbot — configure embedding models, build the Chroma vector index from the business dictionary, test the agent, and start the Gradio UI. Invoke when the user wants a conversational interface for business consumers to ask natural-language questions about features, datasets, definitions, freshness, lineage, or how features are calculated.
argument-hint: [embedding-provider] [chroma-mode: local|server]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to set up and launch the `tdfs4ds` **consumer agent** — a conversational chatbot that lets business users ask natural-language questions about features, datasets, definitions, data freshness, lineage, and how features are calculated. The agent runs as a LangGraph state machine over an embedding-backed vector index of the **business dictionary**.

User context: $ARGUMENTS

## Related skills (call before / after this one)

| Step | Skill | Why |
|------|-------|-----|
| Before | [`fs-setup`](../fs-setup/) | Establish the Teradata connection and run `tdfs4ds.setup()` once if catalogs are not yet provisioned. |
| Before | [`fs-document`](../fs-document/) | Populate the business dictionary — the agent answers only from documented objects. Run `document_process` / `document_dataset_incremental` / `document_feature_store_incremental` first. |
| After | [`fs-inspect`](../fs-inspect/) | If the agent says "no features found", inspect the feature catalog and the follow-up table to confirm what is actually registered. |

## Prerequisites

The agent answers only from the **business dictionary** — three temporal tables populated by:

- `document_process` / `document_process_incremental` (see `fs-document`)
- `document_dataset_incremental`
- `document_feature_store_incremental`
- `upload_business_dictionary_objects` / `upload_business_dictionary_columns` / `upload_business_dictionary_sections`

If the dictionary is empty, **run documentation first** — the agent will not invent answers.

Ask for any missing values before generating code:

- **Embedding provider** — `'openai'`, `'vllm'`, `'azure'`, or `'bedrock'`. Determines how vectors are computed.
- **Chroma mode** — `'local'` (persist to disk under `CHROMA_PATH`) or `'server'` (connect to a running Chroma instance via `CHROMA_HOST`/`CHROMA_PORT`).

---

## Pattern

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, INSTRUCT_MODEL_*, EMBEDDING_MODEL_*, CHROMA_*) are auto-loaded
# from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'], create_if_missing=True)
tdfs4ds.select_data_domain('<DATA_DOMAIN>')   # or set TDFS4DS_DATA_DOMAIN in .env

# ---------------------------------------------------------------------------
# Instruct model — intent classification + answer synthesis
# Preferred: set TDFS4DS_INSTRUCT_MODEL_* in .env — auto-loaded at import.
# ---------------------------------------------------------------------------
tdfs4ds.INSTRUCT_MODEL_PROVIDER = '<PROVIDER>'                 # 'openai' | 'vllm' | 'azure' | 'bedrock'
tdfs4ds.INSTRUCT_MODEL_URL      = os.getenv('FS_API_URL')      # None for default OpenAI / Bedrock
tdfs4ds.INSTRUCT_MODEL_API_KEY  = os.getenv('FS_API_KEY')
tdfs4ds.INSTRUCT_MODEL_MODEL    = os.getenv('FS_API_MODEL')

# ---------------------------------------------------------------------------
# Embedding model — for the Chroma vector index
# Falls back to INSTRUCT_MODEL_* if EMBEDDING_MODEL_* is not set.
# ---------------------------------------------------------------------------
tdfs4ds.EMBEDDING_MODEL_PROVIDER = '<EMBEDDING_PROVIDER>'      # 'openai' | 'vllm' | 'azure' | 'bedrock'
tdfs4ds.EMBEDDING_MODEL_URL      = os.getenv('FS_API_URL')    # e.g. 'https://api.example.com/v1/e5'
tdfs4ds.EMBEDDING_MODEL_API_KEY  = os.getenv('FS_API_KEY')
tdfs4ds.EMBEDDING_MODEL_MODEL    = '<EMBEDDING_MODEL>'         # e.g. 'text-embedding-3-small'
tdfs4ds.EMBEDDING_MODEL_DIM      = 1536

# Chroma vector store
tdfs4ds.CHROMA_MODE = 'local'                                  # 'local' | 'server'
tdfs4ds.CHROMA_PATH = './tdfs4ds_chroma'                       # disk path (local mode)
# tdfs4ds.CHROMA_HOST = 'localhost'                            # server mode only
# tdfs4ds.CHROMA_PORT = 8000                                   # server mode only

# ---------------------------------------------------------------------------
# 1. Verify the business dictionary has content (sanity check)
# ---------------------------------------------------------------------------
objects = tdml.execute_sql(
    f"""
    CURRENT VALIDTIME
    SELECT OBJECT_NAME, OBJECT_TYPE,
           BUSINESS_DESCRIPTION (VARCHAR(100)) AS BUSINESS_DESCRIPTION
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS}
    ORDER BY OBJECT_TYPE, OBJECT_NAME
    """
).fetchall()

print(f"Business dictionary: {len(objects)} object(s)")
for row in objects[:10]:
    print(f"  [{row[1]}] {row[0]:40s}  {(row[2] or '')[:60]}")

# ---------------------------------------------------------------------------
# 2. Build (or rebuild) the Chroma vector index
#    force_rebuild=False = incremental — only new/changed docs are embedded.
# ---------------------------------------------------------------------------
from tdfs4ds.agent import build_vector_index

build_vector_index(force_rebuild=False)

# ---------------------------------------------------------------------------
# 3. Smoke-test the agent programmatically
# ---------------------------------------------------------------------------
from tdfs4ds.agent import consumer_agent

print(consumer_agent("What features are available?", thread_id="test-1"))

# ---------------------------------------------------------------------------
# 4. Launch the Gradio chatbot (one-command equivalent: launch_chatbot_with_index)
# ---------------------------------------------------------------------------
from tdfs4ds.agent import launch_chatbot

demo = launch_chatbot(
    title="Feature Store Assistant",
    description=(
        "Ask questions about available features, datasets, definitions, "
        "data freshness, lineage, or how a feature is calculated — in French or English."
    ),
    port=7860,
    # public_base_url='https://my-jupyterhub.example.com',  # if behind a proxy
)

# tdml.remove_context()   # leave open while the chatbot is running
```

---

## Agent intents (consumer-agent skills)

The agent's skill set is data-driven — each skill is defined by a `ca-*` SKILL.md file in `tdfs4ds/skills/`.  Removing a file removes that intent from the agent; the available skills are loaded at graph construction time.

| Skill file | Intent | Trigger example |
|------------|--------|-----------------|
| [`ca-search`](../ca-search/) | `SEARCH` | "What features measure customer spending?" |
| [`ca-definition`](../ca-definition/) | `DEFINITION` | "What is `total_amount`?" |
| [`ca-usage`](../ca-usage/) | `USAGE` | "How do I use `avg_amount` in a model?" |
| [`ca-freshness`](../ca-freshness/) | `FRESHNESS` | "Is `total_amount` up to date?" |
| [`ca-summary`](../ca-summary/) | `SUMMARY` | "Give me a snapshot of the feature store" |
| [`ca-lineage`](../ca-lineage/) | `LINEAGE` | "Where does `total_amount` come from?" |
| [`ca-explain`](../ca-explain/) | `EXPLAIN` | "How is `total_amount` calculated?" |
| [`ca-dataset`](../ca-dataset/) | `DATASET` | "Which dataset exposes `total_amount`?" |

To restrict the agent to a subset of skills, pass the `skills=` parameter:

```python
consumer_agent("What features are available?", skills=["SEARCH", "SUMMARY"])
```

To discover installed consumer-agent skills programmatically:

```python
import tdfs4ds
tdfs4ds.consumer_agent_skill_catalog()   # {skill_name: {intent, description, ...}}
```

## Multi-turn memory

The agent uses LangGraph with a process-level `MemorySaver` checkpointer (singleton — never created per call). Pass the same `thread_id` to maintain context:

```python
consumer_agent("What datasets are available?",          thread_id="session-1")
consumer_agent("Tell me more about the first one",      thread_id="session-1")
consumer_agent("How is the first feature calculated?", thread_id="session-1")
consumer_agent("When was it last updated?",             thread_id="session-1")  # entity + feature remembered
```

Remembered state spans:

- `resolved_data_domain` — domain that owns the current feature
- `resolved_object_name` — last explicitly named feature / dataset
- `resolved_feature_triplet` — `(feature_name, entity_name, process_id, view_name)`
- `resolved_entity_name`, `resolved_feature_list` — entity + feature group in focus
- `resolved_column_sources` — column→source-table map from the last EXPLAIN answer (enables drilling into any column with "what is `<col>`?")

## Vector index details

`build_vector_index` populates three Chroma collections from the business dictionary:

- **`objects`** — table / view / dataset overviews
- **`sections`** — `OVERVIEW`, `ENTITY`, `FEATURE_THEMES`, `BUSINESS_QUESTIONS`, `INTENDED_AUDIENCE` (datasets)
- **`columns`** — per-column business descriptions

Documents are embedded in batches of 8 to respect TEI / OpenAI rate limits. `force_rebuild=False` is incremental — re-run it after every documentation pass.

## Rules

- The business dictionary must be populated **before** `build_vector_index`. Run `fs-document` first or call `document_feature_store_incremental(upload=True)` to cover the entire store in one pass.
- All `TDFS4DS_*` config can come from `.env` or `tdfs4ds.json`; explicit assignment always wins.
- For `'bedrock'`, no `URL` / `API_KEY` is needed — boto3 default credentials are used.
- The agent never invents answers — if the dictionary lacks coverage, fix the documentation, then re-run `build_vector_index(force_rebuild=False)`.
- The graph is a process-level singleton: do **not** wrap the agent in a fresh `StateGraph(...).compile(MemorySaver())` per call — every cross-turn state would be lost. Use `consumer_agent(...)` directly.
- `launch_chatbot_with_index(port=..., force_rebuild=False)` is the single-call equivalent of steps 2–4.
