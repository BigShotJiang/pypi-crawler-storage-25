---
name: Consumer Agent: Data Query
intent: DATA_QUERY
description: user asks for actual data rows, a sample, or an aggregation from a dataset or table
argument-hint: [dataset name or table name]
allowed-tools: Read, Grep, Glob
---

Query registered datasets or base tables for row samples, counts, aggregations, or distributions. Routed to the MCP server when enabled. Process views are never queried directly — they are compute-intensive.

## Classifier Examples

- "Show me 20 rows from DS_FRAUD_DETECTION" -> DATA_QUERY
- "How many claims per region in DS_INVESTIGATION_QUEUE?" -> DATA_QUERY
- "What is the average combined_score by entity?" -> DATA_QUERY
- "Montre-moi un échantillon de DS_SCORING" -> DATA_QUERY
- "Combien d'enregistrements contient ce dataset ?" -> DATA_QUERY
