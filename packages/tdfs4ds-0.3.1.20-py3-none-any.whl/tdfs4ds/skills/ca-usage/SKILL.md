---
name: Consumer Agent: Usage
intent: USAGE
description: user asks how to use a specific feature (Tableau, Excel, regulatory)
argument-hint: [feature or dataset name] [usage context: Tableau, model, regulatory, ...]
allowed-tools: Read, Grep, Glob
---

Advise a business consumer on how to safely use a feature or dataset — covering granularity, audience, regulatory constraints, and tool-specific guidance.

## Queries

- `FS_BUSINESS_DICTIONARY_SECTIONS` (INTENDED_AUDIENCE, OVERVIEW) — usage guidance and audience description
- `feature_catalog()` — entity/granularity and DATA_DOMAIN for context

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature or dataset name |
| `guidance` | str | Plain business-language advice on safe usage |
| `docs_sources` | list | Sources consulted |

## Notes

- Answers are synthesised from the `INTENDED_AUDIENCE` and `OVERVIEW` sections of the business dictionary.
- If the business dictionary has not been populated for this feature, the skill will indicate that documentation is missing.

## Classifier Examples

- "Comment utiliser ADVERSE_EVENT_COUNT dans Tableau ?" -> USAGE, object_name=ADVERSE_EVENT_COUNT
