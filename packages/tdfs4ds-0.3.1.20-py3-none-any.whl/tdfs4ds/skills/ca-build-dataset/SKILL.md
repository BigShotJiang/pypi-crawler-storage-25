---
name: Consumer Agent: Build Dataset
intent: BUILD_DATASET
description: user wants to create a new dataset for a specific analytical use case (e.g. churn, risk scoring, anomaly detection) — user describes the goal without needing to name a feature first
argument-hint: [analytical use case description]
allowed-tools: Read, Grep, Glob
---

Autonomously create a feature store dataset from a use-case description: resolves the entity, proposes relevant features, handles version conflicts interactively, validates the name, then calls `build_dataset()` and auto-documents the result.

## Queries

1. `_get_feature_catalog_with_docs()` — resolves entity from catalog; picks the entity with the most features when no feature name is given
2. `skill_propose_features(use_case, entity_name, all_features, top_n=20)` — LLM selects the most relevant features for the use case
3. `resolve_features_for_dataset(entity_name, feature_list)` → `get_feature_versions()` — splits features into a clean `{name: uuid}` dict and a version-conflict list
4. `skill_check_dataset_name(proposed_name)` — verifies the name is not already taken in `dataset_catalog()`
5. `build_dataset(entity_id, selected_features, view_name, schema_name)` — creates the Teradata view and registers it
6. `document_dataset_incremental(dataset_id)` — auto-generates documentation (skipped if no LLM provider is configured)

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `status` | str | `dataset_created` \| `creation_failed` \| `no_features_found` |
| `dataset_name` | str | Name of the created view |
| `schema` | str | Teradata schema |
| `feature_count` | int | Number of features included |
| `doc_status` | str | `success` \| `failed` \| `skipped` |
| `error` | str | Error message (only when `status=creation_failed`) |

## Notes

- The creation flow is multi-turn and managed by `node_skill_build_dataset` in `graph.py` — the pending states are `awaiting_entity_clarification`, `awaiting_feature_confirmation`, `awaiting_version_selection`, and `awaiting_dataset_name`.
- When the catalog returns no features, the agent asks the user to name the entity or subject area before giving up (`awaiting_entity_clarification`). Only if the retry also returns nothing does it report `no_features_found`.
- Version conflicts (feature has multiple registered process IDs) are presented as a numbered list; the user picks by number or view-name substring.
- `doc_status=skipped` when `INSTRUCT_MODEL_PROVIDER` is not set; `doc_status=failed` when documentation raised an exception after successful creation.

## Classifier Examples

- "Build me a dataset for churn analysis" -> BUILD_DATASET
- "Create a dataset for monthly anomaly detection" -> BUILD_DATASET
- "Je veux créer un dataset pour l'analyse de l'attrition" -> BUILD_DATASET
