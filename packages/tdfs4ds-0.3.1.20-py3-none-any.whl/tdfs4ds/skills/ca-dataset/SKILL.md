---
name: Consumer Agent: Dataset
intent: DATASET
description: user asks whether one or more features are available in a dataset, or which datasets expose them
argument-hint: [feature name(s), comma-separated for multi-feature]
allowed-tools: Read, Grep, Glob
---

Look up which datasets expose a given feature, or guide the user through a 4-step flow to create a new dataset if none exists yet.

## Queries (step 0 — initial lookup)

- `feature_catalog()` → `dataset_catalog()` — finds datasets that include the requested feature
- `get_dataset_features()` — feature versions per dataset view

## 4-step creation flow

When no dataset is found, the skill enters a multi-turn flow:

| Step | `pending_action` | What happens |
|------|-----------------|--------------|
| 0 | — | Lookup; if no dataset → propose creation |
| 1 | `awaiting_feature_selection` | LLM proposes top-20 relevant features for the use case |
| 2 | `awaiting_feature_confirmation` | User confirms or requests all features |
| 3 | `awaiting_dataset_name` | User provides a name; `skill_check_dataset_name` validates it |

## Returns (step 0 — single feature)

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature name |
| `datasets` | list | Datasets that expose the feature `{dataset_name, database, dataset_id}` |
| `status` | str | `'found'` or `'no_dataset'` |

## Returns (step 0 — multi-feature)

| Key | Type | Description |
|-----|------|-------------|
| `object_names` | list | Feature names queried |
| `per_feature` | list | `{feature_name, datasets, found}` for each feature |
| `intersection` | list | Datasets containing **all** requested features |
| `status` | str | `'found'` (all), `'partial'` (some), or `'no_dataset'` (none) |

## Notes

- The dataset creation flow is orchestrated by the graph node (`node_skill_dataset`), not by this skill function directly.
- After a successful name check (`status: name_available`), the proposed features and selection context are passed to the caller for downstream `build_dataset` code generation.
- DATASET can also be triggered as a **secondary intent** when a DEFINITION question includes dataset-related keywords (e.g. "same dataset?", "available in a dataset"). In that case `node_recognize_entity` sets `secondary_intent = "DATASET"` and `node_synthesize` runs both skills, appending the dataset result after the definition answer.

## Classifier Examples

- "Is nb_days_since_last_transaction available in a dataset I could use?" -> DATASET, object_name=nb_days_since_last_transaction
- "Dans quel dataset puis-je trouver ADHERENCE_RATE ?" -> DATASET, object_name=ADHERENCE_RATE
- "Is there a dataset that contains both feature1 and feature2?" -> DATASET, object_name=feature1,feature2
- "Dans quel dataset puis-je trouver FEATURE_A et FEATURE_B ensemble ?" -> DATASET, object_name=FEATURE_A,FEATURE_B
