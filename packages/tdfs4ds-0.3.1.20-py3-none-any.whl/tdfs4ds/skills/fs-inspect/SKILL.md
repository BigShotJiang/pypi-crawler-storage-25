---
name: Feature Store: Inspect
description: Generate code to audit the tdfs4ds feature store — list registered processes, feature and dataset catalogs, execution follow-up history, and how to re-run or remove processes. Invoke when the user wants to explore, monitor, or troubleshoot the feature store.
argument-hint: [data-domain] [scope: processes|features|datasets|followup|all]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to explore and monitor the `tdfs4ds` feature store.

User context: $ARGUMENTS

## Related skills

| Step | Skill | Why |
|------|-------|-----|
| Before | [`fs-setup`](../fs-setup/) | Connect first if no Teradata context is open. |
| Action | [`fs-document`](../fs-document/) / [`fs-lineage`](../fs-lineage/) | Once a process is found, run documentation or lineage. |
| Followup | [`fs-rollout`](../fs-rollout/) | Re-execute a registered process across time. |
| Stuck | [`fs-analyze`](../fs-analyze/) | If a run is slow, perform the full scalability analysis. |

Ask for any missing values before generating code:
- **Data domain** — project namespace (must match what was used during registration).
- **Scope** — what to inspect: `processes`, `features`, `datasets`, `followup`, or `all`.

Emit the relevant sections from the following pattern:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.DATA_DOMAIN = '<DATA_DOMAIN>'   # or set TDFS4DS_DATA_DOMAIN in .env

# ---------------------------------------------------------------------------
# Catalogs
# ---------------------------------------------------------------------------
process_cat = tdfs4ds.process_catalog()   # PROCESS_ID, VIEW_NAME, ENTITY_NAME, ...
feature_cat = tdfs4ds.feature_catalog()   # FEATURE_NAME, ENTITY_NAME, FEATURE_TABLE, ...
dataset_cat = tdfs4ds.dataset_catalog()   # VIEW_NAME, ENTITY_NAME, COMMENT, ...

tdfs4ds.get_dataset_entity()              # entity per dataset view
tdfs4ds.get_dataset_features()            # feature versions per dataset view

# ---------------------------------------------------------------------------
# Discover entities and features (scoped to DATA_DOMAIN)
# ---------------------------------------------------------------------------
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_list_entity,
    get_available_features,
)

get_list_entity()

entity = '<ENTITY_NAME>'
get_available_features(entity_id=entity)

# ---------------------------------------------------------------------------
# Execution follow-up — most recent runs first
# ---------------------------------------------------------------------------
follow_up = (
    tdfs4ds.process_store.process_followup.follow_up_report()
    .sort('START_DATETIME', ascending=False)
)
follow_up

# ---------------------------------------------------------------------------
# Look up a process ID by view name
# ---------------------------------------------------------------------------
from tdfs4ds.process_store.process_query_administration import get_process_id

list_views = process_cat[['VIEW_NAME']].to_pandas().VIEW_NAME.values
view_name  = [v for v in list_views if '<SUBSTRING>' in v][0]
process_id = get_process_id(view_name=view_name)
print(f'{view_name}  →  {process_id}')

# ---------------------------------------------------------------------------
# Re-execute a process (refresh features at current time)
# ---------------------------------------------------------------------------
tdfs4ds.run(process_id=process_id)

# ---------------------------------------------------------------------------
# Remove a process from the catalog (metadata only — feature data is preserved)
# ---------------------------------------------------------------------------
# tdfs4ds.process_store.process_query_administration.remove_process(process_id)

print('tdfs4ds version:', tdfs4ds.__version__)

tdml.remove_context()
```

## Follow-up status values

| Status | Meaning |
|--------|---------|
| `COMPLETED` | Process ran successfully |
| `RUNNING` | Currently executing, or crashed before writing `FAILED` |
| `FAILED,...` | Exception raised; suffix contains the error message |

A stale `RUNNING` record after a crash means `followup_close` did not execute — the feature data for that run is incomplete.

## Rules

- All catalog queries are scoped to `DATA_DOMAIN` — always set it before querying.
- `get_process_id(view_name=...)` looks up by the crystallized view name (e.g. `'FEAT_ENG_CUST'`), not the feature or entity name.
- `remove_process` removes only catalog metadata; underlying temporal feature tables and data are preserved.
