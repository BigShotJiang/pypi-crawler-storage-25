---
name: Consumer Agent: Definition
intent: DEFINITION
description: user asks what a specific feature or dataset means
argument-hint: [feature or dataset name(s), comma-separated for multiple]
allowed-tools: Read, Grep, Glob
---

Explain what a specific feature, column, or dataset is in plain business language, by resolving it through the feature catalog and business dictionary.

## Queries

Resolution chain (in order, falling back at each step):

0. **Entity recognition** (`_recognize_object_type`) — run before the skill to identify whether each named object is a feature, dataset, process, or unknown. The result is stored in `recognized_entities` in state and guides the lookup path.

1. **Feature path**:
   - a. `get_list_entity()` → `get_list_features(entity)` → `get_feature_versions(entity, features)` → process catalog → `FS_BUSINESS_DICTIONARY_COLUMNS` (view-scoped: `TABLE_NAME = process view`)
   - b. **Broad fallback** — if (a) returns no description: `FS_BUSINESS_DICTIONARY_COLUMNS` (column-name only: `COLUMN_NAME = feature_name`, any `TABLE_NAME`). Catches docs stored against a dataset view rather than the process view.

2. `FS_BUSINESS_DICTIONARY_COLUMNS` — direct column lookup (for non-feature columns); uses `hint_table_name` from a prior EXPLAIN turn when available.

3. `FS_BUSINESS_DICTIONARY_OBJECTS` + `FS_BUSINESS_DICTIONARY_SECTIONS` — dataset or view-level descriptions.

4. Vector index — semantic fallback.

5. **Catalog-only fallback** — if feature IS in the feature catalog but has no documentation anywhere: returns entity + process view from the catalog with a note that docs are pending. Returns `{"error": "documentation_not_available"}` only when the object is not found in any catalog at all.

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Resolved name (may differ from input if fuzzy-matched) |
| `explanation` | str | Plain business-language definition |
| `columns` | list | Related columns `{name, table, description}` |
| `docs_sources` | list | Sources consulted (e.g. `FEATURE_CATALOG`, `BD_COLUMNS`, `FEATURE_CATALOG_ONLY`) |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` when resolved |
| `from_catalog_only` | bool | True when answer is built from catalog metadata only (no business docs) |

## Notes

- `hint_entity_name` (from a prior turn) auto-disambiguates features that exist under multiple entities without prompting the user.
- `hint_table_name` (from a prior EXPLAIN turn) narrows the BD_COLUMNS lookup for column references found in a formula.
- When the question includes dataset-related keywords (e.g. "same dataset?") and all named objects are features, `node_recognize_entity` sets `secondary_intent = "DATASET"` so `node_synthesize` also appends a dataset-availability section automatically.

## Classifier Examples

- "Quelle est la definition metier de la feature ADHERENCE_RATE ?" -> DEFINITION, object_name=ADHERENCE_RATE
- "I heard about combined_score and risk_band. What are those, and are they in the same dataset?" -> DEFINITION, object_name=combined_score,risk_band
