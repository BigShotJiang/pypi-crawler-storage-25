---
name: Query Optimizer: Explain
intent: EXPLAIN
description: analyze the EXPLAIN plan of a SQL query and score its performance
argument-hint: [sql_query or process_id]
allowed-tools: Read
---

Analyze the EXPLAIN plan of a Teradata SQL query and score its quality from the SQL author's
perspective. Returns structured scores, warnings, and recommendations tagged `[You]`
(SQL-level fixes) or `[Data Engineer / DBA]` (infrastructure concerns).

## Execution

1. Resolve SQL: accept `sql_query` directly **or** `get_process_info(process_id)` → `PROCESS_SQL`
2. `tdml.execute_sql("EXPLAIN " + sql_query)` — retrieve the raw Teradata execution plan text
3. `document_sql_query_explain(sql_query, classify=True)` — LLM chain using
   [`qo-explain`](prompts/qo-explain.md) + [`qo-classify-items`](prompts/qo-classify-items.md):
   scores the plan, classifies `[You]` items, filters false positives
4. `_parse_explain_metrics(explain_text)` — deterministic parse of step count and spool objects

## Inputs

- `sql_query`: a SQL string to analyze directly
- `process_id`: a UUID from the process catalog — SQL is retrieved automatically

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `user_score` | int 1–5 | SQL quality — what the author controls (derived from `[You]` item count) |
| `global_score` | int 1–5 | Overall plan quality including infrastructure factors |
| `n_steps` | int | Numbered execution steps (plan depth), parsed deterministically |
| `n_spool_objects` | int | Distinct intermediate Spool objects referenced |
| `explanation` | str | 3–5 plain-language sentences about the query plan |
| `warnings` | list[str] | Prefixed `[You]` or `[Data Engineer / DBA]` |
| `recommendations` | list[str] | Prefixed `[You]` or `[Data Engineer / DBA]` |

## Notes

- `user_score` is derived from the count of `[You]` items — not an LLM-assigned number.
  Score 5 = no `[You]` items; Score 1 = critical issue (e.g. Cartesian product on multi-row tables).
- `classify=True` filters false positives: uncorrelated scalar subqueries and single-row CROSS JOINs
  are validated against ground-truth signals before counting against the score.
- [`qo-document-sql`](prompts/qo-document-sql.md) documents entity/feature columns; called
  separately by `document_sql_query()` in `genai/documentation.py`.
