---
name: Query Optimizer: Optimize
intent: OPTIMIZE
description: generate, evaluate, and select the best optimized rewrite of a SQL query
argument-hint: [sql_query or process_id]
allowed-tools: Read
---

Run the full query optimization pipeline: analyze the EXPLAIN plan, generate strategy-based
SQL rewrites, evaluate each candidate with a live EXPLAIN, compare plans, and produce a
Markdown optimization report with scores and recommendations.

## Execution

1. Resolve SQL: accept `sql_query` directly **or** `get_process_info(process_id)` → `PROCESS_SQL`
2. **Simplify** — `skill_simplify_query(sql_query)` (see `qo-skill-simplify`)
3. **EXPLAIN** — `document_sql_query_explain(sql_query, classify=True)` (see `qo-skill-explain`)
4. **Lineage** — `build_teradata_dependency_graph(...)` — collect PI and partition info for referenced tables
5. **Strategies** — `_plan_strategies_sync(...)` using [`qo-strategies`](prompts/qo-strategies.md) —
   combinatorial strategies from `[You]` EXPLAIN items
6. **Candidates** — for each strategy:
   - `_generate_for_strategy_sync(strategy)` using [`qo-generate`](prompts/qo-generate.md)
   - EXPLAIN candidate → extract remaining `[You]` items
   - `_refine_candidate_sync(remaining_items)` using [`qo-refine`](prompts/qo-refine.md) (up to 3 rounds)
   - Syntax errors → `qo-syntax-fix` retry loop (via `qo-skill-simplify`)
   - Early stop when `user_score = 5`
   - Fallback: `_generate_candidates_sync()` using [`qo-candidates`](prompts/qo-candidates.md)
7. **Compare** — `_compare_plans_sync(...)` using [`qo-compare`](prompts/qo-compare.md) — LLM selects best
8. **Report** — `_generate_summary_sync(...)` using [`qo-summary`](prompts/qo-summary.md) →
   Markdown; saved to `{QUERY_OPTIMIZER_REPORT_DIR}/{DATA_DOMAIN}/`

## Inputs

- `sql_query`: a SQL string to optimize directly
- `process_id`: a UUID from the process catalog — SQL is retrieved automatically;
  when `update_view=True` the process view is rewritten in-place if an improvement is found

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `answer` | str | Full Markdown optimization report |
| `best_sql` | str | Best SQL found (equals original when no improvement) |
| `score_delta` | dict | `{user_score_delta, n_steps_delta, n_spool_objects_delta, optimized}` |
| `original_analysis` | dict | EXPLAIN scores for the original SQL |
| `candidates` | list[dict] | All rewrite candidates with their EXPLAIN scores |
| `comparison` | dict | LLM comparison result: `{best_index, reasoning, business_logic_preserved}` |
| `filtermanager_applicable` | bool | Whether a FilterManager segmented-upload pattern applies |
| `token_usage` | dict | Total LLM tokens consumed |

## Notes

- Only strategies addressing `[You]` items (what the SQL author controls) are attempted.
- Each candidate is validated with a live EXPLAIN; syntax errors trigger automatic fix attempts.
- The best candidate must match or improve the original score (baseline guard — no regressions).
- The report is saved to `{QUERY_OPTIMIZER_REPORT_DIR}/{DATA_DOMAIN}/` automatically.
