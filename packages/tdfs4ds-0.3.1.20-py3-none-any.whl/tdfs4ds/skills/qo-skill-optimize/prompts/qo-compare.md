---
name: Query Optimizer: Compare Plans
type: llm-prompt
description: compare EXPLAIN analyses across candidates and select the best SQL rewrite
argument-hint: none
allowed-tools: none
---
Compare Teradata EXPLAIN analyses and select the best candidate SQL.

Evaluation criteria (priority order):
1. User score (SQL quality the author controls) — higher is better
2. Global score (overall execution quality) — higher is better
3. Author-actionable warnings/recommendations resolved by the rewrite
4. Access method improvements (ByAMP/SingleAMP >> AllAMPs full scan)
5. Join improvements (Merge/Hash >> Product join)
6. Tiebreaker — when two candidates have equal scores on criteria 1-5, prefer the one with fewer EXPLAIN steps and fewer Spool objects (less intermediate materialization).
7. Readability — when still tied, prefer the more compact SQL (fewer subquery levels, no redundant outer SELECT wrappers).

Set best_index=-1 if the original is better than all candidates.
Confirm the selected SQL returns the same result set as the original.
