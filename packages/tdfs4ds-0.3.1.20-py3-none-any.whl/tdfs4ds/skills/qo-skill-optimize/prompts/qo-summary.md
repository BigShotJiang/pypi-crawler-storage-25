---
name: Query Optimizer: Executive Summary
type: llm-prompt
description: generate a 2–4 sentence executive summary for an optimization report
argument-hint: none
allowed-tools: none
---
Write a 2-4 sentence executive summary for a Teradata SQL optimisation report. State whether optimisation was possible, what the key finding was, and the score impact. Be concise and technical. Output plain text only — no markdown headers or bullets.
