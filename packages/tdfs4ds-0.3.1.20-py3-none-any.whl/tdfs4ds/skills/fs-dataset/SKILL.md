---
name: Feature Store: Dataset
description: Generate code to explore available entities and features in the tdfs4ds feature store, select specific feature versions, and build a denormalised snapshot view ready for model development. Invoke when the user wants to build or refresh a dataset view.
argument-hint: [entity-name] [feature-list] [dataset-view-name]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to explore the `tdfs4ds` feature store, select feature versions, and build a denormalised snapshot dataset view.

User context: $ARGUMENTS

## Related skills

| Step | Skill | Why |
|------|-------|-----|
| Before | [`fs-upload`](../fs-upload/) | Features must be registered before a dataset can reference them. |
| Inspect | [`fs-inspect`](../fs-inspect/) | List entities, features, processes, and follow-up runs to pick what to include. |
| After | [`fs-document`](../fs-document/) | Document the dataset (`document_dataset_incremental`) so it appears in the consumer agent. |
| After | [`fs-lineage`](../fs-lineage/) | Visualise where the dataset's features come from. |

Ask for any missing values before generating code:
- **Entity name** — the entity whose features go into the dataset (e.g. `'CustomerID'`).
- **Feature list** — names of the features to include.
- **Dataset view name** — name for the output Teradata view (e.g. `'DATASET_CUSTOMER'`).
- **Comment** — optional description stored in the dataset catalog.
- **Point-in-time** — timestamp for historical snapshots, or `None` for current state.
- **Join type** — `'INNER'` (default, keeps only entities that have every selected feature) or `'FULL OUTER'` (keeps all entities, `NULL` for missing features).
- **Grouped strategy** — suggest `grouped=True` when the dataset has many features (> ~10) that share the same source table; it collapses N JOINs into one sub-query per (table, version) group using `MAX(CASE WHEN)` pivoting, which reduces JOIN fan-out and often improves EXPLAIN scores significantly.

Emit the following pattern, substituting real values for every `<PLACEHOLDER>`:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.DATA_DOMAIN = '<DATA_DOMAIN>'   # or set TDFS4DS_DATA_DOMAIN in .env

# Optional: point-in-time query (None = latest values)
# tdfs4ds.FEATURE_STORE_TIME = '2024-06-01 00:00:00'

# ---------------------------------------------------------------------------
# 1. Discover available entities and features
# ---------------------------------------------------------------------------
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_list_entity,
    get_available_features,
    get_feature_versions,
)

get_list_entity()

entity = '<ENTITY_NAME>'
get_available_features(entity_id=entity)

# ---------------------------------------------------------------------------
# 2. Resolve feature versions
#    Returns {feature_name: process_uuid} — pass directly to build_dataset.
#    Never construct this dict manually.
# ---------------------------------------------------------------------------
feature_selection = get_feature_versions(
    entity_name=entity,
    features=['<FEATURE_1>', '<FEATURE_2>', '<FEATURE_3>'],
)

# ---------------------------------------------------------------------------
# 3. Inspect the generated DDL before creating the view (optional)
# ---------------------------------------------------------------------------
# sql = build_dataset(
#     entity_id=entity,
#     selected_features=feature_selection,
#     view_name='<DATASET_VIEW_NAME>',
#     return_query=True,   # returns DDL string without executing
# )
# print(sql)

# ---------------------------------------------------------------------------
# 4. Build the dataset view
# ---------------------------------------------------------------------------
from tdfs4ds import build_dataset

dataset = build_dataset(
    entity_id=entity,
    selected_features=feature_selection,
    view_name='<DATASET_VIEW_NAME>',
    comment='<DESCRIPTION>',
    # join_type='INNER',    # default — drop entities missing any feature
    # join_type='FULL OUTER',  # keep all entities, NULL for missing features
    # grouped=False,        # default — one sub-query per feature (classic multi-join)
    # grouped=True,         # recommended for wide datasets: MAX(CASE WHEN) pivot
    #                       # reduces N JOINs to N_distinct_(table,version) groups
)

dataset
dataset.shape

# Reuse in future sessions without rebuild:
# dataset = tdml.DataFrame(tdml.in_schema(Param['database'], '<DATASET_VIEW_NAME>'))

tdml.remove_context()
```

## Rules

- `selected_features` must come from `get_feature_versions()` — never construct the dict manually.
- `build_dataset` creates a **view**, not a table; it always reflects the state at `FEATURE_STORE_TIME`.
- Set `tdfs4ds.FEATURE_STORE_TIME` **before** calling `build_dataset` for historical snapshots.
- Multiple entities cannot be combined in one `build_dataset` call — join the resulting views manually.
- All catalog queries are scoped to `DATA_DOMAIN` — always set it before querying.
- Use `grouped=True` for wide datasets (many features from the same source table). It lowers JOIN count from N_features to N_distinct_(table, version) and typically improves the EXPLAIN score. Use `grouped=False` (default) when features come from many different tables or when single-entity PI lookups are the dominant access pattern.
- Use `join_type='FULL OUTER'` only when downstream models tolerate `NULL` feature values. Default `'INNER'` is safer — it drops entities that lack any selected feature, keeping the dataset clean.
- Use `return_query=True` to review the generated DDL before running it — useful for performance review or when working with `fs-analyze`.
- For **hyper-segmented ML**: to make a partition column (e.g. `region`) available in the dataset, it must have been registered as a feature at upload time — SELECTed in the view SQL and listed in `feature_names` in `upload_features()`. Once registered, include it in `get_feature_versions()` like any other feature; no manual join to the source table is needed.
