---
name: Query Optimizer: Simplify
intent: SIMPLIFY
description: simplify and normalize SQL structure without changing query semantics
argument-hint: [sql_query or process_id]
allowed-tools: Read
---

Flatten unnecessary nesting, remove redundant subquery wrappers, and normalize SQL structure
while preserving exact query semantics. Validates the simplified SQL against the live
database via EXPLAIN before accepting it.

## Execution

1. Resolve SQL: accept `sql_query` directly **or** `get_process_info(process_id)` → `PROCESS_SQL`
2. Deterministic structural passes: passthrough-filter elimination, identity-wrapper removal,
   merged-derived-table flattening (no LLM)
3. `_simplify_sql_sync(sql_query, ddls)` — LLM pass using [`qo-simplify`](prompts/qo-simplify.md)
   to further flatten nesting and merge CTEs
4. `tdml.execute_sql("EXPLAIN " + simplified_sql)` — validate against live database;
   syntax errors → [`qo-syntax-fix`](prompts/qo-syntax-fix.md) retry loop (up to 3 attempts)
5. Accept simplified result only if EXPLAIN succeeds **and** `user_score` does not regress;
   otherwise return original unchanged

## Inputs

- `sql_query`: a SQL string to simplify directly
- `process_id`: a UUID from the process catalog — SQL is retrieved automatically

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `simplified` | bool | Whether a simpler, validated form was found and accepted |
| `simplified_sql` | str | The simplified SQL (equals `original_sql` when `simplified=False`) |
| `original_sql` | str | The input SQL before simplification |
| `original_score` | int | `user_score` of the original (1–5) |
| `simplified_score` | int | `user_score` of the simplified form (1–5) |

## When it helps

- Deeply nested subqueries that can be expressed as CTEs or flat joins
- Redundant identity-wrapper SELECT layers that add no logic
- Unnecessary DISTINCT or GROUP BY that duplicates outer aggregation

## Notes

- Simplification is a non-regression operation: the score must not decrease.
- Use as a pre-step before full optimization to give the optimizer cleaner input.
