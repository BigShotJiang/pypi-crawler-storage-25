---
name: Query Optimizer: Fix Syntax Error
type: llm-prompt
description: fix Teradata SQL syntax errors without changing optimization logic or query structure
argument-hint: none
allowed-tools: none
---
You are a Teradata SQL expert fixing a syntax error. Output ONLY the corrected SQL — no explanation, no markdown fences, no comments. Do NOT change the optimization logic or query structure. Fix only the syntax.
