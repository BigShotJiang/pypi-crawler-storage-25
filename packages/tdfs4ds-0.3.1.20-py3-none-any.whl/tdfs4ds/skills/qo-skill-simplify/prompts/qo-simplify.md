---
name: Query Optimizer: Simplify SQL
type: llm-prompt
description: produce the most compact, readable Teradata SQL form while preserving exact semantics
argument-hint: {teradata_sql_guide}
allowed-tools: none
---
You are a Teradata SQL expert. Output ONLY a JSON object — no preamble, no explanation. Start your response with the opening brace.

Your task is to produce the MOST COMPACT and READABLE form of the SQL below while preserving its exact semantics (same result set, same column names).

SIMPLIFICATION RULES (apply all that match):
1. Remove unnecessary derived-table nesting — if a subquery only re-aliases columns or adds computed columns that could live in the parent SELECT, merge the layers.
2. When there are 3+ nesting levels, consider using CTEs (WITH clauses) to flatten the structure. But do NOT split a single-pass aggregation into multiple CTEs just for readability — keep the fewest CTEs possible.
3. Compute date arithmetic, ratios, and other derived columns in the same SELECT that reads from the aggregation — no intermediate layer needed.
4. Teradata allows expressions referencing aggregate results in the same outer SELECT that reads from a GROUP BY subquery or CTE. Use this to reduce nesting.
5. Keep the same column names/aliases in the final output.
6. If the query scans the same table twice for different aggregations that share the same GROUP BY, merge them into a single pass using conditional aggregation (e.g. SUM(CASE WHEN ... THEN 1 ELSE 0 END)).

{teradata_sql_guide}
SAFETY RULE — copy complex expressions verbatim:
Complex Teradata expressions (INTERVAL, PERIOD, TD_SYSFNLIB, FORMAT, CAST with custom types, temporal qualifiers) must be copied CHARACTER-FOR-CHARACTER from the original SQL. Do NOT paraphrase or reformulate them.

CRITICAL SEMANTIC RULE — do NOT change subquery scope or filter conditions:
Scalar subqueries inside aggregations define core business logic. You MUST preserve their exact scope:
  - If a scalar subquery has NO WHERE clause (global aggregate), keep it without a WHERE clause.
  - If a scalar subquery has a correlated WHERE clause, keep that WHERE clause exactly.
  - NEVER add a WHERE clause to a subquery that did not have one — this changes the business logic (e.g. global threshold → per-customer threshold is a semantic change).
  - NEVER remove a WHERE clause from a correlated subquery.

Output SQL only — no inline comments (-- ...), no block comments (/* ... */), no explanatory text inside the sql field.
Set strategy to 'simplification'. Leave business_assumptions empty.
