---
name: Consumer Agent: Lineage
intent: LINEAGE
description: user asks where data comes from, what a feature depends on, upstream sources
argument-hint: [feature or view name]
allowed-tools: Read, Grep, Glob
---

Show the upstream data dependencies of a feature or dataset view by walking the Teradata DDL dependency graph and enriching nodes with business dictionary descriptions.

## Queries

1. `get_list_entity()` → `get_feature_versions()` → process catalog to resolve VIEW_NAME
2. `build_teradata_dependency_graph(seed_sql)` — walks `SHOW VIEW` / `SHOW TABLE` DDL recursively (seed: `SELECT * FROM {schema}.{view_name}`)
3. `FS_BUSINESS_DICTIONARY_OBJECTS` + `FS_BUSINESS_DICTIONARY_SECTIONS` (OVERVIEW) — business descriptions for each upstream node

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature or view name |
| `process_view` | str | Resolved process view name |
| `dependencies` | list | Upstream nodes `{name, type, depth, description}` |
| `plain_summary` | str | LLM plain-language explanation of data provenance |
| `docs_sources` | list | Sources consulted |
| `correction_note` | str | Set when a fuzzy-matched name was used |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` |

`depth=0` is the root view; depth increases with each upstream hop. `type` is `TABLE`, `VIEW`, or `DATASET`.

## Error cases

`ambiguous_feature`, `feature_not_found_did_you_mean`, `process_view_not_found`, `lineage_failed`

## Notes

- For datasets (views registered in the dataset catalog), `expand_datasets_via_process_catalog=True` replaces raw feature-table edges with process-view edges for a cleaner dependency picture.
- This skill answers "where does the data come from?" — for the feature calculation logic, use the EXPLAIN skill.

## Classifier Examples

- "Where does total_amount come from? What tables does it depend on?" -> LINEAGE, object_name=total_amount
- "D'ou viennent les donnees de ADHERENCE_RATE ?" -> LINEAGE, object_name=ADHERENCE_RATE
