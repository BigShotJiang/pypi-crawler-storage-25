---
name: Feature Store: Upload
description: Generate Python code to engineer features from a Teradata source, persist as a permanent view, and register in the tdfs4ds feature store with upload_features. Invoke when the user wants to create or update a feature engineering process.
argument-hint: [source-table] [entity-column] [feature-columns]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to engineer features from a Teradata source, persist the logic as a permanent view, and register + upload the features to the `tdfs4ds` feature store.

User context: $ARGUMENTS

## Related skills (chain in this order)

| Before / After | Skill | Why |
|----------------|-------|-----|
| Before | [`fs-setup`](../fs-setup/) | Open the Teradata context and activate a data domain. |
| Optional | [`fs-filter`](../fs-filter/) | Segment a large source into iterative passes with `FilterManager`. |
| After | [`fs-document`](../fs-document/) | LLM-generated business description + EXPLAIN score 1–5 for the registered process. |
| After | [`fs-analyze`](../fs-analyze/) | If `USER_SCORE` is 1–3, run the full scalability analysis and propose a rewrite. |
| After | [`fs-rollout`](../fs-rollout/) | Backfill features across a date range with `TimeManager`. |

Ask for any missing values before generating code:
- **Source database and table** — where the raw data lives.
- **Entity column(s)** — the primary key. Plain string for single-column auto-detected types, or a dict with SQL types for multiple columns: `{'CUSTOMER_ID': 'BIGINT', 'EVENT_DATE': 'DATE'}`.
- **Feature columns** — list of derived columns to register as features.
- **View name** — name for the permanent Teradata view.
- **Metadata** — optional dict with descriptive tags.
- **Dataset view name** — optional; if provided, also creates a ready-to-use dataset view.

---

### Pattern A — Raw SQL view (preferred)

Use when feature logic requires Teradata-specific SQL (e.g. `PERCENTILE_CONT`, complex aggregations, window functions). Persist directly with `REPLACE VIEW` — no `crystallize_view` needed.

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.select_data_domain('<DATA_DOMAIN>')   # or set TDFS4DS_DATA_DOMAIN in .env

# ---------------------------------------------------------------------------
# 1. Write feature SQL and persist as a permanent Teradata view
# ---------------------------------------------------------------------------
feature_sql = f"""
LOCKING ROW FOR ACCESS
SELECT
    <ENTITY_COLUMN>,
    <AGGREGATION_EXPRESSION>  AS <FEATURE_NAME>
FROM <SOURCE_DATABASE>.<SOURCE_TABLE>
GROUP BY <ENTITY_COLUMN>
"""

tdml.execute_sql(f"REPLACE VIEW {Param['database']}.<VIEW_NAME> AS {feature_sql}")
df_features_proc = tdml.DataFrame(tdml.in_schema(Param['database'], '<VIEW_NAME>'))

# ---------------------------------------------------------------------------
# 2. Register and upload features
# ---------------------------------------------------------------------------
from tdfs4ds import upload_features

feature_names = ['<FEATURE_NAME>']

upload_features(
    df_features_proc,
    entity_id=<ENTITY_ID>,           # str or {'COL': 'SQL_TYPE', ...}
    feature_names=feature_names,
    metadata={'project': '<PROJECT_NAME>'},
    dataset_view_name='<DATASET_VIEW>',  # name derived from VIEW_NAME, e.g. ds_<base_name>
    # partitioning='PARTITION BY COLUMN',  # SQL DDL clause appended to the feature table's CREATE TABLE
    #   — controls physical storage layout only; does not affect which columns are available
)

tdml.remove_context()
```

---

### Pattern B — teradataml DataFrame methods + `crystallize_view` (fallback)

Use **only** when the feature transformation is expressed through the teradataml DataFrame API. Those build a *temporary* view that disappears when the context is removed; `crystallize_view` persists it as a permanent database object.

```python
# ... connection setup same as Pattern A ...

from tdfs4ds.utils.lineage import crystallize_view
from tdfs4ds import upload_features

# Chained teradataml DataFrame methods produce a *temporary* Teradata view.
# crystallize_view persists it as a permanent database object before upload.
source_data = tdml.DataFrame(tdml.in_schema('<SOURCE_DATABASE>', '<SOURCE_TABLE>'))
df_features = source_data.groupby('<ENTITY_COLUMN>').agg({
    '<VALUE_COLUMN>': ['sum', 'mean'],
})
feature_names = ['sum_<VALUE_COLUMN>', 'mean_<VALUE_COLUMN>']

df_features_proc = crystallize_view(
    df_features,
    view_name='<VIEW_NAME>',
    schema_name=Param['database'],
)

upload_features(
    df_features_proc,
    entity_id=<ENTITY_ID>,
    feature_names=feature_names,
    metadata={'project': '<PROJECT_NAME>'},
    dataset_view_name='<DATASET_VIEW>',  # ds_<base_name>
)

tdml.remove_context()
```

## Rules

- **Prefer Pattern A** — write feature logic as raw SQL with `REPLACE VIEW`. Use `DataFrame.from_query(sql)` for any teradataml data access.
- Only use `crystallize_view` (Pattern B) when the teradataml DataFrame API is unavoidable and produces a temporary view.
- `entity_id` must be a **dict** when SQL types need to be specified: `{'CUSTOMER_ID': 'BIGINT', 'EVENT_DATE': 'DATE'}`.
- `feature_names` must be a subset of the view's columns, **excluding** the entity column(s).
- **Never register a 1:1 copy of a raw source column** (e.g. uploading `claims_raw.amount` unchanged). That is pure data duplication with no governance value. Join the source table in the training query instead and append the column to `column_names_X`.
- `upload_features` internally calls `run(process_id)` — intentional; it exercises the same refresh path used by `roll_out`.
- Always pass `dataset_view_name` to build a denormalised dataset view alongside feature registration. Name it by replacing the `vw_feat_` prefix with `ds_` (e.g. `vw_feat_savings_dist` → `ds_savings_dist`).
- Always include `LOCKING ROW FOR ACCESS` as the first line of every `REPLACE VIEW … AS` body. This tells Teradata to use access locks, preventing read queries from blocking concurrent writers. Omitting it causes read-lock contention on busy feature views.
- When features will feed **hyper-segmented ML** (one model per partition, e.g. per region): include the partition column (e.g. `region`) in the view SQL **and** in `feature_names`. This registers it as a feature so `build_dataset()` includes it naturally — no manual JOIN to the source table needed at training time. Use `partitioning=` separately if you want to physically co-locate rows by that column for efficient partition elimination.
