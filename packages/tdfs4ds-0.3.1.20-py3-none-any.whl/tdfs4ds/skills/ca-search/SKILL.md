---
name: Consumer Agent: Search
intent: SEARCH
description: user is looking for features or datasets matching a business need
argument-hint: [natural-language description of the business need]
allowed-tools: Read, Grep, Glob
---

Find features or datasets that match a business need expressed in natural language, using vector search over the business dictionary and feature catalog.

## Queries

- `feature_catalog()` — all features with FEATURE_NAME, ENTITY_NAME, DATA_DOMAIN
- `FS_BUSINESS_DICTIONARY_SECTIONS` (FEATURE_THEMES, BUSINESS_QUESTIONS) — thematic context
- `FS_BUSINESS_DICTIONARY_OBJECTS` — object-level descriptions
- Vector index (Chroma) — semantic search over objects, sections, and column docs

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `matches` | list | Up to 10 results, each `{name, type, justification}` |
| `docs_sources` | list | Which sources were hit (FEATURE_CATALOG, BD_OBJECTS, BD_SECTIONS, VECTOR_INDEX) |

`type` is `'feature'` or `'dataset'`. `justification` is a one-sentence explanation of why the result matches.

## Notes

- Requires the Chroma vector index to be built (`build_vector_index`) for semantic results.
- Falls back to catalog-only results if the vector index is unavailable.

## Classifier Examples

- "Quelles features sont disponibles pour analyser l'efficacite des traitements ?" -> SEARCH
