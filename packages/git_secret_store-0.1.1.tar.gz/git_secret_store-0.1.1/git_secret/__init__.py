# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Hashberg Ltd

from __future__ import annotations

__version__ = "0.1.1"
