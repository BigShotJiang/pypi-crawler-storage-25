# bpsai-agent-enforce

Enforcement contracts and governance interfaces for BPS AI agents.

Provides gate, pipeline, signal-validation, evidence-mechanics, and hypothesis-lifecycle abstractions that agents implement to enforce correctness and compliance.

## Installation

```bash
pip install bpsai-agent-enforce
```

## Quick Start

### Enforcement Gate

Run content through a set of rules — all must pass:

```python
from bpsai_agent_core.enforcement import EnforcementRule, EnforcementResult
from bpsai_agent_enforce import EnforcementGate


class NoProfanityRule(EnforcementRule):
    def check(self, content, context=None):
        blocked = {"bad", "worse"}
        found = blocked & set(content.lower().split())
        return EnforcementResult(
            passed=len(found) == 0,
            rule_name="no_profanity",
            message=f"Blocked words: {found}" if found else "Clean",
        )


gate = EnforcementGate(rules=[NoProfanityRule()])
assert gate.passes("hello world")
assert not gate.passes("hello bad world")
```

### Enforcement Pipeline

Short-circuits on the first hard failure while collecting all soft warnings:

```python
from bpsai_agent_enforce import EnforcementPipeline, PipelineResult

pipeline = EnforcementPipeline(rules=[NoProfanityRule()])
result: PipelineResult = pipeline.run("some content")

if not result.passed:
    for v in result.violations:
        print(f"BLOCKED: {v.message}")
for w in result.soft_warnings:
    print(f"WARNING: {w.message}")
```

### Signal Validation

Implement `SignalValidator` to enforce output schemas before signals enter the store:

```python
from bpsai_agent_enforce import SignalValidator, ValidationResult


class MyValidator(SignalValidator):
    @property
    def required_fields(self):
        return ["source", "timestamp", "payload"]

    def validate(self, signal):
        missing = [f for f in self.required_fields if f not in signal]
        return ValidationResult(valid=not missing, errors=missing)
```

### Evidence Mechanics

Implement `DedupChecker`, `RateLimitChecker`, or `FreshnessChecker` to control how evidence accumulates against hypotheses:

```python
from bpsai_agent_enforce import DedupChecker


class MyDedupChecker(DedupChecker):
    def __init__(self):
        self._seen: set[str] = set()

    def is_duplicate(self, evidence_id, context=None):
        return evidence_id in self._seen

    def reset(self):
        self._seen.clear()
```

### Hypothesis Lifecycle Gate

Implement `HypothesisLifecycleGate` to govern hypothesis state transitions:

```python
from bpsai_agent_enforce import HypothesisLifecycleGate, TransitionResult


class MyLifecycleGate(HypothesisLifecycleGate):
    @property
    def review_criteria(self):
        return ["evidence_threshold", "confidence_minimum"]

    def check_transition(self, hypothesis_id, from_status, to_status, context=None):
        return TransitionResult(allowed=True, reason="Criteria met")
```

## API Reference

| Export | Kind | Purpose |
|--------|------|---------|
| `EnforcementGate` | Class | All-must-pass rule gate |
| `EnforcementPipeline` | Class | Short-circuit pipeline (sync) |
| `AsyncEnforcementPipeline` | Class | Short-circuit pipeline (async) |
| `PipelineResult` | Dataclass | Pipeline output with violations + warnings |
| `SignalValidator` | ABC | Signal schema validation |
| `ValidationResult` | Dataclass | Validation output |
| `DedupChecker` | ABC | Evidence deduplication |
| `RateLimitChecker` | ABC | Per-cycle rate limiting |
| `FreshnessChecker` | ABC | Evidence age checking |
| `HypothesisLifecycleGate` | ABC | Hypothesis transition governance |
| `TransitionResult` | Dataclass | Transition check output |
| `EnforcementRule` | ABC | Re-export from agent-core |
| `AsyncEnforcementRule` | ABC | Re-export from agent-core |
| `EnforcementResult` | Dataclass | Re-export from agent-core |

## Requirements

- Python >= 3.11
- `bpsai-agent-core >= 0.1.0`

## License

Proprietary - BPS AI Software
