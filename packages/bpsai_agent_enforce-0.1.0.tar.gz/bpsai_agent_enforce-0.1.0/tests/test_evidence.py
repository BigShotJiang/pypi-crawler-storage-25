"""Tests for evidence mechanics contracts."""

from __future__ import annotations

from typing import Any

import pytest

from bpsai_agent_enforce.evidence import (
    DedupChecker,
    FreshnessChecker,
    RateLimitChecker,
)


# --- Test helpers ---


class SimpleDedupChecker(DedupChecker):
    def __init__(self) -> None:
        self._seen: set[str] = set()

    def is_duplicate(self, evidence_id: str, context: dict[str, Any] | None = None) -> bool:
        if evidence_id in self._seen:
            return True
        self._seen.add(evidence_id)
        return False

    def reset(self) -> None:
        self._seen.clear()


class SimpleRateLimitChecker(RateLimitChecker):
    def __init__(self, max_per_cycle: int) -> None:
        self._max = max_per_cycle
        self._count = 0

    @property
    def max_per_cycle(self) -> int:
        return self._max

    def record(self, hypothesis_id: str) -> None:
        self._count += 1

    def exceeded(self, hypothesis_id: str) -> bool:
        return self._count >= self._max

    def reset_cycle(self) -> None:
        self._count = 0


class SimpleFreshnessChecker(FreshnessChecker):
    def __init__(self, max_age_seconds: float) -> None:
        self._max_age = max_age_seconds

    @property
    def max_age_seconds(self) -> float:
        return self._max_age

    def is_fresh(self, evidence_id: str, age_seconds: float) -> bool:
        return age_seconds <= self._max_age


# --- DedupChecker tests ---


class TestDedupChecker:
    def test_first_evidence_not_duplicate(self):
        checker = SimpleDedupChecker()
        assert checker.is_duplicate("ev-1") is False

    def test_same_evidence_is_duplicate(self):
        checker = SimpleDedupChecker()
        checker.is_duplicate("ev-1")
        assert checker.is_duplicate("ev-1") is True

    def test_different_evidence_not_duplicate(self):
        checker = SimpleDedupChecker()
        checker.is_duplicate("ev-1")
        assert checker.is_duplicate("ev-2") is False

    def test_reset_clears_state(self):
        checker = SimpleDedupChecker()
        checker.is_duplicate("ev-1")
        checker.reset()
        assert checker.is_duplicate("ev-1") is False

    def test_context_passed_to_is_duplicate(self):
        """Dedup checker can use context for context-aware dedup."""

        class ContextAwareDedup(DedupChecker):
            def __init__(self) -> None:
                self._seen: dict[str, set[str]] = {}

            def is_duplicate(
                self, evidence_id: str, context: dict[str, Any] | None = None
            ) -> bool:
                scope = (context or {}).get("scope", "default")
                seen = self._seen.setdefault(scope, set())
                if evidence_id in seen:
                    return True
                seen.add(evidence_id)
                return False

            def reset(self) -> None:
                self._seen.clear()

        checker = ContextAwareDedup()
        assert checker.is_duplicate("ev-1", {"scope": "a"}) is False
        assert checker.is_duplicate("ev-1", {"scope": "b"}) is False  # different scope
        assert checker.is_duplicate("ev-1", {"scope": "a"}) is True  # same scope

    def test_is_abstract(self):
        with pytest.raises(TypeError):
            DedupChecker()  # type: ignore[abstract]


# --- RateLimitChecker tests ---


class TestRateLimitChecker:
    def test_not_exceeded_initially(self):
        checker = SimpleRateLimitChecker(max_per_cycle=3)
        assert checker.exceeded("hyp-1") is False

    def test_exceeded_after_max(self):
        checker = SimpleRateLimitChecker(max_per_cycle=2)
        checker.record("hyp-1")
        checker.record("hyp-1")
        assert checker.exceeded("hyp-1") is True

    def test_max_per_cycle_property(self):
        checker = SimpleRateLimitChecker(max_per_cycle=5)
        assert checker.max_per_cycle == 5

    def test_reset_cycle(self):
        checker = SimpleRateLimitChecker(max_per_cycle=1)
        checker.record("hyp-1")
        assert checker.exceeded("hyp-1") is True
        checker.reset_cycle()
        assert checker.exceeded("hyp-1") is False

    def test_per_hypothesis_tracking(self):
        """Rate limiter tracks per hypothesis when implemented that way."""

        class PerHypothesisRateLimit(RateLimitChecker):
            def __init__(self, max_per_cycle: int) -> None:
                self._max = max_per_cycle
                self._counts: dict[str, int] = {}

            @property
            def max_per_cycle(self) -> int:
                return self._max

            def record(self, hypothesis_id: str) -> None:
                self._counts[hypothesis_id] = self._counts.get(hypothesis_id, 0) + 1

            def exceeded(self, hypothesis_id: str) -> bool:
                return self._counts.get(hypothesis_id, 0) >= self._max

            def reset_cycle(self) -> None:
                self._counts.clear()

        checker = PerHypothesisRateLimit(max_per_cycle=2)
        checker.record("hyp-a")
        checker.record("hyp-a")
        checker.record("hyp-b")
        assert checker.exceeded("hyp-a") is True
        assert checker.exceeded("hyp-b") is False

    def test_is_abstract(self):
        with pytest.raises(TypeError):
            RateLimitChecker()  # type: ignore[abstract]


# --- FreshnessChecker tests ---


class TestFreshnessChecker:
    def test_fresh_evidence(self):
        checker = SimpleFreshnessChecker(max_age_seconds=3600)
        assert checker.is_fresh("ev-1", age_seconds=100) is True

    def test_stale_evidence(self):
        checker = SimpleFreshnessChecker(max_age_seconds=3600)
        assert checker.is_fresh("ev-1", age_seconds=7200) is False

    def test_at_boundary(self):
        checker = SimpleFreshnessChecker(max_age_seconds=3600)
        assert checker.is_fresh("ev-1", age_seconds=3600) is True

    def test_max_age_property(self):
        checker = SimpleFreshnessChecker(max_age_seconds=1800)
        assert checker.max_age_seconds == 1800

    def test_zero_age_is_fresh(self):
        checker = SimpleFreshnessChecker(max_age_seconds=3600)
        assert checker.is_fresh("ev-1", age_seconds=0) is True

    def test_is_abstract(self):
        with pytest.raises(TypeError):
            FreshnessChecker()  # type: ignore[abstract]
