"""Tests for enforcement gate and sync pipeline contracts."""

from __future__ import annotations

from bpsai_agent_core.enforcement import (
    EnforcementResult,
    EnforcementRule,
)

from bpsai_agent_enforce.gates import (
    EnforcementGate,
    EnforcementPipeline,
    PipelineResult,
)


# --- Test helpers ---


class PassingRule(EnforcementRule):
    @property
    def name(self) -> str:
        return "pass-rule"

    def check(self, content, context=None):
        return EnforcementResult(passed=True, rule_name=self.name)


class FailingRule(EnforcementRule):
    @property
    def name(self) -> str:
        return "fail-rule"

    def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="hard fail", severity="error"
        )


class WarningRule(EnforcementRule):
    """Rule that returns severity='warning' — should be treated as advisory."""

    @property
    def name(self) -> str:
        return "warning-rule"

    def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="soft warning", severity="warning"
        )


class InfoRule(EnforcementRule):
    """Rule that returns severity='info' — should be treated as advisory."""

    @property
    def name(self) -> str:
        return "info-rule"

    def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="info note", severity="info"
        )


# --- EnforcementGate tests ---


class TestEnforcementGate:
    def test_empty_gate_passes(self):
        gate = EnforcementGate()
        assert gate.passes("anything") is True

    def test_all_passing_rules(self):
        gate = EnforcementGate(rules=[PassingRule(), PassingRule()])
        assert gate.passes("content") is True

    def test_one_failing_rule(self):
        gate = EnforcementGate(rules=[PassingRule(), FailingRule()])
        assert gate.passes("content") is False

    def test_enforce_returns_results(self):
        gate = EnforcementGate(rules=[PassingRule(), FailingRule()])
        results = gate.enforce("content")
        assert len(results) == 2
        assert results[0].passed is True
        assert results[1].passed is False

    def test_add_rule(self):
        gate = EnforcementGate()
        gate.add_rule(PassingRule())
        assert len(gate.rules) == 1

    def test_context_forwarded(self):
        class CtxRule(EnforcementRule):
            @property
            def name(self):
                return "ctx"

            def check(self, content, context=None):
                return EnforcementResult(
                    passed=context is not None and context.get("key") == "val",
                    rule_name=self.name,
                )

        gate = EnforcementGate(rules=[CtxRule()])
        assert gate.passes("x", context={"key": "val"}) is True
        assert gate.passes("x", context={"key": "wrong"}) is False

    def test_all_failing_rules(self):
        gate = EnforcementGate(rules=[FailingRule(), FailingRule()])
        assert gate.passes("content") is False
        results = gate.enforce("content")
        assert len(results) == 2
        assert all(not r.passed for r in results)

    def test_passes_with_no_context(self):
        gate = EnforcementGate(rules=[PassingRule()])
        assert gate.passes("content") is True

    def test_enforce_with_no_context(self):
        gate = EnforcementGate(rules=[PassingRule()])
        results = gate.enforce("content")
        assert len(results) == 1
        assert results[0].passed is True


# --- PipelineResult tests ---


class TestPipelineResult:
    def test_passed_pipeline(self):
        result = PipelineResult(passed=True)
        assert result.passed is True
        assert result.violations == []
        assert result.soft_warnings == []

    def test_failed_pipeline(self):
        v = EnforcementResult(passed=False, rule_name="r1")
        result = PipelineResult(passed=False, violations=[v])
        assert result.passed is False
        assert len(result.violations) == 1


# --- EnforcementPipeline tests ---


class TestEnforcementPipeline:
    def test_empty_pipeline_passes(self):
        pipe = EnforcementPipeline()
        result = pipe.run("content")
        assert result.passed is True

    def test_all_pass(self):
        pipe = EnforcementPipeline(rules=[PassingRule(), PassingRule()])
        result = pipe.run("content")
        assert result.passed is True

    def test_hard_failures_all_collected(self):
        """All hard violations collected, pipeline still marks failed."""
        pipe = EnforcementPipeline(rules=[FailingRule(), FailingRule()])
        result = pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 2

    def test_soft_warnings_collected(self):
        pipe = EnforcementPipeline(rules=[WarningRule(), WarningRule()])
        result = pipe.run("content")
        assert result.passed is True  # soft warnings don't fail
        assert len(result.soft_warnings) == 2

    def test_mixed_hard_and_soft(self):
        pipe = EnforcementPipeline(
            rules=[WarningRule(), FailingRule(), WarningRule()]
        )
        result = pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 1
        assert len(result.soft_warnings) == 2

    def test_rules_property_returns_copy(self):
        pipe = EnforcementPipeline(rules=[PassingRule()])
        rules = pipe.rules
        rules.append(FailingRule())
        assert len(pipe.rules) == 1

    def test_context_forwarded_to_rules(self):
        class CtxRule(EnforcementRule):
            @property
            def name(self):
                return "ctx-pipe"

            def check(self, content, context=None):
                passed = context is not None and context.get("env") == "prod"
                return EnforcementResult(passed=passed, rule_name=self.name)

        pipe = EnforcementPipeline(rules=[CtxRule()])
        assert pipe.run("x", context={"env": "prod"}).passed is True
        assert pipe.run("x", context={"env": "dev"}).passed is False

    def test_soft_warnings_collected_after_hard_failure(self):
        """Soft warnings after a hard failure are still collected."""
        pipe = EnforcementPipeline(
            rules=[FailingRule(), WarningRule()]
        )
        result = pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 1
        assert len(result.soft_warnings) == 1

    def test_passing_warning_rule_not_in_warnings(self):
        """Warning rules that pass are not added to soft_warnings."""

        class PassingWarningRule(EnforcementRule):
            @property
            def name(self):
                return "warning-pass"

            def check(self, content, context=None):
                return EnforcementResult(
                    passed=True, rule_name=self.name, severity="warning"
                )

        pipe = EnforcementPipeline(rules=[PassingWarningRule()])
        result = pipe.run("content")
        assert result.passed is True
        assert len(result.soft_warnings) == 0

    def test_info_severity_treated_as_advisory(self):
        """Info-severity failures go to soft_warnings, not violations."""
        pipe = EnforcementPipeline(rules=[InfoRule()])
        result = pipe.run("content")
        assert result.passed is True
        assert len(result.soft_warnings) == 1
        assert result.soft_warnings[0].severity == "info"

    def test_warning_severity_treated_as_advisory(self):
        """Warning-severity failures go to soft_warnings, not violations."""
        pipe = EnforcementPipeline(rules=[WarningRule()])
        result = pipe.run("content")
        assert result.passed is True
        assert len(result.soft_warnings) == 1
        assert result.soft_warnings[0].severity == "warning"

    def test_multiple_hard_failures_all_collected(self):
        """All hard violations are collected, not just the first one."""
        pipe = EnforcementPipeline(rules=[FailingRule(), FailingRule()])
        result = pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 2
