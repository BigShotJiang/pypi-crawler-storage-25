"""Tests for hypothesis lifecycle gate interface."""

from __future__ import annotations

from typing import Any

import pytest

from bpsai_agent_enforce.hypothesis_gate import (
    HypothesisLifecycleGate,
    TransitionResult,
)


# --- Test helpers ---


VALID_TRANSITIONS = {
    "observed": {"instrumented", "closed"},
    "instrumented": {"incubating", "closed"},
    "incubating": {"actionable", "closed"},
    "actionable": {"closed"},
    "closed": set(),
}


class SimpleLifecycleGate(HypothesisLifecycleGate):
    def check_transition(
        self,
        hypothesis_id: str,
        from_status: str,
        to_status: str,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        allowed = VALID_TRANSITIONS.get(from_status, set())
        if to_status not in allowed:
            return TransitionResult(
                allowed=False,
                reason=f"cannot transition from {from_status} to {to_status}",
            )
        return TransitionResult(allowed=True)

    @property
    def valid_transitions(self) -> dict[str, set[str]]:
        return VALID_TRANSITIONS

    def review_criteria_met(
        self,
        hypothesis_id: str,
        to_status: str,
        context: dict[str, Any] | None = None,
    ) -> bool:
        if to_status == "actionable":
            return context is not None and context.get("evidence_count", 0) >= 3
        return True


# --- Tests ---


class TestTransitionResult:
    def test_allowed(self):
        r = TransitionResult(allowed=True)
        assert r.allowed is True
        assert r.reason is None

    def test_denied_with_reason(self):
        r = TransitionResult(allowed=False, reason="not enough evidence")
        assert r.allowed is False
        assert r.reason == "not enough evidence"


class TestHypothesisLifecycleGate:
    def test_valid_forward_transition(self):
        gate = SimpleLifecycleGate()
        result = gate.check_transition("h1", "observed", "instrumented")
        assert result.allowed is True

    def test_invalid_skip_transition(self):
        gate = SimpleLifecycleGate()
        result = gate.check_transition("h1", "observed", "actionable")
        assert result.allowed is False

    def test_close_from_any_state(self):
        gate = SimpleLifecycleGate()
        for status in ["observed", "instrumented", "incubating", "actionable"]:
            result = gate.check_transition("h1", status, "closed")
            assert result.allowed is True

    def test_no_transition_from_closed(self):
        gate = SimpleLifecycleGate()
        result = gate.check_transition("h1", "closed", "observed")
        assert result.allowed is False

    def test_valid_transitions_property(self):
        gate = SimpleLifecycleGate()
        vt = gate.valid_transitions
        assert "observed" in vt
        assert "instrumented" in vt["observed"]

    def test_review_criteria_met_for_actionable(self):
        gate = SimpleLifecycleGate()
        assert gate.review_criteria_met("h1", "actionable", {"evidence_count": 5}) is True

    def test_review_criteria_not_met_for_actionable(self):
        gate = SimpleLifecycleGate()
        assert gate.review_criteria_met("h1", "actionable", {"evidence_count": 1}) is False

    def test_review_criteria_always_met_for_other(self):
        gate = SimpleLifecycleGate()
        assert gate.review_criteria_met("h1", "instrumented") is True

    def test_review_criteria_not_met_with_none_context(self):
        gate = SimpleLifecycleGate()
        assert gate.review_criteria_met("h1", "actionable") is False

    def test_check_transition_with_context(self):
        """Context is forwarded to check_transition."""

        class ContextGate(HypothesisLifecycleGate):
            def check_transition(self, hypothesis_id, from_status, to_status, context=None):
                if to_status == "actionable" and context and context.get("force"):
                    return TransitionResult(allowed=True)
                allowed = VALID_TRANSITIONS.get(from_status, set())
                if to_status not in allowed:
                    return TransitionResult(allowed=False, reason="not allowed")
                return TransitionResult(allowed=True)

            @property
            def valid_transitions(self):
                return VALID_TRANSITIONS

            def review_criteria_met(self, hypothesis_id, to_status, context=None):
                return True

        gate = ContextGate()
        # Skip transition normally not allowed
        result = gate.check_transition("h1", "observed", "actionable")
        assert result.allowed is False
        # Force via context
        result = gate.check_transition(
            "h1", "observed", "actionable", context={"force": True}
        )
        assert result.allowed is True

    def test_transition_result_reason_defaults_none(self):
        r = TransitionResult(allowed=True)
        assert r.reason is None

    def test_is_abstract(self):
        with pytest.raises(TypeError):
            HypothesisLifecycleGate()  # type: ignore[abstract]
