"""Tests for AsyncEnforcementPipeline: mixed sync+async rule execution."""

from __future__ import annotations

import pytest

from bpsai_agent_core.enforcement import (
    AsyncEnforcementRule,
    EnforcementResult,
    EnforcementRule,
)

from bpsai_agent_enforce.gates import AsyncEnforcementPipeline


# --- Test helpers ---


class PassingRule(EnforcementRule):
    @property
    def name(self) -> str:
        return "pass-rule"

    def check(self, content, context=None):
        return EnforcementResult(passed=True, rule_name=self.name)


class FailingRule(EnforcementRule):
    @property
    def name(self) -> str:
        return "fail-rule"

    def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="hard fail", severity="error"
        )


class WarningRule(EnforcementRule):
    """Rule that returns severity='warning' -- treated as advisory."""

    @property
    def name(self) -> str:
        return "warning-rule"

    def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="soft warning", severity="warning"
        )


class AsyncPassingRule(AsyncEnforcementRule):
    @property
    def name(self) -> str:
        return "async-pass"

    async def check(self, content, context=None):
        return EnforcementResult(passed=True, rule_name=self.name)


class AsyncFailingRule(AsyncEnforcementRule):
    @property
    def name(self) -> str:
        return "async-fail"

    async def check(self, content, context=None):
        return EnforcementResult(
            passed=False, rule_name=self.name, details="async hard fail"
        )


# --- AsyncEnforcementPipeline tests ---


class TestAsyncEnforcementPipeline:
    @pytest.mark.asyncio
    async def test_empty_async_pipeline_passes(self):
        pipe = AsyncEnforcementPipeline()
        result = await pipe.run("content")
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_async_rules_pass(self):
        pipe = AsyncEnforcementPipeline(rules=[AsyncPassingRule()])
        result = await pipe.run("content")
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_async_rules_fail(self):
        pipe = AsyncEnforcementPipeline(rules=[AsyncFailingRule()])
        result = await pipe.run("content")
        assert result.passed is False

    @pytest.mark.asyncio
    async def test_mixed_sync_and_async(self):
        pipe = AsyncEnforcementPipeline(rules=[PassingRule(), AsyncPassingRule()])
        result = await pipe.run("content")
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_async_soft_warnings(self):
        pipe = AsyncEnforcementPipeline(rules=[WarningRule(), AsyncPassingRule()])
        result = await pipe.run("content")
        assert result.passed is True
        assert len(result.soft_warnings) == 1

    @pytest.mark.asyncio
    async def test_async_multiple_hard_failures_all_collected(self):
        """All async hard violations are collected."""
        pipe = AsyncEnforcementPipeline(
            rules=[AsyncFailingRule(), AsyncFailingRule()]
        )
        result = await pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 2

    @pytest.mark.asyncio
    async def test_async_rules_property_returns_copy(self):
        pipe = AsyncEnforcementPipeline(rules=[AsyncPassingRule()])
        rules = pipe.rules
        rules.append(AsyncFailingRule())
        assert len(pipe.rules) == 1

    @pytest.mark.asyncio
    async def test_async_context_forwarded(self):
        class AsyncCtxRule(AsyncEnforcementRule):
            @property
            def name(self):
                return "async-ctx"

            async def check(self, content, context=None):
                passed = context is not None and context.get("mode") == "strict"
                return EnforcementResult(passed=passed, rule_name=self.name)

        pipe = AsyncEnforcementPipeline(rules=[AsyncCtxRule()])
        result = await pipe.run("x", context={"mode": "strict"})
        assert result.passed is True
        result = await pipe.run("x", context={"mode": "lax"})
        assert result.passed is False

    @pytest.mark.asyncio
    async def test_mixed_sync_fail_with_async(self):
        """Sync hard failure short-circuits before async rules run."""
        pipe = AsyncEnforcementPipeline(
            rules=[FailingRule(), AsyncPassingRule()]
        )
        result = await pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 1

    @pytest.mark.asyncio
    async def test_async_soft_warnings_collected_after_hard(self):
        """Async soft warnings still collected after hard failure."""

        class AsyncSoftWarning(AsyncEnforcementRule):
            @property
            def name(self):
                return "async-soft"

            async def check(self, content, context=None):
                return EnforcementResult(
                    passed=False, rule_name=self.name, severity="warning"
                )

        pipe = AsyncEnforcementPipeline(
            rules=[AsyncFailingRule(), AsyncSoftWarning()]
        )
        result = await pipe.run("content")
        assert result.passed is False
        assert len(result.violations) == 1
        assert len(result.soft_warnings) == 1
