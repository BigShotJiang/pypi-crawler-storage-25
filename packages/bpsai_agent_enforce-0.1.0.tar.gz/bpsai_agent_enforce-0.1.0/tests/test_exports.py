"""Tests for package-level exports and agent-core re-exports."""

from __future__ import annotations


class TestPackageExports:
    """AC: bpsai_agent_enforce exports gate/pipeline types."""

    def test_enforcement_gate_exported(self):
        from bpsai_agent_enforce import EnforcementGate

        assert EnforcementGate is not None

    def test_pipeline_result_exported(self):
        from bpsai_agent_enforce import PipelineResult

        assert PipelineResult is not None

    def test_enforcement_pipeline_exported(self):
        from bpsai_agent_enforce import EnforcementPipeline

        assert EnforcementPipeline is not None

    def test_async_enforcement_pipeline_exported(self):
        from bpsai_agent_enforce import AsyncEnforcementPipeline

        assert AsyncEnforcementPipeline is not None


class TestAgentCoreReExports:
    """AC: All existing agent-core enforcement ABCs re-exported."""

    def test_enforcement_result_reexported(self):
        from bpsai_agent_enforce import EnforcementResult

        from bpsai_agent_core.enforcement import (
            EnforcementResult as CoreResult,
        )

        assert EnforcementResult is CoreResult

    def test_enforcement_rule_reexported(self):
        from bpsai_agent_enforce import EnforcementRule

        from bpsai_agent_core.enforcement import (
            EnforcementRule as CoreRule,
        )

        assert EnforcementRule is CoreRule

    def test_async_enforcement_rule_reexported(self):
        from bpsai_agent_enforce import AsyncEnforcementRule

        from bpsai_agent_core.enforcement import (
            AsyncEnforcementRule as CoreRule,
        )

        assert AsyncEnforcementRule is CoreRule


class TestContractExports:
    """AC: Contract ABCs are accessible from package."""

    def test_signal_validator_exported(self):
        from bpsai_agent_enforce import SignalValidator, ValidationResult

        assert SignalValidator is not None
        assert ValidationResult is not None

    def test_evidence_contracts_exported(self):
        from bpsai_agent_enforce import (
            DedupChecker,
            FreshnessChecker,
            RateLimitChecker,
        )

        assert DedupChecker is not None
        assert RateLimitChecker is not None
        assert FreshnessChecker is not None

    def test_hypothesis_gate_exported(self):
        from bpsai_agent_enforce import (
            HypothesisLifecycleGate,
            TransitionResult,
        )

        assert HypothesisLifecycleGate is not None
        assert TransitionResult is not None


class TestAllExportedSymbolsCovered:
    """AC: 100% of exported symbols have test coverage."""

    def test_all_symbols_in_all_are_importable(self):
        import bpsai_agent_enforce

        for name in bpsai_agent_enforce.__all__:
            obj = getattr(bpsai_agent_enforce, name, None)
            assert obj is not None, f"{name} in __all__ but not importable"

    def test_all_public_symbols_in_all(self):
        """Every public attr that isn't dunder should be in __all__."""
        import bpsai_agent_enforce

        public_attrs = {
            k
            for k in dir(bpsai_agent_enforce)
            if not k.startswith("_") and k != "annotations"
        }
        all_set = set(bpsai_agent_enforce.__all__)
        missing = public_attrs - all_set
        # Filter out modules (only check classes/types)
        import types

        missing = {
            m
            for m in missing
            if not isinstance(getattr(bpsai_agent_enforce, m), types.ModuleType)
        }
        assert missing == set(), f"Public symbols not in __all__: {missing}"


class TestNoDependencyOnFramework:
    """AC: Package imports only bpsai-agent-core -- no framework dependency."""

    def test_no_framework_import(self):
        import bpsai_agent_enforce

        # Check that the module source doesn't import from framework
        import inspect

        source_file = inspect.getfile(bpsai_agent_enforce)
        # Read all module files in the package
        import pathlib

        pkg_dir = pathlib.Path(source_file).parent
        for py_file in pkg_dir.glob("*.py"):
            content = py_file.read_text()
            assert "bpsai_framework" not in content, (
                f"{py_file.name} imports from bpsai_framework"
            )
