"""Tests for signal validation contract ABC."""

from __future__ import annotations

from typing import Any

import pytest

from bpsai_agent_enforce.signal_validation import SignalValidator, ValidationResult


# --- Test helpers ---


class StrictValidator(SignalValidator):
    """Requires 'type' and 'payload' fields."""

    def validate(self, signal: dict[str, Any]) -> ValidationResult:
        errors: list[str] = []
        if "type" not in signal:
            errors.append("missing required field: type")
        if "payload" not in signal:
            errors.append("missing required field: payload")
        return ValidationResult(valid=len(errors) == 0, errors=errors)

    @property
    def required_fields(self) -> list[str]:
        return ["type", "payload"]


class AlwaysValidValidator(SignalValidator):
    def validate(self, signal: dict[str, Any]) -> ValidationResult:
        return ValidationResult(valid=True, errors=[])

    @property
    def required_fields(self) -> list[str]:
        return []


# --- Tests ---


class TestValidationResult:
    def test_valid_result(self):
        r = ValidationResult(valid=True, errors=[])
        assert r.valid is True
        assert r.errors == []

    def test_invalid_result(self):
        r = ValidationResult(valid=False, errors=["missing field: x"])
        assert r.valid is False
        assert len(r.errors) == 1


class TestSignalValidator:
    def test_valid_signal(self):
        v = StrictValidator()
        result = v.validate({"type": "observation", "payload": {"k": "v"}})
        assert result.valid is True

    def test_missing_required_field(self):
        v = StrictValidator()
        result = v.validate({"type": "observation"})
        assert result.valid is False
        assert "missing required field: payload" in result.errors

    def test_empty_signal(self):
        v = StrictValidator()
        result = v.validate({})
        assert result.valid is False
        assert len(result.errors) == 2

    def test_required_fields_property(self):
        v = StrictValidator()
        assert v.required_fields == ["type", "payload"]

    def test_always_valid(self):
        v = AlwaysValidValidator()
        result = v.validate({})
        assert result.valid is True

    def test_is_abstract(self):
        with pytest.raises(TypeError):
            SignalValidator()  # type: ignore[abstract]
