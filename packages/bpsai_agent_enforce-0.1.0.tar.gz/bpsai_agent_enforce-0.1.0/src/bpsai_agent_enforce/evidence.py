"""Evidence mechanics contracts: interfaces for dedup, rate limits, freshness.

These contracts govern how evidence accumulates against hypotheses.
Each agent (e.g. Metis) implements these for its domain.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class DedupChecker(ABC):
    """Contract: same finding cannot accumulate across cycles."""

    @abstractmethod
    def is_duplicate(
        self, evidence_id: str, context: dict[str, Any] | None = None
    ) -> bool:
        """Return True if this evidence has already been recorded."""

    @abstractmethod
    def reset(self) -> None:
        """Clear dedup state (e.g. between cycles)."""


class RateLimitChecker(ABC):
    """Contract: max N new evidence items per cycle per hypothesis."""

    @property
    @abstractmethod
    def max_per_cycle(self) -> int:
        """Maximum evidence items allowed per cycle."""

    @abstractmethod
    def record(self, hypothesis_id: str) -> None:
        """Record an evidence item against a hypothesis."""

    @abstractmethod
    def exceeded(self, hypothesis_id: str) -> bool:
        """Return True if the rate limit has been exceeded."""

    @abstractmethod
    def reset_cycle(self) -> None:
        """Reset counters for a new cycle."""


class FreshnessChecker(ABC):
    """Contract: evidence must be within a freshness window."""

    @property
    @abstractmethod
    def max_age_seconds(self) -> float:
        """Maximum age of evidence in seconds."""

    @abstractmethod
    def is_fresh(self, evidence_id: str, age_seconds: float) -> bool:
        """Return True if evidence is within the freshness window."""
