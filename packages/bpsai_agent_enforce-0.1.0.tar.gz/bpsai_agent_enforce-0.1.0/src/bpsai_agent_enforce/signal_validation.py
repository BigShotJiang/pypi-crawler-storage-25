"""Signal validation contract: ABC for validating agent output schemas.

Agents implement this to enforce that their signals are well-formed
and contain required fields before they enter the signal store.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ValidationResult:
    """Result of signal validation."""

    valid: bool
    errors: list[str] = field(default_factory=list)


class SignalValidator(ABC):
    """Abstract contract for signal schema validation.

    Each agent implements this to validate its output signals
    (well-formed, required fields present).
    """

    @abstractmethod
    def validate(self, signal: dict[str, Any]) -> ValidationResult:
        """Validate a signal dict. Returns result with errors if invalid."""

    @property
    @abstractmethod
    def required_fields(self) -> list[str]:
        """Fields that must be present in every signal."""
