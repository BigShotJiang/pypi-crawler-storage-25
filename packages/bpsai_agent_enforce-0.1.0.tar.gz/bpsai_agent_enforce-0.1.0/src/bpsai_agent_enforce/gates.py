"""Enforcement gate and pipeline abstractions.

Compose rules into gates (all-must-pass) and pipelines (short-circuit on
hard failure, collect soft warnings). Extracted from bpsai-framework
engine.enforcement — these sit above the basic ABCs in agent-core.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bpsai_agent_core.enforcement import (
    AsyncEnforcementRule,
    EnforcementResult,
    EnforcementRule,
)


class EnforcementGate:
    """Runs content through a set of enforcement rules.

    All rules must pass for content to proceed. This gate is intentionally
    all-or-nothing: it does not distinguish between severity levels. Any
    failing rule causes ``passes()`` to return False. Use
    ``EnforcementPipeline`` for severity-aware routing where only
    ``severity='error'`` results are hard blockers.
    """

    def __init__(self, rules: list[EnforcementRule] | None = None):
        self.rules = rules or []

    def add_rule(self, rule: EnforcementRule) -> None:
        self.rules.append(rule)

    def enforce(
        self, content: str, context: dict[str, Any] | None = None
    ) -> list[EnforcementResult]:
        return [rule.check(content, context) for rule in self.rules]

    def passes(
        self, content: str, context: dict[str, Any] | None = None
    ) -> bool:
        results = self.enforce(content, context)
        return all(r.passed for r in results)


@dataclass
class PipelineResult:
    """Result of running content through an enforcement pipeline."""

    passed: bool
    violations: list[EnforcementResult] = field(default_factory=list)
    soft_warnings: list[EnforcementResult] = field(default_factory=list)


class EnforcementPipeline:
    """Short-circuiting enforcement pipeline.

    Separates hard violations (blocking) from soft warnings (advisory).
    Stops on first hard failure but always collects all soft warnings.
    """

    def __init__(self, rules: list[EnforcementRule] | None = None) -> None:
        self._rules = rules or []

    @property
    def rules(self) -> list[EnforcementRule]:
        return list(self._rules)

    def run(
        self, content: str, context: dict[str, Any] | None = None
    ) -> PipelineResult:
        violations: list[EnforcementResult] = []
        soft_warnings: list[EnforcementResult] = []
        hard_failed = False

        for rule in self._rules:
            result = rule.check(content, context)
            if result.severity != "error":
                if not result.passed:
                    soft_warnings.append(result)
            elif not result.passed:
                violations.append(result)
                hard_failed = True

        return PipelineResult(
            passed=len(violations) == 0,
            violations=violations,
            soft_warnings=soft_warnings,
        )


class AsyncEnforcementPipeline:
    """Short-circuiting pipeline for mixed sync/async rules."""

    def __init__(
        self,
        rules: list[EnforcementRule | AsyncEnforcementRule] | None = None,
    ) -> None:
        self._rules = rules or []

    @property
    def rules(self) -> list[EnforcementRule | AsyncEnforcementRule]:
        return list(self._rules)

    async def run(
        self, content: str, context: dict[str, Any] | None = None
    ) -> PipelineResult:
        violations: list[EnforcementResult] = []
        soft_warnings: list[EnforcementResult] = []
        hard_failed = False

        for rule in self._rules:
            result = await self._check_rule(rule, content, context)
            if result.severity != "error":
                if not result.passed:
                    soft_warnings.append(result)
            elif not result.passed:
                violations.append(result)
                hard_failed = True

        return PipelineResult(
            passed=len(violations) == 0,
            violations=violations,
            soft_warnings=soft_warnings,
        )

    async def _check_rule(
        self,
        rule: EnforcementRule | AsyncEnforcementRule,
        content: str,
        context: dict[str, Any] | None,
    ) -> EnforcementResult:
        if isinstance(rule, AsyncEnforcementRule):
            return await rule.check(content, context)
        return rule.check(content, context)
