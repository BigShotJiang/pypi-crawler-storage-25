"""BPS AI Agent Enforce — enforcement contracts and governance interfaces."""

__version__ = "0.1.0"

# Re-export agent-core enforcement ABCs for convenience
from bpsai_agent_core.enforcement import (
    AsyncEnforcementRule,
    EnforcementResult,
    EnforcementRule,
)

# Gate and pipeline abstractions
from bpsai_agent_enforce.gates import (
    AsyncEnforcementPipeline,
    EnforcementGate,
    EnforcementPipeline,
    PipelineResult,
)

# Signal validation contract
from bpsai_agent_enforce.signal_validation import SignalValidator, ValidationResult

# Evidence mechanics contracts
from bpsai_agent_enforce.evidence import (
    DedupChecker,
    FreshnessChecker,
    RateLimitChecker,
)

# Hypothesis lifecycle gate
from bpsai_agent_enforce.hypothesis_gate import (
    HypothesisLifecycleGate,
    TransitionResult,
)

__all__ = [
    # agent-core re-exports
    "AsyncEnforcementRule",
    "EnforcementResult",
    "EnforcementRule",
    # gates and pipelines
    "AsyncEnforcementPipeline",
    "EnforcementGate",
    "EnforcementPipeline",
    "PipelineResult",
    # signal validation
    "SignalValidator",
    "ValidationResult",
    # evidence mechanics
    "DedupChecker",
    "FreshnessChecker",
    "RateLimitChecker",
    # hypothesis lifecycle
    "HypothesisLifecycleGate",
    "TransitionResult",
]
