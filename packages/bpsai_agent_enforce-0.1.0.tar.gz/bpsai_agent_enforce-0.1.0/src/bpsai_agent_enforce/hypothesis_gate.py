"""Hypothesis lifecycle gate interface.

Status transitions require review criteria met. Agents implement this
to enforce their hypothesis lifecycle rules (e.g. Metis requires
minimum evidence count before promoting to actionable).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class TransitionResult:
    """Result of a lifecycle transition check."""

    allowed: bool
    reason: str | None = None


class HypothesisLifecycleGate(ABC):
    """Abstract gate for hypothesis status transitions.

    Lifecycle: observed -> instrumented -> incubating -> actionable (or closed).
    Each transition can be gated on review criteria.
    """

    @abstractmethod
    def check_transition(
        self,
        hypothesis_id: str,
        from_status: str,
        to_status: str,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Check if a status transition is allowed."""

    @property
    @abstractmethod
    def valid_transitions(self) -> dict[str, set[str]]:
        """Map of status -> set of allowed target statuses."""

    @abstractmethod
    def review_criteria_met(
        self,
        hypothesis_id: str,
        to_status: str,
        context: dict[str, Any] | None = None,
    ) -> bool:
        """Return True if review criteria are met for the target status."""
