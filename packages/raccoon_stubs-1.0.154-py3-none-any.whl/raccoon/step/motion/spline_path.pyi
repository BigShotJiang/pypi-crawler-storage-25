"""
Spline path motion step — smooth curved path through waypoints.
"""
from __future__ import annotations
import math as math
from raccoon.motion import SplineMotion
from raccoon.motion import SplineMotionConfig
import raccoon.step.annotation
from raccoon.step.annotation import dsl
from raccoon.step.base import Step
import raccoon.step.motion.motion_step
from raccoon.step.motion.motion_step import MotionStep
import typing
__all__: list[str] = ['MotionStep', 'SplineMotion', 'SplineMotionConfig', 'SplinePath', 'Step', 'dsl', 'math', 'spline']
class SplinePath(raccoon.step.motion.motion_step.MotionStep):
    """
    Drive along a centripetal Catmull-Rom spline through waypoints.
    
    Supports two waypoint formats:
    - 2-tuples (forward_cm, left_cm): heading follows spline tangent.
    - 3-tuples (forward_cm, left_cm, heading_deg): explicit heading at each
      waypoint, linearly interpolated vs arc-length. Omni drivetrains only.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'SplinePath'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, waypoints: list[tuple[float, ...]], speed: float) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
def spline(*waypoints: tuple[float, ...], speed: float = 1.0) -> SplinePath:
    """
    Drive along a smooth curved path through a series of waypoints.
    
    The robot follows a centripetal Catmull-Rom spline that passes through
    every waypoint with continuous velocity. A trapezoidal velocity profile
    on arc-length provides smooth acceleration and deceleration along the
    path, while a heading PID keeps the robot oriented along the curve.
    
    Waypoints are specified relative to the robot's pose when the step
    starts. Two formats are supported:
    
    - **2-tuples** ``(forward_cm, left_cm)``: heading automatically follows
      the spline tangent. Works on both differential and omni drivetrains.
    - **3-tuples** ``(forward_cm, left_cm, heading_deg)``: explicit heading
      at each waypoint, linearly interpolated along the path. Omni
      drivetrains only — raises ``ValueError`` on differential bots.
    
    Prerequisites:
        Drive characterization (``auto_tune`` or ``characterize_drive``)
        must have been run so that axis constraints are populated.
    
    Args:
        *waypoints: Two or more waypoints as tuples. ``forward_cm`` is
            centimeters ahead of the start position (positive = forward).
            ``left_cm`` is centimeters to the left (positive = left).
            Optional ``heading_deg`` is the desired heading in degrees
            (0 = initial heading, positive = CCW).
        speed: Fraction of maximum speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A SplinePath step configured for the described curved path.
    
    Raises:
        ValueError: If fewer than 2 waypoints, inconsistent tuple sizes,
            or explicit headings on a non-omni drivetrain.
    
    Example::
    
        from raccoon.step.motion import spline
    
        # S-curve around an obstacle (heading follows tangent)
        spline((30, 0), (50, 15), (50, 30), (30, 30))
    
        # Gentle curve at half speed
        spline((40, 0), (60, 20), speed=0.5)
    
        # Omni: curve while rotating to face 90° left at the end
        spline((30, 0, 0), (50, 15, 45), (50, 30, 90))
    """
