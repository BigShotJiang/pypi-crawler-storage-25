from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeGuard, overload

from schemathesis.core.jsonschema.bundler import BUNDLE_STORAGE_KEY, REFERENCE_TO_BUNDLE_PREFIX
from schemathesis.core.jsonschema.types import JsonSchema
from schemathesis.core.transforms import deepclone
from schemathesis.specs.openapi.patterns import (
    is_valid_python_regex,
    normalize_regex,
    pattern_length_bounds,
    update_quantifier,
)


@overload
def to_json_schema(
    schema: dict[str, Any],
    nullable_keyword: str,
    is_response_schema: bool = False,
    update_quantifiers: bool = True,
    clone: bool = True,
    upgrade_legacy_exclusive_bounds: bool = False,
    convert_prefix_items: bool = True,
    name_to_uri: dict[str, str] | None = None,
) -> dict[str, Any]: ...  # pragma: no cover


@overload
def to_json_schema(
    schema: bool,
    nullable_keyword: str,
    is_response_schema: bool = False,
    update_quantifiers: bool = True,
    clone: bool = True,
    upgrade_legacy_exclusive_bounds: bool = False,
    convert_prefix_items: bool = True,
    name_to_uri: dict[str, str] | None = None,
) -> bool: ...  # pragma: no cover


def to_json_schema(
    schema: dict[str, Any] | bool,
    nullable_keyword: str,
    is_response_schema: bool = False,
    update_quantifiers: bool = True,
    clone: bool = True,
    upgrade_legacy_exclusive_bounds: bool = False,
    convert_prefix_items: bool = True,
    name_to_uri: dict[str, str] | None = None,
) -> dict[str, Any] | bool:
    if isinstance(schema, bool):
        return schema
    if clone:
        schema = deepclone(schema)
    return _to_json_schema(
        schema,
        nullable_keyword=nullable_keyword,
        is_response_schema=is_response_schema,
        update_quantifiers=update_quantifiers,
        upgrade_legacy_exclusive_bounds=upgrade_legacy_exclusive_bounds,
        convert_prefix_items=convert_prefix_items,
        name_to_uri=name_to_uri,
    )


def _to_json_schema(
    schema: JsonSchema,
    *,
    nullable_keyword: str,
    is_response_schema: bool = False,
    update_quantifiers: bool = True,
    upgrade_legacy_exclusive_bounds: bool = False,
    convert_prefix_items: bool = True,
    name_to_uri: dict[str, str] | None = None,
) -> JsonSchema:
    if not isinstance(schema, dict):
        return schema if isinstance(schema, bool) else {}

    if upgrade_legacy_exclusive_bounds:
        _upgrade_legacy_exclusive_bounds(schema)

    if schema.get(nullable_keyword):
        del schema[nullable_keyword]
        bundled = schema.pop(BUNDLE_STORAGE_KEY, None)
        schema = {"anyOf": [schema, {"type": "null"}]}
        if bundled:
            schema[BUNDLE_STORAGE_KEY] = bundled
    schema_type = schema.get("type")
    if schema_type == "file":
        schema["type"] = "string"
        schema["format"] = "binary"

    # Handle unsupported regex patterns - try translation first, remove if that fails
    pattern = schema.get("pattern")
    if pattern is not None:
        if not is_valid_python_regex(pattern):
            # Pattern is invalid Python regex - try to translate PCRE constructs
            translated = normalize_regex(pattern)
            if translated is not None:
                schema["pattern"] = translated
            else:
                del schema["pattern"]
        elif pattern.startswith(r"\A") or pattern.endswith(r"\Z"):
            # Pattern uses Python-specific anchors that need Rust translation for jsonschema-rs
            translated = normalize_regex(pattern)
            if translated is not None:
                schema["pattern"] = translated
    if update_quantifiers:
        update_pattern_in_schema(schema)
    # Sometimes `required` is incorrectly has a boolean value
    properties = schema.get("properties")
    if isinstance(properties, dict):
        for name, subschema in properties.items():
            if not isinstance(subschema, dict):
                continue
            is_required = subschema.get("required")
            if is_required is True:
                required = schema.setdefault("required", [])
                if name not in required:
                    required.append(name)
                del subschema["required"]
            elif is_required is False:
                if "required" in schema and name in schema["required"]:
                    schema["required"].remove(name)
                del subschema["required"]

    if schema_type == "object":
        if is_response_schema:
            # Write-only properties should not occur in responses
            rewrite_properties(schema, is_write_only)
        else:
            # Read-only properties should not occur in requests
            rewrite_properties(schema, is_read_only)

    ensure_required_properties(schema)

    # Convert prefixItems -> items[array] for hypothesis-jsonschema (Draft 4/7-only).
    # Skipped when the consumer needs `prefixItems` to stay intact (e.g. for Draft 2020-12 validators).
    if convert_prefix_items and "prefixItems" in schema:
        prefix_items = schema.pop("prefixItems")
        if "items" in schema:
            # When both prefixItems and items exist, items becomes additionalItems
            schema["additionalItems"] = schema.pop("items")
        schema["items"] = prefix_items

    if schema_type == "array":
        _rewrite_allof_of_contains_consts(schema)

    if not is_response_schema:
        _pin_discriminator_property(schema, name_to_uri)

    for keyword, value in schema.items():
        if keyword in IN_VALUE and isinstance(value, dict):
            schema[keyword] = _to_json_schema(
                value,
                nullable_keyword=nullable_keyword,
                is_response_schema=is_response_schema,
                update_quantifiers=update_quantifiers,
                upgrade_legacy_exclusive_bounds=upgrade_legacy_exclusive_bounds,
                convert_prefix_items=convert_prefix_items,
                name_to_uri=name_to_uri,
            )
        elif keyword in IN_ITEM and isinstance(value, list):
            for idx, subschema in enumerate(value):
                value[idx] = _to_json_schema(
                    subschema,
                    nullable_keyword=nullable_keyword,
                    is_response_schema=is_response_schema,
                    update_quantifiers=update_quantifiers,
                    upgrade_legacy_exclusive_bounds=upgrade_legacy_exclusive_bounds,
                    convert_prefix_items=convert_prefix_items,
                    name_to_uri=name_to_uri,
                )
        elif keyword in IN_CHILD and isinstance(value, dict):
            for name, subschema in value.items():
                value[name] = _to_json_schema(
                    subschema,
                    nullable_keyword=nullable_keyword,
                    is_response_schema=is_response_schema,
                    update_quantifiers=update_quantifiers,
                    upgrade_legacy_exclusive_bounds=upgrade_legacy_exclusive_bounds,
                    convert_prefix_items=convert_prefix_items,
                    name_to_uri=name_to_uri,
                )

    # A property forbidden inside an `allOf` branch (read/write-only rewrite produces `{"not": {}}`)
    # must also be removed from the parent's `required`, otherwise the schema is unsatisfiable.
    required = schema.get("required")
    if isinstance(required, list) and required:
        forbidden = _forbidden_in_allof_branches(schema)
        if forbidden:
            new_required = [name for name in required if name not in forbidden]
            if new_required:
                schema["required"] = new_required
            else:
                schema.pop("required", None)

    return schema


def _forbidden_in_allof_branches(schema: dict[str, Any]) -> set[str]:
    forbidden: set[str] = set()
    for branch in schema.get("allOf") or []:
        if not isinstance(branch, dict):
            continue
        for name, subschema in (branch.get("properties") or {}).items():
            if subschema == {"not": {}}:
                forbidden.add(name)
        forbidden.update(_forbidden_in_allof_branches(branch))
    return forbidden


def _pin_discriminator_property(schema: dict[str, Any], name_to_uri: dict[str, str] | None) -> None:
    """Pin the discriminator property to its expected value in each oneOf/anyOf branch.

    When a schema has a `discriminator`, each branch in oneOf/anyOf is wrapped in
    `allOf` with an `enum` constraint on the discriminator property. This ensures
    hypothesis-jsonschema generates the correct discriminator value for each branch.
    """
    discriminator = schema.get("discriminator")
    if not isinstance(discriminator, dict):
        return
    property_name = discriminator.get("propertyName")
    if not property_name:
        return
    explicit_mapping: dict[str, str] = discriminator.get("mapping") or {}
    ref_to_value = {ref: value for value, ref in explicit_mapping.items()}

    for keyword in ("anyOf", "oneOf"):
        items = schema.get(keyword)
        if not isinstance(items, list):
            continue
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            ref = item.get("$ref")
            if not isinstance(ref, str):
                continue
            # Resolve bundled ref (e.g. "#/x-bundled/schema1") back to original URI for schema name extraction
            resolved_ref = ref
            if name_to_uri and ref.startswith(f"{REFERENCE_TO_BUNDLE_PREFIX}/"):
                bundled_name = ref[len(REFERENCE_TO_BUNDLE_PREFIX) + 1 :]
                original_uri = name_to_uri.get(bundled_name, "")
                if "#" in original_uri:
                    resolved_ref = "#" + original_uri.split("#", 1)[1]
            # Look up explicit mapping first, then fall back to schema name from ref path
            disc_value = ref_to_value.get(resolved_ref) or resolved_ref.rstrip("/").rsplit("/", 1)[-1]
            if not disc_value:
                continue
            # `enum` is used instead of `const` so the pin is recognized under Draft 4
            # (used by OpenAPI 2.0 / 3.0); Draft 4 silently ignores `const`.
            items[idx] = {"allOf": [item, {"properties": {property_name: {"enum": [disc_value]}}}]}


def _rewrite_allof_of_contains_consts(schema: dict[str, Any]) -> None:
    # `allOf: [{contains: {const: A}}, {contains: {const: B}}, ...]` can't be merged by
    # hypothesis-jsonschema, so it falls back to filtering and exhausts. Rewriting the
    # required consts as a positional `items` prefix forces them into the array up front.
    all_of = schema.get("allOf")
    if not isinstance(all_of, list) or len(all_of) < 2:
        return
    if isinstance(schema.get("items"), list):
        return
    consts = []
    keep = []
    for entry in all_of:
        if (
            isinstance(entry, dict)
            and len(entry) == 1
            and isinstance(entry.get("contains"), dict)
            and entry["contains"].keys() == {"const"}
        ):
            consts.append({"const": entry["contains"]["const"]})
        else:
            keep.append(entry)
    if len(consts) < 2:
        return
    original_items = schema.get("items")
    if isinstance(original_items, dict):
        schema["additionalItems"] = original_items
    schema["items"] = consts
    if keep:
        schema["allOf"] = keep
    else:
        schema.pop("allOf", None)
    min_items = schema.get("minItems")
    if not isinstance(min_items, int) or min_items < len(consts):
        schema["minItems"] = len(consts)


def _upgrade_legacy_exclusive_bounds(schema: dict[str, Any]) -> None:
    for exclusive_key, bound_key in (("exclusiveMinimum", "minimum"), ("exclusiveMaximum", "maximum")):
        exclusive = schema.get(exclusive_key)
        if not isinstance(exclusive, bool):
            continue
        if not exclusive:
            schema.pop(exclusive_key, None)
            continue

        bound = schema.get(bound_key)
        if isinstance(bound, bool) or not isinstance(bound, int | float):
            # `exclusive* = true` without a numeric bound can't be represented in modern drafts.
            schema.pop(exclusive_key, None)
            continue
        schema[exclusive_key] = bound
        schema.pop(bound_key, None)


def ensure_required_properties(schema: dict[str, Any]) -> None:
    if schema.get("additionalProperties") is not False:
        return

    required = schema.get("required")
    if not required or not isinstance(required, list):
        return

    properties = schema.setdefault("properties", {})

    # Add missing required properties as empty schemas
    for name in required:
        if name not in properties:
            properties[name] = {}


IN_VALUE = frozenset(
    (
        "additionalProperties",
        "contains",
        "contentSchema",
        "else",
        "if",
        "items",
        "not",
        "propertyNames",
        "then",
        "unevaluatedItems",
        "unevaluatedProperties",
    )
)
IN_ITEM = frozenset(
    (
        "allOf",
        "anyOf",
        "oneOf",
        "prefixItems",
    )
)
IN_CHILD = frozenset(
    (
        "$defs",
        "definitions",
        "dependentSchemas",
        "patternProperties",
        "properties",
        BUNDLE_STORAGE_KEY,
    )
)


def update_pattern_in_schema(schema: dict[str, Any]) -> None:
    pattern = schema.get("pattern")
    min_length = schema.get("minLength")
    max_length = schema.get("maxLength")
    if pattern and (min_length or max_length):
        new_pattern = update_quantifier(pattern, min_length, max_length)
        if new_pattern != pattern:
            # Pop a bound only if the rewrite encodes it; rewrites with unbounded slots can't absorb `maxLength`.
            new_min, new_max = pattern_length_bounds(new_pattern)
            schema["pattern"] = new_pattern
            if min_length is not None and new_min >= min_length:
                schema.pop("minLength", None)
            if max_length is not None and new_max is not None and new_max <= max_length:
                schema.pop("maxLength", None)


def rewrite_properties(schema: dict[str, Any], predicate: Callable[[dict[str, Any]], bool]) -> None:
    required = schema.get("required", [])
    for name, subschema in list(schema.get("properties", {}).items()):
        if predicate(subschema):
            if name in required:
                required.remove(name)
            schema["properties"][name] = {"not": {}}
    if not schema.get("required"):
        schema.pop("required", None)
    if not schema.get("properties"):
        schema.pop("properties", None)


def is_write_only(schema: Any) -> TypeGuard[dict[str, Any]]:
    if not isinstance(schema, dict):
        return False
    return schema.get("writeOnly", False) or schema.get("x-writeOnly", False)


def is_read_only(schema: Any) -> TypeGuard[dict[str, Any]]:
    if not isinstance(schema, dict):
        return False
    return schema.get("readOnly", False)
