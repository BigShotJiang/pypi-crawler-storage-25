Simple cli tool for tracking the position of the ISS in real time!

commands include:
    help  - Lists all commands.
    track {parameter}
        {-t}  - Returns position data for the ISS until interupted.
        {[num]}  - Returns position data for the ISS [num] times.
    people  - Returns the number of people that are currently in space.

Hope you like it! :)


(this project uses open notify API)