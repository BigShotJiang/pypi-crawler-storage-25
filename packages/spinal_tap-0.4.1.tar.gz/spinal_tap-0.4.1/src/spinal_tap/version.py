"""Module which stores the current software version."""

__version__ = "0.4.1"
