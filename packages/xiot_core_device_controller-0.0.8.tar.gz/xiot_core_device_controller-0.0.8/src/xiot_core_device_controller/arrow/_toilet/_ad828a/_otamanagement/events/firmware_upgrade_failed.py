from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.code import Code
from ..properties.did import Did

# 固件升级失败
class FirmwareUpgradeFailed(EventController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:event:firmware-upgrade-failed:00000a2a:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "firmware-upgrade-failed"
        self.description["zh-CN"] = "固件升级失败"

        self._observer: Callable[[int, str], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            code = self.__code(o)
            did = self.__did(o)
            self._observer(code, did)

    def observer(self, observer: Callable[[int, str], None]) -> None:
        self._observer = observer

    @staticmethod
    def __code(o: EventOperation) -> int :
        argument: ArgumentOperation = o.arguments[Code.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(Code.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(Code.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(Code.IID))

        value: object = objects[0]
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __did(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[Did.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(Did.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(Did.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(Did.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

