from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.ip import Ip
from .properties.ipv4_subnet_mask import Ipv4SubnetMask
from .properties.mac_address import MacAddress
from .properties.rssi import Rssi

# 无线网络连接
class WifiConnectivity(ServiceController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:service:wifi-connectivity:00000002:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Wi-Fi Connectivity"
        self.description["zh-CN"] = "无线网络连接"

        self.properties[Ip.IID] = Ip()
        self.properties[Ipv4SubnetMask.IID] = Ipv4SubnetMask()
        self.properties[MacAddress.IID] = MacAddress()
        self.properties[Rssi.IID] = Rssi()



    # IPv4地址
    def ip_(self) -> Ip:
        return self.properties[Ip.IID] # type: ignore[no-any-return]

    # IPv4子网掩码
    def ipv4_subnet_mask_(self) -> Ipv4SubnetMask:
        return self.properties[Ipv4SubnetMask.IID] # type: ignore[no-any-return]

    # Mac地址
    def mac_address_(self) -> MacAddress:
        return self.properties[MacAddress.IID] # type: ignore[no-any-return]

    # 信号强度
    def rssi_(self) -> Rssi:
        return self.properties[Rssi.IID] # type: ignore[no-any-return]



