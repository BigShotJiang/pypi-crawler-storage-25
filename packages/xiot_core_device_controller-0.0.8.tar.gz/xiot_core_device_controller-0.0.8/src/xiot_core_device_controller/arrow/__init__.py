"""Device class."""
