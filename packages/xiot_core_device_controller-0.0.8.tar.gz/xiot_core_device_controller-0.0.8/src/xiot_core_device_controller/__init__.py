"""JD xIoT 设备类注册模块.

用于统一注册各类京东智能设备类到 device_mapping 中
"""

# 注册设备类到device_mapping中
from .jd._light._jdznsd04sy.jdznsd04sy import Jdznsd04sy
from .jd._light._jdznxtd02sy.jdznxtd02sy import Jdznxtd02sy
from .jd._light._jdznxtd01sy.jdznxtd01sy import Jdznxtd01sy
from .jd._light._jdznxtd03sy.jdznxtd03sy import Jdznxtd03sy
from .jd._light._jdznsd01sy.jdznsd01sy import Jdznsd01sy
from .jd._light._jdzntd02sy.jdzntd02sy import Jdzntd02sy
from .jd._light._jdzntd01sy.jdzntd01sy import Jdzntd01sy
from .jd._switch._jdzn3kg03lf.jdzn3kg03lf import Jdzn3kg03lf
from .jd._switch._jdzn2kg02lf.jdzn2kg02lf import Jdzn2kg02lf
from .jd._switch._jdzn1kg01lf.jdzn1kg01lf import Jdzn1kg01lf
from .jd._curtain._jdzncl01dy.jdzncl01dy import Jdzncl01dy
from .jd._switch._jdzn1kg04lf.jdzn1kg04lf import Jdzn1kg04lf
from .jd._switch._jdzn2kg05lf.jdzn2kg05lf import Jdzn2kg05lf
from .jd._switch._jdzn3kg06lf.jdzn3kg06lf import Jdzn3kg06lf
from .jd._gateway._jdzhp02qs.jdzhp02qs import Jdzhp02qs
from .jd._gateway._jdzhp01qs.jdzhp01qs import Jdzhp01qs
from .jd._light._jdznsd02sy.jdznsd02sy import Jdznsd02sy
from .jd._light._jdznsd03sy.jdznsd03sy import Jdznsd03sy
from .jd._light._d1max150.d1_max_150 import D1Max150
from .arrow._toilet._ad828a.ad828a import Ad828a

__all__ = [
    "Jdznsd04sy",
    "Jdznxtd02sy",
    "Jdznxtd01sy",
    "Jdznxtd03sy",
    "Jdznsd01sy",
    "Jdzntd02sy",
    "Jdzntd01sy",
    "Jdzn3kg03lf",
    "Jdzn2kg02lf",
    "Jdzn1kg01lf",
    "Jdzncl01dy",
    "Jdzn1kg04lf",
    "Jdzn2kg05lf",
    "Jdzn3kg06lf",
    "Jdzhp02qs",
    "Jdzhp01qs",
    "Jdznsd02sy",
    "Jdznsd03sy",
    "D1Max150",
    "Ad828a",
]
