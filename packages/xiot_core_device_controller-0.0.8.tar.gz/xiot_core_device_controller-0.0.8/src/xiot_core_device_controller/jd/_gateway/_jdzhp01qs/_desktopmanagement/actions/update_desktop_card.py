from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.desk_card_number import DeskCardNumber
from ..properties.content import Content


import logging

_LOGGER = logging.getLogger(__name__)

# 更新桌面卡片
class UpdateDesktopCard(ActionController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:action:update-desktop-card:00000e33:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Update Desktop Card"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "更新桌面卡片"


    # 执行 Action 调用
    async def invoke(self, desk_card_number: Optional[int], content: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if desk_card_number is None:
            raise ValueError("参数desk_card_number不能为空")
        arguments[DeskCardNumber.IID] = ArgumentOperation(piid = DeskCardNumber.IID, value = desk_card_number)

        if content is None:
            raise ValueError("参数content不能为空")
        arguments[Content.IID] = ArgumentOperation(piid = Content.IID, value = content)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
