from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.desk_number import DeskNumber


import logging

_LOGGER = logging.getLogger(__name__)

# 删除桌面
class DeleteDesktop(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:delete-desktop:00000e2e:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Delete Desktop"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "删除桌面"


    # 执行 Action 调用
    async def invoke(self, desk_number: Optional[int]):
        arguments: Dict[int, ArgumentOperation] = {}

        if desk_number is None:
            raise ValueError("参数desk_number不能为空")
        arguments[DeskNumber.IID] = ArgumentOperation(piid = DeskNumber.IID, value = desk_number)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
