from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .color4 import Color4
from .brightness import Brightness
from .hue import Hue

class SettingsValue:
    color4: Color4 = Color4()
    brightness: Brightness = Brightness()
    hue: Hue = Hue()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.color4.put_value(value[Color4.IID])
            self.brightness.put_value(value[Brightness.IID])
            self.hue.put_value(value[Hue.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Color4.IID: self.color4.to_map(self.color4.get_value()),
            Brightness.IID: self.brightness.get_value(),
            Hue.IID: self.hue.get_value(),
        }
        return _map

# 设置
class Settings(PropertyController[SettingsValue]):
    IID: int = 10
    TYPE: str = "urn:jd-spec:property:settings:0000000a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "Settings"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "设置"



    def to_map(self, value: Optional[SettingsValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
