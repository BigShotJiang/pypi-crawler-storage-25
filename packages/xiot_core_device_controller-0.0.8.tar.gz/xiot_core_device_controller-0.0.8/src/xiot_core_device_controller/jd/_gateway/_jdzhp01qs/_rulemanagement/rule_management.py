from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.add_rule import AddRule
from .actions.edit_rule import EditRule
from .actions.enable_rule import EnableRule
from .actions.trigger_rule import TriggerRule
from .actions.remove_rule import RemoveRule
from .actions.get_rules6 import GetRules6
from .actions.get_rules7 import GetRules7

from .events.rule_removed import RuleRemoved
from .events.rule_added import RuleAdded
from .events.rule_updated import RuleUpdated
from .events.rule_enabled import RuleEnabled
from .events.rule_started import RuleStarted
from .events.rule_running import RuleRunning
from .events.rule_excuted_result import RuleExcutedResult

from .properties.rule_name import RuleName
from .properties.rule_id import RuleId
from .properties.rule_enable import RuleEnable
from .properties.rule_content import RuleContent
from .properties.content_formatter import ContentFormatter
from .properties.rule_info_c import RuleInfoC
from .properties.roomid import Roomid
from .properties.timestamp import Timestamp
from .properties.operation_type import OperationType
from .properties.operation_id import OperationId
from .properties.operation_value import OperationValue
from .properties.operation_result import OperationResult
from .properties.status import Status
from .properties.r_description import RDescription
from .properties.progress import Progress
from .properties.iconid import Iconid
from .properties.delete_after_execution import DeleteAfterExecution

# 场景管理服务
class RuleManagement(ServiceController):
    IID: int = 8
    TYPE: str = "urn:jd-spec:service:rule-management:00000e78:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "rule-management"
        self.description["zh-CN"] = "场景管理服务"

        self.properties[RuleName.IID] = RuleName()
        self.properties[RuleId.IID] = RuleId()
        self.properties[RuleEnable.IID] = RuleEnable()
        self.properties[RuleContent.IID] = RuleContent()
        self.properties[ContentFormatter.IID] = ContentFormatter()
        self.properties[RuleInfoC.IID] = RuleInfoC()
        self.properties[Roomid.IID] = Roomid()
        self.properties[Timestamp.IID] = Timestamp()
        self.properties[OperationType.IID] = OperationType()
        self.properties[OperationId.IID] = OperationId()
        self.properties[OperationValue.IID] = OperationValue()
        self.properties[OperationResult.IID] = OperationResult()
        self.properties[Status.IID] = Status()
        self.properties[RDescription.IID] = RDescription()
        self.properties[Progress.IID] = Progress()
        self.properties[Iconid.IID] = Iconid()
        self.properties[DeleteAfterExecution.IID] = DeleteAfterExecution()

        self.actions[AddRule.IID] = AddRule()
        self.actions[EditRule.IID] = EditRule()
        self.actions[EnableRule.IID] = EnableRule()
        self.actions[TriggerRule.IID] = TriggerRule()
        self.actions[RemoveRule.IID] = RemoveRule()
        self.actions[GetRules6.IID] = GetRules6()
        self.actions[GetRules7.IID] = GetRules7()

        self.events[RuleRemoved.IID] = RuleRemoved()
        self.events[RuleAdded.IID] = RuleAdded()
        self.events[RuleUpdated.IID] = RuleUpdated()
        self.events[RuleEnabled.IID] = RuleEnabled()
        self.events[RuleStarted.IID] = RuleStarted()
        self.events[RuleRunning.IID] = RuleRunning()
        self.events[RuleExcutedResult.IID] = RuleExcutedResult()

    # 场景名称
    def rule_name_(self) -> RuleName:
        return self.properties[RuleName.IID] # type: ignore[no-any-return]

    # 场景id
    def rule_id_(self) -> RuleId:
        return self.properties[RuleId.IID] # type: ignore[no-any-return]

    # 场景使能
    def rule_enable_(self) -> RuleEnable:
        return self.properties[RuleEnable.IID] # type: ignore[no-any-return]

    # 场景内容
    def rule_content_(self) -> RuleContent:
        return self.properties[RuleContent.IID] # type: ignore[no-any-return]

    # 场景内容格式
    def content_formatter_(self) -> ContentFormatter:
        return self.properties[ContentFormatter.IID] # type: ignore[no-any-return]

    # 规则信息
    def rule_info_c_(self) -> RuleInfoC:
        return self.properties[RuleInfoC.IID] # type: ignore[no-any-return]

    # 房间id
    def roomid_(self) -> Roomid:
        return self.properties[Roomid.IID] # type: ignore[no-any-return]

    # 时间戳
    def timestamp_(self) -> Timestamp:
        return self.properties[Timestamp.IID] # type: ignore[no-any-return]

    # 操作类型
    def operation_type_(self) -> OperationType:
        return self.properties[OperationType.IID] # type: ignore[no-any-return]

    # 操作id，根据operation-type决定，invoke-aciton：aid，invoke-rule：null，sleep：null,set-property:pid
    def operation_id_(self) -> OperationId:
        return self.properties[OperationId.IID] # type: ignore[no-any-return]

    # 操作值
    def operation_value_(self) -> OperationValue:
        return self.properties[OperationValue.IID] # type: ignore[no-any-return]

    # 操作结果
    def operation_result_(self) -> OperationResult:
        return self.properties[OperationResult.IID] # type: ignore[no-any-return]

    # 设备状态
    def status_(self) -> Status:
        return self.properties[Status.IID] # type: ignore[no-any-return]

    # 描述
    def r_description_(self) -> RDescription:
        return self.properties[RDescription.IID] # type: ignore[no-any-return]

    # 进度
    def progress_(self) -> Progress:
        return self.properties[Progress.IID] # type: ignore[no-any-return]

    # iconId
    def iconid_(self) -> Iconid:
        return self.properties[Iconid.IID] # type: ignore[no-any-return]

    # 执行完删除
    def delete_after_execution_(self) -> DeleteAfterExecution:
        return self.properties[DeleteAfterExecution.IID] # type: ignore[no-any-return]


    # 添加场景
    def add_rule_(self) -> AddRule:
        return self.actions[AddRule.IID] # type: ignore[no-any-return]

    # 修改场景
    def edit_rule_(self) -> EditRule:
        return self.actions[EditRule.IID] # type: ignore[no-any-return]

    # 使能场景
    def enable_rule_(self) -> EnableRule:
        return self.actions[EnableRule.IID] # type: ignore[no-any-return]

    # 执行场景
    def trigger_rule_(self) -> TriggerRule:
        return self.actions[TriggerRule.IID] # type: ignore[no-any-return]

    # 删除场景
    def remove_rule_(self) -> RemoveRule:
        return self.actions[RemoveRule.IID] # type: ignore[no-any-return]

    # 查询场景
    def get_rules6_(self) -> GetRules6:
        return self.actions[GetRules6.IID] # type: ignore[no-any-return]

    # 查询场景列表
    def get_rules7_(self) -> GetRules7:
        return self.actions[GetRules7.IID] # type: ignore[no-any-return]


    # 场景删除
    def rule_removed_(self) -> RuleRemoved:
        return self.events[RuleRemoved.IID] # type: ignore[no-any-return]

    # 场景创建
    def rule_added_(self) -> RuleAdded:
        return self.events[RuleAdded.IID] # type: ignore[no-any-return]

    # 场景更新
    def rule_updated_(self) -> RuleUpdated:
        return self.events[RuleUpdated.IID] # type: ignore[no-any-return]

    # 场景使能
    def rule_enabled_(self) -> RuleEnabled:
        return self.events[RuleEnabled.IID] # type: ignore[no-any-return]

    # 场景执行开始
    def rule_started_(self) -> RuleStarted:
        return self.events[RuleStarted.IID] # type: ignore[no-any-return]

    # 场景执行中
    def rule_running_(self) -> RuleRunning:
        return self.events[RuleRunning.IID] # type: ignore[no-any-return]

    # 场景执行结果
    def rule_excuted_result_(self) -> RuleExcutedResult:
        return self.events[RuleExcutedResult.IID] # type: ignore[no-any-return]

