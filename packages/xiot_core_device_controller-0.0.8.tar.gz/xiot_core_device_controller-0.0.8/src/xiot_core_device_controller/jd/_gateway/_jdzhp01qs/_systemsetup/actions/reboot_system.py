from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController



import logging

_LOGGER = logging.getLogger(__name__)

# 重启系统
class RebootSystem(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:reboot-system:00000d50:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "reboot system"
        self.description["zh-CN"] = "重启系统"


    # 执行 Action 调用
    async def invoke(self, ):
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
