from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.say import Say


from .properties.format import Format
from .properties.content import Content

# 语音服务
class Voice(ServiceController):
    IID: int = 144
    TYPE: str = "urn:jd-spec:service:voice:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Voice Service"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "语音服务"

        self.properties[Format.IID] = Format()
        self.properties[Content.IID] = Content()

        self.actions[Say.IID] = Say()


    # 格式
    def format_(self) -> Format:
        return self.properties[Format.IID] # type: ignore[no-any-return]

    # 内容
    def content_(self) -> Content:
        return self.properties[Content.IID] # type: ignore[no-any-return]


    # 说话
    def say_(self) -> Say:
        return self.actions[Say.IID] # type: ignore[no-any-return]


