from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .did import Did
from .pid import Pid
from .device_type import DeviceType

class DeviceInfoCValue:
    did: Did = Did()
    pid: Pid = Pid()
    device_type: DeviceType = DeviceType()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.did.put_value(value[Did.IID])
            self.pid.put_value(value[Pid.IID])
            self.device_type.put_value(value[DeviceType.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Did.IID: self.did.get_value(),
            Pid.IID: self.pid.get_value(),
            DeviceType.IID: self.device_type.get_value(),
        }
        return _map

# 设备信息
class DeviceInfoC(PropertyController[DeviceInfoCValue]):
    IID: int = 5
    TYPE: str = "urn:jd-spec:property:device-info-c:00001c2f:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "device-info-c"
        self.description["zh-CN"] = "设备信息"



    def to_map(self, value: Optional[DeviceInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
