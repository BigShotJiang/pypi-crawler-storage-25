from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 模式
class Mode(PropertyController[int]):
    IID: int = 4
    TYPE: str = "urn:jd-spec:property:mode:00000007:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=True, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Mode"
        self.description["zh-CN"] = "模式"

        value_list: list[ValueDefinition[int]] = []
        desc_0: Dict[str, str] = {
            "en-US": "nightlight",
            "zh-CN": "夜灯",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 1, description = desc_0))

        desc_1: Dict[str, str] = {
            "en-US": "cold",
            "zh-CN": "冷",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 2, description = desc_1))

        desc_2: Dict[str, str] = {
            "en-US": "neutral",
            "zh-CN": "中性",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 3, description = desc_2))

        desc_3: Dict[str, str] = {
            "en-US": "warm",
            "zh-CN": "暖",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 4, description = desc_3))

        self.constraint_value = ValueList(value_list)


