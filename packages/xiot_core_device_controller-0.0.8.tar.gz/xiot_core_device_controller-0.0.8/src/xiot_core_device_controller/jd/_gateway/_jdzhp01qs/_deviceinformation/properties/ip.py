from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# ipv4地址
class Ip(PropertyController[str]):
    IID: int = 7
    TYPE: str = "urn:jd-spec:property:ip:00000086:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.STRING
        )
        self.description["en-US"] = "IpV4"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "ipv4地址"



