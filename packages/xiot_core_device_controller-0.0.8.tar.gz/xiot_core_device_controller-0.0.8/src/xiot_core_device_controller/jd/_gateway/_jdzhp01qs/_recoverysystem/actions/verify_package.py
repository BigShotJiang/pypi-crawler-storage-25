from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.path import Path


import logging

_LOGGER = logging.getLogger(__name__)

# 验证固件包
class VerifyPackage(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:verify-package:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Verify Package"
        self.description["zh-CN"] = "验证固件包"


    # 执行 Action 调用
    async def invoke(self, path: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if path is None:
            raise ValueError("参数path不能为空")
        arguments[Path.IID] = ArgumentOperation(piid = Path.IID, value = path)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
