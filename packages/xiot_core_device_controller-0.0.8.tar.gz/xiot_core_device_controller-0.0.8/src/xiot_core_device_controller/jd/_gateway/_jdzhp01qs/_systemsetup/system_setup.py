from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.reboot_system import RebootSystem
from .actions.logout import Logout


from .properties.mute import Mute
from .properties.voice_assistant_enabled import VoiceAssistantEnabled

# 系统设置
class SystemSetup(ServiceController):
    IID: int = 17
    TYPE: str = "urn:jd-spec:service:system-setup:00000e7e:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "System Setup"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "系统设置"

        self.properties[Mute.IID] = Mute()
        self.properties[VoiceAssistantEnabled.IID] = VoiceAssistantEnabled()

        self.actions[RebootSystem.IID] = RebootSystem()
        self.actions[Logout.IID] = Logout()


    # 静音
    def mute_(self) -> Mute:
        return self.properties[Mute.IID] # type: ignore[no-any-return]

    # 语音助手使能
    def voice_assistant_enabled_(self) -> VoiceAssistantEnabled:
        return self.properties[VoiceAssistantEnabled.IID] # type: ignore[no-any-return]


    # 重启系统
    def reboot_system_(self) -> RebootSystem:
        return self.actions[RebootSystem.IID] # type: ignore[no-any-return]

    # 登出
    def logout_(self) -> Logout:
        return self.actions[Logout.IID] # type: ignore[no-any-return]


