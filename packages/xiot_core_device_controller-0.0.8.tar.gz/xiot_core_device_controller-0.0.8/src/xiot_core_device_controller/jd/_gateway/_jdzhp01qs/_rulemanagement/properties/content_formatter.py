from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 场景内容格式
class ContentFormatter(PropertyController[int]):
    IID: int = 5
    TYPE: str = "urn:jd-spec:property:content-formatter:00001c35:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "content-formatter"
        self.description["zh-CN"] = "场景内容格式"

        value_list: list[ValueDefinition[int]] = []
        desc_0: Dict[str, str] = {
            "en-US": "rdl",
            "zh-CN": "RDL 格式",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 0, description = desc_0))

        desc_1: Dict[str, str] = {
            "en-US": "json",
            "zh-CN": "JSON 格式",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 1, description = desc_1))

        self.constraint_value = ValueList(value_list)


