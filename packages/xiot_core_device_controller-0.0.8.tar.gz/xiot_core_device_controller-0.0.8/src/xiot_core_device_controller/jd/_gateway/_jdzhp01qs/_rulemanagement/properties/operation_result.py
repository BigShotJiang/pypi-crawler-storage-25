from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .operation_type import OperationType
from .operation_id import OperationId
from .operation_value import OperationValue
from .status import Status
from .r_description import RDescription

class OperationResultValue:
    operation_type: OperationType = OperationType()
    operation_id: OperationId = OperationId()
    operation_value: OperationValue = OperationValue()
    status: Status = Status()
    r_description: RDescription = RDescription()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.operation_type.put_value(value[OperationType.IID])
            self.operation_id.put_value(value[OperationId.IID])
            self.operation_value.put_value(value[OperationValue.IID])
            self.status.put_value(value[Status.IID])
            self.r_description.put_value(value[RDescription.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            OperationType.IID: self.operation_type.get_value(),
            OperationId.IID: self.operation_id.get_value(),
            OperationValue.IID: self.operation_value.get_value(),
            Status.IID: self.status.get_value(),
            RDescription.IID: self.r_description.get_value(),
        }
        return _map

# 操作结果
class OperationResult(PropertyController[OperationResultValue]):
    IID: int = 12
    TYPE: str = "urn:jd-spec:property:operation-result:00001c3a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "operation-result"
        self.description["zh-CN"] = "操作结果"



    def to_map(self, value: Optional[OperationResultValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
