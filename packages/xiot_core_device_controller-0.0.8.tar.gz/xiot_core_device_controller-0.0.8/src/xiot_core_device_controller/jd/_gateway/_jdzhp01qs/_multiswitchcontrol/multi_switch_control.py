from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.open_all_switches import OpenAllSwitches
from .actions.close_all_switches import CloseAllSwitches



# 多路开关控制
class MultiSwitchControl(ServiceController):
    IID: int = 146
    TYPE: str = "urn:jd-spec:service:multi-switch-control:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Multi Switch Control"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "多路开关控制"


        self.actions[OpenAllSwitches.IID] = OpenAllSwitches()
        self.actions[CloseAllSwitches.IID] = CloseAllSwitches()



    # 全开
    def open_all_switches_(self) -> OpenAllSwitches:
        return self.actions[OpenAllSwitches.IID] # type: ignore[no-any-return]

    # 全关
    def close_all_switches_(self) -> CloseAllSwitches:
        return self.actions[CloseAllSwitches.IID] # type: ignore[no-any-return]


