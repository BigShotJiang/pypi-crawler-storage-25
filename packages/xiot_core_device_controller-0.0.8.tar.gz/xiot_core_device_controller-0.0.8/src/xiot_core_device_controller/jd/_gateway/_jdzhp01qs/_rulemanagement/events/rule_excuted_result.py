from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.rule_id import RuleId
from ..properties.timestamp import Timestamp
from ..properties.operation_result import OperationResult
from ..properties.operation_result import OperationResultValue

# 场景执行结果
class RuleExcutedResult(EventController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:event:rule-excuted-result:00000a3a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "rule-excuted-result"
        self.description["zh-CN"] = "场景执行结果"

        self._observer: Callable[[str, int, list[OperationResultValue]], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            rule_id = self.__rule_id(o)
            timestamp = self.__timestamp(o)
            operation_results: list[OperationResultValue]  = self.__operation_results(o)
            self._observer(rule_id, timestamp, operation_results)

    def observer(self, observer: Callable[[str, int, list[OperationResultValue]], None]) -> None:
        self._observer = observer

    @staticmethod
    def __rule_id(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[RuleId.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(RuleId.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(RuleId.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(RuleId.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __timestamp(o: EventOperation) -> int :
        argument: ArgumentOperation = o.arguments[Timestamp.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(Timestamp.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(Timestamp.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(Timestamp.IID))

        value: object = objects[0]
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __operation_results(o: EventOperation) -> list[OperationResultValue]:
        argument: ArgumentOperation = o.arguments[OperationResult.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(OperationResult.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(OperationResult.IID))

        values: list[OperationResultValue] = []
        for item in objects:
            if isinstance(item, dict):
                values.append(OperationResultValue(item))
            else:
                _LOGGER.error("argument value invalid: %s", type(item).__name__)

        return values

