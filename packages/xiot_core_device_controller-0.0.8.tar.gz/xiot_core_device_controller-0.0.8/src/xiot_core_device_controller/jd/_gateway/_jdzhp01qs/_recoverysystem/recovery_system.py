from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.verify_package import VerifyPackage
from .actions.install_package import InstallPackage


from .properties.path import Path
from .properties.progress import Progress

# Recovery系统
class RecoverySystem(ServiceController):
    IID: int = 25
    TYPE: str = "urn:jd-spec:service:recovery-system:000000f1:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Recovery System"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "Recovery系统"

        self.properties[Path.IID] = Path()
        self.properties[Progress.IID] = Progress()

        self.actions[VerifyPackage.IID] = VerifyPackage()
        self.actions[InstallPackage.IID] = InstallPackage()


    # 固件文件路径
    def path_(self) -> Path:
        return self.properties[Path.IID] # type: ignore[no-any-return]

    # 验证固件包的进度
    def progress_(self) -> Progress:
        return self.properties[Progress.IID] # type: ignore[no-any-return]


    # 验证固件包
    def verify_package_(self) -> VerifyPackage:
        return self.actions[VerifyPackage.IID] # type: ignore[no-any-return]

    # 升级固件包
    def install_package_(self) -> InstallPackage:
        return self.actions[InstallPackage.IID] # type: ignore[no-any-return]


