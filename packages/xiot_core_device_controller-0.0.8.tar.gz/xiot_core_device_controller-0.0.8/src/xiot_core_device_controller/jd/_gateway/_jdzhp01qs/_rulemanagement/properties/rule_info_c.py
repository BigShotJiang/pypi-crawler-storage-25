from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .rule_name import RuleName
from .rule_id import RuleId
from .rule_enable import RuleEnable
from .rule_content import RuleContent
from .content_formatter import ContentFormatter
from .roomid import Roomid
from .r_description import RDescription
from .iconid import Iconid

class RuleInfoCValue:
    rule_name: RuleName = RuleName()
    rule_id: RuleId = RuleId()
    rule_enable: RuleEnable = RuleEnable()
    rule_content: RuleContent = RuleContent()
    content_formatter: ContentFormatter = ContentFormatter()
    roomid: Roomid = Roomid()
    r_description: RDescription = RDescription()
    iconid: Iconid = Iconid()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.rule_name.put_value(value[RuleName.IID])
            self.rule_id.put_value(value[RuleId.IID])
            self.rule_enable.put_value(value[RuleEnable.IID])
            self.rule_content.put_value(value[RuleContent.IID])
            self.content_formatter.put_value(value[ContentFormatter.IID])
            self.roomid.put_value(value[Roomid.IID])
            self.r_description.put_value(value[RDescription.IID])
            self.iconid.put_value(value[Iconid.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            RuleName.IID: self.rule_name.get_value(),
            RuleId.IID: self.rule_id.get_value(),
            RuleEnable.IID: self.rule_enable.get_value(),
            RuleContent.IID: self.rule_content.get_value(),
            ContentFormatter.IID: self.content_formatter.get_value(),
            Roomid.IID: self.roomid.get_value(),
            RDescription.IID: self.r_description.get_value(),
            Iconid.IID: self.iconid.get_value(),
        }
        return _map

# 规则信息
class RuleInfoC(PropertyController[RuleInfoCValue]):
    IID: int = 6
    TYPE: str = "urn:jd-spec:property:rule-info-c:00001c3b:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "rule-info-c"
        self.description["zh-CN"] = "规则信息"



    def to_map(self, value: Optional[RuleInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
