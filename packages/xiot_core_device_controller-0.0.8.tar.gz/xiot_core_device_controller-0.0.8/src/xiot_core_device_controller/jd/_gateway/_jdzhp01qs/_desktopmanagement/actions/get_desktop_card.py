from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.desk_card_number import DeskCardNumber


import logging

_LOGGER = logging.getLogger(__name__)

# 查询桌面卡片
class GetDesktopCard(ActionController):
    IID: int = 8
    TYPE: str = "urn:jd-spec:action:get-desktop-card:00000e31:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Get Desktop Card"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "查询桌面卡片"


    # 执行 Action 调用
    async def invoke(self, desk_card_number: Optional[int]):
        arguments: Dict[int, ArgumentOperation] = {}

        if desk_card_number is None:
            raise ValueError("参数desk_card_number不能为空")
        arguments[DeskCardNumber.IID] = ArgumentOperation(piid = DeskCardNumber.IID, value = desk_card_number)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
