from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.firmware_info_c import FirmwareInfoC
from ..properties.firmware_info_c import FirmwareInfoCValue
from ..properties.did import Did


import logging

_LOGGER = logging.getLogger(__name__)

# 升级固件
class UpgradeFirmware(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:upgrade-firmware:00000d49:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "upgrade-firmware"
        self.description["zh-CN"] = "升级固件"


    # 执行 Action 调用
    async def invoke(self, firmware_info_c: Optional[FirmwareInfoCValue], did: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if firmware_info_c is None:
            raise ValueError("参数firmware_info_c不能为空")
        arguments[FirmwareInfoC.IID] = ArgumentOperation(piid = FirmwareInfoC.IID, value = firmware_info_c.to_map())

        if did is None:
            raise ValueError("参数did不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, value = did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
