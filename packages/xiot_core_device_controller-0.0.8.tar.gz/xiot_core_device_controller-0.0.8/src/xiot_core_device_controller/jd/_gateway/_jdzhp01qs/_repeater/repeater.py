from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.enable import Enable

# 中继
class Repeater(ServiceController):
    IID: int = 145
    TYPE: str = "urn:jd-spec:service:repeater:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Repeater"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "中继"

        self.properties[Enable.IID] = Enable()



    # 启用
    def enable_(self) -> Enable:
        return self.properties[Enable.IID] # type: ignore[no-any-return]



