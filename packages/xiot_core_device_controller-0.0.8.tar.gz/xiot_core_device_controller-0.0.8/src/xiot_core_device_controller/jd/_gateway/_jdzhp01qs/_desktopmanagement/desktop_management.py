from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.add_desktop import AddDesktop
from .actions.delete_desktop import DeleteDesktop
from .actions.update_desktop import UpdateDesktop
from .actions.get_desktop import GetDesktop
from .actions.add_desktop_card import AddDesktopCard
from .actions.delete_desktop_card import DeleteDesktopCard
from .actions.update_desktop_card import UpdateDesktopCard
from .actions.get_desktop_card import GetDesktopCard


from .properties.desk_number import DeskNumber
from .properties.desk_card_number import DeskCardNumber
from .properties.content import Content

# 桌面管理
class DesktopManagement(ServiceController):
    IID: int = 21
    TYPE: str = "urn:jd-spec:service:desktop-management:00000e8b:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Desktop Management"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "桌面管理"

        self.properties[DeskNumber.IID] = DeskNumber()
        self.properties[DeskCardNumber.IID] = DeskCardNumber()
        self.properties[Content.IID] = Content()

        self.actions[AddDesktop.IID] = AddDesktop()
        self.actions[DeleteDesktop.IID] = DeleteDesktop()
        self.actions[UpdateDesktop.IID] = UpdateDesktop()
        self.actions[GetDesktop.IID] = GetDesktop()
        self.actions[AddDesktopCard.IID] = AddDesktopCard()
        self.actions[DeleteDesktopCard.IID] = DeleteDesktopCard()
        self.actions[UpdateDesktopCard.IID] = UpdateDesktopCard()
        self.actions[GetDesktopCard.IID] = GetDesktopCard()


    # 桌面编号
    def desk_number_(self) -> DeskNumber:
        return self.properties[DeskNumber.IID] # type: ignore[no-any-return]

    # 桌面卡片编号
    def desk_card_number_(self) -> DeskCardNumber:
        return self.properties[DeskCardNumber.IID] # type: ignore[no-any-return]

    # 内容
    def content_(self) -> Content:
        return self.properties[Content.IID] # type: ignore[no-any-return]


    # 添加桌面
    def add_desktop_(self) -> AddDesktop:
        return self.actions[AddDesktop.IID] # type: ignore[no-any-return]

    # 删除桌面
    def delete_desktop_(self) -> DeleteDesktop:
        return self.actions[DeleteDesktop.IID] # type: ignore[no-any-return]

    # 更新桌面
    def update_desktop_(self) -> UpdateDesktop:
        return self.actions[UpdateDesktop.IID] # type: ignore[no-any-return]

    # 查询桌面
    def get_desktop_(self) -> GetDesktop:
        return self.actions[GetDesktop.IID] # type: ignore[no-any-return]

    # 添加桌面卡片
    def add_desktop_card_(self) -> AddDesktopCard:
        return self.actions[AddDesktopCard.IID] # type: ignore[no-any-return]

    # 删除桌面卡片
    def delete_desktop_card_(self) -> DeleteDesktopCard:
        return self.actions[DeleteDesktopCard.IID] # type: ignore[no-any-return]

    # 更新桌面卡片
    def update_desktop_card_(self) -> UpdateDesktopCard:
        return self.actions[UpdateDesktopCard.IID] # type: ignore[no-any-return]

    # 查询桌面卡片
    def get_desktop_card_(self) -> GetDesktopCard:
        return self.actions[GetDesktopCard.IID] # type: ignore[no-any-return]


