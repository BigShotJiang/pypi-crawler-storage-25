from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.permit_join import PermitJoin
from .actions.forbid_join import ForbidJoin
from .actions.remove_device import RemoveDevice

from .events.device_removed import DeviceRemoved
from .events.device_added import DeviceAdded

from .properties.did import Did
from .properties.time_out import TimeOut
from .properties.pid import Pid
from .properties.device_type import DeviceType
from .properties.device_info_c import DeviceInfoC

# zigbee设备管理服务
class ZigbeeDeviceManagement(ServiceController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:service:zigbee-device-management:00000e77:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "zigbee-device-management"
        self.description["zh-CN"] = "zigbee设备管理服务"

        self.properties[Did.IID] = Did()
        self.properties[TimeOut.IID] = TimeOut()
        self.properties[Pid.IID] = Pid()
        self.properties[DeviceType.IID] = DeviceType()
        self.properties[DeviceInfoC.IID] = DeviceInfoC()

        self.actions[PermitJoin.IID] = PermitJoin()
        self.actions[ForbidJoin.IID] = ForbidJoin()
        self.actions[RemoveDevice.IID] = RemoveDevice()

        self.events[DeviceRemoved.IID] = DeviceRemoved()
        self.events[DeviceAdded.IID] = DeviceAdded()

    # 设备did
    def did_(self) -> Did:
        return self.properties[Did.IID] # type: ignore[no-any-return]

    # 超时时间
    def time_out_(self) -> TimeOut:
        return self.properties[TimeOut.IID] # type: ignore[no-any-return]

    # 产品ID
    def pid_(self) -> Pid:
        return self.properties[Pid.IID] # type: ignore[no-any-return]

    # 设备类型
    def device_type_(self) -> DeviceType:
        return self.properties[DeviceType.IID] # type: ignore[no-any-return]

    # 设备信息
    def device_info_c_(self) -> DeviceInfoC:
        return self.properties[DeviceInfoC.IID] # type: ignore[no-any-return]


    # 开启组网
    def permit_join_(self) -> PermitJoin:
        return self.actions[PermitJoin.IID] # type: ignore[no-any-return]

    # 关闭组网
    def forbid_join_(self) -> ForbidJoin:
        return self.actions[ForbidJoin.IID] # type: ignore[no-any-return]

    # 删除设备
    def remove_device_(self) -> RemoveDevice:
        return self.actions[RemoveDevice.IID] # type: ignore[no-any-return]


    # 设备删除
    def device_removed_(self) -> DeviceRemoved:
        return self.events[DeviceRemoved.IID] # type: ignore[no-any-return]

    # 设备添加
    def device_added_(self) -> DeviceAdded:
        return self.events[DeviceAdded.IID] # type: ignore[no-any-return]

