from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .brightness import Brightness
from .hue import Hue
from .saturation import Saturation
from .color_temperature import ColorTemperature

class Color9Value:
    brightness: Brightness = Brightness()
    hue: Hue = Hue()
    saturation: Saturation = Saturation()
    color_temperature: ColorTemperature = ColorTemperature()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.brightness.put_value(value[Brightness.IID])
            self.hue.put_value(value[Hue.IID])
            self.saturation.put_value(value[Saturation.IID])
            self.color_temperature.put_value(value[ColorTemperature.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Brightness.IID: self.brightness.get_value(),
            Hue.IID: self.hue.get_value(),
            Saturation.IID: self.saturation.get_value(),
            ColorTemperature.IID: self.color_temperature.get_value(),
        }
        return _map

# 颜色
class Color9(PropertyController[Color9Value]):
    IID: int = 9
    TYPE: str = "urn:jd-spec:property:color:00000009:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "YUV"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "颜色"



    def to_map(self, value: Optional[Color9Value]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
