from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .red import Red
from .green import Green
from .blue import Blue

class Color4Value:
    red: Red = Red()
    green: Green = Green()
    blue: Blue = Blue()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.red.put_value(value[Red.IID])
            self.green.put_value(value[Green.IID])
            self.blue.put_value(value[Blue.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Red.IID: self.red.get_value(),
            Green.IID: self.green.get_value(),
            Blue.IID: self.blue.get_value(),
        }
        return _map

# 颜色
class Color4(PropertyController[Color4Value]):
    IID: int = 4
    TYPE: str = "urn:jd-spec:property:color:00000004:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "RGB"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "颜色"



    def to_map(self, value: Optional[Color4Value]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
