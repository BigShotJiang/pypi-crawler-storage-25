from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .did import Did
from .rssi import Rssi

class DeviceRssiCValue:
    did: Did = Did()
    rssi: Rssi = Rssi()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.did.put_value(value[Did.IID])
            self.rssi.put_value(value[Rssi.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Did.IID: self.did.get_value(),
            Rssi.IID: self.rssi.get_value(),
        }
        return _map

# 设备rssi
class DeviceRssiC(PropertyController[DeviceRssiCValue]):
    IID: int = 7
    TYPE: str = "urn:jd-spec:property:device-rssi-c:00001c2f:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "device-rssi-c"
        self.description["zh-CN"] = "设备rssi"



    def to_map(self, value: Optional[DeviceRssiCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
