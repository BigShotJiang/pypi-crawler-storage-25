from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 目标位置
class TargetPosition(PropertyController[int]):
    IID: int = 1
    TYPE: str = "urn:jd-spec:property:target-position:00000fb4:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=True, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Target Position"
        self.description["zh-CN"] = "目标位置"

        self.constraint_value = ValueRange(DataFormat.UINT8,
            min_ = 0,
            max_ = 100,
            step_ = 1
        )


