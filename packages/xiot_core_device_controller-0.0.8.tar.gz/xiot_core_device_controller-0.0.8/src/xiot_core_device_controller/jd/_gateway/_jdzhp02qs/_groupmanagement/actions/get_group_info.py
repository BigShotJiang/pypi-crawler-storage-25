from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.group_did import GroupDid

from ..properties.group_did import GroupDid
from ..properties.did import Did

import logging

_LOGGER = logging.getLogger(__name__)

# 获取组信息
class GetGroupInfo(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:get-group-info:00000b5a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Get Group Info"
        self.description["zh-CN"] = "获取组信息"

    # Action 出参
    class Result:
        # 组did
        group_did: str
        # 设备did列表
        dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[GroupDid.IID]
            if _1 is not None:
                v = _1.values[0]
                if isinstance(v, str):
                    self.group_did = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", GroupDid)

            _2: Optional[ArgumentOperation] = result[Did.IID]
            if _2 is not None:
                self.dids = [str(item) for item in _2.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", Did)

            return

    # 执行 Action 调用
    async def invoke(self, group_did: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if group_did is None:
            raise ValueError("参数group_did不能为空")
        arguments[GroupDid.IID] = ArgumentOperation(piid = GroupDid.IID, value = group_did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return GetGroupInfo.Result(out)
