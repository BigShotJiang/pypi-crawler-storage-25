from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .protocol import Protocol
from .md5 import Md5
from .sha256 import Sha256
from .firmware_url import FirmwareUrl
from .firmware_type import FirmwareType
from .file_size import FileSize
from .firmware_revision import FirmwareRevision

class FirmwareInfoCValue:
    protocol: Protocol = Protocol()
    md5: Md5 = Md5()
    sha256: Sha256 = Sha256()
    firmware_url: FirmwareUrl = FirmwareUrl()
    firmware_type: FirmwareType = FirmwareType()
    file_size: FileSize = FileSize()
    firmware_revision: FirmwareRevision = FirmwareRevision()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.protocol.put_value(value[Protocol.IID])
            self.md5.put_value(value[Md5.IID])
            self.sha256.put_value(value[Sha256.IID])
            self.firmware_url.put_value(value[FirmwareUrl.IID])
            self.firmware_type.put_value(value[FirmwareType.IID])
            self.file_size.put_value(value[FileSize.IID])
            self.firmware_revision.put_value(value[FirmwareRevision.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            Protocol.IID: self.protocol.get_value(),
            Md5.IID: self.md5.get_value(),
            Sha256.IID: self.sha256.get_value(),
            FirmwareUrl.IID: self.firmware_url.get_value(),
            FirmwareType.IID: self.firmware_type.get_value(),
            FileSize.IID: self.file_size.get_value(),
            FirmwareRevision.IID: self.firmware_revision.get_value(),
        }
        return _map

# 固件信息
class FirmwareInfoC(PropertyController[FirmwareInfoCValue]):
    IID: int = 7
    TYPE: str = "urn:jd-spec:property:firmware-info-c:00001c27:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "firmware-info-c"
        self.description["zh-CN"] = "固件信息"



    def to_map(self, value: Optional[FirmwareInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
