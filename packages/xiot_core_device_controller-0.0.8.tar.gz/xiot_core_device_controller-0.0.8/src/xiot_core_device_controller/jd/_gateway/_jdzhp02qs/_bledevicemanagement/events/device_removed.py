from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.did import Did

# 设备删除
class DeviceRemoved(EventController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:event:device-removed:00000a2c:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "device-removed"
        self.description["zh-CN"] = "设备删除"

        self._observer: Callable[[str], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            did = self.__did(o)
            self._observer(did)

    def observer(self, observer: Callable[[str], None]) -> None:
        self._observer = observer

    @staticmethod
    def __did(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[Did.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(Did.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(Did.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(Did.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

