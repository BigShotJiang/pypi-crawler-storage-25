from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.send_easylink import SendEasylink


from .properties.on import On
from .properties.brightness import Brightness
from .properties.color_temperature import ColorTemperature
from .properties.mode import Mode

# 灯控面板
class LightPanel141(ServiceController):
    IID: int = 141
    TYPE: str = "urn:jd-spec:service:light-panel:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Light Panel"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "灯控面板"

        self.properties[On.IID] = On()
        self.properties[Brightness.IID] = Brightness()
        self.properties[ColorTemperature.IID] = ColorTemperature()
        self.properties[Mode.IID] = Mode()

        self.actions[SendEasylink.IID] = SendEasylink()


    # 开关
    def on_(self) -> On:
        return self.properties[On.IID] # type: ignore[no-any-return]

    # 亮度
    def brightness_(self) -> Brightness:
        return self.properties[Brightness.IID] # type: ignore[no-any-return]

    # 色温
    def color_temperature_(self) -> ColorTemperature:
        return self.properties[ColorTemperature.IID] # type: ignore[no-any-return]

    # 模式
    def mode_(self) -> Mode:
        return self.properties[Mode.IID] # type: ignore[no-any-return]


    # 发出爽连指令
    def send_easylink_(self) -> SendEasylink:
        return self.actions[SendEasylink.IID] # type: ignore[no-any-return]


