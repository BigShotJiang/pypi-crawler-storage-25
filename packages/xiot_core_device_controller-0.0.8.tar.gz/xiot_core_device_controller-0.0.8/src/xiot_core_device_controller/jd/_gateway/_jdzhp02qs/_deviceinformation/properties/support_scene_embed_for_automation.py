from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 网关本地自动化是否支持嵌入场景
class SupportSceneEmbedForAutomation(PropertyController[bool]):
    IID: int = 9
    TYPE: str = "urn:jd-spec:property:support-scene-embed-for-automation:00001e1a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.BOOL
        )
        self.description["en-US"] = "Support Scene Embed For Automation"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "网关本地自动化是否支持嵌入场景"



