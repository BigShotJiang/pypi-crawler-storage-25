from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.group_did import GroupDid
from ..properties.did import Did


import logging

_LOGGER = logging.getLogger(__name__)

# 从组中移除设备
class RemoveDevicesFromGroup(ActionController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:action:remove-devices-from-group:00000bbb:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Remove Devices from Group"
        self.description["zh-CN"] = "从组中移除设备"


    # 执行 Action 调用
    async def invoke(self, group_did: Optional[str], dids: Optional[list[str]]):
        arguments: Dict[int, ArgumentOperation] = {}

        if group_did is None:
            raise ValueError("参数group_did不能为空")
        arguments[GroupDid.IID] = ArgumentOperation(piid = GroupDid.IID, value = group_did)

        if dids is None or len(dids) == 0:
            raise ValueError("参数dids不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, values = dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
