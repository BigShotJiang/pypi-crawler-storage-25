from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.did import Did

from ..properties.device_rssi_c import DeviceRssiC
from ..properties.device_rssi_c import DeviceRssiCValue

import logging

_LOGGER = logging.getLogger(__name__)

# 读取子设备rssi
class GetDeviceRssi(ActionController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:action:get-device-rssi:00000d4a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "get-device-rssi"
        self.description["zh-CN"] = "读取子设备rssi"

    # Action 出参
    class Result:
        # 设备rssi列表
        device_rssi_cs: list[DeviceRssiCValue]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _7: Optional[ArgumentOperation] = result[DeviceRssiC.IID]
            if _7 is not None:
                self.device_rssi_cs = [DeviceRssiCValue(value=v) for v in _7.values if isinstance(v, dict)]
            else:
                _LOGGER.error("result error, not found: %s.IID}", DeviceRssiC)

            return

    # 执行 Action 调用
    async def invoke(self, dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if dids is None or len(dids) == 0:
            raise ValueError("参数dids不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, values = dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return GetDeviceRssi.Result(out)
