from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.support_interaction import SupportInteraction
from .properties.current_interaction import CurrentInteraction

# 本地自动化设置
class Interaction(ServiceController):
    IID: int = 132
    TYPE: str = "urn:jd-spec:service:interaction:00000d49:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Interaction"
        self.description["zh-CN"] = "本地自动化设置"

        self.properties[SupportInteraction.IID] = SupportInteraction()
        self.properties[CurrentInteraction.IID] = CurrentInteraction()



    # 设备支持的微型自动化数量
    def support_interaction_(self) -> SupportInteraction:
        return self.properties[SupportInteraction.IID] # type: ignore[no-any-return]

    # 设备当下的微型自动化数量
    def current_interaction_(self) -> CurrentInteraction:
        return self.properties[CurrentInteraction.IID] # type: ignore[no-any-return]



