from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController



import logging

_LOGGER = logging.getLogger(__name__)

# 打开爽连
class StartEasylink(ActionController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:action:start-easylink:00000e40:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Start EasyLink"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "打开爽连"


    # 执行 Action 调用
    async def invoke(self, ):
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
