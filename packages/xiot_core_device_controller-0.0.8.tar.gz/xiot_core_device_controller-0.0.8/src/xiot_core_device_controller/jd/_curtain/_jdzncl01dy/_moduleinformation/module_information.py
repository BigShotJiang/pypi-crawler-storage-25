from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.protocol import Protocol
from .properties.rssi import Rssi

# 模组信息
class ModuleInformation(ServiceController):
    IID: int = 128
    TYPE: str = "urn:jd-spec:service:module-information:00000c1e:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Module Information"
        self.description["zh-CN"] = "模组信息"

        self.properties[Protocol.IID] = Protocol()
        self.properties[Rssi.IID] = Rssi()



    # 通信方式
    def protocol_(self) -> Protocol:
        return self.properties[Protocol.IID] # type: ignore[no-any-return]

    # 接收信号强度指示
    def rssi_(self) -> Rssi:
        return self.properties[Rssi.IID] # type: ignore[no-any-return]



