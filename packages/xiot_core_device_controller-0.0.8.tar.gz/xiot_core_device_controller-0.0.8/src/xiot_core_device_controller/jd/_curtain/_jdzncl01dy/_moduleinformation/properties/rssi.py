from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 接收信号强度指示
class Rssi(PropertyController[int]):
    IID: int = 2
    TYPE: str = "urn:jd-spec:property:rssi:000019cc:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.INT8
        )
        self.description["en-US"] = "Received Signal Strength Indication"
        self.description["zh-CN"] = "接收信号强度指示"

        self.constraint_value = ValueRange(DataFormat.INT8,
            min_ = -128,
            max_ = 127,
            step_ = 1
        )


