from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.stop_curtain import StopCurtain
from .actions.open_curtain import OpenCurtain
from .actions.close_curtain import CloseCurtain
from .actions.stroke_calibration import StrokeCalibration
from .actions.motor_reverse import MotorReverse

from .events.curtain_stopped import CurtainStopped
from .events.curtain_opened import CurtainOpened
from .events.curtain_closed import CurtainClosed

from .properties.motor_control import MotorControl
from .properties.current_position import CurrentPosition
from .properties.target_position import TargetPosition
from .properties.motor_reverse import MotorReverse
from .properties.whether_travel_exists import WhetherTravelExists
from .properties.name import Name

# 窗帘
class Curtain(ServiceController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:service:curtain:000007db:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Curtain"
        self.description["zh-CN"] = "窗帘"

        self.properties[MotorControl.IID] = MotorControl()
        self.properties[CurrentPosition.IID] = CurrentPosition()
        self.properties[TargetPosition.IID] = TargetPosition()
        self.properties[MotorReverse.IID] = MotorReverse()
        self.properties[WhetherTravelExists.IID] = WhetherTravelExists()
        self.properties[Name.IID] = Name()

        self.actions[StopCurtain.IID] = StopCurtain()
        self.actions[OpenCurtain.IID] = OpenCurtain()
        self.actions[CloseCurtain.IID] = CloseCurtain()
        self.actions[StrokeCalibration.IID] = StrokeCalibration()
        self.actions[MotorReverse.IID] = MotorReverse()

        self.events[CurtainStopped.IID] = CurtainStopped()
        self.events[CurtainOpened.IID] = CurtainOpened()
        self.events[CurtainClosed.IID] = CurtainClosed()

    # 电机控制
    def motor_control_(self) -> MotorControl:
        return self.properties[MotorControl.IID] # type: ignore[no-any-return]

    # 当前位置
    def current_position_(self) -> CurrentPosition:
        return self.properties[CurrentPosition.IID] # type: ignore[no-any-return]

    # 目标位置
    def target_position_(self) -> TargetPosition:
        return self.properties[TargetPosition.IID] # type: ignore[no-any-return]

    # 电机反转
    def motor_reverse_(self) -> MotorReverse:
        return self.properties[MotorReverse.IID] # type: ignore[no-any-return]

    # 是否存在行程
    def whether_travel_exists_(self) -> WhetherTravelExists:
        return self.properties[WhetherTravelExists.IID] # type: ignore[no-any-return]

    # 名称
    def name_(self) -> Name:
        return self.properties[Name.IID] # type: ignore[no-any-return]


    # 暂停窗帘
    def stop_curtain_(self) -> StopCurtain:
        return self.actions[StopCurtain.IID] # type: ignore[no-any-return]

    # 打开窗帘
    def open_curtain_(self) -> OpenCurtain:
        return self.actions[OpenCurtain.IID] # type: ignore[no-any-return]

    # 关闭窗帘
    def close_curtain_(self) -> CloseCurtain:
        return self.actions[CloseCurtain.IID] # type: ignore[no-any-return]

    # 行程校准
    def stroke_calibration_(self) -> StrokeCalibration:
        return self.actions[StrokeCalibration.IID] # type: ignore[no-any-return]

    # 电机反转
    def motor_reverse_(self) -> MotorReverse:
        return self.actions[MotorReverse.IID] # type: ignore[no-any-return]


    # 窗帘暂停
    def curtain_stopped_(self) -> CurtainStopped:
        return self.events[CurtainStopped.IID] # type: ignore[no-any-return]

    # 窗帘打开
    def curtain_opened_(self) -> CurtainOpened:
        return self.events[CurtainOpened.IID] # type: ignore[no-any-return]

    # 窗帘关闭
    def curtain_closed_(self) -> CurtainClosed:
        return self.events[CurtainClosed.IID] # type: ignore[no-any-return]

