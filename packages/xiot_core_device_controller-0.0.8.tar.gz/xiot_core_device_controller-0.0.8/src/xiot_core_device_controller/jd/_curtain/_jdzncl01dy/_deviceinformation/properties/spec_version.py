from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 物模型版本
class SpecVersion(PropertyController[int]):
    IID: int = 4
    TYPE: str = "urn:jd-spec:property:spec-version:00001a2d:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Spec Version"
        self.description["zh-CN"] = "物模型版本"

        self.constraint_value = ValueRange(DataFormat.UINT8,
            min_ = 0,
            max_ = 255,
            step_ = 1
        )


