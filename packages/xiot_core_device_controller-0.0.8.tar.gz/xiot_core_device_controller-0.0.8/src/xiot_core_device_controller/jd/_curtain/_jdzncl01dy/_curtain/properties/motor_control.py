from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 电机控制
class MotorControl(PropertyController[int]):
    IID: int = 1
    TYPE: str = "urn:jd-spec:property:motor-control:00000fb2:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Motor Control"
        self.description["zh-CN"] = "电机控制"

        value_list: list[ValueDefinition[int]] = []
        desc_0: Dict[str, str] = {
            "en-US": "Off",
            "zh-CN": "关闭",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 0, description = desc_0))

        desc_1: Dict[str, str] = {
            "en-US": "On",
            "zh-CN": "开启",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 1, description = desc_1))

        desc_2: Dict[str, str] = {
            "en-US": "Pause",
            "zh-CN": "暂停",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 2, description = desc_2))

        self.constraint_value = ValueList(value_list)


