# xiot-core-device-controller-python
xiot-core-device-controller library for python 3.10+

# install lib
```bash
pip install -e .
```

# run test
```bash
python tests/typedef/definition/urn/test_action_type.py
```

# run publish
```bash
python -m build
twine upload dist/*
```