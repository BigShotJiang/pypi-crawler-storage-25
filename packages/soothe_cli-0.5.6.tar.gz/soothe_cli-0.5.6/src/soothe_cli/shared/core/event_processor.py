"""Unified daemon event processor with pluggable rendering.

This module implements RFC-0019's unified event processing architecture.
EventProcessor handles all event routing, state management, and filtering,
delegating display to RendererProtocol implementations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from langchain_core.messages import AIMessage, AIMessageChunk, ToolMessage
from soothe_sdk.client.protocol import preview_first
from soothe_sdk.core.events import (
    PLAN_CREATED,
    PLAN_STEP_COMPLETED,
    PLAN_STEP_STARTED,
)
from soothe_sdk.core.verbosity import VerbosityTier
from soothe_sdk.ux import classify_event_to_tier
from soothe_sdk.ux.loop_stream import LOOP_ASSISTANT_OUTPUT_PHASES, assistant_output_phase
from soothe_sdk.ux.task_namespace import (
    enqueue_task_spawn,
    maybe_bind_namespace,
    resolve_task_scope_for_namespace,
)

from soothe_cli.shared.core.presentation_engine import PresentationEngine
from soothe_cli.shared.core.processor_state import ProcessorState
from soothe_cli.shared.events.display_policy import DisplayPolicy
from soothe_cli.shared.events.tui_trace_log import log_tui_trace
from soothe_cli.shared.tools.message_processing import (
    accumulate_tool_call_chunks,
    extract_tool_args_dict,
    extract_tool_brief,
    finalize_pending_tool_call,
    normalize_tool_calls_list,
    strip_internal_tags,
    tool_calls_have_any_arg_dict,
    try_parse_pending_tool_call_args,
)
from soothe_cli.shared.tools.rendering import update_name_map_from_tool_calls
from soothe_cli.shared.tools.tool_card_payload import (
    extract_tool_result_card_payload,
    infer_tool_output_suggests_error,
)

if TYPE_CHECKING:
    from soothe_sdk.client.schemas import Plan

    from soothe_cli.shared.core.renderer_protocol import RendererProtocol

logger = logging.getLogger(__name__)

_MSG_PAIR_LEN = 2


def _loop_msg_accum_event_key(phase: str) -> str:
    """Accumulator event-type key for loop-tagged assistant streams (RFC-614)."""
    return f"_soothe.internal.loop_messages.{phase}"


class EventProcessor:
    """Unified daemon event processor with pluggable rendering.

    Handles all event routing, state management, and filtering.
    Delegates display to RendererProtocol implementation.

    Display policy is fixed to the former **normal** client mode (IG-343).
    When ``headless_output`` is True, RFC-614 loop-tagged main-graph assistant
    text is emitted; tools and progress are not rendered.

    Usage:
        processor = EventProcessor(renderer)

        # In event loop:
        processor.process_event(event)
    """

    def __init__(
        self,
        renderer: RendererProtocol,
        *,
        presentation_engine: PresentationEngine | None = None,
        tui_debug: bool = False,
        headless_output: bool = False,
    ) -> None:
        """Initialize processor with renderer.

        Args:
            renderer: Callback interface for display.
            presentation_engine: Shared engine; if omitted, uses renderer's
                ``presentation_engine`` when present, else a new instance.
            tui_debug: When True, emit INFO logs on logger ``soothe.ux.tui.trace`` (IG-129).
            headless_output: Headless CLI: loop-tagged main answers only, no tool/progress UI.
        """
        self._renderer = renderer
        self._headless_output = headless_output
        self._tui_debug = tui_debug

        rebind = getattr(renderer, "_rebind_presentation", None)
        shared_from_renderer = getattr(renderer, "presentation_engine", None)
        if presentation_engine is not None:
            self._presentation = presentation_engine
            # Avoid rebuilding StreamDisplayPipeline when renderer already uses this engine.
            if callable(rebind) and shared_from_renderer is not presentation_engine:
                rebind(presentation_engine)
        elif isinstance(shared_from_renderer, PresentationEngine):
            self._presentation = shared_from_renderer
        else:
            self._presentation = PresentationEngine()

        self._policy = DisplayPolicy()
        self._state = ProcessorState()

    @property
    def current_plan(self) -> Plan | None:
        """Read-only access to current plan for renderers."""
        return self._state.current_plan

    @property
    def loop_id(self) -> str:
        """Active AgentLoop id from daemon status frames."""
        return self._state.loop_id

    @property
    def state(self) -> ProcessorState:
        """Read-only access to processor state."""
        return self._state

    def _maybe_bind_task_namespace(self, namespace: tuple[str, ...]) -> None:
        """Bind LangGraph subgraph ``namespace`` to the next queued Task spawn (IG-334)."""
        maybe_bind_namespace(
            self._state.namespace_task_bindings,
            self._state.task_spawn_queue,
            namespace,
        )

    def _resolve_task_scope(self, namespace: tuple[str, ...]) -> tuple[str, str] | None:
        """Return ``(task_tool_call_id, subagent_type)`` for this stream namespace."""
        return resolve_task_scope_for_namespace(self._state.namespace_task_bindings, namespace)

    def _enqueue_task_spawn_if_needed(
        self, name: str, args: dict[str, Any], tool_call_id: str, *, is_main: bool
    ) -> None:
        """Record main-graph ``task`` tool calls so subgraph streams can resolve labels."""
        enqueue_task_spawn(
            self._state.task_spawn_queue,
            tool_name=name,
            args=args,
            tool_call_id=tool_call_id,
            is_main=is_main,
        )

    def _emit_tool_call_for_renderer(
        self,
        name: str,
        args: dict[str, Any],
        tool_call_id: str,
        *,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        self._enqueue_task_spawn_if_needed(name, args, tool_call_id, is_main=is_main)
        scope = None if is_main else self._resolve_task_scope(namespace)
        self._renderer.on_tool_call(name, args, tool_call_id, is_main=is_main, task_scope=scope)

    def _emit_tool_result_for_renderer(
        self,
        name: str,
        result: str,
        tool_call_id: str,
        *,
        is_error: bool,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        scope = None if is_main else self._resolve_task_scope(namespace)
        self._renderer.on_tool_result(
            name, result, tool_call_id, is_error=is_error, is_main=is_main, task_scope=scope
        )

    def _collect_ai_message_plain_text(self, msg: AIMessage) -> str:
        """Concatenate user-visible text from an AIMessage / AIMessageChunk."""
        parts: list[str] = []
        blocks = getattr(msg, "content_blocks", None) or []
        if blocks:
            for block in blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    t = block.get("text", "")
                    if isinstance(t, str):
                        parts.append(t)
        elif isinstance(msg.content, str):
            parts.append(msg.content)
        elif isinstance(msg.content, list):
            for item in msg.content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict) and item.get("type") == "text":
                    parts.append(str(item.get("text", "")))
        return "".join(parts)

    def _collect_ai_dict_plain_text(self, msg: dict[str, Any]) -> str:
        """Concatenate user-visible text from a serialized AI message dict."""
        parts: list[str] = []
        blocks = msg.get("content_blocks") or []
        if isinstance(blocks, list) and blocks:
            for block in blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    t = block.get("text", "")
                    if isinstance(t, str):
                        parts.append(t)
            return "".join(parts)
        content = msg.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict) and item.get("type") == "text":
                    parts.append(str(item.get("text", "")))
        return "".join(parts)

    def _suppress_main_assistant_body_for_headless_obj(
        self, msg: AIMessage, *, is_main: bool
    ) -> bool:
        """Headless stdout: only RFC-614 loop-tagged finals (IG-343 / IG-345).

        Suppresses unphased execute-wave narration on the main graph; ``goal_completion``,
        ``chitchat``, etc. are routed via ``assistant_output_phase`` before this path.

        Subgraph streams without RFC-614 phases are skipped in ``_handle_ai_message`` before
        this runs; loop-tagged subgraph finals use ``_dispatch_loop_tagged_assistant_text``.
        """
        if not (self._headless_output and is_main):
            return False
        lo = assistant_output_phase(msg)
        return lo not in LOOP_ASSISTANT_OUTPUT_PHASES

    def _suppress_main_assistant_body_for_headless_dict(
        self, msg: dict[str, Any], *, is_main: bool, ai_wire: bool
    ) -> bool:
        """See :meth:`_suppress_main_assistant_body_for_headless_obj`."""
        del ai_wire
        if not (self._headless_output and is_main):
            return False
        lo = assistant_output_phase(msg)
        return lo not in LOOP_ASSISTANT_OUTPUT_PHASES

    def _dispatch_loop_tagged_assistant_text(
        self,
        raw_text: str,
        *,
        namespace: tuple[str, ...],
        is_chunk: bool,
        phase: str,
    ) -> None:
        """Display logic for RFC-614 loop-tagged assistant messages (IG-317 / IG-343)."""
        if phase not in LOOP_ASSISTANT_OUTPUT_PHASES:
            return
        if not self._presentation.tier_visible(VerbosityTier.QUIET):
            return

        accum_key = _loop_msg_accum_event_key(phase)
        streaming_config = self._get_effective_streaming_config()

        if is_chunk:
            if not streaming_config.get("enabled", True):
                return
            if streaming_config.get("mode") == "batch":
                return
            if not streaming_config.get("synthesis_streaming", True):
                return
            display_text = self._state.streaming_accumulator.accumulate(
                accum_key,
                raw_text,
                namespace=namespace,
                is_chunk=True,
            )
            if display_text:
                cleaned = self._clean_assistant_text(display_text, is_streaming=True)
                if cleaned:
                    self._emit_assistant_text(
                        cleaned,
                        is_main=True,
                        is_streaming=True,
                    )
            return

        if (phase, namespace) in self._state.final_loop_output_emitted:
            return

        if streaming_config.get("mode") == "streaming":
            stream_state = self._state.streaming_accumulator.streams.get((accum_key, namespace))
            if stream_state and stream_state.accumulated_text.strip():
                pending_tail = (getattr(stream_state, "pending_fragment", "") or "").strip()
                if pending_tail:
                    cleaned_tail = self._clean_assistant_text(
                        pending_tail,
                        is_streaming=True,
                    )
                    if cleaned_tail:
                        self._emit_assistant_text(
                            cleaned_tail,
                            is_main=True,
                            is_streaming=True,
                        )
                    stream_state.pending_fragment = ""
                self._presentation.mark_final_answer_locked()
                self._state.streaming_accumulator.finalize_stream(
                    accum_key,
                    namespace=namespace,
                )
                self._state.final_loop_output_emitted.add((phase, namespace))
                return

        stream_like = streaming_config.get("mode") == "streaming"
        cleaned = self._clean_assistant_text(raw_text, is_streaming=stream_like)
        if cleaned:
            self._emit_assistant_text(
                cleaned,
                is_main=True,
                is_streaming=not stream_like,
            )
        # Do not lock after each non-chunk segment: ``mark_final_answer_locked`` would
        # block the next incremental emit via ``_emit_assistant_text``. Chunk finalize
        # path above still locks after a streamed segment completes.

    def _emit_assistant_text(
        self,
        text: str,
        *,
        is_main: bool,
        is_streaming: bool,
        namespace: tuple[str, ...] = (),
    ) -> None:
        """Forward assistant text unless a custom final response already locked the stream."""
        if is_main and self._presentation.final_answer_locked:
            return
        log_tui_trace(
            tui_debug=self._tui_debug,
            event="processor.emit_assistant_text",
            is_main=is_main,
            is_streaming=is_streaming,
            chars=len(text),
        )
        task_scope = None if is_main else self._resolve_task_scope(namespace)
        self._renderer.on_assistant_text(
            text,
            is_main=is_main,
            is_streaming=is_streaming,
            task_scope=task_scope,
        )

    def process_event(self, event: dict[str, Any]) -> None:
        """Main entry point - routes event to appropriate handler.

        Args:
            event: Daemon event dictionary with 'type' key.
        """
        event_type = event.get("type", "")
        log_tui_trace(
            tui_debug=self._tui_debug,
            event="processor.process_event",
            event_type=event_type,
        )

        if event_type == "status":
            self._handle_status(event)
        elif event_type == "event":
            self._handle_stream_event(event)
        elif event_type == "error":
            self._handle_error_event(event)
        elif event_type == "command_response":
            self._handle_command_response(event)
        elif event_type == "clear":
            self._handle_clear_event(event)

    def _handle_command_response(self, event: dict[str, Any]) -> None:
        """Handle command response from daemon (RFC-404)."""
        command = event.get("command")
        data = event.get("data")
        error = event.get("error")

        if error:
            self._renderer.on_error(error)
            return

        # Find rendering handler from registry
        from soothe_cli.shared.commands.command_router import find_command_by_daemon_command

        entry = find_command_by_daemon_command(command)
        if entry and entry.get("handler") and data:
            handler = entry["handler"]
            handler(self._renderer.console, data)
        else:
            # Default: pretty print JSON
            import json

            from rich.panel import Panel

            self._renderer.console.print(
                Panel(json.dumps(data, indent=2, default=str), title=command, border_style="cyan")
            )

    def _handle_clear_event(self, event: dict[str, Any]) -> None:
        """Handle clear event from daemon."""
        # Clear local UI state if renderer supports it
        if hasattr(self._renderer, "clear"):
            self._renderer.clear()

    def _handle_status(self, event: dict[str, Any]) -> None:
        """Process status changes, update loop_id, call on_status_change."""
        state_str = event.get("state", "unknown")
        lid_raw = event.get("loop_id")
        previous_loop_id = self._state.loop_id
        # Keep existing loop_id when the daemon omits loop_id on the frame (e.g. minimal status).
        lid = previous_loop_id if lid_raw in (None, "") else str(lid_raw)
        self._state.loop_id = lid
        log_tui_trace(
            tui_debug=self._tui_debug,
            event="processor.status",
            state=state_str,
            loop_id=lid,
        )

        # Clear session state on loop change
        if lid and lid != previous_loop_id:
            self._state.clear_session()
            self._presentation.reset_session()

        self._renderer.on_status_change(state_str)

        # On turn end, finalize streaming and call hook
        if state_str in {"idle", "stopped"}:
            self._state.reset_turn()
            self._presentation.reset_turn()
            self._renderer.on_turn_end()

    def _handle_stream_event(self, event: dict[str, Any]) -> None:
        """Route to messages or custom event handlers."""
        mode = event.get("mode", "")
        namespace = tuple(event.get("namespace", []))
        data = event.get("data")
        log_tui_trace(
            tui_debug=self._tui_debug,
            event="processor.stream_event",
            mode=mode,
            namespace=namespace,
        )

        if mode == "messages":
            self._handle_messages(data, namespace)
        elif mode == "custom" and isinstance(data, dict):
            self._handle_custom_event(data, namespace)

    def _handle_error_event(self, event: dict[str, Any]) -> None:
        """Handle error events."""
        error = event.get("message", event.get("error", "Unknown error"))
        context = event.get("code")
        self._renderer.on_error(error, context=context)

    def _handle_messages(
        self,
        data: Any,
        namespace: tuple[str, ...],
    ) -> None:
        """Process AIMessage/ToolMessage with deduplication and streaming."""
        if isinstance(data, (list, tuple)) and len(data) == _MSG_PAIR_LEN:
            msg, metadata = data
        elif isinstance(data, dict):
            return
        else:
            return

        # Skip summarization messages
        if metadata and isinstance(metadata, dict) and metadata.get("lc_source") == "summarization":
            return

        self._maybe_bind_task_namespace(namespace)
        is_main = not namespace
        msg_kind: str
        if isinstance(msg, AIMessage):
            msg_kind = "AIMessageChunk" if isinstance(msg, AIMessageChunk) else "AIMessage"
        elif isinstance(msg, ToolMessage):
            msg_kind = "ToolMessage"
        elif isinstance(msg, dict):
            msg_kind = str(msg.get("type", "dict"))
        else:
            msg_kind = type(msg).__name__
        log_tui_trace(
            tui_debug=self._tui_debug,
            event="processor.messages",
            msg_kind=msg_kind,
            is_main=is_main,
        )

        if isinstance(msg, AIMessage):
            self._handle_ai_message(msg, is_main=is_main, namespace=namespace)
        elif isinstance(msg, ToolMessage):
            self._handle_tool_message(msg, is_main=is_main, namespace=namespace)
        elif isinstance(msg, dict):
            self._handle_dict_message(msg, is_main=is_main, namespace=namespace)

    def _handle_ai_message(
        self,
        msg: AIMessage,
        *,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        """Handle AIMessage objects."""
        # Headless (IG-343): drop subgraph chatter unless RFC-614 loop-tagged output,
        # which is emitted via _dispatch_loop_tagged_assistant_text as main-visible text.
        if self._headless_output and not is_main:
            lo = assistant_output_phase(msg)
            if lo not in LOOP_ASSISTANT_OUTPUT_PHASES:
                return

        # Update name_map from tool calls
        update_name_map_from_tool_calls(msg, self._state.name_map)

        # Deduplication (complete messages only, chunks share IDs)
        msg_id = msg.id or ""
        is_chunk = isinstance(msg, AIMessageChunk)
        if not is_chunk:
            if msg_id in self._state.seen_message_ids:
                return
            self._state.seen_message_ids.add(msg_id)

        raw_tcs = getattr(msg, "tool_calls", None) or []
        tcs = normalize_tool_calls_list(raw_tcs)
        has_tc_args = tool_calls_have_any_arg_dict(raw_tcs)

        # Accumulate streaming tool args (IG-053)
        tool_call_chunks = getattr(msg, "tool_call_chunks", None) or []
        accumulate_tool_call_chunks(
            self._state.pending_tool_calls,
            tool_call_chunks,
            is_main=is_main,
        )

        # Emit pending tool calls with complete args
        self._emit_pending_tool_calls(namespace)

        loop_phase = assistant_output_phase(msg)
        if (
            loop_phase
            and loop_phase in LOOP_ASSISTANT_OUTPUT_PHASES
            and (is_main or self._headless_output)
        ):
            txt = self._collect_ai_message_plain_text(msg)
            self._dispatch_loop_tagged_assistant_text(
                txt, namespace=namespace, is_chunk=is_chunk, phase=loop_phase
            )
            return

        # Process content blocks
        tool_call_emitted_from_blocks = False
        if hasattr(msg, "content_blocks") and msg.content_blocks:
            for block in msg.content_blocks:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text = block.get("text", "")
                    # Suppress during internal context (research internal LLM responses)
                    if self._state.internal_context_active and not is_main:
                        continue
                    if self._suppress_main_assistant_body_for_headless_obj(msg, is_main=is_main):
                        continue
                    # Always pass to renderer for accumulation, let renderer decide display
                    if text:
                        cleaned = self._clean_assistant_text(text, is_streaming=is_chunk)
                        if cleaned:
                            self._emit_assistant_text(
                                cleaned,
                                is_main=is_main,
                                is_streaming=is_chunk,
                                namespace=namespace,
                            )
                elif btype in ("tool_call", "tool_call_chunk"):
                    if has_tc_args:
                        continue
                    name = block.get("name", "")
                    if name and self._presentation.tier_visible(VerbosityTier.NORMAL):
                        coerced = extract_tool_args_dict(block)
                        # Skip if no args - will be emitted when tool result arrives
                        if not coerced:
                            continue
                        tool_call_id = block.get("id", "")
                        self._emit_tool_call_for_renderer(
                            name,
                            coerced,
                            tool_call_id,
                            is_main=is_main,
                            namespace=namespace,
                        )
                        tool_call_emitted_from_blocks = True
                        # Log tool invocation for audit trail
                        logger.info(
                            "tool_call name=%s id=%s args=%s is_main=%s",
                            name,
                            tool_call_id,
                            preview_first(str(coerced), 200) if coerced else "{}",
                            is_main,
                        )
        elif isinstance(msg.content, str) and msg.content:
            if self._suppress_main_assistant_body_for_headless_obj(msg, is_main=is_main):
                pass
            elif not (self._state.internal_context_active and not is_main):
                cleaned = self._clean_assistant_text(msg.content, is_streaming=is_chunk)
                if cleaned:
                    self._emit_assistant_text(
                        cleaned,
                        is_main=is_main,
                        is_streaming=is_chunk,
                        namespace=namespace,
                    )

        # Handle tool_calls attribute
        # IMPORTANT: Only emit if we have non-empty args. Otherwise, let the accumulation
        # from tool_call_chunks happen and emit when tool result arrives.
        if tcs:
            for tc in tcs:
                name = tc.get("name", "")
                if not name or not self._presentation.tier_visible(VerbosityTier.NORMAL):
                    continue
                tc_args = extract_tool_args_dict(tc)

                # Skip chunks with empty args - they'll come from tool_call_chunks
                if is_chunk and not tc_args and not has_tc_args:
                    continue

                # Skip if args are empty - will be emitted via finalize_pending_tool_call
                if not tc_args and not tool_call_emitted_from_blocks:
                    continue

                if has_tc_args:
                    tool_call_id = tc.get("id", "")
                    # Deduplicate tool calls by ID
                    if tool_call_id and tool_call_id in self._state.emitted_tool_call_ids:
                        continue
                    if tool_call_id:
                        self._state.emitted_tool_call_ids.add(tool_call_id)
                    self._emit_tool_call_for_renderer(
                        name,
                        tc_args,
                        tool_call_id,
                        is_main=is_main,
                        namespace=namespace,
                    )
                    # Log tool invocation for audit trail
                    logger.info(
                        "tool_call name=%s id=%s args=%s is_main=%s",
                        name,
                        tool_call_id,
                        preview_first(str(tc_args), 200) if tc_args else "{}",
                        is_main,
                    )

    def _handle_tool_message(
        self,
        msg: ToolMessage,
        *,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        """Handle ToolMessage objects."""
        if self._headless_output:
            return
        if not self._presentation.tier_visible(VerbosityTier.NORMAL):
            return

        tool_name = getattr(msg, "name", "tool")
        tool_call_id = getattr(msg, "tool_call_id", None) or ""

        # Deduplicate tool results by ID
        if tool_call_id and tool_call_id in self._state.emitted_tool_result_ids:
            return
        if tool_call_id:
            self._state.emitted_tool_result_ids.add(tool_call_id)

        content = msg.content if isinstance(msg.content, str) else str(msg.content)
        brief = extract_tool_brief(tool_name, content)

        # Finalize pending tool call if needed (IG-053)
        parsed_args, pending, needs_emit, raw_args_str = finalize_pending_tool_call(
            self._state.pending_tool_calls,
            tool_call_id,
        )
        if needs_emit:
            # Pass raw args for display fallback when parsed args unavailable
            args_to_display = parsed_args or ({"_raw": raw_args_str} if raw_args_str else {})
            pending_is_main = pending.get("is_main", is_main)
            emit_ns = () if pending_is_main else namespace
            self._emit_tool_call_for_renderer(
                pending.get("name") or tool_name,
                args_to_display,
                tool_call_id,
                is_main=pending_is_main,
                namespace=emit_ns,
            )

        payload = extract_tool_result_card_payload(msg)
        is_error = (
            payload.is_error
            if payload is not None
            else infer_tool_output_suggests_error(content, tool_name)
        )

        # Log tool result for audit trail
        logger.info(
            "tool_result name=%s id=%s status=%s result=%s is_main=%s",
            tool_name,
            tool_call_id,
            "error" if is_error else "success",
            preview_first(brief, 300) if brief else "",
            is_main,
        )

        self._emit_tool_result_for_renderer(
            tool_name,
            brief,
            tool_call_id,
            is_error=is_error,
            is_main=is_main,
            namespace=namespace,
        )

    def _handle_dict_message(
        self,
        msg: dict[str, Any],
        *,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        """Handle deserialized dict messages (after JSON transport)."""
        if self._headless_output and not is_main:
            lo = assistant_output_phase(msg)
            if lo not in LOOP_ASSISTANT_OUTPUT_PHASES:
                return

        msg_type = msg.get("type", "")
        msg_id = msg.get("id", "")
        is_chunk = msg_type == "AIMessageChunk"

        # Handle ToolMessage dicts (serialized via model_dump)
        if msg_type in ("ToolMessage", "tool"):
            self._handle_tool_message_dict(msg, is_main=is_main, namespace=namespace)
            return

        if not is_chunk:
            if msg_id and msg_id in self._state.seen_message_ids:
                return
            if msg_id:
                self._state.seen_message_ids.add(msg_id)

        ai_wire = msg_type in ("ai", "AIMessage", "AIMessageChunk") or (
            isinstance(msg_type, str) and msg_type.endswith("AIMessageChunk")
        )
        loop_phase = assistant_output_phase(msg)
        if (
            loop_phase
            and loop_phase in LOOP_ASSISTANT_OUTPUT_PHASES
            and ai_wire
            and (is_main or self._headless_output)
        ):
            txt = self._collect_ai_dict_plain_text(msg)
            self._dispatch_loop_tagged_assistant_text(
                txt, namespace=namespace, is_chunk=is_chunk, phase=loop_phase
            )
            return

        # Accumulate streaming tool args from tool_call_chunks (IG-053)
        tool_call_chunks = msg.get("tool_call_chunks", [])
        if isinstance(tool_call_chunks, list) and tool_call_chunks:
            accumulate_tool_call_chunks(
                self._state.pending_tool_calls,
                tool_call_chunks,
                is_main=is_main,
            )

        self._emit_pending_tool_calls(namespace)

        # Process content blocks or content string
        blocks = msg.get("content_blocks") or []
        if not blocks:
            content = msg.get("content", "")
            if isinstance(content, list):
                blocks = content
            elif isinstance(content, str) and content:
                if self._suppress_main_assistant_body_for_headless_dict(
                    msg, is_main=is_main, ai_wire=ai_wire
                ):
                    pass
                else:
                    cleaned = self._clean_assistant_text(content, is_streaming=is_chunk)
                    if cleaned:
                        self._emit_assistant_text(
                            cleaned,
                            is_main=is_main,
                            is_streaming=is_chunk,
                            namespace=namespace,
                        )

        for block in blocks:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text = block.get("text", "")
                # Always pass to renderer for accumulation, let renderer decide display
                if text:
                    if self._suppress_main_assistant_body_for_headless_dict(
                        msg, is_main=is_main, ai_wire=ai_wire
                    ):
                        continue
                    cleaned = self._clean_assistant_text(text, is_streaming=is_chunk)
                    if cleaned:
                        self._emit_assistant_text(
                            cleaned,
                            is_main=is_main,
                            is_streaming=is_chunk,
                            namespace=namespace,
                        )
            elif btype in ("tool_call_chunk", "tool_call"):
                name = block.get("name", "")
                if name and self._presentation.tier_visible(VerbosityTier.NORMAL):
                    args = extract_tool_args_dict(block)
                    tool_call_id = block.get("id", "")
                    # Deduplicate tool calls
                    if tool_call_id and tool_call_id in self._state.emitted_tool_call_ids:
                        continue
                    if tool_call_id:
                        self._state.emitted_tool_call_ids.add(tool_call_id)
                    self._emit_tool_call_for_renderer(
                        name,
                        args,
                        tool_call_id,
                        is_main=is_main,
                        namespace=namespace,
                    )
                    # Log tool invocation for audit trail
                    logger.info(
                        "tool_call name=%s id=%s args=%s is_main=%s",
                        name,
                        tool_call_id,
                        preview_first(str(args), 200) if args else "{}",
                        is_main,
                    )

        # Handle tool_calls from serialized AIMessage (model_dump produces tool_calls not tool_call_chunks)
        # IMPORTANT: Only emit if we have non-empty args. Otherwise, let the accumulation
        # from tool_call_chunks happen and emit when tool result arrives.
        tool_calls = msg.get("tool_calls", [])
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                if isinstance(tc, dict):
                    name = tc.get("name", "")
                    if name and self._presentation.tier_visible(VerbosityTier.NORMAL):
                        args = extract_tool_args_dict(tc)
                        tool_call_id = tc.get("id", "")

                        # Skip emitting if args are empty - they'll come from tool_call_chunks
                        # and will be emitted when the tool result arrives (via finalize_pending_tool_call)
                        if not args:
                            continue

                        # Deduplicate tool calls
                        if tool_call_id and tool_call_id in self._state.emitted_tool_call_ids:
                            continue
                        if tool_call_id:
                            self._state.emitted_tool_call_ids.add(tool_call_id)
                        self._emit_tool_call_for_renderer(
                            name,
                            args,
                            tool_call_id,
                            is_main=is_main,
                            namespace=namespace,
                        )
                        # Log tool invocation for audit trail
                        logger.info(
                            "tool_call name=%s id=%s args=%s is_main=%s",
                            name,
                            tool_call_id,
                            preview_first(str(args), 200) if args else "{}",
                            is_main,
                        )

    def _handle_tool_message_dict(
        self,
        msg: dict[str, Any],
        *,
        is_main: bool,
        namespace: tuple[str, ...],
    ) -> None:
        """Handle ToolMessage dict (serialized via model_dump).

        Args:
            msg: ToolMessage serialized as dict.
            is_main: True if from main agent.
            namespace: LangGraph stream namespace for subgraph correlation.
        """
        if not self._presentation.tier_visible(VerbosityTier.NORMAL):
            return

        tool_name = msg.get("name", "tool")
        tool_call_id = msg.get("tool_call_id", "")

        # Deduplicate tool results by ID
        if tool_call_id and tool_call_id in self._state.emitted_tool_result_ids:
            return
        if tool_call_id:
            self._state.emitted_tool_result_ids.add(tool_call_id)

        content = msg.get("content", "")
        if not isinstance(content, str):
            content = str(content)

        brief = extract_tool_brief(tool_name, content)

        # Finalize pending tool call if needed (IG-053)
        parsed_args, pending, needs_emit, raw_args_str = finalize_pending_tool_call(
            self._state.pending_tool_calls,
            tool_call_id,
        )
        if needs_emit:
            # Pass raw args for display fallback when parsed args unavailable
            args_to_display = parsed_args or ({"_raw": raw_args_str} if raw_args_str else {})
            pending_is_main = pending.get("is_main", is_main)
            emit_ns = () if pending_is_main else namespace
            self._emit_tool_call_for_renderer(
                pending.get("name") or tool_name,
                args_to_display,
                tool_call_id,
                is_main=pending_is_main,
                namespace=emit_ns,
            )

        payload = extract_tool_result_card_payload(msg)
        is_error = (
            payload.is_error
            if payload is not None
            else infer_tool_output_suggests_error(content, tool_name)
        )

        # Log tool result for audit trail
        logger.info(
            "tool_result name=%s id=%s status=%s result=%s is_main=%s",
            tool_name,
            tool_call_id,
            "error" if is_error else "success",
            preview_first(brief, 300) if brief else "",
            is_main,
        )

        self._emit_tool_result_for_renderer(
            tool_name,
            brief,
            tool_call_id,
            is_error=is_error,
            is_main=is_main,
            namespace=namespace,
        )

    def _emit_pending_tool_calls(self, namespace: tuple[str, ...]) -> None:
        """Emit pending tool calls that have complete JSON args."""
        if self._headless_output:
            return
        for tc_id, pending in list(self._state.pending_tool_calls.items()):
            if pending["emitted"]:
                continue
            # Deduplicate
            if tc_id in self._state.emitted_tool_call_ids:
                pending["emitted"] = True
                continue
            parsed_args = try_parse_pending_tool_call_args(pending)
            if parsed_args is not None and self._presentation.tier_visible(VerbosityTier.NORMAL):
                self._state.emitted_tool_call_ids.add(tc_id)
                pending_is_main = pending.get("is_main", not namespace)
                emit_ns = () if pending_is_main else namespace
                self._emit_tool_call_for_renderer(
                    pending["name"],
                    parsed_args,
                    tc_id,
                    is_main=pending_is_main,
                    namespace=emit_ns,
                )
                pending["emitted"] = True

    def _handle_custom_event(
        self,
        data: dict[str, Any],
        namespace: tuple[str, ...],
    ) -> None:
        """Process protocol/progress events."""
        etype = data.get("type", "")

        if self._headless_output:
            category = classify_event_to_tier(etype, namespace)
            if category == VerbosityTier.QUIET and "error" in etype:
                error_text = data.get("error", data.get("message", str(etype)))
                self._renderer.on_error(error_text)
            return

        # Tool events are now visible at NORMAL verbosity (RFC-0020 CLI Stream Display Pipeline)
        # They are processed through on_progress_event -> StreamDisplayPipeline

        category = classify_event_to_tier(etype, namespace)

        # Update plan state and call specific hooks
        if etype == PLAN_CREATED:
            self._handle_plan_created(data)
        elif etype == PLAN_STEP_STARTED:
            self._handle_plan_step_started(data)
        elif etype == PLAN_STEP_COMPLETED:
            self._handle_plan_step_completed(data)
        elif category == VerbosityTier.QUIET and "error" in etype:
            error_text = data.get("error", data.get("message", str(etype)))
            self._renderer.on_error(error_text)
        elif self._presentation.tier_visible(category):
            task_scope = None if not namespace else self._resolve_task_scope(namespace)
            self._renderer.on_progress_event(
                etype, data, namespace=namespace, task_scope=task_scope
            )

    def _handle_plan_created(self, data: dict[str, Any]) -> None:
        """Handle plan creation event."""
        from soothe_sdk.client.schemas import Plan, PlanStep

        steps = [
            PlanStep(
                step_id=str(s.get("step_id") or s.get("id") or i),
                description=str(s.get("description", "")),
                status=str(s.get("status", "pending")),
            )
            for i, s in enumerate(data.get("steps", []))
        ]
        plan = Plan(
            plan_id=str(data.get("plan_id") or "local-plan"),
            goal=str(data.get("goal", "")),
            steps=steps,
            status=str(data.get("plan_status", data.get("status", "created"))),
        )
        self._state.current_plan = plan
        self._renderer.on_plan_created(plan)

    def _handle_plan_step_started(self, data: dict[str, Any]) -> None:
        """Handle plan step started event."""
        step_id = data.get("step_id", "")
        description = data.get("description", "")

        if self._state.current_plan:
            for step in self._state.current_plan.steps:
                if step.step_id == step_id:
                    step.status = "in_progress"
                    break

        self._renderer.on_plan_step_started(step_id, description)

    def _handle_plan_step_completed(self, data: dict[str, Any]) -> None:
        """Handle plan step completed event."""
        step_id = data.get("step_id", "")
        success = data.get("success", False)
        duration_ms = data.get("duration_ms", 0)

        if self._state.current_plan:
            for step in self._state.current_plan.steps:
                if step.step_id == step_id:
                    step.status = "completed" if success else "failed"
                    break

        self._renderer.on_plan_step_completed(step_id, success, duration_ms)

    def _clean_assistant_text(self, text: str, *, is_streaming: bool = False) -> str:
        """Apply shared response cleaning for user-facing assistant text.

        Args:
            text: Text to clean.
            is_streaming: If True, preserve boundary whitespace for proper
                streaming chunk concatenation.
        """
        return self._policy.filter_content(
            strip_internal_tags(text),
            preserve_boundary_whitespace=is_streaming,
        )

    def _get_effective_streaming_config(self) -> Any:
        """Get effective streaming config with defaults (RFC-614).

        Since EventProcessor doesn't have direct access to CLI config,
        we use sensible defaults based on initialization parameters.

        Returns:
            Dict with enabled, mode, and synthesis_streaming fields.
        """
        # Use defaults - streaming is enabled by default per RFC-614
        # Always use streaming mode
        config = {
            "enabled": True,
            "mode": "streaming",
            "synthesis_streaming": True,
        }

        return config
