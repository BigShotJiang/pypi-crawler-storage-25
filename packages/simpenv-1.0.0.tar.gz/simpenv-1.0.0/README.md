
# simpenv

**simpenv** is a minimalist Python library for accessing environment variables. It lets you read variables as attributes or via function calls – no more repetitive `os.getenv()`.

## Features

- Two ways to access: `env.VAR` or `env("VAR")`
- Optional default values when a variable is missing
- Automatically loads `.env` file from current directory (if exists)
- Lightweight, zero external dependencies

## Installation

```bash
pip install simpenv
```

## Usage

Just `import env` – no need for `from simpenv import env`.

### 1. Import

```python
import env
```

The `env` object is ready to use immediately.

### 2. Access environment variables

#### As an attribute

```python
# Assume DATABASE_URL is set in the environment or .env file
db_url = env.DATABASE_URL

# Returns None if the variable does not exist
api_key = env.API_KEY
```

#### As a function call

```python
db_url = env("DATABASE_URL")
api_key = env("API_KEY")
```

### 3. Provide a default value

Use the `default` parameter with the function form to avoid `None` values.

```python
port = env("PORT", default=8080)
debug = env("DEBUG", default=False)
```

> **Note:** The attribute style (`env.VAR`) does not support defaults – use the function style when you need a fallback value.

### 4. Using a `.env` file

Create a `.env` file in your project directory:

```env
DATABASE_URL=postgresql://user:pass@localhost/db
PORT=3000
API_KEY=secret123
```

Then run your Python code:

```python
import env

print(env.DATABASE_URL)        # postgresql://user:pass@localhost/db
print(env("PORT"))             # 3000
print(env("API_KEY"))          # secret123
print(env("NON_EXISTENT", default="no-value"))  # no-value
```

Environment variables set in your shell take precedence over those in `.env`.

### 5. Complete example

Set an environment variable in your shell:

```bash
export DATABASE_URL="postgresql://user:pass@localhost/db"
export PORT=3000
```

Then run your Python code:

```python
import env

print(env.DATABASE_URL)        # postgresql://user:pass@localhost/db
print(env("PORT"))             # 3000
print(env("API_KEY"))          # None
print(env("API_KEY", default="no-key"))  # no-key
```

## License
MIT