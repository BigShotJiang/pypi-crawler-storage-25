import os

def _load_dotenv():
    """Load environment variables from .env file in current working directory."""
    dotenv_path = os.path.join(os.getcwd(), '.env')
    if not os.path.exists(dotenv_path):
        return
    with open(dotenv_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip()
                # Remove surrounding quotes if present
                if value and value[0] in ('"', "'") and value[-1] == value[0]:
                    value = value[1:-1]
                # Only set if not already set by system environment
                os.environ.setdefault(key, value)

# Load .env file once when module is imported
_load_dotenv()

class _Env:
    """
    Environment variable accessor.
    Usage:
        import env
        value = env.VARIABLE_NAME
        value = env('VARIABLE_NAME', default='fallback')
    """
    def __getattr__(self, name):
        """Access as attribute: env.VAR -> returns value or None."""
        return os.getenv(name)

    def __call__(self, key, default=None):
        """Access as function: env('VAR', default=...) -> returns value or default."""
        return os.getenv(key, default)

# Singleton instance
env = _Env()