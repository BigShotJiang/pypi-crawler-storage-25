# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

from typing import Optional

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.resources.inline.api_keys import ApiKey
from airs_api_mgmt.resources.inline.ai_sec_profiles import AISecProfile
from airs_api_mgmt.resources.inline.dlp_profiles import DlpProfile
from airs_api_mgmt.resources.inline.deployment_profiles import DeploymentProfile
from airs_api_mgmt.resources.inline.oauth import OAuth
from airs_api_mgmt.resources.inline.customer_app import CustomerApp
from airs_api_mgmt.resources.inline.custom_topic import CustomTopic
from .utils import get_logger

log = get_logger(__name__)


class MgmtClient:
    """
    Main client for AI Security Management API.

    This class provides access to all API resources. Configuration is managed through
    the `config` attribute (ClientConfig instance).

    Attributes:
        config (ClientConfig): Configuration container with authentication and settings
            - config.client_id: Service account client ID for authentication
            - config.client_secret: Client secret for authentication
            - config.base_url: Management API base URL
            - config.token_base_url: OAuth2 token endpoint URL
            - config.num_retries: Maximum number of retries for API calls
            - config.token_expiry: Token expiration timestamp

    Resource Properties:
        api_keys: API key management operations (create, delete, regenerate)
        ai_sec_profiles: AI security profile management operations
        dlp_profiles: DLP profile management operations
        deployment_profiles: Deployment profile management operations
        oauth: OAuth token management operations
        customer_apps: Customer application management operations
        custom_topics: Custom topic management operations

    Examples:
        # Option 1: Using context manager (recommended)
        with MgmtClient(
            client_id="your_client_id",
            client_secret="your_secret"
        ) as client:
            new_key = client.api_keys.create_new_api_key(
                api_key_name="my-key",
                cust_app="my-app",
                auth_code="auth123",
                created_by="user@example.com",
                rotation_time_interval=30,
                rotation_time_unit="days",
                cust_env="production",
                cust_cloud_provider="AWS"
            )

        # Option 2: Manual cleanup
        client = MgmtClient()  # Auto-loads from PANW_CLIENT_ID, PANW_CLIENT_SECRET
        try:
            new_key = client.api_keys.create_new_api_key(...)
        finally:
            client.close()

        # Access configuration
        print(client.config.base_url)
        client.config.num_retries = 5
    """

    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        token_base_url: Optional[str] = None,
        base_url: Optional[str] = None,
        num_retries: Optional[int] = None,
    ):
        """
        Initialize the AI Security Management Client.

        If credentials are not provided, they will be loaded from environment variables
        (PANW_CLIENT_ID, PANW_CLIENT_SECRET).

        Args:
            client_id: Service account client ID (e.g., "account@123.iam.panserviceaccount.com").
                      Falls back to PANW_CLIENT_ID environment variable if not provided.
            client_secret: Client secret UUID for authentication.
                          Falls back to PANW_CLIENT_SECRET environment variable if not provided.
            token_base_url: OAuth2 token endpoint URL. Defaults to DEFAULT_TOKEN_BASE_URL.
            base_url: Management API base URL. Defaults to DEFAULT_BASE_URL.
            num_retries: Maximum number of retries for API calls.
                        Defaults to MAX_NUMBER_OF_RETRIES.

        Raises:
            MissingVariableError: If client_id and client_secret are not provided.

        Examples:
            # Option 1: Direct initialization
            client = MgmtClient(
                client_id="your_client_id",
                client_secret="your_secret"
            )

            # Option 2: Auto-load from environment variables
            client = MgmtClient()  # Auto-loads from PANW_CLIENT_ID, PANW_CLIENT_SECRET
        """
        super().__init__()

        # Delegate all configuration to ClientConfig
        self.config = ClientConfig(
            client_id=client_id,
            client_secret=client_secret,
            token_base_url=token_base_url,
            base_url=base_url,
            num_retries=num_retries,
        )

        # Resource clients (lazy-loaded on first access)
        self._api_keys: Optional[ApiKey] = None
        self._ai_sec_profiles: Optional[AISecProfile] = None
        self._dlp_profiles: Optional[DlpProfile] = None
        self._deployment_profiles: Optional[DeploymentProfile] = None
        self._oauth: Optional[OAuth] = None
        self._customer_apps: Optional[CustomerApp] = None
        self._custom_topics: Optional[CustomTopic] = None

    @property
    def api_keys(self) -> ApiKey:
        """
        Get the API Keys resource client.

        This property provides lazy-loaded access to API key management operations.
        The ApiKey client is instantiated only when first accessed.

        Returns:
            ApiKey: API key management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Access API keys directly
            new_key = client.api_keys.create_new_api_key(...)
            client.api_keys.delete_api_key(...)
        """
        if self._api_keys is None:
            self._api_keys = ApiKey(self.config)
            log.debug("event=api_keys_property action=lazy_loaded")
        return self._api_keys

    @property
    def ai_sec_profiles(self) -> AISecProfile:
        """
        Get the AI Security Profiles resource client.

        This property provides lazy-loaded access to AI security profile management operations.
        The AISecProfile client is instantiated only when first accessed.

        Returns:
            AISecProfile: AI security profile management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Access AI security profiles directly
            new_profile = client.ai_sec_profiles.create_new_ai_profile(...)
            client.ai_sec_profiles.delete_ai_profile(...)
        """
        if self._ai_sec_profiles is None:
            self._ai_sec_profiles = AISecProfile(self.config)
            log.debug("event=ai_sec_profiles_property action=lazy_loaded")
        return self._ai_sec_profiles

    @property
    def dlp_profiles(self) -> DlpProfile:
        """
        Get the DLP Profiles resource client.

        This property provides lazy-loaded access to DLP profile management operations.
        The DlpProfile client is instantiated only when first accessed.

        Returns:
            DlpProfile: DLP profile management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Access DLP profiles directly
            profiles = client.dlp_profiles.get_all_dlp_profiles()
        """
        if self._dlp_profiles is None:
            self._dlp_profiles = DlpProfile(self.config)
            log.debug("event=dlp_profiles_property action=lazy_loaded")
        return self._dlp_profiles

    @property
    def deployment_profiles(self) -> DeploymentProfile:
        """
        Get the Deployment Profiles resource client.

        This property provides lazy-loaded access to deployment profile management operations.
        The DeploymentProfile client is instantiated only when first accessed.

        Returns:
            DeploymentProfile: Deployment profile management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Access deployment profiles directly
            profiles = client.deployment_profiles.get_all_deployment_profiles()
            # Or with unactivated filter
            unactivated_profiles = client.deployment_profiles.get_all_deployment_profiles(unactivated=True)
        """
        if self._deployment_profiles is None:
            self._deployment_profiles = DeploymentProfile(self.config)
            log.debug("event=deployment_profiles_property action=lazy_loaded")
        return self._deployment_profiles

    @property
    def oauth(self) -> OAuth:
        """
        Get the OAuth resource client.

        This property provides lazy-loaded access to OAuth token management operations.
        The OAuth client is instantiated only when first accessed.

        Returns:
            OAuth: OAuth token management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Generate OAuth token
            token = client.oauth.get_oauth_token(
                client_id="test_client_id",
                customer_app="test_app",
                token_ttl_interval=60,
                token_ttl_unit="minutes"
            )
        """
        if self._oauth is None:
            self._oauth = OAuth(self.config)
            log.debug("event=oauth_property action=lazy_loaded")
        return self._oauth

    @property
    def customer_apps(self) -> CustomerApp:
        """
        Get the Customer Apps resource client.

        This property provides lazy-loaded access to customer application management operations.
        The CustomerApp client is instantiated only when first accessed.

        Returns:
            CustomerApp: Customer application management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Retrieve customer app details
            app = client.customer_apps.retrieve_customer_app_details(app_name="my_app")

            # Retrieve all customer apps
            all_apps = client.customer_apps.get_all_customer_apps(offset=0, limit=10)

            # Update customer app
            updated = client.customer_apps.update_customer_app(
                customer_app_id="app123",
                app_name="my_app",
                tsg_id="tsg123",
                updated_by="user@example.com"
            )

            # Delete customer app
            client.customer_apps.delete_customer_app(app_name="my_app", updated_by="user@example.com")
        """
        if self._customer_apps is None:
            self._customer_apps = CustomerApp(self.config)
            log.debug("event=customer_apps_property action=lazy_loaded")
        return self._customer_apps

    @property
    def custom_topics(self) -> CustomTopic:
        """
        Get the Custom Topics resource client.

        This property provides lazy-loaded access to custom topic management operations.
        The CustomTopic client is instantiated only when first accessed.

        Returns:
            CustomTopic: Custom topic management client instance

        Example:
            client = MgmtClient()
            client.init(client_id="...", client_secret="...")

            # Retrieve custom topic details
            topic = client.custom_topics.retrieve_custom_topic_details(topic_id="topic123")

            # Retrieve all custom topics
            all_topics = client.custom_topics.get_all_custom_topics(offset=0, limit=10)

            # Modify custom topic
            modified = client.custom_topics.modify_custom_topic_details(
                topic_id="topic123",
                topic_name="My Topic",
                description="Topic description",
                examples=["example1", "example2"],
                updated_by="user@example.com"
            )

            # Delete custom topic
            client.custom_topics.delete_custom_topic(topic_id="topic123")

            # Force delete custom topic
            client.custom_topics.force_delete_custom_topic(
                topic_id="topic123", updated_by="user@example.com"
            )
        """
        if self._custom_topics is None:
            self._custom_topics = CustomTopic(self.config)
            log.debug("event=custom_topics_property action=lazy_loaded")
        return self._custom_topics

    def close(self):
        """Close all HTTP connection pools and clean up resources.

        This method should be called when you're done using the client to properly
        clean up all network connections and resources.

        Example:
            client = MgmtClient(client_id="...", client_secret="...")
            try:
                result = client.api_keys.create_new_api_key(...)
            finally:
                client.close()
        """
        # Close all resource clients
        resources = [
            self._api_keys,
            self._ai_sec_profiles,
            self._dlp_profiles,
            self._deployment_profiles,
            self._oauth,
            self._customer_apps,
            self._custom_topics,
        ]

        for resource in resources:
            if resource is not None:
                resource.close()
        log.debug("Closed all HTTP connection pools")

    def __enter__(self):
        """Context manager entry.

        Example:
            with MgmtClient(client_id="...", client_secret="...") as client:
                result = client.api_keys.create_new_api_key(...)
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures resources are cleaned up."""
        self.close()
        return False
