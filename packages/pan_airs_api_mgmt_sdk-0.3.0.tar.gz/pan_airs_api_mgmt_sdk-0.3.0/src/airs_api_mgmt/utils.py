# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Utility functions for the AI Security Management SDK.

This module provides helper functions for common SDK operations,
including standardized logger creation.
"""

import logging
import uuid

from airs_api_mgmt.config.constants import MGMT_SDK_PREFIX


def get_logger(name: str) -> logging.Logger:
    """Get a standardized logger for SDK components.

    Creates logger instances with consistent naming conventions across the SDK.
    Logger names are prefixed with MGMT_SDK_PREFIX and use hyphens instead of
    underscores for better readability in log output.

    Args:
        name: The module name, typically from __name__. For main modules or
              the package itself, this returns the root SDK logger.

    Returns:
        A configured logging.Logger instance with a standardized name.

    Examples:
        # From a module file
        logger = get_logger(__name__)

        # For main module
        logger = get_logger("__main__")
        # Returns: Logger("MGMT_SDK")

        # For submodule like "airs_api_mgmt.api_keys"
        logger = get_logger("airs_api_mgmt.api_keys")
        # Returns: Logger("MGMT_SDK.api-keys")

    Note:
        - Main module and package-level calls return the root logger
        - Package name is replaced with MGMT_SDK_PREFIX
        - Underscores are converted to hyphens for cleaner log names
    """
    # Handle main module or package-level calls
    if name == "__main__" or name == __package__:
        return logging.getLogger(MGMT_SDK_PREFIX)

    # Replace package name with SDK prefix and convert underscores to hyphens
    name = name.replace(__package__, MGMT_SDK_PREFIX)
    name = name.replace("_", "-")

    return logging.getLogger(name)


def is_valid_uuid(id_string: str) -> bool:
    """
    Check if a given string is a valid UUID.

    Args:
    id_string (str): The string to check.

    Returns:
    bool: True if the string is a valid UUID, False otherwise.
    """
    try:
        uuid_obj = uuid.UUID(id_string)
        return str(uuid_obj) == id_string.lower()
    except ValueError:
        return False
