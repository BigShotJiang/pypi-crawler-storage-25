# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Token management for AI Security Management SDK.

This module provides synchronous token acquisition and refresh functionality
that can be used from both synchronous and asynchronous contexts.
"""

from __future__ import annotations

from datetime import datetime, timedelta
import json
from typing import Optional
from urllib.parse import urlencode

from urllib3 import poolmanager
from urllib3.util import Retry


from airs_api_mgmt.config.constants import (
    HTTP_FORCE_RETRY_STATUS_CODES,
    GRANT_TYPE,
    CONTENT_TYPE,
    CONTENT_TYPE_FORM_URLENCODED,
    ACCEPT,
    ACCEPT_JSON,
    CLIENT_ID_FIELD,
    CLIENT_SECRET_FIELD,
    GRANT_TYPE_FIELD,
    ACCESS_TOKEN_FIELD,
    EXPIRES_IN_FIELD,
    TOKEN_REFRESH_BUFFER,
    DEFAULT_TIME_BETWEEN_TOKEN_REFRESH,
)
from airs_api_mgmt.exceptions import MgmtSdkServerError
from airs_api_mgmt.utils import get_logger

log = get_logger(__name__)


class TokenManager:
    """
    Manages OAuth2 token acquisition and refresh using synchronous HTTP calls.

    This class uses urllib3 for synchronous token requests and can be safely
    used from both synchronous and asynchronous contexts. Token requests are
    typically infrequent, so using synchronous calls simplifies the implementation
    without significant performance impact.

    This class handles:
    - Token caching and expiry tracking
    - Automatic token refresh when expired
    - Synchronous token requests via urllib3

    Attributes:
        config: ClientConfig instance with authentication credentials
        access_token: Current cached access token

    Examples:
        # Synchronous usage
        from airs_api_mgmt.config import ClientConfig, TokenManager

        config = ClientConfig(client_id="...", client_secret="...")
        token_manager = TokenManager(config)
        token = token_manager.get_access_token()

        # From async context (token fetch is still sync, which is fine)
        token_manager = TokenManager(config)
        token = token_manager.get_access_token()  # No await needed
    """

    def __init__(self, config):
        """
        Initialize TokenManager with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        self.config = config
        self.access_token: Optional[str] = None

        # HTTP client for token requests (urllib3)
        self._pool_manager: Optional[poolmanager.PoolManager] = None

    def _is_token_valid(self) -> bool:
        """
        Check if the current cached token is still valid.

        Returns:
            bool: True if token exists and hasn't expired, False otherwise
        """
        if self.access_token and self.config.token_expiry:
            return datetime.now() < self.config.token_expiry
        return False

    def _calculate_token_expiry(self, expires_in: Optional[int]) -> datetime:
        """
        Calculate when the token should be refreshed.

        Args:
            expires_in: Token lifetime in seconds from OAuth response

        Returns:
            datetime: When the token should be considered expired
        """
        if expires_in is None:
            expires_in = DEFAULT_TIME_BETWEEN_TOKEN_REFRESH

        # Refresh token before actual expiry (use buffer or half the expiry time)
        refresh_buffer = min(TOKEN_REFRESH_BUFFER, expires_in // 2)
        return datetime.now() + timedelta(seconds=expires_in - refresh_buffer)

    def get_access_token(self) -> str:
        """
        Get access token using OAuth2 client credentials flow.

        This method uses urllib3 for synchronous HTTP requests. It includes
        automatic token caching and will only make a network request when
        the cached token is expired or missing.

        Returns:
            str: Valid bearer token

        Raises:
            MgmtSdkServerError: If token acquisition fails
        """
        # Return cached token if still valid
        if self._is_token_valid():
            return self.access_token

        # Initialize urllib3 pool manager if not already created
        if self._pool_manager is None:
            self._pool_manager = poolmanager.PoolManager(
                retries=Retry(
                    total=self.config.num_retries,
                    status_forcelist=HTTP_FORCE_RETRY_STATUS_CODES,
                    backoff_factor=1,  # Wait 1s, 2s, 4s, 8s... between retries
                ),
            )

        # Prepare request
        headers = {
            CONTENT_TYPE: CONTENT_TYPE_FORM_URLENCODED,
            ACCEPT: ACCEPT_JSON,
        }

        payload = {
            CLIENT_ID_FIELD: self.config.client_id,
            CLIENT_SECRET_FIELD: self.config.client_secret,
            GRANT_TYPE_FIELD: GRANT_TYPE,
        }

        encoded_data = urlencode(payload)

        try:
            # Make POST request
            response = self._pool_manager.request(
                "POST",
                self.config.token_base_url,
                headers=headers,
                body=encoded_data,
            )

            # Check response status
            if response.status < 200 or response.status >= 300:
                error_msg = f"HTTP {response.status}: {response.data.decode('utf-8', errors='replace')}"
                log.error(f"event=get_access_token {error_msg}")
                raise MgmtSdkServerError(
                    f"Failed to get access token: {error_msg}",
                    status_code=response.status,
                    response_body=response.data.decode("utf-8", errors="replace"),
                )

            # Parse JSON response
            try:
                token_data = json.loads(response.data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                log.error("event=get_access_token error=invalid_json_response")
                raise MgmtSdkServerError(
                    f"Invalid JSON response from token endpoint: {e}"
                )

            # Extract and validate access token
            access_token = token_data.get(ACCESS_TOKEN_FIELD)
            if not access_token:
                log.error("event=get_access_token error=no_access_token_in_response")
                raise MgmtSdkServerError("No access token in response")

            # Update token expiry
            expires_in = token_data.get(EXPIRES_IN_FIELD)
            self.config.token_expiry = self._calculate_token_expiry(expires_in)

            # Cache and return token
            self.access_token = access_token
            log.info("event=get_access_token action=token_acquired_successfully")
            return access_token

        except MgmtSdkServerError:
            # Re-raise our custom exceptions
            raise
        except Exception as e:
            error_msg = f"Failed to get access token: {e}"
            log.error(f"event=get_access_token {error_msg}")
            raise MgmtSdkServerError(error_msg)

    def close(self):
        """
        Close HTTP clients and clean up resources.

        This should be called when the token manager is no longer needed
        to properly clean up resources.
        """
        if self._pool_manager is not None:
            self._pool_manager.clear()
