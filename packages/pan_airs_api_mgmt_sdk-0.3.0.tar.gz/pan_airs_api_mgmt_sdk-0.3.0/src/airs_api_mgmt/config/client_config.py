# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Pure configuration class for AI Security Management SDK.

This module contains only configuration data and has no dependencies on
resource classes (OAuth, CustomerApp, etc.). This design prevents circular imports.
"""

from __future__ import annotations

import os
from typing import Optional
from datetime import datetime

from airs_api_mgmt.config.constants import (
    DEFAULT_TOKEN_BASE_URL,
    DEFAULT_BASE_URL,
    MAX_NUMBER_OF_RETRIES,
    PANW_CLIENT_ID,
    PANW_CLIENT_SECRET,
    PANW_BASE_URL,
    PANW_TOKEN_BASE_URL,
)
from airs_api_mgmt.exceptions import (
    MgmtSdkConfigurationError,
    MissingVariableError,
)
from airs_api_mgmt.utils import get_logger

log = get_logger(__name__)


class ClientConfig:
    """
    Configuration container for AI Security Management SDK.

    This class holds only configuration data and has NO dependencies on
    resource classes (OAuth, CustomerApp, etc.). This design prevents
    circular imports and allows for cleaner type hints throughout the SDK.

    Attributes:
        client_id (str): Service account client ID for authentication
        client_secret (str): Client secret for authentication
        base_url (str): Management API base URL
        token_base_url (str): OAuth2 token endpoint URL
        num_retries (int): Maximum number of retries for API calls
        token_expiry (datetime): Token expiration timestamp

    Examples:
        # Option 1: Direct initialization with credentials
        config = ClientConfig(
            client_id="your_client_id",
            client_secret="your_secret",
            base_url="https://api.example.com"
        )

        # Option 2: Auto-load from environment variables
        config = ClientConfig()  # Reads from PANW_CLIENT_ID, PANW_CLIENT_SECRET
    """

    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        token_base_url: Optional[str] = None,
        base_url: Optional[str] = None,
        num_retries: Optional[int] = None,
    ):
        """
        Initialize SDK configuration.

        Args:
            client_id: Service account client ID (e.g., "account@123.iam.panserviceaccount.com").
                      Falls back to PANW_CLIENT_ID environment variable if not provided.
            client_secret: Client secret UUID for authentication.
                          Falls back to PANW_CLIENT_SECRET environment variable if not provided.
            base_url: Management API base URL.
                     Falls back to PANW_BASE_URL environment variable if not provided.
                     Defaults to DEFAULT_BASE_URL if neither parameter nor env var is set.
            token_base_url: OAuth2 token endpoint URL.
                           Falls back to PANW_TOKEN_BASE_URL environment variable if not provided.
                           Defaults to DEFAULT_TOKEN_BASE_URL if neither parameter nor env var is set.
            num_retries: Maximum number of retries for API calls.
                        Defaults to MAX_NUMBER_OF_RETRIES.

        Raises:
            MissingVariableError: If client_id and client_secret are not provided.
        """
        # Initialize instance variables with defaults
        self._client_id: Optional[str] = None
        self._client_secret: Optional[str] = None
        self._base_url: str = DEFAULT_BASE_URL
        self._token_base_url: str = DEFAULT_TOKEN_BASE_URL
        self._num_retries: int = num_retries or MAX_NUMBER_OF_RETRIES
        self.token_expiry: Optional[datetime] = None

        # Load base_url from parameter or environment or default
        if base_url is not None:
            self._base_url = base_url
        elif env_base_url := os.getenv(PANW_BASE_URL):
            self._base_url = env_base_url

        # Load token_base_url from parameter or environment or default
        if token_base_url is not None:
            self._token_base_url = token_base_url
        elif env_token_base_url := os.getenv(PANW_TOKEN_BASE_URL):
            self._token_base_url = env_token_base_url

        # Load client_id from parameter or environment
        if client_id is not None:
            self.client_id = client_id
        elif client_id := os.getenv(PANW_CLIENT_ID):
            self.client_id = client_id

        # Load client_secret from parameter or environment
        if client_secret is not None:
            self.client_secret = client_secret
        elif client_secret := os.getenv(PANW_CLIENT_SECRET):
            self.client_secret = client_secret

        # Validate that both credentials are provided
        if self.client_id is None or self.client_secret is None:
            error_msg = "Both client_id and client_secret must be provided"
            log.error(f"event=__init__ error={error_msg}")
            raise MissingVariableError(error_msg)

    @property
    def base_url(self) -> str:
        """
        Get the Management API base URL.

        Returns:
            str: The base URL for the Management API
        """
        return self._base_url

    @base_url.setter
    def base_url(self, value: Optional[str]):
        """
        Set the Management API base URL.

        Args:
            value: Base URL to set. If None, defaults to DEFAULT_BASE_URL
        """
        if value is None:
            value = DEFAULT_BASE_URL
        self._base_url = value
        log.info(f"event=base_url_setter base_url={self._base_url} action=set")

    @property
    def client_id(self) -> Optional[str]:
        """
        Get the service account client ID.

        Returns:
            str: The client ID used for authentication
        """
        return self._client_id

    @client_id.setter
    def client_id(self, value: Optional[str]):
        """
        Set the service account client ID.

        Args:
            value: Client ID to set. Must not be None or empty.

        Raises:
            MissingVariableError: If value is None or empty string
            MgmtSdkConfigurationError: If value is whitespace-only string
        """
        if value is None:
            error_msg = "client_id cannot be None"
            log.error(f"event=client_id_setter error={error_msg}")
            raise MissingVariableError(error_msg)
        if isinstance(value, str) and value == "":
            error_msg = "client_id cannot be empty"
            log.error(f"event=client_id_setter error={error_msg}")
            raise MissingVariableError(error_msg)
        if isinstance(value, str) and not value.strip():
            error_msg = "client_id cannot be whitespace-only"
            log.error(f"event=client_id_setter error={error_msg}")
            raise MgmtSdkConfigurationError(error_msg)
        self._client_id = value
        log.info("event=client_id_setter client_id value configured action=set")

    @property
    def client_secret(self) -> Optional[str]:
        """
        Get the client secret.

        Returns:
            str: The client secret used for authentication
        """
        return self._client_secret

    @client_secret.setter
    def client_secret(self, value: Optional[str]):
        """
        Set the client secret.

        Args:
            value: Client secret to set. Must not be None or empty.

        Raises:
            MissingVariableError: If value is None or empty string
            MgmtSdkConfigurationError: If value is whitespace-only string
        """
        if value is None:
            error_msg = "client_secret cannot be None"
            log.error(f"event=client_secret_setter error={error_msg}")
            raise MissingVariableError(error_msg)
        if isinstance(value, str) and value == "":
            error_msg = "client_secret cannot be empty"
            log.error(f"event=client_secret_setter error={error_msg}")
            raise MissingVariableError(error_msg)
        if isinstance(value, str) and not value.strip():
            error_msg = "client_secret cannot be whitespace-only"
            log.error(f"event=client_secret_setter error={error_msg}")
            raise MgmtSdkConfigurationError(error_msg)
        self._client_secret = value
        log.info("event=client_secret_setter client_secret value configured action=set")

    @property
    def token_base_url(self) -> str:
        """
        Get the OAuth2 token endpoint URL.

        Returns:
            str: The token endpoint URL for authentication
        """
        return self._token_base_url

    @token_base_url.setter
    def token_base_url(self, value: Optional[str]):
        """
        Set the OAuth2 token endpoint URL.

        Args:
            value: Token endpoint URL to set. If None, defaults to DEFAULT_TOKEN_BASE_URL
        """
        if value is None:
            value = DEFAULT_TOKEN_BASE_URL
        self._token_base_url = value
        log.info(
            f"event=token_base_url_setter token_base_url={self._token_base_url} action=set"
        )

    @property
    def num_retries(self) -> int:
        """
        Get the maximum number of retries for API calls.

        Returns:
            int: Maximum number of retries
        """
        return self._num_retries

    @num_retries.setter
    def num_retries(self, value: Optional[int]):
        """
        Set the maximum number of retries for API calls.

        Args:
            value: Maximum retries to set. If None, defaults to MAX_NUMBER_OF_RETRIES
        """
        if value is None:
            value = MAX_NUMBER_OF_RETRIES
        self._num_retries = value
        log.info(f"event=num_retries_setter num_retries={self._num_retries} action=set")
