# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

import airs_api_mgmt._version

DEFAULT_TOKEN_BASE_URL = "https://auth.apps.paloaltonetworks.com/am/oauth2/access_token"
DEFAULT_BASE_URL = "https://api.sase.paloaltonetworks.com/aisec"
DEFAULT_TIME_BETWEEN_TOKEN_REFRESH = 900
GRANT_TYPE = "client_credentials"

MAX_NUMBER_OF_RETRIES = 3
PANW_CLIENT_ID = "PANW_CLIENT_ID"
PANW_CLIENT_SECRET = "PANW_CLIENT_SECRET"
MGMT_SDK_PREFIX = "MGMT-SDK"


# My Extensions


DEFAULT_TIME_BETWEEN_TOKEN_REFRESH = 900
GRANT_TYPE = "client_credentials"
MAX_NUMBER_OF_RETRIES = 3
PANW_CLIENT_ID = "PANW_CLIENT_ID"
PANW_CLIENT_SECRET = "PANW_CLIENT_SECRET"
PANW_BASE_URL = "PANW_BASE_URL"
PANW_TOKEN_BASE_URL = "PANW_TOKEN_BASE_URL"
HEADER_AUTH_TOKEN = "Authorization"
BEARER = "Bearer "
USER_AGENT = f"PAN-AIRS/{airs_api_mgmt._version.__version__}-MGMT-PYTHON-SDK"
HTTP_FORCE_RETRY_STATUS_CODES = [500, 502, 503, 504]

# HTTP Headers
CONTENT_TYPE = "Content-Type"
CONTENT_TYPE_FORM_URLENCODED = "application/x-www-form-urlencoded"
ACCEPT = "Accept"
ACCEPT_JSON = "application/json"

# OAuth2 Request Fields
CLIENT_ID_FIELD = "client_id"
CLIENT_SECRET_FIELD = "client_secret"
GRANT_TYPE_FIELD = "grant_type"

# OAuth2 Response Fields
ACCESS_TOKEN_FIELD = "access_token"
EXPIRES_IN_FIELD = "expires_in"

# Token Refresh Buffer (seconds)
TOKEN_REFRESH_BUFFER = 300  # 5 minutes

# length
MAX_EMAIL_LENGTH = 100
MAX_API_KEY_NAME_LENGTH = 31
MAX_AI_PROFILE_NAME_LENGTH = 100
MAX_PROFILE_ID_LENGTH = 36
MAX_CONNECTION_POOL_SIZE = 100
