# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

import asyncio
from typing import Optional

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.resources.asyncio.api_keys import ApiKeyAsync
from airs_api_mgmt.resources.asyncio.ai_sec_profiles import AISecProfileAsync
from airs_api_mgmt.resources.asyncio.dlp_profiles import DLPProfilesAsync
from airs_api_mgmt.resources.asyncio.deployment_profiles import DeploymentProfilesAsync
from airs_api_mgmt.resources.asyncio.oauth import OauthAsync
from airs_api_mgmt.resources.asyncio.customer_app import CustomerAppAsync
from airs_api_mgmt.resources.asyncio.custom_topic import CustomTopicAsync
from .utils import get_logger

log = get_logger(__name__)


class MgmtClientAsync:
    """
    Async client for AI Security Management API.

    This class provides async access to all API resources using asyncio/aiohttp.
    Configuration is managed through the `config` attribute (ClientConfig instance).

    Attributes:
        config (ClientConfig): Configuration container with authentication and settings
            - config.client_id: Service account client ID for authentication
            - config.client_secret: Client secret for authentication
            - config.base_url: Management API base URL
            - config.token_base_url: OAuth2 token endpoint URL
            - config.num_retries: Maximum number of retries for API calls
            - config.token_expiry: Token expiration timestamp

    Resource Properties:
        api_keys: Async API key management operations (create, delete, regenerate)
        ai_sec_profiles: Async AI security profile management operations
        dlp_profiles: Async DLP profile management operations
        deployment_profiles: Async deployment profile management operations
        oauth: Async OAuth token management operations
        customer_apps: Async customer application management operations
        custom_topics: Async custom topic management operations

    Examples:
        # Option 1: Using async context manager (recommended)
        async with MgmtClientAsync(
            client_id="your_client_id",
            client_secret="your_secret"
        ) as client:
            new_key = await client.api_keys.create_new_api_key(
                api_key_name="my-key",
                cust_app="my-app",
                auth_code="auth123",
                created_by="user@example.com",
                rotation_time_interval=30,
                rotation_time_unit="days",
                cust_env="production",
                cust_cloud_provider="AWS"
            )

        # Option 2: Manual cleanup
        client = MgmtClientAsync()  # Auto-loads from PANW_CLIENT_ID, PANW_CLIENT_SECRET
        try:
            new_key = await client.api_keys.create_new_api_key(...)
        finally:
            await client.close()

        # Access configuration
        print(client.config.base_url)
        client.config.num_retries = 5
    """

    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        token_base_url: Optional[str] = None,
        base_url: Optional[str] = None,
        num_retries: Optional[int] = None,
    ):
        """
        Initialize the AI Security Management Async Client.

        If credentials are not provided, they will be loaded from environment variables
        (PANW_CLIENT_ID, PANW_CLIENT_SECRET).

        Args:
            client_id: Service account client ID (e.g., "account@123.iam.panserviceaccount.com").
                      Falls back to PANW_CLIENT_ID environment variable if not provided.
            client_secret: Client secret UUID for authentication.
                          Falls back to PANW_CLIENT_SECRET environment variable if not provided.
            token_base_url: OAuth2 token endpoint URL. Defaults to DEFAULT_TOKEN_BASE_URL.
            base_url: Management API base URL. Defaults to DEFAULT_BASE_URL.
            num_retries: Maximum number of retries for API calls.
                        Defaults to MAX_NUMBER_OF_RETRIES.

        Raises:
            MissingVariableError: If client_id and client_secret are not provided.

        Examples:
            # Option 1: Direct initialization
            client = MgmtClientAsync(
                client_id="your_client_id",
                client_secret="your_secret"
            )

            # Option 2: Auto-load from environment variables
            client = MgmtClientAsync()  # Auto-loads from PANW_CLIENT_ID, PANW_CLIENT_SECRET
        """
        super().__init__()

        # Delegate all configuration to ClientConfig
        self.config = ClientConfig(
            client_id=client_id,
            client_secret=client_secret,
            token_base_url=token_base_url,
            base_url=base_url,
            num_retries=num_retries,
        )

        # Async resource clients (lazy-loaded on first access)
        self._api_keys: Optional[ApiKeyAsync] = None
        self._ai_sec_profiles: Optional[AISecProfileAsync] = None
        self._dlp_profiles: Optional[DLPProfilesAsync] = None
        self._deployment_profiles: Optional[DeploymentProfilesAsync] = None
        self._oauth: Optional[OauthAsync] = None
        self._customer_apps: Optional[CustomerAppAsync] = None
        self._custom_topics: Optional[CustomTopicAsync] = None

    @property
    def api_keys(self) -> ApiKeyAsync:
        """
        Get the async API Keys resource client.

        This property provides lazy-loaded access to async API key management operations.
        The ApiKeyAsync client is instantiated only when first accessed.

        Returns:
            ApiKeyAsync: Async API key management client instance

        Example:
            client = MgmtClientAsync()

            # Access API keys asynchronously
            new_key = await client.api_keys.create_new_api_key(...)
            await client.api_keys.delete_api_key(...)
        """
        if self._api_keys is None:
            self._api_keys = ApiKeyAsync(self.config)
            log.debug("event=api_keys_property action=lazy_loaded")
        return self._api_keys

    @property
    def ai_sec_profiles(self) -> AISecProfileAsync:
        """
        Get the async AI Security Profiles resource client.

        This property provides lazy-loaded access to async AI security profile management operations.
        The AISecProfileAsync client is instantiated only when first accessed.

        Returns:
            AISecProfileAsync: Async AI security profile management client instance

        Example:
            client = MgmtClientAsync()

            # Access AI security profiles asynchronously
            new_profile = await client.ai_sec_profiles.create_new_ai_profile(...)
            await client.ai_sec_profiles.delete_ai_profile(...)
        """
        if self._ai_sec_profiles is None:
            self._ai_sec_profiles = AISecProfileAsync(self.config)
            log.debug("event=ai_sec_profiles_property action=lazy_loaded")
        return self._ai_sec_profiles

    @property
    def dlp_profiles(self) -> DLPProfilesAsync:
        """
        Get the async DLP Profiles resource client.

        This property provides lazy-loaded access to async DLP profile management operations.
        The DLPProfilesAsync client is instantiated only when first accessed.

        Returns:
            DLPProfilesAsync: Async DLP profile management client instance

        Example:
            client = MgmtClientAsync()

            # Access DLP profiles asynchronously
            profiles = await client.dlp_profiles.get_all_dlp_profiles()
        """
        if self._dlp_profiles is None:
            self._dlp_profiles = DLPProfilesAsync(self.config)
            log.debug("event=dlp_profiles_property action=lazy_loaded")
        return self._dlp_profiles

    @property
    def deployment_profiles(self) -> DeploymentProfilesAsync:
        """
        Get the async Deployment Profiles resource client.

        This property provides lazy-loaded access to async deployment profile management operations.
        The DeploymentProfilesAsync client is instantiated only when first accessed.

        Returns:
            DeploymentProfilesAsync: Async deployment profile management client instance

        Example:
            client = MgmtClientAsync()

            # Access deployment profiles asynchronously
            profiles = await client.deployment_profiles.get_all_deployment_profiles()
            # Or with unactivated filter
            unactivated = await client.deployment_profiles.get_all_deployment_profiles(unactivated=True)
        """
        if self._deployment_profiles is None:
            self._deployment_profiles = DeploymentProfilesAsync(self.config)
            log.debug("event=deployment_profiles_property action=lazy_loaded")
        return self._deployment_profiles

    @property
    def oauth(self) -> OauthAsync:
        """
        Get the async OAuth resource client.

        This property provides lazy-loaded access to async OAuth token management operations.
        The OauthAsync client is instantiated only when first accessed.

        Returns:
            OauthAsync: Async OAuth token management client instance

        Example:
            client = MgmtClientAsync()

            # Generate OAuth token asynchronously
            token = await client.oauth.get_oauth_token(
                client_id="test_client_id",
                customer_app="test_app",
                token_ttl_interval=60,
                token_ttl_unit="minutes"
            )
        """
        if self._oauth is None:
            self._oauth = OauthAsync(self.config)
            log.debug("event=oauth_property action=lazy_loaded")
        return self._oauth

    @property
    def customer_apps(self) -> CustomerAppAsync:
        """
        Get the async Customer Apps resource client.

        This property provides lazy-loaded access to async customer application management operations.
        The CustomerAppAsync client is instantiated only when first accessed.

        Returns:
            CustomerAppAsync: Async customer application management client instance

        Example:
            client = MgmtClientAsync()

            # Retrieve all customer apps asynchronously
            all_apps = await client.customer_apps.get_all_customer_apps(offset=0, limit=10)

            # Update customer app asynchronously
            updated = await client.customer_apps.update_customer_app(
                customer_app_id="app123",
                app_name="my_app",
                cloud_provider="AWS",
                environment="production",
                auth_code="auth123",
                updated_by="user@example.com"
            )

            # Delete customer app asynchronously
            await client.customer_apps.delete_customer_app(app_name="my_app", updated_by="user@example.com")
        """
        if self._customer_apps is None:
            self._customer_apps = CustomerAppAsync(self.config)
            log.debug("event=customer_apps_property action=lazy_loaded")
        return self._customer_apps

    @property
    def custom_topics(self) -> CustomTopicAsync:
        """
        Get the async Custom Topics resource client.

        This property provides lazy-loaded access to async custom topic management operations.
        The CustomTopicAsync client is instantiated only when first accessed.

        Returns:
            CustomTopicAsync: Async custom topic management client instance

        Example:
            client = MgmtClientAsync()

            # Retrieve custom topic details asynchronously
            topic = await client.custom_topics.retrieve_custom_topic_details(topic_id="topic123")

            # Retrieve all custom topics asynchronously
            all_topics = await client.custom_topics.get_all_custom_topics(offset=0, limit=10)

            # Modify custom topic asynchronously
            modified = await client.custom_topics.modify_custom_topic_details(
                topic_id="topic123",
                topic_name="My Topic",
                description="Topic description",
                examples=["example1", "example2"],
                updated_by="user@example.com"
            )

            # Delete custom topic asynchronously
            await client.custom_topics.delete_custom_topic(topic_id="topic123")

            # Force delete custom topic asynchronously
            await client.custom_topics.force_delete_custom_topic(
                topic_id="topic123", updated_by="user@example.com"
            )
        """
        if self._custom_topics is None:
            self._custom_topics = CustomTopicAsync(self.config)
            log.debug("event=custom_topics_property action=lazy_loaded")
        return self._custom_topics

    async def close(self):
        """Close all aiohttp sessions and clean up resources.

        This method should be called when you're done using the client to properly
        clean up all network connections and resources.

        Example:
            client = MgmtClientAsync(client_id="...", client_secret="...")
            try:
                result = await client.api_keys.create_new_api_key(...)
            finally:
                await client.close()
        """
        # Close all resource clients
        resources = [
            self._api_keys,
            self._ai_sec_profiles,
            self._dlp_profiles,
            self._deployment_profiles,
            self._oauth,
            self._customer_apps,
            self._custom_topics,
        ]

        tasks = []
        for resource in resources:
            if resource is not None:
                tasks.append(resource.close())
        if tasks:
            await asyncio.gather(*tasks)
            log.debug(f"Closed {len(tasks)} asyncio connection pools")

    async def __aenter__(self):
        """Async context manager entry.

        Example:
            async with MgmtClientAsync(client_id="...", client_secret="...") as client:
                result = await client.api_keys.create_new_api_key(...)
        """
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - ensures resources are cleaned up."""
        await self.close()
        return False
