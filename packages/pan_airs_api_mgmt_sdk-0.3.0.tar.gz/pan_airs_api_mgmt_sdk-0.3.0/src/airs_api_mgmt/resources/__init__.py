# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Resource classes for AI Security Management API.

This module provides resource classes for different API endpoint groups,
following a fluent API design pattern.
"""

from .inline.ai_sec_profiles import AISecProfile
from .inline.api_keys import ApiKey
from .inline.custom_topic import CustomTopic
from .inline.customer_app import CustomerApp
from .inline.deployment_profiles import DeploymentProfile
from .inline.dlp_profiles import DlpProfile
from .inline.oauth import OAuth

__all__ = [
    "AISecProfile",
    "ApiKey",
    "CustomTopic",
    "CustomerApp",
    "DeploymentProfile",
    "DlpProfile",
    "OAuth",
]
