# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

from typing import Optional
from datetime import datetime

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.config.constants import (
    MAX_EMAIL_LENGTH,
    MAX_AI_PROFILE_NAME_LENGTH,
    MAX_PROFILE_ID_LENGTH,
)
from airs_api_mgmt.sdk.inline import ApiException
from airs_api_mgmt.sdk.inline.api import AISecProfileApi
from airs_api_mgmt.sdk.models import AIProfileObjectPolicy
from airs_api_mgmt.sdk.models import AIProfileObject
from airs_api_mgmt.sdk.models import (
    PaginatedAIProfileObject,
)

from airs_api_mgmt.resources.inline.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
    PayloadConfigurationError,
)
from airs_api_mgmt.utils import get_logger, is_valid_uuid


class AISecProfile(BaseClient):
    """AI Security Profile management class for handling AI profile operations.

    This class provides methods to manage AI Security Profiles including creation, retrieval,
    update, deletion, and force deletion operations.
    """

    def __init__(self, config: ClientConfig):
        """Initialize AISecProfile with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = AISecProfileApi(self.api_client)

    def create_new_ai_profile(
        self,
        profile_name: str,
        revision: int,
        policy: AIProfileObjectPolicy,
        profile_id: Optional[str] = None,
        created_by: Optional[str] = None,
        updated_by: Optional[str] = None,
        last_modified_ts: Optional[datetime] = None,
        **kwargs,
    ) -> AIProfileObject:
        """Create a new AI Security Profile with the specified configuration.

        Args:
            profile_name: The name of the AI Security Profile.
            revision: The revision number of the AI Security Profile.
            policy: The policy configuration object for the AI Security Profile.
            profile_id: The unique identifier for the AI Security Profile. Optional.
            created_by: Identifier of the user creating the AI Security Profile. Optional.
            updated_by: Identifier of the user who last updated the profile. Optional.
            last_modified_ts: Timestamp of the last modification. Optional.
            **kwargs: Deprecated parameters (e.g., 'active') are accepted but ignored for backward compatibility.

        Returns:
            AIProfileObject: The created AI Security Profile object.

        Raises:
            MgmtSdkClientError: If AI profile creation fails due to client error (4xx)
            MgmtSdkServerError: If AI profile creation fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Handle deprecated parameters for backward compatibility
        if "active" in kwargs:
            self.logger.warning(
                f"event={self.create_new_ai_profile.__name__} "
                "The 'active' parameter is deprecated and will be ignored."
            )

        # Validate mandatory arguments
        if not profile_name or len(profile_name.strip()) == 0:
            raise PayloadConfigurationError(
                "profile_name is required and cannot be empty"
            )
        elif len(profile_name.strip()) > MAX_AI_PROFILE_NAME_LENGTH:
            raise PayloadConfigurationError(
                f"profile_name cannot exceed {MAX_AI_PROFILE_NAME_LENGTH} characters"
            )
        if revision is None:
            raise PayloadConfigurationError("revision is required and cannot be None")
        if policy is None:
            raise PayloadConfigurationError("policy is required and cannot be None")

        self.refresh_token_if_expired()

        # Build AI profile object with only non-None optional parameters
        profile_data = {
            "profile_name": profile_name.strip(),
            "revision": revision,
            "policy": policy,
        }
        if profile_id is not None:
            if len(profile_id.strip()) > MAX_PROFILE_ID_LENGTH:
                raise PayloadConfigurationError(
                    f"profile_id cannot exceed {MAX_PROFILE_ID_LENGTH} characters"
                )
            profile_data["profile_id"] = profile_id.strip()
        if created_by is not None:
            if len(created_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"created_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            profile_data["created_by"] = created_by.strip()
        if updated_by is not None:
            if len(updated_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            profile_data["updated_by"] = updated_by.strip()
        if last_modified_ts is not None:
            profile_data["last_modified_ts"] = last_modified_ts

        ai_profile_object = AIProfileObject(**profile_data)
        try:
            self.logger.info(f"event={self.create_new_ai_profile.__name__}")
            self.logger.debug(
                f"event={self.create_new_ai_profile.__name__} profile_name={profile_name!r}"
            )
            response = self._api.create_new_ai_profile(
                ai_profile_object=ai_profile_object
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to create AI profile: {e}"
            self.logger.error(
                f"event={self.create_new_ai_profile.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while creating AI profile: {e}"
            self.logger.error(
                f"event={self.create_new_ai_profile.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def get_all_ai_profiles(
        self, offset: int = 0, limit: int = 100
    ) -> PaginatedAIProfileObject:
        """Retrieve AI Security Profiles with pagination support.

        Args:
            offset: The starting position for pagination (number of records to skip).
                Defaults to 0.
            limit: The maximum number of AI profiles to retrieve in a single request.
                Defaults to 100.

        Returns:
            PaginatedAIProfileObject: A paginated collection of AI profile objects with
                pagination metadata.

        Raises:
            MgmtSdkClientError: If AI profile retrieval fails due to client error (4xx)
            MgmtSdkServerError: If AI profile retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """

        if offset < 0 or limit < 0:
            raise PayloadConfigurationError("offset and/or limit not specified")

        self.refresh_token_if_expired()

        try:
            response = self._api.get_all_ai_profiles_for_tsg_id(
                offset=offset, limit=limit
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve AI profiles: {e}"
            self.logger.error(
                f"event={self.get_all_ai_profiles.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving AI profiles: {e}"
            self.logger.error(
                f"event={self.get_all_ai_profiles.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def update_ai_profile(
        self,
        profile_id: str,
        profile_name: str,
        revision: int,
        policy: AIProfileObjectPolicy,
        created_by: Optional[str] = None,
        updated_by: Optional[str] = None,
        last_modified_ts: Optional[datetime] = None,
        **kwargs,
    ) -> AIProfileObject:
        """Update an AI Security Profile by its ID.

        Args:
            profile_id: The ID of the AI Security Profile to update.
            profile_name: Updated name of the AI Security Profile.
            revision: The revision number of the AI Security Profile.
            policy: The policy configuration object for the AI Security Profile.
            created_by: Identifier of the user who created the profile. Optional.
            updated_by: Identifier of the user updating the profile. Optional.
            last_modified_ts: Timestamp of the last modification. Optional.
            **kwargs: Deprecated parameters (e.g., 'active') are accepted but ignored for backward compatibility.

        Returns:
            AIProfileObject: The updated AI Security Profile object.

        Raises:
            MgmtSdkClientError: If AI profile update fails due to client error (4xx)
            MgmtSdkServerError: If AI profile update fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Handle deprecated parameters for backward compatibility
        if "active" in kwargs:
            self.logger.warning(
                f"event={self.update_ai_profile.__name__} "
                "The 'active' parameter is deprecated and will be ignored."
            )

        # Validate mandatory arguments
        if not profile_id or len(profile_id.strip()) == 0:
            raise PayloadConfigurationError(
                "profile_id is required and cannot be empty"
            )
        elif len(profile_id.strip()) > MAX_PROFILE_ID_LENGTH:
            raise PayloadConfigurationError(
                f"profile_id cannot exceed {MAX_PROFILE_ID_LENGTH} characters"
            )
        elif not is_valid_uuid(profile_id):
            raise PayloadConfigurationError("Profile Id is not a valid UUID format")
        if not profile_name or len(profile_name.strip()) == 0:
            raise PayloadConfigurationError(
                "profile_name is required and cannot be empty"
            )
        elif len(profile_name.strip()) > MAX_AI_PROFILE_NAME_LENGTH:
            raise PayloadConfigurationError(
                f"profile_name cannot exceed {MAX_AI_PROFILE_NAME_LENGTH} characters"
            )
        if revision is None:
            raise PayloadConfigurationError("revision is required and cannot be None")
        if policy is None:
            raise PayloadConfigurationError("policy is required and cannot be None")

        self.refresh_token_if_expired()

        # Build AI profile object with only non-None optional parameters
        profile_data = {
            "profile_name": profile_name.strip(),
            "revision": revision,
            "policy": policy,
            "profile_id": profile_id.strip(),
        }
        if created_by is not None:
            if len(created_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"created_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            profile_data["created_by"] = created_by.strip()
        if updated_by is not None:
            if len(updated_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            profile_data["updated_by"] = updated_by.strip()
        if last_modified_ts is not None:
            profile_data["last_modified_ts"] = last_modified_ts

        ai_profile_object = AIProfileObject(**profile_data)

        try:
            self.logger.info(
                f"event={self.update_ai_profile.__name__} profile_id={profile_id}"
            )
            response = self._api.update_profile_by_profile_id(
                profile_id=profile_id.strip(), ai_profile_object=ai_profile_object
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to update AI profile: {e}"
            self.logger.error(
                f"event={self.update_ai_profile.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while updating AI profile: {e}"
            self.logger.error(
                f"event={self.update_ai_profile.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def delete_ai_profile(self, profile_id: str) -> str:
        """Delete an AI Security Profile by its ID.

        Args:
            profile_id: The ID of the AI Security Profile to delete.

        Returns:
            DeleteAIProfile200Response: Response object confirming the deletion operation.

        Raises:
            MgmtSdkClientError: If AI profile deletion fails due to client error (4xx)
            MgmtSdkServerError: If AI profile deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not profile_id or len(profile_id.strip()) == 0:
            raise PayloadConfigurationError(
                "profile_id is required and cannot be empty"
            )
        elif len(profile_id.strip()) > MAX_PROFILE_ID_LENGTH:
            raise PayloadConfigurationError(
                f"profile_id cannot exceed {MAX_PROFILE_ID_LENGTH} characters"
            )
        elif not is_valid_uuid(profile_id):
            raise PayloadConfigurationError("Profile Id is not a valid UUID format")

        self.refresh_token_if_expired()

        try:
            self.logger.info(
                f"event={self.delete_ai_profile.__name__} profile_id={profile_id}"
            )
            response = self._api.delete_ai_profile(profile_id=profile_id.strip())
            return response
        except ApiException as e:
            error_msg = f"Failed to delete AI profile: {e}"
            self.logger.error(
                f"event={self.delete_ai_profile.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while deleting AI profile: {e}"
            self.logger.error(
                f"event={self.delete_ai_profile.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def force_delete_ai_profile(self, profile_id: str, updated_by: str) -> str:
        """Force delete an AI Security Profile by its ID, bypassing safety checks.

        Args:
            profile_id: The ID of the AI Security Profile to force delete.
            updated_by: Identifier of the user performing the force deletion.

        Returns:
            DeleteAIProfile200Response: Response object confirming the deletion operation.

        Raises:
            MgmtSdkClientError: If AI profile force deletion fails due to client error (4xx)
            MgmtSdkServerError: If AI profile force deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not profile_id or len(profile_id.strip()) == 0:
            raise PayloadConfigurationError(
                "profile_id is required and cannot be empty"
            )
        elif len(profile_id.strip()) > MAX_PROFILE_ID_LENGTH:
            raise PayloadConfigurationError(
                f"profile_id cannot exceed {MAX_PROFILE_ID_LENGTH} characters"
            )
        elif not is_valid_uuid(profile_id):
            raise PayloadConfigurationError("Profile Id is not a valid UUID format")
        if not updated_by or len(updated_by.strip()) == 0:
            raise PayloadConfigurationError(
                "updated_by is required and cannot be empty"
            )
        elif len(updated_by.strip()) > MAX_EMAIL_LENGTH:
            raise PayloadConfigurationError(
                f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
            )

        self.refresh_token_if_expired()

        try:
            self.logger.info(
                f"event={self.force_delete_ai_profile.__name__} profile_id={profile_id}"
            )
            response = self._api.force_delete_ai_profile(
                profile_id=profile_id.strip(), updated_by=updated_by.strip()
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to force delete AI profile: {e}"
            self.logger.error(
                f"event={self.force_delete_ai_profile.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while force deleting AI profile: {e}"
            self.logger.error(
                f"event={self.force_delete_ai_profile.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
