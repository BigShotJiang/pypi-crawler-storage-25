# Migration from rest-pysuggester EntityFishing to pyannotators_entityfishing

This document describes the migration from the `rest-pysuggester` `EntityFishingSuggester`
to the standalone `pyannotators_entityfishing` annotator plugin.

## Architecture change

The original implementation lived inside `rest-pysuggester` as a `Suggester` subclass
with tight coupling to MongoDB, the Sherpa training pipeline, and a shared resource
manager. The new implementation is a standalone `AnnotatorBase` plugin following the
`pymultirole_plugins` v1 contract.

### What was kept (upward-compatible)

| Feature | Original | New |
|---------|----------|-----|
| EntityFishing HTTP client | `ef_client.py` (env-var config) | `ef_client.py` (constructor params from `EntityFishingParameters`) |
| Disambiguation parameters | `minSelectorScore`, `maxTermFrequency` | Same field names and defaults |
| Label mapping | `mapped_labels` (dict of JSON mongoquery) | Same format, same `mongoquery` library |
| Default label | `default_label` | Same |
| Output label filtering | `output_labels` | Same |
| Fingerprinting | `fingerprint`, `wikidata_properties`, `multivalued_props` | Same |
| Chunking | `do_chunking` | Same |
| Short text mode | `short_text` | Same |
| Noun filtering | `noun_forms_only` (default True) | Same (default changed to False, spacy optional) |
| Overlap filtering | `filter_annotations` (longest match) | Same algorithm |
| Annotation output | `Annotation` with `Term(identifier=QID, lexicon="wikidata", ...)` | Same schema |
| Parallel requests | `requests-futures` / `FuturesSession` | Same |
| Caching | `requests-cache` / `CachedSession` | Same (disabled by default) |

### What changed

1. **No training pipeline**: The annotator is stateless. There is no `train_model_unsafe`
   or model persistence. The label classes are derived from `mapped_labels` +
   `default_label` + `output_labels` at annotation time.

2. **No MongoDB integration**: Documents are passed in and returned directly.

3. **No spacy by default**: `noun_forms_only` defaults to `False` (was `True`).
   When enabled, spacy is imported lazily and a language-specific model is loaded.
   Install spacy separately: `pip install pyannotators-entityfishing[spacy]`.

4. **Configuration via parameters**: The EntityFishing service URL, pool size, and
   caching settings are now fields on `EntityFishingParameters` instead of environment
   variables. This makes the annotator self-contained and testable.

5. **Classification mode not ported**: The `EntityFishingClassifierSuggester` and
   `EntityFishingDispatcherSuggester` were not ported. The classifier mode was
   incomplete in the original and can be added later if needed.

6. **Python 3.12+ / Pydantic v2**: Following the migration guide from
   `pyannotators_duckling`, the project uses modern Python type syntax and Pydantic v2.

## Parameter mapping reference

| Original `EntityFishingSequenceTrainParameters` | New `EntityFishingParameters` |
|--------------------------------------------------|-------------------------------|
| `minSelectorScore: float = 0.3` | `minSelectorScore: float = 0.3` |
| `maxTermFrequency: Optional[float]` | `maxTermFrequency: float \| None` |
| `mapped_labels: Dict[str, str]` | `mapped_labels: dict[str, str] \| None` |
| `default_label: Optional[str]` | `default_label: str \| None` |
| `output_labels: List[str]` | `output_labels: list[str] \| None` |
| `noun_forms_only: Optional[bool] = True` | `noun_forms_only: bool = False` |
| `fingerprint: Optional[str]` | `fingerprint: str \| None` |
| `wikidata_properties: Optional[str]` | `wikidata_properties: str \| None` |
| `do_chunking: Optional[bool] = False` | `do_chunking: bool = False` |
| `short_text: Optional[bool] = False` | `short_text: bool = False` |
| `multivalued_props: Optional[bool] = False` | `multivalued_props: bool = False` |
| *(env)* `APP_EF_URI` | `ef_uri: str` |
| *(env)* `APP_EF_CLIENT_POOLSIZE` | `ef_pool_size: int` |
| *(env)* `APP_EF_CLIENT_FULL` | `ef_full: bool` |

## Build and tooling

Following `pyannotators_duckling` MIGRATION.md:

- **Build system**: hatchling + uv
- **Python**: >=3.12
- **Pydantic**: v2
- **Linter**: ruff
- **Tests**: `uv run pytest`
- **CI**: Jenkinsfile with `uv sync --extra test`
