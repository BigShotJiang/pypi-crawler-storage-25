# TODO

- [ ] Reduce signal-check false positives and false negatives ([plan](docs/plans/002-handle-openalex-metadata-quirks.md))
- [x] Add bib-table command. Wide-table view of a `.bib` file with `key` + `entry_type` + fields as columns, polars output, `--csv` / `--fields` flags.
- [x] Absorb bib verification scripts into the package ([plan](docs/plans/001-absorb-bib-verification-scripts.md))
- [x] Add OpenAlex client and arXiv DOI routing as Crossref fallback ([plan](docs/plans/000-add-openalex-client.md))
