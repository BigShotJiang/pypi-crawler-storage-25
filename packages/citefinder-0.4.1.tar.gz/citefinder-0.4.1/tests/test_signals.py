"""Tests for citefinder.signals — signal checks and status reduction."""

from citefinder.signals import (
    BibCitation,
    Status,
    Work,
    check_author,
    check_container,
    check_title,
    check_year,
    compute_signals,
    container_similarity,
    normalize_title,
    status_from_signals,
    title_similarity,
)


def test_normalize_title_lowercases_and_strips_punctuation() -> None:
    assert normalize_title("Hello, World!") == "hello world"


def test_normalize_title_handles_unicode_diacritics() -> None:
    # NFKD decomposition + dropping combining marks: "café" → "cafe".
    assert normalize_title("Café Résumé") == "cafe resume"


def test_title_similarity_identical_is_one() -> None:
    assert title_similarity("Hello World", "Hello World") == 1.0


def test_title_similarity_disjoint_is_zero() -> None:
    assert title_similarity("Hello World", "Foo Bar") == 0.0


def test_title_similarity_empty_inputs() -> None:
    assert title_similarity("", "anything") == 0.0


def test_check_title_high_overlap_passes() -> None:
    r = check_title("A Study of Things", "A Study of Things")
    assert r["verdict"] == "pass"


def test_check_title_no_overlap_fails() -> None:
    r = check_title("Apples Oranges", "Bicycles Trucks")
    assert r["verdict"] == "fail"


def test_check_title_partial_is_unknown() -> None:
    # A 50% Jaccard overlap should land in the "unknown" band so we don't
    # punish source-side title truncation.
    r = check_title("foo bar baz", "foo bar")
    assert r["verdict"] == "unknown"


def test_check_title_missing_input_is_unknown() -> None:
    assert check_title(None, "Title")["verdict"] == "unknown"
    assert check_title("Title", None)["verdict"] == "unknown"


def test_check_year_exact_match() -> None:
    assert check_year("2020", 2020)["verdict"] == "pass"


def test_check_year_within_one_year_passes() -> None:
    # Tolerates preprint-vs-proceedings drift.
    assert check_year("2020", 2021)["verdict"] == "pass"
    assert check_year("2020", 2019)["verdict"] == "pass"


def test_check_year_far_off_fails() -> None:
    assert check_year("2020", 2018)["verdict"] == "fail"


def test_check_year_unparseable_is_unknown() -> None:
    assert check_year("forthcoming", 2020)["verdict"] == "unknown"
    assert check_year("2020", None)["verdict"] == "unknown"


def test_check_author_token_overlap_passes() -> None:
    # Compound surname on one side, single token on the other — token-overlap
    # rule lets these match.
    assert check_author("Larios Vargas", "Vargas")["verdict"] == "pass"


def test_check_author_no_overlap_fails() -> None:
    assert check_author("Smith", "Jones")["verdict"] == "fail"


def test_check_author_missing_is_unknown() -> None:
    assert check_author(None, "Smith")["verdict"] == "unknown"


def test_container_similarity_prefix_matches_abbreviations() -> None:
    # `proc` should match `proceedings` via the prefix rule.
    sim = container_similarity("Proc ICML", "Proceedings of ICML")
    assert sim > 0.0


def test_check_container_full_overlap_passes() -> None:
    r = check_container("Journal of Things", ["Journal of Things"])
    assert r["verdict"] == "pass"


def test_check_container_unrelated_fails() -> None:
    r = check_container("Nature", ["Annual Review of Sociology"])
    assert r["verdict"] == "fail"


def test_check_container_picks_best_alias() -> None:
    # Crossref returns multiple aliases; the check should pick the closest.
    r = check_container("Journal of Things", ["Random Other", "Journal of Things"])
    assert r["verdict"] == "pass"
    assert r["crossref"] == "Journal of Things"


def test_compute_signals_builds_all_four() -> None:
    cit = BibCitation(
        title="Paper",
        year="2020",
        first_author_surname="Smith",
        container="J",
    )
    work = Work(
        title="Paper",
        year=2020,
        first_author_surname="Smith",
        container_names=["J"],
    )
    signals = compute_signals(cit, work)
    assert set(signals) == {"title", "year", "author", "container"}
    assert all(s["verdict"] == "pass" for s in signals.values())


def _signals(verdicts: dict[str, str]) -> dict:
    return {
        k: {"verdict": v, "bib": None, "crossref": None} for k, v in verdicts.items()
    }


def test_status_from_signals_two_passes_is_matched() -> None:
    s, _ = status_from_signals(
        _signals(
            {
                "title": "pass",
                "year": "pass",
                "author": "unknown",
                "container": "unknown",
            }
        )
    )
    assert s == Status.MATCHED


def test_status_from_signals_one_fail_is_probable() -> None:
    s, note = status_from_signals(
        _signals(
            {"title": "pass", "year": "fail", "author": "pass", "container": "unknown"}
        )
    )
    assert s == Status.PROBABLE
    assert "year" in note


def test_status_from_signals_two_fails_is_mismatch() -> None:
    s, _ = status_from_signals(
        _signals(
            {"title": "fail", "year": "fail", "author": "pass", "container": "unknown"}
        )
    )
    assert s == Status.MISMATCH


def test_status_from_signals_all_unknown_is_probable() -> None:
    s, _ = status_from_signals(
        _signals(dict.fromkeys(["title", "year", "author", "container"], "unknown"))
    )
    assert s == Status.PROBABLE


def test_status_keeps_str_compatibility() -> None:
    # StrEnum guarantees: status values compare equal to their string form.
    assert Status.MATCHED == "matched"
    assert Status.MATCHED.header.startswith("Matched")
