from ...mixin import (
    ANTHROPIC_CHAT_MODELS,
    ANTHROPIC_REASONING_MODELS,
    CEREBRAS_CHAT_MODELS,
    CEREBRAS_REASONING_MODELS,
    DEEPSEEK_CHAT_MODELS,
    DEEPSEEK_REASONING_MODELS,
    GOOGLE_CHAT_MODELS,
    GOOGLE_REASONING_MODELS,
    GROQ_CHAT_MODELS,
    GROQ_REASONING_MODELS,
    OPENAI_CHAT_MODELS,
    OPENAI_REASONING_MODELS,
    OPENAI_RESPONSES_MODELS,
    OPENROUTER_CHAT_MODELS,
    OPENROUTER_REASONING_MODELS,
)
from .engine_anthropic_claudeX_chat import ClaudeXChatEngine
from .engine_anthropic_claudeX_reasoning import ClaudeXReasoningEngine
from .engine_cerebras import CerebrasEngine
from .engine_deepseekX_reasoning import DeepSeekXReasoningEngine
from .engine_google_geminiX_reasoning import GeminiXReasoningEngine
from .engine_groq import GroqEngine
from .engine_openai_gptX_chat import GPTXChatEngine
from .engine_openai_gptX_reasoning import GPTXReasoningEngine
from .engine_openai_responses import OpenAIResponsesEngine
from .engine_openrouter import OpenRouterEngine

# create the mapping
ENGINE_MAPPING = {
    **dict.fromkeys(ANTHROPIC_CHAT_MODELS, ClaudeXChatEngine),
    **dict.fromkeys(ANTHROPIC_REASONING_MODELS, ClaudeXReasoningEngine),
    **dict.fromkeys(CEREBRAS_CHAT_MODELS, CerebrasEngine),
    **dict.fromkeys(CEREBRAS_REASONING_MODELS, CerebrasEngine),
    **dict.fromkeys(DEEPSEEK_REASONING_MODELS, DeepSeekXReasoningEngine),
    **dict.fromkeys(GOOGLE_CHAT_MODELS, GeminiXReasoningEngine),
    **dict.fromkeys(GOOGLE_REASONING_MODELS, GeminiXReasoningEngine),
    **dict.fromkeys(OPENAI_CHAT_MODELS, GPTXChatEngine),
    **dict.fromkeys(OPENAI_REASONING_MODELS, GPTXReasoningEngine),
    **dict.fromkeys(OPENAI_RESPONSES_MODELS, OpenAIResponsesEngine),
    **dict.fromkeys(GROQ_CHAT_MODELS, GroqEngine),
    **dict.fromkeys(GROQ_REASONING_MODELS, GroqEngine),
    **dict.fromkeys(OPENROUTER_CHAT_MODELS, OpenRouterEngine),
    **dict.fromkeys(OPENROUTER_REASONING_MODELS, OpenRouterEngine),
}

__all__ = [
    "ANTHROPIC_CHAT_MODELS",
    "ANTHROPIC_REASONING_MODELS",
    "CEREBRAS_CHAT_MODELS",
    "CEREBRAS_REASONING_MODELS",
    "DEEPSEEK_CHAT_MODELS",
    "DEEPSEEK_REASONING_MODELS",
    "ENGINE_MAPPING",
    "GOOGLE_CHAT_MODELS",
    "GOOGLE_REASONING_MODELS",
    "GROQ_CHAT_MODELS",
    "GROQ_REASONING_MODELS",
    "OPENAI_CHAT_MODELS",
    "OPENAI_REASONING_MODELS",
    "OPENAI_RESPONSES_MODELS",
    "OPENROUTER_CHAT_MODELS",
    "OPENROUTER_REASONING_MODELS",
    "ClaudeXChatEngine",
    "ClaudeXReasoningEngine",
    "DeepSeekXReasoningEngine",
    "GPTXChatEngine",
    "GPTXReasoningEngine",
    "GeminiXReasoningEngine",
    "GroqEngine",
    "OpenAIResponsesEngine",
    "OpenRouterEngine",
]
