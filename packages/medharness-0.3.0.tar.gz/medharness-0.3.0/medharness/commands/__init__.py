"""CR command implementations."""
