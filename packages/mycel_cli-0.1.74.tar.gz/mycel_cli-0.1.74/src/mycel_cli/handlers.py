"""Command handlers for cel."""

from __future__ import annotations

import getpass
import os
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TextIO

from mycel_sdk.errors import ApiError

from .binding_resolver import BindingResolutionError, resolve_binding
from .config import CliConfig, effective_base_url, save_global_config
from .identity_store import IdentityStore
from .internal_hooks import (
    format_bootstrap_context,
    clear_hook_error_context,
    format_agent_guide,
    format_hook_error_context,
    hook_event_name,
    hook_output,
    read_hook_payload,
    should_emit_bootstrap_context,
    should_emit_hook_error_context,
    stop_block_output,
)
from .daemon.surfaces import claim_pending_from_env
from .daemon.sessions import bind_session
from .daemon.inbox_context import read_inbox_context
from .daemon.wake import record_rewake
from .providers.launcher import (
    build_provider_launch,
    format_provider_status,
    is_provider_status_request,
    provider_status,
    provider_status_json_requested,
)
from .providers.runtime_policy import provider_hook_runtime_policy
from .target_resolver import (
    MessageTarget,
    message_mentions,
    parse_message_target,
    resolve_message_target,
    resolved_target,
)
from .workflow_targets import resolve_chat_addressed_ref


@dataclass(frozen=True)
class HandlerContext:
    args: Any
    client: Any
    config: CliConfig
    stdin: TextIO
    stdout: TextIO


CommandHandler = Callable[[HandlerContext], Any]


@dataclass(frozen=True)
class RawOutput:
    text: str
    return_code: int = 0


@dataclass(frozen=True)
class ProcessRequest:
    command: list[str]
    env: dict[str, str]


def _resolve_login_password(args: Any, stdin: TextIO) -> str:
    if args.password_stdin:
        password = stdin.readline().rstrip("\r\n")
        if not password:
            raise RuntimeError("stdin password is required")
        return password
    return getpass.getpass("Password: ")


def _current_binding(provider: str | None, *, allow_cwd: bool = True) -> dict[str, Any]:
    return resolve_binding(
        store=IdentityStore.from_env(),
        cwd=Path.cwd(),
        provider=provider,
        interactive=False,
        allow_cwd=allow_cwd,
    )


def _login(ctx: HandlerContext) -> Any:
    if getattr(ctx.args, "guest", False):
        return _guest(ctx)
    if not getattr(ctx.args, "identifier", None):
        raise RuntimeError("login requires an owner identifier or --guest")
    result = ctx.client.auth.login(
        ctx.args.identifier, _resolve_login_password(ctx.args, ctx.stdin)
    )
    if not isinstance(result, dict) or not result.get("token"):
        raise RuntimeError("login did not return a token")
    user = result.get("user") if isinstance(result.get("user"), dict) else {}
    local_id = str(user.get("id") or ctx.args.identifier)
    IdentityStore.from_env().save_user(
        local_id,
        base_url=ctx.config.base_url,
        auth_token=str(result["token"]),
    )
    public = dict(result)
    public["token"] = "<redacted>"
    if ctx.args.json:
        return public
    return RawOutput(
        _format_owner_login(
            user_id=local_id,
            base_url=ctx.config.base_url,
        )
    )


def _guest(ctx: HandlerContext) -> Any:
    token = str(getattr(ctx.args, "token", "") or "").strip()
    if token:
        return _guest_from_token(ctx, token)
    result = ctx.client.auth.create_guest_owner(display_name=ctx.args.name)
    if not isinstance(result, dict) or not result.get("token"):
        raise RuntimeError("guest owner creation did not return a token")
    user = result.get("user") if isinstance(result.get("user"), dict) else {}
    local_id = str(user.get("id") or "").strip()
    if not local_id:
        raise RuntimeError("guest owner creation did not return a user id")
    IdentityStore.from_env().save_user(
        local_id,
        base_url=ctx.config.base_url,
        auth_token=str(result["token"]),
    )
    public = dict(result)
    public["token"] = "<redacted>"
    if ctx.args.json:
        return public
    return RawOutput(
        _format_owner_login(
            title="Guest owner saved",
            user_id=local_id,
            base_url=ctx.config.base_url,
        )
    )


def _guest_from_token(ctx: HandlerContext, token: str) -> Any:
    if getattr(ctx.args, "name", None):
        raise RuntimeError("--name is only valid when creating a new guest owner")
    try:
        result = ctx.client.me.whoami()
    except ApiError as exc:
        if exc.is_transport_error:
            raise RuntimeError(_format_guest_token_transport_error(ctx.config)) from exc
        raise
    if not isinstance(result, dict):
        raise RuntimeError("guest token validation did not return a user")
    if not result.get("is_guest"):
        raise RuntimeError("provided token is not a restricted guest owner token")
    local_id = str(result.get("id") or "").strip()
    if not local_id:
        raise RuntimeError("guest token validation did not return a user id")
    IdentityStore.from_env().save_user(
        local_id,
        base_url=ctx.config.base_url,
        auth_token=token,
    )
    public = {"token": "<redacted>", "user": result}
    if ctx.args.json:
        return public
    return RawOutput(
        _format_owner_login(
            title="Guest owner token saved",
            user_id=local_id,
            base_url=ctx.config.base_url,
        )
    )


def _format_guest_token_transport_error(config: CliConfig) -> str:
    proxy = config.proxy or "(none)"
    return (
        "Could not validate the guest token against the Mycel backend.\n"
        f"Backend: {config.base_url}\n"
        f"Proxy: {proxy}\n"
        "Check that this machine can reach the backend. If it needs an explicit "
        "host proxy, run: cel self connect <backend-url> --proxy <proxy-url>\n"
        "For a one-off retry, run: cel login --guest --token <token> --base-url <backend-url>"
    )


def _logout(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    if ctx.args.all_local:
        store.clear_users()
        result = {"current_user_id": None, "users": []}
        if ctx.args.json:
            return result
        return RawOutput("All local owner logins cleared.\n")
    store.clear_current_user()
    result = {"current_user_id": None}
    if ctx.args.json:
        return result
    return RawOutput("Current owner login cleared.\n")


def _connect(ctx: HandlerContext) -> Any:
    info = ctx.client.backend_info()
    if not isinstance(info, dict):
        raise RuntimeError("backend probe did not return a JSON object")
    base_url = str(info.get("base_url") or ctx.config.base_url).strip().rstrip("/")
    if not base_url:
        raise RuntimeError("backend probe did not return a base URL")
    payload = {"base_url": base_url}
    if ctx.config.proxy:
        payload["proxy"] = ctx.config.proxy
    if getattr(ctx.args, "clear_proxy", False):
        payload["proxy"] = None
    save_global_config(payload)
    public = dict(info)
    public["base_url"] = base_url
    if ctx.config.proxy:
        public["proxy"] = ctx.config.proxy
    if ctx.args.json:
        return public
    return RawOutput(_format_backend_connection(public))


def _format_backend_connection(info: dict[str, Any]) -> str:
    capabilities = (
        info.get("capabilities") if isinstance(info.get("capabilities"), dict) else {}
    )
    enabled = [
        name
        for name in ("guest_auth", "external_users", "chat_messages", "runtime_inbox")
        if capabilities.get(name)
    ]
    capability_line = ", ".join(enabled) if enabled else "none reported"
    lines = [
        "Mycel backend connected",
        "",
        f"Backend: {info.get('base_url')}",
        f"Proxy: {info.get('proxy') or '(none)'}",
    ]
    if info.get("title"):
        lines.append(f"Title: {info['title']}")
    if info.get("version"):
        lines.append(f"Version: {info['version']}")
    lines.extend(
        [
            f"Capabilities: {capability_line}",
            "",
            "Next: cel login --guest",
        ]
    )
    return "\n".join(lines) + "\n"


def _agent_guide(ctx: HandlerContext) -> Any:
    provider = str(
        getattr(ctx.args, "provider", None) or os.getenv("MYCEL_PROVIDER") or ""
    )
    if provider not in {"codex", "claude"}:
        provider = "codex"
    store = IdentityStore.from_env()
    owner_user_id = store.current_user_id()
    try:
        binding = resolve_binding(
            store=store,
            cwd=Path.cwd(),
            provider=provider,
            interactive=False,
        )
        return RawOutput(
            format_agent_guide(
                provider=provider,
                owner_user_id=owner_user_id,
                resolved_local_id=str(binding["local_id"]),
                backend=effective_base_url(),
            )
        )
    except BindingResolutionError as exc:
        multiple_local_ids = list(exc.candidates) if exc.reason == "multiple" else None
    return RawOutput(
        format_agent_guide(
            provider=provider,
            owner_user_id=owner_user_id,
            multiple_local_ids=multiple_local_ids,
            backend=effective_base_url(),
        )
    )


def _format_owner_login(
    *, user_id: str, base_url: str, title: str = "Owner login saved"
) -> str:
    return (
        f"{title}\n\n"
        f"User ID: {user_id}\n"
        f"Backend: {base_url}\n\n"
        "Use --json for machine-readable login result.\n"
    )


def _agent_show(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    binding = _current_binding(None)
    public_identity = store.public_identity(str(binding["local_id"]))
    current_user = ctx.client.me.whoami()
    if not isinstance(current_user, dict):
        raise RuntimeError("current identity did not resolve to a backend user")
    user_id = str(current_user.get("id") or "")
    display_name = str(current_user.get("name") or "")
    if not user_id:
        raise RuntimeError("current backend user is missing id")
    if not display_name:
        raise RuntimeError("current backend user is missing name")
    local_user_id = str(public_identity.get("user_id") or "")
    if local_user_id and local_user_id != user_id:
        raise RuntimeError(
            f"local identity {public_identity['local_id']} resolves to backend user {user_id}, "
            f"not {local_user_id}"
        )
    store.update_identity(
        str(binding["local_id"]),
        user_id=user_id,
        display_name=display_name,
    )
    public_identity["user_id"] = user_id
    public_identity["display_name"] = display_name
    if ctx.args.json:
        return public_identity
    return RawOutput(
        _format_current_agent_identity("Current agent identity", public_identity)
    )


def _format_current_agent_identity(title: str, identity: dict[str, Any]) -> str:
    lines = [title, ""]
    fields = [
        ("Local ID", identity.get("local_id")),
        ("Provider", identity.get("provider")),
        ("Name", identity.get("display_name") or identity.get("local_display_name")),
        ("User ID", identity.get("user_id")),
        ("Owner", identity.get("created_by_user_id")),
        ("Backend", identity.get("base_url")),
    ]
    for label, value in fields:
        if value:
            lines.append(f"{label}: {value}")
    lines.extend(["", "Use --json for machine-readable identity."])
    return "\n".join(lines) + "\n"


def _agent_external_create(ctx: HandlerContext) -> Any:
    created = ctx.client.users.create_external(
        user_id=ctx.args.local_id,
        display_name=ctx.args.name,
    )
    if not isinstance(created, dict) or not created.get("token"):
        raise RuntimeError("external agent identity creation did not return a token")
    external_user = created.get("user") if isinstance(created.get("user"), dict) else {}
    user_id = str(external_user.get("id") or ctx.args.local_id)
    store = IdentityStore.from_env()
    store.save_identity(
        local_id=ctx.args.local_id,
        provider=ctx.args.provider,
        base_url=ctx.config.base_url,
        auth_token=str(created["token"]),
        user_id=user_id,
        display_name=ctx.args.name,
        created_by_user_id=store.current_user_id(),
    )
    store.add_cwd_identity(Path.cwd(), ctx.args.local_id)
    session_id = os.getenv("MYCEL_SESSION_ID")
    if session_id:
        bind_session(session_id, ctx.args.local_id)
    claim_pending_from_env(ctx.args.local_id, os.environ)
    public_identity = store.public_identity(ctx.args.local_id)
    if ctx.args.json:
        return {
            "user": external_user,
            "identity": public_identity,
        }
    return RawOutput(
        _format_current_agent_identity("Agent identity created", public_identity)
    )


def _agent_external_list(ctx: HandlerContext) -> Any:
    rows = [
        _local_identity_inventory_row(identity)
        for identity in IdentityStore.from_env().public_identities()
    ]
    if ctx.args.json:
        return rows
    return RawOutput(_format_external_identity_list(rows))


def _agent_external_remove(ctx: HandlerContext) -> Any:
    removed = IdentityStore.from_env().remove_identity(ctx.args.local_id)
    if removed.get("auth_token"):
        removed["auth_token"] = "<redacted>"
    row = _local_identity_inventory_row(removed)
    if ctx.args.json:
        return row
    return RawOutput(_format_current_agent_identity("Agent identity removed", row))


def _agent_external_unbind(ctx: HandlerContext) -> Any:
    path = Path(ctx.args.path).expanduser() if ctx.args.path else Path.cwd()
    unbound = IdentityStore.from_env().unbind_cwd_identity(path, ctx.args.local_id)
    return {
        "local_id": ctx.args.local_id,
        "path": str(path.resolve()),
        "unbound": unbound,
    }


def _agent_external_cleanup(ctx: HandlerContext) -> Any:
    return IdentityStore.from_env().cleanup_local_identity_state()


def _local_identity_inventory_row(identity: dict[str, Any]) -> dict[str, Any]:
    row = dict(identity)
    local_display_name = row.pop("display_name", None)
    if local_display_name is not None:
        row["local_display_name"] = local_display_name
    return row


def _format_external_identity_list(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return (
            "Local agent identities: none\n\n"
            "Create one after owner login:\n"
            '  cel agent external create codex-a --name "Codex A" --provider codex\n'
            "\n"
            "Use --json for machine-readable local inventory.\n"
        )

    lines = ["Local agent identities"]
    for row in rows:
        local_id = str(row["local_id"])
        provider = str(row["provider"])
        lines.extend(
            [
                "",
                f"- {local_id}",
                f"  Provider: {provider}",
            ]
        )
        display_name = row.get("local_display_name")
        if display_name:
            lines.append(f"  Name: {display_name}")
        user_id = row.get("user_id")
        if user_id:
            lines.append(f"  User ID: {user_id}")
        owner = row.get("created_by_user_id")
        if owner:
            lines.append(f"  Owner: {owner}")
        base_url = row.get("base_url")
        if base_url:
            lines.append(f"  Backend: {base_url}")

    lines.extend(["", "Use --json for machine-readable local inventory."])
    return "\n".join(lines) + "\n"


def _send_message(ctx: HandlerContext) -> Any:
    store = IdentityStore.from_env()
    content = _message_content_from_args(ctx.args)
    target = resolve_message_target(
        parse_message_target(ctx.args.target),
        store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    chat_id = _send_chat_id(ctx.client, target)
    mentioned_user_ids = message_mentions(
        target,
        ctx.args.mentions,
        store=store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    workflow_refs: list[str] = []
    target_addressed_user_ids: list[str] = []
    target_addressed_local_ids: list[str] = []
    if target.addressed_user_id:
        addressed_resolution = resolve_chat_addressed_ref(
            ctx.client,
            chat_id=chat_id,
            user_ref=target.addressed_user_id,
            store=store,
            owner_user_id=ctx.config.created_by_user_id,
        )
        if addressed_resolution.user_id:
            target_addressed_user_ids.append(addressed_resolution.user_id)
        if addressed_resolution.local_id:
            target_addressed_local_ids.append(addressed_resolution.local_id)
        if addressed_resolution.workflow_ref:
            workflow_refs.append(addressed_resolution.workflow_ref)
    (
        explicit_addressed_user_ids,
        explicit_addressed_local_ids,
        explicit_workflow_refs,
    ) = _resolve_addressed_refs(
        ctx.client,
        chat_id=chat_id,
        user_refs=ctx.args.addressed_to,
        store=store,
        owner_user_id=ctx.config.created_by_user_id,
    )
    workflow_refs.extend(explicit_workflow_refs)
    addressed_to_user_ids = list(
        dict.fromkeys([*target_addressed_user_ids, *explicit_addressed_user_ids])
    )
    addressed_local_ids = list(
        dict.fromkeys([*target_addressed_local_ids, *explicit_addressed_local_ids])
    )
    send_kwargs = {
        "reply_to": ctx.args.reply_to,
        "mentions": mentioned_user_ids,
    }
    if addressed_to_user_ids:
        send_kwargs["delivery_scope"] = "addressed"
        send_kwargs["addressed_to_user_ids"] = addressed_to_user_ids
    message = ctx.client.messages.send(chat_id, content, **send_kwargs)
    payload = {
        "resolved": resolved_target(
            target,
            chat_id=chat_id,
            mentioned_user_ids=mentioned_user_ids,
            addressed_to_user_ids=(
                addressed_to_user_ids if addressed_to_user_ids else None
            ),
            addressed_resolved_from_local_ids=addressed_local_ids,
            addressed_resolved_from_workflow_refs=workflow_refs,
        ),
        "message": message,
    }
    if ctx.args.json:
        return payload
    return RawOutput(_format_send_message_result(payload))


def _resolve_addressed_refs(
    client: Any,
    *,
    chat_id: str,
    user_refs: list[str],
    store: IdentityStore,
    owner_user_id: str | None,
) -> tuple[list[str], list[str], list[str]]:
    user_ids: list[str] = []
    local_ids: list[str] = []
    workflow_refs: list[str] = []
    for user_ref in user_refs:
        resolved = resolve_chat_addressed_ref(
            client,
            chat_id=chat_id,
            user_ref=user_ref,
            store=store,
            owner_user_id=owner_user_id,
        )
        if resolved.user_id:
            user_ids.append(resolved.user_id)
        if resolved.local_id:
            local_ids.append(resolved.local_id)
        if resolved.workflow_ref:
            workflow_refs.append(resolved.workflow_ref)
    return (
        list(dict.fromkeys(user_ids)),
        list(dict.fromkeys(local_ids)),
        list(dict.fromkeys(workflow_refs)),
    )


def _message_content_from_args(args: Any) -> str:
    content = args.content
    content_file = args.content_file
    if content is not None and content_file:
        raise RuntimeError("send-message accepts either CONTENT or --file, not both")
    if content_file:
        path = Path(str(content_file)).expanduser()
        if not path.is_file():
            raise RuntimeError(f"message file not found: {path}")
        text = path.read_text(encoding="utf-8")
    elif content is not None:
        text = str(content)
    else:
        raise RuntimeError("send-message requires CONTENT or --file")
    if not text.strip():
        raise RuntimeError("send-message content cannot be empty")
    return text


def _read_message(ctx: HandlerContext) -> Any:
    target = resolve_message_target(
        parse_message_target(ctx.args.target, allow_chat_mention=False),
        IdentityStore.from_env(),
        owner_user_id=ctx.config.created_by_user_id,
    )
    chat_id = _read_chat_id(ctx.client, target)
    if ctx.args.last is not None:
        messages = ctx.client.messages.list(
            chat_id,
            limit=ctx.args.last,
            before=ctx.args.before,
        )
    else:
        messages = ctx.client.messages.read(chat_id)
    payload = {
        "resolved": resolved_target(target, chat_id=chat_id),
        "messages": messages,
    }
    if ctx.args.json:
        return payload
    return RawOutput(
        _format_read_message_result(payload, peek=ctx.args.last is not None)
    )


def _format_send_message_result(payload: dict[str, Any]) -> str:
    resolved = payload["resolved"]
    message = payload["message"] if isinstance(payload["message"], dict) else {}
    lines = ["Message sent", ""]
    _append_resolved_message_target(lines, resolved)
    message_id = message.get("id")
    if message_id:
        lines.append(f"Message ID: {message_id}")
    seq = message.get("seq")
    if seq is not None:
        lines.append(f"Seq: {seq}")
    lines.extend(["", "Use --json for machine-readable send result."])
    return "\n".join(lines) + "\n"


def _format_read_message_result(payload: dict[str, Any], *, peek: bool) -> str:
    resolved = payload["resolved"]
    messages = payload["messages"] if isinstance(payload["messages"], list) else []
    title = "Messages (peek)" if peek else "Messages"
    lines = [title, ""]
    _append_resolved_message_target(lines, resolved)
    lines.extend([f"Count: {len(messages)}", ""])
    if not messages:
        lines.append("(none)")
    for message in messages:
        if not isinstance(message, dict):
            lines.append(str(message))
            continue
        prefix = _message_prefix(message)
        content = str(message.get("content") or "")
        lines.append(f"{prefix} {content}".rstrip())
    lines.extend(["", "Use --json for machine-readable read result."])
    return "\n".join(lines) + "\n"


def _append_resolved_message_target(lines: list[str], resolved: dict[str, Any]) -> None:
    target_type = resolved.get("target_type")
    if target_type:
        lines.append(f"Target: {target_type}")
    chat_id = resolved.get("chat_id")
    if chat_id:
        lines.append(f"Chat ID: {chat_id}")
    user_id = resolved.get("user_id")
    if user_id:
        lines.append(f"User ID: {user_id}")
    local_id = resolved.get("resolved_from_local_id")
    if local_id:
        lines.append(f"Resolved from local ID: {local_id}")
    mentioned = resolved.get("mentioned_user_ids")
    if mentioned:
        lines.append(f"Mentioned user IDs: {', '.join(map(str, mentioned))}")
    addressed = resolved.get("addressed_to_user_ids")
    if addressed:
        lines.append(f"Addressed user IDs: {', '.join(map(str, addressed))}")
    workflow_refs = resolved.get("addressed_resolved_from_workflow_refs")
    if workflow_refs:
        lines.append(f"Addressed workflow refs: {', '.join(map(str, workflow_refs))}")


def _message_prefix(message: dict[str, Any]) -> str:
    seq = message.get("seq")
    sender = message.get("sender_id") or message.get("sender_name") or "unknown"
    if seq is not None:
        return f"[{seq}] {sender}"
    created = message.get("created_at")
    if created is not None:
        return f"[{created}] {sender}"
    return str(sender)


def _send_chat_id(client: Any, target: MessageTarget) -> str:
    if target.kind == "chat":
        return _require_id(target.chat_id, label="chat target")
    chat = client.chats.ensure_direct(_require_id(target.user_id, label="user target"))
    return _chat_id_from_payload(chat)


def _read_chat_id(client: Any, target: MessageTarget) -> str:
    if target.kind == "chat":
        return _require_id(target.chat_id, label="chat target")
    chat = client.chats.direct(_require_id(target.user_id, label="user target"))
    return _chat_id_from_payload(chat)


def _chat_id_from_payload(payload: Any) -> str:
    if not isinstance(payload, dict):
        raise RuntimeError("chat response missing id")
    chat_id = str(payload.get("id") or payload.get("chat_id") or "").strip()
    if not chat_id:
        raise RuntimeError("chat response missing id")
    return chat_id


def _require_id(value: str | None, *, label: str) -> str:
    value = str(value or "").strip()
    if not value:
        raise RuntimeError(f"{label} is empty")
    return value


def _relationships_list(ctx: HandlerContext) -> Any:
    rows = ctx.client.relationships.list()
    if ctx.args.json:
        return rows
    return RawOutput(_format_relationship_list(rows))


def _relationships_request(ctx: HandlerContext) -> Any:
    result = ctx.client.relationships.request(
        ctx.args.target_user_id,
        message=ctx.args.message,
    )
    if ctx.args.json:
        return result
    return RawOutput(_format_relationship_result("Contact request sent", result))


def _relationships_action(ctx: HandlerContext) -> Any:
    action = getattr(ctx.client.relationships, ctx.args.relationship_command)
    result = action(ctx.args.relationship_id)
    if ctx.args.json:
        return result
    title = {
        "approve": "Contact request approved",
        "reject": "Contact request rejected",
    }[ctx.args.relationship_command]
    return RawOutput(_format_relationship_result(title, result))


def _format_relationship_list(rows: Any) -> str:
    relationships = rows if isinstance(rows, list) else []
    lines = ["Contacts", "", f"Count: {len(relationships)}", ""]
    if not relationships:
        lines.append("(none)")
    for row in relationships:
        lines.extend(["", *_relationship_lines(row)])
    lines.extend(["", "Use --json for machine-readable contacts."])
    return "\n".join(lines) + "\n"


def _format_relationship_result(title: str, row: Any) -> str:
    lines = [title, "", *_relationship_lines(row), ""]
    lines.append("Use --json for machine-readable contact result.")
    return "\n".join(lines) + "\n"


def _relationship_lines(row: Any) -> list[str]:
    if not isinstance(row, dict):
        return [str(row)]
    labels = {
        "id": "Contact ID",
        "state": "State",
        "user_id": "User ID",
        "target_user_id": "User ID",
        "direction": "Direction",
        "message": "Message",
    }
    return [
        f"{label}: {row[key]}"
        for key, label in labels.items()
        if row.get(key) is not None
    ]


def _provider_launch(ctx: HandlerContext) -> Any:
    provider_args = list(ctx.args.provider_args)
    if is_provider_status_request(provider_args):
        status = provider_status(
            provider=ctx.args.command,
            cwd=Path.cwd(),
        )
        if provider_status_json_requested(provider_args):
            return status
        return RawOutput(format_provider_status(status))
    launch = build_provider_launch(
        provider=ctx.args.command,
        provider_args=provider_args,
        cwd=Path.cwd(),
        stdin=ctx.stdin,
        stdout=ctx.stdout,
    )
    return ProcessRequest(command=launch.command, env=launch.env)


def _internal_hook(ctx: HandlerContext) -> RawOutput:
    hook_payload = read_hook_payload(ctx.stdin)
    event_name = hook_event_name(hook_payload)
    policy = provider_hook_runtime_policy(ctx.args.provider)
    try:
        binding = _current_binding(ctx.args.provider, allow_cwd=False)
    except BindingResolutionError as exc:
        if exc.reason == "missing" and os.getenv("MYCEL_PROVIDER") == ctx.args.provider:
            if not should_emit_bootstrap_context(
                provider=ctx.args.provider,
                event_name=event_name,
            ):
                return RawOutput("")
            context = format_bootstrap_context(
                ctx.args.provider,
                cli_command=os.getenv("MYCEL_CLI_COMMAND"),
                owner_user_id=IdentityStore.from_env().current_user_id(),
                backend=effective_base_url(),
            )
            return RawOutput(
                hook_output(
                    event_name,
                    context,
                    include_continue=policy.include_continue,
                )
            )
        return RawOutput("")
    bootstrap_daemon_unavailable_context = _bootstrap_daemon_unavailable_context(
        ctx.args.provider,
        str(binding["local_id"]),
    )
    if policy.blocks_event(event_name):
        if hook_payload.get("stop_hook_active") is True:
            return RawOutput("")
        if ctx.args.rewake:
            context = _hook_context_from_cache(
                str(binding["local_id"]),
                daemon_unavailable_context=bootstrap_daemon_unavailable_context,
            )
            if context:
                record_rewake(str(binding["local_id"]))
            return RawOutput(context, return_code=2 if context else 0)
        context = _hook_context_from_cache(
            str(binding["local_id"]),
            daemon_unavailable_context=bootstrap_daemon_unavailable_context,
        )
        return RawOutput(stop_block_output(context))
    try:
        context = _hook_context_from_cache(
            str(binding["local_id"]),
            daemon_unavailable_context=bootstrap_daemon_unavailable_context,
        )
        clear_hook_error_context()
    except RuntimeError as exc:
        if should_emit_hook_error_context(exc, local_id=str(binding["local_id"])):
            context = format_hook_error_context(exc, local_id=str(binding["local_id"]))
        else:
            context = ""
    return RawOutput(
        hook_output(event_name, context, include_continue=policy.include_continue)
    )


def _bootstrap_daemon_unavailable_context(provider: str, local_id: str) -> str | None:
    if os.getenv("MYCEL_PROVIDER") != provider:
        return None
    if not os.getenv("MYCEL_SESSION_ID"):
        return None
    return format_bootstrap_context(
        provider,
        cli_command=os.getenv("MYCEL_CLI_COMMAND"),
        resolved_local_id=local_id,
        backend=effective_base_url(),
    )


def _hook_context_from_cache(
    local_id: str, *, daemon_unavailable_context: str | None = None
) -> str:
    return read_inbox_context(
        local_id,
        daemon_unavailable_context=daemon_unavailable_context,
    )


def handle_command(
    *,
    args: Any,
    handler: CommandHandler,
    client: Any,
    config: CliConfig,
    stdin: TextIO,
    stdout: TextIO,
) -> Any:
    return handler(
        HandlerContext(
            args=args,
            client=client,
            config=config,
            stdin=stdin,
            stdout=stdout,
        )
    )
