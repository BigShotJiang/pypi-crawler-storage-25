"""Terminal abstraction layer for Mycel CLI local wake surfaces.

Group-container model: one group shares a single terminal container
(window / workspace / session). Users are spawned *inside* that
container at role-aware locations.

The container ref is persisted on the group
(``group["terminal_container"]``); backends introspect the live terminal
state (iterate windows by title, list workspaces by id, …) to resolve the
container for subsequent spawns. There is NO in-process cache in the
backend — state is the single source of truth.

Freeform provider wake reuses the same backend implementations for verified
runtime surfaces, but it does not imply every freeform backend is a group
orchestration backend.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Mapping, Protocol, runtime_checkable

DEFAULT_TERMINAL = "cmux"
TERMINAL_CHOICES = ("cmux", "tmux", "terminal", "kitty", "iterm2")
VALID_TERMINALS = frozenset(TERMINAL_CHOICES)
FREEFORM_TERMINAL_CHOICES = ("tmux", "cmux", "kitty", "ghostty")

_TERMINAL_PREREQUISITES = {
    "cmux": "CMUX: Settings → Socket Control → set to 'Automation Mode'",
    "tmux": "TMUX: no prerequisites",
    "terminal": "Terminal.app: System Settings → Privacy → Automation and Accessibility (grant permission to your shell/terminal)",
    "kitty": "Kitty: add 'allow_remote_control yes' and 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf",
    "iterm2": "iTerm2: enable Python API, then grant Automation permission to your shell/terminal to control iTerm2",
    "ghostty": "Ghostty: run from a healthy GUI window; Ghostty's native scripting dictionary must expose windows/terminals and allow input text/send key",
}

PlacementSlot = Literal["primary", "right", "down", "next"]


@dataclass(frozen=True)
class TerminalPlacement:
    slot: PlacementSlot
    title: str
    anchor_title: str | None = None


def terminal_choices() -> tuple[str, ...]:
    return TERMINAL_CHOICES


def freeform_terminal_choices() -> tuple[str, ...]:
    return FREEFORM_TERMINAL_CHOICES


def terminal_choices_text(*, separator: str = ", ") -> str:
    return separator.join(terminal_choices())


def _known_terminal_choices_text() -> str:
    return ", ".join(dict.fromkeys(TERMINAL_CHOICES + FREEFORM_TERMINAL_CHOICES))


def terminal_prerequisite(terminal_type: str) -> str:
    return _TERMINAL_PREREQUISITES[terminal_type]


def freeform_terminal_type_from_env(env: Mapping[str, str]) -> str | None:
    if env.get("TMUX"):
        return "tmux"
    if env.get("CMUX_SURFACE_ID"):
        return "cmux"
    if env.get("KITTY_WINDOW_ID"):
        return "kitty"
    if env.get("TERM_PROGRAM") == "ghostty":
        return "ghostty"
    return None


@runtime_checkable
class Terminal(Protocol):
    def ensure_group_container(self, group_id: str) -> str:
        """Create or return the backend-specific container for this group.

        Idempotent: first call creates the container (window/workspace/session);
        subsequent calls return the same ref. Backend may introspect its own
        live state (e.g. iterate windows by title) rather than caching in-process.
        """
        ...

    def spawn_in_container(
        self,
        container_ref: str,
        placement: TerminalPlacement,
        cwd: str,
        cmd: str,
    ) -> str:
        """Spawn a new surface inside the container at a layout placement.

        Args:
            container_ref: the container handle returned by
                ``ensure_group_container``.
            placement: terminal-layout slot plus display title. Workflow role
                names are mapped by the workflow preset before this layer.
            cwd: working directory for the spawned process.
            cmd: shell command to run.
        """
        ...

    def close_group_container(self, container_ref: str) -> None:
        """Close the entire container (all panes/tabs within).

        Best-effort: callers may swallow errors. Implementations should not
        raise for "already closed" situations.
        """
        ...

    def send_text(self, target_id: str, text: str) -> None:
        """Send text followed by Enter to the session."""
        ...

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session. key values: 'escape', 'enter', 'ctrl-c'."""
        ...

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content of the session."""
        ...

    def close(self, target_id: str) -> None:
        """Close/kill the session."""
        ...

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        """Discover a running process's target_id by introspecting the OS (env vars, etc).
        Returns None if this terminal does not support live discovery (target_id is
        only known at spawn time and must come from the user cache)."""
        ...

    def resolve_target_id_from_env(
        self,
        env: Mapping[str, str],
        *,
        pid: int,
        local_id: str | None = None,
    ) -> str | None:
        """Discover the current target from a launch/hook environment if available."""
        ...


def _default_factory(terminal_type: str) -> Terminal:
    match terminal_type:
        case "cmux":
            from mycel_cli.group.terminals.cmux import CmuxTerminal

            return CmuxTerminal()
        case "tmux":
            from mycel_cli.group.terminals.tmux import TmuxTerminal

            return TmuxTerminal()
        case "terminal":
            from mycel_cli.group.terminals.terminal_app import TerminalAppTerminal

            return TerminalAppTerminal()
        case "kitty":
            from mycel_cli.group.terminals.kitty import KittyTerminal

            return KittyTerminal()
        case "iterm2":
            from mycel_cli.group.terminals.iterm2 import ITerm2Terminal

            return ITerm2Terminal()
        case "ghostty":
            from mycel_cli.group.terminals.ghostty import GhosttyTerminal

            return GhosttyTerminal()
        case _:
            raise ValueError(
                f"Unknown terminal type: {terminal_type!r}. Choose from: {_known_terminal_choices_text()}"
            )


_factory = _default_factory


def get_terminal(terminal_type: str) -> Terminal:
    """Factory: return Terminal implementation for the given type.

    Delegates to the module-level ``_factory`` so tests can swap in a fake by
    monkeypatching ``mycel_cli.group.terminal._factory`` — works regardless of how callers
    imported ``get_terminal`` (``from mycel_cli.group.terminal import get_terminal`` binds
    the function object, but the function still looks up ``_factory`` at call
    time, so the patch takes effect everywhere).
    """
    return _factory(terminal_type)
