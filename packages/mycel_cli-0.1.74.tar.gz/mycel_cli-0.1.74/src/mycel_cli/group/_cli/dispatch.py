"""Group-scoped dispatch: `cel group <group_id> <resource> <command> ...`.

Routes to the per-resource module (`dispatch_task`, `dispatch_worker`,
`dispatch_supervisor`, `dispatch_reviewer`) after loading the group.
"""

from __future__ import annotations

import typer

from mycel_cli.group._cli import (
    dispatch_reviewer,
    dispatch_supervisor,
    dispatch_task,
    dispatch_worker,
)
from mycel_cli.group._cli.helpers import require_global, require_group_by_name
from mycel_cli.group._cli.workflow_participants import KEEP_PRESET
from mycel_cli.group._state.config import (
    default_terminal_global,
    workers_enabled_global,
)
from mycel_cli.group._state.groups import load_group
from mycel_cli.group._state.workflow import (
    ensure_workflow,
    get_header,
    group_from_header,
    mirror_header,
)

_RESOURCE_DISPATCHERS = {
    "task": dispatch_task.dispatch,
    "worker": dispatch_worker.dispatch,
    "supervisor": dispatch_supervisor.dispatch,
    "reviewer": dispatch_reviewer.dispatch,
}

_KEEP_WORKFLOW_COMMANDS = {
    "task": frozenset({"create", "update", "remove"}),
    "worker": frozenset({"create", "update", "remove"}),
    "supervisor": frozenset({"create", "update", "remove"}),
    "reviewer": frozenset({"create", "update", "remove"}),
}


def dispatch_group_scoped(group_id: str, args: list[str]) -> None:
    if not args:
        typer.echo(f"Group '{group_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    require_global()
    resource = args[0]
    command = args[1] if len(args) > 1 else None
    payload = args[2:]
    group = _load_scoped_group(group_id, resource=resource, command=command)
    if _needs_keep_workflow(resource, command):
        header = ensure_workflow(
            group_id,
            terminal_type=str(group.get("terminal_type") or default_terminal_global()),
            workers_enabled=bool(
                group.get("workers_enabled")
                if group.get("workers_enabled") is not None
                else workers_enabled_global()
            ),
            preset=KEEP_PRESET,
            state=str(group.get("status") or "stopped"),
        )
        group = mirror_header(group_id, header)

    dispatcher = _RESOURCE_DISPATCHERS.get(resource)
    if dispatcher is None:
        typer.echo(f"No such command '{resource}'", err=True)
        raise typer.Exit(2)
    dispatcher(group_id, group, command, payload)


def _load_scoped_group(group_id: str, *, resource: str, command: str | None) -> dict:
    if resource == "task" and command in {"list", "show"}:
        return load_group(group_id) or group_from_header(group_id, get_header(group_id))
    return require_group_by_name(group_id)


def _needs_keep_workflow(resource: str, command: str | None) -> bool:
    return command in _KEEP_WORKFLOW_COMMANDS.get(resource, frozenset())
