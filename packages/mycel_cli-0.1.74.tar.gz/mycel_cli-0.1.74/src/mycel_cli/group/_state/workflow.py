"""Chat workflow header store for cel groups."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from mycel_cli.config import config_client_kwargs, load_owner_config
from mycel_cli.group._state.groups import mutate_group
from mycel_sdk import Client
from mycel_sdk.errors import ApiError

KIND = "cel-group"
_OMIT = object()


@dataclass(frozen=True)
class GroupWorkflowHeader:
    state: str
    group_prompt: str | None
    terminal_type: str | None
    workers_enabled: bool | None
    created_at: float | None
    updated_at: float | None


def _client() -> Client:
    cfg = load_owner_config()
    return Client(**config_client_kwargs(cfg))


def _workflow_or_fail(chat_id: str) -> dict[str, Any]:
    workflow = _client().chats.get_workflow(chat_id)
    if not isinstance(workflow, dict):
        raise RuntimeError(f"backend workflow not found for group '{chat_id}'")
    if workflow.get("kind") != KIND:
        raise RuntimeError(
            f"group '{chat_id}' is workflow kind {workflow.get('kind')!r}, expected {KIND!r}"
        )
    return workflow


def _header_from_workflow(workflow: dict[str, Any]) -> GroupWorkflowHeader:
    config = dict(workflow.get("config") or {})
    return GroupWorkflowHeader(
        state=str(workflow.get("state") or "stopped"),
        group_prompt=config.get("group_prompt"),
        terminal_type=config.get("terminal_type"),
        workers_enabled=config.get("workers_enabled"),
        created_at=workflow.get("created_at"),
        updated_at=workflow.get("updated_at"),
    )


def get_header(chat_id: str) -> GroupWorkflowHeader:
    return _header_from_workflow(_workflow_or_fail(chat_id))


def has_header(chat_id: str) -> bool:
    try:
        workflow = _client().chats.get_workflow(chat_id)
    except ApiError as exc:
        if exc.status_code == 404:
            return False
        raise
    if workflow is None:
        return False
    if not isinstance(workflow, dict):
        raise RuntimeError(f"backend returned invalid workflow for group '{chat_id}'")
    if workflow.get("kind") != KIND:
        raise RuntimeError(
            f"group '{chat_id}' is workflow kind {workflow.get('kind')!r}, expected {KIND!r}"
        )
    return True


def create_workflow(
    chat_id: str,
    *,
    terminal_type: str,
    workers_enabled: bool,
    preset: str | None = None,
    state: str = "stopped",
) -> GroupWorkflowHeader:
    config: dict[str, Any] = {
        "terminal_type": terminal_type,
        "workers_enabled": workers_enabled,
        "participants": [],
    }
    if preset:
        config["preset"] = preset
    workflow = _client().chats.set_workflow(
        chat_id,
        kind=KIND,
        state=state,
        config=config,
    )
    if not isinstance(workflow, dict):
        raise RuntimeError("backend did not return a group workflow payload")
    return _header_from_workflow(workflow)


def ensure_workflow(
    chat_id: str,
    *,
    terminal_type: str,
    workers_enabled: bool,
    preset: str | None = None,
    state: str = "stopped",
) -> GroupWorkflowHeader:
    try:
        workflow = _client().chats.get_workflow(chat_id)
    except ApiError as exc:
        if exc.status_code != 404:
            raise
        workflow = None
    if isinstance(workflow, dict):
        if workflow.get("kind") != KIND:
            raise RuntimeError(
                f"group '{chat_id}' is workflow kind {workflow.get('kind')!r}, expected {KIND!r}"
            )
        return _header_from_workflow(workflow)
    if workflow is not None:
        raise RuntimeError(f"backend returned invalid workflow for group '{chat_id}'")
    return create_workflow(
        chat_id,
        terminal_type=terminal_type,
        workers_enabled=workers_enabled,
        preset=preset,
        state=state,
    )


def set_header(
    chat_id: str,
    *,
    state: str | None = None,
    group_prompt: str | None | object = _OMIT,
    terminal_type: str | object = _OMIT,
    workers_enabled: bool | object = _OMIT,
) -> GroupWorkflowHeader:
    updated = _update_workflow_config(
        chat_id,
        lambda workflow, config: _set_header_config(
            workflow,
            config,
            state=state,
            group_prompt=group_prompt,
            terminal_type=terminal_type,
            workers_enabled=workers_enabled,
        ),
    )
    if not isinstance(updated, dict):
        raise RuntimeError("backend did not return a workflow payload")
    return _header_from_workflow(updated)


def delete_header(chat_id: str) -> None:
    _client().chats.delete_workflow(chat_id)


def upsert_participant(
    chat_id: str,
    *,
    participant: dict[str, Any],
    replace_alias: str,
    replace_preset_ref: str | None = None,
) -> None:
    _update_workflow_config(
        chat_id,
        lambda workflow, config: _upsert_participant_config(
            workflow,
            config,
            participant=participant,
            replace_alias=replace_alias,
            replace_preset_ref=replace_preset_ref,
        ),
    )


def remove_participant(
    chat_id: str, *, alias: str, preset_ref: str | None = None
) -> None:
    _update_workflow_config(
        chat_id,
        lambda workflow, config: _remove_participant_config(
            workflow,
            config,
            alias=alias,
            preset_ref=preset_ref,
        ),
    )


def _update_workflow_config(
    chat_id: str,
    mutate: Callable[[dict[str, Any], dict[str, Any]], tuple[str, dict[str, Any]]],
    *,
    attempts: int = 2,
) -> dict[str, Any] | None:
    last_error: ApiError | None = None
    for _ in range(attempts):
        workflow = _workflow_or_fail(chat_id)
        config = dict(workflow.get("config") or {})
        state, config = mutate(workflow, config)
        try:
            return _client().chats.set_workflow(
                chat_id,
                kind=KIND,
                state=state,
                config=config,
                expected_state_version=_state_version(workflow),
            )
        except ApiError as exc:
            if exc.status_code != 409:
                raise
            last_error = exc
    raise RuntimeError(
        f"backend workflow config changed while updating group '{chat_id}'"
    ) from last_error


def _set_header_config(
    workflow: dict[str, Any],
    config: dict[str, Any],
    *,
    state: str | None,
    group_prompt: str | None | object,
    terminal_type: str | object,
    workers_enabled: bool | object,
) -> tuple[str, dict[str, Any]]:
    if group_prompt is not _OMIT:
        if group_prompt:
            config["group_prompt"] = group_prompt
        else:
            config.pop("group_prompt", None)
    if terminal_type is not _OMIT:
        config["terminal_type"] = terminal_type
    if workers_enabled is not _OMIT:
        config["workers_enabled"] = workers_enabled
    return state or str(workflow.get("state") or "stopped"), config


def _upsert_participant_config(
    workflow: dict[str, Any],
    config: dict[str, Any],
    *,
    participant: dict[str, Any],
    replace_alias: str,
    replace_preset_ref: str | None,
) -> tuple[str, dict[str, Any]]:
    config["participants"] = [
        item
        for item in _participant_list(config.get("participants"))
        if not _same_participant(
            item,
            alias=replace_alias,
            preset_ref=replace_preset_ref,
        )
    ]
    config["participants"].append(dict(participant))
    return str(workflow.get("state") or "stopped"), config


def _remove_participant_config(
    workflow: dict[str, Any],
    config: dict[str, Any],
    *,
    alias: str,
    preset_ref: str | None,
) -> tuple[str, dict[str, Any]]:
    config["participants"] = [
        item
        for item in _participant_list(config.get("participants"))
        if not _same_participant(item, alias=alias, preset_ref=preset_ref)
    ]
    return str(workflow.get("state") or "stopped"), config


def _participant_list(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, list):
        return []
    return [dict(item) for item in raw if isinstance(item, dict)]


def _state_version(workflow: dict[str, Any]) -> int | None:
    raw = workflow.get("state_version")
    return int(raw) if raw is not None else None


def _same_participant(
    item: dict[str, Any], *, alias: str, preset_ref: str | None
) -> bool:
    if preset_ref is not None and item.get("preset_ref") != preset_ref:
        return False
    aliases = item.get("aliases")
    return isinstance(aliases, list) and alias in {str(item) for item in aliases}


def apply_header(group: dict[str, Any], header: GroupWorkflowHeader) -> dict[str, Any]:
    group["status"] = header.state
    group["group_prompt"] = header.group_prompt
    if header.terminal_type is not None:
        group["terminal_type"] = header.terminal_type
    if header.workers_enabled is not None:
        group["workers_enabled"] = header.workers_enabled
    if header.created_at is not None:
        group["created_at"] = header.created_at
    return group


def group_from_header(chat_id: str, header: GroupWorkflowHeader) -> dict[str, Any]:
    return apply_header(
        {
            "name": chat_id,
            "status": header.state,
            "roles": [],
            "group_prompt": None,
            "created_at": header.created_at,
            "terminal_type": header.terminal_type,
            "terminal_container": None,
        },
        header,
    )


def mirror_header(chat_id: str, header: GroupWorkflowHeader) -> dict[str, Any]:
    with mutate_group(chat_id) as group:
        apply_header(group, header)
        return dict(group)
