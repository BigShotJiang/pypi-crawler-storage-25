from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderHookRuntimePolicy:
    include_continue: bool = False
    stop_block_event: str | None = None

    def blocks_event(self, event_name: str) -> bool:
        return self.stop_block_event == event_name


_DEFAULT_PROVIDER_HOOK_RUNTIME_POLICY = ProviderHookRuntimePolicy()
_PROVIDER_HOOK_RUNTIME_POLICIES = {
    "codex": ProviderHookRuntimePolicy(include_continue=True),
    "claude": ProviderHookRuntimePolicy(stop_block_event="Stop"),
}


def provider_hook_runtime_policy(provider: str) -> ProviderHookRuntimePolicy:
    return _PROVIDER_HOOK_RUNTIME_POLICIES.get(
        provider, _DEFAULT_PROVIDER_HOOK_RUNTIME_POLICY
    )
