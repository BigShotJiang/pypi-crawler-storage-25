"""`jh withdraw` — I pulled out, status → withdrawn."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from cyclopts import Parameter

from jobhound.commands._terminal import run_transition


def run(
    slug_query: str,
    /,
    *,
    now: Annotated[datetime | None, Parameter(show=False)] = None,
) -> None:
    """Withdraw from an opportunity."""
    run_transition(
        slug_query=slug_query,
        verb="withdraw",
        now=now,
    )
