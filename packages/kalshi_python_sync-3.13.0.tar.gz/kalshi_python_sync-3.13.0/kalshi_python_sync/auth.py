# coding: utf-8

"""Kalshi-specific authentication helpers for generated Python SDKs."""

import base64
import time

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey


class KalshiAuth:
    """Kalshi authentication handler for API requests."""

    def __init__(self, key_id: str, private_key_pem: str):
        self.key_id = key_id

        if isinstance(private_key_pem, str):
            private_key_bytes = private_key_pem.encode()
        else:
            private_key_bytes = private_key_pem  # type: ignore

        loaded_key = serialization.load_pem_private_key(
            private_key_bytes,
            password=None,
            backend=default_backend(),
        )

        if not isinstance(loaded_key, RSAPrivateKey):
            raise ValueError("Private key must be an RSA key")

        self.private_key = loaded_key

    def create_auth_headers(self, method: str, url: str) -> dict:
        current_time_milliseconds = int(time.time() * 1000)
        timestamp_str = str(current_time_milliseconds)

        if url.startswith("http"):
            from urllib.parse import urlparse

            path = urlparse(url).path
        else:
            path = url.split("?")[0]

        msg_string = timestamp_str + method.upper() + path
        message = msg_string.encode("utf-8")
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH,
            ),
            hashes.SHA256(),
        )
        signature_b64 = base64.b64encode(signature).decode("utf-8")

        return {
            "KALSHI-ACCESS-KEY": self.key_id,
            "KALSHI-ACCESS-SIGNATURE": signature_b64,
            "KALSHI-ACCESS-TIMESTAMP": timestamp_str,
        }
