"""Central registry wiring — imports all agent adapters and defines registries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from caretaker.bootstrap_agent.adapter import BootstrapAgentAdapter
from caretaker.charlie_agent.adapter import CharlieAgentAdapter
from caretaker.dependency_agent.adapter import DependencyAgentAdapter
from caretaker.devops_agent.adapter import DevOpsAgentAdapter
from caretaker.docs_agent.adapter import DocsAgentAdapter
from caretaker.escalation_agent.adapter import EscalationAgentAdapter
from caretaker.issue_agent.adapter import IssueAgentAdapter
from caretaker.migration_agent.agent import MigrationAgent
from caretaker.perf_agent.agent import PerformanceAgent
from caretaker.pr_agent.adapter import PRAgentAdapter
from caretaker.pr_agent.shepherd_adapter import ShepherdAgentAdapter
from caretaker.pr_agent.triage_adapter import TriageAgentAdapter
from caretaker.pr_ci_approver.agent import PRCIApproverAgent
from caretaker.pr_reviewer.agent import PRReviewerAgent
from caretaker.principal_agent.agent import PrincipalAgent
from caretaker.refactor_agent.agent import RefactorAgent
from caretaker.review_agent.agent import ReviewAgent
from caretaker.security_agent.adapter import SecurityAgentAdapter
from caretaker.self_heal_agent.adapter import SelfHealAgentAdapter
from caretaker.stale_agent.adapter import StaleAgentAdapter
from caretaker.test_agent.agent import TestAgent
from caretaker.upgrade_agent.adapter import UpgradeAgentAdapter

if TYPE_CHECKING:
    from caretaker.agent_protocol import AgentContext, BaseAgent
    from caretaker.registry import AgentRegistry

ALL_ADAPTERS: list[type[BaseAgent]] = [
    PRAgentAdapter,
    IssueAgentAdapter,
    UpgradeAgentAdapter,
    DevOpsAgentAdapter,
    SelfHealAgentAdapter,
    SecurityAgentAdapter,
    DependencyAgentAdapter,
    DocsAgentAdapter,
    CharlieAgentAdapter,
    StaleAgentAdapter,
    EscalationAgentAdapter,
    ReviewAgent,
    PrincipalAgent,
    TestAgent,
    RefactorAgent,
    PerformanceAgent,
    MigrationAgent,
    PRReviewerAgent,
    PRCIApproverAgent,
    TriageAgentAdapter,
    ShepherdAgentAdapter,
    BootstrapAgentAdapter,
]

# Maps agent name -> set of run modes that include it
AGENT_MODES: dict[str, set[str]] = {
    "pr": {"full", "pr-only"},
    "issue": {"full", "issue-only"},
    "upgrade": {"full", "upgrade"},
    "devops": {"full", "devops"},
    "self-heal": {"self-heal"},  # scheduled self-heal mode only
    "security": {"full", "security"},
    "deps": {"full", "deps"},
    "docs": {"full", "docs"},
    "charlie": {"full", "charlie"},
    "stale": {"full", "stale"},
    "escalation": {"full", "escalation"},
    "review": {"full"},
    "principal": {"full", "principal"},
    "test": {"full", "test"},
    "refactor": {"full", "refactor"},
    "perf": {"full", "perf"},
    "migration": {"full", "migration"},
    "pr-reviewer": {"full", "pr-only", "pr-reviewer"},
    "pr-ci-approver": {"full", "pr-only", "pr-ci-approver"},
    "triage": {"full", "triage"},
    # Shepherd is intentionally NOT in "full" — it runs only on the
    # dedicated "shepherd" mode so scheduled hourly runs keep their
    # current behavior until the operator opts in.
    "shepherd": {"shepherd"},
    # Bootstrap is event-driven only — never picked up by a scheduled
    # mode. It runs on installation/installation_repositories webhook
    # events and is a no-op on a "full" reconciliation tick.
    "bootstrap": {"bootstrap"},
}

# Maps GitHub event types -> list of agent names to run
EVENT_AGENT_MAP: dict[str, list[str]] = {
    "pull_request": ["pr", "pr-reviewer", "pr-ci-approver", "principal", "test", "perf"],
    "pull_request_review": ["pr"],
    "check_run": ["pr"],
    "check_suite": ["pr", "pr-ci-approver"],
    "issues": ["issue", "principal"],
    "issue_comment": ["issue"],
    "workflow_run": ["devops", "self-heal", "pr", "pr-ci-approver"],
    "dependabot_alert": ["security"],
    # App lifecycle events — auto-bootstrap every newly-attached repo.
    "installation": ["bootstrap"],
    "installation_repositories": ["bootstrap"],
}


def build_registry(ctx: AgentContext) -> AgentRegistry:
    """Construct a fully populated AgentRegistry from the given context."""
    from caretaker.registry import AgentRegistry

    registry = AgentRegistry()
    for adapter_cls in ALL_ADAPTERS:
        agent = adapter_cls(ctx)
        modes = AGENT_MODES.get(agent.name, {"full"})
        registry.register(agent, modes=modes)
    return registry
