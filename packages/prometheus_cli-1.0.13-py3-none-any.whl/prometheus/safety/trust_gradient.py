"""Round 160 — Failure-Mode 4: graduated autonomy trust gradient.

Research (Anthropic SOSA methodology): production agents need
graduated autonomy — low-impact tasks run freely, high-impact tasks
require approval. Trust should be earned, not granted.

Tier ladder:

  T0 — Untrusted   read-only tools only (no Bash, no Write)
  T1 — Trusted     Read + Write; Bash requires approval per command
  T2 — Established Read + Write + safe-Bash (git status, pytest, npm test)
                   auto-approved; other Bash gated
  T3 — Full        all tools auto-approved except hard-deny list

Auto-advancement: after `advance_after_n` consecutive successful tool
calls (default 5) the gradient promotes to the next tier. A single
failure resets the streak. Hard-deny verdicts always apply regardless
of tier.

The gradient is layered on top of the existing permission_mode +
Overseer. It expresses *what the model is allowed to attempt* before
the deeper gates run; the Overseer always has the final word on
hard-deny commands.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Iterable


class Tier(IntEnum):
    """Autonomy tier. Higher = more auto-approval surface."""
    UNTRUSTED = 0
    TRUSTED = 1
    ESTABLISHED = 2
    FULL = 3


# --- tool / command classification ----------------------------------


# Tool names that are read-only and side-effect-free at tier 0.
READ_ONLY_TOOLS: frozenset[str] = frozenset({
    "read_file",
    "list_files",
    "glob_files",
    "search_code",
    "grep",
    "web_fetch",   # network read; no local mutation
    "web_search",
    "todo_read",
    "test_discovery",
    "test_runner",  # discovery only, not execution
})


# Tools that *write* but stay inside the workdir at tier 1+.
WRITE_TOOLS: frozenset[str] = frozenset({
    "write_file",
    "edit_file",
    "multi_edit",
    "apply_patch",
    "todo_write",
})


# Bash commands considered "safe" at tier 2 — diagnostic / read-only,
# never destructive. Match by command-prefix (after stripping
# leading/trailing whitespace + quotes).
SAFE_BASH_PREFIXES: tuple[str, ...] = (
    "git status", "git log", "git diff", "git show", "git branch",
    "git rev-parse", "git remote -v", "git config --list",
    "ls", "dir", "pwd", "whoami", "hostname", "uname",
    "python --version", "python -V", "python3 --version",
    "node --version", "npm --version", "yarn --version",
    "pytest --collect-only", "pytest -q", "pytest --version",
    "npm test", "npm run test", "yarn test",
    "cargo check", "cargo test", "cargo --version",
    "go test", "go version",
    "docker ps", "docker images", "docker version",
    "echo ", "printf ", "cat ", "head ", "tail ",
    "which ", "where ", "type ",
    "free", "df ", "du ",
)


def _is_safe_bash(command: str) -> bool:
    cmd = (command or "").strip().lstrip("'\"").rstrip("'\"").strip()
    if not cmd:
        return False
    return any(cmd.startswith(p) or cmd == p.rstrip() for p in SAFE_BASH_PREFIXES)


# --- the gradient itself --------------------------------------------


@dataclass
class TrustGradient:
    """Tracks the current tier + the success streak that drives
    auto-advancement."""
    tier: Tier = Tier.UNTRUSTED
    successful_in_a_row: int = 0
    advance_after_n: int = 5
    history: list[str] = field(default_factory=list)
    """Append-only log of tier transitions for debugging / `/stats`."""

    def record_success(self) -> bool:
        """Record a successful tool call. Returns True if the gradient
        just promoted (so the caller can announce it)."""
        self.successful_in_a_row += 1
        if self.successful_in_a_row >= self.advance_after_n and self.tier < Tier.FULL:
            old = self.tier
            self.tier = Tier(int(self.tier) + 1)
            self.successful_in_a_row = 0
            self.history.append(
                f"promoted {old.name} → {self.tier.name} after "
                f"{self.advance_after_n} clean calls"
            )
            return True
        return False

    def record_failure(self) -> bool:
        """Record a failed tool call. Resets the streak. Returns True
        if the streak was reset from a non-zero value (caller may want
        to log it)."""
        had_streak = self.successful_in_a_row > 0
        self.successful_in_a_row = 0
        return had_streak

    def can_attempt(self, tool_name: str, args: dict | None = None) -> bool:
        """Return True if the model is allowed to *propose* this tool
        call at the current tier. The deeper gates (permission_mode,
        Overseer) still run — this is the trust ceiling that filters
        BEFORE those gates."""
        name = (tool_name or "").lower()
        if self.tier == Tier.UNTRUSTED:
            return name in READ_ONLY_TOOLS
        if self.tier == Tier.TRUSTED:
            # Read + Write OK; Bash needs approval (caller defers to
            # request_approval()).
            return name in READ_ONLY_TOOLS or name in WRITE_TOOLS or name == "run_bash"
        if self.tier == Tier.ESTABLISHED:
            return True  # everything's allowed at this layer; the next
                         # function decides whether to auto-approve.
        # FULL: everything except whatever the Overseer hard-denies.
        return True

    def auto_approves(self, tool_name: str, args: dict | None = None) -> bool:
        """Return True if a tool call should skip the per-call approval
        prompt at the current tier. Hard-deny commands NEVER auto-approve;
        the Overseer must run regardless."""
        name = (tool_name or "").lower()
        args = args or {}
        if self.tier == Tier.UNTRUSTED:
            # Read-only tools have side_effect=READ — they auto-allow at
            # the permission_mode layer anyway. T0 doesn't add anything.
            return name in READ_ONLY_TOOLS
        if self.tier == Tier.TRUSTED:
            # Read + Write auto; Bash always prompts at T1.
            return name in READ_ONLY_TOOLS or name in WRITE_TOOLS
        if self.tier == Tier.ESTABLISHED:
            if name == "run_bash":
                return _is_safe_bash(str(args.get("command", "")))
            return True  # Read / Write / WebFetch / etc.
        # FULL: every tool auto-approves. Overseer-hard-deny still
        # blocks at the next layer.
        return True

    def status_chip(self) -> str:
        """Short label suitable for the bottom HUD."""
        return f"trust:{self.tier.name.lower()}({self.successful_in_a_row}/{self.advance_after_n})"


def from_permission_mode(mode: str) -> TrustGradient:
    """Map a permission_mode string to its starting tier."""
    m = (mode or "default").lower()
    if m == "skipall":
        return TrustGradient(tier=Tier.FULL)
    if m == "acceptedits" or m == "accept_edits":
        return TrustGradient(tier=Tier.ESTABLISHED)
    if m == "default":
        return TrustGradient(tier=Tier.TRUSTED)
    if m == "plan":
        return TrustGradient(tier=Tier.UNTRUSTED)
    return TrustGradient(tier=Tier.TRUSTED)
