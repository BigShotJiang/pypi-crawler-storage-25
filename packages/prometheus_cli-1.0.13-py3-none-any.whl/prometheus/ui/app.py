"""PrometheUS Textual app — single-pane chat with streaming, tool receipts,
inline approvals, slash commands, and a status bar."""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

from rich.console import Group
from rich.text import Text
from rich.markdown import Markdown
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, RichLog, Static

from prometheus import log
from prometheus.agent.loop import AgentLoop
from prometheus.config import FREE_MODELS_PREFERRED, Settings
from prometheus.memory.session import SessionStore
from prometheus.provider.openrouter import OpenRouterClient
from prometheus.slash.commands import (
    SlashRouter,
    _is_session_resumable,
    build_default_router,
)
from prometheus.tools import build_default_registry
from prometheus.ui.render import (
    assistant_markdown,
    error_line,
    expanded_body,
    receipt_line,
    receipt_summary_line,
    system_dim,
    activity_summary_line,
    thought_marker,
    user_line,
)
from prometheus.ui.theme import (
    AMBER,
    DIM,
    ERROR,
    INK,
    MUTED,
    SUCCESS,
)
from prometheus.ui.widgets import (
    ActivityLine,
    FileSuggestions,
    InlineApproval,
    PermissionBar,
    QuestionPrompt,
    SessionHeader,
    SlashSuggestions,
    StatusBar,
    TodoBar,
    WelcomeCard,
)

logger = log.get("ui.app")

# Approximate token budget for the default model (qwen3-coder = 262k).
APPROX_CTX_TOKENS = 200_000


# Round-96.7: tool-aware phase router for the activity rail.
# Maps a tool name to a phase string consumed by ActivityLine's
# render(), which surfaces it as "Inspecting project · Read(...)" /
# "Editing files · Write(...)" / "Running command · Bash(...)".
_PHASE_INSPECTING_TOOLS = frozenset({
    "read_file", "list_files", "discover_test_command",
    "bash_output", "web_fetch",
})
# Round 96.29: Glob/Grep get their own `searching` phase (label
# "Searching") so the rail reads `Searching…` while a grep or glob
# is in flight, not the catch-all `Inspecting project…`. Matches
# Claude Code's task-shaped rail rhythm.
_PHASE_SEARCHING_TOOLS = frozenset({
    "glob_files", "search_code", "grep", "web_search",
})
_PHASE_EDITING_TOOLS = frozenset({
    "edit_file", "write_file", "multi_edit", "apply_patch",
    "todo_write",
})


def _filter_resumable_recent_sessions(
    store: Any, limit: int = 3,
) -> list[dict]:
    """Round 96.11: build the welcome card's `recent activity` list,
    keeping only sessions that /sessions and /resume agree are
    resumable. Pulls a wider window than `limit` so a run of empty
    rows at the top of the list doesn't starve the welcome card of
    /resume shortcuts.

    Smoke 5 retest live case: the welcome card was promoting empty
    sessions as `/resume <id>` shortcuts (rows /sessions later
    classified as `(empty — not resumable)`). Three contracts had
    drifted apart — /sessions display, /resume no-arg selection, and
    welcome recent activity. They now all gate on the same helper.
    """
    import time as _t
    out: list[dict] = []
    now = _t.time()
    try:
        rows = store.list_sessions(limit=20)
    except Exception:
        return out
    for r in rows:
        sid = r.get("id", "") if isinstance(r, dict) else ""
        if not sid:
            continue
        if not _is_session_resumable(store, sid):
            continue
        try:
            age = max(0, now - r["started_at"])
        except Exception:
            age = 0
        if age < 60: ago = f"{int(age)}s ago"
        elif age < 3600: ago = f"{int(age / 60)}m ago"
        elif age < 86400: ago = f"{int(age / 3600)}h ago"
        else: ago = f"{int(age / 86400)}d ago"
        try:
            preview = store.last_user_message(sid)
        except Exception:
            preview = ""
        preview = (preview or "")[:50].replace("\n", " ").strip()
        # Same defensive sanitization /sessions applies — the
        # reserved marker text is a render-time decoration, never
        # user content that should appear next to a /resume shortcut.
        if "(empty — not resumable)" in preview:
            preview = ""
        out.append({"id": sid, "ago": ago, "preview": preview})
        if len(out) >= limit:
            break
    return out


def _phase_for_tool(name: str, args: dict | None = None) -> str:
    """Round-96.7 / 96.7b: map a tool name (+ args) to the
    activity-rail phase that should fire while it executes. The args
    inspection lets `run_bash` differentiate between a test-suite
    invocation, a git status check, a package install, and a generic
    command — all surface with distinct labels on the rail.
    """
    n = (name or "").strip()
    if n in _PHASE_SEARCHING_TOOLS:
        return "searching"
    if n in _PHASE_INSPECTING_TOOLS:
        return "inspecting"
    if n in _PHASE_EDITING_TOOLS:
        return "editing"
    if n == "run_bash" and args:
        cmd = str(args.get("command", "") or "").lower().strip()
        if cmd:
            head_tokens = cmd.split()[:3]
            head_joined = " ".join(head_tokens)
            # Test-suite invocations across the major ecosystems
            if (
                "pytest" in cmd
                or "npm test" in head_joined
                or "yarn test" in head_joined
                or "pnpm test" in head_joined
                or "cargo test" in head_joined
                or "go test" in head_joined
                or "make test" in head_joined
                or cmd.startswith("tox")
            ):
                return "running_tests"
            # Git read-side commands
            if head_tokens and head_tokens[0] == "git":
                if len(head_tokens) >= 2 and head_tokens[1] in (
                    "status", "log", "diff", "show", "branch",
                    "blame", "config", "rev-parse", "describe",
                ):
                    return "checking_git"
            # Package install / dependency setup
            install_starts = (
                "pip install", "pip3 install", "pipx install",
                "npm install", "yarn install", "pnpm install",
                "cargo install", "go install", "uv sync",
                "poetry install",
                "apt install", "apt-get install",
                "brew install", "winget install",
                "choco install", "scoop install",
            )
            if any(cmd.startswith(p) for p in install_starts):
                return "installing"
    return "running"

# Permission cycle order for shift+tab.
PERMISSION_ORDER = ["default", "acceptEdits", "plan", "skipAll"]

# NOTE: the activity-line label is intentionally always "thinking",
# regardless of which tool is running. Tool-specific verbs leaked
# information that the receipt about to land in the chat would display
# again (the user saw "searching the web" flash above the receipt).
# Kept the mapping commented out below for reference if a future variant
# of the activity line wants to surface verb hints.


class PrometheusApp(App):
    # Disable mouse capture by default — Textual normally consumes mouse
    # events for clicks/scroll, which prevents the terminal's native
    # text-selection (Shift-drag on Windows Terminal / Cmd-drag on macOS).
    # Users far prefer being able to select-and-copy chat content with
    # the mouse than the marginal benefit of click-to-focus widgets.
    # The TUI still works fine via keyboard.
    ENABLE_COMMAND_PALETTE = False
    INLINE_PADDING = 0

    CSS = """
    Screen { background: black; }
    #chat-log { background: black; padding: 1 2; height: 1fr; }
    #input-row { height: auto; padding: 0 2; }
    #input-row Input { border: none; background: black; color: white; }
    #input-row Input:focus { border: none; background: black; }
    #picker-slot { height: auto; background: black; }
    Header { background: black; color: white; }
    Footer { background: black; color: white; }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "quit", show=False),
        Binding("ctrl+l", "clear", "clear", show=False),
        Binding("ctrl+r", "history", "history", show=False),
        Binding("ctrl+o", "toggle_verbose", "verbose", show=False),
        Binding("ctrl+y", "copy_last", "copy last reply", show=False),
        Binding("ctrl+b", "background_bash", "background current bash", show=False),
        Binding("shift+tab", "cycle_mode", "cycle modes", show=False, priority=True),
        Binding("escape", "interrupt", "interrupt", show=False),
        Binding("tab", "complete_slash", "complete slash command", show=False, priority=True),
        # Chat scrollback. Mouse-wheel scroll is unavailable because
        # mouse capture is disabled (so the user can drag-select for
        # native copy/paste), so the scroll affordances are keyboard-only.
        # `priority=True` ensures these fire even while the Input has
        # focus — otherwise PageUp/Down would just sit in the textbox.
        Binding("pageup", "scroll_page_up", "scroll up", show=False, priority=True),
        Binding("pagedown", "scroll_page_down", "scroll down", show=False, priority=True),
        Binding("ctrl+home", "scroll_home", "scroll to top", show=False, priority=True),
        Binding("ctrl+end", "scroll_end", "scroll to bottom", show=False, priority=True),
        Binding("shift+pageup", "scroll_home", "scroll to top", show=False, priority=True),
        Binding("shift+pagedown", "scroll_end", "scroll to bottom", show=False, priority=True),
        # Voice mode: Ctrl+Space toggles dictation. priority=True so the
        # binding fires while the Input is focused (otherwise the Input
        # would consume the keypress as text). Esc cancels via the
        # existing action_interrupt path.
        Binding("ctrl+space", "voice_toggle", "voice", show=False, priority=True),
        # Image paste: when the OS clipboard contains a binary image we
        # read it directly. priority=True so the binding fires while
        # Input is focused; if the clipboard is text-only the action
        # returns silently and bracketed-paste delivers text via on_paste.
        Binding("ctrl+v", "paste_image", "paste image", show=False, priority=True),
        # Round-16 WOW: Ctrl+G opens $EDITOR for prompt composition.
        # Tiny diff, repeatedly cited as outsized impact in user research
        # — multi-line prompts, syntax highlighting, snippet pasting.
        Binding("ctrl+g", "compose_in_editor", "edit in $EDITOR", show=False, priority=True),
    ]

    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self.settings = settings
        self.client: OpenRouterClient | None = None
        self.registry = build_default_registry(
            spawn_subagent=self._spawn_subagent,
            ask_user=self.ask_user_question,
        )
        self.agent: AgentLoop | None = None
        self.session_id: str = str(uuid.uuid4())
        self.session_store = SessionStore()
        self.slash: SlashRouter | None = None
        self._busy_task: asyncio.Task | None = None
        self._spinner_task: asyncio.Task | None = None
        self._pending_approval: asyncio.Future[bool] | None = None
        # Pending arrow-key question (from ask_user_question tool):
        self._pending_question: asyncio.Future[str] | None = None
        self._question_widget: QuestionPrompt | None = None
        self._history: list[str] = []
        self._history_idx: int | None = None
        self._approval_widget: InlineApproval | None = None
        self._tokens_total_in: int = 0
        self._tokens_total_out: int = 0
        # Running USD cost. Free engines report 0; we still track in case
        # a user swaps to a paid engine via /model.
        self._cost_total_usd: float = 0.0
        # Header label — defaults to the working-directory name so it
        # never duplicates the user's first prompt (which appears
        # verbatim in the chat scroll right below). Users can change it
        # with /rename.
        self._session_label: str = self._default_session_label()
        # Per-turn delta added to _tokens_total_out from streaming text.
        # When the authoritative usage event arrives we subtract this and
        # add the real count so the persistent total stays accurate.
        self._live_out_delta: int = 0
        # Per-turn output tokens (used by the post-turn '✻ Thought for…' marker).
        self._turn_tokens_out: int = 0
        # Round-96.4: per-turn INPUT tokens. Tracked separately from
        # the session-cumulative `_tokens_total_in` so /stats can show
        # "last model call: ~X input / Y output" honestly. Smoke 4 retest
        # bug: /stats showed `last turn: ↑251.4k / ↓15.2k` because we
        # printed session-cumulative input alongside per-turn output —
        # the user (correctly) read this as the last model call inflating
        # to 251k, when really 251k was lifetime input across all
        # turns + the resumed session's history.
        self._turn_tokens_in: int = 0
        # Per-turn tool-call count — used to decide whether to show the
        # thought marker. Trivial Q&A turns shouldn't get one.
        self._turn_tool_calls: int = 0
        # Verbose toggle (Ctrl+O) — when on, the thought marker shows for
        # every turn regardless of duration / tool count.
        self._verbose: bool = False
        # Live per-turn elapsed time (resets at each /run).
        self._busy_started: float = 0.0
        # Last 6 tool results, used by /expand.
        self._recent_results: list[tuple[str, Any]] = []
        # Pasted-block storage. The Input shows `[Pasted: N lines, M chars]`
        # placeholders; the actual text is held here and substituted back
        # in at submit time.
        self._paste_buffer: dict[str, str] = {}
        self._paste_seq: int = 0
        # Process-wide background-job registry (Ctrl+B + /bashes).
        from prometheus.runtime.bashes import BackgroundJobs
        self.bg_jobs = BackgroundJobs()
        # Async-agent jobs (/async + /jobs).
        from prometheus.runtime.async_jobs import AsyncJobs
        self.async_jobs = AsyncJobs()
        # Round 97: BackgroundAgentManager owns the lifecycle of
        # subagents launched with `run_in_background=true` on the
        # `task` tool. The manager runs each subagent through
        # `_subagent_manager_runner`, which delegates to the same
        # `_spawn_subagent` path the foreground task uses — only
        # difference is an `on_event` hook that pipes a compact
        # one-line summary into the SubAgentTask's events list.
        from prometheus.agent.subagent_manager import (
            BackgroundAgentManager,
        )
        self.subagent_manager = BackgroundAgentManager(
            self._subagent_manager_runner,
        )
        # Mounted lazily in on_mount; held here so tools can sync.
        self.subagent_panel: Any = None
        # Tracks the live foreground bash subprocess so Ctrl+B can adopt it.
        self._fg_bash_proc: Any = None
        self._fg_bash_cmd: str = ""
        # Round 97.3: per-session approval cache. When the user
        # picks "Yes, and don't ask again this session" on a Bash
        # approval card, the (tool, kind) pair is stored here and
        # subsequent matching requests auto-approve. Includes
        # subagent calls — if the user trusted `Bash(pwd)` once,
        # the subagent's `pwd` doesn't re-prompt. Cleared by
        # /clear and on session change. Pre-97.3 the only
        # "remember" path was `permission_mode = acceptEdits`
        # which globally elevated all writes — too coarse.
        self._session_always_yes: set[str] = set()
        # Round 104: Overseer with three-tier rules + circuit
        # breaker + recently-denied ledger. Lives on the app so
        # /permissions can surface it. Round 102's module-level
        # `evaluate()` keeps working — this is the per-session
        # instance that the UI surfaces.
        from prometheus.safety.overseer import Overseer
        self.overseer = Overseer()
        # Idle-bell: when the agent finishes a reply and the user
        # doesn't type anything for IDLE_BELL_SECONDS, ring the bell
        # once. Lets users alt-tab away during long generations and
        # come back when notified.
        self._idle_bell_task: asyncio.Task | None = None
        self.IDLE_BELL_SECONDS = 30
        self._idle_bell_enabled = True
        # Voice mode state. Lazy: nothing imported until first /voice.
        self._voice_session: Any = None
        self._voice_widget: Any = None
        self._voice_tick_task: asyncio.Task | None = None
        # Per-recording epoch — bumped on every start/cancel so a
        # late-arriving transcription from a previous recording
        # doesn't overwrite the user's new typing (audit P0).
        self._voice_epoch: int = 0
        # Image-paste state.
        from prometheus.ui.image_paste import ImagePasteManager
        self._image_paste = ImagePasteManager()

    # ---------- composition ----------

    def compose(self) -> ComposeResult:
        # Round-47: SessionHeader removed. Per Agent-1 web research,
        # Claude Code has NO persistent top header in default mode —
        # the startup banner just scrolls away with the chat. Our
        # `┃ PrometheUS` strip was visual noise; identity now lives
        # only on the bottom StatusBar (matches CC).
        # Progressive disclosure: surface up to 3 recent sessions
        # inline so returning users can /resume without typing
        # /sessions first.
        # Round 96.11: welcome recent activity is gated on the same
        # _is_session_resumable helper /sessions + /resume use, so
        # all three surfaces always agree on what's resumable.
        try:
            recent = _filter_resumable_recent_sessions(self.session_store)
        except Exception:
            recent = []
        yield WelcomeCard(
            self.settings.model, str(self.settings.workdir), recent_sessions=recent,
        )
        yield RichLog(
            id="chat-log",
            highlight=False,
            markup=False,
            wrap=True,
            auto_scroll=True,
            # Round-21: no in-app cap on history. Claude Code's hard
            # 250-line ceiling (issue #40253) is the second-loudest
            # TUI complaint; we leave it unbounded — Textual's
            # virtualized rendering means there's no perf cost.
            max_lines=None,
        )
        yield TodoBar(id="todo-bar", classes="-hidden")
        # Round 97: SubAgentPanel sits between the TodoBar and the
        # ActivityLine so background-subagent cards stack
        # vertically without displacing the live rail. The panel
        # auto-hides itself (`-empty` class) when no cards exist.
        from prometheus.ui.subagent_widgets import SubAgentPanel
        sap = SubAgentPanel()
        sap.id = "subagent-panel"
        sap.add_class("-empty")
        self.subagent_panel = sap
        yield sap
        yield ActivityLine(id="activity", classes="-hidden")
        # Live picker slot — InlineApproval / QuestionPrompt mount here at
        # runtime. They MUST be real mounted widgets (not one-shot Rich
        # renders into the chat log) so reactive `selected` updates show
        # the moving arrow as the user presses ↑/↓.
        yield Vertical(id="picker-slot")
        yield SlashSuggestions(id="slash-sug", classes="-hidden")
        yield FileSuggestions(id="file-sug", classes="-hidden")
        yield PermissionBar(id="perm-bar")
        with Horizontal(id="input-row"):
            # Round 106-final: VimInput subclasses textual Input
            # and intercepts Normal-mode keystrokes when
            # `vim_enabled` is True. The /vim slash command flips
            # that flag at runtime — no app restart required.
            try:
                from prometheus.ui.vim_mode import make_vim_input_class
                _VimInput = make_vim_input_class()
                yield _VimInput(
                    placeholder="Ask PrometheUS to inspect, run, or fix this project…",
                    id="prompt",
                )
            except Exception:
                yield Input(
                    placeholder="Ask PrometheUS to inspect, run, or fix this project…",
                    id="prompt",
                )
        yield StatusBar(id="status-bar")

    async def on_mount(self) -> None:
        self.title = "PrometheUS"
        # CRITICAL for commercial polish: free up the terminal's native
        # text selection so users can drag-select chat content and copy
        # with Ctrl+Shift+C (PowerShell/Linux) or Cmd+C (macOS).
        #
        # Textual's driver normally turns on full mouse reporting
        # (xterm modes 1000/1003/1006), which makes the terminal swallow
        # drag events and feeds them to the app — that's what was
        # blocking copy. We turn those modes back off by writing the
        # disable escape sequences directly. Textual's higher-level
        # mouse features (focus by click, scroll wheel) stop working,
        # but for a chat-style TUI those are nice-to-have; copy/paste is
        # table-stakes commercial behavior.
        self._disable_mouse_capture()
        self.client = OpenRouterClient(self.settings.api_key, self.settings.base_url, self.settings.request_timeout)
        await self.client.__aenter__()
        self.agent = AgentLoop(
            client=self.client,
            registry=self.registry,
            settings=self.settings,
            request_approval=self._request_approval,
            notify=self._notify,
            audit=self._audit,
            session_id=self.session_id,
        )
        # Make the App instance reachable from tools via ctx.runtime.app —
        # used by run_bash to register its subprocess for Ctrl+B handoff.
        class _Runtime:
            pass
        self.agent.runtime = _Runtime()
        self.agent.runtime.app = self
        self.slash = build_default_router(self)
        self._update_status()
        self.session_store.start(self.session_id, self.settings.model, str(self.settings.workdir))
        # Round 99: load Sentinels and fire SessionStart. The
        # registry lives on the app for the rest of the session;
        # _drive_agent fires PreToolUse/PostToolUse/Stop/etc. via
        # this same registry.
        try:
            from prometheus.safety.sentinels import (
                load_sentinels, fire_event, SentinelEvent,
            )
            self.sentinel_registry = load_sentinels(self.settings.workdir)
            self.sentinel_registry.reset_once_flags()
            await fire_event(
                self.sentinel_registry,
                SentinelEvent.SESSION_START,
                session_id=self.session_id,
                cwd=str(self.settings.workdir),
                permission_mode=self.agent.permission_mode if self.agent else "default",
            )
        except Exception:
            self.sentinel_registry = None  # type: ignore[assignment]
        # Round-29 Track H: crash-detection probe. On launch, check if
        # the most recent prior session has a state.json snapshot that
        # was never followed by a clean shutdown. If so, surface a
        # one-line nudge offering /resume <sid>. Best-effort; never
        # blocks startup.
        try:
            self._maybe_offer_crash_resume()
        except Exception:
            pass
        self.query_one("#prompt", Input).focus()
        self._spinner_task = asyncio.create_task(self._spin())
        # Start the user's custom statusline runner (no-op if no script).
        from prometheus.ui.statusline import StatuslineRunner
        self._statusline_runner = StatuslineRunner()
        self._statusline_runner.start(self)

    async def on_unmount(self) -> None:
        # Restore the terminal to a clean state. This prevents the next
        # shell process from being confused by stuck escape sequences,
        # leftover mouse-mode flags, etc. Anthropic shipped a similar
        # fix in v2.1.85 — terminals were left in enhanced keyboard mode.
        try:
            import sys as _sys
            # Re-enable mouse capture (we disabled it for selection).
            self._enable_mouse_capture()
            # Show cursor + reset attributes.
            _sys.__stdout__.write("\x1b[?25h\x1b[0m")
            _sys.__stdout__.flush()
        except Exception:
            pass
        if self._spinner_task:
            self._spinner_task.cancel()
        if hasattr(self, "_statusline_runner"):
            try:
                self._statusline_runner.stop()
            except Exception:
                pass
        # Reap any running MCP servers — Job Object handles this on
        # Windows, but explicit shutdown gives the server a chance to
        # write its own cleanup state and avoids zombie processes on
        # POSIX.
        for srv in list(getattr(self, "_mcp_servers", {}).values()):
            try:
                await srv.shutdown(grace_ms=500)
            except Exception:
                pass
        # Cancel async agent jobs cleanly so we don't orphan them.
        try:
            await self.async_jobs.shutdown_all()
        except Exception:
            pass
        # Kill any foreground bash that's still attached — audit P1
        # called out orphaned npm/winget on quit. Job Object handles
        # MCP children on Windows; this catches the run_bash path.
        proc = getattr(self, "_fg_bash_proc", None)
        if proc is not None and proc.returncode is None:
            try:
                proc.kill()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                pass
        # Cancel any in-flight async tasks the app owns so the event loop
        # doesn't complain about pending tasks at shutdown.
        for t in (self._idle_bell_task, self._busy_task):
            if t and not t.done():
                t.cancel()
        # Reap background bash subprocesses we adopted via Ctrl+B.
        try:
            for job in self.bg_jobs.list():
                if not job.finished:
                    try:
                        job.proc.kill()
                    except Exception:
                        pass
        except Exception:
            pass
        if self.client:
            await self.client.__aexit__(None, None, None)

    # ---------- helpers ----------

    def _log(self, renderable: Any) -> None:
        """Write to the chat log, never raising.

        Trailing whitespace is stripped so copy-paste doesn't carry it
        (Claude Code Issue #18170). Leading whitespace is preserved so
        ASCII art / nested bullets render right (Claude Code v2.1.105).
        Any rendering exception is swallowed; the TUI must never die
        because of one bad line — public users would lose their session.
        """
        try:
            from rich.text import Text as _Text
            if isinstance(renderable, _Text):
                renderable = renderable.copy()
                renderable.rstrip()
        except Exception:
            pass
        try:
            self.query_one("#chat-log", RichLog).write(renderable)
        except Exception:
            # In tests we sometimes write outside an active screen; in
            # prod a corrupt Renderable shouldn't kill the app.
            try:
                logger.exception("chat-log write failed")
            except Exception:
                pass

    def _update_status(self) -> None:
        sb: StatusBar = self.query_one("#status-bar", StatusBar)
        sb.model = self.settings.model
        cwd = self.settings.workdir
        try:
            home = Path.home()
            display = "~/" + str(cwd.relative_to(home)).replace("\\", "/") if cwd.is_relative_to(home) else str(cwd)
        except (ValueError, OSError):
            display = str(cwd)
        sb.folder = display
        # Round-46/96.2: metrics on the bottom strip.
        #
        # Round-96.2 fix: `sb.tokens` now means ACTIVE context tokens
        # (the in-memory message buffer), not the session-lifetime
        # cumulative sum. The previous behavior — adding every input
        # and output token across the session — produced "1.4m" on
        # resumed sessions and made users (correctly) think the
        # context budget was blown when really only 12k was active.
        # The cumulative number moves to `session_tokens_total`
        # (admin-only, opt-in via PROMETHEUS_SHOW_SESSION_TOKENS=1).
        if self.agent and self.agent.messages:
            approx = sum(len(json.dumps(m, default=str)) // 4 for m in self.agent.messages)
            sb.tokens = approx
            sb.ctx_pct = min(100, int(approx * 100 / APPROX_CTX_TOKENS))
        else:
            sb.tokens = 0
            sb.ctx_pct = 0
        sb.session_tokens_total = self._tokens_total_in + self._tokens_total_out
        # Round-96.7: feed per-turn output into the activity rail's
        # live-token reactive so users see token movement in real time
        # during streaming. Resets on turn start (in the busy block).
        try:
            al = self.query_one("#activity", ActivityLine)
            # Round 96.27: feed the in-progress todo subject into
            # the rail so the label reads as the live task name
            # (Claude Code rhythm). Empty when no in-progress item
            # exists — rail falls back to lifecycle labels.
            try:
                if self.agent and self.agent.todos:
                    in_progress = next(
                        (
                            t for t in self.agent.todos
                            if t.get("status") == "in_progress"
                        ),
                        None,
                    )
                    al.current_task = (
                        in_progress.get("subject", "") if in_progress else ""
                    )
                else:
                    al.current_task = ""
            except Exception:
                al.current_task = ""
            al.live_tokens = int(getattr(self, "_turn_tokens_out", 0) or 0)
            # Round 96.17: feed an input-direction signal that's
            # populated during streaming too. `_turn_tokens_in` is
            # only set on the post-stream `usage` event; before
            # that, fall back to the active-context approx (literal
            # prompt size — same 4-bytes/token rule the bottom HUD
            # uses).
            real_in = int(getattr(self, "_turn_tokens_in", 0) or 0)
            ctx_in = int(approx) if "approx" in locals() else 0
            al.live_tokens_in = max(real_in, ctx_in)
            # Round 96.19: direction is EVENT-DRIVEN, not derived
            # from tick deltas. The round-96.18 delta-picker never
            # fired `up` in live runs because `_update_status` is
            # invoked mostly during text streaming (always a `down`
            # delta) — the input-grows phase between iterations
            # passed through faster than the next status tick could
            # observe. The new mechanism: agent-event handlers
            # (`iteration`, `text`, `tool_result`) write directly
            # to `self._live_token_dir`, and we just forward that
            # to the rail. Defaults to `up` at turn start because
            # the FIRST thing any turn does is load context.
            al.live_token_dir = getattr(self, "_live_token_dir", "up")
            # Round 96.16: feed `thought for Ys` to the rail using
            # the same elapsed - tool - approval math the post-turn
            # summary uses. Suppressed by the rail when < 2s.
            try:
                _elapsed = max(
                    0,
                    int(time.monotonic() - self._busy_started)
                    if getattr(self, "_busy_started", 0)
                    else 0,
                )
                _tool = int(getattr(self, "_turn_tool_runtime_s", 0) or 0)
                _wait = int(getattr(self, "_turn_approval_wait_s", 0) or 0)
                al.live_thought_s = max(0, _elapsed - _tool - _wait)
            except Exception:
                al.live_thought_s = 0
        except Exception:
            pass
        sb.cost_usd = self._cost_total_usd
        try:
            _cap_raw = os.getenv("PROMETHEUS_DAILY_USD_LIMIT", "") or "0"
            sb.cap_usd = max(0.0, float(_cap_raw))
        except (ValueError, TypeError):
            sb.cap_usd = 0.0
        try:
            hdr = self.query_one("#session-header", SessionHeader)
            hdr.label = self._session_label
        except Exception:
            pass
        pb: PermissionBar = self.query_one("#perm-bar", PermissionBar)
        pb.mode = self.agent.permission_mode if self.agent else "default"
        # Round 97: refresh the SubAgentPanel from the manager's
        # snapshot. Cheap — sync() reuses existing cards and only
        # mounts/unmounts on actual delta. Tied to the existing
        # rail tick so it inherits the 10 Hz cadence without a new
        # timer.
        try:
            if self.subagent_panel is not None:
                tasks = self.subagent_manager.tasks()
                self.subagent_panel.sync(tasks)
        except Exception:
            # The panel might be mid-mount or torn down; skip this
            # tick — next tick will retry.
            pass

    async def _spin(self) -> None:
        sb: StatusBar = self.query_one("#status-bar", StatusBar)
        al: ActivityLine = self.query_one("#activity", ActivityLine)
        # 10 Hz spinner — Claude Code spins at this rate. 1 Hz felt
        # frozen on short operations; users assumed the app had hung.
        # The braille glyphs animate smoothly at 10 Hz with negligible
        # CPU cost (just two reactive updates per tick).
        SPIN_INTERVAL = 0.1
        # The activity line's elapsed-seconds counter only changes on
        # second boundaries; track the last value and skip redundant
        # writes so we're not thrashing reactive watchers 10×/sec.
        last_elapsed = -1
        # Round-22: per Claude-parity research, the spinner + elapsed
        # counter IS the progress signal. We no longer append a
        # 30-second reassurance line — Claude Code doesn't, and
        # screenshots showed it accumulating noise on long bash runs
        # that already had a visible spinner.
        try:
            while True:
                if sb.busy:
                    sb.spinner_frame = (sb.spinner_frame + 1) % 100
                    al.spinner_frame = sb.spinner_frame
                    if self._busy_started > 0:
                        elapsed = int(time.monotonic() - self._busy_started)
                        if elapsed != last_elapsed:
                            al.elapsed_s = elapsed
                            last_elapsed = elapsed
                else:
                    last_elapsed = -1
                await asyncio.sleep(SPIN_INTERVAL)
        except asyncio.CancelledError:
            return

    def _notify(self, msg: str) -> None:
        # Internal notifications. Per spec — these do NOT appear in chat.
        logger.info("notify: %s", msg)

    def _audit(self, action: str, data: dict[str, Any]) -> None:
        try:
            self.session_store.audit(self.session_id, action, data)
        except Exception:
            logger.exception("audit failed")

    # ---------- approval flow ----------

    async def _request_approval(
        self, tool: str, detail: str, meta: dict | None = None,
    ) -> bool:
        if self.agent and self.agent.permission_mode == "skipAll":
            return True
        if self.agent and self.agent.permission_mode == "acceptEdits" and tool in (
            "write_file", "edit_file", "multi_edit", "todo_write"
        ):
            return True
        if self.agent and self.agent.permission_mode == "plan":
            return False
        # Round 97.3: per-session approval cache check. When the
        # user picked "Yes, and don't ask again this session" on a
        # prior matching call, auto-approve. The cache key is
        # (tool, head_token) — for run_bash, head_token is the
        # first whitespace-token of the command (e.g. "pwd"). For
        # other tools, head_token is "*" so any same-tool request
        # matches.
        cache_key = self._approval_cache_key(tool, detail)
        if cache_key in self._session_always_yes:
            try:
                self._audit("approval_cache_hit", {
                    "tool": tool, "key": cache_key,
                    "from_agent": (meta or {}).get("from_agent_name", ""),
                })
            except Exception:
                pass
            return True
        # Round-20: get_running_loop() — get_event_loop() is deprecated
        # and under Textual's loop-recreate path returns the wrong loop
        # (architectural review #3).
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[str] = loop.create_future()
        self._pending_approval = fut  # type: ignore[assignment]
        # Round-22: Claude-parity approval card. The internal `tool`
        # name (e.g. `run_bash`, `write_file`) is hidden from the user;
        # the header is a human-readable label and the body is the
        # caller-supplied `detail` verbatim. Caller is responsible for
        # formatting `detail` as primary-line + optional secondary
        # description separated by `\n`.
        _HEADERS = {
            "run_bash": "Bash command",
            "edit_file": "Edit file",
            "multi_edit": "Edit file (multi)",
            "write_file": "Write file",
            "apply_patch": "Apply patch",
            "web_fetch": "Fetch URL",
            "web_search": "Web search",
            "todo_write": "Update plan",
        }
        header = _HEADERS.get(tool, tool.replace("_", " ").title())
        # Round-22: compute don't-ask-again prefix from the parsed
        # command (Bash) or tool name (everything else). For Bash we
        # take the first whitespace-delimited token.
        kind = tool
        if tool == "run_bash":
            first_line = detail.splitlines()[0] if detail else ""
            cmd_token = first_line.strip().split()[0] if first_line.strip() else ""
            kind = cmd_token or "this command"
        widget = InlineApproval(detail, header=header, kind=kind, meta=meta)
        self._approval_widget = widget
        # MOUNT it for real so reactive `selected` updates re-render live.
        try:
            slot = self.query_one("#picker-slot", Vertical)
            await slot.mount(widget)
        except Exception:
            logger.exception("failed to mount InlineApproval")
        # Round-95 turn-6: status rail switches to "Awaiting approval"
        # while the approval card is mounted, so the user never sees
        # "still thinking" sitting on top of a card asking THEM to
        # decide. Cleared in the finally branch below.
        try:
            al = self.query_one("#activity", ActivityLine)
            al.phase = "approval"
        except Exception:
            pass
        # Round-95 turn-7: stamp the wall-clock when the approval card
        # mounts so the final activity-summary can subtract the user's
        # decision time from the agent's apparent "thinking" time. The
        # previous summary lumped all 48s of a turn together, even
        # when 26s of that was just the user reading the card — making
        # PrometheUS look slow when most of the wait was off-loop.
        _approval_started_at = time.monotonic()
        try:
            inp = self.query_one("#prompt", Input)
            inp.placeholder = "↑↓ navigate · 1/2/3 direct · enter commit · esc cancel"
            inp.disabled = True
        except Exception:
            pass
        try:
            # 5-minute timeout — if a user walks away mid-prompt the
            # agent is otherwise frozen forever (audit P1). Auto-deny
            # so the loop can wind up cleanly.
            choice = await asyncio.wait_for(fut, timeout=300)
        except asyncio.TimeoutError:
            choice = "no"
            self._log(system_dim(
                "approval timed out (5 min) — denied. "
                "Re-issue the request to retry."
            ))
        finally:
            self._pending_approval = None
            self._approval_widget = None
            # Round-95 turn-7: book-keep the wait. Even on auto-deny
            # (5-min timeout) we record so an idle session doesn't
            # silently bleed into "agent thinking" time.
            try:
                wait_s = max(0.0, time.monotonic() - _approval_started_at)
                if hasattr(self, "_turn_approval_wait_s"):
                    self._turn_approval_wait_s += float(wait_s)
            except Exception:
                pass
            # Unmount the live picker.
            try:
                widget.remove()
            except Exception:
                pass
            try:
                inp = self.query_one("#prompt", Input)
                inp.disabled = False
                inp.focus()
            except Exception:
                pass
            # Round-95 turn-6: drop the rail back to the
            # planning/working default once the user has decided.
            try:
                al = self.query_one("#activity", ActivityLine)
                al.phase = "thinking"
            except Exception:
                pass
            self._restore_input_placeholder()
        if choice == "always":
            # Round 97.3: cache the (tool, head_token) pair instead
            # of globally elevating permission_mode to acceptEdits.
            # The "Yes, and don't ask again for `pwd`" UI text led
            # users to believe ONLY pwd was being approved, but the
            # old behavior approved ALL writes for the rest of the
            # session. The cache form matches the UI promise.
            self._session_always_yes.add(cache_key)
            try:
                self._audit("approval_cache_add", {
                    "tool": tool, "key": cache_key,
                })
            except Exception:
                pass
            return True
        if choice == "yes":
            return True
        return False

    @staticmethod
    def _approval_cache_key(tool: str, detail: str) -> str:
        """Round 97.3: build the per-session approval cache key.
        For run_bash, the key is `run_bash:<head_token>` (e.g.
        `run_bash:pwd`) so the cache scopes per-command. For other
        tools, the key is `<tool>:*` because non-bash approvals
        usually have a path/url payload too rich to glob over."""
        if tool == "run_bash":
            first_line = detail.splitlines()[0] if detail else ""
            head = first_line.strip().split(maxsplit=1)
            head_tok = head[0] if head else "*"
            return f"run_bash:{head_tok}"
        return f"{tool}:*"

    # ---------- input handling ----------

    def on_paste(self, event: Any) -> None:
        """Multi-line pastes get collapsed to a placeholder.

        Normalizes CRLF/CR → LF before processing — Anthropic shipped
        this fix three separate times because Windows clipboards and
        Xcode insert CRLF and the original code inserted blank lines
        (Claude Code v2.1.119).

        Textual sends `Paste(text=...)` for bracketed-paste content. If
        the pasted blob contains a newline, store it under a token like
        `[Pasted #1: 47 lines, 1.2K]` and insert the placeholder into the
        Input. On submit we substitute the original text back. Single-
        line pastes pass through unchanged.
        """
        try:
            text = event.text
        except Exception:
            return
        if not text:
            return
        # Normalize CRLF / lone CR → LF.
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        if "\n" not in text:
            return  # let Textual paste it normally
        try:
            inp = self.query_one("#prompt", Input)
        except Exception:
            return
        self._paste_seq += 1
        token = f"[Pasted #{self._paste_seq}]"
        self._paste_buffer[token] = text
        n_lines = text.count("\n") + 1
        size = f"{len(text):,}"
        placeholder = f"[Pasted #{self._paste_seq}: {n_lines} lines, {size} chars]"
        # Replace newlines/tabs in the displayed prompt so the Input stays single-line.
        before = inp.value[: inp.cursor_position]
        after = inp.value[inp.cursor_position:]
        inp.value = before + placeholder + after
        inp.cursor_position = len(before) + len(placeholder)
        try:
            event.stop()
        except Exception:
            pass

    def _substitute_pastes(self, text: str) -> str:
        """Expand any [Pasted #N: M lines, K chars] placeholders back to original blobs."""
        import re
        for n_str, original in list(self._paste_buffer.items()):
            n = n_str.replace("[Pasted #", "").rstrip("]")
            text = re.sub(
                rf"\[Pasted #{re.escape(n)}(?::[^\]]*)?\]",
                lambda _m, o=original: o,
                text,
            )
        return text

    def on_input_changed(self, event: Input.Changed) -> None:
        """Live filter for slash + @ popups."""
        if event.input.id != "prompt":
            return
        # User started typing — silence the idle-bell.
        self._cancel_idle_bell()
        try:
            slash_sug: SlashSuggestions = self.query_one("#slash-sug", SlashSuggestions)
            file_sug: FileSuggestions = self.query_one("#file-sug", FileSuggestions)
        except Exception:
            return
        text = event.value or ""
        # Suspend popups during a question prompt.
        if self._pending_question:
            slash_sug.matches = []
            file_sug.matches = []
            return

        # --- Slash menu ---
        if text.startswith("/"):
            file_sug.matches = []
            rest = text[1:]
            if " " in rest:
                slash_sug.matches = []
            elif self.slash:
                # Order: recently-used first, then alphabetical.
                ordered_names = list(self.slash.recent) + [
                    n for n in self.slash.names() if n not in self.slash.recent
                ]
                slash_sug.matches = [
                    (name, self.slash.cmds[name].summary)
                    for name in ordered_names
                    if name in self.slash.cmds and (not rest or name.startswith(rest))
                ]
                slash_sug.selected = 0
            return

        # --- @ file picker ---
        # Look back from the cursor to find the most recent unmatched @ token.
        slash_sug.matches = []
        last_at = text.rfind("@")
        if last_at < 0 or (last_at > 0 and not text[last_at - 1].isspace()):
            file_sug.matches = []
            return
        token = text[last_at + 1:]
        if " " in token or "\t" in token or "\n" in token:
            file_sug.matches = []
            return
        file_sug.matches = self._fuzzy_files(token)[:30]
        file_sug.selected = 0

    def _fuzzy_files(self, token: str) -> list[str]:
        """Return up to ~50 files matching the @ token.

        Walks the workdir without following symlinks (so a self-pointing
        symlink loop doesn't freeze the input on every keystroke) and
        caps total paths visited at 5000 so a node_modules-style giant
        tree never makes typing janky.
        """
        import os
        try:
            from prometheus.tools.ignore import GitIgnore
            gi = GitIgnore.for_workdir(self.settings.workdir)
        except Exception:
            class _Pass:
                def is_ignored(self, p): return False
            gi = _Pass()
        token_lower = token.lower()
        out: list[tuple[int, str]] = []
        skip_exts = {".pyc", ".pyo", ".exe", ".dll", ".so", ".dylib", ".bin",
                     ".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf",
                     ".zip", ".tar", ".gz", ".db"}
        from pathlib import Path as _P
        scanned = 0
        try:
            for root, dirs, files in os.walk(self.settings.workdir, followlinks=False):
                root_p = _P(root)
                # Drop ignored / always-ignored directories in-place so
                # os.walk doesn't recurse into them.
                dirs[:] = [d for d in dirs if not gi.is_ignored(root_p / d)]
                for fname in files:
                    scanned += 1
                    if scanned > 5000:
                        break
                    suf = _P(fname).suffix.lower()
                    if suf in skip_exts:
                        continue
                    p = root_p / fname
                    if gi.is_ignored(p):
                        continue
                    try:
                        rel = p.relative_to(self.settings.workdir).as_posix()
                    except Exception:
                        continue
                    rel_l = rel.lower()
                    if not token_lower:
                        out.append((0, rel))
                    else:
                        idx = rel_l.find(token_lower)
                        if idx >= 0:
                            out.append((idx, rel))
                        else:
                            pos = 0
                            ok = True
                            for ch in token_lower:
                                pos = rel_l.find(ch, pos)
                                if pos < 0:
                                    ok = False
                                    break
                                pos += 1
                            if ok:
                                out.append((10000 + len(rel), rel))
                    if len(out) >= 200:
                        break
                if scanned > 5000 or len(out) >= 200:
                    break
        except Exception:
            pass
        out.sort(key=lambda t: (t[0], len(t[1])))
        return [path for _, path in out]

    async def on_key(self, event: Any) -> None:
        # Round-21: scrollback hijack. PageUp/PageDown/Shift+PageUp/
        # Shift+PageDown go directly to the chat log even when the
        # Input has focus and the agent is busy. Per the user-research
        # the loudest TUI complaint is "I can't scroll up while the
        # agent is running" — Textual's `priority=True` binding alone
        # wasn't enough on Windows Terminal because the Input widget
        # consumes navigation keys at the widget layer. Intercepting
        # in on_key BEFORE any widget handler runs side-steps that.
        nav_key = getattr(event, "key", "")
        if nav_key in ("pageup", "pagedown", "shift+pageup", "shift+pagedown",
                        "ctrl+home", "ctrl+end"):
            try:
                if nav_key == "pageup":
                    self.action_scroll_page_up()
                elif nav_key == "pagedown":
                    self.action_scroll_page_down()
                elif nav_key in ("shift+pageup", "ctrl+home"):
                    self.action_scroll_home()
                elif nav_key in ("shift+pagedown", "ctrl+end"):
                    self.action_scroll_end()
                event.stop()
                event.prevent_default()
                return
            except Exception:
                pass
        # Prompt-history navigation (readline-style). Active when:
        #   - the Input has focus, no popups are open, no picker is up, and
        #   - the user pressed Up or Down.
        try:
            inp_for_hist = self.query_one("#prompt", Input)
        except Exception:
            inp_for_hist = None
        no_popup = (
            (self._pending_question is None or self._pending_question.done())
            and (self._pending_approval is None or self._pending_approval.done())
        )
        try:
            slash_open = bool(self.query_one("#slash-sug", SlashSuggestions).matches)
            file_open = bool(self.query_one("#file-sug", FileSuggestions).matches)
        except Exception:
            slash_open = file_open = False
        if (
            no_popup
            and not slash_open
            and not file_open
            and inp_for_hist is not None
            and event.key in ("up", "down")
            and self._history
        ):
            if event.key == "up":
                # Save current draft on first Up so Down can return to it.
                if self._history_idx is None:
                    self._history_draft = inp_for_hist.value
                    self._history_idx = len(self._history) - 1
                else:
                    self._history_idx = max(0, self._history_idx - 1)
                inp_for_hist.value = self._history[self._history_idx]
                inp_for_hist.cursor_position = len(inp_for_hist.value)
                event.stop(); event.prevent_default(); return
            if event.key == "down":
                if self._history_idx is None:
                    return
                if self._history_idx >= len(self._history) - 1:
                    self._history_idx = None
                    inp_for_hist.value = getattr(self, "_history_draft", "")
                else:
                    self._history_idx += 1
                    inp_for_hist.value = self._history[self._history_idx]
                inp_for_hist.cursor_position = len(inp_for_hist.value)
                event.stop(); event.prevent_default(); return

        # Approval picker: highest priority — runs before slash menu / questions.
        if self._pending_approval and not self._pending_approval.done() and self._approval_widget:
            w = self._approval_widget
            key = event.key
            mapping = {"y": "yes", "a": "always", "n": "no"}
            if key in mapping:
                self._pending_approval.set_result(mapping[key])  # type: ignore[arg-type]
                event.stop(); event.prevent_default(); return
            if key == "down":
                w.select_next()
                event.stop(); event.prevent_default(); return
            if key == "up":
                w.select_prev()
                event.stop(); event.prevent_default(); return
            if key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < len(w.LABELS):
                    self._pending_approval.set_result(["yes", "always", "no"][idx])  # type: ignore[arg-type]
                    event.stop(); event.prevent_default(); return
            if key == "enter":
                self._pending_approval.set_result(["yes", "always", "no"][w.selected])  # type: ignore[arg-type]
                event.stop(); event.prevent_default(); return
            if key == "escape":
                self._pending_approval.set_result("no")  # type: ignore[arg-type]
                event.stop(); event.prevent_default(); return
            # Swallow any other key while the picker is up so the input
            # stays disabled and we don't accidentally type elsewhere.
            event.stop(); event.prevent_default(); return

        # @ file suggestions: arrow nav + tab pick. (Higher priority than slash.)
        try:
            file_sug: FileSuggestions = self.query_one("#file-sug", FileSuggestions)
        except Exception:
            file_sug = None  # type: ignore
        if file_sug is not None and file_sug.matches and not self._pending_question:
            key = event.key
            if key == "down":
                file_sug.select_next()
                event.stop(); event.prevent_default(); return
            if key == "up":
                file_sug.select_prev()
                event.stop(); event.prevent_default(); return
            if key == "escape":
                file_sug.matches = []
                event.stop(); event.prevent_default(); return
            if key == "tab":
                pick = file_sug.matches[file_sug.selected]
                try:
                    inp = self.query_one("#prompt", Input)
                    text = inp.value
                    last_at = text.rfind("@")
                    new_value = text[: last_at + 1] + pick + " "
                    inp.value = new_value
                    inp.cursor_position = len(new_value)
                except Exception:
                    pass
                file_sug.matches = []
                event.stop(); event.prevent_default(); return

        # Slash suggestions: arrow nav + tab pick.
        try:
            sug: SlashSuggestions = self.query_one("#slash-sug", SlashSuggestions)
        except Exception:
            sug = None  # type: ignore
        if sug is not None and sug.matches and not self._pending_question:
            key = event.key
            if key == "down":
                sug.select_next()
                event.stop(); event.prevent_default(); return
            if key == "up":
                sug.select_prev()
                event.stop(); event.prevent_default(); return
            if key == "escape":
                sug.matches = []
                event.stop(); event.prevent_default(); return
            # Tab and Enter both complete the highlighted match
            # when the user hasn't yet typed the full command name.
            # Once the typed value matches the selected name
            # exactly (`/help` typed; `/help` highlighted), Enter
            # falls through to normal submit so `/help<Enter>`
            # still works.
            if key in ("tab", "enter"):
                name, _desc = sug.matches[sug.selected]
                try:
                    inp = self.query_one("#prompt", Input)
                    typed = inp.value or ""
                    full = "/" + name
                    already_complete = (
                        key == "enter" and typed.strip() == full
                    )
                    if already_complete:
                        # Let Enter through — the user already
                        # has the full slash command typed and is
                        # submitting it.
                        sug.matches = []
                    else:
                        inp.value = full + " "
                        inp.cursor_position = len(inp.value)
                        sug.matches = []
                        event.stop()
                        event.prevent_default()
                        return
                except Exception:
                    sug.matches = []
                    event.stop()
                    event.prevent_default()
                    return

        # Question picker key handling. Active only while a question is pending.
        if self._pending_question and not self._pending_question.done() and self._question_widget:
            w = self._question_widget
            key = event.key
            if key == "up":
                w.select_prev()
                event.stop()
                event.prevent_default()
                return
            if key == "down":
                w.select_next()
                event.stop()
                event.prevent_default()
                return
            if key == "escape":
                self._pending_question.set_result("cancel")
                event.stop()
                event.prevent_default()
                return
            if key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < len(w.options):
                    self._pending_question.set_result(w.options[idx])
                    event.stop()
                    event.prevent_default()
                    return
            if key == "enter":
                self._pending_question.set_result(w.options[w.selected])
                event.stop()
                event.prevent_default()
                return
            if key == "tab":
                # User wants to type a custom answer instead.
                self._pending_question.set_result("__amend__")
                event.stop()
                event.prevent_default()
                return

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        text = self._substitute_pastes(event.value).strip()
        event.input.value = ""
        self._paste_buffer.clear()
        # Always clear popups on submit.
        try:
            self.query_one("#slash-sug", SlashSuggestions).matches = []
        except Exception:
            pass
        try:
            self.query_one("#file-sug", FileSuggestions).matches = []
        except Exception:
            pass
        if not text:
            return
        # An approval picker disables the Input, so this path won't fire
        # while one is up. We still bail defensively in case of races.
        if self._pending_approval and not self._pending_approval.done():
            return
        # Round-29 Track B: idle-return nudge. Per Anthropic v2.1.84,
        # when a user types after 75+ minutes of session idle, the
        # agent's working context is stale (file state may have
        # changed, intermediate plans no longer apply). We surface
        # a single advisory line — not a hard gate, just a hint that
        # /clear or /resume may produce better results.
        import time as _t_idle
        now_w = _t_idle.time()
        last_w = getattr(self, "_last_user_input_at", 0.0)
        IDLE_NUDGE_S = 75 * 60  # 75 minutes
        if last_w and (now_w - last_w) > IDLE_NUDGE_S and not getattr(self, "_idle_nudged_this_session", False):
            self._idle_nudged_this_session = True
            mins = int((now_w - last_w) / 60)
            self._log(system_dim(
                f"  ⏱ session has been idle ~{mins} min. Older context "
                f"may be stale — consider /clear (fresh start) or /resume "
                f"<sid> (rebuild from snapshot) for best results. "
                f"Continuing this turn anyway."
            ))
        self._last_user_input_at = now_w
        # Round-21: queue input while busy. Per the user-research the
        # whole field converged on, you should never tell a user "agent
        # already busy" — Codex / Cursor / Claude Code all queue. We
        # park the new prompt in `_queued_prompts` and surface a sticky
        # "Pending: N message(s)" status. The completion callback
        # dequeues and dispatches FIFO. Slash and bang commands also
        # queue so a user can type `/cost` mid-build and see it after
        # the bash finishes — matches conversational expectations.
        if self._busy_task and not self._busy_task.done():
            if not hasattr(self, "_queued_prompts"):
                self._queued_prompts = []
            self._queued_prompts.append(text)
            from prometheus.ui.theme import GLYPH_QUEUED
            self._log(system_dim(
                f"{GLYPH_QUEUED} queued ({len(self._queued_prompts)}): "
                f"{text[:60]}{'…' if len(text) > 60 else ''}"
            ))
            self._update_status()
            return
        await self._dispatch_text(text)
        return

    async def _dispatch_text(self, text: str) -> None:
        """Round-21: shared post-validation dispatch used by both the
        Input.Submitted handler and the busy-task dequeue path. Routes
        slash / bang / `?` / `#` / @file / multipart-image / plain
        prompts identically so a queued message behaves the same as a
        typed-now message."""
        # Hide welcome card after the first real input.
        try:
            wc = self.query_one(WelcomeCard)
            wc.set_class(True, "-hidden")
        except Exception:
            pass
        # Save to history (skip exact duplicates of the last entry).
        if not self._history or self._history[-1] != text:
            self._history.append(text)
        self._history_idx = None
        self._history_draft = ""
        # Slash/bang routing first (no @file expansion for slash commands).
        if text.startswith("/"):
            self._log(user_line(text))
            assert self.slash
            await self.slash.dispatch(text)
            self._update_status()
            return
        if text.startswith("!"):
            self._log(user_line(text))
            cmd = text[1:].strip()
            await self._exec_bang(cmd)
            return
        # `?` alone → quick help. `?<query>` → ask the agent a meta question.
        if text == "?":
            self._log(user_line(text))
            assert self.slash
            await self.slash.dispatch("/help")
            return
        # `#<text>` — append to PROMETHEUS.md (project memory).
        if text.startswith("#"):
            note = text[1:].strip()
            self._log(user_line(text))
            if not note:
                self._log(error_line("usage: #<note to remember>"))
                return
            await self._append_project_memory(note)
            return
        # Plain prompt: expand @file references.
        prompt, attached = self._expand_at_files(text)
        self._log(user_line(text))
        for path, ok in attached:
            self._log(system_dim(f"  attached: {path}{'' if ok else ' (not found)'}"))
        # If images were pasted this turn, build a multipart user message.
        if self._image_paste.all():
            from prometheus.ui.image_paste import build_user_message_parts
            parts = build_user_message_parts(prompt, self._image_paste._items)
            n_imgs = sum(1 for p in parts if p.get("type") == "image_url")
            self._log(system_dim(f"  attached {n_imgs} image(s)"))
            self._image_paste.clear()
            await self._run_agent_multipart(parts)
        else:
            await self._run_agent(prompt)

    def _expand_at_files(self, text: str) -> tuple[str, list[tuple[str, bool]]]:
        """Replace @path tokens with a 'Attached file: <path>\\n```\\n<body>\\n```' block.

        Match @ followed by a non-space token. Quoted paths via @"foo bar/baz" are
        also supported. Files larger than 64KB are truncated.
        """
        import re
        attached: list[tuple[str, bool]] = []
        cwd = self.settings.workdir

        def _read(p: str) -> tuple[str, bool]:
            try:
                from pathlib import Path
                pp = Path(p)
                if not pp.is_absolute():
                    pp = cwd / pp
                if not pp.exists() or not pp.is_file():
                    return "", False
                data = pp.read_bytes()[:64 * 1024]
                return data.decode("utf-8", errors="replace"), True
            except Exception:
                return "", False

        # Order: quoted first to avoid greedy match
        out_chunks: list[str] = []
        last = 0
        token_rx = re.compile(r'@"([^"\n]+)"|@([^\s]+)')
        for m in token_rx.finditer(text):
            out_chunks.append(text[last:m.start()])
            path = m.group(1) or m.group(2)
            body, ok = _read(path)
            attached.append((path, ok))
            if ok:
                fence = "```"
                # Pick a language hint from extension
                from pathlib import Path
                lang_map = {".py": "python", ".js": "js", ".ts": "ts", ".tsx": "tsx",
                            ".rs": "rust", ".go": "go", ".java": "java", ".md": "md",
                            ".html": "html", ".css": "css", ".json": "json",
                            ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
                            ".sh": "bash", ".sql": "sql", ".c": "c", ".cpp": "cpp"}
                lang = lang_map.get(Path(path).suffix.lower(), "")
                out_chunks.append(f"\n[Attached file: {path}]\n{fence}{lang}\n{body}\n{fence}\n")
            else:
                out_chunks.append(f"@{path}")
            last = m.end()
        out_chunks.append(text[last:])
        return "".join(out_chunks), attached

    def _log_live_bash(self, chunk: str) -> None:
        """Round-25 Claude-parity progress surfacing.

        Per Track 4 of the deep research: Claude does NOT invent
        progress, but it DOES pass through real milestone-style lines
        when the underlying tool prints them (`pip install
        --progress-bar on`, `winget` fancy mode, `npm install` totals,
        `git clone` Counting/Receiving). We whitelist those patterns
        and surface them on the ActivityLine, replacing the silent-
        only behavior shipped in round 22. Raw columnar stdout (winget
        search rows, ls -l output) is still suppressed.

        Full output is persisted to <workdir>/.prometheus/logs/bash-
        <unix>.log for tail-from-another-pane workflows.
        """
        try:
            text = chunk.rstrip()
            if not text:
                return
            # Persist full chunk (best-effort).
            try:
                logs_dir = self.settings.workdir / ".prometheus" / "logs"
                logs_dir.mkdir(parents=True, exist_ok=True)
                fh = getattr(self, "_bash_live_log_fh", None)
                if fh is None:
                    import time as _t
                    self._bash_live_log_path = logs_dir / f"bash-{int(_t.time())}.log"
                    self._bash_live_log_fh = open(
                        self._bash_live_log_path, "a", encoding="utf-8", buffering=1,
                    )
                    fh = self._bash_live_log_fh
                fh.write(chunk)
                fh.flush()
            except Exception:
                pass
            # Strip ANSI + \r so we work on cleaned text.
            import re as _re
            cleaned = _re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", text)
            cleaned = cleaned.replace("\r", "\n")
            # Walk newest→oldest; first line that matches a milestone
            # pattern wins. Patterns are intentionally narrow — better
            # to show NOTHING than column-table noise.
            milestone = ""
            for line in reversed(cleaned.splitlines()):
                s = line.strip()
                if not s:
                    continue
                # 1. Percent progress: " 73%", "[####  ] 50%", "73% complete"
                if _re.search(r"\b\d{1,3}\s*%", s) and len(s) <= 120:
                    milestone = s; break
                # 2. Size progress: "12.3 MB / 45.6 MB", "downloaded 1.2GB"
                if _re.search(r"\d[\d.,]*\s*(KB|MB|GB|kB|MiB|GiB)\b", s, _re.I) and len(s) <= 120:
                    milestone = s; break
                # 3. Action milestones: Downloading / Installing / Cloning /
                #    Resolving / Building / Compiling / Extracting / Verifying /
                #    Fetching / Receiving / Counting / Done
                if _re.match(
                    r"^(Downloading|Installing|Cloning|Resolving|Building|"
                    r"Compiling|Extracting|Verifying|Fetching|Receiving|"
                    r"Counting|Linking|Reading|Updating|Checking|Done|"
                    r"Successfully|Starting|Running|Loading|Saving|"
                    r"Indexing|Caching|Pulling|Pushing|Adding|Removing|"
                    r"Created|Wrote)\b",
                    s, _re.I,
                ) and len(s) <= 120:
                    milestone = s; break
                # 4. "added N packages", "found 0 vulnerabilities" (npm)
                if _re.match(r"^(added|removed|changed|audited|found)\s+\d", s, _re.I):
                    milestone = s; break
            try:
                act = self.query_one("#activity", ActivityLine)
                act.last_output_line = milestone[:120] if milestone else ""
            except Exception:
                pass
        except Exception:
            pass

    def _maybe_offer_crash_resume(self) -> None:
        """Round-29 Track H: detect crashed previous session.

        Strategy: list the 5 most recent sessions from SessionStore.
        For each, check if state.json exists. If the newest snapshot
        is older than 30 seconds AND newer than 24 hours AND the
        session has a non-trivial message count, the user likely
        crashed (clean exits clear `_busy_task` before the snapshot
        finalizes). Surface a single advisory line offering /resume.
        Never blocks; never auto-resumes (per Claude-parity user
        choice).
        """
        import time as _ti
        try:
            sessions = self.session_store.list_sessions(limit=5)
        except Exception:
            return
        if not sessions:
            return
        now = _ti.time()
        for s in sessions:
            sid = s.get("id", "")
            if not sid or sid == self.session_id:
                continue
            try:
                state = self.session_store.load_state(sid)
            except Exception:
                continue
            if not state or not isinstance(state, dict):
                continue
            saved_at = state.get("saved_at", 0)
            if not saved_at:
                continue
            try:
                saved_at_f = float(saved_at)
            except (TypeError, ValueError):
                continue
            age = now - saved_at_f
            if age < 30:
                continue  # too recent — probably another live session
            if age > 86400:
                continue  # older than 24h — stale, don't nudge
            msgs = state.get("messages") or []
            if len(msgs) < 4:
                continue  # too short to be worth offering
            # Round-46: softened. No glyph (the ⏮ rendered as a teal
            # emoji box on Windows Terminal even with U+FE0E, and the
            # alarm tone wasn't appropriate for an ambient hint anyway).
            # Pure dim text reads as a quiet suggestion, not a warning.
            self._log(system_dim(
                f"  /resume {sid[:8]} to continue where you left off "
                f"({int(age / 60)} min ago, {len(msgs)} messages) "
                f"· /sessions to browse"
            ))
            return  # only surface ONE nudge, even if multiple match

    def _arm_idle_bell(self) -> None:
        """Schedule a bell + the OS-level title-bar attention to fire after
        IDLE_BELL_SECONDS of post-reply silence."""
        if not self._idle_bell_enabled:
            return
        self._cancel_idle_bell()

        async def _ring() -> None:
            try:
                await asyncio.sleep(self.IDLE_BELL_SECONDS)
            except asyncio.CancelledError:
                return
            try:
                import sys as _sys
                _sys.__stdout__.write("\a")
                _sys.__stdout__.flush()
            except Exception:
                pass
        self._idle_bell_task = asyncio.create_task(_ring())

    def _cancel_idle_bell(self) -> None:
        if self._idle_bell_task and not self._idle_bell_task.done():
            self._idle_bell_task.cancel()
        self._idle_bell_task = None

    async def _append_project_memory(self, note: str) -> None:
        """Append a note to PROMETHEUS.md in the workdir, creating it if needed.

        This is the `#<text>` shortcut. The model's next system prompt will
        include the updated memory.
        """
        from datetime import datetime
        target = self.settings.workdir / "PROMETHEUS.md"
        stamp = datetime.now().strftime("%Y-%m-%d")
        line = f"- {stamp}: {note}\n"
        try:
            if target.exists():
                with target.open("a", encoding="utf-8") as f:
                    f.write(line)
            else:
                target.write_text(
                    "# PrometheUS — project memory\n\n"
                    "Notes that should be available to every session.\n\n"
                    "## Notes\n" + line,
                    encoding="utf-8",
                )
        except Exception as e:
            self._log(error_line(f"could not write {target}: {e}"))
            return
        self._log(system_dim(f"saved to {target.name}: {note}"))
        # Force the next agent turn to re-read the system prompt with the
        # new memory injected.
        if self.agent and self.agent.messages and self.agent.messages[0].get("role") == "system":
            self.agent.messages[0]["content"] = self.agent.system_prompt()

    def _disable_mouse_capture(self) -> None:
        """Tell the terminal to stop reporting mouse events.

        Sequences (xterm CSI ? Pm l):
            ?1000l  basic mouse off
            ?1002l  cell-motion mouse off
            ?1003l  any-event mouse off
            ?1015l  urxvt extended off
            ?1006l  SGR extended off

        After these, mouse drag-select is handled by the terminal
        emulator (Windows Terminal, iTerm2, Terminal.app, GNOME Terminal,
        Alacritty…) using the regular shortcuts:
            • Windows Terminal:   left-click drag, Ctrl+Shift+C to copy
            • macOS Terminal:     left-click drag, Cmd+C to copy
            • iTerm2:             left-click drag, Cmd+C
            • GNOME Terminal:     left-click drag, Ctrl+Shift+C
            • Linux x11:          middle-click pastes the selection
        """
        import sys
        seq = "\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1015l\x1b[?1006l"
        try:
            sys.__stdout__.write(seq)
            sys.__stdout__.flush()
        except Exception:
            pass

    def _enable_mouse_capture(self) -> None:
        """Inverse of _disable_mouse_capture — restores Textual's mouse handling."""
        import sys
        seq = "\x1b[?1000h\x1b[?1003h\x1b[?1006h"
        try:
            sys.__stdout__.write(seq)
            sys.__stdout__.flush()
        except Exception:
            pass

    def _default_session_label(self) -> str:
        """The header label shown in the top SessionHeader strip.

        Round-47: dropped the "· YYYY-MM-DD" suffix per user feedback —
        CC doesn't put a date in its header and it read as debug noise.
        Now just the workdir basename, swapped to the first user prompt
        on first message (handled in _drive_agent).
        """
        try:
            return self.settings.workdir.name or "session"
        except Exception:
            return "session"

    def _restore_input_placeholder(self) -> None:
        """Set the Input placeholder to whatever fits the current state.

        The placeholder is the only first-glance affordance for many
        users; making it context-sensitive (Claude Code parity) means
        users see "thinking…" / "pick an option" / a generic hint
        depending on what's happening rather than a stale "ask anything"
        in every state.
        """
        try:
            inp = self.query_one("#prompt", Input)
        except Exception:
            return
        # Order: pickers > busy > mode-specific > default.
        if self._pending_question and not self._pending_question.done():
            inp.placeholder = "↑↓ to navigate · 1-9 to pick · enter / esc"
        elif self._pending_approval and not self._pending_approval.done():
            inp.placeholder = "↑↓ navigate · 1/2/3 direct · enter commit · esc cancel"
        elif self._busy_task and not self._busy_task.done():
            qd = getattr(self, "_queued_prompts", []) or []
            if qd:
                inp.placeholder = (
                    f"thinking…  ({len(qd)} queued)  esc to interrupt · "
                    f"enter to add another"
                )
            else:
                inp.placeholder = (
                    "thinking…  esc to interrupt · type to queue the next message"
                )
        elif self.agent and self.agent.permission_mode == "plan":
            inp.placeholder = "plan mode — read-only · /proceed to execute"
        elif self.agent and self.agent.permission_mode == "skipAll":
            inp.placeholder = "yolo mode — auto-approve writes/exec"
        else:
            # Round-95 turn-6: rotating commercial placeholder system.
            # The legacy `try "fix the failing test"` read as cheap and
            # confusing (looked like text was already typed). One
            # primary phrase + four short rotating examples; advances
            # one slot per call to _restore_input_placeholder so the
            # user sees variety without a CPU-burning timer. Index
            # state lives on the app so stays stable across renders.
            primary = "Ask PrometheUS to inspect, run, or fix this project…"
            rotation = [
                primary,
                "inspect this repo",
                "run the test suite",
                "explain the failing test",
                "fix the failing test",
            ]
            idx = getattr(self, "_placeholder_idx", 0) or 0
            inp.placeholder = rotation[idx % len(rotation)]
            self._placeholder_idx = (idx + 1) % len(rotation)

    def _derive_title_from_last_successful_bash(self) -> str:
        """Round-95 turn-8: walk `_recent_results` from newest to
        oldest, looking for a successful bash run whose output matches
        a known test-suite success pattern. Returns the polished
        title (e.g. "Tests passed: 267 in 3.26s") or "" if no such
        result exists.

        This is the title-derivation hierarchy: last successful test
        wins over assistant text, so a turn that failed discovery and
        then succeeded with the fallback pytest still ends with a
        clean ✓ summary instead of leaking the recovery-prose into
        the final line.
        """
        try:
            results = list(getattr(self, "_recent_results", []) or [])
        except Exception:
            return ""
        # Reuse the same regex set as fast_finalize so the wording
        # stays consistent across the two paths.
        try:
            from prometheus.agent.fast_finalize import _SUCCESS_PATTERNS
        except Exception:
            return ""
        # Newest to oldest.
        for label, rr in reversed(results):
            if rr is None:
                continue
            meta = (rr.metadata or {}) if hasattr(rr, "metadata") else {}
            exit_v = meta.get("exit")
            # Only run_bash results carry int exit; non-bash tools (and
            # discover_test_command on success) don't qualify here.
            if not isinstance(exit_v, int) or exit_v != 0:
                continue
            output = getattr(rr, "output", "") or ""
            for pat, template in _SUCCESS_PATTERNS:
                m = pat.search(output)
                if not m:
                    continue
                try:
                    return template.format(**m.groupdict())[:90]
                except (KeyError, IndexError):
                    return template[:90]
        return ""

    def _remember_result(self, label: str, result: Any) -> None:
        """Push a tool result into /expand history. Slash-tool commands
        and the agent loop both feed this so /expand sees a uniform list."""
        self._recent_results.append((label, result))
        if len(self._recent_results) > 6:
            self._recent_results = self._recent_results[-6:]

    async def ask_user_question(self, question: str, options: list[str]) -> str:
        """Live arrow-key picker. Mounted as a real widget so navigation is visible."""
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[str] = loop.create_future()
        self._pending_question = fut
        widget = QuestionPrompt(question, options)
        self._question_widget = widget
        try:
            slot = self.query_one("#picker-slot", Vertical)
            await slot.mount(widget)
        except Exception:
            logger.exception("failed to mount QuestionPrompt")
        try:
            inp = self.query_one("#prompt", Input)
            inp.placeholder = "↑↓ to navigate · 1-9 to pick · enter / esc"
            inp.disabled = True
        except Exception:
            pass
        try:
            return await fut
        finally:
            self._pending_question = None
            self._question_widget = None
            try:
                widget.remove()
            except Exception:
                pass
            try:
                inp = self.query_one("#prompt", Input)
                inp.disabled = False
                inp.focus()
            except Exception:
                pass
            self._restore_input_placeholder()


    async def _exec_bang(self, cmd: str) -> None:
        if not cmd:
            return
        tool = self.registry.get("run_bash")
        if tool is None:
            return
        ctx = self._make_ctx_for_direct_tool()
        result = await tool.execute({"command": cmd, "description": "user `!` shell"}, ctx)
        line_count = (result.output or "").count("\n") + 1
        self._log(
            receipt_summary_line(
                f"Bash $ {cmd[:80]}",
                result.summary,
                line_count,
                error=result.error,
            )
        )
        # User explicitly invoked `!` so show body inline, but indented.
        self._log(expanded_body(result))
        self._update_status()

    def _make_ctx_for_direct_tool(self) -> Any:
        # Used for `!` bang commands — bypasses agent, but still uses approval/audit hooks.
        from prometheus.tools.base import ToolContext

        return ToolContext(
            workdir=self.settings.workdir,
            permission_mode=self.agent.permission_mode if self.agent else "default",
            request_approval=self._request_approval,
            notify=self._notify,
            session_id=self.session_id,
            audit=self._audit,
            todos=self.agent.todos if self.agent else [],
            snapshots=self.agent.snapshots if self.agent else [],
            # Round 96.14: thread the agent's persistent read_history
            # so a `!cmd` bang call shares the same set with the live
            # agent (consistent guard semantics across surfaces).
            read_history=(
                self.agent.read_history
                if self.agent and hasattr(self.agent, "read_history")
                else set()
            ),
        )

    # ---------- agent run ----------

    async def _run_agent_multipart(self, content_parts: list[dict]) -> None:
        """Submit a user message with multipart content (text + images).

        Mirrors _run_agent but pushes a list-shaped content payload that
        OpenAI / OpenRouter / Anthropic all accept for vision models.
        """
        if not self.agent:
            return
        if self._busy_task and not self._busy_task.done():
            self._log(error_line("agent already busy — esc to interrupt"))
            return
        # Reuse _run_agent's spending-cap + busy state setup by passing
        # a synthetic prompt; the actual user message gets replaced
        # below before the model sees it.
        await self._run_agent("(multipart)", _multipart_parts=content_parts)

    async def _run_agent(self, prompt: str, *, _multipart_parts: list | None = None) -> None:
        if not self.agent:
            return
        if self._busy_task and not self._busy_task.done():
            self._log(error_line("agent already busy — esc to interrupt"))
            return
        # Round-30 P0: per-user daily TURN quota (NOT $-based; covers
        # free-tier users where cost=$0 but free-pool capacity still
        # has a per-day ceiling). Default 200 turns/day per install_id;
        # set PROMETHEUS_USER_DAILY_TURNS_LIMIT=0 to disable. When
        # exceeded, surface BYOK as the unlimited path. This is how
        # PrometheUS serves millions on $0 — every user uses their OWN
        # free OpenRouter quota when they hit the soft cap.
        try:
            daily_cap = int(float(os.getenv("PROMETHEUS_USER_DAILY_TURNS_LIMIT", "200") or 200))
        except ValueError:
            daily_cap = 200
        if daily_cap > 0:
            import time as _t
            today_key = _t.strftime("%Y-%m-%d", _t.gmtime())
            counter_state = getattr(self, "_daily_turn_counter", None)
            if counter_state is None or counter_state.get("date") != today_key:
                counter_state = {"date": today_key, "count": 0}
            count = int(counter_state.get("count", 0) or 0)
            if count >= daily_cap and not getattr(self, "_user_premium_key", None):
                self._log(error_line(
                    f"daily turn quota reached ({daily_cap} turns today). "
                    f"Two ways forward:\n"
                    f"  1) /byok <sk-or-...>  — paste your own free OpenRouter "
                    f"key; quota resets to YOUR daily limit (free models still work)\n"
                    f"  2) wait until tomorrow (UTC) — quota resets at 00:00\n"
                    f"  3) raise PROMETHEUS_USER_DAILY_TURNS_LIMIT or set =0 if "
                    f"you're the host."
                ))
                return
            counter_state["count"] = count + 1
            self._daily_turn_counter = counter_state
        # Spending-limit hard caps (round-13 cost conservation):
        # three layers protect a shared $10 pool from one runaway user:
        #   PROMETHEUS_DAILY_USD_LIMIT       — global daily pool
        #   PROMETHEUS_PER_SESSION_USD_LIMIT — per-app-instance cap
        #   PROMETHEUS_PER_TURN_USD_LIMIT    — kill-switch on a single turn
        # Free engines report cost=0 so these never fire for free-only
        # users — opt-in via env. With $0.50/session, a $10 pool serves
        # at least 20 distinct sessions before it drains.
        def _f(key: str) -> float:
            try:
                return float(os.getenv(key, "0") or 0)
            except ValueError:
                return 0.0
        global_cap = _f("PROMETHEUS_DAILY_USD_LIMIT")
        session_cap = _f("PROMETHEUS_PER_SESSION_USD_LIMIT")
        global_cost = float(getattr(self, "_cost_total_usd", 0.0) or 0.0)
        # Track per-session cost on the App so /clear resets it.
        if not hasattr(self, "_session_cost_usd"):
            self._session_cost_usd = 0.0
        if global_cap > 0 and global_cost >= global_cap:
            self._log(error_line(
                f"daily spend cap reached: ${global_cost:.4f} ≥ ${global_cap:.2f}. "
                f"Raise PROMETHEUS_DAILY_USD_LIMIT, /clear to reset, or "
                f"set your own key with /byok to bypass the pooled cap."
            ))
            return
        if session_cap > 0 and self._session_cost_usd >= session_cap:
            self._log(error_line(
                f"session spend cap reached: ${self._session_cost_usd:.4f} ≥ "
                f"${session_cap:.2f}. /clear to reset, or set "
                f"PROMETHEUS_PER_SESSION_USD_LIMIT higher."
            ))
            return
        # BYOK nudge: when global pool is ≥90% used, suggest /byok.
        # Round-15 hard-throttle: at ≥95% used, ARM the next-turn flag
        # so any escalation gets refused with a clear "/clear or /byok"
        # error. The free chain still works — only paid escalations are
        # gated. Without this, a runaway agent can drain the last 5%
        # of the pool before the user can react to the 90% nudge.
        if global_cap > 0 and not getattr(self, "_user_premium_key", None):
            pct = (global_cost / global_cap) if global_cap else 0
            nudge_threshold = _f("PROMETHEUS_BYOK_NUDGE_THRESHOLD") or 0.90
            throttle_threshold = _f("PROMETHEUS_BYOK_THROTTLE_THRESHOLD") or 0.95
            from prometheus.ui.theme import GLYPH_WARN
            if pct >= nudge_threshold and not getattr(self, "_byok_nudged", False):
                self._byok_nudged = True
                self._log(system_dim(
                    f"{GLYPH_WARN} pooled budget {int(pct*100)}% used — set your own key "
                    f"with /byok <sk-...> to bypass the pooled cap."
                ))
            if pct >= throttle_threshold:
                # Cancel any armed escalation so the next turn stays free-chain.
                if self.agent and hasattr(self.agent, "escalation"):
                    self.agent.escalation.escalate_next_turn = False
                    self.agent.escalation.next_turn_hard = False
                    self.agent.escalation.next_turn_sonnet = False
                self._byok_throttled = True
                self._log(system_dim(
                    f"{GLYPH_WARN} pooled budget {int(pct*100)}% used — paid escalations "
                    f"now blocked. Free engines still work. /byok <sk-...> "
                    f"to use your own key, or /clear to reset the meter."
                ))
        sb = self.query_one("#status-bar", StatusBar)
        al = self.query_one("#activity", ActivityLine)
        sb.busy = True
        al.busy = True
        # Round-95 turn-6: deterministic lifecycle labels. The activity
        # rail starts in the planning/working phase (no tool yet, no
        # approval pending). The phase shifts to "approval" / "running"
        # / "processing" as the agent loop progresses; never falls
        # through to the legacy verb-rotation pool that read as casual
        # chatbot fluff in commercial use.
        al.current_tool = ""
        al.phase = "thinking"
        al.elapsed_s = 0
        self._live_out_delta = 0
        self._turn_tokens_out = 0
        self._turn_tokens_in = 0
        self._turn_tool_calls = 0
        # Round-95 turn-7: separate the components of turn time so the
        # final summary doesn't conflate user-decision wait with agent
        # thinking. `_turn_tool_runtime_s` is the cumulative duration
        # of bash subprocesses (and any other tool that emits
        # `metadata.duration_s`). `_turn_approval_wait_s` is the
        # cumulative wall-clock time the agent was paused on a mounted
        # approval card waiting for the user. Both reset per user turn.
        self._turn_tool_runtime_s = 0.0
        self._turn_approval_wait_s = 0.0
        # Round 96.13: clear halt state at turn start so a previous
        # turn's halt doesn't bleed into this turn's summary.
        self._turn_halted = False
        self._turn_halt_error = ""
        # Round 96.19: event-driven direction picker. The turn always
        # opens with input growing (system prompt + history + new
        # user message about to be sent) — so default to `up`. The
        # text-delta handler flips to `down` as soon as the engine
        # starts streaming output; tool_result flips back to `up`
        # because the next iteration's input is now bigger.
        self._live_token_dir = "up"
        # Round-96.3: discovery-failure suppression flag. Set when
        # discover_test_command errors in compact mode, consumed
        # when the next successful bash run synthesizes a
        # `source: fallback` one-liner.
        self._pending_discovery_failure = False
        # Round-39: files-changed-this-turn for the completion footer.
        # We snapshot the current ledger length and compute the delta
        # at turn-end. Counting unique paths handles edit_file →
        # multi_edit on the same file as 1 change, not 2.
        try:
            self._turn_snap_start = len(self.agent.snapshots) if self.agent else 0
        except Exception:
            self._turn_snap_start = 0
        self._busy_started = time.monotonic()
        pb = self.query_one("#perm-bar", PermissionBar)
        pb.interrupting = True
        # Round-17 P0: assert prior _busy_task is done before reassign,
        # otherwise a stale task in cleanup silently dangles and the
        # next /escalate or /clear races against an in-flight stream.
        prev = self._busy_task
        if prev is not None and not prev.done():
            try:
                prev.cancel()
            except Exception:
                pass
        self._busy_task = asyncio.create_task(
            self._drive_agent(prompt, _multipart_parts=_multipart_parts)
        )

        def _done(task: asyncio.Task) -> None:
            elapsed = max(0, int(time.monotonic() - self._busy_started)) if self._busy_started else 0
            interrupted = False
            try:
                if task.cancelled():
                    interrupted = True
            except Exception:
                pass
            sb.busy = False
            al.busy = False
            al.current_tool = ""
            al.last_output_line = ""
            self._busy_started = 0.0
            pb.interrupting = False
            should_show = (
                self._verbose
                or interrupted
                or self._turn_tool_calls > 0
                or self._turn_tokens_out >= 80
                or elapsed >= 15
            )
            if should_show:
                # Round-39: count unique files changed during this turn
                # (edit + write + multi_edit snapshots collapse to 1 per
                # path so a 5-edit refactor on one file shows "1 file").
                files_changed = 0
                try:
                    if self.agent and self._turn_snap_start <= len(self.agent.snapshots):
                        new_snaps = self.agent.snapshots[self._turn_snap_start:]
                        paths = {s.get("path") for s in new_snaps if s.get("path")}
                        files_changed = len(paths)
                except Exception:
                    pass
                # Round-95 turn-5: polished activity summary line.
                # Derive status + title from the last tool's outcome
                # (timeout / failed) or the agent's final reply
                # (e.g. fast-finalize "Tests passed: 97 in 2.92s").
                # Falls back to a generic "Turn complete" otherwise.
                status = "done"
                title = ""
                # Round-95 turn-8: title derivation prefers the LAST
                # SUCCESSFUL bash result over stale assistant text.
                # Smoke 4 turn-7 live bug: an early discover crash
                # caused the model to emit "The test command discovery
                # failed. I will try to find the test command
                # manually..." — that text became `last_assistant_text`
                # and leaked into the final summary even though the
                # turn ultimately succeeded with `python -m pytest -q`
                # passing 267 tests. Now we walk `_recent_results` for
                # the most recent run_bash success and parse its output
                # for a known success pattern; only fall back to
                # assistant text when no successful tool ran.
                if interrupted:
                    status = "interrupted"
                elif getattr(self, "_turn_halted", False):
                    # Round 96.13: max-iterations / hard-halt path.
                    # Surface the blocker explicitly — never as a
                    # green ✓ Turn complete summary. The error
                    # captured from the halt event becomes the title
                    # so the user sees exactly what stopped the turn.
                    status = "failed"
                    halt_err = (
                        getattr(self, "_turn_halt_error", "") or "halted"
                    )
                    title = f"Stopped — {halt_err}"
                else:
                    last_success_title = self._derive_title_from_last_successful_bash()
                    if last_success_title:
                        title = last_success_title
                    elif self._recent_results:
                        # No successful test result — propagate the
                        # last tool's failure status to the summary.
                        last_label, last_rr = self._recent_results[-1]
                        last_meta = (last_rr.metadata or {}) if last_rr else {}
                        if last_meta.get("exit") == "timeout":
                            status = "timeout"
                            title = f"{last_label} timed out"
                        elif last_rr and last_rr.error:
                            status = "failed"
                            title = f"{last_label} failed"
                # Title preference (last resort): assistant's last
                # reply. Fast-finalize sets this to e.g.
                # "Tests passed: 97 in 2.92s" on a clean turn. We only
                # fall back here when the bash-success scan above
                # didn't find anything — otherwise stale recovery text
                # ("...discovery failed. I will try...") leaks into
                # the summary as it did on smoke 4 turn-7.
                if not title and self.agent and getattr(
                    self.agent, "last_assistant_text", ""
                ):
                    text = self.agent.last_assistant_text.strip()
                    if text:
                        # Reject explicit-failure preambles so a model
                        # that opened with "discovery failed..." can't
                        # win the title race. The successful pytest
                        # run later in the same turn gets the slot.
                        first = text.splitlines()[0][:90]
                        rejected = (
                            "failed", "could not", "i will try",
                            "let me try", "trying to",
                        )
                        if not any(r in first.lower() for r in rejected):
                            title = first
                # Round-95 turn-7: pass the separated tool / approval
                # timers to the renderer so the public summary doesn't
                # lump user-decision wait into agent thinking time.
                # Round-96.2: also pass active-context tokens (stable,
                # meaningful) instead of `_turn_tokens_out` (which
                # inflates with free-model reasoning tokens). Verbose
                # mode flips `show_tokens=True` to surface the raw
                # output count for debugging.
                active_ctx_tokens = None
                try:
                    if self.agent and self.agent.messages:
                        approx_bytes = sum(
                            len(json.dumps(m, default=str))
                            for m in self.agent.messages
                        )
                        active_ctx_tokens = approx_bytes // 4
                except Exception:
                    active_ctx_tokens = None
                verbose = bool(getattr(self, "_verbose_output", False))
                try:
                    # Round 96.17: input-direction fallback. If the
                    # engine never returned a `usage` event with
                    # prompt_tokens (some free-tier providers don't),
                    # `_turn_tokens_in` stays 0 — the post-turn
                    # summary then collapsed to `↓output` only. Use
                    # the active-context approx (the literal byte
                    # size of the message buffer / 4) as a real
                    # fallback so the rhythm reads
                    # `↑X input · ↓Y output` even when the engine
                    # is silent on input cost.
                    _summary_in = max(
                        int(getattr(self, "_turn_tokens_in", 0) or 0),
                        int(active_ctx_tokens or 0),
                    )
                    self._log(activity_summary_line(
                        elapsed_s=elapsed,
                        tokens_out=self._turn_tokens_out,
                        tokens_in=_summary_in,
                        title=title,
                        status=status,
                        tool_calls=self._turn_tool_calls,
                        files_changed=files_changed,
                        tool_runtime_s=getattr(
                            self, "_turn_tool_runtime_s", 0.0,
                        ) or None,
                        approval_wait_s=getattr(
                            self, "_turn_approval_wait_s", 0.0,
                        ) or None,
                        active_ctx_tokens=active_ctx_tokens,
                        show_tokens=verbose,
                    ))
                except Exception:
                    # Belt-and-suspenders fallback to legacy marker.
                    try:
                        self._log(thought_marker(
                            elapsed,
                            self._turn_tokens_out,
                            interrupted=interrupted,
                            tool_calls=self._turn_tool_calls,
                            files_changed=files_changed,
                        ))
                    except Exception:
                        pass
            try:
                self._log("")
            except Exception:
                pass
            # Round-14: _update_status queries widgets that may be
            # unmounted by the time this callback fires (audit pilot
            # tear-down, /clear race, app exit). Swallow defensively.
            try:
                self._update_status()
            except Exception:
                pass
            # Round-95 turn-9: reset the input placeholder back to the
            # idle empty-state hint. Without this call, the bottom
            # input-row keeps showing "thinking…  esc to interrupt"
            # AFTER the turn has completed — exactly the regression
            # the user flagged on smoke 4 turn-8 retest. The busy-
            # branch of _restore_input_placeholder is gated on
            # `self._busy_task and not self._busy_task.done()`, so
            # by the time the done callback fires, this call lands
            # on the empty-state branch and the rotating "Ask
            # PrometheUS to inspect, run, or fix this project…"
            # placeholder takes over again.
            try:
                self._restore_input_placeholder()
            except Exception:
                pass
            # Round-21: dequeue the next prompt if the user typed one
            # while we were busy. Schedule it as a fresh task so we
            # don't recurse inside the done callback. We re-route
            # through on_input_submitted's sibling helper so slash /
            # bang / @file / # memory all behave identically.
            qd = list(getattr(self, "_queued_prompts", []) or [])
            if qd:
                self._queued_prompts = qd[1:]
                next_text = qd[0]
                try:
                    self._log(system_dim(
                        f"▶ dequeued ({len(qd) - 1} remaining): "
                        f"{next_text[:60]}{'…' if len(next_text) > 60 else ''}"
                    ))
                except Exception:
                    pass
                try:
                    asyncio.create_task(self._dispatch_text(next_text))
                except Exception:
                    pass
            # Start the idle-bell timer. Cancelled the moment the user
            # types into the input or when a new turn starts.
            try:
                self._arm_idle_bell()
            except Exception:
                pass

        self._busy_task.add_done_callback(_done)

    async def _drive_agent(self, prompt: str, *, _multipart_parts: list | None = None) -> None:
        assert self.agent
        # Round 105: auto-checkpoint before the agent runs. Each
        # checkpoint snapshots agent.messages + todos +
        # permission_mode + read_history. The label is the first
        # 60 chars of the user prompt so the rewind menu is
        # self-describing. Auto-checkpoints expire after
        # PROMETHEUS_CHECKPOINT_RETENTION_DAYS (default 30) so the
        # anchors directory doesn't grow unbounded. Snapshot
        # failures are non-fatal — never block a turn.
        try:
            from prometheus.agent.anchors import AnchorRegistry
            reg = AnchorRegistry(self.settings.workdir)
            label = prompt.strip().splitlines()[0][:60] if prompt.strip() else "auto"
            reg.save(
                label=label,
                messages=list(self.agent.messages),
                todos=list(self.agent.todos),
                permission_mode=self.agent.permission_mode,
                read_history=set(self.agent.read_history),
                description="auto-checkpoint before agent turn",
                auto=True,
            )
        except Exception:
            pass
        # Round 99: fire UserPromptSubmit Sentinels. A blocking
        # deny short-circuits the turn — the model never sees the
        # prompt. Useful for projects that want to enforce prompt
        # policies (no secrets, no PII, etc.) without touching
        # core PrometheUS code.
        try:
            reg = getattr(self, "sentinel_registry", None)
            if reg is not None:
                from prometheus.safety.sentinels import (
                    fire_event, SentinelEvent, SentinelDecision,
                )
                final, results = await fire_event(
                    reg, SentinelEvent.USER_PROMPT_SUBMIT,
                    match_value=prompt,
                    session_id=self.session_id,
                    cwd=str(self.settings.workdir),
                    permission_mode=self.agent.permission_mode,
                    user_prompt=prompt,
                )
                if final == SentinelDecision.DENY:
                    deny_reason = next(
                        (r.reason for r in results
                         if r.decision == SentinelDecision.DENY),
                        "denied by sentinel",
                    )
                    self._log(error_line(
                        f"prompt blocked by sentinel: {deny_reason}"
                    ))
                    return
        except Exception:
            # Sentinel failures must never block normal operation.
            pass
        # `pending` accumulates assistant text until we hit a flush point
        # (paragraph break or a tool call). On a flush we render and clear.
        pending = ""
        full_assistant_text = ""
        # Round-18: tier name on assistant turn header. Tracks whether
        # we've announced the engine for THIS user-message turn yet, so
        # we render "⏺ PrometheUS Core" once at the start of the first
        # text/tool_call event. Solves user-pain #5 (silent model swap)
        # — every visible turn carries the tier label, no exceptions.
        tier_announced = False
        last_tier_label = ""
        try:
            # For multipart turns we persist a brief textual placeholder
            # in the session DB (image bytes would balloon the row).
            persist_text = (
                "(multipart user message with images)"
                if _multipart_parts is not None else prompt
            )
            self.session_store.add_message(self.session_id, "user", persist_text)
            run_iter = (
                self.agent.run_multipart(_multipart_parts)
                if _multipart_parts is not None
                else self.agent.run(prompt)
            )
            async for ev in run_iter:
                if ev.kind == "text" and ev.text:
                    if not tier_announced:
                        try:
                            from prometheus.config import public_name
                            tier = public_name(self.settings.model) or "PrometheUS"
                        except Exception:
                            tier = "PrometheUS"
                        last_tier_label = tier
                        self._log(receipt_line(tier))
                        tier_announced = True
                    # Round 97.1 / 97.2: silently strip tool-call
                    # markup leaks from the streaming text BEFORE
                    # they reach the chat-log. We DON'T log a
                    # warning here — the loop's round-97.2 recovery
                    # layer (`leak_sanitizer.recover_tool_calls`)
                    # is the canonical surface for what happened.
                    # Logging here would double-up with the loop's
                    # `↻ recovered ...` summary lines (3 leaks
                    # would produce 6 noise lines instead of 3).
                    # Cleaned text feeds BOTH the display path AND
                    # `full_assistant_text` so the model's own
                    # next-iteration history doesn't see the
                    # bogus markup either.
                    from prometheus.agent.leak_sanitizer import (
                        sanitize as _sanitize_leak,
                    )
                    cleaned, _leaks = _sanitize_leak(ev.text)
                    pending += cleaned
                    full_assistant_text += cleaned
                    # Live token estimate (~4 chars/token). Increment the
                    # persistent counter in the status bar so the user sees
                    # tokens climbing in real time AND the count stays put
                    # after the turn ends.
                    # Token count is based on the ORIGINAL ev.text
                    # so the meter still reflects what the model
                    # actually produced, even if we suppressed
                    # leakage from the display.
                    delta = max(1, len(ev.text) // 4)
                    self._live_out_delta += delta
                    self._tokens_total_out += delta
                    self._turn_tokens_out += delta
                    # Round 96.19: model output is streaming → flip
                    # the rail arrow to `down`. Cheap state write,
                    # not a recompute.
                    self._live_token_dir = "down"
                    self._update_status()
                    # Flush on paragraph break to give a streaming feel.
                    while "\n\n" in pending:
                        chunk, pending = pending.split("\n\n", 1)
                        if chunk.strip():
                            self._log(assistant_markdown(chunk))
                elif ev.kind == "iteration":
                    # Round 96.19: the loop yields `iteration` at the
                    # start of every model round-trip. This is the
                    # canonical "input grows" boundary — the agent
                    # has just finished assembling the prompt for
                    # this iteration and is about to send it. Flip
                    # the public rail arrow to `up` so the first
                    # second(s) of every iteration read as "loading
                    # context" rather than continuing the previous
                    # iteration's `down` arrow.
                    self._live_token_dir = "up"
                    try:
                        self._update_status()
                    except Exception:
                        pass
                elif ev.kind == "tool_call":
                    if not tier_announced:
                        try:
                            from prometheus.config import public_name
                            tier = public_name(self.settings.model) or "PrometheUS"
                        except Exception:
                            tier = "PrometheUS"
                        last_tier_label = tier
                        self._log(receipt_line(tier))
                        tier_announced = True
                    if pending.strip():
                        self._log(assistant_markdown(pending))
                        pending = ""
                    self._turn_tool_calls += 1
                    # Round-95 status rail polish: while a tool is
                    # actually executing (between tool_call and
                    # tool_result), surface a `[tool] ToolName` label
                    # in the activity line. This separates "model
                    # thinking" (verb pool rotation) from "tool
                    # running" (concrete tool name). The original
                    # round-22 concern about leaking info was about
                    # tool VERBS ("searching the web") that duplicated
                    # the receipt; the bracketed `[tool]` form is
                    # additive new info during the gap when the
                    # receipt hasn't landed yet.
                    try:
                        al = self.query_one("#activity", ActivityLine)
                        tc_name = (ev.tool_call.name or "").strip()
                        if tc_name:
                            tool = self.registry.get(tc_name)
                            parsed_args = ev.tool_call.parsed_arguments()
                            tc_label = (
                                tool.receipt_label(parsed_args)
                                if tool else tc_name
                            )
                            al.current_tool = tc_label[:60]
                            # Round-96.7 / 96.7b: tool + args aware
                            # phase routing. read-side → "Inspecting
                            # project · X". Write-side → "Editing
                            # files · X". run_bash gets a fine-grained
                            # phase based on the command (test-suite /
                            # git / install / generic) so the rail
                            # reads "Running test suite · Bash(pytest)"
                            # instead of the generic "Running command".
                            al.phase = _phase_for_tool(tc_name, parsed_args)
                    except Exception:
                        pass
                elif ev.kind == "tool_result":
                    tool = self.registry.get(ev.tool_call.name)
                    label = tool.receipt_label(ev.tool_call.parsed_arguments()) if tool else ev.tool_call.name
                    rr = ev.tool_result
                    # Round-95 turn-7: accumulate tool runtime so the
                    # final activity summary can show "tool 18.6s" —
                    # the actual work time, separate from approval-wait
                    # and pure-thinking. Pulls duration_s from the
                    # tool's metadata when it's there; tools that don't
                    # report duration contribute zero. We track this
                    # before the receipt-rendering branch so internal
                    # / cached results still count if they actually
                    # ran (rare but possible).
                    try:
                        dur_s = (rr.metadata or {}).get("duration_s")
                        if isinstance(dur_s, (int, float)) and dur_s > 0:
                            self._turn_tool_runtime_s += float(dur_s)
                    except Exception:
                        pass
                    # Hide internal-bookkeeping receipts:
                    #   "skipped" — guarded (e.g. fetch after search)
                    #   "cached"  — per-turn dedup short-circuit
                    # The model still receives these in its message
                    # history; the user just doesn't see the noise.
                    summary_lower = (rr.summary or "").lower()
                    is_internal = (
                        summary_lower.startswith("skipped")
                        or "cached" in summary_lower
                    )
                    # Round-95: tool finished — drop activity line back
                    # to the model-thinking phase until the next tool
                    # call. Round-95 turn-6: phase becomes "processing"
                    # so the user sees "Processing result" instead of
                    # the fallback "Working" while the model digests
                    # the tool output. Switches back to plain
                    # "thinking" on the next iteration boundary.
                    try:
                        al = self.query_one("#activity", ActivityLine)
                        al.current_tool = ""
                        al.phase = "processing"
                    except Exception:
                        pass
                    # Round 96.24: tool_result does NOT flip direction.
                    # Smoke retest: the round-96.19 flip-to-up here
                    # caused "Reviewing result…" to read as `↑X tokens`
                    # even though the model had already streamed
                    # output for the prior iteration — the meter was
                    # contradicting reality. The new rule: direction
                    # stays ↓ from the last text-delta event until
                    # the NEXT `iteration` event (which signals a
                    # genuinely new model request preparing). That
                    # makes the public meter phase-reactive instead
                    # of bouncing per tool boundary.
                    # Round-96.3: discover_test_command failure
                    # suppression in compact mode. When discovery
                    # errors out (live "parallel crash" / "could not
                    # run" / etc.), the agent loop usually rescues
                    # itself by calling run_bash directly with the
                    # standard fallback (`python -m pytest -q`). The
                    # public timeline doesn't need to surface the
                    # internal failure if the workflow succeeds — the
                    # bash receipt + final summary tell the story.
                    # Set a marker on the app so the next successful
                    # bash result can render a synthetic "Selected
                    # command · X · source: fallback" one-liner.
                    verbose_mode = bool(getattr(self, "_verbose_output", False))
                    if (
                        ev.tool_call.name == "discover_test_command"
                        and rr is not None and rr.error
                        and not verbose_mode
                    ):
                        self._pending_discovery_failure = True
                        self._recent_results.append((label, rr))
                        if len(self._recent_results) > 6:
                            self._recent_results = self._recent_results[-6:]
                        # Skip emitting a receipt for the discovery
                        # failure — public timeline stays clean.
                        # /details last + audit log still have it.
                        try:
                            self._audit("discovery_failure_suppressed", {
                                "tool":    ev.tool_call.name,
                                "summary": rr.summary,
                                "reason":  "compact-mode public clean-up",
                            })
                        except Exception:
                            pass
                        # Skip the receipt + execution_receipt rendering
                        # below by jumping to the todos-update block.
                        todos = (rr.metadata or {}).get("todos") if rr else None
                        if todos is not None:
                            try:
                                tb: TodoBar = self.query_one("#todo-bar", TodoBar)
                                tb.todos = list(todos)
                            except Exception:
                                pass
                        continue
                    # Round-96.3: synthetic discovery one-liner on
                    # successful bash following a suppressed discovery
                    # failure. If discover_test_command failed earlier
                    # in this turn AND we're now seeing a successful
                    # bash result that picked a recognizable test
                    # command, emit a clean
                    # `✦ Selected command · X · source: fallback`
                    # line BEFORE the bash receipt — so the user sees
                    # a coherent "discovery → bash" flow even though
                    # discovery technically errored.
                    if (
                        ev.tool_call.name == "run_bash"
                        and rr is not None and not rr.error
                        and getattr(self, "_pending_discovery_failure", False)
                        and not verbose_mode
                    ):
                        try:
                            from prometheus.ui.render import discovery_one_liner
                            from prometheus.tools.base import ToolResult as _TR
                            # Build a synthetic discovery result so
                            # the existing one-liner renderer works
                            # without special-casing.
                            synth = _TR(
                                output="",
                                metadata={
                                    "kind":           "discovery",
                                    "chosen_command": (rr.metadata or {}).get("command", ""),
                                    "source":         "fallback",
                                },
                            )
                            ol = discovery_one_liner(synth)
                            if ol is not None:
                                self._log(ol)
                        except Exception:
                            pass
                        finally:
                            self._pending_discovery_failure = False
                    if not is_internal:
                        # Round-96: compact-by-default rendering. Three
                        # branches drive the chat-log surface:
                        #   1. Discovery results render as a single-line
                        #      `✦ Selected command · X · source: Y` —
                        #      replaces the multi-line receipt block
                        #      (header + ⎿ command row + source row)
                        #      that the user flagged as nested clutter.
                        #   2. Bash results show the receipt header +
                        #      execution-receipt body filtered to
                        #      success/error markers (drops pytest
                        #      progress dots and warning blocks).
                        #   3. Other tools fall back to the legacy
                        #      receipt_summary_line.
                        #
                        # Verbose mode (/verbose) flips the discovery
                        # path back to the multi-line block AND the
                        # bash receipt to its full last-20-lines tail.
                        line_count = (rr.output or "").count("\n") + 1 if (rr.output or "").strip() else 0
                        verbose = bool(getattr(self, "_verbose_output", False))
                        meta = (rr.metadata or {}) if rr else {}
                        is_discovery = bool(meta.get("chosen_command"))
                        try:
                            from prometheus.ui.render import (
                                execution_receipt, discovery_receipt,
                                discovery_one_liner, bash_compact_receipt,
                            )
                        except Exception:
                            execution_receipt = discovery_receipt = discovery_one_liner = bash_compact_receipt = None  # type: ignore
                        # Branch 1: discovery → one-line receipt in compact,
                        # multi-line in verbose.
                        if is_discovery and discovery_one_liner and not verbose:
                            ol = discovery_one_liner(rr)
                            if ol is not None:
                                self._log(ol)
                            else:
                                # Defensive fallback to legacy receipt
                                self._log(receipt_summary_line(
                                    label, rr.summary, line_count, error=rr.error,
                                ))
                        else:
                            self._log(
                                receipt_summary_line(label, rr.summary, line_count, error=rr.error)
                            )
                            try:
                                if not getattr(self, "_compact_mode", True) or verbose:
                                    # Verbose / non-compact: full execution receipt
                                    if execution_receipt is not None:
                                        er = execution_receipt(rr, verbose=True)
                                        if er is not None:
                                            self._log(er)
                                        else:
                                            dr = discovery_receipt(
                                                rr, verbose=verbose,
                                            ) if discovery_receipt else None
                                            if dr is not None:
                                                self._log(dr)
                                else:
                                    # Compact (default): use the
                                    # premium labeled bash receipt
                                    # for run_bash results, fall back
                                    # to filtered execution_receipt
                                    # for other tools. Discovery
                                    # one-liner already handled above.
                                    if bash_compact_receipt is not None:
                                        br = bash_compact_receipt(rr)
                                        if br is not None:
                                            self._log(br)
                                        elif execution_receipt is not None:
                                            er = execution_receipt(rr, verbose=False)
                                            if er is not None:
                                                self._log(er)
                            except Exception:
                                pass
                        self._recent_results.append((label, rr))
                        if len(self._recent_results) > 6:
                            self._recent_results = self._recent_results[-6:]
                    todos = rr.metadata.get("todos") if rr else None
                    if todos is not None:
                        try:
                            tb: TodoBar = self.query_one("#todo-bar", TodoBar)
                            tb.todos = list(todos)
                        except Exception:
                            # Widget may be transiently unmounted during
                            # CSS reload; never let a UI hiccup kill the stream.
                            pass
                elif ev.kind == "usage" and ev.usage:
                    # Authoritative count from the engine — replace our live
                    # estimate for this turn with the real number.
                    prompt_tokens = int(ev.usage.get("prompt_tokens", 0) or 0)
                    self._tokens_total_in += prompt_tokens
                    self._turn_tokens_in += prompt_tokens
                    real_out = int(ev.usage.get("completion_tokens", 0) or 0)
                    self._tokens_total_out += real_out - self._live_out_delta
                    self._turn_tokens_out += real_out - self._live_out_delta
                    self._live_out_delta = 0
                    # OpenRouter returns `cost` in USD when usage.include is
                    # set. Free engines report 0 — that's the desired display.
                    try:
                        delta = float(ev.usage.get("cost", 0) or 0)
                        self._cost_total_usd += delta
                        # Per-session cost accumulator for the round-13
                        # session cap. Initialized lazily in _run_agent.
                        if not hasattr(self, "_session_cost_usd"):
                            self._session_cost_usd = 0.0
                        self._session_cost_usd += delta
                    except (TypeError, ValueError):
                        pass
                    self._update_status()
                elif ev.kind == "compact":
                    self._log(system_dim(ev.text or "compacted older turns"))
                elif ev.kind == "final":
                    if pending.strip():
                        self._log(assistant_markdown(pending))
                        pending = ""
                    elif ev.text and not full_assistant_text and ev.text.strip():
                        # Round 97.1 / 97.2: defend the final-event
                        # text path too — some providers stream
                        # nothing mid-turn and only deliver the
                        # assistant text on the `final` event.
                        # Strip any leak markup silently; the loop
                        # already emitted a recovery summary if the
                        # markup was recoverable.
                        from prometheus.agent.leak_sanitizer import (
                            sanitize as _sanitize_leak,
                        )
                        cleaned, _leaks = _sanitize_leak(ev.text)
                        if cleaned.strip():
                            self._log(assistant_markdown(cleaned))
                        full_assistant_text = cleaned
                    self.session_store.add_message(self.session_id, "assistant", full_assistant_text)
                    # Mirror to the agent so /copy and /proceed always see it.
                    if self.agent and full_assistant_text:
                        self.agent.last_assistant_text = full_assistant_text
                    # Round-17 P0: snapshot the agent's in-memory buffer
                    # so --resume can restore it after a crash.
                    try:
                        if self.agent is not None:
                            self.session_store.save_state(self.session_id, {
                                "messages": self.agent.messages,
                                "todos": self.agent.todos,
                                "permission_mode": self.agent.permission_mode,
                                "saved_at": time.time(),
                            })
                    except Exception:
                        pass
                elif ev.kind == "error":
                    self._log(error_line(ev.error or "stream error"))
                    return
                elif ev.kind == "halt":
                    # Round 96.13: capture the halt reason so the
                    # turn-end summary can render an honest blocked
                    # state instead of `✓ Turn complete`. Smoke 6
                    # retest live case: max-iterations halt was
                    # rendered with the green check + "Turn complete"
                    # alongside the warning, which read as success
                    # on a turn that never repaired the failing test.
                    self._turn_halted = True
                    self._turn_halt_error = ev.error or "halted"
                    self._log(error_line(ev.error or "halted"))
                    return
        except asyncio.CancelledError:
            self._log(system_dim("interrupted"))
        except Exception as e:
            logger.exception("agent error")
            self._log(error_line(f"agent: {e}"))
        finally:
            try:
                if pending.strip():
                    self._log(assistant_markdown(pending))
            except Exception:
                pass
            try:
                self._update_status()
            except Exception:
                # Audit pilot tear-down / app exit can race; widget
                # query may fail. Don't propagate.
                pass

    # ---------- subagent spawn (for the `task` tool) ----------

    async def _subagent_manager_runner(
        self, task: Any, parent_ctx: Any,
    ) -> str:
        """Round 97: per-subagent worker called by
        BackgroundAgentManager. Delegates to the same
        `_spawn_subagent` codepath the foreground task tool uses,
        passing an `on_event` hook that funnels event summaries
        into the SubAgentTask's events list. Status transitions
        (running/completed/failed/cancelled/timeout) are owned by
        the manager — this coroutine just runs to completion or
        raises."""
        def _hook(kind: str, text: str) -> None:
            try:
                self.subagent_manager.emit_event(task.id, kind, text)
            except Exception:
                # Hook failure must never crash the subagent.
                pass
        return await self._spawn_subagent(
            task.prompt, parent_ctx, task.subagent_type,
            on_event=_hook,
            from_agent_name=task.name,
            from_agent_id=task.id,
        )

    async def _spawn_subagent(
        self,
        prompt: str,
        parent_ctx: Any,
        subagent_type: str = "general-purpose",
        on_event: Any = None,
        from_agent_name: str = "",
        from_agent_id: str = "",
    ) -> str:
        """Run an isolated sub-agent on the prompt and return ONLY its
        final text reply.

        Each subagent gets its OWN AgentLoop with:
          • its own message buffer (parent context never sees the sub's
            tool calls — only the final answer).
          • subagent_type-specific tool restrictions (round-49):
            'explore' → read-only; 'plan' → read+plan, no edits;
            'code-reviewer' → read-only structured review; or a
            custom agent loaded from `.prometheus/agents/<name>.md`.
          • a one-iteration cap by default to prevent runaway recursion
            (subagent can't spawn its own subagent).
          • the parent's permission_mode (subagents inherit safety
            posture; they can't escalate beyond what the parent allows).

        Multiple `task` tool calls in the same parent turn execute in
        parallel because the agent loop already runs READ-class tools
        concurrently via asyncio.gather (loop.py:_execute_tools), and
        TaskTool.side_effect = READ.
        """
        assert self.client
        # Round-49: discover custom agents from .prometheus/agents/*.md
        # and let them act as named subagent types.
        from prometheus.agent.custom_agents import discover as _discover_agents
        custom = _discover_agents(self.settings.workdir)
        custom_agent = custom.get(subagent_type)

        # Build a fresh registry with subagent-spawning DISABLED — a
        # sub-agent that could spawn its own sub-agents leads to
        # exponential context blowup (Claude Code shipped the same
        # restriction). Skills/web/file/search tools are kept.
        from prometheus.tools import build_default_registry
        sub_registry = build_default_registry(
            spawn_subagent=None,             # explicit: no nested spawns
            ask_user=None,                   # subagents can't prompt the user
        )
        # Apply subagent_type tool restrictions.
        # 'explore'      → strip every WRITE/EXEC tool (read-only recon)
        # 'plan'         → same as explore (no edits, just plan)
        # 'code-reviewer'→ same as explore + structured review prompt
        # 'general-purpose' → no restriction
        # custom agent   → use frontmatter tools/disallowed_tools lists
        from prometheus.tools.base import SideEffect as _SE
        if custom_agent is not None and (
            custom_agent.tools is not None or custom_agent.disallowed_tools
        ):
            avail_names = list(sub_registry._tools.keys())
            from prometheus.agent.custom_agents import filter_tool_set
            keep = set(filter_tool_set(avail_names, custom_agent))
            for name in list(sub_registry._tools.keys()):
                if name not in keep:
                    sub_registry._tools.pop(name, None)
        elif subagent_type in ("explore", "plan", "code-reviewer"):
            for name, tool in list(sub_registry._tools.items()):
                if tool.side_effect in (_SE.WRITE, _SE.EXEC):
                    sub_registry._tools.pop(name, None)
        from prometheus.agent.loop import AgentLoop
        sub_settings = self.settings
        # Round 97.3: subagent approvals inherit the parent's
        # `_request_approval` callback BUT we wrap it so the meta
        # dict carries `from_agent_name` / `from_agent_id`. The
        # InlineApproval widget reads the `from` field and prefixes
        # the header so the user sees `Agent(<name>) wants to run
        # Bash(pwd)` instead of a generic `Bash command` card.
        # Also threads through to the per-session approval cache
        # so a "don't ask again" decision applies to subagents too.
        if from_agent_name:
            _from_name = from_agent_name
            _from_id = from_agent_id

            async def _request_approval_with_provenance(
                tool: str, detail: str, meta: Any = None,
            ) -> bool:
                meta_d = dict(meta) if meta else {}
                meta_d["from_agent_name"] = _from_name
                meta_d["from_agent_id"] = _from_id
                return await self._request_approval(tool, detail, meta_d)

            sub_request_approval = _request_approval_with_provenance
        else:
            sub_request_approval = self._request_approval
        sub = AgentLoop(
            client=self.client,
            registry=sub_registry,
            settings=sub_settings,
            request_approval=sub_request_approval,
            notify=self._notify,
            audit=self._audit,
            session_id=f"{self.session_id}.sub.{uuid.uuid4().hex[:6]}",
        )
        # Inherit parent's permission posture so a subagent in plan mode
        # can't sneakily call write_file.
        if self.agent:
            sub.permission_mode = self.agent.permission_mode
        # Round 97.3: subagents auto-elevate `default` → `acceptEdits`
        # so writes from inside a subagent don't trigger an approval
        # card per call. The user explicitly dispatched a subagent;
        # interrupting them with N approvals (one per file write)
        # broke the live UX. `plan` and `skipAll` still pass through
        # unchanged — those modes are explicit user choices.
        # Bash and apply_patch still go through the parent's approval
        # queue (with from_agent_name provenance per round 97.3) so
        # destructive shell commands still get a confirm step.
        if sub.permission_mode == "default":
            sub.permission_mode = "acceptEdits"
        # Round-49: built-in subagent_type permission overrides + custom
        # agent permission_mode applied last (custom wins).
        if subagent_type in ("plan",):
            sub.permission_mode = "plan"
        if custom_agent is not None and custom_agent.permission_mode:
            sub.permission_mode = custom_agent.permission_mode
        # Tighter iteration budget — subagents are focused workers, not
        # multi-turn debug sessions. 6 iterations = enough for a
        # search → read → answer pattern, not enough to recurse forever.
        sub.settings = type(self.settings)(**self.settings.__dict__)
        sub.settings.max_iterations = 6
        # Round-49: prepend the custom agent's system-prompt body as a
        # system message before the user prompt. The body acts as an
        # overlay on top of the standard PrometheUS system prompt.
        framed_prompt = prompt
        if custom_agent is not None and custom_agent.body:
            framed_prompt = (
                f"<custom-agent name=\"{custom_agent.name}\">\n"
                f"{custom_agent.body.strip()}\n"
                f"</custom-agent>\n\n"
                f"User task:\n{prompt}"
            )
        elif subagent_type == "code-reviewer":
            framed_prompt = (
                "You are a code reviewer. Look for: obvious bugs, edge "
                "cases, missing error handling, style/consistency issues, "
                "and security concerns. Return findings as a markdown "
                "checklist with file:line references when possible. Do "
                "not edit files — only report.\n\n"
                f"User task:\n{prompt}"
            )
        # Run to completion and gather the final assistant text.
        # Round 97: optional on_event hook lets the
        # BackgroundAgentManager pipe a compact one-line summary
        # of each event into the SubAgentTask's `events` list for
        # the expanded-view body. The hook fires for ALL event
        # kinds (text/tool_call/tool_result/error/halt/final) so
        # the card UI can show meaningful progress without
        # leaking subagent activity into the parent's chat-log.
        final_text: list[str] = []

        def _emit(kind: str, text: str) -> None:
            if on_event is None:
                return
            try:
                on_event(kind, text)
            except Exception:
                # Hooks must never crash the subagent.
                pass
        try:
            async for ev in sub.run(framed_prompt):
                if ev.kind == "text" and ev.text:
                    final_text.append(ev.text)
                    _emit("text", ev.text.split("\n", 1)[0])
                elif ev.kind == "final" and ev.text:
                    final_text.append(ev.text)
                    _emit("status", "final reply ready")
                elif ev.kind == "tool_call":
                    # `_compact_label` for a tool call: prefer the
                    # tool's receipt_label() if available; else
                    # fall back to the tool name.
                    tc_name = getattr(ev, "tool_name", "") or ""
                    tc_args = getattr(ev, "tool_args", {}) or {}
                    label = tc_name
                    try:
                        tool = sub_registry.get(tc_name) if tc_name else None
                        if tool is not None and hasattr(tool, "receipt_label"):
                            label = tool.receipt_label(tc_args) or tc_name
                    except Exception:
                        label = tc_name
                    _emit("tool_call", label)
                elif ev.kind == "tool_result":
                    summary = ""
                    try:
                        summary = (
                            getattr(ev, "summary", "")
                            or getattr(ev, "result_summary", "")
                            or ""
                        )
                    except Exception:
                        summary = ""
                    _emit("tool_result", summary or "ok")
                elif ev.kind == "error":
                    _emit("status", f"error: {ev.error}")
                    return f"sub-agent error: {ev.error}"
                elif ev.kind == "halt":
                    _emit("status", f"halted: {ev.error}")
                    return f"sub-agent halted: {ev.error}"
        except Exception as e:
            _emit("status", f"crashed: {e}")
            return f"sub-agent crashed: {e}"
        return "".join(final_text).strip() or "(empty response)"

    # ---------- bindings ----------

    async def action_copy_last(self) -> None:
        """Ctrl+Y — copy the last assistant reply, no slash needed."""
        if not self.slash:
            return
        await self.slash.dispatch("/copy")

    def action_background_bash(self) -> None:
        """Ctrl+B — move the current foreground bash to a background job.

        run_bash registers its subprocess on self._fg_bash_proc when it
        starts; this hands the process to the BackgroundJobs registry,
        which keeps reading stdout. The agent loop's await on the
        original bash will see EOF promptly.
        """
        proc = getattr(self, "_fg_bash_proc", None)
        if proc is None:
            self._log(system_dim("no foreground bash running"))
            return
        job = self.bg_jobs.adopt(self._fg_bash_cmd, proc)
        self._fg_bash_proc = None
        self._fg_bash_cmd = ""
        self._log(system_dim(f"backgrounded as {job.job_id} · /bashes to manage"))

    def action_toggle_verbose(self) -> None:
        """Ctrl+O — round 97: when a SubAgentCard is on screen, this
        toggles its expanded state (the user-facing contract surface
        documented on the card itself: `ctrl+o to expand`). When no
        cards are visible, falls back to the original behavior of
        toggling the persistent thought marker on every turn."""
        # Subagent expand takes precedence whenever a panel card
        # exists, so the binding always matches what the card's
        # subline advertises. If no panel is mounted yet, fall
        # through to the verbose toggle.
        try:
            if self.subagent_panel is not None:
                from prometheus.ui.subagent_widgets import (
                    toggle_most_recent_card,
                )
                if toggle_most_recent_card(self.subagent_panel):
                    return
        except Exception:
            # Panel not mounted yet, or import failure — fall through.
            pass
        self._verbose = not self._verbose
        self._log(system_dim(f"verbose: {'on' if self._verbose else 'off'}"))

    def action_complete_slash(self) -> None:
        """Tab autocomplete for /commands. Also routes Tab to 'amend' when a
        question is pending, and to the @ file picker when one is active."""
        if self._pending_question and not self._pending_question.done():
            self._pending_question.set_result("__amend__")
            return
        try:
            inp: Input = self.query_one("#prompt", Input)
        except Exception:
            return
        # File picker takes precedence — typing `@cli<TAB>` should commit a file.
        try:
            from prometheus.ui.widgets import FileSuggestions as _FS
            file_sug = self.query_one("#file-sug", _FS)
        except Exception:
            file_sug = None  # type: ignore
        if file_sug is not None and file_sug.matches:
            pick = file_sug.matches[file_sug.selected]
            text = inp.value
            last_at = text.rfind("@")
            if last_at >= 0:
                inp.value = text[: last_at + 1] + pick + " "
                inp.cursor_position = len(inp.value)
            file_sug.matches = []
            return
        text = inp.value
        if not text.startswith("/") or not self.slash:
            # Let Tab fall through to default behavior — nothing to do here.
            return
        prefix = text[1:].split(maxsplit=1)[0]
        matches = self.slash.complete(prefix)
        if not matches:
            return
        if len(matches) == 1:
            inp.value = "/" + matches[0] + " "
            inp.cursor_position = len(inp.value)
        else:
            # Compute longest common prefix and show options.
            lcp = matches[0]
            for m in matches[1:]:
                while not m.startswith(lcp):
                    lcp = lcp[:-1]
                    if not lcp:
                        break
            if lcp and lcp != prefix:
                inp.value = "/" + lcp
                inp.cursor_position = len(inp.value)
            self._log(system_dim("  " + "  ".join(f"/{m}" for m in matches[:12])))

    # ---------- image paste ----------

    def action_paste_image(self) -> None:
        """Ctrl+V — read OS clipboard, insert a placeholder if it's an image.

        Returns silently when the clipboard is text-only so bracketed
        paste handling still fires for normal text paste.
        """
        try:
            from prometheus.ui.clipboard import read_clipboard_image
        except Exception:
            return
        result = read_clipboard_image()
        if result is None:
            return  # text clipboard — let on_paste handle it
        img_bytes, mime = result
        # Hard cap so a giant snip doesn't OOM the request.
        if len(img_bytes) > 10 * 1024 * 1024:
            self._log(error_line(
                f"image too large ({len(img_bytes)//1024//1024} MB > 10 MB) — "
                f"snip a smaller area"
            ))
            return
        item = self._image_paste.add(img_bytes, mime)
        try:
            inp = self.query_one("#prompt", Input)
            before = inp.value[: inp.cursor_position]
            after = inp.value[inp.cursor_position:]
            inp.value = before + item.placeholder + after
            inp.cursor_position = len(before) + len(item.placeholder)
        except Exception:
            return
        # Vision-capability hint (best-effort, non-blocking).
        asyncio.create_task(self._warn_if_no_vision())

    async def _warn_if_no_vision(self) -> None:
        if not self.client:
            return
        try:
            ok = await self.client.is_vision_capable(self.settings.model)
        except Exception:
            return
        if not ok:
            # Pull the live vision-chain primary so the suggestion never
            # goes stale when the chain is rebalanced.
            from prometheus.config import VISION_CHAIN
            suggestion = VISION_CHAIN[0] if VISION_CHAIN else "a vision-capable engine"
            self._log(error_line(
                "the active engine doesn't accept images. Switch with: "
                f"/model {suggestion}"
            ))

    # ---------- voice ----------

    def action_compose_in_editor(self) -> None:
        """Round-16 WOW: open $EDITOR (or VISUAL) on a temp file pre-filled
        with whatever is in the input. The editor is run synchronously —
        the TUI yields the terminal to it via Textual's `suspend()`. When
        the editor closes, the file body becomes the new input value."""
        import os as _os
        import tempfile as _tempfile
        import subprocess as _sp
        editor = (
            _os.environ.get("VISUAL")
            or _os.environ.get("EDITOR")
            or ("notepad" if __import__("sys").platform == "win32" else "nano")
        )
        try:
            inp = self.query_one("#input", Input)
        except Exception:
            return
        seed = inp.value or ""
        try:
            fd, tmp_path = _tempfile.mkstemp(prefix="prometheus-prompt-", suffix=".md")
            with _os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(seed)
            try:
                with self.suspend():
                    _sp.call([*editor.split(), tmp_path])
            except Exception as e:
                self._log(error_line(f"editor failed: {e}"))
                return
            try:
                with open(tmp_path, "r", encoding="utf-8") as f:
                    body = f.read()
            finally:
                try:
                    _os.unlink(tmp_path)
                except OSError:
                    pass
            inp.value = body.rstrip("\n")
        except Exception as e:
            self._log(error_line(f"compose: {e}"))

    def action_voice_toggle(self) -> None:
        """Ctrl+Space — start or stop dictation."""
        sess = self._voice_session
        if sess is not None and sess.is_recording:
            asyncio.create_task(self._voice_stop_and_fill())
        else:
            self._voice_start()

    def _voice_start(self) -> None:
        from prometheus.voice import VoiceSession, VoiceConfig, is_available
        cfg = VoiceConfig()
        ok, reason = is_available(cfg)
        if not ok:
            self._log(error_line(f"voice: {reason}"))
            return
        # New recording epoch — invalidates any in-flight stop_and_transcribe
        # from a previous Ctrl+Space cycle.
        self._voice_epoch += 1
        try:
            from prometheus.ui.widgets import VUMeterWidget
            self._voice_widget = VUMeterWidget()
            slot = self.query_one("#picker-slot", Vertical)
            asyncio.create_task(slot.mount(self._voice_widget))
        except Exception:
            self._voice_widget = None
        sess = VoiceSession(cfg, on_level=self._on_voice_level)
        try:
            sess.start()
        except Exception as e:
            self._log(error_line(f"voice: mic unavailable — {e}"))
            self._voice_session = None
            if self._voice_widget is not None:
                try:
                    self._voice_widget.remove()
                except Exception:
                    pass
                self._voice_widget = None
            return
        self._voice_session = sess
        try:
            inp = self.query_one("#prompt", Input)
            inp.placeholder = "recording… ctrl+space stop · esc cancel"
        except Exception:
            pass

        async def _tick() -> None:
            try:
                while self._voice_session is not None and self._voice_session.is_recording:
                    await asyncio.sleep(1.0)
                    if self._voice_widget is not None and self._voice_session is not None:
                        self._voice_widget.elapsed_s = int(self._voice_session.elapsed_s)
                    # Cap-driven auto-stop.
                    if (self._voice_session is not None
                            and self._voice_session.elapsed_s >= cfg.max_seconds):
                        await self._voice_stop_and_fill()
                        return
            except asyncio.CancelledError:
                return
        self._voice_tick_task = asyncio.create_task(_tick())

    def _on_voice_level(self, rms01: float) -> None:
        if self._voice_widget is not None:
            try:
                self._voice_widget.level = rms01
            except Exception:
                pass

    async def _voice_stop_and_fill(self) -> None:
        sess = self._voice_session
        if sess is None:
            return
        # Snapshot the epoch so we can detect mid-flight cancellation —
        # if the user hits Esc while transcribe() is awaiting, the
        # epoch advances and we suppress the stale append.
        my_epoch = self._voice_epoch
        self._voice_session = None
        if self._voice_tick_task is not None:
            self._voice_tick_task.cancel()
            self._voice_tick_task = None
        text = ""
        try:
            text = await sess.stop_and_transcribe()
        except Exception as e:
            self._log(error_line(f"voice: transcription failed — {e}"))
        finally:
            if self._voice_widget is not None:
                try:
                    self._voice_widget.remove()
                except Exception:
                    pass
                self._voice_widget = None
            self._restore_input_placeholder()
        # Audit P0: if the user cancelled (or started a new recording)
        # while we were awaiting transcribe(), our `text` is stale.
        # Drop it instead of stomping on the input the user has now
        # typed.
        if my_epoch != self._voice_epoch:
            return
        if text:
            try:
                inp = self.query_one("#prompt", Input)
                if inp.value and not inp.value.endswith(" "):
                    inp.value += " "
                inp.value += text
                inp.cursor_position = len(inp.value)
            except Exception:
                pass

    def _voice_cancel(self) -> bool:
        """Returns True if a recording was cancelled (used by action_interrupt
        so Esc kills voice instead of falling through to rewind)."""
        sess = self._voice_session
        if sess is None or not sess.is_recording:
            return False
        # Bump epoch FIRST so any in-flight transcribe coroutine drops
        # its result instead of writing to the prompt.
        self._voice_epoch += 1
        try:
            sess.cancel()
        except Exception:
            pass
        self._voice_session = None
        if self._voice_tick_task is not None:
            self._voice_tick_task.cancel()
            self._voice_tick_task = None
        if self._voice_widget is not None:
            try:
                self._voice_widget.remove()
            except Exception:
                pass
            self._voice_widget = None
        self._restore_input_placeholder()
        return True

    def action_scroll_page_up(self) -> None:
        """PageUp — scroll the chat log up one page.

        Pauses auto-scroll while the user is reading scrollback so a
        burst of streamed assistant text doesn't yank them back to the
        bottom mid-read. Auto-scroll resumes when they hit
        action_scroll_end (or Ctrl+End / Shift+PgDn).
        """
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.auto_scroll = False
            log_w.scroll_page_up(animate=False)
        except Exception:
            pass

    def action_scroll_page_down(self) -> None:
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.scroll_page_down(animate=False)
            # If we've scrolled all the way back to the bottom, re-arm
            # auto-scroll so new text continues to land in view.
            if log_w.scroll_y >= log_w.max_scroll_y:
                log_w.auto_scroll = True
        except Exception:
            pass

    # Round-59: mouse-wheel scrollback. Without these handlers the
    # default auto_scroll=True yanks the user back to the bottom on
    # every new line, so wheel-up appears not to work.
    def on_mouse_scroll_up(self, event: Any) -> None:
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.auto_scroll = False
            log_w.scroll_relative(y=-3, animate=False)
            event.stop()
        except Exception:
            pass

    def on_mouse_scroll_down(self, event: Any) -> None:
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.scroll_relative(y=3, animate=False)
            # Re-arm auto-scroll once the user reaches the bottom
            if log_w.scroll_y >= log_w.max_scroll_y - 1:
                log_w.auto_scroll = True
            event.stop()
        except Exception:
            pass

    def action_scroll_home(self) -> None:
        """Ctrl+Home / Shift+PgUp — jump to the very first message."""
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.auto_scroll = False
            log_w.scroll_home(animate=False)
        except Exception:
            pass

    def action_scroll_end(self) -> None:
        """Ctrl+End / Shift+PgDn — jump to the latest message and re-arm auto-scroll."""
        try:
            log_w: RichLog = self.query_one("#chat-log", RichLog)
            log_w.scroll_end(animate=False)
            log_w.auto_scroll = True
        except Exception:
            pass

    def action_clear(self) -> None:
        self.query_one("#chat-log", RichLog).clear()
        if self.agent:
            self.agent.reset()
            # A fresh session starts in default permission mode — bleeding
            # mode across sessions surprises users (and broke the audit).
            self.agent.set_permission_mode("default")
        # Round 97.3: per-session approval cache is per-session by
        # name — reset it on /clear so the user's "don't ask again"
        # decisions don't leak into the next session.
        self._session_always_yes.clear()
        self.session_id = str(uuid.uuid4())
        if self.agent:
            self.agent.session_id = self.session_id
        self.session_store.start(self.session_id, self.settings.model, str(self.settings.workdir))
        self._tokens_total_in = 0
        self._tokens_total_out = 0
        self._cost_total_usd = 0.0
        self._session_cost_usd = 0.0
        self._byok_nudged = False
        self._byok_throttled = False
        self._session_label = self._default_session_label()
        self._recent_results.clear()
        # Reset the image-paste counter so the next paste shows
        # `[Image #1: …]` instead of `[Image #1004: …]` after long sessions.
        try:
            self._image_paste.clear()
        except Exception:
            pass
        tb: TodoBar = self.query_one("#todo-bar", TodoBar)
        tb.todos = []
        # Re-show the welcome card on a clean session.
        try:
            self.query_one(WelcomeCard).set_class(False, "-hidden")
        except Exception:
            pass
        self._log(system_dim("conversation cleared"))
        self._update_status()

    def action_cycle_mode(self) -> None:
        if not self.agent:
            return
        cur = self.agent.permission_mode
        idx = PERMISSION_ORDER.index(cur) if cur in PERMISSION_ORDER else 0
        nxt = PERMISSION_ORDER[(idx + 1) % len(PERMISSION_ORDER)]
        self.agent.set_permission_mode(nxt)
        self._update_status()
        # Mode change updates the placeholder hint (plan / skipAll get
        # explicit prompts; default and acceptEdits fall back to the
        # generic try-this hint).
        self._restore_input_placeholder()
        self._log(system_dim(f"mode → {nxt}"))

    def action_history(self) -> None:
        if not self._history:
            self._log(system_dim("no history yet"))
            return
        self._log(system_dim("recent prompts:"))
        for i, h in enumerate(self._history[-15:], 1):
            self._log(system_dim(f"  {i:>2}. {h[:120]}"))

    def action_interrupt(self) -> None:
        # Voice recording wins over every other Esc behavior — users
        # expect a single Esc to drop the mic without affecting any
        # in-flight turn.
        if self._voice_cancel():
            return
        # Cancel any in-flight pickers first so they don't keep blocking
        # input after the user wants out.
        for fut_attr in ("_pending_approval", "_pending_question"):
            fut = getattr(self, fut_attr, None)
            if fut is not None and not fut.done():
                try:
                    fut.cancel()
                except Exception:
                    pass
        # Round 97.3: cancel-all-subagents BEFORE checking _busy_task.
        # The pre-97.3 path only cancelled subagents inside the busy
        # branch — but a stuck subagent approval (live failure mode
        # from the round-97.3 user screenshots) often runs while the
        # parent turn is already idle. Without this hoist, Esc on a
        # stuck subagent approval would only cancel the approval
        # future and leave the subagent's asyncio.Task untouched.
        try:
            has_running_subagents = any(
                not t.is_terminal()
                for t in self.subagent_manager.tasks()
            )
            if has_running_subagents:
                asyncio.create_task(
                    self.subagent_manager.cancel_all()
                )
        except Exception:
            pass
        if self._busy_task and not self._busy_task.done():
            self._busy_task.cancel()
            return
        # Esc+Esc within ~1.5s → rewind one assistant turn.
        now = time.monotonic()
        last = getattr(self, "_last_esc_at", 0.0)
        self._last_esc_at = now
        if now - last < 1.5:
            # Only rewind when the loop is fully idle — otherwise we'd
            # mutate self.agent.messages while _drive_agent is iterating
            # and an in-flight tool's snapshot append would race the pop.
            if self._busy_task is None or self._busy_task.done():
                self._rewind_one_turn()

    def _rewind_one_turn(self) -> None:
        if not self.agent:
            return
        from prometheus.safety.checkpoint import rewind_snapshots
        msgs = self.agent.messages
        # Stash the messages we're about to remove so /redo can put them
        # back. We store a shallow-copied list because the agent loop
        # may reuse dict slots otherwise.
        stripped: list[dict[str, Any]] = []
        # Count snapshots taken since the last user message — we'll undo those.
        # We don't know exact attribution per-message, so we restore *all* snapshots
        # added during the most recent assistant turn(s).
        rewind_count = len(self.agent.snapshots)
        while msgs and msgs[-1].get("role") != "user":
            stripped.insert(0, msgs.pop())
        # Round 172: capture the popped user text so we can drop it
        # back into the prompt for editing — matches Claude Code's
        # Esc-Esc semantics where the previous prompt becomes the
        # editable draft. We still keep /redo bookkeeping for users
        # who actually want the rewind-and-replay behavior.
        last_user_text: str = ""
        if msgs and msgs[-1].get("role") == "user":
            popped = msgs.pop()
            stripped.insert(0, popped)
            content = popped.get("content", "")
            if isinstance(content, str):
                last_user_text = content
            elif isinstance(content, list):
                # Multipart user messages (image paste etc.). Pick
                # the first text part for the editable draft.
                for part in content:
                    if isinstance(part, dict) and part.get("type") in (
                        "text", None,
                    ):
                        t = part.get("text", "")
                        if isinstance(t, str) and t:
                            last_user_text = t
                            break
        if not hasattr(self, "_redo_stack"):
            self._redo_stack: list[list[dict[str, Any]]] = []
        if stripped:
            self._redo_stack.append(stripped)
            if len(self._redo_stack) > 20:
                # Cap depth so /redo doesn't accumulate forever in pathological loops.
                self._redo_stack = self._redo_stack[-20:]
        if rewind_count:
            n, errs = rewind_snapshots(self.agent.snapshots, rewind_count)
            for e in errs:
                self._log(error_line(f"rewind: {e}"))
            self._log(system_dim(
                f"rewound 1 turn · restored {n} file change(s) · /redo to step forward"
            ))
        else:
            self._log(system_dim("rewound 1 turn (no file changes to restore) · /redo to step forward"))
        # Round 172: restore the popped user text into the input box
        # so the user can edit and resubmit. Best-effort — if there's
        # no Input widget mounted yet (e.g., headless test harness)
        # we just skip silently.
        if last_user_text:
            try:
                from textual.widgets import Input
                inp = self.query_one("Input", Input)
                # Don't clobber the user's in-flight draft if they
                # already typed something. Only fill an empty input.
                if not inp.value:
                    inp.value = last_user_text
                    inp.cursor_position = len(last_user_text)
            except Exception:
                pass
        self._update_status()

    def _redo_one_turn(self) -> None:
        """Restore the most recently rewound turn (messages only).

        Note: we deliberately DO NOT replay tool side-effects — the
        rewind already restored disk state via snapshots, and naively
        re-executing a tool message could re-issue a destructive
        command. /redo brings the conversation back to the post-turn
        state without firing tools again, which matches Claude Code's
        v2.2 behavior.
        """
        if not self.agent:
            return
        if not getattr(self, "_redo_stack", None):
            self._log(system_dim("nothing to redo"))
            return
        msgs_to_restore = self._redo_stack.pop()
        self.agent.messages.extend(msgs_to_restore)
        n_user = sum(1 for m in msgs_to_restore if m.get("role") == "user")
        n_asst = sum(1 for m in msgs_to_restore if m.get("role") == "assistant")
        self._log(system_dim(
            f"redone 1 turn · {n_user} user / {n_asst} assistant message(s) restored"
        ))
        self._update_status()
