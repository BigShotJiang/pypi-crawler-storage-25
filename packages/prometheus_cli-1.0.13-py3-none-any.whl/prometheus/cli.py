"""prometheus / prom — CLI entry point."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from prometheus import __version__
from prometheus.config import load_settings
from prometheus.log import setup as setup_log


def _build_parser() -> argparse.ArgumentParser:
    """The single argparse parser for the `prometheus` command.

    Round 187: merged with `headless.build_parser()` so every flag the
    headless / `-p` path accepts is visible from a plain
    `prometheus --help`. Pre-R187 the launcher parser only exposed the
    interactive-launch flags (--workdir, --model, --doctor, etc.), so
    a user reading `prometheus --help` had no way to discover
    --offline, --reasoning-effort, --add-gitignore-files,
    --output-format, --input-format, --mcp-config, --add-dir,
    --permission-mode, --worktree, --keep-worktree, --tmux,
    --append-system-prompt[-file], --disable-slash-commands,
    --setting-sources, --betas, --include-partial-messages,
    --output-schema, --verbose, --debug, --debug-file, --name,
    --max-turns, etc. — 30+ documented flags were effectively hidden.

    The headless parser is the SoT for every option a user can pass.
    We add the launcher-only flags on top so the same parser handles
    interactive + headless dispatch.
    """
    # Lazy import so the launcher path doesn't pay the headless
    # module's import cost when the user just wants `--help`.
    from prometheus.headless import build_parser as _headless_parser
    p = _headless_parser()
    # Override the description with the launcher-friendly one.
    p.description = "PrometheUS — a free terminal AI coding agent."
    # Existing actions registered by build_parser() — used to skip
    # re-adding flags it already exposes.
    _existing = {opt for a in p._actions for opt in (a.option_strings or [])}
    def _add_if_new(*names: str, **kw):
        if any(n in _existing for n in names):
            return
        p.add_argument(*names, **kw)
        _existing.update(names)

    # Pin --version against the live __init__ value so dev installs
    # show pyproject.toml's version (R187 single-source-of-truth).
    _add_if_new(
        "--version", action="version",
        version=f"PrometheUS {__version__}",
    )
    # --workdir / -C is launcher-only (headless inherits the user's
    # cwd and doesn't expose this).
    _add_if_new(
        "--workdir", "-C",
        help="working directory (default: cwd)",
    )
    # Launcher-only conveniences.
    _add_if_new(
        "--doctor", action="store_true",
        help="check setup and exit",
    )
    _add_if_new(
        "--deep", action="store_true",
        help="with --doctor: live-probe every provider + every chain entry",
    )
    _add_if_new(
        "--list-models", action="store_true",
        help="list free models and exit",
    )
    _add_if_new(
        "--audit", action="store_true",
        help="run the public acceptance suite and print N/M passing summary",
    )
    _add_if_new(
        "--eval", action="store_true",
        help="run the universal-task evaluation harness — graded canonical workflows",
    )
    _add_if_new(
        "--run", metavar="RECIPE",
        help="execute a recipe.yaml — a declarative, portable agent workflow",
    )
    _add_if_new(
        "--export-session", metavar="SID",
        help="export a session as a portable .json bundle for cross-machine resume",
    )
    _add_if_new(
        "--import-session", metavar="FILE",
        help="import a session bundle previously created with --export-session",
    )
    _add_if_new(
        "--resume-latest", action="store_true",
        help="resume the most recent session without scrolling the picker",
    )
    return p


def _export_session(settings, sid: str) -> int:
    """Round-29 Track J: dump a session as a self-contained JSON
    bundle (messages + state.json + todos + permission_mode + audit
    metadata). Lands in `<workdir>/.prometheus/exports/<sid>.json`.
    Sync via the user's preferred channel (rsync, scp, dropbox).
    """
    import json as _json
    import sys as _sys
    import time as _t
    from pathlib import Path as _Path
    from prometheus.memory.session import SessionStore
    store = SessionStore()
    try:
        msgs = store.get_messages(sid)
    except Exception as e:
        print(f"failed to read session {sid}: {e}", file=_sys.stderr)
        return 1
    if not msgs:
        print(f"no session found with id starting with {sid!r}", file=_sys.stderr)
        return 1
    state = {}
    try:
        s = store.load_state(sid)
        if isinstance(s, dict):
            state = s
    except Exception:
        pass
    bundle = {
        "format_version": 1,
        "exported_at": _t.strftime("%Y-%m-%dT%H:%M:%SZ", _t.gmtime()),
        "session_id": sid,
        "prometheus_version": __version__,
        "messages": msgs,
        "state": state,
    }
    out_dir = settings.workdir / ".prometheus" / "exports"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"can't create exports dir: {e}", file=_sys.stderr)
        return 1
    target = out_dir / f"{sid[:16]}.json"
    try:
        from prometheus.tools.files import _atomic_write_text
        _atomic_write_text(target, _json.dumps(bundle, default=str, indent=2))
    except Exception as e:
        print(f"export failed: {e}", file=_sys.stderr)
        return 1
    print(f"exported session → {target}")
    print(f"  {len(msgs)} messages, "
          f"{len(state.get('messages', [])) if isinstance(state.get('messages'), list) else 0} "
          f"in-memory snapshot frames")
    print(f"  to import on another machine: prometheus --import-session {target}")
    return 0


def _import_session(settings, path: str) -> int:
    """Round-29 Track J: ingest a session bundle and replay it into
    the local session store. Generates a new session_id (collision-
    safe) and seeds messages + state.json. User can then `prometheus`
    + `/resume <new-sid>` to pick up.
    """
    import json as _json
    import sys as _sys
    import uuid as _uuid
    from pathlib import Path as _Path
    from prometheus.memory.session import SessionStore
    p = _Path(path)
    if not p.exists():
        print(f"bundle not found: {p}", file=_sys.stderr)
        return 1
    try:
        bundle = _json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"bundle parse failed: {e}", file=_sys.stderr)
        return 1
    if bundle.get("format_version") != 1:
        print(f"unsupported bundle format_version: "
              f"{bundle.get('format_version')!r}", file=_sys.stderr)
        return 1
    new_sid = str(_uuid.uuid4())
    store = SessionStore()
    store.start(new_sid, settings.model, str(settings.workdir),
                label=f"imported from {p.name}")
    msgs = bundle.get("messages") or []
    for m in msgs:
        try:
            store.add_message(new_sid, m.get("role", "user"),
                              str(m.get("content", "")))
        except Exception:
            continue
    state = bundle.get("state") or {}
    if isinstance(state, dict) and state:
        try:
            store.save_state(new_sid, state)
        except Exception:
            pass
    print(f"imported session → new sid {new_sid}")
    print(f"  {len(msgs)} messages, source-sid {bundle.get('session_id', '?')[:16]}")
    print(f"  to continue: prometheus  →  /resume {new_sid[:8]}")
    return 0


def _run_recipe(settings, recipe_path: str) -> int:
    """Round-17 WOW: execute a YAML/JSON recipe, single-command portability.

    Recipe schema (all fields optional except `prompt`):

        name: build-changelog
        description: Generate CHANGELOG.md from commits since last tag
        permission_mode: acceptEdits          # default | acceptEdits | plan | skipAll
        model: ""                              # override settings.model
        env:                                   # extra env vars for this run
          PROMETHEUS_PER_TURN_USD_LIMIT: "0.5"
        prompt: |
          Read the most recent git tag and write a CHANGELOG.md...

    No magic, no DSL — just a stable command-line wrapper that turns a
    file checked into the repo into a reproducible agent invocation.
    """
    import asyncio, sys as _sys
    from pathlib import Path as _Path
    # Round-19: resolve `@gallery/<name>` to the bundled recipe shipped
    # under prometheus/recipes/. Lets users run `prometheus --run
    # @gallery/code-review` without copying a YAML into their repo.
    if recipe_path.startswith("@gallery/") or recipe_path == "@gallery":
        if recipe_path == "@gallery":
            here = _Path(__file__).resolve().parent / "recipes"
            if not here.exists():
                print("recipe gallery not bundled with this install", file=_sys.stderr)
                return 1
            print("Bundled recipe gallery:")
            for r in sorted(here.glob("*.yaml")):
                print(f"  @gallery/{r.stem}")
            return 0
        name = recipe_path[len("@gallery/"):]
        here = _Path(__file__).resolve().parent / "recipes"
        cand = here / f"{name}.yaml"
        if not cand.exists():
            cand = here / f"{name}.yml"
        if not cand.exists():
            print(
                f"unknown gallery recipe: {name}\n"
                f"see `prometheus --run @gallery` for the list",
                file=_sys.stderr,
            )
            return 1
        p = cand
    else:
        p = _Path(recipe_path)
    if not p.exists():
        print(f"recipe not found: {p}", file=_sys.stderr)
        return 1
    body = p.read_text(encoding="utf-8")
    recipe: dict
    try:
        if p.suffix.lower() in (".yaml", ".yml"):
            try:
                import yaml
                recipe = yaml.safe_load(body) or {}
            except ImportError:
                print(
                    "PyYAML not installed — `pip install pyyaml` or use "
                    "a JSON recipe file (.json)",
                    file=_sys.stderr,
                )
                return 1
        else:
            import json
            recipe = json.loads(body)
    except Exception as e:
        print(f"failed to parse recipe: {e}", file=_sys.stderr)
        return 1
    if not isinstance(recipe, dict):
        print("recipe root must be a mapping", file=_sys.stderr)
        return 1
    prompt = str(recipe.get("prompt", "")).strip()
    if not prompt:
        print("recipe missing required `prompt` field", file=_sys.stderr)
        return 1
    name = recipe.get("name") or p.stem
    perm_mode = str(recipe.get("permission_mode", "acceptEdits"))
    model = recipe.get("model") or settings.model
    env_extras = recipe.get("env") or {}
    if isinstance(env_extras, dict):
        import os as _os
        for k, v in env_extras.items():
            _os.environ[str(k)] = str(v)
    settings.model = model

    print(f"PrometheUS {__version__} — running recipe: {name}")
    if recipe.get("description"):
        print(f"  {recipe['description']}")
    print("─" * 40)

    from prometheus.agent.loop import AgentLoop
    from prometheus.provider.openrouter import OpenRouterClient
    from prometheus.tools import build_default_registry

    async def approve(_a, _b):
        return True

    def notify(_): pass
    def audit(*_): pass

    async def _run() -> int:
        registry = build_default_registry()
        async with OpenRouterClient(settings.api_key, settings.base_url, settings.request_timeout) as cli:
            agent = AgentLoop(
                client=cli, registry=registry, settings=settings,
                request_approval=approve, notify=notify, audit=audit,
            )
            agent.set_permission_mode(perm_mode)
            async for ev in agent.run(prompt):
                if ev.kind == "text" and ev.text:
                    _sys.stdout.write(ev.text)
                    _sys.stdout.flush()
                elif ev.kind == "tool_call":
                    _sys.stderr.write(f"\n[{ev.tool_call.name}]\n")
                elif ev.kind == "error":
                    _sys.stderr.write(f"\nerror: {ev.error}\n")
                    return 1
                elif ev.kind == "halt":
                    _sys.stderr.write(f"\nhalted: {ev.error}\n")
                    return 1
            _sys.stdout.write("\n")
            return 0

    return asyncio.run(_run())


def _eval() -> int:
    """Run the universal-task evaluation harness.

    Round-25 Track 5: graded canonical-workflow scoring. Distinct
    from --audit (structural / regression tests) — `--eval` runs the
    universal-audit script that grades real agent behavior on a fixed
    task set: scaffold a website, install + verify, refactor, debug,
    stuck-loop recovery, image paste, /architect → /proceed, BYOK,
    spending caps, mid-stream interrupt. Result is N/M PASS plus per-
    scenario verdicts. Use this between releases to catch behavioral
    regressions that --audit can't detect (model drift, latency
    creep, response-format drift).
    """
    import subprocess, sys as _sys
    from pathlib import Path as _Path
    here = _Path(__file__).resolve().parent.parent
    script = here / "scripts" / "live_universal_audit.py"
    if not script.exists():
        print(
            f"eval script not found at {script}.\n"
            "If you installed via PyPI the eval harness ships separately:\n"
            "  git clone https://github.com/prometheus-cli/prometheus\n"
            "  cd prometheus && python scripts/live_universal_audit.py",
            file=_sys.stderr,
        )
        return 1
    print(f"PrometheUS {__version__} — universal-task evaluation")
    print("─" * 56)
    rc = subprocess.call(
        [_sys.executable, "-u", str(script)],
        cwd=str(here),
        env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"},
    )
    print("─" * 56)
    if rc == 0:
        print("eval: PASS — universal-task suite verified for this release")
    else:
        print(f"eval: FAIL — see scenarios above (exit {rc})")
    return rc


def _audit() -> int:
    """Run the public acceptance suite and print a release-grade summary.

    PrometheUS ships its own audit. No other terminal AI agent does this —
    users can verify the release-on-disk does what the README claims by
    running `prometheus --audit` and reading the count.
    """
    import subprocess
    import sys as _sys
    from pathlib import Path as _Path
    here = _Path(__file__).resolve().parent.parent
    script = here / "scripts" / "workflow_audit.py"
    if not script.exists():
        print(
            f"audit script not found at {script}.\n"
            "If you installed via PyPI, the audit suite ships separately:\n"
            "  pip install prometheus-cli[dev]\n"
            "  git clone https://github.com/prometheus-cli/prometheus\n"
            "  cd prometheus && python scripts/workflow_audit.py",
            file=_sys.stderr,
        )
        return 1
    print(f"PrometheUS {__version__} — audit run")
    print("─" * 36)
    rc = subprocess.call(
        [_sys.executable, "-u", str(script)],
        cwd=str(here),
        env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"},
    )
    print("─" * 36)
    if rc == 0:
        print("audit: PASS — release verified against the public suite")
    else:
        print(f"audit: FAIL — see scenarios above (exit {rc})")
    return rc


def _doctor(settings) -> int:
    import asyncio
    from prometheus.config import public_name
    from prometheus.provider.openrouter import OpenRouterClient
    print(f"PrometheUS {__version__}")
    print(f"workdir: {settings.workdir}")
    print(f"engine:  {public_name(settings.model)}")
    print(f"credentials: {'configured' if settings.api_key else 'missing'}")
    # Round-18: pricing-data freshness. /cost is only as accurate as
    # pricing.json; surface a warning if it's >90 days stale so users
    # know to upgrade or refresh.
    try:
        from prometheus.provider.escalate import (
            pricing_is_stale, PRICING_LAST_UPDATED,
        )
        if pricing_is_stale():
            print(
                f"pricing: WARN — pricing.json last updated "
                f"{PRICING_LAST_UPDATED or '(never)'}, may be stale"
            )
        else:
            print(f"pricing: ok (last_updated {PRICING_LAST_UPDATED})")
    except Exception:
        pass
    # Round-19: telemetry-off attestation. PrometheUS makes no
    # background analytics calls. PROMETHEUS_TELEMETRY=off makes the
    # promise auditable in --doctor — users (and security reviewers)
    # can grep this line to confirm.
    import os as _os
    tele = _os.environ.get("PROMETHEUS_TELEMETRY", "off").lower()
    if tele in ("off", "0", "false", ""):
        print("telemetry: off — no analytics endpoint, no opt-in needed")
    else:
        print(f"telemetry: WARN — PROMETHEUS_TELEMETRY={tele!r} (no endpoint exists yet)")
    if not settings.api_key:
        print("FAIL: credentials missing — add PROMETHEUS_API_KEY to .env")
        return 1
    async def _check() -> int:
        async with OpenRouterClient(settings.api_key, settings.base_url, 30) as c:
            models = await c.free_models()
            print(f"engine status: ok ({len(models)} engines available)")
            return 0 if models else 2
    return asyncio.run(_check())


def _doctor_deep(settings) -> int:
    """Round-60: --doctor --deep — live-probe every chain entry against
    OpenRouter's catalog AND every configured pool provider's reachability.

    Prints a per-role chain liveness summary (live/dead counts), flags
    any dead chain HEADs (where every first request currently rotates
    away from), and notes which pool providers are configured + ready.
    """
    import asyncio, os as _os
    from prometheus.config import (
        CODER_CHAIN, PLANNER_CHAIN, FAST_CHAIN, VISION_CHAIN,
    )
    from prometheus.provider.pool import ProviderPool
    print(f"PrometheUS {__version__}  ·  --doctor --deep")
    print()
    # Pool reachability
    pool = ProviderPool.from_env()
    configured = pool.configured_providers()
    print(f"=== pool: {len(configured)}/{len(pool.providers)} providers configured ===")
    for p in pool.providers:
        if p.configured:
            kc = len(p.keys)
            print(f"  [READY] {p.name:<14}  {kc} key{'s' if kc != 1 else ''}")
        else:
            print(f"  [----]  {p.name:<14}  (not configured)")
    print()
    # Live chain probe
    from prometheus.provider.openrouter import OpenRouterClient

    async def _go() -> int:
        async with OpenRouterClient(
            settings.api_key, "https://openrouter.ai/api/v1", 30,
        ) as c:
            try:
                models = await c.list_models()
            except Exception as e:
                print(f"chain probe FAILED: {e}")
                return 1
            live = {m.get("id") for m in models if m.get("id")}
            any_dead_head = False
            for name, chain in (
                ("CODER", CODER_CHAIN), ("PLANNER", PLANNER_CHAIN),
                ("FAST", FAST_CHAIN), ("VISION", VISION_CHAIN),
            ):
                live_n = sum(1 for m in chain if m in live)
                head = chain[:3]
                head_live = sum(1 for m in head if m in live)
                tag = "[OK]      " if head_live == 3 else "[DEAD HEAD]"
                print(
                    f"  {tag} {name:<8}  head[{head_live}/3]  "
                    f"total[{live_n}/{len(chain)}]"
                )
                if head_live < 3:
                    any_dead_head = True
                    for m in head:
                        if m not in live:
                            print(f"          dead head entry: {m}")
            return 1 if any_dead_head else 0
    rc = asyncio.run(_go())
    print()
    if rc == 0:
        print("All chain heads live. Pool ready.")
    else:
        print("Chain has dead heads — run scripts/chain-check.ps1 for "
              "replacement candidates.")
    return rc


def _list_models(settings) -> int:
    """Show the configured engine roles + counts. Real upstream IDs are
    only revealed under PROMETHEUS_VERBOSE_MODELS=1 (power users / debug)."""
    import asyncio
    import os as _os
    from prometheus.config import (
        CODER_CHAIN, PLANNER_CHAIN, FAST_CHAIN, VISION_CHAIN,
    )
    verbose = _os.getenv("PROMETHEUS_VERBOSE_MODELS") == "1"
    chains = [
        ("Coder",   CODER_CHAIN),
        ("Planner", PLANNER_CHAIN),
        ("Fast",    FAST_CHAIN),
        ("Vision",  VISION_CHAIN),
    ]
    if not verbose:
        # Brand-hidden default: list each PUBLIC name in each tier.
        # Real upstream ids stay hidden behind PROMETHEUS_VERBOSE_MODELS=1.
        from prometheus.config import public_name
        for role, chain in chains:
            print(f"\n[{role}]")
            seen: set[str] = set()
            for mid in chain:
                pn = public_name(mid)
                if pn in seen:
                    continue
                seen.add(pn)
                print(f"  · {pn}")
        print()
        print("(set PROMETHEUS_VERBOSE_MODELS=1 to see upstream ids)")
        return 0
    # Verbose: show real IDs + ctx + tool support.
    from prometheus.provider.openrouter import OpenRouterClient
    async def _go() -> int:
        async with OpenRouterClient(settings.api_key, settings.base_url, 30) as c:
            data = await c.list_models()
            by_id = {m.get("id"): m for m in data}
            for role, chain in chains:
                print(f"\n[{role}]")
                for mid in chain:
                    m = by_id.get(mid, {})
                    ctx = m.get("context_length", 0)
                    tools = "tools" in (m.get("supported_parameters") or [])
                    print(f"  {mid:60} ctx={ctx:>7} tools={tools}")
            return 0
    return asyncio.run(_go())


def _prompt_once(settings, prompt: str) -> int:
    import asyncio
    from prometheus.agent.loop import AgentLoop
    from prometheus.provider.openrouter import OpenRouterClient
    from prometheus.tools import build_default_registry

    async def approve(_a, _b):
        return True

    def notify(_): pass
    def audit(*_): pass

    # Round-70: headless `-p` output. Pre-70 every tool call wrote a
    # raw snake_case name like "[web_search]" to stderr, leaking
    # internal tool identifiers into pipeable output. Now we emit
    # the brand-neutral PascalCase receipt_label that the TUI uses
    # (Read(foo.py), WebSearch("..."), Bash(npm test), etc.) ONLY
    # when PROMETHEUS_HEADLESS_VERBOSE=1 is set. Default behavior
    # is assistant-text-only so `prometheus -p "..."` works cleanly
    # in pipelines.
    import os as _os
    show_tool_lines = _os.getenv("PROMETHEUS_HEADLESS_VERBOSE") == "1"

    # Round 160 / FM3: headless checkpoint + structured failure file +
    # mandatory non-zero exit on failure. SitePoint production analysis
    # showed agents running in -p mode could fail silently for days.
    # Every tool call now writes a checkpoint BEFORE execution so the
    # user always has a known location to resume from.
    from prometheus.headless_checkpoint import (
        write_checkpoint, write_error_state, format_error_for_stderr,
    )

    async def _run() -> int:
        registry = build_default_registry()
        last_tool: str | None = None
        last_iter: int = 0
        async with OpenRouterClient(settings.api_key, settings.base_url, settings.request_timeout) as cli:
            agent = AgentLoop(
                client=cli,
                registry=registry,
                settings=settings,
                request_approval=approve,
                notify=notify,
                audit=audit,
            )
            agent.set_permission_mode("acceptEdits")
            try:
                # Round 182: NO_COLOR / piped-output detection. When
                # the user has set NO_COLOR, or stdout isn't a tty
                # (piped to a file or process), strip every ANSI
                # escape from the streamed text so the saved log
                # doesn't end up with literal `\x1b[31m` codes
                # embedded mid-line. This is the no-color.org spec
                # behaviour that every commercial CLI honours.
                from prometheus.color import should_use_color, strip_ansi
                _color_on = should_use_color(sys.stdout)
                async for ev in agent.run(prompt):
                    if ev.kind == "text" and ev.text:
                        out = ev.text if _color_on else strip_ansi(ev.text)
                        sys.stdout.write(out)
                        sys.stdout.flush()
                    elif ev.kind == "tool_call":
                        last_tool = ev.tool_call.name if ev.tool_call else last_tool
                        last_iter = getattr(ev, "iteration", last_iter) or last_iter
                        # FM3: checkpoint BEFORE the tool body runs.
                        try:
                            args = ev.tool_call.parsed_arguments() if ev.tool_call else {}
                        except Exception:
                            args = {}
                        write_checkpoint(
                            session_id=agent.session_id,
                            tool=last_tool or "<unknown>",
                            args=args,
                            iteration=last_iter,
                        )
                        if show_tool_lines:
                            tool = registry.get(ev.tool_call.name) if ev.tool_call else None
                            if tool is not None:
                                try:
                                    label = tool.receipt_label(
                                        ev.tool_call.parsed_arguments()
                                    )
                                except Exception:
                                    label = ev.tool_call.name
                            else:
                                label = ev.tool_call.name if ev.tool_call else "?"
                            sys.stderr.write(f"\n[{label}]\n")
                    elif ev.kind == "error":
                        write_error_state(
                            session_id=agent.session_id,
                            error=ev.error or "unspecified error",
                            last_tool=last_tool,
                            iteration=last_iter,
                        )
                        sys.stderr.write(format_error_for_stderr(
                            error=ev.error or "unspecified error",
                            session_id=agent.session_id,
                            last_tool=last_tool,
                        ) + "\n")
                        return 1
                    elif ev.kind == "halt":
                        write_error_state(
                            session_id=agent.session_id,
                            error=f"halted: {ev.error or 'unspecified halt'}",
                            last_tool=last_tool,
                            iteration=last_iter,
                        )
                        sys.stderr.write(format_error_for_stderr(
                            error=f"halted: {ev.error or 'unspecified halt'}",
                            session_id=agent.session_id,
                            last_tool=last_tool,
                        ) + "\n")
                        return 1
                sys.stdout.write("\n")
                return 0
            except Exception as e:
                # Catch anything the loop didn't surface as an event so
                # the user still gets a structured error file + exit 1.
                import traceback as _tb
                write_error_state(
                    session_id=agent.session_id,
                    error=f"{type(e).__name__}: {e}",
                    last_tool=last_tool,
                    iteration=last_iter,
                    traceback_text=_tb.format_exc(),
                )
                sys.stderr.write(format_error_for_stderr(
                    error=f"{type(e).__name__}: {e}",
                    session_id=agent.session_id,
                    last_tool=last_tool,
                ) + "\n")
                return 1

    return asyncio.run(_run())


def _dump_system_prompt(settings) -> int:
    """Round 137: print the assembled system prompt and exit.

    Loads the same registry the runtime uses, then calls
    `build_system_prompt` and writes the result to stdout."""
    try:
        from prometheus.agent.system import build_system_prompt
        from prometheus.tools import build_default_registry
    except Exception as e:
        print(f"failed to load prompt builder: {e}", file=sys.stderr)
        return 1
    try:
        tools = build_default_registry()
        body = build_system_prompt(
            settings.workdir,
            tools,
            permission_mode="default",
            output_style="default",
            user_prompt="",
        )
    except Exception as e:
        print(f"failed to build system prompt: {e}", file=sys.stderr)
        return 1
    print(body)
    return 0


def _fork_session_cli(settings, source_id: str) -> int:
    """Round 137: clone an existing session and print the new id."""
    try:
        from prometheus.session_fork import fork_session, render_fork_banner
        from prometheus.memory.session import SessionStore
    except Exception as e:
        print(f"fork-session unavailable: {e}", file=sys.stderr)
        return 1
    store = SessionStore()
    res = fork_session(source_id=source_id, store=store)
    if res is None:
        print(
            f"could not fork session: no source matching {source_id!r}",
            file=sys.stderr,
        )
        return 1
    print(render_fork_banner(res))
    return 0


def _from_pr_cli(settings, pr_number: int) -> int:
    """Round 137: locate the most-recent session linked to PR #N."""
    try:
        from prometheus.session_fork import (
            find_session_for_pr, render_from_pr_banner,
        )
        from prometheus.memory.session import SessionStore
    except Exception as e:
        print(f"from-pr unavailable: {e}", file=sys.stderr)
        return 1
    store = SessionStore()
    sessions: list[dict] = []
    try:
        rows = store.list_sessions() if hasattr(store, "list_sessions") else []
        for r in rows:
            if isinstance(r, dict):
                sessions.append(r)
            else:
                sessions.append({
                    "session_id": getattr(r, "session_id", ""),
                    "label": getattr(r, "label", ""),
                    "started_at": getattr(r, "started_at", 0),
                    "pr": getattr(r, "pr", 0),
                    "branch": getattr(r, "branch", ""),
                })
    except Exception:
        sessions = []
    match = find_session_for_pr(pr_number=pr_number, sessions=sessions)
    print(render_from_pr_banner(pr_number, match))
    return 0 if match is not None else 1


def _maybe_dispatch_subcommand(argv: list[str] | None) -> int | None:
    """Round 136: route `prometheus agents`, `prometheus mcp`,
    `prometheus forge`, `prometheus project purge` before
    arg-parse — these are first-class subcommands, not flags."""
    raw = list(argv) if argv is not None else sys.argv[1:]
    try:
        from prometheus.cli_subcommands import (
            is_subcommand, dispatch_subcommand,
        )
    except ImportError:
        return None
    if not is_subcommand(raw):
        return None
    res = dispatch_subcommand(raw, workdir=Path.cwd())
    if res.output:
        print(res.output)
    return res.exit_code


def _is_print_mode(argv: list[str] | None) -> bool:
    """Round 173: detect headless invocation early.

    The interactive parser in `_build_parser()` only knows a small
    flag set (--workdir, --model, --doctor, --prompt …). The full
    Claude-Code-style flag surface (--max-turns, --output-format,
    --mcp-config, --continue, --resume, --add-dir, --append-system-
    prompt, --allowedTools, --include-partial-messages, etc.) is
    defined in `prometheus.headless.build_parser()`. Without this
    early dispatch, every one of those flags errors out as
    "unrecognized argument" when the user runs
    `prometheus -p "task" --max-turns 5` — silently breaking
    documented commercial behaviour.

    Detection is intentionally simple: scan argv for `-p` or
    `--print`. Anything else stays on the interactive path.

    Round 189 (post-launch fix): only fall back to `sys.argv` when
    argv is None, not when it's an empty list. Pre-R189 the
    `if not argv` check treated `[]` as a sentinel and pulled in
    pytest's own `-p` plugin flag, producing false positives in
    every test that called `_is_print_mode([])`. The signature
    already typed argv as `list[str] | None`; the body should
    honour that.
    """
    if argv is None:
        argv = sys.argv[1:] if sys.argv else []
    for a in argv:
        if a in ("-p", "--print"):
            return True
        if a.startswith("--print="):
            return True
    return False


def _run_print_mode(argv: list[str] | None) -> int:
    """Round 173 / 174: dispatch to the full headless parser when
    the user invokes print mode. This is the bridge that makes
    every flag in `headless.build_parser()` actually reachable
    from the `prometheus` entry script.

    Round 174 fix: `render_result` takes the format string, not
    the parsed args namespace. The R173 first cut passed the
    namespace, which crashed inside the function with a string
    comparison TypeError on every -p invocation that produced
    output. Pure regression from R173 — caught by R174 audit.
    """
    import asyncio as _asyncio
    from prometheus.headless import build_parser as _hp, run_headless, render_result
    parser = _hp()
    args = parser.parse_args(argv)
    try:
        result = _asyncio.run(run_headless(args))
    except KeyboardInterrupt:
        sys.stderr.write("\ninterrupted\n")
        return 130
    fmt = getattr(args, "output_format", "text") or "text"
    rendered = render_result(result, fmt)
    if rendered:
        print(rendered)
    # 1.0.3 first-day bug fix: in text mode an init/runtime failure
    # used to produce zero stdout AND zero stderr — the user got an
    # exit-1 with no clue what went wrong. Surface the error string
    # to stderr whenever ok=False AND the format hasn't already
    # delivered it (json mode bakes the error into the envelope;
    # stream-json emits a `result` event during streaming).
    ok = bool(getattr(result, "ok", True))
    err = (getattr(result, "error", "") or "").strip()
    if not ok and err and fmt == "text":
        sys.stderr.write(f"prometheus: {err}\n")
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    sub_rc = _maybe_dispatch_subcommand(argv)
    if sub_rc is not None:
        return sub_rc
    # Round 173: early dispatch to the headless parser so all
    # documented `-p`/--print flags actually work. The interactive
    # parser below stays small.
    if _is_print_mode(argv):
        return _run_print_mode(argv)
    args = _build_parser().parse_args(argv)
    settings = load_settings()
    if args.workdir:
        settings.workdir = Path(args.workdir).resolve()
    if args.model:
        settings.model = args.model
    # Round 183: apply --offline / --reasoning-effort /
    # --add-gitignore-files. Each maps to both a Settings field
    # AND its env-var equivalent so downstream modules that read
    # the env directly (like prometheus.offline.is_offline) see
    # the flag too.
    if getattr(args, "offline", False):
        settings.offline = True
        os.environ["PROMETHEUS_OFFLINE"] = "1"
    if getattr(args, "reasoning_effort", ""):
        settings.reasoning_effort = args.reasoning_effort
        os.environ["PROMETHEUS_REASONING_EFFORT"] = args.reasoning_effort
    if getattr(args, "add_gitignore_files", False):
        settings.add_gitignore_files = True
        os.environ["PROMETHEUS_ADD_GITIGNORE_FILES"] = "1"
    setup_log(settings.log_level)

    if args.doctor:
        if args.deep:
            return _doctor_deep(settings)
        return _doctor(settings)
    if args.list_models:
        return _list_models(settings)
    if args.audit:
        return _audit()
    if args.eval:
        return _eval()
    if args.run:
        return _run_recipe(settings, args.run)
    if getattr(args, "export_session", None):
        return _export_session(settings, args.export_session)
    if getattr(args, "import_session", None):
        return _import_session(settings, args.import_session)
    # Round 137: --dump-system-prompt prints + exits.
    if getattr(args, "dump_system_prompt", False):
        return _dump_system_prompt(settings)
    # Round 137: --fork-session clones an existing session.
    if getattr(args, "fork_session", ""):
        return _fork_session_cli(settings, args.fork_session)
    # Round 137: --from-pr looks up a session by PR number.
    if getattr(args, "from_pr", 0):
        return _from_pr_cli(settings, int(args.from_pr))
    # Round 151: --resume-latest finds the most recent
    # session and threads its id into PROMETHEUS_RESUME_ID,
    # which the TUI app picks up on launch.
    if getattr(args, "resume_latest", False):
        try:
            from prometheus.memory.session import SessionStore
            store = SessionStore()
            rows = (
                store.list_sessions()
                if hasattr(store, "list_sessions") else []
            )
            sid = ""
            for row in rows:
                if isinstance(row, dict):
                    sid = str(row.get("session_id") or "")
                else:
                    sid = str(getattr(row, "session_id", "") or "")
                if sid:
                    break
            if sid:
                import os as _os
                _os.environ["PROMETHEUS_RESUME_ID"] = sid
                print(f"resuming latest session: {sid[:16]}…")
            else:
                print("no prior session found", file=sys.stderr)
                return 1
        except Exception as e:
            print(f"--resume-latest failed: {e}", file=sys.stderr)
            return 1
    # Round 187: the unified parser exposes prompt text in three slots
    # depending on how the user passed it:
    #   - positional `prompt ...`         → args.prompt (list[str])
    #   - --prompt VALUE                  → args.prompt_flag (str)
    #   - -p / --print on its own         → args.print_mode (bool)
    # Coalesce to a single string. -p alone with no text falls
    # through to the interactive launch (matches CC's `claude -p`).
    _prompt_text = ""
    _raw = getattr(args, "prompt", "")
    if isinstance(_raw, list):
        _prompt_text = " ".join(str(x) for x in _raw if x)
    elif isinstance(_raw, str):
        _prompt_text = _raw
    if not _prompt_text:
        _prompt_text = getattr(args, "prompt_flag", "") or ""
    if _prompt_text:
        return _prompt_once(settings, _prompt_text)

    if not settings.api_key:
        # Friendly first-run message — public users coming from a
        # blog/tweet may not know the env-var name or where to get a
        # key. Spell out every step.
        msg = (
            "\nPrometheUS — first run\n"
            "──────────────────────\n\n"
            "Set up takes 60 seconds:\n\n"
            "  1. Get a free API key from your engine provider:\n"
            "       https://openrouter.ai/keys\n"
            "       (sign in with GitHub or Google · no credit card required)\n\n"
            "  2. Drop it into a .env file in this folder:\n"
            f"       cd {settings.workdir}\n"
            "       echo PROMETHEUS_API_KEY=sk-or-v1-... > .env\n\n"
            "  3. Re-launch:\n"
            "       prometheus\n\n"
            "Optional premium-tier escalation (paid, off by default):\n"
            "       echo ANTHROPIC_API_KEY=sk-ant-... >> .env\n"
            "       — fires only when /escalate is invoked or the free\n"
            "         tier has failed twice on the same prompt.\n\n"
            "Tip: run `prometheus --doctor` after setup to verify.\n"
        )
        print(msg, file=sys.stderr)
        return 1

    # Launch the TUI.
    from prometheus.ui.app import PrometheusApp
    app = PrometheusApp(settings)
    # Round 180: honour Claude Code's CLAUDE_CODE_DISABLE_ALTERNATE_SCREEN
    # opt-out — keep the TUI inline in the terminal's native scrollback
    # rather than entering the fullscreen alternate screen. Real users:
    # CI log pipelines that want the conversation in scrollback,
    # screen-reader users, asciinema recorders, anyone wanting to copy/
    # paste session output into a bug report. PROMETHEUS_INLINE=1 is
    # the native alias for users who want the same behaviour without
    # adopting the CC env-var name.
    inline = (
        os.environ.get("CLAUDE_CODE_DISABLE_ALTERNATE_SCREEN", "").strip() in ("1", "true", "yes")
        or os.environ.get("PROMETHEUS_INLINE", "").strip() in ("1", "true", "yes")
    )
    try:
        if inline:
            app.run(inline=True)
        else:
            app.run()
    except TypeError:
        # Older Textual versions don't accept the `inline` kwarg —
        # fall through to the default fullscreen launch so the env-var
        # is a graceful no-op rather than a crash.
        app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
