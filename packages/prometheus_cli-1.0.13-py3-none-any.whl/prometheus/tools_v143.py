"""Round 143-v2: 10 new tools.

  EnterWorktree / ExitWorktree   — git worktree lifecycle
  TaskStop / TaskOutput          — bg-task lifecycle
  NotebookEdit                   — Jupyter cell edits
  PowerShell                     — native Windows shell
  EnterPlanMode / ExitPlanMode   — planning-phase gating
  ListMcpResources / ReadMcpResource — MCP resource browsing

Each Tool subclass declares its `side_effect` per the
round-93 contract. Execution paths are intentionally minimal
— they validate inputs, dispatch to the existing data
layer, and return structured results.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from prometheus.tools.base import Tool, SideEffect, ToolContext, ToolResult


# ---------- worktree ----------


class EnterWorktree(Tool):
    """Round 143-v2 + 1.0.3: create a worktree, or switch into an
    existing one (CC v2.1.105 parity)."""
    name = "enter_worktree"
    description = (
        "Create an isolated git worktree at a temp path (with `branch`), "
        "or switch into an existing worktree of the current repo (with "
        "`path`). Fires the WorktreeCreate sentinel."
    )
    schema = {
        "type": "object",
        "properties": {
            "branch": {"type": "string"},
            "base": {"type": "string"},
            "path": {
                "type": "string",
                "description": (
                    "1.0.3 (CC v2.1.105 parity): switch into an "
                    "existing worktree at this path instead of "
                    "creating a new one. Mutually exclusive with "
                    "`branch`."
                ),
            },
        },
    }
    side_effect = SideEffect.WRITE

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        from prometheus.worktree_launch import (
            create_worktree, list_worktrees,
        )
        existing_path = str(args.get("path", "")).strip()
        branch = str(args.get("branch", "")).strip()
        if existing_path and branch:
            return ToolResult(
                error=True,
                output="`path` and `branch` are mutually exclusive",
            )
        if not existing_path and not branch:
            return ToolResult(
                error=True,
                output="provide either `branch` (create new) or `path` (switch into existing)",
            )
        # 1.0.3: switch into an existing worktree.
        if existing_path:
            target = Path(existing_path).expanduser()
            try:
                target = target.resolve(strict=True)
            except (OSError, RuntimeError):
                return ToolResult(
                    error=True,
                    output=f"worktree path does not exist: {existing_path}",
                )
            if not target.is_dir():
                return ToolResult(
                    error=True,
                    output=f"worktree path is not a directory: {existing_path}",
                )
            # Verify this is a real worktree of the current repo.
            try:
                known = list_worktrees(ctx.workdir)
            except Exception:
                known = []
            known_resolved = {Path(p).resolve() for p in known} if known else set()
            if known_resolved and target not in known_resolved:
                return ToolResult(
                    error=True,
                    output=(
                        f"path is not a git worktree of this repo: "
                        f"{existing_path}"
                    ),
                )
            # If list_worktrees returned nothing (e.g. git missing),
            # fall back to a `.git` presence check — every worktree
                # has a `.git` file (not dir) pointing at the parent.
            if not known_resolved:
                gitfile = target / ".git"
                if not gitfile.exists():
                    return ToolResult(
                        error=True,
                        output=(
                            f"path has no .git entry — not a worktree: "
                            f"{existing_path}"
                        ),
                    )
            return ToolResult(
                error=False,
                output=f"switched into existing worktree\n  path:   {target}",
            )
        # original "create new" path
        base = args.get("base") or None
        h = create_worktree(
            base=Path(base) if base else None,
            branch_prefix=branch,
        )
        if h is None:
            return ToolResult(
                error=True,
                output="could not create worktree (git unavailable or not a repo)",
            )
        return ToolResult(
            error=False,
            output=(
                f"worktree created\n"
                f"  branch: {h.branch}\n"
                f"  path:   {h.path}"
            ),
        )


class ExitWorktree(Tool):
    """Round 143-v2: clean up the active worktree."""
    name = "exit_worktree"
    description = (
        "Tear down the active worktree and switch back to the "
        "parent repo. Fires the WorktreeRemove sentinel."
    )
    schema = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "base": {"type": "string"},
            "keep": {"type": "boolean"},
        },
        "required": ["path", "base"],
    }
    side_effect = SideEffect.WRITE

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        from prometheus.worktree_launch import (
            WorktreeHandle, cleanup_worktree,
        )
        path = str(args.get("path", "")).strip()
        base = str(args.get("base", "")).strip()
        keep = bool(args.get("keep", False))
        if not path or not base:
            return ToolResult(
                error=True, output="path and base are required",
            )
        h = WorktreeHandle(
            path=Path(path), branch="",
            base_repo=Path(base), keep=keep,
        )
        ok = cleanup_worktree(h)
        return ToolResult(
            error=not ok,
            output=(
                "worktree removed" if ok
                else "worktree removal failed (cleanup left stale files)"
            ),
        )


# ---------- task lifecycle ----------


class TaskStop(Tool):
    """Round 143-v2: stop a running background task by id."""
    name = "task_stop"
    description = "Stop a running background task by its id."
    schema = {
        "type": "object",
        "properties": {"task_id": {"type": "string"}},
        "required": ["task_id"],
    }
    side_effect = SideEffect.EXEC

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        tid = str(args.get("task_id", "")).strip()
        if not tid:
            return ToolResult(error=True, output="task_id is required")
        # Round-97 BackgroundAgentManager is on app — try it
        # then fall back to round-142 bg_sessions when host is
        # the CLI launcher, not the TUI app.
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        mgr = getattr(app, "background_agent_manager", None)
        if mgr is not None and hasattr(mgr, "cancel"):
            try:
                ok = bool(mgr.cancel(tid))
                return ToolResult(
                    error=not ok,
                    output=(
                        f"task {tid} cancelled" if ok
                        else f"no running task with id {tid}"
                    ),
                )
            except Exception as e:
                return ToolResult(
                    error=True, output=f"cancel failed: {e}",
                )
        return ToolResult(
            error=True,
            output=f"no background-agent manager available",
        )


class TaskOutput(Tool):
    """Round 143-v2: retrieve output from a completed bg task."""
    name = "task_output"
    description = (
        "Return the output of a completed background task."
    )
    schema = {
        "type": "object",
        "properties": {"task_id": {"type": "string"}},
        "required": ["task_id"],
    }
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        tid = str(args.get("task_id", "")).strip()
        if not tid:
            return ToolResult(error=True, output="task_id is required")
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        mgr = getattr(app, "background_agent_manager", None)
        if mgr is not None and hasattr(mgr, "output_for"):
            try:
                body = mgr.output_for(tid) or ""
                if not body:
                    return ToolResult(
                        error=True,
                        output=f"no output for {tid} (task still running?)",
                    )
                return ToolResult(error=False, output=body)
            except Exception as e:
                return ToolResult(error=True, output=str(e))
        return ToolResult(
            error=True, output="no background-agent manager available",
        )


# ---------- notebook ----------


class NotebookEdit(Tool):
    """Round 143-v2: edit a Jupyter notebook cell.

    Loads the .ipynb JSON, replaces / inserts / deletes the
    referenced cell, and writes back atomically."""
    name = "notebook_edit"
    description = (
        "Edit a Jupyter notebook cell. Reads the .ipynb JSON, "
        "applies the requested mutation, and writes the file "
        "back atomically."
    )
    # Round 173: schema accepts both Prometheus-native names
    # (path / operation / source / cell_index) AND the official
    # Claude Code names (notebook_path / edit_type / new_source /
    # cell_id). The Anthropic models ship trained against the
    # CC schema, so without dual-name support every NotebookEdit
    # tool call from the model would have errored "invalid args"
    # for paying users.
    schema = {
        "type": "object",
        "properties": {
            "notebook_path": {
                "type": "string",
                "description": "Absolute path to the .ipynb file (preferred name).",
            },
            "path": {"type": "string", "description": "Alias for notebook_path."},
            "edit_type": {
                "type": "string",
                "enum": ["replace", "insert", "delete"],
                "description": "Operation to perform (default replace).",
            },
            "operation": {
                "type": "string",
                "enum": ["replace", "insert", "delete"],
                "description": "Alias for edit_type.",
            },
            "cell_id": {
                "type": "string",
                "description": "Cell `id` field as an alternative to cell_index.",
            },
            "cell_index": {
                "type": "integer",
                "description": "0-based cell index (alternative to cell_id).",
            },
            "new_source": {
                "type": "string",
                "description": "New cell content (preferred name).",
            },
            "source": {"type": "string", "description": "Alias for new_source."},
            "cell_type": {
                "type": "string",
                "enum": ["code", "markdown", "raw"],
            },
        },
        "required": ["notebook_path"],
    }
    side_effect = SideEffect.WRITE

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        if (r := ctx.plan_mode_refusal("notebook_edit")):
            return r
        # Round 173: accept both naming conventions.
        path = str(
            args.get("notebook_path") or args.get("path") or ""
        ).strip()
        op = str(
            args.get("edit_type") or args.get("operation") or "replace"
        ).lower()
        source = (
            args.get("new_source")
            if args.get("new_source") is not None
            else args.get("source", "")
        )
        cell_id = str(args.get("cell_id") or "").strip()
        # cell_index is None vs 0 ambiguity — only treat the key
        # as supplied if it's literally in the dict.
        idx_supplied = "cell_index" in args
        idx = int(args.get("cell_index", 0)) if idx_supplied else 0
        cell_type = str(args.get("cell_type", "code"))
        if not path:
            return ToolResult(
                error=True,
                output="missing required arg: notebook_path (or path)",
            )
        if op not in ("replace", "insert", "delete"):
            return ToolResult(
                error=True,
                output=f"invalid edit_type/operation: {op!r} "
                       f"(expected replace|insert|delete)",
            )
        p = Path(path)
        if not p.exists():
            return ToolResult(error=True, output=f"not found: {path}")
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            return ToolResult(error=True, output=f"parse failed: {e}")
        cells = data.get("cells")
        if not isinstance(cells, list):
            return ToolResult(error=True, output="not a notebook")
        # Round 173: resolve cell_id → cell_index when caller
        # used the Claude Code addressing scheme.
        if cell_id and not idx_supplied:
            resolved = -1
            for i, c in enumerate(cells):
                if isinstance(c, dict) and str(c.get("id") or "") == cell_id:
                    resolved = i
                    break
            if resolved < 0:
                return ToolResult(
                    error=True,
                    output=f"cell_id {cell_id!r} not found",
                )
            idx = resolved
        new_cell = {
            "cell_type": cell_type,
            "metadata": {},
            "source": (
                source.splitlines(keepends=True)
                if isinstance(source, str) else []
            ),
        }
        if cell_type == "code":
            new_cell["execution_count"] = None
            new_cell["outputs"] = []
        if op == "replace":
            if not 0 <= idx < len(cells):
                return ToolResult(
                    error=True,
                    output=f"cell_index {idx} out of range",
                )
            cells[idx] = new_cell
        elif op == "insert":
            cells.insert(max(0, min(len(cells), idx)), new_cell)
        elif op == "delete":
            if not 0 <= idx < len(cells):
                return ToolResult(
                    error=True,
                    output=f"cell_index {idx} out of range",
                )
            cells.pop(idx)
        # Atomic write.
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(
            json.dumps(data, indent=1, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp.replace(p)
        return ToolResult(
            error=False,
            output=f"{op} cell {idx} in {p}; {len(cells)} cell(s) total",
        )


# ---------- PowerShell ----------


class PowerShell(Tool):
    """Round 143-v2: native PowerShell execution on Windows.

    On non-Windows hosts, returns an unsupported error so the
    agent falls through to RunBash."""
    name = "powershell"
    description = (
        "Run a PowerShell command natively. Auto-detects "
        "pwsh.exe vs powershell.exe. Windows only."
    )
    schema = {
        "type": "object",
        "properties": {
            "command": {"type": "string"},
            "timeout_ms": {"type": "integer"},
        },
        "required": ["command"],
    }
    side_effect = SideEffect.EXEC

    @staticmethod
    def _resolve_exe() -> Optional[str]:
        import shutil as _sh
        for cand in ("pwsh.exe", "pwsh", "powershell.exe", "powershell"):
            p = _sh.which(cand)
            if p:
                return p
        return None

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        if not sys.platform.startswith("win"):
            return ToolResult(
                error=True,
                output="powershell tool: Windows-only (use run_bash on POSIX)",
            )
        cmd = str(args.get("command", "")).strip()
        if not cmd:
            return ToolResult(error=True, output="command is required")
        exe = self._resolve_exe()
        if exe is None:
            return ToolResult(
                error=True,
                output="powershell not found on PATH",
            )
        timeout = max(
            1000,
            int(args.get("timeout_ms", 60_000)),
        ) / 1000.0
        try:
            cp = subprocess.run(
                [exe, "-NoProfile", "-Command", cmd],
                capture_output=True, text=True,
                timeout=timeout, check=False,
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                error=True, output=f"timeout after {timeout}s",
            )
        out = (cp.stdout or "") + (cp.stderr or "")
        return ToolResult(
            error=(cp.returncode != 0),
            output=out.strip()[:30_000],
        )


# ---------- plan mode ----------


class EnterPlanMode(Tool):
    """Round 143-v2: enter planning phase. Read-only + opusplan
    routing."""
    name = "enter_plan_mode"
    description = (
        "Enter planning phase. Reads only, no edits. The model "
        "produces a plan and waits for user approval before "
        "any write."
    )
    schema = {"type": "object", "properties": {}}
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        agent = getattr(app, "agent", None) if app else None
        if agent is not None and hasattr(agent, "set_permission_mode"):
            try:
                agent.set_permission_mode("plan")
            except Exception:
                pass
        os.environ["PROMETHEUS_PLAN_MODE"] = "1"
        return ToolResult(
            error=False,
            output="plan mode entered — read-only; produce a plan, await approval.",
        )


class ExitPlanMode(Tool):
    """Round 143-v2: leave planning phase."""
    name = "exit_plan_mode"
    description = "Exit planning phase and resume normal execution."
    schema = {"type": "object", "properties": {}}
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        agent = getattr(app, "agent", None) if app else None
        if agent is not None and hasattr(agent, "set_permission_mode"):
            try:
                agent.set_permission_mode("default")
            except Exception:
                pass
        os.environ["PROMETHEUS_PLAN_MODE"] = "0"
        return ToolResult(
            error=False,
            output="plan mode exited — normal execution resumed.",
        )


# ---------- MCP resources ----------


class ListMcpResources(Tool):
    """Round 143-v2: list resources exposed by every connected
    MCP server. Works against the round-100 mcp registry."""
    name = "list_mcp_resources"
    description = (
        "List resources exposed by all connected MCP servers."
    )
    schema = {
        "type": "object",
        "properties": {"server": {"type": "string"}},
    }
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        only = str(args.get("server", "")).strip()
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        servers: dict[str, Any] = (
            getattr(app, "_mcp_servers", {}) or {}
        )
        if not servers:
            return ToolResult(
                error=False, output="no MCP servers running",
            )
        rows: list[str] = []
        for name, srv in servers.items():
            if only and name != only:
                continue
            try:
                resp = await srv.call("resources/list", {})
                resources = (
                    resp.get("resources", []) if isinstance(resp, dict)
                    else []
                )
                rows.append(f"  {name}: {len(resources)} resource(s)")
                for r in resources[:20]:
                    if isinstance(r, dict):
                        uri = r.get("uri") or "?"
                        title = r.get("name") or r.get("description") or ""
                        rows.append(f"    {uri}  {title}")
            except Exception as e:
                rows.append(f"  {name}: error — {e}")
        if not rows:
            return ToolResult(
                error=False,
                output=f"no MCP server matching {only!r}",
            )
        return ToolResult(error=False, output="\n".join(rows))


class ReadMcpResource(Tool):
    """Round 143-v2: read a specific MCP resource by uri."""
    name = "read_mcp_resource"
    description = (
        "Read a specific MCP resource by URI from a connected "
        "server."
    )
    schema = {
        "type": "object",
        "properties": {
            "server": {"type": "string"},
            "uri": {"type": "string"},
        },
        "required": ["server", "uri"],
    }
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        name = str(args.get("server", "")).strip()
        uri = str(args.get("uri", "")).strip()
        if not name or not uri:
            return ToolResult(
                error=True, output="server and uri are required",
            )
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        servers: dict[str, Any] = (
            getattr(app, "_mcp_servers", {}) or {}
        )
        srv = servers.get(name)
        if srv is None:
            return ToolResult(
                error=True, output=f"no MCP server named {name!r}",
            )
        try:
            resp = await srv.call(
                "resources/read", {"uri": uri},
            )
        except Exception as e:
            return ToolResult(error=True, output=f"read failed: {e}")
        return ToolResult(
            error=False,
            output=json.dumps(resp, indent=2, default=str)[:30_000],
        )


# ---------- registry helper ----------


def all_round143_tools() -> list[Tool]:
    """Round 143-v2: every new tool to register. The registry
    builder calls this so tests can probe the surface."""
    return [
        EnterWorktree(), ExitWorktree(),
        TaskStop(), TaskOutput(),
        NotebookEdit(),
        PowerShell(),
        EnterPlanMode(), ExitPlanMode(),
        ListMcpResources(), ReadMcpResource(),
    ]
