"""Tool ABC, registry, and execution context.

A tool is: a name, JSON schema, side-effect class, and an async execute()
that takes parsed args and a ToolContext. Side-effect class drives both
the permission check (read-only auto-allowed; mutations gated) and the
parallel-dispatch policy in the agent loop.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable


class SideEffect(str, Enum):
    READ = "read"        # safe, parallel-dispatchable
    WRITE = "write"      # mutates files / state — checkpoint first
    EXEC = "exec"        # runs commands — gated unless skip-all
    NETWORK = "network"  # web fetch — read-only but external


def classify_phase(tool_name: str) -> str:
    """Round-37: Claude-Code-style three-phase tag for a tool.

    Returns one of: 'gather' | 'execute' | 'verify'. The TUI activity
    line consumes this to render subtle phase transitions during a
    multi-tool turn ("gathering context…" → "executing…" → "verifying…").
    """
    n = (tool_name or "").lower()
    if n in {"read_file", "glob_files", "list_files", "grep", "search_code",
             "web_search", "web_fetch"}:
        return "gather"
    if n in {"py_compile", "lint", "typecheck", "test", "verify"}:
        return "verify"
    return "execute"


class PermissionDenied(Exception):
    """Raised when permission mode forbids a tool execution."""


class ToolError(Exception):
    """Tool execution failed in a way the model should learn about."""


@dataclass
class ToolResult:
    """Result of a tool call.

    `output` is the model-facing string (becomes tool message content).
    `display` is the optional UI-facing rich text (multi-line, indented).
    `summary` is the short one-line ⏺ receipt label.
    """
    output: str
    summary: str = ""
    display: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    error: bool = False


@dataclass
class ToolContext:
    """Per-call execution context provided by the agent loop."""
    workdir: Path
    permission_mode: str  # "default" | "acceptEdits" | "plan" | "skipAll"
    # Round-95: optional `meta` kwarg lets tools attach structured
    # approval-card fields (cwd / risk / timeout / why). Old callers
    # that only pass (tool, detail) keep working — the bridge in
    # PrometheusApp._request_approval defaults meta=None.
    request_approval: Callable[..., Awaitable[bool]]
    notify: Callable[[str], None]  # for UI announcements (rare)
    session_id: str
    audit: Callable[[str, dict[str, Any]], None]
    # Tool-specific shared state holders:
    todos: list[dict[str, Any]] = field(default_factory=list)
    snapshots: list[dict[str, Any]] = field(default_factory=list)
    # Per-turn ledger of {tool_name → bool success}. Used by tools that
    # want to short-circuit when a sibling tool already produced an
    # answer (e.g. web_fetch after a successful web_search).
    turn_tools: dict[str, bool] = field(default_factory=dict)
    # Round-24 Claude-parity: set of absolute paths the agent has Read
    # this session. EditFile / MultiEdit / ApplyPatch must error if
    # asked to edit a path NOT in here. Matches Claude Code's
    # `EditWithoutReadError` behavior. Reset on /clear.
    read_history: set[str] = field(default_factory=set)
    # Optional handle to runtime singletons (background jobs, etc.).
    # The agent loop fills this when running under the live App.
    runtime: Any = None

    def plan_mode_refusal(self, tool_name: str) -> "ToolResult | None":
        """Round 175: defense-in-depth plan-mode gate.

        The agent loop already simulates WRITE/EXEC tools when
        `permission_mode == "plan"`, but tools can also be invoked
        outside the loop — by hooks, MCP bridges, recipe runners,
        custom slash commands, or automation scripts that hand-build
        a `ToolContext`. Without a tool-side guard, those paths bypass
        plan mode entirely and writes hit disk.

        Side-effect WRITE / EXEC / NETWORK tools call this at the
        top of `execute()`. Returns a `ToolResult` with the standard
        refusal message if plan mode is active; `None` otherwise so
        the call site can `if (r := ctx.plan_mode_refusal("foo"))
        return r`.
        """
        if self.permission_mode == "plan":
            return ToolResult(
                output=(
                    f"refused: {tool_name} is not allowed in plan mode. "
                    f"Plan mode is read-only — call ExitPlanMode with "
                    f"the proposed plan, get user approval, and the "
                    f"agent will switch back to a writable mode."
                ),
                error=True,
                summary="plan-mode refused",
            )
        return None


class Tool(ABC):
    name: str
    description: str
    schema: dict[str, Any]
    side_effect: SideEffect = SideEffect.READ

    @abstractmethod
    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult: ...

    def to_openai_tool(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.schema,
            },
        }

    def receipt_label(self, args: dict[str, Any]) -> str:
        """Short label shown next to ⏺ for this tool. Subclasses override."""
        return self.name


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def all(self) -> list[Tool]:
        return list(self._tools.values())

    def to_openai_tools(self) -> list[dict[str, Any]]:
        return [t.to_openai_tool() for t in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def subset(self, names: list[str]) -> "ToolRegistry":
        """Round-92: return a smaller registry containing only the named
        tools. Used to lean down the tool definitions sent to free
        models on focused tasks (a clone-and-read job needs run_bash +
        read_file, not all 15 tools)."""
        sub = ToolRegistry()
        for n in names:
            t = self._tools.get(n)
            if t is not None:
                sub.register(t)
        return sub
