# pyright: strict

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Protocol

from pydantic import BaseModel

import fusaware_instruments.visa_instrument_hal.hal_oscilloscope as hal_oscope
from fusaware_instruments.utils import (
    MappingDirection,
    MappingException,
    MappingExceptionBase,
)


class Coupling(Enum):
    AC = "ac"
    DC = "dc"
    Ground = "ground"


class State(Enum):
    Disabled = "disabled"
    Enabled = "enabled"


class Units(Enum):
    Amps = "amps"
    Volts = "volts"
    Other = "other"


class ProbeState(BaseModel):
    attenuation: float
    bandwidth_limit: float | None = None
    coupling: Coupling
    offset: float
    scale: float
    state: State
    units: Units


class OscopeConverter:
    def __init__(self):
        pass

    def state_to_hal(self, state: State) -> bool:
        match state:
            case State.Disabled:
                return False
            case State.Enabled:
                return True

    def state_from_hal(self, hal_state: bool) -> State:
        return State.Enabled if hal_state else State.Disabled

    def units_to_hal(self, units: Units) -> hal_oscope.Units:
        match units:
            case Units.Amps:
                return hal_oscope.Units.AMPS
            case Units.Volts:
                return hal_oscope.Units.VOLTS
            case Units.Other:
                return hal_oscope.Units.CUSTOM

    def units_from_hal(self, hal_units: hal_oscope.Units) -> Units:
        match hal_units:
            case hal_oscope.Units.AMPS:
                return Units.Amps
            case hal_oscope.Units.VOLTS:
                return Units.Volts
            case hal_oscope.Units.CUSTOM:
                return Units.Other
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToConfig,
                    from_type=Units,
                    to_type=hal_oscope.Units,
                    value=hal_units,
                )

    # YOLO'd this
    def bandwidth_limit_to_hal(
        self, bandwidth_limit: float | None
    ) -> tuple[bool, float]:
        if bandwidth_limit is None:
            return (False, 0)
        else:
            return (True, bandwidth_limit)

    def bandwidth_limit_from_hal(
        self, enabled: bool, hal_bandwidth_limit: float
    ) -> float | None:
        if not enabled:
            return None
        else:
            return hal_bandwidth_limit

    def coupling_to_hal(self, coupling: Coupling) -> hal_oscope.ProbeCoupling:
        match coupling:
            case Coupling.AC:
                return hal_oscope.ProbeCoupling.AC
            case Coupling.DC:
                return hal_oscope.ProbeCoupling.DC
            case Coupling.Ground:
                return hal_oscope.ProbeCoupling.GROUND

    def coupling_from_hal(self, hal_coupling: hal_oscope.ProbeCoupling) -> Coupling:
        match hal_coupling:
            case hal_oscope.ProbeCoupling.AC:
                return Coupling.AC
            case hal_oscope.ProbeCoupling.DC:
                return Coupling.DC
            case hal_oscope.ProbeCoupling.GROUND:
                return Coupling.Ground

    def attenuation_to_hal(self, attenuation: float) -> float:
        return attenuation

    def attenuation_from_hal(self, hal_attenuation: float) -> float:
        return hal_attenuation

    def scale_to_hal(self, scale: float) -> float:
        return scale

    def scale_from_hal(self, hal_scale: float) -> float:
        return hal_scale

    def offset_to_hal(self, offset: float) -> float:
        return offset

    def offset_from_hal(self, hal_offset: float) -> float:
        return hal_offset


class ReconcileException(Exception): ...


class Param(Protocol):
    def name(self) -> str: ...
    def value(self) -> str: ...
    def query(self) -> None: ...
    def write(self) -> None: ...
    def compare(self) -> bool: ...
    def error_message(self) -> str: ...


class OscopeParam[T, S]:
    def __init__(
        self,
        desired_value: T,
        hal: hal_oscope.HALOscilloscope,
        converter: OscopeConverter,
    ):
        self._desired_value = desired_value
        self._current_value: S | None = None
        self._hal = hal
        self._converter = converter


class ReconcileState(Enum):
    Start = "start"
    InitialRead = "initial_read"
    Write = "write"
    FinalRead = "final_read"


class OscopeParamV2[T, S]:
    def __init__(
        self,
        desired_value: T,
        getter: Callable[[], S],
        setter: Callable[[S], None],
        converter: Callable[[T], S],
    ):
        self._desired_value = desired_value
        self._current_value: S | None = None
        self._getter = getter
        self._setter = setter
        self._converter = converter
        self._state = ReconcileState.Start
        self._has_compared = True

    def value(self) -> str:
        return str(self._desired_value)

    def query(self) -> None:
        print(self._state)
        match self._state:
            case ReconcileState.Start:
                self._current_value = self._getter()
                self._state = ReconcileState.InitialRead
                self._has_compared = False
            case ReconcileState.InitialRead:
                self._current_value = self._getter()
                self._state = ReconcileState.FinalRead
                self._has_compared = False
            case ReconcileState.Write:
                self._current_value = self._getter()
                self._state = ReconcileState.FinalRead
                self._has_compared = False
            case ReconcileState.FinalRead:
                raise RuntimeError("Already queried final value.")

    def write(self) -> None:
        print(self._state)
        match self._state:
            case ReconcileState.Start:
                raise RuntimeError("Must query before writing.")
            case ReconcileState.InitialRead:
                self._setter(self._converter(self._desired_value))
                self._state = ReconcileState.Write
            case ReconcileState.Write | ReconcileState.FinalRead:
                raise RuntimeError("Already wrote value.")

    def compare(self) -> bool:
        print(self._state)
        match self._state:
            case ReconcileState.Start:
                raise RuntimeError("Must query before comparing.")
            case ReconcileState.InitialRead:
                if self._current_value is None:
                    raise ValueError("Current value is None after initial read.")
                if self._has_compared:
                    raise RuntimeError("Already compared initial value.")
                self._has_compared = True
                return compare_param(
                    self._desired_value, self._current_value, self._converter
                )
            case ReconcileState.Write:
                raise RuntimeError("Must query final value before comparing.")
            case ReconcileState.FinalRead:
                if self._current_value is None:
                    raise ValueError("Current value is None after final read.")
                if self._has_compared:
                    raise RuntimeError("Already compared final value.")
                self._has_compared = True
                return compare_param(
                    self._desired_value, self._current_value, self._converter
                )


class StateParamV2(OscopeParamV2[State, bool], Param):
    def __init__(
        self,
        desired_value: State,
        hal: hal_oscope.HALOscilloscope,
    ) -> None:
        self._hal = hal
        self._converter = OscopeConverter()

        super().__init__(
            desired_value=desired_value,
            getter=self._hal.get_probe_display,
            setter=self._hal.set_probe_display,
            converter=self._converter.state_to_hal,
        )

    def name(self) -> str:
        return "state"

    def value(self) -> str:
        return self._desired_value.value

    def error_message(self) -> str:
        return f"Expected state {self._desired_value}, got {self._current_value}."


class StateParam(OscopeParam[State, bool], Param):
    def name(self) -> str:
        return "state"

    def value(self) -> str:
        return self._desired_value.value

    def query(self) -> None:
        self._current_value = self._hal.get_probe_display()

    def write(self) -> None:
        self._hal.set_probe_display(self._converter.state_to_hal(self._desired_value))

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return compare_param(
            self._desired_value, self._current_value, self._converter.state_to_hal
        )

    def error_message(self) -> str:
        return f"Expected state {self._desired_value}, got {self._current_value}."


class UnitsParam(OscopeParam[Units, hal_oscope.Units], Param):
    def name(self) -> str:
        return "units"

    def value(self) -> str:
        return self._desired_value.value

    def query(self) -> None:
        self._current_value = self._hal.get_probe_units()

    def write(self) -> None:
        self._hal.set_probe_units(self._converter.units_to_hal(self._desired_value))

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return compare_param(
            self._desired_value, self._current_value, self._converter.units_to_hal
        )

    def error_message(self) -> str:
        return f"Expected units {self._desired_value}, got {self._current_value}."


class BandwidthLimitParam(OscopeParam[float | None, tuple[bool, float]], Param):
    def name(self) -> str:
        return "bandwidth_limit"

    def value(self) -> str:
        return str(self._desired_value)

    def query(self) -> None:
        self._current_value = self._hal.get_probe_bandwidth_limit()

    def write(self) -> None:
        converted_bandwidth_limit = self._converter.bandwidth_limit_to_hal(
            self._desired_value
        )
        self._hal.set_probe_bandwidth_limit(
            converted_bandwidth_limit[0], converted_bandwidth_limit[1]
        )

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return compare_param(
            self._desired_value,
            self._current_value,
            self._converter.bandwidth_limit_to_hal,
        )

    def error_message(self) -> str:
        return f"Expected bandwidth limit {self._desired_value}, got {self._current_value}."


class CouplingParam(OscopeParam[Coupling, hal_oscope.ProbeCoupling], Param):
    def name(self) -> str:
        return "coupling"

    def value(self) -> str:
        return self._desired_value.value

    def query(self) -> None:
        self._current_value = self._hal.get_probe_coupling()

    def write(self) -> None:
        self._hal.set_probe_coupling(
            self._converter.coupling_to_hal(self._desired_value)
        )

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return compare_param(
            self._desired_value, self._current_value, self._converter.coupling_to_hal
        )

    def error_message(self) -> str:
        return f"Expected coupling {self._desired_value}, got {self._current_value}."


class AttenuationParam(OscopeParam[float, float], Param):
    def name(self) -> str:
        return "attenuation"

    def value(self) -> str:
        return str(self._desired_value)

    def query(self) -> None:
        hal_attenuation = self._hal.get_probe_attenuation()
        self._current_value = self._converter.attenuation_from_hal(
            hal_attenuation.attenuation
        )

    def write(self) -> None:
        self._hal.set_probe_attenuation(
            self._converter.attenuation_to_hal(self._desired_value)
        )

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return self._current_value == self._desired_value

    def error_message(self) -> str:
        return f"Expected attenuation {self._desired_value}, got {self._current_value}."


class ScaleParam(OscopeParam[float, float], Param):
    def name(self) -> str:
        return "scale"

    def value(self) -> str:
        return str(self._desired_value)

    def query(self) -> None:
        hal_scale = self._hal.get_probe_scale()
        self._current_value = self._converter.scale_from_hal(hal_scale)

    def write(self) -> None:
        self._hal.set_probe_scale(self._converter.scale_to_hal(self._desired_value))

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return self._current_value == self._desired_value

    def error_message(self) -> str:
        return f"Expected scale {self._desired_value}, got {self._current_value}."


class OffsetParam(OscopeParam[float, float], Param):
    def name(self) -> str:
        return "offset"

    def value(self) -> str:
        return str(self._desired_value)

    def query(self) -> None:
        hal_offset = self._hal.get_probe_offset()
        self._current_value = self._converter.offset_from_hal(hal_offset)

    def write(self) -> None:
        self._hal.set_probe_offset(self._converter.offset_to_hal(self._desired_value))

    def compare(self) -> bool:
        if self._current_value is None:
            raise ValueError("Must query before comparing.")
        return self._current_value == self._desired_value

    def error_message(self) -> str:
        return f"Expected offset {self._desired_value}, got {self._current_value}."


def reconcile[R](
    params: list[Param], response_factory: Callable[[dict[str, Any]], R]
) -> R:
    # Read
    for param in params:
        param.query()

    params_to_reconcile = [param for param in params if not param.compare()]

    # Update
    for param in params_to_reconcile:
        param.write()

    # Read again
    for param in params:
        param.query()

    reconciliation_errors = [
        param.error_message() for param in params if not param.compare()
    ]

    # Raise with all errors
    if len(reconciliation_errors) > 0:
        raise ReconcileException(reconciliation_errors)

    # Marshall into expected response
    return response_factory(
        {param.name(): param.value() for param in params if param.value() != "None"}
    )


def compare_param[T, S](left: T, right: S, converter: Callable[[T], S]) -> bool:
    try:
        return converter(left) == right
    except MappingException:
        return False


class AnalogProbe:
    def __init__(self, hal: hal_oscope.HALOscilloscope):
        self._hal = hal
        self._converter = OscopeConverter()

    def configure_probe(self, state: ProbeState) -> ProbeState:
        final_state = reconcile(
            [
                StateParam(state.state, self._hal, self._converter),
                UnitsParam(state.units, self._hal, self._converter),
                BandwidthLimitParam(state.bandwidth_limit, self._hal, self._converter),
                CouplingParam(state.coupling, self._hal, self._converter),
                AttenuationParam(state.attenuation, self._hal, self._converter),
                ScaleParam(state.scale, self._hal, self._converter),
                OffsetParam(state.offset, self._hal, self._converter),
            ],
            lambda values: ProbeState(**values),
        )

        return final_state

    def configure_probe_old(self, state: ProbeState) -> ProbeState:
        initial_state = self._hal.get_probe_display()
        initial_units = self._hal.get_probe_units()
        initial_bandwidth_state, initial_bandwidth_limit = (
            self._hal.get_probe_bandwidth_limit()
        )
        initial_coupling = self._hal.get_probe_coupling()
        initial_attenuation = self._hal.get_probe_attenuation()
        initial_scale = self._hal.get_probe_scale()
        initial_offset = self._hal.get_probe_offset()

        if not compare_param(state.state, initial_state, self._converter.state_to_hal):
            self._hal.set_probe_display(self._converter.state_to_hal(state.state))
        # if self._converter.state_from_hal(initial_state) != state.state:
        #     self._hal.set_probe_display(self._converter.state_to_hal(state.state))
        if self._converter.units_from_hal(initial_units) != state.units:
            self._hal.set_probe_units(self._converter.units_to_hal(state.units))
        if (
            self._converter.bandwidth_limit_from_hal(
                initial_bandwidth_state, initial_bandwidth_limit
            )
            != state.bandwidth_limit
        ):
            converted_bandwidth_limit = self._converter.bandwidth_limit_to_hal(
                state.bandwidth_limit
            )
            self._hal.set_probe_bandwidth_limit(
                converted_bandwidth_limit[0], converted_bandwidth_limit[1]
            )
        if self._converter.coupling_from_hal(initial_coupling) != state.coupling:
            self._hal.set_probe_coupling(
                self._converter.coupling_to_hal(state.coupling)
            )
        if (
            self._converter.attenuation_from_hal(initial_attenuation.attenuation)
            != state.attenuation
        ):
            self._hal.set_probe_attenuation(
                self._converter.attenuation_to_hal(state.attenuation)
            )
        if self._converter.scale_from_hal(initial_scale) != state.scale:
            self._hal.set_probe_scale(self._converter.scale_to_hal(state.scale))
        if self._converter.offset_from_hal(initial_offset) != state.offset:
            self._hal.set_probe_offset(self._converter.offset_to_hal(state.offset))

        final_state = self._hal.get_probe_display()
        final_units = self._hal.get_probe_units()
        final_bandwidth_state, initial_bandwidth_limit = (
            self._hal.get_probe_bandwidth_limit()
        )
        final_coupling = self._hal.get_probe_coupling()
        final_attenuation = self._hal.get_probe_attenuation()
        final_scale = self._hal.get_probe_scale()
        final_offset = self._hal.get_probe_offset()

        errors: list[str] = []

        if self._converter.state_from_hal(final_state) != state.state:
            errors.append(
                f"expected state {state.state}, got {self._converter.state_from_hal(final_state)}."
            )
        if self._converter.units_from_hal(final_units) != state.units:
            errors.append(
                f"expected units {state.units}, got {self._converter.units_from_hal(final_units)}."
            )
        if (
            self._converter.bandwidth_limit_from_hal(
                final_bandwidth_state, initial_bandwidth_limit
            )
            != state.bandwidth_limit
        ):
            errors.append(
                f"expected bandwidth limit {state.bandwidth_limit}, got {self._converter.bandwidth_limit_from_hal(final_bandwidth_state, initial_bandwidth_limit)}."
            )
        if self._converter.coupling_from_hal(final_coupling) != state.coupling:
            errors.append(
                f"expected coupling {state.coupling}, got {self._converter.coupling_from_hal(final_coupling)}."
            )
        if (
            self._converter.attenuation_from_hal(final_attenuation.attenuation)
            != state.attenuation
        ):
            errors.append(
                f"expected attenuation {state.attenuation}, got {self._converter.attenuation_from_hal(final_attenuation.attenuation)}."
            )
        if self._converter.scale_from_hal(final_scale) != state.scale:
            errors.append(
                f"expected scale {state.scale}, got {self._converter.scale_from_hal(final_scale)}."
            )
        if self._converter.offset_from_hal(final_offset) != state.offset:
            errors.append(
                f"expected offset {state.offset}, got {self._converter.offset_from_hal(final_offset)}."
            )

        if len(errors) > 0:
            raise ValueError(
                "Probe configuration did not match expected values:\n"
                + "\n".join(errors)
            )

        return ProbeState(
            attenuation=self._converter.attenuation_from_hal(
                final_attenuation.attenuation
            ),
            bandwidth_limit=self._converter.bandwidth_limit_from_hal(
                final_bandwidth_state, initial_bandwidth_limit
            ),
            coupling=self._converter.coupling_from_hal(final_coupling),
            offset=self._converter.offset_from_hal(final_offset),
            scale=self._converter.scale_from_hal(final_scale),
            state=self._converter.state_from_hal(final_state),
            units=self._converter.units_from_hal(final_units),
        )


# class FusawareParameter(Protocol):
#     def get(self) -> None: ...
#     def set(self) -> None: ...
#     def compare(self) -> None: ...
#     def error(self) -> str: ...


class Empty: ...


@dataclass
class Invalid:
    error: MappingExceptionBase


@dataclass
class Valid[T]:
    inner: T


type ParameterValue[T] = Empty | Invalid | Valid[T]


class FusawareParameter[T]:
    def __init__(
        self,
        name: str,
        desired: T,
        getter: Callable[[], T],
        setter: Callable[[T], None],
        comparator: Callable[[T, T], bool],
    ) -> None:
        self.name = name
        self.desired = desired
        self.initial: ParameterValue[T] = Empty()
        self.final: ParameterValue[T] = Empty()
        self.getter = getter
        self.setter = setter
        self.comparator = comparator
        self.has_written = False

    def get(self) -> None:
        if self.has_written:
            match self.final:
                case Empty():
                    try:
                        self.final = Valid(inner=self.getter())
                    except MappingExceptionBase as e:
                        self.final = Invalid(error=e)
                case _:
                    raise RuntimeError(
                        f"Final value for parameter '{self.name}' already read"
                    )
        else:
            match self.final:
                case Empty():
                    try:
                        self.initial = Valid(inner=self.getter())
                    except MappingExceptionBase as e:
                        self.initial = Invalid(error=e)
                case _:
                    raise RuntimeError(
                        f"Final value for parameter '{self.name}' already read"
                    )

    def set(self) -> None:
        if self.has_written:
            raise RuntimeError(f"Parameter '{self.name}' already written")

        match self.initial:
            case Empty():
                raise RuntimeError(
                    f"Cannot write parameter '{self.name}' before reading initial value"
                )
            case Invalid():
                self._set()
            case Valid(inner):
                if not self.comparator(self.desired, inner):
                    self._set()

    def error(self) -> str | None:
        match self.final:
            case Empty():
                raise RuntimeError(
                    f"Cannot generate error for parameter '{self.name}' before final value is read"
                )
            case Invalid(error):
                return str(error)
            case Valid(inner):
                if not self.comparator(self.desired, inner):
                    return f"Failed to reconcile parameter '{self.name}': expected '{self.desired}', got '{inner}'"

    def _set(self) -> None:
        self.setter(self.desired)
        self.has_written = True
