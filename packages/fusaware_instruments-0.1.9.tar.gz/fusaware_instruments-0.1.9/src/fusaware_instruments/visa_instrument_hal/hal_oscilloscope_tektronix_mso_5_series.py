# pyright: strict

import logging
import struct
import time
import traceback

from fusaware_instruments.utils import (
    MappingDirection,
    MappingException,
    ReconcileException,
    ScpiParseError,
    VisaIO,
    compare_floats,
)
from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series import (
    MAX_ANALOG_SAMPLE_RATE,
    NUM_HORIZONTAL_DIVISIONS,
    DEFAULT_OFFSET_PERCENTAGE,
    AnalogChannel,
    ChannelDisplayState,
    DelayModeState,
    HorizontalModeManualConfigure,
    HorizontalMode,
    ProbeType,
    TektronixMso5SeriesDriver,
    DisplayViewstyle,
    TriggerSource,
)
import fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series as driver
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    FixedAttenuation,
    HALOscilloscope,
    Units,
    ProbeCoupling,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerState,
    TriggerSweep,
    ImageFormat,
    Preamble,
    UnknownProbe,
    WaveformEncoding,
    ProbeAttenuation,
    Attenuation,
    ProbeId,
    AcquisitionCondition,
    AcquisitionState,
    AcquisitionInfo,
)


class Mso5Probe(ProbeId):
    def __init__(self, name: str) -> None:
        self._name = name

    def name(self) -> str:
        return self._name


class Conversions:
    @staticmethod
    def units_from_driver(units: driver.ProbeUnits) -> Units:
        match units:
            case driver.ProbeUnits.VOLTS:
                return Units.VOLTS
            case driver.ProbeUnits.AMPS:
                return Units.AMPS
            case driver.ProbeUnits.WATTS:
                return Units.WATTS


# Default directory on the instrument's internal Windows drive for ephemeral
# files the HAL writes and reads back (screenshots, etc.). C:/ exists on a
# stock TekScope image and is writable without requiring a USB flash drive in
# the E: port. Override via the ``screenshot_scope_dir`` constructor argument
# if your TekScope image differs or policy requires a different location.
DEFAULT_SCOPE_SCRATCH_DIR = "C:/"


class HALOscilloscopeProbeTektronixMso5Series(HALOscilloscope):
    def __init__(
        self,
        io: VisaIO,
        channel_number: int,
        screenshot_scope_dir: str = DEFAULT_SCOPE_SCRATCH_DIR,
        sync_time: float = 0.1,
    ):
        self._io = io
        self._channel = AnalogChannel(channel_number)
        self._driver = TektronixMso5SeriesDriver(io)
        self._screenshot_scope_dir = screenshot_scope_dir.rstrip("/")
        # MSO5 has no SAVe:IMAGe:FILEFormat SCPI command — the format is chosen
        # by the file extension when saving. Track the format in Python state so
        # the HAL API still has a get/set/apply triple that behaves consistently.
        self._image_format: ImageFormat = ImageFormat.PNG
        self._sync_time = sync_time

        # All of this can interfere with expected device behavior
        self._driver.write_horizontal_delay_mode(DelayModeState.OFF)
        self._driver.write_display_waveview_viewstyle(DisplayViewstyle.OVERLAY)
        self._driver.write_header(False)
        self._driver.write_verbose(False)

    def connect(self):
        pass

    def disconnect(self):
        pass

    def get_probe_attenuation(self) -> ProbeAttenuation:
        """
        Reads the effective probe gain and returns it as a ``FixedAttenuation``.

        On MSO5 the attenuation is a property of the connected probe hardware
        (``CH<x>:PRObe:GAIN`` is query-only over SCPI), so it's always reported
        as fixed. Probes that expose user-settable attenuation via the
        ``CH<x>:PRObe:SET "ATTENUATION ..."`` command are not auto-detected
        here; callers that want to reconfigure such probes must call the
        driver's :py:meth:`write_channel_probe_set` directly.
        """
        gain = self._driver.query_channel_probe_gain(self._channel)
        return FixedAttenuation(attenuation=1 / gain)

    def set_probe_attenuation(self, attenuation: float | int) -> None:
        """
        No-op on MSO5 — ``CH<x>:PRObe:GAIN`` is query-only.

        Logs at INFO level so callers can see the requested attenuation was
        ignored. The subsequent reconcile read will raise
        :py:class:`ReconcileException` if the probe's fixed attenuation does
        not match.
        """
        logging.info(
            "MSO5 series does not support setting probe attenuation via "
            "CH<x>:PRObe:GAIN; attenuation is determined by the connected "
            "probe. Requested value %s will not be applied.",
            attenuation,
        )

    def apply_probe_attenuation(self, attenuation: float | int) -> ProbeAttenuation:
        self.set_probe_attenuation(attenuation)
        actual = self.get_probe_attenuation()

        match actual:
            case FixedAttenuation():
                if not compare_floats(actual.attenuation, attenuation):
                    raise ReconcileException(
                        param_name="attenuation",
                        expected=attenuation,
                        actual=actual,
                        message=(
                            f"Probe attenuation on MSO5 is fixed by the "
                            f"connected probe hardware. Expected attenuation "
                            f"{attenuation}, but the probe reports "
                            f"{actual.attenuation}."
                        ),
                    )
            case Attenuation():
                if not compare_floats(actual.attenuation, attenuation):
                    raise ReconcileException(
                        param_name="attenuation",
                        expected=attenuation,
                        actual=actual,
                    )

        return actual

    def get_probe_bandwidth_limit(self) -> tuple[bool, float | int]:
        bandwidth_limit = self._driver.query_channel_bandwidth(self._channel)

        match bandwidth_limit:
            case "FULL":
                return False, 0
            case float() | int():
                return True, bandwidth_limit

    def set_probe_bandwidth_limit(
        self, enable: bool, bandwidth_limit: float | int
    ) -> None:
        if enable:
            self._driver.write_channel_bandwidth(self._channel, bandwidth_limit)
        else:
            self._driver.write_channel_bandwidth(self._channel, "FULL")

    def apply_probe_bandwidth_limit(
        self, enable: bool, bandwidth_limit: float | int
    ) -> tuple[bool, float | int]:
        self.set_probe_bandwidth_limit(enable, bandwidth_limit)
        actual_enable, actual_bandwidth_limit = self.get_probe_bandwidth_limit()

        if actual_enable != enable:
            raise ReconcileException(
                param_name="bandwidth_limit_enable",
                expected=enable,
                actual=actual_enable,
            )

        if enable and not compare_floats(actual_bandwidth_limit, bandwidth_limit):
            raise ReconcileException(
                param_name="bandwidth_limit",
                expected=bandwidth_limit,
                actual=actual_bandwidth_limit,
            )

        return actual_enable, actual_bandwidth_limit

    def get_probe_coupling(self) -> ProbeCoupling:
        match self._driver.query_channel_coupling(self._channel):
            case driver.ProbeCoupling.DC:
                return ProbeCoupling.DC
            case driver.ProbeCoupling.AC:
                return ProbeCoupling.AC
            case driver.ProbeCoupling.DCREJ:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=ProbeCoupling,
                    to_type=driver.ProbeCoupling,
                    value=driver.ProbeCoupling.DCREJ,
                )

    def set_probe_coupling(self, coupling: ProbeCoupling) -> None:
        match coupling:
            case ProbeCoupling.DC:
                driver_coupling = driver.ProbeCoupling.DC
            case ProbeCoupling.AC:
                driver_coupling = driver.ProbeCoupling.AC
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=ProbeCoupling,
                    to_type=driver.ProbeCoupling,
                    value=coupling,
                )

        self._driver.write_channel_coupling(self._channel, driver_coupling)

    def apply_probe_coupling(self, coupling: ProbeCoupling) -> ProbeCoupling:
        self.set_probe_coupling(coupling)
        actual = self.get_probe_coupling()

        if actual != coupling:
            raise ReconcileException(
                param_name="coupling", expected=coupling, actual=actual
            )

        return actual

    def get_probe_display(self) -> bool:
        match self._driver.query_channel_display_state(self._channel):
            case ChannelDisplayState.ON:
                return True
            case ChannelDisplayState.OFF:
                return False

    def set_probe_display(self, display: bool) -> None:
        self._driver.write_channel_display_state(
            self._channel,
            ChannelDisplayState.ON if display else ChannelDisplayState.OFF,
        )

    def apply_probe_display(self, display: bool) -> bool:
        self.set_probe_display(display)
        actual = self.get_probe_display()

        if actual != display:
            raise ReconcileException(
                param_name="display_state", expected=display, actual=actual
            )

        return actual

    def get_probe_offset(self) -> float | int:
        scale = self.get_probe_scale()
        return self._driver.query_channel_position(self._channel) * scale

    def set_probe_offset(self, offset: float | int) -> None:
        offset_divisions = offset / self.get_probe_scale()
        self._driver.write_channel_position(self._channel, offset_divisions)

    def apply_probe_offset(self, offset: float | int) -> float | int:
        self.set_probe_offset(offset)
        actual = self.get_probe_offset()

        if not compare_floats(actual, offset):
            raise ReconcileException(
                param_name="offset", expected=offset, actual=actual
            )

        return actual

    def get_probe_scale(self) -> float | int:
        return self._driver.query_channel_scale(self._channel)

    def set_probe_scale(self, scale: float | int) -> None:
        self._driver.write_channel_scale(self._channel, scale)

    def apply_probe_scale(self, scale: float | int) -> float | int:
        self.set_probe_scale(scale)
        actual = self.get_probe_scale()

        if not compare_floats(actual, scale):
            raise ReconcileException(param_name="scale", expected=scale, actual=actual)

        return actual

    def get_probe_units(self) -> Units:
        """
        Units are reported by the probe hardware via CH<x>:PRObe:UNIts? (read-only).
        """
        return Conversions.units_from_driver(
            self._driver.query_channel_probe_units(self._channel)
        )

    def set_probe_units(self, units: Units) -> None:
        logging.info(
            "MSO5 series does not support setting probe units via SCPI. "
            "Units are determined by the connected probe hardware."
        )

    def apply_probe_units(self, units: Units) -> Units:
        return self.get_probe_units()

    def get_timebase_offset(self) -> float | int:
        offset_percentage = self._driver.query_horizontal_position()
        return self._timebase_offset_from_percentage(
            offset_percentage, self.get_timebase_scale()
        )

    def set_timebase_offset(self, offset: float | int) -> None:
        self._driver.write_horizontal_position(
            self._timebase_offset_to_percentage(offset, self.get_timebase_scale())
        )

    def apply_timebase_offset(self, offset: float | int) -> float | int:
        self.set_timebase_offset(offset)
        actual = self.get_timebase_offset()

        if not compare_floats(actual, offset):
            raise ReconcileException(
                param_name="timebase_offset", expected=offset, actual=actual
            )

        return actual

    def _timebase_offset_to_percentage(self, offset: float, scale: float) -> float:
        if compare_floats(offset, 0.0):
            return DEFAULT_OFFSET_PERCENTAGE

        relative_offset_percentage = (offset / (scale * NUM_HORIZONTAL_DIVISIONS)) * 100

        return DEFAULT_OFFSET_PERCENTAGE - relative_offset_percentage

    def _timebase_offset_from_percentage(
        self, offset_percentage: float, scale: float
    ) -> float:
        relative_offset_percentage = offset_percentage - DEFAULT_OFFSET_PERCENTAGE

        if compare_floats(relative_offset_percentage, 0.0):
            return 0.0

        return -relative_offset_percentage / 100 * (scale * NUM_HORIZONTAL_DIVISIONS)

    def get_timebase_scale(self) -> float | int:
        return self._driver.query_horizontal_mode_scale()

    def set_timebase_scale(self, scale: float | int) -> None:
        self._driver.write_horizontal_mode_scale(scale)

    def apply_timebase_scale(self, scale: float | int) -> float | int:
        self.set_timebase_scale(scale)
        actual = self.get_timebase_scale()

        if not compare_floats(actual, scale):
            raise ReconcileException(
                param_name="timebase_scale", expected=scale, actual=actual
            )

        return actual

    def get_trigger_coupling(self) -> TriggerCoupling:
        resp = self._driver.query_trigger_edge_coupling()

        match resp:
            case driver.TriggerCoupling.DC:
                return TriggerCoupling.DC
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=TriggerCoupling,
                    to_type=driver.TriggerCoupling,
                    value=resp,
                )

    def set_trigger_coupling(self, coupling: TriggerCoupling) -> None:
        match coupling:
            case TriggerCoupling.DC:
                driver_coupling = driver.TriggerCoupling.DC
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=TriggerCoupling,
                    to_type=driver.TriggerCoupling,
                    value=coupling,
                )

        self._driver.write_trigger_edge_coupling(driver_coupling)

    def apply_trigger_coupling(self, coupling: TriggerCoupling) -> TriggerCoupling:
        self.set_trigger_coupling(coupling)
        actual = self.get_trigger_coupling()

        if actual != coupling:
            raise ReconcileException(
                param_name="trigger_coupling", expected=coupling, actual=actual
            )

        return actual

    def get_trigger_holdoff(self) -> float:
        return self._driver.query_trigger_holdoff_time()

    def set_trigger_holdoff(self, holdoff: float) -> None:
        self._driver.write_trigger_holdoff_time(holdoff)

    def apply_trigger_holdoff(self, holdoff: float) -> float:
        self.set_trigger_holdoff(holdoff)
        actual = self.get_trigger_holdoff()

        if not compare_floats(actual, holdoff):
            raise ReconcileException(
                param_name="trigger_holdoff", expected=holdoff, actual=actual
            )

        return actual

    def get_trigger_mode(self) -> TriggerMode:
        resp = self._driver.query_trigger_type()

        match resp:
            case driver.TriggerType.EDGE:
                return TriggerMode.EDGE
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=TriggerMode,
                    to_type=driver.TriggerType,
                    value=resp,
                )

    def set_trigger_mode(self, mode: TriggerMode) -> None:
        match mode:
            case TriggerMode.EDGE:
                driver_mode = driver.TriggerType.EDGE
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=TriggerMode,
                    to_type=driver.TriggerType,
                    value=mode,
                )

        self._driver.write_trigger_type(driver_mode)

    def apply_trigger_mode(self, mode: TriggerMode) -> TriggerMode:
        self.set_trigger_mode(mode)
        actual = self.get_trigger_mode()

        if actual != mode:
            raise ReconcileException(
                param_name="trigger_mode", expected=mode, actual=actual
            )

        return actual

    def get_trigger_slope(self) -> TriggerSlope:
        resp = self._driver.query_trigger_edge_slope()

        match resp:
            case driver.TriggerSlope.RISE:
                return TriggerSlope.RISING
            case driver.TriggerSlope.FALL:
                return TriggerSlope.FALLING
            case driver.TriggerSlope.EITHER:
                return TriggerSlope.EITHER

    def set_trigger_slope(self, slope: TriggerSlope) -> None:
        match slope:
            case TriggerSlope.RISING:
                driver_slope = driver.TriggerSlope.RISE
            case TriggerSlope.FALLING:
                driver_slope = driver.TriggerSlope.FALL
            case TriggerSlope.EITHER:
                driver_slope = driver.TriggerSlope.EITHER

        self._driver.write_trigger_edge_slope(driver_slope)

    def apply_trigger_slope(self, slope: TriggerSlope) -> TriggerSlope:
        self.set_trigger_slope(slope)
        actual = self.get_trigger_slope()

        if actual != slope:
            raise ReconcileException(
                param_name="trigger_slope", expected=slope, actual=actual
            )

        return actual

    def get_trigger_threshold(self) -> float:
        return self._driver.query_trigger_level(self._channel)

    def set_trigger_threshold(self, threshold: float) -> None:
        self._driver.write_trigger_level(self._channel, threshold)

    def apply_trigger_threshold(self, threshold: float) -> float:
        self.set_trigger_threshold(threshold)
        actual = self.get_trigger_threshold()

        if not compare_floats(actual, threshold):
            raise ReconcileException(
                param_name="trigger_threshold", expected=threshold, actual=actual
            )

        return actual

    def get_trigger_state(self) -> TriggerState: ...

    def set_trigger_state(self, state: TriggerState) -> None: ...

    def apply_trigger_state(self, state: TriggerState) -> TriggerState: ...

    def get_trigger_sweep(self) -> TriggerSweep:
        mode = self._driver.query_trigger_mode()
        acquire_mode = self._driver.query_acquire_stopafter()
        acquire_state = self._driver.query_acquire_state()

        if (
            mode == driver.TriggerMode.NORMAL
            and acquire_mode == driver.AcquisitionMode.SEQUENCE
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.SINGLE
        elif (
            mode == driver.TriggerMode.AUTO
            and acquire_mode == driver.AcquisitionMode.RUNSTOP
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.AUTO
        elif (
            mode == driver.TriggerMode.NORMAL
            and acquire_mode == driver.AcquisitionMode.RUNSTOP
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.NORMAL
        else:
            raise MappingException(
                direction=MappingDirection.DriverToHal,
                from_type=tuple[
                    driver.TriggerMode, driver.AcquisitionMode, driver.AcquisitionState
                ],
                to_type=TriggerSweep,
                value=(mode, acquire_mode, acquire_state),
            )

    def set_trigger_sweep(self, sweep: TriggerSweep) -> None:
        match sweep:
            case TriggerSweep.SINGLE:
                self._driver.write_trigger_mode(driver.TriggerMode.NORMAL)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.SEQUENCE)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case TriggerSweep.AUTO:
                self._driver.write_trigger_mode(driver.TriggerMode.AUTO)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.RUNSTOP)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case TriggerSweep.NORMAL:
                self._driver.write_trigger_mode(driver.TriggerMode.NORMAL)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.RUNSTOP)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)

    def apply_trigger_sweep(self, sweep: TriggerSweep) -> TriggerSweep:
        self.set_trigger_sweep(sweep)
        actual = self.get_trigger_sweep()

        if actual != sweep:
            raise ReconcileException(
                param_name="trigger_sweep", expected=sweep, actual=actual
            )

        return actual

    def get_sample_rate(self) -> float:
        return self._driver.query_horizontal_sample_rate()

    def set_sample_rate(self, sample_rate: float) -> None:
        """
        Sets the horizontal sample rate.

        MSO5 exposes a settable ``HORizontal:MODE:SAMPLERate`` (unlike MDO3
        where the equivalent query is read-only), but record length and sample
        rate are only directly settable while the instrument is in Manual
        horizontal mode. This method switches to MANUAL before writing so the
        command actually takes effect; it does not restore the prior mode
        afterwards, because most callers of ``set_sample_rate`` are doing
        deterministic capture configuration and want manual mode to persist.

        Writing sample rate on MSO5 also implicitly moves one of horizontal
        scale or record length (see programming guide 2-351). Our configuration
        layer treats timebase and acquisition as independent concerns — see
        ``configure_oscope_timebase`` and ``configure_oscope_acquisition`` —
        so we pin ``HORizontal:MODe:MANual:CONFIGure`` to ``RECORDLength``
        here, which keeps the user-selected horizontal scale stable. Record
        length is subsequently reconciled by :py:meth:`apply_sample_count`.
        """
        if sample_rate > MAX_ANALOG_SAMPLE_RATE:
            raise ValueError(
                f"Sample rate {sample_rate} exceeds maximum sample rate {MAX_ANALOG_SAMPLE_RATE}"
            )

        if self._driver.query_horizontal_mode() != HorizontalMode.MANUAL:
            self._driver.write_horizontal_mode(HorizontalMode.MANUAL)

        if (
            self._driver.query_horizontal_manual_configure()
            != HorizontalModeManualConfigure.RECORD_LENGTH
        ):
            self._driver.write_horizontal_manual_configure(
                HorizontalModeManualConfigure.RECORD_LENGTH
            )

        self._driver.write_horizontal_sample_rate(sample_rate)

    def apply_sample_rate(self, sample_rate: float) -> float:
        self.set_sample_rate(sample_rate)
        actual = self.get_sample_rate()

        if not compare_floats(actual, sample_rate):
            raise ReconcileException(
                param_name="sample_rate",
                expected=sample_rate,
                actual=actual,
            )

        return actual

    def get_sample_count(self) -> float:
        return self._driver.query_horizontal_record_length()

    def set_sample_count(self, sample_count: float) -> None:
        """
        Sets the acquisition record length.

        Record length is read-only in Auto horizontal mode, so this switches
        the instrument into Manual mode first. Note that on MSO5 changing
        record length also re-derives horizontal scale, so set this *after*
        calling :py:meth:`set_timebase_scale` / :py:meth:`set_sample_rate` if
        you want a specific combination.
        """
        if self._driver.query_horizontal_mode() != HorizontalMode.MANUAL:
            self._driver.write_horizontal_mode(HorizontalMode.MANUAL)

        self._driver.write_horizontal_record_length(int(sample_count))

    def apply_sample_count(self, sample_count: float) -> float:
        self.set_sample_count(sample_count)
        result = self.get_sample_count()

        if result != sample_count:
            raise ReconcileException(
                param_name="sample_count",
                expected=sample_count,
                actual=result,
            )

        return result

    def get_image_format(self) -> ImageFormat:
        """
        Returns the image format the HAL will use for the next screenshot.

        This value is Python-side state, not queried from the instrument,
        because MSO5 has no ``SAVe:IMAGe:FILEFormat`` SCPI command (format is
        chosen by the file-extension on each ``SAVe:IMAGe`` call).
        """
        return self._image_format

    def set_image_format(self, image_format: ImageFormat) -> None:
        """
        Sets the image format the HAL will use for the next screenshot.

        Stored in Python state only; see :py:meth:`get_image_format`.
        """
        self._image_format = image_format

    def apply_image_format(self, image_format: ImageFormat) -> ImageFormat:
        self.set_image_format(image_format)
        return self.get_image_format()

    def _image_format_extension(self, image_format: ImageFormat) -> str:
        match image_format:
            case ImageFormat.PNG:
                return "png"
            case ImageFormat.BMP:
                return "bmp"
            case ImageFormat.JPG:
                return "jpg"

    def get_screenshot(self) -> bytes:
        """
        Captures a screenshot by saving to a temporary file on the instrument's
        internal drive, reading it back over SCPI, then deleting it.

        The MSO5 series has no ``HARDCopy`` group (unlike MDO3); the closest
        equivalent is ``SAVe:IMAGe "<path>"`` which writes to the instrument's
        local Windows filesystem. The HAL defaults to ``C:/`` so a USB
        flash drive is not required; pass ``screenshot_scope_dir`` to the
        constructor if your TekScope image uses a different writable location.
        """
        extension = self._image_format_extension(self._image_format)
        screenshot_path = (
            f"{self._screenshot_scope_dir}/fusaware-{int(time.time_ns())}.{extension}"
        )
        self._driver.write_save_image(screenshot_path)
        try:
            self._driver.query_opc()
            self._driver.write_file_read(screenshot_path)
            data = self._driver.io.read_raw()
        finally:
            try:
                self._driver.write_file_delete(screenshot_path)
            except Exception as e:
                logging.warning(
                    f"Failed to delete scope scratch file '{screenshot_path}': {e}"
                )

        return data

    def get_waveform_preamble(self) -> Preamble:
        encoding_driver = self._driver.query_waveform_encoding()
        num_points = self._driver.query_waveform_nr_points()
        x_increment = self._driver.query_waveform_x_increment()
        x_unit = self._driver.query_waveform_x_unit()
        x_zero = self._driver.query_waveform_x_zero()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_unit_driver = self._driver.query_waveform_y_unit()
        y_zero = self._driver.query_waveform_y_zero()

        match encoding_driver:
            case driver.WaveformEncoding.ASCII:
                encoding = WaveformEncoding.CSV
            case driver.WaveformEncoding.BINARY:
                encoding = WaveformEncoding.BINARY

        return Preamble(
            source=self._get_waveform_source().value,
            format=encoding,
            count=num_points,
            x_increment=x_increment,
            x_origin=x_zero,
            x_reference=0,
            x_zero=x_zero,
            x_units=x_unit,
            y_increment=y_multiplier,
            y_origin=y_zero,
            y_reference=0,
            y_zero=y_zero,
            y_units=Conversions.units_from_driver(y_unit_driver),
        )

    def _get_waveform_source(self) -> AnalogChannel:
        source_channel = self._driver.query_data_source()

        match source_channel:
            case driver.WaveformSource.CH1:
                return AnalogChannel.CH1
            case driver.WaveformSource.CH2:
                return AnalogChannel.CH2
            case driver.WaveformSource.CH3:
                return AnalogChannel.CH3
            case driver.WaveformSource.CH4:
                return AnalogChannel.CH4
            case driver.WaveformSource.CH5:
                return AnalogChannel.CH5
            case driver.WaveformSource.CH6:
                return AnalogChannel.CH6
            case driver.WaveformSource.CH7:
                return AnalogChannel.CH7
            case driver.WaveformSource.CH8:
                return AnalogChannel.CH8
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=driver.WaveformSource,
                    to_type=int,
                    value=source_channel,
                )

    def _set_waveform_source(self, channel: AnalogChannel) -> None:
        match channel:
            case AnalogChannel.CH1:
                driver_channel = driver.WaveformSource.CH1
            case AnalogChannel.CH2:
                driver_channel = driver.WaveformSource.CH2
            case AnalogChannel.CH3:
                driver_channel = driver.WaveformSource.CH3
            case AnalogChannel.CH4:
                driver_channel = driver.WaveformSource.CH4
            case AnalogChannel.CH5:
                driver_channel = driver.WaveformSource.CH5
            case AnalogChannel.CH6:
                driver_channel = driver.WaveformSource.CH6
            case AnalogChannel.CH7:
                driver_channel = driver.WaveformSource.CH7
            case AnalogChannel.CH8:
                driver_channel = driver.WaveformSource.CH8

        self._driver.write_data_source(driver_channel)

    def apply_waveform_source(self) -> None:
        self._set_waveform_source(self._channel)
        actual = self._get_waveform_source()

        if actual != self._channel:
            raise ReconcileException(
                param_name="waveform_source_channel_number",
                expected=self._channel,
                actual=actual,
            )

    def get_waveform_start_index(self) -> int:
        return self._driver.query_data_start()

    def set_waveform_start_index(self, start_index: int) -> None:
        self._driver.write_data_start(start_index)

    def apply_waveform_start_index(self, start_index: int) -> int:
        self.set_waveform_start_index(start_index)
        actual = self.get_waveform_start_index()

        if actual != start_index:
            raise ReconcileException(
                param_name="waveform_start_index", expected=start_index, actual=actual
            )

        return actual

    def get_waveform_stop_index(self) -> int:
        return self._driver.query_data_stop()

    def set_waveform_stop_index(self, stop_index: int) -> None:
        self._driver.write_data_stop(stop_index)

    def apply_waveform_stop_index(self, stop_index: int) -> int:
        self.set_waveform_stop_index(stop_index)
        actual = self.get_waveform_stop_index()

        if actual != stop_index:
            raise ReconcileException(
                param_name="waveform_stop_index", expected=stop_index, actual=actual
            )

        return actual

    def get_waveform_encoding(self) -> WaveformEncoding:
        match self._driver.query_waveform_encoding():
            case driver.WaveformEncoding.ASCII:
                return WaveformEncoding.CSV
            case driver.WaveformEncoding.BINARY:
                return WaveformEncoding.BINARY

    def set_waveform_encoding(self, encoding: WaveformEncoding) -> None:
        match encoding:
            case WaveformEncoding.CSV:
                self._driver.write_waveform_encoding(driver.WaveformEncoding.ASCII)
            case WaveformEncoding.BINARY:
                self._driver.write_data_encoding(driver.DataEncoding.RIBINARY)
            case WaveformEncoding.OTHER:
                raise ValueError("'WaveformEncoding.OTHER' should not be passed here")

    def apply_waveform_encoding(self, encoding: WaveformEncoding) -> WaveformEncoding:
        self.set_waveform_encoding(encoding)
        actual = self.get_waveform_encoding()

        if actual != encoding:
            raise ReconcileException(
                param_name="waveform_encoding", expected=encoding, actual=actual
            )

        return actual

    def get_waveform_data(self) -> list[float]:
        match self.get_waveform_encoding():
            case WaveformEncoding.CSV:
                return self._get_waveform_data_ascii()
            case WaveformEncoding.BINARY:
                return self._get_waveform_data_binary()
            case WaveformEncoding.OTHER:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=driver.WaveformEncoding,
                    to_type=WaveformEncoding,
                    value=WaveformEncoding.OTHER,
                )

    def _get_waveform_data_ascii(self) -> list[float]:
        data_raw = self._driver.query_curve()
        y_offset = self._driver.query_waveform_y_offset()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_zero = self._driver.query_waveform_y_zero()

        points_raw = data_raw.split(",")

        return [
            ((int(float(point)) - y_offset) * y_multiplier) + y_zero
            for point in points_raw
            if point.strip() != ""
        ]

    def _get_waveform_data_binary(self) -> list[float]:
        byte_order = self._driver.query_waveform_byte_order()
        binary_fmt = self._driver.query_waveform_binary_format()
        bytes_per_point = self._driver.query_waveform_byte_nr()
        num_points = self._driver.query_waveform_nr_points()
        y_offset = self._driver.query_waveform_y_offset()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_zero = self._driver.query_waveform_y_zero()

        raw_bytes = self._driver.query_curve_binary()

        endian = ">" if byte_order == driver.WaveformByteOrder.MSB else "<"

        match binary_fmt, bytes_per_point:
            case driver.BinaryFormat.RI, 1:
                fmt_char = "b"  # signed int8
            case driver.BinaryFormat.RI, 2:
                fmt_char = "h"  # signed int16
            case driver.BinaryFormat.RP, 1:
                fmt_char = "B"  # unsigned int8
            case driver.BinaryFormat.RP, 2:
                fmt_char = "H"  # unsigned int16
            case driver.BinaryFormat.FP, 4:
                fmt_char = "f"  # float32
            case _:
                raise ScpiParseError(
                    response=f"BN_FMT={binary_fmt.value}, BYT_NR={bytes_per_point}",
                    query=":WFMO:BN_F? / :WFMO:BYT_N?",
                    message=f"Unsupported binary format combination: {binary_fmt} with {bytes_per_point} bytes/point",
                )

        try:
            raw_points = struct.unpack(f"{endian}{num_points}{fmt_char}", raw_bytes)
        except Exception as e:
            traceback.print_exc()
            raise e

        return [((p - y_offset) * y_multiplier) + y_zero for p in raw_points]

    def get_probe_id(self) -> ProbeId | UnknownProbe | None:
        """
        Returns an identifier for the probe connected to this channel.

        MSO5's ``CH<x>:PRObe:ID:TYPe?`` does not document a "no probe attached"
        sentinel the way MDO3's ``"No probe detected"`` does — by default the
        scope reports a passive identifier such as ``"10X"``. We therefore
        never return ``None`` here: a string that's in the driver's
        ``ProbeType`` enum becomes an :class:`Mso5Probe`; anything else
        becomes an :class:`UnknownProbe` carrying the raw ID string so
        callers can surface it verbatim in error messages.
        """
        id = self._driver.query_channel_probe_id(self._channel)

        match id.probe_type:
            case ProbeType.UNKNOWN:
                return UnknownProbe(id.name)
            case ProbeType.NONE:
                # Inherited from MDO3 enum; not expected on MSO5 but harmless
                # to treat the same way as UNKNOWN.
                return UnknownProbe(id.name)
            case _:
                return Mso5Probe(id.name)

    def sync(self) -> bool:
        time.sleep(self._sync_time)
        return True

    def get_acquisition_state(self) -> AcquisitionState:
        acquire_mode = self._driver.query_acquire_stopafter()
        acquire_state = self._driver.query_acquire_state()

        match acquire_state, acquire_mode:
            case driver.AcquisitionState.RUN, driver.AcquisitionMode.SEQUENCE:
                return AcquisitionState.SINGLE
            case driver.AcquisitionState.RUN, driver.AcquisitionMode.RUNSTOP:
                return AcquisitionState.RUNNING
            case (driver.AcquisitionState.STOP, driver.AcquisitionMode.SEQUENCE) | (
                driver.AcquisitionState.STOP,
                driver.AcquisitionMode.RUNSTOP,
            ):
                return AcquisitionState.STOPPED

    def set_acquisition_state(self, state: AcquisitionState) -> None:
        match state:
            case AcquisitionState.RUNNING:
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.RUNSTOP)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case AcquisitionState.SINGLE:
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.SEQUENCE)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case AcquisitionState.STOPPED:
                self._driver.write_acquire_state(driver.AcquisitionState.STOP)

    def get_acquisition_condition(self) -> AcquisitionCondition:
        trigger_mode = self._driver.query_trigger_mode()

        match trigger_mode:
            case driver.TriggerMode.AUTO:
                return AcquisitionCondition.AUTO
            case driver.TriggerMode.NORMAL:
                return AcquisitionCondition.TRIGGER

    def set_acquisition_condition(self, condition: AcquisitionCondition) -> None:
        match condition:
            case AcquisitionCondition.TRIGGER:
                self._driver.write_trigger_mode(driver.TriggerMode.NORMAL)
            case AcquisitionCondition.AUTO:
                self._driver.write_trigger_mode(driver.TriggerMode.AUTO)
            case AcquisitionCondition.ROLLING:
                raise RuntimeError(
                    "'rolling' condition cannot be set for the Tektronix MSO series using this HAL"
                )

    def get_acquisition_info(self, min_sample_rate: float) -> AcquisitionInfo:
        sample_rate = self.get_sample_rate()
        sample_count = self.get_sample_count()

        return AcquisitionInfo(
            sample_rate=sample_rate,
            sample_count=sample_count,
            should_update=sample_rate != min_sample_rate,
        )

    def set_acquisition_info(self, min_sample_rate: float) -> None:
        self.set_sample_rate(min_sample_rate)

    def apply_trigger_source(self) -> None:
        trigger_source = TriggerSource(f"CH{self._channel.value}")
        self._driver.write_trigger_edge_source(trigger_source)
        actual = self._driver.query_trigger_edge_source()

        if actual != trigger_source:
            raise ReconcileException(
                param_name="trigger_source",
                expected=trigger_source,
                actual=actual,
            )
