import math
import time
import logging

import pyvisa
from pyvisa.resources import MessageBasedResource

from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    BKPrecision5491B,
    DCVoltageNPLC,
)
from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    DCCurrentRange as DeviceDCCurrentRange,
)
from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    DCVoltageRange as DeviceDCVoltageRange,
)
from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    MeasurementFunction as DeviceMeasurementFunction,
)
from fusaware_instruments.visa_instrument_hal.hal_dmm import (
    HALDigitalMultimeter,
    MeasurementFunction,
    MeasurementIntegrationTime,
    MeasurementRange,
)

DELAY = 0.5


class HALDmmBkPrecision5491b(HALDigitalMultimeter):
    def __init__(self, resource_name: str):
        self._resource_name = resource_name
        self._rm = None
        self._device = None

    # Note: the BK Precision 5491B is very slow to respond to commands, so we add a
    # delay after writes to avoid overwhelming it.
    def _write(self, msg: str) -> int:
        logging.debug(f"Writing message '{msg}'")
        if self._device is None:
            raise RuntimeError("Device not connected")
        n = self._device.write(msg)
        time.sleep(DELAY)
        return n

    def _query(self, msg: str) -> str:
        if self._device is None:
            raise RuntimeError("Device not connected")
        self._write(msg)
        resp = self._device.read()
        time.sleep(DELAY)
        logging.debug(f"Response '{resp}' received")
        return resp

    def connect(
        self,
        sim_file: str | None = None,
        read_termination: str | None = None,
        write_termination: str | None = None,
    ) -> None:
        if self._rm is None:
            if sim_file is not None:
                self._rm = pyvisa.ResourceManager(f"{sim_file}@sim")
            else:
                self._rm = pyvisa.ResourceManager()
        if self._device is None:
            self._device = MessageBasedResource(self._rm, self._resource_name)
            self._device.open()
            self._device.write_termination = (
                write_termination if write_termination is not None else "\n"
            )
            self._device.read_termination = (
                read_termination if read_termination is not None else "\n"
            )

    def disconnect(self) -> None:
        if self._device is not None:
            self._device.close()
            self._device = None
        if self._rm is not None:
            self._rm.close()
            self._rm = None

    @classmethod
    def _map_device_function_to_hal_function(
        cls, function: DeviceMeasurementFunction
    ) -> MeasurementFunction:
        # do the mapping
        match function:
            case DeviceMeasurementFunction.VOLTAGE_DC:
                return MeasurementFunction.DCVoltage
            case DeviceMeasurementFunction.CURRENT_DC:
                return MeasurementFunction.DCCurrent

    @classmethod
    def _map_hal_function_to_device_function(
        cls, function: MeasurementFunction
    ) -> DeviceMeasurementFunction:
        match function:
            case MeasurementFunction.DCVoltage:
                return DeviceMeasurementFunction.VOLTAGE_DC
            case MeasurementFunction.DCCurrent:
                return DeviceMeasurementFunction.CURRENT_DC

    @classmethod
    def _map_device_dc_voltage_range_to_hal_dc_voltage_range(
        cls, device_range: DeviceDCVoltageRange
    ) -> float:
        match device_range:
            case DeviceDCVoltageRange.RNG_500mV:
                return 0.5
            case DeviceDCVoltageRange.RNG_5V:
                return 5.0
            case DeviceDCVoltageRange.RNG_50V:
                return 50.0
            case DeviceDCVoltageRange.RNG_500V:
                return 500.0
            case DeviceDCVoltageRange.RNG_1000V:
                return 1000.0

    @classmethod
    def _map_hal_dc_voltage_range_to_device_dc_voltage_range(
        cls, hal_range: float
    ) -> DeviceDCVoltageRange:
        if math.isclose(hal_range, 0.5):
            return DeviceDCVoltageRange.RNG_500mV
        elif math.isclose(hal_range, 5.0):
            return DeviceDCVoltageRange.RNG_5V
        elif math.isclose(hal_range, 50.0):
            return DeviceDCVoltageRange.RNG_50V
        elif math.isclose(hal_range, 500.0):
            return DeviceDCVoltageRange.RNG_500V
        elif math.isclose(hal_range, 1000.0):
            return DeviceDCVoltageRange.RNG_1000V

        raise ValueError(f"Unexpected range: {hal_range}")

    @classmethod
    def _map_device_dc_current_range_to_hal_dc_current_range(
        cls, device_range: DeviceDCCurrentRange
    ) -> float:
        match device_range:
            case DeviceDCCurrentRange.RNG_5mA:
                return 0.005
            case DeviceDCCurrentRange.RNG_50mA:
                return 0.05
            case DeviceDCCurrentRange.RNG_500mA:
                return 0.5
            case DeviceDCCurrentRange.RNG_5A:
                return 5.0
            case DeviceDCCurrentRange.RNG_20A:
                return 20.0

    @classmethod
    def _map_hal_dc_current_range_to_device_dc_current_range(
        cls, hal_range: float
    ) -> DeviceDCCurrentRange:
        if math.isclose(hal_range, 0.005):
            return DeviceDCCurrentRange.RNG_5mA
        elif math.isclose(hal_range, 0.05):
            return DeviceDCCurrentRange.RNG_50mA
        elif math.isclose(hal_range, 0.5):
            return DeviceDCCurrentRange.RNG_500mA
        elif math.isclose(hal_range, 5.0):
            return DeviceDCCurrentRange.RNG_5A
        elif math.isclose(hal_range, 20.0):
            return DeviceDCCurrentRange.RNG_20A

        raise ValueError(f"Unexpected range: {hal_range}")

    # def get_dc_voltage_measurement(self) -> float:
    #     if self._device is None:
    #         raise RuntimeError("Device not connected")
    #
    #     msg = BKPrecision5491B.measure_voltage_dc_query()
    #     resp = self._device.query(msg)
    #     return BKPrecision5491B.measure_voltage_dc_parse(resp)

    # @classmethod
    # def _map_device_impedance_to_hal_impedance(
    #     cls, device_impedance: DeviceDCVoltageImpedance
    # ) -> int:
    #     if device_impedance == DeviceDCVoltageImpedance.I_10MOhm:
    #         return 10000000
    #     elif device_impedance == DeviceDCVoltageImpedance.I_10GOhm:
    #         return 10000000000
    #
    # @classmethod
    # def _map_hal_impedance_to_device_impedance(
    #     cls, hal_impedance: int
    # ) -> DeviceDCVoltageImpedance:
    #     if math.isclose(hal_impedance, 10000000):
    #         return DeviceDCVoltageImpedance.I_10MOhm
    #     elif math.isclose(hal_impedance, 10000000000):
    #         return DeviceDCVoltageImpedance.I_10GOhm
    #     raise ValueError(f"Unexpected impedance: {hal_impedance}")

    def get_measurement_function(self) -> MeasurementFunction:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = BKPrecision5491B.function_query()
        resp = self._query(msg)
        device_function = BKPrecision5491B.function_parse(resp)
        return self._map_device_function_to_hal_function(device_function)

    def set_measurement_function(self, function: MeasurementFunction) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = BKPrecision5491B.function_write(
            HALDmmBkPrecision5491b._map_hal_function_to_device_function(function)
        )
        self._write(msg)
        return

    def get_measurement_range(self, function: MeasurementFunction) -> MeasurementRange:
        if self._device is None:
            raise RuntimeError("Device not connected")

        match function:
            case MeasurementFunction.DCVoltage:
                auto_query_msg = BKPrecision5491B.voltage_dc_range_auto_query()
                auto_resp = self._query(auto_query_msg)
                auto_enabled = BKPrecision5491B.voltage_dc_range_auto_parse(auto_resp)
                if auto_enabled:
                    return "auto"

                upper_query_msg = BKPrecision5491B.voltage_dc_range_query()
                upper_resp = self._query(upper_query_msg)
                rnge = BKPrecision5491B.voltage_dc_range_parse(upper_resp)
                return self._map_device_dc_voltage_range_to_hal_dc_voltage_range(rnge)
            case MeasurementFunction.DCCurrent:
                auto_query_msg = BKPrecision5491B.current_dc_range_auto_query()
                auto_resp = self._query(auto_query_msg)
                auto_enabled = BKPrecision5491B.current_dc_range_auto_parse(auto_resp)
                if auto_enabled:
                    return "auto"

                upper_query_msg = BKPrecision5491B.current_dc_range_query()
                upper_resp = self._query(upper_query_msg)
                rnge = BKPrecision5491B.current_dc_range_parse(upper_resp)
                return self._map_device_dc_current_range_to_hal_dc_current_range(rnge)

    def set_measurement_range(
        self, function: MeasurementFunction, measurement_range: MeasurementRange
    ) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        if measurement_range == "auto":
            match function:
                case MeasurementFunction.DCVoltage:
                    msg = BKPrecision5491B.voltage_dc_range_auto_write(True)
                    self._write(msg)
                case MeasurementFunction.DCCurrent:
                    msg = BKPrecision5491B.current_dc_range_auto_write(True)
                    self._write(msg)
            return

        match function:
            case MeasurementFunction.DCVoltage:
                device_voltage_range = (
                    self._map_hal_dc_voltage_range_to_device_dc_voltage_range(
                        measurement_range
                    )
                )
                msg = BKPrecision5491B.voltage_dc_range_write(device_voltage_range)
            case MeasurementFunction.DCCurrent:
                device_current_range = (
                    self._map_hal_dc_current_range_to_device_dc_current_range(
                        measurement_range
                    )
                )
                msg = BKPrecision5491B.current_dc_range_write(device_current_range)

        self._write(msg)

    def get_measurement_integration_time(
        self, function: MeasurementFunction
    ) -> MeasurementIntegrationTime:
        if self._device is None:
            raise RuntimeError("Device not connected")

        match function:
            case MeasurementFunction.DCVoltage:
                query = BKPrecision5491B.voltage_dc_nplc_query()
                response = self._query(query)
                nplcs = BKPrecision5491B.voltage_dc_nplc_parse(response)
            case MeasurementFunction.DCCurrent:
                query = BKPrecision5491B.current_dc_nplc_query()
                response = self._query(query)
                nplcs = BKPrecision5491B.current_dc_nplc_parse(response)

        match nplcs:
            case DCVoltageNPLC.NPLC_0p1:
                return 0.1
            case DCVoltageNPLC.NPLC_1:
                return 1.0
            case DCVoltageNPLC.NPLC_10:
                return 10.0

    def set_measurement_integration_time(
        self, function: MeasurementFunction, integration: MeasurementIntegrationTime
    ) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        match integration:
            case float() | int():
                if math.isclose(integration, 0.1):
                    driver_nplcs = DCVoltageNPLC.NPLC_0p1
                elif math.isclose(integration, 1.0):
                    driver_nplcs = DCVoltageNPLC.NPLC_1
                elif math.isclose(integration, 10.0):
                    driver_nplcs = DCVoltageNPLC.NPLC_10
                else:
                    raise ValueError(
                        f"Integration time {integration} not valid for BK Precision 5491B"
                    )
            case "auto":
                driver_nplcs = DCVoltageNPLC.NPLC_10

        match function:
            case MeasurementFunction.DCVoltage:
                msg = BKPrecision5491B.voltage_dc_nplc_write(driver_nplcs)
            case MeasurementFunction.DCCurrent:
                msg = BKPrecision5491B.current_dc_nplc_write(driver_nplcs)

        self._write(msg)

    def get_measurement_input_impedance(self) -> int:
        ...
        # if self._device is None:
        #     raise RuntimeError("Device not connected")
        #
        # msg = BKPrecision5491B.measure_voltage_dc_impedance_query()
        # resp = self._device.query(msg)
        # device_impedance = BKPrecision5491B.measure_voltage_dc_impedance_parse(resp)
        # return self._map_device_impedance_to_hal_impedance(device_impedance)

    def set_measurement_input_impedance(self, impedance: int) -> None:
        ...
        # if self._device is None:
        #     raise RuntimeError("Device not connected")
        #
        # device_impedance = self._map_hal_impedance_to_device_impedance(impedance)
        # msg = BKPrecision5491B.measure_voltage_dc_impedance_write(device_impedance)
        # self._device.write(msg)
        # return

    def get_measurement(self) -> float:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = BKPrecision5491B.fetch_query()
        resp = self._device.query(msg)
        return BKPrecision5491B.fetch_parse(resp)
