import math
from typing import Tuple

from fusaware_instruments.visa_instrument_drivers.driver_rigol_mso_base import (
    Attenuation as DriverAttenuation,
    BandwidthLimit as DriverBandwidthLimit,
    Channel as DriverChannel,
    Coupling as DriverCoupling,
    DisplayEnable as DriverDisplayEnable,
    Units as DriverUnits,
    RigolMSOBase,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    Attenuation,
    HALOscilloscope,
    ProbeAttenuation,
    ProbeCoupling,
    Units,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerState,
    TriggerSweep,
    ImageFormat,
    WaveformEncoding,
    Preamble,
    ProbeId,
    UnknownProbe,
    AcquisitionState,
    AcquisitionCondition,
    AcquisitionInfo,
)


def _convert_driver_attenuation_to_hal_attenuation(
    attenuation: DriverAttenuation,
) -> float | int:
    if attenuation == DriverAttenuation.ATN_100u:
        return 0.0001
    elif attenuation == DriverAttenuation.ATN_200u:
        return 0.0002
    elif attenuation == DriverAttenuation.ATN_500u:
        return 0.0005
    elif attenuation == DriverAttenuation.ATN_1m:
        return 0.001
    elif attenuation == DriverAttenuation.ATN_2m:
        return 0.002
    elif attenuation == DriverAttenuation.ATN_5m:
        return 0.005
    elif attenuation == DriverAttenuation.ATN_10m:
        return 0.01
    elif attenuation == DriverAttenuation.ATN_20m:
        return 0.02
    elif attenuation == DriverAttenuation.ATN_50m:
        return 0.05
    elif attenuation == DriverAttenuation.ATN_100m:
        return 0.1
    elif attenuation == DriverAttenuation.ATN_200m:
        return 0.2
    elif attenuation == DriverAttenuation.ATN_500m:
        return 0.5
    elif attenuation == DriverAttenuation.ATN_1:
        return 1
    elif attenuation == DriverAttenuation.ATN_2:
        return 2
    elif attenuation == DriverAttenuation.ATN_5:
        return 5
    elif attenuation == DriverAttenuation.ATN_10:
        return 10
    elif attenuation == DriverAttenuation.ATN_20:
        return 20
    elif attenuation == DriverAttenuation.ATN_50:
        return 50
    elif attenuation == DriverAttenuation.ATN_100:
        return 100
    elif attenuation == DriverAttenuation.ATN_200:
        return 200
    elif attenuation == DriverAttenuation.ATN_500:
        return 500
    elif attenuation == DriverAttenuation.ATN_1000:
        return 1000
    elif attenuation == DriverAttenuation.ATN_2000:
        return 2000
    elif attenuation == DriverAttenuation.ATN_5000:
        return 5000
    elif attenuation == DriverAttenuation.ATN_10000:
        return 10000
    elif attenuation == DriverAttenuation.ATN_20000:
        return 20000
    elif attenuation == DriverAttenuation.ATN_50000:
        return 50000
    else:
        raise ValueError(f"invalid driver attenuation: {attenuation}")


def _convert_hal_attenuation_to_driver_attenuation(
    attenuation: float | int,
) -> DriverAttenuation:
    if math.isclose(attenuation, DriverAttenuation.ATN_100u.value):
        return DriverAttenuation.ATN_100u
    elif math.isclose(attenuation, DriverAttenuation.ATN_200u.value):
        return DriverAttenuation.ATN_200u
    elif math.isclose(attenuation, DriverAttenuation.ATN_500u.value):
        return DriverAttenuation.ATN_500u
    elif math.isclose(attenuation, DriverAttenuation.ATN_1m.value):
        return DriverAttenuation.ATN_1m
    elif math.isclose(attenuation, DriverAttenuation.ATN_2m.value):
        return DriverAttenuation.ATN_2m
    elif math.isclose(attenuation, DriverAttenuation.ATN_5m.value):
        return DriverAttenuation.ATN_5m
    elif math.isclose(attenuation, DriverAttenuation.ATN_10m.value):
        return DriverAttenuation.ATN_10m
    elif math.isclose(attenuation, DriverAttenuation.ATN_20m.value):
        return DriverAttenuation.ATN_20m
    elif math.isclose(attenuation, DriverAttenuation.ATN_50m.value):
        return DriverAttenuation.ATN_50m
    elif math.isclose(attenuation, DriverAttenuation.ATN_100m.value):
        return DriverAttenuation.ATN_100m
    elif math.isclose(attenuation, DriverAttenuation.ATN_200m.value):
        return DriverAttenuation.ATN_200m
    elif math.isclose(attenuation, DriverAttenuation.ATN_500m.value):
        return DriverAttenuation.ATN_500m
    elif math.isclose(attenuation, DriverAttenuation.ATN_1.value):
        return DriverAttenuation.ATN_1
    elif math.isclose(attenuation, DriverAttenuation.ATN_2.value):
        return DriverAttenuation.ATN_2
    elif math.isclose(attenuation, DriverAttenuation.ATN_5.value):
        return DriverAttenuation.ATN_5
    elif math.isclose(attenuation, DriverAttenuation.ATN_10.value):
        return DriverAttenuation.ATN_10
    elif math.isclose(attenuation, DriverAttenuation.ATN_20.value):
        return DriverAttenuation.ATN_20
    elif math.isclose(attenuation, DriverAttenuation.ATN_50.value):
        return DriverAttenuation.ATN_50
    elif math.isclose(attenuation, DriverAttenuation.ATN_100.value):
        return DriverAttenuation.ATN_100
    elif math.isclose(attenuation, DriverAttenuation.ATN_200.value):
        return DriverAttenuation.ATN_200
    elif math.isclose(attenuation, DriverAttenuation.ATN_500.value):
        return DriverAttenuation.ATN_500
    elif math.isclose(attenuation, DriverAttenuation.ATN_1000.value):
        return DriverAttenuation.ATN_1000
    elif math.isclose(attenuation, DriverAttenuation.ATN_2000.value):
        return DriverAttenuation.ATN_2000
    elif math.isclose(attenuation, DriverAttenuation.ATN_5000.value):
        return DriverAttenuation.ATN_5000
    elif math.isclose(attenuation, DriverAttenuation.ATN_10000.value):
        return DriverAttenuation.ATN_10000
    elif math.isclose(attenuation, DriverAttenuation.ATN_20000.value):
        return DriverAttenuation.ATN_20000
    elif math.isclose(attenuation, DriverAttenuation.ATN_50000.value):
        return DriverAttenuation.ATN_50000
    else:
        raise ValueError(f"invalid hal attenuation: {attenuation}")


def _is_attenuation_equal(first: float | int, second: float | int) -> bool:
    return math.isclose(first, second, rel_tol=1e-4, abs_tol=1e-6)


def _verify_attenuation(expected: float | int, actual: float | int) -> None:
    if not _is_attenuation_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure for attenuation: expected {expected}, got {actual}"
        )


def _convert_driver_bandwidth_to_hal_bandwidth(
    bandwidth: DriverBandwidthLimit,
) -> Tuple[bool, float | int]:
    if bandwidth == DriverBandwidthLimit.BWL_OFF:
        return False, 0
    elif bandwidth == DriverBandwidthLimit.BWL_20M:
        return True, 20000000
    elif bandwidth == DriverBandwidthLimit.BWL_100M:
        return True, 100000000
    elif bandwidth == DriverBandwidthLimit.BWL_200M:
        return True, 200000000
    raise ValueError(f"invalid driver bandwidth limit: {bandwidth}")


def _convert_hal_bandwidth_to_driver_bandwidth(
    enable: bool, bandwidth: float
) -> DriverBandwidthLimit:
    if not enable:
        return DriverBandwidthLimit.BWL_OFF
    elif math.isclose(bandwidth, 20000000, rel_tol=1e-4, abs_tol=1e-6):
        return DriverBandwidthLimit.BWL_20M
    elif math.isclose(bandwidth, 100000000, rel_tol=1e-4, abs_tol=1e-6):
        return DriverBandwidthLimit.BWL_100M
    elif math.isclose(bandwidth, 200000000, rel_tol=1e-4, abs_tol=1e-6):
        return DriverBandwidthLimit.BWL_200M
    raise ValueError(f"invalid hal bandwidth limit: {bandwidth}")


def _is_bandwidth_limit_equal(
    first_enable: bool,
    first_bandwidth: float | int,
    second_enable: bool,
    second_bandwidth: float | int,
) -> bool:
    return first_enable == second_enable and math.isclose(
        first_bandwidth, second_bandwidth, rel_tol=1e-4, abs_tol=1e-6
    )


def _verify_bandwidth_limit(
    expected_enable: bool,
    expected_bandwidth: float | int,
    actual_enable: bool,
    actual_bandwidth: float | int,
) -> None:
    if not _is_bandwidth_limit_equal(
        expected_enable, expected_bandwidth, actual_enable, actual_bandwidth
    ):
        raise RuntimeError(
            f"Verification failure for bandwidth limit: expected ({expected_enable}, {expected_bandwidth}) actual ({actual_enable}, {actual_bandwidth})"
        )


def _convert_driver_coupling_to_hal_coupling(coupling: DriverCoupling) -> ProbeCoupling:
    if coupling == DriverCoupling.AC:
        return ProbeCoupling.AC
    elif coupling == DriverCoupling.DC:
        return ProbeCoupling.DC
    elif coupling == DriverCoupling.GND:
        return ProbeCoupling.GROUND
    raise ValueError(f"Invalid driver coupling {coupling}")


def _convert_hal_coupling_to_driver_coupling(coupling: ProbeCoupling) -> DriverCoupling:
    if coupling == ProbeCoupling.AC:
        return DriverCoupling.AC
    elif coupling == ProbeCoupling.DC:
        return DriverCoupling.DC
    elif coupling == ProbeCoupling.GROUND:
        return DriverCoupling.GND
    raise ValueError(f"Invalid hal coupling {coupling}")


def _is_coupling_equal(first: ProbeCoupling, second: ProbeCoupling) -> bool:
    return first == second


def _verify_coupling(expected: ProbeCoupling, actual: ProbeCoupling) -> None:
    if not _is_coupling_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure on coupling: expected ({expected}) actual ({actual})"
        )


def _convert_driver_display_enable_to_hal_display_enable(
    enable: DriverDisplayEnable,
) -> bool:
    if enable == DriverDisplayEnable.OFF:
        return False
    elif enable == DriverDisplayEnable.ON:
        return True
    else:
        raise ValueError(f"Invalid driver display enable {enable}")


def _convert_hal_display_visibility_to_driver_display_enable(
    visibility: bool,
) -> DriverDisplayEnable:
    if visibility:
        return DriverDisplayEnable.ON
    elif not visibility:
        return DriverDisplayEnable.OFF
    else:
        raise ValueError(f"Invalid hal display visibility {visibility}")


def _is_display_visibility_equal(first: bool, second: bool) -> bool:
    return first == second


def _verify_visibility(expected: bool, actual: bool) -> None:
    if not _is_display_visibility_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure: expected ({expected}) actual ({actual})"
        )


def _convert_hal_offset_to_driver_offset(offset: float | int) -> float | int:
    return offset


def _convert_driver_offset_to_hal_offset(offset: float | int) -> float | int:
    return offset


def _is_offset_equal(first: float | int, second: float | int) -> bool:
    return math.isclose(first, second, rel_tol=1e-4, abs_tol=1e-6)


def _verify_offset(expected: float, actual: float) -> None:
    if not _is_offset_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure: expected {expected} actual ({actual})"
        )


def _convert_hal_scale_to_driver_scale(scale: float | int) -> float | int:
    return scale


def _convert_driver_scale_to_driver_scale(scale: float | int) -> float | int:
    return scale


def _is_scale_equal(expected: float | int, actual: float | int) -> bool:
    return math.isclose(expected, actual, rel_tol=1e-4, abs_tol=1e-6)


def _verify_scale(expected: float | int, actual: float | int) -> None:
    if not _is_scale_equal(expected, actual):
        raise RuntimeError(f"Verification failure: expected {expected} actual {actual}")


def _convert_hal_units_to_driver_units(units: Units) -> DriverUnits:
    if units == Units.AMPS:
        return DriverUnits.AMP
    elif units == Units.VOLTS:
        return DriverUnits.VOLT
    elif units == Units.WATTS:
        return DriverUnits.WATT
    elif units == Units.CUSTOM:
        return DriverUnits.UNKN
    else:
        raise ValueError(f"Invalid channel hal units {units}")


def _convert_driver_units_to_hal_units(units: DriverUnits) -> Units:
    if units == DriverUnits.AMP:
        return Units.AMPS
    elif units == DriverUnits.VOLT:
        return Units.VOLTS
    elif units == DriverUnits.WATT:
        return Units.WATTS
    elif units == DriverUnits.UNKN:
        return Units.CUSTOM
    else:
        raise ValueError(f"Invalid channel driver units {units}")


def _is_units_equal(first: Units, second: Units) -> bool:
    return first == second


def _verify_units(expected: Units, actual: Units) -> None:
    if not _is_units_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure on units: expected {expected}, actual {actual}"
        )


def _convert_driver_timebase_offset_to_offset(offset_drv: float | int) -> float | int:
    offset = offset_drv
    return offset


def _convert_offset_to_driver_timebase_offset(offset: float | int) -> float | int:
    offset_drv = offset
    return offset_drv


def _is_timebase_offset_equal(first: float | int, second: float | int) -> bool:
    return first == second


def _verify_timebase_offset(expected: float | int, actual: float | int) -> None:
    if not _is_timebase_offset_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure on timebase offset: expected {expected} actual: {actual}"
        )


def _convert_driver_timebase_scale_to_scale(scale_drv: float | int) -> float | int:
    scale = scale_drv
    return scale


def _convert_scale_to_driver_timebase_scale(scale: float | int) -> float | int:
    scale_drv = scale
    return scale_drv


def _is_timebase_scale_equal(first: float | int, second: float | int) -> bool:
    return first == second


def _verify_timebase_scale(expected: float | int, actual: float | int) -> None:
    if not _is_timebase_offset_equal(expected, actual):
        raise RuntimeError(
            f"Verification failure on timebase offset: expected {expected} actual: {actual}"
        )


class HALOscilloscopeProbeRigolMSOBase(HALOscilloscope):
    def __init__(self, resource_name: str, channel_number: int, visa_path: str):
        if not isinstance(resource_name, str):
            raise TypeError("resource_name must be a string")

        self._resource_name = resource_name
        self._channel = DriverChannel(channel_number)

        self._device = RigolMSOBase(self._resource_name, visa_path=visa_path)
        return

    def connect(self):
        if self._device:
            self._device.open()
        return

    def disconnect(self):
        if self._device:
            self._device.close()
        return

    def get_probe_attenuation(self) -> ProbeAttenuation:
        attenuation_drv = self._device.query_channel_probe(self._channel)
        attenuation = _convert_driver_attenuation_to_hal_attenuation(attenuation_drv)
        return Attenuation(attenuation=attenuation)

    def set_probe_attenuation(self, attenuation: float | int) -> None:
        attenuation_param = _convert_hal_attenuation_to_driver_attenuation(attenuation)
        self._device.write_channel_probe(self._channel, attenuation_param)
        return

    def apply_probe_attenuation(self, attenuation: float | int) -> ProbeAttenuation:
        self.set_probe_attenuation(attenuation)
        new_attenuation = self.get_probe_attenuation()
        _verify_attenuation(attenuation, attenuation)
        return new_attenuation

    def get_probe_bandwidth_limit(self) -> Tuple[bool, float | int]:
        bandwidth_drv = self._device.query_channel_bandwidth(self._channel)
        bandwidth = _convert_driver_bandwidth_to_hal_bandwidth(bandwidth_drv)
        return bandwidth

    def set_probe_bandwidth_limit(
        self, enable: bool, bandwidth_limit: float | int
    ) -> None:
        bandwidth_drv = _convert_hal_bandwidth_to_driver_bandwidth(
            enable, bandwidth_limit
        )
        self._device.write_channel_bandwidth(self._channel, bandwidth_drv)
        return

    def apply_probe_bandwidth_limit(
        self, enable: bool, bandwidth_limit: float | int
    ) -> Tuple[bool, float | int]:
        self.set_probe_bandwidth_limit(enable, bandwidth_limit)
        new_enable, new_bandwidth = self.get_probe_bandwidth_limit()
        _verify_bandwidth_limit(enable, bandwidth_limit, new_enable, new_bandwidth)
        return new_enable, new_bandwidth

    def get_probe_coupling(self) -> ProbeCoupling:
        coupling_drv = self._device.query_channel_coupling(self._channel)
        coupling = _convert_driver_coupling_to_hal_coupling(coupling_drv)
        return coupling

    def set_probe_coupling(self, coupling: ProbeCoupling) -> None:
        coupling_drv = _convert_hal_coupling_to_driver_coupling(coupling)
        self._device.write_channel_coupling(self._channel, coupling_drv)
        return

    def apply_probe_coupling(self, coupling: ProbeCoupling) -> ProbeCoupling:
        self.set_probe_coupling(coupling)
        new_coupling = self.get_probe_coupling()
        _verify_coupling(coupling, new_coupling)
        return new_coupling

    def get_probe_display_visibility(self) -> bool:
        display_drv = self._device.query_channel_display(self._channel)
        display = _convert_driver_display_enable_to_hal_display_enable(display_drv)
        return display

    def set_probe_display_visibility(self, enable: bool) -> None:
        enable_drv = _convert_hal_display_visibility_to_driver_display_enable(enable)
        self._device.write_channel_display(self._channel, enable_drv)
        return

    def apply_probe_display_visibility(self, visible: bool) -> bool:
        self.set_probe_display_visibility(visible)
        new_visible = self.get_probe_display_visibility()
        _verify_visibility(visible, new_visible)
        return new_visible

    def get_probe_offset(self) -> float | int:
        offset = self._device.query_channel_offset(self._channel)
        return offset

    def set_probe_offset(self, offset: float | int) -> None:
        self._device.write_channel_offset(self._channel, offset)
        return

    def apply_probe_offset(self, offset: float | int) -> float | int:
        self.set_probe_offset(offset)
        new_offset = self.get_probe_offset()
        _verify_offset(offset, new_offset)
        return new_offset

    def get_probe_scale(self) -> float | int:
        scale = self._device.query_channel_scale(self._channel)
        return scale

    def set_probe_scale(self, scale: float | int) -> None:
        self._device.write_channel_scale(self._channel, scale)
        return

    def apply_probe_scale(self, scale: float | int) -> float | int:
        self.set_probe_scale(scale)
        new_scale = self.get_probe_scale()
        _verify_scale(scale, new_scale)
        return new_scale

    def get_probe_units(self) -> Units:
        units_drv = self._device.query_channel_units(self._channel)
        units = _convert_driver_units_to_hal_units(units_drv)
        return units

    def set_probe_units(self, units: Units) -> None:
        units_param = _convert_hal_units_to_driver_units(units)
        self._device.write_channel_units(self._channel, units_param)
        return

    def apply_probe_units(self, units: Units) -> Units:
        self.set_probe_units(units)
        new_units = self.get_probe_units()
        _verify_units(units, new_units)
        return new_units

    def get_timebase_offset(self) -> float | int:
        offset_drv = self._device.query_timebase_offset()
        offset = _convert_driver_timebase_offset_to_offset(offset_drv)
        return offset

    def set_timebase_offset(self, offset: float | int) -> None:
        offset_drv = _convert_offset_to_driver_timebase_offset(offset)
        self._device.write_timebase_offset(offset_drv)
        return

    def apply_timebase_offset(self, offset: float | int) -> float | int:
        self.set_timebase_offset(offset)
        new_offset = self.get_timebase_offset()
        _verify_timebase_offset(offset, new_offset)
        return new_offset

    def get_timebase_scale(self) -> float | int:
        scale_drv = self._device.query_timebase_scale()
        scale = _convert_driver_timebase_scale_to_scale(scale_drv)
        return scale

    def set_timebase_scale(self, scale: float | int) -> None:
        scale_drv = _convert_scale_to_driver_timebase_scale(scale)
        self._device.write_timebase_scale(scale_drv)
        return

    def apply_timebase_scale(self, scale: float | int) -> float | int:
        self.set_timebase_scale(scale)
        new_scale = self.get_timebase_scale()
        _verify_timebase_scale(scale, new_scale)
        return new_scale

    def get_probe_display(self) -> bool: ...

    def set_probe_display(self, display: bool) -> None: ...

    def apply_probe_display(self, display: bool) -> bool: ...

    def get_trigger_coupling(self) -> TriggerCoupling: ...

    def set_trigger_coupling(self, coupling: TriggerCoupling) -> None: ...

    def apply_trigger_coupling(self, coupling: TriggerCoupling) -> TriggerCoupling: ...

    def get_trigger_holdoff(self) -> float: ...

    def set_trigger_holdoff(self, holdoff: float) -> None: ...

    def apply_trigger_holdoff(self, holdoff: float) -> float: ...

    def get_trigger_mode(self) -> TriggerMode: ...

    def set_trigger_mode(self, mode: TriggerMode) -> None: ...

    def apply_trigger_mode(self, mode: TriggerMode) -> TriggerMode: ...

    def get_trigger_slope(self) -> TriggerSlope: ...

    def set_trigger_slope(self, slope: TriggerSlope) -> None: ...

    def apply_trigger_slope(self, slope: TriggerSlope) -> TriggerSlope: ...

    def get_trigger_threshold(self) -> float: ...

    def set_trigger_threshold(self, threshold: float) -> None: ...

    def apply_trigger_threshold(self, threshold: float) -> float: ...

    def get_trigger_state(self) -> TriggerState: ...

    def set_trigger_state(self, state: TriggerState) -> None: ...

    def apply_trigger_state(self, state: TriggerState) -> TriggerState: ...

    def get_trigger_sweep(self) -> TriggerSweep: ...

    def set_trigger_sweep(self, sweep: TriggerSweep) -> None: ...

    def apply_trigger_sweep(self, sweep: TriggerSweep) -> TriggerSweep: ...

    def get_sample_rate(self) -> float: ...

    def set_sample_rate(self, sample_rate: float) -> None: ...

    def apply_sample_rate(self, sample_rate: float) -> float: ...

    def get_sample_count(self) -> float: ...

    def set_sample_count(self, sample_count: float) -> None: ...

    def apply_sample_count(self, sample_count: float) -> float: ...

    def get_image_format(self) -> ImageFormat: ...

    def set_image_format(self, image_format: ImageFormat) -> None: ...

    def apply_image_format(self, image_format: ImageFormat) -> ImageFormat: ...

    def get_screenshot(self) -> bytes: ...

    def get_waveform_preamble(self) -> Preamble: ...

    def get_waveform_start_index(self) -> int: ...

    def set_waveform_start_index(self, start_index: int) -> None: ...

    def apply_waveform_start_index(self, start_index: int) -> int: ...

    def get_waveform_stop_index(self) -> int: ...

    def set_waveform_stop_index(self, stop_index: int) -> None: ...

    def apply_waveform_stop_index(self, stop_index: int) -> int: ...

    def get_waveform_encoding(self) -> WaveformEncoding: ...

    def set_waveform_encoding(self, encoding: WaveformEncoding) -> None: ...

    def apply_waveform_encoding(
        self, encoding: WaveformEncoding
    ) -> WaveformEncoding: ...

    def get_waveform_data(self) -> list[float]: ...

    def apply_waveform_source(self) -> None: ...

    def get_probe_id(self) -> ProbeId | UnknownProbe | None: ...

    def sync(self) -> bool: ...

    def get_acquisition_state(self) -> AcquisitionState: ...

    def set_acquisition_state(self, state: AcquisitionState) -> None: ...

    def get_acquisition_condition(self) -> AcquisitionCondition: ...

    def set_acquisition_condition(self, condition: AcquisitionCondition) -> None: ...

    def get_acquisition_info(self, min_sample_rate: float) -> AcquisitionInfo: ...

    def set_acquisition_info(self, min_sample_rate: float) -> None: ...

    def apply_trigger_source(self) -> None: ...
