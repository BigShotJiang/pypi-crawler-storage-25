import math

import pyvisa
from pyvisa.resources import MessageBasedResource

from fusaware_instruments.visa_instrument_hal.hal_dmm import (
    MeasurementFunction,
    HALDigitalMultimeter,
    MeasurementIntegrationTime,
    MeasurementRange,
    DEFAULT_NPLCS,
)
from fusaware_instruments.visa_instrument_drivers.driver_keithley_dmm6500 import (
    KeithleyDMM6500,
    MeasurementFunction as DeviceMeasurementFunction,
    DisplayDigit as DeviceDisplayDigit,
    DCVoltageRange as DeviceDCVoltageRange,
    DCCurrentRange as DeviceDCCurrentRange,
    DCVoltageInputImpedance as DeviceDCVoltageImpedance,
    CommandSet,
    Terminals,
)


class HALDmmKeithleyDMM6500(HALDigitalMultimeter):
    def __init__(self, resource_name: str, timeout_ms: int = 5000):
        self._resource_name = resource_name
        self._rm = None
        self._device = None
        return

    def connect(self, sim_file: str | None = None) -> None:
        if self._rm is None:
            self._rm = (
                pyvisa.ResourceManager(f"{sim_file}@sim")
                if sim_file is not None
                else pyvisa.ResourceManager()
            )
        if self._device is None:
            self._device = MessageBasedResource(self._rm, self._resource_name)
            self._device.open()
        return

    def disconnect(self):
        if self._device is not None:
            self._device.close()
            self._device = None
        if self._rm is not None:
            self._rm.close()
            self._rm = None
        return

    @classmethod
    def _map_device_function_to_hal_function(
        cls, function: DeviceMeasurementFunction
    ) -> MeasurementFunction:
        match function:
            case DeviceMeasurementFunction.VOLT_DC:
                return MeasurementFunction.DCVoltage
            case DeviceMeasurementFunction.CURR_DC:
                return MeasurementFunction.DCCurrent
            case _:
                raise ValueError("Function '{function'} not supported by HAL")

    @classmethod
    def _map_hal_function_to_device_function(
        cls, function: MeasurementFunction
    ) -> DeviceMeasurementFunction:
        match function:
            case MeasurementFunction.DCVoltage:
                return DeviceMeasurementFunction.VOLT_DC
            case MeasurementFunction.DCCurrent:
                return DeviceMeasurementFunction.CURR_DC

    def get_measurement_function(self) -> MeasurementFunction:
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        msg = KeithleyDMM6500.sense_function_on_query()
        resp = self._device.query(msg)
        device_function = KeithleyDMM6500.sense_function_on_parse(resp)
        return self._map_device_function_to_hal_function(device_function)

    def set_measurement_function(self, function: MeasurementFunction) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        match function:
            case MeasurementFunction.DCCurrent:
                msg = KeithleyDMM6500.sense_function_on_write(
                    DeviceMeasurementFunction.CURR_DC
                )
            case MeasurementFunction.DCVoltage:
                msg = KeithleyDMM6500.sense_function_on_write(
                    DeviceMeasurementFunction.VOLT_DC
                )

        self._device.write(msg)
        return

    @classmethod
    def _map_device_dc_voltage_range_to_hal_dc_voltage_range(
        cls, device_range: DeviceDCVoltageRange
    ) -> float:
        return device_range.value

    @classmethod
    def _map_hal_dc_voltage_range_to_device_dc_voltage_range(
        cls, hal_range: float
    ) -> DeviceDCVoltageRange:
        if math.isclose(hal_range, 0.1):
            return DeviceDCVoltageRange.RNG_100mV
        elif math.isclose(hal_range, 1):
            return DeviceDCVoltageRange.RNG_1V
        elif math.isclose(hal_range, 10):
            return DeviceDCVoltageRange.RNG_10V
        elif math.isclose(hal_range, 100):
            return DeviceDCVoltageRange.RNG_100V
        elif math.isclose(hal_range, 1000.0):
            return DeviceDCVoltageRange.RNG_1000V
        raise ValueError(f"Unexpected range: {hal_range}")

    @classmethod
    def _map_device_dc_current_range_to_hal_dc_current_range(
        cls, device_range: DeviceDCCurrentRange
    ) -> float:
        return device_range.value

    @classmethod
    def _map_hal_dc_current_range_to_device_dc_current_range(
        cls, hal_range: float, terminals: Terminals
    ) -> DeviceDCCurrentRange:
        if math.isclose(hal_range, 10e-6):
            return DeviceDCCurrentRange.RNG_10uA
        elif math.isclose(hal_range, 100e-6):
            return DeviceDCCurrentRange.RNG_100uA
        elif math.isclose(hal_range, 1e-3):
            return DeviceDCCurrentRange.RNG_1mA
        elif math.isclose(hal_range, 10e-3):
            return DeviceDCCurrentRange.RNG_10mA
        elif math.isclose(hal_range, 100e-3):
            return DeviceDCCurrentRange.RNG_100mA
        elif math.isclose(hal_range, 1):
            return DeviceDCCurrentRange.RNG_1A
        elif math.isclose(hal_range, 3):
            return DeviceDCCurrentRange.RNG_3A
        elif math.isclose(hal_range, 10):
            match terminals:
                case Terminals.FRONT:
                    raise ValueError("Front terminals do not support 10A range")
                case Terminals.REAR:
                    return DeviceDCCurrentRange.RNG_10A
        raise ValueError(f"Unexpected range: {hal_range}")

    def get_measurement_range(self, function: MeasurementFunction) -> MeasurementRange:
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        match function:
            case MeasurementFunction.DCVoltage:
                auto_query_msg = KeithleyDMM6500.sense_dc_voltage_range_auto_query()
                resp = self._device.query(auto_query_msg)
                auto_enabled = KeithleyDMM6500.sense_dc_voltage_range_auto_parse(resp)
                if auto_enabled:
                    return "auto"

                upper_query_msg = KeithleyDMM6500.sense_dc_voltage_range_upper_query()
                resp = self._device.query(upper_query_msg)
                rnge = KeithleyDMM6500.sense_dc_voltage_range_upper_parse(resp)
                return self._map_device_dc_voltage_range_to_hal_dc_voltage_range(rnge)
            case MeasurementFunction.DCCurrent:
                auto_query_msg = KeithleyDMM6500.sense_dc_current_range_auto_query()
                resp = self._device.query(auto_query_msg)
                auto_enabled = KeithleyDMM6500.sense_dc_current_range_auto_parse(resp)
                if auto_enabled:
                    return "auto"

                msg = KeithleyDMM6500.sense_dc_current_range_upper_query()
                resp = self._device.query(msg)
                rnge = KeithleyDMM6500.sense_dc_current_range_upper_parse(resp)
                return self._map_device_dc_current_range_to_hal_dc_current_range(rnge)

    def set_measurement_range(
        self, function: MeasurementFunction, measurement_range: MeasurementRange
    ):
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        terminals_query = KeithleyDMM6500.route_teminals_query()
        terminals_response = self._device.query(terminals_query)
        terminals = KeithleyDMM6500.route_teminals_parse(terminals_response)

        if measurement_range == "auto":
            match function:
                case MeasurementFunction.DCVoltage:
                    msg = KeithleyDMM6500.sense_dc_voltage_range_auto_write(True)
                    self._device.write(msg)
                case MeasurementFunction.DCCurrent:
                    msg = KeithleyDMM6500.sense_dc_current_range_auto_write(True)
                    self._device.write(msg)
            return

        match function:
            case MeasurementFunction.DCVoltage:
                device_voltage_range = (
                    self._map_hal_dc_voltage_range_to_device_dc_voltage_range(
                        measurement_range
                    )
                )
                msg = KeithleyDMM6500.sense_dc_voltage_range_upper_write(
                    device_voltage_range
                )
                self._device.write(msg)
            case MeasurementFunction.DCCurrent:
                device_current_range = (
                    self._map_hal_dc_current_range_to_device_dc_current_range(
                        measurement_range, terminals
                    )
                )
                msg = KeithleyDMM6500.sense_dc_current_range_upper_write(
                    device_current_range
                )
                self._device.write(msg)

    @classmethod
    def _map_device_digits_to_hal_digits(cls, device_digits: DeviceDisplayDigit) -> int:
        if device_digits == DeviceDisplayDigit.DIGIT_3p5:
            return 3
        elif device_digits == DeviceDisplayDigit.DIGIT_4p5:
            return 4
        elif device_digits == DeviceDisplayDigit.DIGIT_5p5:
            return 5
        elif device_digits == DeviceDisplayDigit.DIGIT_6p5:
            return 6
        raise ValueError(f"Unexpected device digits: {device_digits}")

    @classmethod
    def _map_hal_digits_to_device_digits(cls, hal_digits: int) -> DeviceDisplayDigit:
        return DeviceDisplayDigit(hal_digits)

    def get_dc_voltage_measurement_display_digits(self) -> int:
        ...
        # if self._device is None:
        #     raise RuntimeError("Device not connected")
        # msg = KeithleyDMM6500.display_function_digits_query()
        # resp = self._device.query(msg)
        # device_digits = KeithleyDMM6500.display_function_digits_parse(resp)
        # return self._map_device_digits_to_hal_digits(device_digits)

    def set_dc_voltage_measurement_display_digits(self, digits: int) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")
        device_digits = self._map_hal_digits_to_device_digits(digits)
        KeithleyDMM6500.display_function_digits_write(
            DeviceMeasurementFunction.VOLT_DC, device_digits
        )
        return

    def get_measurement_integration_time(
        self, function: MeasurementFunction
    ) -> MeasurementIntegrationTime:
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        match function:
            case MeasurementFunction.DCVoltage:
                func = DeviceMeasurementFunction.VOLT_DC
            case MeasurementFunction.DCCurrent:
                func = DeviceMeasurementFunction.CURR_DC
        query = KeithleyDMM6500.sense_function_nplcycles_query(func)
        resp = self._device.query(query)
        nplcs = KeithleyDMM6500.sense_function_nplcycles_parse(resp)
        return nplcs

    def set_measurement_integration_time(
        self, function: MeasurementFunction, integration: MeasurementIntegrationTime
    ) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        self._apply_scpi_command_set()

        match function:
            case MeasurementFunction.DCVoltage:
                func = DeviceMeasurementFunction.VOLT_DC
            case MeasurementFunction.DCCurrent:
                func = DeviceMeasurementFunction.CURR_DC

        match integration:
            case float() | int():
                msg = KeithleyDMM6500.sense_function_nplcycles_write(func, integration)
            case "auto":
                msg = KeithleyDMM6500.sense_function_nplcycles_write(
                    func, DEFAULT_NPLCS
                )

        self._device.write(msg)

    def get_dc_current_measurement(self) -> float:
        ...
        # if self._device is None:
        #     raise RuntimeError("Device not connected")
        # msg = KeithleyDMM6500.measure_current_dc_query()
        # resp = self._device.query(msg)
        # resp = resp.strip()
        # return float(resp)

    def get_dc_voltage_measurement(self) -> float:
        ...
        # if self._device is None:
        #     raise RuntimeError("Device not connected")
        # msg = KeithleyDMM6500.measure_voltage_dc_query()
        # resp = self._device.query(msg)
        # return KeithleyDMM6500.measure_voltage_dc_parse(resp)

    @classmethod
    def _map_device_impedance_to_hal_impedance(
        cls, device_impedance: DeviceDCVoltageImpedance
    ) -> int:
        match device_impedance:
            case DeviceDCVoltageImpedance.I_10MOhm:
                return int(1e7)
            case DeviceDCVoltageImpedance.I_10GOhm:
                return int(1e10)

    @classmethod
    def _map_hal_impedance_to_device_impedance(
        cls, hal_impedance: int
    ) -> DeviceDCVoltageImpedance:
        if math.isclose(hal_impedance, 10000000):
            return DeviceDCVoltageImpedance.I_10MOhm
        elif math.isclose(hal_impedance, 10000000000):
            return DeviceDCVoltageImpedance.I_10GOhm
        raise ValueError(f"Unexpected impedance: {hal_impedance}")

    def get_measurement_input_impedance(self) -> int:
        if self._device is None:
            raise RuntimeError("Device not connected")
        msg = KeithleyDMM6500.sense_function_dc_voltage_input_impedance_query()
        resp = self._device.query(msg)
        device_impedance = (
            KeithleyDMM6500.sense_function_dc_voltage_input_impedance_parse(resp)
        )
        return self._map_device_impedance_to_hal_impedance(device_impedance)

    def set_measurement_input_impedance(self, impedance: int) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")
        device_impedance = self._map_hal_impedance_to_device_impedance(impedance)
        msg = KeithleyDMM6500.sense_function_dc_voltage_input_impedance_write(
            device_impedance
        )
        self._device.write(msg)
        return

    def get_measurement(self) -> float:
        if self._device is None:
            raise RuntimeError("Device not connected")

        query = KeithleyDMM6500.measure_query()
        response = self._device.query(query)
        return KeithleyDMM6500.measure_parse(response)

    def _apply_scpi_command_set(self) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        query = KeithleyDMM6500.lang_query()
        initial_command_set_resp = self._device.query(query)
        initial_command_set = KeithleyDMM6500.lang_parse(initial_command_set_resp)

        if initial_command_set == CommandSet.SCPI:
            return

        self._device.write(KeithleyDMM6500.lang_write(CommandSet.SCPI))

        final_command_set_resp = self._device.query(query)
        final_command_set = KeithleyDMM6500.lang_parse(final_command_set_resp)

        if final_command_set != CommandSet.SCPI:
            raise RuntimeError(
                f"Failed to set command set to SCPI, got {final_command_set.value}"
            )
