import math

import pyvisa
from pyvisa.resources import MessageBasedResource

from ..visa_instrument_hal.hal_dmm import (
    HALDigitalMultimeter,
    MeasurementFunction,
    MeasurementIntegrationTime,
    MeasurementRange,
)
from ..visa_instrument_drivers.driver_rigol_dm3000 import (
    MeasurementFunction as DeviceMeasurementFunction,
    RigolDM3000,
    DCVoltageRange as DeviceDCVoltageRange,
    DCVoltageInputImpedance as DeviceDCVoltageImpedance,
    DCCurrentRange as DeviceDCCurrentRange,
)


class HALDmmRigolDm3000(HALDigitalMultimeter):
    def __init__(self, resouce_name: str):
        self._resource_name = resouce_name
        self._rm = None
        self._device = None

    def connect(self, sim_file: str | None = None) -> None:
        if self._rm is None:
            self._rm = (
                pyvisa.ResourceManager(f"{sim_file}@sim")
                if sim_file is not None
                else pyvisa.ResourceManager()
            )
        if self._device is None:
            self._device = MessageBasedResource(self._rm, self._resource_name)
            self._device.open()

    def disconnect(self) -> None:
        if self._device is not None:
            self._device.close()
            self._device = None
        if self._rm is not None:
            self._rm.close()
            self._rm = None

    @classmethod
    def _map_device_function_to_hal_function(
        cls, function: DeviceMeasurementFunction
    ) -> MeasurementFunction:
        # do the mapping
        match function:
            case DeviceMeasurementFunction.DCV:
                return MeasurementFunction.DCVoltage
            case DeviceMeasurementFunction.DCI:
                return MeasurementFunction.DCCurrent

    @classmethod
    def _map_hal_function_to_device_function(
        cls, function: MeasurementFunction
    ) -> DeviceMeasurementFunction:
        return DeviceMeasurementFunction(function)

    @classmethod
    def _map_device_dc_voltage_range_to_hal_dc_voltage_range(
        cls, device_range: DeviceDCVoltageRange
    ) -> float:
        match device_range:
            case DeviceDCVoltageRange.V_200mV:
                return 0.2
            case DeviceDCVoltageRange.V_2V:
                return 2.0
            case DeviceDCVoltageRange.V_20V:
                return 20.0
            case DeviceDCVoltageRange.V_200V:
                return 200.0
            case DeviceDCVoltageRange.V_1000V:
                return 1000.0
            case DeviceDCVoltageRange.MIN:
                return 0.2
            case DeviceDCVoltageRange.DEF:
                return 20.0
            case DeviceDCVoltageRange.MAX:
                return 1000.0

    @classmethod
    def _map_hal_dc_voltage_range_to_device_dc_voltage_range(
        cls, hal_range: float
    ) -> DeviceDCVoltageRange:
        if math.isclose(hal_range, 0.2):
            return DeviceDCVoltageRange.V_200mV
        elif math.isclose(hal_range, 2.0):
            return DeviceDCVoltageRange.V_2V
        elif math.isclose(hal_range, 20.0):
            return DeviceDCVoltageRange.V_20V
        elif math.isclose(hal_range, 200.0):
            return DeviceDCVoltageRange.V_200V
        elif math.isclose(hal_range, 1000.0):
            return DeviceDCVoltageRange.V_1000V
        raise ValueError(f"Unexpected range: {hal_range}")

    @classmethod
    def _map_device_dc_current_range_to_hal_dc_current_range(
        cls, device_range: DeviceDCCurrentRange
    ) -> float:
        match device_range:
            case DeviceDCCurrentRange.I_2mA:
                return 0.002
            case DeviceDCCurrentRange.I_20mA:
                return 0.02
            case DeviceDCCurrentRange.I_200mA:
                return 0.2
            case DeviceDCCurrentRange.I_1A:
                return 1.0
            case DeviceDCCurrentRange.I_10A:
                return 10.0
            case DeviceDCCurrentRange.MIN:
                return 0.002
            case DeviceDCCurrentRange.DEF:
                return 0.2
            case DeviceDCCurrentRange.MAX:
                return 10.0

    @classmethod
    def _map_hal_dc_current_range_to_device_dc_current_range(
        cls, hal_range: float
    ) -> DeviceDCCurrentRange:
        if math.isclose(hal_range, 0.002):
            return DeviceDCCurrentRange.I_2mA
        elif math.isclose(hal_range, 0.02):
            return DeviceDCCurrentRange.I_20mA
        elif math.isclose(hal_range, 0.2):
            return DeviceDCCurrentRange.I_200mA
        elif math.isclose(hal_range, 1.0):
            return DeviceDCCurrentRange.I_1A
        elif math.isclose(hal_range, 10.0):
            return DeviceDCCurrentRange.I_10A

        raise ValueError(f"Unexpected range: {hal_range}")

    def get_dc_voltage_measurement(self) -> float:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = RigolDM3000.measure_voltage_dc_query()
        resp = self._device.query(msg)
        return RigolDM3000.measure_voltage_dc_parse(resp)

    @classmethod
    def _map_device_impedance_to_hal_impedance(
        cls, device_impedance: DeviceDCVoltageImpedance
    ) -> int:
        if device_impedance == DeviceDCVoltageImpedance.I_10MOhm:
            return 10000000
        elif device_impedance == DeviceDCVoltageImpedance.I_10GOhm:
            return 10000000000

    @classmethod
    def _map_hal_impedance_to_device_impedance(
        cls, hal_impedance: int
    ) -> DeviceDCVoltageImpedance:
        if math.isclose(hal_impedance, 10000000):
            return DeviceDCVoltageImpedance.I_10MOhm
        elif math.isclose(hal_impedance, 10000000000):
            return DeviceDCVoltageImpedance.I_10GOhm
        raise ValueError(f"Unexpected impedance: {hal_impedance}")

    def get_measurement_function(self) -> MeasurementFunction:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = RigolDM3000.function_query()
        resp = self._device.query(msg)
        device_function = RigolDM3000.function_parse(resp)
        return self._map_device_function_to_hal_function(device_function)

    def set_measurement_function(self, function: MeasurementFunction) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        match function:
            case MeasurementFunction.DCVoltage:
                msg = RigolDM3000.function_voltage_dc_write()
            case MeasurementFunction.DCCurrent:
                msg = RigolDM3000.function_current_dc_write()

        self._device.write(msg)

    def get_measurement_range(self, function: MeasurementFunction) -> float:
        if self._device is None:
            raise RuntimeError("Device not connected")

        match function:
            case MeasurementFunction.DCVoltage:
                msg = RigolDM3000.measure_voltage_dc_range_query()
                resp = self._device.query(msg)
                rnge = RigolDM3000.measure_voltage_dc_range_parse(resp)
                return self._map_device_dc_voltage_range_to_hal_dc_voltage_range(rnge)
            case MeasurementFunction.DCCurrent:
                msg = RigolDM3000.measure_current_dc_range_query()
                resp = self._device.query(msg)
                rnge = RigolDM3000.measure_current_dc_range_parse(resp)
                return self._map_device_dc_current_range_to_hal_dc_current_range(rnge)

    def set_measurement_range(
        self, function: MeasurementFunction, measurement_range: MeasurementRange
    ) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        if measurement_range == "auto":
            raise RuntimeError("Auto range not supported for the Rigol DM3000 series")

        match function:
            case MeasurementFunction.DCVoltage:
                device_voltage_range = (
                    self._map_hal_dc_voltage_range_to_device_dc_voltage_range(
                        measurement_range
                    )
                )
                msg = RigolDM3000.measure_voltage_dc_write(device_voltage_range)
            case MeasurementFunction.DCCurrent:
                device_current_range = (
                    self._map_hal_dc_current_range_to_device_dc_current_range(
                        measurement_range
                    )
                )
                msg = RigolDM3000.measure_current_dc_write(device_current_range)

        self._device.write(msg)

    def get_measurement_integration_time(
        self, function: MeasurementFunction
    ) -> MeasurementIntegrationTime:
        return "auto"

    def set_measurement_integration_time(
        self, function: MeasurementFunction, integration: MeasurementIntegrationTime
    ) -> None:
        return None

    def get_measurement_input_impedance(self) -> int:
        if self._device is None:
            raise RuntimeError("Device not connected")

        msg = RigolDM3000.measure_voltage_dc_impedance_query()
        resp = self._device.query(msg)
        device_impedance = RigolDM3000.measure_voltage_dc_impedance_parse(resp)
        return self._map_device_impedance_to_hal_impedance(device_impedance)

    def set_measurement_input_impedance(self, impedance: int) -> None:
        if self._device is None:
            raise RuntimeError("Device not connected")

        device_impedance = self._map_hal_impedance_to_device_impedance(impedance)
        msg = RigolDM3000.measure_voltage_dc_impedance_write(device_impedance)
        self._device.write(msg)
        return

    def get_measurement(self) -> float:
        if self._device is None:
            raise RuntimeError("Device not connected")

        function = self.get_measurement_function()

        match function:
            case MeasurementFunction.DCVoltage:
                msg = RigolDM3000.measure_voltage_dc_query()
                resp = self._device.query(msg)
                return RigolDM3000.measure_voltage_dc_parse(resp)
            case MeasurementFunction.DCCurrent:
                msg = RigolDM3000.measure_current_dc_query()
                resp = self._device.query(msg)
                return RigolDM3000.measure_current_dc_parse(resp)
