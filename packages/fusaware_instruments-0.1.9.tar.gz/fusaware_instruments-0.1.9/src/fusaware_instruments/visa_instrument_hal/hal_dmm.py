from abc import ABC, abstractmethod
from enum import Enum
from typing import Literal

from pydantic import BaseModel

DEFAULT_NPLCS = 10.0


class MeasurementFunction(Enum):
    """
    Measurement function. Only DC voltage and DC current are supported in this HAL.
    """

    DCVoltage = "DC_VOLTAGE"
    DCCurrent = "DC_CURRENT"


class HALDigitalCurrentMeter(ABC):
    @abstractmethod
    def connect(self) -> None:
        """Open connection to the instrument."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close connection to the instrument."""
        pass


type MeasurementRange = float | Literal["auto"]


type MeasurementIntegrationTime = float | Literal["auto"]


def compare_measurement_range(
    desired: MeasurementRange, actual: MeasurementRange
) -> bool:
    # TODO use helper function for float comparison
    match desired, actual:
        case float() | int(), float() | int():
            return abs(desired - actual) < 1e-9
        case "auto", "auto":
            return True
        case _:
            return False


def compare_measurement_integration_time(
    desired: MeasurementIntegrationTime, actual: MeasurementIntegrationTime
) -> bool:
    # TODO use helper function for float comparison
    match desired, actual:
        case float() | int(), float() | int():
            return abs(desired - actual) < 1e-9
        case "auto", "auto":
            return True
        case "auto", float() | int():
            return abs(actual - DEFAULT_NPLCS) < 1e-9
        case float() | int(), "auto":
            return abs(desired - DEFAULT_NPLCS) < 1e-9
        case _:
            return False


class HALDigitalMultimeter(ABC, BaseModel):
    """
    Hardware abstraction layer for digital multimeters (DMM).
    """

    @abstractmethod
    def get_measurement_function(self) -> MeasurementFunction: ...

    @abstractmethod
    def set_measurement_function(self, function: MeasurementFunction) -> None: ...

    @abstractmethod
    def get_measurement_range(self, function: MeasurementFunction) -> MeasurementRange:
        """Return the current range setting (in current units)."""
        ...

    @abstractmethod
    def set_measurement_range(
        self, function: MeasurementFunction, measurement_range: MeasurementRange
    ) -> None:
        """Set the range."""
        ...

    @abstractmethod
    def get_measurement_integration_time(
        self, function: MeasurementFunction
    ) -> MeasurementIntegrationTime:
        """
        Return the integration time.
        """
        ...

    @abstractmethod
    def set_measurement_integration_time(
        self, function: MeasurementFunction, integration: MeasurementIntegrationTime
    ) -> None:
        """Set the integration time."""
        ...

    @abstractmethod
    def get_measurement_input_impedance(self) -> int:
        """Get the input impedance."""
        ...

    @abstractmethod
    def set_measurement_input_impedance(self, impedance: int) -> None:
        """Set the input impedance."""
        ...

    @abstractmethod
    def get_measurement(self) -> float:
        """
        Return a single measurement in the current function's units.

        The instrument must be in the appropriate function (e.g. DC voltage or
        DC current). Value is in the current units (e.g. volts or amps).
        """
        ...


class HALDmmDcVoltageMeter:
    """
    Hardware abstraction layer for digital voltage meters (DVM).
    """

    @classmethod
    def initialize(cls, dmm: HALDigitalMultimeter) -> None:
        """Initialize the DMM for voltage measurement."""
        dmm.set_measurement_function(MeasurementFunction.DCVoltage)

    @classmethod
    def set_to_measurement_function(cls, dmm: HALDigitalMultimeter) -> None:
        """Set the measurement function."""
        dmm.set_measurement_function(MeasurementFunction.DCVoltage)

    @classmethod
    def get_measurement_range(cls, dmm: HALDigitalMultimeter) -> MeasurementRange:
        """Return the current range setting (in current units)."""
        return dmm.get_measurement_range(MeasurementFunction.DCVoltage)

    @classmethod
    def set_measurement_range(
        cls, dmm: HALDigitalMultimeter, value: MeasurementRange
    ) -> None:
        """Set the range."""
        dmm.set_measurement_range(MeasurementFunction.DCVoltage, value)

    @classmethod
    def get_measurement_integration_time(
        cls, dmm: HALDigitalMultimeter
    ) -> MeasurementIntegrationTime:
        """
        Return the integration time.
        """
        return dmm.get_measurement_integration_time(MeasurementFunction.DCVoltage)

    @classmethod
    def set_measurement_integration_time(
        cls, dmm: HALDigitalMultimeter, integration: MeasurementIntegrationTime
    ) -> None:
        """Set the integration time."""
        dmm.set_measurement_integration_time(MeasurementFunction.DCVoltage, integration)

    @classmethod
    def get_measurement_input_impedance(cls, dmm: HALDigitalMultimeter) -> int:
        """Get the input impedance."""
        return dmm.get_measurement_input_impedance()

    @classmethod
    def set_measurement_input_impedance(
        cls, dmm: HALDigitalMultimeter, impedance: int
    ) -> None:
        """Set the input impedance."""
        dmm.set_measurement_input_impedance(impedance)

    @classmethod
    def get_measurement(cls, dmm: HALDigitalMultimeter) -> float:
        """
        Return a single measurement in the current function's units.

        The instrument must be in the appropriate function (e.g. DC voltage or
        DC current). Value is in the current units (e.g. volts or amps).
        """
        return dmm.get_measurement()


class HALDmmDcCurrentMeter:
    @classmethod
    def initialize(cls, dmm: HALDigitalMultimeter) -> None:
        dmm.set_measurement_function(MeasurementFunction.DCCurrent)

    @classmethod
    def set_to_measurement_function(cls, dmm: HALDigitalMultimeter) -> None:
        dmm.set_measurement_function(MeasurementFunction.DCCurrent)

    @classmethod
    def get_measurement_range(cls, dmm: HALDigitalMultimeter) -> MeasurementRange:
        return dmm.get_measurement_range(MeasurementFunction.DCCurrent)

    @classmethod
    def set_measurement_range(
        cls, dmm: HALDigitalMultimeter, value: MeasurementRange
    ) -> None:
        dmm.set_measurement_range(MeasurementFunction.DCCurrent, value)

    @classmethod
    def get_measurement_integration_time(
        cls, dmm: HALDigitalMultimeter
    ) -> MeasurementIntegrationTime:
        return dmm.get_measurement_integration_time(MeasurementFunction.DCCurrent)

    @classmethod
    def set_measurement_integration_time(
        cls, dmm: HALDigitalMultimeter, integration: MeasurementIntegrationTime
    ) -> None:
        dmm.set_measurement_integration_time(MeasurementFunction.DCCurrent, integration)

    @classmethod
    def get_measurement_input_impedance(cls, dmm: HALDigitalMultimeter) -> int:
        return dmm.get_measurement_input_impedance()

    @classmethod
    def set_measurement_input_impedance(
        cls, dmm: HALDigitalMultimeter, impedance: int
    ) -> None:
        dmm.set_measurement_input_impedance(impedance)

    @classmethod
    def get_measurement(cls, dmm: HALDigitalMultimeter) -> float:
        return dmm.get_measurement()
