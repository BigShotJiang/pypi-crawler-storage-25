import math
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    HALDCPowerSupply,
    PowerSourceMode,
    VoltageSensingMode,
)
from fusaware_instruments.visa_instrument_drivers.driver_dc_power_supply_simulator import (
    DCPowerSupplySimulator,
)


class HALDCPowerSupplySimulator(HALDCPowerSupply):
    def __init__(self, channel_number: int):
        if not isinstance(channel_number, int):
            raise TypeError("channel_number must be an int")
        if channel_number not in (1, 2, 3):
            raise ValueError("channel_number must be 1, 2, or 3")

        self._channel_number = channel_number
        self._device: DCPowerSupplySimulator = DCPowerSupplySimulator()
        return

    def connect(self):
        self._device.open()
        return

    def disconnect(self):
        self._device.close()
        return

    def get_power_source_mode(self) -> PowerSourceMode:
        channel_name = f"CH{self._channel_number}"

        mode_param = self._device.query_output_mode(channel_name)

        if mode_param == "CV":
            return PowerSourceMode.ConstantVoltage
        else:
            raise ValueError(f"Unexpected power source mode response: {mode_param}")

    def get_output_enable(self) -> bool:
        enable_param = self._device.query_output_state(f"CH{self._channel_number}")

        if enable_param == "OFF":
            enable = False
        elif enable_param == "ON":
            enable = True
        else:
            raise ValueError(f"Unexpected output enable response: {enable_param}")

        return enable

    def set_output_enable(self, enable: bool) -> None:
        if not isinstance(enable, bool):
            raise TypeError("enable must be a bool")

        channel_name = f"CH{self._channel_number}"

        enable_param = "ON" if enable else "OFF"

        self._device.write_output_state(channel_name, enable_param)

        return

    def apply_output_enable(self, enable: bool) -> bool:
        self.set_output_enable(enable)
        new_enable = self.get_output_enable()

        if new_enable != enable:
            raise RuntimeError(f"Verification failure: set {enable}, read {new_enable}")

        return new_enable

    def get_source_voltage_amplitude(self) -> float:
        amplitude = self._device.query_source_voltage_level_immediate_amplitude(
            self._channel_number
        )
        return amplitude

    def set_source_voltage_amplitude(self, amplitude: float) -> None:
        if not isinstance(amplitude, (float, int)):
            raise TypeError("amplitude must be a float")

        self._device.write_source_voltage_level_immediate_amplitude(
            self._channel_number, amplitude
        )

        return

    def apply_source_voltage_amplitude(self, amplitude: float) -> float:
        self.set_source_voltage_amplitude(amplitude)
        new_amplitude = self.get_source_voltage_amplitude()
        if not math.isclose(amplitude, new_amplitude, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(
                f"Verification failure: set {amplitude}, read {new_amplitude}"
            )
        return new_amplitude

    def get_source_voltage_sensing_mode(self) -> VoltageSensingMode:
        channel_name = f"CH{self._channel_number}"
        mode_param = self._device.query_output_sense(channel_name)

        if mode_param in ("NONE", "OFF"):
            return VoltageSensingMode.LOCAL
        elif mode_param == "ON":
            return VoltageSensingMode.REMOTE
        else:
            raise ValueError(f"Unexpected voltage sensing mode response: {mode_param}")

    def set_source_voltage_sensing_mode(self, mode: VoltageSensingMode) -> None:
        if not isinstance(mode, str):
            raise TypeError("mode must be a string")
        if mode not in ("LOCAL", "REMOTE"):  # no support for 'REMOTE'
            raise ValueError("mode must be 'LOCAL'")

        if mode in "LOCAL":
            mode_param = "OFF"
        elif mode == "REMOTE":
            mode_param = "ON"
        else:
            raise ValueError(f"Unexpected mode: {mode}")

        channel_name = f"CH{self._channel_number}"
        self._device.write_output_sense(channel_name, mode_param)

        return

    def apply_source_voltage_sensing_mode(
        self, mode: VoltageSensingMode
    ) -> VoltageSensingMode:
        self.set_source_voltage_sensing_mode(mode)
        new_mode = self.get_source_voltage_sensing_mode()

        if mode != new_mode:
            raise RuntimeError(f"Verification failure: set {mode}, read {new_mode}")

        return new_mode

    def get_source_current_limit(self) -> float:
        amplitude = self._device.query_source_current_level_immediate_amplitude(
            self._channel_number
        )

        limit = amplitude

        return limit

    def set_source_current_limit(self, limit: float) -> None:
        if not isinstance(limit, (float, int)):
            raise TypeError("limit must be a float")

        self._device.write_source_current_level_immediate_amplitude(
            self._channel_number, limit
        )

        return

    def apply_source_current_limit(self, limit: float) -> float:
        self.set_source_current_limit(limit)
        new_limit = self.get_source_current_limit()

        if not math.isclose(limit, new_limit, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(f"Verification failure: set {limit}, read {new_limit}")

        return new_limit

    def get_over_current_protection_enable(self) -> bool:
        raise NotImplementedError("Not yet implemented")

    def set_over_current_protection_enable(self, enable: bool) -> None:
        if not isinstance(enable, bool):
            raise TypeError("enable must be a bool")
        raise NotImplementedError("Not yet implemented")

    def apply_over_current_protection_enable(self, enable: bool) -> bool:
        self.set_over_current_protection_enable(enable)
        new_enable = self.get_over_current_protection_enable()

        if enable != new_enable:
            raise RuntimeError(f"Verification failure: set {enable}, read {new_enable}")

        return new_enable

    def get_over_current_protection_threshold(self) -> float:
        raise NotImplementedError("Not yet implemented")

    def set_over_current_protection_threshold(self, threshold: float) -> None:
        raise NotImplementedError("Not yet implemented")

    def apply_over_current_protection_threshold(self, threshold: float) -> float:
        self.set_over_current_protection_threshold(threshold)
        new_threshold = self.get_over_current_protection_threshold()

        if not math.isclose(threshold, new_threshold, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(
                f"Verification failure: set {threshold}, read {new_threshold}"
            )

        return new_threshold

    def get_output_current_measurement(self) -> float:
        raise NotImplementedError("Not yet implemented")

    def get_output_voltage_measurement(self) -> float:
        raise NotImplementedError("Not yet implemented")

    def sync(self) -> bool:
        return True
