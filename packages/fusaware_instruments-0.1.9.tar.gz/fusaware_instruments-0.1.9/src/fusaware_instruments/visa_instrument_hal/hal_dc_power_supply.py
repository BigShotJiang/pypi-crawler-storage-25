from abc import ABC, abstractmethod
from enum import Enum

from pydantic import BaseModel


class PowerSourceMode(Enum):
    ConstantCurrent = "CONSTANT_CURRENT"
    ConstantVoltage = "CONSTANT_VOLTAGE"
    Unregulated = "UNREGULATED"


class VoltageSensingMode(Enum):
    LOCAL = "local"
    REMOTE = "remote"
    UNKNOWN = "unknown"


class HALDCPowerSupply(ABC, BaseModel):
    @abstractmethod
    def connect(self): ...

    @abstractmethod
    def disconnect(self): ...

    @abstractmethod
    def get_source_voltage_amplitude(self) -> float | int: ...

    @abstractmethod
    def set_source_voltage_amplitude(self, amplitude: float | int) -> None: ...

    @abstractmethod
    def apply_source_voltage_amplitude(self, amplitude: float | int) -> float | int: ...

    @abstractmethod
    def get_source_voltage_sensing_mode(self) -> VoltageSensingMode: ...

    @abstractmethod
    def set_source_voltage_sensing_mode(self, mode: VoltageSensingMode) -> None: ...

    @abstractmethod
    def apply_source_voltage_sensing_mode(
        self, mode: VoltageSensingMode
    ) -> VoltageSensingMode: ...

    @abstractmethod
    def get_source_current_limit(self) -> float | int: ...

    @abstractmethod
    def set_source_current_limit(self, limit: float | int) -> None: ...

    @abstractmethod
    def apply_source_current_limit(self, limit: float | int) -> float | int: ...

    @abstractmethod
    def get_over_current_protection_enable(self) -> bool: ...

    @abstractmethod
    def set_over_current_protection_enable(self, enable: bool) -> None: ...

    @abstractmethod
    def apply_over_current_protection_enable(self, enable: bool) -> bool: ...

    @abstractmethod
    def get_over_current_protection_threshold(self) -> float | int: ...

    @abstractmethod
    def set_over_current_protection_threshold(self, threshold: float | int) -> None: ...

    @abstractmethod
    def apply_over_current_protection_threshold(
        self, threshold: float | int
    ) -> float | int: ...

    @abstractmethod
    def get_power_source_mode(self) -> PowerSourceMode: ...

    @abstractmethod
    def get_output_enable(self) -> bool: ...

    @abstractmethod
    def set_output_enable(self, enable: bool) -> None: ...

    @abstractmethod
    def apply_output_enable(self, enable: bool) -> bool: ...

    @abstractmethod
    def get_output_current_measurement(self) -> float | int: ...

    @abstractmethod
    def get_output_voltage_measurement(self) -> float | int: ...

    @abstractmethod
    def sync(self) -> bool: ...
