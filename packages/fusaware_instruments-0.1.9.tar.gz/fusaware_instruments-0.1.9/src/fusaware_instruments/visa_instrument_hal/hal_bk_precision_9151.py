# pyright: strict

import time

import pyvisa
from pyvisa.resources import MessageBasedResource

from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    HALDCPowerSupply,
    VoltageSensingMode,
    PowerSourceMode,
)
from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_9151 import (
    BKPrecision9151,
)


class HALDCPowerSupplyBKPrecision9151(HALDCPowerSupply):
    def __init__(self, resource_name: str, visa_path: str | None = None):
        self._resource_name = resource_name
        self._visa_path = visa_path
        self._rm = None
        self._instr = None

    def connect(self):
        if self._rm is None:
            if self._visa_path is None:
                self._rm = pyvisa.ResourceManager()
            else:
                self._rm = pyvisa.ResourceManager(self._visa_path)
        if self._instr is None:
            self._instr = MessageBasedResource(self._rm, self._resource_name)
            self._instr.open()

    def disconnect(self):
        if self._instr is not None:
            self._instr.close()
        if self._rm is not None:
            self._rm.close()

    def get_source_voltage_amplitude(self) -> float | int:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.source_voltage_level_immediate_amplitude_query()
        resp = self._instr.query(msg)
        return BKPrecision9151.source_voltage_level_immediate_amplitude_parse(resp)

    def set_source_voltage_amplitude(self, amplitude: float | int) -> None:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.source_voltage_level_immediate_amplitude_write(amplitude)
        self._instr.write(msg)

    def apply_source_voltage_amplitude(self, amplitude: float | int) -> float | int:
        self.set_source_voltage_amplitude(amplitude)
        actual = self.get_source_voltage_amplitude()

        if actual != amplitude:
            raise RuntimeError(
                f"Failed to apply source voltage amplitude. Expected: {amplitude}, Actual: {actual}"
            )

        return actual

    def get_source_voltage_sensing_mode(self) -> VoltageSensingMode:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        query = BKPrecision9151.source_system_sense_state_query()
        response = self._instr.query(query)

        match BKPrecision9151.source_system_sense_state_parse(response):
            case BKPrecision9151.RemoteSenseState.OFF:
                return VoltageSensingMode.LOCAL
            case BKPrecision9151.RemoteSenseState.ON:
                return VoltageSensingMode.REMOTE

    def set_source_voltage_sensing_mode(self, mode: VoltageSensingMode) -> None:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        match mode:
            case VoltageSensingMode.LOCAL:
                msg = BKPrecision9151.source_system_sense_state_write(
                    BKPrecision9151.RemoteSenseState.OFF
                )
            case VoltageSensingMode.REMOTE:
                msg = BKPrecision9151.source_system_sense_state_write(
                    BKPrecision9151.RemoteSenseState.ON
                )
            case VoltageSensingMode.UNKNOWN:
                raise ValueError(
                    "BK Precision 9151 does not support 'UNKNOWN' voltage sensing"
                )

        self._instr.write(msg)

    def apply_source_voltage_sensing_mode(
        self, mode: VoltageSensingMode
    ) -> VoltageSensingMode:
        self.set_source_voltage_sensing_mode(mode)
        actual = self.get_source_voltage_sensing_mode()

        if actual != mode:
            raise RuntimeError(
                f"Failed to apply source voltage sensing mode. Expected: {mode}, Actual: {actual}"
            )

        return actual

    def get_source_current_limit(self) -> float | int:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.source_current_level_immediate_amplitude_query()
        resp = self._instr.query(msg)
        return BKPrecision9151.source_current_level_immediate_amplitude_parse(resp)

    def set_source_current_limit(self, limit: float | int) -> None:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.source_current_level_immediate_amplitude_write(limit)
        self._instr.write(msg)

    def apply_source_current_limit(self, limit: float | int) -> float | int:
        self.set_source_current_limit(limit)
        actual = self.get_source_current_limit()

        if actual != limit:
            raise RuntimeError(
                f"Failed to apply source current limit. Expected: {limit}, Actual: {actual}"
            )

        return actual

    def get_output_enable(self) -> bool:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.output_state_query()
        resp = self._instr.query(msg)
        state = BKPrecision9151.output_state_parse(resp)

        match state:
            case BKPrecision9151.OutputState.OFF:
                return False
            case BKPrecision9151.OutputState.ON:
                return True

    def set_output_enable(self, enable: bool) -> None:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        if enable:
            state = BKPrecision9151.OutputState.ON
        else:
            state = BKPrecision9151.OutputState.OFF

        msg = BKPrecision9151.output_state_write(state)
        self._instr.write(msg)

        return None

    def apply_output_enable(self, enable: bool) -> bool:
        self.set_output_enable(enable)
        actual = self.get_output_enable()

        if actual != enable:
            raise RuntimeError(
                f"Failed to apply output enable. Expected: {enable}, Actual: {actual}"
            )

        return actual

    def get_output_voltage_measurement(self) -> float | int:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.measure_scalar_voltage_dc_query()
        resp = self._instr.query(msg)
        return BKPrecision9151.measure_scalar_voltage_dc_parse(resp)

    def get_output_current_measurement(self) -> float | int:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        msg = BKPrecision9151.measure_scalar_current_dc_query()
        resp = self._instr.query(msg)
        return BKPrecision9151.measure_scalar_current_dc_parse(resp)

    def get_over_current_protection_enable(self) -> bool:
        raise NotImplementedError(
            "Over current protection enable query not implemented"
        )

    def set_over_current_protection_enable(self, enable: bool) -> None:
        raise NotImplementedError(
            "Over current protection enable write not implemented"
        )

    def apply_over_current_protection_enable(self, enable: bool) -> bool:
        raise NotImplementedError(
            "Over current protection enable apply not implemented"
        )

    def get_over_current_protection_threshold(self) -> float | int:
        raise NotImplementedError(
            "Over current protection threshold query not implemented"
        )

    def set_over_current_protection_threshold(self, threshold: float | int) -> None:
        raise NotImplementedError(
            "Over current protection threshold write not implemented"
        )

    def apply_over_current_protection_threshold(
        self, threshold: float | int
    ) -> float | int:
        raise NotImplementedError(
            "Over current protection threshold apply not implemented"
        )

    def get_power_source_mode(self) -> PowerSourceMode:
        raise NotImplementedError("Power source mode query not implemented")

    def sync(self) -> bool:
        if self._instr is None:
            raise RuntimeError("Instrument not connected")

        for _ in range(5):
            response = self._instr.query(BKPrecision9151.opc_query())
            if BKPrecision9151.opc_parse(response):
                return True
            time.sleep(0.25)

        return False
