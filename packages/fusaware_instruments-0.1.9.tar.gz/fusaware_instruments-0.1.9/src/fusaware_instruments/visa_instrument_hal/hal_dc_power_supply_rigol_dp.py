import math
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    HALDCPowerSupply,
    PowerSourceMode,
    VoltageSensingMode,
)
from fusaware_instruments.visa_instrument_drivers.driver_rigol_dp_base import (
    RigolDPBase,
    Channel,
    OutputMode,
    OutputSense,
    OutputState,
)


def _map_channel_number_to_channel_name(channel_number: int) -> str:
    return f"CH{channel_number}"


def _map_channel_name_to_channel_number(channel_name: str) -> int:
    return int(channel_name[-1])


def _map_hal_output_enable_to_driver_output_state(enable: bool) -> OutputState:
    if enable:
        return OutputState.One
    elif not enable:
        return OutputState.Zero
    else:
        raise ValueError(f"Invalid enable {enable}")


def _map_driver_output_state_to_hal_output_enable(state: OutputState) -> bool:
    if state == OutputState.Zero or state == OutputState.OFF:
        return False
    elif state == OutputState.One or state == OutputState.ON:
        return True
    else:
        raise ValueError(f"Invalid state {state}")


def _map_driver_source_mode_to_hal_power_source_mode(
    mode_param: OutputMode,
) -> PowerSourceMode:
    if mode_param == OutputMode.CC:
        return PowerSourceMode.ConstantCurrent
    elif mode_param == OutputMode.CV:
        return PowerSourceMode.ConstantVoltage
    elif mode_param == OutputMode.UR:
        return PowerSourceMode.Unregulated
    else:
        raise ValueError(f"Unexpected power source mode response: {mode_param}")


def _map_hal_source_voltage_sensing_mode_to_driver_output_sense(
    mode: VoltageSensingMode,
) -> OutputSense:
    match mode:
        case VoltageSensingMode.LOCAL:
            return OutputSense.OFF
        case VoltageSensingMode.REMOTE:
            return OutputSense.ON
        case VoltageSensingMode.UNKNOWN:
            raise ValueError(f"Unsupported voltage mode {mode}")


def _map_driver_output_sense_to_hal_source_voltage_sensing_mode(
    sensing_mode_param: OutputSense,
) -> VoltageSensingMode:
    if sensing_mode_param == OutputSense.NONE or sensing_mode_param.OFF:
        return VoltageSensingMode.LOCAL
    elif sensing_mode_param == OutputSense.ON:
        return VoltageSensingMode.REMOTE
    else:
        raise ValueError(
            f"Unexpected voltage sensing mode response: {sensing_mode_param}"
        )


class HALDCPowerSupplyRigol(HALDCPowerSupply):
    def __init__(self, resource_name: str, channel_number: int, visa_path: str):
        if not isinstance(resource_name, str):
            raise TypeError("resource_name must be a string")
        if not isinstance(channel_number, int):
            raise TypeError("channel_number must be an int")

        self._resource_name = resource_name
        self._channel = Channel(channel_number)

        self._device: RigolDPBase = RigolDPBase(
            self._resource_name, visa_path=visa_path
        )
        return

    def connect(self):
        if self._device:
            self._device.open()
        return

    def disconnect(self):
        if self._device:
            self._device.close()
            # self._device = None
        return

    def get_power_source_mode(self) -> PowerSourceMode:
        mode_param = self._device.query_output_mode(self._channel)

        mode = _map_driver_source_mode_to_hal_power_source_mode(mode_param)

        return mode

    def get_output_enable(self) -> bool:
        state_param = self._device.query_output_state(self._channel)
        enable = _map_driver_output_state_to_hal_output_enable(state_param)
        return enable

    def set_output_enable(self, enable: bool) -> None:
        state_param = _map_hal_output_enable_to_driver_output_state(enable)
        self._device.write_output_state(self._channel, state_param)
        return

    def apply_output_enable(self, enable: bool) -> bool:
        self.set_output_enable(enable)
        new_enable = self.get_output_enable()

        if new_enable != enable:
            raise RuntimeError(f"Verification failure: set {enable}, read {new_enable}")

        return new_enable

    def get_source_voltage_amplitude(self) -> float | int:
        amplitude = self._device.query_source_voltage_level_immediate_amplitude(
            self._channel
        )
        return amplitude

    def set_source_voltage_amplitude(self, amplitude: float | int) -> None:
        if not isinstance(amplitude, (float, int)):
            raise TypeError("amplitude must be a float")

        self._device.write_source_voltage_level_immediate_amplitude(
            self._channel, amplitude
        )

        return

    def apply_source_voltage_amplitude(self, amplitude: float | int) -> float | int:
        self.set_source_voltage_amplitude(amplitude)
        new_amplitude = self.get_source_voltage_amplitude()

        if not math.isclose(amplitude, new_amplitude, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(
                f"Verification failure: set {amplitude}, read {new_amplitude}"
            )
        return new_amplitude

    def get_source_voltage_sensing_mode(self) -> VoltageSensingMode:
        mode_param = self._device.query_output_sense(self._channel)
        mode = _map_driver_output_sense_to_hal_source_voltage_sensing_mode(mode_param)

        return mode

    def set_source_voltage_sensing_mode(self, mode: VoltageSensingMode) -> None:
        mode_param = _map_hal_source_voltage_sensing_mode_to_driver_output_sense(mode)
        self._device.write_output_sense(self._channel, mode_param)

        return

    def apply_source_voltage_sensing_mode(
        self, mode: VoltageSensingMode
    ) -> VoltageSensingMode:
        self.set_source_voltage_sensing_mode(mode)
        new_mode = self.get_source_voltage_sensing_mode()

        if mode != new_mode:
            raise RuntimeError(f"Verification failure: set {mode}, read {new_mode}")

        return new_mode

    def get_source_current_limit(self) -> float | int:
        amplitude = self._device.query_source_current_level_immediate_amplitude(
            self._channel
        )

        limit = amplitude

        return limit

    def set_source_current_limit(self, limit: float | int) -> None:
        if not isinstance(limit, (float, int)):
            raise TypeError("limit must be a float")

        self._device.write_source_current_level_immediate_amplitude(
            self._channel, limit
        )

        return

    def apply_source_current_limit(self, limit: float | int) -> float | int:
        self.set_source_current_limit(limit)
        new_limit = self.get_source_current_limit()

        if not math.isclose(limit, new_limit, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(f"Verification failure: set {limit}, read {new_limit}")

        return new_limit

    def get_over_current_protection_enable(self) -> bool:
        raise NotImplementedError("Not yet implemented")

    def set_over_current_protection_enable(self, enable: bool) -> None:
        if not isinstance(enable, bool):
            raise TypeError("enable must be a bool")
        raise NotImplementedError("Not yet implemented")

    def apply_over_current_protection_enable(self, enable: bool) -> bool:
        self.set_over_current_protection_enable(enable)
        new_enable = self.get_over_current_protection_enable()

        if enable != new_enable:
            raise RuntimeError(f"Verification failure: set {enable}, read {new_enable}")

        return new_enable

    def get_over_current_protection_threshold(self) -> float | int:
        raise NotImplementedError("Not yet implemented")

    def set_over_current_protection_threshold(self, threshold: float | int) -> None:
        raise NotImplementedError("Not yet implemented")

    def apply_over_current_protection_threshold(
        self, threshold: float | int
    ) -> float | int:
        self.set_over_current_protection_threshold(threshold)
        new_threshold = self.get_over_current_protection_threshold()

        if not math.isclose(threshold, new_threshold, rel_tol=1e-4, abs_tol=1e-6):
            raise RuntimeError(
                f"Verification failure: set {threshold}, read {new_threshold}"
            )

        return new_threshold

    def get_output_current_measurement(self) -> float | int:
        raise NotImplementedError("Not yet implemented")

    def get_output_voltage_measurement(self) -> float | int:
        raise NotImplementedError("Not yet implemented")

    def sync(self) -> bool:
        return True


class HALDCPowerSupplyRigolDP800(HALDCPowerSupplyRigol):
    def __init__(self, resource_name: str, channel_number: int, visa_path: str):
        super().__init__(resource_name, channel_number, visa_path)


class HALDCPowerSupplyRigolDP900(HALDCPowerSupplyRigol):
    def __init__(self, resource_name: str, channel_number: int, visa_path: str):
        super().__init__(resource_name, channel_number, visa_path)


class HALDCPowerSupplyRigolDP2000(HALDCPowerSupplyRigol):
    def __init__(self, resource_name: str, channel_number: int, visa_path: str):
        super().__init__(resource_name, channel_number, visa_path)
