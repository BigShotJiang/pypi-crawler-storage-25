from enum import Enum


class CommandSet(Enum):
    AGILENT = "AGILENT"
    FLUKE = "FLUKE"
    RIGOL = "RIGOL"


class DCCurrentRange(Enum):
    I_2mA = "0"
    I_20mA = "1"
    I_200mA = "2"
    I_1A = "3"
    I_10A = "4"
    DEF = "DEF"  # 2
    MIN = "MIN"  # 0
    MAX = "MAX"  # 4


class DCVoltageInputImpedance(Enum):
    I_10MOhm = "10M"
    I_10GOhm = "10G"


class DCVoltageRange(Enum):
    V_200mV = "0"
    V_2V = "1"
    V_20V = "2"
    V_200V = "3"
    V_1000V = "4"
    DEF = "DEF"
    MIN = "MIN"
    MAX = "MAX"


class MeasurementFunction(Enum):
    DCI = "DCI"
    DCV = "DCV"


class MeasurementMode(Enum):
    AUTO = "AUTO"
    MANUAL = "MANU"


class MeasurementInProgress(Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"


class Resolution(Enum):
    DEF = "DEF"
    MAX = "MAX"
    MIN = "MIN"
    RES_4p5 = "0"
    RES_5p5 = "1"
    RES_6p5 = "2"


class TriggerSource(Enum):
    AUTO = "AUTO"
    EXT = "EXT"
    SINGLE = "SINGLE"


class RigolDM3000:
    @classmethod
    def command_set_query(cls) -> str:
        """
        :return:
        """
        return ":CMDSET?"

    @classmethod
    def command_set_parse(cls, response: str) -> CommandSet:
        """
        :return:
        """
        response = response.strip()
        return CommandSet(response)

    @classmethod
    def command_set_write(cls, command: CommandSet) -> str:
        """
        :return:
        """
        return f":CMDSET {command.value}"

    @classmethod
    def function_query(cls) -> str:
        """
        :return:
        """
        return ":FUNC?"

    @classmethod
    def function_parse(cls, response: str) -> MeasurementFunction:
        response = response.strip()
        return MeasurementFunction(response)

    @classmethod
    def function_current_dc_write(cls) -> str:
        """
        :return:
        """
        return ":FUNC:CURR:DC"

    @classmethod
    def function_voltage_dc_write(cls) -> str:
        """
        :return:
        """
        return ":FUNC:VOLT:DC"

    @classmethod
    def measure_write(cls, mode: MeasurementMode) -> str:
        """
        :return:
        """
        return f":MEAS {mode.value}"

    @classmethod
    def measure_parse(cls, response: str) -> MeasurementInProgress:
        """
        :return:
        """
        response = response.strip()
        return MeasurementInProgress(response)

    @classmethod
    def measure_query(cls) -> str:
        """
        :return:
        """
        return ":MEAS?"

    @classmethod
    def measure_current_dc_query(cls) -> str:
        """
        :return:
        """
        return ":MEAS:CURR:DC?"

    @classmethod
    def measure_current_dc_parse(cls, response: str) -> float:
        """
        :return:
        """
        response = response.strip()
        return float(response)

    @classmethod
    def measure_current_dc_write(cls, current_range: DCCurrentRange) -> str:
        """
        :return:
        """
        return f":MEAS:CURR:DC {current_range.value}"

    @classmethod
    def measure_current_dc_range_query(cls) -> str:
        """
        :return:
        """
        return ":MEAS:CURR:DC:RANG?"

    @classmethod
    def measure_current_dc_range_parse(cls, response: str) -> DCCurrentRange:
        """
        :param response:
        :return:
        """
        response = response.strip()
        return DCCurrentRange(response)

    @classmethod
    def measure_voltage_dc_query(cls) -> str:
        """
        :return:
        """
        return ":MEAS:VOLT:DC?"

    @classmethod
    def measure_voltage_dc_parse(cls, response: str) -> float:
        """
        :return:
        """
        response = response.strip()
        return float(response)

    @classmethod
    def measure_voltage_dc_write(cls, voltage_range: DCVoltageRange) -> str:
        """
        :return:
        """
        return f":MEAS:VOLT:DC {voltage_range.value}"

    @classmethod
    def measure_voltage_dc_impedance_query(cls) -> str:
        """ """
        return ":MEAS:VOLT:DC:IMPE?"

    @classmethod
    def measure_voltage_dc_impedance_parse(
        cls, response: str
    ) -> DCVoltageInputImpedance:
        """ """
        response = response.strip()
        return DCVoltageInputImpedance(response)

    @classmethod
    def measure_voltage_dc_impedance_write(
        cls, impedance: DCVoltageInputImpedance
    ) -> str:
        """ """
        return f":MEAS:VOLT:DC:IMPE {impedance.value}"

    @classmethod
    def measure_voltage_dc_range_query(cls) -> str:
        """
        :return:
        """
        return ":MEAS:VOLT:DC:RANG?"

    @classmethod
    def measure_voltage_dc_range_parse(cls, response: str) -> DCVoltageRange:
        response = response.strip()
        return DCVoltageRange(response)

    @classmethod
    def resolution_current_dc_write(cls, resolution) -> str:
        """ """
        return f":CURR:DC:RES {resolution.value}"

    @classmethod
    def resolution_current_dc_query(cls) -> str:
        """ """
        return ":CURR:DC:RES?"

    @classmethod
    def resolution_current_dc_parse(cls, response: str) -> Resolution:
        """ """
        response = response.strip()
        return Resolution(response)

    @classmethod
    def resolution_voltage_dc_write(cls, resolution: Resolution) -> str:
        """
        :return:
        """
        return f":RESO:VOLT:DC {resolution.value}"

    @classmethod
    def resolution_voltage_dc_query(cls) -> str:
        """
        :return:
        """
        return ":VOLT:DC:RES?"

    @classmethod
    def resolution_voltage_dc_parse(cls, response: str) -> Resolution:
        """
        :return:
        """
        response = response.strip()
        return Resolution(response)

    @classmethod
    def trigger_source_write(cls, source: TriggerSource) -> str:
        """ """
        return f":TRIG:SOUR {source.value}"

    @classmethod
    def trigger_source_query(cls) -> str:
        """ """
        return ":TRIG:SOUR?"

    @classmethod
    def trigger_source_parse(cls, response: str) -> TriggerSource:
        """ """
        response = response.strip()
        return TriggerSource(response)
