# pyright: strict

from enum import Enum
from typing import Literal
import logging

from pydantic import BaseModel

from fusaware_instruments.utils import CaseInsensitiveEnum, VisaIO, ScpiParseError


# 6.25 GSa/s for MSO5 series
MAX_ANALOG_SAMPLE_RATE = 6_250_000_000

NUM_HORIZONTAL_DIVISIONS = 10

DEFAULT_OFFSET_PERCENTAGE = 50.0


class AcquisitionMode(CaseInsensitiveEnum):
    RUNSTOP = "RUNSTop"
    SEQUENCE = "SEQuence"


class AcquisitionState(Enum):
    STOP = "0"
    RUN = "1"


class AnalogChannel(Enum):
    CH1 = 1
    CH2 = 2
    CH3 = 3
    CH4 = 4
    CH5 = 5
    CH6 = 6
    CH7 = 7
    CH8 = 8


# TODO verify this, at least for voltage and current
class ProbeUnits(Enum):
    VOLTS = "V"
    AMPS = "A"
    WATTS = "W"

    # CH<x>:PRObe:UNITs? might return qstring
    @classmethod
    def _missing_(cls, value: object) -> "ProbeUnits | None":
        if value == '"V"':
            return ProbeUnits.VOLTS
        elif value == '"A"':
            return ProbeUnits.AMPS
        elif value == '"W"':
            return ProbeUnits.WATTS
        else:
            return super()._missing_(value)


class ProbeCoupling(CaseInsensitiveEnum):
    AC = "AC"
    DC = "DC"
    DCREJ = "DCREJect"


type ProbeBandwidthLimit = float | Literal["FULL"]


class WaveformSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    CH5 = "CH5"
    CH6 = "CH6"
    CH7 = "CH7"
    CH8 = "CH8"
    CH1_DAll = "CH1_DAll"
    CH2_DAll = "CH2_DAll"
    CH3_DAll = "CH3_DAll"
    CH4_DAll = "CH4_DAll"
    CH5_DAll = "CH5_DAll"
    CH6_DAll = "CH6_DAll"
    CH7_DAll = "CH7_DAll"
    CH8_DAll = "CH8_DAll"
    CH1_D0 = "CH1_D0"
    CH1_D1 = "CH1_D1"
    CH1_D2 = "CH1_D2"
    CH1_D3 = "CH1_D3"
    CH1_D4 = "CH1_D4"
    CH1_D5 = "CH1_D5"
    CH1_D6 = "CH1_D6"
    CH1_D7 = "CH1_D7"
    CH2_D0 = "CH2_D0"
    CH2_D1 = "CH2_D1"
    CH2_D2 = "CH2_D2"
    CH2_D3 = "CH2_D3"
    CH2_D4 = "CH2_D4"
    CH2_D5 = "CH2_D5"
    CH2_D6 = "CH2_D6"
    CH2_D7 = "CH2_D7"
    CH3_D0 = "CH3_D0"
    CH3_D1 = "CH3_D1"
    CH3_D2 = "CH3_D2"
    CH3_D3 = "CH3_D3"
    CH3_D4 = "CH3_D4"
    CH3_D5 = "CH3_D5"
    CH3_D6 = "CH3_D6"
    CH3_D7 = "CH3_D7"
    CH4_D0 = "CH4_D0"
    CH4_D1 = "CH4_D1"
    CH4_D2 = "CH4_D2"
    CH4_D3 = "CH4_D3"
    CH4_D4 = "CH4_D4"
    CH4_D5 = "CH4_D5"
    CH4_D6 = "CH4_D6"
    CH4_D7 = "CH4_D7"
    CH5_D0 = "CH5_D0"
    CH5_D1 = "CH5_D1"
    CH5_D2 = "CH5_D2"
    CH5_D3 = "CH5_D3"
    CH5_D4 = "CH5_D4"
    CH5_D5 = "CH5_D5"
    CH5_D6 = "CH5_D6"
    CH5_D7 = "CH5_D7"
    CH6_D0 = "CH6_D0"
    CH6_D1 = "CH6_D1"
    CH6_D2 = "CH6_D2"
    CH6_D3 = "CH6_D3"
    CH6_D4 = "CH6_D4"
    CH6_D5 = "CH6_D5"
    CH6_D6 = "CH6_D6"
    CH6_D7 = "CH6_D7"
    CH7_D0 = "CH7_D0"
    CH7_D1 = "CH7_D1"
    CH7_D2 = "CH7_D2"
    CH7_D3 = "CH7_D3"
    CH7_D4 = "CH7_D4"
    CH7_D5 = "CH7_D5"
    CH7_D6 = "CH7_D6"
    CH7_D7 = "CH7_D7"
    CH8_D0 = "CH8_D0"
    CH8_D1 = "CH8_D1"
    CH8_D2 = "CH8_D2"
    CH8_D3 = "CH8_D3"
    CH8_D4 = "CH8_D4"
    CH8_D5 = "CH8_D5"
    CH8_D6 = "CH8_D6"
    CH8_D7 = "CH8_D7"
    MATH1 = "MATH1"
    MATH2 = "MATH2"
    MATH3 = "MATH3"
    MATH4 = "MATH4"
    REF1 = "REF1"
    REF2 = "REF2"
    REF3 = "REF3"
    REF4 = "REF4"
    REF5 = "REF5"
    REF6 = "REF6"
    REF7 = "REF7"
    REF8 = "REF8"
    DIGITAL_ALL = "DIGITALALL"


class ImageFormat(Enum):
    """
    Image formats supported by ``SAVe:IMAGe``.

    On the MSO5 series, ``SAVe:IMAGe`` infers the output format from the file
    extension in the quoted path argument — there is no ``SAVe:IMAGe:FILEFormat``
    SCPI command. (The separate ``SAVEON:IMAGe:FILEFormat`` command exists but
    only governs what happens during Save-On-Event triggers, not on-demand
    screenshot captures.) The enum values here are the exact lowercase
    extensions the driver appends to the save path.

    See programming guide 2-617 (SAVe:IMAGe).
    """

    PNG = "png"
    BMP = "bmp"
    JPG = "jpg"


class ChannelDisplayState(Enum):
    OFF = "0"
    ON = "1"


class TriggerCoupling(Enum):
    DC = "DC"
    HFREJ = "HFRej"
    LFREJ = "LFRej"
    NOISEREJ = "NOISErej"

    # TODO: verify the exact query response strings from a real MSO5 instrument.
    # The MSO5 manual lists HFRej/LFRej/NOISErej as write values; the instrument
    # may return abbreviated forms ("HFR", "LFR", "NOISE") as MDO3 does.
    @classmethod
    def _missing_(cls, value: object) -> "TriggerCoupling | None":
        if isinstance(value, str):
            match value:
                case "HFR" | "HFREJ":
                    return TriggerCoupling.HFREJ
                case "LFR" | "LFREJ":
                    return TriggerCoupling.LFREJ
                case "NOISE" | "NOISEREJ":
                    return TriggerCoupling.NOISEREJ
                case _:
                    return None

        return None


class TriggerSlope(CaseInsensitiveEnum):
    RISE = "RISe"
    FALL = "FALL"
    EITHER = "EITher"


class TriggerSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    CH5 = "CH5"
    CH6 = "CH6"
    CH7 = "CH7"
    CH8 = "CH8"
    CH1_D0 = "CH1_D0"
    CH1_D1 = "CH1_D1"
    CH1_D2 = "CH1_D2"
    CH1_D3 = "CH1_D3"
    CH1_D4 = "CH1_D4"
    CH1_D5 = "CH1_D5"
    CH1_D6 = "CH1_D6"
    CH1_D7 = "CH1_D7"
    CH2_D0 = "CH2_D0"
    CH2_D1 = "CH2_D1"
    CH2_D2 = "CH2_D2"
    CH2_D3 = "CH2_D3"
    CH2_D4 = "CH2_D4"
    CH2_D5 = "CH2_D5"
    CH2_D6 = "CH2_D6"
    CH2_D7 = "CH2_D7"
    CH3_D0 = "CH3_D0"
    CH3_D1 = "CH3_D1"
    CH3_D2 = "CH3_D2"
    CH3_D3 = "CH3_D3"
    CH3_D4 = "CH3_D4"
    CH3_D5 = "CH3_D5"
    CH3_D6 = "CH3_D6"
    CH3_D7 = "CH3_D7"
    CH4_D0 = "CH4_D0"
    CH4_D1 = "CH4_D1"
    CH4_D2 = "CH4_D2"
    CH4_D3 = "CH4_D3"
    CH4_D4 = "CH4_D4"
    CH4_D5 = "CH4_D5"
    CH4_D6 = "CH4_D6"
    CH4_D7 = "CH4_D7"
    CH5_D0 = "CH5_D0"
    CH5_D1 = "CH5_D1"
    CH5_D2 = "CH5_D2"
    CH5_D3 = "CH5_D3"
    CH5_D4 = "CH5_D4"
    CH5_D5 = "CH5_D5"
    CH5_D6 = "CH5_D6"
    CH5_D7 = "CH5_D7"
    CH6_D0 = "CH6_D0"
    CH6_D1 = "CH6_D1"
    CH6_D2 = "CH6_D2"
    CH6_D3 = "CH6_D3"
    CH6_D4 = "CH6_D4"
    CH6_D5 = "CH6_D5"
    CH6_D6 = "CH6_D6"
    CH6_D7 = "CH6_D7"
    CH7_D0 = "CH7_D0"
    CH7_D1 = "CH7_D1"
    CH7_D2 = "CH7_D2"
    CH7_D3 = "CH7_D3"
    CH7_D4 = "CH7_D4"
    CH7_D5 = "CH7_D5"
    CH7_D6 = "CH7_D6"
    CH7_D7 = "CH7_D7"
    CH8_D0 = "CH8_D0"
    CH8_D1 = "CH8_D1"
    CH8_D2 = "CH8_D2"
    CH8_D3 = "CH8_D3"
    CH8_D4 = "CH8_D4"
    CH8_D5 = "CH8_D5"
    CH8_D6 = "CH8_D6"
    CH8_D7 = "CH8_D7"
    LINE = "LINE"
    AUX = "AUXiliary"

    @classmethod
    def _missing_(cls, value: object) -> "TriggerSource | None":
        if isinstance(value, str):
            if value == "AUXILIARY" or value == "AUX":
                return TriggerSource.AUX

        return None


class TriggerMode(CaseInsensitiveEnum):
    AUTO = "AUTO"
    NORMAL = "NORMal"


class TriggerType(CaseInsensitiveEnum):
    EDGE = "EDGE"
    WIDTH = "WIDth"
    TIMEOUT = "TIMEOut"
    RUNT = "RUNT"
    WINDOW = "WINdow"
    LOGIC = "LOGIc"
    SETHOLD = "SETHold"
    TRANSITION = "TRANsition"
    BUS = "BUS"


class WaveformEncoding(CaseInsensitiveEnum):
    """
    WFMOutpre:ENCdg response values. The enum is case-insensitive on responses
    and also accepts Tek SCPI short forms (e.g. ``ASC`` / ``BIN``).
    """

    ASCII = "ASCii"
    BINARY = "BINary"


class BinaryFormat(Enum):
    RI = "RI"
    RP = "RP"
    FP = "FP"


class WaveformByteOrder(Enum):
    MSB = "MSB"
    LSB = "LSB"


class DataEncoding(CaseInsensitiveEnum):
    """
    DATa:ENCdg encoding types.

    A convenience enum that sets WFMOutpre:ENCdg, WFMOutpre:BN_Fmt, and
    WFMOutpre:BYT_Or together with a single command.
    """

    ASCII = "ASCIi"
    RIBINARY = "RIBinary"  # signed integer, MSB first
    RPBINARY = "RPBinary"  # unsigned integer, MSB first
    FPBINARY = "FPbinary"  # 32-bit float, MSB first
    SRIBINARY = "SRIbinary"  # signed integer, LSB first
    SRPBINARY = "SRPbinary"  # unsigned integer, LSB first
    SFPBINARY = "SFPbinary"  # 32-bit float, LSB first


class DelayModeState(Enum):
    OFF = "OFF"
    ON = "ON"


class HorizontalMode(Enum):
    """HORizontal:MODE values — see programming guide 2-349."""

    AUTO = "AUTO"
    MANUAL = "MANUAL"

    @classmethod
    def _missing_(cls, value: object) -> "HorizontalMode | None":
        if isinstance(value, str):
            upper = value.upper()
            if upper in ("MAN", "MANUAL"):
                return HorizontalMode.MANUAL
            if upper == "AUTO":
                return HorizontalMode.AUTO
        return None


class DisplayViewstyle(str, Enum):
    OVERLAY = "OVErlay"
    STACKED = "STacked"

    @classmethod
    def _missing_(cls, value: object) -> "DisplayViewstyle | None":
        if isinstance(value, str):
            upper = value.upper()
            if upper in ("OVE", "OVERLAY"):
                return DisplayViewstyle.OVERLAY
            if upper in ("ST", "STACKED"):
                return DisplayViewstyle.STACKED
        return None


class HorizontalModeManualConfigure(CaseInsensitiveEnum):
    """
    HORizontal:MODe:MANual:CONFIGure values — see programming guide 2-351.

    Selects which horizontal control the instrument will adjust as a side
    effect of writing :py:meth:`write_horizontal_sample_rate` while in
    ``HorizontalMode.MANUAL``:

    * ``HORIZONTAL_SCALE`` (instrument default): writing sample rate will
      also move the horizontal scale (s/div).
    * ``RECORD_LENGTH``: writing sample rate will also move record length,
      leaving the horizontal scale untouched.
    """

    HORIZONTAL_SCALE = "HORIZontalscale"
    RECORD_LENGTH = "RECORDLength"


class ProbeType(Enum):
    TPP0500B = "TPP0500B"
    TPP1000 = "TPP1000"
    TPP0250 = "TPP0250"
    TCP0020 = "TCP0020"
    TCP0030 = "TCP0030"
    TCP0030A = "TCP0030A"
    TCP0150 = "TCP0150"
    TMDP0200 = "TMDP0200"
    NONE = "No probe detected"
    UNKNOWN = "unknown"


class ProbeID(BaseModel):
    probe_type: ProbeType
    name: str


class TektronixMso5SeriesDriver:
    io: VisaIO

    def __init__(self, io: VisaIO) -> None:
        self.io = io

    def query_acquire_state(self) -> AcquisitionState:
        """
        ACQuire:STATE?
        """
        query = ":ACQ:STATE?"
        resp = self.io.query(query).strip()

        try:
            return AcquisitionState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_acquire_state(self, state: AcquisitionState) -> None:
        """
        ACQuire:STATE {OFF|ON|RUN|STOP|<NR1>}
        """
        command = f":ACQ:STATE {state.value}"
        self.io.write(command)

    def query_acquire_stopafter(self) -> AcquisitionMode:
        """
        ACQuire:STOPAfter?
        """
        query = ":ACQ:STOPA?"
        resp = self.io.query(query).strip()

        try:
            return AcquisitionMode(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_acquire_stopafter(self, mode: AcquisitionMode) -> None:
        """
        ACQuire:STOPAfter {RUNSTop|SEQuence}
        """
        command = f":ACQ:STOPA {mode.value}"
        self.io.write(command)

    def query_channel_bandwidth(self, channel: AnalogChannel) -> ProbeBandwidthLimit:
        """
        CH<x>:BANdwidth {FULl|<NR3>}
        CH<x>:BANdwidth?
        """
        query = f":CH{channel.value}:BAN?"
        resp = self.io.query(query).strip()

        try:
            if resp == "FULL" or resp == "FULl" or resp == "FUL":
                return "FULL"
            else:
                return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_bandwidth(
        self, channel: AnalogChannel, bandwidth: ProbeBandwidthLimit
    ) -> None:
        """
        CH<x>:BANdwidth {FULl|<NR3>}
        """
        match bandwidth:
            case "FULL":
                bw_str = "FULL"
            case float() | int():
                bw_str = str(bandwidth)

        command = f":CH{channel.value}:BAN {bw_str}"
        self.io.write(command)

    def query_channel_coupling(self, channel: AnalogChannel) -> ProbeCoupling:
        """
        CH<x>:COUPling?
        """
        query = f":CH{channel.value}:COUP?"
        resp = self.io.query(query).strip()

        try:
            return ProbeCoupling(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_coupling(
        self, channel: AnalogChannel, coupling: ProbeCoupling
    ) -> None:
        """
        CH<x>:COUPling {AC|DC|DCREJect}
        """
        command = f":CH{channel.value}:COUP {coupling.value}"
        self.io.write(command)

    def query_channel_offset(self, channel: AnalogChannel) -> float:
        """
        CH<x>:OFFSet?
        """
        query = f":CH{channel.value}:OFFS?"

        resp = self.io.query(query)

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_offset(self, channel: AnalogChannel, offset: float) -> None:
        """
        CH<x>:OFFSet <NR3>
        """
        command = f":CH{channel.value}:OFFS {offset}"
        self.io.write(command)

    def query_channel_position(self, channel: AnalogChannel) -> float:
        """
        CH<x>:POSition?
        """
        query = f":CH{channel.value}:POS?"

        resp = self.io.query(query)

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_position(self, channel: AnalogChannel, position: float) -> None:
        """
        CH<x>:POSition <NR3>
        """
        command = f":CH{channel.value}:POS {position}"
        self.io.write(command)

    def query_channel_probe_gain(self, channel: AnalogChannel) -> float:
        """
        CH<x>:PRObe:GAIN? (Query-only)

        On the MSO5 series this command is *query-only* — the gain is a property
        of the connected probe hardware and cannot be set over SCPI. To change
        the effective attenuation of a user-configurable probe, use
        ``CH<x>:PRObe:SET "ATTENUATION <factor>"``. See programming guide 2-202.
        """
        query = f":CH{channel.value}:PRO:GAIN?"

        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_probe_set(self, channel: AnalogChannel, setting: str) -> None:
        """
        CH<x>:PRObe:SET "<QString>"

        Sets probe-accessory settings as an opaque quoted string. Available
        arguments are probe-dependent — e.g. ``"ATTENUATION 5X"`` on probes
        that support user-settable attenuation. Most Level 0/1 passive probes
        expose no settable aspects and will silently ignore this command.
        See programming guide 2-199.
        """
        command = f':CH{channel.value}:PRO:SET "{setting}"'
        self.io.write(command)

    def query_channel_probe_units(self, channel: AnalogChannel) -> ProbeUnits:
        """
        CH<x>:PRObe:UNIts?
        Query-only — units are set by the probe hardware.
        """
        query = f":CH{channel.value}:PRO:UNI?"
        resp = self.io.query(query).strip()

        try:
            return ProbeUnits(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_channel_scale(self, channel: AnalogChannel) -> float:
        """
        CH<x>:SCAle?
        """
        query = f":CH{channel.value}:SCA?"

        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_scale(self, channel: AnalogChannel, scale: float) -> None:
        """
        CH<x>:SCAle <NR3>
        """
        command = f":CH{channel.value}:SCA {scale}"
        self.io.write(command)

    def query_channel_probe_type(self, channel: AnalogChannel) -> ProbeType:
        """
        CH<x>:PRObe:ID:TYPe?
        Returns the type of probe attached to the channel.
        """
        query = f":CH{channel.value}:PRO:ID:TYP?"
        resp = self.io.query(query).strip().replace('"', "")

        try:
            return ProbeType(resp)
        except ValueError:
            logging.warning(f"Unrecognized probe type: '{resp}'")
            return ProbeType.UNKNOWN

    def query_channel_probe_id(self, channel: AnalogChannel) -> ProbeID:
        """
        Returns ProbeID for the given channel.
        """
        probe_type = self.query_channel_probe_type(channel)
        return ProbeID(probe_type=probe_type, name=probe_type.value)

    def query_channel_display_state(
        self, channel: AnalogChannel
    ) -> ChannelDisplayState:
        """
        DISplay:GLObal:CH<x>:STATE?
        """
        query = f":DISP:GLOB:CH{channel.value}:STATE?"
        resp = self.io.query(query).strip()

        try:
            return ChannelDisplayState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_display_state(
        self, channel: AnalogChannel, state: ChannelDisplayState
    ) -> None:
        """
        DISplay:GLObal:CH<x>:STATE {ON|OFF|<NR1>}
        """
        command = f":DISP:GLOB:CH{channel.value}:STATE {state.value}"
        self.io.write(command)

    def query_curve(self) -> str:
        """
        CURVe?
        """
        query = ":CURV?"
        resp = self.io.query(query).strip()
        return resp

    def query_curve_binary(self) -> bytes:
        """
        CURVe? (binary encoding)

        Call this after setting DATa:ENCdg to a binary format. Writes the
        query and reads the raw IEEE 488.2 block response from the instrument.
        Returns the decoded payload bytes (block header stripped).

        Block format is #<x><yyy><data><newline>
        """
        self.io.write(":CURV?")
        header_start = self.io.read_bytes(2)
        if header_start[0] != ord("#"):
            raise ScpiParseError(
                response=str(header_start),
                query=":CURV?",
                message=f"Expected '#' at start of IEEE 488.2 block, got {header_start[0]}",
            )

        header_str = header_start.decode("ascii")
        # 'x' field in block data format is hexidecimal
        n = int(header_str[1], 16)

        num_bytes_raw = self.io.read_bytes(n)
        num_bytes_str = num_bytes_raw.decode("ascii")
        num_bytes = int(num_bytes_str)

        payload = self.io.read_bytes(num_bytes)

        return payload

    def query_data_source(self) -> WaveformSource:
        """
        DATa:SOUrce?
        """
        query = ":DAT:SOU?"
        resp = self.io.query(query).strip()

        try:
            return WaveformSource(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_source(self, source: WaveformSource) -> None:
        """
        DATa:SOUrce {source}
        """
        command = f":DAT:SOU {source.value}"
        self.io.write(command)

    def query_data_start(self) -> int:
        """
        DATa:STARt?
        """
        query = ":DAT:STAR?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_start(self, start: int) -> None:
        """
        DATa:STARt {start}
        """
        command = f":DAT:STAR {start}"
        self.io.write(command)

    def query_data_stop(self) -> int:
        """
        DATa:STOP?
        """
        query = ":DAT:STOP?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_stop(self, stop: int) -> None:
        """
        DATa:STOP {stop}
        """
        command = f":DAT:STOP {stop}"
        self.io.write(command)

    def query_data_encoding(self) -> DataEncoding:
        """
        DATa:ENCdg?
        """
        query = ":DAT:ENC?"
        resp = self.io.query(query).strip()

        try:
            return DataEncoding(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_encoding(self, encoding: DataEncoding) -> None:
        """
        DATa:ENCdg {ASCIi|FAStest|RIBinary|RPBinary|SRIbinary|SRPbinary|FPbinary|SFPbinary}

        Sets WFMOutpre:ENCdg, WFMOutpre:BN_Fmt, and WFMOutpre:BYT_Or atomically.
        """
        command = f":DAT:ENC {encoding.value}"
        self.io.write(command)

    def query_filesystem_cwd(self) -> str:
        """
        FILESystem:CWD?
        """
        query = ":FILES:CWD?"
        return self.io.query(query).strip().replace('"', "")

    def write_filesystem_cwd(self, path: str) -> None:
        """
        FILESystem:CWD {<new working directory path>}
        """
        command = f':FILES:CWD "{path}"'
        self.io.write(command)

    def write_file_delete(self, path: str) -> None:
        """
        FILESystem:DELEte {path}
        """
        command = f':FILES:DELE "{path}"'
        self.io.write(command)

    def write_file_read(self, path: str) -> None:
        """
        FILESystem:READFile {path}

        Sends the read command; call io.read_raw() afterwards to retrieve the data.
        """
        command = f':FILES:READFile "{path}"'
        self.io.write(command)

    def query_horizontal_position(self) -> float:
        """
        HORizontal:POSition?
        """
        query = ":HOR:POS?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_position(self, position: float) -> None:
        """
        HORizontal:POSition <NR3>
        """
        command = f":HOR:POS {position}"
        self.io.write(command)

    def query_horizontal_delay_mode(self) -> DelayModeState:
        """
        HORizontal:DELay:MODe?
        """
        query = ":HOR:DEL:MOD?"
        resp = self.io.query(query).strip()

        try:
            return DelayModeState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_delay_mode(self, state: DelayModeState) -> None:
        """
        HORizontal:DELay:MODe {OFF|ON|<NR1>}
        """
        command = f":HOR:DEL:MOD {state.value}"
        self.io.write(command)

    def query_horizontal_mode(self) -> HorizontalMode:
        """
        HORizontal:MODE?
        """
        query = ":HOR:MODE?"
        resp = self.io.query(query).strip()

        try:
            return HorizontalMode(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_mode(self, mode: HorizontalMode) -> None:
        """
        HORizontal:MODE {AUTO|MANual}

        AUTO: scope chooses sample rate and record length (record length is
        read-only in this mode). MANUAL: caller can set sample rate, record
        length, and horizontal scale independently. See programming guide 2-349.
        """
        command = f":HOR:MODE {mode.value}"
        self.io.write(command)

    def query_horizontal_sample_rate(self) -> float:
        """
        HORizontal:MODE:SAMPLERate?
        """
        query = ":HOR:MODE:SAMPLER?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_sample_rate(self, sample_rate: float) -> None:
        """
        HORizontal:MODE:SAMPLERate <NR1>

        Settable on MSO5 (unlike MDO3 where the equivalent is query-only). Only
        takes effect while the instrument is in Manual horizontal mode. See
        programming guide 2-351.

        Writing sample rate also implicitly moves one of horizontal scale or
        record length; which one is selected by
        :py:meth:`write_horizontal_manual_configure`.
        """
        command = f":HOR:MODE:SAMPLER {sample_rate}"
        self.io.write(command)

    def query_horizontal_manual_configure(self) -> HorizontalModeManualConfigure:
        """
        HORizontal:MODe:MANual:CONFIGure?

        Returns which horizontal control absorbs the side effect of a sample
        rate write in Manual mode. See programming guide 2-351.
        """
        query = ":HOR:MODE:MAN:CONFIG?"
        resp = self.io.query(query).strip()

        try:
            return HorizontalModeManualConfigure(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_manual_configure(
        self, configure: HorizontalModeManualConfigure
    ) -> None:
        """
        HORizontal:MODe:MANual:CONFIGure {HORIZontalscale|RECORDLength}

        Selects whether horizontal scale or record length changes when sample
        rate is adjusted in Manual mode. See programming guide 2-351.
        """
        command = f":HOR:MODE:MAN:CONFIG {configure.value}"
        self.io.write(command)

    def query_horizontal_main_delay_time(self) -> float:
        """
        HORizontal:DELay:TIMe?
        """
        query = ":HOR:DEL:TIM?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_main_delay_time(self, offset: float) -> None:
        """
        HORizontal:DELay:TIMe <NR3>
        """
        command = f":HOR:DEL:TIM {offset}"
        self.io.write(command)

    def query_horizontal_mode_scale(self) -> float:
        """
        HORizontal:MODE:SCAle?
        """
        query = ":HOR:MODE:SCA?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_mode_scale(self, scale: float) -> None:
        """
        HORizontal:MODE:SCAle {scale}
        """
        command = f":HOR:MODE:SCA {scale}"
        self.io.write(command)

    def query_horizontal_record_length(self) -> int:
        """
        HORizontal:MODE:RECOrdlength?

        Always queryable. See programming guide 2-351.
        """
        query = ":HOR:MODE:RECO?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_record_length(self, length: int) -> None:
        """
        HORizontal:MODE:RECOrdlength <NR1>

        Note: the instrument must be in Manual horizontal mode (see
        :py:meth:`write_horizontal_mode`) to change record length; otherwise
        this command is a no-op. Callers that want "set record length now"
        semantics should set mode to MANUAL first.
        """
        command = f":HOR:MODE:RECO {length}"
        self.io.write(command)

    def query_opc(self) -> int:
        """
        *OPC?
        """
        query = "*OPC?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_save_image(self, path: str) -> None:
        """
        SAVe:IMAGe "<path>"

        Saves a screenshot of the instrument display to the given file path on
        the *instrument's* local filesystem. The image format is inferred from
        the file extension (``.png`` / ``.bmp`` / ``.jpg``).

        There is no ``SAVe:IMAGe:FILEFormat`` SCPI command on the MSO5 series,
        so there is no corresponding query or format setter; the format is
        chosen exclusively by the extension of ``path``. See programming guide
        2-617.
        """
        command = f':SAV:IMAG "{path}"'
        self.io.write(command)

    def query_trigger_edge_coupling(self) -> TriggerCoupling:
        """
        TRIGger:A:EDGE:COUPling?
        """
        query = ":TRIG:A:EDGE:COUP?"
        resp = self.io.query(query).strip()

        try:
            return TriggerCoupling(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_coupling(self, coupling: TriggerCoupling) -> None:
        """
        TRIGger:A:EDGE:COUPling {DC|HFRej|LFRej|NOISErej}
        """
        command = f":TRIG:A:EDGE:COUP {coupling.value}"
        self.io.write(command)

    def query_trigger_edge_slope(self) -> TriggerSlope:
        """
        TRIGger:A:EDGE:SLOpe?
        """
        query = ":TRIG:A:EDGE:SLO?"
        resp = self.io.query(query).strip()

        try:
            return TriggerSlope(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_slope(self, slope: TriggerSlope) -> None:
        """
        TRIGger:A:EDGE:SLOpe {RISe|FALL|EITher}
        """
        command = f":TRIG:A:EDGE:SLO {slope.value}"
        self.io.write(command)

    def query_trigger_edge_source(self) -> TriggerSource:
        """
        TRIGger:A:EDGE:SOUrce?
        """
        query = ":TRIG:A:EDGE:SOU?"
        resp = self.io.query(query).strip()

        try:
            return TriggerSource(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_source(self, source: TriggerSource) -> None:
        """
        TRIGger:A:EDGE:SOUrce {CH<x>|LINE|AUXiliary}
        """
        command = f":TRIG:A:EDGE:SOU {source.value}"
        self.io.write(command)

    def query_trigger_holdoff_time(self) -> float:
        """
        TRIGger:A:HOLDoff:TIMe?
        """
        query = ":TRIG:A:HOLDO:TIM?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_holdoff_time(self, time: float) -> None:
        """
        TRIGger:A:HOLDoff:TIMe {time}
        """
        command = f":TRIG:A:HOLDO:TIM {time}"
        self.io.write(command)

    def query_trigger_level(self, channel: AnalogChannel) -> float:
        """
        TRIGger:A:LEVel:{channel}?
        """
        query = f":TRIG:A:LEV:CH{channel.value}?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_level(self, channel: AnalogChannel, level: float) -> None:
        """
        TRIGger:A:LEVel:{channel} {level}
        """
        command = f":TRIG:A:LEV:CH{channel.value} {level}"
        self.io.write(command)

    def query_trigger_mode(self) -> TriggerMode:
        """
        TRIGger:A:MODe?
        """
        query = ":TRIG:A:MOD?"
        resp = self.io.query(query).strip()

        try:
            return TriggerMode(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_mode(self, mode: TriggerMode) -> None:
        """
        TRIGger:A:MODe {AUTO|NORMal}
        """
        command = f":TRIG:A:MOD {mode.value}"
        self.io.write(command)

    def query_trigger_type(self) -> TriggerType:
        """
        TRIGger:A:TYPe?
        """
        query = ":TRIG:A:TYP?"
        resp = self.io.query(query).strip()

        try:
            return TriggerType(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_type(self, type: TriggerType) -> None:
        """
        TRIGger:A:TYPe {EDGE|WIDth|TIMEOut|RUNt|WINdow|LOGIc|SETHold|TRANsition|BUS}

        See programming guide 2-728.
        """
        command = f":TRIG:A:TYP {type.value}"
        self.io.write(command)

    def query_waveform_bit_nr(self) -> int:
        """
        WFMOutpre:BIT_Nr?
        """
        query = ":WFMO:BIT_N?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_binary_format(self) -> BinaryFormat:
        """
        WFMOutpre:BN_Fmt?
        """
        query = ":WFMO:BN_F?"
        resp = self.io.query(query).strip()

        try:
            return BinaryFormat(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_byte_nr(self) -> int:
        """
        WFMOutpre:BYT_Nr?
        """
        query = ":WFMO:BYT_N?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_byte_nr(self, byte_nr: int) -> None:
        """
        WFMOutpre:BYT_Nr {1|2}
        """
        command = f":WFMO:BYT_N {byte_nr}"
        self.io.write(command)

    def query_waveform_byte_order(self) -> WaveformByteOrder:
        """
        WFMOutpre:BYT_Or?
        """
        query = ":WFMO:BYT_O?"
        resp = self.io.query(query).strip()

        try:
            return WaveformByteOrder(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_byte_order(self, order: WaveformByteOrder) -> None:
        """
        WFMOutpre:BYT_Or {MSB|LSB}
        """
        command = f":WFMO:BYT_O {order.value}"
        self.io.write(command)

    def query_waveform_encoding(self) -> WaveformEncoding:
        """
        WFMOutpre:ENCdg?
        """
        query = ":WFMO:ENC?"
        resp = self.io.query(query).strip()

        try:
            return WaveformEncoding(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_encoding(self, encoding: WaveformEncoding) -> None:
        """
        WFMOutpre:ENCdg {encoding}
        """
        command = f":WFMO:ENC {encoding.value}"
        self.io.write(command)

    def query_waveform_nr_points(self) -> int:
        """
        WFMOutpre:NR_Pt?
        """
        query = ":WFMO:NR_P?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_id(self) -> str:
        """
        WFMOutpre:WFId?
        """
        query = ":WFMO:WFI?"
        return self.io.query(query).strip()

    def query_waveform_x_increment(self) -> float:
        """
        WFMOutpre:XINcr?
        """
        query = ":WFMO:XIN?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_x_unit(self) -> str:
        """
        WFMOutpre:XUNit?
        """
        query = ":WFMO:XUN?"
        return self.io.query(query).strip()

    def query_waveform_x_zero(self) -> float:
        """
        WFMOutpre:XZEro?
        """
        query = ":WFMO:XZE?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_multiplier(self) -> float:
        """
        WFMOutpre:YMUlt?
        """
        query = ":WFMO:YMU?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_offset(self) -> float:
        """
        WFMOutpre:YOFf?
        """
        query = ":WFMO:YOF?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_unit(self) -> ProbeUnits:
        """
        WFMOutpre:YUNit?
        """
        query = ":WFMO:YUN?"
        resp = self.io.query(query).strip().replace('"', "")

        try:
            return ProbeUnits(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_zero(self) -> float:
        """
        WFMOutpre:YZEro?
        """
        query = ":WFMO:YZE?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_display_waveview_viewstyle(self) -> DisplayViewstyle:
        """
        DISplay:WAVEView<x>:VIEWStyle
        programming guide, page 2-309
        'x' must be '1'
        """
        query = ":DISplay:WAVEView1:VIEWStyle?"
        resp = self.io.query(query).strip()

        try:
            return DisplayViewstyle(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_display_waveview_viewstyle(self, viewstyle: DisplayViewstyle) -> None:
        """
        DISplay:WAVEView<x>:VIEWStyle
        programming guide, page 2-309
        'x' must be '1'
        """
        command = f":DISPLAY:WAVEVIEW1:VIEWSTYLE {viewstyle.value}"
        self.io.write(command)

    def query_header(self) -> bool:
        """
        HEADer
        programming guide, page 2-338
        """
        query = ":HEAD?"
        resp = self.io.query(query).strip()

        return resp == "1"

    def write_header(self, on: bool) -> None:
        """
        HEADer
        programming guide, page 2-338
        """
        command = f":HEAD {'1' if on else '0'}"
        self.io.write(command)

    def query_verbose(self) -> bool:
        """
        VERBose
        programming guide, page 2-886
        """
        query = ":VERB?"
        resp = self.io.query(query).strip()

        return resp == "1"

    def write_verbose(self, on: bool) -> None:
        """
        VERBose
        programming guide, page 2-886
        """
        command = f":VERB {'1' if on else '0'}"
        self.io.write(command)
