from enum import Enum


class DCCurrentRange(Enum):
    RNG_10uA = 10e-6
    RNG_100uA = 100e-6
    RNG_1mA = 1e-3
    RNG_10mA = 10e-3
    RNG_100mA = 100e-3
    RNG_1A = 1
    RNG_3A = 3
    RNG_10A = 10  # rear terminals only


class DCVoltageInputImpedance(Enum):
    I_10MOhm = 10e6
    I_10GOhm = 10e9


class DCVoltageRange(Enum):
    RNG_100mV = 100e-3
    RNG_1V = 1
    RNG_10V = 10
    RNG_100V = 100
    RNG_1000V = 1000


class DisplayDigit(Enum):
    DEF = "DEF"
    MIN = "MIN"
    MAX = "MAX"
    DIGIT_3p5 = "3"
    DIGIT_4p5 = "4"
    DIGIT_5p5 = "5"
    DIGIT_6p5 = "6"


class MeasurementFunction(Enum):
    CURR_AC = "CURR:AC"
    CURR_DC = "CURR:DC"
    VOLT_AC = "VOLT:AC"
    VOLT_DC = "VOLT:DC"


class CommandSet(Enum):
    SCPI = "SCPI"
    TSP = "TSP"
    SCPI2000 = "SCPI2000"
    SCPI34401 = "SCPI34401"


class Terminals(Enum):
    FRONT = "FRON"
    REAR = "REAR"


class KeithleyDMM6500:
    @classmethod
    def display_function_digits_query(cls, function: MeasurementFunction) -> str:
        return f":DISP:{function.value}:DIG?"

    @classmethod
    def display_function_digits_parse(cls, response: str) -> DisplayDigit:
        response = response.strip()
        return DisplayDigit(response)

    @classmethod
    def display_function_digits_write(
        cls, function: MeasurementFunction, digits: DisplayDigit
    ) -> str:
        return f":DISP:{function.value}:DIG {digits.value}"

    @classmethod
    def sense_function_aperture_query(cls, function: MeasurementFunction) -> str:
        return f":SENS:{function.value}:APER?"

    @classmethod
    def sense_function_aperture_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def sense_function_aperture_write(
        cls, function: MeasurementFunction, aperture: float
    ) -> str:
        return f":SENS:{function.value}:APER {aperture}"

    @classmethod
    def sense_function_nplcycles_query(cls, function: MeasurementFunction) -> str:
        return f":SENS:{function.value}:NPLC?"

    @classmethod
    def sense_function_nplcycles_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def sense_function_nplcycles_write(
        cls, function: MeasurementFunction, nplcs: float
    ) -> str:
        return f":SENS:{function.value}:NPLC {nplcs}"

    @classmethod
    def sense_function_dc_voltage_input_impedance_query(cls) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:INP?"

    @classmethod
    def sense_function_dc_voltage_input_impedance_parse(
        cls, response: str
    ) -> DCVoltageInputImpedance:
        response = response.strip()
        return DCVoltageInputImpedance(response)

    @classmethod
    def sense_function_dc_voltage_input_impedance_write(
        cls, impedance: DCVoltageInputImpedance
    ) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:INP {impedance.value}"

    @classmethod
    def sense_dc_current_range_auto_query(cls) -> str:
        return f":SENS:{MeasurementFunction.CURR_DC.value}:RANG:AUTO?"

    @classmethod
    def sense_dc_current_range_auto_parse(cls, response: str) -> bool:
        response = response.strip()

        match response:
            case "1" | "ON":
                return True
            case "0" | "OFF":
                return False
            case _:
                raise ValueError(f"Invalid response for auto range: {response}")

    @classmethod
    def sense_dc_current_range_auto_write(cls, enable: bool) -> str:
        return f":SENS:{MeasurementFunction.CURR_DC.value}:RANG:AUTO {'1' if enable else '0'}"

    @classmethod
    def sense_dc_current_range_upper_query(cls) -> str:
        return f":SENS:{MeasurementFunction.CURR_DC.value}:RANG?"

    @classmethod
    def sense_dc_current_range_upper_parse(cls, response: str) -> DCCurrentRange:
        response = response.strip()
        return DCCurrentRange(float(response))

    @classmethod
    def sense_dc_current_range_upper_write(cls, voltage_range: DCCurrentRange) -> str:
        return f":SENS:{MeasurementFunction.CURR_DC.value}:RANG {voltage_range.value}"

    @classmethod
    def sense_dc_voltage_range_auto_query(cls) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:RANG:AUTO?"

    @classmethod
    def sense_dc_voltage_range_auto_parse(cls, response: str) -> bool:
        response = response.strip()

        match response:
            case "1" | "ON":
                return True
            case "0" | "OFF":
                return False
            case _:
                raise ValueError(f"Invalid response for auto range: {response}")

    @classmethod
    def sense_dc_voltage_range_auto_write(cls, enable: bool) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:RANG:AUTO {'1' if enable else '0'}"

    @classmethod
    def sense_dc_voltage_range_upper_query(cls) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:RANG?"

    @classmethod
    def sense_dc_voltage_range_upper_parse(cls, response: str) -> DCVoltageRange:
        response = response.strip()
        return DCVoltageRange(float(response))

    @classmethod
    def sense_dc_voltage_range_upper_write(cls, voltage_range: DCVoltageRange) -> str:
        return f":SENS:{MeasurementFunction.VOLT_DC.value}:RANG {voltage_range.value}"

    @classmethod
    def sense_function_on_query(cls) -> str:
        return ":FUNC?"

    @classmethod
    def sense_function_on_parse(cls, response: str) -> MeasurementFunction:
        response = response.strip()
        return MeasurementFunction(response)

    @classmethod
    def sense_function_on_write(cls, function: MeasurementFunction) -> str:
        return f':FUNC "{function.value}"'

    @classmethod
    def lang_query(cls) -> str:
        return "*LANG?"

    @classmethod
    def lang_parse(cls, response: str) -> CommandSet:
        response = response.strip()
        return CommandSet(response)

    @classmethod
    def lang_write(cls, command_set: CommandSet) -> str:
        return f"*LANG {command_set.value}"

    @classmethod
    def measure_query(cls) -> str:
        return ":MEAS?"

    @classmethod
    def measure_parse(cls, response: str) -> float:
        reponse = response.strip()
        return float(reponse)

    @classmethod
    def route_teminals_query(cls) -> str:
        return ":ROUT:TERM?"

    @classmethod
    def route_teminals_parse(cls, response: str) -> Terminals:
        response = response.strip()
        return Terminals(response)

    @classmethod
    def route_teminals_write(cls, terminals: Terminals) -> str:
        return f":ROUT:TERM {terminals.value}"
