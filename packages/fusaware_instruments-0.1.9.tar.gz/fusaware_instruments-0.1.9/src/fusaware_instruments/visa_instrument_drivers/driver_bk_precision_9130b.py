# pyright: strict

from enum import Enum

from fusaware_instruments.utils import ScpiParseError


class BKPrecision9130B:
    class ChannelName(Enum):
        CH1 = "CH1"
        CH2 = "CH2"
        CH3 = "CH3"

    class OutputState(Enum):
        OFF = "0"
        ON = "1"

    @classmethod
    def output_series_query(cls) -> str:
        return ":OUTP:SER:STAT?"

    @classmethod
    def output_series_parse(cls, response: str) -> OutputState:
        response = response.strip()
        return cls.OutputState(response)

    @classmethod
    def output_series_write(cls, state: OutputState) -> str:
        return f":OUTP:SER:STAT {state.value}"

    @classmethod
    def output_parallel_query(cls) -> str:
        return ":OUTP:PAR:STAT?"

    @classmethod
    def output_parallel_parse(cls, response: str) -> OutputState:
        response = response.strip()
        return cls.OutputState(response)

    @classmethod
    def output_parallel_write(cls, state: OutputState) -> str:
        return f":OUTP:PAR:STAT {state.value}"

    @classmethod
    def source_channel_output_state_query(cls) -> str:
        return ":CHAN:OUTP:STAT?"

    @classmethod
    def source_channel_output_state_parse(cls, response: str) -> OutputState:
        response = response.strip()
        return cls.OutputState(response)

    @classmethod
    def source_channel_output_state_write(cls, state: OutputState) -> str:
        return f":CHAN:OUTP:STAT {state.value}"

    @classmethod
    def source_current_level_immediate_amplitude_query(cls) -> str:
        return ":CURR?"

    @classmethod
    def source_current_level_immediate_amplitude_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def source_current_level_immediate_amplitude_write(cls, amplitude: float) -> str:
        return f":CURR {amplitude}"

    @classmethod
    def source_voltage_level_immediate_amplitude_query(cls) -> str:
        return ":VOLT?"

    @classmethod
    def source_voltage_level_immediate_amplitude_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def source_voltage_level_immediate_amplitude_write(cls, amplitude: float) -> str:
        return f":VOLT {amplitude}"

    @classmethod
    def instrument_select_query(cls) -> str:
        return ":INST?"

    @classmethod
    def instrument_select_parse(cls, response: str) -> str:
        response = response.strip()
        return response

    @classmethod
    def instrument_select_write(cls, channel: ChannelName) -> str:
        return f":INST {channel.value}"

    @classmethod
    def measure_scalar_voltage_dc_query(cls) -> str:
        return ":MEAS:VOLT:DC?"

    @classmethod
    def measure_scalar_voltage_dc_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def measure_scalar_voltage_dc_write(cls, voltage: float) -> str:
        return f":MEAS:VOLT:DC {voltage}"

    @classmethod
    def measure_scalar_current_dc_query(cls) -> str:
        return ":MEAS:CURR:DC?"

    @classmethod
    def measure_scalar_current_dc_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def measure_scalar_current_dc_write(cls, voltage: float) -> str:
        return f":MEAS:CURR {voltage}"

    @classmethod
    def opc_query(cls) -> str:
        return "*OPC?"

    @classmethod
    def opc_parse(cls, response: str) -> bool:
        match response.strip():
            case "0":
                return False
            case "1":
                return True
            case _:
                raise ScpiParseError(response, cls.opc_query())
