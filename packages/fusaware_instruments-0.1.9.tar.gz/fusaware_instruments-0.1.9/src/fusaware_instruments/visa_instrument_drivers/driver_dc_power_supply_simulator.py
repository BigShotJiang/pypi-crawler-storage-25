from enum import Enum

VERSION = "0.0.1"


class OutputState(Enum):
    OFF = 0
    ON = 1


class Channels(Enum):
    CH1 = 1
    CH2 = 2
    CH3 = 3


class PowerChannel:
    def __init__(self) -> None:
        self.source_current_amplitude: float = 0.0
        self.source_voltage_amplitude: float = 0.0
        self.output_state: str = "OFF"
        self.source_remote_sense_mode: str = "OFF"
        self.source_mode: str = "CV"
        return


class DCPowerSupplySimulator:
    def __init__(self):
        self._serial_number = "1"
        self._channels = {
            "CH1": PowerChannel(),
            "CH2": PowerChannel(),
            "CH3": PowerChannel(),
        }
        self._connection = None
        return

    def open(self):
        self._connection = True
        return

    def close(self):
        self._connection = False
        return

    def _channel(self, channel_name: str) -> PowerChannel:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")
        return self._channels[channel_name]

    def query_identity(self) -> str:
        identity = (
            f"Fusaware, DC Power Supply Simulator, {self._serial_number}, {VERSION}"
        )
        return identity

    def query_source_current_level_immediate_amplitude(
        self, channel_number: int
    ) -> float:
        if channel_number not in [e.value for e in Channels]:
            raise ValueError(f"Invalid channel number: '{channel_number}'.")

        channel_name = f"CH{channel_number}"
        amplitude = self._channel(channel_name).source_current_amplitude

        return amplitude

    def write_source_current_level_immediate_amplitude(
        self, channel_number: int, amplitude: float
    ) -> None:
        if channel_number not in [e.value for e in Channels]:
            raise ValueError(f"Invalid channel number: '{channel_number}'.")
        if amplitude < 0.0:
            raise ValueError(
                f"Current amplitude must be positive or zero: '{amplitude}'."
            )

        channel_name = f"CH{channel_number}"
        self._channel(channel_name).source_current_amplitude = amplitude

        return

    def query_source_voltage_level_immediate_amplitude(
        self, channel_number: int
    ) -> float:
        if channel_number not in [e.value for e in Channels]:
            raise ValueError(f"Invalid channel number: '{channel_number}'.")

        channel_name = f"CH{channel_number}"
        amplitude = self._channel(channel_name).source_voltage_amplitude

        return amplitude

    def write_source_voltage_level_immediate_amplitude(
        self, channel_number: int, amplitude: float
    ) -> None:
        if channel_number not in [e.value for e in Channels]:
            raise ValueError(f"Invalid channel number: '{channel_number}'.")
        if amplitude < 0.0:
            raise ValueError(
                f"Voltage amplitude must be positive or zero: '{amplitude}'."
            )

        channel_name = f"CH{channel_number}"
        self._channel(channel_name).source_voltage_amplitude = amplitude

        return

    def query_output_mode(self, channel_name: str) -> str:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")

        mode = self._channel(channel_name).source_mode

        return mode

    def query_output_sense(self, channel_name: str) -> str:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")

        sense = self._channel(channel_name).source_remote_sense_mode

        return sense

    def write_output_sense(self, channel_name: str, sense: str) -> None:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")
        if sense not in ("ON", "OFF", "NONE"):
            raise ValueError(f"Invalid output sense: '{sense}'.")

        self._channel(channel_name).source_remote_sense_mode = sense

        return

    def query_output_state(self, channel_name: str) -> str:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")

        state = self._channel(channel_name).output_state

        return state

    def write_output_state(self, channel_name: str, state: str) -> None:
        if channel_name not in Channels.__members__:
            raise ValueError(f"Invalid channel name: '{channel_name}'.")
        if state not in ("ON", "OFF"):
            raise ValueError(f"Invalid output state: '{state}'.")

        self._channel(channel_name).output_state = state

        return
