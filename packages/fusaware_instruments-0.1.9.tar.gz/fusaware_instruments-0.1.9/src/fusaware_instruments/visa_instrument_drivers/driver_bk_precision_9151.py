# pyright: strict

from enum import Enum

from fusaware_instruments.utils import ScpiParseError


class BKPrecision9151:
    class OutputState(Enum):
        OFF = "0"
        ON = "1"

    class RemoteSenseState(Enum):
        OFF = "0"
        ON = "1"

    @classmethod
    def output_state_query(cls) -> str:
        return ":OUTP:STAT?"

    @classmethod
    def output_state_parse(cls, response: str) -> OutputState:
        response = response.strip()
        return cls.OutputState(response)

    @classmethod
    def output_state_write(cls, state: OutputState) -> str:
        return f":OUTP:STAT {state.value}"

    @classmethod
    def source_current_level_immediate_amplitude_query(cls) -> str:
        return ":CURR?"

    @classmethod
    def source_current_level_immediate_amplitude_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def source_current_level_immediate_amplitude_write(cls, amplitude: float) -> str:
        return f":CURR {amplitude}"

    @classmethod
    def source_voltage_level_immediate_amplitude_query(cls) -> str:
        return ":VOLT?"

    @classmethod
    def source_voltage_level_immediate_amplitude_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def source_voltage_level_immediate_amplitude_write(cls, amplitude: float) -> str:
        return f":VOLT {amplitude}"

    @classmethod
    def measure_scalar_voltage_dc_query(cls) -> str:
        return ":MEAS:VOLT:DC?"

    @classmethod
    def measure_scalar_voltage_dc_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def measure_scalar_current_dc_query(cls) -> str:
        return ":MEAS:CURR:DC?"

    @classmethod
    def measure_scalar_current_dc_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)

    @classmethod
    def source_system_sense_state_query(cls) -> str:
        return "SYST:SENS?"

    @classmethod
    def source_system_sense_state_parse(cls, response: str) -> RemoteSenseState:
        return cls.RemoteSenseState(response.strip())

    @classmethod
    def source_system_sense_state_write(cls, state: RemoteSenseState) -> str:
        return f"SYST:SENS {state.value}"

    @classmethod
    def opc_query(cls) -> str:
        return "*OPC?"

    @classmethod
    def opc_parse(cls, response: str) -> bool:
        match response.strip():
            case "0":
                return False
            case "1":
                return True
            case _:
                raise ScpiParseError(response, cls.opc_query())
