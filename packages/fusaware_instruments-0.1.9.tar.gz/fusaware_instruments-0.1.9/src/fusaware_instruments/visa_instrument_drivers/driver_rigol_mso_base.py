from enum import Enum
import pyvisa
from pyvisa.resources import MessageBasedResource


class Attenuation(Enum):
    ATN_100u = 0.0001
    ATN_200u = 0.0002
    ATN_500u = 0.0005
    ATN_1m = 0.001
    ATN_2m = 0.002
    ATN_5m = 0.005
    ATN_10m = 0.01
    ATN_20m = 0.02
    ATN_50m = 0.05
    ATN_100m = 0.1
    ATN_200m = 0.2
    ATN_500m = 0.5
    ATN_1 = 1
    ATN_2 = 2
    ATN_5 = 5
    ATN_10 = 10
    ATN_20 = 20
    ATN_50 = 50
    ATN_100 = 100
    ATN_200 = 200
    ATN_500 = 500
    ATN_1000 = 1000
    ATN_2000 = 2000
    ATN_5000 = 5000
    ATN_10000 = 10000
    ATN_20000 = 20000
    ATN_50000 = 50000


class BandwidthLimit(Enum):
    BWL_20M = "20M"
    BWL_100M = "100M"
    BWL_200M = "200M"
    BWL_OFF = "OFF"


class Channel(Enum):
    CH1 = "1"
    CH2 = "2"
    CH3 = "3"
    CH4 = "4"


class Coupling(Enum):
    AC = "AC"
    DC = "DC"
    GND = "GND"


class DisplayEnable(Enum):
    OFF = "0"
    ON = "1"


class TriggerSweep(Enum):
    AUTO = "AUTO"
    NORM = "NORM"
    SING = "SING"


class Units(Enum):
    AMP = "AMP"
    UNKN = "UNKN"
    VOLT = "VOLT"
    WATT = "WATT"


class RigolMSOBase:
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        self._visa_path = visa_path
        self._resource_name = resource_name
        self._rm = None
        self._instr = None
        self._timeout = timeout
        return

    def open(self):
        if self._visa_path is not None:
            self._rm = pyvisa.ResourceManager(self._visa_path)
        else:
            self._rm = pyvisa.ResourceManager()

        self._instr = MessageBasedResource(self._rm, self._resource_name)
        self._instr.timeout = self._timeout  # 5 seconds

    def close(self):
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.close()
        if self._rm is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._rm.close()
        self._instr = None
        self._rm = None

    def query_identity(self) -> str:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = "*IDN?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        if not resp.startswith("RIGOL TECHNOLOGIES,MSO5"):
            raise RuntimeError(f"invalid identity response: {resp}")
        identity = resp
        return identity

    def query_channel_bandwidth(self, channel: Channel) -> BandwidthLimit:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:BWL?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        bandwidth = BandwidthLimit(resp)
        return bandwidth

    def write_channel_bandwidth(
        self, channel: Channel, bandwidth: BandwidthLimit
    ) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:BWL {bandwidth.value}"
        self._instr.write(msg)
        return

    def query_channel_coupling(self, channel: Channel) -> Coupling:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:COUP?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        coupling = Coupling(resp)
        return coupling

    def write_channel_coupling(self, channel: Channel, coupling: Coupling) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.write(f"CHAN{channel.value}:COUP {coupling.value}")
        return

    def query_channel_display(self, channel: Channel) -> DisplayEnable:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:DISP?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        return DisplayEnable(resp)

    def write_channel_display(self, channel: Channel, enable: DisplayEnable) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:DISP {enable.value}"
        self._instr.write(msg)
        return

    def query_channel_offset(self, channel: Channel) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:OFFS?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        offset = float(resp)
        return offset

    def write_channel_offset(self, channel: Channel, offset: float | int) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:OFFS {offset:.8f}"
        self._instr.write(msg)
        return

    def query_channel_scale(self, channel: Channel) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:SCAL?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        scale = float(resp)
        return scale

    def write_channel_scale(self, channel: Channel, scale: float) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.write(f"CHAN{channel.value}:SCAL {scale:.8f}")
        return

    def query_channel_probe(self, channel: Channel) -> Attenuation:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:PROB?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        attenuation = Attenuation(resp)
        return attenuation

    def write_channel_probe(self, channel: Channel, attenuation: Attenuation):
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:PROB {attenuation.value}"
        self._instr.write(msg)
        return

    def query_channel_units(self, channel: Channel) -> Units:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:UNIT?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        units = Units(resp)
        return units

    def write_channel_units(self, channel: Channel, units: Units) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":CHAN{channel.value}:UNIT {units.value}"
        self._instr.write(msg)
        return

    def query_timebase_offset(self) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = ":TIM:OFFS?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        offset = float(resp)
        return offset

    def write_timebase_offset(self, offset: float) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":TIM:OFFS {offset}"
        self._instr.write(msg)
        return

    def query_timebase_scale(self) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = ":TIM:SCAL?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        offset = float(resp)
        return offset

    def write_timebase_scale(self, scale: float) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":TIM:SCAL {scale}"
        self._instr.write(msg)
        return
