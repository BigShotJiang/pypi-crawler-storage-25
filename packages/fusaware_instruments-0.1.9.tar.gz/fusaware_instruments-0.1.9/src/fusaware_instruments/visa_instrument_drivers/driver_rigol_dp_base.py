from enum import Enum
import pyvisa
from pyvisa.resources import MessageBasedResource


class Channel(Enum):
    CH1 = 1
    CH2 = 2
    CH3 = 3


class OutputMode(Enum):
    CC = "CC"
    CV = "CV"
    UR = "UR"


class OutputSense(Enum):
    NONE = "NONE"
    OFF = "OFF"
    ON = "ON"


class OutputState(Enum):
    Zero = "0"
    One = "1"
    OFF = "OFF"
    ON = "ON"


class RigolDPBase:
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        self._visa_path = visa_path
        self._resource_name = resource_name
        self._rm = None
        self._instr = None
        self._timeout = timeout
        return

    def query(self, msg: str) -> str:
        if not self._instr:
            raise RuntimeError("Driver not connected to instrument.")
        resp = self._instr.query(msg)
        resp = resp.strip()
        return resp

    def write(self, msg: str) -> None:
        if not self._instr:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.write(msg)

    def open(self):
        if self._visa_path is not None:
            self._rm = pyvisa.ResourceManager(self._visa_path)
        else:
            self._rm = pyvisa.ResourceManager()

        self._instr = MessageBasedResource(self._rm, self._resource_name)
        self._instr.timeout = self._timeout  # 5 seconds

    def close(self):
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.close()
        if self._rm is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._rm.close()
        self._instr = None
        self._rm = None

    def query_identity(self) -> str:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = "*IDN?"
        resp = self._instr.query(msg)
        identity = resp.strip()
        return identity

    def query_source_current_level_immediate_amplitude(self, channel: Channel) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":SOUR{channel.value}:CURR?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        amplitude = float(resp)

        return amplitude

    def write_source_current_level_immediate_amplitude(
        self, channel: Channel, amplitude: float
    ) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":SOUR{channel.value}:CURR {amplitude}"
        self._instr.write(msg)
        return

    def query_source_voltage_level_immediate_amplitude(self, channel: Channel) -> float:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":SOUR{channel.value}:VOLT?"
        resp = self._instr.query(msg)
        resp = resp.strip()
        amplitude = float(resp)
        return amplitude

    def write_source_voltage_level_immediate_amplitude(
        self, channel: Channel, amplitude: float
    ) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":SOUR{channel.value}:VOLT {amplitude}"
        self._instr.write(msg)
        return

    def query_output_mode(self, channel: Channel) -> OutputMode:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":OUTP:MODE? {channel.name}"
        resp = self._instr.query(msg)
        resp = resp.strip()
        mode = resp

        if mode not in OutputMode.__members__:
            raise ValueError(f"Unexpected output mode: '{mode}'.")

        return OutputMode(mode)

    def query_output_sense(self, channel: Channel) -> OutputSense:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":OUTP:SENS? {channel.name}"
        resp = self._instr.query(msg)
        resp = resp.strip()
        sense = resp

        if sense not in OutputSense.__members__:
            raise ValueError(f"Unexpected output sense response: '{sense}'.")

        return OutputSense(sense)

    def write_output_sense(self, channel: Channel, sense: OutputSense) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":OUTP:SENS {channel.name},{sense.value}"
        self._instr.write(msg)

        return

    def query_output_state(self, channel: Channel) -> OutputState:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":OUTP? {channel.name}"
        resp = self._instr.query(msg)
        resp = resp.strip()

        if resp not in OutputState.__members__:
            raise ValueError(f"Unexpected output state response: '{resp}'.")

        return OutputState(resp)

    def write_output_state(self, channel: Channel, state: OutputState) -> None:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        msg = f":OUTP:STAT {channel.name},{state.value}"
        self._instr.write(msg)

        return


class RigolDP800(RigolDPBase):
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        super().__init__(resource_name, timeout, visa_path)
        return


class RigolDP900(RigolDPBase):
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        super().__init__(resource_name, timeout, visa_path)


class RigolDP2000(RigolDPBase):
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        super().__init__(resource_name, timeout, visa_path)
