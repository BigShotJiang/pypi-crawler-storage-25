from enum import Enum


class MeasurementFunction(Enum):
    CURRENT_DC = "CURRent:DC"
    VOLTAGE_DC = "VOLTage:DC"


class DCCurrentNPLC(Enum):
    NPLC_0p1 = "0.1"
    NPLC_1 = "1"
    NPLC_10 = "10"


class DCCurrentRange(Enum):
    RNG_5mA = "0.005"
    RNG_50mA = "0.05"
    RNG_500mA = "0.5"
    RNG_5A = "5"
    RNG_20A = "20"


class DCVoltageNPLC(Enum):
    NPLC_0p1 = "0.1"
    NPLC_1 = "1"
    NPLC_10 = "10"


# Note that the user manual specifies the valid values for the 2831E, these are the valid
# values for the 5491B per the specifiation of the instrument (see chapter 7) and our
# empirical testing
class DCVoltageRange(Enum):
    RNG_500mV = "0.5"
    RNG_5V = "5"
    RNG_50V = "50"
    RNG_500V = "500"
    RNG_1000V = "1000"


class BKPrecision5491B:
    @classmethod
    def function_query(cls) -> str:
        return ":FUNC?"

    @classmethod
    def function_parse(cls, response: str) -> MeasurementFunction:
        response = response.strip()
        match response:
            case MeasurementFunction.CURRENT_DC.value:
                return MeasurementFunction.CURRENT_DC
            case MeasurementFunction.VOLTAGE_DC.value:
                return MeasurementFunction.VOLTAGE_DC
            case _:
                raise ValueError(
                    f"Unexpected measurement function response: {response}"
                )

    @classmethod
    def function_write(cls, function: MeasurementFunction) -> str:
        return f":FUNC {function.value}"

    @classmethod
    def voltage_dc_nplc_query(cls) -> str:
        return ":VOLT:DC:NPLC?"

    @classmethod
    def voltage_dc_nplc_parse(cls, response: str) -> DCVoltageNPLC:
        response = response.strip()
        match response:
            case DCVoltageNPLC.NPLC_0p1.value:
                return DCVoltageNPLC.NPLC_0p1
            case DCVoltageNPLC.NPLC_1.value:
                return DCVoltageNPLC.NPLC_1
            case DCVoltageNPLC.NPLC_10.value:
                return DCVoltageNPLC.NPLC_10
            case _:
                raise ValueError(f"Unexpected dc voltage nplc response: {response}")

    @classmethod
    def voltage_dc_nplc_write(cls, voltage_nplc: DCVoltageNPLC) -> str:
        return f":VOLT:DC:NPLC {voltage_nplc.value}"

    @classmethod
    def voltage_dc_range_query(cls) -> str:
        return ":VOLT:DC:RANG?"

    @classmethod
    def voltage_dc_range_parse(cls, response: str) -> DCVoltageRange:
        response = response.strip()
        match response:
            case DCVoltageRange.RNG_500mV.value:
                return DCVoltageRange.RNG_500mV
            case DCVoltageRange.RNG_5V.value:
                return DCVoltageRange.RNG_5V
            case DCVoltageRange.RNG_50V.value:
                return DCVoltageRange.RNG_50V
            case DCVoltageRange.RNG_500V.value:
                return DCVoltageRange.RNG_500V
            case DCVoltageRange.RNG_1000V.value:
                return DCVoltageRange.RNG_1000V
            case _:
                raise ValueError(f"Unexpected dc voltage range response: {response}")

    @classmethod
    def voltage_dc_range_write(cls, voltage_range: DCVoltageRange) -> str:
        return f":VOLT:DC:RANG {voltage_range.value}"

    @classmethod
    def voltage_dc_range_auto_query(cls) -> str:
        return ":VOLT:DC:RANG:AUTO?"

    @classmethod
    def voltage_dc_range_auto_parse(cls, response: str) -> bool:
        response = response.strip()

        match response:
            case "1" | "ON":
                return True
            case "0" | "OFF":
                return False
            case _:
                raise ValueError(f"Invalid response for auto range: {response}")

    @classmethod
    def voltage_dc_range_auto_write(cls, enable: bool) -> str:
        return f":VOLT:DC:RANG:AUTO {'1' if enable else '0'}"

    @classmethod
    def current_dc_nplc_query(cls) -> str:
        return ":CURR:DC:NPLC?"

    @classmethod
    def current_dc_nplc_parse(cls, response: str) -> DCVoltageNPLC:
        response = response.strip()
        match response:
            case DCVoltageNPLC.NPLC_0p1.value:
                return DCVoltageNPLC.NPLC_0p1
            case DCVoltageNPLC.NPLC_1.value:
                return DCVoltageNPLC.NPLC_1
            case DCVoltageNPLC.NPLC_10.value:
                return DCVoltageNPLC.NPLC_10
            case _:
                raise ValueError(f"Unexpected dc voltage nplc response: {response}")

    @classmethod
    def current_dc_nplc_write(cls, voltage_nplc: DCVoltageNPLC) -> str:
        return f":CURR:DC:NPLC {voltage_nplc.value}"

    @classmethod
    def current_dc_range_query(cls) -> str:
        return ":CURR:DC:RANG?"

    @classmethod
    def current_dc_range_parse(cls, response: str) -> DCCurrentRange:
        response = response.strip()
        return DCCurrentRange(response)

    @classmethod
    def current_dc_range_write(cls, current_range: DCCurrentRange) -> str:
        return f":CURR:DC:RANG {current_range.value}"

    @classmethod
    def current_dc_range_auto_query(cls) -> str:
        return ":CURR:DC:RANG:AUTO?"

    @classmethod
    def current_dc_range_auto_parse(cls, response: str) -> bool:
        response = response.strip()

        match response:
            case "1" | "ON":
                return True
            case "0" | "OFF":
                return False
            case _:
                raise ValueError(f"Invalid response for auto range: {response}")

    @classmethod
    def current_dc_range_auto_write(cls, enable: bool) -> str:
        return f":CURR:DC:RANG:AUTO {'1' if enable else '0'}"

    @classmethod
    def fetch_query(cls) -> str:
        return ":FETC?"

    @classmethod
    def fetch_parse(cls, response: str) -> float:
        response = response.strip()
        return float(response)
