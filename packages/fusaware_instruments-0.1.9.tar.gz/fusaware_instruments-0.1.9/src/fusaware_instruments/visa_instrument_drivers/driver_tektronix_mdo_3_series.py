from enum import Enum
from typing import Literal
import logging

from pydantic import BaseModel

from fusaware_instruments.utils import VisaIO, ScpiParseError, compare_floats


MAX_ANALOG_BANDWIDTH = 200e6

MAX_ANALOG_SAMPLE_RATE = 2_500_000_000

VALID_RECORD_LENGTHS = [1000, 10000, 100000, 1_000_000, 5_000_000, 10_000_000]

NUM_HORIZONTAL_DIVISIONS = 10

DEFAULT_OFFSET_PERCENTAGE = 50.0


class AcquisitionMode(Enum):
    RUNSTOP = "RUNSTOP"
    SEQUENCE = "SEQUENCE"


class AcquisitionState(Enum):
    STOP = "0"
    RUN = "1"


class AnalogChannel(Enum):
    CH1 = 1
    CH2 = 2
    CH3 = 3
    CH4 = 4


class ProbeUnits(Enum):
    VOLTS = "V"
    AMPS = "A"
    WATTS = "W"


class ProbeCoupling(Enum):
    AC = "AC"
    DC = "DC"
    DCREJ = "DCREJ"


type ProbeBandwidthLimit = float | Literal["FULL"]


# TODO: add D<x> for digital channels
class WaveformSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    MATH = "MATH"
    REF1 = "REF1"
    REF2 = "REF2"
    DIGITAL = "DIG"
    RF_AMPLITUDE = "RF_AMPL"
    RF_FREQUENCY = "RF_FREQ"
    RF_PHASE = "RF_PHA"
    RF_NORMAL = "RF_NORM"
    RF_AVERAGE = "RF_AVER"
    RF_MAXHOLD = "RF_MAXH"
    RF_MINHOLD = "RF_MINH"


class ImageFormat(Enum):
    PNG = "PNG"
    BMP = "BMP"
    TIFF = "TIFF"


class ChannelDisplayState(Enum):
    OFF = "0"
    ON = "1"


class TriggerCoupling(Enum):
    AC = "AC"
    DC = "DC"
    HFREJ = "HFR"
    LFREJ = "LFR"
    NOISEREJ = "NOISE"


class TriggerSlope(Enum):
    RISE = "RISE"
    FALL = "FALL"
    EITHER = "EITHER"


# TODO: add D<x> for digital channels
class TriggerSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    LINE = "LINE"
    AUX = "AUX"
    RF = "RF"


class TriggerMode(Enum):
    AUTO = "AUTO"
    NORMAL = "NORMAL"


class TriggerType(Enum):
    EDGE = "EDGE"
    PULSE = "PULSE"
    LOGIC = "LOGIC"
    BUS = "BUS"
    VIDEO = "VIDEO"


class WaveformEncoding(Enum):
    ASCII = "ASCII"
    BINARY = "BINARY"


class BinaryFormat(Enum):
    RI = "RI"
    RP = "RP"
    FP = "FP"


class WaveformByteOrder(Enum):
    MSB = "MSB"
    LSB = "LSB"


class DataEncoding(Enum):
    """
    DATa:ENCdg encoding types.
    Programming guide page 2-96

    A convenience enum that sets WFMOutpre:ENCdg, WFMOutpre:BN_Fmt, and
    WFMOutpre:BYT_Or together with a single command.
    """

    ASCII = "ASCIi"
    FASTEST = "FAStest"
    RIBINARY = "RIBinary"  # signed integer, MSB first
    RPBINARY = "RPBinary"  # unsigned integer, MSB first
    SRIBINARY = "SRIbinary"  # signed integer, LSB first
    SRPBINARY = "SRPbinary"  # unsigned integer, LSB first
    FPBINARY = "FPbinary"  # 32-bit float, MSB first
    SFPBINARY = "SFPbinary"  # 32-bit float, LSB first


class DelayModeState(Enum):
    OFF = "OFF"
    ON = "ON"


class ProbeType(Enum):
    TPP0100 = "TPP0100"
    TPP0200 = "TPP0200"
    TPP0250 = "TPP0250"
    TPP0500B = "TPP0500B"
    TPP0502 = "TPP0502"
    TPP1000 = "TPP1000"
    TAP1500 = "TAP1500"
    TAP2500 = "TAP2500"
    ADA400A = "ADA400A"
    TDP1500 = "TDP1500"
    TDP3500 = "TDP3500"
    TDP0500 = "TDP0500"
    TDP1000 = "TDP1000"
    THDP0100 = "THDP0100"
    THDP0200 = "THDP0200"
    TMDP0200 = "TMDP0200"
    TPP0850 = "TPP0850"
    A621 = "A621"
    A622 = "A622"
    TCP0020 = "TCP0020"
    TCP0030 = "TCP0030"
    TCP0030A = "TCP0030A"
    TCP0150 = "TCP0150"
    TCP303 = "TCP303"
    TCP305A = "TCP305A"
    TCP312A = "TCP312A"
    TCP404XL = "TCP404XL"
    P6316 = "P6316"
    NONE = "No probe detected"
    UNKNOWN = "unknown"


class ProbeID(BaseModel):
    probe_type: ProbeType
    name: str
    serial_number: str


class TektronixMdo3SeriesDriver:
    io: VisaIO

    def __init__(self, io: VisaIO) -> None:
        self.io = io

    def query_acquire_state(self) -> AcquisitionState:
        """
        ACQuire:STATE?
        Programming guide page 43
        """
        query = ":ACQ:STATE?"
        resp = self.io.query(query).strip()

        try:
            return AcquisitionState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_acquire_state(self, state: AcquisitionState) -> None:
        """
        ACQuire:STATE {OFF|ON|RUN|STOP|<NR1>}
        Programming guide page 43
        """
        command = f":ACQ:STATE {state.value}"
        self.io.write(command)

    def query_acquire_stopafter(self) -> AcquisitionMode:
        """
        ACQuire:STOPAfter?
        Programming guide page 44
        """
        query = ":ACQ:STOPA?"
        resp = self.io.query(query).strip()

        try:
            return AcquisitionMode(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_acquire_stopafter(self, mode: AcquisitionMode) -> None:
        """
        ACQuire:STOPAfter {RUNSTop|SEQuence}
        Programming guide page 44
        """
        command = f":ACQ:STOPA {mode.value}"
        self.io.write(command)

    def query_channel_bandwidth(self, channel: AnalogChannel) -> ProbeBandwidthLimit:
        """
        CH<x>:BANdwidth {FULl|<NR3>}
        CH<x>:BANdwidth?
        Programming guide page 2-199
        """
        query = f":CH{channel.value}:BAN?"
        resp = self.io.query(query).strip()

        try:
            if resp == "FULL":
                return "FULL"
            else:
                resp_float = float(resp)
                if compare_floats(resp_float, MAX_ANALOG_BANDWIDTH):
                    return "FULL"
                else:
                    return resp_float
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_bandwidth(
        self, channel: AnalogChannel, bandwidth: ProbeBandwidthLimit
    ) -> None:
        """
        CH<x>:BANdwidth {FULl|<NR3>}
        Programming guide page 2-199
        """
        match bandwidth:
            case "FULL":
                bw_str = "FULL"
            case float() | int():
                bw_str = str(bandwidth)

        command = f":CH{channel.value}:BAN {bw_str}"
        self.io.write(command)

    def query_channel_coupling(self, channel: AnalogChannel) -> ProbeCoupling:
        """
        CH<x>:COUPling?
        Programming guide page 2-199
        """
        query = f":CH{channel.value}:COUP?"
        resp = self.io.query(query).strip()

        try:
            return ProbeCoupling(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_coupling(
        self, channel: AnalogChannel, coupling: ProbeCoupling
    ) -> None:
        """
        CH<x>:COUPling {AC|DC|DCREJect}
        Programming guide page 2-199
        """
        command = f":CH{channel.value}:COUP {coupling.value}"
        self.io.write(command)

    def query_channel_offset(self, channel: AnalogChannel) -> float:
        """
        CH<x>:OFFSet?
        Programming guide page 69
        """
        query = f":CH{channel.value}:OFFS?"

        resp = self.io.query(query)

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_offset(self, channel: AnalogChannel, offset: float) -> None:
        """
        CH<x>:OFFSet <NR3>
        Programming guide page 2-202
        """
        command = f":CH{channel.value}:OFFS {offset}"
        self.io.write(command)

    def query_channel_position(self, channel: AnalogChannel) -> float:
        """
        CH<x>:POSition?
        Programming guide page 2-202
        """
        query = f":CH{channel.value}:POS?"

        resp = self.io.query(query)

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_position(self, channel: AnalogChannel, offset: float) -> None:
        """
        CH<x>:POSition <NR3>
        Programming guide page 69
        """
        command = f":CH{channel.value}:POS {offset}"
        self.io.write(command)

    def query_channel_probe_gain(self, channel: AnalogChannel) -> float:
        """
        CH<x>:PRObe:GAIN?
        Programming guide page 74
        """
        query = f":CH{channel.value}:PRO:GAIN?"

        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_probe_gain(self, channel: AnalogChannel, gain: float) -> None:
        """
        CH<x>:PRObe:GAIN <NR3>
        Programming guide page 74
        """
        command = f":CH{channel.value}:PRO:GAIN {gain}"
        self.io.write(command)

    def query_channel_probe_units(self, channel: AnalogChannel) -> ProbeUnits:
        """
        CH<x>:PRObe:UNIts?
        Programming guide page 77
        """
        query = f":CH{channel.value}:PRO:UNI?"
        resp = self.io.query(query).strip()

        try:
            return ProbeUnits(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_channel_scale(self, channel: AnalogChannel) -> float:
        """
        CH<x>:SCAle?
        Programming guide page 77
        """
        query = f":CH{channel.value}:SCA?"

        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_scale(self, channel: AnalogChannel, scale: float) -> None:
        """
        CH<x>:SCAle <NR3>
        Programming guide page 77
        """
        command = f":CH{channel.value}:SCA {scale}"
        self.io.write(command)

    def query_channel_yunit(self, channel: AnalogChannel) -> ProbeUnits:
        """
        CH<x>:YUNit?
        Programming guide page 79
        """
        query = f":CH{channel.value}:YUN?"
        resp = self.io.query(query).strip()

        try:
            return ProbeUnits(resp.replace('"', ""))
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_yunit(self, channel: AnalogChannel, units: ProbeUnits) -> None:
        """
        CH<x>:YUNit <QString>
        Programming guide page 79
        """
        command = f':CH{channel.value}:YUN "{units.value}"'
        self.io.write(command)

    def query_channel_probe_id(self, channel: AnalogChannel) -> ProbeID:
        """
        CH<x>:PRObe:ID?
        Programming guide page 2-208
        """
        query = f":CH{channel.value}:PRO:ID?"
        resp_raw = self.io.query(query).strip()
        resp = resp_raw.replace('"', "")
        parts = resp.split(";")

        if len(parts) != 2:
            raise ScpiParseError(
                response=resp,
                query=query,
                message='Expected response format: "<probe type>;<serial number>"',
            )

        try:
            probe_type = ProbeType(parts[0])
            return ProbeID(
                probe_type=probe_type, name=probe_type.value, serial_number=parts[1]
            )
        except ValueError:
            logging.warning(f"Unrecognized probe type: '{parts[0]}'")
            return ProbeID(
                probe_type=ProbeType.UNKNOWN, name=parts[0], serial_number=parts[1]
            )

    def query_curve(self) -> str:
        """
        CURVe?
        Programming guide page 92
        """
        query = ":CURV?"
        resp = self.io.query(query).strip()
        return resp

    def query_curve_binary(self) -> bytes:
        """
        CURVe? (binary encoding)
        Programming guide page 92

        Call this after setting DATa:ENCdg to a binary format. Writes the
        query and reads the raw IEEE 488.2 block response from the instrument.
        Returns the decoded payload bytes (block header stripped).
        """
        self.io.write(":CURV?")
        header_start = self.io.read_bytes(2)
        if header_start[0] != ord("#"):
            raise ScpiParseError(
                response=str(header_start),
                query=":CURV?",
                message=f"Expected '#' at start of IEEE 488.2 block, got {header_start[0]}",
            )
        header_str = header_start.decode("ascii")
        n = int(header_str[1])

        num_bytes_raw = self.io.read_bytes(n)
        num_bytes_str = num_bytes_raw.decode("ascii")
        num_bytes = int(num_bytes_str)

        payload = self.io.read_bytes(num_bytes)

        return payload

    def query_data_source(self) -> WaveformSource:
        """
        DATa:SOUrce?
        Programming guide page 97
        """
        query = ":DAT:SOU?"
        resp = self.io.query(query).strip()

        try:
            return WaveformSource(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_source(self, source: WaveformSource) -> None:
        """
        DATa:SOUrce {source}
        Programming guide page 97
        """
        command = f":DAT:SOU {source.value}"
        self.io.write(command)

    def query_data_start(self) -> int:
        """
        DATa:STARt?
        Programming guide page 98
        """
        query = ":DAT:STAR?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_start(self, start: int) -> None:
        """
        DATa:STARt {start}
        Programming guide page 98
        """
        command = f":DAT:STAR {start}"
        self.io.write(command)

    def query_data_stop(self) -> int:
        """
        DATa:STOP?
        Programming guide page 99
        """
        query = ":DAT:STOP?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_stop(self, stop: int) -> None:
        """
        DATa:STOP {stop}
        Programming guide page 99
        """
        command = f":DAT:STOP {stop}"
        self.io.write(command)

    def query_data_encoding(self) -> DataEncoding:
        """
        DATa:ENCdg?
        Programming guide page 2-96
        """
        query = ":DAT:ENC?"
        resp = self.io.query(query).strip()

        try:
            return DataEncoding(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_data_encoding(self, encoding: DataEncoding) -> None:
        """
        DATa:ENCdg {ASCIi|FAStest|RIBinary|RPBinary|SRIbinary|SRPbinary|FPbinary|SFPbinary}
        Programming guide page 2-96

        Sets WFMOutpre:ENCdg, WFMOutpre:BN_Fmt, and WFMOutpre:BYT_Or atomically.
        """
        command = f":DAT:ENC {encoding.value}"
        self.io.write(command)

    def query_filesystem_cwd(self) -> str:
        """
        FILESystem:CWD?
        Programming guide page 133
        """
        query = ":FILES:CWD?"
        return self.io.query(query).strip().replace('"', "")

    def write_filesystem_cwd(self, path: str) -> None:
        """
        FILESystem:CWD {<new working directory path>}
        Programming guide page 133
        """
        command = f':FILES:CWD "{path}"'
        self.io.write(command)

    def write_file_delete(self, path: str) -> None:
        """
        FILESystem:DELEte {path}
        Programming guide page 134
        """
        command = f':FILES:DELE "{path}"'
        self.io.write(command)

    def write_file_read(self, path: str) -> None:
        """
        FILESystem:READFile {path}
        Programming guide page 137
        """
        command = f':FILES:READFile "{path}"'
        self.io.write(command)

    def query_horizontal_main_delay_position(self) -> float:
        """
        HORizontal[:MAIn][:DELay]:POSition?
        Programming guide page 157
        """
        query = ":HOR:POS?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_main_delay_position(self, position: float) -> None:
        """
        HORizontal[:MAIn][:DELay]:POSition <NR1>
        Programming guide page 157
        """
        command = f":HOR:POS {position}"
        self.io.write(command)

    def query_horizontal_main_delay_mode(self) -> DelayModeState:
        """
        HORizontal[:MAIn]:DELay:MODe?
        Programming guide page 158
        """
        query = ":HOR:DEL:MOD?"
        resp = self.io.query(query).strip()

        try:
            return DelayModeState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_main_delay_mode(self, state: DelayModeState) -> None:
        """
        HORizontal[:MAIn]:DELay:MODe {OFF|ON|<NR1>}
        Programming guide page 158
        """
        command = f":HOR:DEL:MOD {state.value}"
        self.io.write(command)

    def query_horizontal_sample_rate(self) -> float:
        """
        HORizontal:SAMPLERate?
        Programming guide page 161
        """
        query = ":HOR:SAMPLER?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_horizontal_main_delay_time(self) -> float:
        """
        HORizontal:MAIn:DELay:TIMe?
        Programming guide page 160
        """
        query = ":HOR:DEL:TIM?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_main_delay_time(self, offset: float) -> None:
        """
        HORizontal:MAIn:DELay:TIMe <NR3>
        Programming guide page 160
        """
        command = f":HOR:DEL:TIM {offset}"
        self.io.write(command)

    def query_horizontal_main_scale(self) -> float:
        """
        HORizontal[:MAIn]:SCAle?
        Programming guide page 161
        """
        query = ":HOR:SCA?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_main_scale(self, scale: float) -> None:
        """
        HORizontal[:MAIn]:SCAle {scale}
        Programming guide page 161
        """
        command = f":HOR:SCA {scale}"
        self.io.write(command)

    def query_horizontal_record_length(self) -> int:
        """
        HORizontal:RECOrdlength?
        Programming guide page 164
        """
        query = ":HOR:RECO?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_horizontal_record_length(self, length: int) -> None:
        """
        HORizontal:RECOrdlength {NR1}
        Programming guide page 164
        """
        command = f":HOR:RECO {length}"
        self.io.write(command)

    def query_opc(self) -> int:
        """
        *OPC?
        Programming guide page 199
        """
        query = "*OPC?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_save_image(self, path: str) -> None:
        """
        SAVe:IMAGe {path}
        Programming guide page 212
        """
        command = f':SAV:IMAG "{path}"'
        self.io.write(command)

    def query_save_image_format(self) -> ImageFormat:
        """
        SAVe:IMAGe:FILEFormat?
        Programming guide page 213
        """
        query = ":SAV:IMAG:FILEF?"
        resp = self.io.query(query).strip()

        try:
            return ImageFormat(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_save_image_format(self, fmt: ImageFormat) -> None:
        """
        SAVe:IMAGe:FILEFormat {format}
        Programming guide page 213
        """
        command = f":SAV:IMAG:FILEF {fmt.value}"
        self.io.write(command)

    def write_hardcopy_start(self) -> None:
        """
        HARDCopy {STARt}
        Programming guide 2-306
        """
        command = ":HARDC STAR"
        self.io.write(command)

    def query_hardcopy_inksaver(self) -> bool:
        """
        HARDCopy:INKSaver?
        Programming guide 2-308
        """
        query = ":HARDC:INKS?"

        response = self.io.query(query)

        match response:
            case "ON" | "1":
                return True
            case "OFF" | "0":
                return False
            case _:
                raise ScpiParseError(response=response, query=query)

    def write_hardcopy_inksaver(self, enable: bool) -> None:
        """
        HARDCopy:INKSaver <ON | 1 | OFF | 0>
        Programming guide 2-308
        """
        command = f":HARDC:INKS {'ON' if enable else 'OFF'}"
        self.io.write(command)

    def query_channel_select(self, channel: AnalogChannel) -> ChannelDisplayState:
        """
        SELect:{channel}?
        Programming guide page 218
        """
        query = f":SEL:CH{channel.value}?"
        resp = self.io.query(query).strip()

        try:
            return ChannelDisplayState(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_channel_select(
        self, channel: AnalogChannel, state: ChannelDisplayState
    ) -> None:
        """
        SELect:{channel} {state}
        Programming guide page 218
        """
        command = f":SEL:CH{channel.value} {state.value}"
        self.io.write(command)

    def query_trigger_edge_coupling(self) -> TriggerCoupling:
        """
        TRIGger:A:EDGE:COUPling?
        Programming guide page 236
        """
        query = ":TRIG:A:EDGE:COUP?"
        resp = self.io.query(query).strip()

        try:
            return TriggerCoupling(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_coupling(self, coupling: TriggerCoupling) -> None:
        """
        TRIGger:A:EDGE:COUPling {coupling}
        Programming guide page 236
        """
        command = f":TRIG:A:EDGE:COUP {coupling.value}"
        self.io.write(command)

    def query_trigger_edge_slope(self) -> TriggerSlope:
        """
        TRIGger:A:EDGE:SLOpe?
        Programming guide page 237
        """
        query = ":TRIG:A:EDGE:SLO?"
        resp = self.io.query(query).strip()

        try:
            return TriggerSlope(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_slope(self, slope: TriggerSlope) -> None:
        """
        TRIGger:A:EDGE:SLOpe {slope}
        Programming guide page 237
        """
        command = f":TRIG:A:EDGE:SLO {slope.value}"
        self.io.write(command)

    def query_trigger_edge_source(self) -> TriggerSource:
        """
        TRIGger:A:EDGE:SOUrce?
        Programming guide page 238
        """
        query = ":TRIG:A:EDGE:SOU?"
        resp = self.io.query(query).strip()

        try:
            return TriggerSource(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_edge_source(self, source: TriggerSource) -> None:
        """
        TRIGger:A:EDGE:SOUrce {source}
        Programming guide page 238
        """
        command = f":TRIG:A:EDGE:SOU {source.value}"
        self.io.write(command)

    def query_trigger_holdoff_time(self) -> float:
        """
        TRIGger:A:HOLDoff:TIMe?
        Programming guide page 239
        """
        query = ":TRIG:A:HOLDO:TIM?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_holdoff_time(self, time: float) -> None:
        """
        TRIGger:A:HOLDoff:TIMe {time}
        Programming guide page 239
        """
        command = f":TRIG:A:HOLDO:TIM {time}"
        self.io.write(command)

    def query_trigger_level(self, channel: AnalogChannel) -> float:
        """
        TRIGger:A:LEVel:{channel}?
        Programming guide page 241
        """
        query = f":TRIG:A:LEV:CH{channel.value}?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_level(self, channel: AnalogChannel, level: float) -> None:
        """
        TRIGger:A:LEVel:{channel} {level}
        Programming guide page 241
        """
        command = f":TRIG:A:LEV:CH{channel.value} {level}"
        self.io.write(command)

    def query_trigger_mode(self) -> TriggerMode:
        """
        TRIGger:A:MODe?
        Programming guide page 242
        """
        query = ":TRIG:A:MOD?"
        resp = self.io.query(query).strip()

        try:
            return TriggerMode(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_mode(self, mode: TriggerMode) -> None:
        """
        TRIGger:A:MODe {mode}
        Programming guide page 242
        """
        command = f":TRIG:A:MOD {mode.value}"
        self.io.write(command)

    def query_trigger_type(self) -> TriggerType:
        """
        TRIGger:A:TYPe?
        Programming guide page 252
        """
        query = ":TRIG:A:TYP?"
        resp = self.io.query(query).strip()

        try:
            return TriggerType(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_trigger_type(self, type: TriggerType) -> None:
        """
        TRIGger:A:TYPe {type}
        Programming guide page 252
        """
        command = f":TRIG:A:TYP {type.value}"
        self.io.write(command)

    def query_waveform_bit_nr(self) -> int:
        """
        WFMOutpre:BIT_Nr?
        Programming guide page 272
        """
        query = ":WFMO:BIT_N?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_binary_format(self) -> BinaryFormat:
        """
        WFMOutpre:BN_Fmt?
        Programming guide page 273
        """
        query = ":WFMO:BN_F?"
        resp = self.io.query(query).strip()

        try:
            return BinaryFormat(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_byte_nr(self) -> int:
        """
        WFMOutpre:BYT_Nr?
        Programming guide page 274
        """
        query = ":WFMO:BYT_N?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_byte_nr(self, byte_nr: int) -> None:
        """
        WFMOutpre:BYT_Nr {1|2}
        Programming guide page 274
        """
        command = f":WFMO:BYT_N {byte_nr}"
        self.io.write(command)

    def query_waveform_byte_order(self) -> WaveformByteOrder:
        """
        WFMOutpre:BYT_Or?
        Programming guide page 274

        Only meaningful when WFMOutpre:ENCdg is BINARY and BYT_Nr is 2.
        """
        query = ":WFMO:BYT_O?"
        resp = self.io.query(query).strip()

        try:
            return WaveformByteOrder(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_byte_order(self, order: WaveformByteOrder) -> None:
        """
        WFMOutpre:BYT_Or {MSB|LSB}
        Programming guide page 274
        """
        command = f":WFMO:BYT_O {order.value}"
        self.io.write(command)

    def query_waveform_encoding(self) -> WaveformEncoding:
        """
        WFMOutpre:ENCdg?
        Programming guide page 275
        """
        query = ":WFMO:ENC?"
        resp = self.io.query(query).strip()

        try:
            return WaveformEncoding(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def write_waveform_encoding(self, encoding: WaveformEncoding) -> None:
        """
        WFMOutpre:ENCdg {encoding}
        Programming guide page 275
        """
        command = f":WFMO:ENC {encoding.value}"
        self.io.write(command)

    def query_waveform_nr_points(self) -> int:
        """
        WFMOutpre:NR_Pt?
        Programming guide page 276
        """
        query = ":WFMO:NR_P?"
        resp = self.io.query(query).strip()

        try:
            return int(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_id(self) -> str:
        """
        WFMOutpre:WFId?
        Programming guide page 277
        """
        query = ":WFMO:WFI?"
        return self.io.query(query).strip()

    def query_waveform_x_increment(self) -> float:
        """
        WFMOutpre:XINcr?
        Programming guide page 278
        """
        query = ":WFMO:XIN?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_x_unit(self) -> str:
        """
        WFMOutpre:XUNit?
        Programming guide page 278
        """
        query = ":WFMO:XUN?"
        return self.io.query(query).strip()

    def query_waveform_x_zero(self) -> float:
        """
        WFMOutpre:XZEro?
        Programming guide page 279
        """
        query = ":WFMO:XZE?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_multiplier(self) -> float:
        """
        WFMOutpre:YMUlt?
        Programming guide page 280
        """
        query = ":WFMO:YMU?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_offset(self) -> float:
        """
        WFMOutpre:YOFf?
        Programming guide page 280
        """
        query = ":WFMO:YOF?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_unit(self) -> ProbeUnits:
        """
        WFMOutpre:YUNit?
        Programming guide page 281
        """
        query = ":WFMO:YUN?"
        resp = self.io.query(query).strip().replace('"', "")

        try:
            return ProbeUnits(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def query_waveform_y_zero(self) -> float:
        """
        WFMOutpre:YZEro?
        Programming guide page 282
        """
        query = ":WFMO:YZE?"
        resp = self.io.query(query).strip()

        try:
            return float(resp)
        except ValueError as e:
            raise ScpiParseError(response=resp, query=query) from e

    def get_probe_specific_gain(
        self, channel: AnalogChannel, probe: ProbeType
    ) -> float:
        match probe:
            case (
                ProbeType.TPP0100
                | ProbeType.TPP0250
                | ProbeType.TPP0500B
                | ProbeType.TPP1000
            ):
                return 0.1  # Gain for 10x probe
            case ProbeType.TCP0020 | ProbeType.TCP0030A:
                return self.query_channel_probe_gain(channel)
            case ProbeType.TMDP0200:
                return self.query_channel_probe_gain(channel)
            case ProbeType.NONE | ProbeType.UNKNOWN:
                return self.query_channel_probe_gain(channel)
            case _:
                return self.query_channel_probe_gain(channel)


def parse_ieee_488_2_block_data(data: bytes) -> bytes:
    """
    Parse an IEEE 488.2 binary block and return the payload.

    Block format:  #N<N-digit-length><payload bytes>
      - '#'           : literal marker
      - N             : single ASCII digit — number of length digits that follow
      - <N digits>    : decimal byte count of the payload
      - <payload>     : exactly that many bytes of data

    Any trailing bytes (e.g. a newline terminator from read_raw) are ignored.
    """
    if len(data) < 2 or data[0] != ord("#"):
        raise ScpiParseError(
            response=str(data[:10]),
            query=":CURV?",
            message=f"Expected '#' at start of IEEE 488.2 block, got {data[:1]!r}",
        )

    n = int(chr(data[1]))
    if len(data) < 2 + n:
        raise ScpiParseError(
            response=str(data[:10]),
            query=":CURV?",
            message=f"Block header truncated: need {2 + n} bytes, got {len(data)}",
        )

    num_bytes = int(data[2 : 2 + n])

    payload = data[2 + n : 2 + n + num_bytes]

    if len(payload) < num_bytes:
        raise ScpiParseError(
            response=f"Byte array with lenght {len(payload)}",
            query=":CURV?",
            message=f"Expected to read {num_bytes} bytes, read {len(payload)} bytes instead",
        )

    return payload
