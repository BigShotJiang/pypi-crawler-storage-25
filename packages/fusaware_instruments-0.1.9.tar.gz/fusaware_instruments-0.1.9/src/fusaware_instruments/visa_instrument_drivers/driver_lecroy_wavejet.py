import pyvisa
from pyvisa.resources import MessageBasedResource


class LeCroyWaveJet:
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        self._visa_path = visa_path
        self._resource_name = resource_name
        self._rm = None
        self._instr = None
        self._timeout = timeout

    def open(self):
        if self._visa_path is not None:
            self._rm = pyvisa.ResourceManager(self._visa_path)
        else:
            self._rm = pyvisa.ResourceManager()

        self._instr = MessageBasedResource(self._rm, self._resource_name)
        self._instr.timeout = self._timeout  # 5 seconds

    def close(self):
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.close()
        if self._rm is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._rm.close()
        self._instr = None
        self._rm = None

    def query_identity(self) -> str:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")

        msg = "*IDN?"
        resp = self._instr.query(msg)
        identity = resp.strip()
        return identity
