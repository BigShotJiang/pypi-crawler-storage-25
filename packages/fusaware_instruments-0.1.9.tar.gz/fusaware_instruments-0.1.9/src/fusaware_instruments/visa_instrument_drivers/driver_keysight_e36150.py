from typing import List
import pyvisa
from pyvisa.resources import MessageBasedResource


class KeysightE36150:
    def __init__(
        self, resource_name: str, timeout: int = 5000, visa_path: str | None = None
    ):
        self._visa_path = visa_path
        self._resource_name = resource_name
        self._rm = None
        self._instr = None
        self._timeout = timeout
        return

    def query(self, msg: str) -> str:
        if not self._instr:
            raise RuntimeError("Driver not connected to instrument.")
        resp = self._instr.query(msg)
        resp = resp.strip()
        return resp

    def write(self, msg: str) -> None:
        if not self._instr:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.write(msg)

    def open(self):
        if self._visa_path is not None:
            self._rm = pyvisa.ResourceManager(self._visa_path)
        else:
            self._rm = pyvisa.ResourceManager()

        self._instr = MessageBasedResource(self._rm, self._resource_name)
        self._instr.timeout = self._timeout  # 5 seconds

    def close(self):
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._instr.close()
        if self._rm is None:
            raise RuntimeError("Driver not connected to instrument.")
        self._rm.close()
        self._instr = None
        self._rm = None

    def query_identity(self) -> str:
        if self._instr is None:
            raise RuntimeError("Driver not connected to instrument.")

        msg = "*IDN?"
        resp = self._instr.query(msg)
        identity = resp.strip()
        return identity

    def output(self):
        return OUTPutSubsystem(self)

    def source(self):
        return


class BaseSubsystem:
    def __init__(self, parent: KeysightE36150):
        self._parent = parent
        return

    def _query(self, cmd) -> str:
        return self._parent.query(cmd)

    def _write(self, cmd: str) -> None:
        return self._parent.write(cmd)


class OUTPutSubsystem(BaseSubsystem):
    def __init__(self, parent: KeysightE36150):
        super().__init__(parent)
        self._base = ":OUTP"

    def state(self):
        return OUTPutSTATeSubsystem(self)


class OUTPutSTATeSubsystem(BaseSubsystem):
    def __init__(self, parent: OUTPutSubsystem):
        super().__init__(parent._parent)
        self._base = f"{parent._base}:STAT"
        return

    def query(self):
        return OUTPutSTATeSubsystemQuery(self)

    def write(self):
        return OUTPutSTATeSubsystemWrite(self)


class OUTPutSTATeSubsystemQuery(BaseSubsystem):
    def __init__(self, parent: OUTPutSTATeSubsystem):
        super().__init__(parent._parent)
        self._base = f"{parent._base}?"
        return

    def channel(self, channel_number: int):
        return OUTPutSTATeSubsystemQueryChannel(self, channel_number)


class OUTPutSTATeSubsystemQueryChannel(BaseSubsystem):
    def __init__(self, parent: OUTPutSTATeSubsystemQuery, channel_number: int):
        super().__init__(parent._parent)
        self._base = f"{parent._base} CH{channel_number}"

    def state(self):
        return OUTPutSTATeSubsystemQueryChannelState(self)


class OUTPutSTATeSubsystemQueryChannelState(BaseSubsystem):
    def __init__(self, parent: OUTPutSTATeSubsystemQueryChannel):
        super().__init__(parent._parent)
        self._base = f"{parent._base}"
        return

    def off(self) -> bool:
        state = self._query(self._base)
        if state == "OFF":
            return True
        raise ValueError(f"Unexpected state response: '{state}'.")

    def on(self) -> bool:
        state = self._query(self._base)
        if state == "ON":
            return True
        raise ValueError(f"Unexpected state response: '{state}'.")

    def value(self) -> str:
        return self._query(self._base)


class OUTPutSTATeSubsystemWrite(BaseSubsystem):
    def __init__(self, parent: OUTPutSTATeSubsystem):
        super().__init__(parent._parent)
        self._base = f"{parent._base}"
        return

    def state(self, state: str):
        return OUTPutSTATeSubsystemWriteState(self, state)


class OUTPutSTATeSubsystemWriteState(BaseSubsystem):
    def __init__(self, parent: OUTPutSTATeSubsystemWrite, state: str):
        super().__init__(parent._parent)
        self._base = f"{parent._base} {state}"

    def channel(self, channel_number_list: List[int]):
        return OUTPutSTATeSubsystemWriteStateChannel(self, channel_number_list)


class OUTPutSTATeSubsystemWriteStateChannel(BaseSubsystem):
    def __init__(
        self, parent: OUTPutSTATeSubsystemWriteState, channel_number_list: List[int]
    ):
        super().__init__(parent._parent)
        channel_number_list_str = None
        for channel_number in channel_number_list:
            if channel_number_list_str is None:
                channel_number_list_str = str(channel_number)
            else:
                channel_number_list_str += f",{channel_number}"
        if channel_number_list_str is not None:
            self._base = f"{self._base},(@{channel_number_list_str})"
        else:
            self._base = parent._base
        return

    def off(self) -> None:
        return self.value("OFF")

    def on(self) -> None:
        return self.value("ON")

    def value(self, value: str) -> None:
        msg = f"{self._base} {value}"
        return self._write(msg)
