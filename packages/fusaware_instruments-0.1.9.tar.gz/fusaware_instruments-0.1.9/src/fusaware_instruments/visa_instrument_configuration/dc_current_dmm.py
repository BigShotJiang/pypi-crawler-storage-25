from pydantic import validate_call

from fusaware_instruments.visa_instrument_hal.hal_dmm import (
    HALDigitalMultimeter,
    HALDmmDcCurrentMeter,
    MeasurementRange,
    compare_measurement_range,
    MeasurementIntegrationTime,
    compare_measurement_integration_time,
)


@validate_call
def configure_dc_current_meter(
    resource: HALDigitalMultimeter,
    current_range: MeasurementRange,
    integration_time: MeasurementIntegrationTime,
) -> tuple[MeasurementRange, list[ValueError]]:
    HALDmmDcCurrentMeter.initialize(resource)

    initial_current_range = HALDmmDcCurrentMeter.get_measurement_range(resource)
    initial_integration_time = HALDmmDcCurrentMeter.get_measurement_integration_time(
        resource
    )

    if not compare_measurement_range(current_range, initial_current_range):
        HALDmmDcCurrentMeter.set_measurement_range(resource, current_range)
    if not compare_measurement_integration_time(
        integration_time, initial_integration_time
    ):
        HALDmmDcCurrentMeter.set_measurement_integration_time(
            resource, integration_time
        )

    final_current_range = HALDmmDcCurrentMeter.get_measurement_range(resource)
    final_integration_time = HALDmmDcCurrentMeter.get_measurement_integration_time(
        resource
    )

    errors = []

    if not compare_measurement_range(final_current_range, current_range):
        errors.append(
            ValueError(
                f"Current range mismatch: expected {current_range}, got {final_current_range}."
            )
        )
    if not compare_measurement_integration_time(
        final_integration_time, integration_time
    ):
        errors.append(
            ValueError(
                f"Integration time mismatch: expected {integration_time}, got {final_integration_time}."
            )
        )

    return final_current_range, errors
