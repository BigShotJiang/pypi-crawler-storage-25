from pydantic import validate_call

from fusaware_instruments.visa_instrument_hal.hal_dmm import (
    HALDigitalMultimeter,
    HALDmmDcVoltageMeter,
    MeasurementIntegrationTime,
    MeasurementRange,
    compare_measurement_range,
    compare_measurement_integration_time,
)


@validate_call
def configure_dc_voltage_meter(
    resource: HALDigitalMultimeter,
    voltage_range: MeasurementRange,
    integration_time: MeasurementIntegrationTime,
) -> tuple[MeasurementRange, list[ValueError]]:
    HALDmmDcVoltageMeter.initialize(resource)

    initial_voltage_range = HALDmmDcVoltageMeter.get_measurement_range(resource)
    initial_integration_time = HALDmmDcVoltageMeter.get_measurement_integration_time(
        resource
    )

    if not compare_measurement_range(voltage_range, initial_voltage_range):
        HALDmmDcVoltageMeter.set_measurement_range(resource, voltage_range)
    if not compare_measurement_integration_time(
        integration_time, initial_integration_time
    ):
        HALDmmDcVoltageMeter.set_measurement_integration_time(
            resource, integration_time
        )

    final_voltage_range = HALDmmDcVoltageMeter.get_measurement_range(resource)
    final_integration_time = HALDmmDcVoltageMeter.get_measurement_integration_time(
        resource
    )

    errors = []

    if not compare_measurement_range(final_voltage_range, voltage_range):
        errors.append(
            ValueError(
                f"Voltage range mismatch: expected {voltage_range}, got {final_voltage_range}."
            )
        )
    if not compare_measurement_integration_time(
        final_integration_time, integration_time
    ):
        errors.append(
            ValueError(
                f"Integration time mismatch: expected {integration_time}, got {final_integration_time}."
            )
        )

    return final_voltage_range, errors
