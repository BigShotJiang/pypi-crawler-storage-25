import math
from fusaware_instruments.visa_instrument_configuration.dc_voltage_supply import (
    DCVoltageSupply,
    State,
    VoltageResponse,
    VoltageSensing,
)
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply_simulator import (
    HALDCPowerSupplySimulator,
)
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    HALDCPowerSupply,
    VoltageSensingMode,
)


class DCVoltageSupplySimulator(DCVoltageSupply):
    def __init__(self, channel_name: str):
        self._channel_name: str = channel_name
        self._channel_number: int = int(channel_name[-1])

    def configure_dc_voltage_supply(
        self, current_limit: float, sensing: str, state: str, target_voltage: float
    ) -> tuple[VoltageResponse, list[str]]:
        desired_current_limit = current_limit
        desired_sensing = sensing
        desired_state = state
        desired_voltage = target_voltage

        ps = HALDCPowerSupplySimulator(self._channel_number)
        ps.connect()

        initial_current_limit = get_current_limit_from_dc_power_supply(ps)
        initial_sensing = get_sensing_from_dc_power_supply(ps)
        initial_state = get_state_from_dc_power_supply(ps)
        initial_voltage = get_voltage_from_dc_power_supply(ps)

        if not is_current_limit_equal(desired_current_limit, initial_current_limit):
            set_current_limit_on_dc_power_supply(ps, desired_current_limit)

        if not is_sensing_equal(desired_sensing, initial_sensing):
            set_sensing_on_dc_power_supply(ps, desired_sensing)

        if not is_voltage_equal(desired_voltage, initial_voltage):
            set_voltage_on_dc_power_supply(ps, desired_voltage)

        if not is_state_equal(desired_state, initial_state):
            set_state_on_dc_power_supply(ps, desired_state)

        final_current_limit = get_current_limit_from_dc_power_supply(ps)
        final_state = get_state_from_dc_power_supply(ps)
        final_sensing = get_sensing_from_dc_power_supply(ps)
        final_voltage = get_voltage_from_dc_power_supply(ps)

        errors = []

        if not is_current_limit_equal(final_current_limit, final_current_limit):
            errors.append(f"expected {final_current_limit}, got {final_current_limit}.")

        if not is_sensing_equal(desired_sensing, final_sensing):
            errors.append(f"expected {desired_sensing}, got {final_sensing}.")

        if not is_state_equal(desired_state, final_state):
            errors.append(f"expected {desired_state}, got {final_state}.")

        if not is_voltage_equal(desired_voltage, final_voltage):
            errors.append(f"expected {desired_voltage}, got {final_voltage}.")

        ps.disconnect()

        return VoltageResponse(
            current_limit=final_current_limit,
            sensing=VoltageSensing(final_sensing),
            state=State(final_state),
            target=final_voltage,
        ), errors


def is_voltage_equal(expected: float, actual: float) -> bool:
    return math.isclose(expected, actual, rel_tol=1e-04, abs_tol=1e-06)


def get_voltage_from_dc_power_supply(ps: HALDCPowerSupply) -> float:
    amplitude = ps.get_source_voltage_amplitude()
    return amplitude


def set_voltage_on_dc_power_supply(ps: HALDCPowerSupply, voltage: float) -> None:
    ps.set_source_voltage_amplitude(voltage)
    return


def is_state_equal(expected: str, actual: str) -> bool:
    return expected == actual


def _map_enable_to_state(enable: bool) -> str:
    if enable:
        return "enabled"
    elif not enable:
        return "disabled"
    else:
        raise ValueError(f"Invalid output enable state: '{enable}'.")


def get_state_from_dc_power_supply(ps: HALDCPowerSupply) -> str:
    enable = ps.get_output_enable()
    state = _map_enable_to_state(enable)
    return state


def _map_state_to_enable(state: str) -> bool:
    if state == "enabled":
        enable = True
    elif state == "disabled":
        enable = False
    else:
        raise ValueError(f"Invalid state state: '{state}'.")
    return enable


def set_state_on_dc_power_supply(ps: HALDCPowerSupply, state: str) -> None:
    enable = _map_state_to_enable(state)
    ps.set_output_enable(enable)


def is_sensing_equal(expected: str, actual: str) -> bool:
    return expected == actual


def _map_mode_to_sensing(mode: str) -> str:
    if mode == "LOCAL":
        return "local"
    elif mode == "REMOTE":
        return "remote"
    else:
        raise ValueError(f"Invalid sensing mode: {mode}")


def get_sensing_from_dc_power_supply(ps: HALDCPowerSupply) -> str:
    mode = ps.get_source_voltage_sensing_mode()
    sensing = _map_mode_to_sensing(mode.value)
    return sensing


def _map_sensing_to_sensing_param(sensing: str) -> str:
    if sensing == "local":
        return "LOCAL"
    elif sensing == "remote":
        return "REMOTE"
    else:
        raise ValueError(f"Invalid sensing mode: {sensing}")


def set_sensing_on_dc_power_supply(ps: HALDCPowerSupply, sensing: str) -> None:
    sensing_param = _map_sensing_to_sensing_param(sensing)
    ps.set_source_voltage_sensing_mode(VoltageSensingMode(sensing_param))


def is_current_limit_equal(expected: float, actual: float) -> bool:
    return math.isclose(expected, actual, rel_tol=1e-04, abs_tol=1e-06)


def get_current_limit_from_dc_power_supply(ps: HALDCPowerSupply) -> float:
    current_limit = ps.get_source_current_limit()
    return current_limit


def set_current_limit_on_dc_power_supply(
    ps: HALDCPowerSupply, current_limit: float
) -> None:
    ps.set_source_current_limit(current_limit)
