from fusaware_instruments.visa_instrument_configuration.dc_voltage_supply import (
    DCVoltageSupply,
    configure_dc_voltage_supply,
    VoltageSensing,
    State,
    VoltageResponse,
)
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply_rigol_dp import (
    HALDCPowerSupplyRigolDP800,
)


class DCVoltageSupplyRigolBase(DCVoltageSupply):
    def __init__(self, address: str, channel_name: str):
        self._address = address
        self._channel_name: str = channel_name
        self._channel_number: int = int(channel_name[-1])
        self._ps = HALDCPowerSupplyRigolDP800(self._address, self._channel_number, "")

    def configure_dc_voltage_supply(
        self, current_limit: float, sensing: str, state: str, target_voltage: float
    ) -> tuple[VoltageResponse, list[str]]:
        match sensing:
            case "local":
                sensing_value = VoltageSensing.LOCAL
            case "remote":
                sensing_value = VoltageSensing.REMOTE
            case _:
                raise ValueError(f"Invalid sensing: {sensing}")

        match state:
            case "enabled":
                state_value = State.ENABLED
            case "disabled":
                state_value = State.DISABLED
            case _:
                raise ValueError(f"Invalid state: {state}")

        return configure_dc_voltage_supply(
            self._ps, current_limit, sensing_value, state_value, target_voltage
        )


class DCVoltageSupplyRigolDP800(DCVoltageSupplyRigolBase):
    def __init__(self, address: str, channel_name: str):
        super().__init__(address, channel_name)


class DCVoltageSupplyRigolDP900(DCVoltageSupplyRigolBase):
    def __init__(self, address: str, channel_name: str):
        super().__init__(address, channel_name)


class DCVoltageSupplyRigolDP2000(DCVoltageSupplyRigolBase):
    def __init__(self, address: str, channel_name: str):
        super().__init__(address, channel_name)
