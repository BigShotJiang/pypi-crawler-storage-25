from fusaware_instruments.visa_instrument_configuration.analog_probe import (
    AnalogProbe,
    AnalogProbeState,
    configure_analog_probe,
    Coupling,
    State,
    Units,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope_rigol_mso import (
    HALOscilloscopeProbeRigolMSOBase,
)


class AnalogVoltageProbeRigolMSO5000(AnalogProbe):
    def __init__(self, address: str, channel_name: str):
        self._address = address
        self._channel_name: str = channel_name
        self._channel_number: int = int(channel_name[-1])
        self._op = HALOscilloscopeProbeRigolMSOBase(
            self._address, self._channel_number, ""
        )

    def configure_analog_probe(
        self,
        attenuation: float,
        bandwidth_limit: float | int | str,
        coupling: Coupling,
        offset: float | int,
        scale: float | int,
        state: State,
        units: Units,
    ) -> AnalogProbeState:
        probe_state, _ = configure_analog_probe(
            self._op,
            attenuation,
            bandwidth_limit,
            coupling,
            offset,
            scale,
            state,
            units,
        )

        return probe_state
