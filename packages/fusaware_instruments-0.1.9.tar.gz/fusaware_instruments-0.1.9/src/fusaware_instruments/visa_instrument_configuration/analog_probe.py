# pyright: strict

import math
from abc import ABC, abstractmethod
from enum import Enum
from typing import Tuple
import logging

from pydantic import BaseModel, validate_call

from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    Attenuation,
    HALOscilloscope,
    ProbeAttenuation,
    ProbeId,
    UnknownProbe,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    ProbeCoupling as HALCoupling,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import Units as HALUnits


class Coupling(Enum):
    AC = "ac"
    DC = "dc"
    Ground = "ground"


class State(Enum):
    Disabled = "disabled"
    Enabled = "enabled"


class Units(str, Enum):
    Amps = "amps"
    Volts = "volts"
    Watts = "watts"
    Other = "other"


class AnalogProbeState(BaseModel):
    attenuation: float
    bandwidth_limit: float | int | str
    coupling: Coupling
    offset: float
    scale: float
    state: State
    units: Units


class AnalogProbe(ABC):
    @abstractmethod
    def configure_analog_probe(
        self,
        attenuation: float,
        bandwidth_limit: float | int | str,
        coupling: Coupling,
        offset: float | int,
        scale: float | int,
        state: State,
        units: Units,
    ) -> AnalogProbeState:
        pass


@validate_call
def configure_analog_probe(
    op: HALOscilloscope,
    attenuation: float | int,
    bandwidth_limit: float | int | str,
    coupling: Coupling,
    scale: float | int,
    offset: float | int,
    state: State,
    units: Units,
) -> tuple[AnalogProbeState, list[str]]:
    desired_attenuation = Attenuation(attenuation=attenuation)
    desired_bandwidth_limit = bandwidth_limit
    desired_coupling = Coupling(coupling)
    desired_scale = scale
    desired_offset = offset
    desired_state = State(state)
    desired_units = Units(units)

    probe_id = op.get_probe_id()

    initial_state = get_state(op)
    initial_units = get_units(op)
    initial_bandwidth_limit = get_bandwidth_limit(op)
    initial_coupling = get_coupling(op)
    initial_attenuation = get_attenuation(op)
    initial_scale = get_scale(op)
    initial_offset = get_offset(op)

    if not _is_state_equal(initial_state, desired_state):
        set_state(op, desired_state)

    if not _is_units_equal(desired_units, initial_units):
        set_units(op, desired_units)

    if not _is_attenuation_equal(desired_attenuation, initial_attenuation):
        set_attenuation(op, desired_attenuation)
        op.sync()
        initial_scale = get_scale(op)
        initial_offset = get_offset(op)

    if not _is_scale_equal(desired_scale, initial_scale):
        set_scale(op, desired_scale)
        op.sync()
        initial_offset = get_offset(op)

    if not _is_offset_equal(desired_offset, initial_offset):
        set_offset(op, desired_offset)

    if not _is_bandwidth_limit_equal(desired_bandwidth_limit, initial_bandwidth_limit):
        set_bandwidth_limit(op, desired_bandwidth_limit)

    if not _is_coupling_equal(desired_coupling, initial_coupling):
        set_coupling(op, desired_coupling)

    op.sync()

    final_state = get_state(op)
    final_units = get_units(op)
    final_attenuation = get_attenuation(op)
    final_scale = get_scale(op)
    final_offset = get_offset(op)
    final_coupling = get_coupling(op)
    final_bandwidth_limit = get_bandwidth_limit(op)

    errors: list[str] = []

    # TODO make these errors a type or something
    if not _is_state_equal(final_state, desired_state):
        errors.append(f"State mismatch: expected {desired_state}, got {final_state}")

    if not _is_units_equal(final_units, desired_units):
        match probe_id:
            case ProbeId() | UnknownProbe():
                errors.append(
                    f"Probe '{probe_id.name()}' does not support units '{desired_units.value}', final units: '{final_units.value}'"
                )
            case None:
                errors.append(
                    f"Units mismatch: expected {desired_units}, got {final_units}"
                )

        # For future use

        # match probe_id:
        #     case ProbeId():
        #         valid_units = [unit.value for unit in probe_id.valid_units()]
        #         errors.append(
        #             f"""
        #             Probe '{probe_id.name()}' does not support units '{desired_units.value}'
        #             Supported units: {",".join(valid_units)}
        #             """
        #         )
        #     case UnknownProbe():
        #         errors.append(
        #             f"Probe '{probe_id.name()}' does not support units '{desired_units.value}', check its documentation for more information"
        #         )
        #     case None:
        #         errors.append(
        #             f"Units mismatch: expected {desired_units}, got {final_units}"
        #         )

    if not _is_attenuation_equal(desired_attenuation, final_attenuation):
        match probe_id:
            case ProbeId() | UnknownProbe():
                errors.append(
                    f"Probe '{probe_id.name()}' does not support attenuation '{desired_attenuation.attenuation}', final attenuation: '{final_attenuation.attenuation}'"
                )
            case None:
                errors.append(
                    f"Attenuation mismatch: expected {desired_attenuation.attenuation}, got {final_attenuation.attenuation}"
                )

    if not _is_scale_equal(desired_scale, final_scale):
        match probe_id:
            case ProbeId() | UnknownProbe():
                errors.append(
                    f"Probe '{probe_id.name()}' does not support scale '{desired_scale}', final scale: '{final_scale}'"
                )
            case None:
                errors.append(
                    f"Scale mismatch: expected {desired_scale}, got {final_scale}"
                )

    if not _is_offset_equal(desired_offset, final_offset):
        match probe_id:
            case ProbeId() | UnknownProbe():
                errors.append(
                    f"Probe '{probe_id.name()}' does not support offset '{desired_offset}', final offset: '{final_offset}'"
                )
            case None:
                errors.append(
                    f"Offset mismatch: expected {desired_offset}, got {final_offset}"
                )

    if not _is_coupling_equal(desired_coupling, final_coupling):
        match probe_id:
            case ProbeId() | UnknownProbe():
                logging.warning(
                    f"Probe '{probe_id.name()}' does not support coupling '{desired_coupling.value}', final coupling: '{final_coupling.value}'"
                )
            case None:
                errors.append(
                    f"Coupling mismatch: expected {desired_coupling.value}, got {final_coupling.value}"
                )

    if not _is_bandwidth_limit_equal(desired_bandwidth_limit, final_bandwidth_limit):
        match probe_id:
            case ProbeId() | UnknownProbe():
                logging.warning(
                    f"Probe '{probe_id.name()}' does not support bandwidth limit '{desired_bandwidth_limit}', final bandwidth limit: '{final_bandwidth_limit}'"
                )
            case None:
                errors.append(
                    f"Bandwidth limit mismatch: expected {desired_bandwidth_limit}, got {final_bandwidth_limit}"
                )

    return AnalogProbeState(
        attenuation=final_attenuation.attenuation,
        bandwidth_limit=final_bandwidth_limit,
        coupling=final_coupling,
        scale=final_scale,
        offset=final_offset,
        state=final_state,
        units=final_units,
    ), errors


def _is_attenuation_equal(expected: ProbeAttenuation, actual: ProbeAttenuation) -> bool:
    return math.isclose(
        expected.attenuation, actual.attenuation, rel_tol=1e-4, abs_tol=1e-6
    )


def get_attenuation(op: HALOscilloscope) -> ProbeAttenuation:
    attenuation = op.get_probe_attenuation()
    return attenuation


def set_attenuation(op: HALOscilloscope, attenuation: ProbeAttenuation) -> None:
    op.set_probe_attenuation(attenuation.attenuation)


def _map_bandwidth_limit_to_hal_bandwidth_limit(
    bandwidth_limit: float | int | str,
) -> Tuple[bool, float | int]:
    if isinstance(bandwidth_limit, str) and bandwidth_limit == "none":
        hal_enable = False
        hal_bandwidth_limit = 0.0
    elif isinstance(bandwidth_limit, (float, int)):
        hal_enable = True
        hal_bandwidth_limit = bandwidth_limit
    else:
        raise ValueError(f"Invalid bandwidth limit {bandwidth_limit}")

    return hal_enable, hal_bandwidth_limit


def _is_bandwidth_limit_equal(
    expected: float | int | str, actual: float | int | str
) -> bool:
    match expected, actual:
        case str(), str():
            return expected == actual
        case float() | int(), float() | int():
            return math.isclose(
                expected,
                actual,
                rel_tol=1e-4,
                abs_tol=1e-6,
            )
        case _:
            return False


def get_bandwidth_limit(op: HALOscilloscope) -> float | int | str:
    enable, bandwidth = op.get_probe_bandwidth_limit()

    if enable:
        return bandwidth
    else:
        return "none"


def set_bandwidth_limit(
    op: HALOscilloscope, bandwidth_limit: float | int | str
) -> None:
    hal_enable, hal_bandwidth_limit = _map_bandwidth_limit_to_hal_bandwidth_limit(
        bandwidth_limit
    )
    op.set_probe_bandwidth_limit(hal_enable, hal_bandwidth_limit)


def _map_hal_units_to_units(units: HALUnits) -> Units:
    match units:
        case HALUnits.VOLTS:
            return Units.Volts
        case HALUnits.AMPS:
            return Units.Amps
        case HALUnits.WATTS:
            return Units.Watts
        case HALUnits.CUSTOM:
            return Units.Other


def _map_units_to_hal_units(units: Units) -> HALUnits:
    match units:
        case Units.Volts:
            return HALUnits.VOLTS
        case Units.Amps:
            return HALUnits.AMPS
        case Units.Watts:
            return HALUnits.WATTS
        case Units.Other:
            return HALUnits.CUSTOM


def _is_units_equal(first: Units, second: Units) -> bool:
    return first == second


def get_units(op: HALOscilloscope) -> Units:
    hal_units = op.get_probe_units()
    units = _map_hal_units_to_units(hal_units)
    return units


def set_units(op: HALOscilloscope, units: Units):
    hal_units = _map_units_to_hal_units(units)
    op.set_probe_units(hal_units)
    return


def _map_hal_coupling_to_coupling(coupling: HALCoupling) -> Coupling:
    if coupling == HALCoupling.AC:
        return Coupling.AC
    elif coupling == HALCoupling.DC:
        return Coupling.DC
    elif coupling == HALCoupling.GROUND:
        return Coupling.Ground
    raise ValueError(f"Invalid hal coupling: {coupling}")


def _map_coupling_to_hal_coupling(coupling: Coupling) -> HALCoupling:
    if coupling == Coupling.AC:
        return HALCoupling.AC
    elif coupling == Coupling.DC:
        return HALCoupling.DC
    elif coupling == Coupling.Ground:
        return HALCoupling.GROUND
    raise ValueError(f"Invalid coupling: {coupling}")


def _is_coupling_equal(first: Coupling, second: Coupling) -> bool:
    return first == second


def get_coupling(op: HALOscilloscope) -> Coupling:
    coupling_param = op.get_probe_coupling()
    coupling = _map_hal_coupling_to_coupling(coupling_param)
    return coupling


def set_coupling(op: HALOscilloscope, coupling: Coupling) -> None:
    coupling_param = _map_coupling_to_hal_coupling(coupling)
    op.set_probe_coupling(coupling_param)


def _map_hal_scale_to_scale(hal_scale: float | int) -> float | int:
    scale = hal_scale
    return scale


def _map_scale_to_scale_param(scale: float | int) -> float | int:
    scale_param = scale
    return scale_param


def _is_scale_equal(first: float | int, second: float | int) -> bool:
    return math.isclose(first, second, rel_tol=1e-4, abs_tol=1e-6)


def get_scale(op: HALOscilloscope) -> float | int:
    scale_param = op.get_probe_scale()
    scale = _map_hal_scale_to_scale(scale_param)
    return scale


def set_scale(op: HALOscilloscope, scale: float | int) -> None:
    scale_param = _map_scale_to_scale_param(scale)
    op.set_probe_scale(scale_param)


def _map_offset_param_to_offset(hal_offset: float | int) -> float | int:
    offset = hal_offset
    return offset


def _map_offset_to_hal_offset(offset: float | int) -> float | int:
    hal_offset = offset
    return hal_offset


def _is_offset_equal(first: float | int, second: float | int) -> bool:
    return math.isclose(first, second, rel_tol=1e-4, abs_tol=1e-6)


def get_offset(op: HALOscilloscope) -> float | int:
    offset_param = op.get_probe_offset()
    offset = _map_offset_param_to_offset(offset_param)
    return offset


def set_offset(op: HALOscilloscope, offset: float | int) -> None:
    offset_param = _map_offset_to_hal_offset(offset)
    op.set_probe_offset(offset_param)


def _map_hal_display_to_state(display_param: bool) -> State:
    if display_param:
        return State.Enabled
    elif not display_param:
        return State.Disabled
    raise Exception(f"Invalid display param {display_param}")


def _map_state_to_hal_display(state: State) -> bool:
    if state == State.Disabled:
        return False
    elif state == State.Enabled:
        return True
    raise Exception(f"Invalid state {state}")


def _is_state_equal(first: State, second: State) -> bool:
    return first == second


def get_state(op: HALOscilloscope) -> State:
    display = op.get_probe_display()
    state = _map_hal_display_to_state(display)
    return state


def set_state(op: HALOscilloscope, state: State) -> None:
    display = _map_state_to_hal_display(state)
    op.set_probe_display(display)
