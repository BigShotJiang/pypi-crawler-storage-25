import math
from abc import ABC, abstractmethod
from enum import Enum

from pydantic import BaseModel, validate_call

from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    HALDCPowerSupply,
    VoltageSensingMode,
)


class VoltageSensing(Enum):
    LOCAL = "local"
    REMOTE = "remote"
    UNKNOWN = "unknown"


class State(Enum):
    DISABLED = "disabled"
    ENABLED = "enabled"


class VoltageResponse(BaseModel):
    state: State
    sensing: VoltageSensing
    target: float
    current_limit: float


class DCVoltageSupply(ABC):
    @abstractmethod
    def configure_dc_voltage_supply(
        self, current_limit: float, sensing: str, state: str, target_voltage: float
    ) -> tuple[VoltageResponse, list[str]]:
        pass


@validate_call
def configure_dc_voltage_supply(
    ps: HALDCPowerSupply,
    current_limit: float,
    sensing: VoltageSensing,
    state: State,
    target_voltage: float,
) -> tuple[VoltageResponse, list[str]]:
    desired_current_limit = current_limit
    desired_voltage_sensing = sensing
    desired_target_voltage = target_voltage
    desired_state = state

    initial_current_limit = get_current_limit(ps)
    initial_voltage_sensing = get_sensing(ps)
    initial_target_voltage = get_target_voltage(ps)
    initial_state = get_state(ps)

    if not _is_current_limit_equal(desired_current_limit, initial_current_limit):
        set_current_limit(ps, desired_current_limit)
    if not _is_sensing_equal(desired_voltage_sensing, initial_voltage_sensing):
        set_sensing(ps, desired_voltage_sensing)
    if not _is_target_voltage_equal(desired_target_voltage, initial_target_voltage):
        set_target_voltage(ps, desired_target_voltage)
    if not _is_state_equal(desired_state, initial_state):
        set_state(ps, desired_state)

    ps.sync()

    final_current_limit = get_current_limit(ps)
    final_sensing = get_sensing(ps)
    final_target_voltage = get_target_voltage(ps)
    final_state = get_state(ps)

    errors = []

    if not _is_current_limit_equal(final_current_limit, final_current_limit):
        errors.append(
            f"current_limit: expected {final_current_limit}, got {final_current_limit}."
        )
    # Don't fail reconciliation if sensing is UNKNOWN
    if (
        not _is_sensing_equal(desired_voltage_sensing, final_sensing)
        and final_sensing != VoltageSensing.UNKNOWN
    ):
        errors.append(
            f"sensing: expected {desired_voltage_sensing}, got {final_sensing}."
        )
    if not _is_target_voltage_equal(desired_target_voltage, final_target_voltage):
        errors.append(
            f"target_voltage: expected {desired_target_voltage}, got {final_target_voltage}."
        )
    if not _is_state_equal(desired_state, final_state):
        errors.append(f"state: expected {desired_state}, got {final_state}.")

    return VoltageResponse(
        state=final_state,
        sensing=final_sensing,
        target=final_target_voltage,
        current_limit=final_current_limit,
    ), errors


def _is_target_voltage_equal(expected: float, actual: float) -> bool:
    return math.isclose(expected, actual, rel_tol=1e-04, abs_tol=1e-06)


def get_target_voltage(ps: HALDCPowerSupply) -> float:
    amplitude = ps.get_source_voltage_amplitude()
    return amplitude


def set_target_voltage(ps: HALDCPowerSupply, voltage: float) -> None:
    ps.set_source_voltage_amplitude(voltage)
    return


def _map_hal_enable_to_state(enable: bool) -> State:
    if enable:
        return State.ENABLED
    elif not enable:
        return State.DISABLED


def _map_state_to_hal_enable(state: State) -> bool:
    if state == State.ENABLED:
        return True
    elif state == State.DISABLED:
        return False


def _is_state_equal(expected: State, actual: State) -> bool:
    return expected == actual


def get_state(ps: HALDCPowerSupply) -> State:
    enable_param = ps.get_output_enable()
    state = _map_hal_enable_to_state(enable_param)
    return State(state)


def set_state(ps: HALDCPowerSupply, state: State) -> None:
    enable_param = _map_state_to_hal_enable(state)
    ps.set_output_enable(enable_param)


def _map_hal_mode_to_sensing(mode_param: VoltageSensingMode) -> VoltageSensing:
    match mode_param:
        case VoltageSensingMode.LOCAL:
            return VoltageSensing.LOCAL
        case VoltageSensingMode.REMOTE:
            return VoltageSensing.REMOTE
        case VoltageSensingMode.UNKNOWN:
            return VoltageSensing.UNKNOWN


def _map_sensing_to_hal_mode(sensing: VoltageSensing) -> VoltageSensingMode:
    match sensing:
        case VoltageSensing.LOCAL:
            return VoltageSensingMode.LOCAL
        case VoltageSensing.REMOTE:
            return VoltageSensingMode.REMOTE
        case VoltageSensing.UNKNOWN:
            return VoltageSensingMode.UNKNOWN


def _is_sensing_equal(first: VoltageSensing, second: VoltageSensing) -> bool:
    return first == second


def get_sensing(ps: HALDCPowerSupply) -> VoltageSensing:
    mode_param = ps.get_source_voltage_sensing_mode()
    sensing = _map_hal_mode_to_sensing(mode_param)
    return sensing


def set_sensing(ps: HALDCPowerSupply, sensing: VoltageSensing) -> None:
    mode_param = _map_sensing_to_hal_mode(sensing)
    ps.set_source_voltage_sensing_mode(mode_param)


def _map_hal_current_limit_to_current_limit(hal_current_limit: float) -> float:
    current_limit = hal_current_limit
    return current_limit


def _map_current_limit_to_current_limit_param(current_limit: float) -> float:
    hal_current_limit = current_limit
    return hal_current_limit


def _is_current_limit_equal(expected: float, actual: float) -> bool:
    return math.isclose(expected, actual, rel_tol=1e-04, abs_tol=1e-06)


def get_current_limit(ps: HALDCPowerSupply) -> float:
    current_limit_param = ps.get_source_current_limit()
    current_limit = _map_hal_current_limit_to_current_limit(current_limit_param)
    return current_limit


def set_current_limit(ps: HALDCPowerSupply, current_limit: float) -> None:
    current_limit_param = _map_current_limit_to_current_limit_param(current_limit)
    ps.set_source_current_limit(current_limit_param)
