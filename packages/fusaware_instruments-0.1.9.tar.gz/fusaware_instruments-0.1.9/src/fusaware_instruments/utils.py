# pyright: strict

from typing import Protocol
from dataclasses import dataclass
from enum import Enum
import logging

import pyvisa as pv


class VisaIO(Protocol):
    def query(self, message: str) -> str: ...

    def write(self, message: str) -> int: ...

    def read(self) -> str: ...

    def read_bytes(self, count: int) -> bytes: ...

    def read_raw(self, size: int | None = None) -> bytes: ...


class PyvisaIO(VisaIO):
    def __init__(self, resource: pv.resources.MessageBasedResource):
        self._resource = resource

    def query(self, message: str) -> str:
        resp = self._resource.query(message)
        logging.info(
            f"Query: '{message}' -> Response: '{resp[:20] if len(resp) > 20 else resp}'"
        )
        return resp

    def write(self, message: str) -> int:
        logging.info(f"Write: '{message}'")
        return self._resource.write(message)

    def read(self) -> str:
        resp = self._resource.read()
        logging.info(f"Read: '{resp}'")
        return resp

    def read_bytes(self, count: int) -> bytes:
        read_term = self._resource.read_termination

        try:
            self._resource.read_termination = None
            resp = self._resource.read_bytes(count)
            logging.info(f"Read bytes: {resp[:20] if len(resp) > 20 else resp}")
            return resp
        except Exception as e:
            logging.error(f"Error: {e}")
            raise e
        finally:
            self._resource.read_termination = read_term

    def read_raw(self, size: int | None = None) -> bytes:
        read_term = self._resource.read_termination

        try:
            self._resource.read_termination = None
            resp = self._resource.read_raw(size)
            logging.info(f"Read raw: {resp[:20] if len(resp) > 20 else resp}")
            return resp
        except Exception as e:
            logging.error(f"Error: {e}")
            raise e
        finally:
            self._resource.read_termination = read_term


@dataclass
class ScpiParseError(Exception):
    response: str
    query: str
    message: str | None = None

    def __str__(self):
        if self.message is None:
            return f"ScpiParseError: Could not parse response '{self.response}' for query '{self.query}'"
        else:
            return self.message


@dataclass
class ReconcileException[T](Exception):
    param_name: str
    expected: T
    actual: T
    message: str | None = None

    def __str__(self):
        if self.message is None:
            return f"ReconcileException: Parameter '{self.param_name}' did not reconcile: expected '{self.expected}' but got '{self.actual}'"
        else:
            return self.message


class MappingDirection(Enum):
    ConfigToHal = "CONFIG_TO_HAL"
    HalToConfig = "HAL_TO_CONFIG"
    HalToDriver = "HAL_TO_DRIVER"
    DriverToHal = "DRIVER_TO_HAL"


@dataclass
class MappingExceptionBase(Exception):
    direction: MappingDirection
    from_type: type
    to_type: type


@dataclass
class MappingException[T](MappingExceptionBase):
    direction: MappingDirection
    from_type: type
    to_type: type
    value: T

    def __str__(self) -> str:
        match self.direction:
            case MappingDirection.ConfigToHal:
                return f"Configuration value '{self.value}' of type {self.from_type} cannot be mapped to HAL representation of type {self.to_type}."
            case MappingDirection.HalToConfig:
                return f"HAL value '{self.value}' of type {self.to_type} cannot be mapped to configuration representation of type {self.from_type}."
            case MappingDirection.HalToDriver:
                return f"HAL value '{self.value}' of type {self.to_type} cannot be mapped to driver representation of type {self.from_type}."
            case MappingDirection.DriverToHal:
                return f"Driver value '{self.value}' of type {self.from_type} cannot be mapped to HAL representation of type {self.to_type}."


def compare_floats(a: float, b: float, tolerance: float = 1e-9) -> bool:
    return abs(a - b) <= tolerance


def _scpi_short_form(long_form: str) -> str:
    """
    Return the SCPI short form of a mixed-case command keyword.

    SCPI-1999 / IEEE 488.2 convention: the short form is the leading run of
    uppercase characters (plus any intervening digits), e.g. ``"WIDth" ->
    "WID"``, ``"TIMEOut" -> "TIMEO"``, ``"WINdow" -> "WIN"``. A keyword with
    no lowercase letters (e.g. ``"EDGE"``) has no abbreviated short form
    distinct from itself; callers rely on exact-match logic for those.
    """
    out: list[str] = []
    for ch in long_form:
        if ch.isupper() or ch.isdigit() or ch == "_":
            out.append(ch)
        else:
            break
    return "".join(out)


# Add some safety around SCPI responses whose case and abbreviation level are
# under-specified: many instruments respond in UPPERCASE regardless of how the
# command is documented (e.g. "BINARY" for a documented "BINary"), and when
# HEADer is turned on some return the abbreviated form (e.g. "WID" for
# "WIDth"). We match both here so driver enums can mirror the documentation
# verbatim and still parse real-world responses.
class CaseInsensitiveEnum(Enum):
    @classmethod
    def _missing_(cls, value: object) -> "CaseInsensitiveEnum | None":
        if not isinstance(value, str):
            return None

        value_upper = value.upper()

        for member in cls:
            if member.value.upper() == value_upper:
                return member

        for member in cls:
            short = _scpi_short_form(member.value).upper()
            if short and short == value_upper:
                return member

        return None
