# pyright: strict

from abc import ABC, abstractmethod

from pydantic import BaseModel

from fusaware_instruments.visa.oscilloscope.types import (
    AcquisitionCondition,
    AcquisitionState,
    ImageFormat,
    Preamble,
    ProbeAttenuation,
    ProbeBandwidthLimit,
    ProbeCoupling,
    ProbeId,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerState,
    TriggerSweep,
    Units,
    UnknownProbe,
    WaveformEncoding,
)


class HALOscilloscope(ABC, BaseModel):
    @abstractmethod
    def __init__(self, resource_name: str): ...

    @abstractmethod
    def connect(self): ...

    @abstractmethod
    def disconnect(self): ...

    @abstractmethod
    def get_probe_attenuation(self) -> ProbeAttenuation: ...

    @abstractmethod
    def set_probe_attenuation(self, attenuation: float | int) -> None: ...

    @abstractmethod
    def apply_probe_attenuation(self, attenuation: float | int) -> ProbeAttenuation: ...

    @abstractmethod
    def get_probe_bandwidth_limit(self) -> ProbeBandwidthLimit: ...

    @abstractmethod
    def set_probe_bandwidth_limit(
        self, bandwidth_limit: ProbeBandwidthLimit
    ) -> None: ...

    @abstractmethod
    def apply_probe_bandwidth_limit(
        self, bandwidth_limit: ProbeBandwidthLimit
    ) -> ProbeBandwidthLimit: ...

    @abstractmethod
    def get_probe_coupling(self) -> ProbeCoupling: ...

    @abstractmethod
    def set_probe_coupling(self, coupling: ProbeCoupling) -> None: ...

    @abstractmethod
    def apply_probe_coupling(self, coupling: ProbeCoupling) -> ProbeCoupling: ...

    @abstractmethod
    def get_probe_display(self) -> bool: ...

    @abstractmethod
    def set_probe_display(self, display: bool) -> None: ...

    @abstractmethod
    def apply_probe_display(self, display: bool) -> bool: ...

    @abstractmethod
    def get_probe_offset(self) -> float | int: ...

    @abstractmethod
    def set_probe_offset(self, offset: float | int) -> None: ...

    @abstractmethod
    def apply_probe_offset(self, offset: float | int) -> float | int: ...

    @abstractmethod
    def get_probe_scale(self) -> float | int: ...

    @abstractmethod
    def set_probe_scale(self, scale: float | int) -> None: ...

    @abstractmethod
    def apply_probe_scale(self, scale: float | int) -> float | int: ...

    @abstractmethod
    def get_probe_units(self) -> Units: ...

    @abstractmethod
    def set_probe_units(self, units: Units) -> None: ...

    @abstractmethod
    def apply_probe_units(self, units: Units) -> Units: ...

    @abstractmethod
    def get_timebase_offset(self) -> float | int: ...

    @abstractmethod
    def set_timebase_offset(self, offset: float | int) -> None: ...

    @abstractmethod
    def apply_timebase_offset(self, offset: float | int) -> float | int: ...

    @abstractmethod
    def get_timebase_scale(self) -> float | int: ...

    @abstractmethod
    def set_timebase_scale(self, scale: float | int) -> None: ...

    @abstractmethod
    def apply_timebase_scale(self, scale: float | int) -> float | int: ...

    @abstractmethod
    def get_trigger_coupling(self) -> TriggerCoupling: ...

    @abstractmethod
    def set_trigger_coupling(self, coupling: TriggerCoupling) -> None: ...

    @abstractmethod
    def apply_trigger_coupling(self, coupling: TriggerCoupling) -> TriggerCoupling: ...

    @abstractmethod
    def get_trigger_holdoff(self) -> float: ...

    @abstractmethod
    def set_trigger_holdoff(self, holdoff: float) -> None: ...

    @abstractmethod
    def apply_trigger_holdoff(self, holdoff: float) -> float: ...

    @abstractmethod
    def get_trigger_mode(self) -> TriggerMode: ...

    @abstractmethod
    def set_trigger_mode(self, mode: TriggerMode) -> None: ...

    @abstractmethod
    def apply_trigger_mode(self, mode: TriggerMode) -> TriggerMode: ...

    @abstractmethod
    def get_trigger_slope(self) -> TriggerSlope: ...

    @abstractmethod
    def set_trigger_slope(self, slope: TriggerSlope) -> None: ...

    @abstractmethod
    def apply_trigger_slope(self, slope: TriggerSlope) -> TriggerSlope: ...

    @abstractmethod
    def get_trigger_threshold(self) -> float: ...

    @abstractmethod
    def set_trigger_threshold(self, threshold: float) -> None: ...

    @abstractmethod
    def apply_trigger_threshold(self, threshold: float) -> float: ...

    @abstractmethod
    def get_trigger_state(self) -> TriggerState: ...

    @abstractmethod
    def set_trigger_state(self, state: TriggerState) -> None: ...

    @abstractmethod
    def apply_trigger_state(self, state: TriggerState) -> TriggerState: ...

    @abstractmethod
    def get_trigger_sweep(self) -> TriggerSweep: ...

    @abstractmethod
    def set_trigger_sweep(self, sweep: TriggerSweep) -> None: ...

    @abstractmethod
    def apply_trigger_sweep(self, sweep: TriggerSweep) -> TriggerSweep: ...

    @abstractmethod
    def get_sample_rate(self) -> float: ...

    @abstractmethod
    def set_sample_rate(self, sample_rate: float) -> None: ...

    @abstractmethod
    def apply_sample_rate(self, sample_rate: float) -> float: ...

    @abstractmethod
    def get_sample_count(self) -> float: ...

    @abstractmethod
    def set_sample_count(self, sample_count: float) -> None: ...

    @abstractmethod
    def apply_sample_count(self, sample_count: float) -> float: ...

    @abstractmethod
    def get_image_format(self) -> ImageFormat: ...

    @abstractmethod
    def set_image_format(self, image_format: ImageFormat) -> None: ...

    @abstractmethod
    def apply_image_format(self, image_format: ImageFormat) -> ImageFormat: ...

    @abstractmethod
    def get_screenshot(self) -> bytes: ...

    @abstractmethod
    def get_waveform_preamble(self) -> Preamble: ...

    @abstractmethod
    def get_waveform_start_index(self) -> int: ...

    @abstractmethod
    def set_waveform_start_index(self, start_index: int) -> None: ...

    @abstractmethod
    def apply_waveform_start_index(self, start_index: int) -> int: ...

    @abstractmethod
    def get_waveform_stop_index(self) -> int: ...

    @abstractmethod
    def set_waveform_stop_index(self, stop_index: int) -> None: ...

    @abstractmethod
    def apply_waveform_stop_index(self, stop_index: int) -> int: ...

    @abstractmethod
    def get_waveform_encoding(self) -> WaveformEncoding: ...

    @abstractmethod
    def set_waveform_encoding(self, encoding: WaveformEncoding) -> None: ...

    @abstractmethod
    def apply_waveform_encoding(
        self, encoding: WaveformEncoding
    ) -> WaveformEncoding: ...

    @abstractmethod
    def get_waveform_data(self) -> list[float]: ...

    @abstractmethod
    def apply_waveform_source(self) -> None: ...

    @abstractmethod
    def get_probe_id(self) -> ProbeId | UnknownProbe | None: ...

    @abstractmethod
    def sync(self) -> bool: ...

    @abstractmethod
    def get_acquisition_state(self) -> AcquisitionState: ...

    @abstractmethod
    def set_acquisition_state(self, state: AcquisitionState) -> None: ...

    @abstractmethod
    def get_acquisition_condition(self) -> AcquisitionCondition: ...

    @abstractmethod
    def set_acquisition_condition(self, condition: AcquisitionCondition) -> None: ...
