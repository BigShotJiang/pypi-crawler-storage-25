# pyright: strict

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Literal

from pydantic import BaseModel

from fusaware_instruments.utils import compare_floats


class WaveformSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    CH5 = "CH5"
    CH6 = "CH6"
    CH7 = "CH7"
    CH8 = "CH8"


class AcquisitionState(str, Enum):
    RUNNING = "running"
    STOPPED = "stopped"
    SINGLE = "single"


class AcquisitionCondition(str, Enum):
    TRIGGER = "trigger"
    AUTO = "auto"
    ROLLING = "rolling"


class ProbeCoupling(Enum):
    AC = "ac"
    DC = "dc"
    GROUND = "ground"


class TriggerCoupling(str, Enum):
    AC = "ac"
    DC = "dc"


class TriggerMode(str, Enum):
    EDGE = "edge"
    CAN = "can"


class TriggerSlope(str, Enum):
    RISING = "rising"
    FALLING = "falling"
    EITHER = "either_edge"


class TriggerState(Enum):
    ENABLED = "enabled"
    DISABLED = "disabled"


class TriggerSweep(str, Enum):
    AUTO = "auto"
    SINGLE = "single"
    NORMAL = "normal"


class ImageFormat(Enum):
    PNG = "png"
    BMP = "bmp"
    JPG = "jpg"


class WaveformEncoding(str, Enum):
    CSV = "csv"
    BINARY = "binary"
    OTHER = "other"


class Units(str, Enum):
    AMPS = "amps"
    VOLTS = "volts"
    WATTS = "watts"
    OTHER = "other"


# WIP
class Preamble(BaseModel):
    source: int
    format: WaveformEncoding
    count: int
    x_increment: float
    x_origin: float
    x_reference: int
    x_zero: float
    x_units: str
    y_increment: float
    y_origin: float
    y_reference: int
    y_zero: float
    y_units: Units


class FixedAttenuation(BaseModel):
    attenuation: float | int


class Attenuation(BaseModel):
    attenuation: float | int


type ProbeAttenuation = FixedAttenuation | Attenuation


class State(Enum):
    Disabled = "disabled"
    Enabled = "enabled"


class ProbeId(ABC):
    @abstractmethod
    def name(self) -> str: ...

    # For future use

    # @abstractmethod
    # def valid_attenutations(self) -> list[float | int]: ...
    #
    # @abstractmethod
    # def valid_bandwidth_limits(self) -> list[float | int | Literal["none"]]: ...
    #
    # @abstractmethod
    # def valid_couplings(self) -> list[ProbeCoupling]: ...
    #
    # @abstractmethod
    # def valid_scales(self) -> list[float | int]: ...
    #
    # @abstractmethod
    # def valid_units(self) -> list[Units]: ...


class UnknownProbe:
    def __init__(self, name: str):
        self._name = name

    def name(self) -> str:
        return self._name


@dataclass
class ProbeBandwidthLimit:
    limit: float | int | Literal["none"]

    def __eq__(self, value: object, /) -> bool:
        if not isinstance(value, ProbeBandwidthLimit):
            return False

        match self.limit:
            case float() | int():
                if value.limit == "none":
                    return False
                if not compare_floats(self.limit, value.limit):
                    return False
            case "none":
                if value.limit != "none":
                    return False

        return True
