# pyright: strict

import struct
import time
import traceback

import fusaware_instruments.visa.oscilloscope.tektronix.mdo_3_series.driver as driver
from fusaware_instruments.utils import (
    MappingDirection,
    MappingException,
    ReconcileException,
    ScpiParseError,
    VisaIO,
    compare_floats,
)
from fusaware_instruments.visa.oscilloscope.hal import (
    HALOscilloscope,
)
from fusaware_instruments.visa.oscilloscope.tektronix.mdo_3_series.driver import (
    DEFAULT_OFFSET_PERCENTAGE,
    MAX_ANALOG_SAMPLE_RATE,
    NUM_HORIZONTAL_DIVISIONS,
    VALID_RECORD_LENGTHS,
    AnalogChannel,
    ChannelDisplayState,
    ProbeType,
    TektronixMdo3SeriesDriver,
)
from fusaware_instruments.visa.oscilloscope.types import (
    AcquisitionCondition,
    AcquisitionState,
    Attenuation,
    FixedAttenuation,
    ImageFormat,
    Preamble,
    ProbeAttenuation,
    ProbeBandwidthLimit,
    ProbeCoupling,
    ProbeId,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerState,
    TriggerSweep,
    Units,
    UnknownProbe,
    WaveformEncoding,
)


class Mdo34Probe(ProbeId):
    def __init__(self, name: str) -> None:
        self._name = name

    def name(self) -> str:
        return self._name


class Conversions:
    @staticmethod
    def units_to_driver(units: Units) -> driver.ProbeUnits:
        match units:
            case Units.VOLTS:
                return driver.ProbeUnits.VOLTS
            case Units.AMPS:
                return driver.ProbeUnits.AMPS
            case Units.WATTS:
                return driver.ProbeUnits.WATTS
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=Units,
                    to_type=driver.ProbeUnits,
                    value=units,
                )

    @staticmethod
    def units_from_driver(units: driver.ProbeUnits) -> Units:
        match units:
            case driver.ProbeUnits.VOLTS:
                return Units.VOLTS
            case driver.ProbeUnits.AMPS:
                return Units.AMPS
            case driver.ProbeUnits.WATTS:
                return Units.WATTS


class HALOscilloscopeProbeTektronixMdo3Series(HALOscilloscope):
    def __init__(self, io: VisaIO, channel_number: int):
        self._io = io
        self._channel = AnalogChannel(channel_number)
        self._driver = TektronixMdo3SeriesDriver(io)

    def connect(self):
        pass

    def disconnect(self):
        pass

    def get_probe_attenuation(self) -> ProbeAttenuation:
        gain = self._driver.query_channel_probe_gain(self._channel)
        return Attenuation(attenuation=1 / gain)

    def set_probe_attenuation(self, attenuation: float | int) -> None:
        self._driver.write_channel_probe_gain(self._channel, 1 / attenuation)

    def apply_probe_attenuation(self, attenuation: float | int) -> ProbeAttenuation:
        self.set_probe_attenuation(attenuation)
        actual = self.get_probe_attenuation()

        match actual:
            case FixedAttenuation():
                if not compare_floats(actual.attenuation, attenuation):
                    raise ReconcileException(
                        param_name="attenuation",
                        expected=attenuation,
                        actual=actual,
                        message=f"""
                        Attenuation is fixed for this probe, so the actual attenuation cannot be changed.
                        Expected attenuation was {attenuation}, but actual attenuation is {actual.attenuation}.
                        """,
                    )
            case Attenuation():
                if not compare_floats(actual.attenuation, attenuation):
                    raise ReconcileException(
                        param_name="attenuation",
                        expected=attenuation,
                        actual=actual,
                    )

        return actual

    def get_probe_bandwidth_limit(self) -> ProbeBandwidthLimit:
        bandwidth_limit = self._driver.query_channel_bandwidth(self._channel)

        match bandwidth_limit:
            case "FULL":
                return ProbeBandwidthLimit(limit="none")
            case float() | int():
                return ProbeBandwidthLimit(limit=bandwidth_limit)

    def set_probe_bandwidth_limit(self, bandwidth_limit: ProbeBandwidthLimit) -> None:
        if bandwidth_limit.limit == "none":
            self._driver.write_channel_bandwidth(self._channel, "FULL")
        else:
            self._driver.write_channel_bandwidth(self._channel, bandwidth_limit.limit)

    def apply_probe_bandwidth_limit(
        self, bandwidth_limit: ProbeBandwidthLimit
    ) -> ProbeBandwidthLimit:
        self.set_probe_bandwidth_limit(bandwidth_limit)
        actual_bandwidth_limit = self.get_probe_bandwidth_limit()

        if actual_bandwidth_limit != bandwidth_limit:
            raise ReconcileException(
                param_name="bandwidth_limit",
                expected=bandwidth_limit,
                actual=actual_bandwidth_limit,
            )

        return actual_bandwidth_limit

    def get_probe_coupling(self) -> ProbeCoupling:
        match self._driver.query_channel_coupling(self._channel):
            case driver.ProbeCoupling.DC:
                return ProbeCoupling.DC
            case driver.ProbeCoupling.AC:
                return ProbeCoupling.AC
            case driver.ProbeCoupling.DCREJ:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=ProbeCoupling,
                    to_type=driver.ProbeCoupling,
                    value=driver.ProbeCoupling.DCREJ,
                )

    def set_probe_coupling(self, coupling: ProbeCoupling) -> None:
        match coupling:
            case ProbeCoupling.DC:
                driver_coupling = driver.ProbeCoupling.DC
            case ProbeCoupling.AC:
                driver_coupling = driver.ProbeCoupling.AC
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=ProbeCoupling,
                    to_type=driver.ProbeCoupling,
                    value=coupling,
                )

        self._driver.write_channel_coupling(self._channel, driver_coupling)

    def apply_probe_coupling(self, coupling: ProbeCoupling) -> ProbeCoupling:
        self.set_probe_coupling(coupling)
        actual = self.get_probe_coupling()

        if actual != coupling:
            raise ReconcileException(
                param_name="coupling", expected=coupling, actual=actual
            )

        return actual

    def get_probe_display(self) -> bool:
        match self._driver.query_channel_select(self._channel):
            case ChannelDisplayState.ON:
                return True
            case ChannelDisplayState.OFF:
                return False

    def set_probe_display(self, display: bool) -> None:
        self._driver.write_channel_select(
            self._channel,
            ChannelDisplayState.ON if display else ChannelDisplayState.OFF,
        )

    def apply_probe_display(self, display: bool) -> bool:
        self.set_probe_display(display)
        actual = self.get_probe_display()

        if actual != display:
            raise ReconcileException(
                param_name="display_state", expected=display, actual=actual
            )

        return actual

    def get_probe_offset(self) -> float | int:
        scale = self.get_probe_scale()
        return self._driver.query_channel_position(self._channel) * scale

    def set_probe_offset(self, offset: float | int) -> None:
        offset_divisions = offset / self.get_probe_scale()
        self._driver.write_channel_position(self._channel, offset_divisions)

    def apply_probe_offset(self, offset: float | int) -> float | int:
        self.set_probe_offset(offset)
        actual = self.get_probe_offset()

        if not compare_floats(actual, offset):
            raise ReconcileException(
                param_name="offset", expected=offset, actual=actual
            )

        return actual

    def get_probe_scale(self) -> float | int:
        return self._driver.query_channel_scale(self._channel)

    def set_probe_scale(self, scale: float | int) -> None:
        self._driver.write_channel_scale(self._channel, scale)

    def apply_probe_scale(self, scale: float | int) -> float | int:
        self.set_probe_scale(scale)
        actual = self.get_probe_scale()

        if not compare_floats(actual, scale):
            raise ReconcileException(param_name="scale", expected=scale, actual=actual)

        return actual

    def get_probe_units(self) -> Units:
        return Conversions.units_from_driver(
            self._driver.query_channel_yunit(self._channel)
        )

    def set_probe_units(self, units: Units) -> None:
        driver_units = Conversions.units_to_driver(units)
        self._driver.write_channel_yunit(self._channel, driver_units)

    def apply_probe_units(self, units: Units) -> Units:
        self.set_probe_units(units)
        actual = self.get_probe_units()

        if actual != units:
            raise ReconcileException(param_name="units", expected=units, actual=actual)

        return actual

    def get_timebase_offset(self) -> float | int:
        # TODO should we do some rounding?
        offset_percentage = self._driver.query_horizontal_main_delay_position()
        return self._timebase_offset_from_percentage(
            offset_percentage, self.get_timebase_scale()
        )

    def set_timebase_offset(self, offset: float | int) -> None:
        self._driver.write_horizontal_main_delay_position(
            self._timebase_offset_to_percentage(offset, self.get_timebase_scale())
        )

    def apply_timebase_offset(self, offset: float | int) -> float | int:
        self.set_timebase_offset(offset)
        actual = self.get_timebase_offset()

        if not compare_floats(actual, offset):
            raise ReconcileException(
                param_name="timebase_offset", expected=offset, actual=actual
            )

        return actual

    def _timebase_offset_to_percentage(self, offset: float, scale: float) -> float:
        if compare_floats(offset, 0.0):
            return DEFAULT_OFFSET_PERCENTAGE

        relative_offset_percentage = (offset / (scale * NUM_HORIZONTAL_DIVISIONS)) * 100

        return DEFAULT_OFFSET_PERCENTAGE - relative_offset_percentage

    def _timebase_offset_from_percentage(
        self, offset_percentage: float, scale: float
    ) -> float:
        relative_offset_percentage = offset_percentage - DEFAULT_OFFSET_PERCENTAGE

        if compare_floats(relative_offset_percentage, 0.0):
            return 0.0

        return -relative_offset_percentage / 100 * (scale * NUM_HORIZONTAL_DIVISIONS)

    def get_timebase_scale(self) -> float | int:
        return self._driver.query_horizontal_main_scale()

    def set_timebase_scale(self, scale: float | int) -> None:
        self._driver.write_horizontal_main_scale(scale)

    def apply_timebase_scale(self, scale: float | int) -> float | int:
        self.set_timebase_scale(scale)
        actual = self.get_timebase_scale()

        if not compare_floats(actual, scale):
            raise ReconcileException(
                param_name="timebase_scale", expected=scale, actual=actual
            )

        return actual

    def get_trigger_coupling(self) -> TriggerCoupling:
        resp = self._driver.query_trigger_edge_coupling()

        match resp:
            case driver.TriggerCoupling.DC:
                return TriggerCoupling.DC
            case driver.TriggerCoupling.AC:
                return TriggerCoupling.AC
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=TriggerCoupling,
                    to_type=driver.TriggerCoupling,
                    value=resp,
                )

    def set_trigger_coupling(self, coupling: TriggerCoupling) -> None:
        match coupling:
            case TriggerCoupling.DC:
                driver_coupling = driver.TriggerCoupling.DC
            case TriggerCoupling.AC:
                driver_coupling = driver.TriggerCoupling.AC

        self._driver.write_trigger_edge_coupling(driver_coupling)

    def apply_trigger_coupling(self, coupling: TriggerCoupling) -> TriggerCoupling:
        self.set_trigger_coupling(coupling)
        actual = self.get_trigger_coupling()

        if actual != coupling:
            raise ReconcileException(
                param_name="trigger_coupling", expected=coupling, actual=actual
            )

        return actual

    def get_trigger_holdoff(self) -> float:
        return self._driver.query_trigger_holdoff_time()

    def set_trigger_holdoff(self, holdoff: float) -> None:
        self._driver.write_trigger_holdoff_time(holdoff)

    def apply_trigger_holdoff(self, holdoff: float) -> float:
        self.set_trigger_holdoff(holdoff)
        actual = self.get_trigger_holdoff()

        if not compare_floats(actual, holdoff):
            raise ReconcileException(
                param_name="trigger_holdoff", expected=holdoff, actual=actual
            )

        return actual

    def get_trigger_mode(self) -> TriggerMode:
        resp = self._driver.query_trigger_type()

        match resp:
            case driver.TriggerType.EDGE:
                return TriggerMode.EDGE
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=TriggerMode,
                    to_type=driver.TriggerType,
                    value=resp,
                )

    def set_trigger_mode(self, mode: TriggerMode) -> None:
        match mode:
            case TriggerMode.EDGE:
                driver_mode = driver.TriggerType.EDGE
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=TriggerMode,
                    to_type=driver.TriggerType,
                    value=mode,
                )

        self._driver.write_trigger_type(driver_mode)

    def apply_trigger_mode(self, mode: TriggerMode) -> TriggerMode:
        self.set_trigger_mode(mode)
        actual = self.get_trigger_mode()

        if actual != mode:
            raise ReconcileException(
                param_name="trigger_mode", expected=mode, actual=actual
            )

        return actual

    def get_trigger_slope(self) -> TriggerSlope:
        resp = self._driver.query_trigger_edge_slope()

        match resp:
            case driver.TriggerSlope.RISE:
                return TriggerSlope.RISING
            case driver.TriggerSlope.FALL:
                return TriggerSlope.FALLING
            case driver.TriggerSlope.EITHER:
                return TriggerSlope.EITHER

    def set_trigger_slope(self, slope: TriggerSlope) -> None:
        match slope:
            case TriggerSlope.RISING:
                driver_slope = driver.TriggerSlope.RISE
            case TriggerSlope.FALLING:
                driver_slope = driver.TriggerSlope.FALL
            case TriggerSlope.EITHER:
                driver_slope = driver.TriggerSlope.EITHER

        self._driver.write_trigger_edge_slope(driver_slope)

    def apply_trigger_slope(self, slope: TriggerSlope) -> TriggerSlope:
        self.set_trigger_slope(slope)
        actual = self.get_trigger_slope()

        if actual != slope:
            raise ReconcileException(
                param_name="trigger_slope", expected=slope, actual=actual
            )

        return actual

    def get_trigger_threshold(self) -> float:
        return self._driver.query_trigger_level(self._channel)

    def set_trigger_threshold(self, threshold: float) -> None:
        self._driver.write_trigger_level(self._channel, threshold)

    def apply_trigger_threshold(self, threshold: float) -> float:
        self.set_trigger_threshold(threshold)
        actual = self.get_trigger_threshold()

        if not compare_floats(actual, threshold):
            raise ReconcileException(
                param_name="trigger_threshold", expected=threshold, actual=actual
            )

        return actual

    def get_trigger_state(self) -> TriggerState: ...

    def set_trigger_state(self, state: TriggerState) -> None: ...

    def apply_trigger_state(self, state: TriggerState) -> TriggerState: ...

    def get_trigger_sweep(self) -> TriggerSweep:
        mode = self._driver.query_trigger_mode()
        acquire_mode = self._driver.query_acquire_stopafter()
        acquire_state = self._driver.query_acquire_state()

        if (
            mode == driver.TriggerMode.NORMAL
            and acquire_mode == driver.AcquisitionMode.SEQUENCE
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.SINGLE
        elif (
            mode == driver.TriggerMode.AUTO
            and acquire_mode == driver.AcquisitionMode.RUNSTOP
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.AUTO
        elif (
            mode == driver.TriggerMode.NORMAL
            and acquire_mode == driver.AcquisitionMode.RUNSTOP
            and acquire_state == driver.AcquisitionState.RUN
        ):
            return TriggerSweep.NORMAL
        else:
            raise MappingException(
                direction=MappingDirection.DriverToHal,
                from_type=tuple[
                    driver.TriggerMode, driver.AcquisitionMode, driver.AcquisitionState
                ],
                to_type=TriggerSweep,
                value=(mode, acquire_mode, acquire_state),
            )

    def set_trigger_sweep(self, sweep: TriggerSweep) -> None:
        match sweep:
            case TriggerSweep.SINGLE:
                self._driver.write_trigger_mode(driver.TriggerMode.NORMAL)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.SEQUENCE)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case TriggerSweep.AUTO:
                self._driver.write_trigger_mode(driver.TriggerMode.AUTO)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.RUNSTOP)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)
            case TriggerSweep.NORMAL:
                self._driver.write_trigger_mode(driver.TriggerMode.NORMAL)
                self._driver.write_acquire_stopafter(driver.AcquisitionMode.RUNSTOP)
                self._driver.write_acquire_state(driver.AcquisitionState.RUN)

    def apply_trigger_sweep(self, sweep: TriggerSweep) -> TriggerSweep:
        self.set_trigger_sweep(sweep)
        actual = self.get_trigger_sweep()

        if actual != sweep:
            raise ReconcileException(
                param_name="trigger_sweep", expected=sweep, actual=actual
            )

        return actual

    def get_sample_rate(self) -> float:
        return self._driver.query_horizontal_sample_rate()

    def set_sample_rate(self, sample_rate: float) -> None:
        if sample_rate > MAX_ANALOG_SAMPLE_RATE:
            raise ValueError(
                f"Sample rate {sample_rate} exceeds maximum sample rate {MAX_ANALOG_SAMPLE_RATE}"
            )

        record_length = self._calculate_closest_record_length(sample_rate)
        self._driver.write_horizontal_record_length(record_length)

    def _calculate_closest_record_length(self, sample_rate: float) -> int:
        timebase_scale = self.get_timebase_scale()
        time_per_capture = timebase_scale * NUM_HORIZONTAL_DIVISIONS
        ideal_record_length = int(sample_rate * time_per_capture)

        # Clamp to max if sample_rate is max
        if ideal_record_length > max(VALID_RECORD_LENGTHS):
            return max(VALID_RECORD_LENGTHS)

        # Otherwise find the closest that is >= ideal_record_length
        eligible_record_lengths = [
            record_length
            for record_length in VALID_RECORD_LENGTHS
            if record_length >= ideal_record_length
        ]
        if not eligible_record_lengths:
            MappingException(
                direction=MappingDirection.ConfigToHal,
                from_type=float,
                to_type=float,
                value=sample_rate,
            )

        return eligible_record_lengths[0]

    def apply_sample_rate(self, sample_rate: float) -> float:
        self.set_sample_rate(sample_rate)
        actual = self.get_sample_rate()
        actual_record_length = self._driver.query_horizontal_record_length()

        expected_record_length = self._calculate_closest_record_length(sample_rate)
        if actual_record_length != expected_record_length:
            raise ReconcileException(
                param_name="sample_rate_record_length",
                expected=expected_record_length,
                actual=actual_record_length,
            )

        # If the above checks pass, then the sample rate is the closest value that is >= the
        # requested sample rate
        return actual

    def get_sample_count(self) -> float:
        return self._driver.query_horizontal_record_length()

    def set_sample_count(self, sample_count: float) -> None:
        self._driver.write_horizontal_record_length(int(sample_count))

    def apply_sample_count(self, sample_count: float) -> float:
        self.set_sample_count(sample_count)
        result = self.get_sample_count()

        if result != sample_count:
            raise ReconcileException(
                param_name="sample_rate_record_length",
                expected=sample_count,
                actual=result,
            )

        return result

    def get_image_format(self) -> ImageFormat:
        resp = self._driver.query_save_image_format()

        match resp:
            case driver.ImageFormat.BMP:
                return ImageFormat.BMP
            case driver.ImageFormat.PNG:
                return ImageFormat.PNG
            case driver.ImageFormat.TIFF:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=ImageFormat,
                    to_type=driver.ImageFormat,
                    value=resp,
                )

    def set_image_format(self, image_format: ImageFormat) -> None:
        match image_format:
            case ImageFormat.BMP:
                driver_format = driver.ImageFormat.BMP
            case ImageFormat.PNG:
                driver_format = driver.ImageFormat.PNG
            case _:
                raise MappingException(
                    direction=MappingDirection.HalToDriver,
                    from_type=ImageFormat,
                    to_type=driver.ImageFormat,
                    value=image_format,
                )

        self._driver.write_save_image_format(driver_format)

    def apply_image_format(self, image_format: ImageFormat) -> ImageFormat:
        self.set_image_format(image_format)
        actual = self.get_image_format()

        if actual != image_format:
            raise ReconcileException(
                param_name="image_format", expected=image_format, actual=actual
            )

        return actual

    def get_screenshot_old(self) -> bytes:
        screenshot_path = f"E:/fusaware-{int(time.time_ns())}.bmp"
        self._driver.write_save_image(screenshot_path)
        # self._driver.query_opc()
        self._driver.write_file_read(screenshot_path)
        data = self._driver.io.read_raw()
        self._driver.write_file_delete(screenshot_path)
        return data

    def get_screenshot(self) -> bytes:
        self._driver.write_hardcopy_inksaver(False)
        self._driver.write_hardcopy_start()
        data = self._driver.io.read_raw()
        return data

    def get_waveform_preamble(self) -> Preamble:
        encoding_driver = self._driver.query_waveform_encoding()
        num_points = self._driver.query_waveform_nr_points()
        x_increment = self._driver.query_waveform_x_increment()
        x_unit = self._driver.query_waveform_x_unit()
        x_zero = self._driver.query_waveform_x_zero()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_unit_driver = self._driver.query_waveform_y_unit()
        y_zero = self._driver.query_waveform_y_zero()

        match encoding_driver:
            case driver.WaveformEncoding.ASCII:
                encoding = WaveformEncoding.CSV
            case driver.WaveformEncoding.BINARY:
                encoding = WaveformEncoding.BINARY

        return Preamble(
            source=self._get_waveform_source().value,
            format=encoding,
            count=num_points,
            x_increment=x_increment,
            x_origin=x_zero,
            x_reference=0,  # TODO: figure out what this is
            x_zero=x_zero,
            x_units=x_unit,
            y_increment=y_multiplier,
            y_origin=y_zero,
            y_reference=0,
            y_zero=y_zero,
            y_units=Conversions.units_from_driver(y_unit_driver),
        )

    def _get_waveform_source(self) -> AnalogChannel:
        source_channel = self._driver.query_data_source()

        match source_channel:
            case driver.WaveformSource.CH1:
                return AnalogChannel.CH1
            case driver.WaveformSource.CH2:
                return AnalogChannel.CH2
            case driver.WaveformSource.CH3:
                return AnalogChannel.CH3
            case driver.WaveformSource.CH4:
                return AnalogChannel.CH4
            case _:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=driver.WaveformSource,
                    to_type=int,
                    value=source_channel,
                )

    def _set_waveform_source(self, channel: AnalogChannel) -> None:
        match channel:
            case AnalogChannel.CH1:
                driver_channel = driver.WaveformSource.CH1
            case AnalogChannel.CH2:
                driver_channel = driver.WaveformSource.CH2
            case AnalogChannel.CH3:
                driver_channel = driver.WaveformSource.CH3
            case AnalogChannel.CH4:
                driver_channel = driver.WaveformSource.CH4

        self._driver.write_data_source(driver_channel)

    def apply_waveform_source(self) -> None:
        self._set_waveform_source(self._channel)
        actual = self._get_waveform_source()

        if actual != self._channel:
            raise ReconcileException(
                param_name="waveform_source_channel_number",
                expected=self._channel,
                actual=actual,
            )

    def get_waveform_start_index(self) -> int:
        return self._driver.query_data_start()

    def set_waveform_start_index(self, start_index: int) -> None:
        self._driver.write_data_start(start_index)

    def apply_waveform_start_index(self, start_index: int) -> int:
        self.set_waveform_start_index(start_index)
        actual = self.get_waveform_start_index()

        if actual != start_index:
            raise ReconcileException(
                param_name="waveform_start_index", expected=start_index, actual=actual
            )

        return actual

    def get_waveform_stop_index(self) -> int:
        return self._driver.query_data_stop()

    def set_waveform_stop_index(self, stop_index: int) -> None:
        self._driver.write_data_stop(stop_index)

    def apply_waveform_stop_index(self, stop_index: int) -> int:
        self.set_waveform_stop_index(stop_index)
        actual = self.get_waveform_stop_index()

        if actual != stop_index:
            raise ReconcileException(
                param_name="waveform_stop_index", expected=stop_index, actual=actual
            )

        return actual

    def get_waveform_encoding(self) -> WaveformEncoding:
        match self._driver.query_waveform_encoding():
            case driver.WaveformEncoding.ASCII:
                return WaveformEncoding.CSV
            case driver.WaveformEncoding.BINARY:
                return WaveformEncoding.BINARY

    def set_waveform_encoding(self, encoding: WaveformEncoding) -> None:
        match encoding:
            case WaveformEncoding.CSV:
                # Use WFMOutpre:ENCdg directly — ASCII needs no BN_Fmt/BYT_Or setup
                self._driver.write_waveform_encoding(driver.WaveformEncoding.ASCII)
            case WaveformEncoding.BINARY:
                # Use DATa:ENCdg to atomically set ENCdg=BINARY, BN_Fmt=RI, BYT_Or=MSB
                self._driver.write_data_encoding(driver.DataEncoding.RIBINARY)
            case WaveformEncoding.OTHER:
                raise ValueError("'WaveformEncoding.OTHER' should not be passed here")

    def apply_waveform_encoding(self, encoding: WaveformEncoding) -> WaveformEncoding:
        self.set_waveform_encoding(encoding)
        actual = self.get_waveform_encoding()

        if actual != encoding:
            raise ReconcileException(
                param_name="waveform_encoding", expected=encoding, actual=actual
            )

        return actual

    def get_waveform_data(self) -> list[float]:
        match self.get_waveform_encoding():
            case WaveformEncoding.CSV:
                return self._get_waveform_data_ascii()
            case WaveformEncoding.BINARY:
                return self._get_waveform_data_binary()
            case WaveformEncoding.OTHER:
                raise MappingException(
                    direction=MappingDirection.DriverToHal,
                    from_type=driver.WaveformEncoding,
                    to_type=WaveformEncoding,
                    value=WaveformEncoding.OTHER,
                )

    def _get_waveform_data_ascii(self) -> list[float]:
        data_raw = self._driver.query_curve()
        y_offset = self._driver.query_waveform_y_offset()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_zero = self._driver.query_waveform_y_zero()

        points_raw = data_raw.split(",")

        # See programming guide page 268
        # curve_in_dl values are NR1 signed integers (ADC counts)
        return [
            ((int(float(point)) - y_offset) * y_multiplier) + y_zero
            for point in points_raw
            if point.strip() != ""
        ]

    def _get_waveform_data_binary(self) -> list[float]:
        byte_order = self._driver.query_waveform_byte_order()
        binary_fmt = self._driver.query_waveform_binary_format()
        bytes_per_point = self._driver.query_waveform_byte_nr()
        num_points = self._driver.query_waveform_nr_points()
        y_offset = self._driver.query_waveform_y_offset()
        y_multiplier = self._driver.query_waveform_y_multiplier()
        y_zero = self._driver.query_waveform_y_zero()

        raw_bytes = self._driver.query_curve_binary()

        endian = ">" if byte_order == driver.WaveformByteOrder.MSB else "<"

        # See table 2-49 in programming guide
        match binary_fmt, bytes_per_point:
            case driver.BinaryFormat.RI, 1:
                fmt_char = "b"  # signed int8
            case driver.BinaryFormat.RI, 2:
                fmt_char = "h"  # signed int16
            case driver.BinaryFormat.RP, 1:
                fmt_char = "B"  # unsigned int8
            case driver.BinaryFormat.RP, 2:
                fmt_char = "H"  # unsigned int16
            case driver.BinaryFormat.FP, 4:
                fmt_char = "f"  # float32
            case _:
                raise ScpiParseError(
                    response=f"BN_FMT={binary_fmt.value}, BYT_NR={bytes_per_point}",
                    query=":WFMO:BN_F? / :WFMO:BYT_N?",
                    message=f"Unsupported binary format combination: {binary_fmt} with {bytes_per_point} bytes/point",
                )

        try:
            raw_points = struct.unpack(f"{endian}{num_points}{fmt_char}", raw_bytes)
        except Exception as e:
            traceback.print_exc()
            raise e

        return [((p - y_offset) * y_multiplier) + y_zero for p in raw_points]

    def get_probe_id(self) -> ProbeId | UnknownProbe | None:
        id = self._driver.query_channel_probe_id(self._channel)

        match id.probe_type:
            case ProbeType.UNKNOWN:
                return UnknownProbe(id.name)
            case ProbeType.NONE:
                return None
            case _:
                return Mdo34Probe(id.name)

    def sync(self) -> bool: ...

    def get_acquisition_state(self) -> AcquisitionState: ...

    def set_acquisition_state(self, state: AcquisitionState) -> None: ...

    def get_acquisition_condition(self) -> AcquisitionCondition: ...

    def set_acquisition_condition(self, condition: AcquisitionCondition) -> None: ...
