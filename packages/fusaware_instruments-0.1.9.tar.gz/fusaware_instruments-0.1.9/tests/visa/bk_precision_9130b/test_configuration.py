# pyright: strict

import pyvisa

from fusaware_instruments.visa_instrument_configuration.dc_voltage_supply import (
    State,
    VoltageSensing,
    configure_dc_voltage_supply,
)
from fusaware_instruments.visa_instrument_hal.hal_bk_precision_9130b import (
    HALDCPowerSupplyBKPrecision9130B,
)


def make_hal() -> HALDCPowerSupplyBKPrecision9130B:
    resource_name = "TCPIP0::localhost::inst0::INSTR"
    channel_number = 1
    hal = HALDCPowerSupplyBKPrecision9130B(resource_name, channel_number)
    hal._rm = pyvisa.ResourceManager(  # pyright: ignore[reportPrivateUsage]
        "tests/visa/bk_precision_9130b/mock_9130b.yaml@sim"
    )
    hal.connect()
    if hal._instr is None:  # pyright: ignore[reportPrivateUsage]
        raise RuntimeError("Failed to connect to instrument")
    hal._instr.write_termination = "\n"  # pyright: ignore[reportPrivateUsage]
    hal._instr.read_termination = "\n"  # pyright: ignore[reportPrivateUsage]
    return hal


def test_configure_dc_voltage_supply():
    hal = make_hal()

    current_limit = 0.5
    target_voltage = 5.0

    for state in State:
        for sensing in VoltageSensing:
            response, errors = configure_dc_voltage_supply(
                hal, current_limit, sensing, state, target_voltage
            )

            assert len(errors) == 0
            assert response.current_limit == current_limit
            assert response.sensing == VoltageSensing.UNKNOWN
            assert response.state == state
            assert response.target == target_voltage
