# pyright: strict

import pytest
from unittest.mock import MagicMock

from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mdo_3_series import (
    ProbeCoupling,
    AcquisitionState,
    AcquisitionMode,
    AnalogChannel,
    DataEncoding,
    ProbeUnits,
    TektronixMdo3SeriesDriver,
    WaveformByteOrder,
    WaveformSource,
    DelayModeState,
    ImageFormat,
    ChannelDisplayState,
    TriggerCoupling,
    TriggerSlope,
    TriggerSource,
    TriggerMode,
    TriggerType,
    WaveformEncoding,
    parse_ieee_488_2_block_data,
)
from fusaware_instruments.utils import ScpiParseError, compare_floats

from tests.visa.tektronix_mdo_3_series import make_mdo_3_series_driver


def test_acquire_state():
    driver = make_mdo_3_series_driver()

    for state in AcquisitionState:
        driver.write_acquire_state(state)
        assert driver.query_acquire_state() == state


def test_acquire_stop_after():
    driver = make_mdo_3_series_driver()

    for mode in AcquisitionMode:
        driver.write_acquire_stopafter(mode)
        assert driver.query_acquire_stopafter() == mode


def test_channel_bandwidth():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_bandwidth(channel, "FULL")
        resp = driver.query_channel_bandwidth(channel)
        assert resp == "FULL"

        driver.write_channel_bandwidth(channel, 20e6)
        resp = driver.query_channel_bandwidth(channel)
        assert isinstance(resp, (float, int))
        assert compare_floats(resp, 20e6)


def test_channel_coupling():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        for coupling in ProbeCoupling:
            driver.write_channel_coupling(channel, coupling)
            assert driver.query_channel_coupling(channel) == coupling


def test_channel_offset():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_offset(channel, 0.0)
        assert compare_floats(driver.query_channel_offset(channel), 0.0)


def test_channel_probe_gain():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_probe_gain(channel, 0.0)
        assert compare_floats(driver.query_channel_probe_gain(channel), 0.0)


# Query-only command
def test_query_channel_probe_units():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        _ = driver.query_channel_probe_units(channel)


def test_channel_scale():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_scale(channel, 0.0)
        assert compare_floats(driver.query_channel_scale(channel), 0.0)


def test_channel_yunit():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        for unit in ProbeUnits:
            driver.write_channel_yunit(channel, unit)
            assert driver.query_channel_yunit(channel) == unit


# Just test that the command is valid and returns something that can be parsed
def test_curve():
    driver = make_mdo_3_series_driver()
    _ = driver.query_curve()


def test_data_source():
    driver = make_mdo_3_series_driver()

    for source in WaveformSource:
        driver.write_data_source(source)
        assert driver.query_data_source() == source


def test_data_start():
    driver = make_mdo_3_series_driver()
    driver.write_data_start(0)
    assert driver.query_data_start() == 0


def test_data_stop():
    driver = make_mdo_3_series_driver()
    driver.write_data_stop(0)
    assert driver.query_data_stop() == 0


def test_filesystem_cwd():
    driver = make_mdo_3_series_driver()

    driver.write_filesystem_cwd("my_dir")
    assert driver.query_filesystem_cwd() == "my_dir"


def test_write_file_delete():
    driver = make_mdo_3_series_driver()
    driver.write_file_delete("E:/fusaware-12345.bmp")


def test_write_file_read():
    driver = make_mdo_3_series_driver()
    driver.write_file_read("E:/fusaware-12345.bmp")
    data = driver.io.read()  # Clear the response from the read command
    assert data == "hello world"


def test_horizontal_main_delay_position():
    driver = make_mdo_3_series_driver()
    driver.write_horizontal_main_delay_position(0.0)
    assert compare_floats(driver.query_horizontal_main_delay_position(), 0.0)


def test_horizontal_main_delay_mode():
    driver = make_mdo_3_series_driver()

    for state in DelayModeState:
        driver.write_horizontal_main_delay_mode(state)
        assert driver.query_horizontal_main_delay_mode() == state


def test_query_horizontal_sample_rate():
    driver = make_mdo_3_series_driver()
    _ = driver.query_horizontal_sample_rate()


def test_horizontal_main_delay_time():
    driver = make_mdo_3_series_driver()
    driver.write_horizontal_main_delay_time(0.0)
    assert compare_floats(driver.query_horizontal_main_delay_time(), 0.0)


def test_horizontal_main_scale():
    driver = make_mdo_3_series_driver()
    driver.write_horizontal_main_scale(0.0)
    assert compare_floats(driver.query_horizontal_main_scale(), 0.0)


def test_horizontal_record_length():
    driver = make_mdo_3_series_driver()
    driver.write_horizontal_record_length(0)
    assert driver.query_horizontal_record_length() == 0


def test_query_opc():
    driver = make_mdo_3_series_driver()
    _ = driver.query_opc()


def test_write_save_image():
    driver = make_mdo_3_series_driver()
    driver.write_save_image("E:/fusaware-12345.bmp")


def test_save_image_format():
    driver = make_mdo_3_series_driver()

    for fmt in ImageFormat:
        driver.write_save_image_format(fmt)
        assert driver.query_save_image_format() == fmt


def test_channel_select():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        for state in ChannelDisplayState:
            driver.write_channel_select(channel, state)
            assert driver.query_channel_select(channel) == state


def test_trigger_edge_coupling():
    driver = make_mdo_3_series_driver()

    for coupling in TriggerCoupling:
        driver.write_trigger_edge_coupling(coupling)
        assert driver.query_trigger_edge_coupling() == coupling


def test_trigger_edge_slope():
    driver = make_mdo_3_series_driver()

    for slope in TriggerSlope:
        driver.write_trigger_edge_slope(slope)
        assert driver.query_trigger_edge_slope() == slope


def test_trigger_edge_source():
    driver = make_mdo_3_series_driver()

    for source in TriggerSource:
        driver.write_trigger_edge_source(source)
        assert driver.query_trigger_edge_source() == source


def test_trigger_holdoff_time():
    driver = make_mdo_3_series_driver()
    driver.write_trigger_holdoff_time(0.0)
    assert compare_floats(driver.query_trigger_holdoff_time(), 0.0)


def test_trigger_level():
    driver = make_mdo_3_series_driver()

    for channel in AnalogChannel:
        driver.write_trigger_level(channel, 0.0)
        assert compare_floats(driver.query_trigger_level(channel), 0.0)


def test_trigger_mode():
    driver = make_mdo_3_series_driver()

    for mode in TriggerMode:
        driver.write_trigger_mode(mode)
        assert driver.query_trigger_mode() == mode


def test_trigger_type():
    driver = make_mdo_3_series_driver()

    for typ in TriggerType:
        driver.write_trigger_type(typ)
        assert driver.query_trigger_type() == typ


def test_query_waveform_bit_nr():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_bit_nr()


def test_query_waveform_binary_format():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_binary_format()


def test_query_waveform_byte_nr():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_byte_nr()


def test_waveform_encoding():
    driver = make_mdo_3_series_driver()

    for encoding in WaveformEncoding:
        driver.write_waveform_encoding(encoding)
        assert driver.query_waveform_encoding() == encoding


def test_query_waveform_nr_points():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_nr_points()


def test_query_waveform_id():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_id()


def test_query_waveform_x_increment():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_x_increment()


def test_query_waveform_x_unit():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_x_unit()


def test_query_waveform_x_zero():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_x_zero()


def test_query_waveform_y_multiplier():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_y_multiplier()


def test_query_waveform_y_offset():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_y_offset()


def test_query_waveform_y_unit():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_y_unit()


def test_query_waveform_y_zero():
    driver = make_mdo_3_series_driver()
    _ = driver.query_waveform_y_zero()


def test_data_encoding():
    driver = make_mdo_3_series_driver()

    for encoding in DataEncoding:
        driver.write_data_encoding(encoding)
        assert driver.query_data_encoding() == encoding


def test_waveform_byte_order():
    driver = make_mdo_3_series_driver()

    for order in WaveformByteOrder:
        driver.write_waveform_byte_order(order)
        assert driver.query_waveform_byte_order() == order


def test_write_waveform_byte_nr():
    driver = make_mdo_3_series_driver()

    for byte_nr in [1, 2]:
        driver.write_waveform_byte_nr(byte_nr)
        assert driver.query_waveform_byte_nr() == byte_nr


def test_parse_ieee_488_2_block_data_single_digit_length():
    payload = b"\x00\x01\x02\x03\x04"
    block = b"#1" + b"5" + payload  # N=1, length="5", 5 bytes
    assert parse_ieee_488_2_block_data(block) == payload


def test_parse_ieee_488_2_block_data_two_digit_length():
    payload = bytes(range(10))
    block = b"#2" + b"10" + payload  # N=2, length="10", 10 bytes
    assert parse_ieee_488_2_block_data(block) == payload


def test_parse_ieee_488_2_block_data_ignores_trailing_bytes():
    payload = b"\xaa\xbb\xcc"
    block = b"#1" + b"3" + payload + b"\n"  # trailing newline as from read_raw
    assert parse_ieee_488_2_block_data(block) == payload


def test_parse_ieee_488_2_block_data_invalid_marker():
    with pytest.raises(ScpiParseError):
        parse_ieee_488_2_block_data(b"@15\x00\x01\x02\x03\x04")


def test_parse_ieee_488_2_block_data_truncated():
    with pytest.raises(ScpiParseError):
        parse_ieee_488_2_block_data(b"#")


def test_query_curve_binary():
    io = MagicMock()

    def mock_read_bytes(count: int) -> bytes:
        match count:
            case 2:
                return b"#1"
            case 1:
                return b"5"
            case 5:
                return b"12345"
            case _:
                raise ValueError(f"Unexpected count: {count}")

    io.read_bytes = mock_read_bytes

    drv = TektronixMdo3SeriesDriver(io)
    result = drv.query_curve_binary()

    io.write.assert_called_with(":CURV?")
    assert result == b"12345"
