# pyright: strict

import tempfile
from typing import Any
from unittest.mock import MagicMock, patch
import os

import pytest

from fusaware_instruments.visa_instrument_configuration.oscilloscope import (
    TimebaseState,
    capture_screenshot,
    capture_waveform,
    configure_oscope_acquisition,
    configure_oscope_timebase,
    TriggerState,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mdo_3_series import (
    HALOscilloscopeProbeTektronixMdo3Series,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    AcquisitionCondition,
    AcquisitionState,
    TriggerMode,
)
from fusaware_instruments.visa_instrument_configuration.analog_probe import (
    AnalogProbeState,
    Coupling,
    Units,
)
from fusaware_instruments.utils import (
    MappingDirection,
    MappingException,
    MappingExceptionBase,
)

from tests.visa.oscilloscope_harnesses import probe_harness, trigger_harness
from tests.visa.tektronix_mdo_3_series import make_mdo_3_series_io

# from scratch import make_mdo_3_series_io as real_io

from experiments import AnalogProbe, ProbeState
import experiments as exp


def test_configure_analog_probe():
    io = make_mdo_3_series_io()

    for channel_num in [1, 2, 3, 4]:
        hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_num, 0)

        def handle_exception(e: Exception, desired_state: AnalogProbeState) -> None:
            if isinstance(e, MappingExceptionBase):
                if e.direction == MappingDirection.HalToDriver and (
                    desired_state.units == Units.Other
                    or desired_state.coupling == Coupling.Ground
                ):
                    pass
                else:
                    raise e

        probe_harness(hal, handle_exception)


def test_configure_trigger():
    io = make_mdo_3_series_io()

    for channel_num in [1, 2, 3, 4]:
        hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_num, 0)

        def handle_exception(e: Exception, desired_state: TriggerState) -> None:
            if isinstance(e, MappingExceptionBase):
                if (
                    e.direction == MappingDirection.HalToDriver
                    and desired_state.mode == TriggerMode.CAN
                ):
                    pass
                else:
                    raise e

        trigger_harness(hal, handle_exception)


def test_configure_timebase():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, 1, 0)

    desired_state = TimebaseState(scale=1e-3, offset=0.0)

    final_state, errors = configure_oscope_timebase(
        hal, scale=desired_state.scale, offset=desired_state.offset
    )

    assert len(errors) == 0
    assert final_state == desired_state


def test_configure_acquisition():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, 1, 0)

    permutations: list[dict[str, Any]] = []

    for state in AcquisitionState:
        for condition in [AcquisitionCondition.AUTO, AcquisitionCondition.TRIGGER]:
            permutations.append(
                {
                    "state": state,
                    "condition": condition,
                    "min_sample_rate": 1000,
                    "max_sample_count": 10000,
                }
            )

    for p in permutations:
        response, errors = configure_oscope_acquisition(hal, **p)

        assert len(errors) == 0
        assert response.state == p["state"]
        assert response.condition == p["condition"]
        assert response.sample_rate >= 1000
        assert response.sample_count <= 10000


def test_configure_acquisition_no_rolling():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, 1, 0)

    with pytest.raises(RuntimeError):
        _ = configure_oscope_acquisition(
            hal, AcquisitionState.RUNNING, AcquisitionCondition.ROLLING, 1000, 10000
        )


@patch("time.time_ns", return_value=12345)
def test_capture_screenshot(_: MagicMock):
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, 1, 0)

    data_dir = tempfile.gettempdir()

    response, errors = capture_screenshot(hal, data_dir)

    assert len(errors) == 0
    assert response.file_name == "12345.bmp"
    assert response.path == os.path.join(data_dir, "12345.bmp")

    with open(response.path) as f:
        data = f.read()
        assert data.strip() == "hello world"


@patch("time.time_ns", return_value=12345)
def test_capture_waveform(_: MagicMock):
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, 1, 0)

    data_dir = tempfile.gettempdir()

    # The sim cannot return IEEE 488.2 binary block data for CURV?, but
    # capture_waveform now uses the binary path (DATA_FORMAT = WaveformEncoding.BINARY).
    # Patch query_curve_binary on the driver so no write is sent to the sim (avoiding
    # stale responses that would corrupt subsequent tests).
    payload = bytes(range(1, 11))  # 10 signed int8 values
    with patch.object(hal._driver, "query_curve_binary", return_value=payload):  # pyright: ignore[reportPrivateUsage]
        response, errors = capture_waveform(hal, data_dir)

    assert len(errors) == 0
    assert response.path == os.path.join(data_dir, "12345.csv")


def test_configure_analog_probe_experiment():
    io = make_mdo_3_series_io()

    for channel_num in range(1, 5):
        hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_num, 0)
        probe = AnalogProbe(hal)

        for state in exp.State:
            for coupling in exp.Coupling:
                for unit in exp.Units:
                    for bandwidth_limit in [None, 20e6]:
                        desired_state = ProbeState(
                            attenuation=10.0,
                            bandwidth_limit=bandwidth_limit,
                            coupling=coupling,
                            offset=0.0,
                            state=state,
                            units=unit,
                            scale=1.0,
                        )

                        try:
                            final_state = probe.configure_probe(desired_state)
                            assert final_state == desired_state
                        except MappingException:
                            pass
