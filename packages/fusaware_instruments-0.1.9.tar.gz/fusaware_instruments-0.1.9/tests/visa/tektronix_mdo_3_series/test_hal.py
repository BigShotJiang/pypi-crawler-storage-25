# pyright: strict

import struct

import pytest
from unittest.mock import MagicMock

from fusaware_instruments.utils import MappingDirection, MappingException
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mdo_3_series import (
    HALOscilloscopeProbeTektronixMdo3Series,
)
import fusaware_instruments.visa_instrument_hal.hal_oscilloscope as hal_oscope
import fusaware_instruments.visa_instrument_drivers.driver_tektronix_mdo_3_series as driver

from tests.visa.tektronix_mdo_3_series import make_mdo_3_series_io


def test_probe_coupling_mappings_hal_to_driver():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for coupling in hal_oscope.ProbeCoupling:
        try:
            hal.set_probe_coupling(coupling)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            assert coupling == hal_oscope.ProbeCoupling.GROUND


def test_probe_coupling_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for coupling in driver.ProbeCoupling:
        io.query.return_value = coupling.value

        try:
            _ = hal.get_probe_coupling()
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.DriverToHal
            assert coupling == driver.ProbeCoupling.DCREJ


def test_probe_units_mappings_hal_to_driver():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for units in hal_oscope.Units:
        try:
            hal.set_probe_units(units)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            assert units == hal_oscope.Units.CUSTOM


def test_probe_units_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for units in driver.ProbeUnits:
        io.query.return_value = units.value
        _ = hal.get_probe_units()


def test_trigger_coupling_mappings_hal_to_driver():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for coupling in hal_oscope.TriggerCoupling:
        hal.set_trigger_coupling(coupling)


def test_trigger_coupling_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for units in driver.TriggerCoupling:
        io.query.return_value = units.value

        try:
            _ = hal.get_trigger_coupling()
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.DriverToHal
            assert units in [
                driver.TriggerCoupling.HFREJ,
                driver.TriggerCoupling.LFREJ,
                driver.TriggerCoupling.NOISEREJ,
            ]


def test_trigger_mode_mappings_hal_to_driver():
    io = make_mdo_3_series_io()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for mode in hal_oscope.TriggerMode:
        try:
            hal.set_trigger_mode(mode)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            assert mode == hal_oscope.TriggerMode.CAN


def test_trigger_mode_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    for trigger_type in driver.TriggerType:
        io.query.return_value = trigger_type.value

        try:
            _ = hal.get_trigger_mode()
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.DriverToHal
            assert trigger_type in [
                driver.TriggerType.PULSE,
                driver.TriggerType.LOGIC,
                driver.TriggerType.BUS,
                driver.TriggerType.VIDEO,
            ]


def test_waveform_encoding_mappings_hal_to_driver():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    hal.set_waveform_encoding(hal_oscope.WaveformEncoding.CSV)
    io.write.assert_called_with(":WFMO:ENC ASCII")

    hal.set_waveform_encoding(hal_oscope.WaveformEncoding.BINARY)
    io.write.assert_called_with(":DAT:ENC RIBinary")

    with pytest.raises(ValueError):
        hal.set_waveform_encoding(hal_oscope.WaveformEncoding.OTHER)


def test_waveform_encoding_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    io.query.return_value = driver.WaveformEncoding.ASCII.value
    assert hal.get_waveform_encoding() == hal_oscope.WaveformEncoding.CSV

    io.query.return_value = driver.WaveformEncoding.BINARY.value
    assert hal.get_waveform_encoding() == hal_oscope.WaveformEncoding.BINARY


def test_get_waveform_data_binary_1byte_signed():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    responses = {
        ":WFMO:ENC?": "BINARY",
        ":WFMO:BYT_O?": "MSB",
        ":WFMO:BN_F?": "RI",
        ":WFMO:BYT_N?": "1",
        ":WFMO:NR_P?": "3",
        ":WFMO:YOF?": "10.0",
        ":WFMO:YMU?": "0.5",
        ":WFMO:YZE?": "1.0",
    }
    io.query.side_effect = lambda q: responses[q.strip()]  # pyright: ignore[reportUnknownLambdaType, reportUnknownMemberType]

    # 3 signed int8 values: 12, 14, 16
    raw = bytes([12, 14, 16])

    def mock_read_bytes(count: int) -> bytes:
        match count:
            case 2:
                return b"#1"
            case 1:
                return b"3"
            case 3:
                return raw
            case _:
                raise ValueError(f"Unexpected count: {count}")

    io.read_bytes = mock_read_bytes

    result = hal.get_waveform_data()

    # Formula: ((raw - y_offset) * y_multiplier) + y_zero
    # ((12 - 10) * 0.5) + 1.0 = 2.0
    # ((14 - 10) * 0.5) + 1.0 = 3.0
    # ((16 - 10) * 0.5) + 1.0 = 4.0
    assert result == [2.0, 3.0, 4.0]


def test_get_waveform_data_binary_2byte_signed():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMdo3Series(io, channel_number=1)

    responses = {
        ":WFMO:ENC?": "BINARY",
        ":WFMO:BYT_O?": "MSB",
        ":WFMO:BN_F?": "RI",
        ":WFMO:BYT_N?": "2",
        ":WFMO:NR_P?": "2",
        ":WFMO:YOF?": "0.0",
        ":WFMO:YMU?": "1.0",
        ":WFMO:YZE?": "0.0",
    }
    io.query.side_effect = lambda q: responses[q.strip()]  # pyright: ignore[reportUnknownLambdaType, reportUnknownMemberType]

    # 2 signed int16 big-endian values: 256, -256
    raw = struct.pack(">2h", 256, -256)

    def mock_read_bytes(count: int) -> bytes:
        match count:
            case 2:
                return b"#1"
            case 1:
                return b"4"
            case 4:
                return raw
            case _:
                raise ValueError(f"Unexpected count: {count}")

    io.read_bytes = mock_read_bytes

    result = hal.get_waveform_data()

    assert result == [256.0, -256.0]
