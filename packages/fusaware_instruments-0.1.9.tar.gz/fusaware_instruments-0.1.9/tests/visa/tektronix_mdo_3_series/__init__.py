# pyright: strict

from fusaware_instruments.utils import PyvisaIO
from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mdo_3_series import (
    TektronixMdo3SeriesDriver,
)
from tests.visa import make_sim_io


def make_mdo_3_series_io() -> PyvisaIO:
    return make_sim_io("tests/visa/tektronix_mdo_3_series/mock_mdo_3_series.yaml")


def make_mdo_3_series_driver() -> TektronixMdo3SeriesDriver:
    io = make_mdo_3_series_io()
    return TektronixMdo3SeriesDriver(io)
