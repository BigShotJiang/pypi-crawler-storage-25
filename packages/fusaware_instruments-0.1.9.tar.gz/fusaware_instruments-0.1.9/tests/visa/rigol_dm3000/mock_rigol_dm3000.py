from fusaware_instruments.visa_instrument_drivers.driver_rigol_dm3000 import (
    CommandSet,
    DCCurrentRange,
    DCVoltageRange,
    MeasurementFunction,
)


class MockRigolDM3000Device:
    def __init__(self):
        self.command_set: CommandSet = CommandSet.RIGOL
        self.dc_current_range: DCCurrentRange = DCCurrentRange.DEF
        self.dc_voltage_range: DCVoltageRange = DCVoltageRange.DEF
        self.measurement_function: MeasurementFunction = MeasurementFunction.DCV

    def query(self, message: str, delay: float | None = None) -> str:
        print(f"Query: {message}")
        parts = message.strip().split()
        msg = parts[0]
        _ = parts[1:]

        match msg:
            case ":CMDSET?":
                result = self.command_set.value
            case ":FUNC?":
                result = self.measurement_function.value
            case ":MEAS:VOLT:DC:RANG?":
                result = self.dc_voltage_range.value
            case ":MEAS:CURR:DC:RANG?":
                result = self.dc_current_range.value
            case ":MEAS?":
                result = "42.0"
            case ":MEAS:VOLT:DC?":
                result = "42.0"
            case _:
                raise ValueError(f"Unknown message: {message}")

        print(f"Response: {result}")
        return result

    def write(
        self, message: str, termination: str | None = None, encoding: str | None = None
    ) -> int:
        print(f"Write: {message}")
        parts = message.strip().split()
        msg = parts[0]
        args = parts[1:]

        match msg:
            case ":CMDSET":
                self.command_set = CommandSet(args[0])
            case ":FUNC:VOLT:DC":
                self.measurement_function = MeasurementFunction.DCV
            case ":FUNC:CURR:DC":
                self.measurement_function = MeasurementFunction.DCI
            case ":MEAS:VOLT:DC":
                self.dc_voltage_range = DCVoltageRange(args[0])
            case ":MEAS:CURR:DC":
                self.dc_current_range = DCCurrentRange(args[0])
            case _:
                raise ValueError(f"Unknown message: {message}")

        return len(message)
