from fusaware_instruments.visa_instrument_drivers.driver_rigol_dm3000 import (
    DCVoltageRange,
    DCCurrentRange,
)
from fusaware_instruments.visa_instrument_hal.hal_dmm import MeasurementFunction

from tests.visa.rigol_dm3000 import make_dmm_sim


def test_measurement_function():
    dmm = make_dmm_sim()

    for func in MeasurementFunction:
        dmm.set_measurement_function(func)
        assert dmm.get_measurement_function() == func


def test_dc_voltage_range():
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCVoltage)

    for voltage_range in DCVoltageRange:
        range_float = dmm._map_device_dc_voltage_range_to_hal_dc_voltage_range(
            voltage_range
        )
        print(f"Testing DC Voltage Range: {range_float} V")
        dmm.set_measurement_range(MeasurementFunction.DCVoltage, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCVoltage,
            )
            == range_float
        )


def test_dc_current_range():
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCCurrent)

    for voltage_range in DCCurrentRange:
        range_float = dmm._map_device_dc_current_range_to_hal_dc_current_range(
            voltage_range
        )
        dmm.set_measurement_range(MeasurementFunction.DCCurrent, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCCurrent,
            )
            == range_float
        )


def test_get_measurement():
    dmm = make_dmm_sim()
    assert dmm.get_measurement() == 42.0
