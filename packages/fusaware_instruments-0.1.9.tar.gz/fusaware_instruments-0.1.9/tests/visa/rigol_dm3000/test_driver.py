from fusaware_instruments.visa_instrument_drivers.driver_rigol_dm3000 import (
    RigolDM3000,
    MeasurementFunction,
)


# Maybe not so useful
def test_function():
    assert RigolDM3000.function_query() == ":FUNC?"

    for func in MeasurementFunction:
        assert RigolDM3000.function_parse(func.value) == func

        match func:
            case MeasurementFunction.DCV:
                assert RigolDM3000.function_voltage_dc_write() == ":FUNC:VOLT:DC"
            case MeasurementFunction.DCI:
                assert RigolDM3000.function_current_dc_write() == ":FUNC:CURR:DC"
