import pytest

from fusaware_instruments.visa_instrument_configuration.dc_voltage_dmm import (
    configure_dc_voltage_meter,
)
from fusaware_instruments.visa_instrument_configuration.dc_current_dmm import (
    configure_dc_current_meter,
)
from fusaware_instruments.visa_instrument_drivers.driver_rigol_dm3000 import (
    DCCurrentRange,
    DCVoltageRange,
)

from fusaware_instruments.visa_instrument_hal.hal_dmm import DEFAULT_NPLCS
from tests.visa.rigol_dm3000 import make_dmm_sim


def test_configure_dc_voltage_meter():
    dmm = make_dmm_sim()
    dmm.connect()

    for voltage_range in DCVoltageRange:
        range_float = dmm._map_device_dc_voltage_range_to_hal_dc_voltage_range(
            voltage_range
        )
        result, errors = configure_dc_voltage_meter(dmm, range_float, DEFAULT_NPLCS)
        assert len(errors) == 0
        assert result == range_float


def test_configure_dc_voltage_meter_auto_range():
    dmm = make_dmm_sim()
    dmm.connect()

    for voltage_range in DCVoltageRange:
        range_float = dmm._map_device_dc_voltage_range_to_hal_dc_voltage_range(
            voltage_range
        )
        result, errors = configure_dc_voltage_meter(dmm, range_float, DEFAULT_NPLCS)
        assert len(errors) == 0
        assert result == range_float


def test_configure_dc_current_meter():
    dmm = make_dmm_sim()
    dmm.connect()

    for current_range in DCCurrentRange:
        range_float = dmm._map_device_dc_current_range_to_hal_dc_current_range(
            current_range
        )
        result, errors = configure_dc_current_meter(dmm, range_float, DEFAULT_NPLCS)
        assert len(errors) == 0
        assert result == range_float


def test_configure_dc_current_meter_auto_range():
    dmm = make_dmm_sim()
    dmm.connect()

    with pytest.raises(RuntimeError) as exc_info:
        _ = configure_dc_current_meter(dmm, "auto", DEFAULT_NPLCS)

    assert "Auto range not supported" in str(exc_info)
