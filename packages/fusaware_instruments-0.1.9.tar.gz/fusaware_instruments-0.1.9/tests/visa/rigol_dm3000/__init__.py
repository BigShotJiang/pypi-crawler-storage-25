from fusaware_instruments.visa_instrument_hal.hal_dmm_rigol_dm3000 import (
    HALDmmRigolDm3000,
)
from tests.visa.rigol_dm3000.mock_rigol_dm3000 import MockRigolDM3000Device


def make_dmm_sim() -> HALDmmRigolDm3000:
    dmm = HALDmmRigolDm3000("TCPIP0::localhost::inst0::INSTR")
    dmm.connect(sim_file="tests/visa/rigol_dm3000/mock_rigol_dm3000.yaml")
    assert dmm._device is not None
    dmm._device.read_termination = "\n"
    dmm._device.write_termination = "\n"
    device = MockRigolDM3000Device()
    dmm._device.query = device.query
    dmm._device.write = device.write

    return dmm
