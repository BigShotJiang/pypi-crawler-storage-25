# pyright: strict

import pyvisa
from pyvisa.resources import MessageBasedResource

from fusaware_instruments.utils import PyvisaIO


def make_sim_io(
    sim_file_path: str, sim_address: str = "TCPIP0::localhost::inst0::INSTR"
) -> PyvisaIO:

    rm = pyvisa.ResourceManager(f"{sim_file_path}@sim")
    resource = MessageBasedResource(rm, sim_address)

    resource.open()
    resource.write_termination = "\n"
    resource.read_termination = "\n"

    return PyvisaIO(resource)
