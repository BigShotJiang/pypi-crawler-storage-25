# pyright: strict

from fusaware_instruments.utils import PyvisaIO
from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series import (
    TektronixMso5SeriesDriver,
)
from tests.visa import make_sim_io


def make_mso_5_series_io() -> PyvisaIO:
    return make_sim_io("tests/visa/tektronix_mso_5_series/mock_mso_5_series.yaml")


def make_mso_5_series_driver() -> TektronixMso5SeriesDriver:
    io = make_mso_5_series_io()
    return TektronixMso5SeriesDriver(io)
