# pyright: strict

import tempfile
from unittest.mock import MagicMock, patch
import os
from typing import Any

import pytest

from fusaware_instruments.visa_instrument_configuration.oscilloscope import (
    TimebaseState,
    capture_screenshot,
    capture_waveform,
    configure_oscope_acquisition,
    configure_oscope_timebase,
    TriggerState,
)
from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series import (
    AnalogChannel,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mso_5_series import (
    HALOscilloscopeProbeTektronixMso5Series,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    AcquisitionCondition,
    AcquisitionState,
    TriggerCoupling,
    TriggerMode,
)
from fusaware_instruments.visa_instrument_configuration.analog_probe import (
    AnalogProbeState,
    configure_analog_probe,
    Coupling,
    Units,
    State,
)
from fusaware_instruments.utils import (
    MappingDirection,
    MappingException,
    MappingExceptionBase,
)

from tests.visa.tektronix_mso_5_series import make_mso_5_series_io
from tests.visa.oscilloscope_harnesses import trigger_harness

# from scratch import make_mdo_3_series_io as real_io

from experiments import AnalogProbe, ProbeState
import experiments as exp


@patch(
    "fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mso_5_series.time.sleep",
    return_value=None,
)
def test_configure_analog_probe(_):
    io = make_mso_5_series_io()

    for channel_num in [channel.value for channel in AnalogChannel]:
        hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_num, sync_time=0)

        # Don't iterate over units — they're query-only on MSO5 (probe-
        # controlled). Same goes for attenuation: CH<x>:PRObe:GAIN is
        # query-only and the mock returns gain=1.0, so we request attenuation
        # 1.0 here to stay inside the happy path.
        for state in State:
            for coupling in Coupling:
                for bandwidth_limit in ["none", 20e6]:
                    desired_state = AnalogProbeState(
                        attenuation=1.0,
                        bandwidth_limit=bandwidth_limit,
                        coupling=coupling,
                        offset=0.0,
                        state=state,
                        units=Units.Volts,
                        scale=1.0,
                    )

                    try:
                        final_state, errors = configure_analog_probe(
                            hal,
                            attenuation=desired_state.attenuation,
                            bandwidth_limit=desired_state.bandwidth_limit,
                            coupling=desired_state.coupling,
                            offset=desired_state.offset,
                            state=desired_state.state,
                            units=desired_state.units,
                            scale=desired_state.scale,
                        )

                        assert len(errors) == 0
                        assert final_state == desired_state
                    except MappingExceptionBase as e:
                        if (
                            e.direction == MappingDirection.HalToDriver
                            and desired_state.coupling == Coupling.Ground
                        ):
                            pass
                        else:
                            raise e


@patch(
    "fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mso_5_series.time.sleep",
    return_value=None,
)
def test_configure_trigger(_):
    io = make_mso_5_series_io()

    for channel_num in [channel.value for channel in AnalogChannel]:
        hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_num, sync_time=0)

        def handle_exception(e: Exception, desired_state: TriggerState) -> None:
            if isinstance(e, MappingExceptionBase):
                if e.direction == MappingDirection.HalToDriver and (
                    desired_state.coupling == TriggerCoupling.AC
                    or desired_state.mode == TriggerMode.CAN
                ):
                    pass
                else:
                    raise e

        trigger_harness(hal, handle_exception)


def test_configure_timebase():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, 1, sync_time=0)

    desired_state = TimebaseState(scale=1e-3, offset=0.0)

    final_state, errors = configure_oscope_timebase(
        hal, scale=desired_state.scale, offset=desired_state.offset
    )

    assert len(errors) == 0
    assert final_state == desired_state


@patch(
    "fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mso_5_series.time.sleep",
    return_value=None,
)
def test_configure_acquisition(_):
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, 1, sync_time=0)

    permutations: list[dict[str, Any]] = []

    for state in AcquisitionState:
        for condition in [AcquisitionCondition.AUTO, AcquisitionCondition.TRIGGER]:
            permutations.append(
                {
                    "state": state,
                    "condition": condition,
                    "min_sample_rate": 1000,
                    "max_sample_count": 10000,
                }
            )

    for p in permutations:
        response, errors = configure_oscope_acquisition(hal, **p)

        assert len(errors) == 0
        assert response.state == p["state"]
        assert response.condition == p["condition"]
        assert response.sample_rate >= 1000
        assert response.sample_count <= 10000


def test_configure_acquisition_no_rolling():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, 1, sync_time=0)

    with pytest.raises(RuntimeError):
        _ = configure_oscope_acquisition(
            hal, AcquisitionState.RUNNING, AcquisitionCondition.ROLLING, 1000, 10000
        )


@patch("time.time_ns", return_value=12345)
def test_capture_screenshot(_: MagicMock):
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, 1, sync_time=0)

    data_dir = tempfile.gettempdir()

    response, errors = capture_screenshot(hal, data_dir)

    assert len(errors) == 0
    # The shared capture_screenshot helper currently targets BMP; the MSO5 HAL
    # saves to C:/ internally (not E:/), using the extension requested by
    # the HAL-level image format (set by capture_screenshot).
    assert response.file_name == "12345.bmp"
    assert response.path == os.path.join(data_dir, "12345.bmp")

    with open(response.path) as f:
        data = f.read()
        assert data.strip() == "hello world"


@patch("time.time_ns", return_value=12345)
def test_capture_waveform(_: MagicMock):
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, 1, sync_time=0)

    data_dir = tempfile.gettempdir()

    # The sim cannot return IEEE 488.2 binary block data for CURV?, but
    # capture_waveform now uses the binary path (DATA_FORMAT = WaveformEncoding.BINARY).
    # Patch query_curve_binary on the driver so no write is sent to the sim (avoiding
    # stale responses that would corrupt subsequent tests).
    payload = bytes(range(1, 11))  # 10 signed int8 values
    with patch.object(hal._driver, "query_curve_binary", return_value=payload):  # pyright: ignore[reportPrivateUsage]
        response, errors = capture_waveform(hal, data_dir)

    assert len(errors) == 0
    assert response.path == os.path.join(data_dir, "12345.csv")


def test_configure_analog_probe_experiment():
    io = make_mso_5_series_io()

    for channel_num in range(1, 5):
        hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_num, sync_time=0)
        probe = AnalogProbe(hal)

        # Don't iterate over units cause they're query only
        for state in exp.State:
            for coupling in exp.Coupling:
                for bandwidth_limit in [None, 20e6]:
                    desired_state = ProbeState(
                        attenuation=1.0,
                        bandwidth_limit=bandwidth_limit,
                        coupling=coupling,
                        offset=0.0,
                        state=state,
                        units=exp.Units.Volts,
                        scale=1.0,
                    )

                    try:
                        final_state = probe.configure_probe(desired_state)
                        assert final_state == desired_state
                    except MappingException:
                        pass
