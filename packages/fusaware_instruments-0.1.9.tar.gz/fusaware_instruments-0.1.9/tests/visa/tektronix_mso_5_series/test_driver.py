# pyright: strict

from unittest.mock import MagicMock


from fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series import (
    ProbeCoupling,
    AcquisitionState,
    AcquisitionMode,
    AnalogChannel,
    DataEncoding,
    HorizontalModeManualConfigure,
    TektronixMso5SeriesDriver,
    WaveformSource,
    DelayModeState,
    ChannelDisplayState,
    TriggerCoupling,
    TriggerSlope,
    TriggerSource,
    TriggerMode,
    TriggerType,
    WaveformEncoding,
)
from fusaware_instruments.utils import compare_floats

from tests.visa.tektronix_mso_5_series import make_mso_5_series_driver


def test_acquire_state():
    driver = make_mso_5_series_driver()

    for state in AcquisitionState:
        driver.write_acquire_state(state)
        assert driver.query_acquire_state() == state


def test_acquire_stop_after():
    driver = make_mso_5_series_driver()

    for mode in AcquisitionMode:
        driver.write_acquire_stopafter(mode)
        assert driver.query_acquire_stopafter() == mode


def test_channel_bandwidth():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_bandwidth(channel, "FULL")
        resp = driver.query_channel_bandwidth(channel)
        assert resp == "FULL"

        driver.write_channel_bandwidth(channel, 20e6)
        resp = driver.query_channel_bandwidth(channel)
        assert isinstance(resp, (float, int))
        assert compare_floats(resp, 20e6)


def test_channel_coupling():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        for coupling in ProbeCoupling:
            driver.write_channel_coupling(channel, coupling)
            assert driver.query_channel_coupling(channel) == coupling


def test_channel_offset():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_offset(channel, 0.0)
        assert compare_floats(driver.query_channel_offset(channel), 0.0)


def test_channel_probe_gain():
    driver = make_mso_5_series_driver()

    # CH<x>:PRObe:GAIN is query-only on MSO5 — gain is determined by the
    # connected probe hardware. We just verify the query round-trips.
    for channel in AnalogChannel:
        _ = driver.query_channel_probe_gain(channel)


def test_query_channel_probe_units():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        _ = driver.query_channel_probe_units(channel)


def test_channel_scale():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        driver.write_channel_scale(channel, 1.0)
        assert compare_floats(driver.query_channel_scale(channel), 1.0)


def test_channel_display_state():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        for state in ChannelDisplayState:
            driver.write_channel_display_state(channel, state)
            assert driver.query_channel_display_state(channel) == state


def test_query_channel_probe_type():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        _ = driver.query_channel_probe_type(channel)


def test_query_channel_probe_id():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        probe_id = driver.query_channel_probe_id(channel)
        assert probe_id.name != ""


def test_curve():
    driver = make_mso_5_series_driver()
    _ = driver.query_curve()


def test_data_source():
    driver = make_mso_5_series_driver()

    for source in WaveformSource:
        driver.write_data_source(source)
        assert driver.query_data_source() == source


def test_data_start():
    driver = make_mso_5_series_driver()
    driver.write_data_start(0)
    assert driver.query_data_start() == 0


def test_data_stop():
    driver = make_mso_5_series_driver()
    driver.write_data_stop(0)
    assert driver.query_data_stop() == 0


def test_filesystem_cwd():
    driver = make_mso_5_series_driver()

    driver.write_filesystem_cwd("my_dir")
    assert driver.query_filesystem_cwd() == "my_dir"


def test_write_file_delete():
    driver = make_mso_5_series_driver()
    driver.write_file_delete("C:/fusaware-12345.png")


def test_write_file_read():
    driver = make_mso_5_series_driver()
    driver.write_file_read("C:/fusaware-12345.png")
    data = driver.io.read()
    assert data == "hello world"


def test_horizontal_main_delay_position():
    driver = make_mso_5_series_driver()
    driver.write_horizontal_position(0.0)
    assert compare_floats(driver.query_horizontal_position(), 0.0)


def test_horizontal_main_delay_mode():
    driver = make_mso_5_series_driver()

    for state in DelayModeState:
        driver.write_horizontal_delay_mode(state)
        assert driver.query_horizontal_delay_mode() == state


def test_query_horizontal_sample_rate():
    driver = make_mso_5_series_driver()
    _ = driver.query_horizontal_sample_rate()


def test_horizontal_manual_configure():
    driver = make_mso_5_series_driver()

    for value in HorizontalModeManualConfigure:
        driver.write_horizontal_manual_configure(value)
        assert driver.query_horizontal_manual_configure() == value


def test_horizontal_main_delay_time():
    driver = make_mso_5_series_driver()
    driver.write_horizontal_main_delay_time(0.0)
    assert compare_floats(driver.query_horizontal_main_delay_time(), 0.0)


def test_horizontal_main_scale():
    driver = make_mso_5_series_driver()
    driver.write_horizontal_mode_scale(0.0)
    assert compare_floats(driver.query_horizontal_mode_scale(), 0.0)


def test_horizontal_record_length():
    driver = make_mso_5_series_driver()
    driver.write_horizontal_record_length(0)
    assert driver.query_horizontal_record_length() == 0


def test_query_opc():
    driver = make_mso_5_series_driver()
    _ = driver.query_opc()


def test_write_save_image():
    driver = make_mso_5_series_driver()
    # Save to the instrument's internal C: drive so this test doesn't require a
    # USB flash drive to be plugged into the E: port.
    driver.write_save_image("C:/fusaware-12345.png")


def test_trigger_edge_coupling():
    driver = make_mso_5_series_driver()

    for coupling in TriggerCoupling:
        driver.write_trigger_edge_coupling(coupling)
        assert driver.query_trigger_edge_coupling() == coupling


def test_trigger_edge_coupling_parsing():
    driver = make_mso_5_series_driver()
    possible_values = ["HFR", "HFREJ", "LFR", "LFREJ", "NOISE", "NOISEREJ"]

    mock_query = MagicMock()
    mock_query.side_effect = possible_values

    driver.io.query = mock_query

    # HFR and HFREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.HFREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.HFREJ

    # LFR and LFREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.LFREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.LFREJ

    # NOISE and NOISEREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.NOISEREJ
    assert driver.query_trigger_edge_coupling() == TriggerCoupling.NOISEREJ


def test_trigger_edge_slope():
    driver = make_mso_5_series_driver()

    for slope in TriggerSlope:
        driver.write_trigger_edge_slope(slope)
        assert driver.query_trigger_edge_slope() == slope


def test_trigger_edge_source():
    driver = make_mso_5_series_driver()

    for source in TriggerSource:
        driver.write_trigger_edge_source(source)
        assert driver.query_trigger_edge_source() == source


def test_trigger_edge_source_parsing():
    def mock_query(message: str) -> str:
        return "AUXILIARY"

    mock_visaio = MagicMock()
    mock_visaio.query = mock_query

    driver = TektronixMso5SeriesDriver(mock_visaio)

    assert driver.query_trigger_edge_source() == TriggerSource.AUX


def test_trigger_holdoff_time():
    driver = make_mso_5_series_driver()
    driver.write_trigger_holdoff_time(0.0)
    assert compare_floats(driver.query_trigger_holdoff_time(), 0.0)


def test_trigger_level():
    driver = make_mso_5_series_driver()

    for channel in AnalogChannel:
        driver.write_trigger_level(channel, 0.0)
        assert compare_floats(driver.query_trigger_level(channel), 0.0)


def test_trigger_mode():
    driver = make_mso_5_series_driver()

    for mode in TriggerMode:
        driver.write_trigger_mode(mode)
        assert driver.query_trigger_mode() == mode


def test_trigger_type():
    driver = make_mso_5_series_driver()

    for typ in TriggerType:
        driver.write_trigger_type(typ)
        assert driver.query_trigger_type() == typ


def test_query_waveform_bit_nr():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_bit_nr()


def test_query_waveform_binary_format():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_binary_format()


def test_query_waveform_byte_nr():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_byte_nr()


def test_waveform_encoding():
    driver = make_mso_5_series_driver()

    for encoding in WaveformEncoding:
        driver.write_waveform_encoding(encoding)
        assert driver.query_waveform_encoding() == encoding


def test_query_waveform_nr_points():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_nr_points()


def test_query_waveform_id():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_id()


def test_query_waveform_x_increment():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_x_increment()


def test_query_waveform_x_unit():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_x_unit()


def test_query_waveform_x_zero():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_x_zero()


def test_query_waveform_y_multiplier():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_y_multiplier()


def test_query_waveform_y_offset():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_y_offset()


def test_query_waveform_y_unit():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_y_unit()


def test_query_waveform_y_zero():
    driver = make_mso_5_series_driver()
    _ = driver.query_waveform_y_zero()


def test_data_encoding():
    driver = make_mso_5_series_driver()

    for encoding in DataEncoding:
        driver.write_data_encoding(encoding)
        assert driver.query_data_encoding() == encoding


def test_analog_channel_has_8_channels():
    channels = list(AnalogChannel)
    assert len(channels) == 8
    assert AnalogChannel.CH1.value == 1
    assert AnalogChannel.CH8.value == 8


def test_trigger_coupling_has_no_ac():
    couplings = [c for c in TriggerCoupling]
    names = [c.name for c in couplings]
    assert "AC" not in names
    assert "DC" in names


def test_trigger_type_has_mso5_types():
    types = {t.name for t in TriggerType}
    for name in [
        "EDGE",
        "WIDTH",
        "TIMEOUT",
        "RUNT",
        "WINDOW",
        "LOGIC",
        "SETHOLD",
        "TRANSITION",
        "BUS",
    ]:
        assert name in types


def test_trigger_source_has_no_rf():
    sources = {s.name for s in TriggerSource}
    assert "RF" not in sources
    assert "CH8" in sources
