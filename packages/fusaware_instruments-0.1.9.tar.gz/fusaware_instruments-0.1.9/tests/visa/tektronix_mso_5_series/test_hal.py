# pyright: strict

from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import Units
import struct

from unittest.mock import MagicMock

from fusaware_instruments.utils import MappingDirection, MappingException
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope_tektronix_mso_5_series import (
    HALOscilloscopeProbeTektronixMso5Series,
)
import fusaware_instruments.visa_instrument_hal.hal_oscilloscope as hal_oscope
import fusaware_instruments.visa_instrument_drivers.driver_tektronix_mso_5_series as driver

from tests.visa.tektronix_mso_5_series import make_mso_5_series_io


def test_probe_coupling_mappings_hal_to_driver():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for coupling in hal_oscope.ProbeCoupling:
        try:
            hal.set_probe_coupling(coupling)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            assert coupling == hal_oscope.ProbeCoupling.GROUND


def test_probe_coupling_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for coupling in driver.ProbeCoupling:
        io.query.return_value = coupling.value

        try:
            _ = hal.get_probe_coupling()
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.DriverToHal
            assert coupling == driver.ProbeCoupling.DCREJ


def test_probe_units_get():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    units = hal.get_probe_units()
    assert units == Units.VOLTS


def test_trigger_coupling_mappings_hal_to_driver():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for coupling in hal_oscope.TriggerCoupling:
        try:
            hal.set_trigger_coupling(coupling)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            # AC trigger coupling is not supported on MSO5
            assert coupling == hal_oscope.TriggerCoupling.AC


def test_trigger_coupling_mappings_driver_to_hal():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for coupling in driver.TriggerCoupling:
        io.query.return_value = coupling.value

        try:
            _ = hal.get_trigger_coupling()
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.DriverToHal
            assert coupling in [
                driver.TriggerCoupling.HFREJ,
                driver.TriggerCoupling.LFREJ,
                driver.TriggerCoupling.NOISEREJ,
            ]


def test_trigger_mode_mappings_hal_to_driver():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for mode in hal_oscope.TriggerMode:
        try:
            hal.set_trigger_mode(mode)
        except MappingException as e:  # pyright: ignore[reportUnknownVariableType]
            assert e.direction == MappingDirection.HalToDriver
            assert mode == hal_oscope.TriggerMode.CAN


def test_trigger_slope_mappings():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    for slope in hal_oscope.TriggerSlope:
        hal.set_trigger_slope(slope)
        assert hal.get_trigger_slope() == slope


def test_waveform_encoding_csv():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    hal.set_waveform_encoding(hal_oscope.WaveformEncoding.CSV)
    assert hal.get_waveform_encoding() == hal_oscope.WaveformEncoding.CSV


def test_waveform_encoding_binary():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    # Simulate the instrument returning BINARY after DATa:ENCdg RIBinary is sent.
    # On real hardware, DATa:ENCdg atomically sets WFMOutpre:ENCdg, BN_Fmt and BYT_Or.
    io.query.return_value = "BINARY"

    hal.set_waveform_encoding(hal_oscope.WaveformEncoding.BINARY)
    assert hal.get_waveform_encoding() == hal_oscope.WaveformEncoding.BINARY


def test_get_waveform_data_ascii():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    hal.set_waveform_encoding(hal_oscope.WaveformEncoding.CSV)
    data = hal.get_waveform_data()

    # Mock returns "1,2,3,4,5,6,7,8,9,10" with ymult=1.0, yoff=0.0, yzero=0.0
    assert len(data) == 10
    assert data[0] == 1.0
    assert data[9] == 10.0


def test_get_waveform_data_binary_int8():
    io = MagicMock()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    num_points = 4
    raw_points = [10, -20, 30, -40]
    raw_bytes = struct.pack(f">{num_points}b", *raw_points)
    ieee_block = b"#1" + str(len(raw_bytes)).encode() + raw_bytes

    y_multiplier = 0.5
    y_offset = 0.0
    y_zero = 0.0

    io.query.side_effect = [
        "BINARY",  # get_waveform_encoding → :WFMO:ENC?
        "MSB",  # query_waveform_byte_order → :WFMO:BYT_O?
        "RI",  # query_waveform_binary_format → :WFMO:BN_F?
        "1",  # query_waveform_byte_nr → :WFMO:BYT_N?
        str(num_points),  # query_waveform_nr_points → :WFMO:NR_P?
        str(y_offset),  # query_waveform_y_offset → :WFMO:YOF?
        str(y_multiplier),  # query_waveform_y_multiplier → :WFMO:YMU?
        str(y_zero),  # query_waveform_y_zero → :WFMO:YZE?
    ]
    io.read_bytes.side_effect = [
        ieee_block[:2],  # header start (#1)
        str(len(raw_bytes)).encode(),  # length digits
        raw_bytes,  # payload
    ]

    data = hal.get_waveform_data()

    expected = [((p - y_offset) * y_multiplier) + y_zero for p in raw_points]
    assert len(data) == num_points
    for actual, exp in zip(data, expected):
        assert abs(actual - exp) < 1e-6


def test_probe_display_on_off():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=1)

    hal.set_probe_display(True)
    assert hal.get_probe_display() is True

    hal.set_probe_display(False)
    assert hal.get_probe_display() is False


def test_channel_8_supported():
    io = make_mso_5_series_io()
    hal = HALOscilloscopeProbeTektronixMso5Series(io, channel_number=8)

    _ = hal.get_probe_scale()
