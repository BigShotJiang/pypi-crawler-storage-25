import pytest
from unittest.mock import patch

from fusaware_instruments.visa_instrument_hal.hal_bk_precision_9151 import (
    HALDCPowerSupplyBKPrecision9151,
)
from fusaware_instruments.visa_instrument_hal.hal_dc_power_supply import (
    VoltageSensingMode,
)

from tests.visa.bk_precision_9151 import make_hal


def test_output_enable():
    hal = make_hal()

    hal.set_output_enable(False)
    assert not hal.get_output_enable()

    hal.set_output_enable(True)
    assert hal.get_output_enable()


def test_apply_output_enable():
    hal = make_hal()

    assert hal.apply_output_enable(True)
    assert not hal.apply_output_enable(False)


def test_apply_output_enable_mismatch():
    hal = make_hal()

    with patch.object(
        HALDCPowerSupplyBKPrecision9151, "get_output_enable", return_value=False
    ):
        with pytest.raises(RuntimeError):
            hal.apply_output_enable(True)


def test_source_voltage():
    hal = make_hal()

    hal.set_source_voltage_amplitude(5.0)
    assert hal.get_source_voltage_amplitude() == 5.0

    hal.set_source_voltage_amplitude(0.1)
    assert hal.get_source_voltage_amplitude() == pytest.approx(0.1)


def test_apply_source_voltage():
    hal = make_hal()

    assert hal.apply_source_voltage_amplitude(5.0) == 5.0


def test_apply_source_voltage_mismatch():
    hal = make_hal()

    with patch.object(
        HALDCPowerSupplyBKPrecision9151,
        "get_source_voltage_amplitude",
        return_value=0.0,
    ):
        with pytest.raises(RuntimeError):
            hal.apply_source_voltage_amplitude(5.0)


def test_source_current_limit():
    hal = make_hal()

    hal.set_source_current_limit(1.0)
    assert hal.get_source_current_limit() == 1.0

    hal.set_source_current_limit(0.5)
    assert hal.get_source_current_limit() == pytest.approx(0.5)


def test_apply_source_current_limit():
    hal = make_hal()

    assert hal.apply_source_current_limit(1.0) == 1.0


def test_apply_source_current_limit_mismatch():
    hal = make_hal()

    with patch.object(
        HALDCPowerSupplyBKPrecision9151, "get_source_current_limit", return_value=0.0
    ):
        with pytest.raises(RuntimeError):
            hal.apply_source_current_limit(1.0)


def test_voltage_sensing_mode():
    hal = make_hal()

    for mode in [VoltageSensingMode.LOCAL, VoltageSensingMode.REMOTE]:
        hal.set_source_voltage_sensing_mode(mode)
        assert hal.get_source_voltage_sensing_mode() == mode


def test_voltage_sensing_mode_unknown_raises():
    hal = make_hal()

    with pytest.raises(ValueError):
        hal.set_source_voltage_sensing_mode(VoltageSensingMode.UNKNOWN)


def test_apply_voltage_sensing_mode():
    hal = make_hal()

    assert (
        hal.apply_source_voltage_sensing_mode(VoltageSensingMode.LOCAL)
        == VoltageSensingMode.LOCAL
    )
    assert (
        hal.apply_source_voltage_sensing_mode(VoltageSensingMode.REMOTE)
        == VoltageSensingMode.REMOTE
    )


def test_apply_voltage_sensing_mode_mismatch():
    hal = make_hal()

    with patch.object(
        HALDCPowerSupplyBKPrecision9151,
        "get_source_voltage_sensing_mode",
        return_value=VoltageSensingMode.REMOTE,
    ):
        with pytest.raises(RuntimeError):
            hal.apply_source_voltage_sensing_mode(VoltageSensingMode.LOCAL)


def test_measurements():
    hal = make_hal()

    assert hal.get_output_voltage_measurement() == 5.0
    assert hal.get_output_current_measurement() == 1.0


def test_not_connected():
    hal = HALDCPowerSupplyBKPrecision9151(
        resource_name="TCPIP0::localhost::inst0::INSTR"
    )

    with pytest.raises(RuntimeError, match="not connected"):
        hal.get_source_voltage_amplitude()
    with pytest.raises(RuntimeError, match="not connected"):
        hal.set_source_voltage_amplitude(5.0)
    with pytest.raises(RuntimeError, match="not connected"):
        hal.get_source_current_limit()
    with pytest.raises(RuntimeError, match="not connected"):
        hal.get_output_enable()
    with pytest.raises(RuntimeError, match="not connected"):
        hal.get_output_voltage_measurement()
    with pytest.raises(RuntimeError, match="not connected"):
        hal.get_output_current_measurement()


def test_ocp_not_implemented():
    hal = make_hal()

    with pytest.raises(NotImplementedError):
        hal.get_over_current_protection_enable()
    with pytest.raises(NotImplementedError):
        hal.set_over_current_protection_enable(True)
    with pytest.raises(NotImplementedError):
        hal.apply_over_current_protection_enable(True)
    with pytest.raises(NotImplementedError):
        hal.get_over_current_protection_threshold()
    with pytest.raises(NotImplementedError):
        hal.set_over_current_protection_threshold(1.0)
    with pytest.raises(NotImplementedError):
        hal.apply_over_current_protection_threshold(1.0)
    with pytest.raises(NotImplementedError):
        hal.get_power_source_mode()
