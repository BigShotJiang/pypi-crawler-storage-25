# pyright: strict

import pyvisa
import logging

from fusaware_instruments.visa_instrument_configuration.dc_voltage_supply import (
    State,
    VoltageSensing,
    configure_dc_voltage_supply,
)
from fusaware_instruments.visa_instrument_hal.hal_bk_precision_9151 import (
    HALDCPowerSupplyBKPrecision9151,
)


def make_hal() -> HALDCPowerSupplyBKPrecision9151:
    resource_name = "TCPIP0::localhost::inst0::INSTR"
    hal = HALDCPowerSupplyBKPrecision9151(resource_name)
    hal._rm = pyvisa.ResourceManager(  # pyright: ignore[reportPrivateUsage]
        "tests/visa/bk_precision_9151/mock_9151.yaml@sim"
    )
    hal.connect()
    if hal._instr is None:  # pyright: ignore[reportPrivateUsage]
        raise RuntimeError("Failed to connect to instrument")
    hal._instr.write_termination = "\n"  # pyright: ignore[reportPrivateUsage]
    hal._instr.read_termination = "\n"  # pyright: ignore[reportPrivateUsage]

    if logging.root.level >= logging.INFO:
        query_original = hal._instr.query  # pyright: ignore[reportPrivateUsage]
        write_original = hal._instr.write  # pyright: ignore[reportPrivateUsage]

        def query_with_logging(message: str, delay: float | None = None) -> str:
            # logging.info(f"Writing '{message}' for query")
            response = query_original(message, delay)
            logging.info(f"Reponse for query '{message}': {response}")
            return response

        def write_with_logging(
            message: str, termination: str | None = None, encoding: str | None = None
        ) -> int:
            logging.info(f"Writing '{message}'")
            bytes_written = write_original(message, termination, encoding)
            logging.info(f"Wrote {bytes_written} bytes")
            return bytes_written

        hal._instr.query = query_with_logging  # pyright: ignore[reportPrivateUsage]
        hal._instr.write = write_with_logging  # pyright: ignore[reportPrivateUsage]

    return hal


def test_configure_dc_voltage_supply():
    hal = make_hal()

    current_limit = 0.5
    target_voltage = 5.0

    for state in State:
        for sensing in [VoltageSensing.LOCAL, VoltageSensing.REMOTE]:
            response, errors = configure_dc_voltage_supply(
                hal, current_limit, sensing, state, target_voltage
            )

            assert len(errors) == 0
            assert response.current_limit == current_limit
            assert response.sensing == sensing
            assert response.state == state
            assert response.target == target_voltage
