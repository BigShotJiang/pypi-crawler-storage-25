import pytest

from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_9151 import (
    BKPrecision9151,
)


def test_output_state():
    assert BKPrecision9151.output_state_query() == ":OUTP:STAT?"

    assert BKPrecision9151.output_state_parse("0") == BKPrecision9151.OutputState.OFF
    assert BKPrecision9151.output_state_parse("1") == BKPrecision9151.OutputState.ON

    assert (
        BKPrecision9151.output_state_write(BKPrecision9151.OutputState.OFF)
        == ":OUTP:STAT 0"
    )
    assert (
        BKPrecision9151.output_state_write(BKPrecision9151.OutputState.ON)
        == ":OUTP:STAT 1"
    )


def test_output_state_parse_invalid():
    with pytest.raises(ValueError):
        BKPrecision9151.output_state_parse("2")


def test_source_voltage():
    assert BKPrecision9151.source_voltage_level_immediate_amplitude_query() == ":VOLT?"

    assert BKPrecision9151.source_voltage_level_immediate_amplitude_parse("5.0") == 5.0
    assert (
        BKPrecision9151.source_voltage_level_immediate_amplitude_parse("1.5E+00") == 1.5
    )

    assert (
        BKPrecision9151.source_voltage_level_immediate_amplitude_write(5.0)
        == ":VOLT 5.0"
    )
    assert (
        BKPrecision9151.source_voltage_level_immediate_amplitude_write(0.0)
        == ":VOLT 0.0"
    )


def test_source_current():
    assert BKPrecision9151.source_current_level_immediate_amplitude_query() == ":CURR?"

    assert BKPrecision9151.source_current_level_immediate_amplitude_parse("1.5") == 1.5
    assert BKPrecision9151.source_current_level_immediate_amplitude_parse(
        "2.0E-01"
    ) == pytest.approx(0.2)

    assert (
        BKPrecision9151.source_current_level_immediate_amplitude_write(1.5)
        == ":CURR 1.5"
    )
    assert (
        BKPrecision9151.source_current_level_immediate_amplitude_write(0.0)
        == ":CURR 0.0"
    )


def test_measure_voltage():
    assert BKPrecision9151.measure_scalar_voltage_dc_query() == ":MEAS:VOLT:DC?"

    assert BKPrecision9151.measure_scalar_voltage_dc_parse("5.0") == 5.0
    assert BKPrecision9151.measure_scalar_voltage_dc_parse("1.5E+00") == 1.5
    assert BKPrecision9151.measure_scalar_voltage_dc_parse("0.000000") == 0.0
    assert BKPrecision9151.measure_scalar_voltage_dc_parse("-5.0") == -5.0
    assert BKPrecision9151.measure_scalar_voltage_dc_parse("-1.5E+00") == -1.5


def test_measure_current():
    assert BKPrecision9151.measure_scalar_current_dc_query() == ":MEAS:CURR:DC?"

    assert BKPrecision9151.measure_scalar_current_dc_parse("1.0") == 1.0
    assert BKPrecision9151.measure_scalar_current_dc_parse("2.5E-02") == pytest.approx(
        0.025
    )
    assert BKPrecision9151.measure_scalar_current_dc_parse("-1.0") == -1.0
    assert BKPrecision9151.measure_scalar_current_dc_parse("-2.5E-02") == pytest.approx(
        -0.025
    )


def test_remote_sense_state():
    assert BKPrecision9151.source_system_sense_state_query() == "SYST:SENS?"

    assert (
        BKPrecision9151.source_system_sense_state_parse("0")
        == BKPrecision9151.RemoteSenseState.OFF
    )
    assert (
        BKPrecision9151.source_system_sense_state_parse("1")
        == BKPrecision9151.RemoteSenseState.ON
    )

    assert (
        BKPrecision9151.source_system_sense_state_write(
            BKPrecision9151.RemoteSenseState.OFF
        )
        == "SYST:SENS 0"
    )
    assert (
        BKPrecision9151.source_system_sense_state_write(
            BKPrecision9151.RemoteSenseState.ON
        )
        == "SYST:SENS 1"
    )


def test_remote_sense_state_parse_invalid():
    with pytest.raises(ValueError):
        BKPrecision9151.source_system_sense_state_parse("2")
