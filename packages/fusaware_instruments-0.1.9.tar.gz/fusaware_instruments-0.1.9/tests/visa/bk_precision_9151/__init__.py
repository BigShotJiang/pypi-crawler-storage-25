import pyvisa

from fusaware_instruments.visa_instrument_hal.hal_bk_precision_9151 import (
    HALDCPowerSupplyBKPrecision9151,
)


def make_hal() -> HALDCPowerSupplyBKPrecision9151:
    resource_name = "TCPIP0::localhost::inst0::INSTR"
    hal = HALDCPowerSupplyBKPrecision9151(resource_name)
    hal._rm = pyvisa.ResourceManager(  # pyright: ignore[reportPrivateUsage]
        "tests/visa/bk_precision_9151/mock_9151.yaml@sim"
    )
    hal.connect()
    if hal._instr is None:  # pyright: ignore[reportPrivateUsage]
        raise RuntimeError("Failed to connect to instrument")
    hal._instr.write_termination = "\n"  # pyright: ignore[reportPrivateUsage]
    hal._instr.read_termination = "\n"  # pyright: ignore[reportPrivateUsage]
    return hal
