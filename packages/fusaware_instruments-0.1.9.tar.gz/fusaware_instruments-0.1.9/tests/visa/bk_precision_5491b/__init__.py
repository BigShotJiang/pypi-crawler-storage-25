from fusaware_instruments.visa_instrument_hal.hal_dmm_bk_precision_5491b import (
    HALDmmBkPrecision5491b,
)


def make_dmm_sim() -> HALDmmBkPrecision5491b:
    dmm = HALDmmBkPrecision5491b("TCPIP0::localhost::inst0::INSTR")
    dmm.connect(sim_file="tests/visa/bk_precision_5491b/mock_bk_5491b.yaml")
    assert dmm._device is not None
    dmm._device.read_termination = "\n"
    dmm._device.write_termination = "\n"

    return dmm
