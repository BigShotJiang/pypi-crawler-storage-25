from unittest.mock import patch


from fusaware_instruments.visa_instrument_configuration.dc_voltage_dmm import (
    configure_dc_voltage_meter,
)
from fusaware_instruments.visa_instrument_configuration.dc_current_dmm import (
    configure_dc_current_meter,
)
from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    DCCurrentRange,
    DCVoltageRange,
)

from fusaware_instruments.visa_instrument_hal.hal_dmm import DEFAULT_NPLCS
from tests.visa.bk_precision_5491b import make_dmm_sim


@patch("time.sleep", return_value=None)
def test_configure_dc_voltage_meter(_):
    dmm = make_dmm_sim()

    for voltage_range in DCVoltageRange:
        result, errors = configure_dc_voltage_meter(
            dmm, float(voltage_range.value), DEFAULT_NPLCS
        )
        assert len(errors) == 0
        assert result == float(voltage_range.value)


@patch("time.sleep", return_value=None)
def test_configure_dc_current_meter(_):
    dmm = make_dmm_sim()

    for current_range in DCCurrentRange:
        result, errors = configure_dc_current_meter(
            dmm, float(current_range.value), DEFAULT_NPLCS
        )
        assert len(errors) == 0
        assert result == float(current_range.value)
