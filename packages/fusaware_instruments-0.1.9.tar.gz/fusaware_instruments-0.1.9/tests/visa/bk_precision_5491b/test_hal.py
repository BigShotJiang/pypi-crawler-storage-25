from unittest.mock import MagicMock, patch, call


from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    DCVoltageRange,
    DCCurrentRange,
)
from fusaware_instruments.visa_instrument_hal.hal_dmm import MeasurementFunction
from fusaware_instruments.visa_instrument_hal.hal_dmm_bk_precision_5491b import (
    DELAY,
)

from tests.visa.bk_precision_5491b import make_dmm_sim


@patch("time.sleep", return_value=None)
def test_io_wrappers(mock_sleep: MagicMock):
    dmm = make_dmm_sim()

    dmm._write("*IDN?")
    assert mock_sleep.call_count == 1

    assert dmm._device is not None
    _ = dmm._device.read()

    dmm._query("*IDN?")
    assert mock_sleep.call_count == 3

    mock_sleep.assert_has_calls([call(DELAY), call(DELAY), call(DELAY)])


@patch("time.sleep", return_value=None)
def test_measurement_function(_):
    dmm = make_dmm_sim()

    for func in MeasurementFunction:
        dmm.set_measurement_function(func)
        assert dmm.get_measurement_function() == func


@patch("time.sleep", return_value=None)
def test_dc_voltage_range(_):
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCVoltage)

    for voltage_range in DCVoltageRange:
        range_float = float(voltage_range.value)
        dmm.set_measurement_range(MeasurementFunction.DCVoltage, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCVoltage,
            )
            == range_float
        )


@patch("time.sleep", return_value=None)
def test_dc_current_range(_):
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCCurrent)

    for voltage_range in DCCurrentRange:
        range_float = float(voltage_range.value)
        dmm.set_measurement_range(MeasurementFunction.DCCurrent, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCCurrent,
            )
            == range_float
        )


@patch("time.sleep", return_value=None)
def test_get_measurement(_):
    dmm = make_dmm_sim()
    assert dmm.get_measurement() == 42.0
