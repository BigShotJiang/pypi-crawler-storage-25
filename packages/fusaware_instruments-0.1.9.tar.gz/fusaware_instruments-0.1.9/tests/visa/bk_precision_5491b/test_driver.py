from fusaware_instruments.visa_instrument_drivers.driver_bk_precision_5491b import (
    BKPrecision5491B as bk_msg,
    MeasurementFunction,
)


# Maybe not so useful
def test_function():
    assert bk_msg.function_query() == ":FUNC?"

    for func in MeasurementFunction:
        assert bk_msg.function_parse(func.value) == func
        assert bk_msg.function_write(func) == f":FUNC {func.value}"
