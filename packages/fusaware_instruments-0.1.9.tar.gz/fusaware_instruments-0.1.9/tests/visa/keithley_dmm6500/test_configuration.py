from fusaware_instruments.visa_instrument_configuration.dc_voltage_dmm import (
    configure_dc_voltage_meter,
)
from fusaware_instruments.visa_instrument_drivers.driver_keithley_dmm6500 import (
    DCCurrentRange,
    DCVoltageRange,
    KeithleyDMM6500,
    Terminals,
)
from fusaware_instruments.visa_instrument_hal.hal_dmm import DEFAULT_NPLCS
from fusaware_instruments.visa_instrument_configuration.dc_current_dmm import (
    configure_dc_current_meter,
)

from fusaware_instruments.visa_instrument_hal.hal_dmm_keithley_dmm6500 import (
    HALDmmKeithleyDMM6500,
)
from tests.visa.keithley_dmm6500 import make_dmm_sim


def test_configure_dc_voltage_meter():
    dmm = make_dmm_sim()

    valid_ranges = [rnge.value for rnge in DCVoltageRange]

    for voltage_range in valid_ranges:
        result, errors = configure_dc_voltage_meter(dmm, voltage_range, DEFAULT_NPLCS)
        assert len(errors) == 0
        assert result == voltage_range


def test_configure_dc_voltage_meter_auto_range():
    dmm = make_dmm_sim()

    result, errors = configure_dc_voltage_meter(dmm, "auto", DEFAULT_NPLCS)
    assert len(errors) == 0
    assert result == "auto"


def apply_terminal(dmm: HALDmmKeithleyDMM6500, terminal: Terminals):
    assert dmm._device is not None

    write_msg = KeithleyDMM6500.route_teminals_write(terminal)
    dmm._device.write(write_msg)
    query_msg = KeithleyDMM6500.route_teminals_query()
    resp = dmm._device.query(query_msg)
    parsed = KeithleyDMM6500.route_teminals_parse(resp)
    assert parsed == terminal

    if terminal == Terminals.REAR:
        write_msg = KeithleyDMM6500.sense_dc_current_range_auto_write(False)
        dmm._device.write(write_msg)
        query_msg = KeithleyDMM6500.sense_dc_current_range_auto_query()
        resp = dmm._device.query(query_msg)
        parsed = KeithleyDMM6500.sense_dc_current_range_auto_parse(resp)
        assert not parsed


def test_configure_dc_current_meter_front_terminal():
    dmm = make_dmm_sim()
    apply_terminal(dmm, Terminals.FRONT)

    valid_ranges = [rnge.value for rnge in DCCurrentRange]

    for current_range in valid_ranges:
        try:
            result, errors = configure_dc_current_meter(
                dmm, current_range, DEFAULT_NPLCS
            )
            assert len(errors) == 0
            assert result == current_range
        except ValueError as e:
            assert "Front" in str(e)


def test_configure_dc_current_meter_rear_terminal():
    dmm = make_dmm_sim()
    apply_terminal(dmm, Terminals.REAR)

    valid_ranges = [rnge.value for rnge in DCCurrentRange]

    for current_range in valid_ranges:
        result, errors = configure_dc_current_meter(dmm, current_range, DEFAULT_NPLCS)
        assert len(errors) == 0
        assert result == current_range


def test_configure_dc_current_meter_auto_range():
    dmm = make_dmm_sim()

    apply_terminal(dmm, Terminals.FRONT)
    result, errors = configure_dc_current_meter(dmm, "auto", DEFAULT_NPLCS)
    assert len(errors) == 0
    assert result == "auto"

    apply_terminal(dmm, Terminals.REAR)
    result, errors = configure_dc_current_meter(dmm, "auto", DEFAULT_NPLCS)
    assert len(errors) == 0
    assert result == "auto"
