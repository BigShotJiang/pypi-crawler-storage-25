from fusaware_instruments.visa_instrument_hal.hal_dmm_keithley_dmm6500 import (
    HALDmmKeithleyDMM6500,
)


def make_dmm_sim() -> HALDmmKeithleyDMM6500:
    dmm = HALDmmKeithleyDMM6500("TCPIP0::localhost::inst0::INSTR")
    dmm.connect(sim_file="tests/visa/keithley_dmm6500/mock_keithley_dmm6500.yaml")
    assert dmm._device is not None
    dmm._device.read_termination = "\n"
    dmm._device.write_termination = "\n"
    original_query = dmm._device.query
    original_write = dmm._device.write

    def query_with_logging(message: str, delay: float | None = None) -> str:
        resp = original_query(message, delay)
        print(f"Read response '{resp}' for query '{message}'")
        return resp

    def write_with_logging(
        message: str, termination: str | None = None, encoding: str | None = None
    ) -> int:
        print(f"Writing message '{message}'")
        return original_write(message, termination, encoding)

    dmm._device.query = query_with_logging
    dmm._device.write = write_with_logging

    return dmm
