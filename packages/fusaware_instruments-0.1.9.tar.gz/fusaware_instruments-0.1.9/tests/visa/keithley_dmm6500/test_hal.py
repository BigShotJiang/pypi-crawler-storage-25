from fusaware_instruments.visa_instrument_drivers.driver_keithley_dmm6500 import (
    DCVoltageRange,
    DCCurrentRange,
    KeithleyDMM6500,
)
from fusaware_instruments.visa_instrument_hal.hal_dmm import MeasurementFunction

from tests.visa.keithley_dmm6500 import make_dmm_sim


def test_measurement_function():
    dmm = make_dmm_sim()

    for func in MeasurementFunction:
        dmm.set_measurement_function(func)
        assert dmm.get_measurement_function() == func


def test_dc_voltage_range():
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCVoltage)

    assert dmm._device is not None
    write_msg = KeithleyDMM6500.sense_dc_voltage_range_auto_write(False)
    dmm._device.write(write_msg)
    query_msg = KeithleyDMM6500.sense_dc_voltage_range_auto_query()
    resp = dmm._device.query(query_msg)
    assert not KeithleyDMM6500.sense_dc_voltage_range_auto_parse(resp)

    for voltage_range in DCVoltageRange:
        range_float = float(voltage_range.value)
        dmm.set_measurement_range(MeasurementFunction.DCVoltage, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCVoltage,
            )
            == range_float
        )


def test_dc_current_range():
    dmm = make_dmm_sim()
    dmm.set_measurement_function(MeasurementFunction.DCCurrent)

    assert dmm._device is not None
    write_msg = KeithleyDMM6500.sense_dc_current_range_auto_write(False)
    dmm._device.write(write_msg)
    query_msg = KeithleyDMM6500.sense_dc_current_range_auto_query()
    resp = dmm._device.query(query_msg)
    assert not KeithleyDMM6500.sense_dc_current_range_auto_parse(resp)

    for voltage_range in DCCurrentRange:
        range_float = float(voltage_range.value)
        dmm.set_measurement_range(MeasurementFunction.DCCurrent, range_float)
        assert (
            dmm.get_measurement_range(
                MeasurementFunction.DCCurrent,
            )
            == range_float
        )


def test_get_measurement():
    dmm = make_dmm_sim()
    assert dmm.get_measurement() == 42.0
