from fusaware_instruments.visa_instrument_drivers.driver_keithley_dmm6500 import (
    KeithleyDMM6500,
    MeasurementFunction,
)


# Maybe not so useful
def test_function():
    assert KeithleyDMM6500.sense_function_on_query() == ":FUNC?"

    for func in MeasurementFunction:
        assert KeithleyDMM6500.sense_function_on_parse(func.value) == func
        assert KeithleyDMM6500.sense_function_on_write(func) == f':FUNC "{func.value}"'
