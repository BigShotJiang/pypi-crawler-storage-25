# pyright: strict

from typing import Callable
import random

from fusaware_instruments.visa_instrument_configuration.oscilloscope import (
    configure_oscope_trigger,
    TriggerState,
)
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    HALOscilloscope,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerSweep,
)
from fusaware_instruments.visa_instrument_configuration.analog_probe import (
    AnalogProbeState,
    configure_analog_probe,
    Coupling,
    Units,
    State,
)


def eulerian_circuit[T](nodes: list[T]) -> list[T]:
    """
    Returns a sequence visiting every ordered pair (a, b) where a != b exactly once,
    by finding an Eulerian circuit in the complete directed graph K_n.

    Consecutive elements in the returned list are the transitions to test.
    Length: n*(n-1) + 1, with first == last.
    """
    n = len(nodes)
    # Each node i has neighbors [0..i-1, i+1..n-1]; track how far we've consumed
    neighbor_idx = [0] * n

    def nth_neighbor(i: int, k: int) -> int:
        # k-th neighbor of i, skipping self
        return k if k < i else k + 1

    stack = [0]
    circuit: list[int] = []

    while stack:
        v = stack[-1]
        if neighbor_idx[v] < n - 1:
            u = nth_neighbor(v, neighbor_idx[v])
            neighbor_idx[v] += 1
            stack.append(u)
        else:
            circuit.append(stack.pop())

    circuit.reverse()
    return [nodes[i] for i in circuit]


def generate_probe_permutations() -> list[AnalogProbeState]:
    scale_values = [0.01, 0.1, 0.5, 1, 2, 5, 10]
    offset_values = [0.0]
    attenuation_values = [10.0]

    permutations: list[AnalogProbeState] = []

    for state in State:
        for coupling in Coupling:
            for units in Units:
                for bandwidth_limit in ["none", 20e6]:
                    for scale in scale_values:
                        for offset in offset_values:
                            for attenuation in attenuation_values:
                                permutations.append(
                                    AnalogProbeState(
                                        attenuation=attenuation,
                                        bandwidth_limit=bandwidth_limit,
                                        coupling=coupling,
                                        offset=offset,
                                        state=state,
                                        units=units,
                                        scale=scale,
                                    )
                                )

    return permutations


def probe_harness(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, AnalogProbeState], None],
    attenuation: float = 10.0,
    scale: float = 1.0,
    offset: float = 0.0,
) -> None:
    """
    Harness for testing a HALOscilloscope instance against all practical permutations for the configure_analog_probe function
    """

    permutations: list[AnalogProbeState] = []

    for state in State:
        for coupling in Coupling:
            for units in Units:
                for bandwidth_limit in ["none", 20e6]:
                    permutations.append(
                        AnalogProbeState(
                            attenuation=attenuation,
                            bandwidth_limit=bandwidth_limit,
                            coupling=coupling,
                            offset=offset,
                            state=state,
                            units=units,
                            scale=scale,
                        )
                    )

    for desired_state in permutations:
        try:
            final_state, errors = configure_analog_probe(
                hal,
                attenuation=desired_state.attenuation,
                bandwidth_limit=desired_state.bandwidth_limit,
                coupling=desired_state.coupling,
                offset=desired_state.offset,
                state=desired_state.state,
                units=desired_state.units,
                scale=desired_state.scale,
            )

            assert len(errors) == 0
            assert final_state == desired_state

        except Exception as e:
            exception_handler(e, desired_state)


def probe_harness_exhaustive(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, AnalogProbeState], None],
    attenuation: float = 10.0,
    scale: float = 1.0,
    offset: float = 0.0,
) -> None:
    """
    Harness for testing a HALOscilloscope instance against all possible valid state transitions
    for AnalogProbeState, not including changes to scale and offset

    CAUTION: this will result in >2000 calls to configure_analog_probe with the current API
    """

    permutations: list[AnalogProbeState] = []

    for state in State:
        for coupling in Coupling:
            for units in Units:
                for bandwidth_limit in ["none", 20e6]:
                    analog_probe_state = AnalogProbeState(
                        attenuation=attenuation,
                        bandwidth_limit=bandwidth_limit,
                        coupling=coupling,
                        offset=offset,
                        state=state,
                        units=units,
                        scale=scale,
                    )
                    permutations.append(analog_probe_state)

    for desired_state in eulerian_circuit(permutations):
        try:
            final_state, errors = configure_analog_probe(
                hal,
                attenuation=desired_state.attenuation,
                bandwidth_limit=desired_state.bandwidth_limit,
                coupling=desired_state.coupling,
                offset=desired_state.offset,
                state=desired_state.state,
                units=desired_state.units,
                scale=desired_state.scale,
            )

            assert len(errors) == 0
            assert final_state == desired_state

        except Exception as e:
            exception_handler(e, desired_state)


def probe_harness_random_sample(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, AnalogProbeState], None],
    sample_iterations: int,
    sample_count: int,
) -> None:
    permutations = generate_probe_permutations()
    iteration = 1

    for _ in range(sample_iterations):
        samples = random.sample(permutations, sample_count)
        random.shuffle(samples)

        for desired_state in samples:
            try:
                final_state, errors = configure_analog_probe(
                    hal,
                    attenuation=desired_state.attenuation,
                    bandwidth_limit=desired_state.bandwidth_limit,
                    coupling=desired_state.coupling,
                    offset=desired_state.offset,
                    state=desired_state.state,
                    units=desired_state.units,
                    scale=desired_state.scale,
                )

                assert len(errors) == 0
                assert final_state == desired_state

            except Exception as e:
                exception_handler(e, desired_state)
            finally:
                print(
                    f"Ran iteration {iteration} for state {desired_state.model_dump_json()}"
                )
                iteration += 1


def generate_trigger_permutations() -> list[TriggerState]:
    permutations: list[TriggerState] = []
    threshold_values = [0.1, 1, 5, 7, 10, 20]
    holdoff_values = [1e-6, 1e-3, 0.1]

    for state in State:
        for coupling in TriggerCoupling:
            for mode in TriggerMode:
                for slope in TriggerSlope:
                    for sweep in TriggerSweep:
                        for threshold in threshold_values:
                            for holdoff in holdoff_values:
                                permutations.append(
                                    TriggerState(
                                        coupling=coupling,
                                        holdoff=holdoff,
                                        mode=mode,
                                        slope=slope,
                                        threshold=threshold,
                                        state=state,
                                        sweep=sweep,
                                    )
                                )

    return permutations


def trigger_harness(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, TriggerState], None],
    threshold: float = 1.0,
    holdoff: float = 1e-3,
) -> None:
    """
    Harness for testing a HALOscilloscope instance against all practical permutations for the configure_oscope_trigger function
    """
    permutations: list[TriggerState] = []

    for state in State:
        for coupling in TriggerCoupling:
            for mode in TriggerMode:
                for slope in TriggerSlope:
                    for sweep in TriggerSweep:
                        permutations.append(
                            TriggerState(
                                coupling=coupling,
                                holdoff=holdoff,
                                mode=mode,
                                slope=slope,
                                threshold=threshold,
                                state=state,
                                sweep=sweep,
                            )
                        )

    for desired_state in permutations:
        try:
            final_state, errors = configure_oscope_trigger(
                hal,
                coupling=desired_state.coupling,
                holdoff=desired_state.holdoff,
                mode=desired_state.mode,
                slope=desired_state.slope,
                threshold=desired_state.threshold,
                state=desired_state.state,
                sweep=desired_state.sweep,
            )

            assert len(errors) == 0
            assert final_state == desired_state
        except Exception as e:
            exception_handler(e, desired_state)


def trigger_harness_exhaustive(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, TriggerState], None],
    threshold: float = 1.0,
    holdoff: float = 1e-3,
) -> None:
    """
    Harness for testing a HALOscilloscope instance against all possible valid state transitions
    for TriggerState, not including changes to threshold and holdoff

    CAUTION: this will result in >5000 calls to configure_oscope_trigger with the current API
    """
    permutations: list[TriggerState] = []

    for state in State:
        for coupling in TriggerCoupling:
            for mode in TriggerMode:
                for slope in TriggerSlope:
                    for sweep in TriggerSweep:
                        permutations.append(
                            TriggerState(
                                coupling=coupling,
                                holdoff=holdoff,
                                mode=mode,
                                slope=slope,
                                threshold=threshold,
                                state=state,
                                sweep=sweep,
                            )
                        )

    for desired_state in eulerian_circuit(permutations):
        try:
            final_state, errors = configure_oscope_trigger(
                hal,
                coupling=desired_state.coupling,
                holdoff=desired_state.holdoff,
                mode=desired_state.mode,
                slope=desired_state.slope,
                threshold=desired_state.threshold,
                state=desired_state.state,
                sweep=desired_state.sweep,
            )

            assert len(errors) == 0
            assert final_state == desired_state
        except Exception as e:
            exception_handler(e, desired_state)


def trigger_harness_random_sample(
    hal: HALOscilloscope,
    exception_handler: Callable[[Exception, TriggerState], None],
    sample_iterations: int,
    sample_count: int,
) -> None:
    permutations = generate_trigger_permutations()
    iteration = 1

    for _ in range(sample_iterations):
        samples = random.sample(permutations, sample_count)
        random.shuffle(samples)

        for desired_state in samples:
            try:
                final_state, errors = configure_oscope_trigger(
                    hal,
                    coupling=desired_state.coupling,
                    holdoff=desired_state.holdoff,
                    mode=desired_state.mode,
                    slope=desired_state.slope,
                    threshold=desired_state.threshold,
                    state=desired_state.state,
                    sweep=desired_state.sweep,
                )

                assert len(errors) == 0
                assert final_state == desired_state

            except Exception as e:
                exception_handler(e, desired_state)
            finally:
                print(
                    f"Ran iteration {iteration} for state {desired_state.model_dump_json()}"
                )
                iteration += 1
