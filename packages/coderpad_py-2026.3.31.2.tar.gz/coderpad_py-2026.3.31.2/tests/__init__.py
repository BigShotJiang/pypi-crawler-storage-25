"""Tests for ``coderpad``."""
