"""spec §8.1 / §8.3 边界 / 容器交叉 / 集成不变性补齐：

- T-D：容器交叉（fence 内 pipe / table 内 fence / 嵌套 marker）
- T-K：集成不变性（reset_history_view 清空 5 字段、handle_event 后
  Q11 兜底语义保持）
"""

from __future__ import annotations

import unittest

from comate_agent_sdk.agent.events import (
    StopEvent,
    TextDeltaEvent,
    ThinkingDeltaEvent,
)

from comate_cli.terminal_agent.event_renderer import (
    ContainerState,
    EventRenderer,
)


class TestContainerCrossing(unittest.TestCase):
    """spec §8.1 T-D：容器交叉路径。

    T-D1：fence 内含 "| a |" 不进 table 模式（fence 优先级最高）
    T-D2：table 内出现 ```python → table flush + fence open（递归路径）
          —— 已被 test_event_renderer_streaming.py::TestHandleCompleteLine
          ::test_handle_complete_line_table_ends_on_fence 覆盖；本文件
          再补一个 unit 版用作冗余护栏
    T-D3：fence 内嵌套 marker（如 "```inner") —— 按 CommonMark 同 char +
          ≥ 同长度规则视为闭合，非容器嵌套
    """

    def test_d1_fence_keeps_pipe_lines_verbatim(self):
        renderer = EventRenderer()
        renderer._handle_complete_line("```py")
        # 容器内出现疑似 table 行 —— 应 verbatim append 不切到 table 模式
        renderer._handle_complete_line("| a | b |")
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.kind, "fence")
        self.assertEqual(renderer._container.lines, ["```py", "| a | b |"])
        self.assertIsNone(renderer._held_pipe_line)

    def test_d2_table_to_fence_recursive_path(self):
        """容器内 ```py 行：table flush + fence open（递归路径）"""
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |"],
        )
        before_history = len(renderer._history)
        renderer._handle_complete_line("```python")
        # table flush 入 history（1 entry）+ fence 容器开启
        self.assertEqual(len(renderer._history), before_history + 1)
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.kind, "fence")
        self.assertEqual(renderer._container.fence_lang, "python")

    def test_d3_fence_nested_marker_is_close(self):
        """fence 内出现 "```" 即按 CommonMark 闭合规则关闭，无嵌套语义。"""
        renderer = EventRenderer()
        renderer._handle_complete_line("```py")
        renderer._handle_complete_line("inner code")
        # 容器内 "```" → 闭合 fence
        before_history = len(renderer._history)
        renderer._handle_complete_line("```")
        self.assertIsNone(renderer._container)
        self.assertEqual(len(renderer._history), before_history + 1)
        entry = renderer._history[-1]
        self.assertEqual(entry.text, "```py\ninner code\n```\n")


class TestResetHistoryViewClearsNewFields(unittest.TestCase):
    """spec §8.3 T-K4：reset_history_view 清空 5 个新字段（与 start_turn 对齐）。

    reset 用于会话切换 / rewind / 退回首屏，必须把容器 / pending /
    thinking / aux 全部清零，避免新会话继承上轮残留状态。
    """

    def test_reset_clears_all_five_new_fields(self):
        renderer = EventRenderer()
        # 制造一些 pending state（直接赋字段，独立于容器状态）
        renderer._text_pending = "halfline"
        renderer._held_pipe_line = "| a | b |"
        renderer._container = ContainerState(
            kind="fence", lines=["```py"], fence_marker="```",
        )
        renderer._thinking_batch = "thought"
        renderer._loading_aux_text = "aux"
        # 同时也让 history 有内容（用 _emit_text_line 直接入队，不走
        # _handle_complete_line 避免被预设容器吃掉）
        renderer._emit_text_line("entry 1")
        self.assertGreater(len(renderer._history), 0)

        renderer.reset_history_view()

        # 5 个新字段清零
        self.assertEqual(renderer._text_pending, "")
        self.assertIsNone(renderer._held_pipe_line)
        self.assertIsNone(renderer._container)
        self.assertEqual(renderer._thinking_batch, "")
        self.assertEqual(renderer._loading_aux_text, "")
        # history 也清空（reset 语义）
        self.assertEqual(renderer._history, [])

    def test_start_turn_clears_all_five_new_fields(self):
        """对照测试：start_turn 也应清 5 字段（用于 turn 间隔保持干净）。"""
        renderer = EventRenderer()
        renderer._text_pending = "x"
        renderer._held_pipe_line = "| a |"
        renderer._container = ContainerState(kind="fence", lines=["```"], fence_marker="```")
        renderer._thinking_batch = "y"
        renderer._loading_aux_text = "z"

        renderer.start_turn()

        self.assertEqual(renderer._text_pending, "")
        self.assertIsNone(renderer._held_pipe_line)
        self.assertIsNone(renderer._container)
        self.assertEqual(renderer._thinking_batch, "")
        self.assertEqual(renderer._loading_aux_text, "")


class TestHandleEventRoutingViaPipeline(unittest.TestCase):
    """补强：handle_event 入口路由确实调到新管道（防 Phase 7 退化）。"""

    def test_text_delta_routes_to_consume_text_delta(self):
        renderer = EventRenderer()
        renderer.start_turn()
        # 触发 handle_event TextDeltaEvent 分支
        renderer.handle_event(TextDeltaEvent(delta="hello\n", message_id="m1"))
        # 应通过 _consume_text_delta → _handle_complete_line → _emit_text_line
        # 即时入队（不等 finalize_turn）
        self.assertEqual(renderer._history[-1].text, "hello\n")
        self.assertTrue(renderer._turn_received_text_delta)

    def test_thinking_delta_routes_to_thinking_batch(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer.start_turn()
        renderer.handle_event(ThinkingDeltaEvent(delta="hmm", message_id="m1"))
        # thinking 进入 batch 不立即入 history
        self.assertEqual(renderer._thinking_batch, "hmm")
        # finalize_turn 才 force flush
        renderer.handle_event(StopEvent(reason="completed"))
        renderer.finalize_turn()
        thinking_entries = [
            e for e in renderer._history if e.entry_type == "thinking"
        ]
        self.assertEqual(len(thinking_entries), 1)
        self.assertEqual(thinking_entries[0].text, "hmm")


if __name__ == "__main__":
    unittest.main()
