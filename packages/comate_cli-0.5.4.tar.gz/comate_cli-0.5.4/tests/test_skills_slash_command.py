from __future__ import annotations

import unittest
from types import SimpleNamespace

from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, text: str, *, severity: str = "info") -> None:
        self.messages.append((text, severity))


class _FakeSelectionUI:
    def __init__(self, *, set_options_ok: bool = True) -> None:
        self.set_options_ok = set_options_ok
        self.last_kwargs: dict | None = None
        self.on_confirm = None
        self.on_cancel = None
        self.refresh_calls = 0

    def set_options(self, **kwargs) -> bool:  # type: ignore[no-untyped-def]
        self.last_kwargs = kwargs
        self.on_confirm = kwargs.get("on_confirm")
        self.on_cancel = kwargs.get("on_cancel")
        return self.set_options_ok

    def refresh(self) -> None:
        self.refresh_calls += 1


class _Harness(CommandsMixin):
    def __init__(
        self,
        *,
        session: object,
        renderer: _FakeRenderer,
        selection_ui: _FakeSelectionUI,
    ) -> None:
        self._session = session
        self._renderer = renderer
        self._selection_ui = selection_ui
        self._ui_mode = UIMode.NORMAL
        self._prefill_text: str | None = None
        self._sync_focus_calls = 0
        self._invalidate_calls = 0
        self._refresh_calls = 0

    def _terminal_width(self) -> int:
        return 80

    def _prefill_user_input(self, text: str) -> None:
        self._prefill_text = text

    def _sync_focus_for_mode(self) -> None:
        self._sync_focus_calls += 1

    def _invalidate(self) -> None:
        self._invalidate_calls += 1

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1


def _build_session(skills: list[object] | None) -> object:
    agent = SimpleNamespace(options=SimpleNamespace(skills=skills))
    return SimpleNamespace(_agent=agent)


class TestSkillsSlashCommand(unittest.TestCase):
    def test_slash_skills_usage_error(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(skills=[]),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("--bad")

        self.assertEqual(renderer.messages[-1], ("Usage: /skills", "error"))

    def test_slash_skills_no_active_skills(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="hidden",
                        description="hidden",
                        disable_model_invocation=True,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("")

        self.assertEqual(renderer.messages[-1], ("No active skills loaded.", "info"))
        self.assertIsNone(selection_ui.last_kwargs)

    def test_slash_skills_opens_inline_selection_with_filtered_skills(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="find-skills",
                        description="discover and install skills",
                        disable_model_invocation=False,
                    ),
                    SimpleNamespace(
                        name="hidden",
                        description="should be filtered",
                        disable_model_invocation=True,
                    ),
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("")

        self.assertIsNotNone(selection_ui.last_kwargs)
        assert selection_ui.last_kwargs is not None
        self.assertEqual(selection_ui.last_kwargs["title"], "Select Skill")
        self.assertEqual(
            selection_ui.last_kwargs["options"],
            [
                {
                    "value": "find-skills",
                    "label": "find-skills",
                    "description": "discover and install skills",
                }
            ],
        )
        self.assertEqual(selection_ui.last_kwargs["layout_mode"], "inline")
        self.assertFalse(selection_ui.last_kwargs["line_wrap"])
        self.assertEqual(selection_ui.last_kwargs["inline_total_width"], 80)
        self.assertEqual(selection_ui.refresh_calls, 1)
        self.assertEqual(app._ui_mode, UIMode.SELECTION)
        self.assertEqual(app._sync_focus_calls, 1)
        self.assertEqual(app._invalidate_calls, 1)

    def test_slash_skills_confirm_prefills_input(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="Skill Creator",
                        description="Create or update a skill",
                        disable_model_invocation=False,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("")
        assert selection_ui.on_confirm is not None
        selection_ui.on_confirm("Skill Creator")

        self.assertEqual(app._prefill_text, "Skill Creator")
        self.assertGreaterEqual(app._refresh_calls, 1)

    def test_active_session_skills_fills_empty_description(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="skill-a",
                        description="",
                        disable_model_invocation=False,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        active = app._active_session_skills()

        self.assertEqual(
            active,
            [{"name": "skill-a", "description": "(No description)"}],
        )


if __name__ == "__main__":
    unittest.main()
