from __future__ import annotations

import asyncio
import unittest
from collections import deque
from contextlib import contextmanager
from typing import Any
from unittest.mock import patch

from comate_cli.terminal_agent.tui import TerminalAgentTUI


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str | None]] = []
        self.closed = False

    def append_system_message(self, text: str, severity: str | None = None) -> None:
        self.messages.append((text, severity))

    def close(self) -> None:
        self.closed = True


class _FakeApp:
    def __init__(self, *, run_sleep_s: float) -> None:
        self._run_sleep_s = run_sleep_s

    async def run_async(self) -> None:
        await asyncio.sleep(self._run_sleep_s)


@contextmanager
def _noop_patch_stdout(*args: Any, **kwargs: Any):
    del args, kwargs
    yield


class TestTUIMcpInitGate(unittest.IsolatedAsyncioTestCase):
    async def test_run_releases_initializing_after_mcp_init_timeout(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._app = _FakeApp(run_sleep_s=0.2)
        tui._renderer = _FakeRenderer()
        tui._refresh_layers = lambda: None
        tui._initializing = False
        tui._busy = False
        tui._closing = False
        tui._queued_messages = deque(["queued-message"])
        tui._mcp_init_gate_timeout_s = 0.05
        tui._mcp_init_cancel_timeout_s = 0.05
        tui._mcp_init_task = None
        tui._ui_tick_task = None

        # Provide a minimal status bar stub for show_transient()
        class _FakeStatusBar:
            def __init__(self) -> None:
                self.transient_calls: list[tuple[str, float]] = []
            def show_transient(self, msg: str, duration_s: float = 5.0,
                               severity: str = "info") -> None:
                self.transient_calls.append((msg, duration_s))
            def clear_transient_if_expired(self) -> bool:
                return False
            @property
            def has_transient(self) -> bool:
                return False
            @property
            def transient_severity(self) -> str:
                return "info"

        fake_status_bar = _FakeStatusBar()
        tui._status_bar = fake_status_bar

        submitted: list[str] = []

        async def _fake_submit_user_message(
            text: str,
            *,
            display_text: str | None = None,
        ) -> None:
            del display_text
            submitted.append(text)

        tui._submit_user_message = _fake_submit_user_message
        tui._schedule_background = lambda coro: asyncio.create_task(coro)

        async def _fake_ui_tick() -> None:
            await asyncio.Event().wait()

        tui._ui_tick = _fake_ui_tick

        async def _stuck_mcp_init() -> None:
            await asyncio.Event().wait()

        with patch("comate_cli.terminal_agent.tui.patch_stdout", _noop_patch_stdout):
            await tui.run(mcp_init=_stuck_mcp_init)

        self.assertFalse(tui._initializing)
        self.assertEqual(submitted, ["queued-message"])
        self.assertEqual(list(tui._queued_messages), [])
        self.assertTrue(tui._renderer.closed)
        self.assertEqual(tui._renderer.messages, [])
        self.assertEqual(len(fake_status_bar.transient_calls), 1)
        self.assertIn("timed out", fake_status_bar.transient_calls[0][0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
