from __future__ import annotations

import unittest

from comate_cli.terminal_agent.question_view import AskUserQuestionUI
from comate_cli.terminal_agent.tui_parts.key_bindings import KeyBindingsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _StubSelectionUI:
    def confirm(self):  # noqa: ANN201
        return None

    def move_selection(self, _delta: int) -> None:
        return None

    def cancel(self):  # noqa: ANN201
        return None


class _StubRunController:
    def interrupt(self, reason: str) -> None:  # noqa: ARG002
        return None


class _StubSession:
    def __init__(self) -> None:
        self.run_controller = _StubRunController()

    def request_exit(self) -> None:
        return None


class _StubRenderer:
    def __init__(self) -> None:
        self.active_todos = True
        self.todo_lines = [
            "Tasks",
            "◼ task-1",
            "▢ task-2",
            "▢ task-3",
            "▢ task-4",
            "▢ task-5",
            "▢ task-6",
            "▢ task-7",
            "▢ task-8",
        ]

    def has_active_todos(self) -> bool:
        return self.active_todos

    def append_system_message(self, *_args, **_kwargs) -> None:
        return None

    def todo_all_lines(self) -> list[str]:
        return list(self.todo_lines)


class _StubMentionCompleter:
    def extract_context(self, _text: str):  # noqa: ANN201
        return None


class _StubTaskPanelHost(KeyBindingsMixin):
    def __init__(self) -> None:
        self._ui_mode = UIMode.NORMAL
        self._question_ui = AskUserQuestionUI()
        self._question_ui.set_questions(
            [
                {
                    "question": "Q",
                    "header": "H",
                    "options": [{"label": "A", "description": ""}],
                    "multiSelect": False,
                }
            ]
        )
        self._selection_ui = _StubSelectionUI()
        self._mention_completer = _StubMentionCompleter()
        self._queued_messages = []
        self._busy = False
        self._initializing = False
        self._app = None
        self._stream_task = None
        self._interrupt_requested_at = None
        self._interrupt_force_window_seconds = 1.5
        self._session = _StubSession()
        self._renderer = _StubRenderer()
        self._waiting_for_input = False
        self._pending_questions = None
        self._esc_press_count = 0
        self._esc_last_pressed_at = 0.0
        self._esc_clear_window_seconds = 1.0
        self._ctrl_c_press_count = 0
        self._ctrl_c_last_pressed_at = 0.0
        self._ctrl_c_exit_window_seconds = 1.0
        self._input_area = type("InputArea", (), {"window": None})()
        self._diff_panel_visible = False
        self._diff_panel_scroll = 0
        self._todo_panel_expanded = False
        self._todo_panel_scroll = 0
        self._todo_panel_expanded_max_lines = 8
        self.invalidate_count = 0
        self._show_thinking = True

    def _handle_selection_result(self, *_args, **_kwargs) -> None:
        return None

    def _invalidate(self) -> None:
        self.invalidate_count += 1

    def _sync_focus_for_mode(self) -> None:
        return None

    def _handle_question_action(self, *_args, **_kwargs) -> None:
        return None

    def _submit_from_input(self) -> None:
        return None

    def _cycle_agent_mode(self) -> None:
        return None

    def _move_completion_selection(self, *_args, **_kwargs) -> bool:
        return False

    def _move_cursor_visual(self, *_args, **_kwargs) -> bool:
        return False

    def _should_handle_history(self) -> bool:
        return False

    def _clear_input_area(self, **_kw: object) -> None:
        return None

    def _set_busy(self, *_args, **_kwargs) -> None:
        return None

    def _exit_question_mode(self) -> None:
        return None

    def _refresh_layers(self) -> None:
        return None

    def _request_exit(self) -> None:
        return None


def _is_named_key(binding, name: str) -> bool:
    if len(binding.keys) != 1:
        return False
    key_name = str(binding.keys[0]).lower()
    normalized = name.lower().replace("-", "")
    if normalized.startswith("c") and len(normalized) == 2:
        return key_name.endswith(f"control{normalized[1]}")
    return key_name.endswith(normalized)


def _find_bindings(host: _StubTaskPanelHost, key_name: str):
    bindings = host._build_key_bindings().bindings
    return [binding for binding in bindings if _is_named_key(binding, key_name)]


class TestTaskPanelKeyBindings(unittest.TestCase):
    def test_ctrl_y_toggles_task_panel_expansion(self) -> None:
        host = _StubTaskPanelHost()
        bindings = _find_bindings(host, "c-y")
        self.assertEqual(len(bindings), 1)
        binding = bindings[0]

        self.assertFalse(host._todo_panel_expanded)
        binding.handler(None)
        self.assertTrue(host._todo_panel_expanded)
        binding.handler(None)
        self.assertFalse(host._todo_panel_expanded)
        self.assertGreaterEqual(host.invalidate_count, 2)

    def test_expanded_task_panel_down_key_scrolls(self) -> None:
        host = _StubTaskPanelHost()
        host._todo_panel_expanded = True
        bindings = _find_bindings(host, "down")
        active_bindings = [binding for binding in bindings if binding.filter()]

        self.assertEqual(len(active_bindings), 1)
        binding = active_bindings[0]

        self.assertTrue(binding.filter())
        binding.handler(None)

        self.assertEqual(host._todo_panel_scroll, 1)
        self.assertGreaterEqual(host.invalidate_count, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
