from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal

from comate_cli.terminal_agent.slash_commands import SlashCommandSpec


SlashCommandSource = Literal["builtin", "custom"]


@dataclass(frozen=True, slots=True)
class RegisteredSlashCommand:
    spec: SlashCommandSpec
    handler: Callable[[str], Any]
    allow_when_busy: bool = False
    source: SlashCommandSource = "builtin"
    argument_hint: str | None = None


class SlashCommandRegistry:
    def __init__(self) -> None:
        self._entries_by_name: dict[str, RegisteredSlashCommand] = {}
        self._entries_by_spec_name: dict[str, RegisteredSlashCommand] = {}

    def register(
        self,
        *,
        spec: SlashCommandSpec,
        handler: Callable[[str], Any],
        allow_when_busy: bool = False,
        source: SlashCommandSource = "builtin",
        argument_hint: str | None = None,
    ) -> None:
        entry = RegisteredSlashCommand(
            spec=spec,
            handler=handler,
            allow_when_busy=allow_when_busy,
            source=source,
            argument_hint=argument_hint,
        )
        names = (spec.name, *spec.aliases)
        for name in names:
            if name in self._entries_by_name:
                raise ValueError(f"Duplicate slash command registration: {name}")
        for name in names:
            self._entries_by_name[name] = entry
        self._entries_by_spec_name[spec.name] = entry

    def unregister(self, name: str) -> None:
        """Remove a registered command by name or alias.

        Removes the entry from both _entries_by_name (for all aliases) and
        _entries_by_spec_name. Silent no-op if name doesn't exist.
        """
        entry = self._entries_by_name.get(name)
        if entry is None:
            return
        # Remove all aliases pointing to this entry
        names_to_remove = [n for n, e in self._entries_by_name.items() if e is entry]
        for n in names_to_remove:
            del self._entries_by_name[n]
        self._entries_by_spec_name.pop(entry.spec.name, None)

    def resolve(self, name: str) -> RegisteredSlashCommand | None:
        return self._entries_by_name.get(name)

    def command_specs(self) -> tuple[SlashCommandSpec, ...]:
        return tuple(entry.spec for entry in self._entries_by_spec_name.values())
