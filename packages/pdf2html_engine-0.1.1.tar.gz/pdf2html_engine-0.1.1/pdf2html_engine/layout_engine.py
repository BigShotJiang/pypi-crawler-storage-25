import fitz
import re

class LayoutEngine:
    @staticmethod
    def _is_page_number(text):
        """Identifies common page number patterns."""
        if not text: return False
        text = text.strip()
        # Patterns like: "1", "1 / 10", "Page 1", "第 1 页", "- 1 -", "1 of 10"
        patterns = [
            r"^\d+$",
            r"^\d+\s*/\s*\d+$",
            r"^\d+\s+of\s+\d+$",
            r"^Page\s*\d+$",
            r"^第\s*\d+\s*页$",
            r"^-?\s*\d+\s*-?$",
            r"^第\s*\d+\s*页\s*，\s*共\s*\d+\s*页$"
        ]
        for p in patterns:
            if re.match(p, text, re.IGNORECASE):
                return True
        return False

    @staticmethod
    def extract_layout(fitz_page, table_bboxes):
        """
        Extracts layout by merging text and drawings into stable visual lines with dynamic font sizes.
        Uses padding-left for precise horizontal positioning.
        """
        page_width = fitz_page.rect.width
        page_height = fitz_page.rect.height
        header_threshold = page_height * 0.08
        footer_threshold = page_height * 0.92
        all_fragments = []

        # 1. Collect text spans with detailed styles using rawdict for character-level precision
        text_dict = fitz_page.get_text("rawdict", flags=fitz.TEXT_PRESERVE_WHITESPACE)
        for b in text_dict["blocks"]:
            if b["type"] != 0: continue
            if LayoutEngine._is_inside_table(b["bbox"], table_bboxes): continue
            
            # Skip blocks in header/footer area (potential page numbers, headers, footers)
            # More aggressive filtering for page numbers
            if b["bbox"][1] < header_threshold or b["bbox"][3] > footer_threshold:
                # Extra check: if it looks like a page number, we definitely skip it
                # In rawdict, spans don't have "text", they have "chars"
                block_text = "".join([c["c"] for l in b["lines"] for s in l["spans"] for c in s.get("chars", [])]).strip()
                if LayoutEngine._is_page_number(block_text):
                    continue
                # If it's very close to top/bottom, we skip it anyway to be safe
                if b["bbox"][1] < page_height * 0.05 or b["bbox"][3] > page_height * 0.95:
                    continue

            for line in b["lines"]:
                for span in line["spans"]:
                    if not span["chars"]: continue
                    
                    # 增强的加粗识别逻辑
                    font_name = span["font"].lower()
                    is_bold = bool(
                        (span["flags"] & 2**4) or 
                        "bold" in font_name or 
                        "semibold" in font_name or 
                        "medium" in font_name or
                        "heavy" in font_name or
                        "-w6" in font_name or
                        "-w7" in font_name
                    )
                    
                    current_f = None
                    for char in span["chars"]:
                        c = char["c"]
                        c_bbox = char["bbox"]
                        
                        if current_f is None:
                            current_f = {
                                "x0": c_bbox[0], "y0": c_bbox[1], "x1": c_bbox[2], "y1": c_bbox[3],
                                "text": c if c != " " else "",
                                "size": span["size"], "bold": is_bold, "is_drawing": False
                            }
                        else:
                            gap = c_bbox[0] - current_f["x1"]
                            if gap > span["size"] * 0.15 or c == " ":
                                if current_f["text"].strip():
                                    all_fragments.append(current_f)
                                current_f = {
                                    "x0": c_bbox[0], "y0": c_bbox[1], "x1": c_bbox[2], "y1": c_bbox[3],
                                    "text": c if c != " " else "",
                                    "size": span["size"], "bold": is_bold, "is_drawing": False
                                }
                            else:
                                current_f["text"] += c
                                current_f["x1"] = c_bbox[2]
                                current_f["y0"] = min(current_f["y0"], c_bbox[1])
                                current_f["y1"] = max(current_f["y1"], c_bbox[3])
                    
                    if current_f and current_f["text"].strip():
                        all_fragments.append(current_f)

        # 2. Collect drawings (underscores)
        drawings = []
        for p in fitz_page.get_drawings():
            for item in p["items"]:
                r = None
                if item[0] == "l":
                    p0, p1 = item[1], item[2]
                    # Check if it's a horizontal line
                    if abs(p1.y - p0.y) < 3 and abs(p1.x - p0.x) > 5:
                        r = fitz.Rect(min(p0.x, p1.x), p0.y - 1, max(p0.x, p1.x), p0.y + 1)
                elif item[0] == "re":
                    # Check if it's a thin rectangle (horizontal line)
                    if item[1].height < 3 and item[1].width > 5:
                        r = item[1]
                
                if r and not LayoutEngine._is_inside_table(r, table_bboxes):
                    # Skip drawings in header/footer area
                    if r.y0 < header_threshold or r.y1 > footer_threshold:
                        continue
                    drawings.append(r)

        # 2.1 Associate drawings with text to detect underlines
        for f in all_fragments:
            f["underlined"] = False
            f_rect = fitz.Rect(f["x0"], f["y0"], f["x1"], f["y1"])
            for r in drawings:
                # Vertical check: drawing is near the bottom of the text
                # Horizontal check: significant overlap
                if abs(r.y0 - f["y1"]) < 4 or (f["y0"] < r.y0 < f["y1"] + 2):
                    overlap_x0 = max(f["x0"], r.x0)
                    overlap_x1 = min(f["x1"], r.x1)
                    if (overlap_x1 - overlap_x0) > (f["x1"] - f["x0"]) * 0.6:
                        f["underlined"] = True
                        break

        # 2.2 Add remaining drawing parts as underscore placeholders
        for r in drawings:
            # Find all text fragments that this drawing underlines
            overlapping_text_ranges = []
            for f in all_fragments:
                if abs(r.y0 - f["y1"]) < 4 or (f["y0"] < r.y0 < f["y1"] + 2):
                    overlap_x0 = max(f["x0"], r.x0)
                    overlap_x1 = min(f["x1"], r.x1)
                    if overlap_x1 > overlap_x0:
                        overlapping_text_ranges.append((overlap_x0, overlap_x1))
            
            # If no significant overlap, add as underscores
            if not overlapping_text_ranges:
                width_chars = min(16, max(1, int(r.width / 6)))
                all_fragments.append({
                    "x0": r.x0, "y0": r.y0, "x1": r.x1, "y1": r.y1,
                    "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                })
            else:
                # If there is overlap, we only add underscores for the "trailing" part 
                # or parts that don't cover text.
                overlapping_text_ranges.sort()
                current_x = r.x0
                for tx0, tx1 in overlapping_text_ranges:
                    if tx0 > current_x + 5:
                        # Gap before text
                        width_chars = max(1, int((tx0 - current_x) / 6))
                        all_fragments.append({
                            "x0": current_x, "y0": r.y0, "x1": tx0, "y1": r.y1,
                            "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                        })
                    current_x = max(current_x, tx1)
                
                if r.x1 > current_x + 5:
                    # Trailing line
                    width_chars = max(1, int((r.x1 - current_x) / 6))
                    all_fragments.append({
                        "x0": current_x, "y0": r.y0, "x1": r.x1, "y1": r.y1,
                        "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                    })

        if not all_fragments: return []

        # 3. Group fragments into lines
        all_fragments.sort(key=lambda s: ((s["y0"] + s["y1"])/2, s["x0"]))
        lines = []
        if all_fragments:
            current_line = [all_fragments[0]]
            for i in range(1, len(all_fragments)):
                prev = all_fragments[i-1]
                curr = all_fragments[i]
                prev_mid = (prev["y0"] + prev["y1"]) / 2
                curr_mid = (curr["y0"] + curr["y1"]) / 2
                # 动态阈值：取碎片高度的 60% 与 8px 的较大值，以容纳大字号标题下的下划线
                threshold = max(8, max(prev["y1"]-prev["y0"], curr["y1"]-curr["y0"]) * 0.6)
                if abs(curr_mid - prev_mid) < threshold:
                    current_line.append(curr)
                else:
                    lines.append(current_line)
                    current_line = [curr]
            lines.append(current_line)

        # 4. Convert lines to HTML
        elements = []
        prev_line_y1 = None
        
        for line in lines:
            line.sort(key=lambda s: s["x0"])
            
            # 分析整行属性
            max_size = max(s["size"] for s in line)
            line_text_plain = "".join(s["text"] for s in line).strip()
            line_x0 = line[0]["x0"]
            line_y0 = line[0]["y0"]
            line_width = line[-1]["x1"] - line[0]["x0"]
            
            # 计算加粗比例 (排除下划线等绘图元素的影响)
            text_only_fragments = [s for s in line if s["text"].strip() and not s.get("is_drawing", False)]
            bold_fragments = [s for s in text_only_fragments if s["bold"]]
            is_mostly_bold = len(text_only_fragments) > 0 and (len(bold_fragments) / len(text_only_fragments)) >= 0.8
            
            # 对齐判断
            left_margin = line_x0
            right_margin = page_width - line[-1]["x1"]
            is_centered = abs(left_margin - right_margin) < 15 and line_width < page_width * 0.8
            
            # 决定标签类型
            tag = "p"
            is_heading_style = is_mostly_bold or (max_size >= 14 and is_centered)
            
            if is_heading_style and 0 < len(line_text_plain) < 60:
                if max_size >= 16: tag = "h1"
                elif max_size >= 14: tag = "h2"
                elif max_size >= 12: tag = "h3"
                elif max_size >= 10.5: tag = "h4"
                else: tag = "h5"
            
            # 生成 HTML 内容
            line_html = ""
            current_x = line_x0

            # --- 优化：合并片段以提升可编辑性 ---
            merged_fragments = []
            if line:
                temp_f = line[0].copy()
                if temp_f.get("is_drawing"):
                    # 将线条还原为下划线字符，使其可搜索、可编辑
                    temp_f["text"] = "_" * max(1, int((temp_f["x1"] - temp_f["x0"]) / 6))

                for next_f in line[1:]:
                    gap = next_f["x0"] - temp_f["x1"]
                    # 如果间距极小且样式一致，则合并为连续字符串
                    if gap < 2.0 and next_f.get("bold") == temp_f.get("bold") and not next_f.get("is_drawing") and not temp_f.get("is_drawing"):
                        temp_f["text"] += next_f["text"]
                        temp_f["x1"] = next_f["x1"]
                    else:
                        merged_fragments.append(temp_f)
                        temp_f = next_f.copy()
                        if temp_f.get("is_drawing"):
                            temp_f["text"] = "_" * max(1, int((temp_f["x1"] - temp_f["x0"]) / 6))
                merged_fragments.append(temp_f)

            for f in merged_fragments:
                gap = f["x0"] - current_x
                if gap > 2.0:
                    if gap > 15: # 只有大间距（如列间距）才使用 span 定位
                        line_html += f'<span style="display:inline-block; width:{gap/page_width*100:.2f}%"></span>'
                    else:
                        line_html += " " * max(1, int(gap / 3.5))

                txt = f["text"]
                if f.get("underlined"):
                    txt = f"<u>{txt}</u>"

                if tag == "p" and f.get("bold"):
                    line_html += f"<strong>{txt}</strong>"
                else:
                    line_html += txt
                current_x = f["x1"]
            
            # 计算样式
            margin_top = 0
            if prev_line_y1 is not None:
                dist = line_y0 - prev_line_y1
                if dist > 5: margin_top = min(40, int(dist * 0.8))
            
            style_parts = [
                f"font-size: {max_size:.1f}pt",
                f"margin-top: {margin_top}px",
                "white-space: pre-wrap",
                "word-break: break-word"
            ]
            
            if is_centered:
                style_parts.append("text-align: center")
            else:
                indent = (line_x0 / page_width) * 100
                if indent > 1.0:
                    style_parts.append(f"margin-left: {indent:.2f}%")

            if tag.startswith("h"):
                style_parts.append("font-weight: bold")
                style_parts.append("margin: 0.8em 0")

            elements.append({
                "type": "text",
                "html": f'<{tag} style="{"; ".join(style_parts)}">{line_html}</{tag}>',
                "y0": line_y0
            })
            prev_line_y1 = max(s["y1"] for s in line)

        return elements

    @staticmethod
    def _is_inside_table(bbox, table_bboxes):
        r = fitz.Rect(bbox)
        for tb in table_bboxes:
            if r.intersects(fitz.Rect(tb)):
                return True
        return False
