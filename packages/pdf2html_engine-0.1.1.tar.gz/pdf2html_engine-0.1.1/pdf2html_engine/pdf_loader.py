import fitz
import pdfplumber
import io
import os

class PDFLoader:
    def __init__(self, pdf_path):
        self.pdf_path = pdf_path
        self.fitz_doc = None
        self.plumber_pdf = None
        self._temp_stream = None

    def __enter__(self):
        # 1. 首先用 fitz 打开原始文件
        temp_doc = fitz.open(self.pdf_path)
        
        # 2. 导出修复后的标准 PDF 流 (解决 Unexpected EOF 并统一结构)
        # clean=True 会重构 xref 表，彻底移除已删除的页面或无效对象
        pdf_bytes = temp_doc.tobytes(clean=True, deflate=True)
        temp_doc.close()
        
        self._temp_stream = io.BytesIO(pdf_bytes)
        
        # 3. 双引擎同时加载这个【唯一的、修复后的】流
        self.fitz_doc = fitz.open(stream=self._temp_stream, filetype="pdf")
        self.plumber_pdf = pdfplumber.open(self._temp_stream)
        
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.plumber_pdf:
            self.plumber_pdf.close()
        if self.fitz_doc:
            self.fitz_doc.close()
        if self._temp_stream:
            self._temp_stream.close()

    def __len__(self):
        return len(self.fitz_doc) if self.fitz_doc else 0

    def get_pages(self, indices=None):
        """返回同步的 (fitz_page, plumber_page, index)"""
        if indices is None:
            indices = range(len(self))
        for i in indices:
            if 0 <= i < len(self.fitz_doc):
                yield self.fitz_doc[i], self.plumber_pdf.pages[i], i
