"""AEGIS gate decorator for Python functions.

Usage:
    from aegis import aegis_gate

    @aegis_gate(proposal_summary="Deploy auth service", estimated_impact="high")
    def deploy():
        ...

    # Raises HaltError if AEGIS returns HALT.
    # Passes through silently on PROCEED/PAUSE/ESCALATE.
"""

from __future__ import annotations

import inspect
from functools import wraps
from typing import Any, Callable, TypeVar

from aegis._client import Aegis
from aegis._errors import HaltError

F = TypeVar("F", bound=Callable[..., Any])


def aegis_gate(
    proposal_summary: str = "",
    estimated_impact: str = "medium",
    fail_on_halt: bool = True,
    **gate_kwargs: Any,
) -> Callable[[F], F]:
    """Decorator that evaluates an AEGIS gate before function execution.

    The decorated function only executes if the gate does not return HALT
    (or if ``fail_on_halt=False``).

    Args:
        proposal_summary: Description of what this function does. Falls back
            to the function's docstring or name if empty.
        estimated_impact: Blast radius — "low", "medium", "high", "critical".
        fail_on_halt: If True (default), raises ``HaltError`` on HALT decisions.
            If False, the function executes regardless of the gate result.
        **gate_kwargs: Additional keyword arguments passed to ``Aegis.evaluate()``
            (e.g., ``risk_proposed=0.15``, ``complexity_score=0.8``).

    Returns:
        Decorated function that runs AEGIS evaluation before execution.

    Raises:
        HaltError: If the gate returns HALT and ``fail_on_halt=True``.
    """

    def decorator(fn: F) -> F:
        if inspect.iscoroutinefunction(fn):
            from aegis._async_client import AsyncAegis

            @wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                summary = proposal_summary or fn.__doc__ or fn.__name__
                async with AsyncAegis() as client:
                    decision = await client.evaluate(
                        proposal_summary=summary,
                        estimated_impact=estimated_impact,
                        **gate_kwargs,
                    )
                if decision.status == "halt" and fail_on_halt:
                    raise HaltError(decision)
                return await fn(*args, **kwargs)

            return async_wrapper  # type: ignore[return-value]

        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            summary = proposal_summary or fn.__doc__ or fn.__name__
            with Aegis() as client:
                decision = client.evaluate(
                    proposal_summary=summary,
                    estimated_impact=estimated_impact,
                    **gate_kwargs,
                )
            if decision.status == "halt" and fail_on_halt:
                raise HaltError(decision)
            return fn(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
