"""Sandbox mode constants and shared logic."""

from __future__ import annotations

import sys
import threading

SANDBOX_PATH = "/sandbox/evaluate"
SANDBOX_NOTICE = (
    "AEGIS Sandbox Mode: 10 free evaluations/day, no signup required.\n"
    "For production use (100/month free): https://portal.undercurrentholdings.com"
)

_notice_lock = threading.Lock()
_notice_shown = False


def print_sandbox_notice() -> None:
    """Print sandbox notice to stderr (once per process)."""
    global _notice_shown  # noqa: PLW0603
    if _notice_shown:
        return
    with _notice_lock:
        if _notice_shown:
            return
        print(SANDBOX_NOTICE, file=sys.stderr)
        _notice_shown = True


def _reset_notice() -> None:
    """Reset notice state (for testing only)."""
    global _notice_shown  # noqa: PLW0603
    with _notice_lock:
        _notice_shown = False
