"""AEGIS SDK error types.

Error hierarchy modeled after Stripe/OpenAI SDKs:
- AegisError (base)
  - AuthenticationError (401/403)
  - ValidationError (400)
  - RateLimitError (429)
  - ServerError (5xx)
  - ConnectionError (network)
  - TimeoutError (timeout)
"""

from __future__ import annotations


class AegisError(Exception):
    """Base exception for all AEGIS SDK errors.

    Attributes:
        message: Human-readable error description (never contains API key).
        status_code: HTTP status code (if from API response).
        request_id: Server-assigned request ID for debugging.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        super().__init__(message)

    def __repr__(self) -> str:
        parts = [f"{self.__class__.__name__}({self.message!r}"]
        if self.status_code is not None:
            parts.append(f", status_code={self.status_code}")
        if self.request_id is not None:
            parts.append(f", request_id={self.request_id!r}")
        parts.append(")")
        return "".join(parts)


class AuthenticationError(AegisError):
    """API key is missing, invalid, or lacks permission (HTTP 401/403)."""


class ValidationError(AegisError):
    """Request payload failed validation (HTTP 400)."""


class RateLimitError(AegisError):
    """Rate limit exceeded (HTTP 429).

    Attributes:
        retry_after: Seconds to wait before retrying (from Retry-After header).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 429,
        request_id: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, request_id=request_id)
        self.retry_after = retry_after


class SandboxLimitError(AegisError):
    """Sandbox evaluation limit reached — sign up for a free API key.

    Attributes:
        limit: Maximum evaluations per day in sandbox mode.
        upgrade_url: Portal URL to get an API key.
    """

    def __init__(
        self,
        message: str = "",
        *,
        limit: int = 10,
        upgrade_url: str = "https://portal.undercurrentholdings.com",
    ) -> None:
        super().__init__(
            message
            or (
                f"Sandbox limit reached ({limit} evaluations/day). "
                f"Get a free API key at {upgrade_url} for 100/month."
            ),
            status_code=429,
        )
        self.limit = limit
        self.upgrade_url = upgrade_url


class ServerError(AegisError):
    """Server-side error (HTTP 5xx)."""


class ConnectionError(
    AegisError
):  # noqa: A001 — shadows builtin intentionally (Stripe pattern)
    """Network connection failed."""


class TimeoutError(
    AegisError
):  # noqa: A001 — shadows builtin intentionally (OpenAI pattern)
    """Request timed out."""


class HaltError(AegisError):
    """AEGIS gate evaluation returned HALT — proposal was rejected.

    Raised by the ``@aegis_gate`` decorator when ``fail_on_halt=True``
    and the evaluation returns a HALT decision.

    Attributes:
        decision: The full Decision object from the evaluation.
    """

    def __init__(self, decision: object) -> None:
        self.decision = decision
        rationale = getattr(decision, "rationale", "Gate evaluation returned HALT")
        super().__init__(
            f"AEGIS HALT: {rationale}",
            status_code=None,
        )


# ── Attestation errors (Sprint 4 / D1) ───────────────────────────────


class AttestationCollisionError(AegisError):
    """Decision-id collision with a foreign customer (HTTP 409 from POST /attest).

    The same ``decision_id`` already exists for a DIFFERENT ``customer_id``.
    Same-customer replays return 200 with the existing record (idempotent).
    """


class AttestationNotFoundError(AegisError):
    """Attestation not found (HTTP 404 from GET /attestations/{decision_id}).

    Returned for both (a) decision_id does not exist and (b) decision_id exists
    but belongs to a different customer. Single response shape eliminates the
    tenant-discovery side channel.
    """


class AttestationProviderUnavailableError(AegisError):
    """Server-side attestation provider unavailable (HTTP 503).

    Issued when the AEGIS attestation key material failed to load at server
    startup, or signing failed mid-request. Retryable; safe to back off.
    """


class AttestationSchemaDriftError(AegisError):
    """Persisted attestation no longer matches the current predicate schema (HTTP 410).

    Indicates a post-migration drift where a stored ``predicate_json`` row
    fails Pydantic re-validation. Operator action required; not retryable.
    """
