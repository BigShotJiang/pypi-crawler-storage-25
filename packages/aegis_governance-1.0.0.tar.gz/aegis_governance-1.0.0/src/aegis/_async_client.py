"""AEGIS SDK asynchronous client.

Usage:
    from aegis import AsyncAegis

    async with AsyncAegis() as client:  # sandbox mode — works immediately
        decision = await client.evaluate(proposal_summary="Add caching layer")
        print(decision.status)
"""

from __future__ import annotations

import os
from typing import Any

from aegis._attestations import AsyncAttestationClient
from aegis._errors import RateLimitError, SandboxLimitError, ValidationError
from aegis._http import AsyncHttpTransport, _mask_key
from aegis.types import (
    ApiKey,
    CustomerProfile,
    Decision,
    HealthStatus,
    RiskCheckResult,
    UsageReport,
)

_NORMALIZED_FIELDS = (
    "risk_baseline",
    "risk_proposed",
    "novelty_score",
    "complexity_score",
    "quality_score",
)


class AsyncAegis:
    """Asynchronous client for the AEGIS Governance API.

    When no API key is provided, operates in **sandbox mode** — 10 free
    evaluations per day, no signup required.

    Args:
        api_key: Unkey API key (``uk_live_...``). Falls back to ``AEGIS_API_KEY`` env var.
            Omit for sandbox mode.
        base_url: API base URL. Falls back to ``AEGIS_BASE_URL`` env var, then production default.
        timeout: Request timeout in seconds (default 30).
        max_retries: Max retry attempts for transient failures (default 2).
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        resolved_key = api_key or os.environ.get("AEGIS_API_KEY", "")
        self._sandbox = not resolved_key
        self._api_key = resolved_key

        import httpx as _httpx

        self._transport = AsyncHttpTransport(
            api_key=resolved_key,
            base_url=base_url,
            timeout=_httpx.Timeout(timeout),
            max_retries=max_retries,
        )
        self._attestations: AsyncAttestationClient | None = None

    @property
    def attestations(self) -> AsyncAttestationClient:
        """Async attestation operations (Sprint 4 / D1).

        Lazy-initialized on first access; reuses the parent client's
        ``AsyncHttpTransport``. See
        :class:`aegis._attestations.AsyncAttestationClient`.

        Sandbox mode (no API key) raises ``ValidationError`` on every method
        call — attestations require authentication.
        """
        if self._attestations is None:
            self._attestations = AsyncAttestationClient(
                self._transport, is_sandbox=self._sandbox
            )
        return self._attestations

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> AsyncAegis:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def __repr__(self) -> str:
        if self._sandbox:
            return "AsyncAegis(sandbox=True)"
        return f"AsyncAegis(api_key={_mask_key(self._api_key)!r})"

    # ── Core evaluation ──────────────────────────────────────────────

    async def evaluate(
        self,
        *,
        proposal_summary: str,
        estimated_impact: str = "medium",
        risk_baseline: float = 0.02,
        risk_proposed: float = 0.05,
        profit_baseline: float = 0.98,
        profit_proposed: float = 0.98,
        novelty_score: float = 0.75,
        complexity_score: float = 0.8,
        quality_score: float = 0.85,
        quality_subscores: list[float] | None = None,
        agent_id: str | None = None,
        session_id: str | None = None,
        phase: str | None = None,
        change_type: str | None = None,
        shadow_mode: bool = False,
        idempotency_key: str | None = None,
        **extra: Any,
    ) -> Decision:
        """Evaluate an engineering proposal through 6 governance gates."""
        if not proposal_summary or not proposal_summary.strip():
            raise ValidationError("proposal_summary is required and cannot be empty")
        if len(proposal_summary) > 10_000:
            raise ValidationError("proposal_summary exceeds 10,000 character limit")

        body: dict[str, Any] = {
            "proposal_summary": proposal_summary.strip(),
            "estimated_impact": estimated_impact,
            "risk_baseline": risk_baseline,
            "risk_proposed": risk_proposed,
            "profit_baseline": profit_baseline,
            "profit_proposed": profit_proposed,
            "novelty_score": novelty_score,
            "complexity_score": complexity_score,
            "quality_score": quality_score,
        }

        for field_name in _NORMALIZED_FIELDS:
            val = body.get(field_name)
            if val is not None:
                if isinstance(val, bool):
                    raise ValidationError(f"{field_name} must be numeric, not bool")
                if not (0.0 <= float(val) <= 1.0):
                    raise ValidationError(
                        f"{field_name} must be between 0.0 and 1.0, got {val}"
                    )

        if quality_subscores is not None:
            body["quality_subscores"] = quality_subscores
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if phase is not None:
            body["phase"] = phase
        if change_type is not None:
            body["change_type"] = change_type
        if shadow_mode:
            body["shadow_mode"] = True
        body.update(extra)

        if self._sandbox:
            return await self._evaluate_sandbox(body)

        response = await self._transport.request(
            "POST",
            "/evaluate",
            json_body=body,
            idempotent=True,
            idempotency_key=idempotency_key,
        )
        data = response.json()
        request_id = response.headers.get("X-AEGIS-Request-Id")
        return Decision.from_response(data, request_id=request_id)

    async def _evaluate_sandbox(self, body: dict[str, Any]) -> Decision:
        """Evaluate via the unauthenticated sandbox endpoint."""
        from aegis._sandbox import SANDBOX_PATH, print_sandbox_notice

        print_sandbox_notice()
        try:
            response = await self._transport.request(
                "POST", SANDBOX_PATH, json_body=body
            )
        except RateLimitError:
            raise SandboxLimitError() from None

        data = response.json()
        request_id = response.headers.get("X-AEGIS-Request-Id")
        return Decision.from_response(data, request_id=request_id)

    async def risk_check(
        self,
        *,
        risk_score: float,
        threshold: float = 0.3,
        action_description: str = "",
        agent_id: str | None = None,
    ) -> RiskCheckResult:
        """Quick risk threshold check."""
        if not (0.0 <= risk_score <= 1.0):
            raise ValidationError(
                f"risk_score must be between 0.0 and 1.0, got {risk_score}"
            )
        if not (0.0 <= threshold <= 1.0):
            raise ValidationError(
                f"threshold must be between 0.0 and 1.0, got {threshold}"
            )

        body: dict[str, Any] = {
            "risk_score": risk_score,
            "threshold": threshold,
            "action_description": action_description,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id

        response = await self._transport.request("POST", "/risk-check", json_body=body)
        data = response.json()
        request_id = response.headers.get("X-AEGIS-Request-Id")
        return RiskCheckResult.from_response(data, request_id=request_id)

    async def health(self) -> HealthStatus:
        """Check API health status."""
        response = await self._transport.request("GET", "/health")
        return HealthStatus.from_response(response.json())

    # ── Customer management ──────────────────────────────────────────

    async def get_profile(self) -> CustomerProfile:
        response = await self._transport.request("GET", "/customer/profile")
        request_id = response.headers.get("X-AEGIS-Request-Id")
        return CustomerProfile.from_response(response.json(), request_id=request_id)

    async def get_usage(self, month: str | None = None) -> UsageReport:
        if month is not None:
            import re

            if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", month):
                raise ValidationError(f"month must be in YYYY-MM format, got {month!r}")
        path = f"/customer/usage/{month}" if month else "/customer/usage"
        response = await self._transport.request("GET", path)
        request_id = response.headers.get("X-AEGIS-Request-Id")
        return UsageReport.from_response(response.json(), request_id=request_id)

    async def list_keys(self) -> list[ApiKey]:
        response = await self._transport.request("GET", "/customer/keys")
        data = response.json()
        keys_list = data.get("keys", [])
        return [
            ApiKey(
                key_id=str(k.get("key_id", "")),
                name=str(k.get("name", "")),
                created_at=k.get("created_at"),
                enabled=k.get("enabled"),
            )
            for k in keys_list
        ]

    async def create_key(self, name: str) -> ApiKey:
        if not name or not name.strip():
            raise ValidationError("Key name is required")
        response = await self._transport.request(
            "POST", "/customer/keys", json_body={"name": name.strip()}, idempotent=True
        )
        data = response.json()
        return ApiKey(
            key_id=str(data.get("key_id", "")),
            name=str(data.get("name", name)),
            key=data.get("key"),
        )

    async def revoke_key(self, key_id: str) -> None:
        if not key_id:
            raise ValidationError("key_id is required")
        await self._transport.request(
            "DELETE", f"/customer/keys/{key_id}", idempotent=True
        )

    async def list_decisions(
        self, *, month: str | None = None, limit: int = 50
    ) -> list[Decision]:
        import re

        params: dict[str, Any] = {"limit": limit}
        if month is not None:
            if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", month):
                raise ValidationError(f"month must be in YYYY-MM format, got {month!r}")
            params["month"] = month
        response = await self._transport.request(
            "GET", "/customer/decisions", params=params
        )
        data = response.json()
        request_id = response.headers.get("X-AEGIS-Request-Id")
        decisions = data.get("decisions", [])
        return [Decision.from_response(d, request_id=request_id) for d in decisions]

    async def get_decision(self, decision_id: str) -> Decision:
        if not decision_id:
            raise ValidationError("decision_id is required")
        response = await self._transport.request(
            "GET", f"/customer/decisions/{decision_id}"
        )
        request_id = response.headers.get("X-AEGIS-Request-Id")
        data = response.json()
        decision_data = data.get("decision", data)
        return Decision.from_response(decision_data, request_id=request_id)
