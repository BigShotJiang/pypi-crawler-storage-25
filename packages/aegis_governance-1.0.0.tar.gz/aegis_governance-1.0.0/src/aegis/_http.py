"""AEGIS SDK HTTP transport layer.

Security-hardened HTTP client wrapping httpx:
- TLS always enforced (no verify=False)
- API key only in Authorization header (never URL/body)
- Automatic retry with exponential backoff + jitter
- Idempotency keys on mutating requests
- Key masking in all repr/error output
- Granular timeouts (connect/read/write/pool)
"""

from __future__ import annotations

import contextlib
import os
import platform
import random
import sys
import time
import uuid
from typing import Any

import httpx

from aegis._errors import (
    AegisError,
    AuthenticationError,
    ConnectionError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from aegis._version import __version__

_RETRYABLE_STATUS_CODES: set[int] = {429, 500, 502, 503, 504}
_MAX_RETRY_DELAY: float = 60.0

_DEFAULT_TIMEOUT = httpx.Timeout(
    connect=5.0,
    read=30.0,
    write=5.0,
    pool=10.0,
)

_PRODUCTION_BASE_URL = "https://api.aegis.undercurrentholdings.com"


def _build_user_agent() -> str:
    """Build User-Agent string: aegis-python/0.1.0 python/3.12 darwin/arm64."""
    py_version = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    os_name = platform.system().lower()
    arch = platform.machine().lower()
    return f"aegis-python/{__version__} python/{py_version} {os_name}/{arch}"


def _mask_key(api_key: str) -> str:
    """Mask API key for safe display: uk_live_...ab12."""
    if len(api_key) > 8:
        return f"{api_key[:7]}...{api_key[-4:]}"
    return "***"


def _validate_base_url(url: str) -> str:
    """Enforce HTTPS unless targeting localhost for development."""
    url = url.rstrip("/")
    if url.startswith("https://"):
        return url
    if url.startswith("http://"):
        from urllib.parse import urlparse

        parsed = urlparse(url)
        host = parsed.hostname or ""
        if host in ("localhost", "127.0.0.1", "0.0.0.0", "::1"):
            return url
        raise AegisError(
            f"Insecure base URL rejected: {url}. "
            "AEGIS SDK requires HTTPS for all non-localhost connections."
        )
    raise AegisError(f"Invalid base URL scheme: {url}. Must start with https://")


class HttpTransport:
    """Secure HTTP transport for the AEGIS API.

    Args:
        api_key: Unkey Bearer token.
        base_url: API base URL (must be HTTPS except localhost).
        timeout: Request timeout configuration.
        max_retries: Maximum retry attempts for transient failures.
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str | None = None,
        timeout: httpx.Timeout | None = None,
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = _validate_base_url(
            base_url or os.environ.get("AEGIS_BASE_URL", "") or _PRODUCTION_BASE_URL
        )
        self._max_retries = max(0, max_retries)
        self._user_agent = _build_user_agent()

        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout or _DEFAULT_TIMEOUT,
            verify=True,  # TLS always enforced — no opt-out
            http2=True,
            headers={
                "User-Agent": self._user_agent,
                "X-AEGIS-Client": "python-sdk",
                "X-AEGIS-Client-Version": __version__,
            },
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        idempotent: bool = False,
        idempotency_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Execute an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, DELETE, PATCH).
            path: API path (e.g., "/evaluate").
            json_body: JSON request body.
            idempotent: Whether to attach an idempotency key.
            idempotency_key: Custom idempotency key (overrides auto-generated UUID).
            params: Query parameters (URL-encoded by httpx).

        Returns:
            httpx.Response on success.

        Raises:
            AegisError subclass on failure.
        """
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        elif idempotent:
            headers["Idempotency-Key"] = str(uuid.uuid4())

        last_error: Exception | None = None

        for attempt in range(1 + self._max_retries):
            try:
                response = self._client.request(
                    method,
                    path,
                    headers=headers,
                    json=json_body,
                    params=params,
                )

                if response.status_code < 400:
                    return response

                if (
                    response.status_code in _RETRYABLE_STATUS_CODES
                    and attempt < self._max_retries
                ):
                    delay = self._retry_delay(attempt, response)
                    time.sleep(delay)
                    continue

                self._raise_for_status(response)

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._max_retries:
                    time.sleep(self._retry_delay(attempt))
                    continue
                raise TimeoutError(
                    f"Request timed out after {attempt + 1} attempt(s)",
                ) from e

            except httpx.ConnectError as e:
                last_error = e
                if attempt < self._max_retries:
                    time.sleep(self._retry_delay(attempt))
                    continue
                raise ConnectionError(
                    f"Failed to connect to AEGIS API at {self._base_url}",
                ) from e

        # Should not reach here, but fail-safe
        raise AegisError(
            f"Request failed after {self._max_retries + 1} attempts"
        ) from last_error

    def _retry_delay(
        self, attempt: int, response: httpx.Response | None = None
    ) -> float:
        """Calculate retry delay with exponential backoff + jitter."""
        base = min(0.5 * (2**attempt), _MAX_RETRY_DELAY)
        jitter = random.random() * 0.5  # noqa: S311 — not cryptographic
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    return max(base, float(retry_after))
                except ValueError:
                    pass
        return base + jitter

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Convert HTTP error responses to typed exceptions."""
        request_id = response.headers.get("X-AEGIS-Request-Id")

        try:
            body = response.json()
            message = body.get("error", body.get("message", response.text))
        except Exception:
            message = response.text or f"HTTP {response.status_code}"

        if isinstance(message, dict):
            message = str(message)

        kwargs = {"status_code": response.status_code, "request_id": request_id}

        if response.status_code in (401, 403):
            raise AuthenticationError(str(message), **kwargs)
        elif response.status_code == 400:
            raise ValidationError(str(message), **kwargs)
        elif response.status_code == 429:
            retry_after_raw = response.headers.get("Retry-After")
            retry_after = None
            if retry_after_raw:
                with contextlib.suppress(ValueError):
                    retry_after = float(retry_after_raw)
            raise RateLimitError(
                str(message), request_id=request_id, retry_after=retry_after
            )
        elif response.status_code >= 500:
            raise ServerError(str(message), **kwargs)
        else:
            raise AegisError(str(message), **kwargs)

    def __repr__(self) -> str:
        return (
            f"HttpTransport(base_url={self._base_url!r}, "
            f"api_key={_mask_key(self._api_key)!r})"
        )


class AsyncHttpTransport:
    """Async HTTP transport for the AEGIS API.

    Same security properties as HttpTransport, using httpx.AsyncClient.
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str | None = None,
        timeout: httpx.Timeout | None = None,
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = _validate_base_url(
            base_url or os.environ.get("AEGIS_BASE_URL", "") or _PRODUCTION_BASE_URL
        )
        self._max_retries = max(0, max_retries)
        self._user_agent = _build_user_agent()

        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=timeout or _DEFAULT_TIMEOUT,
            verify=True,
            http2=True,
            headers={
                "User-Agent": self._user_agent,
                "X-AEGIS-Client": "python-sdk",
                "X-AEGIS-Client-Version": __version__,
            },
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        idempotent: bool = False,
        idempotency_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Async HTTP request with retry logic."""
        import asyncio

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        elif idempotent:
            headers["Idempotency-Key"] = str(uuid.uuid4())

        last_error: Exception | None = None

        for attempt in range(1 + self._max_retries):
            try:
                response = await self._client.request(
                    method,
                    path,
                    headers=headers,
                    json=json_body,
                    params=params,
                )

                if response.status_code < 400:
                    return response

                if (
                    response.status_code in _RETRYABLE_STATUS_CODES
                    and attempt < self._max_retries
                ):
                    delay = self._retry_delay(attempt, response)
                    await asyncio.sleep(delay)
                    continue

                self._raise_for_status(response)

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._max_retries:
                    await asyncio.sleep(self._retry_delay(attempt))
                    continue
                raise TimeoutError(
                    f"Request timed out after {attempt + 1} attempt(s)",
                ) from e

            except httpx.ConnectError as e:
                last_error = e
                if attempt < self._max_retries:
                    await asyncio.sleep(self._retry_delay(attempt))
                    continue
                raise ConnectionError(
                    f"Failed to connect to AEGIS API at {self._base_url}",
                ) from e

        raise AegisError(
            f"Request failed after {self._max_retries + 1} attempts"
        ) from last_error

    def _retry_delay(
        self, attempt: int, response: httpx.Response | None = None
    ) -> float:
        base = min(0.5 * (2**attempt), _MAX_RETRY_DELAY)
        jitter = random.random() * 0.5  # noqa: S311
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    return max(base, float(retry_after))
                except ValueError:
                    pass
        return base + jitter

    def _raise_for_status(self, response: httpx.Response) -> None:
        request_id = response.headers.get("X-AEGIS-Request-Id")
        try:
            body = response.json()
            message = body.get("error", body.get("message", response.text))
        except Exception:
            message = response.text or f"HTTP {response.status_code}"

        if isinstance(message, dict):
            message = str(message)

        kwargs = {"status_code": response.status_code, "request_id": request_id}

        if response.status_code in (401, 403):
            raise AuthenticationError(str(message), **kwargs)
        elif response.status_code == 400:
            raise ValidationError(str(message), **kwargs)
        elif response.status_code == 429:
            retry_after_raw = response.headers.get("Retry-After")
            retry_after = None
            if retry_after_raw:
                with contextlib.suppress(ValueError):
                    retry_after = float(retry_after_raw)
            raise RateLimitError(
                str(message), request_id=request_id, retry_after=retry_after
            )
        elif response.status_code >= 500:
            raise ServerError(str(message), **kwargs)
        else:
            raise AegisError(str(message), **kwargs)

    def __repr__(self) -> str:
        return (
            f"AsyncHttpTransport(base_url={self._base_url!r}, "
            f"api_key={_mask_key(self._api_key)!r})"
        )
