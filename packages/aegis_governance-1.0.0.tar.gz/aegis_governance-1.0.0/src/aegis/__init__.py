"""AEGIS Python SDK — quantitative AI governance, no signup required.

Usage:
    from aegis import Aegis

    client = Aegis()  # Works immediately — 10 free evaluations/day
    decision = client.evaluate(
        proposal_summary="Add Redis caching layer",
        estimated_impact="medium",
        risk_baseline=0.02,
        risk_proposed=0.05,
    )
    print(decision.status)  # "proceed"

Offline attestation verification (Sprint 4 / D2 — opt-in via [verify] extra)::

    from aegis import verify_attestation_locally, AttestationVerifyKey

    keys = AttestationVerifyKey(ed25519_public=..., mldsa65_public=...)
    valid, error_class = verify_attestation_locally(
        envelope=envelope,
        expected_digest="<sha256 hex>",
        expected_environment="production",
        keys=keys,
    )

Full documentation: https://aegis.undercurrentholdings.com
Production API keys: https://portal.undercurrentholdings.com
"""

from typing import Any

from aegis._async_client import AsyncAegis
from aegis._attestations import AsyncAttestationClient, AttestationClient
from aegis._client import Aegis
from aegis._decorators import aegis_gate
from aegis._errors import (
    AegisError,
    AttestationCollisionError,
    AttestationNotFoundError,
    AttestationProviderUnavailableError,
    AttestationSchemaDriftError,
    AuthenticationError,
    ConnectionError,
    HaltError,
    RateLimitError,
    SandboxLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from aegis._version import __version__
from aegis.types import (
    AEGISPredicate,
    ApiKey,
    AttestationGovernance,
    AttestationRecord,
    AttestationResult,
    AttestationVerifyResult,
    BuildDefinition,
    CustomerProfile,
    Decision,
    DriftResult,
    DSSEEnvelope,
    DSSESignature,
    GateResult,
    Gates,
    HealthStatus,
    InTotoStatement,
    ResourceDescriptor,
    RiskCheckResult,
    RunDetails,
    TierDetails,
    UsageReport,
)

__all__ = [
    # Clients
    "Aegis",
    "AsyncAegis",
    # Sub-clients
    "AttestationClient",
    "AsyncAttestationClient",
    # Decorator
    "aegis_gate",
    # Types
    "ApiKey",
    "CustomerProfile",
    "Decision",
    "DriftResult",
    "GateResult",
    "Gates",
    "HealthStatus",
    "RiskCheckResult",
    "TierDetails",
    "UsageReport",
    # Attestation types (Sprint 4 / D1)
    "AEGISPredicate",
    "AttestationGovernance",
    "AttestationRecord",
    "AttestationResult",
    "AttestationVerifyResult",
    "BuildDefinition",
    "DSSEEnvelope",
    "DSSESignature",
    "InTotoStatement",
    "ResourceDescriptor",
    "RunDetails",
    # Errors
    "AegisError",
    "AuthenticationError",
    "ConnectionError",
    "HaltError",
    "RateLimitError",
    "SandboxLimitError",
    "ServerError",
    "TimeoutError",
    "ValidationError",
    # Attestation errors (Sprint 4 / D1)
    "AttestationCollisionError",
    "AttestationNotFoundError",
    "AttestationProviderUnavailableError",
    "AttestationSchemaDriftError",
    # Metadata
    "__version__",
]


# ── Conditional [verify] extra (Sprint 4 / D2 + audit) ─────────────────────
#
# The offline verifier requires `cryptography`, `liboqs-python`, and `rfc8785`,
# which we don't want to force on HTTP-only consumers of the base SDK.
#
# Strategy (post-audit fix for F6+F7): probe at module-load whether the extra
# is installed. If yes, eagerly import the symbols and add them to __all__
# (so `from aegis import *` works correctly). If no, leave __all__ unchanged
# and define `__getattr__` to raise AttributeError with an install-hint when
# someone accesses the verify symbols.
#
# Why AttributeError (not ImportError) on `__getattr__` miss: PEP 8 / Python 3.2+
# `hasattr(module, name)` only swallows AttributeError, not ImportError. Raising
# ImportError from __getattr__ would break `hasattr(aegis, "verify_attestation_locally")`
# for HTTP-only consumers — they'd get an unhandled ImportError instead of False.
# The install hint is embedded in the AttributeError message.

try:
    from aegis._verify_local import (  # noqa: F401
        AttestationVerifyKey,
        verify_attestation_locally,
    )

    _HAS_VERIFY_EXTRA = True
    __all__ = __all__ + ["AttestationVerifyKey", "verify_attestation_locally"]
except ImportError:
    _HAS_VERIFY_EXTRA = False


_VERIFY_EXTRA_NAMES = frozenset({"verify_attestation_locally", "AttestationVerifyKey"})


def __getattr__(name: str) -> Any:
    if name in _VERIFY_EXTRA_NAMES and not _HAS_VERIFY_EXTRA:
        raise AttributeError(
            f"module 'aegis' has no attribute {name!r}. "
            f"This requires the 'verify' extra. "
            f"Install with: pip install aegis-governance[verify]\n"
            f"This pulls in: cryptography, liboqs-python, rfc8785."
        )
    raise AttributeError(f"module 'aegis' has no attribute {name!r}")
