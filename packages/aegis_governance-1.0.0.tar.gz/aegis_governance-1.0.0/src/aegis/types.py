"""AEGIS SDK response types.

Typed dataclasses mirroring the AEGIS API response shapes.
All fields are deserialized from JSON — no engine logic here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class GateResult:
    """Result of a single governance gate evaluation."""

    passed: bool
    value: float
    threshold: float
    confidence: float
    message: str


@dataclass(frozen=True)
class Gates:
    """All six governance gate results."""

    risk: GateResult | None = None
    profit: GateResult | None = None
    novelty: GateResult | None = None
    complexity: GateResult | None = None
    quality: GateResult | None = None
    utility: GateResult | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Gates:
        """Deserialize from API response dict."""
        gates: dict[str, GateResult | None] = {}
        for name in ("risk", "profit", "novelty", "complexity", "quality", "utility"):
            raw = data.get(name)
            if raw and isinstance(raw, dict):
                gates[name] = GateResult(
                    passed=bool(raw.get("passed", False)),
                    value=float(raw["value"]) if raw.get("value") is not None else 0.0,
                    threshold=(
                        float(raw["threshold"]) if raw.get("threshold") is not None else 0.0
                    ),
                    confidence=(
                        float(raw["confidence"]) if raw.get("confidence") is not None else 0.0
                    ),
                    message=str(raw.get("message", "")),
                )
            else:
                gates[name] = None
        return cls(**gates)


@dataclass(frozen=True)
class DriftResult:
    """KL divergence drift detection result."""

    status: str  # normal | warning | critical
    kl_divergence: float
    action: str
    message: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DriftResult:
        return cls(
            status=str(data.get("status", "normal")),
            kl_divergence=(
                float(data["kl_divergence"]) if data.get("kl_divergence") is not None else 0.0
            ),
            action=str(data.get("action", "")),
            message=str(data.get("message", "")),
        )


@dataclass(frozen=True)
class Decision:
    """Governance decision returned by the AEGIS evaluation engine."""

    status: str  # proceed | pause | halt | escalate
    confidence: float
    gates_passed: int
    gates_failed: int
    failing_gates: list[str]
    rationale: str
    next_steps: list[str]
    constraints: list[str]
    decision_id: str
    timestamp: str
    override_eligible: bool
    override_requires: list[str]
    gates: Gates | None = None
    drift: DriftResult | None = None
    request_id: str | None = None
    sandbox: bool = False
    remaining: int | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str | None = None) -> Decision:
        """Deserialize from API response JSON."""
        gates_raw = data.get("gates")
        drift_raw = data.get("drift")
        return cls(
            status=str(data.get("status", "halt")),
            confidence=(float(data["confidence"]) if data.get("confidence") is not None else 0.0),
            gates_passed=int(data.get("gates_passed", 0)),
            gates_failed=int(data.get("gates_failed", 0)),
            failing_gates=list(data.get("failing_gates", [])),
            rationale=str(data.get("rationale", "")),
            next_steps=list(data.get("next_steps", [])),
            constraints=list(data.get("constraints", [])),
            decision_id=str(data.get("decision_id", "")),
            timestamp=str(data.get("timestamp", "")),
            override_eligible=bool(data.get("override_eligible", False)),
            override_requires=list(data.get("override_requires", [])),
            gates=(
                Gates.from_dict(gates_raw) if gates_raw and isinstance(gates_raw, dict) else None
            ),
            drift=(
                DriftResult.from_dict(drift_raw)
                if drift_raw and isinstance(drift_raw, dict)
                else None
            ),
            request_id=request_id,
            sandbox=bool(data.get("sandbox", False)),
            remaining=(int(data["remaining"]) if data.get("remaining") is not None else None),
        )


@dataclass(frozen=True)
class RiskCheckResult:
    """Quick risk check result."""

    safe: bool
    risk_score: float
    threshold: float
    rationale: str | None = None
    request_id: str | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str | None = None) -> RiskCheckResult:
        return cls(
            safe=bool(data.get("safe", False)),
            risk_score=float(data.get("risk_score", 0.0)),
            threshold=float(data.get("threshold", 0.0)),
            rationale=data.get("rationale"),
            request_id=request_id,
        )


@dataclass(frozen=True)
class HealthStatus:
    """API health check response."""

    status: str  # ok | degraded
    version: str
    stage: str
    checks: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> HealthStatus:
        return cls(
            status=str(data.get("status", "unknown")),
            version=str(data.get("version", "")),
            stage=str(data.get("stage", "")),
            checks=dict(data.get("checks", {})),
        )


@dataclass(frozen=True)
class TierDetails:
    """Customer tier details."""

    name: str
    display_name: str
    monthly_evaluations: int
    rate_per_minute: int
    max_keys: int
    overage_per_eval: float
    monthly_price_usd: int
    features: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CustomerProfile:
    """Customer profile from the management API."""

    customer_id: str
    name: str
    email: str
    company: str
    tier: str
    status: str
    created_at: str
    updated_at: str
    tier_details: TierDetails | None = None
    request_id: str | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str | None = None) -> CustomerProfile:
        customer = data.get("customer", data)
        tier_raw = data.get("tier_details")
        tier_details = None
        if tier_raw and isinstance(tier_raw, dict):
            tier_details = TierDetails(
                name=str(tier_raw.get("name", "")),
                display_name=str(tier_raw.get("display_name", "")),
                monthly_evaluations=int(tier_raw.get("monthly_evaluations", 0)),
                rate_per_minute=int(tier_raw.get("rate_per_minute", 0)),
                max_keys=int(tier_raw.get("max_keys", 0)),
                overage_per_eval=float(tier_raw.get("overage_per_eval", 0.0)),
                monthly_price_usd=int(tier_raw.get("monthly_price_usd", 0)),
                features=list(tier_raw.get("features", [])),
            )
        return cls(
            customer_id=str(customer.get("customer_id", "")),
            name=str(customer.get("name", "")),
            email=str(customer.get("email", "")),
            company=str(customer.get("company", "")),
            tier=str(customer.get("tier", "")),
            status=str(customer.get("status", "")),
            created_at=str(customer.get("created_at", "")),
            updated_at=str(customer.get("updated_at", "")),
            tier_details=tier_details,
            request_id=request_id,
        )


@dataclass(frozen=True)
class UsageReport:
    """Monthly usage report."""

    customer_id: str
    month: str
    total_evaluations: int
    total_risk_checks: int
    total_calls: int
    channels: dict[str, int]
    quota: int
    quota_remaining: int
    quota_percent: float
    request_id: str | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str | None = None) -> UsageReport:
        return cls(
            customer_id=str(data.get("customer_id", "")),
            month=str(data.get("month", "")),
            total_evaluations=int(data.get("total_evaluations", 0)),
            total_risk_checks=int(data.get("total_risk_checks", 0)),
            total_calls=int(data.get("total_calls", 0)),
            channels=dict(data.get("channels", {})),
            quota=int(data.get("quota", 0)),
            quota_remaining=int(data.get("quota_remaining", 0)),
            quota_percent=float(data.get("quota_percent", 0)),
            request_id=request_id,
        )


@dataclass(frozen=True)
class ApiKey:
    """API key info."""

    key_id: str
    name: str
    key: str | None = None  # Only present on creation
    created_at: float | None = None
    enabled: bool | None = None
    request_id: str | None = None


# ── Attestation types (Sprint 4 / D1) ─────────────────────────────────
#
# Hand-mirrored from aegis-governance/src/aegis_governance/attestation_models.py
# Pydantic v2 source-of-truth. NOT imported — that would force Pydantic +
# rfc8785 + cryptography + liboqs onto every SDK consumer. Server-side Pydantic
# is the canonical validator; SDK is happy-path-with-fail-fast.
#
# Wire format follows in-toto Statement v1 + DSSE v1 with camelCase aliases for
# spec-compliance (`_type`, `predicateType`, `payloadType`, `buildDefinition`,
# `runDetails`, `externalParameters`, etc.). Aliases are translated in
# `to_dict()` / `from_response()` — Python identifiers stay snake_case.


@dataclass(frozen=True)
class ResourceDescriptor:
    """in-toto Statement v1 subject descriptor."""

    digest: dict[str, str]
    name: str | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> ResourceDescriptor:
        return cls(
            digest=dict(data.get("digest") or {}),
            name=data.get("name"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"digest": dict(self.digest)}
        if self.name is not None:
            out["name"] = self.name
        return out


@dataclass(frozen=True)
class BuildDefinition:
    """SLSA v1.0 BuildDefinition shape inside the predicate."""

    build_type: str
    external_parameters: dict[str, Any]
    internal_parameters: dict[str, Any] | None = None
    resolved_dependencies: list[dict[str, Any]] | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> BuildDefinition:
        return cls(
            build_type=str(data.get("buildType", "")),
            external_parameters=dict(data.get("externalParameters") or {}),
            internal_parameters=data.get("internalParameters"),
            resolved_dependencies=data.get("resolvedDependencies"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "buildType": self.build_type,
            "externalParameters": dict(self.external_parameters),
        }
        if self.internal_parameters is not None:
            out["internalParameters"] = dict(self.internal_parameters)
        if self.resolved_dependencies is not None:
            out["resolvedDependencies"] = list(self.resolved_dependencies)
        return out


@dataclass(frozen=True)
class RunDetails:
    """SLSA v1.0 RunDetails shape inside the predicate."""

    builder: dict[str, Any]
    metadata: dict[str, Any] | None = None
    byproducts: list[dict[str, Any]] | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> RunDetails:
        return cls(
            builder=dict(data.get("builder") or {}),
            metadata=data.get("metadata"),
            byproducts=data.get("byproducts"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"builder": dict(self.builder)}
        if self.metadata is not None:
            out["metadata"] = dict(self.metadata)
        if self.byproducts is not None:
            out["byproducts"] = list(self.byproducts)
        return out


@dataclass(frozen=True)
class AttestationGovernance:
    """AEGIS governance namespace inside the predicate (13 required fields).

    `nonce` is required server-side when `risk_class` is "high" or "critical";
    SDK does not duplicate this validator (server returns 400 with error_class).
    """

    decision_id: str
    artifact_digest: str
    environment: str
    risk_class: str
    policy_version: str
    issued_at: str
    expires_at: str
    gate_pass_states: dict[str, str]
    repository: str
    workflow_ref: str
    run_id: str
    run_attempt: int
    nonce: str | None = None

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> AttestationGovernance:
        return cls(
            decision_id=str(data.get("decision_id", "")),
            artifact_digest=str(data.get("artifact_digest", "")),
            environment=str(data.get("environment", "")),
            risk_class=str(data.get("risk_class", "")),
            policy_version=str(data.get("policy_version", "")),
            issued_at=str(data.get("issued_at", "")),
            expires_at=str(data.get("expires_at", "")),
            gate_pass_states=dict(data.get("gate_pass_states") or {}),
            repository=str(data.get("repository", "")),
            workflow_ref=str(data.get("workflow_ref", "")),
            run_id=str(data.get("run_id", "")),
            run_attempt=int(data.get("run_attempt", 0)),
            nonce=data.get("nonce"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "decision_id": self.decision_id,
            "artifact_digest": self.artifact_digest,
            "environment": self.environment,
            "risk_class": self.risk_class,
            "policy_version": self.policy_version,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "gate_pass_states": dict(self.gate_pass_states),
            "repository": self.repository,
            "workflow_ref": self.workflow_ref,
            "run_id": self.run_id,
            "run_attempt": self.run_attempt,
        }
        if self.nonce is not None:
            out["nonce"] = self.nonce
        return out


@dataclass(frozen=True)
class AEGISPredicate:
    """AEGIS attestation predicate body (in-toto Statement.predicate)."""

    build_definition: BuildDefinition
    run_details: RunDetails
    governance: AttestationGovernance

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> AEGISPredicate:
        return cls(
            build_definition=BuildDefinition.from_response(data.get("buildDefinition", {})),
            run_details=RunDetails.from_response(data.get("runDetails", {})),
            governance=AttestationGovernance.from_response(data.get("governance", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "buildDefinition": self.build_definition.to_dict(),
            "runDetails": self.run_details.to_dict(),
            "governance": self.governance.to_dict(),
        }


@dataclass(frozen=True)
class InTotoStatement:
    """in-toto Statement v1 (the DSSE payload, base64-encoded canonical JSON)."""

    type_: str
    subject: list[ResourceDescriptor]
    predicate_type: str
    predicate: AEGISPredicate

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> InTotoStatement:
        return cls(
            type_=str(data.get("_type", "https://in-toto.io/Statement/v1")),
            subject=[ResourceDescriptor.from_response(s) for s in (data.get("subject") or [])],
            predicate_type=str(
                data.get(
                    "predicateType",
                    "https://aegis.undercurrentholdings.com/attestation/v1",
                )
            ),
            predicate=AEGISPredicate.from_response(data.get("predicate", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "_type": self.type_,
            "subject": [s.to_dict() for s in self.subject],
            "predicateType": self.predicate_type,
            "predicate": self.predicate.to_dict(),
        }


@dataclass(frozen=True)
class DSSESignature:
    """DSSE v1 signature entry (one of two: ed25519: or ml-dsa-65:)."""

    keyid: str
    sig: str

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> DSSESignature:
        return cls(
            keyid=str(data.get("keyid", "")),
            sig=str(data.get("sig", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        return {"keyid": self.keyid, "sig": self.sig}


@dataclass(frozen=True)
class DSSEEnvelope:
    """DSSE v1 envelope wrapping an in-toto Statement.

    AEGIS uses hybrid Ed25519 + ML-DSA-65 multi-sig (per ADR-011 §Decision);
    `signatures` ALWAYS contains exactly two entries, one per algorithm.
    """

    payload_type: str
    payload: str
    signatures: list[DSSESignature]

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> DSSEEnvelope:
        return cls(
            payload_type=str(data.get("payloadType", "application/vnd.in-toto+json")),
            payload=str(data.get("payload", "")),
            signatures=[DSSESignature.from_response(s) for s in (data.get("signatures") or [])],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "payloadType": self.payload_type,
            "payload": self.payload,
            "signatures": [s.to_dict() for s in self.signatures],
        }


@dataclass(frozen=True)
class AttestationResult:
    """Response from POST /attest.

    `idempotent_replayed` is derived from the X-AEGIS-Idempotent-Replayed
    response header; True when the server returned a cached record (HTTP 200)
    rather than issuing a fresh attestation (HTTP 201).
    """

    decision_id: str
    envelope: DSSEEnvelope
    statement_canonical_sha256: str
    issued_at: str
    expires_at: str
    request_id: str | None = None
    idempotent_replayed: bool = False

    @classmethod
    def from_response(
        cls,
        data: dict[str, Any],
        request_id: str | None = None,
        idempotent_replayed: bool = False,
    ) -> AttestationResult:
        return cls(
            decision_id=str(data.get("decision_id", "")),
            envelope=DSSEEnvelope.from_response(data.get("envelope", {})),
            statement_canonical_sha256=str(data.get("statement_canonical_sha256", "")),
            issued_at=str(data.get("issued_at", "")),
            expires_at=str(data.get("expires_at", "")),
            request_id=request_id,
            idempotent_replayed=idempotent_replayed,
        )


@dataclass(frozen=True)
class AttestationVerifyResult:
    """Response from POST /attestations/verify.

    HTTP 200 indicates "verification ran successfully" — the cryptographic
    outcome is in the ``valid`` field. Caller should check ``result.valid``;
    do NOT treat HTTP 200 alone as success. ``error_class`` holds the
    server-returned reason on ``valid=False`` (e.g. AttestationDigestMismatch,
    AttestationEnvironmentMismatch, AttestationExpired).
    """

    valid: bool
    verified_at: str
    error_class: str | None = None
    request_id: str | None = None

    @classmethod
    def from_response(
        cls, data: dict[str, Any], request_id: str | None = None
    ) -> AttestationVerifyResult:
        return cls(
            valid=bool(data.get("valid", False)),
            verified_at=str(data.get("verified_at", "")),
            error_class=data.get("error_class"),
            request_id=request_id,
        )


@dataclass(frozen=True)
class AttestationRecord:
    """Full persisted attestation returned by GET /attestations/{decision_id}.

    Includes the raw envelope, the parsed predicate, audit metadata, and the
    ``customer_id`` echoed for audit clarity (caller is already authenticated
    as this customer; no info leak).
    """

    decision_id: str
    envelope: DSSEEnvelope
    predicate: AEGISPredicate
    artifact_digest: str
    environment: str
    risk_class: str
    policy_version: str
    repository: str
    workflow_ref: str
    run_id: str
    run_attempt: int
    expires_at: str
    created_at: str
    customer_id: str
    request_id: str | None = None

    @classmethod
    def from_response(
        cls, data: dict[str, Any], request_id: str | None = None
    ) -> AttestationRecord:
        return cls(
            decision_id=str(data.get("decision_id", "")),
            envelope=DSSEEnvelope.from_response(data.get("envelope", {})),
            predicate=AEGISPredicate.from_response(data.get("predicate", {})),
            artifact_digest=str(data.get("artifact_digest", "")),
            environment=str(data.get("environment", "")),
            risk_class=str(data.get("risk_class", "")),
            policy_version=str(data.get("policy_version", "")),
            repository=str(data.get("repository", "")),
            workflow_ref=str(data.get("workflow_ref", "")),
            run_id=str(data.get("run_id", "")),
            run_attempt=int(data.get("run_attempt", 0)),
            expires_at=str(data.get("expires_at", "")),
            created_at=str(data.get("created_at", "")),
            customer_id=str(data.get("customer_id", "")),
            request_id=request_id,
        )
