"""AEGIS attestation client (Sprint 4 / D1).

Wraps three server-side endpoints:

- ``POST /attest`` — issue an artifact-bound attestation
- ``POST /attestations/verify`` — server-side reference verifier (HTTP 200
  always when verification ran; cryptographic outcome lives in ``valid`` field)
- ``GET /attestations/{decision_id}`` — tenant-isolated retrieve

Pure HTTP — NO crypto. Offline envelope verification is Sprint 4 / D2 and
ships in the ``aegis[verify]`` extra (cryptography + liboqs-python + rfc8785).

Usage::

    from aegis import Aegis

    client = Aegis(api_key="uk_live_...")
    result = client.attestations.attest(
        decision_id="...",
        subject_digest_sha256="...",
        environment="production",
        risk_class="medium",
        policy_version="1.2.0",
        repository="undercurrentai/foo",
        workflow_ref=".github/workflows/aegis-deploy.yml@refs/heads/main",
        run_id="123",
        run_attempt=1,
        gate_pass_states={"risk": "pass", "profit": "pass", "novelty": "pass",
                          "complexity": "pass", "quality": "pass", "utility": "pass"},
        builder_id="https://github.com/undercurrentai/foo/actions",
        expires_at="2026-05-10T12:00:00+00:00",
    )

    verify = client.attestations.verify(
        envelope=result.envelope,
        expected_digest="<hex64>",
        expected_environment="production",
    )

    record = client.attestations.get(decision_id="...")
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from aegis._errors import (
    AegisError,
    AttestationCollisionError,
    AttestationNotFoundError,
    AttestationProviderUnavailableError,
    AttestationSchemaDriftError,
    ValidationError,
)
from aegis.types import (
    AttestationRecord,
    AttestationResult,
    AttestationVerifyResult,
    DSSEEnvelope,
)

if TYPE_CHECKING:
    from aegis._http import AsyncHttpTransport, HttpTransport


_UUID36_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")

_ENVIRONMENTS: tuple[str, ...] = ("production", "staging", "preview")
_RISK_CLASSES: tuple[str, ...] = ("low", "medium", "high", "critical")


def _validate_uuid36(decision_id: str) -> None:
    if not _UUID36_RE.match(decision_id):
        raise ValidationError(
            f"decision_id must be a 36-char UUID (8-4-4-4-12 hex), got {decision_id!r}"
        )


def _validate_sha256_hex(digest: str, field_name: str) -> None:
    if not _HEX64_RE.match(digest):
        raise ValidationError(
            f"{field_name} must be 64 lowercase hex chars (sha256), got {digest!r}"
        )


def _validate_literal(value: str, allowed: tuple[str, ...], field_name: str) -> None:
    if value not in allowed:
        raise ValidationError(f"{field_name} must be one of {allowed}, got {value!r}")


def _build_attest_body(
    *,
    decision_id: str,
    subject_digest_sha256: str,
    environment: str,
    risk_class: str,
    policy_version: str,
    repository: str,
    workflow_ref: str,
    run_id: str,
    run_attempt: int,
    gate_pass_states: dict[str, str],
    builder_id: str,
    expires_at: str,
    subject_name: str | None,
    external_parameters: dict[str, Any] | None,
    build_type: str | None,
) -> dict[str, Any]:
    """Construct the POST /attest request body. Validation already performed."""
    body: dict[str, Any] = {
        "decision_id": decision_id,
        "subject_digest_sha256": subject_digest_sha256,
        "environment": environment,
        "risk_class": risk_class,
        "policy_version": policy_version,
        "repository": repository,
        "workflow_ref": workflow_ref,
        "run_id": run_id,
        "run_attempt": run_attempt,
        "gate_pass_states": dict(gate_pass_states),
        "builder_id": builder_id,
        "expires_at": expires_at,
        "external_parameters": (
            dict(external_parameters) if external_parameters is not None else {}
        ),
    }
    if subject_name is not None:
        body["subject_name"] = subject_name
    if build_type is not None:
        body["build_type"] = build_type
    return body


def _idempotent_replayed_from_headers(headers: Any) -> bool:
    """Read X-AEGIS-Idempotent-Replayed: true from response headers."""
    value = headers.get("X-AEGIS-Idempotent-Replayed")
    return isinstance(value, str) and value.strip().lower() == "true"


def _map_attest_error(exc: AegisError) -> AegisError:
    """Map generic AegisError from POST /attest to typed attestation exceptions.

    409 → AttestationCollisionError (cross-customer decision_id collision)
    422 → ValidationError (Idempotency-Key body mismatch)
    503 → AttestationProviderUnavailableError (server crypto unavailable)
    All other status codes propagate unchanged.
    """
    if exc.status_code == 409:
        return AttestationCollisionError(exc.message, status_code=409, request_id=exc.request_id)
    if exc.status_code == 422:
        return ValidationError(exc.message, status_code=422, request_id=exc.request_id)
    if exc.status_code == 503:
        return AttestationProviderUnavailableError(
            exc.message, status_code=503, request_id=exc.request_id
        )
    return exc


def _map_verify_error(exc: AegisError) -> AegisError:
    """Map generic AegisError from POST /attestations/verify to typed exceptions.

    503 → AttestationProviderUnavailableError. Cryptographic invalidity does
    NOT raise — server returns HTTP 200 with valid=False.
    """
    if exc.status_code == 503:
        return AttestationProviderUnavailableError(
            exc.message, status_code=503, request_id=exc.request_id
        )
    return exc


def _map_get_error(exc: AegisError) -> AegisError:
    """Map generic AegisError from GET /attestations/{decision_id}.

    404 → AttestationNotFoundError (absent OR cross-customer; same shape per
          tenant-isolation invariant)
    410 → AttestationSchemaDriftError (post-migration predicate re-validation
          failed; not retryable)
    """
    if exc.status_code == 404:
        return AttestationNotFoundError(exc.message, status_code=404, request_id=exc.request_id)
    if exc.status_code == 410:
        return AttestationSchemaDriftError(exc.message, status_code=410, request_id=exc.request_id)
    return exc


# ── Sync client ──────────────────────────────────────────────────────


class AttestationClient:
    """Synchronous attestation operations.

    Constructed lazily via ``Aegis.attestations`` property; do NOT instantiate
    directly. Reuses the parent ``Aegis`` client's ``HttpTransport`` (Bearer
    auth, retry/backoff, idempotency-key handling).
    """

    def __init__(self, transport: HttpTransport, *, is_sandbox: bool = False) -> None:
        self._transport = transport
        self._is_sandbox = is_sandbox

    def _require_auth(self) -> None:
        if self._is_sandbox:
            raise ValidationError(
                "Attestations require an API key; sandbox mode does not "
                "support attestations. Get a free key at "
                "https://portal.undercurrentholdings.com"
            )

    def attest(
        self,
        *,
        decision_id: str,
        subject_digest_sha256: str,
        environment: str,
        risk_class: str,
        policy_version: str,
        repository: str,
        workflow_ref: str,
        run_id: str,
        run_attempt: int,
        gate_pass_states: dict[str, str],
        builder_id: str,
        expires_at: str,
        subject_name: str | None = None,
        external_parameters: dict[str, Any] | None = None,
        build_type: str | None = None,
        idempotency_key: str | None = None,
    ) -> AttestationResult:
        """Issue an artifact-bound AEGIS attestation (POST /attest).

        Returns 201 (new) or 200 (idempotent replay) on success;
        ``result.idempotent_replayed`` is True on cache hit.

        Raises:
            ValidationError: on client-side fail-fast or server 400/422
            AuthenticationError: on missing/invalid API key (401/403)
            AttestationCollisionError: on cross-customer decision_id collision (409)
            RateLimitError: on 429
            AttestationProviderUnavailableError: on server crypto unavailable (503)
            ServerError: on 5xx other than 503
        """
        self._require_auth()
        decision_id = decision_id.lower()  # RFC 4122 canonical form (server stores lowercase)
        _validate_uuid36(decision_id)
        _validate_sha256_hex(subject_digest_sha256, "subject_digest_sha256")
        _validate_literal(environment, _ENVIRONMENTS, "environment")
        _validate_literal(risk_class, _RISK_CLASSES, "risk_class")

        body = _build_attest_body(
            decision_id=decision_id,
            subject_digest_sha256=subject_digest_sha256,
            environment=environment,
            risk_class=risk_class,
            policy_version=policy_version,
            repository=repository,
            workflow_ref=workflow_ref,
            run_id=run_id,
            run_attempt=run_attempt,
            gate_pass_states=gate_pass_states,
            builder_id=builder_id,
            expires_at=expires_at,
            subject_name=subject_name,
            external_parameters=external_parameters,
            build_type=build_type,
        )

        try:
            response = self._transport.request(
                "POST",
                "/attest",
                json_body=body,
                idempotent=True,
                idempotency_key=idempotency_key,
            )
        except AegisError as e:
            raise _map_attest_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        idempotent_replayed = _idempotent_replayed_from_headers(response.headers)
        return AttestationResult.from_response(
            response.json(),
            request_id=request_id,
            idempotent_replayed=idempotent_replayed,
        )

    def verify(
        self,
        *,
        envelope: DSSEEnvelope,
        expected_digest: str,
        expected_environment: str,
    ) -> AttestationVerifyResult:
        """Server-side reference verification (POST /attestations/verify).

        HTTP 200 indicates "verification ran successfully" — the cryptographic
        outcome is in ``result.valid``. Caller MUST check ``result.valid``.

        Raises:
            ValidationError: on malformed envelope shape (server 400)
            AuthenticationError: on 401
            AttestationProviderUnavailableError: on 503
        """
        self._require_auth()
        _validate_sha256_hex(expected_digest, "expected_digest")
        _validate_literal(expected_environment, _ENVIRONMENTS, "expected_environment")

        body = {
            "envelope": envelope.to_dict(),
            "expected_digest": expected_digest,
            "expected_environment": expected_environment,
        }

        try:
            response = self._transport.request("POST", "/attestations/verify", json_body=body)
        except AegisError as e:
            raise _map_verify_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        return AttestationVerifyResult.from_response(response.json(), request_id=request_id)

    def get(self, decision_id: str) -> AttestationRecord:
        """Retrieve a persisted attestation (GET /attestations/{decision_id}).

        Tenant-isolated to the caller's customer_id. Cross-customer requests
        return 404 (same shape as not-found) to prevent tenant-discovery side
        channels.

        Raises:
            ValidationError: on malformed decision_id (client-side or server 400)
            AuthenticationError: on 401
            AttestationNotFoundError: on 404 (absent OR cross-customer)
            AttestationSchemaDriftError: on 410 (post-migration drift)
        """
        self._require_auth()
        decision_id = decision_id.lower()  # RFC 4122 canonical form (server stores lowercase)
        _validate_uuid36(decision_id)

        try:
            response = self._transport.request("GET", f"/attestations/{decision_id}")
        except AegisError as e:
            raise _map_get_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        return AttestationRecord.from_response(response.json(), request_id=request_id)


# ── Async client ─────────────────────────────────────────────────────


class AsyncAttestationClient:
    """Asynchronous attestation operations.

    Constructed lazily via ``AsyncAegis.attestations`` property; do NOT
    instantiate directly. Mirrors the sync ``AttestationClient`` API exactly
    with ``async def`` + ``await self._transport.request(...)``.
    """

    def __init__(self, transport: AsyncHttpTransport, *, is_sandbox: bool = False) -> None:
        self._transport = transport
        self._is_sandbox = is_sandbox

    def _require_auth(self) -> None:
        if self._is_sandbox:
            raise ValidationError(
                "Attestations require an API key; sandbox mode does not "
                "support attestations. Get a free key at "
                "https://portal.undercurrentholdings.com"
            )

    async def attest(
        self,
        *,
        decision_id: str,
        subject_digest_sha256: str,
        environment: str,
        risk_class: str,
        policy_version: str,
        repository: str,
        workflow_ref: str,
        run_id: str,
        run_attempt: int,
        gate_pass_states: dict[str, str],
        builder_id: str,
        expires_at: str,
        subject_name: str | None = None,
        external_parameters: dict[str, Any] | None = None,
        build_type: str | None = None,
        idempotency_key: str | None = None,
    ) -> AttestationResult:
        """Async POST /attest. See :meth:`AttestationClient.attest`."""
        self._require_auth()
        decision_id = decision_id.lower()  # RFC 4122 canonical form (server stores lowercase)
        _validate_uuid36(decision_id)
        _validate_sha256_hex(subject_digest_sha256, "subject_digest_sha256")
        _validate_literal(environment, _ENVIRONMENTS, "environment")
        _validate_literal(risk_class, _RISK_CLASSES, "risk_class")

        body = _build_attest_body(
            decision_id=decision_id,
            subject_digest_sha256=subject_digest_sha256,
            environment=environment,
            risk_class=risk_class,
            policy_version=policy_version,
            repository=repository,
            workflow_ref=workflow_ref,
            run_id=run_id,
            run_attempt=run_attempt,
            gate_pass_states=gate_pass_states,
            builder_id=builder_id,
            expires_at=expires_at,
            subject_name=subject_name,
            external_parameters=external_parameters,
            build_type=build_type,
        )

        try:
            response = await self._transport.request(
                "POST",
                "/attest",
                json_body=body,
                idempotent=True,
                idempotency_key=idempotency_key,
            )
        except AegisError as e:
            raise _map_attest_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        idempotent_replayed = _idempotent_replayed_from_headers(response.headers)
        return AttestationResult.from_response(
            response.json(),
            request_id=request_id,
            idempotent_replayed=idempotent_replayed,
        )

    async def verify(
        self,
        *,
        envelope: DSSEEnvelope,
        expected_digest: str,
        expected_environment: str,
    ) -> AttestationVerifyResult:
        """Async POST /attestations/verify. See :meth:`AttestationClient.verify`."""
        self._require_auth()
        _validate_sha256_hex(expected_digest, "expected_digest")
        _validate_literal(expected_environment, _ENVIRONMENTS, "expected_environment")

        body = {
            "envelope": envelope.to_dict(),
            "expected_digest": expected_digest,
            "expected_environment": expected_environment,
        }

        try:
            response = await self._transport.request("POST", "/attestations/verify", json_body=body)
        except AegisError as e:
            raise _map_verify_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        return AttestationVerifyResult.from_response(response.json(), request_id=request_id)

    async def get(self, decision_id: str) -> AttestationRecord:
        """Async GET /attestations/{decision_id}. See :meth:`AttestationClient.get`."""
        self._require_auth()
        decision_id = decision_id.lower()  # RFC 4122 canonical form (server stores lowercase)
        _validate_uuid36(decision_id)

        try:
            response = await self._transport.request("GET", f"/attestations/{decision_id}")
        except AegisError as e:
            raise _map_get_error(e) from e

        request_id = response.headers.get("X-AEGIS-Request-Id")
        return AttestationRecord.from_response(response.json(), request_id=request_id)
