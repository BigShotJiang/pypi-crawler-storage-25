"""Tests for AEGIS SDK sandbox mode."""

from __future__ import annotations

import os
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from aegis import Aegis, AsyncAegis
from aegis._errors import AegisError, SandboxLimitError
from aegis._sandbox import _reset_notice

# ── Mock transport ───────────────────────────────────────────────────


def _mock_handler(
    response_data: Any,
    status_code: int = 200,
    headers: dict[str, str] | None = None,
) -> httpx.MockTransport:
    resp_headers = {"X-AEGIS-Request-Id": "sandbox-test-123"}
    if headers:
        resp_headers.update(headers)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code,
            json=response_data,
            headers=resp_headers,
        )

    return httpx.MockTransport(handler)


def _sandbox_response() -> dict[str, Any]:
    return {
        "status": "proceed",
        "confidence": 0.87,
        "gates_passed": 6,
        "gates_failed": 0,
        "failing_gates": [],
        "rationale": "All 6 gates passed.",
        "next_steps": [],
        "constraints": [],
        "decision_id": "dec_sandbox_123",
        "timestamp": "2026-04-01T12:00:00Z",
        "override_eligible": False,
        "override_requires": [],
        "sandbox": True,
        "remaining": 9,
    }


def _make_sandbox_client(
    mock_transport: httpx.MockTransport,
) -> Aegis:
    """Create a sandbox Aegis client with mock transport."""
    client = Aegis(base_url="https://mock.api.test")
    client._transport._client = httpx.Client(
        transport=mock_transport,
        base_url="https://mock.api.test",
    )
    return client


@pytest.fixture(autouse=True)
def _clean_env() -> Any:
    """Ensure no AEGIS_API_KEY in env and reset notice state."""
    _reset_notice()
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("AEGIS_API_KEY", None)
        yield


# ── Tests ────────────────────────────────────────────────────────────


class TestSandboxModeActivation:
    def test_sandbox_mode_activates_without_key(self) -> None:
        """Aegis() with no key enters sandbox mode."""
        client = Aegis(base_url="https://mock.api.test")
        assert client._sandbox is True
        client.close()

    def test_sandbox_mode_skipped_with_key(self) -> None:
        """Aegis(api_key=...) uses authenticated mode."""
        client = Aegis(api_key="uk_live_xxx", base_url="https://mock.api.test")
        assert client._sandbox is False
        client.close()

    def test_sandbox_mode_skipped_with_env_var(self) -> None:
        """AEGIS_API_KEY env var prevents sandbox mode."""
        os.environ["AEGIS_API_KEY"] = "uk_live_from_env"
        client = Aegis(base_url="https://mock.api.test")
        assert client._sandbox is False
        client.close()


class TestSandboxEvaluation:
    def test_sandbox_evaluate_returns_decision(self) -> None:
        """Sandbox returns a proper Decision object."""
        transport = _mock_handler(_sandbox_response())
        client = _make_sandbox_client(transport)
        decision = client.evaluate(proposal_summary="Test sandbox eval")
        assert decision.status == "proceed"
        assert decision.confidence == 0.87
        client.close()

    def test_sandbox_decision_has_sandbox_fields(self) -> None:
        """Decision from sandbox has sandbox=True and remaining."""
        transport = _mock_handler(_sandbox_response())
        client = _make_sandbox_client(transport)
        decision = client.evaluate(proposal_summary="Test sandbox fields")
        assert decision.sandbox is True
        assert decision.remaining == 9
        client.close()


class TestSandboxRateLimit:
    def test_sandbox_429_raises_limit_error(self) -> None:
        """Server 429 mapped to SandboxLimitError."""
        error_body = {
            "error": "sandbox_limit_reached",
            "limit": 10,
            "remaining": 0,
            "message": (
                "Sandbox limit reached (10/day). "
                "Get a free API key at https://portal.undercurrentholdings.com for 100/month."
            ),
            "upgrade_url": "https://portal.undercurrentholdings.com",
        }
        transport = _mock_handler(error_body, status_code=429)
        client = _make_sandbox_client(transport)
        with pytest.raises(SandboxLimitError) as exc_info:
            client.evaluate(proposal_summary="Over limit")
        assert exc_info.value.limit == 10
        client.close()

    def test_sandbox_limit_error_has_portal_url(self) -> None:
        """SandboxLimitError contains portal URL."""
        error_body = {
            "error": "sandbox_limit_reached",
            "limit": 10,
            "remaining": 0,
            "message": (
                "Sandbox limit reached (10/day). "
                "Get a free API key at https://portal.undercurrentholdings.com for 100/month."
            ),
            "upgrade_url": "https://portal.undercurrentholdings.com",
        }
        transport = _mock_handler(error_body, status_code=429)
        client = _make_sandbox_client(transport)
        with pytest.raises(SandboxLimitError) as exc_info:
            client.evaluate(proposal_summary="Over limit")
        assert "portal.undercurrentholdings.com" in str(exc_info.value)
        assert exc_info.value.upgrade_url == "https://portal.undercurrentholdings.com"
        client.close()

    def test_sandbox_limit_error_inherits_aegis_error(self) -> None:
        """SandboxLimitError is a subclass of AegisError."""
        err = SandboxLimitError()
        assert isinstance(err, AegisError)
        assert err.status_code == 429


class TestSandboxNotice:
    def test_sandbox_notice_printed_once(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Sandbox notice appears on stderr once, not on second eval."""
        transport = _mock_handler(_sandbox_response())
        client = _make_sandbox_client(transport)

        client.evaluate(proposal_summary="First eval")
        captured1 = capsys.readouterr()
        assert "AEGIS Sandbox Mode" in captured1.err

        client.evaluate(proposal_summary="Second eval")
        captured2 = capsys.readouterr()
        assert "AEGIS Sandbox Mode" not in captured2.err
        client.close()


class TestSandboxTransport:
    def test_sandbox_no_auth_header(self) -> None:
        """Sandbox requests do not include Authorization header."""
        sent_headers: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            sent_headers.update(dict(request.headers))
            return httpx.Response(200, json=_sandbox_response())

        transport = httpx.MockTransport(handler)
        client = _make_sandbox_client(transport)
        client.evaluate(proposal_summary="Check headers")
        assert "authorization" not in sent_headers
        client.close()


class TestAsyncSandbox:
    async def test_async_sandbox_mode(self) -> None:
        """AsyncAegis() in sandbox mode returns Decision."""

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                json=_sandbox_response(),
                headers={"X-AEGIS-Request-Id": "sandbox-async-123"},
            )

        client = AsyncAegis(base_url="https://mock.api.test")
        assert client._sandbox is True

        client._transport._client = httpx.AsyncClient(
            transport=httpx.MockTransport(handler),
            base_url="https://mock.api.test",
        )
        decision = await client.evaluate(proposal_summary="Async sandbox test")
        assert decision.status == "proceed"
        assert decision.sandbox is True
        assert decision.remaining == 9
        await client.close()
