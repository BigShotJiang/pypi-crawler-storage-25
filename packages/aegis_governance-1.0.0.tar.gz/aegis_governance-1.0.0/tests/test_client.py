"""Tests for AEGIS SDK client using httpx mock transport."""

from __future__ import annotations

import os
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from aegis import Aegis, AsyncAegis
from aegis._errors import (
    AegisError,
    AuthenticationError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from aegis._http import _mask_key, _validate_base_url

# ── Mock transport ───────────────────────────────────────────────────


def _mock_handler(
    response_data: Any,
    status_code: int = 200,
    headers: dict[str, str] | None = None,
) -> httpx.MockTransport:
    """Create a mock transport that returns a fixed response."""
    resp_headers = {"X-AEGIS-Request-Id": "req_test_123"}
    if headers:
        resp_headers.update(headers)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code,
            json=response_data,
            headers=resp_headers,
        )

    return httpx.MockTransport(handler)


def _make_client(
    mock_transport: httpx.MockTransport,
    api_key: str = "uk_live_test_key",
) -> Aegis:
    """Create an Aegis client with a mock transport."""
    client = Aegis(api_key=api_key, base_url="https://mock.api.test")
    # Inject mock transport into the underlying httpx client
    client._transport._client = httpx.Client(
        transport=mock_transport,
        base_url="https://mock.api.test",
    )
    return client


# ── Security tests ───────────────────────────────────────────────────


class TestSecurity:
    def test_api_key_masked_in_repr(self, api_key: str) -> None:
        with patch.dict(os.environ, {"AEGIS_API_KEY": api_key}):
            client = Aegis(base_url="https://mock.test")
            repr_str = repr(client)
            assert api_key not in repr_str
            assert "uk_live" in repr_str
            assert "..." in repr_str
            client.close()

    def test_mask_key_function(self) -> None:
        assert _mask_key("uk_live_abcdefghijklmnop") == "uk_live...mnop"
        assert _mask_key("short") == "***"

    def test_no_api_key_enters_sandbox(self) -> None:
        """Aegis() without a key enters sandbox mode instead of raising."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("AEGIS_API_KEY", None)
            client = Aegis(base_url="https://mock.api.test")
            assert client._sandbox is True
            client.close()

    def test_tls_enforced_rejects_http(self) -> None:
        with pytest.raises(AegisError, match="Insecure base URL"):
            _validate_base_url("http://evil.example.com")

    def test_tls_allows_localhost(self) -> None:
        url = _validate_base_url("http://localhost:8000")
        assert url == "http://localhost:8000"

    def test_tls_allows_127(self) -> None:
        url = _validate_base_url("http://127.0.0.1:8000")
        assert url == "http://127.0.0.1:8000"

    def test_tls_allows_https(self) -> None:
        url = _validate_base_url("https://api.undercurrentholdings.com/v1")
        assert url == "https://api.undercurrentholdings.com/v1"

    def test_strips_trailing_slash(self) -> None:
        url = _validate_base_url("https://api.example.com/")
        assert url == "https://api.example.com"

    def test_invalid_scheme_rejected(self) -> None:
        with pytest.raises(AegisError, match="Invalid base URL"):
            _validate_base_url("ftp://example.com")


# ── Client tests ─────────────────────────────────────────────────────


class TestEvaluate:
    def test_evaluate_success(self, evaluate_response_data: dict) -> None:
        transport = _mock_handler(evaluate_response_data)
        client = _make_client(transport)
        decision = client.evaluate(proposal_summary="Add caching")
        assert decision.status == "proceed"
        assert decision.confidence == 0.87
        assert decision.gates_passed == 6
        assert decision.request_id == "req_test_123"
        client.close()

    def test_evaluate_empty_summary_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="required"):
            client.evaluate(proposal_summary="")
        client.close()

    def test_evaluate_long_summary_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="10,000"):
            client.evaluate(proposal_summary="x" * 10_001)
        client.close()

    def test_evaluate_invalid_score_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="risk_baseline"):
            client.evaluate(proposal_summary="test", risk_baseline=1.5)
        client.close()

    def test_evaluate_negative_score_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="novelty_score"):
            client.evaluate(proposal_summary="test", novelty_score=-0.1)
        client.close()


class TestRiskCheck:
    def test_risk_check_success(self, risk_check_response_data: dict) -> None:
        transport = _mock_handler(risk_check_response_data)
        client = _make_client(transport)
        result = client.risk_check(risk_score=0.15, threshold=0.3)
        assert result.safe is True
        assert result.risk_score == 0.15
        client.close()

    def test_risk_check_invalid_score(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="risk_score"):
            client.risk_check(risk_score=2.0)
        client.close()


class TestHealth:
    def test_health_success(self, health_response_data: dict) -> None:
        transport = _mock_handler(health_response_data)
        client = _make_client(transport)
        h = client.health()
        assert h.status == "ok"
        assert h.version == "1.1.0"
        client.close()


class TestErrorHandling:
    def test_401_raises_auth_error(self) -> None:
        transport = _mock_handler({"error": "Invalid API key"}, status_code=401)
        client = _make_client(transport)
        with pytest.raises(AuthenticationError, match="Invalid API key"):
            client.evaluate(proposal_summary="test")
        client.close()

    def test_400_raises_validation_error(self) -> None:
        transport = _mock_handler({"error": "Missing field"}, status_code=400)
        client = _make_client(transport)
        with pytest.raises(ValidationError, match="Missing field"):
            client.health()
        client.close()

    def test_429_raises_rate_limit(self) -> None:
        transport = _mock_handler(
            {"error": "Rate limited"},
            status_code=429,
            headers={"Retry-After": "30"},
        )
        client = _make_client(transport)
        # Set max_retries=0 to prevent retry loop
        client._transport._max_retries = 0
        with pytest.raises(RateLimitError) as exc_info:
            client.evaluate(proposal_summary="test")
        assert exc_info.value.retry_after == 30.0
        client.close()

    def test_500_raises_server_error(self) -> None:
        transport = _mock_handler({"error": "Internal"}, status_code=500)
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(ServerError, match="Internal"):
            client.evaluate(proposal_summary="test")
        client.close()


class TestContextManager:
    def test_sync_context_manager(self, evaluate_response_data: dict) -> None:
        transport = _mock_handler(evaluate_response_data)
        with _make_client(transport) as client:
            decision = client.evaluate(proposal_summary="test")
            assert decision.status == "proceed"


class TestCustomerManagement:
    def test_list_keys(self) -> None:
        transport = _mock_handler(
            {
                "count": 2,
                "keys": [
                    {"key_id": "key_1", "name": "Prod", "enabled": True},
                    {"key_id": "key_2", "name": "Stage", "enabled": True},
                ],
            }
        )
        client = _make_client(transport)
        keys = client.list_keys()
        assert len(keys) == 2
        assert keys[0].key_id == "key_1"
        assert keys[1].name == "Stage"
        client.close()

    def test_create_key(self) -> None:
        transport = _mock_handler(
            {
                "key_id": "key_new",
                "name": "CI",
                "key": "uk_live_newkey123",
            }
        )
        client = _make_client(transport)
        key = client.create_key("CI")
        assert key.key_id == "key_new"
        assert key.key == "uk_live_newkey123"
        client.close()

    def test_create_key_empty_name_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="name"):
            client.create_key("")
        client.close()

    def test_revoke_key_empty_id_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="key_id"):
            client.revoke_key("")
        client.close()

    def test_get_decision_empty_id_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="decision_id"):
            client.get_decision("")
        client.close()


# ── Async tests ──────────────────────────────────────────────────────


class TestAsyncClient:
    @pytest.mark.asyncio
    async def test_evaluate_success(self, evaluate_response_data: dict) -> None:
        transport = _mock_handler(evaluate_response_data)
        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        client._transport._client = httpx.AsyncClient(
            transport=transport,
            base_url="https://mock.test",
        )
        decision = await client.evaluate(proposal_summary="test async")
        assert decision.status == "proceed"
        assert decision.confidence == 0.87
        await client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager(self, evaluate_response_data: dict) -> None:
        transport = _mock_handler(evaluate_response_data)
        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        client._transport._client = httpx.AsyncClient(
            transport=transport,
            base_url="https://mock.test",
        )
        async with client:
            decision = await client.evaluate(proposal_summary="test")
            assert decision.status == "proceed"

    @pytest.mark.asyncio
    async def test_async_validation(self) -> None:
        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="required"):
            await client.evaluate(proposal_summary="")
        await client.close()


class TestBH49IdempotencyKey:
    """BH49: idempotency_key must be wired through to transport headers."""

    def test_custom_idempotency_key_sent_in_header(self) -> None:
        """When idempotency_key is provided, it must appear in the request header."""
        captured_headers: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_headers.update(dict(request.headers))
            return httpx.Response(
                200,
                json={
                    "decision_id": "d_1",
                    "status": "proceed",
                    "confidence": 0.9,
                    "gate_results": [],
                    "rationale": "ok",
                    "next_steps": [],
                },
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.evaluate(
            proposal_summary="test",
            idempotency_key="my-custom-key-123",
        )
        assert captured_headers.get("idempotency-key") == "my-custom-key-123"
        client.close()

    def test_auto_generated_key_when_no_custom_key(self) -> None:
        """Without idempotency_key, transport must auto-generate a UUID."""
        captured_headers: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_headers.update(dict(request.headers))
            return httpx.Response(
                200,
                json={
                    "decision_id": "d_1",
                    "status": "proceed",
                    "confidence": 0.9,
                    "gate_results": [],
                    "rationale": "ok",
                    "next_steps": [],
                },
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.evaluate(proposal_summary="test")
        # Should have an auto-generated UUID key
        key = captured_headers.get("idempotency-key", "")
        assert len(key) == 36  # UUID format: 8-4-4-4-12
        client.close()

    @pytest.mark.asyncio
    async def test_async_idempotency_key_sent(self) -> None:
        """Async client must also wire idempotency_key to transport."""
        captured_headers: dict[str, str] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured_headers.update(dict(request.headers))
            return httpx.Response(
                200,
                json={
                    "decision_id": "d_1",
                    "status": "proceed",
                    "confidence": 0.9,
                    "gate_results": [],
                    "rationale": "ok",
                    "next_steps": [],
                },
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        client._transport._client = httpx.AsyncClient(
            transport=httpx.MockTransport(handler),
            base_url="https://mock.test",
        )
        async with client:
            await client.evaluate(
                proposal_summary="test",
                idempotency_key="async-key-456",
            )
        assert captured_headers.get("idempotency-key") == "async-key-456"


class TestBH49BoolValidation:
    """BH49: Bool values must be rejected for normalized float fields."""

    def test_bool_true_rejected_for_risk_baseline(self) -> None:
        client = Aegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="must be numeric, not bool"):
            client.evaluate(proposal_summary="test", risk_baseline=True)  # type: ignore[arg-type]
        client.close()

    def test_bool_false_rejected_for_quality_score(self) -> None:
        client = Aegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="must be numeric, not bool"):
            client.evaluate(proposal_summary="test", quality_score=False)  # type: ignore[arg-type]
        client.close()

    @pytest.mark.asyncio
    async def test_async_bool_rejected(self) -> None:
        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="must be numeric, not bool"):
            await client.evaluate(proposal_summary="test", novelty_score=True)  # type: ignore[arg-type]
        await client.close()


class TestBH49D9URLEncoding:
    """BH49-D9: list_decisions must use URL-encoded params, not f-string."""

    def test_d9_params_passed_to_httpx(self) -> None:
        """Transport must pass params dict to httpx."""
        captured_kwargs: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_kwargs["url"] = str(request.url)
            return httpx.Response(
                200,
                json={"decisions": []},
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.list_decisions(month="2026-03", limit=10)
        url = captured_kwargs["url"]
        assert "month=2026-03" in url
        assert "limit=10" in url
        # Must NOT have raw f-string interpolation artifacts
        assert "?month=2026-03&limit=10" in url or "month=2026-03" in url
        client.close()

    def test_d9_without_month(self) -> None:
        """When month is None, only limit param should be sent."""
        captured_kwargs: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_kwargs["url"] = str(request.url)
            return httpx.Response(
                200,
                json={"decisions": []},
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.list_decisions()
        url = captured_kwargs["url"]
        assert "limit=50" in url
        assert "month" not in url
        client.close()

    def test_d9_invalid_month_format_raises(self) -> None:
        """Non-YYYY-MM month format must raise ValidationError."""
        client = Aegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="YYYY-MM"):
            client.list_decisions(month="January")
        with pytest.raises(ValidationError, match="YYYY-MM"):
            client.list_decisions(month="2026/03")
        with pytest.raises(ValidationError, match="YYYY-MM"):
            client.list_decisions(month="2026-3")
        client.close()

    def test_d9_special_chars_in_month_rejected(self) -> None:
        """Month with injection characters must be rejected."""
        client = Aegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="YYYY-MM"):
            client.list_decisions(month="2026-03&evil=true")
        client.close()

    @pytest.mark.asyncio
    async def test_d9_async_params_passed(self) -> None:
        """Async client must also use params dict."""
        captured_kwargs: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured_kwargs["url"] = str(request.url)
            return httpx.Response(
                200,
                json={"decisions": []},
                headers={"X-AEGIS-Request-Id": "req_1"},
            )

        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        client._transport._client = httpx.AsyncClient(
            transport=httpx.MockTransport(handler),
            base_url="https://mock.test",
        )
        async with client:
            await client.list_decisions(month="2026-01", limit=5)
        url = captured_kwargs["url"]
        assert "month=2026-01" in url
        assert "limit=5" in url

    @pytest.mark.asyncio
    async def test_d9_async_invalid_month(self) -> None:
        """Async client must also reject invalid month format."""
        client = AsyncAegis(api_key="uk_live_test", base_url="https://mock.test")
        with pytest.raises(ValidationError, match="YYYY-MM"):
            await client.list_decisions(month="bad")
        await client.close()
