"""End-to-end integration smoke for the attestation SDK against the real
aegis-governance FastAPI app.

Marked ``@pytest.mark.integration`` and excluded from the default pytest run
via the ``pyproject.toml`` filterwarnings setting (run with
``pytest -m integration -v`` to execute).

Catches wire-format drift between the SDK frozen-dataclass mirrors and the
server-side Pydantic v2 source-of-truth — a class of bugs unit tests with
``httpx.MockTransport`` systematically miss (Sprint 3 hotfix #164 lesson:
mocks hide real ORM/lifespan/DB behaviors).

Prerequisites:
1. ``pip install -e .`` (this SDK)
2. ``pip install -e .[dev,persistence,crypto,pqc]`` from the parent
   aegis-governance repo to bring in api_server + alembic migrations + crypto
3. ``alembic`` CLI on PATH

The test self-skips if any prerequisite is missing.

Run::

    pytest tests/test_attestations_integration.py -m integration -v
"""

from __future__ import annotations

import base64
import os
import subprocess
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from collections.abc import Iterator


# Self-skip if parent aegis-governance package + crypto isn't available
fastapi = pytest.importorskip("fastapi", reason="fastapi required (install aegis-governance[dev])")
oqs = pytest.importorskip("oqs", reason="liboqs-python required (install aegis-governance[pqc])")
aegis_governance = pytest.importorskip(
    "aegis_governance",
    reason="aegis-governance editable install required for integration tests",
)
api_server_mod = pytest.importorskip(
    "api_server", reason="api_server module required (parent src/ on sys.path)"
)
from fastapi.testclient import TestClient  # noqa: E402

from aegis import (  # noqa: E402
    Aegis,
    AttestationCollisionError,
    AttestationNotFoundError,
)

pytestmark = pytest.mark.integration


# ── Fixtures (mirror parent live test pattern) ───────────────────────


def _find_alembic_ini() -> Path:
    """Walk up from this file to find alembic.ini in the parent repo."""
    here = Path(__file__).resolve()
    for ancestor in here.parents:
        candidate = ancestor / "alembic.ini"
        if candidate.exists():
            return candidate
    pytest.skip("alembic.ini not found; parent aegis-governance repo missing")


@pytest.fixture(scope="module")
def live_db_url(tmp_path_factory: pytest.TempPathFactory) -> str:
    db_path = tmp_path_factory.mktemp("sdk_integration_db") / "aegis_sdk_live.db"
    return f"sqlite:///{db_path}"


@pytest.fixture(scope="module")
def live_keys() -> dict[str, str]:
    from aegis_governance.attestation_keys import generate_test_keypair_material

    material = generate_test_keypair_material()
    return {
        "AEGIS_ATTESTATION_ED25519_PRIVATE": base64.b64encode(material.ed25519_private).decode(
            "ascii"
        ),
        "AEGIS_ATTESTATION_ED25519_PUBLIC": base64.b64encode(material.ed25519_public).decode(
            "ascii"
        ),
        "AEGIS_ATTESTATION_MLDSA65_PRIVATE": base64.b64encode(material.mldsa65_private).decode(
            "ascii"
        ),
        "AEGIS_ATTESTATION_MLDSA65_PUBLIC": base64.b64encode(material.mldsa65_public).decode(
            "ascii"
        ),
    }


@pytest.fixture(scope="module")
def live_test_client(live_db_url: str, live_keys: dict[str, str]) -> Iterator[TestClient]:
    alembic_ini = _find_alembic_ini()
    repo_root = alembic_ini.parent
    env = {**os.environ, "DATABASE_URL": live_db_url, **live_keys}
    res = subprocess.run(
        ["alembic", "-c", str(alembic_ini), "upgrade", "head"],
        cwd=str(repo_root),
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    if res.returncode != 0:
        pytest.skip(f"alembic upgrade head failed: {res.stderr}")

    saved = {k: os.environ.get(k) for k in {"DATABASE_URL", *live_keys}}
    for k, v in {"DATABASE_URL": live_db_url, **live_keys}.items():
        os.environ[k] = v

    from aegis_governance.database import reset_engine_cache

    reset_engine_cache()

    import api_server

    try:
        with TestClient(api_server.app) as client:
            yield client
    finally:
        for k, original in saved.items():
            if original is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = original
        reset_engine_cache()
        api_server._set_attestation_provider_for_tests(None, "AttestationProviderUnavailable")


@pytest.fixture
def sdk_client_pointed_at_app(live_test_client: TestClient) -> Iterator[Aegis]:
    """Construct an Aegis client whose transport routes to the live FastAPI app.

    Auth is bypassed via app.dependency_overrides[verify_api_key] (mirrors
    parent live test pattern). The SDK still sends Authorization: Bearer
    <token>, but the server-side dependency override returns a fixed
    AuthContext regardless of header value.
    """
    import api_server
    from aegis_governance.cloud_run_auth import AuthContext, verify_api_key

    api_server.app.dependency_overrides[verify_api_key] = lambda: AuthContext(
        customer_id="cust_sdk_integration",
        tier="professional",
        meta={"tier": "professional"},
        api_key_id="key_sdk_integration",
    )

    # Construct SDK with valid HTTPS placeholder (passes _validate_base_url),
    # then swap underlying httpx.Client for the FastAPI TestClient — TestClient
    # IS an httpx.Client and routes to the in-process app.
    sdk = Aegis(api_key="dummy-bypassed-by-override", base_url="https://localhost")
    sdk._transport._client = live_test_client
    try:
        yield sdk
    finally:
        # NOTE: do NOT call sdk.close() — sdk._transport._client is the
        # module-scoped TestClient; closing it would break sibling tests.
        api_server.app.dependency_overrides.pop(verify_api_key, None)


def _attest_kwargs(**overrides: Any) -> dict[str, Any]:
    base = {
        "decision_id": str(uuid.uuid4()),
        "subject_digest_sha256": "a" * 64,
        "environment": "production",
        "risk_class": "medium",
        "policy_version": "1.2.0",
        "repository": "undercurrentai/aegis-governance",
        "workflow_ref": ".github/workflows/aegis-deploy.yml@refs/heads/main",
        "run_id": "999",
        "run_attempt": 1,
        "gate_pass_states": {
            "risk": "pass",
            "profit": "pass",
            "novelty": "pass",
            "complexity": "pass",
            "quality": "pass",
            "utility": "pass",
        },
        "builder_id": "https://github.com/undercurrentai/aegis-governance/actions",
        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
    }
    base.update(overrides)
    return base


# ── Tests ────────────────────────────────────────────────────────────


class TestAttestationSDKIntegration:
    """End-to-end SDK ↔ live FastAPI app smoke tests."""

    def test_attest_roundtrip_returns_typed_result(self, sdk_client_pointed_at_app: Aegis) -> None:
        """SDK.attest() against real app returns a populated AttestationResult."""
        result = sdk_client_pointed_at_app.attestations.attest(**_attest_kwargs())
        assert result.decision_id != ""
        assert len(result.statement_canonical_sha256) == 64
        assert result.envelope.payload_type == "application/vnd.in-toto+json"
        assert len(result.envelope.signatures) == 2
        # Both algorithms present
        keyid_prefixes = {s.keyid.split(":")[0] for s in result.envelope.signatures}
        assert keyid_prefixes == {"ed25519", "ml-dsa-65"}
        assert result.idempotent_replayed is False
        assert result.request_id is not None

    def test_attest_then_get_roundtrip(self, sdk_client_pointed_at_app: Aegis) -> None:
        """Attest, then fetch via GET — full SDK ↔ DB round-trip."""
        kwargs = _attest_kwargs()
        result = sdk_client_pointed_at_app.attestations.attest(**kwargs)
        record = sdk_client_pointed_at_app.attestations.get(decision_id=result.decision_id)
        assert record.decision_id == result.decision_id
        assert record.artifact_digest == kwargs["subject_digest_sha256"]
        assert record.environment == "production"
        assert record.risk_class == "medium"
        assert record.predicate.governance.policy_version == "1.2.0"
        assert record.customer_id == "cust_sdk_integration"

    def test_attest_then_verify_returns_valid_true(self, sdk_client_pointed_at_app: Aegis) -> None:
        """Attest, then verify the envelope server-side — full round-trip."""
        kwargs = _attest_kwargs()
        result = sdk_client_pointed_at_app.attestations.attest(**kwargs)
        verify = sdk_client_pointed_at_app.attestations.verify(
            envelope=result.envelope,
            expected_digest=kwargs["subject_digest_sha256"],
            expected_environment=kwargs["environment"],
        )
        assert verify.valid is True
        assert verify.error_class is None

    def test_verify_with_wrong_digest_returns_valid_false(
        self, sdk_client_pointed_at_app: Aegis
    ) -> None:
        """SDK never raises on cryptographic-invalid; valid=False with error_class."""
        kwargs = _attest_kwargs()
        result = sdk_client_pointed_at_app.attestations.attest(**kwargs)
        verify = sdk_client_pointed_at_app.attestations.verify(
            envelope=result.envelope,
            expected_digest="0" * 64,  # wrong digest
            expected_environment=kwargs["environment"],
        )
        assert verify.valid is False
        assert verify.error_class is not None

    def test_get_unknown_decision_id_raises_not_found(
        self, sdk_client_pointed_at_app: Aegis
    ) -> None:
        """SDK maps server 404 to AttestationNotFoundError."""
        with pytest.raises(AttestationNotFoundError):
            sdk_client_pointed_at_app.attestations.get(decision_id=str(uuid.uuid4()))

    def test_idempotent_replay_sets_flag(self, sdk_client_pointed_at_app: Aegis) -> None:
        """Same Idempotency-Key + same body → 200 with idempotent_replayed=True."""
        kwargs = _attest_kwargs()
        idem_key = f"sdk-integration-{uuid.uuid4()}"
        first = sdk_client_pointed_at_app.attestations.attest(**kwargs, idempotency_key=idem_key)
        replay = sdk_client_pointed_at_app.attestations.attest(**kwargs, idempotency_key=idem_key)
        assert replay.decision_id == first.decision_id
        assert replay.idempotent_replayed is True

    def test_same_decision_id_same_customer_replay(self, sdk_client_pointed_at_app: Aegis) -> None:
        """Re-attest with same decision_id (same customer) returns existing record.

        Per Sprint 3 §23.16.C: 200 idempotent-replay (NOT 409). This is the
        same-customer path; 409 collision only fires for foreign customers.
        """
        kwargs = _attest_kwargs()
        first = sdk_client_pointed_at_app.attestations.attest(**kwargs)
        # Different idempotency key (force a fresh insert path), same decision_id
        # → should return existing record (200) not raise collision.
        try:
            second = sdk_client_pointed_at_app.attestations.attest(**kwargs)
            assert second.decision_id == first.decision_id
        except AttestationCollisionError:  # pragma: no cover - same-customer should NOT raise
            pytest.fail(
                "Same-customer same-decision_id replay must not raise AttestationCollisionError"
            )
