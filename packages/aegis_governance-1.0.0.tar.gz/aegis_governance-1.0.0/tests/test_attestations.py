"""Tests for the AttestationClient + AsyncAttestationClient (Sprint 4 / D1).

Mirrors the test_client.py pattern: httpx.MockTransport(handler) injected into
the underlying transport's _client. ~60 tests across 6 classes covering happy
paths, validation, idempotency, error mapping, async parity, and lazy property
access. Coverage target: ≥95% on _attestations.py + the 11 new dataclasses.
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from aegis import (
    Aegis,
    AEGISPredicate,
    AsyncAegis,
    AttestationCollisionError,
    AttestationGovernance,
    AttestationNotFoundError,
    AttestationProviderUnavailableError,
    AttestationRecord,
    AttestationResult,
    AttestationSchemaDriftError,
    AttestationVerifyResult,
    AuthenticationError,
    BuildDefinition,
    DSSEEnvelope,
    DSSESignature,
    InTotoStatement,
    ResourceDescriptor,
    RunDetails,
    ValidationError,
)

_VALID_UUID = "12345678-1234-1234-1234-123456789abc"
_VALID_DIGEST = "a" * 64
_BASE_URL = "https://mock.api.test"


# ── Mock transport helpers ───────────────────────────────────────────


def _mock_handler(
    response_data: Any,
    status_code: int = 200,
    headers: dict[str, str] | None = None,
) -> httpx.MockTransport:
    resp_headers = {"X-AEGIS-Request-Id": "req_attest_test"}
    if headers:
        resp_headers.update(headers)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, json=response_data, headers=resp_headers)

    return httpx.MockTransport(handler)


def _make_client(mock_transport: httpx.MockTransport, api_key: str = "uk_live_test_key") -> Aegis:
    client = Aegis(api_key=api_key, base_url=_BASE_URL)
    client._transport._client = httpx.Client(transport=mock_transport, base_url=_BASE_URL)
    return client


def _make_async_client(
    mock_transport: httpx.MockTransport, api_key: str = "uk_live_test_key"
) -> AsyncAegis:
    client = AsyncAegis(api_key=api_key, base_url=_BASE_URL)
    client._transport._client = httpx.AsyncClient(transport=mock_transport, base_url=_BASE_URL)
    return client


def _attest_kwargs(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "decision_id": _VALID_UUID,
        "subject_digest_sha256": _VALID_DIGEST,
        "environment": "production",
        "risk_class": "medium",
        "policy_version": "1.2.0",
        "repository": "undercurrentai/aegis-governance",
        "workflow_ref": ".github/workflows/aegis-deploy.yml@refs/heads/main",
        "run_id": "25579660561",
        "run_attempt": 1,
        "gate_pass_states": {
            "risk": "pass",
            "profit": "pass",
            "novelty": "pass",
            "complexity": "pass",
            "quality": "pass",
            "utility": "pass",
        },
        "builder_id": "https://github.com/undercurrentai/aegis-governance/actions",
        "expires_at": "2026-05-10T12:00:00+00:00",
    }
    base.update(overrides)
    return base


# ── TestAttestEndpoint ───────────────────────────────────────────────


class TestAttestEndpoint:
    def test_attest_happy_path_201(self, attestation_result_data: dict) -> None:
        transport = _mock_handler(attestation_result_data, status_code=201)
        client = _make_client(transport)
        result = client.attestations.attest(**_attest_kwargs())
        assert isinstance(result, AttestationResult)
        assert result.decision_id == _VALID_UUID
        assert result.statement_canonical_sha256 == "b" * 64
        assert result.request_id == "req_attest_test"
        assert result.idempotent_replayed is False
        assert isinstance(result.envelope, DSSEEnvelope)
        assert len(result.envelope.signatures) == 2
        client.close()

    def test_attest_idempotent_replay_200_sets_flag(self, attestation_result_data: dict) -> None:
        transport = _mock_handler(
            attestation_result_data,
            status_code=200,
            headers={"X-AEGIS-Idempotent-Replayed": "true"},
        )
        client = _make_client(transport)
        result = client.attestations.attest(**_attest_kwargs())
        assert result.idempotent_replayed is True
        client.close()

    def test_attest_idempotent_replay_header_with_whitespace_sets_flag(
        self, attestation_result_data: dict
    ) -> None:
        transport = _mock_handler(
            attestation_result_data,
            status_code=200,
            headers={"X-AEGIS-Idempotent-Replayed": " true "},
        )
        client = _make_client(transport)
        result = client.attestations.attest(**_attest_kwargs())
        assert result.idempotent_replayed is True
        client.close()

    def test_attest_replayed_header_false_when_absent(self, attestation_result_data: dict) -> None:
        transport = _mock_handler(attestation_result_data, status_code=201)
        client = _make_client(transport)
        result = client.attestations.attest(**_attest_kwargs())
        assert result.idempotent_replayed is False
        client.close()

    def test_attest_409_raises_collision_error(self) -> None:
        transport = _mock_handler(
            {
                "error": "decision_id collision",
                "error_class": "AttestationDecisionIdCollisionForeignCustomer",
            },
            status_code=409,
        )
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationCollisionError) as exc_info:
            client.attestations.attest(**_attest_kwargs())
        assert exc_info.value.status_code == 409
        assert exc_info.value.request_id == "req_attest_test"
        client.close()

    def test_attest_422_raises_validation_error(self) -> None:
        transport = _mock_handler({"error": "Idempotency-Key body mismatch"}, status_code=422)
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(ValidationError) as exc_info:
            client.attestations.attest(**_attest_kwargs(), idempotency_key="reused-key")
        assert exc_info.value.status_code == 422
        client.close()

    def test_attest_503_raises_provider_unavailable(self) -> None:
        transport = _mock_handler({"error": "attestation provider unavailable"}, status_code=503)
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationProviderUnavailableError) as exc_info:
            client.attestations.attest(**_attest_kwargs())
        assert exc_info.value.status_code == 503
        client.close()

    def test_attest_401_raises_authentication_error(self) -> None:
        transport = _mock_handler({"error": "Invalid API key"}, status_code=401)
        client = _make_client(transport)
        with pytest.raises(AuthenticationError):
            client.attestations.attest(**_attest_kwargs())
        client.close()

    def test_attest_invalid_uuid_raises_validation_error(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="decision_id"):
            client.attestations.attest(**_attest_kwargs(decision_id="not-a-uuid"))
        client.close()

    def test_attest_invalid_digest_uppercase_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="subject_digest_sha256"):
            client.attestations.attest(**_attest_kwargs(subject_digest_sha256="A" * 64))
        client.close()

    def test_attest_invalid_digest_short_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="subject_digest_sha256"):
            client.attestations.attest(**_attest_kwargs(subject_digest_sha256="a" * 63))
        client.close()

    def test_attest_invalid_environment_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="environment"):
            client.attestations.attest(**_attest_kwargs(environment="dev"))
        client.close()

    def test_attest_invalid_risk_class_raises(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="risk_class"):
            client.attestations.attest(**_attest_kwargs(risk_class="urgent"))
        client.close()

    def test_attest_idempotency_key_passed_through(self, attestation_result_data: dict) -> None:
        captured: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured.update(dict(request.headers))
            return httpx.Response(
                201,
                json=attestation_result_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.attestations.attest(**_attest_kwargs(), idempotency_key="my-attest-key-789")
        assert captured.get("idempotency-key") == "my-attest-key-789"
        client.close()

    def test_attest_auto_idempotency_key_generated(self, attestation_result_data: dict) -> None:
        captured: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured.update(dict(request.headers))
            return httpx.Response(
                201,
                json=attestation_result_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.attestations.attest(**_attest_kwargs())
        # Auto-generated UUID format
        key = captured.get("idempotency-key", "")
        assert len(key) == 36
        client.close()

    def test_attest_body_includes_optional_fields_when_provided(
        self, attestation_result_data: dict
    ) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.read()
            return httpx.Response(
                201,
                json=attestation_result_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.attestations.attest(
            **_attest_kwargs(),
            subject_name="my-artifact",
            build_type="https://custom.build/type",
        )
        import json

        body = json.loads(captured["body"])
        assert body["subject_name"] == "my-artifact"
        assert body["build_type"] == "https://custom.build/type"
        assert body["external_parameters"] == {}
        client.close()


# ── TestVerifyEndpoint ───────────────────────────────────────────────


def _make_envelope() -> DSSEEnvelope:
    return DSSEEnvelope(
        payload_type="application/vnd.in-toto+json",
        payload="eyJfdHlwZSI6Imh0dHBzOi8vaW4tdG90by5pby9TdGF0ZW1lbnQvdjEifQ==",
        signatures=[
            DSSESignature(keyid="ed25519:k1", sig="ZWQ="),
            DSSESignature(keyid="ml-dsa-65:k2", sig="bWw="),
        ],
    )


class TestVerifyEndpoint:
    def test_verify_valid_true(self) -> None:
        transport = _mock_handler(
            {
                "valid": True,
                "error_class": None,
                "verified_at": "2026-05-09T10:00:00+00:00",
            }
        )
        client = _make_client(transport)
        result = client.attestations.verify(
            envelope=_make_envelope(),
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
        )
        assert isinstance(result, AttestationVerifyResult)
        assert result.valid is True
        assert result.error_class is None
        assert result.request_id == "req_attest_test"
        client.close()

    @pytest.mark.parametrize(
        "error_class",
        [
            "AttestationDigestMismatch",
            "AttestationEnvironmentMismatch",
            "AttestationExpired",
            "AttestationSubjectMissing",
            "AttestationExpiresAtMalformed",
        ],
    )
    def test_verify_valid_false_returns_error_class(self, error_class: str) -> None:
        transport = _mock_handler(
            {
                "valid": False,
                "error_class": error_class,
                "verified_at": "2026-05-09T10:00:00+00:00",
            }
        )
        client = _make_client(transport)
        result = client.attestations.verify(
            envelope=_make_envelope(),
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
        )
        # NEVER raises on cryptographic-invalid; caller checks .valid
        assert result.valid is False
        assert result.error_class == error_class
        client.close()

    def test_verify_503_raises_provider_unavailable(self) -> None:
        transport = _mock_handler({"error": "attestation provider unavailable"}, status_code=503)
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationProviderUnavailableError):
            client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest=_VALID_DIGEST,
                expected_environment="production",
            )
        client.close()

    def test_verify_401_raises_authentication_error(self) -> None:
        transport = _mock_handler({"error": "Invalid API key"}, status_code=401)
        client = _make_client(transport)
        with pytest.raises(AuthenticationError):
            client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest=_VALID_DIGEST,
                expected_environment="production",
            )
        client.close()

    def test_verify_invalid_digest_raises_client_side(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="expected_digest"):
            client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest="not-hex",
                expected_environment="production",
            )
        client.close()

    def test_verify_invalid_environment_raises_client_side(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="expected_environment"):
            client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest=_VALID_DIGEST,
                expected_environment="dev",
            )
        client.close()

    def test_verify_envelope_serialized_in_body(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.read()
            return httpx.Response(
                200,
                json={
                    "valid": True,
                    "error_class": None,
                    "verified_at": "2026-05-09T10:00:00+00:00",
                },
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.attestations.verify(
            envelope=_make_envelope(),
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
        )
        import json

        body = json.loads(captured["body"])
        # DSSE camelCase aliases preserved
        assert body["envelope"]["payloadType"] == "application/vnd.in-toto+json"
        assert len(body["envelope"]["signatures"]) == 2
        assert body["expected_digest"] == _VALID_DIGEST
        assert body["expected_environment"] == "production"
        client.close()


# ── TestGetEndpoint ──────────────────────────────────────────────────


class TestGetEndpoint:
    def test_get_happy_path(self, attestation_record_data: dict) -> None:
        transport = _mock_handler(attestation_record_data)
        client = _make_client(transport)
        record = client.attestations.get(decision_id=_VALID_UUID)
        assert isinstance(record, AttestationRecord)
        assert record.decision_id == _VALID_UUID
        assert record.customer_id == "cust_test_123"
        assert isinstance(record.envelope, DSSEEnvelope)
        assert isinstance(record.predicate, AEGISPredicate)
        assert record.predicate.governance.environment == "production"
        assert record.request_id == "req_attest_test"
        client.close()

    def test_get_404_raises_not_found(self) -> None:
        transport = _mock_handler(
            {"error": "attestation not found", "error_class": "AttestationNotFound"},
            status_code=404,
        )
        client = _make_client(transport)
        with pytest.raises(AttestationNotFoundError) as exc_info:
            client.attestations.get(decision_id=_VALID_UUID)
        assert exc_info.value.status_code == 404
        client.close()

    def test_get_404_cross_customer_same_shape_as_absent(self) -> None:
        """Tenant-isolation invariant: cross-customer + absent return identical 404."""
        # Both server-side cases (absent + cross-customer) emit the same 404.
        # The SDK reflects this by raising the same exception for both.
        transport_absent = _mock_handler(
            {"error": "attestation not found", "error_class": "AttestationNotFound"},
            status_code=404,
        )
        client = _make_client(transport_absent)
        with pytest.raises(AttestationNotFoundError) as e1:
            client.attestations.get(decision_id=_VALID_UUID)
        client.close()

        # Cross-customer: same 404 + AttestationNotFound shape
        transport_cross = _mock_handler(
            {"error": "attestation not found", "error_class": "AttestationNotFound"},
            status_code=404,
        )
        client = _make_client(transport_cross)
        with pytest.raises(AttestationNotFoundError) as e2:
            client.attestations.get(decision_id=_VALID_UUID)
        client.close()

        assert type(e1.value) is type(e2.value)
        assert e1.value.status_code == e2.value.status_code == 404

    def test_get_410_raises_schema_drift(self) -> None:
        transport = _mock_handler(
            {
                "error": "schema drift",
                "error_class": "AttestationSchemaDriftPostMigration",
            },
            status_code=410,
        )
        client = _make_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationSchemaDriftError) as exc_info:
            client.attestations.get(decision_id=_VALID_UUID)
        assert exc_info.value.status_code == 410
        client.close()

    def test_get_invalid_uuid_raises_client_side(self) -> None:
        client = _make_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="decision_id"):
            client.attestations.get(decision_id="not-a-uuid")
        client.close()

    def test_get_401_raises_authentication_error(self) -> None:
        transport = _mock_handler({"error": "Invalid API key"}, status_code=401)
        client = _make_client(transport)
        with pytest.raises(AuthenticationError):
            client.attestations.get(decision_id=_VALID_UUID)
        client.close()

    def test_get_url_path_includes_decision_id(self, attestation_record_data: dict) -> None:
        captured: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["path"] = request.url.path
            return httpx.Response(
                200,
                json=attestation_record_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        client = _make_client(httpx.MockTransport(handler))
        client.attestations.get(decision_id=_VALID_UUID)
        assert captured["path"] == f"/attestations/{_VALID_UUID}"
        client.close()


# ── TestDataclassRoundtrip ───────────────────────────────────────────


class TestDataclassRoundtrip:
    def test_resource_descriptor_roundtrip(self) -> None:
        rd = ResourceDescriptor(name="art", digest={"sha256": "a" * 64})
        rd2 = ResourceDescriptor.from_response(rd.to_dict())
        assert rd == rd2

    def test_resource_descriptor_no_name(self) -> None:
        rd = ResourceDescriptor(digest={"sha256": "a" * 64})
        rd2 = ResourceDescriptor.from_response(rd.to_dict())
        assert rd == rd2
        assert rd.name is None

    def test_build_definition_roundtrip(self) -> None:
        bd = BuildDefinition(build_type="https://x.y/z", external_parameters={"sha": "abc"})
        bd2 = BuildDefinition.from_response(bd.to_dict())
        assert bd == bd2
        # Wire alias correctness
        assert bd.to_dict()["buildType"] == "https://x.y/z"
        assert bd.to_dict()["externalParameters"] == {"sha": "abc"}

    def test_run_details_roundtrip(self) -> None:
        rd = RunDetails(builder={"id": "https://x"})
        rd2 = RunDetails.from_response(rd.to_dict())
        assert rd == rd2

    def test_build_definition_with_optional_fields(self) -> None:
        bd = BuildDefinition(
            build_type="https://x",
            external_parameters={},
            internal_parameters={"secret": "redacted"},
            resolved_dependencies=[{"uri": "git+https://...", "digest": {}}],
        )
        bd2 = BuildDefinition.from_response(bd.to_dict())
        assert bd == bd2
        assert bd.to_dict()["internalParameters"] == {"secret": "redacted"}
        assert bd.to_dict()["resolvedDependencies"] == [{"uri": "git+https://...", "digest": {}}]

    def test_run_details_with_optional_fields(self) -> None:
        rd = RunDetails(
            builder={"id": "https://x"},
            metadata={"invocationId": "abc"},
            byproducts=[{"name": "log.txt"}],
        )
        rd2 = RunDetails.from_response(rd.to_dict())
        assert rd == rd2
        assert rd.to_dict()["metadata"] == {"invocationId": "abc"}
        assert rd.to_dict()["byproducts"] == [{"name": "log.txt"}]

    def test_attestation_governance_roundtrip(self) -> None:
        gov = AttestationGovernance(
            decision_id=_VALID_UUID,
            artifact_digest=_VALID_DIGEST,
            environment="production",
            risk_class="medium",
            policy_version="1.2.0",
            issued_at="2026-05-09T10:00:00+00:00",
            expires_at="2026-05-10T10:00:00+00:00",
            gate_pass_states={
                "risk": "pass",
                "profit": "pass",
                "novelty": "pass",
                "complexity": "pass",
                "quality": "pass",
                "utility": "pass",
            },
            repository="undercurrentai/foo",
            workflow_ref="x",
            run_id="1",
            run_attempt=1,
            nonce=None,
        )
        gov2 = AttestationGovernance.from_response(gov.to_dict())
        assert gov == gov2

    def test_attestation_governance_with_nonce(self) -> None:
        gov = AttestationGovernance(
            decision_id=_VALID_UUID,
            artifact_digest=_VALID_DIGEST,
            environment="production",
            risk_class="critical",
            policy_version="1.2.0",
            issued_at="2026-05-09T10:00:00+00:00",
            expires_at="2026-05-09T11:00:00+00:00",
            gate_pass_states={
                "risk": "pass",
                "profit": "pass",
                "novelty": "pass",
                "complexity": "pass",
                "quality": "pass",
                "utility": "pass",
            },
            repository="undercurrentai/foo",
            workflow_ref="x",
            run_id="1",
            run_attempt=1,
            nonce="dGVzdC1ub25jZS0zMi1ieXRlcy1iYXNlNjQtZW5jb2RlZA==",
        )
        gov2 = AttestationGovernance.from_response(gov.to_dict())
        assert gov == gov2
        assert gov.nonce is not None

    def test_aegis_predicate_roundtrip(self) -> None:
        gov = AttestationGovernance(
            decision_id=_VALID_UUID,
            artifact_digest=_VALID_DIGEST,
            environment="production",
            risk_class="medium",
            policy_version="1.2.0",
            issued_at="2026-05-09T10:00:00+00:00",
            expires_at="2026-05-10T10:00:00+00:00",
            gate_pass_states={
                "risk": "pass",
                "profit": "pass",
                "novelty": "pass",
                "complexity": "pass",
                "quality": "pass",
                "utility": "pass",
            },
            repository="undercurrentai/foo",
            workflow_ref="x",
            run_id="1",
            run_attempt=1,
        )
        pred = AEGISPredicate(
            build_definition=BuildDefinition(build_type="https://x", external_parameters={}),
            run_details=RunDetails(builder={"id": "https://x"}),
            governance=gov,
        )
        pred2 = AEGISPredicate.from_response(pred.to_dict())
        assert pred == pred2
        # Wire aliases
        assert "buildDefinition" in pred.to_dict()
        assert "runDetails" in pred.to_dict()

    def test_in_toto_statement_roundtrip(self) -> None:
        gov = AttestationGovernance(
            decision_id=_VALID_UUID,
            artifact_digest=_VALID_DIGEST,
            environment="production",
            risk_class="medium",
            policy_version="1.2.0",
            issued_at="2026-05-09T10:00:00+00:00",
            expires_at="2026-05-10T10:00:00+00:00",
            gate_pass_states={
                "risk": "pass",
                "profit": "pass",
                "novelty": "pass",
                "complexity": "pass",
                "quality": "pass",
                "utility": "pass",
            },
            repository="undercurrentai/foo",
            workflow_ref="x",
            run_id="1",
            run_attempt=1,
        )
        pred = AEGISPredicate(
            build_definition=BuildDefinition(build_type="https://x", external_parameters={}),
            run_details=RunDetails(builder={"id": "https://x"}),
            governance=gov,
        )
        stmt = InTotoStatement(
            type_="https://in-toto.io/Statement/v1",
            subject=[ResourceDescriptor(digest={"sha256": _VALID_DIGEST})],
            predicate_type="https://aegis.undercurrentholdings.com/attestation/v1",
            predicate=pred,
        )
        stmt2 = InTotoStatement.from_response(stmt.to_dict())
        assert stmt == stmt2
        # Wire aliases _type, predicateType
        assert stmt.to_dict()["_type"] == "https://in-toto.io/Statement/v1"
        assert (
            stmt.to_dict()["predicateType"]
            == "https://aegis.undercurrentholdings.com/attestation/v1"
        )

    def test_dsse_signature_roundtrip(self) -> None:
        s = DSSESignature(keyid="ed25519:k1", sig="ZWQ=")
        s2 = DSSESignature.from_response(s.to_dict())
        assert s == s2

    def test_dsse_envelope_roundtrip(self) -> None:
        env = _make_envelope()
        env2 = DSSEEnvelope.from_response(env.to_dict())
        assert env == env2
        # Wire alias
        assert env.to_dict()["payloadType"] == "application/vnd.in-toto+json"


# ── TestAsyncParity ──────────────────────────────────────────────────


class TestAsyncParity:
    @pytest.mark.asyncio
    async def test_async_attest_happy(self, attestation_result_data: dict) -> None:
        transport = _mock_handler(attestation_result_data, status_code=201)
        client = _make_async_client(transport)
        result = await client.attestations.attest(**_attest_kwargs())
        assert result.decision_id == _VALID_UUID
        await client.close()

    @pytest.mark.asyncio
    async def test_async_attest_idempotent_replay(self, attestation_result_data: dict) -> None:
        transport = _mock_handler(
            attestation_result_data,
            status_code=200,
            headers={"X-AEGIS-Idempotent-Replayed": "true"},
        )
        client = _make_async_client(transport)
        result = await client.attestations.attest(**_attest_kwargs())
        assert result.idempotent_replayed is True
        await client.close()

    @pytest.mark.asyncio
    async def test_async_attest_409_collision(self) -> None:
        transport = _mock_handler({"error": "collision"}, status_code=409)
        client = _make_async_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationCollisionError):
            await client.attestations.attest(**_attest_kwargs())
        await client.close()

    @pytest.mark.asyncio
    async def test_async_attest_503_provider_unavailable(self) -> None:
        transport = _mock_handler({"error": "unavailable"}, status_code=503)
        client = _make_async_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationProviderUnavailableError):
            await client.attestations.attest(**_attest_kwargs())
        await client.close()

    @pytest.mark.asyncio
    async def test_async_verify_valid_true(self) -> None:
        transport = _mock_handler(
            {
                "valid": True,
                "error_class": None,
                "verified_at": "2026-05-09T10:00:00+00:00",
            }
        )
        client = _make_async_client(transport)
        result = await client.attestations.verify(
            envelope=_make_envelope(),
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
        )
        assert result.valid is True
        await client.close()

    @pytest.mark.asyncio
    async def test_async_verify_valid_false_does_not_raise(self) -> None:
        transport = _mock_handler(
            {
                "valid": False,
                "error_class": "AttestationDigestMismatch",
                "verified_at": "2026-05-09T10:00:00+00:00",
            }
        )
        client = _make_async_client(transport)
        result = await client.attestations.verify(
            envelope=_make_envelope(),
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
        )
        assert result.valid is False
        assert result.error_class == "AttestationDigestMismatch"
        await client.close()

    @pytest.mark.asyncio
    async def test_async_get_happy(self, attestation_record_data: dict) -> None:
        transport = _mock_handler(attestation_record_data)
        client = _make_async_client(transport)
        record = await client.attestations.get(decision_id=_VALID_UUID)
        assert record.decision_id == _VALID_UUID
        assert record.predicate.governance.environment == "production"
        await client.close()

    @pytest.mark.asyncio
    async def test_async_get_404_not_found(self) -> None:
        transport = _mock_handler({"error": "not found"}, status_code=404)
        client = _make_async_client(transport)
        with pytest.raises(AttestationNotFoundError):
            await client.attestations.get(decision_id=_VALID_UUID)
        await client.close()

    @pytest.mark.asyncio
    async def test_async_get_410_schema_drift(self) -> None:
        transport = _mock_handler({"error": "drift"}, status_code=410)
        client = _make_async_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationSchemaDriftError):
            await client.attestations.get(decision_id=_VALID_UUID)
        await client.close()

    @pytest.mark.asyncio
    async def test_async_validation_fail_fast(self) -> None:
        client = _make_async_client(_mock_handler({}))
        with pytest.raises(ValidationError, match="decision_id"):
            await client.attestations.attest(**_attest_kwargs(decision_id="bad"))
        await client.close()

    @pytest.mark.asyncio
    async def test_async_verify_503_raises_provider_unavailable(self) -> None:
        transport = _mock_handler({"error": "unavailable"}, status_code=503)
        client = _make_async_client(transport)
        client._transport._max_retries = 0
        with pytest.raises(AttestationProviderUnavailableError):
            await client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest=_VALID_DIGEST,
                expected_environment="production",
            )
        await client.close()


# ── TestPropertyAccess ───────────────────────────────────────────────


class TestPropertyAccess:
    def test_attestations_property_lazy_init(self) -> None:
        client = Aegis(api_key="uk_live_test", base_url=_BASE_URL)
        assert client._attestations is None
        sub = client.attestations
        assert client._attestations is sub
        client.close()

    def test_attestations_property_cached(self) -> None:
        client = Aegis(api_key="uk_live_test", base_url=_BASE_URL)
        sub1 = client.attestations
        sub2 = client.attestations
        assert sub1 is sub2
        client.close()

    def test_sandbox_attest_raises_validation_error(self) -> None:
        client = Aegis(base_url=_BASE_URL)  # no api_key → sandbox
        with pytest.raises(ValidationError, match="sandbox"):
            client.attestations.attest(**_attest_kwargs())
        client.close()

    def test_sandbox_verify_raises_validation_error(self) -> None:
        client = Aegis(base_url=_BASE_URL)
        with pytest.raises(ValidationError, match="sandbox"):
            client.attestations.verify(
                envelope=_make_envelope(),
                expected_digest=_VALID_DIGEST,
                expected_environment="production",
            )
        client.close()

    def test_sandbox_get_raises_validation_error(self) -> None:
        client = Aegis(base_url=_BASE_URL)
        with pytest.raises(ValidationError, match="sandbox"):
            client.attestations.get(decision_id=_VALID_UUID)
        client.close()

    @pytest.mark.asyncio
    async def test_async_attestations_property_lazy_cached(self) -> None:
        client = AsyncAegis(api_key="uk_live_test", base_url=_BASE_URL)
        assert client._attestations is None
        sub1 = client.attestations
        sub2 = client.attestations
        assert sub1 is sub2
        await client.close()

    @pytest.mark.asyncio
    async def test_async_sandbox_attest_raises(self) -> None:
        client = AsyncAegis(base_url=_BASE_URL)
        with pytest.raises(ValidationError, match="sandbox"):
            await client.attestations.attest(**_attest_kwargs())
        await client.close()


# ── TestDefensiveDeserialization (Phase 2 cycle 1: F2.1 + F2.2) ──────


class TestDefensiveDeserialization:
    """Regression tests for null-tolerant from_response defaults.

    Sprint 4/D1 audit Phase 2 cycle 1 found that ``dict(data.get(key, {}))``
    crashes with TypeError when the server emits ``{"key": null}`` because
    ``data.get(key, {})`` returns None (not the default), and ``dict(None)``
    raises. Same class for ``[x for x in data.get(key, [])]`` when the
    server emits ``{"key": null}``. Fix: ``dict(... or {})`` and ``... or []``
    coerce None to the empty default.
    """

    def test_resource_descriptor_handles_null_digest(self) -> None:
        rd = ResourceDescriptor.from_response({"digest": None, "name": "art"})
        assert rd.digest == {}
        assert rd.name == "art"

    def test_build_definition_handles_null_external_parameters(self) -> None:
        bd = BuildDefinition.from_response({"buildType": "https://x", "externalParameters": None})
        assert bd.external_parameters == {}
        assert bd.build_type == "https://x"

    def test_run_details_handles_null_builder(self) -> None:
        rd = RunDetails.from_response({"builder": None})
        assert rd.builder == {}

    def test_attestation_governance_handles_null_gate_pass_states(self) -> None:
        gov = AttestationGovernance.from_response(
            {
                "decision_id": _VALID_UUID,
                "artifact_digest": _VALID_DIGEST,
                "environment": "production",
                "risk_class": "medium",
                "policy_version": "1.2.0",
                "issued_at": "2026-05-09T10:00:00+00:00",
                "expires_at": "2026-05-10T10:00:00+00:00",
                "gate_pass_states": None,
                "repository": "x",
                "workflow_ref": "x",
                "run_id": "1",
                "run_attempt": 1,
            }
        )
        assert gov.gate_pass_states == {}

    def test_dsse_envelope_handles_null_signatures(self) -> None:
        env = DSSEEnvelope.from_response(
            {
                "payloadType": "application/vnd.in-toto+json",
                "payload": "Zm9v",
                "signatures": None,
            }
        )
        assert env.signatures == []

    def test_in_toto_statement_handles_null_subject(self) -> None:
        stmt = InTotoStatement.from_response(
            {
                "_type": "https://in-toto.io/Statement/v1",
                "subject": None,
                "predicateType": "https://aegis.undercurrentholdings.com/attestation/v1",
                "predicate": {
                    "buildDefinition": {
                        "buildType": "https://x",
                        "externalParameters": {},
                    },
                    "runDetails": {"builder": {"id": "https://x"}},
                    "governance": {
                        "decision_id": _VALID_UUID,
                        "artifact_digest": _VALID_DIGEST,
                        "environment": "production",
                        "risk_class": "medium",
                        "policy_version": "1.2.0",
                        "issued_at": "2026-05-09T10:00:00+00:00",
                        "expires_at": "2026-05-10T10:00:00+00:00",
                        "gate_pass_states": {},
                        "repository": "x",
                        "workflow_ref": "x",
                        "run_id": "1",
                        "run_attempt": 1,
                    },
                },
            }
        )
        assert stmt.subject == []


# ── TestUuidNormalization (Phase 2 cycle 1: F2.4) ────────────────────


class TestUuidNormalization:
    """Regression tests for RFC 4122 UUID lowercase normalization.

    Sprint 4/D1 audit Phase 2 cycle 1 found that the SDK's UUID-36 regex
    accepts mixed case (RFC 4122 §3 says case-insensitive on input), but
    the server stores ``decision_id`` as the case-sensitive primary key.
    Without SDK normalization, ``attest("AB...")`` then ``get("ab...")``
    would fail (server stores "AB...", path lookup with "ab..." misses).

    Fix: SDK normalizes to lowercase at the boundary, ensuring symmetric
    write/read regardless of caller-supplied case.
    """

    def test_attest_normalizes_uppercase_decision_id_to_lowercase_in_body(
        self, attestation_result_data: dict
    ) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.read()
            return httpx.Response(
                201,
                json=attestation_result_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        upper_uuid = "AB123456-1234-1234-1234-123456789ABC"
        lower_uuid = upper_uuid.lower()
        client = _make_client(httpx.MockTransport(handler))
        client.attestations.attest(**_attest_kwargs(decision_id=upper_uuid))
        import json

        body = json.loads(captured["body"])
        assert body["decision_id"] == lower_uuid
        assert body["decision_id"] != upper_uuid
        client.close()

    def test_get_normalizes_uppercase_decision_id_to_lowercase_in_path(
        self, attestation_record_data: dict
    ) -> None:
        captured: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["path"] = request.url.path
            return httpx.Response(
                200,
                json=attestation_record_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        upper_uuid = "AB123456-1234-1234-1234-123456789ABC"
        lower_uuid = upper_uuid.lower()
        client = _make_client(httpx.MockTransport(handler))
        client.attestations.get(decision_id=upper_uuid)
        assert captured["path"] == f"/attestations/{lower_uuid}"
        client.close()

    @pytest.mark.asyncio
    async def test_async_attest_normalizes_uppercase_uuid(
        self, attestation_result_data: dict
    ) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.read()
            return httpx.Response(
                201,
                json=attestation_result_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        upper_uuid = "AB123456-1234-1234-1234-123456789ABC"
        client = _make_async_client(httpx.MockTransport(handler))
        await client.attestations.attest(**_attest_kwargs(decision_id=upper_uuid))
        import json

        body = json.loads(captured["body"])
        assert body["decision_id"] == upper_uuid.lower()
        await client.close()

    @pytest.mark.asyncio
    async def test_async_get_normalizes_uppercase_uuid(self, attestation_record_data: dict) -> None:
        captured: dict[str, str] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["path"] = request.url.path
            return httpx.Response(
                200,
                json=attestation_record_data,
                headers={"X-AEGIS-Request-Id": "req_attest_test"},
            )

        upper_uuid = "AB123456-1234-1234-1234-123456789ABC"
        client = _make_async_client(httpx.MockTransport(handler))
        await client.attestations.get(decision_id=upper_uuid)
        assert captured["path"] == f"/attestations/{upper_uuid.lower()}"
        await client.close()
