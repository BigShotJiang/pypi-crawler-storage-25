"""Tests for @aegis_gate decorator."""

from unittest.mock import MagicMock, patch

import pytest

from aegis._decorators import aegis_gate
from aegis._errors import HaltError


def _mock_decision(status: str, rationale: str = "test") -> MagicMock:
    d = MagicMock()
    d.status = status
    d.rationale = rationale
    return d


class TestAegisGateDecorator:
    """Tests for the @aegis_gate decorator."""

    @patch("aegis._decorators.Aegis")
    def test_proceed_executes_function(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate(proposal_summary="deploy")
        def my_func():
            return "executed"

        assert my_func() == "executed"
        client.evaluate.assert_called_once()

    @patch("aegis._decorators.Aegis")
    def test_halt_raises_halt_error(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("halt", "complexity floor")

        @aegis_gate(proposal_summary="risky deploy")
        def my_func():
            return "should not run"

        with pytest.raises(HaltError, match="AEGIS HALT"):
            my_func()

    @patch("aegis._decorators.Aegis")
    def test_halt_with_fail_on_halt_false(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("halt")

        @aegis_gate(proposal_summary="deploy", fail_on_halt=False)
        def my_func():
            return "executed anyway"

        assert my_func() == "executed anyway"

    @patch("aegis._decorators.Aegis")
    def test_pause_does_not_raise(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("pause")

        @aegis_gate(proposal_summary="deploy")
        def my_func():
            return "executed"

        assert my_func() == "executed"

    @patch("aegis._decorators.Aegis")
    def test_escalate_does_not_raise(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("escalate")

        @aegis_gate(proposal_summary="deploy")
        def my_func():
            return "executed"

        assert my_func() == "executed"

    @patch("aegis._decorators.Aegis")
    def test_passes_gate_kwargs(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate(
            proposal_summary="deploy",
            estimated_impact="high",
            risk_proposed=0.3,
            complexity_score=0.8,
        )
        def my_func():
            return "ok"

        my_func()
        call_kwargs = client.evaluate.call_args.kwargs
        assert call_kwargs["risk_proposed"] == 0.3
        assert call_kwargs["complexity_score"] == 0.8
        assert call_kwargs["estimated_impact"] == "high"

    @patch("aegis._decorators.Aegis")
    def test_uses_docstring_as_fallback_summary(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate()
        def my_func():
            """Deploy the auth service."""
            return "ok"

        my_func()
        call_kwargs = client.evaluate.call_args.kwargs
        assert call_kwargs["proposal_summary"] == "Deploy the auth service."

    @patch("aegis._decorators.Aegis")
    def test_uses_function_name_as_last_fallback(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate()
        def deploy_auth_service():
            return "ok"

        deploy_auth_service()
        call_kwargs = client.evaluate.call_args.kwargs
        assert call_kwargs["proposal_summary"] == "deploy_auth_service"

    @patch("aegis._decorators.Aegis")
    def test_preserves_function_metadata(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate(proposal_summary="test")
        def my_func():
            """My docstring."""
            return "ok"

        assert my_func.__name__ == "my_func"
        assert my_func.__doc__ == "My docstring."

    @patch("aegis._decorators.Aegis")
    def test_passes_args_and_kwargs_through(self, MockAegis):
        client = MockAegis.return_value.__enter__.return_value
        client.evaluate.return_value = _mock_decision("proceed")

        @aegis_gate(proposal_summary="test")
        def add(a, b, extra=0):
            return a + b + extra

        assert add(1, 2, extra=3) == 6


class TestHaltError:
    """Tests for HaltError exception."""

    def test_halt_error_message(self):
        decision = _mock_decision("halt", "Complexity floor not met")
        err = HaltError(decision)
        assert "Complexity floor not met" in str(err)
        assert err.decision is decision

    def test_halt_error_is_aegis_error(self):
        from aegis._errors import AegisError

        err = HaltError(_mock_decision("halt"))
        assert isinstance(err, AegisError)
