"""End-to-end round-trip vs server-side AttestationProvider (Sprint 4 / D2).

Marked ``@pytest.mark.integration`` and excluded from the default pytest run
via ``pyproject.toml`` ``addopts = "-m 'not integration'"``. Run explicitly:

    pytest -m integration tests/test_verify_local_integration.py -v

Catches wire-format / canonicalization drift between server-side
``AttestationProvider.issue()`` and SDK ``verify_attestation_locally()``.
The whole point of D2 is a byte-exact mirror of the server's verify path —
this integration test is the canonical proof that mirror holds.

Self-skips if the parent ``aegis_governance`` package is not editable-installed
(consumers may have only ``[verify]`` deps, no parent server).
"""

from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone

import pytest

# Self-skip the whole module if parent package isn't installed
aegis_governance = pytest.importorskip(
    "aegis_governance",
    reason="aegis-governance editable install required for round-trip integration",
)
pytest.importorskip("rfc8785")
pytest.importorskip("oqs")
from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey,
)

from aegis import AttestationVerifyKey, verify_attestation_locally  # noqa: E402
from aegis import DSSEEnvelope as SdkDSSEEnvelope  # noqa: E402

pytestmark = pytest.mark.integration


_VALID_UUID = "12345678-1234-1234-1234-123456789abc"
_VALID_DIGEST = "a" * 64


@pytest.fixture(scope="module")
def server_signed_envelope() -> tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str]:
    """Use server-side AttestationProvider.issue() to produce a real envelope,
    then return it as the SDK's DSSEEnvelope dataclass for D2 verification."""
    from aegis_governance.attestation_keys import (
        AttestationKeyMaterial,
        generate_test_keypair_material,
    )
    from aegis_governance.attestation_models import (
        AEGISPredicate,
        AttestationGovernance,
        BuildDefinition,
        InTotoStatement,
        ResourceDescriptor,
        RunDetails,
    )
    from crypto.attestation_provider import AttestationProvider

    material: AttestationKeyMaterial = generate_test_keypair_material()
    provider = AttestationProvider(key_material=material)

    issued_at = datetime.now(timezone.utc)
    expires_at = issued_at + timedelta(hours=1)

    governance = AttestationGovernance(
        decision_id=_VALID_UUID,
        artifact_digest=_VALID_DIGEST,
        environment="production",
        risk_class="medium",
        policy_version="1.2.0",
        issued_at=issued_at.isoformat(),
        expires_at=expires_at.isoformat(),
        gate_pass_states={
            "risk": "pass",
            "profit": "pass",
            "novelty": "pass",
            "complexity": "pass",
            "quality": "pass",
            "utility": "pass",
        },
        repository="undercurrentai/foo",
        workflow_ref="x",
        run_id="1",
        run_attempt=1,
        nonce=None,
    )
    predicate = AEGISPredicate(
        build_definition=BuildDefinition(
            build_type="https://x.y/z", external_parameters={"sha": "abc"}
        ),
        run_details=RunDetails(builder={"id": "https://x"}),
        governance=governance,
    )
    statement = InTotoStatement(
        subject=[ResourceDescriptor(digest={"sha256": _VALID_DIGEST})],
        predicate=predicate,
    )

    server_envelope = provider.issue(statement)

    sdk_envelope = SdkDSSEEnvelope.from_response(
        server_envelope.model_dump(by_alias=True, mode="json")
    )

    keys = AttestationVerifyKey(
        ed25519_public=material.ed25519_public,
        mldsa65_public=material.mldsa65_public,
    )

    return sdk_envelope, keys, _VALID_DIGEST, "production"


class TestServerToSdkRoundTrip:
    """Server signs → SDK verifies. Exercises the byte-exact mirror invariant."""

    def test_server_envelope_verifies_locally(
        self,
        server_signed_envelope: tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str],
    ) -> None:
        envelope, keys, digest, env = server_signed_envelope
        valid, err = verify_attestation_locally(
            envelope=envelope,
            expected_digest=digest,
            expected_environment=env,
            keys=keys,
        )
        assert valid is True, f"unexpected failure: {err}"
        assert err is None

    def test_server_envelope_wrong_digest_fails_locally(
        self,
        server_signed_envelope: tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str],
    ) -> None:
        envelope, keys, _digest, env = server_signed_envelope
        valid, err = verify_attestation_locally(
            envelope=envelope,
            expected_digest="0" * 64,
            expected_environment=env,
            keys=keys,
        )
        assert valid is False
        assert err == "AttestationDigestMismatch"

    def test_server_envelope_wrong_environment_fails_locally(
        self,
        server_signed_envelope: tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str],
    ) -> None:
        envelope, keys, digest, _env = server_signed_envelope
        valid, err = verify_attestation_locally(
            envelope=envelope,
            expected_digest=digest,
            expected_environment="staging",
            keys=keys,
        )
        assert valid is False
        assert err == "AttestationEnvironmentMismatch"

    def test_server_envelope_wrong_pinned_keys_fails_locally(
        self,
        server_signed_envelope: tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str],
    ) -> None:
        envelope, _keys, digest, env = server_signed_envelope
        # Pin DIFFERENT public keys — verification must fail
        bogus_priv = Ed25519PrivateKey.generate()
        bogus_pub = bogus_priv.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        # Same length but different bytes for ml-dsa-65 (random will fail verify)
        bogus_keys = AttestationVerifyKey(
            ed25519_public=bogus_pub,
            mldsa65_public=b"\x00" * 1952,
        )
        valid, err = verify_attestation_locally(
            envelope=envelope,
            expected_digest=digest,
            expected_environment=env,
            keys=bogus_keys,
        )
        assert valid is False
        # Fail-fast on Ed25519 (first AND-of-2 half checked)
        assert err == "AttestationEd25519VerifyFailed"

    def test_server_envelope_tampered_payload_fails_canonical_check(
        self,
        server_signed_envelope: tuple[SdkDSSEEnvelope, AttestationVerifyKey, str, str],
    ) -> None:
        envelope, keys, digest, env = server_signed_envelope
        # Tamper with payload: decode + add whitespace + re-encode
        decoded = base64.b64decode(envelope.payload)
        tampered = decoded + b" "  # extra trailing space
        bad = SdkDSSEEnvelope(
            payload_type=envelope.payload_type,
            payload=base64.b64encode(tampered).decode("ascii"),
            signatures=envelope.signatures,
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=digest,
            expected_environment=env,
            keys=keys,
        )
        assert valid is False
        # Tampering surfaces as canonical mismatch (caught BEFORE signature verify)
        assert err in {
            "AttestationCanonicalBytesMismatch",
            "AttestationPayloadJsonInvalid",
        }
