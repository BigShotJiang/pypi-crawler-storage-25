"""Shared test fixtures for the AEGIS SDK test suite."""

from __future__ import annotations

import pytest


@pytest.fixture()
def api_key() -> str:
    return "uk_live_test_abc123xyz"


@pytest.fixture()
def evaluate_response_data() -> dict:
    return {
        "status": "proceed",
        "confidence": 0.87,
        "gates_passed": 6,
        "gates_failed": 0,
        "failing_gates": [],
        "rationale": "All 6 gates passed. Proposal approved.",
        "next_steps": ["Proceed with implementation"],
        "constraints": [],
        "decision_id": "dec_abc123",
        "timestamp": "2026-03-23T12:00:00Z",
        "override_eligible": False,
        "override_requires": [],
        "gates": {
            "risk": {
                "passed": True,
                "value": 0.05,
                "threshold": 0.3,
                "confidence": 0.92,
                "message": "Risk within acceptable bounds",
            },
            "profit": {
                "passed": True,
                "value": 0.98,
                "threshold": 0.8,
                "confidence": 0.95,
                "message": "Profit projection maintained",
            },
            "novelty": {
                "passed": True,
                "value": 0.75,
                "threshold": 0.6,
                "confidence": 0.88,
                "message": "Sufficient novelty",
            },
            "complexity": {
                "passed": True,
                "value": 0.8,
                "threshold": 0.5,
                "confidence": 0.90,
                "message": "Complexity within bounds",
            },
            "quality": {
                "passed": True,
                "value": 0.9,
                "threshold": 0.7,
                "confidence": 0.93,
                "message": "Quality standards met",
            },
            "utility": {
                "passed": True,
                "value": 0.85,
                "threshold": 0.5,
                "confidence": 0.91,
                "message": "Utility score acceptable",
            },
        },
    }


@pytest.fixture()
def risk_check_response_data() -> dict:
    return {
        "safe": True,
        "risk_score": 0.15,
        "threshold": 0.3,
        "rationale": "Risk below threshold",
    }


@pytest.fixture()
def health_response_data() -> dict:
    return {
        "status": "ok",
        "version": "1.1.0",
        "stage": "dev",
        "checks": {"config": {"ok": True}, "gates": {"ok": True}},
    }


# ── Attestation fixtures (Sprint 4 / D1) ─────────────────────────────


_TEST_DECISION_ID = "12345678-1234-1234-1234-123456789abc"
_TEST_DIGEST = "a" * 64  # 64 lowercase hex
_TEST_PAYLOAD_B64 = "eyJfdHlwZSI6Imh0dHBzOi8vaW4tdG90by5pby9TdGF0ZW1lbnQvdjEifQ=="


@pytest.fixture()
def attestation_request_data() -> dict:
    """Canonical POST /attest request body (matches AttestationRequest)."""
    return {
        "decision_id": _TEST_DECISION_ID,
        "subject_digest_sha256": _TEST_DIGEST,
        "environment": "production",
        "risk_class": "medium",
        "policy_version": "1.2.0",
        "repository": "undercurrentai/aegis-governance",
        "workflow_ref": ".github/workflows/aegis-deploy.yml@refs/heads/main",
        "run_id": "25579660561",
        "run_attempt": 1,
        "gate_pass_states": {
            "risk": "pass",
            "profit": "pass",
            "novelty": "pass",
            "complexity": "pass",
            "quality": "pass",
            "utility": "pass",
        },
        "external_parameters": {"sha": "abc123"},
        "builder_id": "https://github.com/undercurrentai/aegis-governance/actions",
        "expires_at": "2026-05-10T12:00:00+00:00",
    }


def _envelope_dict() -> dict:
    """Canonical DSSE envelope shape with two-sig (ed25519 + ml-dsa-65)."""
    return {
        "payloadType": "application/vnd.in-toto+json",
        "payload": _TEST_PAYLOAD_B64,
        "signatures": [
            {"keyid": "ed25519:test-key-1", "sig": "ZWQyNTUxOS1zaWctYjY0"},
            {"keyid": "ml-dsa-65:test-key-2", "sig": "bWxkc2EtNDQtc2lnLWI2NA=="},
        ],
    }


@pytest.fixture()
def attestation_result_data() -> dict:
    """Canonical POST /attest response body (matches AttestationResult)."""
    return {
        "decision_id": _TEST_DECISION_ID,
        "envelope": _envelope_dict(),
        "statement_canonical_sha256": "b" * 64,
        "issued_at": "2026-05-09T10:00:00+00:00",
        "expires_at": "2026-05-10T10:00:00+00:00",
    }


@pytest.fixture()
def attestation_verify_result_data() -> dict:
    """Canonical POST /attestations/verify response body (valid=True)."""
    return {
        "valid": True,
        "error_class": None,
        "verified_at": "2026-05-09T10:05:00+00:00",
    }


# ── Sprint 4 / D2: offline-verifier fixtures ─────────────────────────


@pytest.fixture(scope="session")
def verify_test_keys() -> dict:
    """Fresh Ed25519 + ML-DSA-65 keypair for offline verifier tests.

    Requires the [verify] extra (cryptography + liboqs-python). Generates
    new keys per session; tests that need deterministic vectors should
    construct their own.
    """
    import oqs
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    ed_priv = Ed25519PrivateKey.generate()
    ed_pub = ed_priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    with oqs.Signature("ML-DSA-65") as ml:
        ml_pub = ml.generate_keypair()
        ml_priv = ml.export_secret_key()
    return {
        "ed25519_priv": ed_priv,
        "ed25519_pub": ed_pub,
        "mldsa65_priv": ml_priv,
        "mldsa65_pub": ml_pub,
    }


@pytest.fixture()
def attestation_record_data() -> dict:
    """Canonical GET /attestations/{decision_id} response body."""
    governance = {
        "decision_id": _TEST_DECISION_ID,
        "artifact_digest": _TEST_DIGEST,
        "environment": "production",
        "risk_class": "medium",
        "policy_version": "1.2.0",
        "issued_at": "2026-05-09T10:00:00+00:00",
        "expires_at": "2026-05-10T10:00:00+00:00",
        "gate_pass_states": {
            "risk": "pass",
            "profit": "pass",
            "novelty": "pass",
            "complexity": "pass",
            "quality": "pass",
            "utility": "pass",
        },
        "repository": "undercurrentai/aegis-governance",
        "workflow_ref": ".github/workflows/aegis-deploy.yml@refs/heads/main",
        "run_id": "25579660561",
        "run_attempt": 1,
    }
    return {
        "decision_id": _TEST_DECISION_ID,
        "envelope": _envelope_dict(),
        "predicate": {
            "buildDefinition": {
                "buildType": "https://aegis.undercurrentholdings.com/buildtype/v1",
                "externalParameters": {"sha": "abc123"},
            },
            "runDetails": {
                "builder": {"id": "https://github.com/undercurrentai/aegis-governance/actions"}
            },
            "governance": governance,
        },
        "artifact_digest": _TEST_DIGEST,
        "environment": "production",
        "risk_class": "medium",
        "policy_version": "1.2.0",
        "repository": "undercurrentai/aegis-governance",
        "workflow_ref": ".github/workflows/aegis-deploy.yml@refs/heads/main",
        "run_id": "25579660561",
        "run_attempt": 1,
        "expires_at": "2026-05-10T10:00:00+00:00",
        "created_at": "2026-05-09T10:00:00+00:00",
        "customer_id": "cust_test_123",
    }
