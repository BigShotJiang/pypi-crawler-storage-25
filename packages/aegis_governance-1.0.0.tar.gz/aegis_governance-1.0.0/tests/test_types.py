"""Tests for AEGIS SDK response types."""

from __future__ import annotations

from aegis.types import (
    CustomerProfile,
    Decision,
    DriftResult,
    GateResult,
    Gates,
    HealthStatus,
    RiskCheckResult,
    UsageReport,
)


class TestGateResult:
    def test_from_dict_values(self) -> None:
        gr = GateResult(
            passed=True, value=0.5, threshold=0.3, confidence=0.9, message="ok"
        )
        assert gr.passed is True
        assert gr.value == 0.5
        assert gr.threshold == 0.3
        assert gr.confidence == 0.9
        assert gr.message == "ok"

    def test_frozen(self) -> None:
        gr = GateResult(
            passed=True, value=0.5, threshold=0.3, confidence=0.9, message="ok"
        )
        try:
            gr.value = 0.6  # type: ignore[misc]
            raise AssertionError("Should be frozen")
        except AttributeError:
            pass


class TestGates:
    def test_from_dict_full(self, evaluate_response_data: dict) -> None:
        gates = Gates.from_dict(evaluate_response_data["gates"])
        assert gates.risk is not None
        assert gates.risk.passed is True
        assert gates.risk.value == 0.05
        assert gates.profit is not None
        assert gates.novelty is not None
        assert gates.complexity is not None
        assert gates.quality is not None
        assert gates.utility is not None

    def test_from_dict_partial(self) -> None:
        raw = {
            "passed": False,
            "value": 0.9,
            "threshold": 0.3,
            "confidence": 0.5,
            "message": "high",
        }
        gates = Gates.from_dict({"risk": raw})
        assert gates.risk is not None
        assert gates.risk.passed is False
        assert gates.profit is None

    def test_from_dict_empty(self) -> None:
        gates = Gates.from_dict({})
        assert gates.risk is None
        assert gates.profit is None


class TestDriftResult:
    def test_from_dict(self) -> None:
        dr = DriftResult.from_dict(
            {
                "status": "warning",
                "kl_divergence": 0.42,
                "action": "recalibrate",
                "message": "Drift detected",
            }
        )
        assert dr.status == "warning"
        assert dr.kl_divergence == 0.42
        assert dr.action == "recalibrate"


class TestDecision:
    def test_from_response_full(self, evaluate_response_data: dict) -> None:
        d = Decision.from_response(evaluate_response_data, request_id="req_123")
        assert d.status == "proceed"
        assert d.confidence == 0.87
        assert d.gates_passed == 6
        assert d.gates_failed == 0
        assert d.failing_gates == []
        assert d.decision_id == "dec_abc123"
        assert d.request_id == "req_123"
        assert d.gates is not None
        assert d.gates.risk is not None

    def test_from_response_minimal(self) -> None:
        d = Decision.from_response({"status": "halt"})
        assert d.status == "halt"
        assert d.confidence == 0.0
        assert d.gates is None
        assert d.drift is None

    def test_from_response_with_drift(self) -> None:
        data = {
            "status": "pause",
            "confidence": 0.6,
            "gates_passed": 4,
            "gates_failed": 2,
            "failing_gates": ["risk", "novelty"],
            "rationale": "Risk elevated",
            "next_steps": [],
            "constraints": [],
            "decision_id": "dec_xyz",
            "timestamp": "2026-03-23T12:00:00Z",
            "override_eligible": True,
            "override_requires": ["governance_lead"],
            "drift": {
                "status": "warning",
                "kl_divergence": 0.42,
                "action": "recalibrate",
                "message": "Drift detected",
            },
        }
        d = Decision.from_response(data)
        assert d.drift is not None
        assert d.drift.status == "warning"
        assert d.drift.kl_divergence == 0.42


class TestRiskCheckResult:
    def test_from_response(self, risk_check_response_data: dict) -> None:
        r = RiskCheckResult.from_response(
            risk_check_response_data, request_id="req_456"
        )
        assert r.safe is True
        assert r.risk_score == 0.15
        assert r.threshold == 0.3
        assert r.request_id == "req_456"


class TestHealthStatus:
    def test_from_response(self, health_response_data: dict) -> None:
        h = HealthStatus.from_response(health_response_data)
        assert h.status == "ok"
        assert h.version == "1.1.0"
        assert h.checks["config"]["ok"] is True


class TestCustomerProfile:
    def test_from_response(self) -> None:
        data = {
            "customer": {
                "customer_id": "cust_001",
                "name": "Test User",
                "email": "test@example.com",
                "company": "Acme",
                "tier": "professional",
                "status": "active",
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-03-23T00:00:00Z",
            },
            "tier_details": {
                "name": "professional",
                "display_name": "Professional",
                "monthly_evaluations": 10000,
                "rate_per_minute": 100,
                "max_keys": 5,
                "overage_per_eval": 0.25,
                "monthly_price_usd": 3500,
                "features": ["gates", "mcp_server"],
            },
        }
        p = CustomerProfile.from_response(data)
        assert p.customer_id == "cust_001"
        assert p.tier == "professional"
        assert p.tier_details is not None
        assert p.tier_details.monthly_price_usd == 3500
        assert p.tier_details.monthly_evaluations == 10000


class TestUsageReport:
    def test_from_response(self) -> None:
        data = {
            "customer_id": "cust_001",
            "month": "2026-03",
            "total_evaluations": 500,
            "total_risk_checks": 100,
            "total_calls": 600,
            "channels": {"sdk": 350, "api": 150, "mcp": 100},
            "quota": 10000,
            "quota_remaining": 9500,
            "quota_percent": 5,
        }
        u = UsageReport.from_response(data)
        assert u.total_evaluations == 500
        assert u.channels["sdk"] == 350
        assert u.quota_remaining == 9500
