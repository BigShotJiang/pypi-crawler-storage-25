"""Tests for verify_attestation_locally + AttestationVerifyKey (Sprint 4 / D2).

Requires the [verify] extra (cryptography + liboqs-python + rfc8785). Tests
construct fresh signing material in-process so each verification path can be
exercised with real crypto — no mocks. ~40 tests across 5 classes covering
shape validation, PAE/canonical determinism, AND-of-2, error mapping parity
with server-side strings, and tampering scenarios.
"""

from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any

import oqs
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from aegis import AttestationVerifyKey, DSSEEnvelope, verify_attestation_locally
from aegis._verify_local import (
    CONTEXT_STRING,
    ED25519_KEYID_PREFIX,
    ED25519_PUBLIC_LEN,
    MLDSA65_PUBLIC_LEN,
    MLDSA_KEYID_PREFIX,
    PAYLOAD_TYPE,
    _build_dsse_pae,
    _canonical_statement_bytes,
    _nfc_normalize_strings,
    _verify_ed25519_with_context,
    _verify_mldsa65_with_context,
)
from aegis.types import DSSESignature

_VALID_UUID = "12345678-1234-1234-1234-123456789abc"
_VALID_DIGEST = "a" * 64


# ── Helpers ──────────────────────────────────────────────────────────


def _build_signed_envelope(
    *,
    ed25519_priv: Ed25519PrivateKey,
    mldsa65_sigobj: oqs.Signature,
    statement_dict: dict[str, Any],
) -> DSSEEnvelope:
    """Build a fully signed DSSEEnvelope for the given statement.

    Mirrors server-side AttestationProvider.issue() byte-for-byte per ADR-012:
    NFC-normalize statement, RFC 8785 canonicalize, build DSSE PAE, then apply
    uniform prefix-hash-and-sign for BOTH algorithms — message signed is
    ``msg' = SHA-256(CONTEXT_STRING ‖ PAE)``. GCP KMS does not expose FIPS 204
    ctx-string parameter, so the SDK verifier uses plain `oqs.Signature.verify`
    over the prefix-hash digest, NOT `verify_with_ctx_str`. The test fixture
    MUST mirror this signing scheme or sign/verify mismatch causes spurious
    `AttestationMLDSAVerifyFailed` results.
    """
    canonical = _canonical_statement_bytes(statement_dict)
    pae = _build_dsse_pae(PAYLOAD_TYPE, canonical)
    # Uniform prefix-hash: same input to both signers (matches ADR-012)
    prefix_hash = hashlib.sha256(CONTEXT_STRING + pae).digest()
    # Ed25519: sign the prefix-hash directly
    ed_sig = ed25519_priv.sign(prefix_hash)
    # ML-DSA-65: sign the prefix-hash directly (NOT sign_with_ctx_str, which
    # internally re-hashes with a domain separator + ctx; would cause
    # mismatch with the SDK's `oqs.Signature.verify(prefix_hash, sig, pk)`).
    ml_sig = mldsa65_sigobj.sign(prefix_hash)
    return DSSEEnvelope(
        payload_type=PAYLOAD_TYPE,
        payload=base64.b64encode(canonical).decode("ascii"),
        signatures=[
            DSSESignature(
                keyid=f"{ED25519_KEYID_PREFIX}test-1",
                sig=base64.b64encode(ed_sig).decode("ascii"),
            ),
            DSSESignature(
                keyid=f"{MLDSA_KEYID_PREFIX}test-2",
                sig=base64.b64encode(ml_sig).decode("ascii"),
            ),
        ],
    )


def _make_statement(
    *,
    decision_id: str = _VALID_UUID,
    digest: str = _VALID_DIGEST,
    environment: str = "production",
    expires_at: str | None = None,
) -> dict[str, Any]:
    """Build a minimal valid in-toto Statement v1 dict."""
    if expires_at is None:
        expires_at = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    return {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": [{"name": "art", "digest": {"sha256": digest}}],
        "predicateType": "https://aegis.undercurrentholdings.com/attestation/v1",
        "predicate": {
            "buildDefinition": {
                "buildType": "https://x.y/z",
                "externalParameters": {"sha": "abc"},
            },
            "runDetails": {"builder": {"id": "https://x"}},
            "governance": {
                "decision_id": decision_id,
                "artifact_digest": digest,
                "environment": environment,
                "risk_class": "medium",
                "policy_version": "1.2.0",
                "issued_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": expires_at,
                "gate_pass_states": {
                    "risk": "pass",
                    "profit": "pass",
                    "novelty": "pass",
                    "complexity": "pass",
                    "quality": "pass",
                    "utility": "pass",
                },
                "repository": "undercurrentai/foo",
                "workflow_ref": "x",
                "run_id": "1",
                "run_attempt": 1,
            },
        },
    }


@pytest.fixture()
def signed_envelope_factory(verify_test_keys: dict):
    """Factory: build_envelope(**statement_overrides) -> DSSEEnvelope."""
    ed_priv = verify_test_keys["ed25519_priv"]

    # Per-test ML-DSA-65 signer instance with the keypair from the session fixture
    def _factory(**overrides: Any) -> DSSEEnvelope:
        statement = _make_statement(**overrides)
        # Construct Signature with pre-existing secret_key (oqs API for keypair reuse)
        with oqs.Signature(
            "ML-DSA-65", secret_key=verify_test_keys["mldsa65_priv"]
        ) as ml_sig:
            return _build_signed_envelope(
                ed25519_priv=ed_priv, mldsa65_sigobj=ml_sig, statement_dict=statement
            )

    return _factory


@pytest.fixture()
def verify_keys(verify_test_keys: dict) -> AttestationVerifyKey:
    return AttestationVerifyKey(
        ed25519_public=verify_test_keys["ed25519_pub"],
        mldsa65_public=verify_test_keys["mldsa65_pub"],
    )


# ── TestAttestationVerifyKey ─────────────────────────────────────────


class TestAttestationVerifyKey:
    def test_valid_construction(self) -> None:
        k = AttestationVerifyKey(
            ed25519_public=b"\x00" * ED25519_PUBLIC_LEN,
            mldsa65_public=b"\x00" * MLDSA65_PUBLIC_LEN,
        )
        assert len(k.ed25519_public) == 32
        assert len(k.mldsa65_public) == 1952

    def test_ed25519_wrong_size_raises(self) -> None:
        with pytest.raises(ValueError, match="ed25519_public"):
            AttestationVerifyKey(
                ed25519_public=b"\x00" * 31,
                mldsa65_public=b"\x00" * MLDSA65_PUBLIC_LEN,
            )

    def test_mldsa65_wrong_size_raises(self) -> None:
        with pytest.raises(ValueError, match="mldsa65_public"):
            AttestationVerifyKey(
                ed25519_public=b"\x00" * ED25519_PUBLIC_LEN,
                mldsa65_public=b"\x00" * 1311,
            )

    def test_frozen_dataclass_immutable(self) -> None:
        k = AttestationVerifyKey(
            ed25519_public=b"\x00" * 32, mldsa65_public=b"\x00" * 1952
        )
        with pytest.raises((AttributeError, Exception)):
            k.ed25519_public = b"\x01" * 32  # type: ignore[misc]

    def test_constants_match_server(self) -> None:
        # Server src/crypto/attestation_provider.py:42
        assert CONTEXT_STRING == b"aegis-attestation-v1"
        assert ED25519_KEYID_PREFIX == "ed25519:"
        assert MLDSA_KEYID_PREFIX == "ml-dsa-65:"
        assert PAYLOAD_TYPE == "application/vnd.in-toto+json"
        assert ED25519_PUBLIC_LEN == 32
        assert MLDSA65_PUBLIC_LEN == 1952


# ── TestPaeAndCanonical ──────────────────────────────────────────────


class TestPaeAndCanonical:
    def test_pae_format_byte_exact(self) -> None:
        # Reference vector from DSSE v1 spec; "application/vnd.in-toto+json" = 28 chars
        pae = _build_dsse_pae("application/vnd.in-toto+json", b"hello")
        expected = b"DSSEv1 28 application/vnd.in-toto+json 5 hello"
        assert pae == expected

    def test_pae_with_empty_body(self) -> None:
        pae = _build_dsse_pae("text/plain", b"")
        assert pae == b"DSSEv1 10 text/plain 0 "

    def test_canonical_deterministic(self) -> None:
        d = {"b": 2, "a": 1, "c": [3, 1, 2]}
        c1 = _canonical_statement_bytes(d)
        c2 = _canonical_statement_bytes(d)
        assert c1 == c2

    def test_canonical_sorts_keys(self) -> None:
        d = {"b": 2, "a": 1}
        c = _canonical_statement_bytes(d)
        # RFC 8785: keys sorted lexicographically
        assert c.index(b'"a"') < c.index(b'"b"')

    def test_nfc_normalization_unicode(self) -> None:
        # Café in NFD vs NFC
        nfd = "Café"
        nfc = "Café"
        d_nfd = {"name": nfd}
        d_nfc = {"name": nfc}
        c_nfd = _canonical_statement_bytes(d_nfd)
        c_nfc = _canonical_statement_bytes(d_nfc)
        assert c_nfd == c_nfc, "NFC normalization must converge both forms"

    def test_nfc_recursive_in_lists_and_dicts(self) -> None:
        nfd = "Café"
        nested = {"outer": {"inner": [nfd, {"deep": nfd}]}}
        normalized = _nfc_normalize_strings(nested)
        assert normalized["outer"]["inner"][0] == "Café"
        assert normalized["outer"]["inner"][1]["deep"] == "Café"

    def test_nfc_passes_non_strings(self) -> None:
        assert _nfc_normalize_strings(42) == 42
        assert _nfc_normalize_strings(None) is None
        assert _nfc_normalize_strings(True) is True


# ── TestEd25519AndMldsa primitives ────────────────────────────────────


class TestEd25519AndMldsa:
    def test_ed25519_happy_path(self, verify_test_keys: dict) -> None:
        pae = b"DSSEv1 5 hello 5 world"
        msg = hashlib.sha256(CONTEXT_STRING + pae).digest()
        sig = verify_test_keys["ed25519_priv"].sign(msg)
        assert (
            _verify_ed25519_with_context(sig, pae, verify_test_keys["ed25519_pub"])
            is True
        )

    def test_ed25519_tampered_signature(self, verify_test_keys: dict) -> None:
        pae = b"DSSEv1 5 hello 5 world"
        msg = hashlib.sha256(CONTEXT_STRING + pae).digest()
        sig = verify_test_keys["ed25519_priv"].sign(msg)
        # Flip a bit in signature
        bad = bytearray(sig)
        bad[0] ^= 0x01
        assert (
            _verify_ed25519_with_context(
                bytes(bad), pae, verify_test_keys["ed25519_pub"]
            )
            is False
        )

    def test_ed25519_tampered_pae(self, verify_test_keys: dict) -> None:
        pae = b"DSSEv1 5 hello 5 world"
        msg = hashlib.sha256(CONTEXT_STRING + pae).digest()
        sig = verify_test_keys["ed25519_priv"].sign(msg)
        # Verify against a DIFFERENT PAE
        assert (
            _verify_ed25519_with_context(
                sig, b"DSSEv1 5 hello 5 wOrld", verify_test_keys["ed25519_pub"]
            )
            is False
        )

    def test_ed25519_invalid_public_key_size(self) -> None:
        # Truncated public key — cryptography raises ValueError; we return False
        assert _verify_ed25519_with_context(b"\x00" * 64, b"pae", b"\x00" * 31) is False

    def test_mldsa65_happy_path(self, verify_test_keys: dict) -> None:
        pae = b"DSSEv1 5 hello 5 world"
        with oqs.Signature(
            "ML-DSA-65", secret_key=verify_test_keys["mldsa65_priv"]
        ) as sig_obj:
            # Per ADR-012: uniform prefix-hash-and-sign; verifier uses
            # `oqs.Signature.verify(prefix_hash, ...)`, NOT verify_with_ctx_str.
            prefix_hash = hashlib.sha256(CONTEXT_STRING + pae).digest()
            sig = sig_obj.sign(prefix_hash)
        assert (
            _verify_mldsa65_with_context(sig, pae, verify_test_keys["mldsa65_pub"])
            is True
        )

    def test_mldsa65_tampered_pae(self, verify_test_keys: dict) -> None:
        pae = b"DSSEv1 5 hello 5 world"
        with oqs.Signature(
            "ML-DSA-65", secret_key=verify_test_keys["mldsa65_priv"]
        ) as sig_obj:
            # Per ADR-012: uniform prefix-hash-and-sign; verifier uses
            # `oqs.Signature.verify(prefix_hash, ...)`, NOT verify_with_ctx_str.
            prefix_hash = hashlib.sha256(CONTEXT_STRING + pae).digest()
            sig = sig_obj.sign(prefix_hash)
        assert (
            _verify_mldsa65_with_context(
                sig, b"DSSEv1 5 hello 5 worLd", verify_test_keys["mldsa65_pub"]
            )
            is False
        )


# ── TestEnvelopeFullVerify ───────────────────────────────────────────


class TestEnvelopeFullVerify:
    def test_happy_round_trip(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is True, f"unexpected failure: {err}"
        assert err is None

    def test_digest_mismatch(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest="0" * 64,  # wrong
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationDigestMismatch"

    def test_environment_mismatch(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="staging",  # envelope is "production"
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationEnvironmentMismatch"

    def test_expired(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Expires-at slightly in the future from "issued time", but we set `now` past it
        future_now = datetime.now(timezone.utc) + timedelta(hours=10)
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
            now=future_now,
        )
        assert valid is False
        assert err == "AttestationExpired"

    def test_expires_at_naive_iso(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # tz-naive ISO 8601 (no offset) → AttestationExpiresAtMalformed
        env = signed_envelope_factory(expires_at="2030-01-01T00:00:00")
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationExpiresAtMalformed"

    def test_payload_type_mismatch(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        bad = DSSEEnvelope(
            payload_type="application/json",  # wrong
            payload=env.payload,
            signatures=env.signatures,
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationPayloadTypeMismatch"

    def test_wrong_signature_count_returns_signature_set_incomplete(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Audit fix F5: returns error_class to mirror server, does NOT raise
        env = signed_envelope_factory()
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=env.signatures[:1],  # only 1
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationSignatureSetIncomplete"

    def test_missing_keyid_prefix_returns_signature_set_incomplete(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Audit fix F5: returns error_class to mirror server, does NOT raise
        env = signed_envelope_factory()
        bad_sigs = [
            DSSESignature(keyid="rsa:k1", sig=env.signatures[0].sig),
            env.signatures[1],
        ]
        bad = DSSEEnvelope(
            payload_type=env.payload_type, payload=env.payload, signatures=bad_sigs
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationSignatureSetIncomplete"

    def test_payload_decode_failed(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload="!!!not-valid-base64!!!",
            signatures=env.signatures,
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationPayloadDecodeFailed"

    def test_payload_json_invalid(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        # Valid base64 but not JSON
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=base64.b64encode(b"not-json-content").decode("ascii"),
            signatures=env.signatures,
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationPayloadJsonInvalid"

    def test_canonical_bytes_mismatch_extra_whitespace(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        # Decode + re-encode with non-canonical whitespace
        decoded = base64.b64decode(env.payload)
        as_dict = json.loads(decoded)
        non_canonical = json.dumps(as_dict, indent=2).encode("utf-8")  # adds whitespace
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=base64.b64encode(non_canonical).decode("ascii"),
            signatures=env.signatures,
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationCanonicalBytesMismatch"


# ── TestAndOf2 — both-must-verify invariant ───────────────────────────


class TestAndOf2:
    def test_corrupted_ed25519_sig_only_fails(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        ed_entry = next(s for s in env.signatures if s.keyid.startswith("ed25519:"))
        ml_entry = next(s for s in env.signatures if s.keyid.startswith("ml-dsa-65:"))
        bad_ed_sig_bytes = bytearray(base64.b64decode(ed_entry.sig))
        bad_ed_sig_bytes[0] ^= 0x01
        bad_ed = DSSESignature(
            keyid=ed_entry.keyid,
            sig=base64.b64encode(bytes(bad_ed_sig_bytes)).decode("ascii"),
        )
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=[bad_ed, ml_entry],
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationEd25519VerifyFailed"

    def test_corrupted_mldsa65_sig_only_fails(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        ed_entry = next(s for s in env.signatures if s.keyid.startswith("ed25519:"))
        ml_entry = next(s for s in env.signatures if s.keyid.startswith("ml-dsa-65:"))
        bad_ml_sig_bytes = bytearray(base64.b64decode(ml_entry.sig))
        bad_ml_sig_bytes[0] ^= 0x01
        bad_ml = DSSESignature(
            keyid=ml_entry.keyid,
            sig=base64.b64encode(bytes(bad_ml_sig_bytes)).decode("ascii"),
        )
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=[ed_entry, bad_ml],
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationMLDSAVerifyFailed"

    def test_ed25519_failure_short_circuits_before_mldsa(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Both signatures bad — verifier should fail-fast on Ed25519 first.
        env = signed_envelope_factory()
        ed_entry = next(s for s in env.signatures if s.keyid.startswith("ed25519:"))
        ml_entry = next(s for s in env.signatures if s.keyid.startswith("ml-dsa-65:"))
        bad_ed_sig = bytearray(base64.b64decode(ed_entry.sig))
        bad_ed_sig[0] ^= 0x01
        bad_ml_sig = bytearray(base64.b64decode(ml_entry.sig))
        bad_ml_sig[0] ^= 0x01
        bad_ed = DSSESignature(
            keyid=ed_entry.keyid,
            sig=base64.b64encode(bytes(bad_ed_sig)).decode("ascii"),
        )
        bad_ml = DSSESignature(
            keyid=ml_entry.keyid,
            sig=base64.b64encode(bytes(bad_ml_sig)).decode("ascii"),
        )
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=[bad_ed, bad_ml],
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        # Fail-fast on first failure (Ed25519)
        assert err == "AttestationEd25519VerifyFailed"

    def test_wrong_pinned_keys_fails(
        self, signed_envelope_factory: Any, verify_test_keys: dict
    ) -> None:
        env = signed_envelope_factory()
        # Generate a DIFFERENT keypair and pin those — verification must fail
        other_priv = Ed25519PrivateKey.generate()
        from cryptography.hazmat.primitives import serialization

        other_pub = other_priv.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        wrong_keys = AttestationVerifyKey(
            ed25519_public=other_pub,
            mldsa65_public=verify_test_keys["mldsa65_pub"],  # this one matches
        )
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=wrong_keys,
        )
        assert valid is False
        assert err == "AttestationEd25519VerifyFailed"


# ── TestErrorClassParity — every emitted string matches server contract ──


class TestErrorClassParity:
    """Sprint 4/D2 audit: ensure error_class strings emitted by SDK exactly
    match the server-side AttestationProvider.verify() strings, so consumer
    code can check error_class identically across HTTP-verify (D1) and
    offline-verify (D2)."""

    EXPECTED_ERROR_CLASSES = frozenset(
        {
            "AttestationPayloadTypeMismatch",
            "AttestationSignatureSetIncomplete",  # F5 audit: replaces ValueError raises
            "AttestationPayloadDecodeFailed",
            "AttestationPayloadJsonInvalid",
            "AttestationCanonicalBytesMismatch",
            "AttestationStatementShapeInvalid",
            "AttestationEd25519SigDecodeFailed",
            "AttestationEd25519VerifyFailed",
            "AttestationMLDSASigDecodeFailed",
            "AttestationMLDSAVerifyFailed",
            "AttestationSubjectMissing",
            "AttestationDigestMismatch",
            "AttestationEnvironmentMismatch",
            "AttestationExpiresAtMalformed",
            "AttestationExpired",
        }
    )

    def test_error_class_set_documented(self) -> None:
        # Sanity: the documented set is non-empty + alphanumeric-only
        assert len(self.EXPECTED_ERROR_CLASSES) >= 15
        for ec in self.EXPECTED_ERROR_CLASSES:
            assert ec.startswith("Attestation"), f"server-parity prefix: {ec}"
            assert ec.replace("Attestation", "").isalnum(), f"identifier-clamped: {ec}"

    def test_no_error_class_with_unexpected_chars(self) -> None:
        # Ensure all error classes are safe-clamped (server-side _safe_error_class
        # contract: identifier-clamped, no spaces / special chars / max 64 chars)
        for ec in self.EXPECTED_ERROR_CLASSES:
            assert " " not in ec
            assert len(ec) <= 64
            assert ec.replace("_", "").isalnum() or ec.isidentifier()


# ── TestNowParameter ──────────────────────────────────────────────────


class TestNowParameter:
    def test_now_default_uses_datetime_now_utc(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Don't pass `now` — should use datetime.now(UTC); envelope expires +1h
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is True

    def test_now_explicit_at_expiry_boundary(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Set `now` to AFTER expiry — should fail
        env = signed_envelope_factory(
            expires_at=(datetime.now(timezone.utc) + timedelta(seconds=1)).isoformat()
        )
        future_now = datetime.now(timezone.utc) + timedelta(hours=24)
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
            now=future_now,
        )
        assert valid is False
        assert err == "AttestationExpired"


# ── TestUppercaseDigestNormalize ──────────────────────────────────────


class TestCoverageGapClosers:
    """Cover the rare-but-real failure paths: bad base64 sigs, empty subject,
    corrupt mldsa public key. Pushes _verify_local.py from 90% to ≥95% coverage."""

    def test_bad_base64_in_ed25519_sig(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        ml_entry = next(s for s in env.signatures if s.keyid.startswith("ml-dsa-65:"))
        bad_ed = DSSESignature(keyid="ed25519:k", sig="!!!not-base64!!!")
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=[bad_ed, ml_entry],
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationEd25519SigDecodeFailed"

    def test_bad_base64_in_mldsa65_sig(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        env = signed_envelope_factory()
        ed_entry = next(s for s in env.signatures if s.keyid.startswith("ed25519:"))
        bad_ml = DSSESignature(keyid="ml-dsa-65:k", sig="!!!not-base64!!!")
        bad = DSSEEnvelope(
            payload_type=env.payload_type,
            payload=env.payload,
            signatures=[ed_entry, bad_ml],
        )
        valid, err = verify_attestation_locally(
            envelope=bad,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is False
        assert err == "AttestationMLDSASigDecodeFailed"

    def test_subject_empty_returns_subject_missing(
        self, verify_test_keys: dict
    ) -> None:
        # Build a canonical statement with empty subject list, sign it, verify.
        ed_priv = verify_test_keys["ed25519_priv"]
        empty_subject_stmt = _make_statement()
        empty_subject_stmt["subject"] = []
        with oqs.Signature(
            "ML-DSA-65", secret_key=verify_test_keys["mldsa65_priv"]
        ) as ml_sig:
            env = _build_signed_envelope(
                ed25519_priv=ed_priv,
                mldsa65_sigobj=ml_sig,
                statement_dict=empty_subject_stmt,
            )
        keys = AttestationVerifyKey(
            ed25519_public=verify_test_keys["ed25519_pub"],
            mldsa65_public=verify_test_keys["mldsa65_pub"],
        )
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="production",
            keys=keys,
        )
        assert valid is False
        assert err == "AttestationSubjectMissing"


class TestUppercaseDigestNormalize:
    def test_expected_digest_uppercase_normalizes(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Caller passes UPPERCASE expected_digest; SDK lowercases for comparison
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST.upper(),
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is True
        assert err is None

    def test_expected_digest_whitespace_normalizes(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Mirror server: caller whitespace is stripped before digest compare
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=f"  {_VALID_DIGEST.upper()}  ",
            expected_environment="production",
            keys=verify_keys,
        )
        assert valid is True
        assert err is None

    def test_expected_environment_whitespace_normalizes(
        self, signed_envelope_factory: Any, verify_keys: AttestationVerifyKey
    ) -> None:
        # Mirror server: expected_environment is stripped before compare
        env = signed_envelope_factory()
        valid, err = verify_attestation_locally(
            envelope=env,
            expected_digest=_VALID_DIGEST,
            expected_environment="  production  ",
            keys=verify_keys,
        )
        assert valid is True
        assert err is None


# ── TestPep562Module (Phase 2 audit fixes F6 + F7) ────────────────────


class TestPep562Module:
    """Regression tests for the conditional __all__ + AttributeError-on-miss
    pattern that closes the hasattr / from-aegis-import-* footguns.

    F6 (audit): `from aegis import *` previously broke for HTTP-only consumers
    because `__all__` unconditionally listed verify-extra names. Fix: list them
    only when `_HAS_VERIFY_EXTRA = True`.

    F7 (audit): `hasattr(aegis, "verify_attestation_locally")` previously raised
    ImportError instead of returning False (PEP 8 only swallows AttributeError).
    Fix: __getattr__ raises AttributeError with install-hint embedded.
    """

    def test_has_verify_extra_flag_true_when_deps_installed(self) -> None:
        import aegis

        # Test env has [verify] extra installed via [dev,verify] in CI
        assert aegis._HAS_VERIFY_EXTRA is True

    def test_verify_symbols_in_all_when_extra_installed(self) -> None:
        import aegis

        assert "AttestationVerifyKey" in aegis.__all__
        assert "verify_attestation_locally" in aegis.__all__

    def test_hasattr_returns_true_for_verify_symbols(self) -> None:
        import aegis

        assert hasattr(aegis, "AttestationVerifyKey") is True
        assert hasattr(aegis, "verify_attestation_locally") is True

    def test_hasattr_returns_false_for_nonexistent_attribute(self) -> None:
        import aegis

        assert hasattr(aegis, "definitely_not_a_real_attribute") is False

    def test_getattr_raises_attribute_error_not_import_error_for_verify_names_when_extra_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Simulate the [verify] extra missing by patching the flag.
        # A consumer hitting the lazy path should get AttributeError (which
        # hasattr() catches) — NOT ImportError (which propagates and breaks
        # feature-detection).
        import aegis

        monkeypatch.setattr(aegis, "_HAS_VERIFY_EXTRA", False)
        with pytest.raises(AttributeError, match="pip install aegis-governance"):
            aegis.__getattr__("verify_attestation_locally")
        with pytest.raises(AttributeError, match="pip install aegis-governance"):
            aegis.__getattr__("AttestationVerifyKey")

    def test_getattr_raises_attribute_error_for_nonverify_unknown(self) -> None:
        import aegis

        with pytest.raises(AttributeError, match="has no attribute"):
            aegis.__getattr__("totally_not_a_real_name")
