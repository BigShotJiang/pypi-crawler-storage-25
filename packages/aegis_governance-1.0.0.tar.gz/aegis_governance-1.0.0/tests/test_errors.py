"""Tests for AEGIS SDK error types."""

from __future__ import annotations

from aegis._errors import (
    AegisError,
    AuthenticationError,
    ConnectionError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)


class TestAegisError:
    def test_message(self) -> None:
        e = AegisError("something failed")
        assert str(e) == "something failed"
        assert e.message == "something failed"
        assert e.status_code is None
        assert e.request_id is None

    def test_with_metadata(self) -> None:
        e = AegisError("fail", status_code=500, request_id="req_123")
        assert e.status_code == 500
        assert e.request_id == "req_123"

    def test_repr_no_metadata(self) -> None:
        e = AegisError("fail")
        assert repr(e) == "AegisError('fail')"

    def test_repr_with_metadata(self) -> None:
        e = AegisError("fail", status_code=500, request_id="req_123")
        assert "status_code=500" in repr(e)
        assert "request_id='req_123'" in repr(e)

    def test_no_api_key_in_message(self) -> None:
        """Ensure error messages never contain API keys."""
        e = AegisError("something failed")
        assert "uk_live" not in str(e)
        assert "uk_live" not in repr(e)


class TestErrorHierarchy:
    def test_authentication_is_aegis_error(self) -> None:
        e = AuthenticationError("invalid key", status_code=401)
        assert isinstance(e, AegisError)
        assert e.status_code == 401

    def test_validation_is_aegis_error(self) -> None:
        e = ValidationError("bad request", status_code=400)
        assert isinstance(e, AegisError)

    def test_rate_limit_has_retry_after(self) -> None:
        e = RateLimitError("slow down", retry_after=30.0)
        assert isinstance(e, AegisError)
        assert e.retry_after == 30.0
        assert e.status_code == 429

    def test_rate_limit_no_retry_after(self) -> None:
        e = RateLimitError("slow down")
        assert e.retry_after is None

    def test_server_error(self) -> None:
        e = ServerError("internal error", status_code=500)
        assert isinstance(e, AegisError)
        assert e.status_code == 500

    def test_connection_error(self) -> None:
        e = ConnectionError("network down")
        assert isinstance(e, AegisError)

    def test_timeout_error(self) -> None:
        e = TimeoutError("timed out")
        assert isinstance(e, AegisError)

    def test_catch_base_catches_all(self) -> None:
        """All error types should be catchable via AegisError."""
        for cls in (
            AuthenticationError,
            ValidationError,
            RateLimitError,
            ServerError,
            ConnectionError,
            TimeoutError,
        ):
            try:
                raise cls("test")
            except AegisError:
                pass
