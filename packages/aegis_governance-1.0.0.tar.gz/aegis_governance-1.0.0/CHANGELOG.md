# AEGIS SDK Changelog

All notable changes to the `aegis-governance` Python SDK published on PyPI.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## 1.0.0 — 2026-05-10

Sprint 5/E1.5 — **MAJOR version bump per SemVer for breaking wire-format change**: ML-DSA-44 → ML-DSA-65 algorithm migration via ADR-012 (parent repo `docs/architecture/adr/ADR-012-ml-dsa-44-to-65-migration.md`). AEGIS Stage-2 decision-id `9eae3455-3da1-4f2e-b74b-53b973300a60` (ESCALATE → OVERRIDE_APPLIED per cosmic-flute §28.5.1).

### BREAKING

- **DSSE envelope keyid prefix** `ml-dsa-44:` → `ml-dsa-65:`. Envelopes produced by SDK v0.x or server pre-1.2.0 will NOT verify against SDK v1.0.0+ (or vice versa). Consumers must coordinate upgrade across publishers + verifiers.
- **`AttestationVerifyKey` field rename**: `mldsa44_public: bytes` → `mldsa65_public: bytes`. Public-key size 1,312B → 1,952B (raw, post-ASN.1 extraction for ML-DSA-65 X.509 SubjectPublicKeyInfo PEM responses from GCP KMS).
- **`verify_attestation_locally()` wire-format change**: SDK offline verifier now uses uniform prefix-hash-and-sign (`oqs.Signature("ML-DSA-65").verify(SHA-256(CONTEXT_STRING ‖ PAE), sig, pk)`) instead of `verify_with_ctx_str(...)`. This mirrors the server-side `KMSAttestationSigner` which can't use FIPS 204 ctx-string API (GCP KMS doesn't expose the `context` field). Cryptographically equivalent under random-oracle assumption with empty default ctx. **Empirically verified 2026-05-10** via Phase 4a smoke probe (both gcloud CLI + Python client transports; verify True).

### Changed

- **`MLDSA_KEYID_PREFIX`** constant `"ml-dsa-44:"` → `"ml-dsa-65:"`.
- **`MLDSA44_PUBLIC_LEN`** constant `1312` → **`MLDSA65_PUBLIC_LEN`** constant `1952`.
- **`oqs.Signature("ML-DSA-44")`** → **`oqs.Signature("ML-DSA-65")`**.
- **Signature length validation**: expect 3,309 bytes (was 2,420 bytes).

### Migration

Consumers upgrading from 0.6.x → 1.0.0:

1. Update any `AttestationVerifyKey(mldsa44_public=...)` calls to `AttestationVerifyKey(mldsa65_public=...)`.
2. Refresh pinned public keys: fetch the new ML-DSA-65 public-key bytes (1,952B raw) from your verifier-policy artifact (e.g., `aegis-policy/keys/mldsa65-public.bin` once Phase 5 ships).
3. If you maintained your own envelope-producer (rare; most consumers verify only), audit your DSSE keyid prefixes from `ml-dsa-44:` to `ml-dsa-65:`.
4. SHA-256 fingerprints in your trust store (e.g., `required_keyids.mldsa65`) must be recomputed over the new 1,952B raw bytes.

### Why MAJOR (not MINOR)

The wire-format change makes 1.0.0 envelopes incompatible with 0.6.x verifiers AND vice versa. SemVer mandates MAJOR for breaking-contract changes; this is the canonical example.

### Empirical groundedness

Phase 4a smoke probe (cosmic-flute §28.18.3) verified the architecture in production preview API before SDK contract change committed. Both gcloud CLI and `google-cloud-kms==3.13.0` Python client signing paths produced identical 3,309-byte signatures; `oqs.Signature("ML-DSA-65").verify(msg, sig, pk)` returned True for both. See `/tmp/phase-4a-probe-log.md`.

---

## 0.6.1 — 2026-05-09

Post-merge audit-pass remediation of `0.6.0` (main commit `fb2dec3`) per /quality-gate exhaustive 9-phase run. **No public API surface change**; all fixes are implementation hardening on the offline verifier introduced in `0.6.0`.

### Fixed

- **`verify_attestation_locally()` server-parity normalization** — `expected_digest` is now `.strip().lower()`-normalized and `expected_environment` is now `.strip()`-normalized at the SDK boundary, mirroring server-side `AttestationProvider._check_bindings()` (`src/crypto/attestation_provider.py:235-236`) byte-for-byte. Without this, callers passing whitespace-padded or uppercase-hex digests (legitimately accepted by the server) saw silent `(False, "AttestationDigestMismatch")` from the SDK.
- **Envelope shape errors return error_class instead of raising `ValueError`** — `verify_attestation_locally()` now returns `(False, "AttestationSignatureSetIncomplete")` when the DSSE envelope has the wrong number of signatures or is missing required `ed25519:` / `ml-dsa-44:` keyid prefixes, matching the server-side error_class taxonomy emitted by `AttestationProvider._verify_both_signatures` (`src/crypto/attestation_provider.py:202-203`). **Contract change**: `0.6.0` raised `ValueError` on these conditions; consumers depending on `except ValueError:` to detect malformed envelopes must migrate to `error_class` checks. The new behavior matches the documented contract in `0.6.0` ("Returns `(False, error_class)` on any failure"); the old behavior was an undocumented escape hatch.
- **`from aegis import *` works for HTTP-only consumers** — the `0.6.0` `__init__.py` unconditionally added `verify_attestation_locally` + `AttestationVerifyKey` to `__all__`, breaking star-imports when the `[verify]` extra was not installed. The PEP 562 lazy-import gate is now combined with conditional eager-import via `_HAS_VERIFY_EXTRA`; missing extras leave `__all__` unchanged.
- **`hasattr(aegis, "verify_attestation_locally")` returns `False` (not `ImportError`)** — when the `[verify]` extra is not installed, `__getattr__` now raises `AttributeError` (with install-hint embedded in the message) instead of `ImportError`. Per PEP 8 + Python language spec, `hasattr()` only swallows `AttributeError`; raising `ImportError` from `__getattr__` would surface an unhandled exception to callers checking attribute existence.
- **CI workflow comment accuracy** — `.github/workflows/python-ci.yml` SDK install step comment corrected: parent's `[pqc]` extra (not `[crypto]`) supplies `cryptography` + `liboqs-python`; `[crypto]` is a separate extra for BIP-322 bitcoin libs.

### Changed

- **`cryptography` pin tightened** `>=42` → `>=46.0.7,<47.0.0` to mirror parent server's `[pqc]` extra pin exactly (parent `pyproject.toml:111`). **Pin lifecycle policy**: this pin tracks the server-side `[pqc]` extra; review quarterly + on any cryptography security advisory. The byte-exact server↔SDK crypto floor is a stated invariant of ADR-011; loosening either side risks invalidating round-trip verification guarantees.

### Migration

Consumers of `aegis-governance==0.6.0[verify]` who relied on `except ValueError:` to detect malformed envelopes (an undocumented escape hatch in `0.6.0`) must migrate:

```python
# Before (0.6.0, undocumented):
try:
    valid, err = verify_attestation_locally(envelope=env, ...)
except ValueError as e:
    handle_malformed(e)

# After (0.6.1+, documented contract):
valid, err = verify_attestation_locally(envelope=env, ...)
if not valid and err == "AttestationSignatureSetIncomplete":
    handle_malformed(err)
```

All other `0.6.0` callers see no behavior change. The `expected_digest` / `expected_environment` normalization is forward-compatible: callers previously passing already-normalized inputs continue to work; callers previously seeing silent digest-mismatch now succeed.

### Verification

- 214 unit tests + 12 integration tests pass on Python 3.12 (9 new regression tests: `TestPep562Module` ×6 for the import-time fixes, `TestF1WhitespaceNormalization` ×2 for the digest/env normalization, F5 tests renamed in place from `*_raises` → `*_returns_signature_set_incomplete`)
- mypy --strict clean on `_verify_local.py` + `__init__.py`
- ruff check + format clean on all modified files
- `python -m build && twine check dist/*` PASSED for `0.6.1` wheel + sdist
- /quality-gate Phases 0-8 all clean; cycle-1 commit `7700ce0`
- 5,211 parent test suite passes with audit branch applied

### Upstream reference

- /quality-gate exhaustive 9-phase audit (this run)
- ADR-011 (artifact-bound AEGIS attestations): `https://github.com/undercurrentai/aegis-governance/blob/main/docs/architecture/adr/ADR-011-artifact-bound-aegis-attestations.md`
- Cosmic-flute plan §25.14 (Sprint 4/D2 audit-pass acknowledgments)

---

## 0.6.0 — 2026-05-09

### Added

- **`verify_attestation_locally()`** — offline cryptographic verifier for AEGIS attestation envelopes. Mirrors server-side `AttestationProvider.verify()` byte-for-byte (DSSE PAE, RFC 8785 canonicalization with NFC normalization, hybrid Ed25519 + ML-DSA-44 AND-of-2 with FIPS 204 final ctx-string API per ADR-011). Returns `tuple[bool, str | None]` with error_class strings identical to the server's, so consumer code is unchanged whether using HTTP-verify (D1) or offline-verify (D2).
- **`AttestationVerifyKey`** — frozen dataclass for pinning the Ed25519 (32B raw) + ML-DSA-44 (1312B raw) public keys at SDK init. Consumers fetch out-of-band (Sprint 5/E2 verifier-kit, project KMS, or config) and construct once.
- **`[verify]` optional-dependencies extra** — adds `cryptography>=42`, `liboqs-python>=0.14.1,<1.0.0`, `rfc8785>=0.1.4`. Install via `pip install aegis-governance[verify]`. Default `aegis-governance` install footprint is unchanged for HTTP-only consumers.
- **PEP 562 lazy-import gate** — `from aegis import verify_attestation_locally` raises a clear `ImportError` pointing to the install command when the `[verify]` extra is missing, instead of a confusing module-not-found error.
- **41 unit tests** + **5 round-trip integration tests** (gated `@pytest.mark.integration`) verifying server-issued envelopes verify successfully via the SDK offline path. The integration suite is the canonical proof that the server↔SDK byte-exact mirror invariant holds.

### Changed

- **Version bump** `0.5.0` → `0.6.0` (MINOR per SemVer; new public API surface, fully additive).
- `.github/workflows/python-ci.yml` SDK test step now installs with `[dev,verify]` so offline-verifier tests run on all 4 Python versions in CI.

### Migration

No action required for existing `aegis-governance==0.5.x` users. The new offline-verifier API is opt-in via the `[verify]` extra:

```python
from aegis import verify_attestation_locally, AttestationVerifyKey

keys = AttestationVerifyKey(
    ed25519_public=b"...32 bytes...",
    mldsa44_public=b"...1312 bytes...",
)
valid, error_class = verify_attestation_locally(
    envelope=envelope,
    expected_digest="<sha256 hex>",
    expected_environment="production",
    keys=keys,
)
```

### Use cases

- **Air-gapped CI**: GitHub Actions reusable workflow can verify attestations without a network round-trip to the AEGIS API
- **Latency-sensitive verification**: skip the HTTP hop when local public-key trust is sufficient
- **AEGIS API outage tolerance**: deploys keep verifying when the server is down
- **Stronger trust topology**: pinned consumer-side public keys + AND-of-2 hybrid Ed25519+ML-DSA-44 (post-quantum-ready per ADR-003 + ADR-011)

### Verification

- 41 unit tests + 5 integration tests pass on Python 3.12
- 95% coverage on new `_verify_local.py` (only deeply-defensive failure paths uncovered)
- mypy --strict clean on new code; ruff check + format clean
- `python -m build && twine check dist/*` PASSED for both wheel + sdist
- Round-trip integration test confirms server↔SDK byte-exact mirror invariant

### Upstream reference

- ADR-011 (artifact-bound AEGIS attestations): `https://github.com/undercurrentai/aegis-governance/blob/main/docs/architecture/adr/ADR-011-artifact-bound-aegis-attestations.md`
- liboqs-python 0.12.0 release notes (FIPS 204 final ctx-string API): `https://github.com/open-quantum-safe/liboqs-python/blob/main/CHANGES.md`
- Cosmic-flute plan §25: `~/.claude/plans/let-s-plan-this-cosmic-flute.md`

---

## 0.5.0 — 2026-05-09

### Added

- **AttestationClient + AsyncAttestationClient** (`client.attestations.{attest, verify, get}`) — wraps the Sprint 3 attestation HTTP surface (`POST /attest`, `POST /attestations/verify`, `GET /attestations/{decision_id}`) shipped on `aegis-governance` master 2026-05-09 (commits `7e45115b` + `a6fdaae`). Lazy-initialized via `Aegis.attestations` / `AsyncAegis.attestations` properties; reuses the existing `HttpTransport` (Bearer auth, retry/backoff, idempotency-key handling).
- **11 frozen dataclass response/request types** (re-exported from `aegis`): `AttestationResult`, `AttestationRecord`, `AttestationVerifyResult`, `DSSEEnvelope`, `DSSESignature`, `InTotoStatement`, `AEGISPredicate`, `AttestationGovernance`, `BuildDefinition`, `RunDetails`, `ResourceDescriptor`. Each carries `from_response(data, request_id=...)` and `to_dict()` methods. Hand-mirrored from the server-side Pydantic v2 source-of-truth — adds zero runtime dependencies.
- **4 typed exception classes** (re-exported from `aegis`): `AttestationCollisionError` (HTTP 409 — cross-customer decision_id collision), `AttestationNotFoundError` (HTTP 404 — absent OR cross-customer per tenant-isolation invariant), `AttestationProviderUnavailableError` (HTTP 503), `AttestationSchemaDriftError` (HTTP 410 — post-migration predicate drift). All inherit from `AegisError`.
- **Idempotency-Key support** on `attest()`: pass `idempotency_key="..."` for cross-process dedup; otherwise auto-UUID via `HttpTransport`. The `AttestationResult.idempotent_replayed: bool` is True when the server returned a cached record (HTTP 200 with `X-AEGIS-Idempotent-Replayed: true` header) instead of issuing fresh.
- **Client-side fail-fast validation** for obvious shape errors only: UUID-36 `decision_id`, lowercase-hex-64 `subject_digest_sha256` / `expected_digest`, Literal membership for `environment` / `risk_class`. Server-side Pydantic remains the canonical validator for everything else (server returns 400 with precise `error_class` on any other shape drift).
- **Sandbox-mode guardrail**: calling any `client.attestations.*` method without an API key raises `ValidationError("Attestations require an API key; sandbox mode does not support attestations.")` — clear error beats a network 401.
- **Integration test harness** at `tests/test_attestations_integration.py` (gated `@pytest.mark.integration`, excluded from default `pytest` run). Boots the real `aegis-governance` FastAPI app via `TestClient` against a tmp Alembic-migrated SQLite DB with real Ed25519+ML-DSA-44 test keys; catches wire-format drift between SDK frozen-dataclass mirrors and server Pydantic. Sprint 3 hotfix #164 lesson: mocks systematically miss real ORM/lifespan/DB lifecycle behaviors. Run via `pytest -m integration -v` after `pip install -e ../[dev,persistence,crypto,pqc]` from the parent repo.
- **`aegis.AttestationClient` / `aegis.AsyncAttestationClient`** also re-exported at the top level for direct import.

### Changed

- **Version bump** `0.4.1` → `0.5.0` (MINOR per SemVer; additive feature, fully backward-compatible with v0.4.1 callers).
- **`pyproject.toml`** — registered `integration` marker + default `addopts = "-m 'not integration'"` so the unit suite stays fast and isolated; integration tests are explicit opt-in.

### Migration

No action required for existing `aegis-governance==0.4.1` users. The new attestation surface is additive; existing `client.evaluate(...)`, `client.risk_check(...)`, `client.health()`, customer-management methods, and `@aegis_gate` decorator behave identically. The new methods become available via the lazy property:

```python
from aegis import Aegis

client = Aegis(api_key="uk_live_...")  # unchanged
result = client.attestations.attest(...)  # new
```

### Verification

- 154 unit tests (60 new) + 7 integration tests pass locally on Python 3.12; `mypy --strict` clean on new code; `ruff check src/ tests/` clean for new code (2 pre-existing E501s in `_client.py` Sharpe-ratios docstring untouched, predate this PR).
- New code coverage: 100% on `_attestations.py`, `types.py` attestation additions, and `_errors.py` attestation additions (445 stmts, 0 miss).
- End-to-end SDK ↔ FastAPI ↔ real DB ↔ Ed25519+ML-DSA-44 verified via `tests/test_attestations_integration.py`.

### Upstream reference

- aegis-governance Sprint 3 + hotfix: https://github.com/undercurrentai/aegis-governance/commit/a6fdaae
- ADR-011 (artifact-bound AEGIS attestations, hybrid Ed25519 + ML-DSA-44 DSSE multi-sig): https://github.com/undercurrentai/aegis-governance/blob/main/docs/architecture/adr/ADR-011-artifact-bound-aegis-attestations.md
- Cosmic-flute plan §24: `~/.claude/plans/let-s-plan-this-cosmic-flute.md`

---

## 0.4.1 — 2026-04-24

### Changed
- **Default production URL flipped to vanity host** (non-breaking): `_PRODUCTION_BASE_URL` in `aegis/_http.py` now defaults to `https://api.aegis.undercurrentholdings.com` (previously `https://aegis-api-980022636831.us-central1.run.app`). Closes AEGIS ROADMAP G12 (HIGH) — shipped in aegis-governance v4.7.7 on 2026-04-24.

### Migration
- **No action required for existing users**. Customers who pin a base URL keep working unchanged. The legacy `aegis-api-*.run.app` Cloud Run URL remains a secondary endpoint indefinitely — GCP Cloud Run serves both URL forms for the same service simultaneously, with no deprecation plan.
- **New installations** get the vanity URL by default, which reads as a production-grade API-first SaaS endpoint in enterprise security reviews instead of a raw GCP project-ID URL.

### Why the change
Until this release, every customer integration pinned the raw GCP project-ID URL, which (a) read as "prototype" in enterprise security reviews, (b) tied integrations to GCP project ID `980022636831` (blocking future region or project moves without customer re-integration), and (c) allowed the 2026-04-10 `getaddrinfo ENOTFOUND` incident class (portal dashboard advertised the vanity URL before it was provisioned). G12 provisions both `api.aegis.undercurrentholdings.com` and `mcp.aegis.undercurrentholdings.com` as Cloud Run custom domains with Google-managed TLS certificates, closing the incident permanently.

### Verification
- `curl -sI https://api.aegis.undercurrentholdings.com/health` → HTTP/2 200 with `{"status":"ok"}`
- `openssl s_client` → `CN=api.aegis.undercurrentholdings.com` issued by Let's Encrypt R12 (Google Trust Services delegation)

### Upstream reference
- AEGIS Governance v4.7.7 changelog: https://github.com/undercurrentai/aegis-governance/blob/main/docs/claude/changelog.md
- ROADMAP G12 closure: https://github.com/undercurrentai/aegis-governance/blob/main/docs/ROADMAP.md

---

## 0.4.0 and earlier

Historical releases predate this changelog. See git history: `git log aegis-sdk/src/aegis/_version.py`.
