from .word import Word

class Memory:
    values: dict[Word, Word]

    def __init__(self):
        self.values = {}

    def __getitem__(self, address: Word) -> Word:
        # adresse non initialisée → exception
        res = self.values.get(address) 
        if res is None:
            raise KeyError
        return res
        
    
    def __setitem__(self, address: Word, value: Word):
        # écriture → alloue si nécessaire
        self.values[address] = value
    
    def load(self, address: Word, program: list[Word]):
        # charge un programme à partir d'une adresse
        for a, v in enumerate(program):
            self.values[address+Word(a)] = v

            
