from tritlib import Tryte
from .word import Word

def encode_R(opcode, rd, rs1, rs2, funct=0):
    trits = (
        Tryte(opcode, 4).trits +
        Tryte(rd, 3).trits +
        Tryte(rs1, 3).trits +
        Tryte(rs2, 3).trits +
        Tryte(funct, 14).trits
    )
    return Word.from_trits(trits)

def encode_I(opcode, rd, rs1, imm):
    trits = (
        Tryte(opcode, 4).trits+
        Tryte(rd, 3).trits + 
        Tryte(rs1, 3).trits +
        Tryte(imm, 17).trits
    )
    return Word.from_trits(trits)

def encode_J(opcode, rs1, offset):
    trits = (
        Tryte(opcode, 4).trits +
        Tryte(rs1, 3).trits +
        Tryte(offset,20).trits
    )
    return Word.from_trits(trits)

def encode_U(opcode, offset):
    trits = (Tryte(opcode, 4).trits + Tryte(offset, 23).trits)
    return Word.from_trits(trits)

def encode_B(opcode, rx, off_z, off_n):
    trits = (
        Tryte(opcode, 4).trits +
        Tryte(rx, 3).trits +
        Tryte(off_z, 10).trits +
        Tryte(off_n, 10).trits
    )
    return Word.from_trits(trits=trits)
