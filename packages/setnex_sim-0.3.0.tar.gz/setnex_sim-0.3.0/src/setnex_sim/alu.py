from setnex_sim.registers import Registers
from setnex_sim.word import Word
from tritlib import Z, N, P, Trit, logic

def get_logic(regs):
    if regs._lmode == N:
        if regs.status_lx == N:
            return logic.HT()
        elif regs.status_lx == P:
            return logic.RM3()
        else:  # Z
            return logic.Lukasiewicz()
    elif regs._lmode == P:
        return logic.B3()
    else:
        return logic.Kleene()

def add(a: Word, b: Word) -> tuple[Word, dict]:
    result, carry = a.add_with_carry(b)
    flags = {
        "sign": result.sign(),
        "carry": carry
    }

    return result, flags

def sub(a: Word, b: Word) -> tuple[Word, dict]:
    return add(a,-b) 

def abs(a: Word) -> Word:
    return a.__abs__()

def tmin(a: Word) -> Word:
    return Word.from_trits([min(a.trits)])

def tmax(a: Word) -> Word:
    return Word.from_trits([max(a.trits)])


def _apply_binary(op, a: Word, b: Word) -> Word:
    trits = [op(ta, tb) for ta, tb in zip(a.trits, b.trits)]
    return Word.from_trits(trits)

def _apply_unary(op, a: Word) -> Word:
    trits = [op(ta) for ta in a.trits]
    return Word.from_trits(trits)

LOGIC_MAP = {
    N: logic.Lukasiewicz(),
    Z:  logic.Kleene(),
    P:  logic.Bochvar(),
}

def tand(a: Word, b: Word, regs: Registers) -> Word:
    lg = get_logic(regs)
    result = _apply_binary(lg.and_op, a, b)
    return Word.from_trits(result.trits)

def tnot(a: Word, regs: Registers) -> Word:
    lg = get_logic(regs)
    result = _apply_unary(lg.not_op, a)
    return Word.from_trits(result.trits)

def tor(a: Word, b: Word, regs: Registers) -> Word:
    lg = get_logic(regs)
    result = _apply_binary(lg.or_op, a, b)
    return Word.from_trits(result.trits)

def txor(a: Word, b: Word, regs: Registers) -> Word:
    lg = get_logic(regs)
    result = _apply_binary(lg.xor_op, a, b)
    return Word.from_trits(result.trits)

def timpl(a: Word, b: Word, regs: Registers) -> Word:
    lg = get_logic(regs)
    result = _apply_binary(lg.imply_op, a, b)
    return Word.from_trits(result.trits)

def mul(a: Word, b: Word) -> tuple[Word, dict]:
    result = a*b 
    flags = {
        "sign": result.sign(),
        "carry": Z
    }
    return result, flags

def div(a: Word, b: Word) -> Word:
    return divmod(a,b)[0]

def mod(a: Word, b: Word) -> Word:
    return a % b

def cons(a: Word, b: Word) -> Word:
    return a.cons(b)

def acons(a: Word, b: Word) -> Word:
    return a.acons(b)

def shift(a: Word, b: Word) -> Word:
    if int(b) >= 0:
        return a << int(b)
    else:
        return a >> -int(b)

def tcmp(a: Word, b: Word) -> Word:
    def cmp(a: Trit, b: Trit):
        if a < b :
            return N
        elif a == b :
            return Z
        else:
            return P
    return _apply_binary(cmp, a, b)
