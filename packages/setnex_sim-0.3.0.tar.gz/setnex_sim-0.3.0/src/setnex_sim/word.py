from __future__ import annotations
from tritlib import Tryte, Trits

class Word(Tryte):
    WIDTH = 27

    def __init__(self, value: str|int|Tryte):
        if isinstance(value, Tryte):
            value = int(value)
        super().__init__(value, width=self.WIDTH)

    @classmethod
    def from_trits(cls, trits: list[Trits]|tuple[Trits,...]) -> Word:
        if isinstance(trits, tuple):
            trits = list(trits)
        return Word(super()._from_trits(trits, cls.WIDTH))

    def __add__(self, other: Word) -> Word:
        result = super().__add__(other)
        return Word(result)

    def __mul__(self, other: Word) -> Word:
        result = super().__mul__(other)
        return Word(result)

    def __mod__(self, other: Word) -> Word:
        result = super().__mod__(other)
        return Word(result)

    def __sub__(self, other: Word) -> Word:
        result = super().__sub__(other)
        return Word(result)

    def cons(self, other: Word) -> Word:
        result = super().cons(other)
        return Word(result)

    def acons(self, other: Word) -> Word:
        result = super().acons(other)
        return Word(result)

    def __rshift__(self, other: int) -> Word:
        result = super().__rshift__(other)
        return Word(result)
    
    def __lshift__(self, other: int) -> Word:
        result = super().__lshift__(other)
        return Word(result)

Word.ZERO = Word(0)
Word.ONE = Word(1)
Word.MAX = Word("".join(['+']*27))
Word.MIN = Word("".join(['-']*27))
