from enum import Enum
from dataclasses import dataclass
from .word import Word

class Format(Enum):
    R = "R"
    I = "I"
    J = "J"
    U = "U"
    B = "B"

@dataclass
class Instruction:
    fmt:    Format
    opcode: int
    rd:     int  = 0
    rs1:    int  = 0
    rs2:    int  = 0
    funct:  int  = 0
    imm:    int  = 0
    offset: int  = 0
    rx:     int  = 0
    off_z:  int  = 0
    off_n:  int  = 0


def _opcode_to_format(op: int) -> Format:
    if -40 <= op <= -27 or -3 <= op <= +7 :
        return Format.R
    if op == -21:
        return Format.B
    if -26 <= op <= -18 or -7 <= op <= -4 :
        return Format.I
    if -17 <= op <= -10:
        return Format.J
    if -9 <= op <= -8:
        return Format.U
    if 8 <= op <= 40:
        raise ValueError(f"Reserved opcode: {op}")
    raise ValueError(f"Unknown opcode: {op}")

def decode(word: Word) -> Instruction:
    opcode = int(word[0:4])
    fmt = _opcode_to_format(opcode)

    if fmt == Format.R:
        return Instruction(
            fmt = fmt,
            opcode = opcode,
            rd = int(word[4:7]),
            rs1 = int(word[7:10]),
            rs2 = int(word[10:13]),
            funct = int(word[13:])
        )
    elif fmt == Format.I:
        return Instruction(
            fmt = fmt,
            opcode = opcode,
            rd = int(word[4:7]),
            rs1 = int(word[7:10]),
            imm = int(word[10:]),
        )
    elif fmt == Format.J:
        return Instruction(
                fmt = fmt,
                opcode = opcode,
                rs1 = int(word[4:7]),
                offset= int(word[7:])
        )
    elif fmt == Format.U:
        return Instruction(
                fmt=fmt,
                opcode=opcode,
                offset=int(word[4:])
        )
    elif fmt == Format.B:
        return Instruction(
                fmt=fmt,
                opcode=opcode,
                rx=int(word[4:7]),
                off_z=int(word[7:17]),
                off_n=int(word[17:])
        )
    else :
        return Instruction(
            fmt = fmt,
            opcode = opcode,
            rs1 = int(word[4:7]),
            offset = int(word[7:]),
        )


