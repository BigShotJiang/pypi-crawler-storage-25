from setnex_sim.decoder import Instruction
from setnex_sim.registers import Registers
from setnex_sim.memory import Memory
from setnex_sim import alu
from setnex_sim.word import Word
from tritlib import Tryte, Z, N, P

CSR_MAP = {
    1:  "pc",
    2:  "lmode",
    3:  "flags",  
    4:  "epc",
    5:  "ecause",
    6:  "evec",
    7:  "status",
    8:  "esave",
}

def execute(instr: Instruction, regs: Registers, mem: Memory) -> bool:
    """Retourne False si HALT, True sinon."""
    match instr.opcode:
        case 0:   # HALT
            return False
        case -40: # ADD
            result, flags = alu.add(regs[instr.rs1], regs[instr.rs2])
            regs[instr.rd] = result
            regs.flag_sign     = flags["sign"]
            regs.flag_carry = flags["carry"]
        case -39: # SUB
            result, flags = alu.sub(regs[instr.rs1], regs[instr.rs2])
            regs[instr.rd] = result
            regs.flag_sign     = flags["sign"]
            regs.flag_carry = flags["carry"]
        case -38: # MUL
            result, flags = alu.mul(regs[instr.rs1], regs[instr.rs2])
            regs[instr.rd] = result
            regs.flag_sign     = flags["sign"]
            regs.flag_carry = flags["carry"]
        case -37: # DIV
            result = alu.div(regs[instr.rs1], regs[instr.rs2])
            regs[instr.rd] = result
        case -36: # MOD
            result = alu.mod(regs[instr.rs1], regs[instr.rs2])
            regs[instr.rd] = result
        case -35: # NEG
            result = -regs[instr.rs1]
            regs[instr.rd] = result
            regs.flag_sign = result.sign()
        case -34: #TAND
            regs[instr.rd] = alu.tand(regs[instr.rs1],regs[instr.rs2], regs)
        case -33: # TOR
            regs[instr.rd] = alu.tor(regs[instr.rs1],regs[instr.rs2], regs)
        case -32: # TNOT
            regs[instr.rd] = alu.tnot(regs[instr.rs1],regs)
        case -31: # TIMPL
            regs[instr.rd] = alu.timpl(regs[instr.rs1],regs[instr.rs2], regs)
        case -30: # CONS
            regs[instr.rd] = alu.cons(regs[instr.rs1], regs[instr.rs2])
        case -29: # CONS
            regs[instr.rd] = alu.acons(regs[instr.rs1], regs[instr.rs2])
        case -28: # SHIFT
            regs[instr.rd] = alu.shift(regs[instr.rs1], regs[instr.rs2])
        case -27: # TCMP
            regs[instr.rd] = alu.tcmp(regs[instr.rs1], regs[instr.rs2])
        #### Memory groupe - I format (opcode -26 to -18)
        case -26: # LOAD
            regs[instr.rd] = mem[regs[instr.rs1]+Word(instr.imm)]
        case -25: # STORE
            mem[regs[instr.rs1]+Word(instr.imm)] = regs[instr.rd]
        case -24: #LI
            regs[instr.rd] = Word(instr.imm)
        case -23: # LUI
            regs[instr.rd] = Word(instr.imm) << 10
        case -22: # ADDI
            regs[instr.rd] = regs[instr.rs1] + Word(instr.imm)
        case -21: # BRT3
            lst = regs[instr.rx].trits[0]
            if lst == Z:
                regs.pc = regs.pc + Word(instr.off_z)
            elif lst == N:
                regs.pc = regs.pc + Word(instr.off_n)
        # -20 - -19 reserved
        case -18: # CMPI
            result, flags = alu.sub(regs[instr.rs1], Word(instr.imm))
            regs.flag_sign     = flags["sign"]
            regs.flag_carry    = flags["carry"]
        #### Branch goup J format and U format (-9 and -8)
        case -17: # BEQ
            if regs[instr.rs1] == Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -16: # BNE
            if regs[instr.rs1] != Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -15: # BLT
            if regs[instr.rs1] < Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -14: # BGT
            if regs[instr.rs1] > Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -13: # BLE
            if regs[instr.rs1] <= Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -12: # BGe
            if regs[instr.rs1] >= Word(0):
                regs.pc = regs.pc + Word(instr.offset)
        case -11: # JMPA
            regs.pc = regs[instr.rs1] + Word(instr.offset)
        case -10: # BF
            mask = Word(instr.rs1).trits
            sign = regs.flag_sign
            take = (
                (mask[0] == P and sign == N) or
                (mask[1] == P and sign == Z) or
                (mask[2] == P and sign == P)
            )
            if take :
                regs.pc = regs.pc + Word(instr.offset)
        case -9: # JMP
            regs.pc = regs.pc + Word(instr.offset)
        case -8: # CALL
            regs[1] = regs.pc + Word(1)
            regs.pc += Word(instr.offset)
        #### CSR and system group - I format (opcode -7 to -4)
        case -7:  # CSRR
            name = CSR_MAP[instr.imm]
            regs[instr.rd] = getattr(regs, name)
        case -6:  # CSRW
            name = CSR_MAP[instr.imm]
            setattr(regs, name, regs[instr.rs1])
        case -5: # CSRX
            name = CSR_MAP[instr.imm]
            regs[instr.rd] = getattr(regs, name)
            setattr(regs, name, regs[instr.rs1])
        case -4: # ECALL
            pass
        
        #### Special group - R format (opcode -3 to 4)
        case -3: # IRET
            regs.pc = regs.epc
            regs.esave = regs.status 
        case -2: # TSEL
            if regs.flag_sign == N:
                regs[instr.rd] = regs[instr.rs1]
            elif regs.flag_sign == Z:
                    regs[instr.rd] = regs[instr.rs2]
            else:
                func_trits = Tryte(instr.funct, 14).trits
                r = int(Tryte._from_trits(func_trits[:3], 3))
                regs[instr.rd] = regs[r]

        case -1:  # NOP
            pass
        case 1: # TGET
            trits = regs[instr.rs1].trits
            pos = int(regs[instr.rs2])
            val = trits[pos]
            regs[instr.rd] = Word.from_trits([val])

        case 2: # TSET
            val = Word(instr.funct).trits[0]
            rs1_trits = list(regs[instr.rs1].trits)
            rs1_trits[int(int(regs[instr.rs2]))] = val
            regs[instr.rd] = Word.from_trits(rs1_trits)

        case 3: # TSIGN:
            s= regs[instr.rs1].sign()
            if s == Z:
                regs[instr.rd] = Word(0)
            elif s == N:
                regs[instr.rd] = Word(-1)
            else:
                regs[instr.rd] = Word(1)
        case 4: # CMP
            if regs[instr.rs1] < regs[instr.rs2]:
                regs.flag_sign = N
            elif regs[instr.rs1] > regs[instr.rs2]:
                regs.flag_sign = P
            else :
                regs.flag_sign = Z

        case 5: # TABS
            regs[instr.rd] = alu.abs(regs[instr.rs1])
        
        case 6: # TMIN
            regs[instr.rd] = alu.tmin(regs[instr.rs1])

        case 7: # TMAX
            regs[instr.rd] = alu.tmax(regs[instr.rs1])

        case _:
            raise ValueError(f"Unknown opcode: {instr.opcode}")

    return True
