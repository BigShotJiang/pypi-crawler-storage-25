from .decoder import decode
from .executor import execute
from .registers import Registers
from .memory import Memory
from .word import Word

class CPU:
    regs: Registers
    mem: Memory

    def __init__(self):
        self.regs = Registers()
        self.mem = Memory()

    def load(self, program: list[Word], start: Word = Word(0)):
        self.mem.load(start, program)
        

    def run(self):
        while self.step():
            pass

    def step(self) -> bool:
        old_pc = self.regs.pc
        word = self.mem[self.regs.pc]
        instr = decode(word)
        result = execute(instr, self.regs, self.mem)
        if result and self.regs.pc == old_pc:
            self.regs.pc = self.regs.pc + Word(1)
        return result
