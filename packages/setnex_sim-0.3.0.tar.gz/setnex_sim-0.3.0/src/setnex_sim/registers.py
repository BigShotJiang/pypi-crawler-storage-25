from .word import Word
from tritlib import Z

class Registers:
    def __init__(self):
        self._regs = [Word(0)] * 27
        
        # CSR
        self.pc     = Word(0)
        self._lmode     = Z
        self.flag_sign = Z
        self.flag_carry = Z
        self.status_mode = Z
        self.status_irq  = Z
        self.status_lx = Z
        self.epc    = Word(0)
        self.ecause = Word(0)
        self.evec   = Word(0)
        self.esave  = Word(0)

    def __getitem__(self, index: int) -> Word:
        return self._regs[index + 13]

    def __setitem__(self, index: int, value: Word):
        if index == -13:  # r0 read-only
            return
        self._regs[index + 13] = value

    @property
    def flags(self) -> Word:
        return Word.from_trits(
            [self.flag_sign,self.flag_carry] + [Z] * 25
        )

    @property
    def status(self) -> Word:
        return Word.from_trits(
            [self.status_mode, self.status_irq, self.status_lx] + [Z] * 24
        )

    @status.setter
    def status(self, value: Word):
        self.status_mode = value.trits[0]
        self.status_irq  = value.trits[1]
        self.status_lx   = value.trits[2]

    @property
    def lmode(self) -> Word:
        return Word.from_trits([self._lmode] + [Z] * 26)

    @lmode.setter
    def lmode(self, value) -> None:
        if isinstance(value, Word):
            self._lmode = value.trits[0]
        else:  # Trit
            self._lmode = value

