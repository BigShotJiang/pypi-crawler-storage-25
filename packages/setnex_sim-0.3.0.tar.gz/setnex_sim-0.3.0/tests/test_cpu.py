from setnex_sim.cpu import CPU
from setnex_sim.assembler import encode_R, encode_I

def test_cpu_add():
    cpu = CPU()
    program = [
        encode_I(-24, rd=1, rs1=0, imm=5),   # LI r1, 5
        encode_I(-24, rd=2, rs1=0, imm=3),   # LI r2, 3
        encode_R(-40, rd=3, rs1=1, rs2=2),   # ADD r3, r1, r2
        encode_R(0,   rd=0, rs1=0, rs2=0),   # HALT
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[3]) == 8

def test_cpu_sub():
    cpu = CPU()
    program = [
        encode_I(-24, rd=1, rs1=0, imm=10),
        encode_I(-24, rd=2, rs1=0, imm=3),
        encode_R(-39, rd=3, rs1=1, rs2=2),   # SUB r3, r1, r2
        encode_R(0,   rd=0, rs1=0, rs2=0),
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[3]) == 7

def test_cpu_mul():
    cpu = CPU()
    program = [
        encode_I(-24, rd=1, rs1=0, imm=6),
        encode_I(-24, rd=2, rs1=0, imm=7),
        encode_R(-38, rd=3, rs1=1, rs2=2),   # MUL r3, r1, r2
        encode_R(0,   rd=0, rs1=0, rs2=0),
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[3]) == 42

def test_cpu_neg():
    cpu = CPU()
    program = [
        encode_I(-24, rd=1, rs1=0, imm=5),
        encode_R(-35, rd=2, rs1=1, rs2=0),   # NEG r2, r1
        encode_R(0,   rd=0, rs1=0, rs2=0),
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[2]) == -5

def test_cpu_load_store():
    cpu = CPU()
    program = [
        encode_I(-24, rd=1, rs1=0, imm=42),  # LI r1, 42
        encode_I(-24, rd=2, rs1=0, imm=100), # LI r2, 100  (adresse)
        encode_I(-25, rd=1, rs1=2, imm=0),   # STORE r1, r2, 0
        encode_I(-26, rd=3, rs1=2, imm=0),   # LOAD r3, r2, 0
        encode_R(0,   rd=0, rs1=0, rs2=0),
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[3]) == 42

def test_cpu_r0_readonly():
    cpu = CPU()
    program = [
        encode_I(-24, rd=0, rs1=0, imm=99),  # LI r0, 99 — ignoré
        encode_R(0,   rd=0, rs1=0, rs2=0),
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs[-13]) == 0

def test_cpu_pc_increments():
    cpu = CPU()
    program = [
        encode_R(-1, rd=0, rs1=0, rs2=0),   # NOP
        encode_R(-1, rd=0, rs1=0, rs2=0),   # NOP
        encode_R(0,  rd=0, rs1=0, rs2=0),   # HALT
    ]
    cpu.load(program)
    cpu.run()
    assert int(cpu.regs.pc) == 2  # PC sur HALT
