from tritlib import Tryte
from setnex_sim.decoder import _opcode_to_format, Format, decode
from setnex_sim.word import Word
import pytest

def test_opcode_to_format():
    with pytest.raises(ValueError):
        _opcode_to_format(-41)

    with pytest.raises(ValueError):
        _opcode_to_format(41)

    for i in range(-40,-26):
        assert _opcode_to_format(i) == Format.R
    for i in range(-26, -17):
        if i == -21:
            assert _opcode_to_format(i) == Format.B
            continue
        assert _opcode_to_format(i) == Format.I
    for i in range(-17,-9):
        assert _opcode_to_format(i) == Format.J
    for i in range(-9,-8):
        assert _opcode_to_format(i) == Format.U
    for i in range(-7,-3):
        assert _opcode_to_format(i) == Format.I
    for i in range(-3,8):
        assert _opcode_to_format(i) == Format.R
    for i in range(8,41):
        with pytest.raises(ValueError):
            _opcode_to_format(i)
    

def test_decode_format_R():
    opcode = Tryte(-40,4)
    rd = Tryte(3,3)
    rs1 = Tryte(4,3)
    rs2 = Tryte(5,3)
    funct = Tryte(23423,14)
    instruction_trits = opcode.trits + rd.trits + rs1.trits + rs2.trits + funct.trits
    assert len(instruction_trits) == 27

    instruction = Word.from_trits(instruction_trits)
    decoded = decode(instruction)
    assert decoded.opcode == -40
    assert decoded.fmt == Format.R
    assert decoded.rd == 3
    assert decoded.rs1 == 4
    assert decoded.rs2 == 5
    assert decoded.funct == 23423

def test_decode_format_I():
    opcode = Tryte(-25,4)
    rd = Tryte(3,3)
    rs1 = Tryte(4,3)
    imm = Tryte(23423,17)
    instruction_trits = opcode.trits + rd.trits + rs1.trits + imm.trits
    assert len(instruction_trits) == 27

    instruction = Word.from_trits(instruction_trits)
    decoded = decode(instruction)
    assert decoded.opcode == -25
    assert decoded.fmt == Format.I
    assert decoded.rd == 3
    assert decoded.rs1 == 4
    assert decoded.imm == 23423


def test_decode_format_J():
    opcode = Tryte(-17,4)
    rs1 = Tryte(4,3)
    offset = Tryte(23423,20)
    instruction_trits = opcode.trits + rs1.trits + offset.trits
    assert len(instruction_trits) == 27

    instruction = Word.from_trits(instruction_trits)
    decoded = decode(instruction)
    assert decoded.opcode == -17
    assert decoded.fmt == Format.J
    assert decoded.rs1 == 4
    assert decoded.offset == 23423
