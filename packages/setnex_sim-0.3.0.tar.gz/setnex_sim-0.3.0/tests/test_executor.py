from tritlib.trit import Z, P, N
from tritlib.tryte import Tryte
from setnex_sim.word import Word
from setnex_sim.registers import Registers
from setnex_sim.memory import Memory
from setnex_sim.decoder import decode
from setnex_sim.executor import execute
from setnex_sim.assembler import encode_R, encode_I, encode_J, encode_U, encode_B

def make_cpu():
    return Registers(), Memory()

# ── ADD (opcode -40, funct[13]=Z) ──
def test_add_basic():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    regs[2] = Word(3)
    execute(decode(encode_R(-40, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 8
    assert regs.flag_sign == P

def test_add_sign_positive():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    regs[2] = Word(3)
    execute(decode(encode_R(-40, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == P

def test_add_sign_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-5)
    regs[2] = Word(-3)
    execute(decode(encode_R(-40, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == N

def test_add_zero_flag():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    regs[2] = Word(-5)
    execute(decode(encode_R(-40, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == Z

# ── SUB (opcode -39) ──
def test_sub_basic():
    regs, mem = make_cpu()
    regs[1] = Word(10)
    regs[2] = Word(3)
    execute(decode(encode_R(-39, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 7
    assert regs.flag_sign == P

# ── NEG (opcode -35) ──
def test_neg():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    execute(decode(encode_R(-35, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == -5
    assert regs.flag_sign == N

# ── MUL (opcode -38, funct[13]=Z) ──
def test_mul():
    regs, mem = make_cpu()
    regs[1] = Word(6)
    regs[2] = Word(7)
    execute(decode(encode_R(-38, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 42
    assert regs.flag_carry == Z  # carry toujours Z pour MUL

# ── DIV (opcode -37) — symmetric Euclidean ──
def test_div_basic():
    regs, mem = make_cpu()
    regs[1] = Word(40)
    regs[2] = Word(6)
    execute(decode(encode_R(-37, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 7  # symmetric: 40/6 = 6.67 → round to 7

def test_div_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-40)
    regs[2] = Word(6)
    execute(decode(encode_R(-37, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == -7

def test_div_by_zero():
    regs, mem = make_cpu()
    regs[1] = Word(10)
    regs[2] = Word(0)
    import pytest
    with pytest.raises(ZeroDivisionError):
        execute(decode(encode_R(-37, rd=3, rs1=1, rs2=2)), regs, mem)

# ── MOD (opcode -36) ──
def test_mod_basic():
    regs, mem = make_cpu()
    regs[1] = Word(40)
    regs[2] = Word(6)
    execute(decode(encode_R(-36, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == -2  # 40 - 7*6 = 40 - 42 = -2

# ── CMP (opcode +4) ──
def test_cmp_less():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == N

def test_cmp_equal():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == Z

def test_cmp_greater():
    regs, mem = make_cpu()
    regs[1] = Word(7)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == P

# ── LOAD (opcode -26) ──
def test_load_basic():
    regs, mem = make_cpu()
    mem[Word(10)] = Word(99)
    regs[1] = Word(10)
    execute(decode(encode_I(-26, rd=2, rs1=1, imm=0)), regs, mem)
    assert int(regs[2]) == 99

def test_load_with_offset():
    regs, mem = make_cpu()
    mem[Word(15)] = Word(42)
    regs[1] = Word(10)
    execute(decode(encode_I(-26, rd=2, rs1=1, imm=5)), regs, mem)
    assert int(regs[2]) == 42

# ── STORE (opcode -25) ──
def test_store_basic():
    regs, mem = make_cpu()
    regs[1] = Word(10)
    regs[2] = Word(77)
    execute(decode(encode_I(-25, rd=2, rs1=1, imm=0)), regs, mem)
    assert int(mem[Word(10)]) == 77

# ── LI (opcode -24) ──
def test_li():
    regs, mem = make_cpu()
    execute(decode(encode_I(-24, rd=3, rs1=0, imm=42)), regs, mem)
    assert int(regs[3]) == 42

def test_li_negative():
    regs, mem = make_cpu()
    execute(decode(encode_I(-24, rd=3, rs1=0, imm=-100)), regs, mem)
    assert int(regs[3]) == -100

# ── ADDI (opcode -22) ──
def test_addi():
    regs, mem = make_cpu()
    regs[1] = Word(10)
    execute(decode(encode_I(-22, rd=2, rs1=1, imm=5)), regs, mem)
    assert int(regs[2]) == 15

# ── TSIGN (opcode +3) ──
def test_tsign_positive():
    regs, mem = make_cpu()
    regs[1] = Word(42)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 1

def test_tsign_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-42)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == -1

def test_tsign_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 0

# ── HALT (opcode 0) ──
def test_halt():
    regs, mem = make_cpu()
    result = execute(decode(encode_R(0, rd=0, rs1=0, rs2=0)), regs, mem)
    assert result == False

# ── NOP (opcode -1) ──
def test_nop():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    result = execute(decode(encode_R(-1, rd=0, rs1=0, rs2=0)), regs, mem)
    assert result == True
    assert int(regs[1]) == 5  

from tritlib.trit import Z, P, N
from setnex_sim.word import Word
from setnex_sim.registers import Registers
from setnex_sim.memory import Memory
from setnex_sim.decoder import decode
from setnex_sim.executor import execute
from setnex_sim.assembler import encode_R, encode_I, encode_J, encode_U, encode_B

def make_cpu():
    regs = Registers()
    mem = Memory()
    return regs, mem

# ── BRT3 (−21, format B) ──
def test_brt3_positive_fallthrough():
    regs, mem = make_cpu()
    regs[1] = Word(1)  # LST = P
    regs.pc = Word(0)
    execute(decode(encode_B(-21, rx=1, off_z=10, off_n=-5)), regs, mem)
    assert regs.pc == Word(0)  # pas de branchement, fall-through

def test_brt3_zero_branch():
    regs, mem = make_cpu()
    regs[1] = Word(0)  # LST = Z
    regs.pc = Word(0)
    execute(decode(encode_B(-21, rx=1, off_z=10, off_n=-5)), regs, mem)
    assert int(regs.pc) == 10

def test_brt3_negative_branch():
    regs, mem = make_cpu()
    regs[1] = Word(-1)  # LST = N
    regs.pc = Word(0)
    execute(decode(encode_B(-21, rx=1, off_z=10, off_n=-5)), regs, mem)
    assert int(regs.pc) == -5

# ── CMPI (−18) ──
def test_cmpi_less():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    execute(decode(encode_I(-18, rd=0, rs1=1, imm=5)), regs, mem)
    assert regs.flag_sign == N

def test_cmpi_equal():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    execute(decode(encode_I(-18, rd=0, rs1=1, imm=5)), regs, mem)
    assert regs.flag_sign == Z

def test_cmpi_greater():
    regs, mem = make_cpu()
    regs[1] = Word(7)
    execute(decode(encode_I(-18, rd=0, rs1=1, imm=5)), regs, mem)
    assert regs.flag_sign == P

# ── BEQ (−17) ──
def test_beq_taken():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    regs.pc = Word(0)
    execute(decode(encode_J(-17, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_beq_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-17, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── BNE (−16) ──
def test_bne_taken():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-16, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_bne_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    regs.pc = Word(0)
    execute(decode(encode_J(-16, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── BLT (−15) ──
def test_blt_taken():
    regs, mem = make_cpu()
    regs[1] = Word(-3)
    regs.pc = Word(0)
    execute(decode(encode_J(-15, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_blt_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-15, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── BGT (−14) ──
def test_bgt_taken():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-14, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_bgt_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(-3)
    regs.pc = Word(0)
    execute(decode(encode_J(-14, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── BLE (−13) ──
def test_ble_taken_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-3)
    regs.pc = Word(0)
    execute(decode(encode_J(-13, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_ble_taken_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    regs.pc = Word(0)
    execute(decode(encode_J(-13, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_ble_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-13, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── BGE (−12) ──
def test_bge_taken_positive():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs.pc = Word(0)
    execute(decode(encode_J(-12, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_bge_taken_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    regs.pc = Word(0)
    execute(decode(encode_J(-12, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 5

def test_bge_not_taken():
    regs, mem = make_cpu()
    regs[1] = Word(-3)
    regs.pc = Word(0)
    execute(decode(encode_J(-12, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── JMPA (−11) ──
def test_jmpa():
    regs, mem = make_cpu()
    regs[1] = Word(100)
    regs.pc = Word(0)
    execute(decode(encode_J(-11, rs1=1, offset=5)), regs, mem)
    assert int(regs.pc) == 105

def test_jmpa_zero_offset():
    regs, mem = make_cpu()
    regs[1] = Word(50)
    regs.pc = Word(0)
    execute(decode(encode_J(-11, rs1=1, offset=0)), regs, mem)
    assert int(regs.pc) == 50

# ── BF (−10) ──
def test_bf_lt():
    regs, mem = make_cpu()
    regs.flag_sign = N
    regs.pc = Word(0)
    # mask P00 = t[4]=P, t[5]=Z, t[6]=Z → rs1 = enc du masque
    execute(decode(encode_J(-10, rs1=1, offset=5)), regs, mem)
    # rs1=1 → trits [+,0,0] → t[4]=P, match si flag_sign=N
    assert int(regs.pc) == 5

def test_bf_not_taken():
    regs, mem = make_cpu()
    regs.flag_sign = P
    regs.pc = Word(0)
    execute(decode(encode_J(-10, rs1=1, offset=5)), regs, mem)
    assert regs.pc == Word(0)

# ── JMP (−9, format U) ──
def test_jmp():
    regs, mem = make_cpu()
    regs.pc = Word(0)
    execute(decode(encode_U(-9, offset=100)), regs, mem)
    assert int(regs.pc) == 100

def test_jmp_negative():
    regs, mem = make_cpu()
    regs.pc = Word(50)
    execute(decode(encode_U(-9, offset=-10)), regs, mem)
    assert int(regs.pc) == 40

# ── CALL (−8, format U) ──
def test_call():
    regs, mem = make_cpu()
    regs.pc = Word(10)
    execute(decode(encode_U(-8, offset=50)), regs, mem)
    assert int(regs.pc) == 60
    assert int(regs[1]) == 11  # ra = PC + 1

# ── CSRR (−7) ──
def test_csrr_lmode():
    regs, mem = make_cpu()
    regs.lmode = P
    execute(decode(encode_I(-7, rd=3, rs1=0, imm=2)), regs, mem)
    assert regs[3].trits[0] == P

# ── CSRW (−6) ──
def test_csrw_lmode():
    regs, mem = make_cpu()
    regs[1] = Word(1)  # P en trit 0
    execute(decode(encode_I(-6, rd=0, rs1=1, imm=2)), regs, mem)
    assert regs._lmode == P

# ── CSRX (−5) ──
def test_csrx():
    regs, mem = make_cpu()
    regs.lmode = N
    regs[1] = Word(1)  # nouvelle valeur
    execute(decode(encode_I(-5, rd=3, rs1=1, imm=2)), regs, mem)
    assert regs[3].trits[0] == N  # ancienne valeur
    assert regs._lmode == P        # nouvelle valeur

# ── IRET (−3) ──
def test_iret():
    regs, mem = make_cpu()
    regs.epc = Word(42)
    regs.esave = Word(0)
    execute(decode(encode_R(-3, rd=0, rs1=0, rs2=0)), regs, mem)
    assert int(regs.pc) == 42

# ── TSEL (−2) ──
def test_tsel_negative():
    regs, mem = make_cpu()
    regs.flag_sign = N
    regs[1] = Word(10)  # rn
    regs[2] = Word(20)  # rz
    regs[3] = Word(30)  # rp (dans funct[13..15])
    execute(decode(encode_R(-2, rd=4, rs1=1, rs2=2, funct=3)), regs, mem)
    assert int(regs[4]) == 10

def test_tsel_zero():
    regs, mem = make_cpu()
    regs.flag_sign = Z
    regs[1] = Word(10)
    regs[2] = Word(20)
    execute(decode(encode_R(-2, rd=4, rs1=1, rs2=2, funct=3)), regs, mem)
    assert int(regs[4]) == 20

def test_tsel_positive():
    regs, mem = make_cpu()
    regs.flag_sign = P
    regs[1] = Word(10)
    regs[2] = Word(20)
    regs[3] = Word(30)
    execute(decode(encode_R(-2, rd=4, rs1=1, rs2=2, funct=3)), regs, mem)
    assert int(regs[4]) == 30

# ── NOP (−1) ──
def test_nop_no_side_effects():
    regs, mem = make_cpu()
    regs[1] = Word(42)
    regs.pc = Word(5)
    result = execute(decode(encode_R(-1, rd=0, rs1=0, rs2=0)), regs, mem)
    assert result == True
    assert int(regs[1]) == 42
    assert regs.pc == Word(5)

# ── TGET (+1) ──
def test_tget():
    regs, mem = make_cpu()
    regs[1] = Word(1)   # LST = P
    regs[2] = Word(0)   # index trit 0
    execute(decode(encode_R(1, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 1  # P → +1

def test_tget_negative_trit():
    regs, mem = make_cpu()
    regs[1] = Word(-1)  # LST = N
    regs[2] = Word(0)
    execute(decode(encode_R(1, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == -1

# ── TSET (+2) ──
def test_tsetp():
    regs, mem = make_cpu()
    regs[1] = Word(0)   # mot zéro
    regs[2] = Word(0)   # index trit 0
    # funct[13] = P → insérer P
    execute(decode(encode_R(2, rd=3, rs1=1, rs2=2, funct=1)), regs, mem)
    assert regs[3].trits[0] == P

def test_tsetz():
    regs, mem = make_cpu()
    regs[1] = Word(1)   # LST = P
    regs[2] = Word(0)   # index trit 0
    # funct[13] = Z → insérer Z
    execute(decode(encode_R(2, rd=3, rs1=1, rs2=2, funct=0)), regs, mem)
    assert regs[3].trits[0] == Z

def test_tsetn():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    regs[2] = Word(0)
    # funct[13] = N → insérer N
    execute(decode(encode_R(2, rd=3, rs1=1, rs2=2, funct=-1)), regs, mem)
    assert regs[3].trits[0] == N

# ── TSIGN (+3) ──
def test_tsign_positive():
    regs, mem = make_cpu()
    regs[1] = Word(42)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 1

def test_tsign_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-42)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == -1

def test_tsign_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    execute(decode(encode_R(3, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 0

# ── CMP (+4) ──
def test_cmp_less():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == N

def test_cmp_equal():
    regs, mem = make_cpu()
    regs[1] = Word(5)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == Z

def test_cmp_greater():
    regs, mem = make_cpu()
    regs[1] = Word(7)
    regs[2] = Word(5)
    execute(decode(encode_R(4, rd=0, rs1=1, rs2=2)), regs, mem)
    assert regs.flag_sign == P

def test_cmp_no_register_write():
    regs, mem = make_cpu()
    regs[1] = Word(3)
    regs[2] = Word(5)
    regs[3] = Word(99)
    execute(decode(encode_R(4, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 99  # rd non modifié

# ── TABS (+5) ──
def test_tabs_positive():
    regs, mem = make_cpu()
    regs[1] = Word(42)
    execute(decode(encode_R(5, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 42

def test_tabs_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-42)
    execute(decode(encode_R(5, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 42

def test_tabs_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    execute(decode(encode_R(5, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 0

# ── TMIN (+6) ──
def test_tmin_all_positive():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P] * 27)
    execute(decode(encode_R(6, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 1  # P

def test_tmin_has_negative():
    regs, mem = make_cpu()
    regs[1] = Word(-1)  # LST = N
    execute(decode(encode_R(6, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == -1  # N

def test_tmin_all_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    execute(decode(encode_R(6, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 0  # Z

# ── TMAX (+7) ──
def test_tmax_all_negative():
    regs, mem = make_cpu()
    # un mot avec uniquement des trits N
    regs[1] = Word._from_trits([N] * 27, 27)
    execute(decode(encode_R(7, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == -1  # N

def test_tmax_has_positive():
    regs, mem = make_cpu()
    regs[1] = Word(1)  # LST = P, reste Z
    execute(decode(encode_R(7, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 1  # P

def test_tmax_all_zero():
    regs, mem = make_cpu()
    regs[1] = Word(0)
    execute(decode(encode_R(7, rd=2, rs1=1, rs2=0)), regs, mem)
    assert int(regs[2]) == 0  # Z

# ── TAND (−34) ──
def test_tand_kleene():
    regs, mem = make_cpu()
    regs.lmode = Z  # Kleene
    regs[1] = Word._from_trits([P, Z, N] * 9, 27)
    regs[2] = Word._from_trits([P, P, P] * 9, 27)
    execute(decode(encode_R(-34, rd=3, rs1=1, rs2=2)), regs, mem)
    result = regs[3].trits
    assert result[0] == P  # P AND P = P
    assert result[1] == Z  # Z AND P = Z
    assert result[2] == N  # N AND P = N

def test_tand_bochvar_zz():
    regs, mem = make_cpu()
    regs.lmode = P  # BI3
    regs[1] = Word._from_trits([Z] * 27, 27)
    regs[2] = Word._from_trits([Z] * 27, 27)
    execute(decode(encode_R(-34, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == Z

# ── TOR (−33) ──
def test_tor_kleene():
    regs, mem = make_cpu()
    regs.lmode = Z
    regs[1] = Word._from_trits([P, Z, N] * 9, 27)
    regs[2] = Word._from_trits([N, N, N] * 9, 27)
    execute(decode(encode_R(-33, rd=3, rs1=1, rs2=2)), regs, mem)
    result = regs[3].trits
    assert result[0] == P  # P OR N = P
    assert result[1] == Z  # Z OR N = Z
    assert result[2] == N  # N OR N = N

# ── TNOT (−32) ──
def test_tnot_kleene():
    regs, mem = make_cpu()
    regs.lmode = Z
    regs[1] = Word._from_trits([P, Z, N] * 9, 27)
    execute(decode(encode_R(-32, rd=2, rs1=1, rs2=0)), regs, mem)
    result = regs[2].trits
    assert result[0] == N  # NOT P = N
    assert result[1] == Z  # NOT Z = Z
    assert result[2] == P  # NOT N = P

def test_tnot_heyting_z():
    regs, mem = make_cpu()
    regs.lmode = N       # Łukasiewicz/Heyting
    regs.status_lx = N  # Heyting
    regs[1] = Word.from_trits([Z] * 27)
    execute(decode(encode_R(-32, rd=2, rs1=1, rs2=0)), regs, mem)
    assert regs[2].trits[0] == N  # NOT_HT(Z) = N

# ── TIMPL (−31) ──
def test_timpl_kleene():
    regs, mem = make_cpu()
    regs.lmode = Z
    regs[1] = Word.from_trits([P, Z, N] * 9)
    regs[2] = Word.from_trits([N, Z, P] * 9)
    execute(decode(encode_R(-31, rd=3, rs1=1, rs2=2)), regs, mem)
    result = regs[3].trits
    assert result[0] == N  # IMPL(P,N) = N
    assert result[1] == Z  # IMPL(Z,Z) = Z
    assert result[2] == P  # IMPL(N,P) = P

def test_timpl_lukasiewicz_zz():
    regs, mem = make_cpu()
    regs.lmode = N        # Łukasiewicz
    regs.status_lx = Z
    regs[1] = Word.from_trits([Z] * 27)
    regs[2] = Word.from_trits([Z] * 27)
    execute(decode(encode_R(-31, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == P  # IMPL_L(Z,Z) = P

# ── CONS (−30) ──
def test_cons_agreement():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P, Z, N] * 9)
    regs[2] = Word.from_trits([P, Z, N] * 9)
    execute(decode(encode_R(-30, rd=3, rs1=1, rs2=2)), regs, mem)
    result = regs[3].trits
    assert result[0] == P
    assert result[1] == Z
    assert result[2] == N

def test_cons_disagreement():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P] * 27)
    regs[2] = Word.from_trits([N] * 27)
    execute(decode(encode_R(-30, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == Z  # désaccord → Z

# ── ACONS (−29) ──
def test_acons_agreement():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P, Z, N] * 9)
    regs[2] = Word.from_trits([P, Z, N] * 9)
    execute(decode(encode_R(-29, rd=3, rs1=1, rs2=2)), regs, mem)
    result = regs[3].trits
    assert result[0] == Z  # accord → Z
    assert result[1] == Z
    assert result[2] == Z

def test_acons_disagreement_nz():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([N] * 27)
    regs[2] = Word.from_trits([Z] * 27)
    execute(decode(encode_R(-29, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == P  # ACONS(N,Z) = P

def test_acons_disagreement_zp():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([Z] * 27)
    regs[2] = Word.from_trits([P] * 27)
    execute(decode(encode_R(-29, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == N  # ACONS(Z,P) = N

def test_acons_disagreement_np():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([N] * 27)
    regs[2] = Word.from_trits([P] * 27)
    execute(decode(encode_R(-29, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == Z  # ACONS(N,P) = Z

# ── TSHIFT (−28) ──
def test_tshift_left():
    regs, mem = make_cpu()
    regs[1] = Word(1)   # LST = P
    regs[2] = Word(3)   # décalage de 3 trits à gauche
    execute(decode(encode_R(-28, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 27  # 1 * 3^3

def test_tshift_right():
    regs, mem = make_cpu()
    regs[1] = Word(27)  # 3^3
    regs[2] = Word(-3)  # décalage de 3 trits à droite
    execute(decode(encode_R(-28, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 1

def test_tshift_zero():
    regs, mem = make_cpu()
    regs[1] = Word(42)
    regs[2] = Word(0)   # pas de décalage
    execute(decode(encode_R(-28, rd=3, rs1=1, rs2=2)), regs, mem)
    assert int(regs[3]) == 42

def test_tshift_vacated_z():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P] * 27)
    regs[2] = Word(1)   # décalage gauche de 1
    execute(decode(encode_R(-28, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == Z  # trit entrant = Z

# ── TCMP (−27) ──
def test_tcmp_all_equal():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P, Z, N] * 9)
    regs[2] = Word.from_trits([P, Z, N] * 9)
    execute(decode(encode_R(-27, rd=3, rs1=1, rs2=2)), regs, mem)
    for t in regs[3].trits:
        assert t == Z  # égaux → Z partout

def test_tcmp_rs1_greater():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([P] * 27)
    regs[2] = Word.from_trits([N] * 27)
    execute(decode(encode_R(-27, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == P  # P > N → P

def test_tcmp_rs1_less():
    regs, mem = make_cpu()
    regs[1] = Word.from_trits([N] * 27)
    regs[2] = Word.from_trits([P] * 27)
    execute(decode(encode_R(-27, rd=3, rs1=1, rs2=2)), regs, mem)
    assert regs[3].trits[0] == N  # N < P → N
