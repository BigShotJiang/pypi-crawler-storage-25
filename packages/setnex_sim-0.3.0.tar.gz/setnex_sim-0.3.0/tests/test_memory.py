from setnex_sim.word import Word
from setnex_sim.memory import Memory
import pytest

def test_write_read():
    mem = Memory()
    addr = Word(42)
    val  = Word(100)
    mem[addr] = val
    assert mem[addr] == val

def test_uninitialised_raises():
    mem = Memory()
    with pytest.raises(KeyError):
        _ = mem[Word(99)]

def test_overwrite():
    mem = Memory()
    addr = Word(0)
    mem[addr] = Word(1)
    mem[addr] = Word(2)
    assert int(mem[addr]) == 2

def test_load():
    mem = Memory()
    program = [Word(i) for i in range(5)]
    start = Word(0)
    mem.load(start, program)
    for i, word in enumerate(program):
        assert mem[Word(i)] == word

def test_different_addresses_independent():
    mem = Memory()
    mem[Word(0)] = Word(10)
    mem[Word(1)] = Word(20)
    assert int(mem[Word(0)]) == 10
    assert int(mem[Word(1)]) == 20
