from setnex_sim.registers import  Registers 
from tritlib import Z, N, P
from setnex_sim.word import Word

def test_status_init():
    regs = Registers()
    assert regs.status_mode == Z
    assert regs.status_irq == Z

def test_status_write():
    regs = Registers()
    regs.status_mode = P  # kernel
    assert regs.status_mode == P
    regs.status_irq = P   # enabled
    assert regs.status_irq == P

def test_epc_init_zero():
    regs = Registers()
    assert regs.epc == Word.ZERO

def test_ecause_init_zero():
    regs = Registers()
    assert regs.ecause == Word.ZERO

def test_evec_init_zero():
    regs = Registers()
    assert regs.evec == Word.ZERO

def test_lmode_trit_init():
    regs = Registers()
    assert regs._lmode == Z
    assert regs.lmode == Word(0)

def test_lmode_write():
    regs = Registers()
    regs._lmode = N
    assert regs._lmode == N
    assert regs.lmode == Word("-")

def test_flags():
    regs = Registers()
    assert regs.flags == Word(0)
    regs.flag_sign = P
    assert regs.flags == Word("+")
    regs.flag_carry = N
    assert regs.flags == Word("-+")

def test_status():
    regs = Registers()
    assert regs.status == Word(0)
    regs.status = Word("+-+")
    assert regs.status_mode == P
    assert regs.status_irq == N
    assert regs.status_lx == P

    regs.status = Word("0+-")
    assert regs.status_mode == N
    assert regs.status_irq == P
    assert regs.status_lx == Z
