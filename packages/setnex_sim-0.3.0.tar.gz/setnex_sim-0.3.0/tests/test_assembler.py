from setnex_sim.assembler import encode_R, encode_I, encode_J, encode_U, encode_B
from setnex_sim.decoder import decode

# R format
def test_encode_R_basic():
    w = encode_R(opcode=-40, rd=3, rs1=1, rs2=2)
    from setnex_sim.decoder import decode
    instr = decode(w)
    assert instr.opcode == -40
    assert instr.rd == 3
    assert instr.rs1 == 1
    assert instr.rs2 == 2
    assert instr.funct == 0

def test_encode_R_with_funct():
    w = encode_R(opcode=-40, rd=1, rs1=2, rs2=3, funct=5)
    instr = decode(w)
    assert instr.funct == 5

# I format
def test_encode_I_basic():
    w = encode_I(opcode=-26, rd=2, rs1=1, imm=42)
    instr = decode(w)
    assert instr.opcode == -26
    assert instr.rd == 2
    assert instr.rs1 == 1
    assert instr.imm == 42

def test_encode_I_negative_imm():
    w = encode_I(opcode=-26, rd=2, rs1=1, imm=-100)
    instr = decode(w)
    assert instr.imm == -100

# J format
def test_encode_J_basic():
    w = encode_J(opcode=-17, rs1=3, offset=1000)
    instr = decode(w)
    assert instr.opcode == -17
    assert instr.rs1 == 3
    assert instr.offset == 1000

def test_encode_J_negative_offset():
    w = encode_J(opcode=-15, rs1=1, offset=-500)
    instr = decode(w)
    assert instr.offset == -500

# U format
def test_encode_U_basic():
    w = encode_U(opcode=-9, offset=100000)
    instr = decode(w)
    assert instr.opcode == -9
    assert instr.offset == 100000

def test_encode_U_call():
    w = encode_U(opcode=-8, offset=-50000)
    instr = decode(w)
    assert instr.opcode == -8
    assert instr.offset == -50000

# B format
def test_encode_B_basic():
    w = encode_B(opcode=-21, rx=2, off_z=100, off_n=-50)
    instr = decode(w)
    assert instr.opcode == -21
    assert instr.rx == 2
    assert instr.off_z == 100
    assert instr.off_n == -50

def test_encode_B_zero_offsets():
    w = encode_B(opcode=-21, rx=0, off_z=0, off_n=0)
    instr = decode(w)
    assert instr.off_z == 0
    assert instr.off_n == 0

def test_encode_B_max_offsets():
    max_off = (3**10 - 1) // 2  # 29524
    w = encode_B(opcode=-21, rx=1, off_z=max_off, off_n=-max_off)
    instr = decode(w)
    assert instr.off_z == max_off
    assert instr.off_n == -max_off


