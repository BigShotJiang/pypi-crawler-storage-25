from setnex_sim.alu import add, cons, acons, shift, sub, tand, tcmp, tnot, tor, txor, timpl, mul,div,mod
from setnex_sim.registers import Registers
from setnex_sim.word import Word
from tritlib import Tryte, N, Z, P

def test_add():
    a = Word(123)
    b = Word(456)
    result, flags = add(a,b)
    assert isinstance(result, Tryte)
    assert len(result) == 27
    assert int(result) == 123+456
    assert flags['carry'] == Z
    assert flags['sign'] == P

    
def test_add_carry():
    a = Word(int(Word.MAX)-3)
    b = Word(4)
    result, flags = add(a,b)
    assert isinstance(result, Tryte)
    assert len(result) == 27
    assert result == Word.MIN
    assert flags['carry'] == P
    assert flags['sign'] == N

    result, flags = add(b, -b)
    assert flags['sign'] == Z

def test_sub():
    a = Word(123)
    b = Word(456)
    result, flags = sub(a,b)
    assert isinstance(result, Tryte)
    assert len(result) == 27
    assert int(result) == 123-456
    assert flags['carry'] == Z
    assert flags['sign'] == N

def test_sub_carry():
    a = Word(int(Word.MIN)+2)
    b = Word(3)
    result, flags = sub(a,b)
    assert isinstance(result, Tryte)
    assert len(result) == 27
    assert result == Word.MAX
    assert flags['carry'] == N
    assert flags['sign'] == P

def test_tand():
    a = Word("+++---000")
    b = Word("+0-+0-+0-")
    regs = Registers()
    assert tand(a, b, regs) == Word("+0----00-")
    regs._lmode = N
    assert tand(a, b, regs) == Word("+0----00-")
    regs._lmode = P
    assert tand(a, b, regs) == Word("00000000000000000+0--0-000")


def test_tnot():
    a = Word("---++0")
    b = Word("+++--0")
    regs = Registers()
    assert tnot(a, regs) == b
    regs._lmode = N
    assert tnot(a, regs) == b
    regs._lmode = P
    assert tnot(a, regs) == b


def test_tor():
    a = Word("+++---000")
    b = Word("+0-+0-+0-")

    regs = Registers()
    assert tor(a, b, regs) == Word("++++0-+00")
    regs._lmode = N
    assert tor(a, b, regs) == Word("++++0-+00")
    regs._lmode = P
    assert tor(a, b, regs) == Word("000000000000000000+0++0-000")

def test_txor():
    a = Word("+++000---")
    b = Word("+0-+0-+0-")

    regs = Registers()
    assert txor(a, b, regs) == Word("-0+000+0-")
    regs._lmode = N
    assert txor(a, b, regs) == Word("-0+000+0-")
    regs._lmode = P
    assert txor(a, b, regs) == Word("000000000000000000-0+000+0-")


def test_timpl():
    a = Word("+++000---")
    b = Word("+0-+0-+0-")
    regs = Registers()
    regs._lmode = N
    assert timpl(a, b, regs) == Word("+++++++++++++++++++0-++0+++")
    regs._lmode = Z
    assert timpl(a, b, regs) == Word("+0-+00+++")
    regs._lmode = P
    assert timpl(a, b, regs) == Word("+0-000+0+")

def test_mul():
    a = Word(42)
    b = Word(234)

    assert int(mul(a, b)[0]) == int(a)*int(b)
    b = Word(-12)
    assert int(mul(a, b)[0]) == int(a)*int(b)

def test_div_mod():
    a = Word(40)
    b = Word(6)
    assert int(div(a,b)) == 7
    assert int(mod(a,b)) == -2

def test_cons():
    a = Word("+++---000")
    b = Word("+-0+-0+-0")
    assert cons(a, b) == Word("+000-0000")

def test_acons():
    a = Word("+++---000")
    b = Word("+-0+-0+-0")
    assert acons(a, b) == Word("00-00+-+0")

def test_tcmp():
    a = Word("+++---000")
    b = Word("+-0+-0+-0")
    assert tcmp(a, b) == Word("0++-0--+0")

def test_shift():
    a_trits = "+-0-++++-0"
    a = Word(a_trits)
    assert shift(a, Word(1)) == Word(a_trits + "0")
    assert shift(a, Word(2)) == Word(a_trits + "00")
    assert shift(a, Word(3)) == Word(a_trits + "000")
    assert shift(a, Word(4)) == Word(a_trits + "0000")
    assert shift(a, Word(-1)) == Word(a_trits[:-1])
    assert shift(a, Word(-2)) == Word(a_trits[:-2])
    assert shift(a, Word(-5)) == Word(a_trits[:-5])
    assert shift(a, Word(-9)) == Word(a_trits[:-9])
