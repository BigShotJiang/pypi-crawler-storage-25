from setnex_sim.word import Word

def test_word_init():
    a = Word(42)
    assert len(a) == 27
    assert int(a) == 42

    b = Word(-432)

    assert len(b) == 27
    assert int(b) == -432

def test_word_min_max_zero():
    assert Word(0) == Word.ZERO
    assert Word(3812798742493) == Word.MAX == -Word.MIN

def test_word_rshift():
    a = Word(10)
    assert Word(30) == a << 1

    assert Word(3) == a >> 1
