# setnex-sim

Python simulator for the [Setnex ISA](https://setnex.org) — an open balanced ternary instruction set architecture.

Implements the full fetch/decode/execute cycle for a 27-trit processor:
27 general-purpose registers, 5 configurable ternary logic modes (LMODE), and fixed-length R/I/J/U/B instructions.

Built on [tritlib](https://codeberg.org/setnex/tritlib).

## Status

v0.3 — fully functional simulator. 46 opcodes implemented, 98% test coverage.

Implemented:
- Decoder (R, I, J, U, B formats)
- ALU (ADD, SUB, MUL, DIV, MOD, NEG, TAND, TOR, TNOT, TIMPL, CONS, ACONS, TSHIFT, TCMP, TGET, TSET, TSIGN, TABS, TMIN, TMAX)
- Configurable ternary logic via LMODE (Kleene, Łukasiewicz, Heyting, RM3, Bochvar)
- Registers (27 GPR + CSR: PC, LMODE, FLAGS, EPC, ECAUSE, EVEC, STATUS, ESAVE)
- Sparse word-addressed memory
- CPU fetch/decode/execute loop with ternary FLAGS (sign, carry)
- Branches and jumps (BEQ, BNE, BLT, BGT, BLE, BGE, BF, BRT3, JMP, JMPA, CALL)
- System instructions (CSRR, CSRW, CSRX, ECALL, IRET, TSEL)

## Install

```bash
pip install setnex-sim
```

Or from source:

```bash
git clone https://codeberg.org/setnex/setnex-sim
cd setnex-sim
pip install -e ".[dev]"
```

## Usage

```python
from setnex_sim.cpu import CPU
from setnex_sim.assembler import encode_R, encode_I

cpu = CPU()

program = [
    encode_I(-24, rd=1, rs1=0, imm=5),   # LI r1, 5
    encode_I(-24, rd=2, rs1=0, imm=3),   # LI r2, 3
    encode_R(-40, rd=3, rs1=1, rs2=2),   # ADD r3, r1, r2
    encode_R(0,   rd=0, rs1=0, rs2=0),   # HALT
]

cpu.load(program)
cpu.run()
print(int(cpu.regs[3]))  # 8
```

## Setnex ISA

The full ISA specification is available at [setnex.org](https://setnex.org) and on
[Codeberg](https://codeberg.org/setnex/setnex-isa) — Apache 2.0, patent-free.

## Licence

MIT — Copyright 2026 Eric Tellier
