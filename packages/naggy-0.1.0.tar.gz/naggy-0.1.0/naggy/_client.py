from __future__ import annotations

from typing import Any

from ._http import HTTPClient


class NaggyClient:
    """Full-surface client for the NaggyAI platform API."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://parallaxed.app",
        timeout: float = 15.0,
    ) -> None:
        self._http = HTTPClient(api_key, base_url, timeout=timeout)
        self.api_key = api_key
        self.base_url = base_url

    # ── Events ────────────────────────────────────────────────────────────────

    def ingest(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        """Send a batch of telemetry events."""
        return self._http.post("/v1/naggyai/events", {"events": events})

    def list_events(
        self,
        *,
        provider: str | None = None,
        model: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if provider:
            params["provider"] = provider
        if model:
            params["model"] = model
        if status:
            params["status"] = status
        return self._http.get("/v1/naggyai/events", params)["events"]

    # ── Overview & Config ─────────────────────────────────────────────────────

    def overview(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/overview")

    def config(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/config")

    # ── Stats ─────────────────────────────────────────────────────────────────

    def cost_by_provider(self) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/stats/cost-by-provider")["breakdown"]

    def cost_by_model(self) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/stats/cost-by-model")["breakdown"]

    def error_stats(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/stats/errors")

    # ── Score ─────────────────────────────────────────────────────────────────

    def score(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/score")

    def score_history(self, *, limit: int = 30) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/score/history", {"limit": limit})

    # ── Insights ──────────────────────────────────────────────────────────────

    def list_insights(
        self, *, status: str = "active", limit: int = 50, offset: int = 0
    ) -> list[dict[str, Any]]:
        return self._http.get(
            "/v1/naggyai/insights",
            {"status": status, "limit": limit, "offset": offset},
        )["insights"]

    def generate_insights(self) -> list[dict[str, Any]]:
        return self._http.post("/v1/naggyai/insights/generate")["insights"]

    def dismiss_insight(self, insight_id: str) -> dict[str, Any]:
        return self._http.post(f"/v1/naggyai/insights/{insight_id}/dismiss")

    def apply_insight(self, insight_id: str) -> dict[str, Any]:
        return self._http.post(f"/v1/naggyai/insights/{insight_id}/apply")

    # ── Alerts ────────────────────────────────────────────────────────────────

    def list_alert_rules(self, *, limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
        return self._http.get(
            "/v1/naggyai/alerts/rules", {"limit": limit, "offset": offset}
        )["rules"]

    def evaluate_alerts(self) -> list[dict[str, Any]]:
        return self._http.post("/v1/naggyai/alerts/evaluate")["triggered"]

    def alert_history(self, *, limit: int = 50) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/alerts/history", {"limit": limit})["history"]

    def intelligence(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/intelligence")

    # ── Nags ──────────────────────────────────────────────────────────────────

    def nag_history(
        self, *, status: str = "", limit: int = 50, offset: int = 0
    ) -> list[dict[str, Any]]:
        return self._http.get(
            "/v1/naggyai/nags",
            {"status": status, "limit": limit, "offset": offset},
        )["history"]

    def acknowledge_nag(self, nag_item_id: str) -> dict[str, Any]:
        return self._http.post(f"/v1/naggyai/nags/{nag_item_id}/acknowledge")

    # ── Traces ────────────────────────────────────────────────────────────────

    def list_traces(self, *, limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
        return self._http.get(
            "/v1/naggyai/traces", {"limit": limit, "offset": offset}
        )["traces"]

    def get_trace(self, trace_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/naggyai/traces/{trace_id}")

    # ── Feedback ──────────────────────────────────────────────────────────────

    def submit_feedback(
        self,
        trace_id: str,
        *,
        score: float,
        label: str = "",
        comment: str = "",
        environment: str = "production",
    ) -> dict[str, Any]:
        return self._http.post(
            "/v1/naggyai/feedback",
            {
                "trace_id": trace_id,
                "score": score,
                "label": label,
                "comment": comment,
                "environment": environment,
            },
        )

    def list_feedback(
        self,
        *,
        trace_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if trace_id:
            params["trace_id"] = trace_id
        return self._http.get("/v1/naggyai/feedback", params)["feedback"]

    # ── Standup ───────────────────────────────────────────────────────────────

    def standup(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/standup")

    def standup_history(self, *, limit: int = 30) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/standup/history", {"limit": limit})

    # ── API Keys ──────────────────────────────────────────────────────────────

    def create_key(self, project_id: str, *, name: str = "default") -> dict[str, Any]:
        return self._http.post(
            "/v1/naggyai/keys", {"project_id": project_id, "name": name}
        )

    def list_keys(self, project_id: str) -> list[dict[str, Any]]:
        return self._http.get("/v1/naggyai/keys", {"project_id": project_id})

    def revoke_key(self, key_id: str) -> dict[str, Any]:
        return self._http.delete(f"/v1/naggyai/keys/{key_id}")

    # ── Health ────────────────────────────────────────────────────────────────

    def health(self) -> dict[str, Any]:
        return self._http.get("/v1/naggyai/health")
