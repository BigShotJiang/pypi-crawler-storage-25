from __future__ import annotations

import httpx
from typing import Any


class NaggyHTTPError(Exception):
    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(f"HTTP {status_code}: {detail}")
        self.status_code = status_code
        self.detail = detail


class HTTPClient:
    def __init__(self, api_key: str, base_url: str, timeout: float = 15.0) -> None:
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    def _raise(self, r: httpx.Response) -> None:
        if r.is_error:
            try:
                detail = r.json().get("error", r.text[:200])
            except Exception:
                detail = r.text[:200]
            raise NaggyHTTPError(r.status_code, detail)

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        with httpx.Client(timeout=self._timeout) as c:
            r = c.get(f"{self._base}{path}", headers=self._headers, params=params or {})
        self._raise(r)
        return r.json()

    def post(self, path: str, body: Any = None) -> Any:
        with httpx.Client(timeout=self._timeout) as c:
            r = c.post(f"{self._base}{path}", headers=self._headers, json=body)
        self._raise(r)
        return r.json()

    def delete(self, path: str) -> Any:
        with httpx.Client(timeout=self._timeout) as c:
            r = c.delete(f"{self._base}{path}", headers=self._headers)
        self._raise(r)
        return r.json()
