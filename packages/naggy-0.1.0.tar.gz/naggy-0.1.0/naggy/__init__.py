from __future__ import annotations

from typing import Any

from ._client import NaggyClient
from ._event import feedback_event, llm_event
from ._http import NaggyHTTPError
from ._trace import trace, trace_context

__all__ = [
    "NaggyClient",
    "NaggyHTTPError",
    "init",
    "get_client",
    "trace",
    "trace_context",
    "llm_event",
    "feedback_event",
    "instrument_anthropic",
    "instrument_openai",
]

_default_client: NaggyClient | None = None


def init(
    api_key: str,
    *,
    base_url: str = "https://parallaxed.app",
    timeout: float = 15.0,
) -> NaggyClient:
    """Configure the module-level default client. Call once at startup."""
    global _default_client
    _default_client = NaggyClient(api_key, base_url=base_url, timeout=timeout)
    return _default_client


def get_client() -> NaggyClient:
    if _default_client is None:
        raise RuntimeError("Call naggy.init(api_key=...) before using the SDK.")
    return _default_client


def instrument_anthropic(anthropic_client: Any, *, environment: str = "production") -> Any:
    from .integrations.anthropic import instrument
    return instrument(anthropic_client, environment=environment)


def instrument_openai(openai_client: Any, *, environment: str = "production") -> Any:
    from .integrations.openai import instrument
    return instrument(openai_client, environment=environment)
