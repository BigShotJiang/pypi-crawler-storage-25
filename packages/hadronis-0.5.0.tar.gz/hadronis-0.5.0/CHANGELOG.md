# Changelog

<!--next-version-placeholder-->

## v0.5.0 (2026-04-03)

### Feature

* Add Codecov configuration and update GitHub Actions for push events ([`ad292c2`](https://github.com/louischereau/Hadronis/commit/ad292c2411e879c82c07a8bfc19772b4498729ce))
* Enhance C++ coverage instrumentation and improve quality check workflow ([`9cf1514`](https://github.com/louischereau/Hadronis/commit/9cf151471c4d0c82fb03722728796e211f05dafc))
* Enhance quality checks and optimize graph building with improved coverage and performance metrics ([`9c06ef8`](https://github.com/louischereau/Hadronis/commit/9c06ef87a3b75dce9eff5a6b3bd5414b8135f7d7))
* Optimize benchmarks and profiling configurations for improved performance ([`b7dbf3d`](https://github.com/louischereau/Hadronis/commit/b7dbf3d1a91466424344d3b255d7d67dd57eade2))

### Fix

* Update LLVM_PROFILE_FILE path for C++ test coverage profiles ([`88fd60f`](https://github.com/louischereau/Hadronis/commit/88fd60fe9bdae1a367a7921711db7818dec744e0))
* Remove unnecessary llvm-profdata and llvm-cov installation from C++ dependencies ([`d36d508`](https://github.com/louischereau/Hadronis/commit/d36d508313b3f138aac028960c2ccbc381677469))
