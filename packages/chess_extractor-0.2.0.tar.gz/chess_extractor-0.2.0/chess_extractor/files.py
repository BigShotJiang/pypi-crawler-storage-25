import csv

def export_tsv(path, games):
    fieldnames = ["federation", "opponent", "o_rating", "color", "result", "month", "p_rating", "k_chg"]
    with open(path, 'w', newline='', encoding="utf-8") as csvfile: 
        writer = csv.DictWriter(csvfile, delimiter="\t", fieldnames=fieldnames)
        writer.writeheader()
        for row in games:
            writer.writerow(row)