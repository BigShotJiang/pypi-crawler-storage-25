import requests
from bs4 import BeautifulSoup
from pathlib import Path

def fetch_html(url, params, headers=None, cache_file=None, use_cache=False):
    if use_cache and cache_file and cache_file.exists():
        return cache_file.read_text(encoding="utf-8")

    r = requests.get(url, params=params, headers=headers, timeout=10)
    text = r.text

    if use_cache and cache_file:
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.write_text(text, encoding="utf-8")

    return text

def get_fide_games(id_number, month, use_cache=False):
    BASE_DIR = Path(__file__).resolve().parent
    cache_dir = BASE_DIR / "cache"
    cache_dir.mkdir(exist_ok=True)

    cache_file = cache_dir / f"{id_number}_{month}.html"
    url = "https://ratings.fide.com/a_indv_calculations.php"

    params = {
        "id_number": id_number,
        "rating_period": month + "-01",
        "t": "0"
    }

    headers = {
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://ratings.fide.com/"
    }

    text = fetch_html(url, params, headers, cache_file, use_cache)

    soup = BeautifulSoup(text, "html.parser")
    tables = soup.find_all("table", class_="calc_table")

    partidas = []

    for table in tables:
        for row in table.find_all("tr"):
            cols = row.find_all("td")
            if not cols:
                continue

            span = row.find("span", class_=["black_note", "white_note"])
            color = None

            if span:
                if "black_note" in span.get("class", []):
                    color = "Black"
                elif "white_note" in span.get("class", []):
                    color = "White"

            name = cols[0].get_text(strip=True)

            if not name or name[0].isdigit() or "Rc" in name:
                continue

            raw = [c.get_text(strip=True) or None for c in cols]

            if len(raw) < 10:
                continue
            o_rating = raw[3]
            if o_rating.endswith("*"):
                o_rating = o_rating[:-1]
            partidas.append({
                "month": month,
                "opponent": raw[0],
                "color": color,
                "o_rating": int(o_rating),
                "federation": raw[4],
                "result": float(raw[5]),
                "k_chg": float(raw[9])
            })

    return partidas