from chess_extractor.filters import filter_by_elo_diff

def compute_fide_performance(games: list[dict]):
    """
    Calculates FIDE performance rating:
    
        Rp = Ra + dp
    
    Where:
        Ra = average opponent rating
        dp = value from FIDE table based on score
    """

    if not games:
        return None

    # --- FIDE dp table ---
    dp_table = {1.0: 800, 0.99: 677, 0.98: 589, 0.97: 538, 0.96: 501, 0.95: 470, 0.94: 444, 0.93: 422,
                0.92: 401, 0.91: 383, 0.9: 366, 0.89: 351, 0.88: 336, 0.87: 322, 0.86: 309, 0.85: 296,
                0.84: 284, 0.83: 273, 0.82: 262, 0.81: 251, 0.8: 240, 0.79: 230, 0.78: 220, 0.77: 211,
                0.76: 202, 0.75: 193, 0.74: 184, 0.73: 175, 0.72: 166, 0.71: 158, 0.7: 149, 0.69: 141,
                0.68: 133, 0.67: 125, 0.66: 117, 0.65: 110, 0.64: 102, 0.63: 95, 0.62: 87, 0.61: 80,
                0.6: 72, 0.59: 65, 0.58: 57, 0.57: 50, 0.56: 43, 0.55: 36, 0.54: 29, 0.53: 21, 0.52: 14,
                0.51: 7, 0.5: 0, 0.49: -7, 0.48: -14, 0.47: -21, 0.46: -29, 0.45: -36, 0.44: -43, 0.43: -50,
                0.42: -57, 0.41: -65, 0.4: -72, 0.39: -80, 0.38: -87, 0.37: -95, 0.36: -102, 0.35: -110,
                0.34: -117, 0.33: -125, 0.32: -133, 0.31: -141, 0.3: -149, 0.29: -158, 0.28: -166, 0.27: -175,
                0.26: -184, 0.25: -193, 0.24: -202, 0.23: -211, 0.22: -220, 0.21: -230, 0.2: -240, 0.19: -251,
                0.18: -262, 0.17: -273, 0.16: -284, 0.15: -296, 0.14: -309, 0.13: -322, 0.12: -336, 0.11: -351,
                0.1: -366, 0.09: -383, 0.08: -401, 0.07: -422, 0.06: -444, 0.05: -470, 0.04: -501, 0.03: -538,
                0.02: -589, 0.01: -677, 0.0: -800}

    n = len(games)
    ra = sum(g["o_rating"] for g in games) / n
    score = sum(g["result"] for g in games)
    p = score/n
    p_key = round(p, 2)
    dp = dp_table.get(p_key, 0)
    rp = ra + dp

    return rp

def compute_elo_change(games: list[dict]) -> float:
    """
    Computes Elo change in two different ways:

    1) Expected change (K-factor accumulation)
       expected_change = sum of k_chg across all games
       → reflects per-game Elo updates from FIDE system

    2) Real rating evolution (start → end)
       real_change = last p_rating - first p_rating
       → reflects actual rating progression in time window

    Returns:
        (expected_change, real_change)
    """

    if not games:
        expected_change = 0.0

    else:
        expected_change = sum(game.get("k_chg", 0) for game in games)
    if len(games) < 2:
        real_change = 0.0
    else:
        real_change = games[-1]["p_rating"] - games[0]["p_rating"]
    return expected_change, real_change


def compute_results_in_elo_range(games: list[dict], elo_diff_lower: int = None, elo_diff_upper: int = None):
    """
    Counts results only for games where opponent Elo difference
    is within a fixed range relative to the player.

    diff = opponent_rating - player_rating

    Only games satisfying:
        elo_diff_lower <= diff <= elo_diff_upper
    are included.
    """
    filtered_games = filter_by_elo_diff(games, elo_diff_lower, elo_diff_upper)
    stats = {"wins": 0, "draws": 0, "losses": 0, "games": 0}
    stats["games"] = len(filtered_games)
    for g in filtered_games:
        if g["result"] > 0.75:
            stats["wins"] += 1
        elif g["result"] == 0.5:
            stats["draws"] += 1
        else:
            stats["losses"] += 1

    return stats