def normalize_bounds(lower, upper):
    return (float("-inf") if lower is None else lower,float("inf") if upper is None else upper)
def filter_by_elo_diff(games: list[dict], elo_diff_lower: int = None, elo_diff_upper: int = None):
    lower, upper = normalize_bounds(elo_diff_lower, elo_diff_upper)
    
    return [g.copy() for g in games if lower <= (g["o_rating"] - g["p_rating"]) <= upper]