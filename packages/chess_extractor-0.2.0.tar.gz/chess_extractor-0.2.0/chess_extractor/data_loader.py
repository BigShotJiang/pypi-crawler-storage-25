import requests
from bs4 import BeautifulSoup
from datetime import datetime
from chess_extractor.scraper import get_fide_games

def get_rating_history(fide_id):
    url = f"https://ratings.fide.com/profile/{fide_id}"

    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")

    rows = soup.find_all("tr")
    rows.reverse()
    rating_history = {}

    for row in rows:
        cols = row.find_all("td")

        if len(cols) < 2:
            continue

        month_str = cols[0].get_text(strip=True)
        rating = cols[1].get_text(strip=True)

        # filtrar filas que no sean meses
        if "-" not in month_str:
            continue

        # convertir "2026-Apr" -> "2026-04"
        fecha = datetime.strptime(month_str, "%Y-%b").strftime("%Y-%m")

        try:
            rating_history[fecha] = int(rating)
        except ValueError:
            continue
    return rating_history


def load_games(fide_id, use_cache=False, date_from="2008-04", date_to=None):
    rating_history = get_rating_history(fide_id)
    games = []

    min_date = datetime(2008, 4, 1)
    from_date = datetime.strptime(date_from, "%Y-%m") if date_from else None
    to_date = datetime.strptime(date_to, "%Y-%m") if date_to else None
    if from_date and from_date < min_date:
        from_date = min_date
    for t in sorted(rating_history):
        t_date = datetime.strptime(t, "%Y-%m")
        if from_date and t_date < from_date:
            continue

        if to_date and t_date > to_date:
            continue
        monthly_games = get_fide_games(fide_id, t, use_cache=use_cache)

        for g in monthly_games:
            g = g.copy()
            g["p_rating"] = rating_history[t]
            games.append(g)

    return games