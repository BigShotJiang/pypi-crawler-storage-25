import argparse

from chess_extractor.data_loader import load_games
from chess_extractor.analysis import compute_fide_performance, compute_elo_change, compute_results_in_elo_range
from chess_extractor.files import export_tsv


def print_games(games: list[dict]):    
    print("{0:^5}{1:^45}{2:^12}{3:^8}{4:^8}{5:^8}{6:^10}".format("(FED)", "Opponent", "Opponent ELO", "W", "Month", "Own ELO", "ELO change"))
    for game in games:
        print("{0:^5}{1:^45}{2:^12}{3:^8}{4:^8}{5:^8}{6:^10}".format(f"({game['federation']})", game["opponent"], game["o_rating"], game["result"], game["month"], game["p_rating"], game["k_chg"]))


def main():
    p = argparse.ArgumentParser(description="Fetch and export FIDE game data")

    sub = p.add_subparsers(dest="command", required=True)

    p_games = sub.add_parser("fetch", help="Extract all games of the player")
    p_games.add_argument("id", help="Player FIDE ID")
    p_games.add_argument("--date-from", dest="date_from", default="2008-04", help="Start date YYYY-MM")
    p_games.add_argument("--date-to", dest="date_to", default=None, help="End date YYYY-MM")
    p_games.add_argument("--export", default=None, help="Output TSV file (optional)")
    p_games.add_argument("--cache", action="store_true", help="Enable local cache")
    
    p_analyze = sub.add_parser("analyze", help="Analyze games dataset")

    group = p_analyze.add_mutually_exclusive_group(required=True)

    group.add_argument("--id", help="FIDE player ID")
    group.add_argument("--file", help="Local TSV file")
    p_analyze.add_argument("--date-from", dest="date_from", default="2008-04", help="Start date YYYY-MM")
    p_analyze.add_argument("--date-to", dest="date_to", default=None, help="End date YYYY-MM")
    p_analyze.add_argument("--performance", action="store_true", help="Compute FIDE performance rating")
    p_analyze.add_argument("--elo-change", action="store_true", help="Compute total Elo change")
    p_analyze.add_argument("--elo-diff-range", action="store_true", help="Enable Elo difference range analysis")
    p_analyze.add_argument("--elo-diff-upper", type=int, default=None, help="Upper bound of opponent Elo difference")
    p_analyze.add_argument("--elo-diff-lower", type=int, default=None, help="Lower bound of opponent Elo difference")
    p_analyze.add_argument("--cache", action="store_true", help="Enable local cache")

    args = p.parse_args()

    if args.command == "fetch":
        games = load_games(args.id, use_cache=args.cache, date_from=args.date_from, date_to=args.date_to)
        print_games(games)

        if args.export:
            export_tsv(args.export,games)
            print(f"Exported TSV: {args.export}")
    elif args.command == "analyze":
        if args.id:
            if not (args.performance or args.elo_change or args.elo_diff_range):
                print("❌ You must request at least one analysis flag: --performance or --elo-change or --elo-diff-range")
                return
            
            games = load_games(args.id, use_cache=args.cache, date_from=args.date_from, date_to=args.date_to)
            print("📊 BASIC STATS")
            print("Games:", len(games))

            if not games:
                print("No games found")
                return
            
            # 1. Performance
            if args.performance:
                rp = compute_fide_performance(games)
                print(f"FIDE Performance Rating: {rp:.2f}")

            # 2. Elo change
            if args.elo_change:
                expected_change, real_change = compute_elo_change(games)

                print("📊 Elo change analysis:")
                print(f"Expected (K-factor sum): {expected_change:.2f}")
                print(f"Observed (rating delta): {real_change:.2f}")
                print(f"Difference:              {(real_change - expected_change):.2f}")

            # 3. Elo difference range analysis
            if args.elo_diff_range:
                if args.elo_diff_upper is None and args.elo_diff_lower is None:
                    print("❌ You must specify at least one bound")
                    return
                upper = args.elo_diff_upper
                lower = args.elo_diff_lower
                high = upper if upper is not None else "inf"
                low = lower if lower is not None else "-inf"

                stats = compute_results_in_elo_range(games, elo_diff_upper=upper, elo_diff_lower=lower)

                g, w, d, l = stats["games"], stats["wins"], stats["draws"], stats["losses"]
                if g > 0:
                    w_p = round(w/g, 2)
                    d_p = round(d/g, 2)
                    l_p = round(l/g, 2)
                else:
                    w_p = d_p = l_p = 0

                print(f"📊 RESULTS (Elo diff [{low}, {high}])")
                print(f"Games:   {g}")
                print(f"Wins:    {w}   Win percentage:   {w_p}")
                print(f"Draws:   {d}   Draw percentage:  {d_p}")
                print(f"Losses:  {l}   Loss percentage:   {l_p}")
        elif args.file:
            print("Offline mode not implemented yet")
    else:
        raise SystemExit("Comando no implementado.")
    
if __name__ == "__main__":
    main()