import subprocess


def test_cli_runs():
    result = subprocess.run(
        ["fide-games", "games", "1503014"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert "Opponent" in result.stdout