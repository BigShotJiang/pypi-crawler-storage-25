from chess_extractor.fide_func import load_games


def test_load_games_returns_list():
    games = load_games("1503014", use_cache=False)

    assert isinstance(games, list)
    assert len(games) > 0


def test_game_structure():
    games = load_games("1503014", use_cache=False)
    game = games[0]

    expected_keys = {
        "federation",
        "opponent",
        "o_rating",
        "result",
        "month",
        "p_rating",
        "k_chg",
    }

    assert expected_keys.issubset(game.keys())