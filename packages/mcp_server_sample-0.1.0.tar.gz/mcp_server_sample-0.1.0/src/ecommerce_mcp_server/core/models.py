from typing import Annotated, Self
from datetime import datetime, timedelta, date as datetime_date
from zoneinfo import ZoneInfo
from pydantic import BaseModel, Field, field_validator, model_validator

# ############################
# tool 등에서 사용하는 입출력 명시
# ############################
