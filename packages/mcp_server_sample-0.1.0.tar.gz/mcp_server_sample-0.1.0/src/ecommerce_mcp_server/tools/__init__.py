from fastmcp import FastMCP

from .ecommerce import (
    get_customer_info,
    get_order_details,
    check_inventory,
    get_customer_ids_by_name,
    get_orders_by_customer_id,
)


def register_tools(mcp: FastMCP):
    # register tools using decorator explicitly
    mcp.tool()(get_customer_info)
    mcp.tool()(get_order_details)
    mcp.tool()(check_inventory)
    mcp.tool()(get_customer_ids_by_name)
    mcp.tool()(get_orders_by_customer_id)
    return
