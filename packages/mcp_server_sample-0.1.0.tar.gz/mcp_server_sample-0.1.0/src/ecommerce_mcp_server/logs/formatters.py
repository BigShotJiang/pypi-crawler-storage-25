import logging
import pytz

from datetime import datetime
from uvicorn.logging import DefaultFormatter, AccessFormatter


class TZAccessFormatter(AccessFormatter):
    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None, ) -> str:
        # Convert to desired timezone
        kst = pytz.timezone("Asia/Seoul")
        dt = datetime.fromtimestamp(record.created, kst)
        if datefmt:
            if "%f" in datefmt:
                ms_str = f"{int(record.msecs):03d}"
                datefmt=datefmt.replace("%f", ms_str)
                
            return dt.strftime(datefmt)
        else:
            return dt.replace(tzinfo=None).isoformat(timespec='milliseconds')


class TZDefaultFormatter(DefaultFormatter):
    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None) -> str:
        # Convert to desired timezone
        kst = pytz.timezone("Asia/Seoul")
        dt = datetime.fromtimestamp(record.created, kst)
        if datefmt:
            if "%f" in datefmt:
                ms_str = f"{int(record.msecs):03d}"
                datefmt=datefmt.replace("%f", ms_str)
                
            return dt.strftime(datefmt)
        else:
            return dt.replace(tzinfo=None).isoformat(timespec='milliseconds')

    def format(self, record: logging.LogRecord):
        # Safely handle optional keys in `extra`
        default_extra = None
        optional_keys = ["meta", "credit"]
        for key in optional_keys:
            if not hasattr(record, key):
                setattr(record, key, default_extra)
        return super().format(record)
