import json
import logging

from typing import Any

from . import MY_LOGGER_NAME


def log_level(level: str) -> int:
    """
    Convert log level string 'level' to logging module's level constants
    """
    valid_levels = {
        "CRITICAL",
        "FATAL",
        "ERROR",
        "WARNING",
        "WARN",
        "INFO",
        "DEBUG",
        "NOTSET",
    }
    level = level.upper()

    if level not in valid_levels:
        raise ValueError(
            f"Invalid log level: '{level}'. Must be one of: {', '.join(valid_levels)}"
        )
    return getattr(logging, level)


def extra_fields(meta: dict[str, Any] | None = None) -> dict[str, str] | None:
    ef = dict()
    if meta is not None:
        ef["meta"] = json.dumps(meta, default=str)
    if len(ef) == 0:
        ef = None
    return ef


def server_log(msg: str, meta: dict[str, Any] | None = None, level: str = "DEBUG") -> None:
    logger = logging.getLogger(MY_LOGGER_NAME)
    ef = extra_fields(meta=meta)
    logger.log(level=log_level(level), msg=msg, extra=ef)
    return
