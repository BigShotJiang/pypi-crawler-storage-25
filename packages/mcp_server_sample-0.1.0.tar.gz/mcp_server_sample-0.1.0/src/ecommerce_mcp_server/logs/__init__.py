MY_LOGGER_NAME = "ncai.openapi.usage"
