import logging

from copy import deepcopy

from . import MY_LOGGER_NAME
from .formatters import TZDefaultFormatter


LOGGING_CONFIG_BASE = {
    "version": 1,
    "disable_existing_loggers": False,  # default True
}


def setup_dev(level: str = "DEBUG"):
    # for dev,
    # override uvicorn's error logger
    # use custom access logger that mimics uvicor's access logger
    # use colorful uvicorn's fomatter
    log_config = deepcopy(LOGGING_CONFIG_BASE)

    # set formatters
    log_config["formatters"] = {
        "standard": {
            "()": lambda: TZDefaultFormatter(
                fmt="%(levelprefix)s %(asctime)s :: %(message)s | meta: %(meta)s",
                datefmt="%Y-%m-%dT%H:%M:%S.%f",
                use_colors=True,
            )
        },
    }

    # set handlers
    log_config["handlers"] = {
        "standard": {
            "formatter": "standard",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr"
        }
    }
    log_config["loggers"] = {
        MY_LOGGER_NAME: {"handlers": ["standard"], "level": level, "propagate": False},
    }

    logging.config.dictConfig(log_config)
    return
