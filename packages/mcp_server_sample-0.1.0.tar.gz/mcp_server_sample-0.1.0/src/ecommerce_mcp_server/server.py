import os
import logging

from starlette.requests import Request
from starlette.responses import JSONResponse
from fastmcp import FastMCP
from fastmcp.server.middleware import Middleware, MiddlewareContext
from fastmcp.server.lifespan import lifespan
from fastmcp.utilities.logging import get_logger

from .logs.loaders import setup_dev
from .logs.helper import server_log
from .tools import register_tools


# setup logger
if os.getenv("APP_ENV", "dev").lower() == "prod":
    pass
else:
    setup_dev(level="DEBUG")


# implement middleware
class RequestHeaderMiddleware(Middleware):
    async def on_message(self, context: MiddlewareContext, call_next):
        # context.method is the MCP operation name (e.g., 'tools/call'), not the HTTP method.
        mcp_method = context.method

        # Extract MCP message data safely (FastMCP messages are Pydantic models)
        message_data = (
            context.message.model_dump()
            if hasattr(context.message, "model_dump")
            else context.message
        )

        # Safely access the underlying Starlette HTTP request (only present for HTTP transport)
        fastmcp_ctx = context.fastmcp_context
        if fastmcp_ctx and getattr(fastmcp_ctx, "request_context", None):
            request: Request = fastmcp_ctx.request_context.request
            server_log(
                f"[{request.method}] {request.url.path} (MCP: {mcp_method}) request",
                meta={"message": message_data, "headers": dict(request.headers)},
                level="INFO",
            )
        else:
            # Fallback for stdio transport
            server_log(
                f"[MCP] {mcp_method} request",
                meta={"message": message_data},
                level="INFO",
            )
        response = await call_next(context)
        return response


@lifespan
async def app_lifespan(server):
    # app startup

    # print all envrionment variables
    server_log("=== Environment variables: ===", level="INFO")
    for key, value in os.environ.items():
        server_log(f"{key}: {value}", level="INFO")
    server_log("==============================", level="INFO")

    # FastMCP의 logger 설정
    # to_client logger setting
    to_client_logger = get_logger(name="fastmcp.server.context.to_client")
    to_client_logger.setLevel(level=logging.DEBUG)

    try:
        # FastMCP의 Context 객체에서 사용할 global object 설정
        yield {}
    finally:
        # app shutdown
        pass


mcp = FastMCP(name="My MCP Server", lifespan=app_lifespan)
mcp.add_middleware(RequestHeaderMiddleware())


# `<url>/mcp` 외 추가적인 http endpoint 설정 가능
@mcp.custom_route("/healthz", methods=["GET"])
async def health_check(request: Request) -> JSONResponse:
    server_log("health check", level="INFO")
    return JSONResponse({"status": "ok"})


# register tools
register_tools(mcp)


def main(raw_args=None):
    # parse transport: "stdio", "http"
    transport = os.getenv("MCP_TRANSPORT", "stdio").lower()

    if transport == "http":
        host = os.getenv("MCP_HOST", "0.0.0.0").lower()
        port = int(os.getenv("MCP_PORT", "8000"))
        mcp.run(transport="http", host=host, port=port)
    else:
        mcp.run()  # stdio default
    return


if __name__ == "__main__":
    main()
