from ecommerce_mcp_server.server import mcp
