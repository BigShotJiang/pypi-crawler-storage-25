# FastMCP Template

## 파일 설명

```bash
(fastmcp-template) moono@9ff9740bf671:/mnt/data_ssd/ncai-git-repos/fastmcp-template$ tree .
.
|-- README.md
|-- fastmcp.json    # FastMCP cli 용
|-- launcher.py     # FastMCP cli 용
|-- pyproject.toml  # uv project 세팅
|-- src             # actual source code
|   `-- ecommerce_mcp_server
|       |-- Dockerfile
|       |-- __init__.py
|       |-- core
|       |   |-- __init__.py
|       |   |-- httpx_async_client.py
|       |   `-- models.py
|       |-- logs
|       |   |-- __init__.py
|       |   |-- formatters.py
|       |   |-- helper.py
|       |   `-- loaders.py
|       |-- server.py
|       `-- tools
|           |-- __init__.py
|           `-- openapi.py
`-- uv.lock
```

## App 환경변수

| env variable    | description                        | default   |
| --------------- | ---------------------------------- | --------- |
| `MCP_TRANSPORT` | select transport (`stdio`, `http`) | `stdio`   |
| `MCP_HOST`      | host setting on `http` setting     | `0.0.0.0` |
| `MCP_PORT`      | port setting on `http` setting     | `8000`    |

## 사용 방법

1. Command line

```bash
# 1-1. Using `uv`
~$ uv run python -m ecommerce_mcp_server.server
~$ MCP_TRANSPORT=http uv run python -m ecommerce_mcp_server.server  # http transport with --host=0.0.0.0 --port=8000

# 1-2. Using `pyproject.toml` defined script
~$ run-mcp-server
~$ MCP_TRANSPORT=http run-mcp-server  # http transport with --host=0.0.0.0 --port=8000

# 1-3. FastMCP cli using `fastmcp.json` (default)
~$ fastmcp run
~$ fastmcp run fastmcp.json
~$ fastmcp run --transport=http --host=0.0.0.0 --port=8000  # http transport
```

2. vscode debugger

- choose launch target `Python Debugger: FastMCP`

### FastMCP Cli

- Run MCP server

```bash
~$ fastmcp run
```

- Extract schema

```bash
~$ fastmcp inspect launcher.py -f fastmcp -o manifest.json
```
