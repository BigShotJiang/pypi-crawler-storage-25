# termtools 

A beautiful Textual TUI to browse the CLI tools you have installed on your system.

## 🚀 Install

> ## ⭐ Use pipx — it's the only method that works on every modern system ⭐
>
> Modern macOS, Debian, Ubuntu, and Fedora **block plain `pip install`** for safety
> (PEP 668 / "externally-managed-environment"). **pipx is the fix.** It manages an
> isolated environment for you, works everywhere, and is the standard way to
> install Python CLI tools in 2025.

### ✅ Recommended — pipx (works on every OS)

**macOS:**
```bash
brew install pipx
pipx install termtools-tui
```

**Linux (Debian / Ubuntu):**
```bash
sudo apt install pipx
pipx install termtools-tui
```

**Linux (Fedora):**
```bash
sudo dnf install pipx
pipx install termtools-tui
```

**Windows:**
```bash
python -m pip install --user pipx
python -m pipx ensurepath
pipx install termtools-tui
```

Then just run:

```bash
termtools
```

---

### ⚠️ Fallback — plain pip (only if you refuse to install pipx)

If you see `error: externally-managed-environment` you'll need to add `--break-system-packages`. The flag name sounds scary, but combined with `--user` it only touches your personal folder — it does **not** modify the system Python:

```bash
pip3 install --user --break-system-packages termtools-tui
```

If `termtools` isn't found after install, add the user-bin folder to your `$PATH`:
- **macOS:** `~/Library/Python/3.X/bin`
- **Linux:** `~/.local/bin`
- **Windows:** `%APPDATA%\Python\PythonXY\Scripts`

```bash
export PATH="$HOME/.local/bin:$PATH"   # add to ~/.zshrc or ~/.bashrc
```

---

## Update

```bash
pipx upgrade termtools-tui                                       # pipx
pip install --upgrade --user --break-system-packages termtools-tui   # pip fallback
```

## Uninstall

```bash
pipx uninstall termtools-tui
# or
pip uninstall termtools-tui
```

## Features

- Scans your `$PATH` against a curated catalog of ~100 CLI tools across 13 categories
- Tabs to filter: Editors, Search, File & Disk, Git, System, Network, Languages, Package Managers, Containers, Data, Shells, AI, Fun, plus a "Cool Picks ★" tab
- Live search bar
- Per-tool detail pane: description, path, size
- Buttons to **Run**, **Inspect**, and view **Install info** with copy-paste install commands for brew, apt, dnf, pacman, apk, winget, scoop, and chocolatey

## Keys

- `/` focus search
- `r` refresh
- `enter` inspect selected tool
- `q` quit
