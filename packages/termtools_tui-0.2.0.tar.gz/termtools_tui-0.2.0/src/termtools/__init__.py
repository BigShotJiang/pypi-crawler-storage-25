#!/usr/bin/env python3
"""termtools — a beautiful TUI to browse the CLI tools installed on your system."""
from __future__ import annotations

import os
import shutil
import subprocess
import platform
from dataclasses import dataclass, field
from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll, Container
from textual.screen import ModalScreen
from textual.widgets import (
    Header, Footer, Input, Button, Static, DataTable, Label, Tabs, Tab, TextArea
)
from textual.binding import Binding
from textual.reactive import reactive


# ---------- curated metadata ----------
# Category -> list of (tool, description)
CATALOG: dict[str, list[tuple[str, str]]] = {
    "Editors": [
        ("vim", "Highly configurable modal text editor"),
        ("nvim", "Hyperextensible Vim-based text editor"),
        ("nano", "Tiny friendly terminal editor"),
        ("emacs", "Extensible self-documenting editor"),
        ("micro", "Modern intuitive terminal editor"),
        ("helix", "Post-modern modal editor"),
        ("code", "VS Code launcher"),
    ],
    "Search & Find": [
        ("rg", "ripgrep — blazing fast recursive search"),
        ("ag", "the_silver_searcher — fast code search"),
        ("ack", "grep-like tool optimized for code"),
        ("fd", "Simple, fast alternative to find"),
        ("find", "POSIX file search"),
        ("grep", "POSIX pattern search"),
        ("fzf", "Fuzzy finder for the command line"),
        ("locate", "Find files by name from a database"),
    ],
    "File & Disk": [
        ("ls", "List directory contents"),
        ("eza", "Modern replacement for ls"),
        ("exa", "Modern replacement for ls (legacy)"),
        ("tree", "Recursive directory listing"),
        ("bat", "cat clone with syntax highlighting"),
        ("less", "Terminal pager"),
        ("dust", "More intuitive du"),
        ("duf", "Disk usage / free utility"),
        ("ncdu", "Disk usage analyzer with TUI"),
        ("rsync", "Fast incremental file transfer"),
        ("trash", "Send files to the trash"),
    ],
    "Git & VCS": [
        ("git", "Distributed version control"),
        ("gh", "GitHub CLI"),
        ("glab", "GitLab CLI"),
        ("lazygit", "Simple terminal UI for git"),
        ("tig", "Text-mode interface for git"),
        ("hub", "Git wrapper for GitHub"),
        ("delta", "Syntax-highlighted git diffs"),
    ],
    "System & Process": [
        ("htop", "Interactive process viewer"),
        ("btop", "Beautiful resource monitor"),
        ("top", "Process monitor"),
        ("ps", "Process status"),
        ("procs", "Modern replacement for ps"),
        ("bottom", "Cross-platform graphical process monitor"),
        ("glances", "Cross-platform monitoring tool"),
        ("neofetch", "System info ASCII art"),
        ("fastfetch", "Fast system info tool"),
    ],
    "Network": [
        ("curl", "Transfer data from/to URLs"),
        ("wget", "Network downloader"),
        ("httpie", "User-friendly HTTP client"),
        ("xh", "Friendly and fast HTTP client"),
        ("dog", "Modern command-line DNS client"),
        ("dig", "DNS lookup utility"),
        ("nslookup", "Query DNS records"),
        ("ping", "Send ICMP echo requests"),
        ("traceroute", "Trace network path"),
        ("mtr", "Network diagnostic tool"),
        ("nmap", "Network exploration & security"),
        ("netcat", "TCP/UDP swiss army knife"),
        ("nc", "TCP/UDP swiss army knife"),
        ("ssh", "OpenSSH client"),
    ],
    "Languages & Runtimes": [
        ("python", "Python interpreter"),
        ("python3", "Python 3 interpreter"),
        ("node", "Node.js JavaScript runtime"),
        ("deno", "Modern JS/TS runtime"),
        ("bun", "Fast JS runtime & toolkit"),
        ("ruby", "Ruby interpreter"),
        ("go", "Go toolchain"),
        ("rustc", "Rust compiler"),
        ("cargo", "Rust package manager"),
        ("java", "Java runtime"),
        ("php", "PHP interpreter"),
    ],
    "Package Managers": [
        ("brew", "Homebrew package manager"),
        ("npm", "Node package manager"),
        ("pnpm", "Fast disk-efficient package manager"),
        ("yarn", "JS package manager"),
        ("pip", "Python package installer"),
        ("pipx", "Install Python apps in isolation"),
        ("uv", "Extremely fast Python package manager"),
        ("apt", "Debian package manager"),
        ("dnf", "Fedora package manager"),
        ("pacman", "Arch package manager"),
    ],
    "Containers & Cloud": [
        ("docker", "Container platform"),
        ("podman", "Daemonless container engine"),
        ("kubectl", "Kubernetes CLI"),
        ("helm", "Kubernetes package manager"),
        ("k9s", "Kubernetes TUI"),
        ("aws", "AWS CLI"),
        ("gcloud", "Google Cloud CLI"),
        ("az", "Azure CLI"),
        ("terraform", "Infrastructure as code"),
    ],
    "Data & Text": [
        ("jq", "Command-line JSON processor"),
        ("yq", "YAML/JSON/XML processor"),
        ("awk", "Pattern scanning language"),
        ("sed", "Stream editor"),
        ("sqlite3", "SQLite shell"),
        ("psql", "PostgreSQL client"),
        ("mysql", "MySQL client"),
        ("xsv", "Fast CSV toolkit"),
        ("miller", "Like awk/sed for CSV/JSON"),
    ],
    "Shells & Multiplex": [
        ("bash", "Bourne Again Shell"),
        ("zsh", "Z shell"),
        ("fish", "Friendly interactive shell"),
        ("nu", "Nushell — structured data shell"),
        ("tmux", "Terminal multiplexer"),
        ("screen", "Terminal multiplexer (classic)"),
        ("zellij", "Modern terminal workspace"),
    ],
    "AI & Dev Tools": [
        ("claude", "Claude Code CLI"),
        ("ollama", "Run LLMs locally"),
        ("gemini", "Gemini CLI"),
        ("aider", "AI pair programming"),
        ("make", "Build automation"),
        ("cmake", "Cross-platform build system"),
        ("ninja", "Small fast build system"),
    ],
    "Fun & Misc": [
        ("cowsay", "ASCII cow speaks your message"),
        ("figlet", "Big ASCII text banners"),
        ("lolcat", "Rainbow text"),
        ("sl", "Steam locomotive (typo of ls)"),
        ("fortune", "Random quotes"),
        ("toilet", "More ASCII text banners"),
        ("tldr", "Simplified man pages"),
    ],
}

COOL_PICKS = {
    "rg", "fd", "fzf", "bat", "eza", "delta", "lazygit", "btop",
    "jq", "httpie", "xh", "zellij", "helix", "nvim", "tldr",
    "dust", "duf", "ncdu", "k9s", "uv", "bun", "nu", "claude",
}

# Build reverse lookup
TOOL_META: dict[str, tuple[str, str]] = {}  # tool -> (category, description)
for cat, items in CATALOG.items():
    for name, desc in items:
        TOOL_META[name] = (cat, desc)

SPECIAL_TABS = ["★ Installed", "💡 Recommended", "All"]
ALL_CATEGORIES = SPECIAL_TABS + list(CATALOG.keys())


# ---------- detection ----------
@dataclass
class Tool:
    name: str
    path: str
    category: str
    description: str
    installed: bool = True
    is_cool: bool = False
    size: int | None = None
    version: str | None = None


def scan_all() -> dict[str, Tool]:
    """Build a Tool entry for every catalog item, marking installed status."""
    found: dict[str, Tool] = {}
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    seen_in_path: set[str] = set()
    for d in path_dirs:
        try:
            for entry in os.scandir(d):
                if entry.is_file() and os.access(entry.path, os.X_OK):
                    seen_in_path.add(entry.name)
        except (FileNotFoundError, PermissionError, NotADirectoryError):
            continue

    for name, (cat, desc) in TOOL_META.items():
        installed = name in seen_in_path
        p = shutil.which(name) or "" if installed else ""
        found[name] = Tool(
            name=name, path=p, category=cat, description=desc,
            installed=installed, is_cool=name in COOL_PICKS,
        )
    return found


def compute_recommendations(tools: dict[str, Tool]) -> list[str]:
    """Suggest cool tools the user is missing in categories they already use."""
    used_categories = {t.category for t in tools.values() if t.installed}
    recs: list[str] = []
    for name, t in tools.items():
        if t.installed:
            continue
        if not t.is_cool:
            continue
        if t.category in used_categories:
            recs.append(name)
    return sorted(recs)


# ---------- install instructions ----------
def install_instructions(tool: str) -> str:
    return (
        f"[b cyan]Install instructions for[/] [b yellow]{tool}[/]\n\n"
        f"[b]macOS (Homebrew)[/]\n  brew install {tool}\n\n"
        f"[b]macOS (MacPorts)[/]\n  sudo port install {tool}\n\n"
        f"[b]Debian / Ubuntu[/]\n  sudo apt install {tool}\n\n"
        f"[b]Fedora[/]\n  sudo dnf install {tool}\n\n"
        f"[b]Arch[/]\n  sudo pacman -S {tool}\n\n"
        f"[b]Alpine[/]\n  sudo apk add {tool}\n\n"
        f"[b]Windows (winget)[/]\n  winget install {tool}\n\n"
        f"[b]Windows (Scoop)[/]\n  scoop install {tool}\n\n"
        f"[b]Windows (Chocolatey)[/]\n  choco install {tool}\n\n"
        f"[dim]Note: package names occasionally differ across distros.[/]"
    )


def detect_install_command(tool: str) -> tuple[str, list[str]] | None:
    sysname = platform.system()
    if sysname == "Darwin" and shutil.which("brew"):
        return ("Homebrew", ["brew", "install", tool])
    if shutil.which("apt"):
        return ("apt", ["sudo", "apt", "install", "-y", tool])
    if shutil.which("dnf"):
        return ("dnf", ["sudo", "dnf", "install", "-y", tool])
    if shutil.which("pacman"):
        return ("pacman", ["sudo", "pacman", "-S", "--noconfirm", tool])
    if shutil.which("apk"):
        return ("apk", ["sudo", "apk", "add", tool])
    if shutil.which("winget"):
        return ("winget", ["winget", "install", tool])
    return None


def file_size(path: str) -> int | None:
    try:
        return os.path.getsize(os.path.realpath(path))
    except OSError:
        return None


def human_size(n: int | None) -> str:
    if n is None:
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def try_version(tool: str) -> str:
    for flag in ("--version", "-V", "-v", "version"):
        try:
            r = subprocess.run(
                [tool, flag], capture_output=True, text=True, timeout=2
            )
            out = (r.stdout or r.stderr).strip().splitlines()
            if out:
                return out[0][:80]
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            continue
    return "(unknown)"


# ---------- modals ----------
class InspectModal(ModalScreen):
    def __init__(self, tool: Tool):
        super().__init__()
        self.tool = tool

    def compose(self) -> ComposeResult:
        size = file_size(self.tool.path)
        version = try_version(self.tool.name)
        real = os.path.realpath(self.tool.path) if self.tool.path else "?"
        body = (
            f"[b cyan]🔍 Inspect:[/] [b yellow]{self.tool.name}[/]\n\n"
            f"[b]Category:[/]    {self.tool.category}\n"
            f"[b]Description:[/] {self.tool.description}\n"
            f"[b]Path:[/]        {self.tool.path}\n"
            f"[b]Real path:[/]   {real}\n"
            f"[b]Size:[/]        {human_size(size)}\n"
            f"[b]Version:[/]     {version}\n"
            f"[b]Cool pick:[/]   {'★ yes' if self.tool.is_cool else 'no'}\n"
        )
        with Container(id="modal-box"):
            yield Static(body, id="modal-body")
            with Horizontal(id="modal-buttons"):
                yield Button("Close", variant="primary", id="close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class InstallModal(ModalScreen):
    def __init__(self, tool_name: str):
        super().__init__()
        self.tool_name = tool_name

    def compose(self) -> ComposeResult:
        with Container(id="modal-box"):
            yield Static(install_instructions(self.tool_name), id="modal-body")
            with Horizontal(id="modal-buttons"):
                cmd = detect_install_command(self.tool_name)
                if cmd:
                    yield Button(f"Install via {cmd[0]}", variant="success", id="install")
                yield Button("Close", variant="primary", id="close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "install":
            cmd = detect_install_command(self.tool_name)
            if cmd:
                self.app.exit(result=("install", cmd[1]))
                return
        self.dismiss()


class ConfirmRunModal(ModalScreen):
    def __init__(self, tool_name: str):
        super().__init__()
        self.tool_name = tool_name

    def compose(self) -> ComposeResult:
        with Container(id="modal-box"):
            yield Static(
                f"[b cyan]▶ Run[/] [b yellow]{self.tool_name}[/]?\n\n"
                f"This will exit termtools and launch [b]{self.tool_name}[/] "
                f"in your current shell.\n",
                id="modal-body",
            )
            with Horizontal(id="modal-buttons"):
                yield Button("Run", variant="success", id="run")
                yield Button("Cancel", variant="error", id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "run":
            self.app.exit(result=("run", [self.tool_name]))
        else:
            self.dismiss()


# ---------- main app ----------
class TermTools(App):
    CSS = """
    Screen { background: #0b0f1a; }
    Header { background: #1a1f3a; color: #ffd866; }
    Footer { background: #1a1f3a; color: #a9b1d6; }

    #top { height: 3; padding: 0 1; }
    #search { width: 1fr; }

    Tabs { background: #0b0f1a; }
    Tab { color: #a9b1d6; }
    Tab.-active { color: #ffd866; text-style: bold; }

    #main { height: 1fr; }
    #left { width: 2fr; border: round #6272a4; padding: 0 1; }
    #right { width: 1fr; border: round #ff79c6; padding: 1 1; }

    DataTable { background: #0b0f1a; }
    DataTable > .datatable--header { background: #1a1f3a; color: #ffd866; text-style: bold; }
    DataTable > .datatable--cursor { background: #44475a; color: #f8f8f2; }
    DataTable > .datatable--hover { background: #21263a; }

    #detail-title { color: #50fa7b; text-style: bold; }
    #detail-body { color: #f8f8f2; padding: 1 0; }

    #buttons { height: auto; padding: 1 0; }
    Button { margin: 0 1; }

    #modal-box {
        align: center middle;
        background: #1a1f3a;
        border: thick #ff79c6;
        padding: 2 4;
        width: 80;
        height: auto;
    }
    #modal-body { color: #f8f8f2; padding: 0 0 1 0; }
    #modal-buttons { align: center middle; height: auto; padding-top: 1; }

    .stat { color: #8be9fd; }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("/", "focus_search", "Search"),
        Binding("r", "refresh", "Refresh"),
        Binding("enter", "inspect", "Inspect"),
    ]

    current_category: reactive[str] = reactive("★ Installed")
    search_text: reactive[str] = reactive("")

    def __init__(self):
        super().__init__()
        self.tools: dict[str, Tool] = {}
        self.recommended: set[str] = set()
        self.selected_tool: Tool | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Vertical():
            with Horizontal(id="top"):
                yield Input(placeholder="🔎 Search tools…", id="search")
            yield Tabs(*(Tab(c, id=f"tab-{i}") for i, c in enumerate(ALL_CATEGORIES)))
            with Horizontal(id="main"):
                with Vertical(id="left"):
                    yield DataTable(id="table", cursor_type="row", zebra_stripes=True)
                with Vertical(id="right"):
                    yield Static("Select a tool to see details", id="detail-title")
                    yield Static("", id="detail-body")
                    with Horizontal(id="buttons"):
                        yield Button("▶ Run", variant="success", id="btn-run")
                        yield Button("🔍 Inspect", variant="primary", id="btn-inspect")
                        yield Button("📦 Install info", variant="warning", id="btn-install")
        yield Footer()

    def on_mount(self) -> None:
        self.title = "termtools ✨"
        self.tools = scan_all()
        self.recommended = set(compute_recommendations(self.tools))
        table = self.query_one("#table", DataTable)
        table.add_columns("Status", "★", "Tool", "Category", "Description")
        self.refresh_table()

    def _row_passes(self, t: Tool, cat: str) -> bool:
        if cat == "★ Installed":
            return t.installed
        if cat == "💡 Recommended":
            return t.name in self.recommended
        if cat == "All":
            return True
        # Category tabs: only show NOT-installed in that category
        return t.category == cat and not t.installed

    def refresh_table(self) -> None:
        from rich.text import Text
        table = self.query_one("#table", DataTable)
        table.clear()
        q = self.search_text.lower().strip()
        cat = self.current_category

        # Sort: installed first within mixed views, then alphabetical
        names = sorted(
            self.tools.keys(),
            key=lambda n: (not self.tools[n].installed, n),
        )

        shown = 0
        for name in names:
            t = self.tools[name]
            if not self._row_passes(t, cat):
                continue
            if q and q not in t.name.lower() and q not in t.description.lower():
                continue

            if t.installed:
                status = Text("✓ installed", style="bold #50fa7b")
            else:
                status = Text("⬇ available", style="#ffb86c")
            star = Text("★", style="bold #ffd866") if t.is_cool else Text(" ")
            tool_name = Text(
                t.name,
                style="bold #8be9fd" if t.installed else "bold #ff79c6",
            )
            category = Text(t.category, style="#bd93f9")
            description = Text(t.description, style="#f8f8f2")

            table.add_row(status, star, tool_name, category, description, key=t.name)
            shown += 1

        installed_total = sum(1 for x in self.tools.values() if x.installed)
        missing_total = len(self.tools) - installed_total
        self.sub_title = (
            f"✓ {installed_total} installed · ⬇ {missing_total} available · "
            f"💡 {len(self.recommended)} recommended · viewing: {cat} ({shown})"
        )

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "search":
            self.search_text = event.value
            self.refresh_table()

    def on_tabs_tab_activated(self, event: Tabs.TabActivated) -> None:
        idx = int(event.tab.id.split("-")[1])
        self.current_category = ALL_CATEGORIES[idx]
        self.refresh_table()

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        key = event.row_key.value if event.row_key else None
        if key and key in self.tools:
            self.selected_tool = self.tools[key]
            self.update_detail()

    def update_detail(self) -> None:
        t = self.selected_tool
        if not t:
            return
        star = "★ " if t.is_cool else ""
        if t.installed:
            title = f"[b #50fa7b]✓ {star}{t.name}[/]"
        else:
            title = f"[b #ff79c6]⬇ {star}{t.name}[/]"
        self.query_one("#detail-title", Static).update(title)

        lines = [
            f"[b #ffd866]━━━━━━━━━━━━━━━━━━━━━━━━━━[/]",
            f"[b #8be9fd]About[/]",
            f"  {t.description}",
            "",
            f"[b #8be9fd]Category[/]",
            f"  [#bd93f9]{t.category}[/]",
            "",
        ]
        if t.installed:
            size = file_size(t.path)
            lines += [
                f"[b #8be9fd]Status[/]",
                f"  [b #50fa7b]✓ Installed on this machine[/]",
                "",
                f"[b #8be9fd]Path[/]",
                f"  [dim]{t.path}[/]",
                "",
                f"[b #8be9fd]Size[/]",
                f"  [#ff79c6]{human_size(size)}[/]",
            ]
        else:
            lines += [
                f"[b #8be9fd]Status[/]",
                f"  [b #ffb86c]⬇ Not installed[/]",
                "",
                f"[dim]Click 📦 Install info to see how to get it.[/]",
            ]
        if t.is_cool:
            lines += ["", f"[b #ffd866]★ Cool pick — highly recommended[/]"]
        self.query_one("#detail-body", Static).update("\n".join(lines))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if not self.selected_tool:
            return
        bid = event.button.id
        t = self.selected_tool
        if bid == "btn-run":
            if not t.installed:
                self.notify(f"{t.name} is not installed yet — use 📦 Install info first.",
                            severity="warning", title="Can't run")
                return
            self.push_screen(ConfirmRunModal(t.name))
        elif bid == "btn-inspect":
            if not t.installed:
                self.notify(f"{t.name} is not installed — nothing to inspect.",
                            severity="warning", title="Not installed")
                return
            self.push_screen(InspectModal(t))
        elif bid == "btn-install":
            self.push_screen(InstallModal(t.name))

    def action_focus_search(self) -> None:
        self.query_one("#search", Input).focus()

    def action_refresh(self) -> None:
        self.tools = scan_all()
        self.recommended = set(compute_recommendations(self.tools))
        self.refresh_table()

    def action_inspect(self) -> None:
        if self.selected_tool:
            self.push_screen(InspectModal(self.selected_tool))


def main() -> None:
    app = TermTools()
    result = app.run()
    if isinstance(result, tuple):
        action, cmd = result
        if action == "run":
            print(f"\n\033[1;32m▶ Launching {cmd[0]}…\033[0m\n")
            try:
                subprocess.call(cmd)
            except FileNotFoundError:
                print(f"\033[1;31mCould not launch {cmd[0]}\033[0m")
        elif action == "install":
            print(f"\n\033[1;33m📦 Installing: {' '.join(cmd)}\033[0m\n")
            subprocess.call(cmd)


if __name__ == "__main__":
    main()
