PACKAGE_NAME = "manywe-turn"
__version__ = "0.0.1"
DEFAULT_TURN_WINDOW_SECONDS = 600


def normalize_turn_uris(value):
    items = value if isinstance(value, (list, tuple)) else str(value).split(",")
    return [str(item).strip() for item in items if str(item).strip()]


def turn_window(unix_seconds: float, window_seconds: int = DEFAULT_TURN_WINDOW_SECONDS) -> int:
    if window_seconds <= 0:
        raise ValueError("window_seconds must be positive")
    return int(unix_seconds // window_seconds)


def credential_message(unix_seconds: float, window_seconds: int = DEFAULT_TURN_WINDOW_SECONDS) -> str:
    return f"turn:{turn_window(unix_seconds, window_seconds)}"


def credential_expires_at(unix_seconds: float, window_seconds: int = DEFAULT_TURN_WINDOW_SECONDS) -> int:
    return (turn_window(unix_seconds, window_seconds) + 1) * window_seconds
