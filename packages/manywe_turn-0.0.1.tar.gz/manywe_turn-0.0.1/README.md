# manywe-turn

Official ManyWe placeholder package for future TURN-related tooling.

Current utilities:
- normalize TURN URI lists
- compute TURN credential windows
- build the credential input message used by ManyWe integration helpers

This package is intentionally small and is not a TURN server implementation.
