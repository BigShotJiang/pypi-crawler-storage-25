# =========================
# Standard library
# =========================
import os
import logging
import ast
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# =========================
# 3rd-party packages
# =========================
import pandas as pd
from alive_progress import alive_bar

# =========================
# Local modules
# =========================
from .initialize_benchmark import initialize_benchmark, process_benchmark, prompt_generator
from .prompt_variation import PromptVariationGenerator, generate_var_bench
from .evaluator import HarnessEvaluator
from .utils import encode_image, get_client, verify_run_name




logger = logging.getLogger(__name__)





def agent(inputs: dict[str, dict], model_name: str,**kwargs):    
    
    client = get_client()

    task_id, task = list(inputs.items())[0]

    images_paths = [p for p in  task["ques_image_path_lst"]]
    response=None
    try:
        # build content list
        content = [{"type": "text", "text": task["task_description"]}]
        
        # add all images
        content += [
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"}
            }
            for path in images_paths if os.path.exists(path)
        ]
        

        
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "user",
                    "content": content
                }
            ],
            temperature=0.1,
            max_tokens=1000,
        )
            
        inputs[task_id]["response"] = response.choices[0].message.content.strip() if response else None
    except Exception as e:
        print(f"Error Answering task {task_id}: {e}")

    

    return inputs


def reasoning_agent(inputs: dict[str, dict], model_name: str,**kwargs):    
    
    client = get_client()

    task_id, task = list(inputs.items())[0]

    images_paths = [p for p in  task["ques_image_path_lst"]]
    response=None
    try:
        reasoning_text="Add Reasoning Behind Your Answer"
        content = [{
            "type": "text", 
            "text": task["task_description"]+reasoning_text
        }]
        
        # add all images
        content += [
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"}
            }
            for path in images_paths if os.path.exists(path)
        ]
        

        
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "user",
                    "content": content
                }
            ],
            temperature=0.1,
            max_tokens=1000,
        )
            
        inputs[task_id]["response"] = response.choices[0].message.content.strip() if response else None
    except Exception as e:
        print(f"Error Answering task {task_id}: {e}")

    

    return inputs


def run_agent_function(inputs: dict[str, dict], agent_function , use_template: bool =False, model_name: str = "" , **kwargs):
    if use_template:
        res=agent_function(inputs,model_name=model_name)
    else:
        res=agent_function(inputs,)

    return res
                
    


def HarnessRunner(
        use_template=True,
        custom_function=None,
        template_name="default_agent",
        reasoning_template=False,
        dataset_dir=None,
        clean_dataset_dir=True,
        template_model="gpt-4o-mini-2024-07-18",
        run_id = "test",
        max_concurrent = 5,
        continue_run = False,
        max_tasks = 0,
        prompt_sensitivity = False,
        num_variations = 3,
        variation_strength = "mild",
        results_dir = "results",
        task_ids = [],
        categories = [],
        sub_categories = [],
        openai_api_key = None,
        open_router_api_key = None,
        evaluation_needed=False,
        mcq_only=False,
        open_ended=False,
        custom_error_taxonomies=None
    ):

    
    function_template = {
        "default_agent": agent,
        "reasoning_agent": reasoning_agent,
    }
    
    if reasoning_template and use_template:
        template_name = "reasoning_agent"

    if openai_api_key:
        os.environ["OPENAI_API_KEY"]=openai_api_key
        
    if open_router_api_key:
        os.environ["OPEN_ROUTER_API_KEY"]=open_router_api_key

    
        
    if (not use_template) and (not custom_function):
        raise ValueError(
            "Select use_template or provide custom_function "
        )
        
    
    if use_template:
        agent_function= function_template[template_name]
    else:
        agent_function= custom_function

    temp_dir="./temp_dir"
    verify_run_name(run_id)
    Path(f"{results_dir}/{run_id}").mkdir(parents=True, exist_ok=True)
    response_path=f"{results_dir}/{run_id}/agent_response.csv"
    
    
    if os.path.exists(response_path) and (not continue_run):
        raise ValueError("Run Already Exist. Pass  continue_run if you want to Continue Run.")

    if dataset_dir:
        temp_dir=dataset_dir
    if not os.path.exists(temp_dir) :
        initialize_benchmark(temp_dir)
    
    
    
    df=pd.read_csv(f"{temp_dir}/annotations.csv").drop_duplicates(subset=["id"])
    
    df["ques_image_path_lst"] = df["ques_image_path_lst"].apply(ast.literal_eval)

    df["ques_image_path_lst"] = df["ques_image_path_lst"].apply(
        lambda paths: [os.path.join(temp_dir, "question_images", p) for p in paths]
    )
    
    dataset = process_benchmark(
        df,
        categories,
        sub_categories,
        task_ids,
        max_tasks,
        continue_run=continue_run,
        eval_path=response_path,
        mcq_only=mcq_only,
        open_ended=open_ended,
    )

    eval_results = {}

    if continue_run and os.path.exists(response_path):
        eval_results=pd.read_csv(response_path).set_index('id').to_dict(orient='index')
    
    var_dataset=None


    if prompt_sensitivity:
        
        
        generator = PromptVariationGenerator(num_variations=num_variations, strength=variation_strength)
        prompt_map = generator.generate_variations_for_dataset(dataset)
        var_dataset=generate_var_bench(dataset, prompt_map)

    active_dataset = var_dataset if var_dataset else dataset
    
    def process_item(key, item):
        """Generate prompt and run agent for a single item"""
        value = prompt_generator(item)
        res = run_agent_function(
            inputs={key: value},
            agent_function=agent_function,
            use_template=use_template,
            model_name=template_model,
            
        )
        return key, res[key]


    # Run in parallel with progress bar
    with alive_bar(len(active_dataset), bar='blocks', spinner='dots', title='Running Agent', force_tty=True) as bar:
        with ThreadPoolExecutor(max_workers=max_concurrent) as executor:
            futures = {executor.submit(process_item, k, v): k for k, v in active_dataset.items()}

            for future in as_completed(futures):
                key, result = future.result()
                eval_results[key] = result
                pd.DataFrame.from_dict(eval_results, orient="index").rename_axis("id").reset_index().to_csv(response_path, index=False)
                bar()  # update progress

    if evaluation_needed:
        # Run evaluator on results
        HarnessEvaluator(
           custom_error_taxonomies= custom_error_taxonomies,
           max_concurrent=max_concurrent,
           model_name=template_model,
           results_path=results_dir,
           
        )
        
    if clean_dataset_dir:
        shutil.rmtree(temp_dir)




