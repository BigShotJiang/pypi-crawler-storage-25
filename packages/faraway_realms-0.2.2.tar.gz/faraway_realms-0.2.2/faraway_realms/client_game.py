"""ClientGame: GameProtocol implementation backed by a NetworkClient snapshot."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from faraway_realms.blood import BloodEvent, BloodMap, BloodTile
from faraway_realms.chat import ChatMessage
from faraway_realms.entity import Entity, GameEntity
from faraway_realms.factions import FactionRelations
from faraway_realms.light import LightSource
from faraway_realms.map import Map
from faraway_realms.static_object import StaticObject
from faraway_realms.status import StatusInstance
from faraway_realms.tile import Tile

if TYPE_CHECKING:
    from faraway_realms.commands import Command
    from faraway_realms.net.client import NetworkClient
    from faraway_realms.net.serialization import EntitySnapshot
    from faraway_realms.projectile import Projectile


@dataclass(frozen=True)
class _ClientProjectile:
    """Lightweight projectile view reconstructed from a network snapshot."""

    x: int
    y: int
    color: tuple[int, int, int]
    trail: deque  # type: ignore[type-arg]
    trail_char: str


@dataclass
class _SnapshotEntity(GameEntity):
    """Lightweight GameEntity reconstructed from a network snapshot."""

    _display_name_val: str = field(default="", kw_only=True)
    _status_dicts_val: list[dict[str, Any]] = field(default_factory=list, kw_only=True)

    @property
    def display_name(self) -> str:
        """Return the entity's display name from the snapshot."""
        return self._display_name_val


def _deserialize_stat(d: dict[str, Any]) -> Any:
    """Reconstruct a Stat or Pool from its serialized dict."""
    from faraway_realms.stats import Pool, Stat

    abbr = d.get("abbreviation")
    bf = tuple(d["bar_filled"]) if d.get("bar_filled") else None
    be = tuple(d["bar_empty"]) if d.get("bar_empty") else None
    if d.get("is_pool"):
        pool = Pool(
            base=d["base"],
            bonus=d.get("bonus", 0),
            abbreviation=abbr,
            bar_filled=bf,
            bar_empty=be,
        )  # type: ignore[arg-type]
        pool.current = d.get("current", pool.value)
        return pool
    return Stat(
        base=d["base"],
        bonus=d.get("bonus", 0),
        abbreviation=abbr,
        bar_filled=bf,
        bar_empty=be,
    )  # type: ignore[arg-type]


def _build_snapshot_entity(snap_e: EntitySnapshot) -> _SnapshotEntity:
    from faraway_realms.abilities import ABILITY_REGISTRY
    from faraway_realms.components import CombatProfile

    abilities = {name: ABILITY_REGISTRY.get(name) for name in snap_e.abilities}
    stats = {k: _deserialize_stat(v) for k, v in snap_e.stats.items()}
    components: dict[str, Any] = {
        "combat_profile": CombatProfile(blood_color=snap_e.blood_color),
    }
    return _SnapshotEntity(
        entity_id=snap_e.entity_id,
        char=snap_e.char,
        fg_color=snap_e.fg_color,
        faction=snap_e.faction,
        target_id=snap_e.target_id,
        abilities=abilities,  # type: ignore[arg-type]
        stats=stats,
        components=components,
        _display_name_val=snap_e.display_name,
        _status_dicts_val=list(snap_e.status_effects),
    )


def _statuses_from_dicts(
    dicts: list[dict[str, Any]],
) -> list[StatusInstance]:
    return [
        StatusInstance(
            name=s["name"],
            expires_at=s["expires_at"],
            immobilize=s.get("immobilize", False),
            stun=s.get("stun", False),
            haste=s.get("haste", 1.0),
        )
        for s in dicts
    ]


class ClientGame:
    """GameProtocol implementation backed by a NetworkClient.

    Parameters
    ----------
    client : NetworkClient
        The network client providing tick snapshots.
    game_map : Map
        Static map tiles (never change; received in welcome message).
    tick_rate : float
        Server tick rate (from welcome or default).
    initial_static_objects : list[dict] | None
        Raw static-object dicts from the welcome message (sent once).
    initial_blood_tiles : dict[str, dict] | None
        Raw blood-tile snapshot from the welcome message (sent once).
    """

    def __init__(
        self,
        client: NetworkClient,
        game_map: Map,
        tick_rate: float = 10.0,
        initial_static_objects: list[dict] | None = None,
        initial_blood_tiles: dict[str, dict] | None = None,
    ) -> None:
        self._client = client
        self._game_map = game_map
        self._tick_rate = tick_rate
        self._blood_map = BloodMap(game_map.width, game_map.height)
        self._entities_cache: dict[int, _SnapshotEntity] = {}
        self._static_objects_cache: list[StaticObject] = [
            StaticObject(
                x=o["x"],
                y=o["y"],
                char=o["char"],
                fg_color=tuple(o["fg_color"]),  # type: ignore[arg-type]
            )
            for o in (initial_static_objects or [])
        ]
        if initial_blood_tiles:
            self._apply_blood_delta(initial_blood_tiles)

    # ------------------------------------------------------------------
    # GameProtocol properties
    # ------------------------------------------------------------------

    @property
    def game_map(self) -> Map:
        """Return the static map (tile data never changes)."""
        self._sync_entity_positions()
        return self._game_map

    @property
    def blood_map(self) -> BloodMap:
        """Return the blood map updated from the latest snapshot."""
        self._sync_blood_map()
        return self._blood_map

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return in-flight projectiles from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []  # type: ignore[return-value]
        projectiles: list[Projectile] = []
        for p in snap.projectiles:
            projectiles.append(  # type: ignore[arg-type]
                _ClientProjectile(
                    x=p["x"],
                    y=p["y"],
                    color=tuple(p["color"]),  # type: ignore[arg-type]
                    trail=deque(tuple(pos) for pos in p.get("trail", [])),
                    trail_char=p.get("trail_char", "+"),
                )
            )
        return projectiles

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return static objects (initialised once from welcome message)."""
        return self._static_objects_cache

    @property
    def faction_relations(self) -> FactionRelations:
        """Return a default FactionRelations (client has no combat logic)."""
        return FactionRelations()

    @property
    def tick_rate(self) -> float:
        """Server tick rate."""
        return self._tick_rate

    # ------------------------------------------------------------------
    # Entity access
    # ------------------------------------------------------------------

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player entities from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        return [self._get_or_update_entity(e) for e in snap.entities if e.is_player]

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities from the latest snapshot."""
        from typing import cast

        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        entities = [
            self._get_or_update_entity(e) for e in snap.entities if not e.is_player
        ]
        return cast(list[Entity], entities)

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return None
        for e in snap.entities:
            if e.entity_id == entity_id:
                return self._get_or_update_entity(e)
        return None

    # ------------------------------------------------------------------
    # Drain methods (consume once per frame)
    # ------------------------------------------------------------------

    def drain_attack_anim_events(
        self,
    ) -> list[tuple[tuple[int, int], tuple[int, int], tuple[int, int, int]]]:
        """Consume pending attack animation events."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        result = [
            (tuple(ev[0]), tuple(ev[1]), tuple(ev[2])) for ev in snap.attack_anim_events
        ]
        snap.attack_anim_events.clear()
        return result  # type: ignore[return-value]

    def drain_blood_events(self) -> list[BloodEvent]:
        """Consume pending blood events."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        result = [
            BloodEvent(
                target_pos=tuple(e["target_pos"]),  # type: ignore[arg-type]
                attacker_pos=tuple(e["attacker_pos"]),  # type: ignore[arg-type]
                landing_positions=tuple(tuple(p) for p in e["landing_positions"]),  # type: ignore[arg-type]
                color=tuple(e["color"]),  # type: ignore[arg-type]
            )
            for e in snap.blood_events
        ]
        snap.blood_events.clear()
        return result

    # ------------------------------------------------------------------
    # Cooldown / status queries
    # ------------------------------------------------------------------

    def _snap_fraction(self, entity_id: int, own_attr: str, target_attr: str, default):
        snap = self._client.latest_snapshot()
        if snap is None:
            return default
        if entity_id == snap.target_entity_id:
            return getattr(snap, target_attr)
        return getattr(snap, own_attr)

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return pre-computed cooldown fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "attack_cooldown_fraction", "target_attack_fraction", 0.0
        )

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return pre-computed GCD fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "gcd_fraction", "target_gcd_fraction", None
        )

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return pre-computed cast fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "cast_fraction", "target_cast_fraction", None
        )

    def ability_cooldown_fraction(
        self,
        entity_id: int,
        ability_name: str,  # noqa: ARG002
    ) -> float:
        """Return ability cooldown fraction from snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return 0.0
        return snap.ability_cooldowns.get(ability_name) or 0.0

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return status effects for entity from snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        for e in snap.entities:
            if e.entity_id == entity_id:
                return _statuses_from_dicts(e.status_effects)
        return []

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return True when entity has the named status."""
        return any(s.name == status_name for s in self.active_statuses(entity_id))

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return chat messages from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        msgs = [
            ChatMessage(
                text=m["text"],
                color=tuple(m["color"]),  # type: ignore[arg-type]
            )
            for m in snap.chat_messages
        ]
        return msgs[-last_n:]

    def get_hit_seq(self, entity_id: int) -> int:  # noqa: ARG002
        """Return the hit sequence counter from the latest snapshot."""
        snap = self._client.latest_snapshot()
        return snap.hit_seq if snap is not None else 0

    def get_crit_dealt_seq(self, entity_id: int) -> int:  # noqa: ARG002
        """Return the crit-dealt sequence counter from the latest snapshot."""
        snap = self._client.latest_snapshot()
        return snap.crit_dealt_seq if snap is not None else 0

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Return light sources from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        result = []
        for src in snap.light_sources:
            x, y, radius, intensity, color = src
            ls = LightSource(
                radius=radius,
                intensity=intensity,
                color=tuple(color),  # type: ignore[arg-type]
            )
            result.append((x, y, ls))
        return result

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = (200, 200, 200),
    ) -> None:
        """No-op on client; chat is server-authoritative."""

    def enqueue_command(self, command: Command) -> None:
        """Send command to the server via the network client."""
        self._client.send_command(command)

    # ------------------------------------------------------------------
    # Internal sync helpers
    # ------------------------------------------------------------------

    def _get_or_update_entity(self, snap_e: EntitySnapshot) -> _SnapshotEntity:
        eid = snap_e.entity_id
        existing = self._entities_cache.get(eid)
        if existing is None:
            existing = _build_snapshot_entity(snap_e)
            self._entities_cache[eid] = existing
        else:
            existing.target_id = snap_e.target_id
            existing._display_name_val = snap_e.display_name  # noqa: SLF001
            existing._status_dicts_val = list(snap_e.status_effects)  # noqa: SLF001
            existing.stats = {k: _deserialize_stat(v) for k, v in snap_e.stats.items()}
        return existing

    def _apply_tile_reveals(self, tile_reveals: list[dict]) -> None:
        for cell in tile_reveals:
            self._game_map.set_tile(
                cell["x"],
                cell["y"],
                Tile(
                    walkable=cell["walkable"],
                    char=cell.get("char", ord(".")),
                    fg_color=tuple(cell["fg"]),  # type: ignore[arg-type]
                    bg_color=tuple(cell["bg"]),  # type: ignore[arg-type]
                ),
            )

    def _sync_entity_positions(self) -> None:
        snap = self._client.latest_snapshot()
        if snap is None:
            return
        for eid in snap.removed_entity_ids:
            self._entities_cache.pop(eid, None)
        snap.removed_entity_ids.clear()
        self._apply_tile_reveals(snap.tile_reveals)
        snap.tile_reveals.clear()
        self._apply_static_object_reveals(snap.static_object_reveals)
        snap.static_object_reveals.clear()
        self._clear_entity_positions()
        self._place_snapshot_entities(snap.entities)

    def _apply_static_object_reveals(self, reveals: list[dict]) -> None:
        existing = {(o.x, o.y) for o in self._static_objects_cache}
        for o in reveals:
            if (o["x"], o["y"]) not in existing:
                self._static_objects_cache.append(
                    StaticObject(
                        x=o["x"],
                        y=o["y"],
                        char=o["char"],
                        fg_color=tuple(o["fg_color"]),  # type: ignore[arg-type]
                    )
                )

    def _clear_entity_positions(self) -> None:
        for eid in list(self._game_map.get_all_positions()):
            self._game_map.remove_entity(eid)

    def _place_snapshot_entities(self, entities: list) -> None:
        for e in entities:
            if e.x >= 0 and e.y >= 0:
                self._game_map.place_entity(e.entity_id, e.x, e.y)

    def _sync_blood_map(self) -> None:
        snap = self._client.latest_snapshot()
        if snap is None or not snap.blood_tiles:
            return
        self._apply_blood_delta(snap.blood_tiles)
        snap.blood_tiles.clear()

    def _apply_blood_delta(self, blood_tiles: dict) -> None:
        for key, val in blood_tiles.items():
            x_str, y_str = key.split(",")
            x, y = int(x_str), int(y_str)
            self._blood_map._tiles[(x, y)] = BloodTile(  # noqa: SLF001
                color=tuple(val["color"]),  # type: ignore[arg-type]
                alpha=val["alpha"],
            )
