"""Blood system — server-side stain accumulation and client-side events."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.color import Color
from faraway_realms.color import lerp_color as _blend_color

_POOL_ALPHAS: dict[int, int] = {0: 20, 1: 10, 2: 4, 3: 1}
_POOL_ALPHA_MAX: int = 80  # stains never fully occlude the tile


def _pool_alpha(dist: int) -> int:
    """Return the alpha value for a blood pool tile at Manhattan distance *dist*.

    Parameters
    ----------
    dist : int
        Manhattan distance from the pool centre.

    Returns
    -------
    int
        Alpha value 0–255; zero when beyond range.
    """
    return _POOL_ALPHAS.get(dist, 0)


@dataclass
class BloodTile:
    """A tile on the blood map with accumulated stain data.

    Parameters
    ----------
    color : Color
        Blended color of the stain.
    alpha : int
        Accumulated opacity 0–255.
    """

    color: Color
    alpha: int


@dataclass(frozen=True)
class BloodEvent:
    """Immutable event describing a blood splat for client-side animation.

    Parameters
    ----------
    target_pos : tuple[int, int]
        Map position of the struck entity.
    attacker_pos : tuple[int, int]
        Map position of the attacker.
    landing_positions : tuple[tuple[int, int], ...]
        Pre-computed landing tiles for each blood drop.
    color : Color
        Blood color of the struck entity.
    """

    target_pos: tuple[int, int]
    attacker_pos: tuple[int, int]
    landing_positions: tuple[tuple[int, int], ...]
    color: Color


class BloodMap:
    """Authoritative per-tile blood stain accumulation for the server.

    Parameters
    ----------
    width : int
        Map width in tiles.
    height : int
        Map height in tiles.
    """

    def __init__(self, width: int, height: int) -> None:
        self._width = width
        self._height = height
        self._tiles: dict[tuple[int, int], BloodTile] = {}
        self._dirty: set[tuple[int, int]] = set()

    @property
    def tiles(self) -> dict[tuple[int, int], BloodTile]:
        """Return the current blood tile mapping (position → BloodTile)."""
        return self._tiles

    def splat(
        self,
        tx: int,
        ty: int,
        ax: int,
        ay: int,
        color: Color,
        drop_count: int = 3,
        max_dist: int = 3,
    ) -> list[tuple[int, int]]:
        """Compute landing positions, update the map, and return positions.

        Parameters
        ----------
        tx, ty : int
            Position of the struck entity (target).
        ax, ay : int
            Position of the attacker.
        color : Color
            Blood color.
        drop_count : int
            Number of blood drops to spray (default 3).
        max_dist : int
            Maximum tiles a drop can travel from the target (default 3).

        Returns
        -------
        list[tuple[int, int]]
            Landing tile positions for client-side animation.
        """
        dx = (tx > ax) - (tx < ax)
        dy = (ty > ay) - (ty < ay)
        positions = self._drop_positions(tx, ty, dx, dy, drop_count, max_dist)
        for x, y in positions:
            self._add_pool(x, y, color)
        return positions

    def _drop_positions(
        self,
        tx: int,
        ty: int,
        dx: int,
        dy: int,
        drop_count: int,
        max_dist: int,
    ) -> list[tuple[int, int]]:
        perp_x, perp_y = -dy, dx
        drops = []
        for _ in range(drop_count):
            dist = random.randint(1, max_dist)  # noqa: S311 — game logic
            lat = random.choice([-1, 0, 0, 1])  # noqa: S311 — game logic
            drops.append((tx + dx * dist + perp_x * lat, ty + dy * dist + perp_y * lat))
        return drops

    def _add_pool(self, cx: int, cy: int, color: Color) -> None:
        for dy in range(-2, 3):
            self._add_pool_row(cx, cy, dy, color)

    def _add_pool_row(self, cx: int, cy: int, dy: int, color: Color) -> None:
        for dx in range(-2, 3):
            if abs(dx) + abs(dy) > 3:
                continue
            self._add_drop(cx + dx, cy + dy, color, _pool_alpha(abs(dx) + abs(dy)))

    def drain_dirty(self) -> dict[tuple[int, int], BloodTile]:
        """Return tiles modified since the last call; clears the dirty set."""
        result = {pos: self._tiles[pos] for pos in self._dirty if pos in self._tiles}
        self._dirty.clear()
        return result

    def _add_drop(self, x: int, y: int, color: Color, alpha: int) -> None:
        if not self._in_bounds(x, y):
            return
        existing = self._tiles.get((x, y))
        if existing is None:
            self._tiles[(x, y)] = BloodTile(color=color, alpha=alpha)
        else:
            new_alpha = min(_POOL_ALPHA_MAX, existing.alpha + alpha)
            new_color = _blend_color(existing.color, color, alpha / 255)
            self._tiles[(x, y)] = BloodTile(color=new_color, alpha=new_alpha)
        self._dirty.add((x, y))

    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self._width and 0 <= y < self._height
