"""NPC behaviour strategies — state-machine-based autonomous movement."""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import tcod.path

from faraway_realms import fov as _fov
from faraway_realms.commands import (
    Command,
    CommandType,
    make_attack_command,
    make_cast_command,
    make_clear_prime_command,
    make_target_command,
)
from faraway_realms.map import chebyshev as _chebyshev

if TYPE_CHECKING:
    from faraway_realms.map import Map


@dataclass(frozen=True)
class BehaviourContext:
    """Snapshot of game state passed to each NPC behaviour each tick.

    Parameters
    ----------
    game_map : Map
        The active map; used for walkability and FOV transparency.
    all_positions : dict[int, tuple[int, int]]
        Every entity currently on the map: ``entity_id → (x, y)``.
    target_ids : frozenset[int]
        Entity IDs this NPC should treat as chase targets.
    occupied : frozenset[tuple[int, int]]
        Tiles currently occupied by any entity (used to prevent collisions).
    abs_tick : int
        Current tick number; used by state transitions (default ``0``).
    ability_cooldowns : frozenset[str]
        Ability names currently on cooldown for this NPC (default empty).
    hp_fraction : float
        Current health as a fraction of maximum; ``1.0`` = full health.
    """

    game_map: Map
    all_positions: dict[int, tuple[int, int]]
    target_ids: frozenset[int]
    occupied: frozenset[tuple[int, int]]
    abs_tick: int = 0
    ability_cooldowns: frozenset[str] = field(default_factory=frozenset)
    hp_fraction: float = 1.0


class Behaviour(ABC):
    """Abstract base for NPC behaviour strategies."""

    @abstractmethod
    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Return commands for this tick (may be empty).

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC being controlled.
        ctx : BehaviourContext
            Snapshot of game state for this tick.

        Returns
        -------
        list[Command]
            The intended actions, to be enqueued by the caller.
        """

    def current_move_every(self, base: int) -> int:
        """Effective move rate for the current state (default: entity base rate)."""
        return base


# Maps (dx, dy) → direction name used by the MOVE command.
# Includes diagonals for A* pathfinding steps.
_DELTA_TO_DIRECTION: dict[tuple[int, int], str] = {
    (-1, 0): "left",
    (1, 0): "right",
    (0, -1): "up",
    (0, 1): "down",
}

_DIRECTIONS: list[tuple[int, int]] = [(-1, 0), (1, 0), (0, -1), (0, 1)]


def _build_transparency(game_map: Map) -> np.ndarray:
    """Return a ``(height, width)`` bool array; ``True`` = transparent.

    .. note::
        This is a compatibility wrapper around
        :func:`faraway_realms.fov.build_transparency`.
        It exists because ``tests/test_behaviour.py`` imports this name directly from
        ``behaviour``. Remove this wrapper only after updating those test imports.
    """
    return _fov.build_transparency(game_map)


def _cell_cost(
    game_map: Map,
    pos: tuple[int, int],
    occupied: frozenset[tuple[int, int]],
    npc_pos: tuple[int, int],
) -> int:
    """Return the pathfinding cost for *pos* (``0`` = impassable)."""
    x, y = pos
    if not game_map.is_walkable(x, y):
        return 0
    if pos in occupied and pos != npc_pos:
        return 0
    return 1


def _build_cost(
    game_map: Map,
    occupied: frozenset[tuple[int, int]],
    npc_pos: tuple[int, int],
) -> np.ndarray:
    """Return a ``(height, width)`` int32 cost array for A* pathfinding."""
    arr = np.zeros((game_map.height, game_map.width), dtype=np.int32)
    for y in range(game_map.height):
        for x in range(game_map.width):
            arr[y, x] = _cell_cost(game_map, (x, y), occupied, npc_pos)
    return arr


def _direction_command(
    npc_id: int, from_x: int, from_y: int, to_x: int, to_y: int
) -> Command | None:
    """Build a MOVE command for the given delta, or ``None`` if unmappable."""
    direction = _DELTA_TO_DIRECTION.get((to_x - from_x, to_y - from_y))
    if direction is None:
        return None
    return Command(
        command_type=CommandType.MOVE,
        actor=str(npc_id),
        args=(direction,),
        raw=f"/move {npc_id} {direction}",
    )


def _walk_candidates(
    npc_x: int, npc_y: int, ctx: BehaviourContext
) -> list[tuple[int, int]]:
    """Return walkable, unoccupied cardinal neighbours of (npc_x, npc_y)."""
    return [
        (npc_x + dx, npc_y + dy)
        for dx, dy in _DIRECTIONS
        if ctx.game_map.is_walkable(npc_x + dx, npc_y + dy)
        and (npc_x + dx, npc_y + dy) not in ctx.occupied
    ]


def _move_randomly(npc_id: int, ctx: BehaviourContext) -> Command | None:
    """Return a MOVE command in a random walkable, unoccupied direction."""
    npc_x, npc_y = ctx.all_positions[npc_id]
    candidates = _walk_candidates(npc_x, npc_y, ctx)
    if not candidates:
        return None
    tx, ty = random.choice(candidates)  # noqa: S311 — game logic, not crypto
    return _direction_command(npc_id, npc_x, npc_y, tx, ty)


def _step_toward(npc_id: int, target_id: int, ctx: BehaviourContext) -> Command | None:
    """Return a MOVE command one A* step toward *target_id*."""
    npc_x, npc_y = ctx.all_positions[npc_id]
    tx, ty = ctx.all_positions[target_id]
    cost = _build_cost(ctx.game_map, ctx.occupied, (npc_x, npc_y))
    path = tcod.path.path2d(
        cost,
        start_points=[(npc_y, npc_x)],
        end_points=[(ty, tx)],
        cardinal=2,
        diagonal=0,
    )
    if len(path) < 2:
        return None
    next_row, next_col = path[1]
    if (int(next_col), int(next_row)) == (tx, ty):  # already adjacent
        return None
    return _direction_command(npc_id, npc_x, npc_y, int(next_col), int(next_row))


def _compute_npc_fov(
    npc_id: int, sight_range: int, ctx: BehaviourContext
) -> np.ndarray:
    """Compute FOV array for the given NPC."""
    npc_x, npc_y = ctx.all_positions[npc_id]
    return _fov.compute_fov(ctx.game_map, npc_x, npc_y, sight_range)


def _find_visible_target(
    npc_id: int, sight_range: int, ctx: BehaviourContext
) -> int | None:
    """Return the first target_id visible to the NPC, or ``None``."""
    visible = _compute_npc_fov(npc_id, sight_range, ctx)
    for tid in ctx.target_ids:
        if tid not in ctx.all_positions:
            continue
        tx, ty = ctx.all_positions[tid]
        if visible[ty, tx]:
            return tid
    return None


def _can_see_target(
    npc_id: int, target_id: int, sight_range: int, ctx: BehaviourContext
) -> bool:
    """Return ``True`` if *target_id* is visible to the NPC."""
    if target_id not in ctx.all_positions:
        return False
    visible = _compute_npc_fov(npc_id, sight_range, ctx)
    tx, ty = ctx.all_positions[target_id]
    return bool(visible[ty, tx])


class BehaviourState(ABC):
    """A single state in a behaviour state machine.

    Each state handles its own per-tick action and its own transition logic.
    """

    @abstractmethod
    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Return commands for this tick (may be empty)."""

    @abstractmethod
    def transition(self, npc_id: int, ctx: BehaviourContext) -> BehaviourState | None:
        """Return the next state if a transition should occur, else ``None``."""

    def on_enter(self, npc_id: int) -> list[Command]:
        """Commands to emit when entering this state (default: none)."""
        return []

    def current_move_every(self, base: int) -> int:
        """Effective move rate for this state (default: entity base rate)."""
        return base


@dataclass
class WanderState(BehaviourState):
    """Random-walk state; transitions to ChaseState when a target enters FOV.

    Parameters
    ----------
    sight_range : int
        Tile radius for target detection.
    speed_factor : float
        Multiplier applied to the entity's base ``move_every``; values > 1
        make wandering slower than chasing (default: ``2.0``).
    preferred_ability : str | None
        Ability name to pass through to the resulting ChaseState.
    """

    sight_range: int = 8
    speed_factor: float = 2.0
    preferred_ability: str | None = None

    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Return a random move command, if any walkable tile is available."""
        cmd = _move_randomly(npc_id, ctx)
        return [cmd] if cmd else []

    def transition(self, npc_id: int, ctx: BehaviourContext) -> BehaviourState | None:
        """Transition to ChaseState when a target comes into view."""
        target_id = _find_visible_target(npc_id, self.sight_range, ctx)
        if target_id is not None:
            return ChaseState(
                sight_range=self.sight_range,
                target_id=target_id,
                preferred_ability=self.preferred_ability,
            )
        return None

    def on_enter(self, npc_id: int) -> list[Command]:
        """Clear attack-cooldown bar on entering wander (entity left combat)."""
        return [make_clear_prime_command(npc_id)]

    def current_move_every(self, base: int) -> int:
        """Wander speed is base multiplied by speed_factor."""
        return round(base * self.speed_factor)


@dataclass
class ChaseState(BehaviourState):
    """A* pursuit state; emits ATTACK when adjacent, returns to WanderState on LoS loss.

    Parameters
    ----------
    sight_range : int
        Tile radius used to verify the target is still visible.
    target_id : int
        Entity ID this NPC is hunting.
    preferred_ability : str | None
        When set and not on cooldown, emit a CAST command instead of ATTACK.
    """

    sight_range: int = 8
    target_id: int = 0
    preferred_ability: str | None = None

    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Step toward target or attack/cast if within Chebyshev range 1."""
        if self.target_id not in ctx.all_positions:
            return []
        nx, ny = ctx.all_positions[npc_id]
        tx, ty = ctx.all_positions[self.target_id]
        if _chebyshev(nx, ny, tx, ty) <= 1:
            return [self._combat_command(npc_id, ctx)]
        cmd = _step_toward(npc_id, self.target_id, ctx)
        return [cmd] if cmd else []

    def _combat_command(self, npc_id: int, ctx: BehaviourContext) -> Command:
        """Return a cast command if ability is ready, otherwise an attack."""
        if (
            self.preferred_ability is not None
            and self.preferred_ability not in ctx.ability_cooldowns
        ):
            return make_cast_command(npc_id, self.preferred_ability, self.target_id)
        return make_attack_command(npc_id, self.target_id)

    def transition(self, npc_id: int, ctx: BehaviourContext) -> BehaviourState | None:
        """Return to WanderState when target is no longer visible."""
        if not _can_see_target(npc_id, self.target_id, self.sight_range, ctx):
            return WanderState(
                sight_range=self.sight_range,
                preferred_ability=self.preferred_ability,
            )
        return None

    def on_enter(self, npc_id: int) -> list[Command]:
        """Acquire target and prime cooldown on entering chase."""
        return [make_target_command(npc_id, self.target_id)]


def _manhattan(a: tuple[int, int], b: tuple[int, int]) -> int:
    """Return Manhattan distance between two points."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _nearest_target_pos(npc_id: int, ctx: BehaviourContext) -> tuple[int, int] | None:
    """Return position of the closest target by Manhattan distance, or None."""
    pos = ctx.all_positions.get(npc_id)
    if pos is None:
        return None
    candidates = [
        ctx.all_positions[tid] for tid in ctx.target_ids if tid in ctx.all_positions
    ]
    if not candidates:
        return None
    return min(candidates, key=lambda p: _manhattan(pos, p))


def _flee_candidates(
    pos: tuple[int, int], target_pos: tuple[int, int], ctx: BehaviourContext
) -> list[tuple[int, int]]:
    """Return walkable, unoccupied neighbours sorted by distance from target."""
    nx, ny = pos
    reachable = [
        (nx + dx, ny + dy)
        for dx, dy in _DIRECTIONS
        if ctx.game_map.is_walkable(nx + dx, ny + dy)
        and (nx + dx, ny + dy) not in ctx.occupied
    ]
    return sorted(reachable, key=lambda p: _manhattan(p, target_pos), reverse=True)


def _move_away(
    npc_id: int,
    pos: tuple[int, int],
    target_pos: tuple[int, int],
    ctx: BehaviourContext,
) -> Command | None:
    """Return a MOVE command that maximises distance from target_pos."""
    candidates = _flee_candidates(pos, target_pos, ctx)
    if not candidates:
        return None
    nx, ny = pos
    best = candidates[0]
    return _direction_command(npc_id, nx, ny, best[0], best[1])


def _flee_from_nearest(npc_id: int, ctx: BehaviourContext) -> Command | None:
    """Return a move command away from the nearest target, or None."""
    pos = ctx.all_positions.get(npc_id)
    if pos is None:
        return None
    target_pos = _nearest_target_pos(npc_id, ctx)
    if target_pos is None:
        return None
    return _move_away(npc_id, pos, target_pos, ctx)


@dataclass
class FleeState(BehaviourState):
    """Move away from the nearest hostile target.

    Parameters
    ----------
    sight_range : int
        Tile radius for detecting when the threat has left FOV.
    speed_factor : float
        Multiplier on base move_every; < 1.0 makes fleeing faster than base.
    """

    sight_range: int = 8
    speed_factor: float = 1.0

    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Move away from the nearest target."""
        cmd = _flee_from_nearest(npc_id, ctx)
        return [cmd] if cmd else []

    def transition(self, npc_id: int, ctx: BehaviourContext) -> BehaviourState | None:
        """Return to WanderState when no targets are visible."""
        target_id = _find_visible_target(npc_id, self.sight_range, ctx)
        if target_id is None:
            return WanderState(sight_range=self.sight_range)
        return None

    def current_move_every(self, base: int) -> int:
        """Flee speed is base multiplied by speed_factor."""
        return round(base * self.speed_factor)


class StateMachineBehaviour(Behaviour):
    """A Behaviour backed by an explicit state machine.

    Parameters
    ----------
    initial_state : BehaviourState
        The state the NPC begins in.
    """

    def __init__(self, initial_state: BehaviourState) -> None:
        self._state = initial_state

    def act(self, npc_id: int, ctx: BehaviourContext) -> list[Command]:
        """Tick the state machine and return resulting commands."""
        next_state = self._state.transition(npc_id, ctx)
        if next_state is not None:
            enter_cmds = next_state.on_enter(npc_id)
            self._state = next_state
            return enter_cmds
        return self._state.act(npc_id, ctx)

    def current_move_every(self, base: int) -> int:
        """Delegate to the current state."""
        return self._state.current_move_every(base)
