"""Shared utilities for content parsers."""

import re

_URIZEN_BASE: int = 0xE000
_URIZEN_RE = re.compile(r"^u:(\d+)$")


def parse_glyph(s: str) -> int:
    """Convert a YAML glyph value to a tcod character codepoint.

    Parameters
    ----------
    s : str
        Either a single ASCII/Unicode character (e.g. ``"@"``) or a Urizen
        sprite reference in the form ``"u:N"`` where *N* is the zero-based
        sprite index within the Urizen section of the unified tilesheet.

    Returns
    -------
    int
        The Unicode codepoint to assign to ``console.rgb["ch"]``.
        Single characters return ``ord(s)``.
        ``"u:N"`` returns ``URIZEN_BASE + N`` (``0xE000 + N``).

    Raises
    ------
    ValueError
        When *s* is not a single character and does not match ``u:N``.
    """
    m = _URIZEN_RE.match(s)
    if m:
        return _URIZEN_BASE + int(m.group(1))
    if len(s) == 1:
        return ord(s)
    msg = f"Invalid glyph {s!r} — use a single character or 'u:N' for Urizen sprite N"
    raise ValueError(msg)


def parse_color(val: list) -> tuple[int, int, int]:
    """Parse a 3-element list into an RGB tuple.

    Parameters
    ----------
    val : list
        A sequence of three numeric values ``[r, g, b]``.

    Returns
    -------
    tuple[int, int, int]
        RGB colour tuple with each channel as an ``int``.
    """
    if len(val) != 3:  # noqa: PLR2004
        msg = f"Color must have exactly 3 components, got {len(val)}"
        raise ValueError(msg)
    return (int(val[0]), int(val[1]), int(val[2]))
