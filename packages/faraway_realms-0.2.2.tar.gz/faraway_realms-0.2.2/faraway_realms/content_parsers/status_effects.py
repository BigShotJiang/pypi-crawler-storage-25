"""Parser for status effect display definition YAML."""

from faraway_realms.content_parsers import parse_color, parse_glyph
from faraway_realms.status_definitions import STATUS_DEF_REGISTRY, StatusDefinition


def parse_status_effects(entries: dict) -> None:
    """Populate STATUS_DEF_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of status name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        kwargs: dict = {
            "name": name,
            "bg_color": parse_color(data["bg_color"]),
            "glyph": parse_glyph(str(data["glyph"])),
        }
        if "fg_color" in data:
            kwargs["fg_color"] = parse_color(data["fg_color"])
        STATUS_DEF_REGISTRY[name] = StatusDefinition(**kwargs)
