"""Parser for static object type YAML definitions."""

from faraway_realms.components import LightEmitter
from faraway_realms.content_parsers import parse_color, parse_glyph
from faraway_realms.static_object import STATIC_OBJECT_REGISTRY, StaticObjectType


def parse_static_objects(entries: dict) -> None:
    """Populate STATIC_OBJECT_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of static object name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        STATIC_OBJECT_REGISTRY[name] = _parse_static_object(name, data)


def _parse_static_object(name: str, data: dict) -> StaticObjectType:
    raw_color = data["fg_color"]
    components = _parse_components(data)
    return StaticObjectType(
        name=name,
        char=parse_glyph(str(data["char"])),
        fg_color=parse_color(raw_color),
        components=components,
        labels=frozenset(data.get("labels") or []),
    )


def _parse_components(data: dict) -> dict:
    """Parse the components: key into a components dict.

    Parameters
    ----------
    data : dict
        Raw YAML dict for a single static object entry.

    Returns
    -------
    dict
        Populated components dict, keyed by component name.
    """
    components: dict = {}
    for key, val in (data.get("components") or {}).items():
        if key == "light_emitter":
            components["light_emitter"] = _parse_light_emitter(val)
    return components


def _parse_light_emitter(data: dict) -> LightEmitter:
    return LightEmitter(
        radius=int(data["radius"]),
        intensity=float(data["intensity"]),
        color=parse_color(data["color"]),
    )
