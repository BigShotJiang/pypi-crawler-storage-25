"""YAML parser for ability definitions — populates ``ABILITY_REGISTRY``."""

from __future__ import annotations

from typing import Callable

from faraway_realms.abilities import (
    ABILITY_REGISTRY,
    Ability,
    AbilityEffect,
    ApplyStatusEffect,
    BackstepEffect,
    DamageEffect,
    KnockbackEffect,
    ProjectileEffect,
)
from faraway_realms.content_parsers import parse_color


def parse_abilities(entries: dict) -> None:
    """Parse a merged abilities dict and populate ``ABILITY_REGISTRY``.

    Parameters
    ----------
    entries : dict
        Mapping of ability name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        ABILITY_REGISTRY[name] = _parse_ability(name, data)


# ------------------------------------------------------------------
# Ability
# ------------------------------------------------------------------


def _parse_ability(name: str, data: dict) -> Ability:
    cost_raw = data.get("resource_cost")
    effects_raw = data.get("effects") or []
    return Ability(
        name=name,
        cooldown=int(data["cooldown"]),
        cast_time=int(data.get("cast_time", 0)),
        range_tiles=int(data.get("range_tiles", 1)),
        can_move_while_casting=bool(data.get("can_move_while_casting", False)),
        gcd=bool(data.get("gcd", True)),
        channel_interval=data.get("channel_interval"),
        description=str(data.get("description", "")),
        abbreviation=str(data.get("abbreviation", "")),
        resource_cost=_parse_resource_cost(cost_raw),
        effects=tuple(_parse_effect(e) for e in effects_raw),
    )


def _parse_resource_cost(val: list | None) -> tuple[str, int] | None:
    if val is None:
        return None
    return (str(val[0]), int(val[1]))


# ------------------------------------------------------------------
# Effects
# ------------------------------------------------------------------

_EFFECT_PARSERS: dict[str, Callable[[dict], AbilityEffect]] = {}


def _register_effect(kind: str) -> Callable:
    def decorator(fn: Callable) -> Callable:
        _EFFECT_PARSERS[kind] = fn
        return fn

    return decorator


def _parse_effect(data: dict) -> AbilityEffect:
    kind = data.get("kind", "")
    parser = _EFFECT_PARSERS.get(kind)
    if parser is None:
        msg = f"Unknown ability effect kind: {kind!r}"
        raise ValueError(msg)
    return parser(data)


@_register_effect("damage")
def _parse_damage_effect(data: dict) -> DamageEffect:
    return DamageEffect(
        base=int(data.get("base", 5)),
        damage_type=str(data.get("damage_type", "bludgeoning")),
    )


@_register_effect("knockback")
def _parse_knockback_effect(data: dict) -> KnockbackEffect:
    return KnockbackEffect(distance=int(data.get("distance", 1)))


@_register_effect("backstep")
def _parse_backstep_effect(data: dict) -> BackstepEffect:
    return BackstepEffect(distance=int(data.get("distance", 2)))


@_register_effect("status")
def _parse_status_effect(data: dict) -> ApplyStatusEffect:
    return ApplyStatusEffect(
        status_name=str(data.get("status_name", "")),
        duration=int(data.get("duration", 0)),
        tick_damage=int(data.get("tick_damage", 0)),
        tick_heal=int(data.get("tick_heal", 0)),
        dot_interval=int(data.get("dot_interval", 10)),
        immobilize=bool(data.get("immobilize", False)),
        stun=bool(data.get("stun", False)),
        haste=float(data.get("haste", 1.0)),
        show_message=bool(data.get("show_message", True)),
    )


@_register_effect("projectile")
def _parse_projectile_effect(data: dict) -> ProjectileEffect:
    from faraway_realms.components import LightEmitter

    components: dict = {}
    for key, val in (data.get("components") or {}).items():
        if key == "light_emitter":
            components["light_emitter"] = LightEmitter(
                radius=int(val["radius"]),
                intensity=float(val["intensity"]),
                color=parse_color(val.get("color", [255, 200, 120])),
            )
    return ProjectileEffect(
        base=int(data.get("base", 10)),
        damage_type=str(data.get("damage_type", "fire")),
        speed=float(data.get("speed", 1.0)),
        color=parse_color(data.get("color", [255, 100, 0])),
        visual_type=str(data.get("visual_type", "spell")),
        trail_length=int(data.get("trail_length", 0)),
        trail_char=str(data.get("trail_char", "+")),
        on_hit_statuses=_parse_on_hit_statuses(data.get("on_hit_statuses") or []),
        components=components,
    )


# ------------------------------------------------------------------
# Nested helpers
# ------------------------------------------------------------------


def _parse_on_hit_statuses(
    items: list[dict],
) -> tuple[ApplyStatusEffect, ...]:
    return tuple(_parse_status_effect(item) for item in items)
