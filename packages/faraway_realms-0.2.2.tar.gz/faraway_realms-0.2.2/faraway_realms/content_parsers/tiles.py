"""Parser for tile type, overlay, and patch YAML definitions."""

from __future__ import annotations

from faraway_realms.content_parsers import parse_color, parse_glyph
from faraway_realms.mapgen.texture import (
    TILE_OVERLAY_REGISTRY,
    TILE_TYPE_PATCH_REGISTRY,
    TileOverlay,
    TileTypePatch,
)
from faraway_realms.tile import TILE_REGISTRY, TileType


def parse_tiles(entries: dict) -> None:
    """Populate TILE_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of tile name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        TILE_REGISTRY[name] = _parse_tile_type(name, data)


def parse_tile_overlays(entries: dict) -> None:
    """Populate TILE_OVERLAY_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of overlay name → raw YAML dict.
    """
    for name, data in entries.items():
        TILE_OVERLAY_REGISTRY[name] = _parse_tile_overlay(data)


def parse_tile_type_patches(entries: dict) -> None:
    """Populate TILE_TYPE_PATCH_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of patch name → raw YAML dict.
    """
    for name, data in entries.items():
        TILE_TYPE_PATCH_REGISTRY[name] = _parse_tile_type_patch(data)


def _parse_tile_type(name: str, data: dict) -> TileType:
    return TileType(
        name=name,
        walkable=bool(data["walkable"]),
        bg_color=parse_color(data["bg_color"]),
        fg_color=parse_color(data["fg_color"]),
        char=parse_glyph(str(data.get("char", "."))),
        description=data.get("description") or None,
    )


def _parse_tile_overlay(data: dict) -> TileOverlay:
    return TileOverlay(
        floor_bg=parse_color(data["floor_bg"]),
        floor_fg=parse_color(data["floor_fg"]),
        wall_bg=parse_color(data["wall_bg"]),
        wall_fg=parse_color(data["wall_fg"]),
        threshold=float(data.get("threshold", 0.75)),
        noise_offset=float(data.get("noise_offset", 0.0)),
        blend=bool(data.get("blend", False)),
        description=data.get("description") or None,
        char=parse_glyph(str(data["char"])) if data.get("char") else None,
    )


def _parse_tile_type_patch(data: dict) -> TileTypePatch:
    return TileTypePatch(
        floor=str(data["floor"]),
        wall=str(data["wall"]),
        threshold=float(data.get("threshold", 0.72)),
        noise_offset=float(data.get("noise_offset", 0.0)),
    )
