"""Parser for stat definition YAML — populates STAT_DEF_REGISTRY."""

from __future__ import annotations

from faraway_realms.content_parsers import parse_color
from faraway_realms.stat_definitions import STAT_DEF_REGISTRY, StatDefinition


def parse_stat_definitions(entries: dict) -> None:
    """Populate STAT_DEF_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of stat name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        STAT_DEF_REGISTRY[name] = _parse_stat_definition(name, data)


def _parse_stat_definition(name: str, data: dict) -> StatDefinition:
    raw_filled = data.get("bar_filled")
    raw_empty = data.get("bar_empty")
    return StatDefinition(
        name=name,
        kind=str(data.get("kind", "stat")),
        abbreviation=str(data.get("abbreviation", "")),
        bar_filled=parse_color(raw_filled) if raw_filled else None,
        bar_empty=parse_color(raw_empty) if raw_empty else None,
        regen_per_tick=int(data.get("regen_per_tick", 0)),
    )
