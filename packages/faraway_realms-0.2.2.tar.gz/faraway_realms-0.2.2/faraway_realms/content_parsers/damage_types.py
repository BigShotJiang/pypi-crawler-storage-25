"""Parser for damage type effectiveness YAML definitions."""

from faraway_realms.damage_types import EFFECTIVENESS


def parse_damage_effectiveness(entries: dict) -> None:
    """Populate EFFECTIVENESS from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of damage_type → {armor_type → multiplier}, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for damage_type, armor_map in entries.items():
        for armor_type, multiplier in armor_map.items():
            EFFECTIVENESS[(str(damage_type), str(armor_type))] = float(multiplier)
