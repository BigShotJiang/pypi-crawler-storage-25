"""Lighting system — LightSource data and per-tile LightMap computation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import tcod.map


@dataclass(frozen=True)
class LightSource:
    """A point light that illuminates tiles within a circular radius.

    Parameters
    ----------
    radius : int
        Maximum illumination distance in tiles.
    intensity : float
        Peak brightness at the source tile (0.0–1.0).  Falls off linearly
        to zero at the edge of the radius.
    color : tuple[int, int, int]
        RGB tint of the light.  Each channel is applied independently so
        a warm torch and a cool mushroom produce visibly different tints.
    """

    radius: int
    intensity: float
    color: tuple[int, int, int] = (255, 200, 120)


class LightMap:
    """Per-tile RGB brightness array recomputed each frame from light sources.

    Three float32 arrays (R, G, B) each start at ``AMBIENT``.  Every source
    accumulates its colour-weighted falloff into the relevant channel, capped
    at ``1.0``.  Explored-but-not-visible tiles are rendered using a separate
    "memory" tint supplied by the renderer.

    Parameters
    ----------
    width : int
        Map width in tiles.
    height : int
        Map height in tiles.
    """

    AMBIENT: float = 0.35

    def __init__(self, width: int, height: int) -> None:
        self._w = width
        self._h = height
        shape = (height, width)
        self._r: np.ndarray = np.full(shape, self.AMBIENT, dtype=np.float32)
        self._g: np.ndarray = np.full(shape, self.AMBIENT, dtype=np.float32)
        self._b: np.ndarray = np.full(shape, self.AMBIENT, dtype=np.float32)

    def compute(
        self,
        sources: list[tuple[int, int, LightSource]],
        transparency: np.ndarray | None = None,
    ) -> None:
        """Recompute brightness from *sources*; resets to ambient first.

        Parameters
        ----------
        sources : list[tuple[int, int, LightSource]]
            Sequence of ``(x, y, light_source)`` tuples for all active emitters.
        transparency : np.ndarray or None
            ``(height, width)`` bool array; ``True`` = transparent (floor).
            Walls block light from passing through but are themselves illuminated.
            When ``None``, the map is treated as fully open (no blocking).
        """
        eff_transparency = (
            transparency
            if transparency is not None
            else np.ones((self._h, self._w), dtype=bool)
        )
        self._r[:] = self.AMBIENT
        self._g[:] = self.AMBIENT
        self._b[:] = self.AMBIENT
        for x, y, src in sources:
            self._add_source(x, y, src, eff_transparency)

    def at(self, x: int, y: int) -> float:
        """Return peak channel brightness at tile ``(x, y)``.

        Returns the maximum of the three RGB channels.  Useful for tests and
        scalar comparisons; the renderer uses :meth:`rgb_at` for full colour.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.

        Returns
        -------
        float
            Brightness in ``[0.0, 1.0]``.
        """
        return max(float(self._r[y, x]), float(self._g[y, x]), float(self._b[y, x]))

    def rgb_at(self, x: int, y: int) -> tuple[float, float, float]:
        """Return the RGB light factor at tile ``(x, y)``.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.

        Returns
        -------
        tuple[float, float, float]
            Per-channel brightness factors in ``[0.0, 1.0]``.
        """
        return (float(self._r[y, x]), float(self._g[y, x]), float(self._b[y, x]))

    def _add_source(
        self, cx: int, cy: int, src: LightSource, transparency: np.ndarray
    ) -> None:
        """Accumulate one light source, blocked by walls via FOV shadow-casting."""
        r = src.radius
        fov = tcod.map.compute_fov(transparency, (cy, cx), radius=r, light_walls=True)
        y0 = max(0, cy - r)
        y1 = min(self._h, cy + r + 1)
        x0 = max(0, cx - r)
        x1 = min(self._w, cx + r + 1)
        ys = np.arange(y0, y1, dtype=np.float32)[:, None]
        xs = np.arange(x0, x1, dtype=np.float32)[None, :]
        dist = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        contrib = np.where(dist <= r, (1.0 - dist / r) * src.intensity, 0.0)
        contrib *= fov[y0:y1, x0:x1]
        cr, cg, cb = src.color[0] / 255.0, src.color[1] / 255.0, src.color[2] / 255.0
        sl = np.s_[y0:y1, x0:x1]
        self._r[sl] = np.minimum(1.0, self._r[sl] + contrib * cr)
        self._g[sl] = np.minimum(1.0, self._g[sl] + contrib * cg)
        self._b[sl] = np.minimum(1.0, self._b[sl] + contrib * cb)
