"""Right-side panel components — renderable sections for the details pane."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.stats import Pool

if TYPE_CHECKING:
    from faraway_realms.entity import GameEntity
    from faraway_realms.game_protocol import GameProtocol

# Bar colours
BAR_FILLED: tuple[int, int, int] = (0, 180, 0)
BAR_EMPTY: tuple[int, int, int] = (140, 20, 20)

_STAT_COLOR: tuple[int, int, int] = (200, 200, 200)
_HEADER_COLOR: tuple[int, int, int] = (140, 140, 80)


def _draw_bar(
    console: tcod.console.Console,
    x: int,
    y: int,
    width: int,
    current: int,
    maximum: int,
    filled: tuple[int, int, int] = BAR_FILLED,
    empty: tuple[int, int, int] = BAR_EMPTY,
) -> None:
    """Draw a filled/empty color bar using background cells.

    Parameters
    ----------
    console : tcod.console.Console
        Target console.
    x : int
        Left column of the bar.
    y : int
        Row of the bar.
    width : int
        Total bar width in tiles.
    current : int
        Current value (filled portion).
    maximum : int
        Maximum value (full width).
    filled : tuple[int, int, int]
        Background color for the filled portion.
    empty : tuple[int, int, int]
        Background color for the empty portion.
    """
    ratio = current / maximum if maximum > 0 else 0.0
    filled_w = round(ratio * width)
    for i in range(width):
        color = filled if i < filled_w else empty
        console.rgb[y, x + i]["bg"] = color
        console.rgb[y, x + i]["ch"] = ord(" ")


class Panel(ABC):
    """Abstract base for a renderable details-pane section.

    Panels are registered with the UI and cycled via a key binding.
    Each panel receives only the region it should draw into.
    """

    @property
    @abstractmethod
    def title(self) -> str:
        """Short label shown in the section header."""

    @abstractmethod
    def render(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
    ) -> int:
        """Draw the panel content into *console*.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        x : int
            Left column of the content region.
        y : int
            Top row of the content region.
        width : int
            Available tile width.

        Returns
        -------
        int
            Number of rows consumed.
        """


class StatsPanel(Panel):
    """Renders an entity's stats: Pools as labelled bars, Stats as values.

    Parameters
    ----------
    entity : GameEntity
        The entity whose ``stats`` dict is rendered.
    abbreviations : dict[str, str] | None
        Optional mapping of stat key → display label.
        E.g. ``{"health": "HP", "strength": "STR"}``.
        Keys not present fall back to ``name.capitalize()``.
    """

    @property
    def title(self) -> str:
        """Return the panel title."""
        return "Stats"

    def __init__(
        self,
        entity: GameEntity,
        abbreviations: dict[str, str] | None = None,
    ) -> None:
        self._entity = entity
        self._abbreviations: dict[str, str] = abbreviations or {}

    def render(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
    ) -> int:
        """Render all stats and return rows consumed.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        x : int
            Left column.
        y : int
            Top row.
        width : int
            Available tile width.

        Returns
        -------
        int
            Total rows consumed.
        """
        row = y
        for name, stat in self._entity.stats.items():
            label = (
                stat.abbreviation or self._abbreviations.get(name) or name.capitalize()
            )
            if isinstance(stat, Pool):
                row += self._render_pool(console, x, row, width, label, stat)
            else:
                row += self._render_flat(console, x, row, width, label, stat.value)
        return row - y

    def _render_pool(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        label: str,
        pool: Pool,
    ) -> int:
        w = width - 1
        text = f"{label}: {pool.current}/{pool.value}"
        console.print(x, y, text[:w], fg=_STAT_COLOR)
        filled = pool.bar_filled or BAR_FILLED
        empty = pool.bar_empty or BAR_EMPTY
        _draw_bar(console, x, y + 1, w, pool.current, pool.value, filled, empty)
        return 3  # text row + bar row + blank spacer

    def _render_flat(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        label: str,
        value: int,
    ) -> int:
        console.print(x, y, f"{label}: {value}"[: width - 1], fg=_STAT_COLOR)
        return 2  # text row + blank spacer


class LiveStatsPanel(Panel):
    """StatsPanel that looks up the entity live from the game each frame.

    Use this instead of ``StatsPanel`` when the entity may not exist yet at
    panel construction time (e.g. the client-side stats panel, created before
    the first snapshot arrives).

    Parameters
    ----------
    game : GameProtocol
        Game instance used to resolve the entity each frame.
    entity_id : int
        ID of the entity to display.
    """

    def __init__(self, game: GameProtocol, entity_id: int) -> None:
        self._game = game
        self._entity_id = entity_id

    @property
    def title(self) -> str:
        """Return the panel title."""
        return "Stats"

    def render(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
    ) -> int:
        """Render stats for the live entity; returns 0 if not yet available."""
        entity = self._game.entity(self._entity_id)
        if entity is None or not entity.stats:
            return 0
        return StatsPanel(entity).render(console, x, y, width)
