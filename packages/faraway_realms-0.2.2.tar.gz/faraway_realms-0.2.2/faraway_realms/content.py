"""Generic YAML content loader — scans directories and dispatches to parsers."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

import yaml


class ContentLoader:
    """Scan one or more directories for YAML files and dispatch to parsers.

    Directories are searched in order; later directories win (user overrides
    game data).  Merging happens at the **entry name** level within each
    top-level key, so a user file containing only ``kick:`` under
    ``abilities:`` overrides just that one ability.

    Parameters
    ----------
    dirs : list[Path]
        Search directories in priority order (last wins).
    """

    def __init__(self, dirs: list[Path]) -> None:
        self._dirs = dirs
        self._parsers: dict[str, Callable[[dict], None]] = {}

    def register_parser(self, key: str, parser: Callable[[dict], None]) -> None:
        """Register a parser for a top-level YAML key.

        Parameters
        ----------
        key : str
            Top-level YAML key (e.g. ``"abilities"``).
        parser : Callable[[dict], None]
            Function that receives the merged dict for *key* and populates
            the relevant in-memory registry.
        """
        self._parsers[key] = parser

    def load(self) -> None:
        """Scan all directories, merge YAML, and dispatch to parsers."""
        merged = self._merge_yaml_files()
        for key, payload in merged.items():
            self._dispatch(key, payload)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _merge_yaml_files(self) -> dict[str, dict]:
        result: dict[str, dict] = {}
        for directory in self._dirs:
            if not directory.exists():
                continue
            for path in sorted(directory.rglob("*.yaml")):
                self._merge_one(result, path)
        return result

    def _merge_one(self, result: dict[str, dict], path: Path) -> None:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return
        for top_key, entries in raw.items():
            if not isinstance(entries, dict):
                continue
            result.setdefault(top_key, {}).update(entries)

    def _dispatch(self, key: str, payload: dict) -> None:
        parser = self._parsers.get(key)
        if parser is not None:
            parser(payload)
