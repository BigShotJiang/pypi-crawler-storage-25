"""Creature type definitions — data-driven NPC templates."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from faraway_realms.behaviour import StateMachineBehaviour, WanderState
from faraway_realms.components import CombatProfile
from faraway_realms.entity import Entity

if TYPE_CHECKING:
    from faraway_realms.behaviour import Behaviour


def _make_behaviour(
    behaviour: str,
    sight_range: int,
    preferred_ability: str | None = None,
) -> Behaviour:
    """Instantiate a behaviour strategy by name.

    # TODO(design): parse a behaviour config dict here instead of matching string keys

    Parameters
    ----------
    behaviour : str
        Registered behaviour key (e.g. ``"wander_chase"``).
        # TODO(design): replace string key with config dict for YAML-isomorphic
        # behaviour definition
    sight_range : int
        Detection radius passed to the behaviour constructor.
    preferred_ability : str | None
        Optional ability name passed through to the initial state.

    Returns
    -------
    Behaviour
        A concrete behaviour instance.

    Raises
    ------
    ValueError
        When *behaviour* does not match a known key.
    """
    if behaviour == "wander_chase":
        return StateMachineBehaviour(
            WanderState(
                sight_range=sight_range,
                preferred_ability=preferred_ability,
            )
        )
    raise ValueError(f"Unknown behaviour: {behaviour!r}")


@dataclass(frozen=True)
# pylint: disable=too-many-instance-attributes
class CreatureType:
    """Immutable template used to spawn NPC entities.

    Parameters
    ----------
    name : str
        Display name and unique registry key.
    char : int
        Unicode codepoint to display.
    fg_color : tuple[int, int, int]
        RGB foreground colour.
    faction : str
        Faction string; defaults to ``"hostile"``.
    stats : dict[str, int]
        Mapping of stat key to base integer value.  Keys are resolved
        against ``STAT_DEF_REGISTRY`` at spawn time.
    move_every : int
        Move once every this many ticks.
    sight_range : int
        Detection radius in tiles.
    labels : frozenset[str]
        Arbitrary tags for filtering (e.g. ``"undead"``, ``"cave"``).
    abilities : tuple[str, ...]
        Ability keys resolved from ``ABILITY_REGISTRY`` at spawn time.
    combat_profile : CombatProfile
        Combat statistics (attack rate, armor/damage types, blood colour).
    behaviour_kind : str | None
        Behaviour strategy key; ``None`` means player-controlled (no AI).
    preferred_ability : str | None
        Optional ability name passed to the initial behaviour state.
    """

    name: str
    char: int
    fg_color: tuple[int, int, int]
    faction: str = "hostile"
    stats: dict[str, int] = field(default_factory=dict)
    move_every: int = 3
    sight_range: int = 8
    labels: frozenset[str] = field(default_factory=frozenset)
    abilities: tuple[str, ...] = ()
    combat_profile: CombatProfile = field(default_factory=CombatProfile)
    behaviour_kind: str | None = "wander_chase"
    preferred_ability: str | None = None

    def to_entity(self, entity_id: int) -> Entity:
        """Instantiate an :class:`Entity` from this template.

        Attaches ``CombatProfile`` from this template directly and builds a
        ``BehaviourComponent`` when ``behaviour_kind`` is not ``None``.
        Absence of ``BehaviourComponent`` signals player-controlled.

        Parameters
        ----------
        entity_id : int
            Unique identifier to assign to the new entity.

        Returns
        -------
        Entity
            A fully configured entity ready to be placed on the map.
        """
        from faraway_realms.abilities import ABILITY_REGISTRY
        from faraway_realms.components import BehaviourComponent
        from faraway_realms.stat_definitions import STAT_DEF_REGISTRY

        stats = {
            key: STAT_DEF_REGISTRY[key].make(value)
            for key, value in self.stats.items()
            if key in STAT_DEF_REGISTRY
        }
        abilities = {
            name: ABILITY_REGISTRY[name]
            for name in self.abilities
            if name in ABILITY_REGISTRY
        }
        from faraway_realms.components import Component

        components: dict[str, Component] = {"combat_profile": self.combat_profile}
        if self.behaviour_kind is not None:
            behaviour = _make_behaviour(
                self.behaviour_kind, self.sight_range, self.preferred_ability
            )
            components["behaviour"] = BehaviourComponent(behaviour=behaviour)
        return Entity(
            entity_id=entity_id,
            char=self.char,
            fg_color=self.fg_color,
            name=self.name,
            move_every=self.move_every,
            faction=self.faction,
            stats=stats,
            abilities=abilities,
            components=components,
        )

    def to_npc(self, entity_id: int) -> Entity:
        """Alias for :meth:`to_entity`; kept for backward compatibility."""
        return self.to_entity(entity_id)


CREATURE_REGISTRY: dict[str, CreatureType] = {}
