"""Structural interface that both Game and ClientGame satisfy."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from faraway_realms.blood import BloodEvent, BloodMap
    from faraway_realms.chat import ChatMessage
    from faraway_realms.commands import Command
    from faraway_realms.entity import Entity, GameEntity
    from faraway_realms.factions import FactionRelations
    from faraway_realms.light import LightSource
    from faraway_realms.map import Map
    from faraway_realms.projectile import Projectile
    from faraway_realms.static_object import StaticObject
    from faraway_realms.status import StatusInstance


@runtime_checkable
class GameProtocol(Protocol):
    """Structural interface satisfied by both Game and ClientGame."""

    @property
    def game_map(self) -> Map:
        """Return the active map."""
        ...

    @property
    def blood_map(self) -> BloodMap:
        """Return the blood stain map."""
        ...

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return in-flight projectiles."""
        ...

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return all static objects on the map."""
        ...

    @property
    def faction_relations(self) -> FactionRelations:
        """Return faction hostility relations."""
        ...

    @property
    def tick_rate(self) -> float:
        """Return the target ticks-per-second rate."""
        ...

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player-controlled entities."""
        ...

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities (those carrying a BehaviourComponent)."""
        ...

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID, or None."""
        ...

    def drain_attack_anim_events(
        self,
    ) -> list[tuple[tuple[int, int], tuple[int, int], tuple[int, int, int]]]:
        """Consume and return pending melee attack animation events."""
        ...

    def drain_blood_events(self) -> list[BloodEvent]:
        """Consume and return pending blood splat events."""
        ...

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return attack cooldown progress for entity (0–1)."""
        ...

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return GCD progress while active, else None."""
        ...

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return cast progress if casting, else None."""
        ...

    def ability_cooldown_fraction(self, entity_id: int, ability_name: str) -> float:
        """Return remaining cooldown fraction for the named ability."""
        ...

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return non-expired status effects on entity."""
        ...

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return True when entity has the named active status."""
        ...

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return the most recent chat messages."""
        ...

    def get_hit_seq(self, entity_id: int) -> int:
        """Return monotonically increasing hit count for entity."""
        ...

    def get_crit_dealt_seq(self, entity_id: int) -> int:
        """Return monotonically increasing crit count for entity."""
        ...

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Return all active light source positions."""
        ...

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = (200, 200, 200),
    ) -> None:
        """Append a message to the chat history."""
        ...

    def enqueue_command(self, command: Command) -> None:
        """Enqueue a command for processing."""
        ...
