"""Tile definitions for the game map."""

from __future__ import annotations

from dataclasses import dataclass

Color = tuple[int, int, int]


@dataclass
class Tile:
    """A single cell in the game map.

    Parameters
    ----------
    walkable : bool
        Whether entities can enter this tile.
    bg_color : Color
        Background RGB color.
    fg_color : Color
        Foreground RGB color for the character glyph.
    char : int
        Unicode codepoint to display. Defaults to space (32).
    """

    walkable: bool
    bg_color: Color
    fg_color: Color
    char: int = ord(" ")


@dataclass(frozen=True)
class TileType:
    """Immutable template for a named tile variant.

    Parameters
    ----------
    name : str
        Registry key (e.g. ``"cave_floor"``).
    walkable : bool
        Whether entities can enter tiles of this type.
    bg_color : Color
        Background RGB color.
    fg_color : Color
        Foreground RGB color.
    char : int
        Unicode codepoint to display. Defaults to ``ord(".")`` (46).
    """

    name: str
    walkable: bool
    bg_color: Color
    fg_color: Color
    char: int = ord(".")
    description: str | None = None

    def make(self) -> Tile:
        """Return a fresh mutable Tile instance from this template.

        Returns
        -------
        Tile
            A new Tile; callers may mutate it freely (e.g. NoiseTexturePass).
        """
        return Tile(
            walkable=self.walkable,
            bg_color=self.bg_color,
            fg_color=self.fg_color,
            char=self.char,
        )


TILE_REGISTRY: dict[str, TileType] = {}


def floor_tile() -> Tile:
    """Return a walkable floor tile.

    Returns
    -------
    Tile
        A dark grey floor tile.
    """
    if "floor" in TILE_REGISTRY:
        return TILE_REGISTRY["floor"].make()
    return Tile(
        walkable=True, bg_color=(50, 50, 50), fg_color=(200, 200, 200), char=ord(".")
    )


def wall_tile() -> Tile:
    """Return a non-walkable wall tile.

    Returns
    -------
    Tile
        A light grey wall tile.
    """
    if "wall" in TILE_REGISTRY:
        return TILE_REGISTRY["wall"].make()
    return Tile(
        walkable=False,
        bg_color=(100, 100, 100),
        fg_color=(200, 200, 200),
        char=ord("#"),
    )


def cave_floor_tile() -> Tile:
    """Return a walkable cave floor tile.

    Returns
    -------
    Tile
        A brownish walkable tile representing carved cave rock.
    """
    if "cave_floor" in TILE_REGISTRY:
        return TILE_REGISTRY["cave_floor"].make()
    return Tile(
        walkable=True, bg_color=(60, 45, 30), fg_color=(160, 130, 80), char=ord(".")
    )


def cave_wall_tile() -> Tile:
    """Return a non-walkable cave rock tile.

    Returns
    -------
    Tile
        A dark brown impassable rock tile.
    """
    if "cave_wall" in TILE_REGISTRY:
        return TILE_REGISTRY["cave_wall"].make()
    return Tile(
        walkable=False, bg_color=(35, 25, 15), fg_color=(80, 60, 40), char=ord("#")
    )


def unknown_tile() -> Tile:
    """Return a pure-black placeholder for tiles the client has not yet explored.

    Returns
    -------
    Tile
        An invisible tile used to fill unexplored map areas.

    Notes
    -----
    ``walkable=True`` so that unexplored tiles are transparent to client-side
    FOV and light computations.  The client never makes movement decisions from
    walkability — that is always server-authoritative.
    """
    return Tile(walkable=True, bg_color=(0, 0, 0), fg_color=(0, 0, 0), char=ord(" "))
