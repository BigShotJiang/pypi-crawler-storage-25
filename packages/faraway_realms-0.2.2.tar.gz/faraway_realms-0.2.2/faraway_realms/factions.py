"""Faction relationship management for entity hostility."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FactionRelations:
    """Tracks mutable hostility relationships between named factions.

    Relationships are symmetric: if A is hostile to B, B is hostile to A.
    Default state: no faction is hostile to any other.

    Examples
    --------
    >>> relations = FactionRelations()
    >>> relations.set_hostile("player", "hostile", True)
    >>> relations.are_hostile("player", "hostile")
    True
    >>> relations.are_hostile("hostile", "player")
    True
    >>> relations.set_hostile("player", "hostile", False)
    >>> relations.are_hostile("player", "hostile")
    False
    """

    _pairs: set[frozenset[str]] = field(default_factory=set, repr=False)

    def set_hostile(self, a: str, b: str, hostile: bool) -> None:
        """Set the hostility relationship between two factions.

        Parameters
        ----------
        a : str
            First faction name.
        b : str
            Second faction name.
        hostile : bool
            ``True`` to mark as hostile, ``False`` to remove hostility.
        """
        pair = frozenset({a, b})
        if hostile:
            self._pairs.add(pair)
        else:
            self._pairs.discard(pair)

    def are_hostile(self, a: str, b: str) -> bool:
        """Return whether two factions are hostile to each other.

        Parameters
        ----------
        a : str
            First faction name.
        b : str
            Second faction name.

        Returns
        -------
        bool
            True if the factions are in a hostile relationship.
        """
        return frozenset({a, b}) in self._pairs


# Populated at startup by content_parsers.factions.parse_factions.
FACTION_RELATIONS: FactionRelations = FactionRelations()
