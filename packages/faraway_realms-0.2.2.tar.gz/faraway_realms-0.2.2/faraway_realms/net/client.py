"""Network client: connects to GameServer, exposes latest snapshot."""

from __future__ import annotations

import asyncio
import logging
import statistics
import threading
import time
from collections import deque
from typing import TYPE_CHECKING

from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.serialization import TickSnapshot, deserialize_snapshot

if TYPE_CHECKING:
    from faraway_realms.commands import Command

_log = logging.getLogger(__name__)

_PING_INTERVAL: float = 5.0  # seconds between pings
_LOG_INTERVAL: float = 30.0  # seconds between client metric logs
_RTT_WINDOW: int = 6  # ping samples kept (~30 s)
_INTERVAL_WINDOW: int = 30  # snapshot interval samples kept (~3 s at 10 Hz)


class _ClientMetrics:
    """Tracks snapshot delivery jitter and round-trip time; logs every 30 s."""

    def __init__(self) -> None:
        self._intervals: deque[float] = deque(maxlen=_INTERVAL_WINDOW)
        self._rtt: deque[float] = deque(maxlen=_RTT_WINDOW)
        self._deser_times: deque[float] = deque(maxlen=_INTERVAL_WINDOW)
        self._last_snap: float | None = None
        self._last_log: float = 0.0
        self._last_ping: float = 0.0

    def record_deser(self, ms: float) -> None:
        """Record time spent deserializing one tick snapshot."""
        self._deser_times.append(ms)

    def on_snapshot(self) -> None:
        """Record arrival of a tick snapshot."""
        now = time.monotonic()
        if self._last_snap is not None:
            self._intervals.append(now - self._last_snap)
        self._last_snap = now
        self._maybe_log(now)

    def on_pong(self, sent_at: float) -> None:
        """Record a pong response; *sent_at* is the timestamp from the ping."""
        self._rtt.append(time.monotonic() - sent_at)

    def ping_payload(self) -> float | None:
        """Return a timestamp to embed in a ping, or None if not yet due."""
        now = time.monotonic()
        if now - self._last_ping < _PING_INTERVAL:
            return None
        self._last_ping = now
        return now

    def _maybe_log(self, now: float) -> None:
        if now - self._last_log < _LOG_INTERVAL:
            return
        self._emit_log()
        self._last_log = now

    def _emit_log(self) -> None:
        self._log_intervals()
        self._log_rtt()
        self._log_deser()

    def _log_intervals(self) -> None:
        if len(self._intervals) < 2:  # noqa: PLR2004 — need at least 2 for stdev
            return
        avg_ms = statistics.mean(self._intervals) * 1000
        jitter_ms = statistics.stdev(self._intervals) * 1000
        _log.info("snapshot interval avg=%.1f ms  jitter=%.1f ms", avg_ms, jitter_ms)

    def _log_rtt(self) -> None:
        if not self._rtt:
            return
        avg_ms = statistics.mean(self._rtt) * 1000
        min_ms = min(self._rtt) * 1000
        max_ms = max(self._rtt) * 1000
        _log.info("RTT avg=%.1f ms  min=%.1f ms  max=%.1f ms", avg_ms, min_ms, max_ms)

    def _log_deser(self) -> None:
        if not self._deser_times:
            return
        avg_ms = statistics.mean(self._deser_times)
        max_ms = max(self._deser_times)
        _log.info("deser avg=%.2f ms  max=%.2f ms", avg_ms, max_ms)


class NetworkClient:
    """Background-thread asyncio client that connects to a GameServer.

    Parameters
    ----------
    host : str
        Server host.
    port : int
        Server port.
    uuid : str
        Unique client identity for reconnection.
    username : str
        Player username to authenticate with.
    """

    def __init__(self, host: str, port: int, uuid: str, username: str) -> None:
        self._host = host
        self._port = port
        self._uuid = uuid
        self._username = username
        self._snapshot: TickSnapshot | None = None
        self._welcome: dict | None = None
        self._lock = threading.Lock()
        self._outbox: list[str] = []
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stopped = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Spawn a daemon thread with its own asyncio event loop."""
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run_loop, daemon=True, name="NetworkClient"
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the background loop to stop."""
        self._stopped = True
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._loop.stop)

    def latest_snapshot(self) -> TickSnapshot | None:
        """Thread-safe; returns the most recent tick snapshot."""
        with self._lock:
            return self._snapshot

    def welcome_info(self) -> dict | None:
        """Return the welcome message from the server, or None."""
        with self._lock:
            return self._welcome

    def send_command(self, command: Command) -> None:
        """Thread-safe: enqueue a command to send on the next loop iteration."""
        with self._lock:
            self._outbox.append(command.raw or "")

    def _run_loop(self) -> None:
        if self._loop is None:
            return
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._connect_loop())

    async def _connect_loop(self) -> None:
        backoff = 1.0
        while not self._stopped:
            try:
                await self._run_session()
                backoff = 1.0
            except OSError, asyncio.IncompleteReadError, ConnectionRefusedError:
                _log.debug("Connection lost; retrying in %ss", backoff)
                await asyncio.sleep(min(backoff, 30.0))
                backoff = min(backoff * 2, 30.0)

    async def _run_session(self) -> None:
        reader, writer = await asyncio.open_connection(self._host, self._port)
        try:
            await send_message(
                writer,
                {
                    "type": "auth",
                    "uuid": self._uuid,
                    "username": self._username,
                },
            )
            welcome = await recv_message(reader)
            if welcome.get("type") != "welcome":
                return
            with self._lock:
                self._welcome = welcome
            metrics = _ClientMetrics()
            recv_task = asyncio.create_task(self._recv_loop(reader, metrics))
            send_task = asyncio.create_task(self._send_loop(writer, metrics))
            _, pending = await asyncio.wait(
                [recv_task, send_task],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
        finally:
            writer.close()

    async def _recv_loop(
        self, reader: asyncio.StreamReader, metrics: _ClientMetrics
    ) -> None:
        while not self._stopped:
            msg = await recv_message(reader)
            if msg.get("type") == "tick":
                t0 = time.monotonic()
                snap = deserialize_snapshot(msg)
                metrics.record_deser((time.monotonic() - t0) * 1000)
                with self._lock:
                    self._snapshot = snap
                metrics.on_snapshot()
            elif msg.get("type") == "pong":
                metrics.on_pong(msg.get("t", 0.0))

    async def _send_pending(
        self, writer: asyncio.StreamWriter, pending: list[str]
    ) -> None:
        for raw in pending:
            if raw:
                await send_message(writer, {"type": "command", "raw": raw})

    async def _send_loop(
        self, writer: asyncio.StreamWriter, metrics: _ClientMetrics
    ) -> None:
        while not self._stopped:
            with self._lock:
                pending, self._outbox = self._outbox, []
            await self._send_pending(writer, pending)
            t = metrics.ping_payload()
            if t is not None:
                await send_message(writer, {"type": "ping", "t": t})
            await asyncio.sleep(0.02)  # 50 Hz send rate
