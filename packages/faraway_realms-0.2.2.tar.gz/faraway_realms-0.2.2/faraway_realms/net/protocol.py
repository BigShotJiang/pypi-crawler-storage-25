"""Length-prefixed msgpack framing for the game network protocol."""

from __future__ import annotations

import asyncio
import struct

import msgpack

HEADER: struct.Struct = struct.Struct(">I")  # 4-byte big-endian uint32


async def send_message(writer: asyncio.StreamWriter, payload: dict) -> int:
    """Encode *payload* as length-prefixed msgpack; return payload byte count."""
    data = msgpack.packb(payload, use_bin_type=True)
    writer.write(HEADER.pack(len(data)) + data)
    await writer.drain()
    return len(data)


async def recv_message(reader: asyncio.StreamReader) -> dict:
    """Read a length-prefixed msgpack message and return the decoded dict."""
    header = await reader.readexactly(HEADER.size)
    (length,) = HEADER.unpack(header)
    data = await reader.readexactly(length)
    return msgpack.unpackb(data, raw=False)
