"""Game-state serialization: TickSnapshot, serialize_tick, deserialize_snapshot."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from faraway_realms.entity import get_combat_profile

if TYPE_CHECKING:
    from faraway_realms.game import Game
    from faraway_realms.map import Map


# ---------------------------------------------------------------------------
# Snapshot dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EntitySnapshot:
    """Serialized view of one entity for the client."""

    entity_id: int
    x: int
    y: int
    char: int
    fg_color: tuple[int, int, int]
    display_name: str
    faction: str
    target_id: int | None
    blood_color: tuple[int, int, int] | None
    is_player: bool
    stats: dict[str, Any]
    abilities: list[str]
    status_effects: list[dict[str, Any]]


@dataclass
class TickSnapshot:
    """All game state the client needs to render one frame."""

    entities: list[EntitySnapshot] = field(default_factory=list)
    blood_tiles: dict[str, dict[str, Any]] = field(default_factory=dict)
    attack_anim_events: list[list] = field(default_factory=list)
    blood_events: list[dict[str, Any]] = field(default_factory=list)
    projectiles: list[dict[str, Any]] = field(default_factory=list)
    light_sources: list[list] = field(default_factory=list)
    static_objects: list[dict[str, Any]] = field(default_factory=list)
    chat_messages: list[dict[str, Any]] = field(default_factory=list)
    removed_entity_ids: list[int] = field(default_factory=list)
    tile_reveals: list[dict[str, Any]] = field(default_factory=list)
    static_object_reveals: list[dict[str, Any]] = field(default_factory=list)
    map_tiles: list[list[dict[str, Any]]] | None = None  # only in welcome
    attack_cooldown_fraction: float = 0.0
    gcd_fraction: float | None = None
    cast_fraction: float | None = None
    ability_cooldowns: dict[str, float | None] = field(default_factory=dict)
    # Fractions for the player's current target (drives the enemy status bar)
    target_entity_id: int | None = None
    target_attack_fraction: float = 0.0
    target_cast_fraction: float | None = None
    target_gcd_fraction: float | None = None
    # Monotonically-increasing counters for screen-flash triggers
    hit_seq: int = 0
    crit_dealt_seq: int = 0


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def _ser_stat(stat: Any) -> dict[str, Any]:
    """Serialize a Stat or Pool to a plain dict."""
    from faraway_realms.stats import Pool

    d: dict[str, Any] = {
        "base": stat.base,
        "bonus": stat.bonus,
        "abbreviation": stat.abbreviation,
        "bar_filled": list(stat.bar_filled) if stat.bar_filled else None,
        "bar_empty": list(stat.bar_empty) if stat.bar_empty else None,
    }
    if isinstance(stat, Pool):
        d["current"] = stat.current
        d["is_pool"] = True
    else:
        d["is_pool"] = False
    return d


def _ser_status(s: Any) -> dict[str, Any]:
    return {
        "name": s.name,
        "expires_at": s.expires_at,
        "immobilize": s.immobilize,
        "stun": s.stun,
        "haste": s.haste,
    }


def _ser_entity(game: Game, entity: Any, is_player: bool) -> EntitySnapshot:
    try:
        x, y = game.game_map.get_entity_position(entity.entity_id)
    except KeyError:
        x, y = -1, -1
    stats = {k: _ser_stat(v) for k, v in entity.stats.items()}
    statuses = [_ser_status(s) for s in entity.status_effects]
    return EntitySnapshot(
        entity_id=entity.entity_id,
        x=x,
        y=y,
        char=entity.char,
        fg_color=entity.fg_color,
        display_name=entity.display_name,
        faction=entity.faction,
        target_id=entity.target_id,
        blood_color=get_combat_profile(entity).blood_color,
        is_player=is_player,
        stats=stats,
        abilities=list(entity.abilities.keys()),
        status_effects=statuses,
    )


def _ser_projectile(p: Any) -> dict[str, Any]:
    return {
        "x": p.x,
        "y": p.y,
        "color": list(p.color),
        "trail": [list(pos) for pos in p.trail],
        "trail_char": p.trail_char,
    }


def _collect_static_reveals(
    game: Game,
    new_tiles: set[tuple[int, int]] | frozenset[tuple[int, int]],
) -> list[dict[str, Any]]:
    """Return static objects whose position falls within newly-explored tiles."""
    return [
        {"x": o.x, "y": o.y, "char": o.char, "fg_color": list(o.fg_color)}
        for o in game.static_objects
        if (o.x, o.y) in new_tiles
    ]


def serialize_tile_sparse(
    game_map: Map,
    tiles: set[tuple[int, int]] | frozenset[tuple[int, int]],
) -> list[dict[str, Any]]:
    """Serialize a sparse set of tiles as a list of positioned tile dicts.

    Parameters
    ----------
    game_map : Map
        Source of tile data.
    tiles : set or frozenset of (x, y) pairs
        Which tiles to include; order is not guaranteed.
    """
    result = []
    for x, y in tiles:
        tile = game_map.get_tile(x, y)
        result.append(
            {
                "x": x,
                "y": y,
                "walkable": tile.walkable,
                "char": tile.char,
                "fg": list(tile.fg_color),
                "bg": list(tile.bg_color),
            }
        )
    return result


def collect_entities(game: Game) -> list[EntitySnapshot]:
    """Serialize all entities once per tick.

    Filter per client via ``serialize_per_client``.
    """
    entities: list[EntitySnapshot] = []
    for player in game.all_player_entities():
        entities.append(_ser_entity(game, player, is_player=True))
    for npc in game.all_npcs():
        entities.append(_ser_entity(game, npc, is_player=False))
    return entities


def _collect_ability_cds(game: Game, player_entity_id: int) -> dict[str, float | None]:
    entity = game.entity(player_entity_id)
    if entity is None:
        return {}
    return {
        name: game.ability_cooldown_fraction(player_entity_id, name)
        for name in entity.abilities
    }


def _collect_target_fractions(game: Game, player_entity_id: int) -> dict[str, Any]:
    """Return cooldown fractions for the player's current target entity."""
    player = game.entity(player_entity_id)
    target_id = player.target_id if player is not None else None
    if target_id is None:
        return {
            "target_entity_id": None,
            "target_attack_fraction": 0.0,
            "target_cast_fraction": None,
            "target_gcd_fraction": None,
        }
    return {
        "target_entity_id": target_id,
        "target_attack_fraction": game.attack_cooldown_fraction(target_id),
        "target_cast_fraction": game.cast_fraction(target_id),
        "target_gcd_fraction": game.gcd_fraction(target_id),
    }


def serialize_shared(game: Game) -> dict[str, Any]:
    """Build the tick payload fields that are identical for every connected client.

    Drains the attack-anim and blood-event queues exactly once so that all
    clients receive the same events regardless of how many are connected.
    Call this once per tick before the per-client broadcast loop.

    ``entities`` is intentionally absent — it is per-client (FOV-filtered) and
    added by ``serialize_per_client``.
    """
    blood_tiles = {
        f"{x},{y}": {"color": list(tile.color), "alpha": tile.alpha}
        for (x, y), tile in game.blood_map.drain_dirty().items()
    }

    attack_anims = [
        [list(from_pos), list(to_pos), list(color)]
        for from_pos, to_pos, color in game.drain_attack_anim_events()
    ]

    blood_evts = [
        {
            "target_pos": list(e.target_pos),
            "attacker_pos": list(e.attacker_pos),
            "landing_positions": [list(p) for p in e.landing_positions],
            "color": list(e.color),
        }
        for e in game.drain_blood_events()
    ]

    return {
        "type": "tick",
        "blood_tiles": blood_tiles,
        "attack_anim_events": attack_anims,
        "blood_events": blood_evts,
        "projectiles": [_ser_projectile(p) for p in game.active_projectiles],
        "light_sources": [
            [x, y, ls.radius, ls.intensity, list(ls.color)]
            for x, y, ls in game.light_sources()
        ],
        "chat_messages": [
            {"text": m.text, "color": list(m.color)}
            for m in game.get_chat_history(last_n=20)
        ],
    }


def serialize_per_client(
    game: Game,
    player_entity_id: int,
    all_snaps: list[EntitySnapshot],
    visible_tiles: frozenset[tuple[int, int]],
    removed_ids: frozenset[int],
    new_tiles: set[tuple[int, int]] | frozenset[tuple[int, int]],
) -> dict[str, Any]:
    """Build the per-client tick payload: FOV-filtered entities + cooldown fractions.

    Parameters
    ----------
    all_snaps : list[EntitySnapshot]
        All entities serialized once this tick (from ``collect_entities``).
    visible_tiles : frozenset[tuple[int, int]]
        (x, y) tiles currently visible to this client.  Entities whose
        position falls outside this set are excluded.  The player's own
        entity is always included regardless of position.
    removed_ids : frozenset[int]
        Entity IDs that were visible last tick but are not this tick.
        Sent so the client can evict them from its cache.
    """
    visible_snaps = [
        s
        for s in all_snaps
        if (s.x, s.y) in visible_tiles or s.entity_id == player_entity_id
    ]
    return {
        "entities": [_entity_snap_to_dict(s) for s in visible_snaps],
        "removed_entity_ids": list(removed_ids),
        "tile_reveals": serialize_tile_sparse(game.game_map, new_tiles),
        "static_object_reveals": _collect_static_reveals(game, new_tiles),
        "attack_cooldown_fraction": game.attack_cooldown_fraction(player_entity_id),
        "gcd_fraction": game.gcd_fraction(player_entity_id),
        "cast_fraction": game.cast_fraction(player_entity_id),
        "ability_cooldowns": _collect_ability_cds(game, player_entity_id),
        "hit_seq": game.get_hit_seq(player_entity_id),
        "crit_dealt_seq": game.get_crit_dealt_seq(player_entity_id),
        **_collect_target_fractions(game, player_entity_id),
    }


def _entity_snap_to_dict(e: EntitySnapshot) -> dict[str, Any]:
    return {
        "entity_id": e.entity_id,
        "x": e.x,
        "y": e.y,
        "char": e.char,
        "fg_color": list(e.fg_color),
        "display_name": e.display_name,
        "faction": e.faction,
        "target_id": e.target_id,
        "blood_color": list(e.blood_color) if e.blood_color else None,
        "is_player": e.is_player,
        "stats": e.stats,
        "abilities": e.abilities,
        "status_effects": e.status_effects,
    }


def deserialize_snapshot(data: dict[str, Any]) -> TickSnapshot:
    """Convert a raw tick dict (from JSON) into a TickSnapshot."""
    entities = [_dict_to_entity_snap(e) for e in data.get("entities", [])]
    return TickSnapshot(
        entities=entities,
        blood_tiles=data.get("blood_tiles", {}),
        attack_anim_events=data.get("attack_anim_events", []),
        blood_events=data.get("blood_events", []),
        projectiles=data.get("projectiles", []),
        light_sources=data.get("light_sources", []),
        static_objects=data.get("static_objects", []),
        chat_messages=data.get("chat_messages", []),
        removed_entity_ids=data.get("removed_entity_ids", []),
        tile_reveals=data.get("tile_reveals", []),
        static_object_reveals=data.get("static_object_reveals", []),
        map_tiles=data.get("map_tiles"),
        attack_cooldown_fraction=data.get("attack_cooldown_fraction", 0.0),
        gcd_fraction=data.get("gcd_fraction"),
        cast_fraction=data.get("cast_fraction"),
        ability_cooldowns=data.get("ability_cooldowns", {}),
        target_entity_id=data.get("target_entity_id"),
        target_attack_fraction=data.get("target_attack_fraction", 0.0),
        target_cast_fraction=data.get("target_cast_fraction"),
        target_gcd_fraction=data.get("target_gcd_fraction"),
        hit_seq=data.get("hit_seq", 0),
        crit_dealt_seq=data.get("crit_dealt_seq", 0),
    )


def _dict_to_entity_snap(d: dict[str, Any]) -> EntitySnapshot:
    fg = tuple(d["fg_color"])
    bc = tuple(d["blood_color"]) if d.get("blood_color") else None
    return EntitySnapshot(
        entity_id=d["entity_id"],
        x=d["x"],
        y=d["y"],
        char=d["char"],
        fg_color=fg,  # type: ignore[arg-type]
        display_name=d["display_name"],
        faction=d["faction"],
        target_id=d.get("target_id"),
        blood_color=bc,  # type: ignore[arg-type]
        is_player=d.get("is_player", False),
        stats=d.get("stats", {}),
        abilities=d.get("abilities", []),
        status_effects=d.get("status_effects", []),
    )


def serialize_map(game: Game) -> list[list[dict[str, Any]]]:
    """Serialize the full map tile grid (sent once in welcome message)."""
    gmap = game.game_map
    rows = []
    for y in range(gmap.height):
        row = []
        for x in range(gmap.width):
            tile = gmap.get_tile(x, y)
            row.append(
                {
                    "walkable": tile.walkable,
                    "char": tile.char,
                    "fg": list(tile.fg_color),
                    "bg": list(tile.bg_color),
                }
            )
        rows.append(row)
    return rows
