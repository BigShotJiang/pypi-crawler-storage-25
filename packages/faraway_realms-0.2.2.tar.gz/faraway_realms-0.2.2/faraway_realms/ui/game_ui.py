"""GameUI — thin coordinator that owns MapView, ChatView, StatusBar, and overlays."""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING

import tcod.console
import tcod.context
import tcod.event
import tcod.tileset

from faraway_realms import fov as _fov
from faraway_realms.commands import Command, CommandParser
from faraway_realms.light import LightMap
from faraway_realms.ui.ability_bar import AbilityBar
from faraway_realms.ui.chat_view import ChatView
from faraway_realms.ui.effects import (
    BloodParticle,
    MeleeAttackAnimation,
    ScreenFlash,
    _swing_char,
    _swing_tiles,
)
from faraway_realms.ui.layout import (
    _FRAME_DURATION,
    _INPUT_BG,
    BINDINGS,
    CHAT_HEIGHT,
    CHAT_WIDTH,
    CHAT_X,
    CHAT_Y,
    CONSOLE_HEIGHT,
    CONSOLE_WIDTH,
    DETAILS_WIDTH,
    DETAILS_X,
    DETAILS_Y,
    INPUT_Y,
    MAP_WIDTH,
    MAP_X,
    TILESET_CHARMAP,
    TILESET_ROWS,
)
from faraway_realms.ui.map_view import MapView
from faraway_realms.ui.overlays import HelpOverlay, Overlay
from faraway_realms.ui.status_bar import NameBar, StatusBar

if TYPE_CHECKING:
    import numpy as np

    from faraway_realms.blood import BloodEvent
    from faraway_realms.entity import GameEntity, Player
    from faraway_realms.game_protocol import GameProtocol
    from faraway_realms.panels import Panel


class GameUI:
    """Manages the TCOD window and three-pane layout.

    Parameters
    ----------
    game : Game
        The game state to render.
    tileset_path : str | Path
        Path to the unified 12×12 tilesheet PNG (CP437 + Urizen sprites).
    viewing_player : Player
        The player this UI instance belongs to.
    panels : list[Panel] | None
        Optional list of detail-pane panels to display.
    """

    def __init__(
        self,
        game: GameProtocol,
        tileset_path: str | Path,
        viewing_player: Player,
        panels: list[Panel] | None = None,
    ) -> None:
        self._game = game
        self._tileset_path = Path(tileset_path)
        self._viewing_player = viewing_player
        self._parser = CommandParser()
        self._panels: list[Panel] = list(panels) if panels else []
        self._panel_idx: int = 0
        self._overlay: Overlay | None = None
        self._map_view = MapView(game=game, viewing_player=viewing_player)
        self._chat = ChatView(game=game)
        self._status_bar = StatusBar(game=game, viewing_player=viewing_player)
        self._name_bar = NameBar(game=game, viewing_player=viewing_player)
        self._ability_bar = AbilityBar(game=game, viewing_player=viewing_player)
        self._light_map = LightMap(game.game_map.width, game.game_map.height)
        self._damage_flash = ScreenFlash()
        self._last_hit_seq: int = game.get_hit_seq(viewing_player.entity.entity_id)
        self._crit_flash = ScreenFlash(color=(255, 210, 0), peak_alpha=200)
        self._last_crit_seq: int = game.get_crit_dealt_seq(
            viewing_player.entity.entity_id
        )
        self._attack_anims: list[MeleeAttackAnimation] = []
        self._blood_particles: list[BloodParticle] = []
        self._ctx: tcod.context.Context  # set in run()

    def _maybe_tick(self) -> None:
        """Call tick() on the game if it supports server-side ticking."""
        if hasattr(self._game, "tick"):
            self._game.tick()  # type: ignore[union-attr]

    def run(self) -> None:
        """Open the window and enter the render/event loop."""
        tileset = tcod.tileset.load_tilesheet(
            self._tileset_path, 16, TILESET_ROWS, TILESET_CHARMAP
        )
        console = tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")
        with tcod.context.new(
            console=console,
            tileset=tileset,
            title="Faraway Realms",
            vsync=False,
        ) as ctx:
            self._ctx = ctx
            last_tick = time.monotonic()
            tick_interval = 1.0 / self._game.tick_rate

            while True:
                now = time.monotonic()
                if now - last_tick >= tick_interval:
                    self._maybe_tick()
                    last_tick = now

                if not self._handle_events(ctx):
                    break

                self._render_frame(console)
                ctx.present(console)

                elapsed = time.monotonic() - now
                time.sleep(max(0.0, _FRAME_DURATION - elapsed))

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _sync_viewing_player(self) -> None:
        """Copy mutable snapshot fields back to the stub entity each frame."""
        pid = self._viewing_player.entity.entity_id
        snap_e = self._game.entity(pid)
        if snap_e is not None:
            self._viewing_player.entity.target_id = snap_e.target_id

    def _render_frame(self, console: tcod.console.Console) -> None:
        self._sync_viewing_player()
        console.clear()
        self._render_borders(console)  # first — draw_frame clears interior cells
        cam = self._map_view.camera_origin()
        visible = self._map_view.compute_fov()
        self._light_map.compute(
            self._game.light_sources(),
            _fov.build_transparency(self._game.game_map),
        )
        self._map_view.render(console, cam, visible, self._light_map)
        self._tick_attack_anims(console, cam)
        self._tick_blood_particles(console, cam)
        self._tick_damage_flash(console)
        self._tick_crit_flash(console)
        self._render_details(console)
        self._chat.render(console)
        self._status_bar.render(console)
        self._name_bar.render(console)
        self._ability_bar.render(console)
        if self._overlay is not None:
            self._overlay.render(console)

    def _tick_blood_particles(
        self, console: tcod.console.Console, cam: tuple[int, int]
    ) -> None:
        for evt in self._game.drain_blood_events():
            self._create_blood_particles(evt)
        self._blood_particles = [p for p in self._blood_particles if p.active]
        for particle in self._blood_particles:
            particle.render(console, cam)

    def _create_blood_particles(self, evt: BloodEvent) -> None:
        for landing in evt.landing_positions:
            path = _swing_tiles(
                evt.target_pos[0], evt.target_pos[1], landing[0], landing[1]
            )
            self._blood_particles.append(BloodParticle(path=path, color=evt.color))

    def _tick_damage_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        hit_seq = self._game.get_hit_seq(eid)
        if hit_seq != self._last_hit_seq:
            self._last_hit_seq = hit_seq
            self._damage_flash.trigger()
        if self._damage_flash.active:
            self._damage_flash.render(console)

    def _tick_crit_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        crit_seq = self._game.get_crit_dealt_seq(eid)
        if crit_seq != self._last_crit_seq:
            self._last_crit_seq = crit_seq
            self._crit_flash.trigger()
        if self._crit_flash.active:
            self._crit_flash.render(console)

    def _tick_attack_anims(
        self, console: tcod.console.Console, cam: tuple[int, int]
    ) -> None:
        for evt in self._game.drain_attack_anim_events():
            x0, y0 = evt[0]
            x1, y1 = evt[1]
            char = _swing_char(x1 - x0, y1 - y0)
            tiles = _swing_tiles(x0, y0, x1, y1)
            self._attack_anims.append(
                MeleeAttackAnimation(tiles=tiles, char=char, color=evt[2])
            )
        self._attack_anims = [a for a in self._attack_anims if a.active]
        for anim in self._attack_anims:
            anim.render(console, cam)

    def _render_borders(self, console: tcod.console.Console) -> None:
        # Vertical divider between map/chat and details
        console.draw_frame(DETAILS_X - 1, DETAILS_Y, DETAILS_WIDTH + 1, CONSOLE_HEIGHT)
        # Horizontal divider between map and chat
        console.draw_frame(MAP_X, CHAT_Y - 1, MAP_WIDTH, CONSOLE_HEIGHT - CHAT_Y + 1)

    def _render_details(self, console: tcod.console.Console) -> None:
        if not self._panels:
            return
        x = DETAILS_X + 1
        width = DETAILS_WIDTH - 2
        panel = self._panels[self._panel_idx]
        self._render_panel_header(console, x, 1, width, panel.title)
        panel.render(console, x, 3, width)
        if len(self._panels) > 1:
            hint = "(]) next panel"
            console.print(x, CONSOLE_HEIGHT - 2, hint[:width], fg=(100, 100, 100))

    def _render_panel_header(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        title: str,
    ) -> None:
        w = width - 1
        label = f"\u2500 {title} "
        padding = "\u2500" * max(0, w - len(label))
        console.print(x, y, (label + padding)[:w], fg=(140, 140, 80))

    # ------------------------------------------------------------------
    # Compatibility shims — delegate to sub-components
    # Used by tests that access private attributes directly.
    # ------------------------------------------------------------------

    def _render_map(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_map(console, cam, visible)  # noqa: SLF001

    def _render_entities(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_entities(console, cam, visible)  # noqa: SLF001

    def _render_map_cell(
        self,
        console: tcod.console.Console,
        screen_x: int,
        screen_y: int,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_map_cell(  # noqa: SLF001
            console, screen_x, screen_y, cam, visible
        )

    def _render_entity(
        self,
        console: tcod.console.Console,
        entity: GameEntity,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_entity(console, entity, cam, visible)  # noqa: SLF001

    def _camera_origin(self) -> tuple[int, int]:
        return self._map_view.camera_origin()

    def _render_chat(self, console: tcod.console.Console) -> None:
        history = self._game.get_chat_history(last_n=CHAT_HEIGHT)
        for i, message in enumerate(history):
            console.print(
                CHAT_X + 1, CHAT_Y + i, message.text[: CHAT_WIDTH - 2], fg=message.color
            )

    def _render_input_line(self, console: tcod.console.Console) -> None:
        console.rgb[INPUT_Y, CHAT_X + 1 : CHAT_X + CHAT_WIDTH - 1]["bg"] = _INPUT_BG
        prompt = "> " + self._chat._buffer  # noqa: SLF001
        if self._chat._focused:  # noqa: SLF001
            prompt += "_"
        console.print(CHAT_X + 1, INPUT_Y, prompt[: CHAT_WIDTH - 2], fg=(255, 255, 255))

    def _render_status_bar(self, console: tcod.console.Console) -> None:
        self._status_bar.render(console)

    @property
    def _input_buffer(self) -> str:  # noqa: D401
        return self._chat._buffer  # noqa: SLF001

    @_input_buffer.setter
    def _input_buffer(self, value: str) -> None:
        self._chat._buffer = value  # noqa: SLF001

    @property
    def _chat_focused(self) -> bool:
        return self._chat._focused  # noqa: SLF001

    @_chat_focused.setter
    def _chat_focused(self, value: bool) -> None:
        self._chat._focused = value  # noqa: SLF001

    @property
    def _command_history(self) -> list[str]:
        return self._chat._history  # noqa: SLF001

    @_command_history.setter
    def _command_history(self, value: list[str]) -> None:
        self._chat._history = value  # noqa: SLF001

    @property
    def _history_idx(self) -> int:
        return self._chat._history_idx  # noqa: SLF001

    @_history_idx.setter
    def _history_idx(self, value: int) -> None:
        self._chat._history_idx = value  # noqa: SLF001

    @property
    def _history_buffer(self) -> str:
        return self._chat._history_buffer  # noqa: SLF001

    @_history_buffer.setter
    def _history_buffer(self, value: str) -> None:
        self._chat._history_buffer = value  # noqa: SLF001

    def _submit_input(self) -> None:
        text = self._chat._buffer.strip()  # noqa: SLF001
        self._game.add_chat_message(text)
        if text.startswith("/"):
            parts = text.lstrip("/").split()
            verb = parts[0].lower() if parts else ""
            if verb != "help":
                self._game.enqueue_command(self._resolve_me(self._parser.parse(text)))
            self._chat.record_history(text)
        self._chat._buffer = ""  # noqa: SLF001
        self._chat._history_idx = -1  # noqa: SLF001
        self._chat._history_buffer = ""  # noqa: SLF001

    def _handle_text_input(self, event: tcod.event.TextInput) -> None:
        self._chat.handle_text_input(event)

    def _history_older(self) -> None:
        self._chat._history_older()  # noqa: SLF001

    def _history_newer(self) -> None:
        self._chat._history_newer()  # noqa: SLF001

    def _handle_history_key(self, event: tcod.event.KeyDown) -> bool:
        return self._chat.handle_history_key(event)

    def _focus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.focus(ctx)

    def _unfocus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.unfocus(ctx)

    def _handle_backspace(self) -> None:
        if self._chat.focused:
            self._chat._buffer = self._chat._buffer[:-1]  # noqa: SLF001

    def _cycle_panel(self) -> None:
        if self._panels and not self._chat.focused:
            self._panel_idx = (self._panel_idx + 1) % len(self._panels)

    def _handle_escape(self, ctx: tcod.context.Context) -> bool:
        """Unfocus chat if focused; return True if something was closed, else False."""
        if self._chat.focused:
            self._chat.unfocus(ctx)
            return True
        return False

    def _handle_bound_key(self, event: tcod.event.KeyDown) -> None:
        if self._chat.focused:
            return
        if self._handle_special_key(event):
            return
        raw = BINDINGS.get(event.sym)
        if raw is None:
            return
        self._game.enqueue_command(self._resolve_me(self._parser.parse(raw)))

    def _handle_special_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle ``?`` and ``/`` quick-focus keys; return True if consumed."""
        if self._is_help_key(event):
            self._overlay = HelpOverlay()
            return True
        if event.sym == tcod.event.KeySym.SLASH:
            self._chat.focus(self._ctx)
            self._chat._buffer = "/"  # noqa: SLF001
            return True
        return False

    @staticmethod
    def _is_help_key(event: tcod.event.KeyDown) -> bool:
        """Return True for ``?`` (SDL may report it as QUESTION or SLASH+Shift)."""
        if event.sym == tcod.event.KeySym.QUESTION:
            return True
        return event.sym == tcod.event.KeySym.SLASH and bool(
            event.mod & tcod.event.Modifier.SHIFT
        )

    def _on_return(self, ctx: tcod.context.Context) -> None:
        if not self._chat.focused:
            self._chat.focus(ctx)
        elif self._chat.buffer.strip():
            self._submit_chat(ctx)
        else:
            self._chat.unfocus(ctx)

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _handle_events(self, ctx: tcod.context.Context) -> bool:
        for event in tcod.event.get():
            if not self._dispatch_event(event, ctx):
                return False
        return True

    def _dispatch_event(
        self, event: tcod.event.Event, ctx: tcod.context.Context
    ) -> bool:
        if isinstance(event, tcod.event.Quit):
            return False
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_keydown(event, ctx)
        if isinstance(event, tcod.event.TextInput):
            self._chat.handle_text_input(event)
        return True

    def _handle_keydown(
        self, event: tcod.event.KeyDown, ctx: tcod.context.Context
    ) -> bool:
        if self._overlay is not None:
            return self._route_to_overlay(event)
        if event.sym == tcod.event.KeySym.ESCAPE:
            self._handle_escape(ctx)
            return True  # ESC never exits the game
        if event.sym == tcod.event.KeySym.RETURN:
            self._on_return(ctx)
        else:
            self._handle_other_key(event)
        return True

    def _route_to_overlay(self, event: tcod.event.KeyDown) -> bool:
        if not self._overlay.handle_key(event):  # type: ignore[union-attr]
            self._overlay = None
        return True

    def _handle_other_key(self, event: tcod.event.KeyDown) -> None:
        if event.sym == tcod.event.KeySym.BACKSPACE:
            self._handle_backspace()
        elif event.sym == tcod.event.KeySym(ord("]")) and not (
            event.mod & tcod.event.Modifier.SHIFT
        ):
            self._cycle_panel()
        else:
            self._handle_navigation_key(event)

    def _handle_navigation_key(self, event: tcod.event.KeyDown) -> None:
        if not self._chat.handle_history_key(event):
            if not self._chat.handle_scroll_key(event):
                self._handle_bound_key(event)

    def _submit_chat(self, ctx: tcod.context.Context) -> None:
        text = self._chat.submit()
        if text is None:
            self._chat.unfocus(ctx)
            return
        self._game.add_chat_message(text)
        if text.startswith("/"):
            self._chat.record_history(text)
            parts = text.lstrip("/").split()
            verb = parts[0].lower() if parts else ""
            if verb == "help":
                topic = parts[1].lower() if len(parts) > 1 else None
                self._overlay = HelpOverlay(topic=topic)
            else:
                self._game.enqueue_command(self._resolve_me(self._parser.parse(text)))
        self._chat.unfocus(ctx)

    def _resolve_me(self, command: Command) -> Command:
        """Replace the ``"me"`` actor token with the viewing player's entity ID."""
        if command.actor != "me":
            return command
        eid = str(self._viewing_player.entity.entity_id)
        return Command(command.command_type, eid, command.args, command.raw)
