"""Layout constants, colour helpers, and key bindings for the game UI."""

from __future__ import annotations

import tcod.event
import tcod.tileset

# Console dimensions in tiles
CONSOLE_WIDTH = 80
CONSOLE_HEIGHT = 50

# Map pane: top-left
MAP_X = 0
MAP_Y = 0
MAP_WIDTH = 59  # 5×12-1=59: exactly 12 four-char ability slots + pipe separators
MAP_HEIGHT = 39  # one row shorter to make room for the status bar

# Details pane: right strip
DETAILS_X = 60  # MAP_WIDTH + 1 (border col)
DETAILS_Y = 0
DETAILS_WIDTH = CONSOLE_WIDTH - DETAILS_X
DETAILS_HEIGHT = CONSOLE_HEIGHT

# Status bar: single row between map and chat frame
STATUS_Y = 39

# Name bar: player and target names, one row below the status bar
NAME_Y = 40

# Ability bar: player abilities, one row below the name bar
ABILITY_Y = 41

# Chat pane: bottom-left
CHAT_X = 0
CHAT_Y = 43  # frame top border at CHAT_Y-1=42; rows 41 and below are HUD rows
CHAT_WIDTH = 59
INPUT_Y = CONSOLE_HEIGHT - 2  # one row above bottom border, inside the frame
CHAT_HEIGHT = INPUT_Y - CHAT_Y  # rows available for message history

# Status bar layout
_STATUS_HALF: int = CHAT_WIDTH // 2  # separator column (28)
_STATUS_PIP_W: int = 3  # pip cells per side
_STATUS_BAR_W: int = 20  # bar width, flush against the centre separator

# CP437 character 179 — uninterrupted vertical line, used as HUD row separator
_SEP_CHAR: int = tcod.tileset.CHARMAP_CP437[179]

# Unified tileset: CP437 occupies the first 256 codepoints (rows 0–15 of the
# sheet); Urizen sprites follow in the Unicode Private Use Area starting at
# U+E000.  Access a sprite: console.tiles["ch"][y, x] = URIZEN_BASE + index
URIZEN_BASE: int = 0xE000
N_URIZEN: int = 10_300
# Full charmap for load_tilesheet: CP437 first, then PUA for Urizen sprites
TILESET_CHARMAP: list[int] = list(tcod.tileset.CHARMAP_CP437) + list(
    range(URIZEN_BASE, URIZEN_BASE + N_URIZEN)
)
# Sheet has 16 CP437 rows + ceil(N_URIZEN / 16) Urizen rows
TILESET_ROWS: int = 16 + (N_URIZEN + 15) // 16

_PIP_UNKNOWN_COLOR: tuple[int, int, int] = (80, 80, 80)  # fallback for unknown statuses
_PIP_EMPTY_BG: tuple[int, int, int] = (15, 15, 15)
_PIP_TEXT_COLOR: tuple[int, int, int] = (230, 230, 230)

_INPUT_BG: tuple[int, int, int] = (40, 40, 40)
_TARGET_BLINK_COLOR: tuple[int, int, int] = (255, 220, 0)
_DIM_FACTOR: float = 0.35
# Explored-but-not-visible tiles: darker and slightly cool so they read as
# "memory" rather than live view.  Distinct from AMBIENT (0.35) on all channels.
_MEMORY_TINT: tuple[float, float, float] = (0.15, 0.15, 0.22)
_PLAYER_BAR_FILLED: tuple[int, int, int] = (0, 160, 220)
_PLAYER_BAR_EMPTY: tuple[int, int, int] = (0, 35, 55)
_ENEMY_BAR_DIM: float = 0.25
_STATUS_TEXT_COLOR: tuple[int, int, int] = (200, 200, 200)
_STATUS_SEP_COLOR: tuple[int, int, int] = (150, 150, 150)
_CAST_BAR_FILLED: tuple[int, int, int] = (220, 140, 0)
_CAST_BAR_EMPTY: tuple[int, int, int] = (55, 35, 0)
_GCD_BAR_FILLED: tuple[int, int, int] = (130, 130, 130)
_GCD_BAR_EMPTY: tuple[int, int, int] = (30, 30, 30)
_HASTE_BAR_FILLED: tuple[int, int, int] = (180, 220, 0)
_HASTE_BAR_EMPTY: tuple[int, int, int] = (45, 55, 0)
_STUN_BAR_FILLED: tuple[int, int, int] = (200, 180, 0)
_STUN_BAR_EMPTY: tuple[int, int, int] = (50, 45, 0)

TARGET_FPS = 30
_FRAME_DURATION = 1.0 / TARGET_FPS


def _dim(
    color: tuple[int, int, int],
    factor: float | tuple[float, float, float],
) -> tuple[int, int, int]:
    """Return *color* scaled by *factor* (component-wise integer multiply).

    Parameters
    ----------
    color : tuple[int, int, int]
        RGB input colour.
    factor : float | tuple[float, float, float]
        Scalar scale applied equally to all channels, or an RGB tuple for
        per-channel scaling (e.g. a coloured light factor from LightMap).

    Returns
    -------
    tuple[int, int, int]
        Dimmed RGB colour.
    """
    r, g, b = color
    if isinstance(factor, tuple):
        fr, fg, fb = factor
        return (int(r * fr), int(g * fg), int(b * fb))
    return (int(r * factor), int(g * factor), int(b * factor))


# Key bindings active when the chat input is not focused.
# Values are raw command strings passed through CommandParser.
BINDINGS: dict[tcod.event.KeySym, str] = {
    tcod.event.KeySym(ord("h")): "/move me left",
    tcod.event.KeySym(ord("j")): "/move me down",
    tcod.event.KeySym(ord("k")): "/move me up",
    tcod.event.KeySym(ord("l")): "/move me right",
    tcod.event.KeySym.LEFT: "/move me left",
    tcod.event.KeySym.DOWN: "/move me down",
    tcod.event.KeySym.UP: "/move me up",
    tcod.event.KeySym.RIGHT: "/move me right",
    tcod.event.KeySym(ord("e")): "/cast me kick @target",
    tcod.event.KeySym(ord("f")): "/attack me @target",
    tcod.event.KeySym(ord("t")): "/target me next",
    tcod.event.KeySym.TAB: "/target me next",
    tcod.event.KeySym(ord("q")): "/cast me backstep @target",
    tcod.event.KeySym(ord("r")): "/cast me haste me",
    tcod.event.KeySym(ord("g")): "/cast me parry @target",
    tcod.event.KeySym(ord("c")): "/cast me second_wind me",
    tcod.event.KeySym(ord("x")): "/cast me firebolt @target",
    tcod.event.KeySym(ord("z")): "/cast me frostbolt @target",
}
