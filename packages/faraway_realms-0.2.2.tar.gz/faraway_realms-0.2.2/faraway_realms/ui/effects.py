"""Screen-space post-processing effects (screen flash vignette, etc.)."""

from __future__ import annotations

from dataclasses import dataclass, field

import tcod.console
import tcod.tileset
from tcod.libtcodpy import BKGND_ALPH

from faraway_realms.ui.layout import MAP_HEIGHT, MAP_WIDTH, MAP_X, MAP_Y

Color = tuple[int, int, int]

# Tileset position 179 (box-drawing light vertical │) — used as vertical swing
# glyph. Stored as the Unicode codepoint tcod expects, not the raw CP437 index.
_VERT_CHAR: int = tcod.tileset.CHARMAP_CP437[179]

# CP437 42 = * — blood particle in flight
_BLOOD_FLY_CHAR: int = tcod.tileset.CHARMAP_CP437[42]
# CP437 15 = ☼ — blood impact flash
_BLOOD_LAND_CHAR: int = tcod.tileset.CHARMAP_CP437[15]


def _swing_char(dx: int, dy: int) -> int:
    r"""Return the CP437 character code for a melee swing in this direction.

    Parameters
    ----------
    dx : int
        Horizontal offset from attacker to defender (negative = left).
    dy : int
        Vertical offset from attacker to defender (negative = up).

    Returns
    -------
    int
        Character code: ``-`` horizontal, ``_VERT_CHAR`` vertical,
        ``\`` same-sign diagonal, ``/`` opposite-sign diagonal.
    """
    if dy == 0:
        return ord("-")
    if dx == 0:
        return _VERT_CHAR
    return ord("\\") if (dx > 0) == (dy > 0) else ord("/")


def _swing_tiles(x0: int, y0: int, x1: int, y1: int) -> list[tuple[int, int]]:
    """Return map-space tiles from ``(x0, y0)`` to ``(x1, y1)`` inclusive.

    Parameters
    ----------
    x0, y0 : int
        Start position (attacker).
    x1, y1 : int
        End position (defender).

    Returns
    -------
    list[tuple[int, int]]
        Ordered tile positions along the line (both endpoints included).
    """
    dx, dy = x1 - x0, y1 - y0
    steps = max(abs(dx), abs(dy))
    if steps == 0:
        return [(x0, y0)]
    return [
        (round(x0 + i / steps * dx), round(y0 + i / steps * dy))
        for i in range(steps + 1)
    ]


@dataclass
class MeleeAttackAnimation:
    """Travelling foreground glyph from attacker tile to defender tile.

    Parameters
    ----------
    tiles : list[tuple[int, int]]
        Map-space positions the glyph travels through (attacker → defender).
    char : int
        CP437 character code of the swing glyph.
    color : Color
        RGB foreground color of the glyph.
    frames_per_tile : int
        Render frames to show the glyph at each tile (default 2, ~67 ms at 30 FPS).
    """

    tiles: list[tuple[int, int]]
    char: int
    color: Color
    frames_per_tile: int = 2
    _frame: int = field(default=0, init=False, repr=False)

    @property
    def active(self) -> bool:
        """True while the animation is still playing."""
        return self._frame < len(self.tiles) * self.frames_per_tile

    def current_tile(self) -> tuple[int, int] | None:
        """Return the map tile currently being drawn, or ``None`` when finished."""
        if not self.active:
            return None
        return self.tiles[self._frame // self.frames_per_tile]

    def advance(self) -> None:
        """Increment the internal frame counter by one."""
        self._frame += 1

    def render(self, console: tcod.console.Console, cam: tuple[int, int]) -> None:
        """Draw the current animation frame and advance the counter.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        cam : tuple[int, int]
            Camera origin ``(cam_x, cam_y)``.
        """
        tile = self.current_tile()
        if tile is not None:
            self._draw(console, tile, cam)
        self.advance()

    def _draw(
        self,
        console: tcod.console.Console,
        tile: tuple[int, int],
        cam: tuple[int, int],
    ) -> None:
        screen_x, screen_y = tile[0] - cam[0], tile[1] - cam[1]
        if 0 <= screen_x < MAP_WIDTH and 0 <= screen_y < MAP_HEIGHT:
            console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["ch"] = self.char
            console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["fg"] = self.color


@dataclass
class BloodParticle:
    """Animated blood drop travelling from a struck entity to a landing tile.

    Parameters
    ----------
    path : list[tuple[int, int]]
        Map-space tiles from the hit position to the landing spot (inclusive).
    color : Color
        Blood color for this particle.
    """

    path: list[tuple[int, int]]
    color: Color
    _frame: int = field(default=0, init=False, repr=False)

    @property
    def active(self) -> bool:
        """True while the particle is still animating."""
        return self._frame <= len(self.path)

    def current_display(self) -> tuple[tuple[int, int], int] | None:
        """Return the current ``(map_tile, char_code)`` to draw, or ``None``."""
        n = len(self.path)
        if self._frame > n:
            return None
        if self._frame < n - 1:
            return (self.path[self._frame], _BLOOD_FLY_CHAR)
        return (self.path[-1], _BLOOD_LAND_CHAR)

    def advance(self) -> None:
        """Increment the internal frame counter by one."""
        self._frame += 1

    def render(self, console: tcod.console.Console, cam: tuple[int, int]) -> None:
        """Draw the current frame and advance the counter.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        cam : tuple[int, int]
            Camera origin ``(cam_x, cam_y)``.
        """
        display = self.current_display()
        if display is not None:
            self._draw(console, display[0], display[1], cam)
        self.advance()

    def _draw(
        self,
        console: tcod.console.Console,
        tile: tuple[int, int],
        char: int,
        cam: tuple[int, int],
    ) -> None:
        screen_x, screen_y = tile[0] - cam[0], tile[1] - cam[1]
        if 0 <= screen_x < MAP_WIDTH and 0 <= screen_y < MAP_HEIGHT:
            console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["ch"] = char
            console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["fg"] = self.color


@dataclass
class ScreenFlash:
    """Coloured vignette around the map pane that fades out over several frames.

    Parameters
    ----------
    color : tuple[int, int, int]
        RGB tint (e.g. ``(220, 0, 0)`` for red damage flash).
    thickness : int
        Number of concentric rings from the map-pane edge (default 3).
    total_frames : int
        Frames until fully faded (default 15, roughly 0.5 s at 30 FPS).
    peak_alpha : int
        Opacity 0–255 of the outermost ring on the first frame (default 160).
    """

    color: Color = (220, 0, 0)
    thickness: int = 3
    total_frames: int = 15
    peak_alpha: int = 160
    _frames_remaining: int = field(default=0, init=False, repr=False)

    def trigger(self) -> None:
        """Restart the flash animation from the beginning."""
        self._frames_remaining = self.total_frames

    @property
    def active(self) -> bool:
        """True while the effect is still animating."""
        return self._frames_remaining > 0

    def render(self, console: tcod.console.Console) -> None:
        """Draw one frame of the effect and advance the counter."""
        if not self.active:
            return
        fade = self._frames_remaining / self.total_frames
        for i in range(self.thickness):
            alpha = self._ring_alpha(i, fade)
            if alpha > 0:
                self._draw_ring(console, i, alpha)
        self._frames_remaining -= 1

    def _ring_alpha(self, ring: int, fade: float) -> int:
        ring_frac = (self.thickness - ring) / self.thickness
        return round(self.peak_alpha * fade * ring_frac)

    def _draw_ring(self, console: tcod.console.Console, ring: int, alpha: int) -> None:
        # BKGND_ALPHA(int) internally does int*255 which wraps; encode directly instead
        blend = BKGND_ALPH | (alpha << 8)
        x0 = MAP_X + ring
        y0 = MAP_Y + ring
        w = MAP_WIDTH - 2 * ring
        h = MAP_HEIGHT - 2 * ring
        # top row
        console.draw_rect(x0, y0, w, 1, ch=0, fg=None, bg=self.color, bg_blend=blend)
        # bottom row
        console.draw_rect(
            x0, y0 + h - 1, w, 1, ch=0, fg=None, bg=self.color, bg_blend=blend
        )
        # left column (excluding corners already drawn)
        console.draw_rect(
            x0, y0 + 1, 1, h - 2, ch=0, fg=None, bg=self.color, bg_blend=blend
        )
        # right column (excluding corners already drawn)
        console.draw_rect(
            x0 + w - 1, y0 + 1, 1, h - 2, ch=0, fg=None, bg=self.color, bg_blend=blend
        )
