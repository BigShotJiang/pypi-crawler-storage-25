"""Overlay system: Overlay ABC and built-in HelpOverlay."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import tcod.console
import tcod.event
from tcod.libtcodpy import BKGND_ALPHA, BKGND_SET

from faraway_realms.ui.layout import MAP_HEIGHT, MAP_WIDTH, MAP_X, MAP_Y
from faraway_realms.ui.scroll_view import ScrollView

Color = tuple[int, int, int]

# ------------------------------------------------------------------
# Help content
# ------------------------------------------------------------------

_HEADER_COLOR: Color = (140, 140, 80)
_TEXT_COLOR: Color = (220, 220, 220)
_KEY_COLOR: Color = (100, 200, 255)
_CMD_COLOR: Color = (100, 255, 160)
_DIM_COLOR: Color = (120, 120, 120)

_GENERAL_LINES: list[tuple[str, Color]] = [
    ("  Movement & Combat", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  hjkl / arrows   Move", _TEXT_COLOR),
    ("  f                Attack target", _TEXT_COLOR),
    ("  t / Tab          Cycle targets", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Abilities", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  e   Kick         Knockback + brief root", _TEXT_COLOR),
    ("  q   Backstep     Disengage 2 tiles", _TEXT_COLOR),
    ("  r   Haste        +50% attack speed (3s)", _TEXT_COLOR),
    ("  g   Parry        Stun target (0.5s)", _TEXT_COLOR),
    ("  c   Second Wind  Heal 30 HP over 3s", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Interface", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  / or Enter       Open chat", _TEXT_COLOR),
    ("  { / }            Scroll chat history", _TEXT_COLOR),
    ("  ?                This help screen", _TEXT_COLOR),
    ("  Esc              Close overlay / unfocus", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Commands", _HEADER_COLOR),
    ("", _TEXT_COLOR),
    ("  /move    Move in a direction", _TEXT_COLOR),
    ("  /attack  Attack an entity", _TEXT_COLOR),
    ("  /cast    Use an ability", _TEXT_COLOR),
    ("  /target  Set or clear target", _TEXT_COLOR),
    ("  /spawn   Spawn a creature (GM only)", _TEXT_COLOR),
    ("  /help    Show help", _TEXT_COLOR),
    ("", _TEXT_COLOR),
    ("  Type /help <command> for details.", _DIM_COLOR),
]

_COMMAND_LINES: dict[str, list[tuple[str, Color]]] = {
    "move": [
        ("  /move", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /move me <direction>", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  direction: left | right | up | down", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Move the player one tile in the", _TEXT_COLOR),
        ("  given direction.", _TEXT_COLOR),
    ],
    "attack": [
        ("  /attack", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /attack me <id|@target>", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Attack entity by ID, or use @target", _TEXT_COLOR),
        ("  to attack the current target.", _TEXT_COLOR),
    ],
    "cast": [
        ("  /cast", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /cast me <ability> <id|@target>", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Use an ability on a target.  Use 'me'", _TEXT_COLOR),
        ("  as target for self-cast abilities.", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Abilities", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  kick        e   Knockback + brief root", _TEXT_COLOR),
        ("              KI  8s CD  · instant · GCD", _DIM_COLOR),
        ("", _TEXT_COLOR),
        ("  backstep    q   Disengage 2 tiles back", _TEXT_COLOR),
        ("              BS  8s CD  · instant · GCD", _DIM_COLOR),
        ("", _TEXT_COLOR),
        ("  haste       r   +50% attack speed (3s)", _TEXT_COLOR),
        ("              HA  20s CD · instant       ", _DIM_COLOR),
        ("", _TEXT_COLOR),
        ("  parry       g   Stun target 0.5s", _TEXT_COLOR),
        ("              PA  12s CD · instant       ", _DIM_COLOR),
        ("", _TEXT_COLOR),
        ("  second_wind c   Heal 30 HP over 3s", _TEXT_COLOR),
        ("              SW  25s CD · instant · GCD", _DIM_COLOR),
    ],
    "target": [
        ("  /target", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /target me [id]", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Set the current target to <id>.", _TEXT_COLOR),
        ("  Omit id to clear the target.", _TEXT_COLOR),
    ],
    "spawn": [
        ("  /spawn  (GM only)", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /spawn me <type> <x,y|random>", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Spawn a creature of the given type.", _TEXT_COLOR),
        ("  Use 'random' for a random visible tile.", _TEXT_COLOR),
        ("  Requires GM privileges.", _TEXT_COLOR),
    ],
    "help": [
        ("  /help", _HEADER_COLOR),
        ("", _TEXT_COLOR),
        ("  Syntax: /help [command]", _TEXT_COLOR),
        ("", _TEXT_COLOR),
        ("  Show general help, or detailed help", _TEXT_COLOR),
        ("  for a specific command.", _TEXT_COLOR),
    ],
}

_OVERLAY_W = MAP_WIDTH
_OVERLAY_H = MAP_HEIGHT + 2  # covers status bar row too
_SCROLL_H = _OVERLAY_H - 4  # inside border + footer
_SCROLL_W = _OVERLAY_W - 2  # inside border

_OVERLAY_BG: Color = (10, 12, 20)  # dark blueish fill
_OVERLAY_ALPHA: int = 210  # opacity 0–255 (255 = opaque); ≈ 0.82 × 255


# ------------------------------------------------------------------
# Overlay ABC
# ------------------------------------------------------------------


class Overlay(ABC):
    """Abstract base for map-pane overlays."""

    @abstractmethod
    def render(self, console: tcod.console.Console) -> None:
        """Draw the overlay into *console*."""

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle a key event.

        Parameters
        ----------
        event : tcod.event.KeyDown
            Incoming key event.

        Returns
        -------
        bool
            ``True`` to keep the overlay open, ``False`` to close it.
        """
        return event.sym != tcod.event.KeySym.ESCAPE


# ------------------------------------------------------------------
# HelpOverlay
# ------------------------------------------------------------------

_SCROLL_KEYS: dict[tcod.event.KeySym, int] = {
    tcod.event.KeySym.UP: -1,
    tcod.event.KeySym.DOWN: 1,
    tcod.event.KeySym.PAGEUP: -_SCROLL_H,
    tcod.event.KeySym.PAGEDOWN: _SCROLL_H,
}


@dataclass
class HelpOverlay(Overlay):
    """Help screen rendered over the map pane.

    Parameters
    ----------
    topic : str | None
        Command name for per-command detail (e.g. ``"move"``).
        ``None`` shows general key-binding and command overview.
    transparent : bool
        When ``True`` (default) the overlay background is alpha-blended
        with whatever is already in the console (map tiles, status bar),
        giving a frosted-glass effect.  ``False`` uses a solid fill.
    """

    topic: str | None = None
    transparent: bool = True
    _scroll: ScrollView = field(init=False, repr=False)

    def __post_init__(self) -> None:  # noqa: D105
        lines = _COMMAND_LINES.get(self.topic or "", _GENERAL_LINES)
        self._scroll = ScrollView(lines=list(lines), height=_SCROLL_H, width=_SCROLL_W)

    def render(self, console: tcod.console.Console) -> None:
        """Draw the help overlay into *console*."""
        ox, oy = MAP_X, MAP_Y
        blend = BKGND_ALPHA(_OVERLAY_ALPHA) if self.transparent else BKGND_SET
        console.draw_frame(
            ox,
            oy,
            _OVERLAY_W,
            _OVERLAY_H,
            fg=_HEADER_COLOR,
            bg=_OVERLAY_BG,
            bg_blend=blend,
            clear=True,
        )
        title = f" HELP \u2014 /{self.topic} " if self.topic else " HELP "
        console.print(ox + 2, oy, title, fg=_HEADER_COLOR)
        self._scroll.render(console, ox + 1, oy + 1)
        footer = "\u2191\u2193 scroll \u00b7 Esc close"
        console.print(ox + 2, oy + _OVERLAY_H - 1, footer, fg=_DIM_COLOR)

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Route scroll keys to the ScrollView; ESC closes the overlay."""
        if event.sym == tcod.event.KeySym.ESCAPE:
            return False
        delta = _SCROLL_KEYS.get(event.sym)
        if delta is not None:
            if delta < 0:
                self._scroll.scroll_up(-delta)
            else:
                self._scroll.scroll_down(delta)
        return True
