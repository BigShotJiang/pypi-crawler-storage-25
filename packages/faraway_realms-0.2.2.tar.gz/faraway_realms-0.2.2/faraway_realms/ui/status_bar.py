"""Status bar: cooldown/cast/GCD bars with status pips; name bar below."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.entity import GameEntity
from faraway_realms.status_definitions import STATUS_DEF_REGISTRY
from faraway_realms.ui.layout import (
    _CAST_BAR_EMPTY,
    _CAST_BAR_FILLED,
    _ENEMY_BAR_DIM,
    _GCD_BAR_EMPTY,
    _GCD_BAR_FILLED,
    _HASTE_BAR_EMPTY,
    _HASTE_BAR_FILLED,
    _PIP_EMPTY_BG,
    _PIP_TEXT_COLOR,
    _PIP_UNKNOWN_COLOR,
    _PLAYER_BAR_EMPTY,
    _PLAYER_BAR_FILLED,
    _SEP_CHAR,
    _STATUS_BAR_W,
    _STATUS_HALF,
    _STATUS_PIP_W,
    _STATUS_SEP_COLOR,
    _STATUS_TEXT_COLOR,
    _STUN_BAR_EMPTY,
    _STUN_BAR_FILLED,
    NAME_Y,
    STATUS_Y,
    _dim,
)

if TYPE_CHECKING:
    from faraway_realms.entity import Player
    from faraway_realms.game_protocol import GameProtocol
    from faraway_realms.status import StatusInstance

_EMPTY_BAR_COLOR: tuple[int, int, int] = (20, 20, 20)
_BAR_X_LEFT: int = _STATUS_HALF - _STATUS_BAR_W  # left bar: flush right to separator
_BAR_X_RIGHT: int = _STATUS_HALF + 1  # right bar: flush left from separator
_PIPS_X_LEFT: int = _BAR_X_LEFT - 1 - _STATUS_PIP_W  # pips: 1 col gap left of bar
_PIPS_X_RIGHT: int = _BAR_X_RIGHT + _STATUS_BAR_W + 1  # pips: 1 col gap right of bar


@dataclass(frozen=True)
class BarSpec:
    """Describes how to render a single status bar.

    Parameters
    ----------
    fraction : float
        Fill level 0.0–1.0.
    filled_color : tuple[int, int, int]
        Background color for filled cells.
    empty_color : tuple[int, int, int]
        Background color for empty cells.
    right_aligned : bool
        When ``True``, the filled portion grows from right to left (toward
        the centre separator).  Default is left-to-right.
    label : str | None
        Optional text centred over the bar (e.g. ``"CAST"``).
    """

    fraction: float
    filled_color: tuple[int, int, int]
    empty_color: tuple[int, int, int]
    right_aligned: bool = False
    label: str | None = None


@dataclass
class StatusBar:
    """Renders the cooldown/cast/GCD bar row with status effect pips.

    Parameters
    ----------
    game : Game
        Game state used to query cooldown fractions and entities.
    viewing_player : Player
        The player whose entity occupies the left half of the bar.
    """

    game: GameProtocol
    viewing_player: Player

    def render(self, console: tcod.console.Console) -> None:
        """Draw the status bar into *console*."""
        player_entity = self.viewing_player.entity
        pid = player_entity.entity_id
        self._draw_bar(console, _BAR_X_LEFT, self._player_bar_spec(pid))
        self._draw_pips_left(console, self.game.active_statuses(pid))
        self._draw_sep(console, STATUS_Y)
        self._draw_right(console, player_entity.target_id)

    # ------------------------------------------------------------------
    # Bar spec selection
    # ------------------------------------------------------------------

    def _player_bar_spec(self, entity_id: int) -> BarSpec:
        """Return the highest-priority bar spec for the player side."""
        cast_frac = self.game.cast_fraction(entity_id)
        if cast_frac is not None:
            return BarSpec(cast_frac, _CAST_BAR_FILLED, _CAST_BAR_EMPTY, label="CAST")
        gcd_frac = self.game.gcd_fraction(entity_id)
        if gcd_frac is not None:
            return BarSpec(gcd_frac, _GCD_BAR_FILLED, _GCD_BAR_EMPTY)
        return self._attack_bar_spec(entity_id)

    def _attack_bar_spec(self, entity_id: int) -> BarSpec:
        """Return attack cooldown spec, or empty when the player has no target."""
        if self.viewing_player.entity.target_id is None:
            return BarSpec(0.0, _EMPTY_BAR_COLOR, _EMPTY_BAR_COLOR)
        frac = self.game.attack_cooldown_fraction(entity_id)
        if self.game.has_active_status(entity_id, "haste"):
            return BarSpec(frac, _HASTE_BAR_FILLED, _HASTE_BAR_EMPTY)
        return BarSpec(frac, _PLAYER_BAR_FILLED, _PLAYER_BAR_EMPTY)

    def _enemy_bar_spec(self, target: GameEntity) -> BarSpec:
        """Return the highest-priority bar spec for the enemy side."""
        if self.game.has_active_status(target.entity_id, "stun"):
            return BarSpec(
                0.0,
                _STUN_BAR_FILLED,
                _STUN_BAR_EMPTY,
                right_aligned=True,
                label="STUN",
            )
        cast_frac = self.game.cast_fraction(target.entity_id)
        if cast_frac is not None:
            return BarSpec(
                cast_frac,
                _CAST_BAR_FILLED,
                _CAST_BAR_EMPTY,
                right_aligned=True,
                label="CAST",
            )
        frac = self.game.attack_cooldown_fraction(target.entity_id)
        return BarSpec(
            frac,
            target.fg_color,
            _dim(target.fg_color, _ENEMY_BAR_DIM),
            right_aligned=True,
        )

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------

    def _draw_right(self, console: tcod.console.Console, target_id: int | None) -> None:
        if target_id is None:
            empty = BarSpec(0.0, _EMPTY_BAR_COLOR, _EMPTY_BAR_COLOR)
            self._draw_bar(console, _BAR_X_RIGHT, empty)
            self._draw_pips_right(console, [])
            return
        target = self.game.entity(target_id)
        if target is None:
            self._draw_pips_right(console, [])
            return
        self._draw_bar(console, _BAR_X_RIGHT, self._enemy_bar_spec(target))
        self._draw_pips_right(console, self.game.active_statuses(target_id))

    def _draw_bar(
        self, console: tcod.console.Console, bar_x: int, spec: BarSpec
    ) -> None:
        filled_w = round(spec.fraction * _STATUS_BAR_W)
        start = _STATUS_BAR_W - filled_w if spec.right_aligned else 0
        end = _STATUS_BAR_W if spec.right_aligned else filled_w
        for i in range(_STATUS_BAR_W):
            color = spec.filled_color if start <= i < end else spec.empty_color
            console.rgb[STATUS_Y, bar_x + i]["bg"] = color
            console.rgb[STATUS_Y, bar_x + i]["ch"] = ord(" ")
        if spec.label:
            lx = bar_x + (_STATUS_BAR_W - len(spec.label)) // 2
            console.print(lx, STATUS_Y, spec.label, fg=(255, 255, 255))

    def _draw_pips_left(
        self, console: tcod.console.Console, statuses: list[StatusInstance]
    ) -> None:
        """Draw player pips right-aligned against the bar's left edge."""
        active = statuses[:_STATUS_PIP_W]
        for i in range(_STATUS_PIP_W):
            col = _PIPS_X_LEFT + i
            self._draw_pip(console, col, active[i] if i < len(active) else None)

    def _draw_pips_right(
        self, console: tcod.console.Console, statuses: list[StatusInstance]
    ) -> None:
        """Draw enemy pips left-aligned against the bar's right edge."""
        active = statuses[:_STATUS_PIP_W]
        for i in range(_STATUS_PIP_W):
            col = _PIPS_X_RIGHT + i
            self._draw_pip(console, col, active[i] if i < len(active) else None)

    def _draw_pip(
        self,
        console: tcod.console.Console,
        col: int,
        status: StatusInstance | None,
    ) -> None:
        if status is not None:
            defn = STATUS_DEF_REGISTRY.get(status.name)
            bg = defn.bg_color if defn is not None else _PIP_UNKNOWN_COLOR
            fg = defn.fg_color if defn is not None else _PIP_TEXT_COLOR
            glyph = defn.glyph if defn is not None else ord(status.name[0].upper())
            console.rgb[STATUS_Y, col]["bg"] = bg
            console.rgb[STATUS_Y, col]["fg"] = fg
            console.rgb[STATUS_Y, col]["ch"] = glyph
        else:
            console.rgb[STATUS_Y, col]["bg"] = _PIP_EMPTY_BG
            console.rgb[STATUS_Y, col]["ch"] = ord(" ")

    def _draw_sep(self, console: tcod.console.Console, y: int) -> None:
        console.rgb[y, _STATUS_HALF]["ch"] = _SEP_CHAR
        console.rgb[y, _STATUS_HALF]["fg"] = _STATUS_SEP_COLOR


@dataclass
class NameBar:
    """Renders the name row showing player and target names.

    Parameters
    ----------
    game : Game
        Game state used to look up entity names.
    viewing_player : Player
        The player whose name appears on the left.
    """

    game: GameProtocol
    viewing_player: Player

    def render(self, console: tcod.console.Console) -> None:
        """Draw the name bar into *console*."""
        player_name = self.viewing_player.entity.display_name
        max_w = _STATUS_HALF - 1  # 27 chars, leaving col 27 blank before the pipe
        console.print(
            0,
            NAME_Y,
            f"{player_name[:max_w]:>{max_w}}",
            fg=_STATUS_TEXT_COLOR,
        )
        self._draw_sep(console)
        target_id = self.viewing_player.entity.target_id
        if target_id is not None:
            self._draw_target_name(console, target_id, max_w)

    def _draw_target_name(
        self, console: tcod.console.Console, target_id: int, max_w: int
    ) -> None:
        target = self.game.entity(target_id)
        if target is None:
            return
        name = target.display_name[:max_w]
        console.print(
            _STATUS_HALF + 1,
            NAME_Y,
            f" {name:<{max_w}}",
            fg=_STATUS_TEXT_COLOR,
        )

    def _draw_sep(self, console: tcod.console.Console) -> None:
        console.rgb[NAME_Y, _STATUS_HALF]["ch"] = _SEP_CHAR
        console.rgb[NAME_Y, _STATUS_HALF]["fg"] = _STATUS_SEP_COLOR
