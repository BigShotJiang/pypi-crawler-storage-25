"""Generic scrollable content area with a right-side scrollbar."""

from __future__ import annotations

from dataclasses import dataclass, field

import tcod.console

Color = tuple[int, int, int]

_DIM_SCROLLBAR: Color = (80, 80, 80)
_BRIGHT_SCROLLBAR: Color = (180, 180, 180)
_THUMB_COLOR: Color = (200, 200, 200)


@dataclass
class ScrollView:
    """Scrollable list of coloured text lines with a right-side scrollbar.

    Parameters
    ----------
    lines : list[tuple[str, Color]]
        Content as ``(text, fg_color)`` pairs.
    height : int
        Number of visible rows (excluding scrollbar controls).
    width : int
        Total column width including the scrollbar column.
    """

    lines: list[tuple[str, Color]]
    height: int
    width: int
    _offset: int = field(default=0, init=False, repr=False)

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def scroll_up(self, n: int = 1) -> None:
        """Scroll up by *n* lines."""
        self._offset = max(0, self._offset - n)

    def scroll_down(self, n: int = 1) -> None:
        """Scroll down by *n* lines."""
        max_offset = max(0, len(self.lines) - self.height)
        self._offset = min(max_offset, self._offset + n)

    def scroll_to_bottom(self) -> None:
        """Jump to the last page of content."""
        self._offset = max(0, len(self.lines) - self.height)

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    @property
    def at_bottom(self) -> bool:
        """True when the last line is visible."""
        return self._offset >= max(0, len(self.lines) - self.height)

    @property
    def can_scroll_up(self) -> bool:
        """True when there is content above the viewport."""
        return self._offset > 0

    @property
    def can_scroll_down(self) -> bool:
        """True when there is content below the viewport."""
        return self._offset < max(0, len(self.lines) - self.height)

    def visible_lines(self) -> list[tuple[str, Color]]:
        """Return the slice of lines currently in the viewport."""
        return self.lines[self._offset : self._offset + self.height]

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render(self, console: tcod.console.Console, x: int, y: int) -> None:
        """Draw visible lines and the scrollbar into *console*.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        x : int
            Left column of this view.
        y : int
            Top row of this view.
        """
        self._render_lines(console, x, y)
        if len(self.lines) > self.height:
            self._render_scrollbar(console, x + self.width - 1, y)

    def _render_lines(self, console: tcod.console.Console, x: int, y: int) -> None:
        text_w = self.width - 2 if len(self.lines) > self.height else self.width
        for i, (text, color) in enumerate(self.visible_lines()):
            console.print(x, y + i, text[:text_w], fg=color)

    def _render_scrollbar(self, console: tcod.console.Console, sx: int, y: int) -> None:
        total = len(self.lines)
        inner_h = self.height - 2  # rows between ▲ and ▼
        thumb_row = 0
        if total > self.height and inner_h > 0:
            frac = self._offset / max(1, total - self.height)
            thumb_row = round(frac * (inner_h - 1))

        up_color = _BRIGHT_SCROLLBAR if self.can_scroll_up else _DIM_SCROLLBAR
        down_color = _BRIGHT_SCROLLBAR if self.can_scroll_down else _DIM_SCROLLBAR

        console.print(sx, y, "\u25b2", fg=up_color)  # ▲
        console.print(sx, y + self.height - 1, "\u25bc", fg=down_color)  # ▼

        for i in range(inner_h):
            row = y + 1 + i
            if i == thumb_row:
                console.print(sx, row, "\u2588", fg=_THUMB_COLOR)  # █
            else:
                console.print(sx, row, "\u2502", fg=_DIM_SCROLLBAR)  # │
