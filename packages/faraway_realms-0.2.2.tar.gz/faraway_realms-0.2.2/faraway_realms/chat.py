"""Chat message — colored text for the chat/combat log."""

from __future__ import annotations

from dataclasses import dataclass, field

# Palette for combat log entries
NPC_HIT_COLOR: tuple[int, int, int] = (160, 40, 40)  # dark red — NPC hits player
PLAYER_HIT_COLOR: tuple[int, int, int] = (220, 200, 60)  # yellow — player hits NPC
OPP_ATTACK_COLOR: tuple[int, int, int] = (220, 120, 20)  # orange — opportunity attack
DEFAULT_COLOR: tuple[int, int, int] = (200, 200, 200)  # light grey — system/chat


@dataclass(frozen=True)
class ChatMessage:
    """An immutable colored chat or combat log entry.

    Parameters
    ----------
    text : str
        The message text.
    color : tuple[int, int, int]
        RGB foreground color.  Defaults to :data:`DEFAULT_COLOR`.
    """

    text: str
    color: tuple[int, int, int] = field(default=DEFAULT_COLOR)
