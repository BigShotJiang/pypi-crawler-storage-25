"""Damage type effectiveness matrix for armor vs damage type interactions."""

from __future__ import annotations

import logging

_log = logging.getLogger(__name__)

# Populated at startup by content_parsers.damage_types.parse_damage_effectiveness.
EFFECTIVENESS: dict[tuple[str, str], float] = {}

# Tracks pairs already warned about to avoid repeated log lines per session.
_warned_pairs: set[tuple[str, str]] = set()


def effectiveness(damage_type: str, armor_type: str) -> float:
    """Return damage multiplier for this damage/armor type pair.

    Parameters
    ----------
    damage_type : str
        The attacker's damage type (e.g. ``"slashing"``).
    armor_type : str
        The defender's armor type (e.g. ``"bone"``).

    Returns
    -------
    float
        Damage multiplier; defaults to ``1.0`` for any unlisted pair.
        An unknown pair emits a one-time ``logging.WARNING``.
    """
    result = EFFECTIVENESS.get((damage_type, armor_type))
    if result is not None:
        return result
    key = (damage_type, armor_type)
    if key not in _warned_pairs:
        _warned_pairs.add(key)
        _log.warning(
            "Unknown damage pair (%r vs %r) — defaulting to 1.0",
            damage_type,
            armor_type,
        )
    return 1.0


def compute_ability_damage(
    base: int,
    damage_type: str,
    armor_type: str,
    armor_value: int,
) -> int:
    """Compute final damage after effectiveness and armor reduction.

    Parameters
    ----------
    base : int
        Raw base damage before reductions.
    damage_type : str
        Attacker's damage type (e.g. ``"fire"``).
    armor_type : str
        Defender's armor type (e.g. ``"stone"``).
    armor_value : int
        Flat armor subtracted from ``base`` before the multiplier.

    Returns
    -------
    int
        Final damage, minimum ``1``.
    """
    mult = effectiveness(damage_type, armor_type)
    return max(1, round((base - armor_value) * mult))
