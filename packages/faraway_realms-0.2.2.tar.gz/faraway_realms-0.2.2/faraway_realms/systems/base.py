"""Base class for all game systems."""


class System:
    """Base class for all game systems.

    Systems receive only the state they need via constructor injection.
    They never hold a reference to the Game coordinator.
    Communication back to the coordinator is via return values only.
    """
