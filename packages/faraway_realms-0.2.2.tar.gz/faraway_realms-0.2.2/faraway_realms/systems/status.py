"""Status-effect system — DoT ticking and status expiry."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.entity import get_combat_profile
from faraway_realms.events import Event, EventType
from faraway_realms.stats import Pool
from faraway_realms.systems.base import System

if TYPE_CHECKING:
    from faraway_realms.entity import GameEntity
    from faraway_realms.status import StatusInstance


class StatusEffectSystem(System):
    """Ticks DoT damage and expires status effects each game tick.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    """

    def __init__(self, entities: dict[int, GameEntity]) -> None:
        self._entities = entities

    def tick(self, abs_tick: int) -> list[Event]:
        """Process all active status effects for every entity.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        list[Event]
            DEATH events produced by DoT damage killing an entity.
        """
        events: list[Event] = []
        for entity in self._entities.values():
            events.extend(self._process_entity(entity, abs_tick))
        return events

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _process_entity(self, entity: GameEntity, abs_tick: int) -> list[Event]:
        """Expire old statuses and apply any due DoT ticks."""
        entity.status_effects = [
            s for s in entity.status_effects if not s.is_expired(abs_tick)
        ]
        events: list[Event] = []
        for status in entity.status_effects:
            if status.dot_due(abs_tick):
                events.extend(self._apply_dot(entity, status, abs_tick))
        return events

    def _apply_dot(
        self, entity: GameEntity, status: StatusInstance, abs_tick: int
    ) -> list[Event]:
        """Apply one DoT/HoT tick; return a DEATH event if the entity is killed."""
        hp = entity.stats.get(get_combat_profile(entity).death_stat)
        if not isinstance(hp, Pool):
            return []
        status.next_dot_tick = abs_tick + status.dot_interval
        return self._apply_hp_change(entity, hp, status, abs_tick)

    def _apply_hp_change(
        self,
        entity: GameEntity,
        hp: Pool,
        status: StatusInstance,
        abs_tick: int,
    ) -> list[Event]:
        """Modify HP for a DoT or HoT tick; emit DEATH if pool empties."""
        if status.tick_damage > 0:
            hp.modify(-status.tick_damage)
            if hp.is_empty:
                return [
                    Event(
                        event_type=EventType.DEATH,
                        source_id=entity.entity_id,
                        target_id=None,
                        resolve_at_tick=abs_tick,
                    )
                ]
        elif status.tick_heal > 0:
            hp.modify(status.tick_heal)
        return []
