"""Movement system — handles MOVE commands, contact detection, opportunity attacks."""

from __future__ import annotations

from faraway_realms.entity import GameEntity
from faraway_realms.events import Event, EventType
from faraway_realms.factions import FactionRelations
from faraway_realms.map import Map, is_adjacent
from faraway_realms.status import is_immobilized
from faraway_realms.systems.base import System

_DIRECTION_DELTAS: dict[str, tuple[int, int]] = {
    "left": (-1, 0),
    "right": (1, 0),
    "up": (0, -1),
    "down": (0, 1),
}


class MovementSystem(System):
    """Handles MOVE commands: direction resolution, occupancy, contact detection.

    Parameters
    ----------
    game_map : Map
        The active map.
    entities : dict[int, GameEntity]
        Shared entity registry.
    faction_relations : FactionRelations
        Used to determine whether adjacency constitutes hostile contact.
    """

    def __init__(
        self,
        game_map: Map,
        entities: dict[int, GameEntity],
        faction_relations: FactionRelations,
    ) -> None:
        self._game_map = game_map
        self._entities = entities
        self._faction_relations = faction_relations

    def handle(self, actor_id: int, direction: str, abs_tick: int) -> list[Event]:
        """Process a move and return any resulting contact events.

        Parameters
        ----------
        actor_id : int
            Resolved entity ID of the mover.
        direction : str
            Cardinal direction string (``"left"``, ``"right"``, ``"up"``, ``"down"``).
        abs_tick : int
            Current tick, used as ``resolve_at_tick`` on emitted events.

        Returns
        -------
        list[Event]
            CONTACT events from opportunity attacks and adjacency checks.
        """
        delta = _DIRECTION_DELTAS.get(direction)
        if delta is None:
            return []
        entity = self._entities.get(actor_id)
        if entity is not None and is_immobilized(entity, abs_tick):
            return []
        x, y = self._game_map.get_entity_position(actor_id)
        dest_x, dest_y = x + delta[0], y + delta[1]
        if self._game_map.is_occupied(dest_x, dest_y):
            return []
        events = self._check_opportunity_attacks(
            actor_id, x, y, dest_x, dest_y, abs_tick
        )
        self._game_map.move_entity(actor_id, delta[0], delta[1])
        events.extend(self._check_contact(actor_id, dest_x, dest_y, abs_tick))
        return events

    def _check_opportunity_attacks(
        self,
        moving_id: int,
        from_x: int,
        from_y: int,
        dest_x: int,
        dest_y: int,
        abs_tick: int,
    ) -> list[Event]:
        events = []
        for other_id, (ox, oy) in self._game_map.get_all_positions().items():
            if other_id == moving_id:
                continue
            event = self._maybe_opportunity_attack(
                moving_id, other_id, ox, oy, from_x, from_y, dest_x, dest_y, abs_tick
            )
            if event is not None:
                events.append(event)
        return events

    def _maybe_opportunity_attack(
        self,
        moving_id: int,
        other_id: int,
        other_x: int,
        other_y: int,
        from_x: int,
        from_y: int,
        dest_x: int,
        dest_y: int,
        abs_tick: int,
    ) -> Event | None:
        if not is_adjacent(other_x, other_y, from_x, from_y):
            return None
        if is_adjacent(other_x, other_y, dest_x, dest_y):
            return None  # still in melee range after the move — not fleeing
        if not self._is_targeting_mover(other_id, moving_id):
            return None
        return Event(
            event_type=EventType.CONTACT,
            source_id=other_id,
            target_id=moving_id,
            resolve_at_tick=abs_tick,
            payload={"opportunity": True},
        )

    def _is_targeting_mover(self, other_id: int, moving_id: int) -> bool:
        other = self._entities.get(other_id)
        if other is None or other.target_id != moving_id:
            return False
        mover = self._entities.get(moving_id)
        return mover is not None and self._faction_relations.are_hostile(
            other.faction, mover.faction
        )

    def _adjacent_other_ids(self, entity_id: int, x: int, y: int) -> list[int]:
        return [
            eid
            for eid, (ox, oy) in self._game_map.get_all_positions().items()
            if eid != entity_id and is_adjacent(ox, oy, x, y)
        ]

    def _check_contact(
        self, entity_id: int, x: int, y: int, abs_tick: int
    ) -> list[Event]:
        mover = self._entities.get(entity_id)
        if mover is None:
            return []
        events = []
        for other_id in self._adjacent_other_ids(entity_id, x, y):
            event = self._check_pair_contact(mover, other_id, abs_tick)
            if event is not None:
                events.append(event)
        return events

    def _check_pair_contact(
        self, mover: GameEntity, other_id: int, abs_tick: int
    ) -> Event | None:
        other = self._entities.get(other_id)
        if other is None:
            return None
        if not self._faction_relations.are_hostile(mover.faction, other.faction):
            return None
        return Event(
            event_type=EventType.CONTACT,
            source_id=mover.entity_id,
            target_id=other.entity_id,
            resolve_at_tick=abs_tick,
        )
