"""Contact resolution system — handles CONTACT events."""

from __future__ import annotations

from faraway_realms.commands import (
    Command,
    CommandType,
    make_attack_command,
    make_prime_cooldown_command,
)
from faraway_realms.entity import GameEntity
from faraway_realms.events import Event
from faraway_realms.systems.base import System


class ContactResolutionSystem(System):
    """Handles CONTACT events: auto-targets both parties and queues an attack.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    """

    def __init__(self, entities: dict[int, GameEntity]) -> None:
        self._entities = entities

    def handle(self, event: Event) -> list[Command]:
        """Resolve a CONTACT event and return resulting attack commands.

        Parameters
        ----------
        event : Event
            Must be ``EventType.CONTACT``.

        Returns
        -------
        list[Command]
            Zero or one ATTACK command to enqueue.
        """
        if event.target_id is None:
            return []
        if not self._both_alive(event.source_id, event.target_id):
            return []
        if event.payload and event.payload.get("opportunity"):
            return self._resolve_opportunity(event.source_id, event.target_id)
        return self._resolve_normal(event.source_id, event.target_id)

    def _resolve_opportunity(self, source_id: int, target_id: int) -> list[Command]:
        """Opportunity attack: source attacks, both sides auto-target."""
        cmds: list[Command] = []
        if self._set_target_if_unset(source_id, target_id):
            cmds.append(make_prime_cooldown_command(source_id))
        if self._set_target_if_unset(target_id, source_id):
            cmds.append(make_prime_cooldown_command(target_id))
        cmds.append(
            make_attack_command(source_id, target_id, CommandType.OPPORTUNITY_ATTACK)
        )
        return cmds

    def _resolve_normal(self, source_id: int, target_id: int) -> list[Command]:
        """Mover attacks; both sides auto-target if not already targeting anyone.

        Attack timing is governed by the cooldown system — the mover's attack
        command is gated by ``CombatSystem`` on the next tick if their cooldown
        is not yet ready.  Initiative is therefore determined by *when* the NPC
        started its chase (PRIME_COOLDOWN) rather than by target bookkeeping here.
        """
        cmds: list[Command] = []
        if self._set_target_if_unset(source_id, target_id):
            cmds.append(make_prime_cooldown_command(source_id))
        if self._set_target_if_unset(target_id, source_id):
            cmds.append(make_prime_cooldown_command(target_id))
        cmds.append(make_attack_command(source_id, target_id))
        return cmds

    def _both_alive(self, a: int, b: int) -> bool:
        return a in self._entities and b in self._entities

    def _set_target_if_unset(self, entity_id: int, new_target_id: int) -> bool:
        """Set target if unset; return True when a new target was assigned."""
        entity = self._entities.get(entity_id)
        if entity is None or entity.target_id is not None:
            return False
        entity.target_id = new_target_id
        return True
