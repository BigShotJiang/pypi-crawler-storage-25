"""Death system — handles DEATH events, entity removal, and target cleanup."""

from __future__ import annotations

from faraway_realms.entity import Entity, GameEntity
from faraway_realms.events import Event
from faraway_realms.map import Map
from faraway_realms.systems.base import System


class DeathSystem(System):
    """Handles DEATH events: removes the entity and clears all target references.

    Parameters
    ----------
    game_map : Map
        The active map.
    entities : dict[int, GameEntity]
        Shared entity registry; the entry is popped on death.
    npcs : list[Entity]
        NPC registry; mutated in place via slice assignment on death.
    """

    def __init__(
        self,
        game_map: Map,
        entities: dict[int, GameEntity],
        npcs: list[Entity],
    ) -> None:
        self._game_map = game_map
        self._entities = entities
        self._npcs = npcs

    def handle(self, event: Event) -> None:
        """Remove the dying entity and clear all targeting references.

        Parameters
        ----------
        event : Event
            Must be ``EventType.DEATH``.
        """
        entity_id = event.source_id
        if self._game_map.has_entity(entity_id):
            self._game_map.remove_entity(entity_id)
        self._entities.pop(entity_id, None)
        self._npcs[:] = [n for n in self._npcs if n.entity_id != entity_id]
        self._clear_targets_to(entity_id)

    def _clear_targets_to(self, dead_id: int) -> None:
        for entity in self._entities.values():
            if entity.target_id == dead_id:
                entity.target_id = None
