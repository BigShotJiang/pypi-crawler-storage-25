"""Combat system — handles ATTACK commands, damage calculation, and death detection."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from faraway_realms.damage_types import effectiveness
from faraway_realms.entity import GameEntity, get_combat_profile
from faraway_realms.events import Event, EventType
from faraway_realms.stats import Pool
from faraway_realms.systems.base import System


def _stat_value(entity: GameEntity, key: str, default: int) -> int:
    stat = entity.stats.get(key)
    return stat.value if stat is not None else default


@dataclass
class CombatResult:
    """Outcome of a single attack resolution.

    Parameters
    ----------
    events : list[Event]
        Zero or one DEATH event if the target's pool reached zero.
    damage_dealt : int
        Damage actually applied this tick; ``0`` when the attack was blocked
        by cooldown or either entity was missing.
    crit : bool
        Whether the attack was a critical hit.
    stagger_ticks : int
        How many ticks of pushback were applied to the target's cooldown;
        ``0`` when the target was already ready and stagger did not apply.
    """

    events: list[Event] = field(default_factory=list)
    damage_dealt: int = 0
    crit: bool = False
    stagger_ticks: int = 0


class CombatSystem(System):
    """Handles ATTACK commands: cooldown gating, damage calculation, death emission.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    """

    def __init__(self, entities: dict[int, GameEntity]) -> None:
        self._entities = entities
        self._last_attack_tick: dict[int, int] = {}

    def handle(
        self,
        attacker_id: int,
        target_id: int,
        abs_tick: int,
        *,
        bypass_cooldown: bool = False,
        haste_factor: float = 1.0,
    ) -> CombatResult:
        """Process an attack and return the outcome.

        Parameters
        ----------
        attacker_id : int
            Resolved entity ID of the attacker.
        target_id : int
            Resolved entity ID of the target.
        abs_tick : int
            Current tick, used for cooldown tracking and event scheduling.
        bypass_cooldown : bool
            When ``True``, skip the cooldown gate (used for opportunity attacks).
        haste_factor : float
            Attack-speed multiplier from active haste effects (>1.0 = faster).

        Returns
        -------
        CombatResult
            Events to emit and the damage actually dealt (``0`` if no hit landed).
        """
        attacker = self._entities.get(attacker_id)
        target = self._entities.get(target_id)
        if attacker is None or target is None:
            return CombatResult()
        attack_ready = self._is_attack_ready(
            attacker_id, attacker, abs_tick, haste_factor
        )
        if not bypass_cooldown and not attack_ready:
            return CombatResult()
        self._last_attack_tick[attacker_id] = abs_tick
        damage, crit = self._calc_damage(attacker, target)
        stagger_ticks = self._apply_stagger(attacker, target, target_id, abs_tick)
        return CombatResult(
            events=self._apply_damage(target, damage, abs_tick),
            damage_dealt=damage,
            crit=crit,
            stagger_ticks=stagger_ticks,
        )

    def effective_last_attack(self, entity_id: int) -> int:
        """Return the tick this entity last attacked.

        Stagger pushback is encoded directly into ``_last_attack_tick``, so
        this value already reflects any active stagger delay.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        int
            Tick of the last recorded (or stagger-adjusted) attack.
        """
        return self._last_attack_tick.get(entity_id, -(10**9))

    def forget(self, entity_id: int) -> None:
        """Remove attack-timing state for *entity_id*, resetting the cooldown bar.

        Parameters
        ----------
        entity_id : int
            Entity whose cooldown tracking should be cleared.
        """
        self._last_attack_tick.pop(entity_id, None)

    def prime(self, entity_id: int, abs_tick: int, *, force: bool = False) -> None:
        """Initialise the attack cooldown as if this entity just attacked.

        Parameters
        ----------
        entity_id : int
            Entity to prime.
        abs_tick : int
            Current tick; the cooldown timer starts from here.
        force : bool
            When ``True``, always reset even if the cooldown is fully charged.
            Use for intentional resets (target switch, cast reprime).  When
            ``False`` (default), priming is a no-op for an entity whose
            cooldown is already fully charged — preserves a charge built up
            during a chase rather than resetting it on contact arrival.
        """
        if not force and entity_id in self._last_attack_tick:
            entity = self._entities.get(entity_id)
            if entity is not None and self._is_attack_ready(
                entity_id, entity, abs_tick
            ):
                return
        self._last_attack_tick[entity_id] = abs_tick

    def _is_attack_ready(
        self,
        attacker_id: int,
        attacker: GameEntity,
        abs_tick: int,
        haste_factor: float = 1.0,
    ) -> bool:
        last = self.effective_last_attack(attacker_id)
        return abs_tick - last >= self._effective_attack_every(attacker, haste_factor)

    def cooldown_fraction(
        self, entity_id: int, abs_tick: int, *, haste_factor: float = 1.0
    ) -> float:
        """Return how far through the attack cooldown this entity is (0–1).

        Parameters
        ----------
        entity_id : int
            Entity to query.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        float
            ``0.0`` when unprimed or immediately after an attack;
            ``1.0`` when ready to attack.
        """
        if entity_id not in self._last_attack_tick:
            return 0.0
        entity = self._entities.get(entity_id)
        if entity is None:
            return 1.0
        last = self.effective_last_attack(entity_id)
        effective = self._effective_attack_every(entity, haste_factor)
        return min(1.0, (abs_tick - last) / effective)

    def _effective_attack_every(
        self, entity: GameEntity, haste_factor: float = 1.0
    ) -> int:
        speed = entity.stats.get("attack_speed")
        bonus = speed.value if speed is not None else 0
        base = max(1, get_combat_profile(entity).attack_every - bonus)
        return max(1, round(base / haste_factor))

    def _calc_damage(
        self, attacker: GameEntity, target: GameEntity
    ) -> tuple[int, bool]:
        str_val = _stat_value(attacker, "strength", 1)
        armor_val = _stat_value(target, "armor", 0)
        acp = get_combat_profile(attacker)
        tcp = get_combat_profile(target)
        mult = effectiveness(acp.damage_type, tcp.armor_type)
        base = max(1, round((str_val - armor_val) * mult))
        crit = self._roll_crit(attacker)
        return (base * 2 if crit else base), crit

    def _roll_crit(self, attacker: GameEntity) -> bool:
        crit_val = _stat_value(attacker, "crit_chance", 0)
        return (
            crit_val > 0 and random.randint(1, 100) <= crit_val  # noqa: S311 — game logic
        )

    def _apply_stagger(
        self,
        attacker: GameEntity,
        target: GameEntity,
        target_id: int,
        abs_tick: int,
    ) -> int:
        """Push the target's attack cooldown back if they are mid-cooldown.

        Stagger has no effect when the target is already fully ready to attack
        — they have recovered from their last swing and are balanced.  When
        mid-cooldown, the remaining wait is extended by
        ``max(1, attacker_strength // 2)`` ticks (capped so the bar never
        resets past its starting point).

        Parameters
        ----------
        attacker : GameEntity
            The entity landing the hit; determines pushback magnitude.
        target : GameEntity
            The entity being staggered; used to read ``attack_every``.
        target_id : int
            Entity ID used to update ``_last_attack_tick``.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        int
            Ticks of pushback applied; ``0`` when no stagger was applied.
        """
        target_last = self._last_attack_tick.get(target_id, -(10**9))
        elapsed = abs_tick - target_last
        if elapsed >= self._effective_attack_every(target):
            return 0  # already ready — not staggered
        pushback = max(1, _stat_value(attacker, "strength", 1) // 2)
        # Advance last_attack_tick forward (extending remaining cooldown).
        # Cap at abs_tick so the bar never goes below 0.
        self._last_attack_tick[target_id] = min(abs_tick, target_last + pushback)
        return pushback

    def _apply_damage(
        self, target: GameEntity, damage: int, abs_tick: int
    ) -> list[Event]:
        """Apply damage to target's death stat pool and emit DEATH if depleted.

        Parameters
        ----------
        target : GameEntity
            The entity receiving damage.
        damage : int
            Amount of damage to apply.
        abs_tick : int
            Current tick, used as ``resolve_at_tick`` on the DEATH event.

        Returns
        -------
        list[Event]
            Zero or one DEATH event.
        """
        pool = target.stats.get(get_combat_profile(target).death_stat)
        if not isinstance(pool, Pool):
            return []
        pool.modify(-damage)
        if pool.is_empty:
            return [
                Event(
                    event_type=EventType.DEATH,
                    source_id=target.entity_id,
                    resolve_at_tick=abs_tick,
                )
            ]
        return []
