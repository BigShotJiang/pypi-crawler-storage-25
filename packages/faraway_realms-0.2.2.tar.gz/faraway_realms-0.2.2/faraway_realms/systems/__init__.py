"""Game systems — each system handles one slice of game logic."""

from faraway_realms.systems.base import System
from faraway_realms.systems.combat import CombatSystem
from faraway_realms.systems.contact import ContactResolutionSystem
from faraway_realms.systems.death import DeathSystem
from faraway_realms.systems.movement import MovementSystem
from faraway_realms.systems.npc_intent import NpcIntentSystem
from faraway_realms.systems.projectile import ProjectileDetonation, ProjectileSystem
from faraway_realms.systems.targeting import TargetingSystem

__all__ = [
    "CombatSystem",
    "ContactResolutionSystem",
    "DeathSystem",
    "MovementSystem",
    "NpcIntentSystem",
    "ProjectileDetonation",
    "ProjectileSystem",
    "System",
    "TargetingSystem",
]
