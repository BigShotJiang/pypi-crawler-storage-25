"""Targeting system — handles TARGET commands, cycling, and LoS maintenance."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from faraway_realms import fov as _fov
from faraway_realms.entity import GameEntity
from faraway_realms.fov import entity_sight
from faraway_realms.map import chebyshev as _chebyshev_dist
from faraway_realms.systems.base import System

if TYPE_CHECKING:
    from faraway_realms.factions import FactionRelations
    from faraway_realms.map import Map


class TargetingSystem(System):
    """Handles TARGET commands: sets, clears, cycles, and validates targets.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    game_map : Map
        The active map; used for position lookups and FOV computation.
    faction_relations : FactionRelations
        Determines which factions are hostile to each other.
    """

    def __init__(
        self,
        entities: dict[int, GameEntity],
        game_map: Map,
        faction_relations: FactionRelations,
    ) -> None:
        self._entities = entities
        self._game_map = game_map
        self._faction_relations = faction_relations

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def handle(self, entity_id: int, new_target_id: int | None) -> None:
        """Set or clear ``target_id`` on an entity.

        Parameters
        ----------
        entity_id : int
            Resolved entity ID.
        new_target_id : int | None
            New target ID, or ``None`` to clear.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return
        entity.target_id = new_target_id

    def cycle(self, entity_id: int) -> None:
        """Advance ``target_id`` to the next visible hostile, by distance.

        Visible hostiles are sorted by Chebyshev distance (nearest first) and
        cycled in order.  Wraps back to the nearest when the end is reached.
        Clears ``target_id`` when no hostiles are visible.

        Parameters
        ----------
        entity_id : int
            The acting entity whose ``target_id`` will be updated.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return
        visible = self._player_fov(entity_id, entity)
        if visible is None:
            entity.target_id = None
            return
        pos = self._entity_pos(entity_id)
        hostiles = self._visible_hostiles(entity, visible)
        by_dist = sorted(hostiles, key=lambda eid: self._chebyshev(pos, eid))
        entity.target_id = self._next_candidate(entity.target_id, by_dist)

    def maintain_los(self, entity_id: int) -> None:
        """Clear ``target_id`` when the target leaves LoS or dies.

        Parameters
        ----------
        entity_id : int
            The entity whose targeting should be validated.
        """
        entity = self._entities.get(entity_id)
        if entity is None or entity.target_id is None:
            return
        if entity.target_id not in self._entities:
            entity.target_id = None
            return
        if not self._target_visible(entity_id, entity):
            entity.target_id = None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _entity_pos(self, entity_id: int) -> tuple[int, int] | None:
        if not self._game_map.has_entity(entity_id):
            return None
        return self._game_map.get_entity_position(entity_id)

    def _player_fov(self, entity_id: int, entity: GameEntity) -> np.ndarray | None:
        pos = self._entity_pos(entity_id)
        if pos is None:
            return None
        return _fov.compute_fov(self._game_map, pos[0], pos[1], entity_sight(entity))

    def _is_hostile_to(self, actor: GameEntity, eid: int) -> bool:
        other = self._entities.get(eid)
        if other is None or eid == actor.entity_id:
            return False
        return self._faction_relations.are_hostile(actor.faction, other.faction)

    def _in_fov(self, eid: int, visible: np.ndarray) -> bool:
        pos = self._entity_pos(eid)
        if pos is None:
            return False
        return bool(visible[pos[1], pos[0]])

    def _visible_hostiles(self, actor: GameEntity, visible: np.ndarray) -> list[int]:
        return [
            eid
            for eid in self._entities
            if self._is_hostile_to(actor, eid) and self._in_fov(eid, visible)
        ]

    def _chebyshev(self, origin: tuple[int, int] | None, target_id: int) -> int:
        if origin is None:
            return 0
        pos = self._entity_pos(target_id)
        if pos is None:
            return 0
        return _chebyshev_dist(origin[0], origin[1], pos[0], pos[1])

    def _next_candidate(self, current: int | None, candidates: list[int]) -> int | None:
        if not candidates:
            return None
        if current not in candidates:
            return candidates[0]
        idx = candidates.index(current)
        return candidates[(idx + 1) % len(candidates)]

    def _target_visible(self, entity_id: int, entity: GameEntity) -> bool:
        visible = self._player_fov(entity_id, entity)
        if visible is None:
            return False
        return self._in_fov(entity.target_id, visible)  # type: ignore[arg-type]
