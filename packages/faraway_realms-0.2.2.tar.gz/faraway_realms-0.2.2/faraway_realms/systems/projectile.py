"""Projectile system — tick-based homing projectile movement and detonation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from faraway_realms.damage_types import compute_ability_damage
from faraway_realms.entity import get_combat_profile
from faraway_realms.projectile import Projectile
from faraway_realms.stats import Pool
from faraway_realms.systems.base import System

if TYPE_CHECKING:
    from faraway_realms.abilities import ApplyStatusEffect, ProjectileEffect
    from faraway_realms.entity import GameEntity
    from faraway_realms.map import Map


@dataclass(frozen=True)
class ProjectileDetonation:
    """Outcome of a single projectile impact.

    Parameters
    ----------
    source_id : int
        Entity ID of the caster/shooter.
    target_id : int
        Entity ID of the entity that was struck.
    damage_dealt : int
        Damage applied to the target's death pool.
    target_died : bool
        Whether the target's death pool was depleted.
    on_hit_statuses : tuple[ApplyStatusEffect, ...]
        Status effects the caller should apply to the target.
    """

    source_id: int
    target_id: int
    damage_dealt: int
    target_died: bool
    on_hit_statuses: tuple[ApplyStatusEffect, ...]


class ProjectileSystem(System):
    """Manages in-flight projectiles: movement, wall collision, and detonation.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    game_map : Map
        Shared map reference for walkability and position lookups.
    """

    def __init__(self, entities: dict[int, GameEntity], game_map: Map) -> None:
        self._entities = entities
        self._game_map = game_map
        self._projectiles: list[Projectile] = []
        self._pending: list[ProjectileDetonation] = []

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return the list of currently in-flight projectiles (read-only view)."""
        return self._projectiles

    def spawn(
        self,
        caster_id: int,
        target_id: int,
        effect: ProjectileEffect,
    ) -> None:
        """Create a new in-flight projectile from a ProjectileEffect.

        Parameters
        ----------
        caster_id : int
            Entity ID of the caster.
        target_id : int
            Entity ID of the target (locked at cast time).
        effect : ProjectileEffect
            Ability effect describing the projectile's properties.
        """
        if not (
            self._game_map.has_entity(caster_id)
            and self._game_map.has_entity(target_id)
        ):
            return
        cx, cy = self._game_map.get_entity_position(caster_id)
        tx, ty = self._game_map.get_entity_position(target_id)
        from faraway_realms.components import LightEmitter

        emitter = effect.components.get("light_emitter")
        light_source = emitter if isinstance(emitter, LightEmitter) else None
        self._projectiles.append(
            Projectile(
                source_id=caster_id,
                target_id=target_id,
                x=cx,
                y=cy,
                target_x=tx,
                target_y=ty,
                speed=effect.speed,
                base_damage=effect.base,
                damage_type=effect.damage_type,
                on_hit_statuses=effect.on_hit_statuses,
                color=effect.color,
                visual_type=effect.visual_type,
                trail_length=effect.trail_length,
                trail_char=effect.trail_char,
                light_source=light_source,
            )
        )

    def tick(self, abs_tick: int) -> list[ProjectileDetonation]:
        """Advance all projectiles one tick; return detonations that occurred.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick, forwarded to detonation helpers.

        Returns
        -------
        list[ProjectileDetonation]
            One entry per projectile that impacted this tick.  The caller is
            responsible for emitting DEATH events, logging, and status effects.
        """
        self._pending = []
        self._projectiles = [p for p in self._projectiles if self._step(p, abs_tick)]
        return self._pending

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _step(self, p: Projectile, abs_tick: int) -> bool:
        """Accumulate speed and advance N tiles; return ``False`` to despawn."""
        p.dist_accum += p.speed
        moves = int(p.dist_accum)
        p.dist_accum -= moves
        self._sync_target(p)
        for _ in range(moves):
            if not self._advance(p, abs_tick):
                return False
        return True

    def _sync_target(self, p: Projectile) -> None:
        """Follow a living target; stop homing when target leaves the map."""
        if not p.homing:
            return
        if self._game_map.has_entity(p.target_id):
            p.target_x, p.target_y = self._game_map.get_entity_position(p.target_id)
        else:
            p.homing = False

    def _advance(self, p: Projectile, abs_tick: int) -> bool:
        """Step one tile toward destination; return ``False`` on wall or impact."""
        dx = (p.target_x > p.x) - (p.target_x < p.x)
        dy = (p.target_y > p.y) - (p.target_y < p.y)
        nx, ny = p.x + dx, p.y + dy
        if not self._game_map.get_tile(nx, ny).walkable:
            return False
        p.trail.appendleft((p.x, p.y))
        p.x, p.y = nx, ny
        if p.x == p.target_x and p.y == p.target_y:
            self._detonate(p, abs_tick)
            return False
        return True

    def _detonate(self, p: Projectile, abs_tick: int) -> None:  # noqa: ARG002 — abs_tick reserved for future use
        """Record a detonation result after applying damage to the target."""
        target = self._entities.get(p.target_id)
        if target is None:
            return
        damage, died = self._deal_damage(p)
        self._pending.append(
            ProjectileDetonation(
                source_id=p.source_id,
                target_id=p.target_id,
                damage_dealt=damage,
                target_died=died,
                on_hit_statuses=p.on_hit_statuses,
            )
        )

    def _deal_damage(self, p: Projectile) -> tuple[int, bool]:
        """Apply impact damage; return ``(damage_dealt, target_died)``."""
        target = self._entities.get(p.target_id)
        if target is None:
            return 0, False
        tcp = get_combat_profile(target)
        pool = target.stats.get(tcp.death_stat)
        if not isinstance(pool, Pool):
            return 0, False
        armor = target.stats.get("armor")
        armor_val = armor.value if armor is not None else 0
        damage = compute_ability_damage(
            p.base_damage, p.damage_type, tcp.armor_type, armor_val
        )
        pool.modify(-damage)
        return damage, pool.is_empty
