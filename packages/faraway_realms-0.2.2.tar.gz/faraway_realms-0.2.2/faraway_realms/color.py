"""Shared colour utilities."""

from __future__ import annotations

Color = tuple[int, int, int]


def lerp_color(a: Color, b: Color, t: float) -> Color:
    """Linearly interpolate between colours *a* and *b* at fraction *t*.

    Parameters
    ----------
    a : Color
        Starting colour (t=0).
    b : Color
        Target colour (t=1).
    t : float
        Blend fraction 0.0–1.0.

    Returns
    -------
    Color
        Blended RGB tuple.
    """
    return (
        round(a[0] + (b[0] - a[0]) * t),
        round(a[1] + (b[1] - a[1]) * t),
        round(a[2] + (b[2] - a[2]) * t),
    )
