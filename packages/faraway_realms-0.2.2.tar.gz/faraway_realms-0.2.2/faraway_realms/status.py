"""Active status-effect instances carried by entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.entity import GameEntity


@dataclass
class StatusInstance:
    """A live status effect applied to an entity.

    Parameters
    ----------
    name : str
        Unique name matching the ``ApplyStatusEffect.status_name`` that created it.
    expires_at : int
        Absolute tick when this status expires.
    tick_damage : int
        HP removed per DoT interval. ``0`` means no damage-over-time.
    tick_heal : int
        HP restored per HoT interval. ``0`` means no healing.
    dot_interval : int
        Ticks between DoT/HoT applications.
    next_dot_tick : int
        Next absolute tick on which DoT/HoT fires.
    immobilize : bool
        When ``True``, the affected entity cannot move.
    stun : bool
        When ``True``, the affected entity cannot attack or cast.
    haste : float
        Attack-speed multiplier (>1.0 = faster; 1.0 = none).
    """

    name: str
    expires_at: int
    tick_damage: int = 0
    tick_heal: int = 0
    dot_interval: int = 10
    next_dot_tick: int = field(default=0)
    immobilize: bool = False
    stun: bool = False
    haste: float = 1.0

    def is_expired(self, abs_tick: int) -> bool:
        """Return ``True`` when this status has run its full duration.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        bool
            ``True`` when ``abs_tick >= expires_at``.
        """
        return abs_tick >= self.expires_at

    def dot_due(self, abs_tick: int) -> bool:
        """Return ``True`` when a DoT tick is due.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        bool
            ``True`` when this status deals damage and the next DoT tick has arrived.
        """
        has_tick = self.tick_damage > 0 or self.tick_heal > 0
        return has_tick and abs_tick >= self.next_dot_tick


def is_immobilized(entity: GameEntity, abs_tick: int) -> bool:
    """Return ``True`` when *entity* has an active immobilize status.

    Parameters
    ----------
    entity : GameEntity
        Entity to query.
    abs_tick : int
        Current absolute tick used to check expiry.

    Returns
    -------
    bool
        ``True`` when at least one active status has ``immobilize=True``.
    """
    return any(
        s.immobilize and not s.is_expired(abs_tick) for s in entity.status_effects
    )


def is_stunned(entity: GameEntity, abs_tick: int) -> bool:
    """Return ``True`` when *entity* has an active stun status.

    Parameters
    ----------
    entity : GameEntity
        Entity to query.
    abs_tick : int
        Current absolute tick used to check expiry.

    Returns
    -------
    bool
        ``True`` when at least one active status has ``stun=True``.
    """
    return any(s.stun and not s.is_expired(abs_tick) for s in entity.status_effects)
