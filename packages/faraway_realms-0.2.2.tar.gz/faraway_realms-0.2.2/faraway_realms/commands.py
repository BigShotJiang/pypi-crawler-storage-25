"""Command parsing — converts raw slash-command strings into Command objects."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class CommandType(Enum):
    """Enumeration of supported command types."""

    MOVE = auto()
    ATTACK = auto()
    OPPORTUNITY_ATTACK = auto()
    TARGET = auto()
    SPAWN = auto()
    PRIME_COOLDOWN = auto()
    CLEAR_PRIME = auto()
    CAST = auto()
    INTERRUPT_CAST = auto()
    UNKNOWN = auto()


@dataclass(frozen=True)
class Command:
    """An immutable parsed game command.

    Parameters
    ----------
    command_type : CommandType
        The type of command.
    actor : str
        Entity name the command targets (e.g. ``"me"``).
    args : tuple[str, ...]
        Additional positional arguments.
    raw : str
        Original unparsed string, preserved for display.
    """

    command_type: CommandType
    actor: str
    args: tuple[str, ...]
    raw: str


def make_attack_command(
    attacker_id: int,
    target_id: int,
    command_type: CommandType = CommandType.ATTACK,
) -> Command:
    """Build an attack-family command.

    Parameters
    ----------
    attacker_id : int
        Entity ID of the attacker.
    target_id : int
        Entity ID of the target.
    command_type : CommandType
        ``ATTACK`` (default) or ``OPPORTUNITY_ATTACK``.

    Returns
    -------
    Command
        An immutable command with *attacker_id* as actor and *target_id* as
        the first arg.
    """
    verb = command_type.name.lower()
    return Command(
        command_type=command_type,
        actor=str(attacker_id),
        args=(str(target_id),),
        raw=f"/{verb} {attacker_id} {target_id}",
    )


def make_prime_cooldown_command(entity_id: int) -> Command:
    """Build a PRIME_COOLDOWN command to initialise an entity's attack cooldown.

    Parameters
    ----------
    entity_id : int
        Entity whose cooldown should be primed.

    Returns
    -------
    Command
        A PRIME_COOLDOWN command with *entity_id* as actor.
    """
    return Command(
        command_type=CommandType.PRIME_COOLDOWN,
        actor=str(entity_id),
        args=(),
        raw=f"/prime_cooldown {entity_id}",
    )


def make_clear_prime_command(entity_id: int) -> Command:
    """Build a CLEAR_PRIME command to reset an entity's attack-cooldown bar.

    Parameters
    ----------
    entity_id : int
        Entity whose cooldown tracking should be cleared.

    Returns
    -------
    Command
        A CLEAR_PRIME command with *entity_id* as actor.
    """
    return Command(
        command_type=CommandType.CLEAR_PRIME,
        actor=str(entity_id),
        args=(),
        raw=f"/clear_prime {entity_id}",
    )


def make_target_command(actor_id: int, target_id: int) -> Command:
    """Build a TARGET command to assign a new target to an entity.

    Parameters
    ----------
    actor_id : int
        Entity ID of the entity acquiring the target.
    target_id : int
        Entity ID of the new target.

    Returns
    -------
    Command
        A TARGET command.
    """
    return Command(
        command_type=CommandType.TARGET,
        actor=str(actor_id),
        args=(str(target_id),),
        raw=f"/target {actor_id} {target_id}",
    )


def make_cast_command(actor_id: int, ability_name: str, target_id: int) -> Command:
    """Build a CAST command.

    Parameters
    ----------
    actor_id : int
        Entity ID of the caster.
    ability_name : str
        Name of the ability to cast.
    target_id : int
        Entity ID of the target.

    Returns
    -------
    Command
        An immutable CAST command.
    """
    return Command(
        command_type=CommandType.CAST,
        actor=str(actor_id),
        args=(ability_name, str(target_id)),
        raw=f"/cast {actor_id} {ability_name} {target_id}",
    )


def make_interrupt_command(actor_id: int) -> Command:
    """Build an INTERRUPT_CAST command.

    Parameters
    ----------
    actor_id : int
        Entity ID whose cast should be interrupted.

    Returns
    -------
    Command
        An immutable INTERRUPT_CAST command.
    """
    return Command(
        command_type=CommandType.INTERRUPT_CAST,
        actor=str(actor_id),
        args=(),
        raw=f"/interrupt {actor_id}",
    )


class CommandParser:
    """Converts a raw slash-command string into a :class:`Command`.

    Examples
    --------
    >>> parser = CommandParser()
    >>> cmd = parser.parse("/move me left")
    >>> cmd.command_type
    <CommandType.MOVE: 1>
    """

    _VERB_TYPES: dict[str, CommandType] = {
        "move": CommandType.MOVE,
        "attack": CommandType.ATTACK,
        "target": CommandType.TARGET,
        "spawn": CommandType.SPAWN,
        "cast": CommandType.CAST,
        "interrupt": CommandType.INTERRUPT_CAST,
    }

    def parse(self, text: str) -> Command:
        """Parse a raw string and return a :class:`Command`.

        Parameters
        ----------
        text : str
            Raw input, optionally prefixed with ``/``.

        Returns
        -------
        Command
            Parsed command, or one with ``CommandType.UNKNOWN`` if unrecognised.
        """
        stripped = text.strip().lstrip("/")
        if not stripped:
            return self._build_unknown(text)
        return self._parse_tokens(stripped.split(), text)

    def _parse_tokens(self, tokens: list[str], raw: str) -> Command:
        command_type = self._VERB_TYPES.get(tokens[0].lower())
        if command_type is None:
            return self._build_unknown(raw)
        return self._build_command(tokens, raw, command_type)

    @staticmethod
    def _build_command(
        tokens: list[str], raw: str, command_type: CommandType
    ) -> Command:
        actor = tokens[1] if len(tokens) > 1 else ""
        args = tuple(tokens[2:])
        return Command(command_type=command_type, actor=actor, args=args, raw=raw)

    @staticmethod
    def _build_unknown(raw: str) -> Command:
        return Command(command_type=CommandType.UNKNOWN, actor="", args=(), raw=raw)
