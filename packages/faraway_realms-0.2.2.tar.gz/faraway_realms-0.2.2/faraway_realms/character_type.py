"""Character type registry — player archetype templates."""

from faraway_realms.creature_type import CreatureType

CHARACTER_REGISTRY: dict[str, CreatureType] = {}
