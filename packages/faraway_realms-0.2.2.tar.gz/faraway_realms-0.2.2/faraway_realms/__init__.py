"""Faraway Realms — a real-time tick-based roguelike RPG."""

__version__ = "0.2.2"
