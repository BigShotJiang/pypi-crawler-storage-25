"""Behaviour conditions — composable predicates for NPC state machine transitions."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

from faraway_realms.behaviour import _find_visible_target
from faraway_realms.map import chebyshev

if TYPE_CHECKING:
    from faraway_realms.behaviour import BehaviourContext


class Condition(ABC):
    """Abstract base for a behaviour condition predicate.

    Conditions are evaluated against live game state each tick to drive
    state machine transitions.
    """

    @abstractmethod
    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when this condition is satisfied.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC being evaluated.
        ctx : BehaviourContext
            Snapshot of game state for this tick.

        Returns
        -------
        bool
            Whether the condition holds.
        """


@dataclass(frozen=True)
class EnemyInSight(Condition):
    """True when a hostile target is within line-of-sight.

    Parameters
    ----------
    sight_range : int
        Tile radius for target detection.
    """

    sight_range: int = 8

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when a visible target exists.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True if any target is visible.
        """
        return _find_visible_target(npc_id, self.sight_range, ctx) is not None


@dataclass(frozen=True)
class EnemyOutOfSight(Condition):
    """True when no hostile targets are within line-of-sight.

    Parameters
    ----------
    sight_range : int
        Tile radius for target detection.
    """

    sight_range: int = 8

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when no visible target exists.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True if no target is visible.
        """
        return _find_visible_target(npc_id, self.sight_range, ctx) is None


@dataclass(frozen=True)
class EnemyAdjacent(Condition):
    """True when any target entity is within Chebyshev distance 1."""

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when a target is adjacent.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True if any target is immediately adjacent.
        """
        pos = ctx.all_positions.get(npc_id)
        if pos is None:
            return False
        return _any_target_adjacent(pos, ctx)


def _any_target_adjacent(pos: tuple[int, int], ctx: "BehaviourContext") -> bool:
    """Return True if any target in ctx is adjacent (Chebyshev ≤ 1) to pos."""
    nx, ny = pos
    for tid in ctx.target_ids:
        tpos = ctx.all_positions.get(tid)
        if tpos is None:
            continue
        tx, ty = tpos
        if chebyshev(nx, ny, tx, ty) <= 1:
            return True
    return False


@dataclass(frozen=True)
class HealthBelow(Condition):
    """True when the NPC's health fraction is below a threshold.

    Parameters
    ----------
    threshold : float
        Fraction in [0, 1]; True when current HP fraction < threshold.
    """

    threshold: float = 0.5

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when hp_fraction is below the threshold.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True when health is critically low.
        """
        return ctx.hp_fraction < self.threshold


@dataclass(frozen=True)
class HealthAbove(Condition):
    """True when the NPC's health fraction is at or above a threshold.

    Parameters
    ----------
    threshold : float
        Fraction in [0, 1]; True when current HP fraction >= threshold.
    """

    threshold: float = 0.5

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when hp_fraction is at or above the threshold.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True when health is healthy.
        """
        return ctx.hp_fraction >= self.threshold


@dataclass(frozen=True)
class AbilityReady(Condition):
    """True when the named ability is not currently on cooldown.

    Parameters
    ----------
    ability_name : str
        Name of the ability to check.
    """

    ability_name: str = ""

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True when ability_name is not in ctx.ability_cooldowns.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC.
        ctx : BehaviourContext
            Game state snapshot.

        Returns
        -------
        bool
            True when the ability can be used.
        """
        return self.ability_name not in ctx.ability_cooldowns


@dataclass(frozen=True)
class Always(Condition):
    """Always returns True regardless of game state."""

    def check(self, npc_id: int, ctx: "BehaviourContext") -> bool:
        """Return True unconditionally.

        Parameters
        ----------
        npc_id : int
            Entity ID of the NPC (unused).
        ctx : BehaviourContext
            Game state snapshot (unused).

        Returns
        -------
        bool
            Always ``True``.
        """
        return True
