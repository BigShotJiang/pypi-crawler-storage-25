"""Base types for the map generation pipeline."""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.creature_type import CreatureType
    from faraway_realms.static_object import StaticObjectType


@dataclass(frozen=True)
class Rect:
    """An axis-aligned rectangle used to represent room bounds.

    Parameters
    ----------
    x : int
        Left column (inclusive).
    y : int
        Top row (inclusive).
    width : int
        Number of columns.
    height : int
        Number of rows.
    """

    x: int
    y: int
    width: int
    height: int

    @property
    def x2(self) -> int:
        """One past the rightmost column (exclusive upper bound)."""
        return self.x + self.width

    @property
    def y2(self) -> int:
        """One past the bottommost row (exclusive upper bound)."""
        return self.y + self.height

    @property
    def center(self) -> tuple[int, int]:
        """Return the centre tile of the rectangle."""
        return (self.x + self.width // 2, self.y + self.height // 2)

    def intersects(self, other: Rect) -> bool:
        """Return True if this rectangle overlaps *other*.

        Parameters
        ----------
        other : Rect
            Rectangle to test against.

        Returns
        -------
        bool
            True when the two rectangles share at least one tile.
        """
        h_overlap = self.x < other.x2 and self.x2 > other.x
        return h_overlap and self.y < other.y2 and self.y2 > other.y


@dataclass
class MapGenResult:
    """Output of a map generation run.

    Parameters
    ----------
    map : faraway_realms.map.Map
        The fully constructed game map.
    rooms : list[Rect]
        All rooms carved into the map, ordered by creation.
        The first room holds the recommended player starting position.
    player_start : tuple[int, int]
        Walkable (x, y) tile suitable for placing the player.
    creature_placements : list[tuple[CreatureType, int, int]]
        Creature type and (x, y) position for each NPC to spawn.
        Populated by :class:`CreaturePopulationPass` after generation.
    """

    from faraway_realms.map import Map  # local import to avoid circular deps

    map: Map
    rooms: list[Rect]
    player_start: tuple[int, int]
    creature_placements: list[tuple[CreatureType, int, int]] = field(
        default_factory=list
    )
    static_object_placements: list[tuple[StaticObjectType, int, int]] = field(
        default_factory=list
    )


class PopulationPass(ABC):
    """Abstract base for a post-generation population step.

    After ``CaveGenerator.generate`` returns a :class:`MapGenResult`,
    one or more ``PopulationPass`` instances can be applied in sequence
    to place creatures, items, or other content.  Each pass receives the
    full generation result and a seeded RNG so that runs are repeatable.
    """

    @abstractmethod
    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate the world from the generation result.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
