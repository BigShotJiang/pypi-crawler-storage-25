"""Cave map generator — carves rooms and corridors into solid rock."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.map import Map
from faraway_realms.mapgen.base import MapGenResult, Rect
from faraway_realms.tile import cave_floor_tile, cave_wall_tile


def _padded(rect: Rect, amount: int = 1) -> Rect:
    """Return *rect* expanded by *amount* tiles on every side."""
    return Rect(
        rect.x - amount,
        rect.y - amount,
        rect.width + 2 * amount,
        rect.height + 2 * amount,
    )


def _carve(game_map: Map, x: int, y: int) -> None:
    """Carve a single tile, leaving the map border intact."""
    if 0 < x < game_map.width - 1 and 0 < y < game_map.height - 1:
        game_map.set_tile(x, y, cave_floor_tile())


@dataclass
class CaveGenerator:
    """Generates a cave map by carving rooms and corridors into solid rock.

    Rooms are rectangular, placed randomly without overlapping (with a
    1-tile rock buffer between them).  Consecutive rooms are connected by
    L-shaped corridors that are always **2 tiles wide** so the player has
    room to manoeuvre and cardinal-only movement never produces dead-end
    single-tile passages.

    Parameters
    ----------
    max_rooms : int
        Upper bound on the number of rooms to attempt.  Rooms that would
        overlap an existing room are skipped, so the actual count may be
        lower.
    room_min_size : int
        Minimum interior dimension (both width and height) of a room.
        Must be ≥ 4 to leave meaningful space for encounters.
    room_max_size : int
        Maximum interior dimension of a room.
    """

    max_rooms: int = 30
    room_min_size: int = 4
    room_max_size: int = 10

    def generate(self, width: int, height: int, rng: random.Random) -> MapGenResult:
        """Build and return a cave map.

        Parameters
        ----------
        width : int
            Map width in tiles.
        height : int
            Map height in tiles.
        rng : random.Random
            Seeded RNG used for all random choices so output is
            reproducible given the same seed.

        Returns
        -------
        MapGenResult
            The generated map, the list of carved rooms, and the
            recommended player starting position (centre of first room).
        """
        tiles = [[cave_wall_tile() for _ in range(width)] for _ in range(height)]
        game_map = Map(width, height, tiles)
        rooms: list[Rect] = []
        for _ in range(self.max_rooms):
            room = self._random_room(width, height, rng)
            if not any(_padded(room).intersects(r) for r in rooms):
                self._carve_room(game_map, room)
                if rooms:
                    self._connect(game_map, rooms[-1], room)
                rooms.append(room)
        start = rooms[0].center if rooms else (width // 2, height // 2)
        return MapGenResult(map=game_map, rooms=rooms, player_start=start)

    def _random_room(self, width: int, height: int, rng: random.Random) -> Rect:
        w = rng.randint(self.room_min_size, self.room_max_size)
        h = rng.randint(self.room_min_size, self.room_max_size)
        x = rng.randint(1, width - w - 1)
        y = rng.randint(1, height - h - 1)
        return Rect(x, y, w, h)

    def _carve_room(self, game_map: Map, room: Rect) -> None:
        for ry in range(room.y, room.y2):
            for rx in range(room.x, room.x2):
                _carve(game_map, rx, ry)

    def _connect(self, game_map: Map, a: Rect, b: Rect) -> None:
        """Connect two rooms with a 2-wide L-shaped corridor."""
        cx1, cy1 = a.center
        cx2, cy2 = b.center
        self._h_tunnel(game_map, cx1, cx2, cy1)
        self._v_tunnel(game_map, cy1, cy2, cx2)

    def _h_tunnel(self, game_map: Map, x1: int, x2: int, y: int) -> None:
        """Carve a 2-tile-tall horizontal passage from x1 to x2 at row y."""
        for xi in range(min(x1, x2), max(x1, x2) + 1):
            for dy in range(2):
                _carve(game_map, xi, y + dy)

    def _v_tunnel(self, game_map: Map, y1: int, y2: int, x: int) -> None:
        """Carve a 2-tile-wide vertical passage from y1 to y2 at column x."""
        for yi in range(min(y1, y2), max(y1, y2) + 1):
            for dx in range(2):
                _carve(game_map, x + dx, yi)
