"""Map generation pipeline — generators and population passes."""

from faraway_realms.mapgen.base import MapGenResult, PopulationPass, Rect
from faraway_realms.mapgen.cave import CaveGenerator
from faraway_realms.mapgen.creature_pass import CreaturePopulationPass
from faraway_realms.mapgen.static_object_pass import StaticObjectPopulationPass
from faraway_realms.mapgen.texture import (
    MOSS_OVERLAY,
    TILE_OVERLAY_REGISTRY,
    TILE_TYPE_PATCH_REGISTRY,
    NoiseTexturePass,
    TileOverlay,
    TileTypePatch,
)

__all__ = [
    "CaveGenerator",
    "CreaturePopulationPass",
    "MapGenResult",
    "MOSS_OVERLAY",
    "NoiseTexturePass",
    "PopulationPass",
    "Rect",
    "StaticObjectPopulationPass",
    "TILE_OVERLAY_REGISTRY",
    "TILE_TYPE_PATCH_REGISTRY",
    "TileOverlay",
    "TileTypePatch",
]
