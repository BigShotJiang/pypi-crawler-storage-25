"""Creature population pass — places NPCs from the creature registry into rooms."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from faraway_realms.creature_type import CREATURE_REGISTRY
from faraway_realms.mapgen.base import MapGenResult, PopulationPass


def _by_labels(
    labels: tuple[str, ...],
) -> list:
    """Return registry entries matching any of the given labels.

    Parameters
    ----------
    labels : tuple[str, ...]
        If non-empty, only types carrying at least one of these labels are
        returned.  Empty tuple returns all types.

    Returns
    -------
    list
        Matching :class:`~faraway_realms.creature_type.CreatureType` instances.
    """
    types = list(CREATURE_REGISTRY.values())
    if not labels:
        return types
    label_set = set(labels)
    return [ct for ct in types if ct.labels & label_set]


@dataclass
class CreaturePopulationPass(PopulationPass):
    """Place one creature per non-player room, drawn from the creature registry.

    Parameters
    ----------
    labels : tuple[str, ...]
        If non-empty, only creature types carrying at least one of these
        labels are eligible.  Empty tuple means all types are eligible.
    """

    labels: tuple[str, ...] = field(default_factory=tuple)

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate rooms with creatures from the registry.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
        types = _by_labels(self.labels)
        if not types:
            return
        for room in result.rooms[1:]:  # rooms[0] is the player start room
            ct = rng.choice(types)  # noqa: S311 — game logic, not crypto
            cx, cy = room.center
            result.creature_placements.append((ct, cx, cy))
