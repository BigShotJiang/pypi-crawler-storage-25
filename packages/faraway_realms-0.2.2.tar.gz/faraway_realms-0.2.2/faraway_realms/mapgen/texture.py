"""Noise-based tile texture pass — colour variation and composable overlays."""

from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np
import tcod.noise

from faraway_realms.color import lerp_color as _lerp_color
from faraway_realms.mapgen.base import MapGenResult, PopulationPass
from faraway_realms.tile import TILE_REGISTRY, Tile


@dataclass(frozen=True)
class TileOverlay:
    """A noise-driven colour compositing rule for :class:`NoiseTexturePass`.

    Each overlay is evaluated on an independent slice of the noise field
    (controlled by ``noise_offset``), so overlays occupy different regions
    of the map rather than always coinciding.

    Parameters
    ----------
    floor_bg : tuple[int, int, int]
        Background colour for walkable tiles that match this overlay.
    floor_fg : tuple[int, int, int]
        Foreground colour for walkable tiles.
    wall_bg : tuple[int, int, int]
        Background colour for non-walkable tiles.
    wall_fg : tuple[int, int, int]
        Foreground colour for non-walkable tiles.
    threshold : float
        Normalised noise value (0–1) above which this overlay is applied.
        Lower = larger / more frequent patches.
    noise_offset : float
        Spatial coordinate offset added before sampling the noise field.
        Use distinct values (e.g. 0, 500, 1000) so each overlay draws
        from a different, decorrelated region of the noise space.
    blend : bool
        When ``True``, tile colours are linearly interpolated between the
        base tile and the overlay colours based on how far above
        ``threshold`` the noise value is.  Tiles at the patch centre get
        the full overlay colour; tiles near the edge fade in organically.
        When ``False`` (default), the overlay colour is applied flat.
    description : str or None
        Short modifier string for a future inspect system (e.g. ``"mossy"``).
        Concatenated with the underlying tile description when reporting
        tile composition to the player.
    char : int or None
        When set, overrides the display glyph codepoint of covered tiles
        (e.g. ``ord(",")`` for moss-carpeted floors, or ``URIZEN_BASE + N``
        for a Urizen sprite).  When ``None``, the underlying tile's glyph is
        preserved.
    """

    floor_bg: tuple[int, int, int]
    floor_fg: tuple[int, int, int]
    wall_bg: tuple[int, int, int]
    wall_fg: tuple[int, int, int]
    threshold: float = 0.75
    noise_offset: float = 0.0
    blend: bool = False
    description: str | None = None
    char: int | None = None


@dataclass(frozen=True)
class TileTypePatch:
    """A noise-driven tile *type replacement* rule for :class:`NoiseTexturePass`.

    Unlike :class:`TileOverlay` (which composites colour on top of an
    existing tile), a patch replaces tiles wholesale with named types from
    :data:`~faraway_realms.tile.TILE_REGISTRY`.  This preserves the full
    semantic identity of the tile — its name, description, and any future
    properties — rather than just recolouring it.

    Use this for materials that are genuinely different from the base tile
    (e.g. gray rock seams, quartz veins).  Use :class:`TileOverlay` for
    environmental modifiers that sit *on top of* a tile (moss, slime, frost).

    Parameters
    ----------
    floor : str
        :data:`~faraway_realms.tile.TILE_REGISTRY` key for the replacement
        walkable tile (e.g. ``"cave_gray_rock_floor"``).
    wall : str
        Registry key for the replacement non-walkable tile.
    threshold : float
        Noise threshold above which the patch is applied.  Default ``0.72``.
    noise_offset : float
        Spatial decorrelation offset.  Default ``0.0``.
    """

    floor: str
    wall: str
    threshold: float = 0.72
    noise_offset: float = 0.0


# Populated at startup by content_parsers.tiles.parse_tile_overlays.
TILE_OVERLAY_REGISTRY: dict[str, TileOverlay] = {}

# Populated at startup by content_parsers.tiles.parse_tile_type_patches.
TILE_TYPE_PATCH_REGISTRY: dict[str, TileTypePatch] = {}


# ---------------------------------------------------------------------------
# Pre-built overlay (kept for direct import in tests and documentation)
# ---------------------------------------------------------------------------

MOSS_OVERLAY = TileOverlay(
    floor_bg=(38, 58, 18),
    floor_fg=(95, 135, 48),
    wall_bg=(20, 35, 10),
    wall_fg=(50, 75, 28),
    threshold=0.75,
    noise_offset=0.0,
    blend=True,
    description="mossy",
)
"""Damp mossy patches — green-tinted floor and wall tiles, fading at edges."""


# ---------------------------------------------------------------------------
# Tile helpers
# ---------------------------------------------------------------------------


def _clamp(v: int) -> int:
    return max(0, min(255, v))


def _shift_color(color: tuple[int, int, int], shift: int) -> tuple[int, int, int]:
    return (
        _clamp(color[0] + shift),
        _clamp(color[1] + shift),
        _clamp(color[2] + shift),
    )


def _shifted_tile(tile: Tile, v: float, strength: float) -> Tile:
    """Return *tile* with colours shifted by a noise-derived amount."""
    shift = int((v - 0.5) * 2.0 * strength * 255)
    return Tile(
        walkable=tile.walkable,
        bg_color=_shift_color(tile.bg_color, shift),
        fg_color=_shift_color(tile.fg_color, shift),
        char=tile.char,
    )


def _patch_tile(tile: Tile, patch: TileTypePatch) -> Tile:
    """Return a tile built from the registry type referenced by *patch*."""
    tile_key = patch.floor if tile.walkable else patch.wall
    tt = TILE_REGISTRY[tile_key]
    return Tile(
        walkable=tile.walkable, bg_color=tt.bg_color, fg_color=tt.fg_color, char=tt.char
    )


def _overlay_tile(tile: Tile, overlay: TileOverlay) -> Tile:
    """Return a tile coloured by *overlay*, preserving walkability."""
    char = overlay.char if overlay.char is not None else tile.char
    if tile.walkable:
        return Tile(
            walkable=True,
            bg_color=overlay.floor_bg,
            fg_color=overlay.floor_fg,
            char=char,
        )
    return Tile(
        walkable=False, bg_color=overlay.wall_bg, fg_color=overlay.wall_fg, char=char
    )


def _blend_overlay_tile(tile: Tile, overlay: TileOverlay, t: float) -> Tile:
    """Return *tile* with overlay colours blended at factor *t* (0=base, 1=overlay)."""
    char = overlay.char if overlay.char is not None else tile.char
    if tile.walkable:
        return Tile(
            walkable=True,
            bg_color=_lerp_color(tile.bg_color, overlay.floor_bg, t),
            fg_color=_lerp_color(tile.fg_color, overlay.floor_fg, t),
            char=char,
        )
    return Tile(
        walkable=False,
        bg_color=_lerp_color(tile.bg_color, overlay.wall_bg, t),
        fg_color=_lerp_color(tile.fg_color, overlay.wall_fg, t),
        char=char,
    )


# ---------------------------------------------------------------------------
# Pass
# ---------------------------------------------------------------------------


@dataclass
class NoiseTexturePass(PopulationPass):
    """Vary tile colours with Simplex noise and apply composable overlays.

    Two effect types are layered over the generated cave:

    1. **Tile type patches** — noise-driven *material replacement*.  Tiles in
       matching regions are replaced wholesale by named tile types from
       :data:`~faraway_realms.tile.TILE_REGISTRY` (e.g. gray rock seams).
       Patches form the absolute base layer.

    2. **Colour overlays** — composited colour effects on top of the base.
       Non-blended overlays (``blend=False``) replace colours flat; blended
       overlays (``blend=True``, e.g. moss) interpolate toward overlay colours
       at patch centres, fading organically at edges.

    Rendering order: patches → non-blended overlays → blended overlays →
    colour shift (applied only to tiles untouched by any of the above).

    When ``patches`` or ``overlays`` is ``None`` (the default), the pass reads
    from :data:`TILE_TYPE_PATCH_REGISTRY` / :data:`TILE_OVERLAY_REGISTRY`
    respectively.  Pass an explicit tuple (including ``()``) to bypass the
    registries entirely — useful in tests.

    Parameters
    ----------
    scale : float
        Noise frequency.  Smaller → larger smoother blobs.  Default ``0.06``.
    strength : float
        Peak colour-shift magnitude as a fraction of 255 for the base
        variation.  Default ``0.15``.
    overlays : tuple[TileOverlay, ...] or None
        Overlay rules.  ``None`` reads from :data:`TILE_OVERLAY_REGISTRY`.
    patches : tuple[TileTypePatch, ...] or None
        Patch rules.  ``None`` reads from :data:`TILE_TYPE_PATCH_REGISTRY`.
    seed : int
        Explicit noise seed.  ``0`` derives the seed from the generation
        RNG passed to :meth:`apply`, keeping the full run reproducible.
    """

    scale: float = 0.06
    strength: float = 0.15
    overlays: tuple[TileOverlay, ...] | None = None
    patches: tuple[TileTypePatch, ...] | None = None
    seed: int = 0

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Texture every tile in *result.map* in-place.

        Parameters
        ----------
        result : MapGenResult
            Generation result whose map tiles will be mutated.
        rng : random.Random
            Generation RNG, used to derive the noise seed when ``seed == 0``.
        """
        noise = tcod.noise.Noise(dimensions=2, seed=self._resolve_seed(rng))
        base_grid = self._sample_grid(noise, result.map.width, result.map.height, 0.0)

        eff_patches = (
            self.patches
            if self.patches is not None
            else tuple(TILE_TYPE_PATCH_REGISTRY.values())
        )
        eff_overlays = (
            self.overlays
            if self.overlays is not None
            else tuple(TILE_OVERLAY_REGISTRY.values())
        )

        patch_idx = self._resolve_patches(
            noise, result.map.width, result.map.height, eff_patches
        )
        base_idx, blend_idx, blend_fac = self._resolve_overlays(
            noise, result.map.width, result.map.height, eff_overlays
        )

        for y in range(result.map.height):
            for x in range(result.map.width):
                result.map.set_tile(
                    x,
                    y,
                    self._texture_tile(
                        result.map.get_tile(x, y),
                        float(base_grid[y, x]),
                        int(patch_idx[y, x]),
                        int(base_idx[y, x]),
                        int(blend_idx[y, x]),
                        float(blend_fac[y, x]),
                        eff_patches,
                        eff_overlays,
                    ),
                )

    def _texture_tile(
        self,
        tile: Tile,
        bv: float,
        pi: int,
        oi: int,
        bdi: int,
        bdf: float,
        patches: tuple[TileTypePatch, ...],
        overlays: tuple[TileOverlay, ...],
    ) -> Tile:
        if pi >= 0:
            under = _patch_tile(tile, patches[pi])
        elif oi >= 0:
            under = _overlay_tile(tile, overlays[oi])
        else:
            under = _shifted_tile(tile, bv, self.strength)
        return _blend_overlay_tile(under, overlays[bdi], bdf) if bdi >= 0 else under

    def _resolve_seed(self, rng: random.Random) -> int:
        if self.seed != 0:
            return self.seed
        return rng.randint(1, 2**31 - 1)  # noqa: S311 — game logic, not crypto

    def _sample_grid(
        self, noise: tcod.noise.Noise, width: int, height: int, offset: float
    ) -> np.ndarray:
        y_i, x_i = np.mgrid[0:height, 0:width]
        raw = noise[
            (x_i * self.scale + offset).astype(np.float32),
            (y_i * self.scale + offset).astype(np.float32),
        ]
        return (np.asarray(raw, dtype=np.float32) + 1.0) / 2.0

    def _resolve_patches(
        self,
        noise: tcod.noise.Noise,
        width: int,
        height: int,
        patches: tuple[TileTypePatch, ...],
    ) -> np.ndarray:
        """Return per-cell patch indices (-1 = no patch)."""
        patch_idx = np.full((height, width), -1, dtype=np.int8)
        for i, patch in enumerate(patches):
            grid = self._sample_grid(noise, width, height, patch.noise_offset)
            above = grid > patch.threshold
            patch_idx[above & (patch_idx == -1)] = i
        return patch_idx

    def _resolve_overlays(
        self,
        noise: tcod.noise.Noise,
        width: int,
        height: int,
        overlays: tuple[TileOverlay, ...],
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (base_indices, blend_indices, blend_factors) per cell.

        Non-blended overlays populate *base_indices*; blended overlays
        populate *blend_indices* and are composited on top of the base layer.
        Each layer uses first-match-wins within its own group.
        """
        base_idx = np.full((height, width), -1, dtype=np.int8)
        blend_idx = np.full((height, width), -1, dtype=np.int8)
        blend_fac = np.zeros((height, width), dtype=np.float32)
        for i, overlay in enumerate(overlays):
            grid = self._sample_grid(noise, width, height, overlay.noise_offset)
            above = grid > overlay.threshold
            if overlay.blend:
                mask = above & (blend_idx == -1)
                blend_idx[mask] = i
                blend_fac[mask] = self._blend_factors(grid, overlay)[mask]
            else:
                base_idx[above & (base_idx == -1)] = i
        return base_idx, blend_idx, blend_fac

    @staticmethod
    def _blend_factors(grid: np.ndarray, overlay: TileOverlay) -> np.ndarray:
        """Return per-cell blend factors for *overlay* given *grid* values."""
        above = (grid - overlay.threshold).clip(0, None)
        return (above / max(1.0 - overlay.threshold, 1e-6)).clip(0.0, 1.0)
