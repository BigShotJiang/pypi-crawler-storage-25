"""Static object population pass — places decorations from the registry."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from faraway_realms.mapgen.base import MapGenResult, PopulationPass
from faraway_realms.static_object import STATIC_OBJECT_REGISTRY


def _by_labels(
    labels: tuple[str, ...],
) -> list:
    """Return registry entries matching any of the given labels.

    Parameters
    ----------
    labels : tuple[str, ...]
        If non-empty, only types carrying at least one of these labels are
        returned.  Empty tuple returns all types.

    Returns
    -------
    list
        Matching :class:`~faraway_realms.static_object.StaticObjectType`
        instances.
    """
    types = list(STATIC_OBJECT_REGISTRY.values())
    if not labels:
        return types
    label_set = set(labels)
    return [sot for sot in types if sot.labels & label_set]


@dataclass
class StaticObjectPopulationPass(PopulationPass):
    """Place static objects (torches, mushrooms, …) drawn from the registry.

    Each non-player room has a *density* probability of receiving one object.
    The object type is chosen randomly from all matching registry entries.

    Parameters
    ----------
    labels : tuple[str, ...]
        If non-empty, only types carrying at least one of these labels are
        eligible.  Empty tuple means all types are eligible.
    density : float
        Probability [0, 1] that any given room receives an object.
        Default 0.4 places objects in roughly 2 out of every 5 rooms.
    """

    labels: tuple[str, ...] = field(default_factory=tuple)
    density: float = 0.4

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate rooms with static objects from the registry.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
        types = _by_labels(self.labels)
        if not types:
            return
        for room in result.rooms[1:]:  # rooms[0] is the player start room
            if rng.random() > self.density:
                continue
            sot = rng.choice(types)  # noqa: S311 — game logic, not crypto
            cx, cy = room.center
            result.static_object_placements.append((sot, cx, cy))
