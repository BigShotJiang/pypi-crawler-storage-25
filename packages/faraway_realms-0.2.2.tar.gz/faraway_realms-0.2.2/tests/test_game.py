from faraway_realms.abilities import ABILITY_REGISTRY
from faraway_realms.commands import (
    Command,
    CommandParser,
    CommandType,
    make_cast_command,
)
from faraway_realms.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.events import EventType
from faraway_realms.factions import FactionRelations
from faraway_realms.game import Game
from faraway_realms.map import make_bordered_map
from faraway_realms.stats import Pool, Stat

# Registry is populated by conftest.py before this module is imported.
BITE = ABILITY_REGISTRY["bite"]
KICK = ABILITY_REGISTRY["kick"]
FIREBOLT = ABILITY_REGISTRY["firebolt"]


def _make_game() -> tuple[Game, Player]:
    game_map = make_bordered_map(10, 10)
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 5, 5)
    return game, player


def test_enqueue_and_tick_move():
    game, _ = _make_game()
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move me left"))
    game.tick()
    assert game.game_map.get_entity_position(1) == (4, 5)


def test_move_blocked_by_wall():
    game, _ = _make_game()
    game.game_map.place_entity(1, 1, 1)  # move to near left wall
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move me left"))
    game.tick()
    assert game.game_map.get_entity_position(1) == (1, 1)


def test_chat_history_append():
    game, _ = _make_game()
    game.add_chat_message("hello")
    game.add_chat_message("world")
    history = game.get_chat_history()
    assert [m.text for m in history] == ["hello", "world"]


def test_get_chat_history_limit():
    game, _ = _make_game()
    for i in range(10):
        game.add_chat_message(str(i))
    assert len(game.get_chat_history(last_n=3)) == 3


def test_add_player():
    game_map = make_bordered_map(5, 5)
    game = Game(game_map=game_map)
    entity = CharacterEntity(
        entity_id=2, char=ord("@"), fg_color=(255, 255, 255), name="Alt"
    )
    player = Player(username="alt", entity=entity)
    game.add_player(player)
    assert game._players["alt"] is player  # noqa: SLF001


def test_tick_drains_queue():
    game, _ = _make_game()
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move me right"))
    game.tick()
    assert game._command_queue == []  # noqa: SLF001


def test_invalid_direction_is_noop():
    game, _ = _make_game()
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move me sideways"))
    game.tick()  # should not raise
    assert game.game_map.get_entity_position(1) == (5, 5)  # unchanged


def test_empty_tick_does_not_raise():
    game_map = make_bordered_map(5, 5)
    game = Game(game_map=game_map)
    game.tick()  # no players, no NPCs — must not raise


def test_player_cannot_move_onto_occupied_tile():
    game, _ = _make_game()
    npc = NonPlayerEntity(
        entity_id=2, char=ord("Z"), fg_color=(0, 180, 0), name="Zombie"
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 4, 5)  # one tile left of player
    parser = CommandParser()
    game.enqueue_command(parser.parse("/move me left"))
    game.tick()
    assert game.game_map.get_entity_position(1) == (5, 5)  # player did not move


def _make_combat_game() -> tuple[Game, Player, NonPlayerEntity]:
    """Game with a hostile NPC adjacent to the player."""
    game_map = make_bordered_map(20, 20)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        attack_every=30,
        stats={"health": Pool(base=50), "strength": Stat(base=3)},
    )
    game.add_npc(npc)
    game_map.place_entity(npc.entity_id, 11, 10)  # adjacent right of player
    return game, player, npc


def test_drain_attack_anim_events_records_hit():
    game, player, npc = _make_combat_game()
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor=str(player.entity.entity_id),
            args=(str(npc.entity_id),),
            raw="",
        )
    )
    game.tick()
    evts = game.drain_attack_anim_events()
    assert len(evts) == 1
    from_pos, to_pos, color = evts[0]
    assert from_pos == (10, 10)
    assert to_pos == (11, 10)
    assert color == player.entity.fg_color


def test_drain_attack_anim_events_clears_after_drain():
    game, player, npc = _make_combat_game()
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor=str(player.entity.entity_id),
            args=(str(npc.entity_id),),
            raw="",
        )
    )
    game.tick()
    game.drain_attack_anim_events()
    assert game.drain_attack_anim_events() == []


def _attack_cmd(actor_id: int, target_id: int) -> Command:
    return Command(
        command_type=CommandType.ATTACK,
        actor=str(actor_id),
        args=(str(target_id),),
        raw="",
    )


def test_drain_blood_events_records_hit():
    game, player, npc = _make_combat_game()
    game.enqueue_command(_attack_cmd(player.entity.entity_id, npc.entity_id))
    game.tick()
    evts = game.drain_blood_events()
    assert len(evts) == 1
    evt = evts[0]
    assert evt.target_pos == (11, 10)
    assert evt.attacker_pos == (10, 10)
    assert len(evt.landing_positions) == 3


def test_no_blood_event_for_no_blood_creature():
    game, player, npc = _make_combat_game()
    npc.blood_color = None  # type: ignore[misc]
    game.enqueue_command(_attack_cmd(player.entity.entity_id, npc.entity_id))
    game.tick()
    assert game.drain_blood_events() == []


def test_blood_map_accumulates_across_hits():
    game, player, npc = _make_combat_game()
    game.enqueue_command(_attack_cmd(player.entity.entity_id, npc.entity_id))
    game.tick()
    count_first = len(game.blood_map.tiles)
    # Force cooldown reset so next attack lands
    game._combat._last_attack_tick[player.entity.entity_id] = 0  # noqa: SLF001
    game.enqueue_command(_attack_cmd(player.entity.entity_id, npc.entity_id))
    game.tick()
    assert len(game.blood_map.tiles) >= count_first


# ---------------------------------------------------------------------------
# Casting system integration tests
# ---------------------------------------------------------------------------


def _make_cast_game():
    """Game with a caster adjacent to a target, both with health."""
    game_map = make_bordered_map(20, 20)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
        abilities={KICK.name: KICK, BITE.name: BITE},
    )
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=50)},
    )
    game.add_npc(npc)
    game_map.place_entity(npc.entity_id, 11, 10)  # adjacent
    return game, player, npc


def test_cast_command_fires_instant_ability():
    game, player, npc = _make_cast_game()
    cmd = make_cast_command(player.entity.entity_id, "kick", npc.entity_id)
    game.enqueue_command(cmd)
    npc_x_before, npc_y_before = game.game_map.get_entity_position(npc.entity_id)
    game.tick()
    # KICK has knockback — target should have moved right
    npc_x_after, _ = game.game_map.get_entity_position(npc.entity_id)
    assert npc_x_after > npc_x_before


def test_cast_command_with_cast_time_delayed():
    game, player, npc = _make_cast_game()
    # BITE has cast_time=10; cast at tick 1
    cmd = make_cast_command(player.entity.entity_id, "bite", npc.entity_id)
    game.enqueue_command(cmd)
    hp_before = npc.stats["health"].current
    game.tick()  # tick 1 — cast started, event queued for tick 11
    # HP should not have changed yet
    assert npc.stats["health"].current == hp_before


def test_cast_complete_applies_damage():
    game, player, npc = _make_cast_game()
    cmd = make_cast_command(player.entity.entity_id, "bite", npc.entity_id)
    game.enqueue_command(cmd)
    hp_before = npc.stats["health"].current
    # Advance 11 ticks to resolve the cast (cast_time=10, emitted at tick 1)
    for _ in range(11):
        game.tick()
    assert npc.stats["health"].current < hp_before


def test_cast_complete_logs_bite_message():
    game, player, npc = _make_cast_game()
    cmd = make_cast_command(player.entity.entity_id, "bite", npc.entity_id)
    game.enqueue_command(cmd)
    for _ in range(11):
        game.tick()
    history = game.get_chat_history()
    texts = [m.text for m in history]
    assert any("sinks its teeth" in t for t in texts)


def test_cast_no_effect_when_out_of_range():
    game, player, npc = _make_cast_game()
    # Move target far away
    game.game_map.place_entity(npc.entity_id, 18, 18)
    cmd = make_cast_command(player.entity.entity_id, "kick", npc.entity_id)
    game.enqueue_command(cmd)
    game.tick()
    # No events should have been emitted (out of range)
    assert game._event_queue == []  # noqa: SLF001


def test_interrupt_clears_pending_cast_events():
    game, player, npc = _make_cast_game()
    cmd = make_cast_command(player.entity.entity_id, "bite", npc.entity_id)
    game.enqueue_command(cmd)
    game.tick()  # cast started, CAST_COMPLETE queued for future
    # Interrupt
    from faraway_realms.commands import make_interrupt_command

    game.enqueue_command(make_interrupt_command(player.entity.entity_id))
    game.tick()
    # Event queue should have no CAST_COMPLETE for player
    cast_events = [
        e
        for e in game._event_queue  # noqa: SLF001
        if e.event_type == EventType.CAST_COMPLETE
        and e.source_id == player.entity.entity_id
    ]
    assert cast_events == []


# ---------------------------------------------------------------------------
# Projectile integration
# ---------------------------------------------------------------------------


def _make_projectile_game():
    """Game with a caster at (5,10) and a target at (12,10) — within firebolt range."""
    game_map = make_bordered_map(20, 20)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={
            "health": Pool(base=100),
            "strength": Stat(base=5),
            "mana": Pool(base=100),
        },
        abilities={FIREBOLT.name: FIREBOLT},
    )
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 5, 10)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=80)},
    )
    game.add_npc(npc)
    game_map.place_entity(npc.entity_id, 12, 10)
    return game, player, npc


def test_firebolt_cast_spawns_projectile():
    game, player, npc = _make_projectile_game()
    cmd = make_cast_command(player.entity.entity_id, "firebolt", npc.entity_id)
    game.enqueue_command(cmd)
    game.tick()
    assert len(game.active_projectiles) == 1


def test_firebolt_projectile_reaches_target_and_damages():
    game, player, npc = _make_projectile_game()
    cmd = make_cast_command(player.entity.entity_id, "firebolt", npc.entity_id)
    game.enqueue_command(cmd)
    hp_before = npc.stats["health"].current
    for _ in range(20):  # enough ticks to reach target
        game.tick()
    hp_after = npc.stats["health"].current
    assert hp_after < hp_before


def test_firebolt_deducts_mana():
    game, player, npc = _make_projectile_game()
    mana_before = player.entity.stats["mana"].current
    cmd = make_cast_command(player.entity.entity_id, "firebolt", npc.entity_id)
    game.enqueue_command(cmd)
    game.tick()
    mana_after = player.entity.stats["mana"].current
    assert mana_after == mana_before - 15


# ---------------------------------------------------------------------------
# Mana regeneration
# ---------------------------------------------------------------------------


def test_mana_regenerates_each_tick():
    game_map = make_bordered_map(10, 10)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"mana": Pool(base=100, regen_per_tick=2)},
    )
    entity.stats["mana"].current = 50  # type: ignore[union-attr]
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 5, 5)
    game.tick()
    assert entity.stats["mana"].current == 52  # type: ignore[union-attr]


def test_mana_does_not_exceed_max():
    game_map = make_bordered_map(10, 10)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"mana": Pool(base=100, regen_per_tick=50)},
    )
    player = Player(username="tester", entity=entity)
    game = Game(game_map=game_map)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 5, 5)
    game.tick()
    # Pool.modify clamps at max
    assert entity.stats["mana"].current <= 100  # type: ignore[union-attr]
