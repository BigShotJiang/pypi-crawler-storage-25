"""Tests for melee attack animation helpers in faraway_realms.ui.effects."""

import tcod.tileset

from faraway_realms.ui.effects import (
    _VERT_CHAR,
    MeleeAttackAnimation,
    _swing_char,
    _swing_tiles,
)

# ---------------------------------------------------------------------------
# _swing_char
# ---------------------------------------------------------------------------


def test_swing_char_horizontal_right():
    assert _swing_char(1, 0) == ord("-")


def test_swing_char_horizontal_left():
    assert _swing_char(-1, 0) == ord("-")


def test_swing_char_vertical_down():
    assert _swing_char(0, 1) == _VERT_CHAR
    assert _VERT_CHAR == tcod.tileset.CHARMAP_CP437[179]


def test_swing_char_vertical_up():
    assert _swing_char(0, -1) == _VERT_CHAR


def test_swing_char_diagonal_backslash_down_right():
    assert _swing_char(1, 1) == ord("\\")


def test_swing_char_diagonal_backslash_up_left():
    assert _swing_char(-1, -1) == ord("\\")


def test_swing_char_diagonal_slash_up_right():
    assert _swing_char(1, -1) == ord("/")


def test_swing_char_diagonal_slash_down_left():
    assert _swing_char(-1, 1) == ord("/")


# ---------------------------------------------------------------------------
# _swing_tiles
# ---------------------------------------------------------------------------


def test_swing_tiles_adjacent_horizontal():
    assert _swing_tiles(3, 3, 4, 3) == [(3, 3), (4, 3)]


def test_swing_tiles_adjacent_vertical():
    assert _swing_tiles(3, 3, 3, 4) == [(3, 3), (3, 4)]


def test_swing_tiles_adjacent_diagonal():
    assert _swing_tiles(3, 3, 4, 4) == [(3, 3), (4, 4)]


def test_swing_tiles_same_position():
    assert _swing_tiles(3, 3, 3, 3) == [(3, 3)]


# ---------------------------------------------------------------------------
# MeleeAttackAnimation
# ---------------------------------------------------------------------------


def test_animation_initially_active():
    anim = MeleeAttackAnimation(
        tiles=[(0, 0), (1, 0)], char=ord("-"), color=(255, 255, 255)
    )
    assert anim.active


def test_animation_expires_after_all_frames():
    anim = MeleeAttackAnimation(
        tiles=[(0, 0)], char=ord("-"), color=(255, 255, 255), frames_per_tile=2
    )
    anim.advance()
    assert anim.active
    anim.advance()
    assert not anim.active


def test_animation_current_tile_advances():
    anim = MeleeAttackAnimation(
        tiles=[(1, 2), (3, 4)], char=ord("-"), color=(0, 0, 0), frames_per_tile=1
    )
    assert anim.current_tile() == (1, 2)
    anim.advance()
    assert anim.current_tile() == (3, 4)
    anim.advance()
    assert anim.current_tile() is None


def test_animation_current_tile_respects_frames_per_tile():
    anim = MeleeAttackAnimation(
        tiles=[(1, 2), (3, 4)], char=ord("-"), color=(0, 0, 0), frames_per_tile=3
    )
    for _ in range(3):
        assert anim.current_tile() == (1, 2)
        anim.advance()
    for _ in range(3):
        assert anim.current_tile() == (3, 4)
        anim.advance()
    assert not anim.active
