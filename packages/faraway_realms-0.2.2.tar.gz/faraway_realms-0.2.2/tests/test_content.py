"""Tests for the generic ContentLoader."""

from pathlib import Path

from faraway_realms.content import ContentLoader


def _write_yaml(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def test_loader_calls_parser_for_known_key(tmp_path):
    _write_yaml(tmp_path / "test.yaml", "abilities:\n  kick:\n    cooldown: 10\n")
    received = {}

    def parser(entries):
        received.update(entries)

    loader = ContentLoader(dirs=[tmp_path])
    loader.register_parser("abilities", parser)
    loader.load()
    assert "kick" in received
    assert received["kick"]["cooldown"] == 10


def test_user_dir_overrides_game_dir(tmp_path):
    game_dir = tmp_path / "game"
    user_dir = tmp_path / "user"
    game_dir.mkdir()
    user_dir.mkdir()
    _write_yaml(game_dir / "a.yaml", "abilities:\n  kick:\n    cooldown: 300\n")
    _write_yaml(user_dir / "b.yaml", "abilities:\n  kick:\n    cooldown: 999\n")

    received = {}
    loader = ContentLoader(dirs=[game_dir, user_dir])
    loader.register_parser("abilities", received.update)
    loader.load()
    assert received["kick"]["cooldown"] == 999


def test_user_dir_does_not_erase_other_entries(tmp_path):
    game_dir = tmp_path / "game"
    user_dir = tmp_path / "user"
    game_dir.mkdir()
    user_dir.mkdir()
    _write_yaml(
        game_dir / "a.yaml",
        "abilities:\n  kick:\n    cooldown: 300\n  bite:\n    cooldown: 50\n",
    )
    _write_yaml(user_dir / "b.yaml", "abilities:\n  kick:\n    cooldown: 999\n")

    received = {}
    loader = ContentLoader(dirs=[game_dir, user_dir])
    loader.register_parser("abilities", received.update)
    loader.load()
    assert received["kick"]["cooldown"] == 999
    assert "bite" in received


def test_unknown_key_silently_ignored(tmp_path):
    _write_yaml(tmp_path / "test.yaml", "future_type:\n  foo:\n    bar: 1\n")
    loader = ContentLoader(dirs=[tmp_path])
    loader.load()  # no registered parser — must not raise


def test_missing_user_dir_skipped(tmp_path):
    loader = ContentLoader(dirs=[tmp_path / "nonexistent"])
    loader.load()  # no error


def test_multiple_files_merged(tmp_path):
    _write_yaml(tmp_path / "a.yaml", "abilities:\n  kick:\n    cooldown: 300\n")
    _write_yaml(tmp_path / "b.yaml", "abilities:\n  bite:\n    cooldown: 50\n")

    received = {}
    loader = ContentLoader(dirs=[tmp_path])
    loader.register_parser("abilities", received.update)
    loader.load()
    assert "kick" in received
    assert "bite" in received


def test_empty_yaml_file_skipped(tmp_path):
    _write_yaml(tmp_path / "empty.yaml", "")
    loader = ContentLoader(dirs=[tmp_path])
    loader.load()  # no error


def test_null_yaml_content_skipped(tmp_path):
    _write_yaml(tmp_path / "null.yaml", "~\n")
    loader = ContentLoader(dirs=[tmp_path])
    loader.load()  # no error
