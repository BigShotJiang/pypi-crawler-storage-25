"""Tests for TickSnapshot serialization/deserialization."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from faraway_realms.net.serialization import (
    TickSnapshot,
    deserialize_snapshot,
    serialize_map,
)


def test_deserialize_empty_tick() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [],
        "attack_cooldown_fraction": 0.5,
        "gcd_fraction": None,
        "cast_fraction": None,
        "ability_cooldowns": {},
    }
    snap = deserialize_snapshot(data)
    assert isinstance(snap, TickSnapshot)
    assert snap.attack_cooldown_fraction == pytest.approx(0.5)
    assert snap.gcd_fraction is None
    assert snap.entities == []


def test_deserialize_with_entity() -> None:
    data = {
        "type": "tick",
        "entities": [
            {
                "entity_id": 1,
                "x": 5,
                "y": 10,
                "char": "@",
                "fg_color": [255, 255, 0],
                "display_name": "Hero",
                "faction": "player",
                "target_id": None,
                "blood_color": None,
                "is_player": True,
                "stats": {},
                "abilities": ["kick"],
                "status_effects": [],
            }
        ],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [{"text": "hello", "color": [200, 200, 200]}],
        "attack_cooldown_fraction": 1.0,
        "gcd_fraction": None,
        "cast_fraction": None,
        "ability_cooldowns": {"kick": 0.0},
    }
    snap = deserialize_snapshot(data)
    assert len(snap.entities) == 1
    e = snap.entities[0]
    assert e.entity_id == 1
    assert e.x == 5
    assert e.display_name == "Hero"
    assert e.is_player is True
    assert snap.chat_messages[0]["text"] == "hello"


def test_deserialize_hit_seq_and_crit_dealt_seq() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [],
        "attack_cooldown_fraction": 0.0,
        "hit_seq": 5,
        "crit_dealt_seq": 2,
    }
    snap = deserialize_snapshot(data)
    assert snap.hit_seq == 5
    assert snap.crit_dealt_seq == 2


def test_deserialize_hit_seq_defaults_to_zero() -> None:
    data = {"type": "tick", "entities": [], "attack_cooldown_fraction": 0.0}
    snap = deserialize_snapshot(data)
    assert snap.hit_seq == 0
    assert snap.crit_dealt_seq == 0


def test_deserialize_target_fractions() -> None:
    data = {
        "type": "tick",
        "entities": [],
        "attack_cooldown_fraction": 0.0,
        "target_entity_id": 7,
        "target_attack_fraction": 0.5,
        "target_cast_fraction": 0.3,
        "target_gcd_fraction": None,
    }
    snap = deserialize_snapshot(data)
    assert snap.target_entity_id == 7
    assert snap.target_attack_fraction == pytest.approx(0.5)
    assert snap.target_cast_fraction == pytest.approx(0.3)
    assert snap.target_gcd_fraction is None


def test_deserialize_blood_color_tuple() -> None:
    data = {
        "type": "tick",
        "entities": [
            {
                "entity_id": 2,
                "x": 3,
                "y": 4,
                "char": "Z",
                "fg_color": [60, 160, 60],
                "display_name": "Zombie",
                "faction": "hostile",
                "target_id": None,
                "blood_color": [180, 0, 0],
                "is_player": False,
                "stats": {},
                "abilities": [],
                "status_effects": [],
            }
        ],
        "attack_cooldown_fraction": 0.0,
    }
    snap = deserialize_snapshot(data)
    assert snap.entities[0].blood_color == (180, 0, 0)


def test_serialize_map_produces_row_col_grid() -> None:
    from faraway_realms.map import make_bordered_map

    game_map = make_bordered_map(5, 4)
    mock_game = MagicMock()
    mock_game.game_map = game_map
    rows = serialize_map(mock_game)
    assert len(rows) == 4
    assert len(rows[0]) == 5
    cell = rows[0][0]
    assert "walkable" in cell
    assert "char" in cell
    assert "fg" in cell
    assert "bg" in cell
