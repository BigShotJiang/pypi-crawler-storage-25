"""Tests for the creature type YAML parser."""

from pathlib import Path

import pytest

from faraway_realms.components import CombatProfile
from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.creatures import parse_creatures
from faraway_realms.creature_type import CREATURE_REGISTRY, CreatureType

_CREATURES_DIR = Path(__file__).parent.parent / "faraway_realms" / "data" / "creatures"


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(CREATURE_REGISTRY)
    CREATURE_REGISTRY.clear()
    yield
    CREATURE_REGISTRY.clear()
    CREATURE_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    """Load the shipped YAML data files into the registry."""
    loader = ContentLoader(dirs=[_CREATURES_DIR])
    loader.register_parser("creatures", parse_creatures)
    loader.load()


# ------------------------------------------------------------------
# Defaults
# ------------------------------------------------------------------


def test_parse_creature_minimal_defaults():
    parse_creatures({"goblin": {"char": "g", "fg_color": [100, 150, 50]}})
    ct = CREATURE_REGISTRY["goblin"]
    assert isinstance(ct, CreatureType)
    assert ct.char == ord("g")
    assert ct.fg_color == (100, 150, 50)
    assert ct.faction == "hostile"
    assert ct.stats == {}
    assert ct.move_every == 3
    assert ct.sight_range == 8
    assert ct.abilities == ()
    assert ct.labels == frozenset()
    # No components.behaviour → player-controlled (behaviour_kind None)
    assert ct.behaviour_kind is None
    assert ct.preferred_ability is None
    # No components.combat_profile → all CombatProfile defaults
    assert ct.combat_profile == CombatProfile()
    assert ct.combat_profile.attack_every == 5
    assert ct.combat_profile.armor_type == "none"
    assert ct.combat_profile.damage_type == "bludgeoning"


# ------------------------------------------------------------------
# blood_color handling (via components.combat_profile)
# ------------------------------------------------------------------


def test_blood_color_absent_defaults_to_red():
    parse_creatures({"goblin": {"char": "g", "fg_color": [1, 2, 3]}})
    assert CREATURE_REGISTRY["goblin"].combat_profile.blood_color == (180, 0, 0)


def test_blood_color_null_becomes_none():
    parse_creatures(
        {
            "ghost": {
                "char": "G",
                "fg_color": [200, 200, 255],
                "components": {"combat_profile": {"blood_color": None}},
            }
        }
    )
    assert CREATURE_REGISTRY["ghost"].combat_profile.blood_color is None


def test_blood_color_list_becomes_tuple():
    parse_creatures(
        {
            "slime": {
                "char": "s",
                "fg_color": [60, 200, 60],
                "components": {"combat_profile": {"blood_color": [0, 200, 60]}},
            }
        }
    )
    assert CREATURE_REGISTRY["slime"].combat_profile.blood_color == (0, 200, 60)


# ------------------------------------------------------------------
# stats dict parsing
# ------------------------------------------------------------------


def test_stats_dict_parsed():
    parse_creatures(
        {
            "orc": {
                "char": "O",
                "fg_color": [100, 80, 50],
                "stats": {"health": 40, "strength": 8, "armor": 2},
            }
        }
    )
    ct = CREATURE_REGISTRY["orc"]
    assert ct.stats == {"health": 40, "strength": 8, "armor": 2}


def test_stats_absent_gives_empty_dict():
    parse_creatures({"rat": {"char": "r", "fg_color": [100, 80, 50]}})
    assert CREATURE_REGISTRY["rat"].stats == {}


# ------------------------------------------------------------------
# combat_profile component
# ------------------------------------------------------------------


def test_combat_profile_parsed():
    parse_creatures(
        {
            "knight": {
                "char": "K",
                "fg_color": [200, 200, 200],
                "components": {
                    "combat_profile": {
                        "attack_every": 15,
                        "armor_type": "plate",
                        "damage_type": "slashing",
                    }
                },
            }
        }
    )
    cp = CREATURE_REGISTRY["knight"].combat_profile
    assert isinstance(cp, CombatProfile)
    assert cp.attack_every == 15
    assert cp.armor_type == "plate"
    assert cp.damage_type == "slashing"


# ------------------------------------------------------------------
# behaviour component
# ------------------------------------------------------------------


def test_behaviour_kind_parsed():
    parse_creatures(
        {
            "goblin": {
                "char": "g",
                "fg_color": [100, 150, 50],
                "components": {"behaviour": {"kind": "wander_chase"}},
            }
        }
    )
    ct = CREATURE_REGISTRY["goblin"]
    assert ct.behaviour_kind == "wander_chase"
    assert ct.preferred_ability is None


def test_preferred_ability_parsed():
    parse_creatures(
        {
            "zombie": {
                "char": "Z",
                "fg_color": [60, 160, 60],
                "components": {
                    "behaviour": {"kind": "wander_chase", "preferred_ability": "bite"}
                },
            }
        }
    )
    ct = CREATURE_REGISTRY["zombie"]
    assert ct.preferred_ability == "bite"


# ------------------------------------------------------------------
# abilities and labels
# ------------------------------------------------------------------


def test_abilities_list_populated():
    parse_creatures(
        {
            "zombie": {
                "char": "Z",
                "fg_color": [60, 160, 60],
                "abilities": ["bite", "scratch"],
            }
        }
    )
    assert CREATURE_REGISTRY["zombie"].abilities == ("bite", "scratch")


def test_labels_become_frozenset():
    parse_creatures(
        {"bat": {"char": "b", "fg_color": [120, 80, 120], "labels": ["cave", "common"]}}
    )
    assert CREATURE_REGISTRY["bat"].labels == frozenset({"cave", "common"})


# ------------------------------------------------------------------
# Shipped YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_loads_all_creatures(load_shipped):
    for name in ("zombie", "slime", "skeleton", "bat", "giant_spider", "rock_golem"):
        assert name in CREATURE_REGISTRY, f"Missing creature: {name}"


def test_shipped_yaml_zombie_stats(load_shipped):
    ct = CREATURE_REGISTRY["zombie"]
    assert ct.stats["health"] == 30
    assert ct.stats["strength"] == 5
    assert ct.stats["armor"] == 1


def test_shipped_yaml_slime_no_armor(load_shipped):
    ct = CREATURE_REGISTRY["slime"]
    assert "armor" not in ct.stats


def test_shipped_yaml_zombie_combat_profile(load_shipped):
    cp = CREATURE_REGISTRY["zombie"].combat_profile
    assert cp.attack_every == 30
    assert cp.armor_type == "flesh"
    assert cp.damage_type == "bludgeoning"
    assert cp.blood_color == (180, 0, 0)


def test_shipped_yaml_zombie_behaviour(load_shipped):
    ct = CREATURE_REGISTRY["zombie"]
    assert ct.behaviour_kind == "wander_chase"
    assert ct.preferred_ability == "bite"


def test_shipped_yaml_skeleton_no_blood(load_shipped):
    assert CREATURE_REGISTRY["skeleton"].combat_profile.blood_color is None


def test_shipped_yaml_rock_golem_no_blood(load_shipped):
    assert CREATURE_REGISTRY["rock_golem"].combat_profile.blood_color is None
