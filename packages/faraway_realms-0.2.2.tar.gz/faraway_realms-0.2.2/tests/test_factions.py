"""Tests for FactionRelations."""

import pytest

from faraway_realms.factions import FACTION_RELATIONS, FactionRelations


def test_default_no_hostility() -> None:
    rel = FactionRelations()
    assert not rel.are_hostile("player", "hostile")


def test_set_hostile_true() -> None:
    rel = FactionRelations()
    rel.set_hostile("player", "hostile", True)
    assert rel.are_hostile("player", "hostile")


def test_hostility_is_symmetric() -> None:
    rel = FactionRelations()
    rel.set_hostile("player", "hostile", True)
    assert rel.are_hostile("hostile", "player")


def test_clear_hostility() -> None:
    rel = FactionRelations()
    rel.set_hostile("player", "hostile", True)
    rel.set_hostile("player", "hostile", False)
    assert not rel.are_hostile("player", "hostile")


def test_clear_nonexistent_pair_does_not_raise() -> None:
    rel = FactionRelations()
    rel.set_hostile("a", "b", False)  # discard on empty set — must not raise


def test_unknown_factions_not_hostile() -> None:
    rel = FactionRelations()
    assert not rel.are_hostile("goblin", "dragon")


def test_self_hostility() -> None:
    rel = FactionRelations()
    rel.set_hostile("player", "player", True)
    assert rel.are_hostile("player", "player")


def test_multiple_pairs_independent() -> None:
    rel = FactionRelations()
    rel.set_hostile("player", "hostile", True)
    rel.set_hostile("neutral", "hostile", True)
    assert rel.are_hostile("player", "hostile")
    assert rel.are_hostile("neutral", "hostile")
    assert not rel.are_hostile("player", "neutral")


# ------------------------------------------------------------------
# YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_populates_faction_relations() -> None:
    assert FACTION_RELATIONS.are_hostile("player", "hostile")


def test_shipped_yaml_hostility_is_symmetric() -> None:
    assert FACTION_RELATIONS.are_hostile("hostile", "player")


# ------------------------------------------------------------------
# Parser isolation
# ------------------------------------------------------------------


@pytest.fixture()
def clean_faction_relations():
    saved = set(FACTION_RELATIONS._pairs)  # noqa: SLF001
    yield
    FACTION_RELATIONS._pairs.clear()  # noqa: SLF001
    FACTION_RELATIONS._pairs.update(saved)


def test_parse_factions_adds_hostile_pair(clean_faction_relations) -> None:
    from faraway_realms.content_parsers.factions import parse_factions

    parse_factions({"hostile_pairs": [["goblin", "elf"]]})
    assert FACTION_RELATIONS.are_hostile("goblin", "elf")


def test_parse_factions_multiple_pairs(clean_faction_relations) -> None:
    from faraway_realms.content_parsers.factions import parse_factions

    parse_factions({"hostile_pairs": [["a", "b"], ["c", "d"]]})
    assert FACTION_RELATIONS.are_hostile("a", "b")
    assert FACTION_RELATIONS.are_hostile("c", "d")
    assert not FACTION_RELATIONS.are_hostile("a", "c")


def test_parse_factions_empty_list_is_noop(clean_faction_relations) -> None:
    from faraway_realms.content_parsers.factions import parse_factions

    pairs_before = set(FACTION_RELATIONS._pairs)  # noqa: SLF001
    parse_factions({"hostile_pairs": []})
    assert FACTION_RELATIONS._pairs == pairs_before  # noqa: SLF001
