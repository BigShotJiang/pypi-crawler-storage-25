"""Tests for the status effect display definition parser."""

from pathlib import Path

import pytest

from faraway_realms.content_parsers.status_effects import parse_status_effects
from faraway_realms.status_definitions import STATUS_DEF_REGISTRY, StatusDefinition

_CORE_YAML = (
    Path(__file__).parent.parent
    / "faraway_realms"
    / "data"
    / "status_effects"
    / "core.yaml"
)


@pytest.fixture(autouse=True)
def clean_registry():
    saved = dict(STATUS_DEF_REGISTRY)
    STATUS_DEF_REGISTRY.clear()
    yield
    STATUS_DEF_REGISTRY.clear()
    STATUS_DEF_REGISTRY.update(saved)


def test_parse_minimal():
    parse_status_effects({"bleed": {"bg_color": [160, 20, 20], "glyph": "B"}})
    sd = STATUS_DEF_REGISTRY["bleed"]
    assert isinstance(sd, StatusDefinition)
    assert sd.bg_color == (160, 20, 20)
    assert sd.glyph == ord("B")
    assert sd.fg_color == (230, 230, 230)  # default


def test_explicit_fg_color():
    parse_status_effects(
        {"bleed": {"bg_color": [160, 20, 20], "glyph": "B", "fg_color": [255, 0, 0]}}
    )
    assert STATUS_DEF_REGISTRY["bleed"].fg_color == (255, 0, 0)


def test_urizen_glyph():
    parse_status_effects({"poison": {"bg_color": [0, 180, 0], "glyph": "u:42"}})
    assert STATUS_DEF_REGISTRY["poison"].glyph == 0xE000 + 42


def test_multiple_entries():
    parse_status_effects(
        {
            "stun": {"bg_color": [200, 180, 0], "glyph": "S"},
            "slow": {"bg_color": [60, 120, 200], "glyph": "L"},
        }
    )
    assert "stun" in STATUS_DEF_REGISTRY
    assert "slow" in STATUS_DEF_REGISTRY


def test_shipped_yaml_round_trip():
    import yaml

    data = yaml.safe_load(_CORE_YAML.read_text())
    parse_status_effects(data["status_effects"])
    for name in ("bleed", "burn", "slow", "immobilize", "stun", "haste", "second_wind"):
        assert name in STATUS_DEF_REGISTRY, f"missing shipped status: {name}"
