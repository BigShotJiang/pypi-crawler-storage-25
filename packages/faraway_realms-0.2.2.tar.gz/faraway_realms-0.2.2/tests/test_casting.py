"""Tests for the CastingSystem."""

from faraway_realms.abilities import ABILITY_REGISTRY, Ability, DamageEffect
from faraway_realms.entity import CharacterEntity, NonPlayerEntity
from faraway_realms.events import EventType
from faraway_realms.map import make_bordered_map
from faraway_realms.stats import Pool
from faraway_realms.systems.casting import CastingSystem

# Registry is populated by conftest.py before this module is imported.
BITE = ABILITY_REGISTRY["bite"]
KICK = ABILITY_REGISTRY["kick"]
FIREBOLT = ABILITY_REGISTRY["firebolt"]


def _make_casting_system():
    game_map = make_bordered_map(20, 20)
    caster = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    target = NonPlayerEntity(
        entity_id=2, char=ord("Z"), fg_color=(0, 180, 0), name="Zombie"
    )
    entities = {1: caster, 2: target}
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)  # adjacent
    return CastingSystem(entities, game_map), game_map, caster, target


def test_begin_cast_instant_returns_complete_event():
    cs, game_map, caster, target = _make_casting_system()
    events = cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert len(events) == 1
    assert events[0].event_type == EventType.CAST_COMPLETE
    assert events[0].source_id == 1
    assert events[0].target_id == 2
    assert events[0].resolve_at_tick == 10  # instant: cast_time=0
    assert events[0].payload == {"ability": "kick"}


def test_begin_cast_with_cast_time_queues_future_event():
    cs, game_map, caster, target = _make_casting_system()
    events = cs.begin_cast(1, BITE, 2, abs_tick=10)
    assert len(events) == 1
    assert events[0].resolve_at_tick == 20  # abs_tick=10 + cast_time=10


def test_begin_cast_respects_cooldown():
    cs, game_map, caster, target = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    # KICK cooldown = 300 ticks; GCD = 10; try again at tick 15
    events = cs.begin_cast(1, KICK, 2, abs_tick=15)
    assert events == []


def test_begin_cast_respects_gcd():
    cs, game_map, caster, target = _make_casting_system()
    # Use a custom instant ability with GCD
    instant_ability = Ability(
        name="zap",
        cooldown=5,
        cast_time=0,
        range_tiles=5,
        gcd=True,
        effects=(DamageEffect(base=3),),
    )
    cs.begin_cast(1, instant_ability, 2, abs_tick=10)
    # GCD lasts 10 ticks; try at tick 12
    events2 = cs.begin_cast(1, instant_ability, 2, abs_tick=12)
    assert events2 == []


def test_begin_cast_respects_range():
    cs, game_map, caster, target = _make_casting_system()
    # Move target far away
    game_map.place_entity(2, 15, 15)
    events = cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert events == []


def test_begin_cast_fails_if_caster_not_on_map():
    cs, game_map, caster, target = _make_casting_system()
    # Entity 99 is not on the map
    events = cs.begin_cast(99, KICK, 2, abs_tick=10)
    assert events == []


def test_begin_cast_fails_if_target_not_on_map():
    cs, game_map, caster, target = _make_casting_system()
    events = cs.begin_cast(1, KICK, 99, abs_tick=10)
    assert events == []


def test_interrupt_removes_casting_state():
    cs, game_map, caster, target = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=10)
    assert 1 in cs._casting  # noqa: SLF001
    cs.interrupt(1)
    assert 1 not in cs._casting  # noqa: SLF001


def test_interrupt_noop_when_not_casting():
    cs, game_map, caster, target = _make_casting_system()
    cs.interrupt(1)  # should not raise


def test_cooldowns_for_returns_on_cooldown_abilities():
    cs, game_map, caster, target = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    cds = cs.cooldowns_for(1, abs_tick=15)
    assert "kick" in cds


def test_cooldowns_for_returns_empty_after_cooldown_expires():
    cs, game_map, caster, target = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    # KICK cooldown: avail_at = 10 + 0 + 300 = 310
    cds = cs.cooldowns_for(1, abs_tick=400)
    assert "kick" not in cds


def test_is_on_cooldown_true_during_cooldown():
    cs, game_map, caster, target = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert cs.is_on_cooldown(1, "kick", abs_tick=15) is True


def test_is_on_cooldown_false_before_use():
    cs, game_map, caster, target = _make_casting_system()
    assert cs.is_on_cooldown(1, "kick", abs_tick=10) is False


def test_channel_produces_multiple_events():
    cs, game_map, caster, target = _make_casting_system()
    channeled = Ability(
        name="channel_test",
        cooldown=100,
        cast_time=30,
        range_tiles=5,
        gcd=False,
        channel_interval=10,
        effects=(DamageEffect(base=2),),
    )
    events = cs.begin_cast(1, channeled, 2, abs_tick=0)
    channel_ticks = [e for e in events if e.event_type == EventType.CHANNEL_TICK]
    complete_events = [e for e in events if e.event_type == EventType.CAST_COMPLETE]
    # channel_interval=10, cast_time=30: ticks at 10, 20, 30
    assert len(channel_ticks) == 3
    assert len(complete_events) == 1
    tick_times = sorted(e.resolve_at_tick for e in channel_ticks)
    assert tick_times == [10, 20, 30]
    assert complete_events[0].resolve_at_tick == 30


def test_is_casting_true_during_timed_cast():
    cs, _, _, _ = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=0)  # cast_time=10
    assert cs.is_casting(1)


def test_is_casting_false_for_instant_cast():
    cs, _, _, _ = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=0)  # cast_time=0
    assert not cs.is_casting(1)


def test_cast_fraction_increases_over_time():
    cs, _, _, _ = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=0)  # cast_time=10
    assert cs.cast_fraction(1, abs_tick=5) == 0.5
    assert cs.cast_fraction(1, abs_tick=10) == 1.0


def test_cast_fraction_none_when_not_casting():
    cs, _, _, _ = _make_casting_system()
    assert cs.cast_fraction(1, abs_tick=0) is None


def test_attack_blocked_during_cast():
    """Attacker cannot land a melee hit while a timed cast is in progress."""
    from faraway_realms.commands import Command, CommandType
    from faraway_realms.entity import Player
    from faraway_realms.factions import FactionRelations
    from faraway_realms.game import Game
    from faraway_realms.map import make_bordered_map
    from faraway_realms.stats import Pool, Stat

    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
    )
    player = Player(username="tester", entity=entity)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=50)},
    )
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game.add_npc(npc)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)

    cast_cmd = Command(
        command_type=CommandType.CAST,
        actor="1",
        args=("bite", "2"),
        raw="/cast 1 bite 2",
    )
    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(cast_cmd)
    game.enqueue_command(attack_cmd)
    game.tick()

    hp: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert hp.current == 50  # attack was blocked during cast


# ------------------------------------------------------------------
# Resource cost (mana)
# ------------------------------------------------------------------


def _make_mana_system(mana_current: int = 100):
    """Return a casting system with a caster that has a mana pool."""
    game_map = make_bordered_map(20, 20)
    caster = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"mana": Pool(base=100)},
    )
    caster.stats["mana"].current = mana_current  # type: ignore[union-attr]
    target = NonPlayerEntity(
        entity_id=2, char=ord("Z"), fg_color=(0, 180, 0), name="Zombie"
    )
    entities = {1: caster, 2: target}
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 8, 5)  # within FIREBOLT range (8 tiles)
    return CastingSystem(entities, game_map), caster


def test_begin_cast_fails_without_mana():
    cs, caster = _make_mana_system(mana_current=0)
    events = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert events == []


def test_begin_cast_deducts_mana_on_success():
    cs, caster = _make_mana_system(mana_current=100)
    mana_before = caster.stats["mana"].current  # type: ignore[union-attr]
    cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    mana_after = caster.stats["mana"].current  # type: ignore[union-attr]
    assert mana_after == mana_before - 15  # FIREBOLT costs 15 mana


def test_begin_cast_free_ability_ignores_missing_mana():
    """KICK has no resource cost; it should succeed even with no mana."""
    cs, caster = _make_mana_system(mana_current=0)
    # Move target adjacent for KICK range
    cs._game_map.place_entity(2, 6, 5)  # noqa: SLF001
    events = cs.begin_cast(1, KICK, 2, abs_tick=0)
    assert len(events) == 1  # instant cast completes


def test_begin_cast_exact_mana_required_succeeds():
    cs, caster = _make_mana_system(mana_current=15)  # exactly enough for FIREBOLT
    events = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert len(events) == 1


def test_begin_cast_one_below_mana_required_fails():
    cs, caster = _make_mana_system(mana_current=14)
    events = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert events == []
