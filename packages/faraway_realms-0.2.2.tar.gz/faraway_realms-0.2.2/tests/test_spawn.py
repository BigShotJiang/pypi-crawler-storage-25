"""Tests for GM spawn command."""

from faraway_realms.commands import Command, CommandParser, CommandType
from faraway_realms.entity import CharacterEntity, NonPlayerEntity, Player
from faraway_realms.factions import FactionRelations
from faraway_realms.game import Game
from faraway_realms.map import make_bordered_map
from faraway_realms.stats import Pool


def _zombie_factory(entity_id: int) -> NonPlayerEntity:
    return NonPlayerEntity(
        entity_id=entity_id,
        char=ord("Z"),
        fg_color=(100, 180, 100),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=10)},
    )


def _make_game(is_gm: bool = True) -> tuple[Game, Player]:
    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )
    player = Player(username="tester", entity=entity, is_game_master=is_gm)
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.register_creature("zombie", _zombie_factory)
    game.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 10)
    return game, player


def _spawn_cmd(pos: str = "12,10") -> Command:
    return Command(
        command_type=CommandType.SPAWN,
        actor="me",
        args=("zombie", pos),
        raw=f"/spawn me zombie {pos}",
    )


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def test_parse_spawn_command() -> None:
    parser = CommandParser()
    cmd = parser.parse("/spawn me zombie 5,7")
    assert cmd.command_type == CommandType.SPAWN
    assert cmd.actor == "me"
    assert cmd.args == ("zombie", "5,7")


# ---------------------------------------------------------------------------
# Fixed-position spawn
# ---------------------------------------------------------------------------


def test_spawn_places_npc_on_map() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    positions = game.game_map.get_all_positions()
    assert (12, 10) in positions.values()


def test_spawn_registers_npc_in_entities() -> None:
    game, _ = _make_game()
    before = set(game._entities)  # noqa: SLF001
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert len(game._entities) == len(before) + 1  # noqa: SLF001


def test_spawn_registers_npc_in_npcs() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert any(n.display_name == "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_assigns_unique_entity_id() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.enqueue_command(_spawn_cmd("13,10"))
    game.tick()
    ids = [n.entity_id for n in game._npcs]  # noqa: SLF001
    assert len(ids) == len(set(ids))


def test_spawn_logs_chat_message() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert any("[GM]" in m.text for m in game.get_chat_history())


# ---------------------------------------------------------------------------
# GM gate
# ---------------------------------------------------------------------------


def test_spawn_rejected_for_non_gm() -> None:
    game, _ = _make_game(is_gm=False)
    game.enqueue_command(_spawn_cmd("12,10"))
    game.tick()
    assert all(n.display_name != "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_rejected_for_unknown_creature_type() -> None:
    game, _ = _make_game()
    cmd = Command(
        command_type=CommandType.SPAWN,
        actor="me",
        args=("dragon", "12,10"),
        raw="/spawn me dragon 12,10",
    )
    game.enqueue_command(cmd)
    game.tick()  # should not raise; nothing spawned
    assert game._npcs == []  # noqa: SLF001


def test_spawn_rejected_for_bad_position() -> None:
    game, _ = _make_game()
    cmd = Command(
        command_type=CommandType.SPAWN,
        actor="me",
        args=("zombie", "notaposition"),
        raw="/spawn me zombie notaposition",
    )
    game.enqueue_command(cmd)
    game.tick()  # should not raise
    assert game._npcs == []  # noqa: SLF001


# ---------------------------------------------------------------------------
# Random-position spawn
# ---------------------------------------------------------------------------


def test_spawn_random_places_npc_somewhere() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    assert any(n.display_name == "Zombie" for n in game._npcs)  # noqa: SLF001


def test_spawn_random_places_npc_on_walkable_tile() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    npc = next(n for n in game._npcs if n.display_name == "Zombie")  # noqa: SLF001
    x, y = game.game_map.get_entity_position(npc.entity_id)
    assert game.game_map.is_walkable(x, y)


def test_spawn_random_does_not_stack_on_existing_entity() -> None:
    game, _ = _make_game()
    game.enqueue_command(_spawn_cmd("random"))
    game.tick()
    positions = list(game.game_map.get_all_positions().values())
    assert len(positions) == len(set(positions))
