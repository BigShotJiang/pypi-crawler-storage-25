"""Test that Game satisfies GameProtocol at runtime."""

from __future__ import annotations

from faraway_realms.factions import FactionRelations
from faraway_realms.game import Game
from faraway_realms.game_protocol import GameProtocol
from faraway_realms.map import make_bordered_map


def _make_game() -> Game:
    return Game(
        game_map=make_bordered_map(20, 20),
        faction_relations=FactionRelations(),
    )


def test_game_satisfies_protocol() -> None:
    game = _make_game()
    assert isinstance(game, GameProtocol)


def test_all_player_entities_empty() -> None:
    game = _make_game()
    assert game.all_player_entities() == []


def test_all_npcs_empty() -> None:
    game = _make_game()
    assert game.all_npcs() == []


def test_entity_missing() -> None:
    game = _make_game()
    assert game.entity(999) is None
