"""Tests for faraway_realms.mapgen.creature_pass."""

import random

import pytest

from faraway_realms.creature_type import CREATURE_REGISTRY, CreatureType
from faraway_realms.mapgen import CaveGenerator, CreaturePopulationPass


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(CREATURE_REGISTRY)
    CREATURE_REGISTRY.clear()
    yield
    CREATURE_REGISTRY.clear()
    CREATURE_REGISTRY.update(saved)


def _make_result(seed=42):
    rng = random.Random(seed)  # noqa: S311 — game logic, not crypto
    return CaveGenerator().generate(100, 60, rng), rng


def _seed_registry():
    CREATURE_REGISTRY["zombie"] = CreatureType(
        name="zombie",
        char=ord("Z"),
        fg_color=(60, 160, 60),
        labels=frozenset({"undead", "cave"}),
    )
    CREATURE_REGISTRY["bat"] = CreatureType(
        name="bat",
        char=ord("b"),
        fg_color=(120, 80, 120),
        labels=frozenset({"creature", "cave"}),
    )


def test_pass_places_creatures_in_rooms():
    _seed_registry()
    result, rng = _make_result()
    CreaturePopulationPass().apply(result, rng)
    assert len(result.creature_placements) == len(result.rooms) - 1


def test_pass_skips_player_room():
    _seed_registry()
    result, rng = _make_result()
    CreaturePopulationPass().apply(result, rng)
    player_x, player_y = result.player_start
    for _ct, cx, cy in result.creature_placements:
        assert (cx, cy) != (player_x, player_y)


def test_pass_empty_registry_no_placements():
    result, rng = _make_result()
    CreaturePopulationPass().apply(result, rng)
    assert result.creature_placements == []


def test_pass_label_filter():
    _seed_registry()
    result, rng = _make_result()
    CreaturePopulationPass(labels=("undead",)).apply(result, rng)
    for ct, _cx, _cy in result.creature_placements:
        assert "undead" in ct.labels


def test_pass_deterministic():
    _seed_registry()
    result1, rng1 = _make_result(seed=7)
    CreaturePopulationPass().apply(result1, rng1)

    result2, rng2 = _make_result(seed=7)
    CreaturePopulationPass().apply(result2, rng2)

    placements1 = [(ct.name, cx, cy) for ct, cx, cy in result1.creature_placements]
    placements2 = [(ct.name, cx, cy) for ct, cx, cy in result2.creature_placements]
    assert placements1 == placements2
