"""Tests for the LightMap and LightSource."""

import numpy as np
import pytest

from faraway_realms.light import LightMap, LightSource

_WARM = LightSource(radius=5, intensity=1.0, color=(255, 200, 120))
_DIM = LightSource(radius=3, intensity=0.5, color=(100, 100, 200))


def _make_map(w: int = 20, h: int = 20) -> LightMap:
    return LightMap(w, h)


# ------------------------------------------------------------------
# Ambient baseline
# ------------------------------------------------------------------


def test_fresh_map_at_ambient():
    lm = _make_map()
    assert lm.at(10, 10) == pytest.approx(LightMap.AMBIENT)


def test_compute_with_no_sources_resets_to_ambient():
    lm = _make_map()
    lm.compute([])
    assert lm.at(5, 5) == pytest.approx(LightMap.AMBIENT)


# ------------------------------------------------------------------
# Single source: intensity and falloff
# ------------------------------------------------------------------


def test_source_centre_at_full_intensity():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    # Centre = ambient + intensity (capped at 1.0)
    assert lm.at(10, 10) == 1.0


def test_source_falls_off_at_radius_edge():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    # Exactly at radius distance the contribution is 0; ambient remains
    assert lm.at(10, 10 + _WARM.radius) == pytest.approx(LightMap.AMBIENT)


def test_brightness_decreases_with_distance():
    lm = _make_map()
    src = LightSource(radius=8, intensity=0.5, color=(255, 255, 255))
    lm.compute([(10, 10, src)])
    assert lm.at(10, 11) > lm.at(10, 12) > lm.at(10, 13)


def test_brightness_capped_at_1():
    """Two overlapping strong sources should not exceed 1.0."""
    lm = _make_map()
    src = LightSource(radius=5, intensity=1.0, color=(255, 255, 255))
    lm.compute([(10, 10, src), (10, 10, src)])
    assert lm.at(10, 10) == 1.0


# ------------------------------------------------------------------
# Multiple sources: additive
# ------------------------------------------------------------------


def test_two_sources_brighter_than_one():
    lm = _make_map()
    src = LightSource(radius=5, intensity=0.4, color=(255, 255, 255))
    lm.compute([(5, 5, src)])
    single = lm.at(5, 5)
    lm.compute([(5, 5, src), (5, 5, src)])
    double = lm.at(5, 5)
    assert double > single


def test_sources_dont_affect_tiles_beyond_radius():
    lm = _make_map()
    lm.compute([(10, 10, _DIM)])  # radius=3; tile at (10,18) is far away
    assert lm.at(10, 18) == pytest.approx(LightMap.AMBIENT)


# ------------------------------------------------------------------
# Map edges: out-of-bounds sources clamp gracefully
# ------------------------------------------------------------------


def test_source_near_corner_does_not_raise():
    lm = _make_map()
    lm.compute([(0, 0, _WARM)])  # circle extends outside map; must not crash
    assert lm.at(0, 0) == 1.0


def test_source_at_bottom_right_corner():
    lm = _make_map(20, 20)
    lm.compute([(19, 19, _WARM)])
    assert lm.at(19, 19) == 1.0


# ------------------------------------------------------------------
# Successive compute() calls reset the map
# ------------------------------------------------------------------


def test_compute_resets_previous_sources():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    bright = lm.at(10, 10)
    lm.compute([])  # no sources → reset to ambient
    assert lm.at(10, 10) < bright
    assert lm.at(10, 10) == pytest.approx(LightMap.AMBIENT)


# ------------------------------------------------------------------
# Symmetry
# ------------------------------------------------------------------


def test_source_is_symmetric():
    lm = _make_map()
    lm.compute([(10, 10, _WARM)])
    assert abs(lm.at(10, 12) - lm.at(10, 8)) < 1e-4
    assert abs(lm.at(12, 10) - lm.at(8, 10)) < 1e-4


# ------------------------------------------------------------------
# Wall blocking
# ------------------------------------------------------------------


def _open_transparency(w: int = 20, h: int = 20) -> np.ndarray:
    """All-floor (fully transparent) grid."""
    return np.ones((h, w), dtype=bool)


def _wall_at(trans: np.ndarray, x: int, y: int) -> np.ndarray:
    """Return a copy of *trans* with tile (x, y) set to opaque."""
    t = trans.copy()
    t[y, x] = False
    return t


def test_wall_blocks_light_behind_it():
    # Torch at (5, 10); wall at (7, 10); tile at (9, 10) should be ambient.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(9, 10) == pytest.approx(LightMap.AMBIENT)


def test_wall_tile_itself_is_lit():
    # The wall that faces the source should still be illuminated.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(7, 10) > LightMap.AMBIENT


def test_light_reaches_around_wall():
    # Torch at (5, 10); wall only at (7, 10); tile at (9, 12) (diagonal) is reachable.
    lm = LightMap(20, 20)
    src = LightSource(radius=8, intensity=1.0, color=(255, 255, 255))
    trans = _wall_at(_open_transparency(), x=7, y=10)
    lm.compute([(5, 10, src)], trans)
    assert lm.at(9, 12) > LightMap.AMBIENT


def test_no_wall_lighting_matches_open_transparency():
    # compute() with no transparency arg must equal all-open transparency.
    lm1 = LightMap(20, 20)
    lm2 = LightMap(20, 20)
    src = LightSource(radius=5, intensity=0.8, color=(255, 200, 120))
    lm1.compute([(10, 10, src)])
    lm2.compute([(10, 10, src)], _open_transparency())
    assert lm1.at(10, 10) == pytest.approx(lm2.at(10, 10))
    assert lm1.at(12, 10) == pytest.approx(lm2.at(12, 10))
