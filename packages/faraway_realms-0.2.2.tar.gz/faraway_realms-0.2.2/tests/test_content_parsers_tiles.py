"""Tests for the tile type YAML parser."""

from pathlib import Path

import pytest

from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.tiles import parse_tiles
from faraway_realms.tile import TILE_REGISTRY, Tile

_TILES_DIR = Path(__file__).parent.parent / "faraway_realms" / "data" / "tiles"


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(TILE_REGISTRY)
    TILE_REGISTRY.clear()
    yield
    TILE_REGISTRY.clear()
    TILE_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    """Load the shipped YAML data files into the registry."""
    loader = ContentLoader(dirs=[_TILES_DIR])
    loader.register_parser("tiles", parse_tiles)
    loader.load()


# ------------------------------------------------------------------
# walkable flag
# ------------------------------------------------------------------


def test_walkable_true_produces_walkable_tile():
    parse_tiles(
        {
            "floor": {
                "walkable": True,
                "bg_color": [50, 50, 50],
                "fg_color": [200, 200, 200],
            }
        }
    )
    tile = TILE_REGISTRY["floor"].make()
    assert tile.walkable is True


def test_walkable_false_produces_non_walkable_tile():
    parse_tiles(
        {
            "wall": {
                "walkable": False,
                "bg_color": [30, 30, 30],
                "fg_color": [80, 80, 80],
            }
        }
    )
    tile = TILE_REGISTRY["wall"].make()
    assert tile.walkable is False


# ------------------------------------------------------------------
# Color parsing
# ------------------------------------------------------------------


def test_colors_parsed_as_tuples():
    parse_tiles(
        {
            "dirt": {
                "walkable": True,
                "bg_color": [60, 45, 30],
                "fg_color": [160, 130, 80],
            }
        }
    )
    tt = TILE_REGISTRY["dirt"]
    assert tt.bg_color == (60, 45, 30)
    assert tt.fg_color == (160, 130, 80)


# ------------------------------------------------------------------
# make() returns independent instance
# ------------------------------------------------------------------


def test_make_returns_tile_instance():
    parse_tiles(
        {
            "rock": {
                "walkable": False,
                "bg_color": [35, 25, 15],
                "fg_color": [80, 60, 40],
            }
        }
    )
    result = TILE_REGISTRY["rock"].make()
    assert isinstance(result, Tile)


def test_make_returns_independent_instance():
    parse_tiles(
        {
            "grass": {
                "walkable": True,
                "bg_color": [20, 80, 20],
                "fg_color": [40, 160, 40],
            }
        }
    )
    t1 = TILE_REGISTRY["grass"].make()
    t2 = TILE_REGISTRY["grass"].make()
    t1.walkable = False
    assert t2.walkable is True  # mutation of t1 does not affect t2


# ------------------------------------------------------------------
# Shipped YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_loads_all_tiles(load_shipped):
    for name in ("cave_floor", "cave_wall", "floor", "wall"):
        assert name in TILE_REGISTRY, f"Missing tile: {name}"


def test_shipped_cave_floor_is_walkable(load_shipped):
    assert TILE_REGISTRY["cave_floor"].make().walkable is True


def test_shipped_cave_wall_is_not_walkable(load_shipped):
    assert TILE_REGISTRY["cave_wall"].make().walkable is False


def test_shipped_cave_floor_colors(load_shipped):
    tt = TILE_REGISTRY["cave_floor"]
    assert tt.bg_color == (60, 45, 30)
    assert tt.fg_color == (160, 130, 80)
