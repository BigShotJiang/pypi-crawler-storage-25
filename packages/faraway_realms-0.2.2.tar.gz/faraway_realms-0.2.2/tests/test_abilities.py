"""Tests for ability and effect definitions — loaded from YAML via conftest."""

from faraway_realms.abilities import (
    ABILITY_REGISTRY,
    ApplyStatusEffect,
    DamageEffect,
    KnockbackEffect,
)


def test_bite_has_damage_and_status_effects():
    bite = ABILITY_REGISTRY["bite"]
    kinds = [e.kind() for e in bite.effects]
    assert "damage" in kinds
    assert "status" in kinds


def test_bite_damage_effect_is_piercing():
    bite = ABILITY_REGISTRY["bite"]
    damage_effects = [e for e in bite.effects if isinstance(e, DamageEffect)]
    assert len(damage_effects) == 1
    assert damage_effects[0].damage_type == "piercing"
    assert damage_effects[0].base == 8


def test_bite_status_effect_is_bleed():
    bite = ABILITY_REGISTRY["bite"]
    status_effects = [e for e in bite.effects if isinstance(e, ApplyStatusEffect)]
    assert len(status_effects) == 1
    assert status_effects[0].status_name == "bleed"
    assert status_effects[0].duration == 30
    assert status_effects[0].tick_damage == 1


def test_kick_is_instant():
    assert ABILITY_REGISTRY["kick"].cast_time == 0


def test_kick_has_knockback_effect():
    kick = ABILITY_REGISTRY["kick"]
    knockbacks = [e for e in kick.effects if isinstance(e, KnockbackEffect)]
    assert len(knockbacks) == 1
    assert knockbacks[0].distance == 1


def test_kick_applies_immobilize():
    kick = ABILITY_REGISTRY["kick"]
    statuses = [e for e in kick.effects if isinstance(e, ApplyStatusEffect)]
    assert len(statuses) == 1
    assert statuses[0].status_name == "immobilize"
    assert statuses[0].immobilize is True


def test_kick_uses_gcd():
    assert ABILITY_REGISTRY["kick"].gcd is True


def test_bite_does_not_use_gcd():
    assert ABILITY_REGISTRY["bite"].gcd is False


def test_ability_registry_contains_bite_and_kick():
    assert "bite" in ABILITY_REGISTRY
    assert "kick" in ABILITY_REGISTRY


def test_effect_kinds():
    assert DamageEffect().kind() == "damage"
    assert KnockbackEffect().kind() == "knockback"
    assert ApplyStatusEffect().kind() == "status"
