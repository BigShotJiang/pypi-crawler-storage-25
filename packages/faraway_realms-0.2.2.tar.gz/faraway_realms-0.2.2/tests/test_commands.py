import pytest

from faraway_realms.commands import CommandParser, CommandType, make_attack_command


@pytest.fixture
def parser() -> CommandParser:
    return CommandParser()


def test_parse_move_command(parser: CommandParser):
    cmd = parser.parse("/move me left")
    assert cmd.command_type == CommandType.MOVE
    assert cmd.actor == "me"
    assert cmd.args == ("left",)


@pytest.mark.parametrize("direction", ["left", "right", "up", "down"])
def test_parse_move_all_directions(parser: CommandParser, direction: str):
    cmd = parser.parse(f"/move me {direction}")
    assert cmd.command_type == CommandType.MOVE
    assert cmd.args == (direction,)


def test_parse_unknown_command(parser: CommandParser):
    cmd = parser.parse("/foobar")
    assert cmd.command_type == CommandType.UNKNOWN


def test_parse_non_slash_string(parser: CommandParser):
    cmd = parser.parse("hello world")
    assert cmd.command_type == CommandType.UNKNOWN


def test_parse_empty_string(parser: CommandParser):
    cmd = parser.parse("")
    assert cmd.command_type == CommandType.UNKNOWN


def test_command_is_frozen(parser: CommandParser):
    cmd = parser.parse("/move me left")
    with pytest.raises(AttributeError):
        cmd.actor = "other"  # type: ignore[misc]


def test_make_attack_command_raw_format():
    cmd = make_attack_command(1, 2)
    assert cmd.raw == "/attack 1 2"
    assert cmd.actor == "1"
    assert cmd.args == ("2",)
    assert cmd.command_type == CommandType.ATTACK


def test_make_attack_command_opportunity_attack():
    cmd = make_attack_command(3, 7, CommandType.OPPORTUNITY_ATTACK)
    assert cmd.command_type == CommandType.OPPORTUNITY_ATTACK
    assert cmd.raw == "/opportunity_attack 3 7"
