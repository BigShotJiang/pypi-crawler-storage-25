"""Tests for ClientGame reading from injected snapshot."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from faraway_realms.client_game import ClientGame
from faraway_realms.map import make_bordered_map
from faraway_realms.net.serialization import EntitySnapshot, TickSnapshot


def _make_snap(**kwargs) -> TickSnapshot:
    defaults = {
        "entities": [],
        "blood_tiles": {},
        "attack_anim_events": [],
        "blood_events": [],
        "projectiles": [],
        "light_sources": [],
        "static_objects": [],
        "chat_messages": [],
        "attack_cooldown_fraction": 0.0,
        "gcd_fraction": None,
        "cast_fraction": None,
        "ability_cooldowns": {},
    }
    defaults.update(kwargs)
    return TickSnapshot(**defaults)


def _make_client_game() -> ClientGame:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = None
    game_map = make_bordered_map(20, 20)
    return ClientGame(client=mock_client, game_map=game_map)


def test_no_snapshot_returns_empty() -> None:
    cg = _make_client_game()
    assert cg.all_player_entities() == []
    assert cg.all_npcs() == []
    assert cg.entity(1) is None
    assert cg.get_chat_history() == []
    assert cg.attack_cooldown_fraction(1) == 0.0
    assert cg.gcd_fraction(1) is None
    assert cg.cast_fraction(1) is None


def _entity_snap(
    entity_id: int = 1, is_player: bool = True, **kwargs
) -> EntitySnapshot:
    defaults: dict = {
        "entity_id": entity_id,
        "x": 5,
        "y": 5,
        "char": "@",
        "fg_color": (255, 255, 0),
        "display_name": "Hero",
        "faction": "player",
        "target_id": None,
        "blood_color": None,
        "is_player": is_player,
        "stats": {},
        "abilities": [],
        "status_effects": [],
    }
    defaults.update(kwargs)
    return EntitySnapshot(**defaults)


def test_entities_from_snapshot() -> None:
    mock_client = MagicMock()
    snap = _make_snap(
        entities=[_entity_snap(entity_id=1)],
        attack_cooldown_fraction=0.75,
    )
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    players = cg.all_player_entities()
    assert len(players) == 1
    assert players[0].entity_id == 1
    assert players[0].display_name == "Hero"
    assert cg.attack_cooldown_fraction(1) == pytest.approx(0.75)


def test_get_hit_seq_reads_from_snapshot() -> None:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = _make_snap(hit_seq=7)
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.get_hit_seq(1) == 7


def test_get_crit_dealt_seq_reads_from_snapshot() -> None:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = _make_snap(crit_dealt_seq=3)
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.get_crit_dealt_seq(1) == 3


def test_get_hit_seq_no_snapshot_returns_zero() -> None:
    cg = _make_client_game()
    assert cg.get_hit_seq(1) == 0


def test_get_crit_dealt_seq_no_snapshot_returns_zero() -> None:
    cg = _make_client_game()
    assert cg.get_crit_dealt_seq(1) == 0


def test_cast_fraction_for_target_entity() -> None:
    mock_client = MagicMock()
    snap = _make_snap(
        target_entity_id=2,
        target_cast_fraction=0.6,
        target_attack_fraction=0.0,
    )
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.cast_fraction(2) == pytest.approx(0.6)


def test_cast_fraction_for_self_uses_player_field() -> None:
    mock_client = MagicMock()
    snap = _make_snap(cast_fraction=0.4, target_entity_id=2, target_cast_fraction=0.9)
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.cast_fraction(1) == pytest.approx(0.4)


def test_attack_cooldown_fraction_for_target() -> None:
    mock_client = MagicMock()
    snap = _make_snap(target_entity_id=2, target_attack_fraction=0.8)
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.attack_cooldown_fraction(2) == pytest.approx(0.8)


def test_gcd_fraction_from_snapshot() -> None:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = _make_snap(gcd_fraction=0.3)
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.gcd_fraction(1) == pytest.approx(0.3)


def test_active_statuses_from_entity_snapshot() -> None:
    mock_client = MagicMock()
    snap = _make_snap(
        entities=[
            _entity_snap(
                entity_id=1,
                status_effects=[
                    {
                        "name": "stun",
                        "expires_at": 100,
                        "immobilize": False,
                        "stun": True,
                        "haste": 1.0,
                    }
                ],
            )
        ]
    )
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    statuses = cg.active_statuses(1)
    assert len(statuses) == 1
    assert statuses[0].name == "stun"
    assert statuses[0].stun is True


def test_has_active_status_true() -> None:
    mock_client = MagicMock()
    snap = _make_snap(
        entities=[
            _entity_snap(
                entity_id=1,
                status_effects=[
                    {
                        "name": "bleed",
                        "expires_at": 100,
                        "immobilize": False,
                        "stun": False,
                        "haste": 1.0,
                    }
                ],
            )
        ]
    )
    mock_client.latest_snapshot.return_value = snap
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.has_active_status(1, "bleed") is True
    assert cg.has_active_status(1, "stun") is False


def test_active_statuses_unknown_entity_returns_empty() -> None:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = _make_snap(entities=[])
    cg = ClientGame(client=mock_client, game_map=make_bordered_map(20, 20))
    assert cg.active_statuses(99) == []
