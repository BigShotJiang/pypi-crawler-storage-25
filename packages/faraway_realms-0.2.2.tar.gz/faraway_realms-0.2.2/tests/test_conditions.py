"""Tests for composable behaviour conditions."""

from faraway_realms.behaviour import BehaviourContext
from faraway_realms.conditions import (
    AbilityReady,
    Always,
    EnemyAdjacent,
    EnemyInSight,
    EnemyOutOfSight,
    HealthAbove,
    HealthBelow,
)
from faraway_realms.map import make_bordered_map


def _make_ctx(
    npc_id,
    npc_pos,
    target_id=None,
    target_pos=None,
    ability_cooldowns=frozenset(),
    hp_fraction=1.0,
):
    game_map = make_bordered_map(20, 20)
    all_positions = {npc_id: npc_pos}
    target_ids = frozenset()
    if target_id is not None and target_pos is not None:
        all_positions[target_id] = target_pos
        target_ids = frozenset([target_id])
    occupied = frozenset(all_positions.values())
    return BehaviourContext(
        game_map=game_map,
        all_positions=all_positions,
        target_ids=target_ids,
        occupied=occupied,
        ability_cooldowns=ability_cooldowns,
        hp_fraction=hp_fraction,
    )


def test_enemy_in_sight_true_when_target_visible():
    ctx = _make_ctx(1, (5, 5), target_id=2, target_pos=(6, 5))
    cond = EnemyInSight(sight_range=8)
    assert cond.check(1, ctx) is True


def test_enemy_in_sight_false_when_no_targets():
    ctx = _make_ctx(1, (5, 5))
    cond = EnemyInSight(sight_range=8)
    assert cond.check(1, ctx) is False


def test_enemy_out_of_sight_true_when_no_targets():
    ctx = _make_ctx(1, (5, 5))
    cond = EnemyOutOfSight(sight_range=8)
    assert cond.check(1, ctx) is True


def test_enemy_out_of_sight_false_when_target_visible():
    ctx = _make_ctx(1, (5, 5), target_id=2, target_pos=(6, 5))
    cond = EnemyOutOfSight(sight_range=8)
    assert cond.check(1, ctx) is False


def test_enemy_adjacent_true_when_adjacent():
    ctx = _make_ctx(1, (5, 5), target_id=2, target_pos=(6, 5))
    cond = EnemyAdjacent()
    assert cond.check(1, ctx) is True


def test_enemy_adjacent_false_when_far():
    ctx = _make_ctx(1, (5, 5), target_id=2, target_pos=(10, 5))
    cond = EnemyAdjacent()
    assert cond.check(1, ctx) is False


def test_enemy_adjacent_false_when_no_targets():
    ctx = _make_ctx(1, (5, 5))
    cond = EnemyAdjacent()
    assert cond.check(1, ctx) is False


def test_health_below_true_when_low():
    ctx = _make_ctx(1, (5, 5), hp_fraction=0.2)
    cond = HealthBelow(threshold=0.5)
    assert cond.check(1, ctx) is True


def test_health_below_false_when_healthy():
    ctx = _make_ctx(1, (5, 5), hp_fraction=0.8)
    cond = HealthBelow(threshold=0.5)
    assert cond.check(1, ctx) is False


def test_health_above_true_when_healthy():
    ctx = _make_ctx(1, (5, 5), hp_fraction=0.8)
    cond = HealthAbove(threshold=0.5)
    assert cond.check(1, ctx) is True


def test_health_above_false_when_low():
    ctx = _make_ctx(1, (5, 5), hp_fraction=0.2)
    cond = HealthAbove(threshold=0.5)
    assert cond.check(1, ctx) is False


def test_health_above_true_at_boundary():
    ctx = _make_ctx(1, (5, 5), hp_fraction=0.5)
    cond = HealthAbove(threshold=0.5)
    assert cond.check(1, ctx) is True


def test_ability_ready_true_when_not_on_cooldown():
    ctx = _make_ctx(1, (5, 5), ability_cooldowns=frozenset({"bite"}))
    cond = AbilityReady(ability_name="kick")
    assert cond.check(1, ctx) is True


def test_ability_ready_false_when_on_cooldown():
    ctx = _make_ctx(1, (5, 5), ability_cooldowns=frozenset({"bite"}))
    cond = AbilityReady(ability_name="bite")
    assert cond.check(1, ctx) is False


def test_ability_ready_true_when_no_cooldowns():
    ctx = _make_ctx(1, (5, 5))
    cond = AbilityReady(ability_name="bite")
    assert cond.check(1, ctx) is True


def test_always_returns_true():
    ctx = _make_ctx(1, (5, 5))
    cond = Always()
    assert cond.check(1, ctx) is True
