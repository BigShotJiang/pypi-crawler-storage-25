"""Tests for Stat and Pool."""

from faraway_realms.stats import Pool, Stat

# ---------------------------------------------------------------------------
# Stat
# ---------------------------------------------------------------------------


def test_stat_value_no_bonus() -> None:
    assert Stat(base=10).value == 10


def test_stat_value_with_bonus() -> None:
    assert Stat(base=10, bonus=5).value == 15


def test_stat_negative_bonus() -> None:
    assert Stat(base=10, bonus=-3).value == 7


# ---------------------------------------------------------------------------
# Pool — initialisation
# ---------------------------------------------------------------------------


def test_pool_starts_full() -> None:
    p = Pool(base=100)
    assert p.current == 100


def test_pool_starts_full_with_bonus() -> None:
    p = Pool(base=100, bonus=20)
    assert p.current == 120


def test_pool_is_a_stat() -> None:
    assert isinstance(Pool(base=10), Stat)


# ---------------------------------------------------------------------------
# Pool — modify
# ---------------------------------------------------------------------------


def test_pool_modify_damage() -> None:
    p = Pool(base=100)
    p.modify(-30)
    assert p.current == 70


def test_pool_modify_clamps_to_zero() -> None:
    p = Pool(base=100)
    p.modify(-999)
    assert p.current == 0


def test_pool_modify_heal() -> None:
    p = Pool(base=100)
    p.modify(-50)
    p.modify(20)
    assert p.current == 70


def test_pool_modify_clamps_to_maximum() -> None:
    p = Pool(base=100)
    p.modify(999)
    assert p.current == 100


def test_pool_maximum_respects_bonus() -> None:
    p = Pool(base=100, bonus=50)
    p.modify(-200)
    p.modify(999)
    assert p.current == 150


# ---------------------------------------------------------------------------
# Pool — is_empty
# ---------------------------------------------------------------------------


def test_pool_not_empty_when_full() -> None:
    assert not Pool(base=100).is_empty


def test_pool_is_empty_at_zero() -> None:
    p = Pool(base=100)
    p.modify(-100)
    assert p.is_empty


def test_pool_modify_zero_is_noop() -> None:
    p = Pool(base=100)
    p.modify(-30)
    before = p.current
    p.modify(0)
    assert p.current == before


def test_pool_base_zero_starts_empty() -> None:
    p = Pool(base=0)
    assert p.is_empty


# ---------------------------------------------------------------------------
# Entity stats dict
# ---------------------------------------------------------------------------


def test_entity_stats_empty_by_default() -> None:
    from faraway_realms.entity import CharacterEntity

    e = CharacterEntity(entity_id=1, char=ord("@"), fg_color=(0, 0, 0), name="Hero")
    assert e.stats == {}


def test_entity_stats_arbitrary_keys() -> None:
    from faraway_realms.entity import NonPlayerEntity

    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("B"),
        fg_color=(0, 0, 0),
        name="Berserker",
        stats={
            "health": Pool(base=80),
            "rage": Pool(base=100),
            "strength": Stat(base=12),
        },
    )
    assert npc.stats["rage"].value == 100
    assert npc.stats["strength"].value == 12
