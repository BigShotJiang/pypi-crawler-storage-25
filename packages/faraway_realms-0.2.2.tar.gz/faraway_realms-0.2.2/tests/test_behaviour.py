"""Tests for NPC behaviour strategies."""

from faraway_realms.behaviour import (
    Behaviour,
    BehaviourContext,
    ChaseState,
    FleeState,
    StateMachineBehaviour,
    WanderState,
    _build_cost,
    _build_transparency,
    _move_randomly,
    _step_toward,
)
from faraway_realms.commands import CommandType
from faraway_realms.map import make_bordered_map


def _make_ctx(
    game_map,
    npc_id: int,
    npc_pos: tuple[int, int],
    target_id: int | None = None,
    target_pos: tuple[int, int] | None = None,
) -> BehaviourContext:
    all_positions = {npc_id: npc_pos}
    target_ids: frozenset[int] = frozenset()
    if target_id is not None and target_pos is not None:
        all_positions[target_id] = target_pos
        target_ids = frozenset([target_id])
    occupied = frozenset(all_positions.values())
    return BehaviourContext(
        game_map=game_map,
        all_positions=all_positions,
        target_ids=target_ids,
        occupied=occupied,
    )


# ---------------------------------------------------------------------------
# BehaviourContext
# ---------------------------------------------------------------------------


def test_behaviour_context_is_frozen() -> None:
    game_map = make_bordered_map(10, 10)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={},
        target_ids=frozenset(),
        occupied=frozenset(),
    )
    try:
        ctx.target_ids = frozenset([1])  # type: ignore[misc]
        raise AssertionError("Assignment should have raised")
    except AttributeError, TypeError:
        pass


def test_behaviour_abc_cannot_be_instantiated() -> None:
    try:
        Behaviour()  # type: ignore[abstract]
        raise AssertionError("Instantiation should have raised")
    except TypeError:
        pass


# ---------------------------------------------------------------------------
# _build_transparency
# ---------------------------------------------------------------------------


def test_build_transparency_shape() -> None:
    game_map = make_bordered_map(10, 8)
    t = _build_transparency(game_map)
    assert t.shape == (8, 10)


def test_build_transparency_walls_are_false() -> None:
    game_map = make_bordered_map(10, 10)
    t = _build_transparency(game_map)
    assert not t[0, 0]
    assert not t[9, 9]


def test_build_transparency_interior_is_true() -> None:
    game_map = make_bordered_map(10, 10)
    t = _build_transparency(game_map)
    assert t[5, 5]


# ---------------------------------------------------------------------------
# _build_cost
# ---------------------------------------------------------------------------


def test_build_cost_shape() -> None:
    game_map = make_bordered_map(10, 8)
    cost = _build_cost(game_map, frozenset(), (5, 4))
    assert cost.shape == (8, 10)


def test_build_cost_walls_are_zero() -> None:
    game_map = make_bordered_map(10, 10)
    cost = _build_cost(game_map, frozenset(), (5, 5))
    assert cost[0, 0] == 0
    assert cost[9, 9] == 0


def test_build_cost_interior_is_one() -> None:
    game_map = make_bordered_map(10, 10)
    cost = _build_cost(game_map, frozenset(), (5, 5))
    assert cost[5, 5] == 1


def test_build_cost_occupied_tile_is_zero() -> None:
    game_map = make_bordered_map(10, 10)
    occupied = frozenset([(3, 4)])
    cost = _build_cost(game_map, occupied, (5, 5))
    assert cost[4, 3] == 0


def test_build_cost_npc_own_tile_not_blocked() -> None:
    game_map = make_bordered_map(10, 10)
    npc_pos = (5, 5)
    occupied = frozenset([npc_pos])
    cost = _build_cost(game_map, occupied, npc_pos)
    assert cost[5, 5] == 1


# ---------------------------------------------------------------------------
# _move_randomly
# ---------------------------------------------------------------------------


def test_move_randomly_returns_move_command() -> None:
    game_map = make_bordered_map(10, 10)
    game_map.place_entity(1, 5, 5)
    ctx = _make_ctx(game_map, 1, (5, 5))
    command = _move_randomly(1, ctx)
    assert command is not None
    assert command.command_type == CommandType.MOVE
    assert command.actor == "1"


def test_move_randomly_avoids_occupied() -> None:
    game_map = make_bordered_map(5, 5)
    game_map.place_entity(1, 2, 2)
    occupied = frozenset([(1, 2), (3, 2), (2, 1), (2, 2)])
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (2, 2)},
        target_ids=frozenset(),
        occupied=occupied,
    )
    for _ in range(20):
        command = _move_randomly(1, ctx)
        if command is not None:
            assert command.args == ("down",)


def test_move_randomly_returns_none_when_all_blocked() -> None:
    game_map = make_bordered_map(3, 3)
    game_map.place_entity(1, 1, 1)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (1, 1)},
        target_ids=frozenset(),
        occupied=frozenset(),
    )
    command = _move_randomly(1, ctx)
    assert command is None


# ---------------------------------------------------------------------------
# _step_toward
# ---------------------------------------------------------------------------


def test_step_toward_returns_right_command() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 2, 2)
    game_map.place_entity(2, 10, 2)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (2, 2), 2: (10, 2)},
        target_ids=frozenset([2]),
        occupied=frozenset([(2, 2), (10, 2)]),
    )
    command = _step_toward(1, 2, ctx)
    assert command is not None
    assert command.command_type == CommandType.MOVE
    assert command.actor == "1"
    assert command.args == ("right",)


def test_step_toward_returns_none_when_no_path() -> None:
    game_map = make_bordered_map(5, 5)
    game_map.place_entity(1, 1, 1)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (1, 1), 2: (1, 1)},
        target_ids=frozenset([2]),
        occupied=frozenset([(1, 1)]),
    )
    command = _step_toward(1, 2, ctx)
    assert command is None


def test_step_toward_returns_none_when_adjacent_to_target() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 9, 5)
    game_map.place_entity(2, 10, 5)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (9, 5), 2: (10, 5)},
        target_ids=frozenset([2]),
        occupied=frozenset([(9, 5), (10, 5)]),
    )
    command = _step_toward(1, 2, ctx)
    assert command is None


# ---------------------------------------------------------------------------
# StateMachineBehaviour — state machine
# ---------------------------------------------------------------------------


def test_state_machine_starts_in_initial_state() -> None:
    b = StateMachineBehaviour(WanderState())
    assert isinstance(b._state, WanderState)  # noqa: SLF001


def test_state_machine_custom_sight_range() -> None:
    b = StateMachineBehaviour(WanderState(sight_range=12))
    assert b._state.sight_range == 12  # noqa: SLF001


def test_wander_act_returns_list() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    ctx = _make_ctx(game_map, 1, (5, 5))
    b = StateMachineBehaviour(WanderState(sight_range=8))
    result = b.act(1, ctx)
    assert isinstance(result, list)


def test_wander_returns_move_command_when_no_target_in_sight() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    ctx = _make_ctx(game_map, 1, (5, 5))
    b = StateMachineBehaviour(WanderState(sight_range=8))
    commands = b.act(1, ctx)
    assert isinstance(b._state, WanderState)  # noqa: SLF001
    assert len(commands) > 0
    assert commands[0].command_type == CommandType.MOVE


def test_wander_transitions_to_chase_on_sight() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 7, 5)
    ctx = _make_ctx(game_map, 1, (5, 5), target_id=2, target_pos=(7, 5))
    b = StateMachineBehaviour(WanderState(sight_range=8))
    commands = b.act(1, ctx)
    assert isinstance(b._state, ChaseState)  # noqa: SLF001
    assert b._state.target_id == 2  # noqa: SLF001
    # Transition tick emits TARGET (which primes cooldown and sets target_id)
    assert len(commands) == 1
    assert commands[0].command_type == CommandType.TARGET


def test_wander_no_transition_when_target_out_of_range() -> None:
    game_map = make_bordered_map(40, 40)
    game_map.place_entity(1, 2, 2)
    game_map.place_entity(2, 30, 30)
    ctx = _make_ctx(game_map, 1, (2, 2), target_id=2, target_pos=(30, 30))
    b = StateMachineBehaviour(WanderState(sight_range=4))
    b.act(1, ctx)
    assert isinstance(b._state, WanderState)  # noqa: SLF001


def test_chase_returns_move_command_toward_target() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 2, 5)
    game_map.place_entity(2, 10, 5)
    ctx = _make_ctx(game_map, 1, (2, 5), target_id=2, target_pos=(10, 5))
    b = StateMachineBehaviour(WanderState(sight_range=15))
    b.act(1, ctx)  # WANDER → CHASE transition
    assert isinstance(b._state, ChaseState)  # noqa: SLF001
    commands = b.act(1, ctx)  # CHASE tick
    assert len(commands) == 1
    assert commands[0].command_type == CommandType.MOVE
    assert commands[0].args == ("right",)


def test_chase_returns_to_wander_when_target_lost() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    ctx_no_target = _make_ctx(game_map, 1, (5, 5))
    b = StateMachineBehaviour(ChaseState(sight_range=8, target_id=99))
    commands = b.act(1, ctx_no_target)
    assert isinstance(b._state, WanderState)  # noqa: SLF001
    # WanderState.on_enter() emits CLEAR_PRIME to reset the attack-cooldown bar
    assert len(commands) == 1
    assert commands[0].command_type == CommandType.CLEAR_PRIME


def test_wall_blocks_sight() -> None:
    from faraway_realms.map import Map
    from faraway_realms.tile import floor_tile, wall_tile

    width, height = 15, 10
    tiles = [
        [
            wall_tile()
            if (x == 0 or x == width - 1 or y == 0 or y == height - 1 or x == 7)
            else floor_tile()
            for x in range(width)
        ]
        for y in range(height)
    ]
    game_map = Map(width, height, tiles)
    game_map.place_entity(1, 3, 5)
    game_map.place_entity(2, 11, 5)
    ctx = _make_ctx(game_map, 1, (3, 5), target_id=2, target_pos=(11, 5))
    b = StateMachineBehaviour(WanderState(sight_range=15))
    b.act(1, ctx)
    assert isinstance(b._state, WanderState)  # noqa: SLF001


# ---------------------------------------------------------------------------
# Speed
# ---------------------------------------------------------------------------


def test_wander_move_every_is_slower_than_base() -> None:
    state = WanderState(speed_factor=2.0)
    assert state.current_move_every(6) == 12


def test_chase_move_every_uses_base() -> None:
    state = ChaseState(sight_range=8, target_id=1)
    assert state.current_move_every(6) == 6


def test_state_machine_delegates_move_every_to_state() -> None:
    b = StateMachineBehaviour(WanderState(speed_factor=2.0))
    assert b.current_move_every(6) == 12


# ---------------------------------------------------------------------------
# ChaseState.on_enter emits TARGET (sets target_id + primes cooldown)
# ---------------------------------------------------------------------------


def test_chase_on_enter_emits_target_command() -> None:
    state = ChaseState(sight_range=8, target_id=2)
    cmds = state.on_enter(npc_id=1)
    assert len(cmds) == 1
    assert cmds[0].command_type == CommandType.TARGET
    assert cmds[0].actor == "1"
    assert cmds[0].args == ("2",)


# ---------------------------------------------------------------------------
# preferred_ability and FleeState tests
# ---------------------------------------------------------------------------


def test_wander_state_passes_preferred_ability_to_chase() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 7, 5)
    ctx = _make_ctx(game_map, 1, (5, 5), target_id=2, target_pos=(7, 5))
    b = StateMachineBehaviour(WanderState(sight_range=8, preferred_ability="bite"))
    b.act(1, ctx)  # triggers WANDER → CHASE transition
    assert isinstance(b._state, ChaseState)  # noqa: SLF001
    assert b._state.preferred_ability == "bite"  # noqa: SLF001


def test_chase_state_emits_cast_when_ability_ready() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 9, 5)
    game_map.place_entity(2, 10, 5)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (9, 5), 2: (10, 5)},
        target_ids=frozenset([2]),
        occupied=frozenset([(9, 5), (10, 5)]),
        ability_cooldowns=frozenset(),  # ability is ready
    )
    state = ChaseState(sight_range=8, target_id=2, preferred_ability="bite")
    cmds = state.act(1, ctx)
    assert len(cmds) == 1
    assert cmds[0].command_type == CommandType.CAST
    assert "bite" in cmds[0].args


def test_chase_state_falls_back_to_attack_when_ability_on_cooldown() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 9, 5)
    game_map.place_entity(2, 10, 5)
    ctx = BehaviourContext(
        game_map=game_map,
        all_positions={1: (9, 5), 2: (10, 5)},
        target_ids=frozenset([2]),
        occupied=frozenset([(9, 5), (10, 5)]),
        ability_cooldowns=frozenset(["bite"]),  # on cooldown
    )
    state = ChaseState(sight_range=8, target_id=2, preferred_ability="bite")
    cmds = state.act(1, ctx)
    assert len(cmds) == 1
    assert cmds[0].command_type == CommandType.ATTACK


def test_flee_state_moves_away_from_target() -> None:
    game_map = make_bordered_map(20, 20)
    # Place NPC at (1, 5); target at (10, 5) to the right.
    # Only left (x-1=0) is blocked by wall.
    # Manhattan distances from target (10,5): right=8, left=10, up/down=10
    # Actually: npc=(1,5), target=(10,5)
    # left (0,5): dist = |0-10|+|5-5| = 10; but (0,5) is a wall — not walkable
    # right (2,5): dist = |2-10|+|5-5| = 8
    # up (1,4): dist = |1-10|+|4-5| = 10
    # down (1,6): dist = |1-10|+|6-5| = 10
    # up is checked before down and gives 10 vs right=8, so up wins.
    game_map.place_entity(1, 1, 5)
    game_map.place_entity(2, 10, 5)
    ctx = _make_ctx(game_map, 1, (1, 5), target_id=2, target_pos=(10, 5))
    state = FleeState(sight_range=8)
    cmds = state.act(1, ctx)
    assert len(cmds) == 1
    assert cmds[0].command_type == CommandType.MOVE
    # Should move away from the target; up or down both maximise distance
    assert cmds[0].args[0] in ("up", "down")


def test_flee_state_transitions_to_wander_on_los_loss() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    ctx = _make_ctx(game_map, 1, (5, 5))  # no targets in sight
    state = FleeState(sight_range=8)
    next_state = state.transition(1, ctx)
    assert isinstance(next_state, WanderState)


def test_flee_state_stays_when_target_visible() -> None:
    game_map = make_bordered_map(20, 20)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 7, 5)
    ctx = _make_ctx(game_map, 1, (5, 5), target_id=2, target_pos=(7, 5))
    state = FleeState(sight_range=8)
    next_state = state.transition(1, ctx)
    assert next_state is None


def test_flee_state_speed_factor() -> None:
    state = FleeState(speed_factor=0.5)
    assert state.current_move_every(10) == 5
