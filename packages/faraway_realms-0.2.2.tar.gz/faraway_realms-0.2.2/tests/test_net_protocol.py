"""Tests for the msgpack wire protocol (framing layer)."""

from __future__ import annotations

import asyncio

from faraway_realms.net.protocol import recv_message, send_message


async def _make_pipe():
    """Create an in-memory (reader, writer) pair via connected sockets."""
    srv_ready = asyncio.Event()
    result = {}

    async def handler(reader, writer):
        result["reader"] = reader
        result["writer"] = writer
        srv_ready.set()
        # Keep alive until the test is done
        await asyncio.sleep(10)

    server = await asyncio.start_server(handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    c_reader, c_writer = await asyncio.open_connection("127.0.0.1", port)
    await srv_ready.wait()
    server.close()
    return c_reader, c_writer, result["reader"], result["writer"]


class TestMsgpackFraming:
    def test_round_trip_simple(self):
        async def _run():
            cr, cw, sr, sw = await _make_pipe()
            payload = {"type": "tick", "value": 42}
            await send_message(cw, payload)
            got = await recv_message(sr)
            assert got == payload
            cw.close()
            sw.close()

        asyncio.run(_run())

    def test_round_trip_nested(self):
        async def _run():
            cr, cw, sr, sw = await _make_pipe()
            payload = {
                "type": "tick",
                "entities": [
                    {"id": 1, "pos": [5, 5], "color": [255, 0, 0]},
                ],
                "blood_tiles": {"3,4": {"color": [200, 0, 0], "alpha": 80}},
                "fraction": 0.75,
                "nothing": None,
            }
            await send_message(cw, payload)
            got = await recv_message(sr)
            assert got == payload
            cw.close()
            sw.close()

        asyncio.run(_run())

    def test_send_returns_byte_count(self):
        async def _run():
            cr, cw, sr, sw = await _make_pipe()
            payload = {"type": "auth", "uuid": "abc"}
            n = await send_message(cw, payload)
            assert isinstance(n, int)
            assert n > 0
            # Byte count should be less than JSON equivalent
            import json

            json_size = len(json.dumps(payload).encode())
            assert n <= json_size
            cw.close()
            sw.close()

        asyncio.run(_run())

    def test_multiple_messages(self):
        async def _run():
            cr, cw, sr, sw = await _make_pipe()
            msgs = [
                {"type": "auth", "uuid": "x"},
                {"type": "tick", "n": 1},
                {"type": "tick", "n": 2},
            ]
            for m in msgs:
                await send_message(cw, m)
            for m in msgs:
                got = await recv_message(sr)
                assert got == m
            cw.close()
            sw.close()

        asyncio.run(_run())

    def test_string_keys_preserved(self):
        """Dict keys must be str after deserialization, not bytes."""

        async def _run():
            cr, cw, sr, sw = await _make_pipe()
            payload = {"5,5": {"color": [200, 0, 0]}}
            await send_message(cw, payload)
            got = await recv_message(sr)
            assert all(isinstance(k, str) for k in got)
            assert all(isinstance(k, str) for k in got["5,5"])
            cw.close()
            sw.close()

        asyncio.run(_run())
