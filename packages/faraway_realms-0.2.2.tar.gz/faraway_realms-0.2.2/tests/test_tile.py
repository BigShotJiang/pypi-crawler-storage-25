from faraway_realms.tile import Tile, floor_tile, wall_tile


def test_floor_tile_is_walkable():
    assert floor_tile().walkable is True


def test_wall_tile_is_not_walkable():
    assert wall_tile().walkable is False


def test_tile_default_char():
    tile = Tile(walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255))
    assert tile.char == ord(" ")


def test_tile_custom_char():
    tile = Tile(
        walkable=True, bg_color=(0, 0, 0), fg_color=(255, 255, 255), char=ord("@")
    )
    assert tile.char == ord("@")


def test_tile_color_fields():
    bg = (10, 20, 30)
    fg = (40, 50, 60)
    tile = Tile(walkable=False, bg_color=bg, fg_color=fg)
    assert tile.bg_color == bg
    assert tile.fg_color == fg


def test_cave_floor_tile_is_walkable() -> None:
    from faraway_realms.tile import cave_floor_tile

    t = cave_floor_tile()
    assert t.walkable is True


def test_cave_wall_tile_is_not_walkable() -> None:
    from faraway_realms.tile import cave_wall_tile

    t = cave_wall_tile()
    assert t.walkable is False


def test_cave_tiles_have_brownish_bg() -> None:
    from faraway_realms.tile import cave_floor_tile, cave_wall_tile

    floor = cave_floor_tile()
    wall = cave_wall_tile()
    # Brown = more red than blue, meaningful green
    assert floor.bg_color[0] > floor.bg_color[2]  # red > blue
    assert wall.bg_color[0] > wall.bg_color[2]
