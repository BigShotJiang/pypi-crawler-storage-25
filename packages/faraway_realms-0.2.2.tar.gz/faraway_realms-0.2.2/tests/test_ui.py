from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import tcod.console
import tcod.event

from faraway_realms.commands import CommandType
from faraway_realms.entity import CharacterEntity, Player
from faraway_realms.game import Game
from faraway_realms.map import make_bordered_map
from faraway_realms.ui import (
    _STATUS_BAR_W,
    _STATUS_HALF,
    BINDINGS,
    CONSOLE_HEIGHT,
    CONSOLE_WIDTH,
    MAP_X,
    MAP_Y,
    NAME_Y,
    STATUS_Y,
    GameUI,
    _dim,
)
from faraway_realms.ui.layout import _MEMORY_TINT, _SEP_CHAR

_TILESET = (
    Path(__file__).parent.parent
    / "faraway_realms"
    / "assets"
    / "terminal16x16_gs_ro.png"
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def game() -> Game:
    game_map = make_bordered_map(20, 15)
    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    player = Player(username="tester", entity=entity)
    g = Game(game_map=game_map)
    g.add_player(player)
    game_map.place_entity(entity.entity_id, 10, 7)
    return g


@pytest.fixture
def ui(game: Game) -> GameUI:
    # Use the real tileset asset so the path exists; rendering is headless
    player = next(iter(game._players.values()))  # noqa: SLF001
    return GameUI(game=game, tileset_path=_TILESET, viewing_player=player)


@pytest.fixture
def console() -> tcod.console.Console:
    return tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")


@pytest.fixture
def mock_ctx() -> MagicMock:
    ctx = MagicMock()
    ctx.sdl_window = MagicMock()
    return ctx


# ---------------------------------------------------------------------------
# Input buffer / submit logic
# ---------------------------------------------------------------------------


def test_submit_non_slash_adds_to_chat(ui: GameUI, game: Game) -> None:
    ui._input_buffer = "hello world"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert any(m.text == "hello world" for m in game.get_chat_history())


def test_submit_slash_enqueues_command(ui: GameUI, game: Game) -> None:
    ui._input_buffer = "/move me left"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert game._command_queue  # noqa: SLF001
    assert game._command_queue[0].command_type == CommandType.MOVE  # noqa: SLF001


def test_submit_clears_buffer(ui: GameUI) -> None:
    ui._input_buffer = "/move me left"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert ui._input_buffer == ""  # noqa: SLF001


def test_text_input_appends_when_focused(ui: GameUI) -> None:
    ui._chat_focused = True  # noqa: SLF001
    event = MagicMock(spec=tcod.event.TextInput)
    event.text = "h"
    ui._handle_text_input(event)  # noqa: SLF001
    assert ui._input_buffer == "h"  # noqa: SLF001


def test_text_input_ignored_when_unfocused(ui: GameUI) -> None:
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.TextInput)
    event.text = "h"
    ui._handle_text_input(event)  # noqa: SLF001
    assert ui._input_buffer == ""  # noqa: SLF001


def test_backspace_removes_char_when_focused(ui: GameUI) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "abc"  # noqa: SLF001
    ui._handle_backspace()  # noqa: SLF001
    assert ui._input_buffer == "ab"  # noqa: SLF001


def test_backspace_noop_when_unfocused(ui: GameUI) -> None:
    ui._chat_focused = False  # noqa: SLF001
    ui._input_buffer = "abc"  # noqa: SLF001
    ui._handle_backspace()  # noqa: SLF001
    assert ui._input_buffer == "abc"  # noqa: SLF001


# ---------------------------------------------------------------------------
# Focus / unfocus
# ---------------------------------------------------------------------------


def test_focus_chat_sets_flag(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._focus_chat(mock_ctx)  # noqa: SLF001
    assert ui._chat_focused is True  # noqa: SLF001


def test_focus_chat_calls_start_text_input(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._focus_chat(mock_ctx)  # noqa: SLF001
    mock_ctx.sdl_window.start_text_input.assert_called_once()


def test_unfocus_chat_clears_flag_and_buffer(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "abc"  # noqa: SLF001
    ui._unfocus_chat(mock_ctx)  # noqa: SLF001
    assert ui._chat_focused is False  # noqa: SLF001
    assert ui._input_buffer == ""  # noqa: SLF001


def test_unfocus_chat_calls_stop_text_input(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._unfocus_chat(mock_ctx)  # noqa: SLF001
    mock_ctx.sdl_window.stop_text_input.assert_called_once()


def test_focus_chat_no_sdl_window(ui: GameUI) -> None:
    ctx = MagicMock()
    ctx.sdl_window = None
    ui._focus_chat(ctx)  # noqa: SLF001 — should not raise
    assert ui._chat_focused is True  # noqa: SLF001


# ---------------------------------------------------------------------------
# on_return logic
# ---------------------------------------------------------------------------


def test_on_return_focuses_when_unfocused(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._chat_focused = False  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert ui._chat_focused is True  # noqa: SLF001


def test_on_return_submits_when_focused_with_text(
    ui: GameUI, mock_ctx: MagicMock, game: Game
) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "hello"  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert any(m.text == "hello" for m in game.get_chat_history())


def test_on_return_unfocuses_after_submit(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "hello"  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert ui._chat_focused is False  # noqa: SLF001


def test_on_return_unfocuses_when_focused_empty(
    ui: GameUI, mock_ctx: MagicMock
) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = ""  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert ui._chat_focused is False  # noqa: SLF001


# ---------------------------------------------------------------------------
# Escape handling
# ---------------------------------------------------------------------------


def test_handle_escape_unfocuses_when_focused(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._chat_focused = True  # noqa: SLF001
    result = ui._handle_escape(mock_ctx)  # noqa: SLF001
    assert result is True
    assert ui._chat_focused is False  # noqa: SLF001


def test_handle_escape_returns_false_when_unfocused(
    ui: GameUI, mock_ctx: MagicMock
) -> None:
    ui._chat_focused = False  # noqa: SLF001
    result = ui._handle_escape(mock_ctx)  # noqa: SLF001
    assert result is False


# ---------------------------------------------------------------------------
# Key bindings
# ---------------------------------------------------------------------------


def test_bound_key_enqueues_command_when_unfocused(ui: GameUI, game: Game) -> None:
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym(ord("h"))
    ui._handle_bound_key(event)  # noqa: SLF001
    assert game._command_queue  # noqa: SLF001
    assert game._command_queue[0].command_type == CommandType.MOVE  # noqa: SLF001


def test_bound_key_ignored_when_focused(ui: GameUI, game: Game) -> None:
    ui._chat_focused = True  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym(ord("h"))
    ui._handle_bound_key(event)  # noqa: SLF001
    assert not game._command_queue  # noqa: SLF001


def test_unbound_key_ignored(ui: GameUI, game: Game) -> None:
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym(ord("y"))  # y is not bound
    ui._handle_bound_key(event)  # noqa: SLF001
    assert not game._command_queue  # noqa: SLF001


def test_all_vim_directions_in_bindings() -> None:
    values = set(BINDINGS.values())
    for direction in ("left", "right", "up", "down"):
        assert f"/move me {direction}" in values


# ---------------------------------------------------------------------------
# Rendering (smoke tests — verify no crash, spot-check output)
# ---------------------------------------------------------------------------


def _all_visible(height: int, width: int) -> np.ndarray:
    return np.ones((height, width), dtype=bool)


def _none_visible(height: int, width: int) -> np.ndarray:
    return np.zeros((height, width), dtype=bool)


def test_render_map_draws_tiles(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_map(console, (0, 0), None)  # noqa: SLF001
    # Floor tile char is '.' (46); at least one interior cell should show it
    interior_chars = console.rgb[1:-1, 1:-1]["ch"]
    assert (interior_chars == ord(".")).any()


def test_render_map_draws_player(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_entities(console, (0, 0), None)  # noqa: SLF001
    assert console.rgb[7, 10]["ch"] == ord("@")


# ---------------------------------------------------------------------------
# Fog of war
# ---------------------------------------------------------------------------


def test_visible_tile_renders_at_full_color(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    visible = _all_visible(15, 20)
    ui._render_map_cell(console, 5, 5, (0, 0), visible)  # noqa: SLF001
    tile = game.game_map.get_tile(5, 5)
    assert tuple(console.rgb[MAP_Y + 5, MAP_X + 5]["bg"]) == tile.bg_color


def test_visible_tile_marks_explored(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    visible = _all_visible(15, 20)
    player = next(iter(game._players.values()))  # noqa: SLF001
    assert (5, 5) not in player.explored
    ui._render_map_cell(console, 5, 5, (0, 0), visible)  # noqa: SLF001
    assert (5, 5) in player.explored


def test_explored_tile_renders_dimmed(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    visible = _none_visible(15, 20)
    player = next(iter(game._players.values()))  # noqa: SLF001
    player.explored.add((5, 5))
    ui._render_map_cell(console, 5, 5, (0, 0), visible)  # noqa: SLF001
    tile = game.game_map.get_tile(5, 5)
    assert tuple(console.rgb[MAP_Y + 5, MAP_X + 5]["bg"]) == _dim(
        tile.bg_color, _MEMORY_TINT
    )


def test_unexplored_tile_not_rendered(
    ui: GameUI, console: tcod.console.Console
) -> None:
    visible = _none_visible(15, 20)
    ui._render_map_cell(console, 5, 5, (0, 0), visible)  # noqa: SLF001
    assert console.rgb[MAP_Y + 5, MAP_X + 5]["ch"] == 32  # space — nothing drawn


def test_entity_hidden_outside_fov(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    visible = _none_visible(15, 20)
    player = next(iter(game._players.values()))  # noqa: SLF001
    ui._render_entity(console, player.entity, (0, 0), visible)  # noqa: SLF001
    assert console.rgb[MAP_Y + 7, MAP_X + 10]["ch"] == 32  # not rendered


# ---------------------------------------------------------------------------
# Camera
# ---------------------------------------------------------------------------


def test_camera_origin_clamps_to_zero_for_small_map(ui: GameUI) -> None:
    # Player at (10, 7) on a 20x15 map — viewport is larger so cam stays at (0, 0)
    cam = ui._camera_origin()  # noqa: SLF001
    assert cam == (0, 0)


def test_camera_centers_on_player_large_map(game: Game) -> None:
    from faraway_realms.map import make_bordered_map
    from faraway_realms.ui import MAP_HEIGHT, MAP_WIDTH

    big_map = make_bordered_map(200, 200)
    game.game_map = big_map
    big_map.place_entity(1, 100, 100)
    player = next(iter(game._players.values()))  # noqa: SLF001
    ui = GameUI(game=game, tileset_path=_TILESET, viewing_player=player)
    cam_x, cam_y = ui._camera_origin()  # noqa: SLF001
    assert cam_x == 100 - MAP_WIDTH // 2
    assert cam_y == 100 - MAP_HEIGHT // 2


def test_camera_clamps_at_map_max(game: Game) -> None:
    from faraway_realms.map import make_bordered_map
    from faraway_realms.ui import MAP_HEIGHT, MAP_WIDTH

    big_map = make_bordered_map(200, 200)
    game.game_map = big_map
    big_map.place_entity(1, 195, 195)
    player = next(iter(game._players.values()))  # noqa: SLF001
    ui = GameUI(game=game, tileset_path=_TILESET, viewing_player=player)
    cam_x, cam_y = ui._camera_origin()  # noqa: SLF001
    assert cam_x == 200 - MAP_WIDTH
    assert cam_y == 200 - MAP_HEIGHT


def test_render_entity_respects_camera_offset(
    ui: GameUI, console: tcod.console.Console
) -> None:
    # Player is at world (10, 7); with cam (5, 3) it should appear at screen (5, 4)
    from faraway_realms.entity import CharacterEntity

    entity = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    ui._render_entity(console, entity, (5, 3), None)  # noqa: SLF001
    assert console.rgb[MAP_Y + 4, MAP_X + 5]["ch"] == ord("@")


def test_arrow_keys_in_bindings() -> None:
    import tcod.event

    from faraway_realms.ui import BINDINGS

    assert tcod.event.KeySym.LEFT in BINDINGS
    assert tcod.event.KeySym.RIGHT in BINDINGS
    assert tcod.event.KeySym.UP in BINDINGS
    assert tcod.event.KeySym.DOWN in BINDINGS


def test_render_chat_empty(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_chat(console)  # noqa: SLF001  — should not raise


def test_render_chat_shows_messages(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    game.add_chat_message("hi there")
    ui._render_chat(console)  # noqa: SLF001
    row_chars = console.rgb[43, 1:10]["ch"].tolist()
    assert ord("h") in row_chars


def test_render_input_line_unfocused(ui: GameUI, console: tcod.console.Console) -> None:
    ui._chat_focused = False  # noqa: SLF001
    ui._render_input_line(console)  # noqa: SLF001
    # Should show '>' prompt, no cursor
    assert console.rgb[48, 1]["ch"] == ord(">")


def test_render_input_line_focused_shows_cursor(
    ui: GameUI, console: tcod.console.Console
) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._render_input_line(console)  # noqa: SLF001
    row = "".join(chr(c) for c in console.rgb[48, 1:6]["ch"].tolist())
    assert "_" in row


def test_render_input_line_bg_color(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_input_line(console)  # noqa: SLF001
    bg = tuple(console.rgb[48, 2]["bg"].tolist())
    assert bg == (40, 40, 40)


def test_render_details_no_crash(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_details(console)  # noqa: SLF001


def test_render_borders_no_crash(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_borders(console)  # noqa: SLF001


def test_render_frame_no_crash(ui: GameUI, console: tcod.console.Console) -> None:
    ui._render_frame(console)  # noqa: SLF001


# ---------------------------------------------------------------------------
# __main__ entry point
# ---------------------------------------------------------------------------


def test_main_runs_without_opening_window() -> None:
    with patch("faraway_realms.__main__.GameUI") as mock_ui_cls:
        mock_ui_cls.return_value.run = MagicMock()
        from faraway_realms.__main__ import main

        main()
        mock_ui_cls.return_value.run.assert_called_once()


# ---------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------


def test_stats_panel_renders_pool_as_text_and_bar(
    console: tcod.console.Console,
) -> None:
    from faraway_realms.entity import CharacterEntity
    from faraway_realms.panels import StatsPanel
    from faraway_realms.stats import Pool, Stat

    entity = CharacterEntity(
        entity_id=99,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Test",
        stats={"health": Pool(base=100), "strength": Stat(base=10)},
    )
    panel = StatsPanel(entity, abbreviations={"health": "HP", "strength": "STR"})
    rows = panel.render(console, x=1, y=1, width=20)

    # Pool consumes 3 rows (text + bar + spacer), Stat consumes 2 (text + spacer)
    assert rows == 5

    # Label row contains "HP: 100/100"
    text_row = "".join(chr(c) for c in console.rgb[1, 1:21]["ch"])
    assert "HP: 100/100" in text_row

    # Bar row (y=2) should have green background for full health
    bar_bg = tuple(console.rgb[2, 1]["bg"].tolist())
    assert bar_bg == (0, 180, 0)  # BAR_FILLED

    # Strength row contains "STR: 10"
    stat_row = "".join(chr(c) for c in console.rgb[4, 1:21]["ch"])
    assert "STR: 10" in stat_row


def test_stats_panel_bar_empty_color_when_depleted(
    console: tcod.console.Console,
) -> None:
    from faraway_realms.entity import CharacterEntity
    from faraway_realms.panels import StatsPanel
    from faraway_realms.stats import Pool

    entity = CharacterEntity(
        entity_id=99,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Test",
        stats={"health": Pool(base=100)},
    )
    pool: Pool = entity.stats["health"]  # type: ignore[assignment]
    pool.modify(-100)  # drain to zero

    panel = StatsPanel(entity)
    panel.render(console, x=0, y=0, width=20)

    # Entire bar row should be empty (red) color
    bar_bg = tuple(console.rgb[1, 0]["bg"].tolist())
    assert bar_bg == (140, 20, 20)  # BAR_EMPTY


def test_panel_cycle_advances_index(game: Game) -> None:
    from faraway_realms.entity import CharacterEntity
    from faraway_realms.panels import StatsPanel

    entity = CharacterEntity(entity_id=99, char=ord("@"), fg_color=(0, 0, 0), name="A")
    p1 = StatsPanel(entity)
    p2 = StatsPanel(entity)
    player = next(iter(game._players.values()))  # noqa: SLF001
    ui = GameUI(
        game=game, tileset_path=_TILESET, viewing_player=player, panels=[p1, p2]
    )

    assert ui._panel_idx == 0  # noqa: SLF001
    ui._cycle_panel()  # noqa: SLF001
    assert ui._panel_idx == 1  # noqa: SLF001
    ui._cycle_panel()  # noqa: SLF001
    assert ui._panel_idx == 0  # wraps around  # noqa: SLF001


def test_cycle_panel_noop_when_chat_focused(game: Game) -> None:
    from faraway_realms.entity import CharacterEntity
    from faraway_realms.panels import StatsPanel

    entity = CharacterEntity(entity_id=99, char=ord("@"), fg_color=(0, 0, 0), name="A")
    panels = [StatsPanel(entity), StatsPanel(entity)]
    player = next(iter(game._players.values()))  # noqa: SLF001
    ui = GameUI(game=game, tileset_path=_TILESET, viewing_player=player, panels=panels)
    ui._chat_focused = True  # noqa: SLF001
    ui._cycle_panel()  # noqa: SLF001
    assert ui._panel_idx == 0  # noqa: SLF001


# ---------------------------------------------------------------------------
# "/" quick-focus
# ---------------------------------------------------------------------------


def test_slash_key_focuses_chat_when_unfocused(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.SLASH
    event.mod = tcod.event.Modifier.NONE
    ui._handle_bound_key(event)  # noqa: SLF001
    assert ui._chat_focused is True  # noqa: SLF001


def test_slash_key_inserts_slash_in_buffer(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.SLASH
    event.mod = tcod.event.Modifier.NONE
    ui._handle_bound_key(event)  # noqa: SLF001
    assert ui._input_buffer == "/"  # noqa: SLF001


def test_slash_key_does_not_enqueue_command(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.SLASH
    event.mod = tcod.event.Modifier.NONE
    ui._handle_bound_key(event)  # noqa: SLF001
    assert ui._game._command_queue == []  # noqa: SLF001


# ---------------------------------------------------------------------------
# Command history — recording
# ---------------------------------------------------------------------------


def test_submit_slash_command_adds_to_history(ui: GameUI) -> None:
    ui._input_buffer = "/move me left"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert ui._command_history == ["/move me left"]  # noqa: SLF001


def test_submit_non_slash_does_not_add_to_history(ui: GameUI) -> None:
    ui._input_buffer = "hello"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert ui._command_history == []  # noqa: SLF001


def test_submit_resets_history_index(ui: GameUI) -> None:
    ui._command_history = ["/move me left"]  # noqa: SLF001
    ui._history_idx = 0  # noqa: SLF001
    ui._input_buffer = "/move me right"  # noqa: SLF001
    ui._submit_input()  # noqa: SLF001
    assert ui._history_idx == -1  # noqa: SLF001


# ---------------------------------------------------------------------------
# Command history — navigation (older / newer)
# ---------------------------------------------------------------------------


def test_history_older_loads_most_recent(ui: GameUI) -> None:
    ui._command_history = ["/cmd a", "/cmd b", "/cmd c"]  # noqa: SLF001
    ui._history_older()  # noqa: SLF001
    assert ui._input_buffer == "/cmd c"  # noqa: SLF001


def test_history_older_saves_current_buffer(ui: GameUI) -> None:
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._input_buffer = "draft"  # noqa: SLF001
    ui._history_older()  # noqa: SLF001
    assert ui._history_buffer == "draft"  # noqa: SLF001


def test_history_older_steps_further_back(ui: GameUI) -> None:
    ui._command_history = ["/cmd a", "/cmd b", "/cmd c"]  # noqa: SLF001
    ui._history_older()  # noqa: SLF001
    ui._history_older()  # noqa: SLF001
    assert ui._input_buffer == "/cmd b"  # noqa: SLF001


def test_history_older_clamps_at_beginning(ui: GameUI) -> None:
    ui._command_history = ["/cmd a", "/cmd b"]  # noqa: SLF001
    ui._history_older()
    ui._history_older()
    ui._history_older()  # should not go below 0  # noqa: SLF001
    assert ui._input_buffer == "/cmd a"  # noqa: SLF001


def test_history_older_noop_when_empty(ui: GameUI) -> None:
    ui._history_older()  # noqa: SLF001
    assert ui._input_buffer == ""  # noqa: SLF001


def test_history_newer_moves_forward(ui: GameUI) -> None:
    ui._command_history = ["/cmd a", "/cmd b", "/cmd c"]  # noqa: SLF001
    ui._history_older()  # → /cmd c, idx=2
    ui._history_older()  # → /cmd b, idx=1
    ui._history_newer()  # → /cmd c, idx=2  # noqa: SLF001
    assert ui._input_buffer == "/cmd c"  # noqa: SLF001


def test_history_newer_at_end_restores_draft(ui: GameUI) -> None:
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._input_buffer = "draft"  # noqa: SLF001
    ui._history_older()  # saves draft, goes to /cmd a
    ui._history_newer()  # past end → restore draft  # noqa: SLF001
    assert ui._input_buffer == "draft"  # noqa: SLF001
    assert ui._history_idx == -1  # noqa: SLF001


def test_history_newer_noop_when_not_browsing(ui: GameUI) -> None:
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._history_idx = -1  # noqa: SLF001
    ui._input_buffer = "unchanged"  # noqa: SLF001
    ui._history_newer()  # noqa: SLF001
    assert ui._input_buffer == "unchanged"  # noqa: SLF001


# ---------------------------------------------------------------------------
# Command history — key handling (UP/DOWN when focused)
# ---------------------------------------------------------------------------


def _up_event() -> MagicMock:
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.UP
    return event


def _down_event() -> MagicMock:
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.DOWN
    return event


def test_up_key_when_focused_navigates_older(ui: GameUI) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._handle_history_key(_up_event())  # noqa: SLF001
    assert ui._input_buffer == "/cmd a"  # noqa: SLF001


def test_down_key_when_focused_navigates_newer(ui: GameUI) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._history_idx = 0  # noqa: SLF001
    ui._handle_history_key(_down_event())  # noqa: SLF001
    assert ui._history_idx == -1  # noqa: SLF001


def test_history_key_ignored_when_unfocused(ui: GameUI) -> None:
    ui._chat_focused = False  # noqa: SLF001
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    result = ui._handle_history_key(_up_event())  # noqa: SLF001
    assert result is False
    assert ui._input_buffer == ""  # no change


def test_text_input_resets_history_idx(ui: GameUI) -> None:
    ui._chat_focused = True  # noqa: SLF001
    ui._history_idx = 1  # noqa: SLF001
    event = MagicMock(spec=tcod.event.TextInput)
    event.text = "x"
    ui._handle_text_input(event)  # noqa: SLF001
    assert ui._history_idx == -1  # noqa: SLF001


def test_unfocus_resets_history_state(ui: GameUI, mock_ctx: MagicMock) -> None:
    ui._command_history = ["/cmd a"]  # noqa: SLF001
    ui._history_idx = 0  # noqa: SLF001
    ui._history_buffer = "draft"  # noqa: SLF001
    ui._unfocus_chat(mock_ctx)  # noqa: SLF001
    assert ui._history_idx == -1  # noqa: SLF001
    assert ui._history_buffer == ""  # noqa: SLF001


# ---------------------------------------------------------------------------
# Status bar
# ---------------------------------------------------------------------------


def test_status_bar_renders_separator(
    ui: GameUI, console: tcod.console.Console
) -> None:
    ui._render_status_bar(console)  # noqa: SLF001
    assert console.rgb[STATUS_Y, _STATUS_HALF]["ch"] == _SEP_CHAR


def test_status_bar_player_bar_empty_when_unprimed(
    ui: GameUI, console: tcod.console.Console
) -> None:
    """Player has no target → attack bar is hidden (shows empty background)."""
    ui._render_status_bar(console)  # noqa: SLF001
    bar_end = _STATUS_HALF - 1  # bar is flush right to the separator
    bg = tuple(console.rgb[STATUS_Y, bar_end]["bg"].tolist())
    assert bg == (20, 20, 20)  # _EMPTY_BAR_COLOR — no target, bar hidden


def test_status_bar_player_bar_empty_immediately_after_attack(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    """Fraction = 0.0 right after an attack → bar is all empty."""
    from faraway_realms.commands import Command, CommandType
    from faraway_realms.entity import NonPlayerEntity
    from faraway_realms.stats import Pool
    from faraway_realms.ui import _PLAYER_BAR_EMPTY

    player = next(iter(game._players.values()))  # noqa: SLF001
    player.entity.attack_every = 100  # long cooldown so it stays at 0 after one tick

    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=200)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 7)

    player = next(iter(game._players.values()))  # noqa: SLF001
    player.entity.target_id = npc.entity_id  # bar only shows when targeting

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
        )
    )
    game.tick()  # tick 1: attack lands

    ui._render_status_bar(console)  # noqa: SLF001

    # Leftmost cell of player bar should be empty (fraction ~ 1/100 rounds to 0 filled)
    bar_start = _STATUS_HALF - _STATUS_BAR_W  # bar is flush right against the separator
    bg = tuple(console.rgb[STATUS_Y, bar_start]["bg"].tolist())
    assert bg == _PLAYER_BAR_EMPTY


def test_status_bar_no_target_dims_enemy_region(
    ui: GameUI, console: tcod.console.Console
) -> None:
    """When no target is selected the enemy bar region shows dark background."""
    player = next(iter(ui._game._players.values()))  # noqa: SLF001
    player.entity.target_id = None

    ui._render_status_bar(console)  # noqa: SLF001

    bar_x = _STATUS_HALF + 1  # col 29
    bg = tuple(console.rgb[STATUS_Y, bar_x]["bg"].tolist())
    assert bg == (20, 20, 20)


def test_status_bar_target_bar_uses_entity_color(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    """With a target that is ready to attack, bar cells use the entity's fg_color."""
    from faraway_realms.entity import NonPlayerEntity
    from faraway_realms.stats import Pool

    target_color = (200, 50, 0)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=target_color,
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=50)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 7)

    player = next(iter(game._players.values()))  # noqa: SLF001
    player.entity.target_id = 2

    # Prime the NPC so its bar is full (fraction = 1.0).
    game._combat.prime(npc.entity_id, 0)  # noqa: SLF001
    for _ in range(npc.attack_every + 1):
        game.tick()

    ui._render_status_bar(console)  # noqa: SLF001

    # NPC cooldown expired → fraction = 1.0 → first bar cell filled with fg_color
    bar_x = _STATUS_HALF + 1  # first bar cell at col 29
    bg = tuple(console.rgb[STATUS_Y, bar_x]["bg"].tolist())
    assert bg == target_color


def test_status_bar_player_name_printed(
    ui: GameUI, console: tcod.console.Console
) -> None:
    ui._render_status_bar(console)  # noqa: SLF001
    ui._name_bar.render(console)  # noqa: SLF001
    # "Hero" right-aligned in the left half (cols 0 to _STATUS_HALF-1)
    name_chars = "".join(
        chr(c) for c in console.rgb[NAME_Y, 0:_STATUS_HALF]["ch"].tolist()
    )
    assert "Hero" in name_chars


# ---------------------------------------------------------------------------
# Overlays — HelpOverlay
# ---------------------------------------------------------------------------


def test_help_overlay_renders_without_error(console: tcod.console.Console) -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    HelpOverlay().render(console)


def test_help_overlay_topic_renders(console: tcod.console.Console) -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    HelpOverlay(topic="move").render(console)


def test_help_overlay_esc_closes() -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.ESCAPE
    assert HelpOverlay().handle_key(event) is False


def test_help_overlay_other_key_stays_open() -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym(ord("a"))
    assert HelpOverlay().handle_key(event) is True


def test_question_mark_opens_overlay(ui: GameUI, mock_ctx: MagicMock) -> None:
    """KeySym.QUESTION (SDL sends shifted character as distinct sym)."""
    from faraway_realms.ui.overlays import HelpOverlay

    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.QUESTION
    event.mod = tcod.event.Modifier.NONE
    ui._handle_bound_key(event)  # noqa: SLF001
    assert isinstance(ui._overlay, HelpOverlay)  # noqa: SLF001


def test_slash_shift_opens_overlay(ui: GameUI, mock_ctx: MagicMock) -> None:
    """SLASH + Shift opens help overlay (SDL variant that doesn't remap sym)."""
    from faraway_realms.ui.overlays import HelpOverlay

    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.SLASH
    event.mod = tcod.event.Modifier.LSHIFT
    ui._handle_bound_key(event)  # noqa: SLF001
    assert isinstance(ui._overlay, HelpOverlay)  # noqa: SLF001


def test_slash_no_shift_focuses_chat(ui: GameUI, mock_ctx: MagicMock) -> None:
    """Plain SLASH without Shift focuses chat, not overlay."""
    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = False  # noqa: SLF001
    event = MagicMock(spec=tcod.event.KeyDown)
    event.sym = tcod.event.KeySym.SLASH
    event.mod = tcod.event.Modifier.NONE
    ui._handle_bound_key(event)  # noqa: SLF001
    assert ui._overlay is None  # noqa: SLF001
    assert ui._chat_focused is True  # noqa: SLF001


def test_help_command_opens_overlay(ui: GameUI, mock_ctx: MagicMock) -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "/help"  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert isinstance(ui._overlay, HelpOverlay)  # noqa: SLF001
    assert ui._overlay.topic is None  # noqa: SLF001


def test_help_topic_command_opens_overlay(ui: GameUI, mock_ctx: MagicMock) -> None:
    from faraway_realms.ui.overlays import HelpOverlay

    ui._ctx = mock_ctx  # noqa: SLF001
    ui._chat_focused = True  # noqa: SLF001
    ui._input_buffer = "/help move"  # noqa: SLF001
    ui._on_return(mock_ctx)  # noqa: SLF001
    assert isinstance(ui._overlay, HelpOverlay)  # noqa: SLF001
    assert ui._overlay.topic == "move"  # noqa: SLF001


# ---------------------------------------------------------------------------
# ScreenFlash effect
# ---------------------------------------------------------------------------


def test_screen_flash_inactive_by_default() -> None:
    from faraway_realms.ui.effects import ScreenFlash

    assert ScreenFlash().active is False


def test_screen_flash_trigger_activates() -> None:
    from faraway_realms.ui.effects import ScreenFlash

    f = ScreenFlash()
    f.trigger()
    assert f.active is True


def test_screen_flash_render_decrements_to_inactive(
    console: tcod.console.Console,
) -> None:
    from faraway_realms.ui.effects import ScreenFlash

    f = ScreenFlash(total_frames=3)
    f.trigger()
    for _ in range(3):
        f.render(console)
    assert f.active is False


def test_screen_flash_renders_without_error(console: tcod.console.Console) -> None:
    from faraway_realms.ui.effects import ScreenFlash

    f = ScreenFlash()
    f.trigger()
    f.render(console)  # must not raise


def test_screen_flash_color_param() -> None:
    from faraway_realms.ui.effects import ScreenFlash

    f = ScreenFlash(color=(0, 200, 0))
    assert f.color == (0, 200, 0)


def test_game_ui_triggers_flash_on_viewing_player_hit(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    from faraway_realms.entity import NonPlayerEntity
    from faraway_realms.stats import Pool

    player = next(iter(game._players.values()))  # noqa: SLF001
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=200), "strength": Pool(base=5)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 7)
    npc.target_id = player.entity.entity_id

    # NPC attacks player
    from faraway_realms.commands import Command, CommandType

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor=str(npc.entity_id),
            args=(str(player.entity.entity_id),),
            raw="/attack 2 1",
        )
    )
    game.tick()

    assert game.get_hit_seq(player.entity.entity_id) > 0
    ui._render_frame(console)  # noqa: SLF001
    assert ui._damage_flash.active  # noqa: SLF001


def test_game_ui_no_flash_when_other_entity_hit(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    from faraway_realms.commands import Command, CommandType
    from faraway_realms.entity import NonPlayerEntity
    from faraway_realms.stats import Pool

    player = next(iter(game._players.values()))  # noqa: SLF001
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=200)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 7)
    player.entity.target_id = npc.entity_id

    # Player attacks NPC (not the viewing player getting hit)
    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor=str(player.entity.entity_id),
            args=(str(npc.entity_id),),
            raw="/attack 1 2",
        )
    )
    game.tick()

    # NPC was hit, but viewing player was not
    assert game.get_hit_seq(player.entity.entity_id) == 0
    ui._render_frame(console)  # noqa: SLF001
    assert not ui._damage_flash.active  # noqa: SLF001


def test_crit_flash_triggers_on_player_crit(
    ui: GameUI, game: Game, console: tcod.console.Console
) -> None:
    from unittest.mock import patch

    from faraway_realms.commands import Command, CommandType
    from faraway_realms.entity import NonPlayerEntity
    from faraway_realms.stats import Pool, Stat

    player = next(iter(game._players.values()))  # noqa: SLF001
    player.entity.stats["strength"] = Stat(base=5)
    player.entity.stats["crit_chance"] = Stat(base=100)

    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=200)},
    )
    game.add_npc(npc)
    game.game_map.place_entity(npc.entity_id, 11, 7)

    game.enqueue_command(
        Command(
            command_type=CommandType.ATTACK,
            actor=str(player.entity.entity_id),
            args=(str(npc.entity_id),),
            raw="/attack 1 2",
        )
    )
    with patch("faraway_realms.systems.combat.random.randint", return_value=1):
        game.tick()

    assert game.get_crit_dealt_seq(player.entity.entity_id) > 0
    ui._render_frame(console)  # noqa: SLF001
    assert ui._crit_flash.active  # noqa: SLF001
