"""Tests for the static object type YAML parser."""

from pathlib import Path

import pytest

from faraway_realms.components import LightEmitter
from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.static_objects import parse_static_objects
from faraway_realms.static_object import STATIC_OBJECT_REGISTRY, StaticObjectType

_STATIC_OBJECTS_DIR = (
    Path(__file__).parent.parent / "faraway_realms" / "data" / "static_objects"
)


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(STATIC_OBJECT_REGISTRY)
    STATIC_OBJECT_REGISTRY.clear()
    yield
    STATIC_OBJECT_REGISTRY.clear()
    STATIC_OBJECT_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    """Load the shipped YAML data files into the registry."""
    loader = ContentLoader(dirs=[_STATIC_OBJECTS_DIR])
    loader.register_parser("static_objects", parse_static_objects)
    loader.load()


# ------------------------------------------------------------------
# Light emitter component parsing
# ------------------------------------------------------------------


def test_with_light_emitter_component_creates_light_emitter():
    parse_static_objects(
        {
            "torch": {
                "char": "!",
                "fg_color": [240, 160, 30],
                "components": {
                    "light_emitter": {
                        "radius": 7,
                        "intensity": 0.95,
                        "color": [255, 150, 60],
                    }
                },
            }
        }
    )
    sot = STATIC_OBJECT_REGISTRY["torch"]
    assert isinstance(sot, StaticObjectType)
    emitter = sot.components.get("light_emitter")
    assert isinstance(emitter, LightEmitter)
    assert emitter.radius == 7
    assert emitter.intensity == pytest.approx(0.95)
    assert emitter.color == (255, 150, 60)


def test_without_light_source_has_no_emitter():
    parse_static_objects({"marker": {"char": "x", "fg_color": [100, 100, 100]}})
    assert STATIC_OBJECT_REGISTRY["marker"].components.get("light_emitter") is None


def test_light_emitter_is_also_light_source():
    from faraway_realms.light import LightSource

    parse_static_objects(
        {
            "torch": {
                "char": "!",
                "fg_color": [240, 160, 30],
                "components": {
                    "light_emitter": {
                        "radius": 5,
                        "intensity": 0.8,
                        "color": [255, 200, 0],
                    }
                },
            }
        }
    )
    emitter = STATIC_OBJECT_REGISTRY["torch"].components.get("light_emitter")
    assert isinstance(emitter, LightSource)


# ------------------------------------------------------------------
# labels
# ------------------------------------------------------------------


def test_labels_become_frozenset():
    parse_static_objects(
        {
            "torch": {
                "char": "!",
                "fg_color": [240, 160, 30],
                "labels": ["torch", "cave"],
            }
        }
    )
    assert STATIC_OBJECT_REGISTRY["torch"].labels == frozenset({"torch", "cave"})


# ------------------------------------------------------------------
# Shipped YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_loads_torch_and_mushroom(load_shipped):
    assert "torch" in STATIC_OBJECT_REGISTRY, "Missing: torch"
    assert "glowing_mushroom" in STATIC_OBJECT_REGISTRY, "Missing: glowing_mushroom"
