# Faraway Realms

A real-time tick-based roguelike RPG built with [tcod](https://python-tcod.readthedocs.io/).

## Install & run

### Windows (no Python required)

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Restart your terminal, then:

```powershell
uv tool install faraway-realms
faraway-realms
```

### macOS / Linux

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install faraway-realms
faraway-realms
```

## Multiplayer

```bash
# Server (headless)
faraway-realms --serve 0.0.0.0:9999 --headless

# Client on another machine
faraway-realms --connect HOST:9999
```
