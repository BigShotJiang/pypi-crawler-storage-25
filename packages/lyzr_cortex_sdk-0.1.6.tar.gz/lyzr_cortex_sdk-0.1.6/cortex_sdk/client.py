"""
Cortex Client - Main interface for Cortex Platform APIs.

Auto-configures from environment variables and provides
graceful degradation when Cortex is not available.
"""

import os
import logging
from typing import Optional, List, Dict, Any

import httpx

from .models import CortexDocument, CortexQueryResult, CortexUser, CortexSource, DocumentPushResponse
from .exceptions import (
    CortexError,
    CortexConnectionError,
    CortexAuthError,
    CortexValidationError,
    CortexRateLimitError,
)

logger = logging.getLogger(__name__)


class CortexClient:
    """
    Client for interacting with Cortex Platform APIs.

    Auto-configures from environment variables:
    - CORTEX_API_URL: Cortex gateway URL
    - CORTEX_API_KEY: Tool's API key
    - CORTEX_TOOL_ID: Tool identifier
    - CORTEX_ENABLED: Enable/disable (default: true if vars are set)

    If CORTEX_ENABLED=false or required env vars are missing,
    operates in no-op mode where all methods return safe defaults.

    Example:
        client = CortexClient()

        # Push a document
        result = await client.push(
            type="meeting_transcript",
            id="transcript_123",
            content="Full transcript...",
            scope="team",
            teams=["team_product"]
        )

        # Query
        result = await client.query("What did we discuss?")
        print(result.answer)
    """

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
        tool_id: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize Cortex client.

        Args:
            api_url: Cortex gateway URL (or CORTEX_API_URL env var)
            api_key: Tool's API key (or CORTEX_API_KEY env var)
            tool_id: Tool identifier (or CORTEX_TOOL_ID env var)
            timeout: Request timeout in seconds
        """
        self.api_url = api_url or os.environ.get("CORTEX_API_URL", "")
        self.api_key = api_key or os.environ.get("CORTEX_API_KEY", "")
        self.tool_id = tool_id or os.environ.get("CORTEX_TOOL_ID", "")
        self.timeout = timeout

        # Check if Cortex is enabled
        enabled_env = os.environ.get("CORTEX_ENABLED", "true").lower()
        self._enabled = (
            enabled_env == "true"
            and bool(self.api_url)
            and bool(self.api_key)
        )

        self._client: Optional[httpx.AsyncClient] = None

        if self._enabled:
            logger.info(f"Cortex SDK enabled: {self.api_url} (tool: {self.tool_id})")
        else:
            logger.info("Cortex SDK disabled - operating in no-op mode")

    @property
    def enabled(self) -> bool:
        """Check if Cortex integration is enabled."""
        return self._enabled

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.api_url.rstrip("/"),
                headers={
                    "X-Cortex-Tool-ID": self.tool_id or "unknown",
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
            )
        return self._client

    def _handle_response_error(self, response: httpx.Response) -> None:
        """Handle HTTP error responses."""
        status = response.status_code

        try:
            error_data = response.json()
            message = error_data.get("detail", error_data.get("message", response.text))
        except Exception:
            message = response.text

        if status == 401:
            raise CortexAuthError(f"Authentication failed: {message}")
        elif status == 403:
            raise CortexAuthError(f"Permission denied: {message}")
        elif status == 422:
            raise CortexValidationError(f"Validation error: {message}")
        elif status == 429:
            retry_after = response.headers.get("Retry-After")
            raise CortexRateLimitError(
                f"Rate limit exceeded: {message}",
                retry_after=int(retry_after) if retry_after else None
            )
        elif status >= 500:
            raise CortexConnectionError(f"Server error ({status}): {message}")
        else:
            raise CortexError(f"Request failed ({status}): {message}")

    async def push(
        self,
        type: str,
        id: str,
        content: str,
        name: Optional[str] = None,
        url: Optional[str] = None,
        scope: str = "global",
        teams: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Optional[DocumentPushResponse]:
        """
        Push a document to Cortex Knowledge Graph.

        Args:
            type: Document type (e.g., "meeting_transcript", "deal", "candidate")
            id: Unique identifier (external_id in Cortex)
            content: Text content for RAG indexing
            name: Display name for the document
            url: URL to view document in source tool
            scope: Access scope - "global", "team", or "personal"
            teams: Team IDs if scope is "team"
            metadata: Additional metadata dict
            **kwargs: Additional fields to include in payload

        Returns:
            DocumentPushResponse with Cortex document ID, or None if disabled

        Raises:
            CortexValidationError: If content is empty or invalid scope
            CortexAuthError: If authentication fails
            CortexConnectionError: If server is unreachable
        """
        if not self._enabled:
            logger.debug(f"Cortex disabled - skipping push for {type}:{id}")
            return None

        if not content or not content.strip():
            raise CortexValidationError("Document content cannot be empty")

        if scope not in ("global", "team", "personal"):
            raise CortexValidationError(f"Invalid scope: {scope}. Must be global, team, or personal")

        payload = {
            "external_id": id,
            "document_type": type,
            "content": content,
            "access_scope": scope,
            "metadata": metadata or {},
            **kwargs,
        }

        if name:
            payload["name"] = name
        if url:
            payload["external_url"] = url
        if teams:
            payload["scope_team_ids"] = teams

        try:
            client = self._get_client()
            response = await client.post("/api/tools/documents", json=payload)

            if response.status_code in (200, 201):
                data = response.json()
                logger.info(f"Pushed document {type}:{id} to Cortex (id: {data.get('id')})")
                return DocumentPushResponse(**data)

            self._handle_response_error(response)

        except httpx.RequestError as e:
            logger.error(f"Connection error pushing to Cortex: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

    async def query(
        self,
        question: str,
        filters: Optional[Dict[str, Any]] = None,
        time_range_days: Optional[int] = None,
        max_results: int = 10,
        user_email: Optional[str] = None,
        attendees: Optional[List[str]] = None,
    ) -> CortexQueryResult:
        """
        Query Cortex Knowledge Graph.

        Args:
            question: Natural language query
            filters: Optional filters (e.g., {"type": ["meeting_transcript"]})
            time_range_days: Limit to recent documents (e.g., 30 for last 30 days)
            max_results: Maximum results to return (default: 10)
            user_email: User email for access control (uses context if not provided)
            attendees: Email list to filter meeting sources by participant overlap

        Returns:
            CortexQueryResult with answer and sources

        Raises:
            CortexAuthError: If authentication fails
            CortexConnectionError: If server is unreachable
        """
        if not self._enabled:
            logger.debug("Cortex disabled - returning empty query result")
            return CortexQueryResult(
                answer="",
                sources=[],
                query=question,
            )

        payload = {
            "query": question,
            "max_results": max_results,
        }

        if filters:
            payload["filters"] = filters
        if time_range_days:
            payload["time_range_days"] = time_range_days
        if user_email:
            payload["user_email"] = user_email
        if attendees:
            payload["attendees"] = attendees

        try:
            client = self._get_client()
            response = await client.post("/api/tools/query", json=payload)

            if response.status_code == 200:
                data = response.json()
                sources = [
                    CortexSource(
                        id=s.get("id", ""),
                        type=s.get("type", ""),
                        name=s.get("name", ""),
                        excerpt=s.get("excerpt", ""),
                        score=s.get("score"),
                        url=s.get("url"),
                        metadata=s.get("metadata", {}),
                    )
                    for s in data.get("sources", [])
                ]
                return CortexQueryResult(
                    answer=data.get("answer", ""),
                    sources=sources,
                    query=question,
                    raw_response=data,
                )

            self._handle_response_error(response)

        except httpx.RequestError as e:
            logger.error(f"Connection error querying Cortex: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        # Fallback (shouldn't reach here)
        return CortexQueryResult(answer="", sources=[], query=question)

    async def fast_search(
        self,
        question: str,
        user_email: str,
        top_k: int = 8,
        attendees: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Parallel RAG search across all of the user's accessible KBs + tool
        docs, returned as pre-formatted markdown. No LLM synthesis — trades a
        polished answer for ~4x speed (≤10s vs ~35s for orchestrated_query).

        Use when you need real retrieved content fast (pre-reads, quick
        lookups, autocomplete).

        Returns dict with keys: answer (markdown), sources (list),
        kbs_searched (int), latency_ms (int). Raises CortexConnectionError
        on network failure.
        """
        if not self._enabled:
            return {"answer": "", "sources": [], "kbs_searched": 0, "latency_ms": 0}

        payload: Dict[str, Any] = {
            "query": question,
            "user_email": user_email,
            "top_k": top_k,
        }
        if attendees:
            payload["attendees"] = attendees

        try:
            client = self._get_client()
            response = await client.post("/api/tools/fast-search", json=payload)
            if response.status_code == 200:
                return response.json()
            self._handle_response_error(response)
        except httpx.RequestError as e:
            logger.error(f"Connection error on fast search: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        return {"answer": "", "sources": [], "kbs_searched": 0, "latency_ms": 0}

    async def orchestrated_query_stream(
        self,
        question: str,
        user_email: str,
        scope: str = "both",
        top_k: int = 10,
        source_tool_id: Optional[str] = None,
    ):
        """
        Streaming version of orchestrated_query. Async generator that yields
        real orchestrator events as they happen: log messages during KB
        search + synthesis, then the final result (or an error).

        Yields dicts of the form:
            {"type": "log", "message": "Searching My Slack, My Emails..."}
            {"type": "result", "data": {answer, sources, contributing_kbs, ...}}
            {"type": "error", "message": "..."}

        Lets callers render live progress to a UI (elapsed timer + log
        stream) instead of a blind 30-second spinner.
        """
        if not self._enabled:
            yield {"type": "error", "message": "Cortex disabled"}
            return

        payload: Dict[str, Any] = {
            "query": question,
            "user_email": user_email,
            "scope": scope,
            "top_k": top_k,
        }
        if source_tool_id:
            payload["source_tool_id"] = source_tool_id

        import json as _json
        try:
            client = self._get_client()
            async with client.stream(
                "POST", "/api/tools/orchestrated-query-stream", json=payload
            ) as response:
                if response.status_code != 200:
                    text = (await response.aread()).decode("utf-8", errors="replace")
                    yield {"type": "error", "message": f"HTTP {response.status_code}: {text[:300]}"}
                    return
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_block, buffer = buffer.split("\n\n", 1)
                        for line in event_block.splitlines():
                            if not line.startswith("data: "):
                                continue
                            try:
                                evt = _json.loads(line[6:])
                            except _json.JSONDecodeError:
                                continue
                            yield evt
        except httpx.RequestError as e:
            yield {"type": "error", "message": f"Connection error: {e}"}

    async def orchestrated_query(
        self,
        question: str,
        user_email: str,
        scope: str = "both",
        top_k: int = 10,
        source_tool_id: Optional[str] = None,
    ) -> CortexQueryResult:
        """
        Run a query through Cortex's full multi-agent orchestrator on behalf
        of a specific user. Uses the same pipeline as the Cortex chat UI —
        cross-KB search (personal + team + global + tool docs), multi-agent
        synthesis, the works. Returns the exact same answer quality the user
        would get if they typed the question into Cortex chat themselves.

        Authenticates via the tool's API key; the target user is identified
        by email and must belong to the tool's organisation.

        Args:
            question: Natural language query
            user_email: Email of the user the query runs for
            scope: "organization" | "personal" | "both"
            top_k: Results per KB to retrieve
            source_tool_id: Optional tool ID to prioritise in results

        Returns:
            CortexQueryResult with answer and sources
        """
        if not self._enabled:
            logger.debug("Cortex disabled - returning empty orchestrated result")
            return CortexQueryResult(answer="", sources=[], query=question)

        payload: Dict[str, Any] = {
            "query": question,
            "user_email": user_email,
            "scope": scope,
            "top_k": top_k,
        }
        if source_tool_id:
            payload["source_tool_id"] = source_tool_id

        try:
            client = self._get_client()
            response = await client.post("/api/tools/orchestrated-query", json=payload)

            if response.status_code == 200:
                data = response.json()
                raw_sources = data.get("sources") or []
                sources = [
                    CortexSource(
                        id=str(s.get("document_id") or s.get("id") or ""),
                        type=str(s.get("type", "")),
                        name=str(s.get("document_name") or s.get("name") or ""),
                        excerpt=str(s.get("snippet") or s.get("excerpt") or ""),
                        score=s.get("relevance_score") or s.get("score"),
                        url=s.get("url"),
                        metadata=s.get("metadata", {}),
                    )
                    for s in raw_sources
                ]
                return CortexQueryResult(
                    answer=data.get("answer", ""),
                    sources=sources,
                    query=question,
                    raw_response=data,
                )

            self._handle_response_error(response)
        except httpx.RequestError as e:
            logger.error(f"Connection error on orchestrated query: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        return CortexQueryResult(answer="", sources=[], query=question)

    async def get_user_context(self, user_email: str) -> Optional[CortexUser]:
        """
        Get user context from Cortex (teams, permissions, etc.)

        Args:
            user_email: User's email address

        Returns:
            CortexUser with full context, or None if not found/disabled

        Raises:
            CortexConnectionError: If server is unreachable
        """
        if not self._enabled:
            logger.debug("Cortex disabled - returning None for user context")
            return None

        try:
            client = self._get_client()
            response = await client.get(f"/api/tools/context/{user_email}")

            if response.status_code == 200:
                data = response.json()
                return CortexUser(**data)
            elif response.status_code == 404:
                logger.warning(f"User not found in Cortex: {user_email}")
                return None

            self._handle_response_error(response)

        except httpx.RequestError as e:
            logger.error(f"Connection error getting user context: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        return None

    async def share_document(
        self,
        document_external_id: str,
        shared_by_email: str,
        shared_with_email: str,
        document_name: Optional[str] = None,
        content: Optional[str] = None,
        external_url: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Share a document with another user in the organization.

        Creates a record in the recipient's "Shared With Me" collection.

        Args:
            document_external_id: External ID of the document to share
            shared_by_email: Email of the user sharing the document
            shared_with_email: Email of the recipient
            document_name: Display name for the shared document
            content: Document content
            external_url: URL to view the document
            metadata: Additional metadata dict

        Returns:
            Dict with share id, shared_with_email, created_at, or None if disabled

        Raises:
            CortexAuthError: If authentication fails
            CortexConnectionError: If server is unreachable
        """
        if not self._enabled:
            logger.debug("Cortex disabled - skipping share_document")
            return None

        payload: Dict[str, Any] = {
            "document_external_id": document_external_id,
            "shared_by_email": shared_by_email,
            "shared_with_email": shared_with_email,
            "metadata": metadata or {},
        }
        if document_name:
            payload["document_name"] = document_name
        if content:
            payload["content"] = content
        if external_url:
            payload["external_url"] = external_url

        try:
            client = self._get_client()
            response = await client.post("/api/tools/share-document-for-user", json=payload)

            if response.status_code in (200, 201):
                data = response.json()
                logger.info(
                    f"Shared document {document_external_id} "
                    f"from {shared_by_email} to {shared_with_email}"
                )
                return data

            self._handle_response_error(response)

        except httpx.RequestError as e:
            logger.error(f"Connection error sharing document: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        return None

    async def get_org_users(
        self,
        exclude_email: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get list of users in the tool's organization.

        Args:
            exclude_email: Email to exclude from results (typically the current user)

        Returns:
            List of user dicts with id, email, full_name, avatar_url

        Raises:
            CortexConnectionError: If server is unreachable
        """
        if not self._enabled:
            logger.debug("Cortex disabled - returning empty org users list")
            return []

        params = {}
        if exclude_email:
            params["exclude_email"] = exclude_email

        try:
            client = self._get_client()
            response = await client.get("/api/tools/org-users-for-tool", params=params)

            if response.status_code == 200:
                return response.json()

            self._handle_response_error(response)

        except httpx.RequestError as e:
            logger.error(f"Connection error getting org users: {e}")
            raise CortexConnectionError(f"Connection error: {str(e)}")

        return []

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "CortexClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
