"""
Cortex SDK Data Models

Pydantic models for type-safe data handling.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class CortexUser(BaseModel):
    """
    User context from Cortex.

    Contains user identity, organization, team memberships, and permissions.
    Used for access control when pushing documents or querying.
    """

    id: str = Field(..., description="User's unique identifier")
    email: str = Field(..., description="User's email address")
    name: Optional[str] = Field(None, description="User's display name")
    org_id: str = Field(..., description="Organization ID")
    org_name: Optional[str] = Field(None, description="Organization name")
    teams: List[Dict[str, str]] = Field(
        default_factory=list,
        description="List of teams: [{'id': '...', 'name': '...'}]"
    )
    role: str = Field("member", description="Organization role: admin, member")
    permissions: List[str] = Field(
        default_factory=list,
        description="Permission list: ['read', 'write', 'admin']"
    )

    @property
    def team_ids(self) -> List[str]:
        """Get list of team IDs."""
        return [t.get("id") for t in self.teams if t.get("id")]

    @property
    def team_names(self) -> List[str]:
        """Get list of team names."""
        return [t.get("name") for t in self.teams if t.get("name")]

    def is_member_of(self, team_id: str) -> bool:
        """Check if user is member of a specific team."""
        return team_id in self.team_ids

    def has_permission(self, permission: str) -> bool:
        """Check if user has a specific permission."""
        return permission in self.permissions


class CortexDocument(BaseModel):
    """
    Document to push to Cortex Knowledge Graph.

    Documents are indexed for RAG retrieval and can be scoped
    to global (org-wide), team, or personal access.
    """

    external_id: str = Field(..., description="Unique ID from the source tool")
    document_type: str = Field(..., description="Document type: meeting_transcript, deal, etc.")
    content: str = Field(..., description="Text content for RAG indexing")
    name: Optional[str] = Field(None, description="Display name for the document")
    external_url: Optional[str] = Field(None, description="URL to view in source tool")
    access_scope: str = Field(
        "global",
        description="Access scope: global, team, personal"
    )
    scope_team_ids: Optional[List[str]] = Field(
        None,
        description="Team IDs if scope is 'team'"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata for filtering"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "external_id": "transcript_123",
                "document_type": "meeting_transcript",
                "content": "Alice: Let's discuss the roadmap...",
                "name": "Product Sync - Jan 15",
                "external_url": "https://tool.example.com/transcript/123",
                "access_scope": "team",
                "scope_team_ids": ["team_product"],
                "metadata": {
                    "participants": ["alice@example.com", "bob@example.com"],
                    "duration_minutes": 45
                }
            }
        }


class CortexSource(BaseModel):
    """A source document returned from a query."""

    id: str = Field(..., description="Document ID in Cortex")
    type: str = Field(..., description="Document type")
    name: str = Field(..., description="Document name")
    excerpt: str = Field(..., description="Relevant excerpt from the document")
    score: Optional[float] = Field(None, description="Relevance score")
    url: Optional[str] = Field(None, description="URL to source")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CortexQueryResult(BaseModel):
    """
    Result from Cortex knowledge query.

    Contains the AI-generated answer and the source documents
    that were used to generate it.
    """

    answer: str = Field(..., description="AI-generated answer")
    sources: List[CortexSource] = Field(
        default_factory=list,
        description="Source documents used for the answer"
    )
    query: str = Field(..., description="Original query")
    raw_response: Optional[Dict[str, Any]] = Field(
        None,
        description="Raw API response for debugging"
    )

    @property
    def has_sources(self) -> bool:
        """Check if any sources were found."""
        return len(self.sources) > 0

    def get_source_ids(self) -> List[str]:
        """Get list of source document IDs."""
        return [s.id for s in self.sources]

    def get_top_sources(self, n: int = 3) -> List[CortexSource]:
        """Get top N sources by relevance."""
        return self.sources[:n]


class DocumentPushResponse(BaseModel):
    """Response from pushing a document."""

    id: str = Field(..., description="Document ID in Cortex")
    status: str = Field(..., description="Status: indexed, pending, failed")
    external_id: str = Field(..., description="Original external ID")
    message: Optional[str] = Field(None, description="Additional info or error message")
