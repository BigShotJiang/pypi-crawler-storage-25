"""
Cortex SDK Authentication Middleware for FastAPI.

Provides dependency injection helpers for extracting and validating
Cortex user context from JWT tokens in embedded mode.

Usage:
    from cortex_sdk.auth import get_current_cortex_user, require_cortex_user

    @router.get("/data")
    async def get_data(user: CortexUser = Depends(require_cortex_user)):
        # user is guaranteed to be authenticated via Cortex
        return {"user": user.email}

    @router.get("/data-optional")
    async def get_data_optional(user: CortexUser | None = Depends(get_current_cortex_user)):
        # user may be None if not in embedded mode
        if user:
            return {"user": user.email}
        return {"user": "anonymous"}
"""

import os
import logging
from typing import Optional

try:
    import jwt
    from fastapi import Depends, HTTPException, Request
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
except ImportError as e:
    raise ImportError(
        "FastAPI dependencies not installed. Install with: pip install lyzr-cortex-sdk[fastapi]"
    ) from e

from .models import CortexUser

logger = logging.getLogger(__name__)

# JWT configuration from environment
_jwt_public_key: Optional[str] = os.environ.get("CORTEX_JWT_PUBLIC_KEY")
_jwt_algorithms: list = ["RS256"]

# HTTP Bearer security scheme (auto_error=False allows optional auth)
_security = HTTPBearer(auto_error=False)


def _decode_jwt(token: str) -> Optional[dict]:
    """
    Decode and validate a Cortex JWT token.

    Args:
        token: JWT token string

    Returns:
        Decoded payload dict, or None if invalid
    """
    if not _jwt_public_key:
        logger.warning("CORTEX_JWT_PUBLIC_KEY not configured - cannot validate JWT")
        return None

    try:
        payload = jwt.decode(
            token,
            _jwt_public_key,
            algorithms=_jwt_algorithms,
            options={"verify_aud": False},  # We don't enforce audience
        )
        return payload
    except jwt.ExpiredSignatureError:
        logger.warning("Cortex JWT token expired")
        return None
    except jwt.InvalidTokenError as e:
        logger.warning(f"Invalid Cortex JWT token: {e}")
        return None


def _payload_to_user(payload: dict) -> CortexUser:
    """Convert JWT payload to CortexUser model."""
    return CortexUser(
        id=payload.get("sub", ""),
        email=payload.get("email", ""),
        name=payload.get("name"),
        org_id=payload.get("org_id", ""),
        org_name=payload.get("org_name"),
        teams=payload.get("teams", []),
        role=payload.get("role", "member"),
        permissions=payload.get("permissions", []),
    )


async def get_current_cortex_user(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_security),
) -> Optional[CortexUser]:
    """
    Extract Cortex user from JWT token if present.

    Works in two modes:
    1. **Embedded mode**: JWT passed in Authorization header (Bearer token)
    2. **Standalone mode**: No token present, returns None

    The token can also be passed as a query parameter `cortex_token`
    for initial iframe load scenarios.

    Args:
        request: FastAPI request object
        credentials: HTTP Bearer credentials (injected)

    Returns:
        CortexUser if valid token present, None otherwise

    Example:
        @router.get("/data")
        async def get_data(
            user: CortexUser | None = Depends(get_current_cortex_user)
        ):
            if user:
                return {"message": f"Hello {user.name}"}
            return {"message": "Hello anonymous"}
    """
    token: Optional[str] = None

    # Try Authorization header first
    if credentials:
        token = credentials.credentials

    # Fall back to query parameter (for iframe initial load)
    if not token:
        token = request.query_params.get("cortex_token")

    if not token:
        # No token provided - standalone mode
        return None

    if not _jwt_public_key:
        # JWT validation not configured - standalone mode
        logger.debug("JWT public key not configured, skipping token validation")
        return None

    payload = _decode_jwt(token)
    if not payload:
        return None

    return _payload_to_user(payload)


async def require_cortex_user(
    cortex_user: Optional[CortexUser] = Depends(get_current_cortex_user),
) -> CortexUser:
    """
    Require a valid Cortex user. Raises 401 if not authenticated.

    Use this dependency when the endpoint MUST have Cortex context
    (e.g., endpoints that only work in embedded mode).

    For endpoints that should work in both standalone and embedded modes,
    use `get_current_cortex_user` instead.

    Args:
        cortex_user: User from get_current_cortex_user (injected)

    Returns:
        CortexUser (guaranteed non-None)

    Raises:
        HTTPException: 401 if user is not authenticated

    Example:
        @router.get("/protected")
        async def protected_endpoint(
            user: CortexUser = Depends(require_cortex_user)
        ):
            # user is guaranteed to be authenticated
            return {"email": user.email, "teams": user.team_names}
    """
    if not cortex_user:
        raise HTTPException(
            status_code=401,
            detail="Cortex authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return cortex_user


def require_permission(permission: str):
    """
    Factory for creating a dependency that requires a specific permission.

    Args:
        permission: Required permission (e.g., "admin", "write")

    Returns:
        FastAPI dependency function

    Example:
        @router.delete("/item/{id}")
        async def delete_item(
            id: str,
            user: CortexUser = Depends(require_permission("admin"))
        ):
            # user is guaranteed to have "admin" permission
            ...
    """

    async def _require_permission(
        cortex_user: CortexUser = Depends(require_cortex_user),
    ) -> CortexUser:
        if not cortex_user.has_permission(permission):
            raise HTTPException(
                status_code=403,
                detail=f"Permission '{permission}' required",
            )
        return cortex_user

    return _require_permission


def require_team(team_id: str):
    """
    Factory for creating a dependency that requires team membership.

    Args:
        team_id: Required team ID

    Returns:
        FastAPI dependency function

    Example:
        @router.get("/team-data")
        async def get_team_data(
            user: CortexUser = Depends(require_team("team_engineering"))
        ):
            # user is guaranteed to be a member of team_engineering
            ...
    """

    async def _require_team(
        cortex_user: CortexUser = Depends(require_cortex_user),
    ) -> CortexUser:
        if not cortex_user.is_member_of(team_id):
            raise HTTPException(
                status_code=403,
                detail=f"Team membership required: {team_id}",
            )
        return cortex_user

    return _require_team
