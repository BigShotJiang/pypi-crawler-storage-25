"""
Cortex SDK Exceptions

All exceptions inherit from CortexError for easy catching.
"""


class CortexError(Exception):
    """Base exception for all Cortex SDK errors."""

    def __init__(self, message: str, details: dict = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class CortexAuthError(CortexError):
    """
    Authentication or authorization error.

    Raised when:
    - API key is invalid
    - JWT token is invalid or expired
    - User lacks permission for the operation
    """
    pass


class CortexConnectionError(CortexError):
    """
    Connection error to Cortex API.

    Raised when:
    - Network is unreachable
    - Request times out
    - Server returns 5xx error
    """
    pass


class CortexNotEnabledError(CortexError):
    """
    Raised when Cortex features are used but not enabled.

    This is typically raised when:
    - CORTEX_ENABLED=false
    - Required environment variables are missing
    """

    def __init__(self, message: str = "Cortex integration is not enabled"):
        super().__init__(message)


class CortexValidationError(CortexError):
    """
    Validation error for request data.

    Raised when:
    - Document content is empty
    - Required fields are missing
    - Invalid scope or filter values
    """
    pass


class CortexRateLimitError(CortexError):
    """
    Rate limit exceeded.

    Contains retry_after in details if available.
    """

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        details = {"retry_after": retry_after} if retry_after else {}
        super().__init__(message, details)
        self.retry_after = retry_after
