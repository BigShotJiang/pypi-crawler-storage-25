"""
Cortex SDK - Build tools that integrate with Cortex Platform.

Usage:
    from cortex_sdk import CortexClient

    # Auto-configured from environment variables
    client = CortexClient()

    # Push a document
    await client.push(
        type="meeting_transcript",
        id="transcript_123",
        content="Full transcript text...",
        scope="team",
        teams=["team_product"]
    )

    # Query knowledge graph
    result = await client.query(
        question="What decisions were made about Q1?",
        filters={"type": ["meeting_transcript"]},
        time_range_days=30
    )

Environment Variables:
    CORTEX_ENABLED: Enable/disable integration (default: true)
    CORTEX_API_URL: Cortex gateway URL
    CORTEX_API_KEY: Tool's API key
    CORTEX_TOOL_ID: Tool identifier
    CORTEX_JWT_PUBLIC_KEY: Public key for embedded mode JWT validation
"""

from .client import CortexClient
from .models import CortexUser, CortexDocument, CortexQueryResult
from .exceptions import (
    CortexError,
    CortexAuthError,
    CortexConnectionError,
    CortexNotEnabledError,
)

# Convenience instance (auto-configured from env vars)
client = CortexClient()

# Re-export common functions at package level
push = client.push
query = client.query
get_user_context = client.get_user_context
share_document = client.share_document
get_org_users = client.get_org_users

__version__ = "0.1.2"
__all__ = [
    # Core client
    "CortexClient",
    "client",
    # Models
    "CortexUser",
    "CortexDocument",
    "CortexQueryResult",
    # Exceptions
    "CortexError",
    "CortexAuthError",
    "CortexConnectionError",
    "CortexNotEnabledError",
    # Convenience functions
    "push",
    "query",
    "get_user_context",
    "share_document",
    "get_org_users",
]

# Auth exports (requires fastapi extra)
try:
    from .auth import require_cortex_user, get_current_cortex_user
    __all__.extend(["require_cortex_user", "get_current_cortex_user"])
except ImportError:
    # FastAPI not installed
    pass
