"""Tests for CortexClient."""

import pytest
from unittest.mock import patch, AsyncMock
import os

from cortex_sdk import CortexClient
from cortex_sdk.models import CortexQueryResult, DocumentPushResponse
from cortex_sdk.exceptions import CortexConnectionError, CortexValidationError


class TestCortexClientInit:
    """Test CortexClient initialization."""

    def test_enabled_with_all_vars(self):
        """Client is enabled when all required vars are set."""
        with patch.dict(os.environ, {
            "CORTEX_ENABLED": "true",
            "CORTEX_API_URL": "http://localhost:8000",
            "CORTEX_API_KEY": "test-key",
            "CORTEX_TOOL_ID": "test-tool",
        }):
            client = CortexClient()
            assert client.enabled is True

    def test_disabled_when_env_false(self):
        """Client is disabled when CORTEX_ENABLED=false."""
        with patch.dict(os.environ, {
            "CORTEX_ENABLED": "false",
            "CORTEX_API_URL": "http://localhost:8000",
            "CORTEX_API_KEY": "test-key",
        }):
            client = CortexClient()
            assert client.enabled is False

    def test_disabled_when_missing_url(self):
        """Client is disabled when API URL is missing."""
        with patch.dict(os.environ, {
            "CORTEX_ENABLED": "true",
            "CORTEX_API_URL": "",
            "CORTEX_API_KEY": "test-key",
        }, clear=True):
            client = CortexClient()
            assert client.enabled is False

    def test_disabled_when_missing_key(self):
        """Client is disabled when API key is missing."""
        with patch.dict(os.environ, {
            "CORTEX_ENABLED": "true",
            "CORTEX_API_URL": "http://localhost:8000",
            "CORTEX_API_KEY": "",
        }, clear=True):
            client = CortexClient()
            assert client.enabled is False

    def test_explicit_config_overrides_env(self):
        """Explicit config overrides environment variables."""
        with patch.dict(os.environ, {
            "CORTEX_API_URL": "http://env-url",
            "CORTEX_API_KEY": "env-key",
        }):
            client = CortexClient(
                api_url="http://explicit-url",
                api_key="explicit-key"
            )
            assert client.api_url == "http://explicit-url"
            assert client.api_key == "explicit-key"


class TestCortexClientPush:
    """Test CortexClient.push() method."""

    @pytest.fixture
    def enabled_client(self):
        """Create an enabled client for testing."""
        with patch.dict(os.environ, {
            "CORTEX_ENABLED": "true",
            "CORTEX_API_URL": "http://localhost:8000",
            "CORTEX_API_KEY": "test-key",
            "CORTEX_TOOL_ID": "test-tool",
        }):
            yield CortexClient()

    @pytest.fixture
    def disabled_client(self):
        """Create a disabled client for testing."""
        with patch.dict(os.environ, {"CORTEX_ENABLED": "false"}):
            yield CortexClient()

    async def test_push_returns_none_when_disabled(self, disabled_client):
        """Push returns None when client is disabled."""
        result = await disabled_client.push(
            type="test",
            id="123",
            content="test content"
        )
        assert result is None

    async def test_push_validates_empty_content(self, enabled_client):
        """Push raises error for empty content."""
        with pytest.raises(CortexValidationError):
            await enabled_client.push(
                type="test",
                id="123",
                content=""
            )

    async def test_push_validates_invalid_scope(self, enabled_client):
        """Push raises error for invalid scope."""
        with pytest.raises(CortexValidationError):
            await enabled_client.push(
                type="test",
                id="123",
                content="test content",
                scope="invalid"
            )


class TestCortexClientQuery:
    """Test CortexClient.query() method."""

    @pytest.fixture
    def disabled_client(self):
        """Create a disabled client for testing."""
        with patch.dict(os.environ, {"CORTEX_ENABLED": "false"}):
            yield CortexClient()

    async def test_query_returns_empty_when_disabled(self, disabled_client):
        """Query returns empty result when client is disabled."""
        result = await disabled_client.query("test question")
        assert isinstance(result, CortexQueryResult)
        assert result.answer == ""
        assert result.sources == []
        assert result.query == "test question"
