"""Pytest-cov coverage testing wrapper.

Provides type-safe wrapper for pytest-cov commands for code coverage analysis.
Shows coverage badge from Codecov.io.

Example:
    >>> from pyrig.rig.tools.project_coverage_tester import (
    ...     ProjectCoverageTester,
    ... )
    >>> ProjectCoverageTester.I.remote_coverage_url()
"""

from pyrig.rig.tools.base.tool import Tool, ToolGroup
from pyrig.rig.tools.package_manager import PackageManager
from pyrig.rig.tools.version_controller import VersionController


class ProjectCoverageTester(Tool):
    """Pytest-cov coverage testing wrapper.

    Constructs pytest-cov command arguments for code coverage analysis.
    Integrates with Codecov.io for badge and coverage tracking.

    Operations:
        - Code coverage analysis
        - Coverage badge generation
        - Coverage integration with remote services

    Example:
        >>> ProjectCoverageTester.I.remote_coverage_url()
    """

    def name(self) -> str:
        """Get tool name.

        Returns:
            'pytest-cov'
        """
        return "pytest-cov"

    def group(self) -> str:
        """Returns the group the tool belongs to.

        Returns:
            'testing'
        """
        return ToolGroup.TESTING

    def badge_urls(self) -> tuple[str, str]:
        """Get Codecov coverage badge image URL and dashboard URL."""
        return (
            f"{self.remote_coverage_url()}/branch/{VersionController.I.default_branch()}/graph/badge.svg",
            self.remote_coverage_url(),
        )

    def coverage_threshold(self) -> int:
        """Get minimum test coverage percentage threshold.

        Returns:
            Coverage percentage (90).
        """
        return 90

    def additional_args(self) -> tuple[str, ...]:
        """Get additional pytest-cov arguments for coverage analysis.

        Returns:
            Tuple of additional pytest-cov arguments.
        """
        return (
            f"--cov={PackageManager.I.package_name()}",
            "--cov-report=term-missing",
            f"--cov-fail-under={self.coverage_threshold()}",
        )

    def additional_ci_args(self) -> tuple[str, ...]:
        """Get additional pytest-cov arguments for CI coverage analysis.

        Returns:
            Tuple of additional pytest-cov arguments for CI.
        """
        return ("--cov-report=xml",)

    def remote_coverage_url(self) -> str:
        """Construct Codecov dashboard URL.

        Returns:
            URL in format: `https://codecov.io/gh/{owner}/{repo}`
        """
        owner, repo = VersionController.I.repo_owner_and_name(
            check_repo_url=False, url_encode=True
        )
        return f"https://codecov.io/gh/{owner}/{repo}"

    def access_token_key(self) -> str:
        """Get the environment variable key for the Codecov access token.

        Used in CI/CD contexts for authentication when uploading coverage reports.
        """
        return "CODECOV_TOKEN"
