## Yandex Music API

> Делаю то, что по определённым причинам не сделала компания Yandex.

⚠️ Это неофициальная библиотека.

Сообщество разработчиков общаются и помогают друг другу в [Telegram чате](https://t.me/yandex_music_api), присоединяйтесь!

### Содержание
  - [Введение](#введение)
    1.  [Доступ к вашим данным Яндекс.Музыка](#доступ-к-вашим-данным-яндексмузыка)
  - [Установка](#установка)
  - [Начало работы](#начало-работы)
    1.  [Изучение по примерам](#изучение-по-примерам)
    2.  [Особенности использования асинхронного клиента](#особенности-использования-асинхронного-клиента)
    3.  [Логирование](#логирование)
    4.  [Документация](#документация)
  - [Получение помощи](#получение-помощи)
  - [Список изменений](#список-изменений)
  - [Реализации на других языках](#реализации-на-других-языках)
  - [Внесение своего вклада в проект](#внесение-своего-вклада-в-проект)
  - [Лицензия](#лицензия)

### Введение

Эта библиотека предоставляет Python интерфейс для никем незадокументированного и сделанного только для себя API Яндекс Музыки.

Она совместима с версиями Python 3.8+ и поддерживает работу как с синхронным, так и с асинхронным (asyncio) кодом.

В дополнение к реализации чистого API данная библиотека имеет ряд классов-обёрток — объектов высокого уровня, дабы сделать разработку клиентов и скриптов простой и понятной. Вся документация была написана с нуля исходя из логического анализа в ходе обратной разработки (reverse engineering) API.

#### Доступ к вашим данным Яндекс.Музыка

Для большинства аккаунтов токен можно получить прямо из библиотеки через OAuth Device Flow:

``` python
from yandex_music import Client


def on_code(code):
    print(f'Откройте {code.verification_url} и введите код: {code.user_code}')


client = Client()
token = client.device_auth(on_code=on_code)

# Сохраните токен куда-нибудь (переменная окружения, файл, БД),
# чтобы не проходить авторизацию при каждом запуске.
print(f'access_token:  {token.access_token}')
print(f'refresh_token: {token.refresh_token}')
print(f'expires_in:    {token.expires_in}')

client.init()
```

Метод `device_auth` блокирующий: он ждёт, пока вы подтвердите вход на странице Яндекса, и возвращает объект `OAuthToken` с полями `access_token`, `refresh_token`, `expires_in`, `token_type`. **Хранение токена — ответственность вызывающего кода:** библиотека не сохраняет его на диск и не обновляет по истечении `expires_in`. Если Device Flow для вашего аккаунта не работает — смотрите альтернативные способы в [документации](https://ym.marshal.dev/token).

### Установка

Установить или обновить библиотеку:

``` shell
pip install -U yandex-music
```

Этой команды достаточно для работы с синхронным клиентом. Для асинхронного клиента (`ClientAsync`) нужны дополнительные зависимости `aiohttp` и `aiofiles` — они доступны как опциональный экстра `async`:

``` shell
pip install -U "yandex-music[async]"
```

Установка из исходного кода:

``` shell
git clone https://github.com/MarshalX/yandex-music-api
cd yandex-music-api
pip install .          # синхронный клиент
pip install ".[async]" # с поддержкой асинхронного клиента
```

### Начало работы

Приступив к работе, первым делом необходимо создать экземпляр клиента.

Инициализация синхронного клиента:

``` python
from yandex_music import Client

client = Client()
client.init()

# или

client = Client().init()
```

Инициализация асинхронного клиента:

``` python
from yandex_music import ClientAsync

client = ClientAsync()
await client.init()

# или

client = await Client().init()
```

Вызов `init()` необходим для получения информации — упрощения будущих запросов.

Работа без авторизации ограничена. Так, например, для загрузки будут доступны только первые 30 секунд аудиофайла. Для понимания всех ограничений зайдите на сайт Яндекс.Музыка в режиме инкогнито и воспользуйтесь сервисом.

Для доступа к личным данным следует авторизоваться. Это осуществляется через токен аккаунта Яндекс.Музыка.

Авторизация:

``` python
from yandex_music import Client

client = Client('token').init()
```

После успешного создания клиента вы вольны в выборе необходимого метода из API. Все они доступны у объекта класса `Client`. Подробнее в методах клиента в [документации](https://ym.marshal.dev/client).

Пример получения первого трека из плейлиста "Мне нравится" и его загрузки:

``` python
from yandex_music import Client

client = Client('token').init()
client.users_likes_tracks()[0].fetch_track().download('example.mp3')
```

В примере выше клиент получает список треков, которые были отмечены как понравившиеся. API возвращает объект [TracksList](https://ym.marshal.dev/yandex_music.tracks_list), в котором содержится список с треками класса [TrackShort](https://ym.marshal.dev/yandex_music.track_short). Данный класс содержит наиважнейшую информацию о треке и никаких подробностей, поэтому для получения полной версии трека со всей информацией необходимо обратиться к методу `fetch_track()`. Затем можно скачать трек методом `download()`.

Пример получения треков по ID:

``` python
from yandex_music import Client

client = Client().init()
client.tracks(['10994777:1193829', '40133452:5206873', '48966383:6693286', '51385674:7163467'])
```

В качестве ID трека выступает его уникальный номер и номер альбома. Первым треком из примера является следующий трек:music.yandex.ru/album/**1193829**/track/**10994777**

Выполнение запросов с использованием прокси в синхронной версии:

``` python
from yandex_music.utils.request import Request
from yandex_music import Client

request = Request(proxy_url='socks5://user:password@host:port')
client = Client(request=request).init()
```

Примеры Proxy URL:
  - socks5://user:<password@host>:port
  - <http://host:port>
  - <https://host:port>
  - <http://user:password@host>

Больше примеров тут: [proxies - advanced usage - requests](https://2.python-requests.org/en/master/user/advanced/#proxies)

Выполнение запросов с использованием прокси в асинхронной версии:

``` python
from yandex_music.utils.request_async import Request
from yandex_music import ClientAsync

request = Request(proxy_url='http://user:pass@some.proxy.com')
client = await ClientAsync(request=request).init()
```

Socks прокси не поддерживаются в асинхронной версии.

Про поддерживаемые прокси тут: [proxy support - advanced usage - aiohttp](https://docs.aiohttp.org/en/stable/client_advanced.html#proxy-support)

#### Изучение по примерам

Вот несколько примеров для обзора. Даже если это не ваш подход к обучению, пожалуйста, возьмите и бегло просмотрите их.

Код примеров опубликован в открытом доступе, поэтому вы можете взять его и начать писать вокруг него свой.

Посетите [эту страницу](https://github.com/MarshalX/yandex-music-api/blob/main/examples/), чтобы изучить официальные примеры.

#### Особенности использования асинхронного клиента

При работе с асинхронной версией библиотеке стоит всегда помнить
следующие особенности:
  - Клиент следует импортировать с названием `ClientAsync`, а не просто `Client`.
  - При использовании методов-сокращений нужно выбирать метод с суффиксом `_async`.

Пояснение ко второму пункту:

``` python
from yandex_music import ClientAsync

client = await ClientAsync('token').init()
liked_short_track = (await client.users_likes_tracks())[0]

# правильно
full_track = await liked_short_track.fetch_track_async()
await full_track.download_async()

# НЕПРАВИЛЬНО
full_track = await liked_short_track.fetch_track()
await full_track.download()
```

#### Логирование

Данная библиотека использует модуль `logging`. Чтобы настроить логирование на стандартный вывод, поместите в начало вашего скрипта следующий код:

``` python
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

Вы также можете использовать логирование в вашем приложении, вызвав `logging.getLogger()` и установить уровень какой вы хотите:

``` python
logger = logging.getLogger()
logger.setLevel(logging.INFO)
```

Если вы хотите `DEBUG` логирование:

``` python
logger.setLevel(logging.DEBUG)
```

### Документация

Документация `yandex-music-api` расположена на [ym.marshal.dev](https://ym.marshal.dev/). Вашей отправной точкой должен быть класс `Client`, а точнее его методы. Именно они выполняют все запросы на API и возвращают вам готовые объекты. [Класс Client на ym.marshal.dev](https://ym.marshal.dev/client).

### Получение помощи

Получить помощь можно несколькими путями:
  - Задать вопрос в [Telegram чате](https://t.me/yandex_music_api), где мы помогаем друг другу, присоединяйтесь\!
  - Сообщить о баге можно [создав Bug Report](https://github.com/MarshalX/yandex-music-api/issues/new?assignees=MarshalX&labels=bug&template=bug-report.md&title=).
  - Предложить новую фичу или задать вопрос можно [создав discussion](https://github.com/MarshalX/yandex-music-api/discussions/new).
  - Найти ответ на вопрос в [документации библиотеки](https://ym.marshal.dev/).

### Список изменений

Весь список изменений ведётся в файле [CHANGES.md](https://github.com/MarshalX/yandex-music-api/blob/main/CHANGES.md).

### Реализации на других языках

- [OpenAPI спецификация](https://github.com/acherkashin/yandex-music-open-api/blob/main/src/yandex-music.yaml)
- [C#](https://github.com/K1llMan/Yandex.Music.Api)
- [PHP](https://github.com/LuckyWins/yandex-music-api)
- [TS](https://github.com/acherkashin/yandex-music-open-api)
- [JS](https://github.com/kontsevoye/ym-api)

### Внесение своего вклада в проект

Внесение своего вклада максимально приветствуется! Есть перечень пунктов, который стоит соблюдать. Каждый пункт перечня расписан в [CONTRIBUTING.md](https://github.com/MarshalX/yandex-music-api/blob/main/CONTRIBUTING.md).

Вы можете помочь и сообщив о [баге](https://github.com/MarshalX/yandex-music-api/issues/new?assignees=MarshalX&labels=bug&template=bug-report.md&title=) или о [новом поле пришедшем от API](https://github.com/MarshalX/yandex-music-api/issues/new?assignees=&labels=feature&template=found-unknown-fields.md&title=%D0%9D%D0%BE%D0%B2%D0%BE%D0%B5+%D0%BD%D0%B5%D0%B8%D0%B7%D0%B2%D0%B5%D1%81%D1%82%D0%BD%D0%BE%D0%B5+%D0%BF%D0%BE%D0%BB%D0%B5+%D0%BE%D1%82+API).

### Лицензия

Вы можете копировать, распространять и модифицировать программное обеспечение при условии, что модификации описаны и лицензированы бесплатно в соответствии с [LGPL-3](https://www.gnu.org/licenses/lgpl-3.0.html). Произведения производных (включая модификации или что-либо статически связанное с библиотекой) могут распространяться только в соответствии с LGPL-3, но приложения, которые используют библиотеку, необязательно.
