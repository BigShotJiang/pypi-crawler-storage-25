import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any


EXPLICIT_PATTERNS = [
    "that's wrong", "not correct", "actually", "I said", "no wait",
    "wrong", "incorrect", "that's not right", "I meant", "forget that",
]


@dataclass
class DetectedCorrection:
    type: str
    rule: str
    original_intent: str
    corrected_intent: str
    confidence: float
    turn_id: str


class CorrectionDetector:
    def __init__(self):
        self.last_user_query = ""
        self.last_agent_response_time = 0.0

    def detect_explicit(self, user_message: str) -> DetectedCorrection | None:
        """Detect explicit corrections like 'that's wrong', 'not correct'."""
        user_lower = user_message.lower()
        
        for pattern in EXPLICIT_PATTERNS:
            if pattern in user_lower:
                return DetectedCorrection(
                    type="explicit",
                    rule=f"Never: {pattern}",
                    original_intent="",
                    corrected_intent=user_message,
                    confidence=0.9,
                    turn_id=str(int(time.time())),
                )
        
        return None

    def detect_implicit(
        self,
        user_message: str,
        response_time: float,
        last_user_query: str | None = None
    ) -> DetectedCorrection | None:
        """Detect implicit corrections - user rephrases after agent response."""
        
        if last_user_query is None:
            last_user_query = self.last_user_query
        
        if response_time < 4.0 and last_user_query:
            similarity = self._cosine_similarity(user_message, last_user_query)
            
            if similarity > 0.8:
                return DetectedCorrection(
                    type="implicit",
                    rule="User rephrased - original intent was X not Y",
                    original_intent=last_user_query,
                    corrected_intent=user_message,
                    confidence=0.7,
                    turn_id=str(int(time.time())),
                )
        
        return None

    def _cosine_similarity(self, text1: str, text2: str) -> float:
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.0

    def update_context(self, user_message: str):
        self.last_user_query = user_message
        self.last_agent_response_time = time.time()


class CorrectionStore:
    def __init__(self, memory):
        self.memory = memory

    async def store_correction(self, correction: DetectedCorrection, user_id: str):
        from agentkit.memory.base import Correction
        
        rule = Correction(
            rule=correction.rule,
            original_intent=correction.original_intent,
            corrected_intent=correction.corrected_intent,
            source_turn_id=correction.turn_id,
            created_at=datetime.now(),
        )
        
        user_model = await self.memory.get_user_model(user_id)
        if user_model:
            user_model.correction_rules.append(rule)
            await self.memory.update_user_model(
                user_id,
                correction_rules=user_model.correction_rules
            )