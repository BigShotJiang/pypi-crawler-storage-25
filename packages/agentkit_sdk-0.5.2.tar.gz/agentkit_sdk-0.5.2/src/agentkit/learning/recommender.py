import asyncio
from datetime import datetime, timedelta
from typing import Any

from agentkit.providers.llm import BaseLLM, Message


class ProactiveRecommender:
    def __init__(self, llm: BaseLLM):
        self.llm = llm

    async def generate_recommendations(
        self,
        user_model: Any,
        recent_turns: list[dict]
    ) -> list[str]:
        """Generate proactive recommendations based on user model and history."""
        
        if not recent_turns:
            return []
        
        context = self._build_context(user_model, recent_turns)
        
        prompt = f"""Based on this user profile and conversation history, suggest 
1-3 proactive recommendations the assistant could make.
Only suggest if there's a clear opportunity (>0.8 confidence).
Return as a JSON array of strings.

User Profile:
{context}

Output:"""
        
        try:
            response = await self.llm.chat(
                messages=[Message(role="user", content=prompt)],
                system="You are a recommendation engine. Output valid JSON only.",
            )
            
            import json
            recommendations = json.loads(response)
            return recommendations
        except:
            return []

    def _build_context(self, user_model: Any, recent_turns: list[dict]) -> str:
        parts = []
        
        if user_model:
            if user_model.inferred_interests:
                parts.append(f"Interests: {', '.join(user_model.inferred_interests)}")
            if user_model.stated_goals:
                parts.append(f"Goals: {', '.join(user_model.stated_goals)}")
            if user_model.open_loops:
                parts.append(f"Open topics: {[o.topic for o in user_model.open_loops]}")
        
        recent_topics = []
        for turn in recent_turns[-5:]:
            msg = turn.get("user_message", "")
            if len(msg) > 20:
                recent_topics.append(msg[:50])
        
        if recent_topics:
            parts.append(f"Recent topics: {', '.join(recent_topics)}")
        
        return "\n".join(parts)

    def detect_open_loops(self, user_message: str) -> list[str]:
        """Detect topics mentioned but not resolved."""
        loops = []
        
        question_markers = ["?", "can you", "how do i", "could you", "will you"]
        if any(m in user_message.lower() for m in question_markers):
            loops.append(user_message[:50])
        
        return loops