import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform, Animated, Dimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import config from './config';
import {
  connectWebSocket, sendText, sendAudio, sendInterrupt,
  closeWebSocket, isConnected,
} from './services/websocket';
import { startRecording, stopRecording, getRecordingBytes } from './services/audio';

const { width: SW } = Dimensions.get('window');

// ─── Color Palette (light lavender / purple) ───
const C = {
  bg: '#f0eeff',        // soft lavender background
  card: '#ffffff',       // white cards
  cardAlt: '#f7f5ff',   // subtle purple tint card
  primary: '#7c5cfc',   // main purple
  primaryDark: '#5b3de6',
  primaryLight: '#b8a9ff',
  accent: '#a78bfa',
  text: '#1e1b4b',      // dark indigo text
  textSec: '#6b6394',   // secondary text
  textMuted: '#a19bc2',
  border: '#e4e0f5',
  userBubble: '#7c5cfc',
  asstBubble: '#ffffff',
  shadow: '#7c5cfc20',
  orbGlow1: '#c4b5fd',
  orbGlow2: '#7c5cfc',
  orbGlow3: '#a78bfa',
  success: '#34d399',
  warning: '#fbbf24',
  danger: '#f87171',
};

export default function App() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  const [streamingText, setStreamingText] = useState('');
  const [activeTab, setActiveTab] = useState('chat');

  const scrollRef = useRef(null);
  const soundRef = useRef(null);
  const audioQ = useRef([]);
  const playing = useRef(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const ringAnim = useRef(new Animated.Value(0.3)).current;
  const orbFloat = useRef(new Animated.Value(0)).current;

  // ─── Orb Animations ───
  useEffect(() => {
    // Gentle float
    Animated.loop(
      Animated.sequence([
        Animated.timing(orbFloat, { toValue: -8, duration: 2000, useNativeDriver: true }),
        Animated.timing(orbFloat, { toValue: 0, duration: 2000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (isListening || isSpeaking || isProcessing) {
      const p = Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.18, duration: 700, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      ]));
      const r = Animated.loop(Animated.sequence([
        Animated.timing(ringAnim, { toValue: 0.8, duration: 900, useNativeDriver: true }),
        Animated.timing(ringAnim, { toValue: 0.3, duration: 900, useNativeDriver: true }),
      ]));
      p.start(); r.start();
      return () => { p.stop(); r.stop(); };
    } else {
      pulseAnim.setValue(1);
      ringAnim.setValue(0.3);
    }
  }, [isListening, isSpeaking, isProcessing]);

  // ─── Audio Queue ───
  const playNext = useCallback(async () => {
    if (!audioQ.current.length) { playing.current = false; setIsSpeaking(false); return; }
    playing.current = true; setIsSpeaking(true);
    const b64 = audioQ.current.shift();
    try {
      const { sound } = await Audio.Sound.createAsync(
        { uri: `data:audio/wav;base64,${b64}` }, { shouldPlay: true }
      );
      soundRef.current = sound;
      sound.setOnPlaybackStatusUpdate(s => {
        if (s.didJustFinish) { sound.unloadAsync(); soundRef.current = null; playNext(); }
      });
    } catch { soundRef.current = null; playNext(); }
  }, []);

  const flush = useCallback(() => {
    audioQ.current = [];
    if (soundRef.current) { soundRef.current.stopAsync().catch(()=>{}); soundRef.current.unloadAsync().catch(()=>{}); soundRef.current = null; }
    playing.current = false; setIsSpeaking(false);
  }, []);

  const enqueue = useCallback((b64) => {
    audioQ.current.push(b64);
    if (!playing.current) playNext();
  }, [playNext]);

  // ─── WebSocket Handler ───
  const onMsg = useCallback((data) => {
    switch (data.type) {
      case 'connection': setConnectionStatus(data.status); break;
      case 'audio': enqueue(data.data); break;
      case 'text_delta': setStreamingText(p => p + data.delta); break;
      case 'text':
        if (data.text) { setStreamingText(''); setMessages(p => [...p, { role: 'assistant', text: data.text }]); }
        break;
      case 'done': setIsProcessing(false); setStreamingText(''); break;
      case 'interrupted': flush(); setIsProcessing(false); setStreamingText(''); break;
      case 'proactive':
        setMessages(p => [...p, { role: 'assistant', text: '💡 ' + data.text }]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); break;
      case 'wake_word_required':
        setMessages(p => [...p, { role: 'system', text: '💤 Say the wake word to activate.' }]); break;
      case 'error':
        setMessages(p => [...p, { role: 'system', text: '⚠️ ' + data.message }]);
        setIsProcessing(false); setStreamingText(''); break;
    }
  }, [enqueue, flush]);

  useEffect(() => {
    connectWebSocket(onMsg, config.BACKEND_URL, config.API_KEY);
    return () => closeWebSocket();
  }, [onMsg]);

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages, streamingText]);

  // ─── Actions ───
  const handleOrb = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isListening) {
      setIsListening(false); setIsProcessing(true);
      const bytes = await getRecordingBytes();
      if (bytes) sendAudio(bytes); else setIsProcessing(false);
    } else {
      if (isSpeaking || isProcessing) { flush(); sendInterrupt(); setIsProcessing(false); }
      setIsListening(true); await startRecording();
    }
  };

  const handleSend = () => {
    const t = inputText.trim(); if (!t || !isConnected()) return;
    if (isSpeaking || isProcessing) { flush(); sendInterrupt(); }
    setMessages(p => [...p, { role: 'user', text: t }]);
    setInputText(''); setIsProcessing(true); sendText(t);
  };

  // ─── Helpers ───
  const statusColor = connectionStatus === 'connected' ? C.success : connectionStatus === 'connecting' ? C.warning : C.danger;
  const statusLabel = connectionStatus === 'connected' ? 'Online' : connectionStatus === 'connecting' ? 'Connecting...' : 'Offline';
  const orbIcon = isListening ? '⏹' : isProcessing ? '⏳' : isSpeaking ? '🔊' : '🎙️';
  const orbHint = isListening ? 'Tap to stop' : isProcessing ? 'Thinking...' : isSpeaking ? 'Speaking...' : 'Tap to speak';

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  // ─── Render ───
  return (
    <View style={s.root}>
      <StatusBar style="dark" />
      <LinearGradient colors={['#ece9ff', '#f5f3ff', C.bg]} style={s.bgGrad} />

      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.greeting}>Hi There 👋</Text>
          <Text style={s.greetSub}>{getGreeting()}</Text>
        </View>
        <View style={s.headerRight}>
          <View style={[s.statusPill, { backgroundColor: statusColor + '20' }]}>
            <View style={[s.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[s.statusLabel, { color: statusColor }]}>{statusLabel}</Text>
          </View>
        </View>
      </View>

      {activeTab === 'home' ? (
        /* ─── Home Tab ─── */
        <ScrollView style={s.homeScroll} showsVerticalScrollIndicator={false}>
          {/* Agent Card */}
          <View style={s.agentCard}>
            <LinearGradient colors={['#7c5cfc', '#a78bfa', '#c4b5fd']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.agentCardGrad}>
              <Text style={s.agentCardName}>{config.AGENT_NAME}</Text>
              <Text style={s.agentCardSub}>Your AI Voice Assistant</Text>
              <TouchableOpacity style={s.agentCardBtn} onPress={() => setActiveTab('chat')}>
                <Text style={s.agentCardBtnText}>Start Chat →</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>

          {/* Quick Actions */}
          <Text style={s.sectionTitle}>Quick Actions</Text>
          <View style={s.qActions}>
            {[
              { icon: '🎙️', label: 'Voice Chat', action: () => { setActiveTab('chat'); setTimeout(handleOrb, 300); } },
              { icon: '💬', label: 'Text Chat', action: () => setActiveTab('chat') },
              { icon: '📋', label: 'History', action: () => setActiveTab('chat') },
              { icon: '⚙️', label: 'Settings', action: () => {} },
            ].map((a, i) => (
              <TouchableOpacity key={i} style={s.qAction} onPress={a.action} activeOpacity={0.7}>
                <View style={s.qActionIcon}><Text style={{ fontSize: 24 }}>{a.icon}</Text></View>
                <Text style={s.qActionLabel}>{a.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Features */}
          <Text style={s.sectionTitle}>Features</Text>
          {[
            { icon: '🧠', title: 'Smart Memory', desc: 'Remembers your preferences and past conversations' },
            { icon: '🗣️', title: 'Voice Powered', desc: 'Natural voice interaction with real-time response' },
            { icon: '🔧', title: 'Tool Calling', desc: 'Can perform actions like search, calculate, and more' },
          ].map((f, i) => (
            <View key={i} style={s.featureCard}>
              <View style={s.featureIcon}><Text style={{ fontSize: 22 }}>{f.icon}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={s.featureTitle}>{f.title}</Text>
                <Text style={s.featureDesc}>{f.desc}</Text>
              </View>
            </View>
          ))}
          <View style={{ height: 100 }} />
        </ScrollView>
      ) : (
        /* ─── Chat Tab ─── */
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={20}>
          {/* Orb */}
          <View style={s.orbWrap}>
            <Animated.View style={[s.orbRing3, { opacity: ringAnim, transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]} />
            <Animated.View style={[s.orbRing2, { opacity: ringAnim, transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]} />
            <Animated.View style={[s.orbRing1, { transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]}>
              <TouchableOpacity onPress={handleOrb} activeOpacity={0.8} style={s.orbTouch}>
                <LinearGradient
                  colors={isListening ? ['#ef4444', '#dc2626'] : isSpeaking ? ['#f97316', '#ea580c'] : isProcessing ? ['#a78bfa', '#7c3aed'] : ['#7c5cfc', '#a78bfa']}
                  style={s.orbGrad}
                >
                  <Text style={s.orbIcon}>{orbIcon}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
            <Text style={s.orbHint}>{orbHint}</Text>
          </View>

          {/* Messages */}
          <ScrollView ref={scrollRef} style={s.msgs} contentContainerStyle={s.msgsContent} showsVerticalScrollIndicator={false}>
            {messages.length === 0 && !streamingText && (
              <View style={s.empty}>
                <Text style={s.emptyIcon}>💬</Text>
                <Text style={s.emptyTitle}>Start a conversation</Text>
                <Text style={s.emptySub}>Tap the mic or type below</Text>
              </View>
            )}
            {messages.map((m, i) => (
              <View key={i} style={[s.bubble, m.role === 'user' ? s.userBbl : m.role === 'system' ? s.sysBbl : s.asstBbl]}>
                <Text style={[s.bubbleText, m.role === 'user' ? s.userTxt : m.role === 'system' ? s.sysTxt : s.asstTxt]}>{m.text}</Text>
              </View>
            ))}
            {streamingText ? (
              <View style={[s.bubble, s.asstBbl]}>
                <Text style={[s.bubbleText, s.asstTxt]}>{streamingText}<Text style={{ color: C.primary }}>▍</Text></Text>
              </View>
            ) : null}
          </ScrollView>

          {/* Input */}
          <View style={s.inputWrap}>
            <View style={s.inputRow}>
              <TextInput
                style={s.input}
                value={inputText}
                onChangeText={setInputText}
                placeholder="Type a message..."
                placeholderTextColor={C.textMuted}
                returnKeyType="send"
                onSubmitEditing={handleSend}
                editable={connectionStatus === 'connected'}
              />
              <TouchableOpacity style={[s.sendBtn, !inputText.trim() && s.sendDisabled]} onPress={handleSend} disabled={!inputText.trim()}>
                <LinearGradient colors={inputText.trim() ? [C.primary, C.accent] : [C.border, C.border]} style={s.sendGrad}>
                  <Text style={s.sendIcon}>↑</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      )}

      {/* Bottom Nav */}
      <View style={s.nav}>
        {[
          { id: 'home', icon: '🏠', label: 'Home' },
          { id: 'chat', icon: '💬', label: 'Chat' },
        ].map(tab => (
          <TouchableOpacity key={tab.id} style={s.navItem} onPress={() => setActiveTab(tab.id)} activeOpacity={0.7}>
            <Text style={{ fontSize: 22 }}>{tab.icon}</Text>
            <Text style={[s.navLabel, activeTab === tab.id && s.navLabelActive]}>{tab.label}</Text>
            {activeTab === tab.id && <View style={s.navDot} />}
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ─── Styles ───
const SHADOW = { shadowColor: C.shadow, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 1, shadowRadius: 16, elevation: 6 };

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  bgGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 300 },

  // Header
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 60, paddingHorizontal: 24, paddingBottom: 8 },
  greeting: { fontSize: 24, fontWeight: '700', color: C.text },
  greetSub: { fontSize: 14, color: C.textSec, marginTop: 2 },
  headerRight: { alignItems: 'flex-end' },
  statusPill: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  statusDot: { width: 7, height: 7, borderRadius: 4, marginRight: 5 },
  statusLabel: { fontSize: 11, fontWeight: '600' },

  // Home
  homeScroll: { flex: 1, paddingHorizontal: 24 },
  agentCard: { marginTop: 20, borderRadius: 20, overflow: 'hidden', ...SHADOW },
  agentCardGrad: { padding: 28, borderRadius: 20 },
  agentCardName: { fontSize: 22, fontWeight: '800', color: '#fff' },
  agentCardSub: { fontSize: 14, color: '#ffffffcc', marginTop: 4 },
  agentCardBtn: { marginTop: 18, backgroundColor: '#ffffff30', alignSelf: 'flex-start', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 24 },
  agentCardBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  sectionTitle: { fontSize: 17, fontWeight: '700', color: C.text, marginTop: 28, marginBottom: 14 },

  qActions: { flexDirection: 'row', justifyContent: 'space-between' },
  qAction: { alignItems: 'center', width: (SW - 72) / 4 },
  qActionIcon: { width: 56, height: 56, borderRadius: 18, backgroundColor: C.card, justifyContent: 'center', alignItems: 'center', ...SHADOW },
  qActionLabel: { fontSize: 11, color: C.textSec, marginTop: 8, fontWeight: '500' },

  featureCard: { flexDirection: 'row', backgroundColor: C.card, padding: 16, borderRadius: 16, marginBottom: 12, alignItems: 'center', ...SHADOW },
  featureIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: C.cardAlt, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  featureTitle: { fontSize: 15, fontWeight: '700', color: C.text },
  featureDesc: { fontSize: 12, color: C.textSec, marginTop: 2 },

  // Orb
  orbWrap: { alignItems: 'center', paddingTop: 16, paddingBottom: 4 },
  orbRing3: { position: 'absolute', top: 0, width: 150, height: 150, borderRadius: 75, backgroundColor: C.orbGlow1 + '30' },
  orbRing2: { position: 'absolute', top: 12, width: 126, height: 126, borderRadius: 63, backgroundColor: C.orbGlow1 + '50' },
  orbRing1: { width: 100, height: 100, borderRadius: 50, justifyContent: 'center', alignItems: 'center' },
  orbTouch: { width: 100, height: 100, borderRadius: 50 },
  orbGrad: { width: 100, height: 100, borderRadius: 50, justifyContent: 'center', alignItems: 'center', ...SHADOW },
  orbIcon: { fontSize: 32 },
  orbHint: { marginTop: 10, fontSize: 13, color: C.textMuted, fontWeight: '500' },

  // Messages
  msgs: { flex: 1, paddingHorizontal: 20 },
  msgsContent: { paddingBottom: 8 },
  empty: { alignItems: 'center', paddingTop: 30, opacity: 0.5 },
  emptyIcon: { fontSize: 36, marginBottom: 10 },
  emptyTitle: { fontSize: 17, fontWeight: '600', color: C.text },
  emptySub: { fontSize: 13, color: C.textSec, marginTop: 2 },

  bubble: { maxWidth: '82%', paddingHorizontal: 16, paddingVertical: 11, borderRadius: 20, marginVertical: 4 },
  userBbl: { alignSelf: 'flex-end', backgroundColor: C.userBubble, borderBottomRightRadius: 6 },
  asstBbl: { alignSelf: 'flex-start', backgroundColor: C.asstBubble, borderBottomLeftRadius: 6, ...SHADOW },
  sysBbl: { alignSelf: 'center', backgroundColor: C.cardAlt, borderRadius: 14 },
  bubbleText: { fontSize: 15, lineHeight: 22 },
  userTxt: { color: '#fff' },
  asstTxt: { color: C.text },
  sysTxt: { color: C.textSec, fontSize: 13, textAlign: 'center' },

  // Input
  inputWrap: { paddingHorizontal: 20, paddingBottom: 4 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 28, paddingLeft: 20, paddingRight: 4, paddingVertical: 4, borderWidth: 1, borderColor: C.border, ...SHADOW },
  input: { flex: 1, height: 42, fontSize: 15, color: C.text },
  sendBtn: { marginLeft: 6 },
  sendDisabled: {},
  sendGrad: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  sendIcon: { fontSize: 18, fontWeight: '800', color: '#fff' },

  // Nav
  nav: { flexDirection: 'row', justifyContent: 'space-around', paddingTop: 10, paddingBottom: Platform.OS === 'ios' ? 30 : 14, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.border },
  navItem: { alignItems: 'center', paddingHorizontal: 20 },
  navLabel: { fontSize: 11, color: C.textMuted, marginTop: 2, fontWeight: '500' },
  navLabelActive: { color: C.primary, fontWeight: '700' },
  navDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: C.primary, marginTop: 4 },
});