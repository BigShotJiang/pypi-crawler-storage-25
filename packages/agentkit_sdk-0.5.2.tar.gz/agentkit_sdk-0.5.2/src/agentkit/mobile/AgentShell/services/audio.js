import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';

let recording = null;

/**
 * Start recording audio from the microphone.
 */
export const startRecording = async () => {
  try {
    const permission = await Audio.requestPermissionsAsync();
    if (!permission.granted) {
      console.error('Microphone permission not granted');
      return;
    }

    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true,
    });

    const { recording: rec } = await Audio.Recording.createAsync(
      Audio.RecordingOptionsPresets.HIGH_QUALITY
    );

    recording = rec;
  } catch (err) {
    console.error('Failed to start recording:', err);
    recording = null;
  }
};

/**
 * Stop recording and return the file URI.
 */
export const stopRecording = async () => {
  if (!recording) return null;

  try {
    await recording.stopAndUnloadAsync();
    await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
    const uri = recording.getURI();
    recording = null;
    return uri;
  } catch (err) {
    console.error('Failed to stop recording:', err);
    recording = null;
    return null;
  }
};

/**
 * Stop recording and return the audio data as an array of byte values
 * suitable for sending over WebSocket.
 */
export const getRecordingBytes = async () => {
  const uri = await stopRecording();
  if (!uri) return null;

  try {
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    // Convert base64 to byte array
    const binaryStr = atob(base64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    return Array.from(bytes);
  } catch (err) {
    console.error('Failed to read recording bytes:', err);
    return null;
  }
};