let socket = null;
let messageCallback = null;
let wsUrl = 'ws://localhost:8000/ws/voice';
let apiKey = '';
let reconnectTimer = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_DELAY = 30000;

/**
 * Connect to the AgentKit backend via WebSocket.
 * @param {Function} onMessage - callback for incoming messages
 * @param {string} url - WebSocket URL (e.g. wss://my-agent.railway.app/ws/voice)
 * @param {string} key - optional API key for auth
 */
export const connectWebSocket = (onMessage, url, key) => {
  messageCallback = onMessage;
  if (url) wsUrl = url;
  if (key) apiKey = key;
  _connect();
};

function _buildUrl() {
  const params = new URLSearchParams();
  if (apiKey) params.set('api_key', apiKey);
  const qs = params.toString();
  return qs ? `${wsUrl}?${qs}` : wsUrl;
}

function _connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    return;
  }

  const fullUrl = _buildUrl();
  socket = new WebSocket(fullUrl);

  socket.onopen = () => {
    console.log('WebSocket connected to', wsUrl);
    reconnectAttempts = 0;
    if (messageCallback) {
      messageCallback({ type: 'connection', status: 'connected' });
    }
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (messageCallback) {
        messageCallback(data);
      }
    } catch (err) {
      console.error('Failed to parse WebSocket message:', err);
    }
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error.message || error);
  };

  socket.onclose = (event) => {
    console.log('WebSocket closed:', event.code, event.reason);
    if (messageCallback) {
      messageCallback({ type: 'connection', status: 'disconnected' });
    }
    // Don't reconnect if closed due to auth failure
    if (event.code === 4003) {
      if (messageCallback) {
        messageCallback({ type: 'error', message: 'Authentication failed. Check your API key.' });
      }
      return;
    }
    _scheduleReconnect();
  };
}

function _scheduleReconnect() {
  if (reconnectTimer) return;
  const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), MAX_RECONNECT_DELAY);
  reconnectAttempts++;
  console.log(`Reconnecting in ${delay}ms (attempt ${reconnectAttempts})...`);
  if (messageCallback) {
    messageCallback({ type: 'connection', status: 'connecting' });
  }
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    _connect();
  }, delay);
}

export const sendText = (text) => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: 'text', text }));
  }
};

export const sendAudio = (audioData) => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: 'audio', data: audioData }));
  }
};

export const sendInterrupt = () => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: 'interrupt' }));
  }
};

export const isConnected = () => {
  return socket && socket.readyState === WebSocket.OPEN;
};

export const closeWebSocket = () => {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  if (socket) {
    socket.close();
    socket = null;
  }
};