import os
import shutil
from pathlib import Path

import click
import yaml


# ------------------------------------------------------------------
# Built-in provider catalog — name → (description, default model, env var, defaults)
# ------------------------------------------------------------------
BUILTIN_PROVIDERS = {
    "stt": {
        "sarvam":   {"desc": "Sarvam AI (Hindi/Hinglish focused)", "env": "SARVAM_API_KEY",   "defaults": {"language_code": "hi-IN"}},
        "deepgram": {"desc": "Deepgram (multilingual)",            "env": "DEEPGRAM_API_KEY",  "defaults": {"language": "hi"}},
    },
    "tts": {
        "sarvam":     {"desc": "Sarvam AI",   "env": "SARVAM_API_KEY",     "defaults": {"voice": "meera", "language_code": "hi-IN"}},
        "deepgram":   {"desc": "Deepgram Aura", "env": "DEEPGRAM_API_KEY",  "defaults": {"model": "aura-asteria-en"}},
        "elevenlabs": {"desc": "ElevenLabs",  "env": "ELEVENLABS_API_KEY", "defaults": {"voice_id": "pNInz6obpgDQGcFmaJgB"}},
    },
    "llm": {
        "groq":   {"desc": "Groq (Llama 3.3 70B — fast & free tier)", "env": "GROQ_API_KEY",   "defaults": {"model": "llama-3.3-70b-versatile", "temperature": 0.7}},
        "openai": {"desc": "OpenAI GPT-4o mini",                       "env": "OPENAI_API_KEY", "defaults": {"model": "gpt-4o-mini",              "temperature": 0.7}},
        "gemini": {"desc": "Google Gemini 2.0 Flash",                   "env": "GEMINI_API_KEY", "defaults": {"model": "gemini-2.0-flash",         "temperature": 0.7}},
    },
}

LANGUAGE_CHOICES = {"english": "English", "hindi": "Hindi", "hinglish": "Hinglish (Hindi + English)"}

MEMORY_CHOICES = {"markdown": "Markdown files (simple, no setup)", "vector": "Qdrant vector DB (semantic search)"}


def _prompt_provider(category: str, label: str) -> tuple[str, dict]:
    """Prompt user to pick a built-in provider or enter a custom one.

    Returns (provider_name, extra_config_dict).
    """
    builtins = BUILTIN_PROVIDERS[category]
    builtin_names = list(builtins.keys())

    click.secho(f"  {label}:", fg="white")
    for key, info in builtins.items():
        click.echo(f"    {key:12s} - {info['desc']}")
    click.echo(f"    {'custom':12s} - Use your own provider class")

    choice = click.prompt(
        f"  Choose {label} provider",
        default=builtin_names[0],
    )

    if choice == "custom":
        dotted = click.prompt(
            "  Provider class (dotted import path)",
            type=str,
        )
        env_var = click.prompt("  API key env var name (or leave empty)", default="", show_default=False)
        extra_cfg: dict = {}
        if env_var:
            extra_cfg["api_key"] = f"${{{env_var}}}"
        # Let user add arbitrary key=value pairs
        click.echo("  Add extra config (key=value). Empty line to finish:")
        while True:
            kv = click.prompt("    ", default="", show_default=False)
            if not kv:
                break
            if "=" in kv:
                k, v = kv.split("=", 1)
                # Try to parse as number/bool
                extra_cfg[k.strip()] = _auto_cast(v.strip())

        return dotted, extra_cfg

    # Built-in provider chosen (may be typed as a known name)
    if choice in builtins:
        info = builtins[choice]
        extra = dict(info["defaults"])
        extra["api_key"] = f"${{{info['env']}}}"
        return choice, extra

    # User typed a name that's not built-in and not "custom"
    # Treat it as a custom dotted path if it has a dot, else unknown
    if "." in choice:
        return choice, {}

    click.secho(f"  Unknown provider '{choice}'. Using as-is in config.", fg="yellow")
    return choice, {}


def _auto_cast(value: str):
    """Cast string values to int/float/bool where obvious."""
    if value.lower() in ("true", "yes"):
        return True
    if value.lower() in ("false", "no"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


@click.command()
@click.argument("name", default="my-agent")
@click.option("--output-dir", default=".", help="Output directory")
@click.option("--non-interactive", is_flag=True, help="Skip prompts, use defaults")
def init(name: str, output_dir: str, non_interactive: bool):
    """Initialize a new AgentKit project.

    Example: agentkit init my-agent
    """

    click.echo()
    click.secho("  AgentKit", fg="cyan", bold=True)
    click.secho(f"  Creating project: {name}", fg="white")
    click.echo()

    if non_interactive:
        language = "hinglish"
        stt_provider, stt_extra = "sarvam", {"api_key": "${SARVAM_API_KEY}", **BUILTIN_PROVIDERS["stt"]["sarvam"]["defaults"]}
        tts_provider, tts_extra = "sarvam", {"api_key": "${SARVAM_API_KEY}", **BUILTIN_PROVIDERS["tts"]["sarvam"]["defaults"]}
        llm_provider, llm_extra = "groq", {"api_key": "${GROQ_API_KEY}", **BUILTIN_PROVIDERS["llm"]["groq"]["defaults"]}
        memory_type = "markdown"
        persona = "You are a helpful personal assistant that remembers conversations and learns from corrections."
    else:
        # Interactive prompts
        click.secho("  1. Agent Configuration", fg="yellow", bold=True)
        persona = click.prompt(
            "  Agent persona",
            default="You are a helpful personal assistant that remembers conversations and learns from corrections.",
        )
        click.echo()

        click.secho("  Language:", fg="white")
        for key, desc in LANGUAGE_CHOICES.items():
            click.echo(f"    {key:12s} - {desc}")
        language = click.prompt(
            "  Choose language",
            type=click.Choice(list(LANGUAGE_CHOICES.keys())),
            default="hinglish",
        )
        click.echo()

        click.secho("  2. Provider Selection", fg="yellow", bold=True)
        click.secho("  (pick a built-in or type 'custom' to use your own class)", dim=True)
        click.echo()

        stt_provider, stt_extra = _prompt_provider("stt", "STT (Speech-to-Text)")
        click.echo()
        tts_provider, tts_extra = _prompt_provider("tts", "TTS (Text-to-Speech)")
        click.echo()
        llm_provider, llm_extra = _prompt_provider("llm", "LLM")
        click.echo()

        click.secho("  3. Memory System", fg="yellow", bold=True)
        for key, desc in MEMORY_CHOICES.items():
            click.echo(f"    {key:12s} - {desc}")
        memory_type = click.prompt(
            "  Choose memory type",
            type=click.Choice(list(MEMORY_CHOICES.keys())),
            default="markdown",
        )
        click.echo()

    # Determine which API keys are needed
    required_keys = _get_required_keys(stt_extra, tts_extra, llm_extra)

    # Build config — merge provider defaults + user extras
    stt_config = {"provider": stt_provider, **stt_extra}
    tts_config = {"provider": tts_provider, **tts_extra}
    llm_config = {"provider": llm_provider, **llm_extra}

    config_content = {
        "agent": {
            "name": name,
            "persona": persona,
            "language": language,
        },
        "voice": {
            "enabled": True,
            "stt": stt_config,
            "tts": tts_config,
        },
        "llm": llm_config,
        "memory": {
            "type": memory_type,
            "backend": "local" if memory_type == "markdown" else "qdrant",
            "episodic_window": 20,
            "semantic_top_k": 5,
        },
        "learning": {
            "enabled": True,
            "correction_detection": True,
            "implicit_feedback": True,
            "profile_extraction": True,
        },
        "deployment": {"type": "self-host", "port": 8000, "backend_url": "", "api_key": ""},
        "wake_word": {
            "enabled": False,
            "words": ["hey " + name.lower().replace("-", " ").replace("_", " ")],
            "required": True,
            "listen_window": 30,
        },
        "proactive": {
            "enabled": False,
            "idle_timeout": 300,
            "idle_message": "Hey! I'm here if you need anything. Just ask!",
            "idle_repeat": False,
        },
    }

    # Create project
    project_dir = Path(output_dir) / name
    project_dir.mkdir(parents=True, exist_ok=True)

    config_path = project_dir / "agent.config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config_content, f, default_flow_style=False, sort_keys=False)

    # Generate .env with placeholders for required keys only
    env_lines = ["# AgentKit API Keys", "# Fill in the keys for your chosen providers", ""]
    for key in required_keys:
        env_lines.append(f"{key}=")
    env_content = "\n".join(env_lines) + "\n"

    (project_dir / ".env").write_text(env_content)
    (project_dir / ".env.example").write_text(env_content)

    # Generate .gitignore
    gitignore = """# Environment
.env
__pycache__/
*.pyc

# Memory storage
memory/

# Build output
build/
dist/
*.egg-info/

# IDE
.vscode/
.idea/
"""
    (project_dir / ".gitignore").write_text(gitignore)

    # Create memory directory
    (project_dir / "memory").mkdir(exist_ok=True)

    # Generate tools.py with example tools
    tools_content = '''"""
AgentKit Tools — define functions your agent can call mid-conversation.

The agent will automatically detect when a tool is needed and call it.
Add your own tools below!
"""
from agentkit.core.tools import ToolRegistry

tools = ToolRegistry()


@tools.register
def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime
    return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")


@tools.register
def calculate(expression: str) -> str:
    """Evaluate a math expression safely."""
    allowed = set("0123456789+-*/.() ")
    if not all(c in allowed for c in expression):
        return "Error: only basic math operations are supported"
    try:
        result = eval(expression)  # safe: input is sanitized above
        return str(result)
    except Exception as e:
        return f"Error: {e}"


# Add your own tools:
#
# @tools.register
# def search_web(query: str) -> str:
#     """Search the web for information."""
#     import httpx
#     response = httpx.get(f"https://api.example.com/search?q={query}")
#     return response.json()["answer"]
#
# @tools.register
# def get_weather(city: str) -> str:
#     """Get the current weather for a city."""
#     return f"25°C and sunny in {city}"
'''
    (project_dir / "tools.py").write_text(tools_content)

    # Generate main.py — the primary entry point with real Python code
    main_content = f'''"""
{name} — built with AgentKit
{"=" * (len(name) + 22)}

Run this file to start your agent:
    python main.py

Or use the CLI:
    agentkit serve
"""
import asyncio
from agentkit import Agent


# Load agent from config
agent = Agent.from_config("agent.config.yaml")


# Register custom tools from tools.py
from tools import tools as custom_tools
for tool_def in custom_tools.list_tools():
    agent.register_tool(tool_def)


async def main():
    """Quick test — send a message and print the response."""
    response = await agent.chat("Hello! Tell me about yourself.")
    print(f"Agent: {{response.text}}")
    await agent.close()


if __name__ == "__main__":
    # ── Option 1: Quick chat test ────────────────────────────
    # asyncio.run(main())

    # ── Option 2: Start the full server with playground ──────
    agent.serve()
'''
    (project_dir / "main.py").write_text(main_content)

    # Generate example.py — standalone programmatic usage without YAML
    example_content = f'''"""
Example: Using AgentKit purely with Python code — no YAML config needed.
========================================================================

This file shows how to use AgentKit as a library, just like OpenAI or
Deepgram. Import, instantiate, call — that's it.
"""
import asyncio
import os

from agentkit import Agent


async def main():
    # ── Create an agent with code — no YAML ──────────────────
    agent = Agent(
        name="{name}",
        persona="You are a friendly, helpful assistant.",
        llm_provider="{llm_provider}",
        llm_api_key=os.getenv("{list(required_keys)[0] if required_keys else 'YOUR_API_KEY'}"),
    )

    # ── Register a tool ──────────────────────────────────────
    @agent.tool
    def get_current_time() -> str:
        """Get the current date and time."""
        from datetime import datetime
        return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")

    # ── Simple chat ──────────────────────────────────────────
    print("Sending message...")
    response = await agent.chat("Hi! What time is it?")
    print(f"Agent: {{response.text}}")
    print()

    # ── Streaming chat ───────────────────────────────────────
    print("Streaming response:")
    async for token in agent.chat_stream("Tell me a short joke"):
        print(token, end="", flush=True)
    print()

    # ── Clean up ─────────────────────────────────────────────
    await agent.close()


if __name__ == "__main__":
    asyncio.run(main())
'''
    (project_dir / "example.py").write_text(example_content)

    # Print summary
    click.echo()
    click.secho("  Project created!", fg="green", bold=True)
    click.echo()
    click.echo(f"  {project_dir}/")
    click.echo(f"    main.py             - start here — run your agent")
    click.echo(f"    example.py          - standalone code usage (no YAML)")
    click.echo(f"    agent.config.yaml   - agent configuration")
    click.echo(f"    tools.py            - custom tools for your agent")
    click.echo(f"    .env                - API keys (fill these in)")
    click.echo(f"    .env.example        - API key template")
    click.echo(f"    .gitignore          - git ignore rules")
    click.echo(f"    memory/             - conversation memory storage")
    click.echo()

    click.secho("  Providers:", fg="white")
    click.echo(f"    STT: {stt_provider}")
    click.echo(f"    TTS: {tts_provider}")
    click.echo(f"    LLM: {llm_provider}")
    click.echo(f"    Memory: {memory_type}")
    click.echo()

    click.secho("  Next steps:", fg="yellow", bold=True)
    click.echo(f"    1. cd {name}")
    click.echo(f"    2. Add your API keys to .env")

    if required_keys:
        click.echo(f"       Required: {', '.join(required_keys)}")

    click.echo(f"    3. python main.py            # start the server")
    click.echo(f"       python example.py         # or try code-only mode")
    click.echo(f"       agentkit serve            # or use the CLI")
    click.echo()


def _get_required_keys(*provider_extras: dict) -> list[str]:
    """Extract env var names from ${VAR} references in provider configs."""
    import re

    keys = set()
    for extra in provider_extras:
        for value in extra.values():
            if isinstance(value, str):
                matches = re.findall(r'\$\{(\w+)\}', value)
                keys.update(matches)
    return sorted(keys)