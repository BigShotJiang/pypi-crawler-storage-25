import os
import subprocess
import sys
from pathlib import Path

import click
import yaml


PLATFORMS = ["railway", "render", "docker", "azure"]


def _update_config_url(config_path: str, backend_url: str):
    """Write the deployed backend_url back into agent.config.yaml."""
    path = Path(config_path)
    with open(path) as f:
        cfg = yaml.safe_load(f)

    if "deployment" not in cfg:
        cfg["deployment"] = {}
    cfg["deployment"]["backend_url"] = backend_url

    with open(path, "w") as f:
        yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

    click.secho(f"  ✓ Saved backend_url to {config_path}", fg="green")


def _ensure_requirements():
    """Generate requirements.txt if it doesn't exist."""
    if not Path("requirements.txt").exists():
        Path("requirements.txt").write_text("agentkit-sdk\n")
        click.echo("  Generated requirements.txt")


def _ensure_dockerfile(config: str):
    """Generate a Dockerfile if it doesn't exist."""
    if Path("Dockerfile").exists():
        return

    with open(config) as f:
        cfg = yaml.safe_load(f)

    port = cfg.get("deployment", {}).get("port", 8000)

    dockerfile = f"""FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE {port}

CMD ["agentkit", "serve", "--port", "{port}"]
"""
    Path("Dockerfile").write_text(dockerfile)
    click.echo("  Generated Dockerfile")


@click.command()
@click.option(
    "--platform",
    type=click.Choice(PLATFORMS),
    required=True,
    help="Deployment platform",
)
@click.option("--config", default="agent.config.yaml", help="Config file path")
@click.option("--url", default=None, help="Manually set the deployed backend URL")
def deploy(platform: str, config: str, url: str):
    """Deploy backend to Railway, Render, Azure, or generate a Dockerfile.

    After deploying, the backend URL is saved to agent.config.yaml
    so that 'agentkit build android' can use it automatically.

    \b
    Examples:
      agentkit deploy --platform render    # One-click Render deploy
      agentkit deploy --platform azure     # One-click Azure deploy
      agentkit deploy --platform railway   # Deploy to Railway
      agentkit deploy --platform docker    # Generate Dockerfile only
    """

    if not Path(config).exists():
        click.secho(f"Error: Config file '{config}' not found.", fg="red")
        click.echo("Run 'agentkit init' first to create a project.")
        sys.exit(1)

    # If user provides --url directly, just save it and exit
    if url:
        _update_config_url(config, url)
        click.echo()
        click.secho("  Next step:", fg="yellow", bold=True)
        click.echo("    agentkit build android")
        click.echo()
        return

    if platform == "docker":
        _generate_dockerfile(config)
    elif platform == "railway":
        _deploy_railway(config)
    elif platform == "render":
        _deploy_render(config)
    elif platform == "azure":
        _deploy_azure(config)


# ------------------------------------------------------------------
# Docker
# ------------------------------------------------------------------

def _generate_dockerfile(config: str):
    """Generate a Dockerfile for self-hosting."""

    with open(config) as f:
        cfg = yaml.safe_load(f)

    port = cfg.get("deployment", {}).get("port", 8000)

    _ensure_requirements()
    _ensure_dockerfile(config)

    click.echo()
    click.secho("  ✓ Generated Dockerfile and requirements.txt", fg="green")
    click.echo()
    click.echo("  Build and run:")
    click.echo("    docker build -t my-agent .")
    click.echo(f"    docker run -p {port}:{port} --env-file .env my-agent")
    click.echo()

    # Prompt for deployed URL
    click.echo("  After deploying your Docker container, set the backend URL:")
    deployed_url = click.prompt(
        "  Enter deployed backend URL (or press Enter to skip)",
        default="",
        show_default=False,
    )
    if deployed_url.strip():
        _update_config_url(config, deployed_url.strip())
        click.echo()
        click.secho("  Next step:", fg="yellow", bold=True)
        click.echo("    agentkit build android")
    else:
        click.echo()
        click.secho("  When deployed, save the URL with:", fg="yellow")
        click.echo("    agentkit deploy --platform docker --url wss://your-server.com/ws/voice")
        click.echo("  Then build your app:")
        click.echo("    agentkit build android")
    click.echo()


# ------------------------------------------------------------------
# Railway
# ------------------------------------------------------------------

def _deploy_railway(config: str):
    import shutil

    if not shutil.which("railway"):
        click.secho("Railway CLI not found.", fg="red")
        click.echo("Install: npm install -g @railway/cli")
        click.echo("Then:    railway login")
        sys.exit(1)

    _ensure_requirements()

    try:
        click.echo("Initializing Railway project...")
        subprocess.run(["railway", "init"], check=True)

        click.echo("Deploying to Railway...")
        subprocess.run(["railway", "up"], check=True)

        click.secho("\nDeployed to Railway!", fg="green", bold=True)
        click.echo("Run 'railway open' to view your deployment.")

        # Try to get the deployment URL
        result = subprocess.run(
            ["railway", "domain"], capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            domain = result.stdout.strip()
            backend_url = f"wss://{domain}/ws/voice"
            _update_config_url(config, backend_url)
            click.echo()
            click.secho("  Next step:", fg="yellow", bold=True)
            click.echo("    agentkit build android")
        else:
            click.echo()
            click.echo("  Could not auto-detect Railway domain.")
            deployed_url = click.prompt(
                "  Enter your Railway deployment URL (or press Enter to skip)",
                default="",
                show_default=False,
            )
            if deployed_url.strip():
                _update_config_url(config, deployed_url.strip())
                click.echo()
                click.secho("  Next step:", fg="yellow", bold=True)
                click.echo("    agentkit build android")
            else:
                click.echo("  Set it later: agentkit deploy --platform railway --url wss://your-app.railway.app/ws/voice")

    except subprocess.CalledProcessError as e:
        click.secho(f"Railway deployment failed: {e}", fg="red")
        sys.exit(1)


# ------------------------------------------------------------------
# Render
# ------------------------------------------------------------------

def _deploy_render(config: str):
    """One-click Render deploy — generates render.yaml and deploys."""

    with open(config) as f:
        cfg = yaml.safe_load(f)

    port = cfg.get("deployment", {}).get("port", 8000)
    agent_name = cfg.get("agent", {}).get("name", "agentkit-server")
    # Sanitize name for Render (lowercase, alphanumeric + hyphens)
    service_name = agent_name.lower().replace("_", "-").replace(" ", "-")

    # Collect env var keys from config
    env_keys = _extract_env_keys(cfg)

    _ensure_requirements()
    _ensure_dockerfile(config)

    # ── Generate render.yaml ─────────────────────────────────────
    render_config = {
        "services": [
            {
                "type": "web",
                "name": service_name,
                "runtime": "docker",
                "plan": "starter",
                "dockerfilePath": "./Dockerfile",
                "envVars": [
                    {"key": k, "sync": False} for k in env_keys
                ],
                "healthCheckPath": "/health",
            }
        ]
    }

    Path("render.yaml").write_text(
        yaml.dump(render_config, default_flow_style=False, sort_keys=False)
    )

    click.echo()
    click.secho("  AgentKit → Render Deploy", fg="cyan", bold=True)
    click.echo()
    click.secho("  ✓ Generated render.yaml", fg="green")
    click.secho("  ✓ Generated Dockerfile", fg="green")
    click.secho("  ✓ Generated requirements.txt", fg="green")
    click.echo()

    _render_manual_instructions(env_keys)

    # Prompt for URL if user has already deployed
    click.echo()
    deployed_url = click.prompt(
        "  Already deployed? Enter your Render URL (or press Enter to skip)",
        default="",
        show_default=False,
    )
    if deployed_url.strip():
        domain = deployed_url.strip().replace("https://", "").replace("http://", "").rstrip("/")
        backend_url = f"wss://{domain}/ws/voice"
        _update_config_url(config, backend_url)
        click.echo()
        click.secho("  Next step:", fg="yellow", bold=True)
        click.echo("    agentkit build android")

    click.echo()


def _render_manual_instructions(env_keys: list):
    """Print manual Render deployment instructions."""
    click.echo()
    click.secho("  Deploy in 3 steps:", fg="yellow", bold=True)
    click.echo()
    click.echo("  1. Push your project to GitHub/GitLab")
    click.echo("     git init && git add . && git commit -m 'initial'")
    click.echo("     git remote add origin https://github.com/you/my-agent.git")
    click.echo("     git push -u origin main")
    click.echo()
    click.echo("  2. Go to https://dashboard.render.com/blueprints")
    click.echo("     Click 'New Blueprint Instance' → connect your repo")
    click.echo("     Render reads render.yaml and creates the service automatically")
    click.echo()
    click.echo("  3. Add environment variables in the Render dashboard:")
    for key in env_keys:
        click.echo(f"     • {key}")
    click.echo()
    click.echo("  After deploying, save the URL:")
    click.echo("    agentkit deploy --platform render --url wss://your-app.onrender.com/ws/voice")


# ------------------------------------------------------------------
# Azure
# ------------------------------------------------------------------

def _deploy_azure(config: str):
    """One-click Azure deploy using Azure Container Apps or App Service."""
    import shutil

    with open(config) as f:
        cfg = yaml.safe_load(f)

    port = cfg.get("deployment", {}).get("port", 8000)
    agent_name = cfg.get("agent", {}).get("name", "agentkit-server")
    # Sanitize for Azure (lowercase, alphanumeric + hyphens, 2-32 chars)
    app_name = agent_name.lower().replace("_", "-").replace(" ", "-")[:32]

    env_keys = _extract_env_keys(cfg)

    _ensure_requirements()
    _ensure_dockerfile(config)

    click.echo()
    click.secho("  AgentKit → Azure Deploy", fg="cyan", bold=True)
    click.echo()

    # Check for Azure CLI
    if not shutil.which("az"):
        click.secho("  Azure CLI not found.", fg="red")
        click.echo()
        click.echo("  Install the Azure CLI:")
        click.echo("    macOS:   brew install azure-cli")
        click.echo("    Windows: winget install Microsoft.AzureCLI")
        click.echo("    Linux:   curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash")
        click.echo()
        click.echo("  Then run: az login")
        click.echo("  And retry: agentkit deploy --platform azure")
        sys.exit(1)

    # Check login status
    login_check = subprocess.run(
        ["az", "account", "show"], capture_output=True, text=True
    )
    if login_check.returncode != 0:
        click.echo("  Not logged in. Running 'az login'...")
        subprocess.run(["az", "login"], check=True)

    # Ask for resource group and location
    click.echo()
    resource_group = click.prompt(
        "  Resource group name",
        default=f"{app_name}-rg",
    )
    location = click.prompt(
        "  Azure region",
        default="eastus",
    )

    # Choose deployment method
    click.echo()
    click.secho("  Choose deployment method:", fg="white")
    click.echo("    1. Azure Container Apps (recommended — serverless, auto-scaling)")
    click.echo("    2. Azure App Service (traditional web app hosting)")
    method = click.prompt("  Select", type=click.Choice(["1", "2"]), default="1")

    if method == "1":
        _deploy_azure_container_apps(config, app_name, resource_group, location, port, env_keys)
    else:
        _deploy_azure_app_service(config, app_name, resource_group, location, port, env_keys)


def _deploy_azure_container_apps(
    config: str, app_name: str, resource_group: str,
    location: str, port: int, env_keys: list,
):
    """Deploy to Azure Container Apps (serverless containers)."""

    click.echo()
    click.secho("  Deploying to Azure Container Apps...", fg="white")
    click.echo()

    try:
        # 1. Create resource group
        click.echo("  [1/4] Creating resource group...")
        subprocess.run([
            "az", "group", "create",
            "--name", resource_group,
            "--location", location,
        ], check=True, capture_output=True, text=True)
        click.secho("  ✓ Resource group created", fg="green")

        # 2. Create Azure Container Registry
        acr_name = app_name.replace("-", "") + "acr"
        # ACR names: 5-50 chars, alphanumeric only
        acr_name = "".join(c for c in acr_name if c.isalnum())[:50]

        click.echo("  [2/4] Creating container registry...")
        subprocess.run([
            "az", "acr", "create",
            "--resource-group", resource_group,
            "--name", acr_name,
            "--sku", "Basic",
            "--admin-enabled", "true",
        ], check=True, capture_output=True, text=True)
        click.secho(f"  ✓ Container registry '{acr_name}' created", fg="green")

        # 3. Build and push image
        click.echo("  [3/4] Building and pushing Docker image (this may take a few minutes)...")
        subprocess.run([
            "az", "acr", "build",
            "--registry", acr_name,
            "--image", f"{app_name}:latest",
            ".",
        ], check=True)
        click.secho("  ✓ Image built and pushed", fg="green")

        # 4. Deploy to Container Apps
        click.echo("  [4/4] Creating Container App...")

        # Build env var flags
        env_flags = []
        for key in env_keys:
            value = os.environ.get(key, "")
            if value:
                env_flags.extend(["--env-vars", f"{key}={value}"])

        # Get ACR credentials
        creds = subprocess.run(
            ["az", "acr", "credential", "show", "--name", acr_name],
            capture_output=True, text=True, check=True,
        )
        import json
        acr_creds = json.loads(creds.stdout)
        acr_password = acr_creds["passwords"][0]["value"]
        acr_username = acr_creds["username"]

        deploy_cmd = [
            "az", "containerapp", "up",
            "--name", app_name,
            "--resource-group", resource_group,
            "--location", location,
            "--image", f"{acr_name}.azurecr.io/{app_name}:latest",
            "--target-port", str(port),
            "--ingress", "external",
            "--registry-server", f"{acr_name}.azurecr.io",
            "--registry-username", acr_username,
            "--registry-password", acr_password,
        ]
        deploy_cmd.extend(env_flags)

        subprocess.run(deploy_cmd, check=True)

        # Get the app URL
        result = subprocess.run(
            ["az", "containerapp", "show",
             "--name", app_name,
             "--resource-group", resource_group,
             "--query", "properties.configuration.ingress.fqdn",
             "-o", "tsv"],
            capture_output=True, text=True,
        )

        click.echo()
        if result.returncode == 0 and result.stdout.strip():
            fqdn = result.stdout.strip()
            backend_url = f"wss://{fqdn}/ws/voice"
            click.secho("  ✓ Deployed to Azure Container Apps!", fg="green", bold=True)
            click.echo()
            click.echo(f"  App URL:    https://{fqdn}")
            click.echo(f"  Playground: https://{fqdn}/playground")
            click.echo(f"  Health:     https://{fqdn}/health")
            click.echo(f"  WebSocket:  {backend_url}")
            _update_config_url(config, backend_url)
            click.echo()
            click.secho("  Next step:", fg="yellow", bold=True)
            click.echo("    agentkit build android")
        else:
            click.secho("  ✓ Deployed! Could not auto-detect URL.", fg="green")
            _azure_url_prompt(config)

    except subprocess.CalledProcessError as e:
        click.secho(f"\n  Azure deployment failed: {e}", fg="red")
        click.echo("  Check the error above and ensure you have the right permissions.")
        click.echo("  You may need to install the containerapp extension:")
        click.echo("    az extension add --name containerapp --upgrade")
        sys.exit(1)

    click.echo()


def _deploy_azure_app_service(
    config: str, app_name: str, resource_group: str,
    location: str, port: int, env_keys: list,
):
    """Deploy to Azure App Service (Web App for Containers)."""

    click.echo()
    click.secho("  Deploying to Azure App Service...", fg="white")
    click.echo()

    plan_name = f"{app_name}-plan"

    try:
        # 1. Create resource group
        click.echo("  [1/5] Creating resource group...")
        subprocess.run([
            "az", "group", "create",
            "--name", resource_group,
            "--location", location,
        ], check=True, capture_output=True, text=True)
        click.secho("  ✓ Resource group created", fg="green")

        # 2. Create ACR
        acr_name = app_name.replace("-", "") + "acr"
        acr_name = "".join(c for c in acr_name if c.isalnum())[:50]

        click.echo("  [2/5] Creating container registry...")
        subprocess.run([
            "az", "acr", "create",
            "--resource-group", resource_group,
            "--name", acr_name,
            "--sku", "Basic",
            "--admin-enabled", "true",
        ], check=True, capture_output=True, text=True)
        click.secho(f"  ✓ Container registry '{acr_name}' created", fg="green")

        # 3. Build and push
        click.echo("  [3/5] Building and pushing Docker image...")
        subprocess.run([
            "az", "acr", "build",
            "--registry", acr_name,
            "--image", f"{app_name}:latest",
            ".",
        ], check=True)
        click.secho("  ✓ Image built and pushed", fg="green")

        # 4. Create App Service Plan
        click.echo("  [4/5] Creating App Service plan...")
        subprocess.run([
            "az", "appservice", "plan", "create",
            "--name", plan_name,
            "--resource-group", resource_group,
            "--sku", "B1",
            "--is-linux",
        ], check=True, capture_output=True, text=True)
        click.secho("  ✓ App Service plan created (B1)", fg="green")

        # 5. Create Web App
        click.echo("  [5/5] Creating web app...")
        subprocess.run([
            "az", "webapp", "create",
            "--resource-group", resource_group,
            "--plan", plan_name,
            "--name", app_name,
            "--deployment-container-image-name",
            f"{acr_name}.azurecr.io/{app_name}:latest",
        ], check=True, capture_output=True, text=True)

        # Set port
        subprocess.run([
            "az", "webapp", "config", "appsettings", "set",
            "--resource-group", resource_group,
            "--name", app_name,
            "--settings", f"WEBSITES_PORT={port}",
        ], check=True, capture_output=True, text=True)

        # Set env vars
        env_settings = []
        for key in env_keys:
            value = os.environ.get(key, "")
            if value:
                env_settings.append(f"{key}={value}")

        if env_settings:
            subprocess.run([
                "az", "webapp", "config", "appsettings", "set",
                "--resource-group", resource_group,
                "--name", app_name,
                "--settings", *env_settings,
            ], check=True, capture_output=True, text=True)

        fqdn = f"{app_name}.azurewebsites.net"
        backend_url = f"wss://{fqdn}/ws/voice"

        click.echo()
        click.secho("  ✓ Deployed to Azure App Service!", fg="green", bold=True)
        click.echo()
        click.echo(f"  App URL:    https://{fqdn}")
        click.echo(f"  Playground: https://{fqdn}/playground")
        click.echo(f"  Health:     https://{fqdn}/health")
        click.echo(f"  WebSocket:  {backend_url}")

        _update_config_url(config, backend_url)
        click.echo()
        click.secho("  Next step:", fg="yellow", bold=True)
        click.echo("    agentkit build android")

    except subprocess.CalledProcessError as e:
        click.secho(f"\n  Azure deployment failed: {e}", fg="red")
        click.echo("  Check the error above and ensure you have the right permissions.")
        sys.exit(1)

    click.echo()


def _azure_url_prompt(config: str):
    """Prompt user for Azure deployment URL."""
    click.echo()
    deployed_url = click.prompt(
        "  Enter your Azure app URL (e.g. my-agent.azurewebsites.net)",
        default="",
        show_default=False,
    )
    if deployed_url.strip():
        domain = deployed_url.strip().replace("https://", "").replace("http://", "").rstrip("/")
        backend_url = f"wss://{domain}/ws/voice"
        _update_config_url(config, backend_url)
        click.echo()
        click.secho("  Next step:", fg="yellow", bold=True)
        click.echo("    agentkit build android")
    else:
        click.echo("  Set it later: agentkit deploy --platform azure --url wss://your-app.azurewebsites.net/ws/voice")


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _extract_env_keys(cfg: dict) -> list:
    """Extract environment variable names from ${VAR} references in config."""
    import re
    keys = set()

    def _walk(obj):
        if isinstance(obj, dict):
            for v in obj.values():
                _walk(v)
        elif isinstance(obj, list):
            for v in obj:
                _walk(v)
        elif isinstance(obj, str):
            keys.update(re.findall(r'\$\{(\w+)\}', obj))

    _walk(cfg)
    return sorted(keys)