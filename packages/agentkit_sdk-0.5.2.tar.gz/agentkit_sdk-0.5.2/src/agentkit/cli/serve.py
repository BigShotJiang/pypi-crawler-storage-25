import os
import re
import sys
from pathlib import Path

import click
import yaml
from dotenv import load_dotenv


def _resolve_env_vars(config: dict) -> dict:
    """Recursively resolve ${VAR} references in config values from environment."""
    if isinstance(config, dict):
        return {k: _resolve_env_vars(v) for k, v in config.items()}
    if isinstance(config, list):
        return [_resolve_env_vars(v) for v in config]
    if isinstance(config, str):
        def replacer(match):
            var_name = match.group(1)
            value = os.environ.get(var_name, "")
            if not value:
                click.secho(f"  Warning: ${{{var_name}}} not set in environment", fg="yellow")
            return value
        return re.sub(r'\$\{(\w+)\}', replacer, config)
    return config


def _validate_config(config: dict) -> list[str]:
    """Validate config and return list of errors."""
    errors = []

    if not config.get("agent", {}).get("persona"):
        errors.append("agent.persona is required")

    llm = config.get("llm", {})
    if not llm.get("api_key") or llm.get("api_key", "").startswith("${"):
        errors.append(f"llm.api_key is not set — add {llm.get('api_key', 'your LLM key')} to .env")

    voice = config.get("voice", {})
    if voice.get("enabled", True):
        stt_key = voice.get("stt", {}).get("api_key", "")
        if not stt_key or stt_key.startswith("${"):
            errors.append(f"voice.stt.api_key is not set — add it to .env")
        tts_key = voice.get("tts", {}).get("api_key", "")
        if not tts_key or tts_key.startswith("${"):
            errors.append(f"voice.tts.api_key is not set — add it to .env")

    return errors


@click.command()
@click.option("--config", default="agent.config.yaml", help="Config file path")
@click.option("--port", default=None, type=int, help="Server port (overrides config)")
@click.option("--reload", is_flag=True, help="Enable auto-reload for development")
@click.option("--validate-only", is_flag=True, help="Validate config without starting server")
def serve(config: str, port: int, reload: bool, validate_only: bool):
    """Start the AgentKit server.

    Loads agent.config.yaml + .env, validates configuration,
    then starts the FastAPI server with WebSocket and playground.
    """

    if not Path(config).exists():
        click.secho(f"Error: Config file '{config}' not found.", fg="red")
        click.echo("Run 'agentkit init <name>' first to create a project.")
        sys.exit(1)

    # Load .env first so config resolution can use env vars
    env_path = Path(".env")
    if env_path.exists():
        load_dotenv(str(env_path))
    else:
        click.secho("Warning: No .env file found. API keys may be missing.", fg="yellow")

    # Load and resolve config
    with open(config) as f:
        raw_config = yaml.safe_load(f)

    resolved_config = _resolve_env_vars(raw_config)

    # Validate
    errors = _validate_config(resolved_config)
    if errors:
        click.secho("\nConfiguration errors:", fg="red", bold=True)
        for err in errors:
            click.echo(f"  - {err}")
        if validate_only:
            sys.exit(1)
        click.echo()
        if not click.confirm("Start server anyway?", default=False):
            sys.exit(1)
    elif validate_only:
        click.secho("Configuration is valid!", fg="green")
        return

    # Resolve port from flag > config > default
    server_port = port or resolved_config.get("deployment", {}).get("port", 8000)

    # Store resolved config path for the server to pick up
    os.environ["AGENTKIT_CONFIG_PATH"] = str(Path(config).resolve())

    import uvicorn

    click.echo()
    click.secho("  AgentKit Server", fg="cyan", bold=True)
    click.echo(f"  Config:     {config}")
    click.echo(f"  Port:       {server_port}")
    click.echo(f"  Playground: http://localhost:{server_port}/playground")
    click.echo(f"  WebSocket:  ws://localhost:{server_port}/ws/voice")
    click.echo(f"  Health:     http://localhost:{server_port}/health")
    click.echo()

    uvicorn.run(
        "agentkit.server.app:app",
        host="0.0.0.0",
        port=server_port,
        reload=reload,
    )