import click

from agentkit.cli.init import init
from agentkit.cli.serve import serve
from agentkit.cli.build import build
from agentkit.cli.deploy import deploy


@click.group()
@click.version_option(package_name="agentkit-sdk")
def cli():
    """AgentKit - Build personalized voice AI assistants

    \b
    Quick start:
      agentkit init my-agent
      cd my-agent
      agentkit serve
    """
    pass


cli.add_command(init)
cli.add_command(serve)
cli.add_command(build)
cli.add_command(deploy)


if __name__ == "__main__":
    cli()