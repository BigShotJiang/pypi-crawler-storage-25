from typing import AsyncIterator

import httpx

from .base import BaseTTS


class ElevenLabsTTS(BaseTTS):
    def __init__(self, api_key: str, voice_id: str = "pNInz6obpgDQGcFmaJgB"):
        self.api_key = api_key
        self.voice_id = voice_id
        self.base_url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"

    async def synthesize_stream(self, text: str) -> AsyncIterator[bytes]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                self.base_url,
                json={
                    "text": text,
                    "model_id": "eleven_multilingual_v2",
                    "voice_settings": {
                        "stability": 0.5,
                        "similarity_boost": 0.8,
                    },
                },
                headers={
                    "Accept": "audio/mpeg",
                    "xi-api-key": self.api_key,
                },
            )
            if response.status_code == 200:
                yield response.content

    async def synthesize(self, text: str) -> bytes:
        async for chunk in self.synthesize_stream(text):
            return chunk
        return b""

    async def close(self):
        pass