from typing import AsyncIterator

import httpx

from .base import BaseTTS


class DeepgramTTS(BaseTTS):
    """Deepgram Aura text-to-speech provider."""

    def __init__(self, api_key: str, model: str = "aura-asteria-en", encoding: str = "linear16", sample_rate: int = 16000):
        self.api_key = api_key
        self.model = model
        self.encoding = encoding
        self.sample_rate = sample_rate
        self.base_url = "https://api.deepgram.com/v1/speak"

    async def synthesize_stream(self, text: str) -> AsyncIterator[bytes]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                self.base_url,
                json={"text": text},
                headers={
                    "Authorization": f"Token {self.api_key}",
                    "Content-Type": "application/json",
                },
                params={
                    "model": self.model,
                    "encoding": self.encoding,
                    "sample_rate": self.sample_rate,
                },
            )
            if response.status_code == 200:
                yield response.content

    async def synthesize(self, text: str) -> bytes:
        async for chunk in self.synthesize_stream(text):
            return chunk
        return b""

    async def close(self):
        pass
