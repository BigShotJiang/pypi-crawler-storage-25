from abc import ABC, abstractmethod
from typing import AsyncIterator


class BaseTTS(ABC):
    @abstractmethod
    async def synthesize_stream(
        self, text: str
    ) -> AsyncIterator[bytes]:
        """Synthesize text to audio stream incrementally."""
        pass

    @abstractmethod
    async def synthesize(self, text: str) -> bytes:
        """Synthesize complete text to audio."""
        pass

    @abstractmethod
    async def close(self):
        """Clean up resources."""
        pass