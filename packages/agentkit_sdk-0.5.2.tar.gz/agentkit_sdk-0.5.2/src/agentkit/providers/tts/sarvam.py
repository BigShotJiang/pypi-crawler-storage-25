from typing import AsyncIterator

import httpx

from .base import BaseTTS


class SarvamTTS(BaseTTS):
    def __init__(self, api_key: str, voice: str = "meera", language_code: str = "hi-IN"):
        self.api_key = api_key
        self.voice = voice
        self.language_code = language_code
        self.base_url = "https://api.sarvam.ai"

    async def synthesize_stream(self, text: str) -> AsyncIterator[bytes]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/text-to-speech",
                json={
                    "inputs": [text],
                    "target_language_code": self.language_code,
                    "speaker": self.voice,
                    "speech_rate": 1.0,
                    "pitch": 0,
                    "volume": 1.0,
                },
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
            if response.status_code == 200:
                data = response.json()
                audio_base64 = data.get("audios", [""])[0]
                if audio_base64:
                    import base64
                    audio_bytes = base64.b64decode(audio_base64)
                    yield audio_bytes

    async def synthesize(self, text: str) -> bytes:
        async for chunk in self.synthesize_stream(text):
            return chunk
        return b""

    async def close(self):
        pass