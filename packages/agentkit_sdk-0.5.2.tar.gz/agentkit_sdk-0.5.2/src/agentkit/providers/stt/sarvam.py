import asyncio
from typing import AsyncIterator

import httpx

from .base import BaseSTT


class SarvamSTT(BaseSTT):
    def __init__(self, api_key: str, language_code: str = "hi-IN"):
        self.api_key = api_key
        self.language_code = language_code
        self.base_url = "https://api.sarvam.ai"

    async def transcribe_stream(
        self, audio: AsyncIterator[bytes]
    ) -> AsyncIterator[str]:
        buffer = bytearray()
        async for chunk in audio:
            buffer.extend(chunk)
            if len(buffer) > 16000:
                result = await self._transcribe_bytes(bytes(buffer))
                if result:
                    yield result
                buffer.clear()

    async def transcribe(self, audio_bytes: bytes) -> str:
        result = await self._transcribe_bytes(audio_bytes)
        return result or ""

    async def _transcribe_bytes(self, audio_bytes: bytes) -> str:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/speech-to-text",
                files={"file": ("audio.wav", audio_bytes, "audio/wav")},
                data={"language_code": self.language_code},
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("transcript", "")
            return ""

    async def close(self):
        pass