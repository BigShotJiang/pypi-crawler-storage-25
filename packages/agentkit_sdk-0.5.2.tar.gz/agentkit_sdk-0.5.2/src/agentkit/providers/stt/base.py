from abc import ABC, abstractmethod
from typing import AsyncIterator


class BaseSTT(ABC):
    @abstractmethod
    async def transcribe_stream(
        self, audio: AsyncIterator[bytes]
    ) -> AsyncIterator[str]:
        """Transcribe audio stream to text incrementally."""
        pass

    @abstractmethod
    async def transcribe(self, audio_bytes: bytes) -> str:
        """Transcribe complete audio to text."""
        pass

    @abstractmethod
    async def close(self):
        """Clean up resources."""
        pass