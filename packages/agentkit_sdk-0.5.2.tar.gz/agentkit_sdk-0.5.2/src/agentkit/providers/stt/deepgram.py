from typing import AsyncIterator

import httpx

from .base import BaseSTT


class DeepgramSTT(BaseSTT):
    def __init__(self, api_key: str, language: str = "hi"):
        self.api_key = api_key
        self.language = language
        self.base_url = "https://api.deepgram.com/v1"

    async def transcribe_stream(
        self, audio: AsyncIterator[bytes]
    ) -> AsyncIterator[str]:
        buffer = bytearray()
        async for chunk in audio:
            buffer.extend(chunk)
            if len(buffer) > 16000:
                result = await self._transcribe_bytes(bytes(buffer))
                if result:
                    yield result
                buffer.clear()

    async def transcribe(self, audio_bytes: bytes) -> str:
        result = await self._transcribe_bytes(audio_bytes)
        return result or ""

    async def _transcribe_bytes(self, audio_bytes: bytes) -> str:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/listen",
                content=audio_bytes,
                headers={
                    "Authorization": f"Token {self.api_key}",
                    "Content-Type": "audio/wav",
                },
                params={
                    "language": self.language,
                    "encoding": "linear16",
                    "sample_rate": 16000,
                },
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("results", {}).get("channels", [{}])[0].get(
                    "alternatives", [{}]
                )[0].get("transcript", "")
            return ""

    async def close(self):
        pass