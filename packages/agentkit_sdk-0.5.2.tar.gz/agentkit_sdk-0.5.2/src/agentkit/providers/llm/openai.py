import asyncio
from typing import AsyncIterator

from openai import AsyncOpenAI

from .base import BaseLLM, Message


class OpenAILLM(BaseLLM):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini", temperature: float = 0.7):
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature

    async def chat_stream(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> AsyncIterator[str]:
        full_system = f"{system}\n\nMemory Context:\n{memory_context}" if memory_context else system
        
        api_messages = [{"role": "system", "content": full_system}] + [
            {"role": m.role, "content": m.content} for m in messages
        ]
        
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            temperature=self.temperature,
            stream=True,
        )
        
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    async def chat(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> str:
        full_system = f"{system}\n\nMemory Context:\n{memory_context}" if memory_context else system
        
        api_messages = [{"role": "system", "content": full_system}] + [
            {"role": m.role, "content": m.content} for m in messages
        ]
        
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            temperature=self.temperature,
        )
        
        return response.choices[0].message.content

    async def close(self):
        await self.client.close()