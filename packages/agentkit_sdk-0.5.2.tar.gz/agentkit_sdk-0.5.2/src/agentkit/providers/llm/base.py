from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator


@dataclass
class Message:
    role: str
    content: str


class BaseLLM(ABC):
    @abstractmethod
    async def chat_stream(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> AsyncIterator[str]:
        """Stream chat response from LLM."""
        pass

    @abstractmethod
    async def chat(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> str:
        """Non-streaming chat response."""
        pass

    @abstractmethod
    async def close(self):
        """Clean up resources."""
        pass