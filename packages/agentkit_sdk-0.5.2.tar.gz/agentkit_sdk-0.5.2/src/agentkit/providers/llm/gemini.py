from typing import AsyncIterator

from google import genai
from google.genai import types

from .base import BaseLLM, Message


class GeminiLLM(BaseLLM):
    def __init__(self, api_key: str, model: str = "gemini-2.0-flash", temperature: float = 0.7):
        self.client = genai.Client(api_key=api_key)
        self.model_name = model
        self.temperature = temperature

    def _build_contents(self, messages: list[Message]) -> list[types.Content]:
        contents = []
        for m in messages:
            role = "model" if m.role == "assistant" else "user"
            contents.append(types.Content(
                role=role,
                parts=[types.Part(text=m.content)],
            ))
        return contents

    def _build_config(self, system: str, memory_context: str = "") -> types.GenerateContentConfig:
        full_system = f"{system}\n\nMemory Context:\n{memory_context}" if memory_context else system
        return types.GenerateContentConfig(
            system_instruction=full_system,
            temperature=self.temperature,
        )

    async def chat_stream(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> AsyncIterator[str]:
        contents = self._build_contents(messages)
        config = self._build_config(system, memory_context)

        async for chunk in self.client.aio.models.generate_content_stream(
            model=self.model_name,
            contents=contents,
            config=config,
        ):
            if chunk.text:
                yield chunk.text

    async def chat(
        self,
        messages: list[Message],
        system: str,
        memory_context: str = ""
    ) -> str:
        contents = self._build_contents(messages)
        config = self._build_config(system, memory_context)

        response = await self.client.aio.models.generate_content(
            model=self.model_name,
            contents=contents,
            config=config,
        )
        return response.text

    async def close(self):
        pass