"""
Provider registry — resolves provider names to classes.

Built-in providers are registered automatically. Users can also
register custom providers or use a dotted import path in config:

    # agent.config.yaml — using built-in
    llm:
      provider: gemini

    # agent.config.yaml — using custom class
    llm:
      provider: my_package.llm.MyCustomLLM

    # Or register at runtime before starting the server
    from agentkit.providers import registry
    registry.register("llm", "my-llm", MyCustomLLM)
"""

import importlib
from typing import Any


class ProviderRegistry:
    """Central registry for STT, LLM, TTS, and memory providers."""

    def __init__(self):
        self._providers: dict[str, dict[str, type]] = {
            "stt": {},
            "llm": {},
            "tts": {},
            "memory": {},
        }

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, category: str, name: str, cls: type) -> None:
        """Register a provider class under a category and name.

        Args:
            category: One of "stt", "llm", "tts", "memory".
            name: Short name used in agent.config.yaml (e.g. "gemini").
            cls: The provider class. Must implement the appropriate base.
        """
        if category not in self._providers:
            raise ValueError(
                f"Unknown provider category '{category}'. "
                f"Must be one of: {list(self._providers.keys())}"
            )
        self._providers[category][name] = cls

    # ------------------------------------------------------------------
    # Resolution
    # ------------------------------------------------------------------

    def get(self, category: str, name: str) -> type:
        """Resolve a provider name to its class.

        Resolution order:
          1. Check the registry for an exact match.
          2. If the name contains a dot, treat it as a dotted import path
             (e.g. "my_package.stt.WhisperSTT") and import dynamically.
          3. Raise ValueError if nothing matches.
        """
        # 1. Registry lookup
        if name in self._providers.get(category, {}):
            return self._providers[category][name]

        # 2. Dotted-path dynamic import
        if "." in name:
            return self._import_class(name)

        raise ValueError(
            f"Unknown {category} provider '{name}'. "
            f"Available: {list(self._providers.get(category, {}).keys())}. "
            f"Or use a dotted import path like 'my_package.module.ClassName'."
        )

    def list_providers(self, category: str) -> dict[str, type]:
        """Return all registered providers for a category."""
        return dict(self._providers.get(category, {}))

    def list_all(self) -> dict[str, dict[str, type]]:
        """Return the full registry."""
        return {cat: dict(providers) for cat, providers in self._providers.items()}

    # ------------------------------------------------------------------
    # Instantiation helpers
    # ------------------------------------------------------------------

    def create_stt(self, config: dict) -> Any:
        """Create an STT provider from a config dict.

        Expected keys: provider, api_key, plus any provider-specific options.
        """
        name = config.get("provider", "sarvam")
        cls = self.get("stt", name)
        return self._instantiate(cls, config, exclude={"provider"})

    def create_llm(self, config: dict) -> Any:
        """Create an LLM provider from a config dict.

        Expected keys: provider, api_key, model, temperature, etc.
        """
        name = config.get("provider", "groq")
        cls = self.get("llm", name)
        return self._instantiate(cls, config, exclude={"provider"})

    def create_tts(self, config: dict) -> Any:
        """Create a TTS provider from a config dict.

        Expected keys: provider, api_key, voice, etc.
        """
        name = config.get("provider", "sarvam")
        cls = self.get("tts", name)
        return self._instantiate(cls, config, exclude={"provider"})

    def create_memory(self, config: dict) -> Any:
        """Create a memory provider from a config dict."""
        name = config.get("type", "markdown")
        cls = self.get("memory", name)
        return self._instantiate(cls, config, exclude={"type"})

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _import_class(dotted_path: str) -> type:
        """Import a class from a dotted path like 'my_package.module.ClassName'."""
        module_path, _, class_name = dotted_path.rpartition(".")
        if not module_path:
            raise ValueError(
                f"Invalid provider path '{dotted_path}'. "
                f"Use format: 'my_package.module.ClassName'"
            )
        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise ValueError(
                f"Could not import module '{module_path}': {e}. "
                f"Make sure the package is installed."
            ) from e

        if not hasattr(module, class_name):
            raise ValueError(
                f"Module '{module_path}' has no class '{class_name}'. "
                f"Available: {[n for n in dir(module) if not n.startswith('_')]}"
            )
        return getattr(module, class_name)

    @staticmethod
    def _instantiate(cls: type, config: dict, exclude: set[str] | None = None) -> Any:
        """Instantiate a provider class, passing config keys as kwargs.

        Only passes kwargs that the constructor actually accepts,
        so extra config keys are silently ignored.
        """
        import inspect

        exclude = exclude or set()
        sig = inspect.signature(cls.__init__)
        valid_params = {
            name for name, p in sig.parameters.items()
            if name != "self" and p.kind in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.KEYWORD_ONLY,
            )
        }
        has_kwargs = any(
            p.kind == inspect.Parameter.VAR_KEYWORD
            for p in sig.parameters.values()
        )

        kwargs = {}
        for key, value in config.items():
            if key in exclude:
                continue
            if has_kwargs or key in valid_params:
                kwargs[key] = value

        return cls(**kwargs)


# ------------------------------------------------------------------
# Global registry singleton
# ------------------------------------------------------------------
registry = ProviderRegistry()


def _register_builtins():
    """Register all built-in providers."""
    from agentkit.providers.stt.sarvam import SarvamSTT
    from agentkit.providers.stt.deepgram import DeepgramSTT
    from agentkit.providers.llm.gemini import GeminiLLM
    from agentkit.providers.llm.groq import GroqLLM
    from agentkit.providers.llm.openai import OpenAILLM
    from agentkit.providers.tts.sarvam import SarvamTTS
    from agentkit.providers.tts.deepgram import DeepgramTTS
    from agentkit.providers.tts.elevenlabs import ElevenLabsTTS
    from agentkit.memory.markdown import MarkdownMemory
    from agentkit.memory.vector import VectorMemory

    registry.register("stt", "sarvam", SarvamSTT)
    registry.register("stt", "deepgram", DeepgramSTT)

    registry.register("llm", "gemini", GeminiLLM)
    registry.register("llm", "groq", GroqLLM)
    registry.register("llm", "openai", OpenAILLM)

    registry.register("tts", "sarvam", SarvamTTS)
    registry.register("tts", "deepgram", DeepgramTTS)
    registry.register("tts", "elevenlabs", ElevenLabsTTS)

    registry.register("memory", "markdown", MarkdownMemory)
    registry.register("memory", "vector", VectorMemory)


_register_builtins()
