"""
High-level Agent class — the primary programmatic interface to AgentKit.

Usage:
    from agentkit import Agent

    # Option 1: Pure code — no YAML needed
    agent = Agent(
        persona="You are a helpful assistant",
        llm_provider="gemini",
        llm_api_key="your-key",
        llm_model="gemini-2.0-flash",
    )
    response = await agent.chat("Hello!")
    print(response.text)

    # Option 2: Load from YAML config
    agent = Agent.from_config("agent.config.yaml")
    agent.serve(port=8000)
"""

import asyncio
import base64
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator, Callable
from uuid import uuid4

import yaml

from agentkit.core.context import ContextAssembler
from agentkit.core.pipeline import PipelineConfig, VoicePipeline
from agentkit.core.tools import ToolRegistry, ToolDef
from agentkit.learning.correction import CorrectionDetector, CorrectionStore
from agentkit.memory.base import BaseMemory, ConversationTurn
from agentkit.providers import registry
from agentkit.providers.llm.base import Message


@dataclass
class AgentResponse:
    """Response from an Agent chat or process_audio call."""

    text: str
    """The text response from the agent."""

    audio: bytes | None = None
    """Raw audio bytes (WAV) of the spoken response, or None if TTS is disabled."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional metadata (e.g. tool calls made, latency info)."""


class Agent:
    """High-level interface for building voice AI assistants with AgentKit.

    Create an agent either programmatically or from a YAML config file.
    Supports text chat, audio processing, tool registration, and running
    the built-in server — all through a clean Python API.

    Examples:
        Programmatic creation::

            from agentkit import Agent

            agent = Agent(
                persona="You are a helpful assistant",
                llm_provider="gemini",
                llm_api_key=os.getenv("GEMINI_API_KEY"),
                llm_model="gemini-2.0-flash",
            )
            response = await agent.chat("Hello!")

        From YAML config::

            agent = Agent.from_config("agent.config.yaml")
            agent.serve(port=8000)
    """

    def __init__(
        self,
        *,
        # Agent identity
        persona: str = "You are a helpful personal assistant.",
        name: str = "Assistant",
        language: str = "english",
        # LLM (required for chat)
        llm_provider: str = "gemini",
        llm_api_key: str | None = None,
        llm_model: str | None = None,
        llm_temperature: float = 0.7,
        llm_kwargs: dict[str, Any] | None = None,
        # STT (optional — only needed for audio input)
        stt_provider: str | None = None,
        stt_api_key: str | None = None,
        stt_kwargs: dict[str, Any] | None = None,
        # TTS (optional — only needed for audio output)
        tts_provider: str | None = None,
        tts_api_key: str | None = None,
        tts_voice: str | None = None,
        tts_kwargs: dict[str, Any] | None = None,
        # Memory
        memory_type: str = "markdown",
        memory_kwargs: dict[str, Any] | None = None,
        # Deployment
        port: int = 8000,
        api_key: str | None = None,
    ):
        """Create an Agent with programmatic configuration.

        Only ``llm_provider`` and ``llm_api_key`` are truly required for
        basic text chat.  STT/TTS providers are optional and only needed
        when processing audio or serving the full voice pipeline.

        Args:
            persona: System prompt / personality for the agent.
            name: Display name for the agent.
            language: Language preference (english, hindi, hinglish).
            llm_provider: LLM provider name (gemini, openai, groq) or dotted path.
            llm_api_key: API key for the LLM provider.
            llm_model: Model name (e.g. gemini-2.0-flash, gpt-4o-mini).
            llm_temperature: Sampling temperature for the LLM.
            llm_kwargs: Additional kwargs passed to the LLM provider constructor.
            stt_provider: STT provider name (sarvam, deepgram) or dotted path.
            stt_api_key: API key for the STT provider.
            stt_kwargs: Additional kwargs for the STT provider.
            tts_provider: TTS provider name (sarvam, elevenlabs, deepgram) or dotted path.
            tts_api_key: API key for the TTS provider.
            tts_voice: Voice ID or name for the TTS provider.
            tts_kwargs: Additional kwargs for the TTS provider.
            memory_type: Memory backend (markdown, vector).
            memory_kwargs: Additional kwargs for the memory provider.
            port: Default port for ``agent.serve()``.
            api_key: Optional API key to protect the server endpoints.
        """
        self._name = name
        self._persona = persona
        self._language = language
        self._port = port
        self._server_api_key = api_key

        # Store raw config for serve() to use
        self._raw_config: dict | None = None

        # Build provider configs
        self._llm_config = {"provider": llm_provider, "temperature": llm_temperature}
        if llm_api_key:
            self._llm_config["api_key"] = llm_api_key
        if llm_model:
            self._llm_config["model"] = llm_model
        if llm_kwargs:
            self._llm_config.update(llm_kwargs)

        self._stt_config: dict | None = None
        if stt_provider:
            self._stt_config = {"provider": stt_provider}
            if stt_api_key:
                self._stt_config["api_key"] = stt_api_key
            if stt_kwargs:
                self._stt_config.update(stt_kwargs)

        self._tts_config: dict | None = None
        if tts_provider:
            self._tts_config = {"provider": tts_provider}
            if tts_api_key:
                self._tts_config["api_key"] = tts_api_key
            if tts_voice:
                self._tts_config["voice"] = tts_voice
            if tts_kwargs:
                self._tts_config.update(tts_kwargs)

        self._memory_config = {"type": memory_type}
        if memory_kwargs:
            self._memory_config.update(memory_kwargs)

        # Tool registry
        self._tools = ToolRegistry()

        # Lazy-initialized internals
        self._pipeline: VoicePipeline | None = None
        self._llm = None
        self._stt = None
        self._tts = None
        self._memory: BaseMemory | None = None
        self._context_assembler: ContextAssembler | None = None
        self._correction_detector: CorrectionDetector | None = None
        self._correction_store: CorrectionStore | None = None
        self._initialized = False

    # ------------------------------------------------------------------
    # Factory — load from YAML config
    # ------------------------------------------------------------------

    @classmethod
    def from_config(
        cls,
        config_path: str = "agent.config.yaml",
        env_path: str | None = ".env",
    ) -> "Agent":
        """Create an Agent from a YAML config file.

        This is the bridge between the CLI-driven workflow (``agentkit init``
        + ``agentkit serve``) and the programmatic API.

        Args:
            config_path: Path to ``agent.config.yaml``.
            env_path: Path to ``.env`` file. Set to None to skip loading.

        Returns:
            A configured Agent instance.

        Example::

            agent = Agent.from_config("agent.config.yaml")
            response = await agent.chat("Hello!")
        """
        # Load .env if present
        if env_path and Path(env_path).exists():
            from dotenv import load_dotenv
            load_dotenv(env_path)

        with open(config_path) as f:
            raw = yaml.safe_load(f)

        config = cls._resolve_env_vars(raw)

        agent_cfg = config.get("agent", {})
        voice_cfg = config.get("voice", {})
        llm_cfg = config.get("llm", {})
        memory_cfg = config.get("memory", {})
        deploy_cfg = config.get("deployment", {})

        instance = cls(
            persona=agent_cfg.get("persona", "You are a helpful assistant."),
            name=agent_cfg.get("name", "Assistant"),
            language=agent_cfg.get("language", "english"),
            llm_provider=llm_cfg.get("provider", "gemini"),
            llm_api_key=llm_cfg.get("api_key"),
            llm_model=llm_cfg.get("model"),
            llm_temperature=llm_cfg.get("temperature", 0.7),
            llm_kwargs={
                k: v for k, v in llm_cfg.items()
                if k not in {"provider", "api_key", "model", "temperature"}
            } or None,
            stt_provider=voice_cfg.get("stt", {}).get("provider"),
            stt_api_key=voice_cfg.get("stt", {}).get("api_key"),
            stt_kwargs={
                k: v for k, v in voice_cfg.get("stt", {}).items()
                if k not in {"provider", "api_key"}
            } or None,
            tts_provider=voice_cfg.get("tts", {}).get("provider"),
            tts_api_key=voice_cfg.get("tts", {}).get("api_key"),
            tts_voice=voice_cfg.get("tts", {}).get("voice"),
            tts_kwargs={
                k: v for k, v in voice_cfg.get("tts", {}).items()
                if k not in {"provider", "api_key", "voice"}
            } or None,
            memory_type=memory_cfg.get("type", "markdown"),
            memory_kwargs={
                k: v for k, v in memory_cfg.items() if k != "type"
            } or None,
            port=deploy_cfg.get("port", 8000),
            api_key=deploy_cfg.get("api_key") or None,
        )
        instance._raw_config = config
        return instance

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    async def _ensure_initialized(self, require_voice: bool = False):
        """Lazily initialize providers on first use."""
        if self._initialized:
            return

        # LLM — always required
        self._llm = registry.create_llm(self._llm_config)

        # STT + TTS — optional
        if self._stt_config:
            self._stt = registry.create_stt(self._stt_config)
        if self._tts_config:
            self._tts = registry.create_tts(self._tts_config)

        if require_voice:
            if not self._stt:
                raise ValueError(
                    "STT provider is required for audio processing. "
                    "Pass stt_provider='sarvam' (or similar) when creating the Agent."
                )
            if not self._tts:
                raise ValueError(
                    "TTS provider is required for audio processing. "
                    "Pass tts_provider='sarvam' (or similar) when creating the Agent."
                )

        # Memory
        self._memory = registry.create_memory(self._memory_config)
        self._context_assembler = ContextAssembler(self._memory)
        self._correction_detector = CorrectionDetector()
        self._correction_store = CorrectionStore(self._memory)

        # Build pipeline if we have all voice providers
        if self._stt and self._tts:
            pipeline_config = PipelineConfig(
                persona=self._persona,
                language=self._language,
                tools=self._tools if self._tools.list_tools() else None,
            )
            self._pipeline = VoicePipeline(
                self._stt, self._llm, self._tts, pipeline_config
            )

        self._initialized = True

    # ------------------------------------------------------------------
    # Tool registration
    # ------------------------------------------------------------------

    def tool(self, func: Callable = None, *, name: str = None, description: str = None):
        """Register a function as a tool the agent can call.

        Can be used as a decorator::

            @agent.tool
            def get_weather(city: str) -> str:
                \"\"\"Get the current weather for a city.\"\"\"
                return "25°C and sunny"

            @agent.tool(name="calc", description="Evaluate math")
            def calculate(expression: str) -> str:
                return str(eval(expression))

        Args:
            func: The function to register (when used without arguments).
            name: Override the tool name (defaults to function name).
            description: Override the description (defaults to docstring).
        """
        return self._tools.register(func, name=name, description=description)

    def register_tool(self, tool_def: ToolDef) -> None:
        """Register an existing ToolDef (e.g. from a ToolRegistry).

        Args:
            tool_def: A ToolDef object to register.
        """
        self._tools._tools[tool_def.name] = tool_def

    # ------------------------------------------------------------------
    # Text chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        message: str,
        *,
        user_id: str = "default",
        include_audio: bool = False,
    ) -> AgentResponse:
        """Send a text message and get a response.

        This is the simplest way to interact with the agent. Only an LLM
        provider is required.  If ``include_audio=True`` and a TTS provider
        is configured, the response will also contain synthesized audio.

        Args:
            message: The user's message.
            user_id: User identifier for memory/personalization.
            include_audio: If True and TTS is configured, synthesize audio.

        Returns:
            An ``AgentResponse`` with ``.text`` and optionally ``.audio``.

        Example::

            response = await agent.chat("What is Python?")
            print(response.text)
        """
        await self._ensure_initialized()

        # Build memory context
        mem_ctx = await self._context_assembler.assemble(message, user_id)
        context_str = mem_ctx.assemble()

        # If we have a full pipeline, use it (gets tool support + TTS)
        if self._pipeline and include_audio:
            audio_chunks = []
            text_parts = []

            async def on_delta(token):
                text_parts.append(token)

            async for audio_chunk in self._pipeline.process_text(
                message, context_str, on_text_delta=on_delta
            ):
                audio_chunks.append(audio_chunk)

            text_response = self._pipeline.get_last_response()
            audio_data = b"".join(audio_chunks) if audio_chunks else None

            # Store turn
            await self._store_turn(user_id, message, text_response)

            return AgentResponse(text=text_response, audio=audio_data)

        # Text-only path — use LLM directly
        messages = [Message(role="user", content=message)]

        system = self._persona
        if self._tools.list_tools():
            system += self._tools.to_system_prompt()

        response_text = await self._llm.chat(
            messages=messages,
            system=system,
            memory_context=context_str,
        )

        # Store turn
        await self._store_turn(user_id, message, response_text)

        # Optionally synthesize audio
        audio_data = None
        if include_audio and self._tts:
            audio_data = await self._tts.synthesize(response_text)

        return AgentResponse(text=response_text, audio=audio_data)

    async def chat_stream(
        self,
        message: str,
        *,
        user_id: str = "default",
    ) -> AsyncIterator[str]:
        """Send a text message and stream the response token-by-token.

        Args:
            message: The user's message.
            user_id: User identifier for memory/personalization.

        Yields:
            Text tokens as they are generated by the LLM.

        Example::

            async for token in agent.chat_stream("Tell me a story"):
                print(token, end="", flush=True)
        """
        await self._ensure_initialized()

        mem_ctx = await self._context_assembler.assemble(message, user_id)
        context_str = mem_ctx.assemble()

        messages = [Message(role="user", content=message)]

        system = self._persona
        if self._tools.list_tools():
            system += self._tools.to_system_prompt()

        full_response = ""
        async for token in self._llm.chat_stream(
            messages=messages,
            system=system,
            memory_context=context_str,
        ):
            full_response += token
            yield token

        # Store turn
        await self._store_turn(user_id, message, full_response)

    # ------------------------------------------------------------------
    # Audio processing
    # ------------------------------------------------------------------

    async def process_audio(
        self,
        audio_bytes: bytes,
        *,
        user_id: str = "default",
    ) -> AgentResponse:
        """Process audio input through the full voice pipeline.

        Requires STT and TTS providers to be configured.

        Args:
            audio_bytes: Raw audio bytes to process.
            user_id: User identifier for memory/personalization.

        Returns:
            An ``AgentResponse`` with ``.text`` and ``.audio``.

        Example::

            with open("question.wav", "rb") as f:
                audio = f.read()
            response = await agent.process_audio(audio)
            # response.text  — transcription + answer
            # response.audio — spoken answer as bytes
        """
        await self._ensure_initialized(require_voice=True)

        mem_ctx = await self._context_assembler.assemble("", user_id)
        context_str = mem_ctx.assemble()

        async def audio_stream():
            yield audio_bytes

        audio_chunks = []
        async for chunk in self._pipeline.process_voice_stream(
            audio_stream(), context_str
        ):
            audio_chunks.append(chunk)

        text_response = self._pipeline.get_last_response()
        audio_data = b"".join(audio_chunks) if audio_chunks else None

        # Store turn
        if self._pipeline.turns:
            last = self._pipeline.turns[-1]
            await self._store_turn(user_id, last.user_message, last.assistant_message)

        return AgentResponse(text=text_response, audio=audio_data)

    # ------------------------------------------------------------------
    # Server
    # ------------------------------------------------------------------

    def serve(
        self,
        *,
        port: int | None = None,
        host: str = "0.0.0.0",
        reload: bool = False,
    ) -> None:
        """Start the AgentKit FastAPI server with playground.

        This starts the same server as ``agentkit serve`` but from Python code.

        Args:
            port: Server port (defaults to the port passed to constructor).
            host: Host to bind to.
            reload: Enable auto-reload for development.

        Example::

            agent = Agent.from_config("agent.config.yaml")
            agent.serve(port=8000)
        """
        import uvicorn

        server_port = port or self._port

        # Write config to a temp location so the server module can pick it up
        if self._raw_config:
            config_path = os.environ.get("AGENTKIT_CONFIG_PATH", "agent.config.yaml")
            os.environ["AGENTKIT_CONFIG_PATH"] = str(Path(config_path).resolve())
        elif not os.environ.get("AGENTKIT_CONFIG_PATH"):
            # Generate a temporary config from the programmatic settings
            config = self._build_config_dict()
            tmp_config = Path(".agentkit.tmp.yaml")
            with open(tmp_config, "w") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            os.environ["AGENTKIT_CONFIG_PATH"] = str(tmp_config.resolve())

        print()
        print(f"  AgentKit Server — {self._name}")
        print(f"  Port:       {server_port}")
        print(f"  Playground: http://localhost:{server_port}/playground")
        print(f"  WebSocket:  ws://localhost:{server_port}/ws/voice")
        print(f"  Health:     http://localhost:{server_port}/health")
        print()

        uvicorn.run(
            "agentkit.server.app:app",
            host=host,
            port=server_port,
            reload=reload,
        )

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Release all resources (provider connections, etc).

        Always call this when you're done using the agent, or use
        the agent as an async context manager::

            async with Agent(...) as agent:
                response = await agent.chat("Hello")
        """
        if self._pipeline:
            await self._pipeline.close()
        elif self._llm:
            await self._llm.close()
            if self._stt:
                await self._stt.close()
            if self._tts:
                await self._tts.close()
        self._initialized = False

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.close()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """The agent's display name."""
        return self._name

    @property
    def persona(self) -> str:
        """The agent's system prompt / persona."""
        return self._persona

    @property
    def tools(self) -> ToolRegistry:
        """The agent's tool registry."""
        return self._tools

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _store_turn(self, user_id: str, user_msg: str, assistant_msg: str):
        """Store a conversation turn in memory."""
        if self._memory and user_msg and assistant_msg:
            turn = ConversationTurn(
                turn_id=str(uuid4()),
                user_id=user_id,
                user_message=user_msg,
                assistant_message=assistant_msg,
                timestamp=datetime.now(),
                metadata={},
            )
            try:
                await self._memory.store(turn)
            except Exception:
                pass  # Don't let memory failures break chat

    def _build_config_dict(self) -> dict:
        """Build a config dict from programmatic settings (for serve())."""
        config = {
            "agent": {
                "name": self._name,
                "persona": self._persona,
                "language": self._language,
            },
            "voice": {"enabled": bool(self._stt_config and self._tts_config)},
            "llm": dict(self._llm_config),
            "memory": dict(self._memory_config),
            "learning": {
                "enabled": True,
                "correction_detection": True,
                "implicit_feedback": True,
                "profile_extraction": True,
            },
            "deployment": {
                "type": "self-host",
                "port": self._port,
                "backend_url": "",
                "api_key": self._server_api_key or "",
            },
        }
        if self._stt_config:
            config["voice"]["stt"] = dict(self._stt_config)
        if self._tts_config:
            config["voice"]["tts"] = dict(self._tts_config)
        return config

    @staticmethod
    def _resolve_env_vars(config):
        """Recursively resolve ${VAR} references in config values."""
        if isinstance(config, dict):
            return {k: Agent._resolve_env_vars(v) for k, v in config.items()}
        if isinstance(config, list):
            return [Agent._resolve_env_vars(v) for v in config]
        if isinstance(config, str):
            return re.sub(
                r'\$\{(\w+)\}',
                lambda m: os.environ.get(m.group(1), ""),
                config,
            )
        return config
