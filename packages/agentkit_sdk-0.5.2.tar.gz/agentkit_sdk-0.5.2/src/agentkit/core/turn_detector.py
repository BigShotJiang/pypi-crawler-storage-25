import asyncio
from typing import AsyncIterator


class TurnDetector:
    def __init__(
        self,
        silence_threshold: float = 1.5,
        energy_threshold: float = 0.01,
    ):
        self.silence_threshold = silence_threshold
        self.energy_threshold = energy_threshold

    async def detect_turn_end(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000
    ) -> AsyncIterator[bytes]:
        """Detect when user has finished speaking based on silence."""
        
        buffer = bytearray()
        silence_duration = 0.0
        chunk_duration = 0.02
        bytes_per_chunk = int(sample_rate * chunk_duration * 2)
        
        async for chunk in audio_stream:
            buffer.extend(chunk)
            
            energy = self._calculate_energy(bytes(chunk[-bytes_per_chunk:]))
            
            if energy < self.energy_threshold:
                silence_duration += chunk_duration
                if silence_duration >= self.silence_threshold:
                    if buffer[:-bytes_per_chunk]:
                        yield bytes(buffer[:-bytes_per_chunk])
                    buffer.clear()
                    break
            else:
                silence_duration = 0.0
        
        if buffer:
            yield bytes(buffer)

    def _calculate_energy(self, audio_bytes: bytes) -> float:
        if not audio_bytes:
            return 0.0
        import struct
        samples = struct.unpack(f"{len(audio_bytes)//2}h", audio_bytes)
        return sum(abs(s) for s in samples) / len(samples) / 32768.0