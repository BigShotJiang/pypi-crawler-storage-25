from dataclasses import dataclass


@dataclass
class MemoryContext:
    user_profile_summary: str = ""
    semantic_episodes: str = ""
    correction_rules: str = ""
    recent_turns: str = ""

    def assemble(self) -> str:
        parts = []
        if self.user_profile_summary:
            parts.append(f"User Profile:\n{self.user_profile_summary}")
        if self.semantic_episodes:
            parts.append(f"Relevant History:\n{self.semantic_episodes}")
        if self.correction_rules:
            parts.append(f"Correction Rules:\n{self.correction_rules}")
        if self.recent_turns:
            parts.append(f"Recent Conversation:\n{self.recent_turns}")
        return "\n\n".join(parts)


class ContextAssembler:
    def __init__(self, memory):
        self.memory = memory

    async def assemble(self, query: str, user_id: str) -> MemoryContext:
        context = MemoryContext()
        
        user_model = await self.memory.get_user_model(user_id)
        if user_model:
            context.user_profile_summary = self._summarize_user_model(user_model)
        
        semantic_results = await self.memory.retrieve(query, user_id)
        if semantic_results:
            context.semantic_episodes = self._format_semantic_results(semantic_results)
        
        if user_model and user_model.correction_rules:
            context.correction_rules = self._format_corrections(user_model.correction_rules)
        
        recent_turns = await self.memory.get_recent_turns(user_id, limit=20)
        if recent_turns:
            context.recent_turns = self._format_recent_turns(recent_turns)
        
        return context

    def _summarize_user_model(self, user_model) -> str:
        parts = [f"Name: {user_model.name}"]
        if user_model.communication_style:
            parts.append(f"Style: {user_model.communication_style}")
        if user_model.inferred_interests:
            parts.append(f"Interests: {', '.join(user_model.inferred_interests[:5])}")
        if user_model.stated_goals:
            parts.append(f"Goals: {', '.join(user_model.stated_goals[:3])}")
        return "\n".join(parts)

    def _format_semantic_results(self, results: list) -> str:
        formatted = []
        for r in results[:5]:
            formatted.append(f"- {r.get('content', '')[:200]}")
        return "\n".join(formatted)

    def _format_corrections(self, corrections: list) -> str:
        formatted = []
        for c in corrections[:10]:
            rule = c.rule if hasattr(c, 'rule') else c.get('rule', '')
            formatted.append(f"- {rule}")
        return "\n".join(formatted)

    def _format_recent_turns(self, turns: list) -> str:
        formatted = []
        for turn in turns:
            formatted.append(f"User: {turn.get('user_message', '')}")
            formatted.append(f"Assistant: {turn.get('assistant_message', '')}")
        return "\n".join(formatted[-40:])