"""
Tool system for AgentKit — lets agents call functions mid-conversation.

Usage:
    from agentkit.core.tools import ToolRegistry, tool

    tools = ToolRegistry()

    @tools.register
    def get_weather(city: str) -> str:
        \"\"\"Get the current weather for a city.\"\"\"
        return f"It's 25°C and sunny in {city}."

    @tools.register
    def search_web(query: str) -> str:
        \"\"\"Search the web for information.\"\"\"
        return f"Top result for '{query}': ..."

    # Pass to pipeline config
    config = PipelineConfig(persona="...", tools=tools)
"""

import inspect
import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class ToolDef:
    """Definition of a callable tool."""
    name: str
    description: str
    parameters: dict[str, dict[str, str]]  # {param_name: {type, description}}
    func: Callable


class ToolRegistry:
    """Registry of tools the agent can invoke during conversation."""

    def __init__(self):
        self._tools: dict[str, ToolDef] = {}

    def register(self, func: Callable = None, *, name: str = None, description: str = None):
        """Register a function as a tool. Can be used as a decorator.

        @tools.register
        def get_weather(city: str) -> str:
            \"\"\"Get current weather for a city.\"\"\"
            ...

        @tools.register(name="search", description="Search the web")
        def search_web(query: str) -> str:
            ...
        """
        def _register(fn):
            tool_name = name or fn.__name__
            tool_desc = description or (fn.__doc__ or "").strip().split("\n")[0]
            params = self._extract_params(fn)
            self._tools[tool_name] = ToolDef(
                name=tool_name,
                description=tool_desc,
                parameters=params,
                func=fn,
            )
            return fn

        if func is not None:
            return _register(func)
        return _register

    def get(self, name: str) -> ToolDef | None:
        return self._tools.get(name)

    def list_tools(self) -> list[ToolDef]:
        return list(self._tools.values())

    def to_system_prompt(self) -> str:
        """Generate a system prompt section describing available tools."""
        if not self._tools:
            return ""

        lines = [
            "\n\n## Available Tools",
            "You can call tools by responding with a JSON block like this:",
            '```json',
            '{"tool": "tool_name", "args": {"param1": "value1"}}',
            '```',
            "IMPORTANT: When you need to call a tool, respond ONLY with the JSON block, nothing else.",
            "After receiving the tool result, continue your response naturally.",
            "",
            "Tools:",
        ]
        for t in self._tools.values():
            param_str = ", ".join(
                f"{p}: {info.get('type', 'str')}" for p, info in t.parameters.items()
            )
            lines.append(f"- **{t.name}**({param_str}): {t.description}")

        return "\n".join(lines)

    async def execute(self, name: str, args: dict[str, Any]) -> str:
        """Execute a tool by name with the given arguments."""
        tool = self._tools.get(name)
        if not tool:
            return f"Error: Unknown tool '{name}'"

        try:
            result = tool.func(**args)
            if inspect.isawaitable(result):
                result = await result
            return str(result)
        except Exception as e:
            return f"Error calling {name}: {e}"

    @staticmethod
    def _extract_params(func: Callable) -> dict[str, dict[str, str]]:
        """Extract parameter info from function signature and type hints."""
        sig = inspect.signature(func)
        hints = getattr(func, "__annotations__", {})
        params = {}
        for pname, param in sig.parameters.items():
            if pname == "self":
                continue
            ptype = hints.get(pname, str).__name__ if pname in hints else "str"
            params[pname] = {"type": ptype}
        return params


def parse_tool_call(text: str) -> tuple[str, dict] | None:
    """Try to parse a tool call from LLM output.

    Looks for JSON like: {"tool": "name", "args": {...}}
    Returns (tool_name, args) or None.
    """
    text = text.strip()

    # Strip markdown code fences if present
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    text = text.strip()

    try:
        data = json.loads(text)
        if isinstance(data, dict) and "tool" in data:
            return data["tool"], data.get("args", {})
    except (json.JSONDecodeError, ValueError):
        pass

    # Try to find JSON embedded in text
    match = re.search(r'\{[^{}]*"tool"\s*:\s*"[^"]+?"[^{}]*\}', text)
    if match:
        try:
            data = json.loads(match.group())
            return data["tool"], data.get("args", {})
        except (json.JSONDecodeError, ValueError):
            pass

    return None
