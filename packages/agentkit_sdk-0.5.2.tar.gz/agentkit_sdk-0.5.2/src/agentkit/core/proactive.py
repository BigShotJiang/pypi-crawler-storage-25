"""
Proactive agent triggers for AgentKit.

Allows the agent to initiate conversations based on:
- Idle timeout: greet or check in after the user has been silent
- Scheduled messages: send messages at specific intervals
- Custom triggers: user-defined async functions

Usage:
    triggers = ProactiveTriggerManager()
    
    triggers.add_idle_trigger(
        timeout=300,  # 5 minutes
        message="Hey! Need any help with anything?"
    )
    
    triggers.add_scheduled_trigger(
        interval=3600,  # every hour
        message="Here's your hourly update..."
    )
    
    @triggers.on_trigger
    def custom_check():
        if some_condition:
            return "I noticed something you might want to know about!"
        return None
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class IdleTrigger:
    """Fires after the user has been idle for a certain duration."""
    timeout: float  # seconds
    message: str
    repeat: bool = False  # If True, fires again after each idle period
    _fired: bool = field(default=False, repr=False)


@dataclass
class ScheduledTrigger:
    """Fires at a regular interval."""
    interval: float  # seconds
    message: str | Callable[[], str | None]
    _last_fired: float = field(default=0.0, repr=False)


@dataclass
class ProactiveConfig:
    """Configuration for proactive agent behavior."""
    enabled: bool = False
    idle_timeout: float = 0  # 0 = disabled. Seconds of silence before greeting.
    idle_message: str = "Hey! I'm here if you need anything. Just ask!"
    idle_repeat: bool = False
    scheduled_triggers: list[dict] = field(default_factory=list)


class ProactiveTriggerManager:
    """Manages proactive triggers that let the agent initiate messages."""

    def __init__(self, config: ProactiveConfig | None = None):
        self.config = config or ProactiveConfig()
        self._idle_triggers: list[IdleTrigger] = []
        self._scheduled_triggers: list[ScheduledTrigger] = []
        self._custom_triggers: list[Callable] = []
        self._last_activity: float = time.time()
        self._running = False
        self._task: asyncio.Task | None = None
        self._on_message: Callable | None = None  # callback(message: str)

        # Set up from config
        if self.config.enabled and self.config.idle_timeout > 0:
            self._idle_triggers.append(IdleTrigger(
                timeout=self.config.idle_timeout,
                message=self.config.idle_message,
                repeat=self.config.idle_repeat,
            ))

        for trigger_cfg in self.config.scheduled_triggers:
            self._scheduled_triggers.append(ScheduledTrigger(
                interval=trigger_cfg.get("interval", 3600),
                message=trigger_cfg.get("message", ""),
            ))

    def add_idle_trigger(self, timeout: float, message: str, repeat: bool = False):
        """Add an idle timeout trigger."""
        self._idle_triggers.append(IdleTrigger(
            timeout=timeout,
            message=message,
            repeat=repeat,
        ))

    def add_scheduled_trigger(self, interval: float, message: str | Callable):
        """Add a scheduled interval trigger."""
        self._scheduled_triggers.append(ScheduledTrigger(
            interval=interval,
            message=message,
        ))

    def on_trigger(self, func: Callable):
        """Register a custom trigger function (decorator).
        
        The function should return a string message to send, or None to skip.
        Can be sync or async.
        """
        self._custom_triggers.append(func)
        return func

    def record_activity(self):
        """Call this whenever the user sends a message."""
        self._last_activity = time.time()
        # Reset idle triggers
        for trigger in self._idle_triggers:
            trigger._fired = False

    async def start(self, on_message: Callable):
        """Start the trigger loop. on_message is called with the message string."""
        if not self.config.enabled:
            return
        if self._running:
            return

        self._on_message = on_message
        self._running = True
        self._last_activity = time.time()

        # Initialize scheduled trigger times
        now = time.time()
        for t in self._scheduled_triggers:
            t._last_fired = now

        self._task = asyncio.create_task(self._loop())

    async def stop(self):
        """Stop the trigger loop."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _loop(self):
        """Main trigger check loop."""
        while self._running:
            try:
                await asyncio.sleep(5)  # Check every 5 seconds
                now = time.time()
                idle_duration = now - self._last_activity

                # Check idle triggers
                for trigger in self._idle_triggers:
                    if trigger._fired and not trigger.repeat:
                        continue
                    if idle_duration >= trigger.timeout:
                        trigger._fired = True
                        if self._on_message:
                            await self._on_message(trigger.message)

                # Check scheduled triggers
                for trigger in self._scheduled_triggers:
                    if (now - trigger._last_fired) >= trigger.interval:
                        trigger._last_fired = now
                        msg = trigger.message
                        if callable(msg):
                            msg = msg()
                        if msg and self._on_message:
                            await self._on_message(msg)

                # Check custom triggers
                for func in self._custom_triggers:
                    try:
                        result = func()
                        if asyncio.iscoroutine(result):
                            result = await result
                        if result and self._on_message:
                            await self._on_message(result)
                    except Exception:
                        pass

            except asyncio.CancelledError:
                break
            except Exception:
                pass
