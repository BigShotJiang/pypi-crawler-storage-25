"""
Wake word detection for AgentKit.

Supports keyword-based detection in transcribed text.
The detector checks if the user's speech starts with (or contains) a
configurable wake phrase before the pipeline processes the input.

Usage:
    detector = WakeWordDetector(wake_words=["hey assistant", "ok assistant"])
    
    if detector.detect("hey assistant, what's the weather?"):
        cleaned = detector.strip_wake_word("hey assistant, what's the weather?")
        # cleaned = "what's the weather?"
"""

import re
from dataclasses import dataclass, field


@dataclass
class WakeWordConfig:
    """Configuration for wake word detection."""
    enabled: bool = False
    words: list[str] = field(default_factory=lambda: ["hey agent"])
    # If True, wake word is required for every message.
    # If False, wake word activates a listen window (always_listen mode).
    required: bool = True
    # Seconds to keep listening after wake word without requiring it again
    listen_window: float = 30.0


class WakeWordDetector:
    """Detects wake words/phrases in transcribed text."""

    def __init__(self, config: WakeWordConfig | None = None):
        self.config = config or WakeWordConfig()
        self._patterns: list[re.Pattern] = []
        self._last_activation: float = 0.0

        for word in self.config.words:
            # Build a flexible regex: allow minor variations
            # "hey agent" matches "hey agent", "hey, agent", "hey agent,"
            parts = word.lower().strip().split()
            pattern = r'[,\s]*'.join(re.escape(p) for p in parts)
            self._patterns.append(re.compile(pattern, re.IGNORECASE))

    def detect(self, text: str) -> bool:
        """Check if text contains a wake word."""
        if not self.config.enabled:
            return True  # If disabled, everything passes through

        text_clean = text.strip().lower()
        for pattern in self._patterns:
            if pattern.search(text_clean):
                return True
        return False

    def strip_wake_word(self, text: str) -> str:
        """Remove the wake word from the beginning of the text."""
        result = text.strip()
        for pattern in self._patterns:
            match = pattern.search(result)
            if match:
                # Remove the wake word and any trailing punctuation/whitespace
                after = result[match.end():].lstrip(' ,.:!?')
                if after:
                    return after
                return result  # Wake word was the entire message, keep it
        return result

    def is_in_listen_window(self, current_time: float) -> bool:
        """Check if we're within the listen window after last activation."""
        if not self.config.enabled or not self.config.required:
            return True
        return (current_time - self._last_activation) < self.config.listen_window

    def activate(self, current_time: float):
        """Mark activation time for listen window tracking."""
        self._last_activation = current_time

    def should_process(self, text: str, current_time: float) -> bool:
        """Determine if a message should be processed.
        
        Returns True if:
        - Wake word is disabled (always process)
        - Wake word is detected in text
        - We're within the listen window from last activation
        """
        if not self.config.enabled:
            return True

        if self.detect(text):
            self.activate(current_time)
            return True

        if self.is_in_listen_window(current_time):
            return True

        return False
