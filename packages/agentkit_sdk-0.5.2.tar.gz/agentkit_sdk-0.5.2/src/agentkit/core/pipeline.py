import asyncio
import time
from dataclasses import dataclass, field
from typing import AsyncIterator

from agentkit.core.tools import ToolRegistry, parse_tool_call
from agentkit.providers.llm import BaseLLM, Message
from agentkit.providers.stt import BaseSTT
from agentkit.providers.tts import BaseTTS


@dataclass
class Turn:
    user_message: str
    assistant_message: str
    timestamp: float


@dataclass
class PipelineConfig:
    persona: str
    language: str = "hinglish"
    sentence_endings: list[str] = field(default_factory=lambda: ['.', '!', '?', '।'])
    tools: ToolRegistry | None = None


class VoicePipeline:
    def __init__(
        self,
        stt: BaseSTT,
        llm: BaseLLM,
        tts: BaseTTS,
        config: PipelineConfig,
    ):
        self.stt = stt
        self.llm = llm
        self.tts = tts
        self.config = config
        self.conversation_history: list[Message] = []
        self.turns: list[Turn] = []
        self._cancel_event = asyncio.Event()
        self._processing = False

    @property
    def is_processing(self) -> bool:
        return self._processing

    def cancel(self):
        """Cancel the current processing (interrupt the agent)."""
        if self._processing:
            self._cancel_event.set()

    async def process_voice_stream(
        self,
        audio_stream: AsyncIterator[bytes],
        memory_context: str = "",
        on_text_delta=None,
    ) -> AsyncIterator[bytes]:
        """Main streaming pipeline: STT → LLM → TTS with sentence-level streaming. Supports tool calling and interruption."""
        self._cancel_event.clear()
        self._processing = True

        try:
            transcription = ""
            async for text in self.stt.transcribe_stream(audio_stream):
                if self._cancel_event.is_set():
                    return
                transcription += text
            
            if not transcription.strip():
                return
            
            self.conversation_history.append(Message(role="user", content=transcription))

            # Build system prompt with tools if available
            system = self.config.persona
            if self.config.tools:
                system += self.config.tools.to_system_prompt()

            max_tool_rounds = 5
            for _ in range(max_tool_rounds):
                if self._cancel_event.is_set():
                    break

                llm_stream = self.llm.chat_stream(
                    messages=self.conversation_history,
                    system=system,
                    memory_context=memory_context,
                )
                
                full_response = ""
                sentence_buffer = ""
                interrupted = False
                async for token in llm_stream:
                    if self._cancel_event.is_set():
                        interrupted = True
                        break
                    sentence_buffer += token
                    full_response += token
                    if on_text_delta:
                        await on_text_delta(token)
                    
                    if self._is_sentence_end(sentence_buffer) and len(sentence_buffer) >= 10:
                        if not self._looks_like_tool_call(full_response):
                            tts_stream = self.tts.synthesize_stream(sentence_buffer)
                            async for audio_chunk in tts_stream:
                                if self._cancel_event.is_set():
                                    interrupted = True
                                    break
                                yield audio_chunk
                        sentence_buffer = ""
                    if interrupted:
                        break

                if interrupted:
                    # Save partial response to history so context isn't lost
                    if full_response.strip():
                        self.conversation_history.append(Message(role="assistant", content=full_response + " [interrupted]"))
                    break

                # Check if the full response is a tool call
                if self.config.tools:
                    tool_call = parse_tool_call(full_response)
                    if tool_call:
                        tool_name, tool_args = tool_call
                        tool_result = await self.config.tools.execute(tool_name, tool_args)

                        self.conversation_history.append(Message(role="assistant", content=full_response))
                        self.conversation_history.append(Message(
                            role="user",
                            content=f"[Tool Result for {tool_name}]: {tool_result}"
                        ))

                        if on_text_delta:
                            await on_text_delta(f"\n🔧 {tool_name}({', '.join(f'{k}={v}' for k,v in tool_args.items())})\n")

                        continue

                # Not a tool call — finalize
                if sentence_buffer.strip() and not self._looks_like_tool_call(full_response):
                    tts_stream = self.tts.synthesize_stream(sentence_buffer)
                    async for audio_chunk in tts_stream:
                        if self._cancel_event.is_set():
                            break
                        yield audio_chunk
                
                self.conversation_history.append(Message(role="assistant", content=full_response))
                self.turns.append(Turn(user_message=transcription, assistant_message=full_response, timestamp=time.time()))
                self._last_response = full_response
                break
        finally:
            self._processing = False

    async def process_text(
        self,
        user_message: str,
        memory_context: str = "",
        on_text_delta=None,
    ) -> AsyncIterator[bytes]:
        """Process text input and stream audio response. Supports tool calling and interruption."""
        self._cancel_event.clear()
        self._processing = True

        try:
            self.conversation_history.append(Message(role="user", content=user_message))

            # Build system prompt with tools if available
            system = self.config.persona
            if self.config.tools:
                system += self.config.tools.to_system_prompt()

            max_tool_rounds = 5
            for _ in range(max_tool_rounds):
                if self._cancel_event.is_set():
                    break

                llm_stream = self.llm.chat_stream(
                    messages=self.conversation_history,
                    system=system,
                    memory_context=memory_context,
                )

                full_response = ""
                sentence_buffer = ""
                interrupted = False
                async for token in llm_stream:
                    if self._cancel_event.is_set():
                        interrupted = True
                        break
                    sentence_buffer += token
                    full_response += token
                    if on_text_delta:
                        await on_text_delta(token)

                    if self._is_sentence_end(sentence_buffer) and len(sentence_buffer) >= 10:
                        if not self._looks_like_tool_call(full_response):
                            tts_stream = self.tts.synthesize_stream(sentence_buffer)
                            async for audio_chunk in tts_stream:
                                if self._cancel_event.is_set():
                                    interrupted = True
                                    break
                                yield audio_chunk
                        sentence_buffer = ""
                    if interrupted:
                        break

                if interrupted:
                    if full_response.strip():
                        self.conversation_history.append(Message(role="assistant", content=full_response + " [interrupted]"))
                    break

                # Check if the full response is a tool call
                if self.config.tools:
                    tool_call = parse_tool_call(full_response)
                    if tool_call:
                        tool_name, tool_args = tool_call
                        tool_result = await self.config.tools.execute(tool_name, tool_args)

                        self.conversation_history.append(Message(role="assistant", content=full_response))
                        self.conversation_history.append(Message(
                            role="user",
                            content=f"[Tool Result for {tool_name}]: {tool_result}"
                        ))

                        if on_text_delta:
                            await on_text_delta(f"\n🔧 {tool_name}({', '.join(f'{k}={v}' for k,v in tool_args.items())})\n")

                        continue

                # Not a tool call — finalize
                if sentence_buffer.strip() and not self._looks_like_tool_call(full_response):
                    tts_stream = self.tts.synthesize_stream(sentence_buffer)
                    async for audio_chunk in tts_stream:
                        if self._cancel_event.is_set():
                            break
                        yield audio_chunk

                self.conversation_history.append(Message(role="assistant", content=full_response))
                self.turns.append(Turn(user_message=user_message, assistant_message=full_response, timestamp=time.time()))
                self._last_response = full_response
                break
        finally:
            self._processing = False

    @staticmethod
    def _looks_like_tool_call(text: str) -> bool:
        """Quick check if text looks like it might be a tool call JSON."""
        stripped = text.strip().lstrip('`').lstrip('json').lstrip('\n').strip()
        return stripped.startswith('{') and '"tool"' in stripped

    def _is_sentence_end(self, text: str) -> bool:
        for ending in self.config.sentence_endings:
            if text.rstrip().endswith(ending):
                return True
        return False

    def get_last_response(self) -> str:
        return getattr(self, '_last_response', '')

    def get_recent_turns(self, count: int = 20) -> list[Turn]:
        return self.turns[-count:]

    async def close(self):
        await self.stt.close()
        await self.llm.close()
        await self.tts.close()