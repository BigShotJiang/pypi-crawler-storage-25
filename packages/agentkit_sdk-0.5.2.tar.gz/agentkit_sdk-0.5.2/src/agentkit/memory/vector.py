import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from qdrant_client import QdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

from .base import BaseMemory, ConversationTurn, UserModel


class VectorMemory(BaseMemory):
    def __init__(
        self,
        qdrant_url: str = "localhost",
        qdrant_port: int = 6333,
        collection_name: str = "agent_memory",
    ):
        self.client = QdrantClient(host=qdrant_url, port=qdrant_port)
        self.collection_name = collection_name
        self._init_collection()

    def _init_collection(self):
        collections = self.client.get_collections().collections
        if not any(c.name == self.collection_name for c in collections):
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=768, distance=Distance.COSINE),
            )

    def _embed_text(self, text: str) -> list[float]:
        import hashlib
        import struct
        
        hash_bytes = hashlib.sha256(text.encode()).digest()
        return list(struct.unpack("768f", hash_bytes + b"\x00" * (768 - len(hash_bytes) % 768)))[:768]

    async def retrieve(self, query: str, user_id: str) -> list[dict]:
        query_vector = self._embed_text(query)
        
        results = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            query_filter={
                "must": [
                    {"key": "user_id", "match": {"value": user_id}}
                ]
            },
            limit=5,
        )
        
        return [{"content": r.payload.get("content", ""), "score": r.score} for r in results]

    async def store(self, turn: ConversationTurn) -> None:
        content = f"User: {turn.user_message}\nAssistant: {turn.assistant_message}"
        vector = self._embed_text(content)
        
        point = PointStruct(
            id=str(uuid.uuid4()),
            vector=vector,
            payload={
                "user_id": turn.user_id,
                "content": content,
                "user_message": turn.user_message,
                "assistant_message": turn.assistant_message,
                "timestamp": turn.timestamp.isoformat(),
            },
        )
        
        self.client.upsert(collection_name=self.collection_name, points=[point])

    async def get_user_model(self, user_id: str) -> UserModel | None:
        return None

    async def update_user_model(self, user_id: str, **kwargs) -> None:
        pass

    async def get_recent_turns(self, user_id: str, limit: int = 20) -> list[dict]:
        results = self.client.scroll(
            collection_name=self.collection_name,
            scroll_filter={
                "must": [
                    {"key": "user_id", "match": {"value": user_id}}
                ]
            },
            limit=limit,
        )[0]
        
        return [
            {
                "user_message": r.payload.get("user_message", ""),
                "assistant_message": r.payload.get("assistant_message", ""),
                "timestamp": r.payload.get("timestamp", ""),
            }
            for r in results
        ]