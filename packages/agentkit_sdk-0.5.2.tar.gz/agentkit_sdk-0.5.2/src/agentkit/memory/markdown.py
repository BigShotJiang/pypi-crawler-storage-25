import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

import aiofiles

from .base import BaseMemory, ConversationTurn, UserModel


class MarkdownMemory(BaseMemory):
    def __init__(self, storage_dir: str = "./memory"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    def _get_memory_path(self, user_id: str) -> Path:
        return self.storage_dir / f"{user_id}.md"

    def _get_user_model_path(self, user_id: str) -> Path:
        return self.storage_dir / f"{user_id}_model.json"

    async def retrieve(self, query: str, user_id: str) -> list[dict]:
        """Recency-based retrieval - returns last N turns as context."""
        path = self._get_memory_path(user_id)
        if not path.exists():
            return []

        turns = await self.get_recent_turns(user_id, limit=10)
        return [
            {"content": f"User: {t['user_message']}\nAssistant: {t['assistant_message']}"}
            for t in turns
        ]

    async def store(self, turn: ConversationTurn) -> None:
        path = self._get_memory_path(turn.user_id)
        
        timestamp = turn.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        entry = f"\n## {timestamp}\n\n**User:** {turn.user_message}\n\n**Assistant:** {turn.assistant_message}\n"
        
        async with aiofiles.open(path, "a") as f:
            await f.write(entry)

    async def get_user_model(self, user_id: str) -> UserModel | None:
        import json
        
        path = self._get_user_model_path(user_id)
        if not path.exists():
            return None
        
        async with aiofiles.open(path, "r") as f:
            content = await f.read()
        
        data = json.loads(content)
        data["last_active"] = datetime.fromisoformat(data["last_active"])
        return UserModel(**data)

    async def update_user_model(self, user_id: str, **kwargs) -> None:
        import json
        
        path = self._get_user_model_path(user_id)
        
        if path.exists():
            async with aiofiles.open(path, "r") as f:
                content = await f.read()
            data = json.loads(content)
            data["last_active"] = datetime.fromisoformat(data["last_active"])
            user_model = UserModel(**data)
        else:
            user_model = UserModel(user_id=user_id, last_active=datetime.now())
        
        for key, value in kwargs.items():
            if hasattr(user_model, key):
                setattr(user_model, key, value)
        
        user_model.last_active = datetime.now()
        
        async with aiofiles.open(path, "w") as f:
            await f.write(user_model.to_json())

    async def get_recent_turns(self, user_id: str, limit: int = 20) -> list[dict]:
        path = self._get_memory_path(user_id)
        if not path.exists():
            return []

        async with aiofiles.open(path, "r") as f:
            content = await f.read()

        turns = []
        current_turn = {}
        
        for line in content.split("\n"):
            if line.startswith("## "):
                if current_turn:
                    turns.append(current_turn)
                current_turn = {"timestamp": line[3:], "user_message": "", "assistant_message": ""}
            elif line.startswith("**User:** "):
                current_turn["user_message"] = line[10:]
            elif line.startswith("**Assistant:** "):
                current_turn["assistant_message"] = line[15:]
        
        if current_turn:
            turns.append(current_turn)
        
        return turns[-limit:]