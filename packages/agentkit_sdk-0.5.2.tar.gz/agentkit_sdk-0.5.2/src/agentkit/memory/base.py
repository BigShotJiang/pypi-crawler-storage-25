from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass
class Fact:
    content: str
    source_turn_id: str
    confidence: float
    created_at: datetime


@dataclass
class Correction:
    rule: str
    original_intent: str
    corrected_intent: str
    source_turn_id: str
    created_at: datetime


@dataclass
class Pattern:
    description: str
    frequency: int
    last_seen: datetime


@dataclass
class Goal:
    description: str
    status: str
    created_at: datetime


@dataclass
class OpenLoop:
    topic: str
    mentioned_at: datetime
    status: str = "open"


@dataclass
class ConversationTurn:
    turn_id: str
    user_id: str
    user_message: str
    assistant_message: str
    timestamp: datetime
    metadata: dict[str, Any]


@dataclass
class UserModel:
    user_id: str
    name: str = ""
    language_preference: str = "en"
    communication_style: str = "neutral"
    inferred_interests: list[str] = None
    semantic_facts: list[Fact] = None
    correction_rules: list[Correction] = None
    behavioral_patterns: list[Pattern] = None
    stated_goals: list[str] = None
    open_loops: list[OpenLoop] = None
    total_conversations: int = 0
    last_active: datetime = None

    def __post_init__(self):
        if self.inferred_interests is None:
            self.inferred_interests = []
        if self.semantic_facts is None:
            self.semantic_facts = []
        if self.correction_rules is None:
            self.correction_rules = []
        if self.behavioral_patterns is None:
            self.behavioral_patterns = []
        if self.stated_goals is None:
            self.stated_goals = []
        if self.open_loops is None:
            self.open_loops = []

    def to_json(self) -> str:
        import json
        from dataclasses import asdict

        data = asdict(self)
        if self.last_active:
            data["last_active"] = self.last_active.isoformat()
        # Convert complex nested objects to serializable form
        data["semantic_facts"] = [
            {**f, "created_at": f["created_at"].isoformat()} if isinstance(f.get("created_at"), datetime) else f
            for f in data.get("semantic_facts", [])
        ]
        data["correction_rules"] = [
            {**c, "created_at": c["created_at"].isoformat()} if isinstance(c.get("created_at"), datetime) else c
            for c in data.get("correction_rules", [])
        ]
        data["behavioral_patterns"] = [
            {**p, "last_seen": p["last_seen"].isoformat()} if isinstance(p.get("last_seen"), datetime) else p
            for p in data.get("behavioral_patterns", [])
        ]
        data["open_loops"] = [
            {**o, "mentioned_at": o["mentioned_at"].isoformat()} if isinstance(o.get("mentioned_at"), datetime) else o
            for o in data.get("open_loops", [])
        ]
        return json.dumps(data, indent=2, default=str)


@dataclass
class MemoryContext:
    pass


class BaseMemory(ABC):
    @abstractmethod
    async def retrieve(self, query: str, user_id: str) -> list[dict]:
        """Retrieve relevant memory context for a query."""
        pass

    @abstractmethod
    async def store(self, turn: ConversationTurn) -> None:
        """Store a conversation turn."""
        pass

    @abstractmethod
    async def get_user_model(self, user_id: str) -> UserModel | None:
        """Get user model."""
        pass

    @abstractmethod
    async def update_user_model(self, user_id: str, **kwargs) -> None:
        """Update user model fields."""
        pass

    @abstractmethod
    async def get_recent_turns(self, user_id: str, limit: int = 20) -> list[dict]:
        """Get recent conversation turns."""
        pass