import asyncio
from datetime import datetime
from typing import Any

from agentkit.providers.llm import BaseLLM, Message


class MemoryExtractor:
    def __init__(self, llm: BaseLLM):
        self.llm = llm

    async def extract_facts(self, turns: list[dict]) -> list[dict]:
        """Extract facts from recent conversation turns."""
        
        if not turns:
            return []
        
        conversation = "\n".join([
            f"User: {t.get('user_message', '')}"
            for t in turns[-5:]
        ])
        
        prompt = f"""Extract factual information about the user from this conversation.
Return a JSON array of facts, each with 'content' and 'confidence' fields.
Only extract facts with >0.7 confidence.

Conversation:
{conversation}

Output:"""
        
        try:
            response = await self.llm.chat(
                messages=[Message(role="user", content=prompt)],
                system="You are a fact extraction assistant. Output valid JSON only.",
            )
            
            import json
            facts = json.loads(response)
            return facts
        except:
            return []

    async def extract_user_model(self, recent_turns: list[dict], current_model: Any) -> dict:
        """Extract/update user model from conversation history."""
        
        if not recent_turns:
            return {}
        
        conversation = "\n".join([
            f"User: {t.get('user_message', '')}\nAssistant: {t.get('assistant_message', '')}"
            for t in recent_turns[-10:]
        ])
        
        prompt = f"""Analyze this conversation and extract user profile information.
Return a JSON object with these fields:
- name: if mentioned
- language_preference: language user prefers (hindi/hinglish/english)
- communication_style: how user communicates (formal/casual/mixed)
- inferred_interests: list of interests mentioned
- stated_goals: any goals user mentioned

Current model: {current_model}

Conversation:
{conversation}

Output:"""
        
        try:
            response = await self.llm.chat(
                messages=[Message(role="user", content=prompt)],
                system="You are a user profiling assistant. Output valid JSON only.",
            )
            
            import json
            return json.loads(response)
        except:
            return {}