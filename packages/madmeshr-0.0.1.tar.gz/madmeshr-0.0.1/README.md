# madmeshr

**Status: name-reservation placeholder (v0.0.1). No functional code is published here yet.**

This is a placeholder release on PyPI. The real project — an in-development
2D unstructured quad-mesh generator using an advancing-front method with
Pan et al.'s SAC over a continuous 3-D action space (DQN retained as a
legacy comparator) — is being developed in the open at:

  https://github.com/domattioli/MADMESHR

A functional release will replace this stub once the project reaches a
publishable milestone.

## Install (placeholder)

```
pip install madmeshr
```

This currently installs only the package metadata and a version string.

## Install from source (active development)

```
git clone https://github.com/domattioli/MADMESHR.git
cd MADMESHR
pip install -e .
```

See the GitHub repository for current status, project plan, and contribution
notes.

## License

MIT. See `LICENSE`.
