"""MADMESHR — Mixed-element ADvanced MESH generator with Reinforcement-learning.

This 0.0.1 release is a name-reservation placeholder. No functional code is
published here yet. Real development happens at:

    https://github.com/domattioli/MADMESHR

The eventual public package will be a 2D unstructured quad-mesh generator
using an advancing-front method with Pan et al.'s SAC over a continuous 3-D
action space (DQN retained as legacy comparator).
"""

__version__ = "0.0.1"
