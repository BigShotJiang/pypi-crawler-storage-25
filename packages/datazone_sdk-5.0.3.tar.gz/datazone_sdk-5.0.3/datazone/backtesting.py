from typing import Callable, Sequence

import pandas as pd
from joblib import Parallel, delayed
from tqdm import tqdm

from datazone.db.snapshot import SnapshotDatabaseClient
from datazone.db.standard import DatabaseClient


def backtest(
    func: Callable[[SnapshotDatabaseClient, pd.Timestamp], pd.DataFrame],
    db: DatabaseClient,
    calculation_times: pd.DatetimeIndex | Sequence[pd.Timestamp],
    parallelize_runs: bool = False,
    cache_queries: bool = False,
    verbose: bool = False,
) -> pd.DataFrame:
    """Simulate historical runs of a function which queries from a database.
    The simulation is done by running the function on series of snapshots of the
    database. The output will be a type 2 historical table representing how the
    historical production table would look like.

    Args:
        func (Callable[[SnapshotDatabaseClient, pd.Timestamp], pd.DataFrame]): Function
            to backtest. Must take as input a database and a calculation time.
        db (DatabaseClient): Database client
        calculation_times (pd.DatetimeIndex | Sequence[pd.Timestamp]): Calculation times
            to use.
        parallelize_runs (bool, optional): Whether to parallelize the backtesting
            iterations. Defaults to False.
        cache_queries (bool, optional): Whether to cache queries from tables (caching
            only takes into account special filters). Defaults to False.
        verbose (bool, optional): Whether to print progress of backtesting iterations
            to the console.

    Returns:
        pd.DataFrame: Concatenated DataFrame of all snapshot results, with
        'valid_from_time_utc' and 'valid_to_time_utc' columns representing
        the calculation times.
    """

    results = []
    calculation_times = pd.DatetimeIndex(calculation_times)

    # Define task to be executed in parallel (or sequentially if parallelize_runs=False)
    def simulate_function_output(
        current_calculation_time: pd.Timestamp,
        next_calculation_time: pd.Timestamp,
    ):
        snapshot_db = db.snapshot_at(current_calculation_time, cache_queries)
        result = func(snapshot_db, current_calculation_time)

        result["valid_from_time_utc"] = current_calculation_time
        result["valid_to_time_utc"] = next_calculation_time

        return result

    if parallelize_runs:
        n_jobs = -1  # when n_jobs=-1, joblib tries to use all available CPU's
    else:
        n_jobs = 1  # when n_jobs=1, joblib runs the execution as a simple for-loop

    n = len(calculation_times)
    job = Parallel(n_jobs)
    iterable = [
        delayed(simulate_function_output)(
            calculation_times[i], calculation_times[i + 1]
        )
        for i in range(n - 1)
    ]

    if verbose:
        iterable = tqdm(iterable, ncols=100)

    results = job(iterable)

    if not results:
        return pd.DataFrame()

    return pd.concat(results, ignore_index=True)
