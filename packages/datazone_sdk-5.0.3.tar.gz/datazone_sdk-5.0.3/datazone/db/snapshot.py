import datamazing.pandas as pdz
import pandas as pd

from datazone.caching import ParquetCache
from datazone.db.base import BaseDatabaseClient
from datazone.db.standard import DatabaseClient
from datazone.deltastorage.slicing import HyperSlice


class SnapshotDatabaseClient(BaseDatabaseClient):
    """ """

    def __init__(
        self,
        db: "DatabaseClient",
        snapshot_time: pd.Timestamp,
        cache_queries: bool = False,
    ):
        """Simulation of data prior to a specific point in time.

        Note: This is not the same as time travelling using an as-of-time. The latter
        returns how the real-world looked at specific point in time (i.e. removing the
        valid-time dimension from the data). Here, we return how the data state looked
        at a specific point in time (i.e. keep the valid-time dimension, but remove all
        data happened after the given point in time).

        Args:
            db (DatabaseClient): Database client
            snapshot_time (pd.Timestamp): Snapshot time
            cache_queries (bool, optional): Whether to cache queries from tables
                (caching only takes into account special filters).
                Defaults to False.
        """
        self.db = db
        self.snapshot_time = snapshot_time
        if cache_queries:
            self.cache = ParquetCache(cache_subdir=".snapshot")
        else:
            self.cache = None

    def memoize(func):
        """Decorator used to memoize instance method"""

        def wrapper(self, *args, **kwargs):
            if self.cache is not None:
                return self.cache.memoize(ignore=[0])(func)(self, *args, **kwargs)
            else:
                return func(self, *args, **kwargs)

        return wrapper

    @memoize
    def _query_only_filters(
        self,
        table_name: str,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:
        return self.db.query(
            table_name,
            time_interval=None,
            time_travel=None,
            filters=filters,
            columns=columns,
            include_generated_columns=include_generated_columns,
        )

    def query(
        self,
        table_name: str,
        time_interval: pdz.TimeInterval | None = None,
        time_travel: pdz.TimeTravel | None = None,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:
        # To optimize the query performance, we first cache the queried data
        # with only special filters applied (i.e. no time interval or time travel
        # filter). This is more efficient for backtesting use cases, where
        # we typically query the same special filters, but different time interval and
        # time travel filters.
        df = self._query_only_filters(
            table_name,
            filters,
            columns,
            include_generated_columns,
        )

        # only keep rows that were valid prior to the snapshot time
        df = df[df["valid_from_time_utc"] <= self.snapshot_time]

        # at the snapshot time, all latest rows were valid until the end-of-time,
        # so we need to simulate this here
        df["valid_to_time_utc"] = df["valid_to_time_utc"].where(
            df["valid_to_time_utc"] <= self.snapshot_time,
            pdz.END_OF_TIME,
        )

        # apply time interval if needed
        if time_interval is not None:
            df = pdz.filter_time_interval(df, time_interval)

        # apply time travel if needed
        if time_travel is not None:
            df = pdz.filter_time_travel(df, time_travel)

        return df

    def list_tables(self):
        return self.db.list_tables()
