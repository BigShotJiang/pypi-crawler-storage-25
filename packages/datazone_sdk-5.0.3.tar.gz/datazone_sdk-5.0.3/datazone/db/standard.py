from typing import TYPE_CHECKING

import datamazing.pandas as pdz
import pandas as pd
import pyarrow.compute as pc

if TYPE_CHECKING:
    from datazone.db.snapshot import SnapshotDatabaseClient

from datazone.db.base import BaseDatabaseClient
from datazone.deltastorage.slicing import HyperSlice
from datazone.deltastorage.store import Store


class DatabaseClient(BaseDatabaseClient):
    def __init__(
        self,
        url: str,
        storage_options: dict[str, str] | None = None,
        table_prefix: str = "",
    ):
        self.store = Store(url, storage_options)
        self.table_prefix = table_prefix

    @classmethod
    def from_resource_name(
        cls,
        storage_account: str,
        container_name: str = "datasets",
        sub_path: str = "",
        table_prefix: str = "",
    ):
        """Create a DatabaseClient from resource name (storage account).
        This assumes the path of the delta lake is of the form:
        abfss://{container_name}@{storage_account}.dfs.core.windows.net/{sub_path}

        Args:
            storage_account (str): Storage account name.
            container_name (str, optional): Container name. Defaults to "datasets".
            sub_path (str, optional): Sub-path within the container. Defaults to "".
            table_prefix (str, optional): Table prefix to use (e.g. `mz_` for archive).
            Defaults to "".
            credential (optional): Azure credential to use.
            Defaults to DefaultAzureCredential().
        """
        url = f"abfss://{container_name}@{storage_account}.dfs.core.windows.net"
        if sub_path:
            url += f"/{sub_path}"

        storage_options = Store._get_func_storage_options()

        return cls(
            url,
            storage_options,
            table_prefix,
        )

    def snapshot_at(
        self, snapshot_time: pd.Timestamp, cache_queries: bool = True
    ) -> "SnapshotDatabaseClient":
        """Snapshot database at a specific point in time."""
        from datazone.db.snapshot import SnapshotDatabaseClient

        return SnapshotDatabaseClient(self, snapshot_time, cache_queries)

    def get_unit_and_multiple(self, timedelta: pd.Timedelta) -> tuple[str | None, int]:
        """
        Get unit and multiple of a timedelta. E.g. for a timedelta of "PT5M" then
        unit = "minute" and multiple = 5.
        NOTE: Timedelta must have one and only one non-zero component,
        i.e. "PT0S" doesnt work, and neither does "PT5M10S".

        Args:
            timedelta (pd.Timedelta): Timedelta

        Returns:
            tuple[str, int]: Unit and multiple
        """
        components = timedelta.components._asdict()

        # remove plural ending from unit, since
        # this is the standard pyarrow uses
        components = {k[:-1]: v for k, v in components.items()}

        non_zero_components = {
            unit: multiple for unit, multiple in components.items() if multiple != 0
        }

        if len(non_zero_components) == 0:
            return None, 0

        if len(non_zero_components) != 1:
            raise ValueError("Timedelta must have one and only one non-zero multiple.")

        return next(iter(non_zero_components.items()))

    def relative_time_travel_version(
        self, time_column: str, block: pd.Timedelta, horizon: pd.Timedelta
    ) -> pc.Expression:
        """
        Get value to use for filtering a relative time travel
        (i.e. the interval [valid-from, valid-to] must contain
        this value)
        """
        unit, multiple = self.get_unit_and_multiple(block)

        if multiple == 0:
            # `pc.floor_temporal` fails with multiple=0,
            # but in this case we don't need to floor
            # the time anyway
            start_of_block = pc.field("time_utc")
        else:
            start_of_block = pc.floor_temporal(
                pc.field(time_column),
                multiple=multiple,
                unit=unit,
            )

        return start_of_block - horizon.to_pytimedelta()

    def time_travel_filter(
        self,
        time_travel: pdz.TimeTravel,
        time_column: str,
        valid_from_column: str,
        valid_to_column: str,
    ) -> list[HyperSlice]:
        """Filter delta table on a time travel

        Args:
            time_travel (pdz.TimeTravel): Time travel
            time_column (str): Time column name
            valid_from_column (str): Valid-from column name
            valid_to_column (str): Valid-to column name
        """
        match time_travel.tense:
            case "absolute":
                # If the time travel is absolute, we filter
                # to entries where [valid-from, valid-to]
                # contains `as_of_time`
                version = time_travel.as_of_time.to_pydatetime()
            case "relative":
                version = self.relative_time_travel_version(
                    time_column, time_travel.block, time_travel.horizon
                )

        return [
            HyperSlice((valid_from_column, "<=", version)),
            HyperSlice((valid_to_column, ">", version)),
        ]

    def query(
        self,
        table_name: str,
        time_interval: pdz.TimeInterval | None = None,
        time_travel: pdz.TimeTravel | None = None,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:
        """Query table.

        Args:
            table_name (str): Name of the table
            time_interval (pdz.TimeInterval | None): Time interval for the query.
                Defaults to None, meaning no time filtering will be applied.
            time_travel (pdz.TimeTravel | None): Time travel for the query.
                Defaults to None, meaning no time travel filtering will be applied
                (i.e. the full type 2 history will be returned)
            filters (HyperSlice | None): Filters to apply to the
                query. Defaults to None.
            columns (list[str] | None): Columns to return.
                Selecting columns can significantly improve query performance.
                Defaults to None, meaning all columns will be returned.
            include_generated_columns (bool, optional): Whether to include generated
                columns in the result; (e.g. `date_utc`). Defaults to False.

        Returns:
            pd.DataFrame: The result of the query.
        """
        # Prefix used to differentiate between operation ("{table_name}")
        # and historical ("mz_{table_name}").
        table_name = f"{self.table_prefix}{table_name}"

        table = self.store.get_table(table_name)
        hyper_slice = []

        if filters:
            hyper_slice.extend(filters)

        if time_interval:
            hyper_slice.append(("time_utc", ">=", time_interval.left))
            hyper_slice.append(("time_utc", "<=", time_interval.right))

        if time_travel:
            tt_filter = self.time_travel_filter(
                time_travel,
                time_column="time_utc",
                valid_from_column="valid_from_time_utc",
                valid_to_column="valid_to_time_utc",
            )

            hyper_slice.extend(tt_filter)

        pl_df = table.read(hyper_slice=HyperSlice(hyper_slice), columns=columns)

        pd_df = pl_df.to_pandas()

        # We truncate to second, and change to nanosecond
        # precision because this was used by the old solution (Azure Table Storage)
        for col in pd_df.select_dtypes(include=["datetime", "datetimetz"]).columns:
            pd_df[col] = pd_df[col].dt.floor("s").dt.as_unit("ns")

        # Drop generated columns
        if not include_generated_columns:
            generated_cols = []
            for field in table.schema().fields:
                if field.generated_as is not None:
                    generated_cols.append(field.column_name)
            pd_df = pd_df.drop(columns=generated_cols, errors="ignore")

        return pd_df

    def list_tables(self) -> list[str]:
        """List tables in the database

        Returns:
            list[str]: List of table names
        """
        return [
            table.removeprefix(self.table_prefix) for table in self.store.list_tables()
        ]

    def copy(
        self, target: "DatabaseClient", subset: list[str], overwrite: bool = False
    ):
        """Copy (subset of) tables in the current database to another target.

        Args:
            target (DatabaseClient): Target database client
            subset (list[str]): Subset of tables to copy.
            overwrite (bool): Whether to overwrite existing tables in the target.
                Defaults to False.
        """
        # Add prefix to table names in subset
        subset = [f"{self.table_prefix}{table_name}" for table_name in subset]

        self.store.copy(
            target=target.store,
            subset=subset,
            overwrite=overwrite,
        )
