import os
from io import BytesIO
from pathlib import Path

import pandas as pd
from diskcache import UNKNOWN, Cache, Disk

DEFAULT_CACHE_DIR = ".diskcache"
CACHE_DIR = Path(os.environ.get("CACHE_DIR", DEFAULT_CACHE_DIR))


class ParquetDisk(Disk):
    def store(self, value: pd.DataFrame, read, key=UNKNOWN):
        buffer = BytesIO()
        value.to_parquet(buffer)
        buffer.seek(0)
        return super().store(buffer, read=True, key=key)

    def fetch(self, mode, filename, value, read):
        buffer = super().fetch(mode, filename, value, read=True)
        value = pd.read_parquet(buffer)
        return value


class ParquetCache(Cache):
    """
    Cache using Parquet files to memoize functions.
    Works only for functions retuning pandas DataFrames
    as output
    """

    def __init__(self, cache_subdir: str = "default"):
        # set `cull_limit` to zero (default is 10, meaning
        # that the cache can only hold 10 items). Zero means
        # unlimited (so only the `size_limit` is limiting
        # the cache)
        cache_dir = CACHE_DIR / cache_subdir
        super().__init__(directory=cache_dir, cull_limit=0, disk=ParquetDisk)
