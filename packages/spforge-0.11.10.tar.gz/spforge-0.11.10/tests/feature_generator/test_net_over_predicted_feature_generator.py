import polars as pl
from polars.testing import assert_frame_equal
from sklearn.base import BaseEstimator, RegressorMixin

from spforge.feature_generator._net_over_predicted import (
    NetOverPredictedFeatureGenerator,
)


class ConstantPredRegressor(RegressorMixin, BaseEstimator):
    def __init__(self, preds):
        self.preds = preds

    def fit(self, X, y=None):
        del y
        return self

    def predict(self, X):
        return self.preds[: len(X)]


def test_net_over_predicted_feature_generator__future_transform_uses_transform_signature():
    df = pl.DataFrame(
        {
            "feature1": [1.0, 2.0, 3.0],
            "target": [0.5, 1.0, 2.0],
        }
    )

    generator = NetOverPredictedFeatureGenerator(
        estimator=ConstantPredRegressor([0.4, 0.8, 2.0]),
        features=["feature1"],
        target_name="target",
        net_over_predicted_col="net_over_predicted",
    )

    generator.fit_transform(df)
    future_out = generator.future_transform(df)

    expected = df.with_columns(pl.Series("net_over_predicted", [0.1, 0.2, 0.0]))
    assert_frame_equal(
        future_out.select(expected.columns),
        expected,
        check_dtypes=False,
    )
