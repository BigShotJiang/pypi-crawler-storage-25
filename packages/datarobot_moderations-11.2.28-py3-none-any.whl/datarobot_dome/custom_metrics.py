#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Items for sending custom-metrics to DataRobot instance."""

import logging
import math
from datetime import datetime
from datetime import timezone
from typing import Any

import numpy as np
from datarobot.errors import ClientError
from datarobot.models.deployment import CustomMetric

from datarobot_dome.async_http_client import AsyncHTTPClient
from datarobot_dome.async_http_client import _get_event_loop
from datarobot_dome.constants import LOGGER_NAME_PREFIX

FAILURE_TITLE = "Failed to create custom metric"


class CustomMetricSession:
    """Container for DataRobot custom-metrics requests.

    General workflow:
    1. Create session
    2. Populate configs - one config per custom-metric (add_config())
    3. Create custom-metrics in deployment (create_metrics())
    4. Create map of custom-metric names to IDs (resolve_metric_ids())
    5. Create by-name storage for values (reset_values())
    6. Accumulate metric values by name (set_value())
    7. Push custom-metric values to DR instance (upload_values())
    8. Repeat steps 5-7 for each prediction
    """

    def __init__(self, deployment_id: str, bulk_upload_url: str, model_id: str | None = None):
        self._logger = logging.getLogger(LOGGER_NAME_PREFIX + "." + type(self).__name__)
        self.deployment_id = deployment_id
        self.model_id = model_id
        self.bulk_upload_url = bulk_upload_url
        self.agg_values = None
        self.configs = dict()
        self.names_to_ids = dict()
        self.loop = _get_event_loop()

    def __repr__(self) -> str:
        cfg_count = len(self.configs)
        id_count = len(self.names_to_ids)
        agg_count = len(self.agg_values) if self.agg_values else 0
        summary = f"{cfg_count} configs, {id_count} ids, {agg_count} aggregates"
        return f"{self.__class__.__name__}({summary})"

    def add_config(self, name: str, config: dict, requires_association_id: bool) -> None:
        """Add item to configurations."""
        self.configs[name] = {
            "metric_definition": config,
            "requires_association_id": requires_association_id,
        }
        self._logger.info("added config for %s", name)

    def config_names(self) -> list[str]:
        """Get the list of configuration names."""
        return [_ for _ in self.configs]

    def id_from_name(self, name: str) -> str | None:
        """Get the id for a name."""
        return self.names_to_ids.get(name)

    def reset_values(self):
        """Resets the aggregate values map with fresh data.

        NOTE: seems like this should be a more transient thing to allow proper multi-threading.
        """
        self.agg_values = dict()
        for name, config in self.configs.items():
            metric_id = self.names_to_ids.get(name)
            if not metric_id:
                self._logger.error("No metric id found for %s", name)
                continue

            if not config["requires_association_id"]:
                self.agg_values[name] = {"customMetricId": str(metric_id)}

    def set_value(
        self, name: str, value: int | float, overwrite: bool = True, timestamp: str | None = None
    ):
        if self.agg_values is None:
            return

        entry = self.agg_values.get(name)
        if not entry:
            self._logger.error("No metric entry found for %s", name)
            return

        if not overwrite and "value" in entry:
            return

        if isinstance(value, np.generic):
            entry["value"] = value.item()
        else:
            entry["value"] = value
        entry["timestamp"] = timestamp or str(datetime.now(timezone.utc).isoformat())
        entry["sampleSize"] = 1

    def create_report_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"buckets": []}
        if self.model_id:
            payload["modelId"] = self.model_id

        missing = []
        for name, data in self.agg_values.items():
            value = data.get("value")
            # TODO: allow categorical? geo? etc
            if value is None or math.isnan(value):
                missing.append(f"{name}={value}")
                continue

            payload["buckets"].append(data)

        if missing:
            self._logger.debug("missing custom metrics: %s", ", ".join(missing))

        return payload

    def upload_values(self, async_client: AsyncHTTPClient, payload: dict):
        """Push the results to the DR instance."""
        if len(payload["buckets"]) == 0:
            self._logger.warning("No custom metrics to report, empty payload")
            return

        # Use thread-local event loop to reuse aiohttp session across multiple calls
        self.loop.run_until_complete(
            async_client.bulk_upload_custom_metrics(
                self.bulk_upload_url, payload, self.deployment_id
            )
        )

    def resolve_metric_ids(self) -> None:
        """Fetches the list of metrics from the DR instance, and maps the names to IDs."""
        custom_metrics = CustomMetric.list(self.deployment_id)
        self.names_to_ids = dict()
        for custom_metric in custom_metrics:
            self.names_to_ids[custom_metric.name] = custom_metric.id

        missing = [name for name in self.configs if name not in self.names_to_ids]
        if missing:
            self._logger.error("missing custom metrics: %s", ", ".join(missing))

        self._logger.debug("found metrics names: %s", self.names_to_ids)

    def create_metrics(self) -> list[dict[str, Any]]:
        """Creates the local configurations into CustomMetrics within the deployment.

        The return value is a list of dict's for the creating events.
        """

        def _exception_to_error(name: str, definition: dict[str, Any], msg: str) -> dict[str, Any]:
            err_msg = f"Exception: {msg} Custom metric definition: {definition}"
            self._logger.error(FAILURE_TITLE + " " + err_msg)
            return {"title": FAILURE_TITLE, "message": err_msg, "metric_name": name}

        errors: list[dict[str, Any]] = []
        for metric_name, config in self.configs.items():
            metric_definition = config["metric_definition"]
            try:
                _metric_obj = CustomMetric.create(
                    deployment_id=self.deployment_id,
                    name=metric_name,
                    directionality=metric_definition["directionality"],
                    aggregation_type=metric_definition["type"],
                    time_step=metric_definition["timeStep"],
                    units=metric_definition["units"],
                    baseline_value=metric_definition["baselineValue"],
                    is_model_specific=metric_definition["isModelSpecific"],
                )
            except ClientError as e:
                if e.status_code == 409:
                    if "not unique for deployment" in e.json["message"]:
                        # Duplicate entry nothing to worry - just continue
                        self._logger.info("Metric '%s' already exists, skipping", metric_name)
                        continue
                    elif e.json["message"].startswith("Maximum number of custom metrics reached"):
                        # Reached the limit - we can't create more
                        message = "Maximum number of custom metrics reached"
                        self._logger.error(FAILURE_TITLE + " " + message)
                        errors.append({"title": FAILURE_TITLE, "message": message})
                        # consolidate valid custom metrics
                        break

                # record the error and keep going
                self._logger.exception(e)
                message = e.json.get("message") or str(e)
                errors.append(_exception_to_error(metric_name, metric_definition, message))
            except Exception as e:
                # record the error and keep going
                self._logger.exception(e)
                errors.append(_exception_to_error(metric_name, metric_definition, str(e)))
                continue

        self.resolve_metric_ids()
        return errors
