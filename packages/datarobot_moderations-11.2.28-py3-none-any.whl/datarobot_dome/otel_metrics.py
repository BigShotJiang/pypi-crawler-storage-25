#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import math
import re
from enum import Enum

from opentelemetry import metrics as otel_metrics
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.metrics import Counter
from opentelemetry.sdk.metrics import Histogram
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics import _Gauge as Gauge
from opentelemetry.sdk.metrics.export import AggregationTemporality
from opentelemetry.sdk.metrics.export import MetricExporter
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import Resource

METRIC_GROUP = "datarobot_dome"
METRIC_PREFIX = "datarobot.moderations"


class OtelMetricType(str, Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


class OtelMetricSession:
    """Container for OTEL metrics session data"""

    def __init__(self):
        self.provider = None
        self.metrics: dict[str, Counter | Gauge | Histogram] = {}

    def headers(self, otel_entity: str, api_key) -> dict[str, str]:
        """Provide headers to be included in the OTel metrics requests."""
        return {
            "X-DataRobot-Entity-Id": otel_entity,
            "X-DataRobot-Api-Key": api_key,
        }

    def custom_metric_to_otel_name(self, custom_metric: str) -> str:
        """Create an underscored_version of the provided value."""
        text = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", custom_metric)
        text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", text)
        text = re.sub(r"([^a-zA-Z0-9])+", r"_", text)
        return f"{METRIC_PREFIX}.{text.lower()}"

    def exporter(
        self, otel_endpoint: str, otel_entity: str, api_key: str, headers: dict[str, str]
    ) -> MetricExporter:
        """Create an exporter for Otel metrics.

        Generally, this will be the only implementation, except it will be overridden in testing
        to allow for checking the reported fields.
        """
        preferred_temporality = {
            Counter: AggregationTemporality.DELTA,
            Histogram: AggregationTemporality.DELTA,
            Gauge: AggregationTemporality.DELTA,
        }
        return OTLPMetricExporter(
            endpoint=otel_endpoint,
            headers=headers,
            preferred_temporality=preferred_temporality,
        )

    def initialize(self, url: str, otel_entity: str, api_key: str) -> "OtelMetricSession":
        """Builder pattern to create an Otel metrics session."""
        otel_endpoint = f"{url}/metrics"
        resource = Resource({"datarobot": "moderations"})
        # NOTE: using `math.inf` means we rely on provider flush to send messages
        headers = self.headers(otel_entity, api_key)
        exporter = self.exporter(otel_endpoint, otel_entity, api_key, headers)
        reader = PeriodicExportingMetricReader(exporter, export_interval_millis=math.inf)
        self.provider = MeterProvider(metric_readers=[reader], resource=resource)
        otel_metrics.set_meter_provider(self.provider)
        return self

    def create_metric(
        self,
        metric_type: OtelMetricType,
        name: str,
        otel_name: str = "",
        unit: str = "",
        description: str = "",
    ) -> Counter | Gauge | Histogram:
        """Create a metric with the provided information."""
        otel_name = otel_name or self.custom_metric_to_otel_name(name)
        group = self.provider.get_meter(METRIC_GROUP)
        if metric_type == OtelMetricType.COUNTER:
            metric = group.create_counter(name=otel_name, unit=unit, description=description)
        elif metric_type == OtelMetricType.GAUGE:
            metric = group.create_gauge(name=otel_name, unit=unit, description=description)
        elif metric_type == OtelMetricType.HISTOGRAM:
            metric = group.create_histogram(name=otel_name, unit=unit, description=description)
        else:
            raise ValueError(f"Unknown metric type: {metric_type}")

        self.metrics[name] = metric
        return metric

    def set_value(
        self, name: str, amount: int | float, attributes: dict[str, str] | None = None
    ) -> None:
        """Set the specified metric value based on the type."""
        metric = self.metrics[name]
        if isinstance(metric, Histogram):
            metric.record(amount=amount, attributes=attributes)
        elif isinstance(metric, Counter):
            metric.add(amount=amount, attributes=attributes)
        elif isinstance(metric, Gauge):
            metric.set(amount=amount, attributes=attributes)
        else:
            raise ValueError(f"Unknown metric type: {metric.__class__.__name__}")

    def publish_values(self) -> None:
        """Sends report with current metric data to Otel metrics endpoint."""
        self.provider.force_flush()
