#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Top-level ModerationConfig schema."""

from typing import Any
from typing import Literal
from typing import Optional

from pydantic import Field
from pydantic import model_validator

from datarobot_dome.constants import DEFAULT_GUARD_PREDICTION_TIMEOUT_IN_SEC
from datarobot_dome.constants import GuardTimeoutAction
from datarobot_dome.schema._base import _BaseSchemaAllowExtra
from datarobot_dome.schema.target_block import TargetBlock
from datarobot_dome.validation_limits import OBJECT_ID_LENGTH

_DEFAULT_TARGET = "_default"


class ModerationConfig(_BaseSchemaAllowExtra):
    """Top-level moderation configuration.

    Supports two YAML layouts:

    **Legacy flat layout** (backward-compatible) — all guards share a single
    implicit ``_default`` target:

    .. code-block:: yaml

        timeout_sec: 10
        guards:
          - name: Token Count
            type: ootb
            ootb_type: token_count
            stage: response

    **Multi-target layout** — guards are grouped under named targets, enabling
    per-entity moderation in agentic workflows:

    .. code-block:: yaml

        timeout_sec: 10
        timeout_action: score
        targets:
          - target: workflow_overall
            guards:
              - name: Token Count
                type: ootb
                ootb_type: token_count
                stage: response
          - target: tool_wikipedia_search
            guards:
              - name: Prompt Injection
                type: ootb
                ootb_type: prompt_injection
                stage: prompt
    """

    timeout_sec: int = Field(default=DEFAULT_GUARD_PREDICTION_TIMEOUT_IN_SEC, gt=1)
    timeout_action: Literal[GuardTimeoutAction.BLOCK, GuardTimeoutAction.SCORE] = Field(
        default=GuardTimeoutAction.SCORE
    )
    nemo_evaluator_deployment_id: Optional[str] = Field(default=None, max_length=OBJECT_ID_LENGTH)
    enable_extra_model_output_for_chat: bool = True
    targets: list[TargetBlock] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _normalise_legacy_guards_format(cls, data: Any) -> Any:
        """Convert the legacy flat ``guards`` key to the ``targets`` structure.

        When a config carries a top-level ``guards`` list but no ``targets``
        list, the guards are wrapped inside a single default target so that
        all downstream code can uniformly iterate over ``targets``.
        """
        if not isinstance(data, dict):
            return data
        if "guards" in data and "targets" not in data:
            data = dict(data)  # shallow copy – do not mutate caller's dict
            data["targets"] = [{"target": _DEFAULT_TARGET, "guards": data.pop("guards")}]
        return data
