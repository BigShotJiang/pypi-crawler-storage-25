#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
# isort: skip_file
"""Public schema types for building moderation pipelines from Python.

Example::

    from datarobot_dome.schema import (
        # Top-level config
        ModerationConfig,
        TargetBlock,
        # Guard subtypes (discriminated union — pick one per guard)
        GuardSchema,
        ModelGuardSchema,
        NemoEvaluatorSchema,
        NemoGuardrailsSchema,
        OOTBGuardSchema,
        # Nested schemas
        AdditionalGuardConfigSchema,
        CostMetricSchema,
        InterventionConditionSchema,
        InterventionSchema,
        ModelInfoSchema,
        NemoLLMJudgeConfigSchema,
        NemoResponseRelevancyConfigSchema,
        NemoTopicAdherenceConfigSchema,
    )
"""

# Top-level config
from datarobot_dome.schema.moderation_config import ModerationConfig
from datarobot_dome.schema.target_block import TargetBlock

# Guard subtypes (discriminated union — pick one per guard)
from datarobot_dome.schema.guards import GuardSchema
from datarobot_dome.schema.guards import ModelGuardSchema
from datarobot_dome.schema.guards import NemoEvaluatorSchema
from datarobot_dome.schema.guards import NemoGuardrailsSchema
from datarobot_dome.schema.guards import OOTBGuardSchema

# Nested schemas
from datarobot_dome.schema.guard_config import AdditionalGuardConfigSchema
from datarobot_dome.schema.guard_config import CostMetricSchema
from datarobot_dome.schema.guard_config import InterventionConditionSchema
from datarobot_dome.schema.guard_config import InterventionSchema
from datarobot_dome.schema.guard_config import ModelInfoSchema
from datarobot_dome.schema.guard_config import NemoLLMJudgeConfigSchema
from datarobot_dome.schema.guard_config import NemoResponseRelevancyConfigSchema
from datarobot_dome.schema.guard_config import NemoTopicAdherenceConfigSchema

__all__ = [
    # Top-level config
    "ModerationConfig",
    "TargetBlock",
    # Guard subtypes (discriminated union — pick one per guard)
    "GuardSchema",
    "ModelGuardSchema",
    "NemoEvaluatorSchema",
    "NemoGuardrailsSchema",
    "OOTBGuardSchema",
    # Nested schemas
    "AdditionalGuardConfigSchema",
    "CostMetricSchema",
    "InterventionConditionSchema",
    "InterventionSchema",
    "ModelInfoSchema",
    "NemoLLMJudgeConfigSchema",
    "NemoResponseRelevancyConfigSchema",
    "NemoTopicAdherenceConfigSchema",
]
