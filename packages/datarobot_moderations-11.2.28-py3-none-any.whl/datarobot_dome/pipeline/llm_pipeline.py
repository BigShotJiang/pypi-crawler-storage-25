#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import math
import os
from typing import Optional

import yaml
from typing_extensions import Self

from datarobot_dome.async_http_client import AsyncHTTPClient
from datarobot_dome.constants import CUSTOM_METRIC_DESCRIPTION_SUFFIX
from datarobot_dome.constants import DEFAULT_PROMPT_COLUMN_NAME
from datarobot_dome.constants import CustomMetricAggregationType
from datarobot_dome.constants import CustomMetricDirectionality
from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardOperatorType
from datarobot_dome.constants import GuardStage
from datarobot_dome.guard_factory import GUARD_SCHEMA_ADAPTER
from datarobot_dome.guard_factory import GuardFactory
from datarobot_dome.guard_helpers import get_rouge_1_scorer
from datarobot_dome.guards import NeMoEvaluatorGuard
from datarobot_dome.guards import NeMoLLMJudgeGuard
from datarobot_dome.otel_metrics import OtelMetricType
from datarobot_dome.pipeline.pipeline import Pipeline
from datarobot_dome.schema.moderation_config import ModerationConfig


def get_stage_str(stage):
    return "Prompts" if stage == GuardStage.PROMPT else "Responses"


def get_blocked_custom_metric(stage):
    return {
        "name": f"Blocked {get_stage_str(stage)}",
        "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
        "units": "count",
        "type": CustomMetricAggregationType.SUM,
        "baselineValue": 0,
        "isModelSpecific": True,
        "timeStep": "hour",
        "description": (
            f"Number of blocked {get_stage_str(stage)}.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
        ),
    }


def get_total_custom_metric(stage):
    return {
        "name": f"Total {get_stage_str(stage)}",
        "directionality": CustomMetricDirectionality.HIGHER_IS_BETTER,
        "units": "count",
        "type": CustomMetricAggregationType.SUM,
        "baselineValue": 0,
        "isModelSpecific": True,
        "timeStep": "hour",
        "description": (
            f"Total Number of {get_stage_str(stage)}.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
        ),
    }


prescore_guard_latency_custom_metric = {
    "name": "Prescore Guard Latency",
    "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
    "units": "seconds",
    "type": CustomMetricAggregationType.AVERAGE,
    "baselineValue": 0,
    "isModelSpecific": True,
    "timeStep": "hour",
    "description": f"Latency to execute prescore guards.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}",
}

postscore_guard_latency_custom_metric = {
    "name": "Postscore Guard Latency",
    "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
    "units": "seconds",
    "type": CustomMetricAggregationType.AVERAGE,
    "baselineValue": 0,
    "isModelSpecific": True,
    "timeStep": "hour",
    "description": f"Latency to execute postscore guards.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}",
}

score_latency = {
    "name": "LLM Score Latency",
    "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
    "units": "seconds",
    "type": CustomMetricAggregationType.AVERAGE,
    "baselineValue": 0,
    "isModelSpecific": True,
    "timeStep": "hour",
    "description": f"Latency of actual LLM Score.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}",
}


class LLMPipeline(Pipeline):
    common_message = "Custom Metrics and deployment settings will not be available"

    def __init__(self, guards_config_filename: str) -> None:
        with open(guards_config_filename) as f:
            moderation_config = ModerationConfig.model_validate(yaml.safe_load(f))
        self._setup(moderation_config, model_dir=os.path.dirname(guards_config_filename))

    @classmethod
    def from_config(cls, config: ModerationConfig, model_dir: Optional[str] = None) -> Self:
        """Create an ``LLMPipeline`` directly from a
        :class:`~datarobot_dome.schema.ModerationConfig`.

        Args:
            config: A fully-constructed ``ModerationConfig`` Pydantic object.
            model_dir: Base directory used to resolve relative asset paths (e.g. NeMo
                guardrails files).  Defaults to the current working directory.

        Returns:
            A fully initialised ``LLMPipeline`` instance.
        """
        instance: LLMPipeline = cls.__new__(cls)
        instance._setup(config, model_dir=model_dir or os.getcwd())
        return instance

    def _setup(self, moderation_config: ModerationConfig, model_dir: str) -> None:
        """Initialise pipeline state from a validated :class:`ModerationConfig`."""
        super().__init__(async_http_timeout_sec=moderation_config.timeout_sec)
        self._pre_score_guards = []
        self._post_score_guards = []
        self._prompt_column_name = None
        self._response_column_name = None
        self._custom_model_dir = model_dir

        self._modifier_guard_seen = {stage: None for stage in GuardStage.ALL}

        # Dictionary of async http clients per process - its important to maintain
        # this when moderation is running with CUSTOM_MODEL_WORKERS > 1
        self.async_http_clients = {}

        self.rouge_scorer = get_rouge_1_scorer()

        self.guard_timeout_sec = moderation_config.timeout_sec
        self.guard_timeout_action = moderation_config.timeout_action
        self.nemo_evaluator_deployment_id = moderation_config.nemo_evaluator_deployment_id
        # Fall back to the legacy key name for backward compatibility with old YAML configs.
        self.extra_model_output_for_chat_enabled = (moderation_config.model_extra or {}).get(
            "extra_model_output_for_chat_enabled",
            moderation_config.enable_extra_model_output_for_chat,
        )

        self._add_default_custom_metrics()
        legacy_guard_schemas = [
            GUARD_SCHEMA_ADAPTER.validate_python(raw)
            for raw in (moderation_config.model_extra or {}).get("guards", [])
        ]
        target_guard_schemas = [
            guard_schema for target in moderation_config.targets for guard_schema in target.guards
        ]
        for guard_schema in legacy_guard_schemas + target_guard_schemas:
            guard_config = guard_schema.model_dump(exclude_none=True)
            if isinstance(guard_config["stage"], list):
                for stage in guard_config["stage"]:
                    self._set_guard(guard_config, stage=stage)
            else:
                self._set_guard(guard_config)

        self.create_custom_metrics_if_any()
        if self._deployment:
            self._prompt_column_name = self._deployment.model.get("prompt")
            self._response_column_name = self._deployment.model["target_name"]
        self._run_llm_in_parallel_with_pre_score_guards = False

    def get_async_http_client(self):
        # For each process we create one Async HTTP Client and any requests to
        # that process will use that same client.
        pid = os.getpid()
        if pid not in self.async_http_clients:
            self.async_http_clients[pid] = AsyncHTTPClient(timeout=self.guard_timeout_sec)

        return self.async_http_clients[pid]

    def _get_average_score_metric_definition(self, guard):
        metric_definition = guard.get_average_score_metric(guard.stage)
        if not guard.intervention:
            return metric_definition

        # Set intervention threshold as metric baseline value.
        # For all other guard types, it's not possible to define baseline value
        if guard.intervention.comparator not in [
            GuardOperatorType.GREATER_THAN,
            GuardOperatorType.LESS_THAN,
        ]:
            return metric_definition
        metric_definition["baselineValue"] = guard.intervention.threshold

        # Infer metric directionality based on intervention comparator - if moderation should
        # intervene when greater than threshold, then lower is better, and vice versa.
        # User provides directionality for NeMo LLM judge guard directly, no need to infer.
        if not isinstance(guard, NeMoLLMJudgeGuard):
            if guard.intervention.comparator == GuardOperatorType.GREATER_THAN:
                metric_definition["directionality"] = CustomMetricDirectionality.LOWER_IS_BETTER
            else:
                metric_definition["directionality"] = CustomMetricDirectionality.HIGHER_IS_BETTER

        return metric_definition

    def _set_guard(self, guard_config, stage=None):
        guard = GuardFactory().create(guard_config, stage=stage, model_dir=self._custom_model_dir)

        if isinstance(guard, NeMoEvaluatorGuard):
            guard.timeout_sec = self.guard_timeout_sec
            guard.nemo_evaluator_deployment_id = self.nemo_evaluator_deployment_id

        guard_stage = stage if stage else guard.stage
        intervention_action = guard.get_intervention_action()

        if intervention_action == GuardAction.REPLACE:
            if self._modifier_guard_seen[guard_stage]:
                modifier_guard = self._modifier_guard_seen[guard_stage]
                raise ValueError(
                    "Cannot configure more than 1 modifier guards in the "
                    f"{guard_config['stage']} stage, "
                    f"guard {modifier_guard.name} already present"
                )
            else:
                self._modifier_guard_seen[guard_stage] = guard
        self._add_guard_to_pipeline(guard)
        guard.set_pipeline(self)

        if guard.has_average_score_custom_metric():
            metric_def = self._get_average_score_metric_definition(guard)
            self.add_metric_definition(metric_def, True, OtelMetricType.GAUGE)

        if guard.has_latency_custom_metric():
            metric_def = guard.get_latency_custom_metric()
            self.add_metric_definition(metric_def, False, OtelMetricType.HISTOGRAM)

        if intervention_action:
            # Enforced metric for all kinds of guards, as long as they have intervention
            # action defined - even for token count
            metric_def = guard.get_enforced_custom_metric(guard_stage, intervention_action)
            self.add_metric_definition(metric_def, True, OtelMetricType.COUNTER)

    def _add_default_custom_metrics(self):
        """Default custom metrics"""
        # These metrics do not need association id for reporting
        for metric_def, otel_type in [
            (get_total_custom_metric(GuardStage.PROMPT), OtelMetricType.COUNTER),
            (get_total_custom_metric(GuardStage.RESPONSE), OtelMetricType.COUNTER),
            (prescore_guard_latency_custom_metric, OtelMetricType.HISTOGRAM),
            (postscore_guard_latency_custom_metric, OtelMetricType.HISTOGRAM),
            (score_latency, OtelMetricType.HISTOGRAM),
        ]:
            self.add_metric_definition(metric_def, False, otel_type)

        # These metrics report with an association-id
        for metric_def in [
            get_blocked_custom_metric(GuardStage.PROMPT),
            get_blocked_custom_metric(GuardStage.RESPONSE),
        ]:
            self.add_metric_definition(metric_def, True, OtelMetricType.COUNTER)

    def _add_guard_to_pipeline(self, guard):
        if guard.stage == GuardStage.PROMPT:
            self._pre_score_guards.append(guard)
        elif guard.stage == GuardStage.RESPONSE:
            self._post_score_guards.append(guard)
        else:
            print("Ignoring invalid guard stage", guard.stage)

    def report_stage_total_inputs(self, stage, num_rows):
        metric_name = f"Total {get_stage_str(stage)}"
        self.set_otel_metric_value(metric_name, num_rows)
        self.set_custom_metrics_agg_value(metric_name, num_rows)

    def get_prescore_guards(self):
        return self._pre_score_guards

    def get_postscore_guards(self):
        return self._post_score_guards

    def report_stage_latency(self, latency_in_sec, stage):
        if stage == GuardStage.PROMPT:
            metric_name = str(prescore_guard_latency_custom_metric["name"])
        else:
            metric_name = str(postscore_guard_latency_custom_metric["name"])
        self.set_otel_metric_value(metric_name, latency_in_sec)
        self.set_custom_metrics_agg_value(metric_name, latency_in_sec)

    def report_guard_latency(self, guard, latency_in_sec):
        metric_name = guard.get_latency_custom_metric_name()
        self.set_otel_metric_value(metric_name, latency_in_sec)
        self.set_custom_metrics_agg_value(metric_name, latency_in_sec)

    def report_score_latency(self, latency_in_sec):
        metric_name = str(score_latency["name"])
        self.set_otel_metric_value(metric_name, latency_in_sec)
        self.set_custom_metrics_agg_value(metric_name, latency_in_sec)

    def get_input_column(self, stage):
        if stage == GuardStage.PROMPT:
            return (
                self._prompt_column_name if self._prompt_column_name else DEFAULT_PROMPT_COLUMN_NAME
            )
        else:
            # DRUM ensures that TARGET_NAME is always set as environment variable, but
            # TARGET_NAME comes in double quotes, remove those
            return (
                self._response_column_name
                if self._response_column_name
                else (os.environ.get("TARGET_NAME").replace('"', ""))
            )

    def get_enforced_column_name(self, guard, stage):
        input_column = self.get_input_column(stage)
        intervention_action = guard.get_intervention_action()
        if intervention_action == GuardAction.REPLACE:
            return f"{guard.name}_replaced_{input_column}"
        else:
            return f"{guard.name}_{intervention_action}ed_{input_column}"

    def get_guard_specific_custom_metric_names(self, guard):
        intervention_action = guard.get_intervention_action()
        metric_list = []
        if guard.has_average_score_custom_metric():
            metric_list = [
                (
                    guard.get_average_score_custom_metric_name(guard.stage),
                    guard.metric_column_name,
                )
            ]
        if intervention_action:
            metric_list.append(
                (
                    guard.get_guard_enforced_custom_metric_name(guard.stage, intervention_action),
                    self.get_enforced_column_name(guard, guard.stage),
                )
            )
        return metric_list

    def _add_guard_specific_custom_metrics(self, row, guards):
        if len(guards) == 0:
            return []

        association_id = row[self._association_id_column_name]

        buckets = []
        for guard in guards:
            for metric_name, column_name in self.get_guard_specific_custom_metric_names(guard):
                if column_name not in row:
                    # It is possible metric column is missing if there is exception
                    # executing the guard.  Just continue with rest
                    self._logger.warning(
                        f"Missing {column_name} in result for guard {guard.name} "
                        f"Not reporting the value with association id {association_id}"
                    )
                    continue
                if math.isnan(row[column_name]):
                    self._logger.warning(
                        f"{column_name} in result is NaN for guard {guard.name} "
                        f"Not reporting the value with association id {association_id}"
                    )
                    continue
                custom_metric_id = self.custom_metric_id_from_name(metric_name)
                if custom_metric_id is None:
                    self._logger.warning(f"No metric id for '{metric_name}', not reporting")
                    continue
                item = self.custom_metric_individual_payload(
                    custom_metric_id, row[column_name], association_id
                )
                buckets.append(item)
        return buckets

    def _get_blocked_column_name_from_result_df(self, stage):
        input_column_name = self.get_input_column(stage)
        return f"blocked_{input_column_name}"

    def _set_individual_custom_metrics_entries(self, result_df, payload):
        for index, row in result_df.iterrows():
            association_id = row[self._association_id_column_name]
            for stage in GuardStage.ALL:
                blocked_metric_name = f"Blocked {get_stage_str(stage)}"
                blocked_column_name = self._get_blocked_column_name_from_result_df(stage)
                if blocked_metric_name not in self.custom_metric_map:
                    continue
                if blocked_column_name not in result_df.columns:
                    continue
                if math.isnan(row[blocked_column_name]):
                    # If prompt is blocked, response will be NaN, so don't report it
                    continue
                custom_metric_id = self.custom_metric_id_from_name(blocked_metric_name)
                if custom_metric_id is None:
                    self._logger.warning(f"No metric id for '{blocked_metric_name}', not reporting")
                    continue
                bucket = self.custom_metric_individual_payload(
                    custom_metric_id, row[blocked_column_name], association_id
                )
                payload["buckets"].append(bucket)

            buckets = self._add_guard_specific_custom_metrics(row, self.get_prescore_guards())
            payload["buckets"].extend(buckets)
            buckets = self._add_guard_specific_custom_metrics(row, self.get_postscore_guards())
            payload["buckets"].extend(buckets)

    def report_custom_metrics_from_extra_body(
        self, association_id: str, extra_params: dict
    ) -> None:
        """
        Add any key-value pairs extracted from extra_body as custom metrics.
        The custom metrics must be deployment-based, not model-specific.
        (Bulk upload does not support heterogeneous model/non-model metrics.)
        :param association_id: Association ID of the chat request
        :param extra_params: a dict of {"name": value} for all extra_body parameters found
        """
        # If no association ID is defined for deployment, custom metrics will not be processed
        if self._association_id_column_name is None:
            return
        if not extra_params:
            return  # nothing to send
        payload = {"buckets": []}
        for name, value in extra_params.items():
            if name in self.custom_metric_map:
                # In case of name collision:
                # the extra_body metric will _not_ override the other moderation metric
                self._logger.warning(
                    "extra_body custom metric name is already in use in moderation; "
                    f"will not be sent: {name}"
                )
                continue
            if name not in self.custom_metric_names_to_ids:
                self._logger.warning(f"extra_body custom metric ID not in map: {name}")
                continue
            metric_id = self.custom_metric_names_to_ids.get(name)
            if not metric_id:
                # this should not be possible, as the name/id information
                # is taken directly from DataRobot API
                self._logger.warning(f"extra_body custom metric has missing ID: {name}")
                continue
            payload["buckets"].append(
                self.custom_metric_individual_payload(
                    metric_id=metric_id, value=value, association_id=association_id
                )
            )
        self._logger.debug(f"Sending custom metrics payload from extra_body: {payload}")
        self.upload_custom_metrics(payload)
        self.report_otel_metrics()

    def report_custom_metrics(self, result_df):
        if self.delayed_custom_metric_creation:
            # Flag is not set yet, so no point reporting custom metrics
            return

        if self._association_id_column_name is None:
            return

        payload = {"buckets": []}

        if self._association_id_column_name in result_df.columns:
            # Custom metrics are reported only if the association id column
            # is defined and is "present" in result_df
            self._set_individual_custom_metrics_entries(result_df, payload)

        # Ensure that "Total Prompts" and "Total Responses" are set properly too.
        for stage in GuardStage.ALL:
            total_name = f"Total {get_stage_str(stage)}"
            if stage == GuardStage.PROMPT:
                # If No prompt guards, then all entries are in Total Prompts
                total_value = result_df.shape[0]
                latency_name = str(prescore_guard_latency_custom_metric["name"])
            else:
                # Prompt guards might have blocked some, so remaining will be
                # Total Responses
                blocked_column_name = self._get_blocked_column_name_from_result_df(
                    GuardStage.PROMPT
                )
                total_value = result_df.shape[0] - ((result_df[blocked_column_name]).sum())
                latency_name = str(postscore_guard_latency_custom_metric["name"])

            # NOTE: do NOT set OTel metrics here... they're set elsewhere
            self.set_custom_metrics_agg_value(latency_name, 0.0, overwrite=False)
            self.set_custom_metrics_agg_value(total_name, total_value)

        payload = self.add_aggregate_metrics_to_payload(payload)
        self.upload_custom_metrics(payload)
        self.report_otel_metrics()

    async def send_event_async(self, title, message, event_type, guard_name=None, metric_name=None):
        if not self._deployment_id or self.async_http_client is None:
            return

        await self.async_http_client.async_report_event(
            title,
            message,
            event_type,
            self._deployment_id,
            guard_name=guard_name,
            metric_name=metric_name,
        )

    def agentic_metrics_configured(self):
        if len(self.get_postscore_guards()) == 0:
            # All Agentic metrics at response stage only
            return False

        for guard in self.get_postscore_guards():
            if guard.is_agentic:
                return True

        return False
