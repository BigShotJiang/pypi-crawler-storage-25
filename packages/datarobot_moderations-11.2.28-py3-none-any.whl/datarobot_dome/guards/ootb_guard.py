from __future__ import annotations

#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
from typing import TYPE_CHECKING

from datarobot_dome._import_utils import require_extra
from datarobot_dome.constants import AGENT_GOAL_ACCURACY_COLUMN_NAME
from datarobot_dome.constants import COST_COLUMN_NAME
from datarobot_dome.constants import CUSTOM_METRIC_DESCRIPTION_SUFFIX
from datarobot_dome.constants import FAITHFULLNESS_COLUMN_NAME
from datarobot_dome.constants import GUIDELINE_ADHERENCE_COLUMN_NAME
from datarobot_dome.constants import ROUGE_1_COLUMN_NAME
from datarobot_dome.constants import SPAN_PREFIX
from datarobot_dome.constants import TASK_ADHERENCE_SCORE_COLUMN_NAME
from datarobot_dome.constants import TOKEN_COUNT_COLUMN_NAME
from datarobot_dome.constants import CustomMetricAggregationType
from datarobot_dome.constants import CustomMetricDirectionality
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardStage
from datarobot_dome.constants import OOTBType

from .base import Guard
from .guard_llm_mixin import GuardLLMMixin

if TYPE_CHECKING:
    from deepeval.metrics import TaskCompletionMetric
    from llama_index.core.evaluation import FaithfulnessEvaluator
    from llama_index.core.evaluation import GuidelineEvaluator
    from ragas.metrics.collections import AgentGoalAccuracyWithoutReference


class OOTBGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self._ootb_type = config["ootb_type"]

    @property
    def ootb_type(self):
        return self._ootb_type

    def has_latency_custom_metric(self):
        """Latency is not tracked for token counts guards"""
        return self._ootb_type != OOTBType.TOKEN_COUNT

    def get_span_column_name(self, _):
        if self._ootb_type == OOTBType.TOKEN_COUNT:
            return TOKEN_COUNT_COLUMN_NAME
        elif self._ootb_type == OOTBType.ROUGE_1:
            return ROUGE_1_COLUMN_NAME
        elif self._ootb_type == OOTBType.CUSTOM_METRIC:
            return self.name
        else:
            raise NotImplementedError(f"No span attribute name defined for {self._ootb_type} guard")

    def get_span_attribute_name(self, stage):
        return f"{SPAN_PREFIX}.{stage.lower()}.{self.get_span_column_name(stage)}"


class OOTBCostMetric(OOTBGuard):
    def __init__(self, config, stage):
        super().__init__(config, stage)
        # The cost is calculated based on the usage metrics returned by the
        # completion object, so it can be evaluated only at response stage
        self._stage = GuardStage.RESPONSE
        cost_config = config["additional_guard_config"]["cost"]
        self.currency = cost_config["currency"]
        self.input_price = cost_config["input_price"]
        self.input_unit = cost_config["input_unit"]
        self.input_multiplier = self.input_price / self.input_unit
        self.output_price = cost_config["output_price"]
        self.output_unit = cost_config["output_unit"]
        self.output_multiplier = self.output_price / self.output_unit

    def get_average_score_custom_metric_name(self, _):
        return f"Total cost in {self.currency}"

    def get_average_score_metric(self, _):
        return {
            "name": self.get_average_score_custom_metric_name(_),
            "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
            "units": "value",
            "type": CustomMetricAggregationType.SUM,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_average_score_custom_metric_name(_)}. "
                f" {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def get_span_column_name(self, _):
        return f"{COST_COLUMN_NAME}.{self.currency.lower()}"

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBFaithfulnessGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Faithfulness cannot be configured for the Prompt stage")

        # Default LLM Type for Faithfulness is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)

        try:
            from llama_index.core import Settings
            from llama_index.core.evaluation import FaithfulnessEvaluator
        except ImportError as e:
            raise require_extra("llama-index-core", "llm-eval", e)

        try:
            from langchain_openai import AzureChatOpenAI
            from langchain_openai import ChatOpenAI
        except ImportError as e:
            raise require_extra("langchain-openai", "llm-eval", e)

        try:
            from llama_index.llms.langchain import LangChainLLM
        except ImportError as e:
            raise require_extra("llama-index-llms-langchain", "llm-eval", e)

        if isinstance(llm, AzureChatOpenAI) or isinstance(llm, ChatOpenAI):
            llm = LangChainLLM(llm=llm)

        Settings.llm = llm
        Settings.embed_model = None
        self._evaluator = FaithfulnessEvaluator()

    @property
    def faithfulness_evaluator(self) -> FaithfulnessEvaluator:
        return self._evaluator

    def get_span_column_name(self, _):
        return FAITHFULLNESS_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBAgentGoalAccuracyGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Agent Goal Accuracy guard cannot be configured for the Prompt stage")

        # Default LLM Type for Agent Goal Accuracy is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)

        try:
            from ragas.metrics.collections import AgentGoalAccuracyWithoutReference
        except ImportError as e:
            raise require_extra("ragas", "llm-eval", e)

        evaluator_llm = self._build_evaluator_llm(config)
        self.scorer = AgentGoalAccuracyWithoutReference(llm=evaluator_llm)

    def _build_evaluator_llm(self, config):
        """Build a ragas InstructorLLM for AgentGoalAccuracy evaluation.

        ragas >= 0.4 CollectionMetrics exclusively accept an ``InstructorLLM``
        produced by ``llm_factory()``, which requires an OpenAI SDK async client.
        """
        try:
            from ragas.llms import llm_factory
        except ImportError as e:
            raise require_extra("ragas", "llm-eval", e)

        try:
            from langchain_openai import AzureChatOpenAI
            from langchain_openai import ChatOpenAI
        except ImportError as e:
            raise require_extra("langchain-openai", "llm-eval", e)

        llm = self.get_llm(config, self._llm_type)

        if isinstance(llm, (AzureChatOpenAI, ChatOpenAI)):
            return llm_factory(model=llm.model_name, client=llm.async_client._client)

        if self._llm_type == GuardLLMType.OPENAI:
            from openai import AsyncOpenAI

            openai_api_key = self.get_openai_api_key(config, GuardLLMType.OPENAI)
            return llm_factory(
                model=config.get("openai_deployment_id") or "gpt-4o-mini",
                client=AsyncOpenAI(api_key=openai_api_key),
            )

        raise ValueError(
            f"{type(llm).__name__} is not supported by the Agent Goal Accuracy guard. "
        )

    @property
    def accuracy_scorer(self) -> AgentGoalAccuracyWithoutReference:
        return self.scorer

    def get_span_column_name(self, _):
        return AGENT_GOAL_ACCURACY_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBTaskAdherenceGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Agent Goal Accuracy guard cannot be configured for the Prompt stage")

        # Default LLM Type for Task Adherence is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)

        try:
            from datarobot_dome._deepeval_adapter import ModerationDeepEvalLLM
        except ImportError as e:
            raise require_extra("deepeval", "llm-eval", e)
        try:
            from deepeval.metrics import TaskCompletionMetric
        except ImportError as e:
            raise require_extra("deepeval", "llm-eval", e)

        deepeval_llm = ModerationDeepEvalLLM(llm)
        self.scorer = TaskCompletionMetric(model=deepeval_llm, include_reason=True)

    @property
    def task_adherence_scorer(self) -> TaskCompletionMetric:
        return self.scorer

    def get_span_column_name(self, _):
        return TASK_ADHERENCE_SCORE_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBAgentGuidelineAdherence(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception(
                "Agent Guideline Adherence guard cannot be configured for the Prompt stage"
            )

        self.guideline = config.get("additional_guard_config", {}).get("agent_guideline")
        if self.guideline is None or len(self.guideline) == 0:
            raise Exception("Agent Guideline Adherence requires at least one guideline.")

        # Default LLM Type for Guideline Adherence is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)

        try:
            from langchain_openai import AzureChatOpenAI
            from langchain_openai import ChatOpenAI
        except ImportError as e:
            raise require_extra("langchain-openai", "llm-eval", e)
        try:
            from llama_index.core.evaluation import GuidelineEvaluator
            from llama_index.core.evaluation.guideline import EvaluationData
            from llama_index.core.output_parsers import PydanticOutputParser
        except ImportError as e:
            raise require_extra("llama-index-core", "llm-eval", e)
        try:
            from llama_index.llms.langchain import LangChainLLM
        except ImportError as e:
            raise require_extra("llama-index-llms-langchain", "llm-eval", e)

        if isinstance(llm, AzureChatOpenAI) or isinstance(llm, ChatOpenAI):
            llm = LangChainLLM(llm=llm)

        # llama_index bug: PydanticOutputParser.format() uses escape_json=True,
        # sending doubled braces ({{ }}) to the LLM, which echoes them back,
        # producing JSON that fails model_validate_json().  Fix: escape_json=False.
        class _FixedPydanticOutputParser(PydanticOutputParser):
            def format(self, query: str) -> str:
                return query + "\n\n" + self.get_format_string(escape_json=False)

        self.scorer = GuidelineEvaluator(
            llm=llm,
            guidelines=self.guideline,
            output_parser=_FixedPydanticOutputParser(output_cls=EvaluationData),
        )

    @property
    def guideline_adherence_scorer(self) -> GuidelineEvaluator:
        return self.scorer

    def get_span_column_name(self, _):
        return GUIDELINE_ADHERENCE_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"
