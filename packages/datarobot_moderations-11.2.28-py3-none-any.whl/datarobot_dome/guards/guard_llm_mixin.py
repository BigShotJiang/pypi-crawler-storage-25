#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import json
import os
from typing import Annotated
from typing import Literal
from typing import Union

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from pydantic import field_validator

from datarobot_dome._import_utils import require_extra
from datarobot_dome.constants import AWS_ACCOUNT_SECRET_DEFINITION_SUFFIX
from datarobot_dome.constants import GOOGLE_SERVICE_ACCOUNT_SECRET_DEFINITION_SUFFIX
from datarobot_dome.constants import OPENAI_SECRET_DEFINITION_SUFFIX
from datarobot_dome.constants import SECRET_DEFINITION_PREFIX
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardType
from datarobot_dome.constants import OOTBType
from datarobot_dome.guard_helpers import DEFAULT_OPEN_AI_API_VERSION
from datarobot_dome.guard_helpers import get_azure_openai_client
from datarobot_dome.guard_helpers import get_bedrock_client
from datarobot_dome.guard_helpers import get_datarobot_llm
from datarobot_dome.guard_helpers import get_llm_gateway_client
from datarobot_dome.guard_helpers import get_vertex_client
from datarobot_dome.guard_helpers import use_llm_gateway_inference


class _CredentialBase(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class _BasicCredential(_CredentialBase):
    credential_type: Literal["basic"] = Field(alias="credentialType")
    password: str


class _ApiTokenCredential(_CredentialBase):
    credential_type: Literal["api_token"] = Field(alias="credentialType")
    api_token: str = Field(alias="apiToken")


class _GcpCredential(_CredentialBase):
    credential_type: Literal["gcp"] = Field(alias="credentialType")
    gcp_key: dict = Field(alias="gcpKey")


class _S3Credential(_CredentialBase):
    credential_type: Literal["s3"] = Field(alias="credentialType")
    aws_access_key_id: str = Field(alias="awsAccessKeyId")
    aws_secret_access_key: str = Field(alias="awsSecretAccessKey")
    aws_session_token: str | None = Field(default=None, alias="awsSessionToken")


class _CredentialWrapper(BaseModel):
    type: Literal["credential"]
    payload: Annotated[
        Union[_BasicCredential, _ApiTokenCredential, _GcpCredential, _S3Credential],
        Field(discriminator="credential_type"),
    ]

    @field_validator("payload", mode="before")
    @classmethod
    def coerce_string_payload(cls, v: object) -> object:
        """Decode a string payload to a credential dict.

        Handles two forms of string payload that both cause a validation error
        without this coercion:
        - JSON-encoded credential (double-encoded env var): decoded via json.loads.
        - Bare API key string: wrapped as an api_token credential dict.
        """
        if not isinstance(v, str):
            return v
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            return {"credentialType": "api_token", "apiToken": v}


def _load_credential(env_var_name: str) -> _CredentialWrapper:
    return _CredentialWrapper.model_validate(json.loads(os.environ[env_var_name]))


class GuardLLMMixin:
    def get_secret_env_var_base(self, config, llm_type_str):
        guard_type = config["type"]
        guard_stage = config["stage"]
        secret_env_var_name_prefix = f"{SECRET_DEFINITION_PREFIX}_{guard_type}_{guard_stage}_"
        if guard_type == GuardType.NEMO_GUARDRAILS:
            return f"{secret_env_var_name_prefix}{llm_type_str}"
        elif guard_type == GuardType.OOTB:
            if config["ootb_type"] == OOTBType.FAITHFULNESS:
                return f"{secret_env_var_name_prefix}{OOTBType.FAITHFULNESS}_{llm_type_str}"
            elif config["ootb_type"] == OOTBType.AGENT_GOAL_ACCURACY:
                return f"{secret_env_var_name_prefix}{OOTBType.AGENT_GOAL_ACCURACY}_{llm_type_str}"
            elif config["ootb_type"] == OOTBType.TASK_ADHERENCE:
                return f"{secret_env_var_name_prefix}{OOTBType.TASK_ADHERENCE}_{llm_type_str}"
            elif config["ootb_type"] == OOTBType.GUIDELINE_ADHERENCE:
                return f"{secret_env_var_name_prefix}{OOTBType.GUIDELINE_ADHERENCE}_{llm_type_str}"
            raise Exception("Invalid guard config for building env var name")
        raise Exception("Invalid guard config for building env var name")

    def build_open_ai_api_key_env_var_name(self, config, llm_type):
        llm_type_str = ""
        if llm_type == GuardLLMType.AZURE_OPENAI:
            llm_type_str = "AZURE_"
        elif llm_type == GuardLLMType.NIM:
            llm_type_str = "NIM_"
        var_name = self.get_secret_env_var_base(config, llm_type_str)
        var_name += OPENAI_SECRET_DEFINITION_SUFFIX
        return var_name.upper()

    def get_openai_api_key(self, config, llm_type):
        api_key_env_var_name = self.build_open_ai_api_key_env_var_name(config, llm_type)
        if api_key_env_var_name not in os.environ:
            if llm_type == GuardLLMType.NIM:
                return None
            raise Exception(f"Expected environment variable '{api_key_env_var_name}' not found")

        credential_config = _load_credential(api_key_env_var_name)
        if isinstance(credential_config.payload, _BasicCredential):
            return credential_config.payload.password
        return credential_config.payload.api_token

    def get_google_service_account(self, config):
        service_account_env_var_name = self.get_secret_env_var_base(
            config, GOOGLE_SERVICE_ACCOUNT_SECRET_DEFINITION_SUFFIX
        ).upper()
        if service_account_env_var_name not in os.environ:
            raise Exception(
                f"Expected environment variable '{service_account_env_var_name}' not found"
            )

        credential_config = _load_credential(service_account_env_var_name)
        if isinstance(credential_config.payload, _GcpCredential):
            return credential_config.payload.gcp_key
        raise Exception("Google model requires a credential of type 'gcp'")

    def get_aws_account(self, config):
        service_account_env_var_name = self.get_secret_env_var_base(
            config, AWS_ACCOUNT_SECRET_DEFINITION_SUFFIX
        ).upper()
        if service_account_env_var_name not in os.environ:
            raise Exception(
                f"Expected environment variable '{service_account_env_var_name}' not found"
            )

        credential_config = _load_credential(service_account_env_var_name)
        if isinstance(credential_config.payload, _S3Credential):
            return credential_config.payload.model_dump()
        raise Exception("Amazon model requires a credential of type 's3'")

    def get_llm(self, config, llm_type):
        openai_api_base = config.get("openai_api_base")
        openai_deployment_id = config.get("openai_deployment_id")
        llm_id = None
        credentials = None
        use_llm_gateway = use_llm_gateway_inference(llm_type)
        try:
            if llm_type in [GuardLLMType.OPENAI, GuardLLMType.AZURE_OPENAI]:
                openai_api_key = self.get_openai_api_key(config, llm_type)
                if openai_api_key is None:
                    raise ValueError("OpenAI API key is required for Faithfulness guard")

                if llm_type == GuardLLMType.OPENAI:
                    credentials = {
                        "credential_type": "openai",
                        "api_key": openai_api_key,
                    }
                    os.environ["OPENAI_API_KEY"] = openai_api_key
                    try:
                        from llama_index.llms.openai import OpenAI
                    except ImportError as e:
                        raise require_extra("llama-index-llms-openai", "llm-eval", e)
                    llm = OpenAI()
                elif llm_type == GuardLLMType.AZURE_OPENAI:
                    if openai_api_base is None:
                        raise ValueError("OpenAI API base url is required for LLM Guard")
                    if openai_deployment_id is None:
                        raise ValueError("OpenAI deployment ID is required for LLM Guard")
                    credentials = {
                        "credential_type": "azure_openai",
                        "api_key": openai_api_key,
                        "api_base": openai_api_base,
                        "api_version": DEFAULT_OPEN_AI_API_VERSION,
                    }
                    azure_openai_client = get_azure_openai_client(
                        openai_api_key=openai_api_key,
                        openai_api_base=openai_api_base,
                        openai_deployment_id=openai_deployment_id,
                    )
                    llm = azure_openai_client
            elif llm_type == GuardLLMType.GOOGLE:
                llm_id = config["google_model"]
                if llm_id is None:
                    raise ValueError("Google model is required for LLM Guard")
                if config.get("google_region") is None:
                    raise ValueError("Google region is required for LLM Guard")
                service_account_info = self.get_google_service_account(config)
                credentials = {
                    "credential_type": "google_vertex_ai",
                    "region": config["google_region"],
                    "service_account_info": service_account_info,
                }
                llm = get_vertex_client(
                    google_model=llm_id,
                    google_service_account=service_account_info,
                    google_region=config["google_region"],
                )
            elif llm_type == GuardLLMType.AMAZON:
                llm_id = config["aws_model"]
                if llm_id is None:
                    raise ValueError("AWS model is required for LLM Guard")
                if config.get("aws_region") is None:
                    raise ValueError("AWS region is required for LLM Guard")
                credential_config = self.get_aws_account(config)
                credentials = {
                    "credential_type": "amazon_bedrock",
                    "access_key_id": credential_config["aws_access_key_id"],
                    "secret_access_key": credential_config["aws_secret_access_key"],
                    "session_token": credential_config["aws_session_token"],
                    "region": config["aws_region"],
                }
                llm = get_bedrock_client(
                    aws_model=llm_id,
                    aws_access_key_id=credential_config["aws_access_key_id"],
                    aws_secret_access_key=credential_config["aws_secret_access_key"],
                    aws_session_token=credential_config["aws_session_token"],
                    aws_region=config["aws_region"],
                )
            elif llm_type == GuardLLMType.DATAROBOT:
                try:
                    import datarobot as dr
                except ImportError as e:
                    raise require_extra("datarobot", "datarobot-sdk", e)
                if config.get("deployment_id") is None:
                    raise ValueError("Deployment ID is required for LLM Guard")
                deployment = dr.Deployment.get(config["deployment_id"])
                llm = get_datarobot_llm(deployment)
            elif llm_type == GuardLLMType.NIM:
                raise NotImplementedError
            elif llm_type == GuardLLMType.LLM_GATEWAY:
                # Gateway client is built unconditionally below in the use_llm_gateway block.
                pass
            else:
                raise ValueError(f"Invalid LLMType: {llm_type}")

        except Exception as e:
            # no valid user credentials provided, raise if not using LLM Gateway
            credentials = None
            if not use_llm_gateway:
                raise e

        if use_llm_gateway:
            # For Bedrock and Vertex the model in the config is actually the LLM ID
            # For OpenAI we use the default model defined in get_llm_gateway_client
            # For Azure we use the deployment ID
            # For explicit llmGateway type we use llm_gateway_model_id from the config.
            llm = get_llm_gateway_client(
                model=config.get("llm_gateway_model_id"),
                llm_id=llm_id,
                openai_deployment_id=openai_deployment_id,
                credentials=credentials,
            )

        return llm
