#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Guard configuration validation utilities.

All structural validation is handled by the Pydantic schemas in
``datarobot_dome.schema``.  This module retains only:

* The :func:`validate_config_nemo_evaluator` helper for cross-field
  business-rule checks on NeMo Evaluator guards.
* A re-export of :data:`~datarobot_dome.validation_limits.MAX_GUARD_MESSAGE_LENGTH`
  for backward-compatibility with existing import sites.
"""

from datarobot_dome.constants import NemoEvaluatorType
from datarobot_dome.validation_limits import (
    MAX_GUARD_MESSAGE_LENGTH as MAX_GUARD_MESSAGE_LENGTH,  # noqa: PLC0414
)


def validate_config_nemo_evaluator(config: dict):
    nemo_evaluator_type = config.get("nemo_evaluator_type")
    if not nemo_evaluator_type:
        raise ValueError("nemo_evaluator_type is required for NeMo Evaluator guard")
    if nemo_evaluator_type == NemoEvaluatorType.LLM_JUDGE and "nemo_llm_judge_config" not in config:
        raise ValueError("nemo_llm_judge_config is required for LLM judge NeMo Evaluator guard")
    if (
        nemo_evaluator_type == NemoEvaluatorType.TOPIC_ADHERENCE
        and "nemo_topic_adherence_config" not in config
    ):
        raise ValueError(
            "nemo_topic_adherence_config is required for Topic Adherence NeMo Evaluator guard"
        )
    if (
        nemo_evaluator_type == NemoEvaluatorType.RESPONSE_RELEVANCY
        and "nemo_response_relevancy_config" not in config
    ):
        raise ValueError(
            "nemo_response_relevancy_config is required for Response Relevancy NeMo Evaluator guard"
        )
