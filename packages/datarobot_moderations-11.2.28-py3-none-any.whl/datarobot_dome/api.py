#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""
Public standalone API for the DataRobot Moderation Library.

Entity-agnostic moderation interface designed to work with any Python application:
applications, workloads, generic/graph artifacts, notebooks, or custom code.

Example Usage:
-------------
    from datarobot_dome.api import ModerationPipeline

    # From a YAML configuration file
    pipeline = ModerationPipeline.from_yaml("moderation_config.yaml")

    # From a plain Python dictionary (same schema as YAML)
    pipeline = ModerationPipeline.from_dict({
        "targets": [
            {
                "target": "_default",
                "guards": [
                    {
                        "name": "Token Count",
                        "type": "ootb",
                        "ootb_type": "token_count",
                        "stage": "prompt",
                    },
                ],
            }
        ]
    })

    # From a Pydantic ModerationConfig object
    from datarobot_dome.schema import ModerationConfig, OOTBGuardSchema, TargetBlock
    config = ModerationConfig(
        targets=[
            TargetBlock(
                target="_default",
                guards=[
                    OOTBGuardSchema(
                        name="Token Count", stage="prompt", ootb_type="token_count"
                    )
                ],
            )
        ]
    )
    pipeline = ModerationPipeline.from_config(config)

    # Evaluate a prompt
    result, latency = pipeline.evaluate_prompt("Hello")

    # Evaluate a response
    result, latency = pipeline.evaluate_response("Paris.", prompt="What is the capital?")

    # Full pipeline with LLM
    def my_llm(prompt: str) -> str:
        return call_openai(prompt)

    result = pipeline.evaluate_full_pipeline("Hello", my_llm)
    if not result.blocked:
        print(result.response)
"""

import logging
import os
import ssl
import urllib.error
import urllib.request
from typing import Any
from typing import Callable
from typing import Optional

import certifi
import pandas as pd
from pydantic import BaseModel
from pydantic import Field
from pydantic import computed_field
from pydantic import model_validator
from typing_extensions import Self

from datarobot_dome.constants import AGENTIC_PIPELINE_INTERACTIONS_ATTR
from datarobot_dome.constants import LOGGER_NAME_PREFIX
from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardStage
from datarobot_dome.guard_executor import AsyncGuardExecutor
from datarobot_dome.pipeline.llm_pipeline import LLMPipeline
from datarobot_dome.schema import ModerationConfig

_logger = logging.getLogger(LOGGER_NAME_PREFIX + ".api")

_SSL_CTX = ssl.create_default_context()
_SSL_CTX.load_verify_locations(cafile=certifi.where())


def _verify_datarobot_credentials() -> None:
    """Verify DataRobot credentials by calling /account/info/.

    Raises RuntimeError if credentials are missing, the token is invalid,
    or the endpoint is unreachable.
    """
    endpoint = os.environ.get("DATAROBOT_ENDPOINT", "").rstrip("/")
    token = os.environ.get("DATAROBOT_API_TOKEN", "")

    if not endpoint or not token:
        raise RuntimeError(
            "DataRobot credentials are required.\n"
            "Set DATAROBOT_ENDPOINT and DATAROBOT_API_TOKEN before calling from_yaml()."
        )

    url = f"{endpoint}/account/info/"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(req, timeout=10, context=_SSL_CTX):
            pass  # 200 OK — token is valid
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise RuntimeError(
                "DataRobot credential validation failed: the API token is invalid or expired.\n"
                "Check your DATAROBOT_API_TOKEN."
            ) from exc
        raise RuntimeError(
            f"DataRobot credential validation failed: HTTP {exc.code} from {endpoint}."
        ) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(
            f"DataRobot credential validation failed: cannot reach {endpoint}.\n"
            f"Cause: {exc.reason}\n"
            "Check your DATAROBOT_ENDPOINT and VPN/network connectivity."
        ) from exc


class EvaluationResult(BaseModel):
    """Evaluation result for a single text (prompt or response)."""

    blocked: bool
    blocked_message: Optional[str] = None
    replaced: bool = False
    replacement: Optional[str] = None
    metrics: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _replacement_invariant(self) -> "EvaluationResult":
        """Enforce: replaced=True is only valid when replacement text exists.

        _str_or_none maps empty strings and NaN to None. If the executor sets
        replaced=True but writes an empty replacement, the result would be
        replaced=True / replacement=None — an inconsistent state that causes
        llm_callable(None) to crash in evaluate_full_pipeline. Reset replaced
        to False whenever there is no actual replacement text.
        """
        if self.replaced and self.replacement is None:
            self.replaced = False
        return self


class PipelineResult(BaseModel):
    """Full pipeline result for a single input: prescore + LLM + postscore."""

    prompt_evaluation: EvaluationResult
    response: Optional[str] = None
    response_evaluation: Optional[EvaluationResult] = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def blocked(self) -> bool:
        """True if either the prompt or the response was blocked."""
        if self.prompt_evaluation.blocked:
            return True
        return bool(self.response_evaluation and self.response_evaluation.blocked)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def replaced(self) -> bool:
        """True if either the prompt or the response was replaced by a guard."""
        if self.prompt_evaluation.replaced:
            return True
        return bool(self.response_evaluation and self.response_evaluation.replaced)


# ── module-level helpers ─────────────


def _to_dataframe(text: str, column: str) -> pd.DataFrame:
    return pd.DataFrame({column: [text]})


def _internal_columns(column: str) -> frozenset[str]:
    """All column names the guard executor writes for infrastructure tracking.

    These are implementation details of the executor and must never appear
    in the user-facing metrics dict.
    """
    return frozenset(
        {
            column,  # the original input text
            f"action_{column}",  # which action was taken
            f"blocked_message_{column}",  # block reason
            f"replaced_message_{column}",  # replacement reason
            f"{GuardAction.NONE}ed_{column}",  # "Noneed_{column}" — None action sentinel
            *GuardAction.possible_column_names(column),  # blocked_, reported_, replaced_
        }
    )


def _str_or_none(value: Any) -> Optional[str]:
    """Convert a scalar to str, returning None for null-like values or empty strings.

    Calling str() before a null check converts None → "None" and np.nan → "nan",
    both of which are truthy and would be returned as real messages. pd.isna()
    catches all pandas null sentinels before the conversion happens.
    """
    if pd.isna(value):
        return None
    return str(value) or None


def _from_dataframe(
    df: pd.DataFrame,
    column: str,
    context_columns: frozenset[str] = frozenset(),
) -> EvaluationResult:
    row = df.iloc[0]
    internal = _internal_columns(column) | context_columns
    metrics = {
        str(k): v for k, v in row.items() if k not in internal and not str(k).endswith("_latency")
    }
    return EvaluationResult(
        blocked=bool(row.get(f"blocked_{column}", False)),
        blocked_message=_str_or_none(row.get(f"blocked_message_{column}")),
        replaced=bool(row.get(f"replaced_{column}", False)),
        replacement=_str_or_none(row.get(f"replaced_message_{column}")),
        metrics=metrics,
    )


def _empty_result() -> EvaluationResult:
    return EvaluationResult(blocked=False)


# ── public API ───────────────────────────────────────────────────────────────


class ModerationPipeline:
    """
    Entity-agnostic moderation pipeline for evaluating prompts and responses.

    Standalone API for moderation without DRUM dependencies. Can be used in
    notebooks, applications, workloads, or any custom Python environment.
    """

    def __init__(self, pipeline: LLMPipeline):
        """Initialize ModerationPipeline with an LLMPipeline instance."""
        self._pipeline = pipeline
        self._executor = AsyncGuardExecutor(pipeline)

    @classmethod
    def from_yaml(cls, config_path: str) -> Self:
        """
        Create a ModerationPipeline from a YAML configuration file.

        Validates DataRobot credentials (DATAROBOT_ENDPOINT and DATAROBOT_API_TOKEN)
        before initialising the pipeline.

        Example:
            pipeline = ModerationPipeline.from_yaml("moderation_config.yaml")
        """
        _verify_datarobot_credentials()
        return cls(LLMPipeline(config_path))

    @classmethod
    def from_dict(
        cls,
        config: dict[str, Any],
        model_dir: Optional[str] = None,
    ) -> Self:
        """
        Create a ModerationPipeline from a plain Python dictionary.

        The dictionary must follow the same schema as the YAML configuration.
        Validates DataRobot credentials (DATAROBOT_ENDPOINT and DATAROBOT_API_TOKEN)
        before initialising the pipeline.

        Args:
            config: A dictionary representing the moderation configuration.
            model_dir: Base directory used to resolve relative asset paths (e.g. NeMo
                guardrails files).  Defaults to the current working directory.
        """
        _verify_datarobot_credentials()
        return cls(
            LLMPipeline.from_config(
                ModerationConfig.model_validate(config),
                model_dir=model_dir,
            )
        )

    @classmethod
    def from_config(
        cls,
        config: ModerationConfig,
        model_dir: Optional[str] = None,
    ) -> Self:
        """
        Create a ModerationPipeline from a :class:`~datarobot_dome.schema.ModerationConfig`.

        Validates DataRobot credentials (DATAROBOT_ENDPOINT and DATAROBOT_API_TOKEN)
        before initialising the pipeline.

        Args:
            config: A fully-constructed ``ModerationConfig`` Pydantic object.
            model_dir: Base directory used to resolve relative asset paths (e.g. NeMo
                guardrails files).  Defaults to the current working directory.
        """
        _verify_datarobot_credentials()
        return cls(LLMPipeline.from_config(config, model_dir=model_dir))

    def _run_stage(
        self,
        df: pd.DataFrame,
        column: str,
        guards: list,
        stage: str,
        context_columns: frozenset[str] = frozenset(),
    ) -> tuple[EvaluationResult, float]:
        """Run a set of guards against a pre-built DataFrame and parse the result."""
        if not guards:
            return _empty_result(), 0.0
        result_df, latency = self._executor.run_guards(df, guards, stage)
        return _from_dataframe(result_df, column, context_columns), latency

    def evaluate_prompt(self, prompt: str) -> tuple[EvaluationResult, float]:
        """
        Evaluate a prompt using prescore guards.

        Returns an EvaluationResult and guard latency in seconds.

        Example:
            result, latency = pipeline.evaluate_prompt("Hello")
            if result.blocked:
                print(result.blocked_message)
        """
        column = self._pipeline.get_input_column(GuardStage.PROMPT)
        return self._run_stage(
            _to_dataframe(prompt, column),
            column,
            self._pipeline.get_prescore_guards(),
            GuardStage.PROMPT,
        )

    def evaluate_response(
        self,
        response: str,
        prompt: Optional[str] = None,
    ) -> tuple[EvaluationResult, float]:
        """
        Evaluate a response using postscore guards.

        Returns an EvaluationResult and guard latency in seconds.

        Example:
            result, latency = pipeline.evaluate_response(
                "Paris.", prompt="What is the capital of France?"
            )
        """
        response_col = self._pipeline.get_input_column(GuardStage.RESPONSE)
        df = _to_dataframe(response, response_col)

        context_columns: frozenset[str] = frozenset()
        if prompt is not None:
            prompt_col = self._pipeline.get_input_column(GuardStage.PROMPT)
            if prompt_col not in df.columns:
                df[prompt_col] = [prompt]
            context_columns = frozenset({prompt_col})

        # TASK_ADHERENCE and AGENT_GOAL_ACCURACY always require this column in the
        # executor, even though both guard functions handle None gracefully.
        if AGENTIC_PIPELINE_INTERACTIONS_ATTR not in df.columns:
            df[AGENTIC_PIPELINE_INTERACTIONS_ATTR] = [None]
            context_columns = context_columns | frozenset({AGENTIC_PIPELINE_INTERACTIONS_ATTR})

        return self._run_stage(
            df,
            response_col,
            self._pipeline.get_postscore_guards(),
            GuardStage.RESPONSE,
            context_columns,
        )

    def evaluate_full_pipeline(
        self,
        prompt: str,
        llm_callable: Callable[[str], str],
    ) -> PipelineResult:
        """
        Execute the full moderation pipeline: prescore → LLM → postscore.

        The prompt is evaluated first. If blocked, the LLM is never called.
        If a REPLACE guard fires on the prompt, the sanitised replacement is
        sent to the LLM instead of the original. If a REPLACE guard fires on
        the response, the sanitised replacement is surfaced in PipelineResult.

        Example:
            def my_llm(prompt: str) -> str:
                return call_openai(prompt)

            result = pipeline.evaluate_full_pipeline("Hello", my_llm)
            if not result.blocked:
                print(result.response)
        """
        prompt_result, _ = self.evaluate_prompt(prompt)
        if prompt_result.blocked:
            return PipelineResult(prompt_evaluation=prompt_result)

        effective_prompt = prompt_result.replacement if prompt_result.replaced else prompt

        try:
            response = llm_callable(effective_prompt)
        except Exception as e:
            _logger.error("LLM callable failed: %s", e)
            raise RuntimeError(f"Failed to call LLM function: {e}") from e

        response_result, _ = self.evaluate_response(response, effective_prompt)
        effective_response = response_result.replacement if response_result.replaced else response
        return PipelineResult(
            prompt_evaluation=prompt_result,
            response=effective_response,
            response_evaluation=response_result,
        )
