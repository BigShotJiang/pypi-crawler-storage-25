"""Unit tests for Slack, HubSpot, and GitHub Actions destinations.

Uses pytest-httpserver to spin up a local HTTP server — no mocking.
"""

from __future__ import annotations

import pytest
from pytest_httpserver import HTTPServer

from drt.config.models import (
    BearerAuth,
    DiscordDestinationConfig,
    GitHubActionsDestinationConfig,
    HubSpotDestinationConfig,
    NotionDestinationConfig,
    RetryConfig,
    SlackDestinationConfig,
    SyncOptions,
)
from drt.destinations.discord import DiscordDestination
from drt.destinations.github_actions import GitHubActionsDestination
from drt.destinations.hubspot import HubSpotDestination
from drt.destinations.notion import NotionDestination
from drt.destinations.slack import SlackDestination

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _options() -> SyncOptions:
    return SyncOptions()


# ---------------------------------------------------------------------------
# SlackDestination
# ---------------------------------------------------------------------------


class TestSlackDestination:
    def test_success(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/webhook").respond_with_data("ok", status=200)
        config = SlackDestinationConfig(
            type="slack",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="hello {{ row.name }}",
        )
        result = SlackDestination().load([{"name": "Alice"}], config, _options())
        assert result.success == 1
        assert result.failed == 0

    def test_on_error_skip(self, httpserver: HTTPServer) -> None:
        httpserver.expect_ordered_request("/webhook").respond_with_data("", status=500)
        httpserver.expect_ordered_request("/webhook").respond_with_data("ok", status=200)
        config = SlackDestinationConfig(
            type="slack",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="{{ row.msg }}",
        )
        opts = SyncOptions(on_error="skip")
        result = SlackDestination().load([{"msg": "a"}, {"msg": "b"}], config, opts)
        assert result.failed == 1
        assert result.success == 1

    def test_missing_webhook_raises(self) -> None:
        config = SlackDestinationConfig(type="slack", message_template="hi")
        with pytest.raises(ValueError, match="webhook_url"):
            SlackDestination().load([{"x": 1}], config, _options())

    def test_block_kit_payload(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/webhook").respond_with_data("ok", status=200)
        config = SlackDestinationConfig(
            type="slack",
            webhook_url=httpserver.url_for("/webhook"),
            block_kit=True,
            message_template=(
                '{"blocks": [{"type": "section",'
                ' "text": {"type": "mrkdwn", "text": "{{ row.msg }}"}}]}'
            ),
        )
        result = SlackDestination().load([{"msg": "hello"}], config, _options())
        assert result.success == 1

    def test_destination_retry_overrides_sync_retry(
        self, httpserver: HTTPServer
    ) -> None:
        """destination.retry > sync.retry (#277)."""
        from werkzeug.wrappers import Response

        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response("upstream busy", status=503)

        httpserver.expect_request("/webhook").respond_with_handler(handler)
        config = SlackDestinationConfig(
            type="slack",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="hi",
            retry=RetryConfig(
                max_attempts=4,
                initial_backoff=0.0,
                backoff_multiplier=1.0,
                max_backoff=0.0,
            ),
        )
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=2,
                initial_backoff=0.0,
                backoff_multiplier=1.0,
                max_backoff=0.0,
            ),
            on_error="skip",
        )
        SlackDestination().load([{"msg": "x"}], config, opts)
        assert call_count["n"] == 4

    def test_on_error_fail_stops_after_first_failure(
        self, httpserver: HTTPServer
    ) -> None:
        """on_error=fail stops batch processing after first failure (#365)."""
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            from werkzeug.wrappers import Response
            call_count["n"] += 1
            return Response("", status=500)

        httpserver.expect_request("/webhook").respond_with_handler(handler)
        config = SlackDestinationConfig(
            type="slack",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="{{ row.msg }}",
            retry=RetryConfig(
                max_attempts=1, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        opts = SyncOptions(on_error="fail")
        result = SlackDestination().load(
            [{"msg": "a"}, {"msg": "b"}, {"msg": "c"}], config, opts
        )
        assert result.failed == 1
        assert result.success == 0
        assert call_count["n"] == 1  # Second and third rows not attempted


# ---------------------------------------------------------------------------
# DiscordDestination
# ---------------------------------------------------------------------------


class TestDiscordDestination:
    def test_success(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/webhook").respond_with_data("ok", status=200)
        config = DiscordDestinationConfig(
            type="discord",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="hello {{ row.name }}",
        )
        result = DiscordDestination().load([{"name": "Alice"}], config, _options())
        assert result.success == 1
        assert result.failed == 0

    def test_on_error_skip(self, httpserver: HTTPServer) -> None:
        httpserver.expect_ordered_request("/webhook").respond_with_data("", status=500)
        httpserver.expect_ordered_request("/webhook").respond_with_data("ok", status=200)
        config = DiscordDestinationConfig(
            type="discord",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="{{ row.msg }}",
        )
        opts = SyncOptions(on_error="skip")
        result = DiscordDestination().load([{"msg": "a"}, {"msg": "b"}], config, opts)
        assert result.failed == 1
        assert result.success == 1

    def test_missing_webhook_raises(self) -> None:
        config = DiscordDestinationConfig(type="discord", message_template="hi")
        with pytest.raises(ValueError, match="webhook_url"):
            DiscordDestination().load([{"x": 1}], config, _options())

    def test_embeds_payload(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/webhook").respond_with_data("ok", status=200)
        config = DiscordDestinationConfig(
            type="discord",
            webhook_url=httpserver.url_for("/webhook"),
            embeds=True,
            message_template=(
                '{"embeds": [{"title": "{{ row.title }}",'
                ' "description": "{{ row.desc }}", "color": 3447003}]}'
            ),
        )
        result = DiscordDestination().load(
            [{"title": "New Alert", "desc": "Something happened"}], config, _options()
        )
        assert result.success == 1

    def test_on_error_fail_stops_after_first_failure(
        self, httpserver: HTTPServer
    ) -> None:
        """on_error=fail stops batch processing after first failure (#365)."""
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            from werkzeug.wrappers import Response
            call_count["n"] += 1
            return Response("", status=500)

        httpserver.expect_request("/webhook").respond_with_handler(handler)
        config = DiscordDestinationConfig(
            type="discord",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="{{ row.msg }}",
            retry=RetryConfig(
                max_attempts=1, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        opts = SyncOptions(on_error="fail")
        result = DiscordDestination().load(
            [{"msg": "a"}, {"msg": "b"}, {"msg": "c"}], config, opts
        )
        assert result.failed == 1
        assert result.success == 0
        assert call_count["n"] == 1

    def test_destination_retry_overrides_sync_retry(
        self, httpserver: HTTPServer
    ) -> None:
        """destination.retry > sync.retry (#277, #365)."""
        from werkzeug.wrappers import Response

        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response("upstream busy", status=503)

        httpserver.expect_request("/webhook").respond_with_handler(handler)
        config = DiscordDestinationConfig(
            type="discord",
            webhook_url=httpserver.url_for("/webhook"),
            message_template="{{ row.msg }}",
            retry=RetryConfig(
                max_attempts=4, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=2, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
            on_error="skip",
        )
        DiscordDestination().load([{"msg": "x"}], config, opts)
        assert call_count["n"] == 4


# ---------------------------------------------------------------------------
# HubSpotDestination
# ---------------------------------------------------------------------------


class TestHubSpotDestination:
    def test_success_upsert(self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("HUBSPOT_TOKEN", "test-token")
        httpserver.expect_request("/crm/v3/objects/contacts").respond_with_data(
            '{"id": "1"}', status=200, content_type="application/json"
        )
        config = HubSpotDestinationConfig(
            type="hubspot",
            object_type="contacts",
            id_property="email",
            properties_template='{"email": "{{ row.email }}"}',
            auth=BearerAuth(type="bearer", token_env="HUBSPOT_TOKEN"),
        )
        # Patch API base URL to point at test server
        import drt.destinations.hubspot as hs_mod

        monkeypatch.setattr(hs_mod, "_HUBSPOT_API", httpserver.url_for("/crm/v3/objects"))
        result = HubSpotDestination().load([{"email": "alice@example.com"}], config, _options())
        assert result.success == 1
        assert result.failed == 0

    def test_missing_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("HUBSPOT_TOKEN", raising=False)
        config = HubSpotDestinationConfig(
            type="hubspot",
            object_type="contacts",
            auth=BearerAuth(type="bearer", token_env="HUBSPOT_TOKEN"),
        )
        with pytest.raises(ValueError, match="HUBSPOT_TOKEN"):
            HubSpotDestination().load([{"email": "x@x.com"}], config, _options())

    def test_template_error_skipped(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("HUBSPOT_TOKEN", "test-token")
        config = HubSpotDestinationConfig(
            type="hubspot",
            object_type="contacts",
            properties_template="not valid json {{ row.email }}",
            auth=BearerAuth(type="bearer", token_env="HUBSPOT_TOKEN"),
        )
        import drt.destinations.hubspot as hs_mod

        monkeypatch.setattr(hs_mod, "_HUBSPOT_API", httpserver.url_for("/crm/v3/objects"))
        result = HubSpotDestination().load([{"email": "x@x.com"}], config, _options())
        assert result.failed == 1
        assert result.success == 0

    def test_on_error_fail_stops_after_first_failure(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """on_error=fail stops batch processing after first failure (#365)."""
        monkeypatch.setenv("HUBSPOT_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            from werkzeug.wrappers import Response
            call_count["n"] += 1
            return Response('{"error": "rate limited"}', status=429)

        httpserver.expect_request("/crm/v3/objects/contacts").respond_with_handler(handler)
        config = HubSpotDestinationConfig(
            type="hubspot",
            object_type="contacts",
            id_property="email",
            properties_template='{"email": "{{ row.email }}"}',
            auth=BearerAuth(type="bearer", token_env="HUBSPOT_TOKEN"),
            retry=RetryConfig(
                max_attempts=1, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        import drt.destinations.hubspot as hs_mod

        monkeypatch.setattr(hs_mod, "_HUBSPOT_API", httpserver.url_for("/crm/v3/objects"))
        opts = SyncOptions(on_error="fail")
        result = HubSpotDestination().load(
            [{"email": "a@x.com"}, {"email": "b@x.com"}, {"email": "c@x.com"}],
            config,
            opts,
        )
        assert result.failed == 1
        assert result.success == 0
        assert call_count["n"] == 1

    def test_destination_retry_overrides_sync_retry(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """destination.retry > sync.retry (#277, #365)."""
        from werkzeug.wrappers import Response

        monkeypatch.setenv("HUBSPOT_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response('{"error": "busy"}', status=503)

        httpserver.expect_request("/crm/v3/objects/contacts").respond_with_handler(handler)
        config = HubSpotDestinationConfig(
            type="hubspot",
            object_type="contacts",
            id_property="email",
            properties_template='{"email": "{{ row.email }}"}',
            auth=BearerAuth(type="bearer", token_env="HUBSPOT_TOKEN"),
            retry=RetryConfig(
                max_attempts=4, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        import drt.destinations.hubspot as hs_mod

        monkeypatch.setattr(hs_mod, "_HUBSPOT_API", httpserver.url_for("/crm/v3/objects"))
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=2, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
            on_error="skip",
        )
        HubSpotDestination().load([{"email": "x@x.com"}], config, opts)
        assert call_count["n"] == 4


# ---------------------------------------------------------------------------
# GitHubActionsDestination
# ---------------------------------------------------------------------------


class TestGitHubActionsDestination:
    def test_success(self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        httpserver.expect_request(
            "/repos/myorg/myapp/actions/workflows/deploy.yml/dispatches"
        ).respond_with_data("", status=204)
        config = GitHubActionsDestinationConfig(
            type="github_actions",
            owner="myorg",
            repo="myapp",
            workflow_id="deploy.yml",
            ref="main",
            auth=BearerAuth(type="bearer", token_env="GITHUB_TOKEN"),
        )
        import drt.destinations.github_actions as ga_mod

        monkeypatch.setattr(ga_mod, "_GITHUB_API", httpserver.url_for(""))
        result = GitHubActionsDestination().load(
            [{"env": "prod", "version": "1.0"}], config, _options()
        )
        assert result.success == 1
        assert result.failed == 0

    def test_missing_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        config = GitHubActionsDestinationConfig(
            type="github_actions",
            owner="myorg",
            repo="myapp",
            workflow_id="deploy.yml",
            auth=BearerAuth(type="bearer", token_env="GITHUB_TOKEN"),
        )
        with pytest.raises(ValueError, match="GITHUB_TOKEN"):
            GitHubActionsDestination().load([{}], config, _options())

    def test_inputs_template_error_skipped(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        config = GitHubActionsDestinationConfig(
            type="github_actions",
            owner="myorg",
            repo="myapp",
            workflow_id="deploy.yml",
            inputs_template="not valid json {{ row.env }}",
            auth=BearerAuth(type="bearer", token_env="GITHUB_TOKEN"),
        )
        import drt.destinations.github_actions as ga_mod

        monkeypatch.setattr(ga_mod, "_GITHUB_API", httpserver.url_for(""))
        result = GitHubActionsDestination().load([{"env": "prod"}], config, _options())
        assert result.failed == 1
        assert result.success == 0

    def test_on_error_fail_stops_after_first_failure(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """on_error=fail stops batch processing after first failure (#365)."""
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            from werkzeug.wrappers import Response
            call_count["n"] += 1
            return Response('{"message": "Bad credentials"}', status=401)

        httpserver.expect_request(
            "/repos/myorg/myapp/actions/workflows/deploy.yml/dispatches"
        ).respond_with_handler(handler)
        config = GitHubActionsDestinationConfig(
            type="github_actions",
            owner="myorg",
            repo="myapp",
            workflow_id="deploy.yml",
            ref="main",
            auth=BearerAuth(type="bearer", token_env="GITHUB_TOKEN"),
            retry=RetryConfig(
                max_attempts=1, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        import drt.destinations.github_actions as ga_mod

        monkeypatch.setattr(ga_mod, "_GITHUB_API", httpserver.url_for(""))
        opts = SyncOptions(on_error="fail")
        result = GitHubActionsDestination().load(
            [{"env": "dev"}, {"env": "stg"}, {"env": "prod"}], config, opts
        )
        assert result.failed == 1
        assert result.success == 0
        assert call_count["n"] == 1

    def test_destination_retry_overrides_sync_retry(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """destination.retry > sync.retry (#277, #365)."""
        from werkzeug.wrappers import Response

        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response('{"message": "API rate limit"}', status=429)

        httpserver.expect_request(
            "/repos/myorg/myapp/actions/workflows/deploy.yml/dispatches"
        ).respond_with_handler(handler)
        config = GitHubActionsDestinationConfig(
            type="github_actions",
            owner="myorg",
            repo="myapp",
            workflow_id="deploy.yml",
            auth=BearerAuth(type="bearer", token_env="GITHUB_TOKEN"),
            retry=RetryConfig(
                max_attempts=4, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        import drt.destinations.github_actions as ga_mod

        monkeypatch.setattr(ga_mod, "_GITHUB_API", httpserver.url_for(""))
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=2, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
            on_error="skip",
        )
        GitHubActionsDestination().load([{"env": "prod"}], config, opts)
        assert call_count["n"] == 4


# ---------------------------------------------------------------------------
# NotionDestination
# ---------------------------------------------------------------------------


class TestNotionDestination:
    def test_success(self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        httpserver.expect_request("/v1/pages").respond_with_data(
            '{"id": "page-1", "url": "https://notion.so/page-1"}',
            status=200,
            content_type="application/json",
        )
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        result = NotionDestination().load([{"name": "Alice"}], config, _options())
        assert result.success == 1
        assert result.failed == 0

    def test_missing_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("NOTION_TOKEN", raising=False)
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        with pytest.raises(ValueError, match="NOTION_TOKEN"):
            NotionDestination().load([{"name": "x"}], config, _options())

    def test_template_error_skipped(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template="not valid json {{ row.name }}",
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        result = NotionDestination().load([{"name": "x"}], config, _options())
        assert result.failed == 1
        assert result.success == 0

    def test_on_error_skip(self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        httpserver.expect_ordered_request("/v1/pages").respond_with_data("", status=500)
        httpserver.expect_ordered_request("/v1/pages").respond_with_data(
            '{"id": "page-2"}', status=200, content_type="application/json"
        )
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        opts = SyncOptions(on_error="skip")
        result = NotionDestination().load([{"name": "a"}, {"name": "b"}], config, opts)
        assert result.failed == 1
        assert result.success == 1

    def test_on_error_fail_stops_after_first_failure(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """on_error=fail stops batch processing after first failure (#365)."""
        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            from werkzeug.wrappers import Response
            call_count["n"] += 1
            return Response("", status=500)

        httpserver.expect_request("/v1/pages").respond_with_handler(handler)
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
            retry=RetryConfig(
                max_attempts=1, initial_backoff=0.0, backoff_multiplier=1.0, max_backoff=0.0
            ),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        opts = SyncOptions(on_error="fail")
        result = NotionDestination().load(
            [{"name": "a"}, {"name": "b"}, {"name": "c"}], config, opts
        )
        assert result.failed == 1
        assert result.success == 0
        assert call_count["n"] == 1

    def test_notion_version_header_sent(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from werkzeug.wrappers import Response

        monkeypatch.setenv("NOTION_TOKEN", "test-token")

        def handler(request):
            assert request.headers["Notion-Version"] == "2022-06-28"
            assert request.headers["Authorization"] == "Bearer test-token"
            return Response('{"id": "page-1"}', content_type="application/json")

        httpserver.expect_request("/v1/pages").respond_with_handler(handler)
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        result = NotionDestination().load([{"name": "Alice"}], config, _options())
        assert result.success == 1

    def test_retry_override_honored(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from werkzeug.wrappers import Response

        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response("Service Unavailable", status=503)

        httpserver.expect_request("/v1/pages").respond_with_handler(handler)
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=5,
                initial_backoff=0.0,
                backoff_multiplier=1.0,
                max_backoff=0.0,
            ),
            on_error="skip",
        )
        NotionDestination().load([{"name": "Alice"}], config, opts)
        assert call_count["n"] == 5

    def test_retry_default_used_when_options_default(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from werkzeug.wrappers import Response

        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response("Service Unavailable", status=503)

        httpserver.expect_request("/v1/pages").respond_with_handler(handler)
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        opts = SyncOptions(on_error="skip")
        NotionDestination().load([{"name": "Alice"}], config, opts)
        assert call_count["n"] == 3

    def test_destination_retry_overrides_sync_retry(
        self, httpserver: HTTPServer, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """destination.retry takes precedence over sync.retry (#277)."""
        from werkzeug.wrappers import Response

        monkeypatch.setenv("NOTION_TOKEN", "test-token")
        call_count = {"n": 0}

        def handler(_request):  # type: ignore[no-untyped-def]
            call_count["n"] += 1
            return Response("Service Unavailable", status=503)

        httpserver.expect_request("/v1/pages").respond_with_handler(handler)
        # destination.retry says 7 attempts; sync.retry says 2.
        # Destination override wins → 7 actual attempts.
        config = NotionDestinationConfig(
            type="notion",
            database_id="db-abc123",
            properties_template='{"Name": {"title": [{"text": {"content": "{{ row.name }}"}}]}}',
            auth=BearerAuth(type="bearer", token_env="NOTION_TOKEN"),
            retry=RetryConfig(
                max_attempts=7,
                initial_backoff=0.0,
                backoff_multiplier=1.0,
                max_backoff=0.0,
            ),
        )
        import drt.destinations.notion as notion_mod

        monkeypatch.setattr(notion_mod, "_NOTION_API", httpserver.url_for("/v1"))
        opts = SyncOptions(
            retry=RetryConfig(
                max_attempts=2,
                initial_backoff=0.0,
                backoff_multiplier=1.0,
                max_backoff=0.0,
            ),
            on_error="skip",
        )
        NotionDestination().load([{"name": "Alice"}], config, opts)
        assert call_count["n"] == 7
