import os
import json
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ImportFormat, Language, ObjectType


class DataJobsStructure:

    def __init__(self, base_path: str):
        self.w         = WorkspaceClient()
        self.base_path = base_path                 # e.g. /Workspace/Users/xxx
        self.datajobs  = f"{base_path}/datajobs"   # datajobs/
        self.root      = f"{self.datajobs}/jobs"   # datajobs/jobs/

    # -----------------------------
    # Detect language
    # -----------------------------
    def _get_language(self, file_name):
        if file_name.endswith(".py"):
            return Language.PYTHON
        elif file_name.endswith(".sql"):
            return Language.SQL
        elif file_name.endswith(".scala"):
            return Language.SCALA
        elif file_name.endswith(".r"):
            return Language.R
        return None

    # -----------------------------
    # JSON fallback serializer
    # -----------------------------
    def _json_fallback(self, obj):
        if isinstance(obj, set):
            return sorted(list(obj))
        if isinstance(obj, bytes):
            return obj.decode("utf-8")
        raise TypeError(f"Type {type(obj).__name__} is not JSON serializable")

    # -----------------------------
    # Delete if wrong type
    # -----------------------------
    def _delete_if_wrong_type(self, full_path, expected_type):
        try:
            obj = self.w.workspace.get_status(full_path)
            if expected_type == "file" and obj.object_type == ObjectType.DIRECTORY:
                print(f"⚠️  Removing stale directory at {full_path} (expected a file)")
                self.w.workspace.delete(full_path, recursive=True)
            elif expected_type == "directory" and obj.object_type != ObjectType.DIRECTORY:
                print(f"⚠️  Removing stale file at {full_path} (expected a directory)")
                self.w.workspace.delete(full_path, recursive=False)
        except Exception:
            pass

    # -----------------------------
    # Upload regular file
    # -----------------------------
    def upload_file(self, full_path, content):
        file_name = os.path.basename(full_path)
        self._delete_if_wrong_type(full_path, "file")

        if file_name.endswith(".json"):
            content_str = json.dumps(content, indent=4, default=self._json_fallback) \
                          if isinstance(content, (dict, list)) else content
        else:
            content_str = content if content else "-- default content\n"

        language = self._get_language(file_name)

        if language:
            self.w.workspace.upload(
                path=full_path,
                content=content_str.encode("utf-8"),
                format=ImportFormat.SOURCE,
                language=language,
                overwrite=True
            )
        else:
            self.w.workspace.upload(
                path=full_path,
                content=content_str.encode("utf-8"),
                format=ImportFormat.AUTO,
                overwrite=True
            )

    # -----------------------------
    # Upload .ipynb notebook
    # -----------------------------
    def create_notebook(self):
        """
        Embeds load_datajobs.ipynb content directly and uploads it
        under datajobs/jobs/ as a Databricks notebook.
        """

        ipynb_content = {
            "cells": [
                {
                    "cell_type": "markdown",
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "4f15e819-d04b-4e09-8742-3c6bffcacd17",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Data Jobs Loader - Documentation"
                        }
                    },
                    "source": [
                        "# Data Jobs Loader\n",
                        "\n",
                        "This notebook loads and processes data jobs using configuration files.\n",
                        "\n",
                        "## Parameters\n",
                        "\n",
                        "* **Base Directory** (`base_dir`): Root directory containing job configurations and scripts\n",
                        "  * Default: `/Workspace/Shared/DATAJOBS/datajobs/jobs`\n",
                        "  \n",
                        "* **Config File Name** (`config_file`): Name of the configuration file to load\n",
                        "  * Default: `customer_config.json`\n",
                        "  * File should be located in `{base_dir}/job_configs/`\n",
                        "\n",
                        "## Required Environment Variables\n",
                        "\n",
                        "Create a `.env` file in `/Workspace/Shared/xyz-demo-project/` with:\n",
                        "\n",
                        "```\n",
                        "DATABRICKS_SERVER_HOSTNAME=\"your-workspace.cloud.databricks.com\"\n",
                        "DATABRICKS_HTTP_PATH=\"/sql/1.0/warehouses/your-warehouse-id\"\n",
                        "DATABRICKS_ACCESS_TOKEN=\"your-token\"\n",
                        "DATAJOBS_COMPUTE_MODE=\"warehouse\" or \"spark\"\n",
                        "```\n",
                        "\n",
                        "**For Workflow/Job Execution:**\n",
                        "* Ensure the `.env` file exists in the notebook's directory\n",
                        "* OR set these as environment variables in the job cluster configuration\n",
                        "* OR use job parameters and modify the code to read from parameters\n",
                        "\n",
                        "## Usage\n",
                        "\n",
                        "### Running Interactively\n",
                        "1. Set the parameters above\n",
                        "2. Ensure `.env` file exists with required variables\n",
                        "3. Run all cells sequentially\n",
                        "\n",
                        "### Running as a Workflow/Job\n",
                        "1. Create a job in Databricks Workflows\n",
                        "2. Add this notebook as a task\n",
                        "3. Set the `base_dir` and `config_file` parameters in the job configuration\n",
                        "4. Ensure environment variables are set (via `.env` file or job cluster configuration)\n",
                        "5. The job will properly report SUCCESS or FAILED status\n",
                        "\n",
                        "## Process Flow\n",
                        "\n",
                        "1. Install required packages (datajobs, python-dotenv)\n",
                        "2. Load and validate environment variables\n",
                        "3. Import libraries and configure logging\n",
                        "4. Set base directory and validate path\n",
                        "5. Load and validate configuration file\n",
                        "6. Initialize LoadScripts instance with configuration\n",
                        "7. Execute job processing\n",
                        "8. Exit with appropriate status code for workflow\n",
                        "\n",
                        "## Error Handling\n",
                        "\n",
                        "The notebook includes comprehensive error handling:\n",
                        "* Environment variable validation\n",
                        "* Path validation for directories and files\n",
                        "* JSON validation for configuration files\n",
                        "* Detailed logging for debugging\n",
                        "* Proper exit codes for workflow integration\n",
                        "* Graceful error messages\n",
                        "\n",
                        "## Create .env file\n",
                        "The notebook required enviroment varaibles:\n",
                        "\n",
                        "* DATABRICKS_SERVER_HOSTNAME = ''\n",
                        "* DATABRICKS_HTTP_PATH = ''\n",
                        "* DATABRICKS_ACCESS_TOKEN = ''\n",
                        "* DATAJOBS_COMPUTE_MODE = 'warehouse' or 'spark'\n",
                        "\n",
                        "---"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "ead42950-71c5-4a39-aba5-35bd07e5d743",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Install Datajobs and requirements"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "%pip install datajobs\n",
                        "%pip install databricks-sql-connector\n",
                        "%pip install databricks-sql-connector[pyarrow]"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "86749b6c-bb3f-4bdd-aeb2-926cb2da8465",
                            "showTitle": False,
                            "tableResultSettingsMap": {},
                            "title": ""
                        }
                    },
                    "outputs": [],
                    "source": [
                        "dbutils.library.restartPython()"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "4cbe1f44-a370-47c4-ad9e-645a9f758a7d",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Import Required Libraries"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "import os\n",
                        "import json\n",
                        "import logging\n",
                        "from datajobs.load_scripts import LoadScripts\n",
                        "\n",
                        "# Configure logging\n",
                        "logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')\n",
                        "logger = logging.getLogger(__name__)"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "8f1d8712-5fa0-4de6-a7e8-c2bb85858753",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Configure Base Directory"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "# Get base directory from parameter\n",
                        "BASE_DIR = dbutils.widgets.get(\"base_dir\")\n",
                        "os.environ[\"BRV_BASE_DIR\"] = BASE_DIR\n",
                        "\n",
                        "logger.info(f\"Base directory set to: {BASE_DIR}\")\n",
                        "\n",
                        "# Validate base directory exists\n",
                        "if not os.path.exists(BASE_DIR):\n",
                        "    raise ValueError(f\"Base directory does not exist: {BASE_DIR}\")"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "c9311375-5b4e-4859-8704-8046674e23dd",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Load Configuration File"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "# Get config file name from parameter\n",
                        "config_file_name = dbutils.widgets.get(\"config_file\")\n",
                        "config_path = os.path.join(BASE_DIR, \"job_configs\", config_file_name)\n",
                        "\n",
                        "logger.info(f\"Loading configuration from: {config_path}\")\n",
                        "\n",
                        "# Validate config file exists\n",
                        "if not os.path.exists(config_path):\n",
                        "    raise FileNotFoundError(f\"Configuration file not found: {config_path}\")\n",
                        "\n",
                        "try:\n",
                        "    with open(config_path, \"r\") as f:\n",
                        "        config = json.load(f)\n",
                        "    logger.info(\"Configuration loaded successfully\")\n",
                        "    print(json.dumps(config, indent=2))\n",
                        "except json.JSONDecodeError as e:\n",
                        "    logger.error(f\"Invalid JSON in configuration file: {e}\")\n",
                        "    raise\n",
                        "except Exception as e:\n",
                        "    logger.error(f\"Error loading configuration: {e}\")\n",
                        "    raise"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "eaedab71-09d1-4c5b-bcaf-767f6e4ea5e8",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Initialize and Configure LoadScripts"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "try:\n",
                        "    logger.info(\"Initializing LoadScripts instance\")\n",
                        "    ls = LoadScripts()\n",
                        "\n",
                        "    # Assign config and split\n",
                        "    ls.config = config\n",
                        "    ls.split_config_object()\n",
                        "\n",
                        "    logger.info(\"LoadScripts configured successfully\")\n",
                        "except AttributeError as e:\n",
                        "    logger.error(f\"Configuration error: {e}\")\n",
                        "    raise\n",
                        "except Exception as e:\n",
                        "    logger.error(f\"Error initializing LoadScripts: {e}\")\n",
                        "    raise"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": 0,
                    "metadata": {
                        "application/vnd.databricks.v1+cell": {
                            "cellMetadata": {"byteLimit": 2048000, "rowLimit": 10000},
                            "inputWidgets": {},
                            "nuid": "2aceaadb-a1f1-4b83-b524-65c829d10ff2",
                            "showTitle": True,
                            "tableResultSettingsMap": {},
                            "title": "Execute Job Processing"
                        }
                    },
                    "outputs": [],
                    "source": [
                        "try:\n",
                        "    logger.info(\"Starting job processing\")\n",
                        "    result = ls.process_job()\n",
                        "\n",
                        "    if result:\n",
                        "        jobs = result.get(\"JOBS\", [])\n",
                        "        failed_jobs = []\n",
                        "\n",
                        "        for job in jobs:\n",
                        "            status = str(job.get(\"STATUS\", \"\")).upper()\n",
                        "            job_id = job.get(\"JOB_ID\")\n",
                        "            job_name = job.get(\"JOB_NAME\")\n",
                        "\n",
                        "            if status != \"SUCCESS\":\n",
                        "                failed_jobs.append(\n",
                        "                    f\"JOB_ID: {job_id}, JOB_NAME: {job_name}, STATUS: {status}\"\n",
                        "                )\n",
                        "\n",
                        "        if failed_jobs:\n",
                        "            raise Exception(\"Some jobs failed:\\n\" + \"\\n\".join(failed_jobs))\n",
                        "\n",
                        "    logger.info(\"Job processing completed successfully\")\n",
                        "    print(\"\\n\" + \"=\"*50)\n",
                        "    print(\"JOB EXECUTION SUCCESSFUL\")\n",
                        "    print(\"=\"*50)\n",
                        "\n",
                        "except Exception as e:\n",
                        "    logger.error(f\"Job processing failed: {e}\")\n",
                        "    print(\"\\n\" + \"=\"*50)\n",
                        "    print(\"JOB EXECUTION FAILED\")\n",
                        "    print(\"=\"*50)\n",
                        "    raise"
                    ]
                }
            ],
            "metadata": {
                "application/vnd.databricks.v1+notebook": {
                    "computePreferences": None,
                    "dashboards": [],
                    "environmentMetadata": {
                        "base_environment": "",
                        "environment_version": "5"
                    },
                    "inputWidgetPreferences": None,
                    "language": "python",
                    "notebookMetadata": {
                        "pythonIndentUnit": 4
                    },
                    "notebookName": "load_datajobs",
                    "widgets": {
                        "base_dir": {
                            "currentValue": "",
                            "nuid": "af89c6ba-c116-4890-a961-8420df7d0ba3",
                            "typedWidgetInfo": {
                                "autoCreated": False,
                                "defaultValue": "/Workspace/Shared/DATAJOBS/datajobs/jobs",
                                "label": "Base Directory",
                                "name": "base_dir",
                                "options": {
                                    "widgetDisplayType": "Text",
                                    "validationRegex": None
                                },
                                "parameterDataType": "String",
                                "dynamic": False
                            },
                            "widgetInfo": {
                                "widgetType": "text",
                                "defaultValue": "/Workspace/Shared/DATAJOBS/datajobs/jobs",
                                "label": "Base Directory",
                                "name": "base_dir",
                                "options": {
                                    "widgetType": "text",
                                    "autoCreated": False,
                                    "validationRegex": None
                                }
                            }
                        },
                        "config_file": {
                            "currentValue": "",
                            "nuid": "a06bdfa7-3a6c-4e07-ac51-344b3cf7ee5a",
                            "typedWidgetInfo": {
                                "autoCreated": False,
                                "defaultValue": "customer_config.json",
                                "label": "Config File Name",
                                "name": "config_file",
                                "options": {
                                    "widgetDisplayType": "Text",
                                    "validationRegex": None
                                },
                                "parameterDataType": "String",
                                "dynamic": False
                            },
                            "widgetInfo": {
                                "widgetType": "text",
                                "defaultValue": "customer_config.json",
                                "label": "Config File Name",
                                "name": "config_file",
                                "options": {
                                    "widgetType": "text",
                                    "autoCreated": False,
                                    "validationRegex": None
                                }
                            }
                        }
                    }
                },
                "language_info": {
                    "name": "python"
                }
            },
            "nbformat": 4,
            "nbformat_minor": 0
        }

        dest_path = f"{self.root}/load_datajobs"

        self._delete_if_wrong_type(dest_path, "file")

        self.w.workspace.upload(
            path=dest_path,
            content=json.dumps(ipynb_content, indent=1).encode("utf-8"),
            format=ImportFormat.JUPYTER,
            overwrite=True
        )

        print(f"📓 Uploaded notebook: load_datajobs → {dest_path}")

    # -----------------------------
    # Create folders
    # -----------------------------
    def create_folders(self):
        folders = [
            self.datajobs,                         # datajobs/
            self.root,                             # datajobs/jobs/
            f"{self.root}/code_snippets",          # datajobs/jobs/code_snippets/
            f"{self.root}/job_scripts",            # datajobs/jobs/job_scripts/
            f"{self.root}/job_configs",            # datajobs/jobs/job_configs/
            f"{self.root}/tests",                  # datajobs/jobs/tests/
            f"{self.root}/validations",            # datajobs/jobs/validations/
        ]
        for folder in folders:
            self._delete_if_wrong_type(folder, "directory")
            self.w.workspace.mkdirs(folder)
            print(f"📁 Created folder: {folder}")

    
    # -----------------------------
    # Create code snippets
    # -----------------------------
    def create_code_snippets(self):
        code_snippets = {
            "batch_process.sql": """#START <BATCH_PROCESS_TABLE>
CREATE TABLE IF NOT EXISTS datajobs.batch.batch_process (
    process_id              DECIMAL(20,0),
    source_table_name       STRING,
    status_code             STRING,
    function_name           STRING,
    file_id                 STRING,
    start_ts                TIMESTAMP,
    end_ts                  TIMESTAMP,
    initial_table_count     BIGINT,
    target_update_count     BIGINT,
    target_insert_count     BIGINT,
    error_message           STRING,
    created_at              TIMESTAMP
)
USING DELTA;
#END <BATCH_PROCESS_TABLE>

#START <PROCESS_START>
-- STEP 1: CREATE PROCESS CONTROL TEMP TABLE
CREATE OR REPLACE TEMP VIEW temp_process_control_<RUN_ID> AS
SELECT 
    CAST('<RAW_TABLE>' AS STRING)          AS source_table_name,
    CAST('<JOB_NAME>'  AS STRING)          AS function_name,
    CAST('<RUN_ID>'    AS DECIMAL(20,0))   AS process_id,
    CURRENT_TIMESTAMP()                    AS start_time,
    CAST('2020-01-01'  AS DATE)            AS default_start_date;
#END <PROCESS_START>

#START <PROCESS_CONTROL_CHECK>
-- STEP 2: CHECK IF ANOTHER RUN IS ACTIVE
CREATE OR REPLACE TEMP VIEW temp_process_control_final_<RUN_ID> AS
SELECT *
FROM temp_process_control_<RUN_ID> tpc
WHERE NOT EXISTS (
    SELECT 1
    FROM datajobs.batch.batch_process bp
    WHERE bp.source_table_name = tpc.source_table_name
      AND bp.status_code = 'RUNNING'
);

SELECT ASSERT_TRUE(
    COUNT(*) > 0,
    'Concurrent run detected. Another process is already RUNNING for this source table. Execution stopped.'
)
FROM temp_process_control_final_<RUN_ID>;

-- STEP 3: LAST SUCCESSFUL TIMESTAMP
CREATE OR REPLACE TEMP VIEW temp_last_run_<RUN_ID> AS
SELECT COALESCE(MAX(start_ts), CAST('1900-01-01' AS TIMESTAMP)) AS last_success_ts
FROM datajobs.batch.batch_process
WHERE source_table_name = '<RAW_TABLE>'
  AND function_name     = '<JOB_NAME>'
  AND status_code       = 'SUCCEEDED';
#END <PROCESS_CONTROL_CHECK>

#START <BATCH_PROCESS_START>
-- STEP 4: INSERT INTO batch_process
INSERT INTO datajobs.batch.batch_process (
    process_id, source_table_name, status_code, function_name, file_id, start_ts
)
SELECT process_id, source_table_name, 'RUNNING', function_name, NULL, start_time
FROM temp_process_control_final_<RUN_ID>;
#END <BATCH_PROCESS_START>

#START <EXTRACT_DATASET>
CREATE OR REPLACE TEMP VIEW extract_<RUN_ID> AS
SELECT * FROM <RAW_TABLE>
UNION
SELECT * FROM <RAW_TABLE>
WHERE <SRC_IDENTIFIER> IN (
    SELECT <SRC_IDENTIFIER>
    FROM datajobs.batch.reject_records
    WHERE dataset || '.' || table_name = '<DATABASE_NAME>.<SCHEMA>.<STG_TABLE>'
);
#END <EXTRACT_DATASET>

#START <BATCH_PROCESS_TEST_FAILED>
MERGE INTO datajobs.batch.batch_process AS target
USING (
    SELECT 
        t.process_id,
        CONCAT(
            'CRITICAL TEST FAILURE: ',
            CONCAT_WS(' | ',
                COLLECT_LIST(CONCAT('[', t.test_phase, '] ', t.error_message))
            )
        ) AS combined_error
    FROM datajobs.batch.batch_test_results t
    WHERE t.severity = 'CRITICAL'
      AND t.status   = 'FAILED'
    GROUP BY t.process_id
) AS failures
ON target.process_id = failures.process_id
   AND target.status_code = 'RUNNING'
WHEN MATCHED THEN
  UPDATE SET
    target.status_code   = 'FAILED',
    target.end_ts        = CURRENT_TIMESTAMP(),
    target.error_message = failures.combined_error;

SELECT ASSERT_TRUE(
    status_code <> 'FAILED',
    COALESCE(error_message, 'Critical TEST failure. Execution stopped.')
)
FROM datajobs.batch.batch_process
WHERE process_id = <RUN_ID>;
#END <BATCH_PROCESS_TEST_FAILED>

#START <BATCH_PROCESS_END>
-- STEP 8: Finalize batch log
MERGE INTO datajobs.batch.batch_process AS target
USING (
    SELECT 
        bp.process_id,
        bp.start_ts,
        (SELECT COUNT(*) FROM dataset_<RUN_ID>) AS initial_table_count,
        (SELECT COUNT(*)
         FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
         WHERE record_updated_at >= bp.start_ts
           AND record_created_at  < bp.start_ts) AS target_update_count,
        (SELECT COUNT(*)
         FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
         WHERE record_created_at >= bp.start_ts) AS target_insert_count
    FROM datajobs.batch.batch_process bp
    WHERE bp.source_table_name = '<RAW_TABLE>'
      AND bp.status_code       = 'RUNNING'
      AND bp.process_id        = <RUN_ID>
) AS src
ON target.process_id      = src.process_id
   AND target.status_code = 'RUNNING'
WHEN MATCHED THEN UPDATE SET
    target.status_code         = 'SUCCEEDED',
    target.end_ts              = CURRENT_TIMESTAMP(),
    target.initial_table_count = src.initial_table_count,
    target.target_update_count = src.target_update_count,
    target.target_insert_count = src.target_insert_count;
#END <BATCH_PROCESS_END>
""",
            "batch_test_results.sql": """
#START <BATCH_TEST_RESULT>
CREATE TABLE IF NOT EXISTS datajobs.batch.batch_test_results (
    process_id        DECIMAL(20,0),
    test_phase        STRING,
    table_name        STRING,
    test_name         STRING,
    test_type         STRING,
    severity          STRING,
    status            STRING,
    expected_value    STRING,
    actual_value      STRING,
    error_message     STRING,
    executed_at       TIMESTAMP
)
USING DELTA;
#END <BATCH_TEST_RESULT>

#START <LOG_RESULT>
INSERT INTO datajobs.batch.batch_test_results
SELECT
    <RUN_ID>          AS process_id,
    test_phase,
    '<STG_TABLE>'     AS table_name,
    test_name,
    test_type,
    severity,
    CASE
        WHEN operator = '>=' AND CAST(actual_value AS BIGINT)
                              >= CAST(expected_value AS BIGINT) THEN 'PASSED'
        WHEN operator = '='  AND actual_value = expected_value  THEN 'PASSED'
        WHEN operator = '<=' AND CAST(actual_value AS BIGINT)
                              <= CAST(expected_value AS BIGINT) THEN 'PASSED'
        ELSE 'FAILED'
    END                                             AS status,
    expected_value,
    actual_value,
    CASE
        WHEN operator = '>=' AND CAST(actual_value AS BIGINT)
                              >= CAST(expected_value AS BIGINT) THEN NULL
        WHEN operator = '='  AND actual_value = expected_value  THEN NULL
        ELSE CONCAT('[', test_phase, ']', description,
                    ' | Expected: ', operator, ' ', expected_value,
                    ' | Got: ', actual_value)
    END                                             AS error_message,
    CURRENT_TIMESTAMP()                             AS executed_at
FROM (
#END <LOG_RESULT>
""",
            "batch_validation_results.sql": """
#START <BATCH_REJECT_RECORDS>
CREATE TABLE IF NOT EXISTS datajobs.batch.reject_records (
    dataset        STRING,
    table_name     STRING,
    src_identifier STRING,
    data           STRING,
    error_message  STRING,
    created_at     TIMESTAMP
) USING DELTA;
#END <BATCH_REJECT_RECORDS>

#START <INSERT_BATCH_REJECTS>
CREATE TEMP VIEW dataset_rejects_<RUN_ID> AS (
    SELECT * FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY src_identifier ORDER BY since_ts DESC) AS rnk
        FROM dataset_<RUN_ID>
        WHERE error_messages IS NOT NULL AND error_messages <> ''
    )
    WHERE rnk = 1
);

MERGE INTO datajobs.batch.reject_records AS target
USING (
    SELECT 
        '<DATABASE_NAME>.<SCHEMA>'  AS dataset,
        '<STG_TABLE>'               AS table_name,
        src_identifier,
        to_json(struct(*))          AS data,
        error_messages              AS error_message,
        CURRENT_TIMESTAMP()         AS created_at
    FROM dataset_rejects_<RUN_ID>
) AS source
ON  target.dataset        = source.dataset
AND target.table_name     = source.table_name
AND target.src_identifier = source.src_identifier
WHEN NOT MATCHED THEN
INSERT (dataset, table_name, src_identifier, data, error_message, created_at)
VALUES (source.dataset, source.table_name, source.src_identifier, source.data, source.error_message, source.created_at);

MERGE INTO datajobs.batch.reject_records AS target
USING (
    SELECT DISTINCT src_identifier
    FROM dataset_<RUN_ID>
    WHERE error_messages IS NULL OR error_messages = ''
) AS source
ON target.dataset || '.' || target.table_name = '<DATABASE_NAME>.<SCHEMA>.<STG_TABLE>'
   AND target.src_identifier = source.src_identifier
WHEN MATCHED THEN DELETE;
#END <INSERT_BATCH_REJECTS>
""",
            "generic_dwh_load_process.sql": """
#START #EXEC <COLUMN_LIST>
SELECT concat_ws(
    ', ',
    sort_array(
        array_except(
            collect_set(column_name),
            array(
                'src_identifier',
                'row_hash',
                'id',
                'record_created_at',
                'record_updated_at',
                'record_created_by',
                'record_updated_by'
            )
        )
    )
) AS column_list
FROM system.information_schema.columns
WHERE LOWER(table_catalog) = '<DATABASE_NAME>'
  AND LOWER(table_schema) = '<SCHEMA>'
  AND LOWER(table_name) = '<STG_TABLE>';
#END <COLUMN_LIST> 


#START #EXEC <UPDATE_SET_CLAUSE>
SELECT concat_ws(
    ', ',
    sort_array(
        array_except(
            collect_list(concat('s.', column_name)),
            array(
                's.src_identifier',
                's.row_hash',
                's.id',
                's.record_created_at',
                's.record_updated_at',
                's.record_created_by',
                's.record_updated_by'
            )
        )
    )
) AS prefixed_column_list
FROM system.information_schema.columns
WHERE LOWER(table_catalog) = '<DATABASE_NAME>'
  AND LOWER(table_schema) = '<SCHEMA>'
  AND LOWER(table_name) = '<STG_TABLE>';
#END <UPDATE_SET_CLAUSE>

#START <UPDATE_SET_CLAUSE1> 
CREATE OR REPLACE TABLE <DATABASE_NAME>.<SCHEMA>.dataset_<RUN_ID> AS
SELECT * FROM dataset_<RUN_ID>;

EXECUTE IMMEDIATE
(SELECT concat_ws(
    ', ',
    collect_list(concat('t.', c.column_name, ' = s.', c.column_name))
) AS update_set_clause
FROM system.information_schema.columns c
JOIN system.information_schema.columns s
  ON c.column_name = s.column_name
WHERE concat_ws('.', LOWER(c.table_catalog), LOWER(c.table_schema), LOWER(c.table_name)) = '<DATABASE_NAME>.<SCHEMA>.<STG_TABLE>'
  AND concat_ws('.', LOWER(s.table_catalog), LOWER(s.table_schema), LOWER(s.table_name)) = '<DATABASE_NAME>.<SCHEMA>.dataset_<RUN_ID>'
  AND c.column_name NOT IN (
      'src_identifier', 'row_hash',
      'id', 'record_created_at', 'record_updated_at',
      'record_created_by', 'record_updated_by'
  );
INTO update_set_clause;);

#END <UPDATE_SET_CLAUSE1>

#START <GENERIC_DWH_LOAD_PROCESS>
-- Step 1: Store the dynamic SQL into a temp view
CREATE OR REPLACE TEMP VIEW dynamic_sql_vw_<RUN_ID> AS
SELECT CONCAT(
    'MERGE INTO <DATABASE_NAME>.<SCHEMA>.<STG_TABLE> AS t
     USING (
         SELECT * 
         FROM dataset_<RUN_ID>
         WHERE error_messages IS NULL OR error_messages = \'\'
     ) AS s
     ON t.src_identifier = s.src_identifier
     WHEN MATCHED AND (
         t.row_hash <> s.row_hash
         OR (t.row_hash IS NULL AND s.row_hash IS NOT NULL)
         OR (t.row_hash IS NOT NULL AND s.row_hash IS NULL)
     )
     THEN UPDATE SET ',
     concat_ws(
         ', ',
         collect_list(concat('t.', column_name, ' = s.', column_name))
     ),
    ', t.record_updated_at = CURRENT_TIMESTAMP()
     WHEN NOT MATCHED THEN
       INSERT (
         <COLUMN_LIST>, src_identifier, row_hash,
         record_created_at, record_updated_at
       )
       VALUES (
         <UPDATE_SET_CLAUSE>, s.src_identifier, s.row_hash,
         CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
       )'
) AS sql_text
FROM system.information_schema.columns
WHERE concat_ws('.', LOWER(table_catalog), LOWER(table_schema), LOWER(table_name))
      = '<DATABASE_NAME>.<SCHEMA>.<STG_TABLE>'
  AND column_name NOT IN (
      'src_identifier', 'row_hash',
      'id', 'record_created_at', 'record_updated_at',
      'record_created_by', 'record_updated_by'
  );

-- Step 2: Execute the generated SQL
DECLARE OR REPLACE VARIABLE sql_to_execute STRING;
SET VAR sql_to_execute = (SELECT sql_text FROM dynamic_sql_vw_<RUN_ID>);
EXECUTE IMMEDIATE sql_to_execute;

OPTIMIZE <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>   ZORDER BY (src_identifier);
#END <GENERIC_DWH_LOAD_PROCESS>
"""
        }

        for file_name, content in code_snippets.items():
            file_path = f"{self.root}/code_snippets/{file_name}"
            self.upload_file(file_path, content)
            print(f"📄 Uploaded code snippet: {file_name}")

    # -----------------------------
    # Create tests
    # -----------------------------
    def create_tests(self):
        tests = {
            "customer.sql": """----------Custom TEST CASES--------
-- Test 1: All records processed in this run have record_updated_at set
SELECT
    1           AS test_order,
    'CUSTOM'    AS test_phase,
    'UPDATED_AT_NOT_NULL'                                AS test_name,
    'CUSTOM'    AS test_type,
    'WARNING'   AS severity,
    'record_updated_at must not be NULL for any row'     AS description,
    (SELECT CAST(COUNT(*) AS STRING)
     FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
     WHERE record_updated_at IS NULL)                    AS actual_value,
    '0'         AS expected_value,
    '='         AS operator;
""",
            "post_test_cases.sql": """-- ── DEFAULT POST-TESTS ────────────────────────────────────────
-- Test 1: Target table must not be empty after merge
SELECT
    1                                              AS test_order,
    'POST-TEST'                                    AS test_phase,
    'TARGET_NOT_EMPTY'                             AS test_name,
    'DEFAULT'                                      AS test_type,
    'CRITICAL'                                     AS severity,
    '<STG_TABLE> table must have rows after merge' AS description,
    (SELECT CAST(COUNT(*) AS STRING)
     FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>)    AS actual_value,
    '1'                                            AS expected_value,
    '>='                                           AS operator

UNION ALL

-- Test 2: Row count in staging must be >= row count in temp
SELECT
    2,
    'POST-TEST',
    'STG_COUNT_GTE_TEMP',
    'DEFAULT',
    'WARNING',
    '<STG_TABLE> row count must be >= TEMP row count (no data loss)',
    (SELECT CAST(
        (SELECT COUNT(*) FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>)
        -
        (SELECT COUNT(*) FROM dataset_<RUN_ID>)
      AS STRING)),
    '0',
    '>='

UNION ALL

-- Test 3: No duplicate src_identifier in target after merge
SELECT
    3,
    'POST-TEST',
    'STG_PK_DUPLICATES',
    'DEFAULT',
    'CRITICAL',
    'src_identifier must be unique in <STG_TABLE> after merge',
    (SELECT CAST(COUNT(*) AS STRING) FROM (
        SELECT src_identifier
        FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
        GROUP BY src_identifier
        HAVING COUNT(*) > 1
    )),
    '0',
    '='

UNION ALL

-- Test 4: All records processed in this run have record_updated_at set
SELECT
    4,
    'POST-TEST',
    'UPDATED_AT_NOT_NULL',
    'DEFAULT',
    'WARNING',
    'record_updated_at must not be NULL for any row',
    (SELECT CAST(COUNT(*) AS STRING)
     FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
     WHERE record_updated_at IS NULL),
    '0',
    '='

UNION ALL

-- Test 5: Inserts + updates count must be > 0 for active pipelines
SELECT
    5,
    'POST-TEST',
    'MERGE_AFFECTED_ROWS',
    'DEFAULT',
    'WARNING',
    'At least 1 row must be inserted or updated in this run',
    (SELECT CAST(COUNT(*) AS STRING)
     FROM <DATABASE_NAME>.<SCHEMA>.<STG_TABLE>
     WHERE record_updated_at >= (SELECT start_time FROM temp_process_control_<RUN_ID> LIMIT 1)
        OR record_created_at >= (SELECT start_time FROM temp_process_control_<RUN_ID> LIMIT 1)),
    '1',
    '>=';
""",
            "pre_test_cases.sql": """-- ── DEFAULT PRE-TESTS ────────────────────────────────────────
-- Test 1: Source table must exist and be accessible
SELECT
    1                                             AS test_order,
    'PRE-TEST'                                    AS test_phase,
    'SOURCE_TABLE_EXISTS'                         AS test_name,
    'DEFAULT'                                     AS test_type,
    'CRITICAL'                                    AS severity,
    'Source table <RAW_TABLE> must exist'         AS description,
    (SELECT CAST(COUNT(*) AS STRING)
     FROM samples.information_schema.tables
     WHERE LOWER(CONCAT(table_catalog,'.',table_schema, '.', table_name))
           = LOWER('<RAW_TABLE>'))                AS actual_value,
    '1'                                           AS expected_value,
    '>='                                          AS operator

UNION ALL

-- Test 2: Source table must not be empty
SELECT
    2,
    'PRE-TEST',
    'SOURCE_TABLE_NOT_EMPTY',
    'DEFAULT',
    'CRITICAL',
    'Source table <RAW_TABLE> must contain at least 1 row',
    (SELECT CAST(COUNT(*) AS STRING) FROM <RAW_TABLE>),
    '1',
    '>=';
"""
        }

        for file_name, content in tests.items():
            file_path = f"{self.root}/tests/{file_name}"
            self.upload_file(file_path, content)
            print(f"📄 Uploaded test: {file_name}")

    # -----------------------------
    # Create validations
    # -----------------------------
    def create_validations(self):
        validations = {
            "customer.sql": """----- Validation Checks-------------------
CASE WHEN customerID IS NULL THEN 'customerID is null' END,
CASE WHEN email_address IS NULL THEN 'email is null' END,
CASE WHEN phone_number IS NULL THEN 'phone number is null' END,
CASE WHEN postal_zip_code IS NULL THEN 'postal code is null'
     WHEN length(CAST(postal_zip_code AS STRING)) < 5 THEN 'postal code must be at least 5 digits'
END
"""
        }

        for file_name, content in validations.items():
            file_path = f"{self.root}/validations/{file_name}"
            self.upload_file(file_path, content)
            print(f"📄 Uploaded validation: {file_name}")

    # -----------------------------
    # Create job scripts
    # -----------------------------
    def create_job_scripts(self):
        job_script = """-- ----------PROCESS START-------
<SESSION_TAGS>
<BATCH_PROCESS_TABLE>
<PROCESS_START>
<PROCESS_CONTROL_CHECK>
<BATCH_PROCESS_START>
<BATCH_TEST_RESULT>
<BATCH_REJECT_RECORDS>
--  ---------ADD PRE TEST AND CUSTOM TEST CASES--------
<TESTS_PRE_TEST_CASES>

<EXTRACT_DATASET>
-- -------------CHANGE THIS ACCORDING TO YOUR DATASET COLUMNS----------
CREATE OR REPLACE TEMP VIEW extract_transformation_<RUN_ID> AS
    SELECT 
        CAST(<SRC_IDENTIFIER> AS STRING)  AS src_identifier,
        CAST(customerID       AS BIGINT)  AS customerID,
        CAST(first_name       AS STRING)  AS first_name,
        CAST(last_name        AS STRING)  AS last_name,
        CAST(email_address    AS STRING)  AS email_address,
        CAST(phone_number     AS STRING)  AS phone_number,
        CAST(address          AS STRING)  AS address,
        CAST(city             AS STRING)  AS city,
        CAST(state            AS STRING)  AS state,
        CAST(country          AS STRING)  AS country,
        CAST(continent        AS STRING)  AS continent,
        CAST(postal_zip_code  AS BIGINT)  AS postal_zip_code,
        CAST(gender           AS STRING)  AS gender
FROM extract_<RUN_ID>;

CREATE OR REPLACE TEMP VIEW extract_dataset_<RUN_ID> AS
    SELECT *,
        (SELECT start_time FROM temp_process_control_<RUN_ID> LIMIT 1) AS since_ts,
        md5(
            CONCAT_WS('|',
                CAST(customerID      AS STRING),
                CAST(first_name      AS STRING),
                CAST(last_name       AS STRING),
                CAST(email_address   AS STRING),
                CAST(phone_number    AS STRING),
                CAST(address         AS STRING),
                CAST(city            AS STRING),
                CAST(state           AS STRING),
                CAST(country         AS STRING),
                CAST(continent       AS STRING),
                CAST(postal_zip_code AS STRING),
                CAST(gender          AS STRING)
            )
        ) AS row_hash
FROM extract_transformation_<RUN_ID>;

-- -------ADD VALIDATIONS--------
<VALIDATIONS_CUSTOMER>

<GENERIC_DWH_LOAD_PROCESS>

-- -----ADD POST TEST CASES---------
<TESTS_POST_TEST_CASES>

<BATCH_PROCESS_END>
"""
        path = f"{self.root}/job_scripts/job_customer_scripts.sql"
        self.upload_file(path, job_script)
        print(f"📄 Uploaded job script: job_customer_scripts.sql")

    # -----------------------------
    # Create job configs
    # -----------------------------
    def create_job_configs(self):
        config = {
            "TEAM_NAME": "Complere Infosystem",
            "TEAM_EMAIL": "ashutosh.semwal@complereinfosystem.com",
            "DOMAIN_NAME": "Transactions",
            "CATEGORY_NAME": "JOB_SCRIPTS",
            "ENGINE_TYPE": "databricks",
            "DATABASE_NAME": "datajobs",
            "CODE_SNIPPETS": [
                {"path": "code_snippets/validations.sql",              "order": 6},
                {"path": "code_snippets/batch_validation_results.sql", "order": 5},
                {"path": "code_snippets/tests.sql",                    "order": 4},
                {"path": "code_snippets/batch_test_results.sql",       "order": 3},
                {"path": "code_snippets/generic_dwh_load_process.sql", "order": 2},
                {"path": "code_snippets/batch_process.sql",            "order": 1}
            ],
            "JOBS": [
                {
                    "JOB_ID": 1,
                    "JOB_NAME": "load_customer_data",
                    "RAW_TABLE": "samples.bakehouse.sales_customers",
                    "STG_TABLE": "sales_customer_stg",
                    "SCHEMA": "bakehouse",
                    "SRC_IDENTIFIER": "customerID",
                    "TARGET_TABLE_NAME": "sales_customer_stg",
                    "JOB_SCRIPTS": "job_scripts/job_customer_scripts.sql"
                }
            ]
        }

        path = f"{self.root}/job_configs/customer_config.json"
        self.upload_file(path, json.dumps(config, indent=4))
        print(f"📄 Uploaded job config: customer_config.json")

    # -----------------------------
    # Main orchestrator
    # -----------------------------
    def create_all(self):
        print(f"\n🚀 Starting structure creation at: {self.base_path}\n")
        self.create_folders()
        self.create_notebook()         
        self.create_code_snippets()
        self.create_tests()
        self.create_validations()
        self.create_job_scripts()
        self.create_job_configs()
        print(f"\n✅ All done!")
    
# -----------------------------
# Public function
# -----------------------------
def structure_setup_data_jobs(base_path: str):
    obj = DataJobsStructure(base_path=base_path)
    obj.create_all()