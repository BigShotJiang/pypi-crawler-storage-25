"""
Tier 2: Decision cache for cached-LLM simulation.

Pre-computes LLM decisions over a parameter grid, then performs
nearest-neighbour lookup at simulation time.  Coming in v0.2.0.
"""

from __future__ import annotations


class DecisionCache:
    """Placeholder for the Tier 2 decision cache (v0.2.0)."""

    def __init__(self) -> None:
        raise NotImplementedError(
            "DecisionCache (Tier 2) is coming in mimic-sim v0.2.0. "
            "Use mode='tier3' for now."
        )
