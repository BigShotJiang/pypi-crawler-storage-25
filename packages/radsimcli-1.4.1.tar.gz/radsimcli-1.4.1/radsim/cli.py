# RadSim - AI Coding Agent
# Copyright (c) 2024-2026 Matthew Bright
# Licensed under the MIT License. See LICENSE file for details.

"""CLI entry point for RadSim Agent."""

import argparse
import atexit
import os
import signal
import sys
import warnings
from importlib.metadata import version

# Track Ctrl+C presses for emergency stop
_interrupt_count = 0
_last_interrupt = 0

# Reference to active agent for soft cancel
_active_agent = None
_process_handlers_installed = False
_runtime_warnings_configured = False


def set_active_agent(agent):
    """Set the active agent for soft cancel support."""
    global _active_agent
    _active_agent = agent


def _emergency_stop_handler(signum, frame):
    """Handle Ctrl+C with escalating response.

    If agent is processing: soft cancel (set interrupt flag, return to prompt)
    If at prompt: raise KeyboardInterrupt (normal behavior)
    Double Ctrl+C within 2 seconds: HARD KILL
    """
    global _interrupt_count, _last_interrupt
    import time

    current_time = time.time()

    # Reset counter if more than 2 seconds since last interrupt
    if current_time - _last_interrupt > 2:
        _interrupt_count = 0

    _interrupt_count += 1
    _last_interrupt = current_time

    if _interrupt_count >= 2:
        print("\n\n  EMERGENCY STOP - Killing process immediately!")
        os._exit(1)

    # Soft cancel: if agent is actively processing, set interrupt flag
    if _active_agent and _active_agent._is_processing.is_set():
        _active_agent._interrupted.set()
        print("\n\n  warning: Cancelling... (press Ctrl+C again to force kill)")
        return

    # At prompt or no agent: raise KeyboardInterrupt
    print("\n\n  warning: Interrupted. Press Ctrl+C again within 2 seconds to FORCE KILL.")
    raise KeyboardInterrupt


def _cleanup_on_exit():
    """Clean up background processes on exit."""
    modes_module = sys.modules.get("radsim.modes")
    if modes_module is not None:
        try:
            modes_module.stop_caffeinate()
        except Exception:
            pass

    telegram_module = sys.modules.get("radsim.telegram")
    if telegram_module is not None:
        try:
            telegram_module.stop_listening()
        except Exception:
            pass

def configure_runtime_warnings():
    """Apply warning filters only when the CLI runtime starts."""
    global _runtime_warnings_configured
    if _runtime_warnings_configured:
        return

    warnings.filterwarnings(
        "ignore",
        message="Core Pydantic V1 functionality",
        category=UserWarning,
    )
    _runtime_warnings_configured = True


def install_process_handlers():
    """Install signal and exit handlers once per process."""
    global _process_handlers_installed
    if _process_handlers_installed:
        return

    signal.signal(signal.SIGINT, _emergency_stop_handler)
    atexit.register(_cleanup_on_exit)
    _process_handlers_installed = True


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        prog="radsim",
        description="RadSim - Radically Simple Code Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  radsim "Create a Python function to validate emails"
  radsim "Build a REST API in Go"
  radsim --yes "Refactor src/utils.js"
  radsim  (starts interactive mode)

Environment variables:
  RADSIM_PROVIDER   API provider (openrouter, openai, claude)
  RADSIM_API_KEY    Your API key
        """,
    )

    parser.add_argument(
        "prompt",
        nargs="?",
        help="The coding task (omit for interactive mode)",
    )

    parser.add_argument(
        "--provider",
        "-p",
        choices=["openrouter", "openai", "claude"],
        help="API provider (default: openrouter)",
    )

    parser.add_argument(
        "--api-key",
        "-k",
        help="API key (or use RADSIM_API_KEY env var)",
    )

    parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Auto-confirm file writes",
    )

    parser.add_argument(
        "--verbose",
        "-V",
        action="store_true",
        help="Enable verbose output",
    )

    parser.add_argument(
        "--no-stream",
        action="store_true",
        help="Disable streaming responses",
    )

    parser.add_argument(
        "--context-file",
        help="Load initial context from a file (e.g. context.md)",
    )

    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"RadSim {version('radsimcli')}",
    )

    parser.add_argument(
        "--skip-onboarding",
        action="store_true",
        help="Skip the first-time setup wizard",
    )

    parser.add_argument(
        "--setup",
        action="store_true",
        help="Re-run the setup wizard",
    )

    parser.add_argument(
        "--skip-update-check",
        action="store_true",
        help="Skip the startup update check",
    )

    return parser.parse_args()


def _run_single_shot_mode(config, prompt, context_file):
    """Import the agent runtime only when single-shot mode is used."""
    from .agent import run_single_shot
    from .output import print_agent_response

    response = run_single_shot(config, prompt, context_file)
    if not config.stream:
        print_agent_response(response)


def _run_interactive_mode(config, context_file):
    """Import the agent runtime only when interactive mode is used."""
    from .agent import run_interactive

    run_interactive(config, context_file)


def _handle_login_subcommand() -> int | None:
    """Intercept `radsim login <provider>` / `radsim logout <provider>`.

    Returns an exit code if the subcommand was handled, or None to let the
    normal argparse flow proceed.
    """
    if len(sys.argv) < 2 or sys.argv[1] not in ("login", "logout"):
        return None

    sub_parser = argparse.ArgumentParser(prog=f"radsim {sys.argv[1]}")
    sub_parser.add_argument(
        "provider",
        choices=["openrouter", "openai", "claude"],
    )

    sub_args = sub_parser.parse_args(sys.argv[2:])
    from . import login as login_module

    if sys.argv[1] == "login":
        return login_module.run_login(sub_args.provider)
    return login_module.run_logout(sub_args.provider)


def main():
    """Main entry point."""
    from .log_config import configure_logging

    configure_runtime_warnings()
    install_process_handlers()
    configure_logging()

    login_exit = _handle_login_subcommand()
    if login_exit is not None:
        sys.exit(login_exit)

    args = parse_arguments()

    from .access_control import check_access_on_startup
    from .config import load_config
    from .health import check_health, check_secret_expirations
    from .onboarding import run_onboarding, should_run_onboarding
    from .output import print_error

    # T&C is shown only during onboarding (first-time setup), not every login

    # Force re-run setup if --setup flag is passed
    if args.setup:
        api_key, provider, model = run_onboarding()
        if not api_key:
            sys.exit(0)
        args.provider = provider
        args.api_key = api_key
    # Normal first-run onboarding (unless skipped)
    elif (
        should_run_onboarding()
        and not args.skip_onboarding
        and not args.api_key
        and not args.provider
    ):
        api_key, provider, model = run_onboarding()
        if not api_key:
            # User didn't complete onboarding
            sys.exit(0)
        # Override args with onboarding results
        args.provider = provider
        args.api_key = api_key

    # Check access control first (if enabled)
    if not check_access_on_startup():
        sys.exit(1)

    # Load configuration
    try:
        config = load_config(
            provider_override=args.provider,
            api_key_override=args.api_key,
            auto_confirm=args.yes,
            verbose=args.verbose,
            stream=not args.no_stream,
        )
    except ValueError as error:
        print_error(str(error))
        sys.exit(1)

    # Production Readiness: Run startup health checks
    health_status = check_health(config)
    if not health_status.healthy:
        print_error("Health check failed:")
        for name, info in health_status.checks.items():
            if not info["ok"]:
                print_error(f"  - {name}: {info['message']}")
        sys.exit(1)

    # Check for expiring secrets
    expiration_warnings = check_secret_expirations()
    for warning in expiration_warnings:
        if warning["status"] == "expired":
            print_error(f"WARNING: {warning['message']}")
        else:
            print(f"  Note: {warning['message']}")

    # Check for updates (non-blocking, fail-silent)
    if not args.skip_update_check:
        from .update_checker import check_for_updates, format_update_notice

        try:
            current_ver = version("radsimcli")
            latest_ver = check_for_updates(current_ver)
            if latest_ver:
                print(format_update_notice(latest_ver, current_ver))
        except Exception:
            pass  # Never let update check break startup

    # Run in appropriate mode (CLI)
    if args.prompt:
        try:
            _run_single_shot_mode(config, args.prompt, args.context_file)
        except KeyboardInterrupt:
            print("\nCancelled.")
            sys.exit(130)
        except Exception as error:
            print_error(str(error))
            sys.exit(1)
    else:
        try:
            _run_interactive_mode(config, args.context_file)
        except KeyboardInterrupt:
            print("\nGoodbye!")
            sys.exit(130)


if __name__ == "__main__":
    main()
