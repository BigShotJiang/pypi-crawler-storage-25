"""Configuration loader for RadSim Agent."""

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from .runtime_context import get_runtime_context

logger = logging.getLogger(__name__)


REASONING_EFFORT_LEVELS = ("low", "medium", "high")
DEFAULT_REASONING_EFFORT = "medium"


@dataclass
class Config:
    """RadSim configuration."""

    provider: str
    api_key: str
    model: str
    auto_confirm: bool = False
    trust_mode: str = "medium"
    verbose: bool = False
    stream: bool = True
    agent_config: dict = field(default_factory=dict)
    reasoning_effort: str = DEFAULT_REASONING_EFFORT
    # Rate limiting settings (aggressive loop protection)
    max_api_calls_per_turn: int = 15  # Hard stop after 15 calls without user input
    max_session_input_tokens: int = 0  # 0 = unlimited (set to 500000 for budget limit)
    max_session_output_tokens: int = 0  # 0 = unlimited (set to 100000 for budget limit)
    rate_limit_cooldown_ms: int = 50  # Faster cooldown
    circuit_breaker_threshold: int = 3


# Rate limit tiers - user-selectable API call limits per turn
RATE_LIMIT_TIERS = {
    "light": {"max_calls": 15, "label": "Light (15 calls)", "description": "Conservative - good for simple tasks"},
    "standard": {"max_calls": 30, "label": "Standard (30 calls)", "description": "Balanced - recommended for most work"},
    "heavy": {"max_calls": 75, "label": "Heavy (75 calls)", "description": "For complex multi-step tasks"},
    "intensive": {"max_calls": 100, "label": "Intensive (100 calls)", "description": "For large refactors and deep analysis"},
    "unlimited": {"max_calls": 200, "label": "Maximum (200 calls)", "description": "Maximum throughput - use with caution"},
}

DEFAULT_RATE_LIMIT_TIER = "standard"


# Available models for each provider (Updated Feb 2026)
PROVIDER_MODELS = {
    "claude": [
        ("claude-opus-4-6", "Claude Opus 4.6 (Most capable)"),
        ("claude-sonnet-4-5", "Claude Sonnet 4.5 (Recommended)"),
        ("claude-haiku-4-5", "Claude Haiku 4.5 (Fast & cheap)"),
    ],
    "openai": [
        ("gpt-5.4", "GPT-5.4 (Most capable)"),
        ("gpt-5.3-codex", "GPT-5.3 Codex (Agentic coding)"),
        ("gpt-5.2", "GPT-5.2 (Recommended)"),
        ("gpt-5.2-codex", "GPT-5.2 Codex (Cheap)"),
        ("gpt-5-mini", "GPT-5 Mini (Fast & cheap)"),
    ],
    "openrouter": [
        ("moonshotai/kimi-k2.5", "Kimi K2.5 (Recommended)"),
        ("anthropic/claude-opus-4.6", "Claude Opus 4.6 via OpenRouter"),
        ("anthropic/claude-sonnet-4.6", "Claude Sonnet 4.6 via OpenRouter"),
        ("openai/gpt-5.4", "GPT-5.4 via OpenRouter"),
        ("openai/gpt-5.3-codex", "GPT-5.3 Codex via OpenRouter"),
        ("openai/gpt-5.2-codex", "GPT-5.2 Codex via OpenRouter (Cheap)"),
        ("minimax/minimax-m2.1", "Minimax M2.1 (Fast)"),
        ("z-ai/glm-4.7", "GLM 4.7 (Capable)"),
    ],
}

# Default model for each provider (Updated Feb 2026)
DEFAULT_MODELS = {
    "openrouter": "moonshotai/kimi-k2.5",
    "openai": "gpt-5.4",
    "claude": "claude-sonnet-4-5",
}

PROVIDER_URLS = {
    "openrouter": "https://openrouter.ai/keys",
    "openai": "https://platform.openai.com/api-keys",
    "claude": "https://console.anthropic.com/settings/keys",
}

# Provider-specific environment variable names
PROVIDER_ENV_VARS = {
    "openrouter": "OPENROUTER_API_KEY",
    "openai": "OPENAI_API_KEY",
    "claude": "ANTHROPIC_API_KEY",
}

# Fallback models for automatic failover (in priority order)
FALLBACK_MODELS = {
    "claude": [
        "claude-sonnet-4-5",
        "claude-haiku-4-5",
    ],
    "openai": [
        "gpt-5.4",
        "gpt-5.3-codex",
        "gpt-5.2",
        "gpt-5.2-codex",
        "gpt-5-mini",
    ],
    "openrouter": [
        "moonshotai/kimi-k2.5",
        "anthropic/claude-opus-4.6",
        "anthropic/claude-sonnet-4.6",
        "openai/gpt-5.4",
        "openai/gpt-5.3-codex",
        "openai/gpt-5.2-codex",
        "minimax/minimax-m2.1",
        "z-ai/glm-4.7",
    ],
}

# Pricing per 1M tokens (input, output) in USD - Updated Feb 2026
MODEL_PRICING = {
    # Claude Series
    "claude-opus-4-6": (15.00, 75.00),
    "claude-sonnet-4-5": (3.00, 15.00),
    "claude-haiku-4-5": (0.80, 4.00),
    # OpenAI GPT-5 Series
    "gpt-5.4": (5.00, 15.00),
    "gpt-5.3-codex": (5.00, 15.00),
    "gpt-5.2": (2.50, 10.00),
    "gpt-5.2-codex": (2.50, 10.00),
    "gpt-5-mini": (1.00, 4.00),
    # OpenRouter models
    "moonshotai/kimi-k2.5": (0.14, 0.28),
    "anthropic/claude-opus-4.6": (5.00, 25.00),
    "anthropic/claude-sonnet-4.6": (3.00, 15.00),
    "openai/gpt-5.4": (2.50, 15.00),
    "openai/gpt-5.3-codex": (1.75, 14.00),
    "openai/gpt-5.2-codex": (0.60, 2.40),
    "minimax/minimax-m2.1": (0.20, 0.55),
    "z-ai/glm-4.7": (0.50, 0.50),
}

# Context window limits per model (in tokens) - Updated Feb 2026
CONTEXT_LIMITS = {
    # Claude Series
    "claude-opus-4-6": 200000,
    "claude-sonnet-4-5": 200000,
    "claude-haiku-4-5": 200000,
    # OpenAI GPT-5 Series
    "gpt-5.4": 1050000,
    "gpt-5.3-codex": 400000,
    "gpt-5.2": 256000,
    "gpt-5.2-codex": 256000,
    "gpt-5-mini": 128000,
    # OpenRouter models
    "anthropic/claude-opus-4.6": 1000000,
    "anthropic/claude-sonnet-4.6": 1000000,
    "openai/gpt-5.4": 1050000,
    "openai/gpt-5.3-codex": 400000,
    "openai/gpt-5.2-codex": 128000,
}

# Model-specific capabilities and settings per provider documentation
# RadSim Principle: Explicit Configuration Over Implicit Defaults
MODEL_CAPABILITIES = {
    # Claude Series
    "claude-opus-4-6": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_extended_thinking": True,
        "supports_vision": True,
        "max_output_tokens": 16384,
    },
    "claude-sonnet-4-5": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_extended_thinking": True,
        "supports_vision": True,
        "max_output_tokens": 8192,
    },
    "claude-haiku-4-5": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_extended_thinking": False,
        "supports_vision": True,
        "max_output_tokens": 4096,
    },
    # GPT-5 Series - Multimodal with O-series reasoning
    "gpt-5.4": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": True,
        "max_output_tokens": 128000,
    },
    "gpt-5.3-codex": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": False,
        "max_output_tokens": 16384,
    },
    "gpt-5.2": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": True,
        "max_output_tokens": 16384,
    },
    "gpt-5.2-codex": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": False,
        "max_output_tokens": 16384,
    },
    "gpt-5-mini": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": True,
        "max_output_tokens": 8192,
    },
    # OpenRouter models (Claude/OpenAI via OpenRouter)
    "anthropic/claude-opus-4.6": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_extended_thinking": True,
        "supports_vision": True,
        "max_output_tokens": 16384,
    },
    "anthropic/claude-sonnet-4.6": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_extended_thinking": True,
        "supports_vision": True,
        "max_output_tokens": 8192,
    },
    "openai/gpt-5.4": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": True,
        "max_output_tokens": 128000,
    },
    "openai/gpt-5.3-codex": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": False,
        "max_output_tokens": 16384,
    },
    "openai/gpt-5.2-codex": {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_reasoning": True,
        "supports_vision": False,
        "max_output_tokens": 16384,
    },
}


def get_model_capabilities(model: str) -> dict:
    """Get capabilities for a specific model.

    RadSim Principle: Graceful Degradation
    Returns default capabilities if model not found.
    """
    default_capabilities = {
        "supports_tools": True,
        "supports_streaming": True,
        "supports_vision": False,
        "max_output_tokens": 4096,
    }
    return MODEL_CAPABILITIES.get(model, default_capabilities)


CONFIG_DIR = Path.home() / ".radsim"
ENV_FILE = CONFIG_DIR / ".env"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
MEMORY_DIR = CONFIG_DIR / "memory"
SCHEDULES_FILE = CONFIG_DIR / "schedules.json"
PACKAGE_DIR = Path(__file__).parent  # The radsim source directory
CUSTOM_PROMPT_FILE = CONFIG_DIR / "custom_prompt.txt"
PROJECT_ENV_FILE = PACKAGE_DIR.parent / ".env"


def load_env_file():
    """Load config from .env files.

    Reads a preferred env file first when configured, then the project-root
    .env next to the current source checkout, then the global ~/.radsim/.env.
    Preferred env files can come from `RADSIM_ENV_FILE`, `settings.json`,
    or the remembered `preferred_env_file` memory preference.

    Supports both RADSIM_API_KEY and provider-specific keys.
    """
    result = {"api_key": None, "provider": None, "model": None, "keys": {}}

    env_files_to_check = []

    preferred_env_file = _get_preferred_env_file()
    if preferred_env_file is not None and preferred_env_file.exists():
        env_files_to_check.append(preferred_env_file)

    try:
        cwd_env_file = Path.cwd() / ".env"
    except (FileNotFoundError, OSError):
        cwd_env_file = None

    candidate_files = []
    if cwd_env_file is not None:
        candidate_files.append(cwd_env_file)
    candidate_files.extend([PROJECT_ENV_FILE, ENV_FILE])

    for env_file in candidate_files:
        if env_file.exists() and env_file not in env_files_to_check:
            env_files_to_check.append(env_file)

    if not env_files_to_check:
        return result

    # Process global config only
    for env_file in env_files_to_check:
        try:
            content = env_file.read_text()
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue

                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()

                # Remove quotes if present
                if (value.startswith('"') and value.endswith('"')) or (
                    value.startswith("'") and value.endswith("'")
                ):
                    value = value[1:-1]

                # Only set if not already set (priority to earlier files)
                if key == "RADSIM_API_KEY" and not result["api_key"]:
                    result["api_key"] = value
                elif key == "RADSIM_PROVIDER" and not result["provider"]:
                    result["provider"] = value
                elif key == "RADSIM_MODEL" and not result["model"]:
                    result["model"] = value
                # Also capture provider-specific API keys and access code
                elif key in (
                    "ANTHROPIC_API_KEY",
                    "OPENAI_API_KEY",
                    "OPENROUTER_API_KEY",
                    "RADSIM_ACCESS_CODE",
                    "TELEGRAM_BOT_TOKEN",
                    "TELEGRAM_CHAT_ID",
                ):
                    if key not in result["keys"]:
                        result["keys"][key] = value
        except Exception:
            logger.debug(f"Failed to parse env file: {env_file}")

    return result


def _get_preferred_env_file() -> Path | None:
    """Return a user-configured env file path when one is available."""
    env_file_path = os.getenv("RADSIM_ENV_FILE")
    if not env_file_path:
        settings = load_settings_file()
        env_file_path = settings.get("env_file")
    if not env_file_path:
        try:
            memory = get_runtime_context().get_memory()
            env_file_path = memory.global_mem.get_preference("preferred_env_file")
        except Exception:
            logger.debug("Preferred env file lookup failed", exc_info=True)
            return None

    if not env_file_path:
        return None

    return Path(env_file_path).expanduser()


def load_settings_file():
    """Load config from settings.json file."""
    if not SETTINGS_FILE.exists():
        return {}

    try:
        return json.loads(SETTINGS_FILE.read_text())
    except Exception:
        logger.debug(f"Failed to parse settings file: {SETTINGS_FILE}")
        return {}


def save_config(api_key, provider, model):
    """Save config to .env file with secure permissions.

    Saves provider, model, AND API key to ~/.radsim/.env
    Preserves existing API keys from other providers.
    File is chmod 600 (owner read/write only) for security.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Get provider-specific env var name
    env_var = PROVIDER_ENV_VARS.get(provider, "RADSIM_API_KEY")

    # Load existing keys to preserve them
    existing_config = load_env_file()
    existing_keys = existing_config.get("keys", {})

    # Update with the new key
    existing_keys[env_var] = api_key

    # Build content preserving all API keys
    lines = [
        "# RadSim Configuration",
        "# This file is chmod 600 (secure)",
        "",
        f'RADSIM_PROVIDER="{provider}"',
        f'RADSIM_MODEL="{model}"',
        "",
        "# API Keys (preserved across provider switches)",
    ]

    # Add all API keys
    for key_name, key_value in existing_keys.items():
        if key_value and not key_value.lower().startswith("paste_your"):
            lines.append(f'{key_name}="{key_value}"')

    lines.append("")  # Trailing newline

    ENV_FILE.write_text("\n".join(lines))
    ENV_FILE.chmod(0o600)  # Secure: owner read/write only


def save_reasoning_effort(effort: str) -> None:
    """Persist global reasoning effort to settings.json."""
    if effort not in REASONING_EFFORT_LEVELS:
        raise ValueError(
            f"Invalid reasoning_effort: {effort}. "
            f"Expected one of {REASONING_EFFORT_LEVELS}."
        )
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    settings = load_settings_file()
    settings["reasoning_effort"] = effort
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))


def load_reasoning_effort() -> str:
    """Read global reasoning effort from settings.json, default to medium."""
    effort = load_settings_file().get("reasoning_effort", DEFAULT_REASONING_EFFORT)
    if effort not in REASONING_EFFORT_LEVELS:
        return DEFAULT_REASONING_EFFORT
    return effort


def save_rate_limit_tier(tier_name):
    """Save rate limit tier to settings.json.

    Args:
        tier_name: One of the keys from RATE_LIMIT_TIERS.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    settings = load_settings_file()
    settings["rate_limit_tier"] = tier_name
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))


def _format_model_label(entry: dict) -> str:
    """Build a TUI-friendly label from a normalized OpenRouter model entry."""
    label = entry.get("name") or entry["id"]
    suffix_parts = []
    if entry.get("supports_reasoning"):
        suffix_parts.append("reasoning")
    ctx = entry.get("context_length") or 0
    if ctx:
        suffix_parts.append(f"{ctx // 1000}k ctx")
    if suffix_parts:
        return f"{label} ({', '.join(suffix_parts)})"
    return label


def _build_openrouter_choices(top_only: bool = True) -> list[tuple[str, str]]:
    """Return (model_id, label) pairs for the OpenRouter catalogue.

    When top_only is True, returns the curated short list from
    PROVIDER_MODELS enriched with live capability metadata when available.
    Otherwise returns the full live catalogue.
    """
    from .openrouter_models import find_model, get_openrouter_models

    if top_only:
        choices = []
        for model_id, fallback_label in PROVIDER_MODELS["openrouter"]:
            entry = find_model(model_id)
            if entry:
                choices.append((model_id, _format_model_label(entry)))
            else:
                choices.append((model_id, fallback_label))
        return choices

    catalogue = get_openrouter_models()
    if not catalogue:
        return PROVIDER_MODELS["openrouter"]
    return [(entry["id"], _format_model_label(entry)) for entry in catalogue]


def _select_openrouter_model() -> str | None:
    """Two-level OpenRouter picker: curated top list with an opt-in full browse."""
    top = _build_openrouter_choices(top_only=True)
    expand_index = len(top) + 1

    print()
    print("  Recommended OpenRouter models:")
    for i, (_, label) in enumerate(top, 1):
        print(f"    {i}. {label}")
    print(f"    {expand_index}. Show all models…")
    print()

    try:
        choice = input(f"  Enter 1-{expand_index} [1]: ").strip() or "1"
    except (KeyboardInterrupt, EOFError):
        return None

    try:
        idx = int(choice) - 1
    except ValueError:
        return top[0][0]

    if idx == len(top):
        return _select_from_full_openrouter()
    if 0 <= idx < len(top):
        return top[idx][0]
    return top[0][0]


def _vendor_of(model_id: str) -> str:
    """Extract the vendor prefix from an OpenRouter model id (e.g. anthropic/claude-…)."""
    if "/" in model_id:
        return model_id.split("/", 1)[0]
    return "other"


def _group_by_vendor(choices: list[tuple[str, str]]) -> dict[str, list[tuple[str, str]]]:
    grouped: dict[str, list[tuple[str, str]]] = {}
    for model_id, label in choices:
        grouped.setdefault(_vendor_of(model_id), []).append((model_id, label))
    return grouped


def _select_from_full_openrouter() -> str | None:
    """Browse the full OpenRouter catalogue via a vendor menu or substring search."""
    full = _build_openrouter_choices(top_only=False)
    if not full:
        print("  warning: full catalogue unavailable, using top list.")
        top = _build_openrouter_choices(top_only=True)
        return top[0][0] if top else None

    grouped = _group_by_vendor(full)
    vendors = sorted(grouped.keys(), key=lambda v: (-len(grouped[v]), v))

    while True:
        print()
        print(f"  Browse {len(full)} models by vendor:")
        for i, vendor in enumerate(vendors, 1):
            print(f"    {i}. {vendor} ({len(grouped[vendor])})")
        search_index = len(vendors) + 1
        back_index = len(vendors) + 2
        print(f"    {search_index}. Search by name…")
        print(f"    {back_index}. Back")
        print()

        try:
            choice = input(f"  Enter 1-{back_index}: ").strip()
        except (KeyboardInterrupt, EOFError):
            return None

        try:
            idx = int(choice) - 1
        except ValueError:
            continue

        if idx == back_index - 1:
            return None
        if idx == search_index - 1:
            picked = _search_openrouter_models(full)
            if picked:
                return picked
            continue
        if 0 <= idx < len(vendors):
            picked = _select_from_vendor(vendors[idx], grouped[vendors[idx]])
            if picked:
                return picked
            continue


def _select_from_vendor(vendor: str, models: list[tuple[str, str]]) -> str | None:
    print()
    print(f"  {vendor} ({len(models)} models):")
    for i, (_, label) in enumerate(models, 1):
        print(f"    {i}. {label}")
    back_index = len(models) + 1
    print(f"    {back_index}. Back")
    print()

    try:
        choice = input(f"  Enter 1-{back_index}: ").strip()
    except (KeyboardInterrupt, EOFError):
        return None

    try:
        idx = int(choice) - 1
    except ValueError:
        return None

    if idx == len(models):
        return None
    if 0 <= idx < len(models):
        return models[idx][0]
    return None


def _search_openrouter_models(full: list[tuple[str, str]]) -> str | None:
    print()
    try:
        query = input("  Search (substring of name or id): ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        return None
    if not query:
        return None

    filtered = [
        (model_id, label)
        for model_id, label in full
        if query in model_id.lower() or query in label.lower()
    ]
    if not filtered:
        print(f"  No matches for '{query}'.")
        return None

    print()
    print(f"  Matches ({len(filtered)}):")
    for i, (_, label) in enumerate(filtered, 1):
        print(f"    {i}. {label}")
    back_index = len(filtered) + 1
    print(f"    {back_index}. Back")
    print()

    try:
        choice = input(f"  Enter 1-{back_index}: ").strip()
    except (KeyboardInterrupt, EOFError):
        return None

    try:
        idx = int(choice) - 1
    except ValueError:
        return None

    if idx == len(filtered):
        return None
    if 0 <= idx < len(filtered):
        return filtered[idx][0]
    return None


def _maybe_prompt_reasoning_effort(provider: str, model: str) -> None:
    """Prompt for reasoning effort when the chosen model supports it."""
    if provider not in ("openai", "openrouter"):
        return
    capabilities = MODEL_CAPABILITIES.get(model, {})
    supports_reasoning = capabilities.get("supports_reasoning", False)
    if provider == "openrouter":
        from .openrouter_models import model_supports_reasoning
        supports_reasoning = supports_reasoning or model_supports_reasoning(model)
    if not supports_reasoning:
        return

    print()
    print("  This model supports reasoning. Choose effort level:")
    print("    1. low (cheapest, faster, less thinking)")
    print("    2. medium (recommended)")
    print("    3. high (deepest reasoning, more tokens)")
    print()
    try:
        choice = input("  Enter 1-3 [2]: ").strip() or "2"
    except (KeyboardInterrupt, EOFError):
        return
    mapping = {"1": "low", "2": "medium", "3": "high"}
    effort = mapping.get(choice, "medium")
    save_reasoning_effort(effort)
    print(f"  ok Reasoning effort set to '{effort}'.")


def setup_config(first_time=True):
    """Prompt user to configure RadSim via .env file.

    Security: Never ask for API keys directly in conversation.
    """
    print()
    if first_time:
        print("  ╭─────────────────────────────────────╮")
        print("  │      RadSim - First Time Setup      │")
        print("  ╰─────────────────────────────────────╯")
        print()
        print("  [api key] For security, API keys must be set in the .env file.")
        print()
        print("  Edit your .env file:")
        print("    Local:  ./.env")
        print(f"    Global: {ENV_FILE}")
        print()
        print("  Add your API key for your chosen provider:")
        print("    OPENROUTER_API_KEY   - https://openrouter.ai/keys")
        print("    OPENAI_API_KEY       - https://platform.openai.com/api-keys")
        print("    ANTHROPIC_API_KEY    - https://console.anthropic.com/settings/keys")
        print()
        print("  Then run 'radsim' again.")
        print()
    else:
        print("  ╭─────────────────────────────────────╮")
        print("  │        RadSim - Configuration       │")
        print("  ╰─────────────────────────────────────╯")
    print()
    print("  Select your AI provider:")
    print("    1. OpenRouter (recommended — free models available)")
    print("    2. OpenAI (GPT-5)")
    print("    3. Claude (Anthropic)")
    print()

    try:
        choice = input("  Enter 1-3: ").strip()
    except (KeyboardInterrupt, EOFError):
        print("\n  Setup cancelled.")
        return None, None, None

    provider_map = {
        "1": "openrouter",
        "2": "openai",
        "3": "claude",
    }
    provider = provider_map.get(choice)

    if not provider:
        print("  Invalid choice.")
        return None, None, None

    # Select model — OpenRouter uses a two-level dynamic picker, others a static list
    if provider == "openrouter":
        model = _select_openrouter_model()
        if not model:
            print("\n  Setup cancelled.")
            return None, None, None
    else:
        print()
        print("  Select model:")
        models = PROVIDER_MODELS[provider]
        for i, (_, model_name) in enumerate(models, 1):
            print(f"    {i}. {model_name}")
        print()

        try:
            model_choice = input(f"  Enter 1-{len(models)} [1]: ").strip() or "1"
        except (KeyboardInterrupt, EOFError):
            print("\n  Setup cancelled.")
            return None, None, None

        try:
            model_index = int(model_choice) - 1
            if 0 <= model_index < len(models):
                model = models[model_index][0]
            else:
                model = models[0][0]
        except ValueError:
            model = models[0][0]

    _maybe_prompt_reasoning_effort(provider, model)

    env_var_name = PROVIDER_ENV_VARS.get(provider, "RADSIM_API_KEY")

    # Standard API key flow
    # Check environment first, then .env file
    existing_key = os.getenv(env_var_name)
    if not existing_key:
        env_config = load_env_file()
        existing_key = env_config.get("keys", {}).get(env_var_name)

    if existing_key and not existing_key.startswith("PASTE_YOUR"):
        print()
        print(f"  ok Found {env_var_name} configured.")
        api_key = existing_key
    else:
        print()
        print(f"  warning: No API key found for {provider}.")
        print()
        print("  [api key] For security, please edit your .env file directly:")
        print(f"     ./.env  OR  {ENV_FILE}")
        print()
        print(f'     Add: {env_var_name}="your-api-key"')
        print()
        print(f"     Get key from: {PROVIDER_URLS[provider]}")
        print()
        print("  Then run 'radsim' again.")
        return None, None, None

    # Save provider and model preferences
    save_config(api_key, provider, model)
    print()
    print(f"  ok Preferences saved to {ENV_FILE}")
    print()

    return api_key, provider, model


def load_config(
    provider_override=None, api_key_override=None, auto_confirm=False, verbose=False, stream=True
):
    """Load configuration from environment or overrides."""
    # Load from env files and settings.json
    env_config = load_env_file()
    settings_config = load_settings_file()

    agent_config = settings_config.get("agent_config", {})

    # Determine provider (priority: override > env var > env files > settings.json > default)
    provider = (
        provider_override
        or os.getenv("RADSIM_PROVIDER")
        or env_config["provider"]
        or settings_config.get("default_provider")
        or "openrouter"
    )

    # Determine API key
    # Priority: 1) CLI override, 2) env files (provider-specific), 3) env files (RADSIM_API_KEY),
    # 4) System env var
    api_key = api_key_override
    provider_env_var = PROVIDER_ENV_VARS.get(provider)

    def is_placeholder_key(key):
        """Check if key is a placeholder, not a real API key."""
        if not key:
            return True
        key_lower = key.lower().strip()
        return (
            key_lower.startswith("paste_your")
            or key_lower.startswith("your-")
            or key_lower == ""
            or "placeholder" in key_lower
        )

    if not api_key:
        # 1. Check .env file for provider-specific key (SECURE - preferred)
        if provider_env_var and provider_env_var in env_config.get("keys", {}):
            candidate = env_config["keys"][provider_env_var]
            if not is_placeholder_key(candidate):
                api_key = candidate

    if not api_key:
        # 2. Check .env file for RADSIM_API_KEY
        api_key = env_config.get("api_key")

    if not api_key:
        # 3. Fall back to system environment variable
        if provider_env_var:
            api_key = os.getenv(provider_env_var)

    if not api_key:
        # 4. Legacy fallback
        api_key = os.getenv("RADSIM_API_KEY")

    # Determine model (priority: env var > env files > settings.json > default)
    model = (
        os.getenv("RADSIM_MODEL") or env_config.get("model") or settings_config.get("default_model")
    )

    # Global flags
    final_verbose = verbose or settings_config.get("verbose", False)

    # If stream is passed as False (specifically disabled), respect that.
    final_stream = stream
    if stream and "stream" in settings_config:
        final_stream = settings_config["stream"]

    if not api_key:
        # Prompt user for setup
        api_key, selected_provider, selected_model = setup_config()
        if not api_key:
            raise ValueError("API key is required to use RadSim.")
        if selected_provider:
            provider = selected_provider
        if selected_model:
            model = selected_model

    if provider not in DEFAULT_MODELS:
        raise ValueError(
            f"Unknown provider: {provider}\nSupported: {', '.join(DEFAULT_MODELS.keys())}"
        )

    # Use default model if none specified
    if not model:
        model = DEFAULT_MODELS[provider]

    # Load rate limit tier from settings
    rate_limit_tier = settings_config.get("rate_limit_tier", DEFAULT_RATE_LIMIT_TIER)
    if rate_limit_tier not in RATE_LIMIT_TIERS:
        rate_limit_tier = DEFAULT_RATE_LIMIT_TIER
    max_api_calls = RATE_LIMIT_TIERS[rate_limit_tier]["max_calls"]

    reasoning_effort = settings_config.get("reasoning_effort", DEFAULT_REASONING_EFFORT)
    if reasoning_effort not in REASONING_EFFORT_LEVELS:
        reasoning_effort = DEFAULT_REASONING_EFFORT

    return Config(
        provider=provider,
        api_key=api_key,
        model=model,
        auto_confirm=auto_confirm,
        verbose=final_verbose,
        stream=final_stream,
        agent_config=agent_config,
        reasoning_effort=reasoning_effort,
        max_api_calls_per_turn=max_api_calls,
    )
