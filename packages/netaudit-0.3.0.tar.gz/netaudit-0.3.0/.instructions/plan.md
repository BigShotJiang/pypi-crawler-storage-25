# Netaudit Development Plan (Refined)

## Context

netaudit is a Python CLI/library that wraps processes under `strace`, captures `connect()` syscalls, and validates them against a declarative YAML allowlist. Goal: CI-native network egress auditing — commit a config, run tests, get pass/fail.

Starting from scratch on `main` (README + LICENSE only, no remote). Each phase produces a testable, CI-validated increment.

### Decisions

- **Versioning:** 0.x semver until API stabilizes, then 1.0
- **First public release:** Phase 3 (when CLI is usable), tagged 0.1.0
- **Docs:** MkDocs Material, deployed to Read the Docs — deferred until Phase 3 (docstrings + README before that)
- **CI:** Ubuntu-only for integration tests, cross-platform for unit tests
- **Changelog:** None until v1
- **pytest plugin:** Session-level first, per-test attribution second commit in same phase
- **Type checking:** mypy strict from Phase 0, `py.typed` marker included
- **Skills:** Only `/commit` from day one; others added when needed

---

## Phase Overview

```
Phase 0: Scaffold ──► Phase 1: Core Engine ──► Phase 2: Runner + Integration
    │                  (parser+allowlist+       (strace subprocess,
    │                   reporter)                end-to-end tests)
    │                                                │
    ▼                                                ▼
  CI v1 (lint+test)                         CI v2 (+integration on Ubuntu)
                                                     │
                                                     ▼
                                            Phase 3: CLI + Docs
                                             (click CLI, mkdocs,
                                              first release 0.1.0)
                                                     │
                                                     ▼
                                            Phase 4: pytest Plugin
                                             (session-level, then
                                              per-test attribution)
                                                     │
                                                     ▼
                                            Phase 5: CLI Enhancements
                                             (--verbose, allowed-call
                                              output, rule name display)
                                                     │
                                                     ▼
                                            Phase 5.5: pytest verbose
                                             (--netaudit-verbose flag,
                                              pyproject.toml config)
                                                     │
                                                     ▼
                                            Phase 6: Release Engineering
                                             (automated PyPI, Docker,
                                              GH Pages, hardening)
```

---

## Phase 0 — Scaffold ✅ DONE

**Goal:** Buildable, installable, lintable skeleton with CI.

- `pyproject.toml`: metadata, deps (`click`, `pyyaml`), dev deps (`pytest`, `ruff`, `mypy`, `pytest-cov`), entry point `netaudit = netaudit.cli:main`
- Package: `netaudit/__init__.py` (version string), `netaudit/integrations/__init__.py`
- `py.typed` marker
- `.gitignore` (Python template + `.strace-out/` + `.venv/`)
- Ruff config: `line-length=100`, `select = ["E", "F", "W", "I"]`
- Mypy config: `strict = true`
- Empty `tests/conftest.py`
- `.venv` local development — created via `python -m venv .venv`, editable install with dev deps
- `Makefile` with `venv`, `lint`, `test`, `clean` targets for one-command local workflow
- GitHub Actions CI (`.github/workflows/ci.yml`): lint (ruff check + ruff format --check + mypy), test (pytest, no tests yet)
- `.claude/commands/commit.md`: conventional commit skill — auto-detects type from diff, GPG-signed, no co-author

**Exit:** `make venv && make lint && make test` works, CI green, `netaudit --help` prints placeholder.

---

## Phase 1 — Core Engine (Parser + Allowlist + Reporter) ✅ DONE

**Goal:** Parse strace output, match against rules, report violations. All tested without strace.

**Parser** (`netaudit/parser.py`):
- `ConnectEvent` dataclass: `pid`, `timestamp`, `family`, `addr`, `port`, `raw_line`, `result`
- `StraceParser.parse_line(line) -> ConnectEvent | None`
- `StraceParser.parse_stream(lines: Iterable[str]) -> list[ConnectEvent]`
- Handle: AF_INET, AF_INET6, AF_UNIX, AF_NETLINK
- Handle: EINPROGRESS (non-blocking connect — not a failure), resumed lines (`<... connect resumed>`)

**Allowlist** (`netaudit/allowlist.py`):
- `Rule` protocol: `matches(event: ConnectEvent) -> bool`
- Concrete: `IPv4Rule(cidr)`, `IPv6Rule(cidr)`, `UnixSocketRule(path_glob)`, `NetlinkRule`
- `AllowList`: load from YAML, `includes_builtins: true` by default (loopback 127.0.0.0/8, ::1/128, all AF_UNIX, all AF_NETLINK)
- `AllowList.is_allowed(event) -> bool`

**Reporter** (`netaudit/reporter.py`):
- `Violation`: groups events by `(family, addr, port)` — tracks PIDs, count, first timestamp
- `Reporter.check(events, allowlist) -> list[Violation]`
- `Reporter.format(violations, stream)` — box-formatted human-readable output

**Tests:** hardcoded strace lines for parser (all families, EINPROGRESS, resumed, malformed), YAML loading + CIDR matching + builtins for allowlist, grouping + formatting for reporter.

**CI update:** Tests run with `--cov=netaudit --cov-fail-under=80`.

**Exit:** All three modules compose together. Tests pass, coverage >= 80%.

---

## Phase 2 — Runner + Integration Tests ✅ DONE

**Goal:** Spawn strace, capture output, validate end-to-end on real syscalls.

**Runner** (`netaudit/runner.py`):
- `StraceRunner.run(command, output_path) -> CompletedProcess` — spawn under `strace -e trace=connect -f -tt -o <path>`
- `StraceRunner.start(command, output_path) -> StraceProcess` / `.stop() -> CompletedProcess`
- Runtime check: `StraceNotFoundError` if `shutil.which("strace")` is None

**Test target** (`tests/integration/egress_target.py`):
- Starts a local `http.server`, connects to it
- Opens a Unix socket
- Triggers DNS/netlink via `socket.getaddrinfo`
- Attempts external connect to `198.51.100.1:443` (TEST-NET-2 — won't route, no flaky external deps)

**Integration tests** (`tests/integration/test_end_to_end.py`, marked `@pytest.mark.integration`):
- strace output file created and non-empty
- Parser extracts expected event types from real output
- External IP `198.51.100.1` produces violation
- Loopback + unix + netlink allowed by default
- Custom allowlist passes external IP

**CI update:** Add `integration` job on `ubuntu-latest` (installs strace via apt). Unit tests remain cross-platform.

**Exit:** Full pipeline works end-to-end. Integration tests green in CI.

---

## Phase 3 — CLI + Docs (First Release 0.1.0) ✅ DONE

**Goal:** User-facing CLI, documentation site, tagged 0.1.0.

**CLI** (`netaudit/cli.py`):
- `netaudit run --allowlist <yaml> -- <command>` — trace, analyze, report, exit 1 on violations
- `netaudit analyze --allowlist <yaml> <strace-log>` — offline analysis
- `--format {text,json}` for machine-readable output
- `--allowlist` defaults to `netaudit.yaml` in cwd if it exists
- Exit codes: 0 clean, 1 violations, 2 strace missing

**Tests** (`tests/test_cli.py`):
- Click `CliRunner` tests (mocked runner for `run`, real file for `analyze`)
- Exit code semantics

**Docs** (`docs/` + `mkdocs.yml`):
- MkDocs Material: nav, search, code highlighting
- Pages: index (overview + quickstart), cli-reference, allowlist-dsl, architecture
- README.md updated with badges, install instructions, quickstart

**CI update:** Add `mkdocs build --strict` to lint job.

**Exit:** Both CLI commands work. Docs build. Tagged `v0.1.0`.

### Out-of-plan additions (done during this phase)

- **PyPI publish:** package manually published to PyPI as `netaudit 0.1.0`; `pyproject.toml` enriched with `authors`, `classifiers`, `keywords`, `urls`
- **Read the Docs:** `.readthedocs.yaml` added; docs building at `netaudit.readthedocs.io`
- **README badges:** CI, PyPI version, Python versions, Apache 2.0 license; cache-busting query params added for GitHub's camo proxy
- **Makefile:** `docs` and `docs-serve` targets added; `venv` now installs `[dev,docs]`

---

## Phase 4 — pytest Plugin ✅ DONE

**Goal:** Automatic network auditing during pytest runs.

**Session-level** (first commit):
- `netaudit/integrations/pytest_plugin.py`, registered via `pytest11` entry point
- `pytest_addoption`: `--netaudit`, `--netaudit-allowlist`
- `pytest_sessionstart`: start strace tracing the test process
- `pytest_sessionfinish`: stop, parse, check, report violations, set exit code
- Allowlist resolution: CLI flag > `[tool.netaudit]` in pyproject.toml > `netaudit.yaml` in cwd

**Per-test attribution** (second commit):
- `pytest_runtest_protocol`: write timestamp markers to sidecar file at test boundaries
- Correlate ConnectEvents with test items by timestamp range
- Reporter enriched: violations grouped by test name

**Tests:** `pytester`-based tests for both modes.

**Docs:** `docs/pytest-plugin.md` — usage, config, examples.

**Exit:** `pytest --netaudit` traces and reports. Per-test attribution shows which test caused each violation.

---

## Phase 5 — CLI Enhancements (Verbose / Allowed-calls Output) ✅ DONE

**Goal:** Give users visibility into all network calls, not just violations.

**New CLI flag** (`--verbose` / `-v`):
- Available on both `netaudit run` and `netaudit analyze`
- When set, output includes *all* `ConnectEvent`s — allowed and violating alike
- Allowed events are annotated with the name of the matching allowlist rule (sourced from the `name` field in the YAML entry)
- Violations are still highlighted distinctly; clean allowed calls are shown as informational rows

**Allowlist changes** (`netaudit/allowlist.py`):
- `Rule` protocol gains an optional `name: str` attribute (default `""`) — built-in rules use descriptive names such as `"loopback (IPv4)"`, `"loopback (IPv6)"`, `"unix (builtin)"`, `"netlink (builtin)"`
- `AllowList.match(event) -> Rule | None` — new method returning the first matching rule (or `None`); replaces the internal `is_allowed` call path when verbose output is needed
- Concrete rule classes (`IPv4Rule`, `IPv6Rule`, `UnixSocketRule`, `NetlinkRule`) accept `name` in their constructor; `_rule_from_dict` passes `entry.get("name", "")` through

**Reporter changes** (`netaudit/reporter.py`):
- `Reporter.format_verbose(events, allowlist, stream)` — renders a table with columns: `family`, `addr:port`, `status` (`OK` / `VIOLATION`), `rule` (rule name or `—`)
- JSON equivalent: `Reporter.format_json` gains an `include_allowed` flag; when true, each entry has `"status": "allowed" | "violation"` and `"rule": "<name>"`

**Tests:** unit tests for `AllowList.match`, `_rule_from_dict` name propagation, built-in rule names, and `Reporter.format_verbose` output; CLI tests via `CliRunner` for `--verbose` on both commands.

**Docs:** update `cli-reference.md` and `allowlist-dsl.md` to document the `name` field and `--verbose` flag.

---

## Phase 5.5 — Verbose Mode in pytest Plugin

**Goal:** Surface the same `--verbose` visibility (all events, annotated with rule names) inside the pytest integration.

**New pytest option** (`--netaudit-verbose`):
- Registered in `pytest_addoption` alongside the existing `--netaudit` and `--netaudit-allowlist` options
- When set, the session-finish report shows *every* `ConnectEvent` attributed to its test, not just violations
- Each event row displays: test nodeid, family, addr:port, status (`OK` / `VIOLATION`), rule name

**`pyproject.toml` config** (`[tool.netaudit]`):
- New key: `verbose = true` — equivalent to passing `--netaudit-verbose` on the CLI
- Resolution order: CLI flag > `pyproject.toml` > default (off), consistent with `allowlist` resolution

**Plugin changes** (`netaudit/integrations/pytest_plugin.py`):
- `_resolve_verbose(config) -> bool` — reads CLI flag then pyproject.toml key
- `_emit_attributed_verbose(events, allowlist, test_ranges, session)` — groups all events (allowed + violations) by test range, prints a per-test table using `Reporter.format_verbose`; still sets `session.exitstatus` to `TESTS_FAILED` if any violations exist
- `pytest_sessionfinish` passes `verbose` through to the right emit path

**Tests:** `pytester`-based tests verifying:
- `--netaudit-verbose` flag triggers verbose output (table headers present, allowed events shown)
- `verbose = true` in pyproject.toml has the same effect without the CLI flag
- Violations still cause non-zero exit even in verbose mode
- Non-verbose mode output is unchanged

**Docs:** update `docs/pytest-plugin.md` — document `--netaudit-verbose` flag and `verbose` key in `[tool.netaudit]`.

---

## Phase 6 — Release Engineering

**Goal:** Automated publishing, Docker image, hardening.

- **PyPI workflow** (`.github/workflows/release.yml`): build + publish on GitHub release (manual publish already done for 0.1.0)
- **Docs deploy** (`.github/workflows/docs.yml`): `mkdocs gh-deploy` on push to main (RTD already configured as interim)
- **Dockerfile**: `python:3.12-slim` + strace, `ENTRYPOINT ["netaudit"]`
- **Docker CI**: build + push to GHCR on release
- **Hardening**: truncated strace output, binary garbage in paths, long lines, permission errors, signal handling
- **Docs:** Docker usage page, contributing guide

**Exit:** automated `pip install netaudit` from PyPI on release, `docker run` works, docs live on GH Pages.

---

## Skills

| Skill | Created in | Description |
|---|---|---|
| `/commit` | Phase 0 | Auto-detect conventional commit type from diff (feat/fix/refactor/test/docs/chore), minimal description, GPG-signed, no co-author |

Additional skills (`/phase-docs`, `/coverage-check`, `/release-prep`) to be created when the need arises, not upfront.

---

## Verification

Each phase verified by:
1. `ruff check . && ruff format --check . && mypy netaudit/` — lint clean
2. `pytest --cov=netaudit --cov-fail-under=80` — tests pass with coverage
3. `pytest -m integration` (Linux only) — real strace tests (from Phase 2)
4. `mkdocs build --strict` — docs build (from Phase 3)
5. CI green on push

---

## Key Files (final state)

```
pyproject.toml
Makefile
.gitignore
mkdocs.yml
.readthedocs.yaml
Dockerfile
netaudit/
  __init__.py
  py.typed
  parser.py
  allowlist.py
  reporter.py
  runner.py
  cli.py
  integrations/
    __init__.py
    pytest_plugin.py
tests/
  conftest.py
  test_parser.py
  test_allowlist.py
  test_reporter.py
  test_cli.py
  integration/
    conftest.py
    egress_target.py
    test_end_to_end.py
docs/
  index.md
  architecture.md
  cli-reference.md
  allowlist-dsl.md
  pytest-plugin.md
  docker.md
.github/workflows/
  ci.yml
  docs.yml
  release.yml
.claude/commands/
  commit.md
```
