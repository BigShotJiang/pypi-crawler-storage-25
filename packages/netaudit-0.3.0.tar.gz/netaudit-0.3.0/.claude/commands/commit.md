Look at the current git diff (staged + unstaged) and create a GPG-signed conventional commit.

Steps:
1. Run `git diff HEAD` to see all changes (staged and unstaged). If nothing, run `git status` to check for untracked files.
2. Determine the commit type from the diff:
   - `feat`: new user-visible functionality
   - `fix`: bug fix
   - `refactor`: restructuring without behavior change
   - `test`: test additions or changes only
   - `docs`: documentation only
   - `chore`: tooling, config, build, CI, deps
3. Stage all relevant changes with `git add` (specific files, not `-A`).
4. Write a single-line commit message: `<type>(<scope>): <short description>` — scope is optional, description is lowercase, no trailing period, under 72 chars total.
5. Commit with `git commit -S -m "<message>"` (GPG-signed, no co-author line).

Rules:
- No co-author trailer.
- No body or footer unless the change genuinely needs explanation.
- Do not skip hooks (`--no-verify`).
- If GPG signing fails, report the error and stop — do not commit unsigned.
- Do not push.
- Never reference phase numbers (e.g. "phase 0", "phase 1") in the commit message — describe what was done, not which plan phase it belongs to.
