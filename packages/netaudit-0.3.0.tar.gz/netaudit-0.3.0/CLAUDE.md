# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this project is

`netaudit` is a Python library and CLI that wraps a process or test suite under `strace`, collects all `connect()` syscalls, filters them against a declarative allowlist, and reports violations. The goal: commit a config file declaring what's allowed, run tests normally, get pass/fail with readable output instead of raw strace noise.

`strace` is a **system dependency** — documented, not bundled. No other runtime dependencies. `pytest` is optional (only needed for the plugin).

## Commands

```bash
# Set up venv (Python 3.11+)
python3.11 -m venv .venv
.venv/bin/pip install -e ".[dev]"

# Run all tests
.venv/bin/pytest

# Run a single test
.venv/bin/pytest tests/test_parser.py::TestStraceParser::test_parse_af_inet_connect

# CLI usage
.venv/bin/netaudit run --allowlist netaudit.yaml -- <command>
.venv/bin/netaudit analyze --allowlist netaudit.yaml /tmp/strace.log
```

## Architecture

Two-layer design: a **language-agnostic core** (syscall tracing + analysis) and **framework-specific integrations** that add execution context (e.g. test attribution). The core must not import anything from integrations.

### Core (`netaudit/`)

| Module | Role |
|---|---|
| `runner.py` | `StraceRunner` — spawns strace as a subprocess wrapping a command, or attaches to an existing PID via `attach(pid)` |
| `parser.py` | `StraceParser` — line-by-line regex parser producing `ConnectEvent` dataclasses |
| `allowlist.py` | `AllowList` + rule types: `IPv4`, `IPv6`, `UnixSocket`, `Netlink` — loaded from YAML or constructed programmatically |
| `reporter.py` | `Violation`, `Reporter` — groups events, formats output; enriched with test attribution when markers are available |
| `cli.py` | CLI entry point (`netaudit run` / `netaudit analyze`) |

### `ConnectEvent` (central data type)

```python
@dataclass
class ConnectEvent:
    pid: int
    timestamp: float
    family: str       # "AF_INET", "AF_INET6", "AF_UNIX", "AF_NETLINK", ...
    addr: str | None  # IP or socket path
    port: int | None
    result: int       # 0 = success; negative errno (e.g. -ECONNREFUSED)
```

### Parser edge cases to handle

- `EINPROGRESS`: non-blocking connect in flight — not a failure, should still be evaluated against the allowlist
- Multi-line strace continuations (syscall split across lines)
- Thread interleavings when strace is run with `-f`

### AllowList DSL

YAML format committed to the repo:

```yaml
version: 1
allowlist:
  - name: "GVM Unix socket"
    family: AF_UNIX
    path_prefix: /run/gvmd/
  - name: "GVM TCP proxy"
    family: AF_INET
    addr: 127.0.0.1
    port: 9393
  - name: "IPv6 loopback"
    family: AF_INET6
    addr: "::1"
  - name: "glibc resolver internals"
    family: AF_NETLINK
```

`Netlink()` and loopback are reasonable built-in defaults — users opt **out** rather than explicitly allowing them.

### pytest integration (`netaudit/integrations/pytest_plugin.py`)

Registered via `entry_points` in `pyproject.toml` (not imported directly). Re-execs the pytest process with strace as parent. Emits timestamp markers at session and test boundaries so violations can be attributed to individual test cases. Calls `pytest.fail()` after `pytest_sessionfinish` if violations exist.

Activated via `pyproject.toml`:
```toml
[tool.netaudit]
allowlist = "netaudit.yaml"
enabled = true
```

### Future integrations

Node.js (Jest/Vitest/Mocha) and other runners are explicitly in scope. All integrations follow the same pattern: **emit execution markers → correlate with syscall timestamps → enrich violation reports**. New integrations go in `netaudit/integrations/` and must not require changes to core modules.

## Key design constraints

- The core is entirely framework-agnostic — no pytest imports outside `integrations/`
- Exit code is non-zero on any violation (CI-native)
- The CLI (`netaudit run`) must work with any executable, not just Python test suites
- Regex is sufficient for parsing strace output — the format is stable and well-documented
- `mypy --strict` enforced from day one; `py.typed` marker included
- `ruff` for linting and formatting (line-length=100, select E,F,W,I)

## Development plan

See [`.instructions/plan.md`](.instructions/plan.md) for the full phased development plan (6 phases, agile approach with CI/CD from Phase 0).
