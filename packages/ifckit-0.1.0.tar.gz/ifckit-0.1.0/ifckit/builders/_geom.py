"""
ifckit.builders._geom
====================

Low-level ifcopenshell geometry helpers shared across builders.
Creates IfcCartesianPoint, IfcDirection, IfcAxis2Placement3D, etc.

Coordinate Precision
-------------------
By default, coordinates are rounded to 4 decimal places (0.1mm precision).
Since ifckit uses millimeters as its internal unit, 4 decimal places in
the IFC output (meters) = 0.1mm precision.

Adjust precision with set_precision()::

    from ifckit.builders import set_precision

    set_precision(3)  # 3 decimals = 1mm precision
    set_precision(4)  # 4 decimals = 0.1mm precision (default)
    set_precision(6)  # 6 decimals = 1μm precision
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, List, Sequence

import ifcopenshell

if TYPE_CHECKING:
    from ifckit.geometry import Arc, Line, Path, Plane, Vec


# Coordinate precision: decimal places in IFC output (meters)
# 4 = 0.1mm precision (default for mm-based projects)
_PRECISION = 4


def set_precision(decimals: int) -> None:
    """
    Set coordinate output precision.

    Args:
        decimals: Number of decimal places (0-10). Higher = more precision.
                 3 = 1mm, 4 = 0.1mm, 6 = 1μm.

    Raises:
        ValueError: If decimals is not in range 0-10.
    """
    global _PRECISION
    if not isinstance(decimals, int):
        raise TypeError(f"decimals must be int, got {type(decimals).__name__}")
    if decimals < 0 or decimals > 10:
        raise ValueError(f"decimals must be 0-10, got {decimals}")
    _PRECISION = decimals


def get_precision() -> int:
    """Return current coordinate precision (decimal places)."""
    return _PRECISION


def _round_coord(value: float) -> float:
    """Round a coordinate value to current precision."""
    return float(round(value, _PRECISION))


def pt2(f: ifcopenshell.file, x: float, y: float) -> ifcopenshell.entity_instance:
    return f.create_entity("IfcCartesianPoint", Coordinates=[_round_coord(x), _round_coord(y)])


def pt3(f: ifcopenshell.file, x: float, y: float, z: float) -> ifcopenshell.entity_instance:
    return f.create_entity(
        "IfcCartesianPoint",
        Coordinates=[_round_coord(x), _round_coord(y), _round_coord(z)],
    )


def dir3(f: ifcopenshell.file, x: float, y: float, z: float) -> ifcopenshell.entity_instance:
    return f.create_entity(
        "IfcDirection",
        DirectionRatios=[_round_coord(x), _round_coord(y), _round_coord(z)],
    )


def axis2placement3d(
    f: ifcopenshell.file,
    origin: "Vec",
    z_axis: "Vec",
    x_axis: "Vec",
) -> ifcopenshell.entity_instance:
    """Create IfcAxis2Placement3D from ifckit Vec objects."""
    return f.create_entity(
        "IfcAxis2Placement3D",
        Location=pt3(f, origin.x, origin.y, origin.z),
        Axis=dir3(f, z_axis.x, z_axis.y, z_axis.z),
        RefDirection=dir3(f, x_axis.x, x_axis.y, x_axis.z),
    )


def local_placement(
    f: ifcopenshell.file,
    plane: "Plane",
    relative_to: ifcopenshell.entity_instance | None = None,
) -> ifcopenshell.entity_instance:
    """Create IfcLocalPlacement from a Plane."""
    ax = axis2placement3d(f, plane.origin, plane.z_axis, plane.x_axis)
    return f.create_entity("IfcLocalPlacement", PlacementRelTo=relative_to, RelativePlacement=ax)


def shift_plane_elevation(plane: "Plane", elev: float) -> "Plane":
    """Return a copy of *plane* with its origin shifted by ``-elev`` in Z.

    Used by builders to convert a world-space plane to storey-local coordinates
    (subtract the storey elevation from the origin Z component).
    """
    from ifckit.geometry import Vec

    local_origin = Vec(plane.origin.x, plane.origin.y, plane.origin.z - elev)
    return plane.__class__(local_origin, plane.x_axis, plane.y_axis)


def _signed_area_2d(points: Sequence[tuple[float, float]]) -> float:
    """Compute signed area of a polygon (shoelace formula). Positive = CCW."""
    n = len(points)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += points[i][0] * points[j][1]
        area -= points[j][0] * points[i][1]
    return area / 2.0


def profile_from_points(
    f: ifcopenshell.file,
    points_2d: Sequence[tuple[float, float]],
    profile_name: str | None = None,
    ensure_ccw: bool = True,
) -> ifcopenshell.entity_instance:
    """
    Create IfcArbitraryClosedProfileDef from a list of (x, y) tuples.
    The list is automatically closed (first == last) if not already.
    If ensure_ccw=True, reverses orientation for positive signed area (CCW).
    """
    pts = list(points_2d)
    # Close the profile if not already closed (epsilon comparison for float safety).
    _EPS = 1e-9
    if not (abs(pts[0][0] - pts[-1][0]) < _EPS and abs(pts[0][1] - pts[-1][1]) < _EPS):
        pts.append(pts[0])
    # CCW normalization (C# approach for viewer compatibility)
    if ensure_ccw and _signed_area_2d(pts) < 0:
        pts = list(reversed(pts[:-1]))  # reverse, drop duplicate end point
        pts.append(pts[0])  # re-close
    ifc_pts = [pt2(f, x, y) for x, y in pts]
    polyline = f.create_entity("IfcPolyline", Points=ifc_pts)
    return f.create_entity(
        "IfcArbitraryClosedProfileDef",
        ProfileType="AREA",
        ProfileName=profile_name,
        OuterCurve=polyline,
    )


def profile_to_ifc(
    f: ifcopenshell.file,
    profile_source: Any,
    profile_name: str | None = None,
    ensure_ccw: bool = True,
) -> ifcopenshell.entity_instance:
    """
    Convert a profile source to an IfcProfileDef entity.

    Accepts:
      - A ``Profile`` subclass instance (calls ``profile.to_ifc(f)``).
      - Any object with ``get_profile_points()`` (legacy duck-typing).
      - A sequence of (x, y) tuples (calls ``profile_from_points()``).

    This is the unified entry-point for all builders.
    """
    # Profile ABC or duck-typed object with to_ifc()
    if hasattr(profile_source, "to_ifc"):
        return profile_source.to_ifc(f)
    # Legacy duck-typed objects without to_ifc but with get_profile_points()
    if hasattr(profile_source, "get_profile_points"):
        pts = profile_source.get_profile_points()
        return profile_from_points(f, pts, profile_name=profile_name, ensure_ccw=ensure_ccw)
    # Plain sequence of (x, y) tuples
    return profile_from_points(f, profile_source, profile_name=profile_name, ensure_ccw=ensure_ccw)


def extrude_profile(
    f: ifcopenshell.file,
    profile: ifcopenshell.entity_instance,
    depth: float,
    position: ifcopenshell.entity_instance | None = None,
    extrude_direction: tuple[float, float, float] = (0.0, 0.0, 1.0),
) -> ifcopenshell.entity_instance:
    """Create IfcExtrudedAreaSolid."""
    if position is None:
        from ifckit.geometry import Vec

        _o = Vec(0, 0, 0)
        _z = Vec(0, 0, 1)
        _x = Vec(1, 0, 0)
        position = axis2placement3d(f, _o, _z, _x)
    ed = dir3(f, *extrude_direction)
    return f.create_entity(
        "IfcExtrudedAreaSolid",
        SweptArea=profile,
        Position=position,
        ExtrudedDirection=ed,
        Depth=float(depth),
    )


def shape_representation(
    f: ifcopenshell.file,
    context: ifcopenshell.entity_instance,
    solid: ifcopenshell.entity_instance,
    rep_type: str = "SweptSolid",
) -> ifcopenshell.entity_instance:
    return f.create_entity(
        "IfcShapeRepresentation",
        ContextOfItems=context,
        RepresentationIdentifier="Body",
        RepresentationType=rep_type,
        Items=[solid],
    )


def product_definition_shape(
    f: ifcopenshell.file,
    shape_rep: ifcopenshell.entity_instance,
) -> ifcopenshell.entity_instance:
    return f.create_entity(
        "IfcProductDefinitionShape",
        Representations=[shape_rep],
    )


def project_profile_to_plane(
    points: List["Vec"],
    plane: "Plane",
) -> List[tuple[float, float]]:
    """
    Project a list of 3D Vec points to 2D (u, v) in a plane's local coordinates.
    """
    result = []
    for p in points:
        local = plane.to_local(p)
        result.append((local.x, local.y))
    return result


def storey_elevation(container: ifcopenshell.entity_instance) -> float:
    """
    Extract the Z-elevation from a storey's ObjectPlacement.

    Returns 0.0 if the storey has no ObjectPlacement (backward-compat).
    """
    try:
        coords = container.ObjectPlacement.RelativePlacement.Location.Coordinates
        return float(coords[2]) if len(coords) > 2 else 0.0
    except AttributeError:
        return 0.0


def directrix_from_line(
    f: ifcopenshell.file,
    line: "Line",
) -> ifcopenshell.entity_instance:
    """Create an IfcPolyline (2-point) directrix from a Line segment."""
    return f.create_entity(
        "IfcPolyline",
        Points=[
            pt3(f, line.start.x, line.start.y, line.start.z),
            pt3(f, line.end.x, line.end.y, line.end.z),
        ],
    )


def directrix_from_arc(
    f: ifcopenshell.file,
    arc: "Arc",
) -> ifcopenshell.entity_instance:
    """
    Create an IfcTrimmedCurve directrix from an Arc.

    The underlying IfcCircle is placed so that:
      - Axis       = arc.normal   (rotation axis)
      - RefDirection = (arc.start - arc.center).normalized()  (0° reference)

    Trim parameters are in degrees (IFC4 default).
    CCW arc (angle > 0): SenseAgreement=True,  Trim1=0°, Trim2=|angle|°
    CW  arc (angle < 0): SenseAgreement=False, Trim1=0°, Trim2=|angle|°
    """
    radial = (arc.start - arc.center).normalized()
    placement = axis2placement3d(f, arc.center, arc.normal, radial)
    circle = f.create_entity(
        "IfcCircle",
        Position=placement,
        Radius=float(arc.radius),
    )
    angle_deg = abs(math.degrees(arc.angle))
    trim1 = f.create_entity("IfcParameterValue", wrappedValue=0.0)
    trim2 = f.create_entity("IfcParameterValue", wrappedValue=angle_deg)
    sense = arc.angle >= 0
    return f.create_entity(
        "IfcTrimmedCurve",
        BasisCurve=circle,
        Trim1=[trim1],
        Trim2=[trim2],
        SenseAgreement=sense,
        MasterRepresentation="PARAMETER",
    )


def directrix_from_path(
    f: ifcopenshell.file,
    path: "Path",
) -> ifcopenshell.entity_instance:
    """
    Create an IfcCompositeCurve directrix from a mixed Line/Arc Path.

    Each segment becomes one IfcCompositeCurveSegment.
    Interior transitions use CONTSAMEGRADIENT; the last uses DISCONTINUOUS.
    """
    from ifckit.geometry import Arc as _Arc

    segments = path.segments
    ifc_segments = []
    for i, seg in enumerate(segments):
        is_last = i == len(segments) - 1
        transition = "DISCONTINUOUS" if is_last else "CONTSAMEGRADIENT"
        if isinstance(seg, _Arc):
            curve = directrix_from_arc(f, seg)
        else:
            curve = directrix_from_line(f, seg)
        ifc_segments.append(
            f.create_entity(
                "IfcCompositeCurveSegment",
                Transition=transition,
                SameSense=True,
                ParentCurve=curve,
            )
        )
    return f.create_entity(
        "IfcCompositeCurve",
        Segments=ifc_segments,
        SelfIntersect=False,
    )


def get_body_context(
    ifc_file: ifcopenshell.file,
) -> ifcopenshell.entity_instance:
    """
    Return the 'Body' sub-context if it exists, otherwise the first
    Model context, otherwise raise.
    """
    for ctx in ifc_file.by_type("IfcGeometricRepresentationSubContext"):
        if ctx.ContextIdentifier == "Body":
            return ctx
    for ctx in ifc_file.by_type("IfcGeometricRepresentationContext"):
        if ctx.ContextType == "Model":
            return ctx
    raise RuntimeError(
        "No suitable geometric representation context found. "
        "Call IfcModel() first, which creates a Model context."
    )


def _arbitrary_perp(v: "Vec") -> "Vec":
    """Return an arbitrary unit vector perpendicular to v."""
    from ifckit.geometry import Vec as _Vec

    n = v.normalized()
    candidate = _Vec(1.0, 0.0, 0.0) if abs(n @ _Vec(1, 0, 0)) < 0.9 else _Vec(0.0, 1.0, 0.0)
    return (candidate - n * (n @ candidate)).normalized()


def apply_style(ifc_file: Any, product: Any, style: Any) -> None:
    """Assign a RenderStyle to an IFC product via IfcStyledItem.

    Creates the minimal IFC style graph::

        IfcShapeRepresentation.Items[0]
            ← IfcStyledItem
                → IfcSurfaceStyle
                    → IfcSurfaceStyleRendering
                        → IfcColourRgb
                        .Transparency

    If the product has no body representation or no items, this is a no-op.

    Args:
        ifc_file: An ``ifcopenshell.file`` instance.
        product:  An IFC product entity (IfcWall, IfcSlab, …).
        style:    A :class:`ifckit.elements.style.RenderStyle` instance.
    """
    if style is None:
        return

    rep = getattr(product, "Representation", None)
    if rep is None:
        return

    # Find the body representation
    body_rep = None
    for shape_rep in rep.Representations or []:
        if getattr(shape_rep, "RepresentationIdentifier", None) == "Body":
            body_rep = shape_rep
            break
    if body_rep is None:
        return

    items = list(body_rep.Items or [])
    if not items:
        return

    colour_rgb = ifc_file.create_entity(
        "IfcColourRgb",
        Name=None,
        Red=style.r,
        Green=style.g,
        Blue=style.b,
    )
    rendering = ifc_file.create_entity(
        "IfcSurfaceStyleRendering",
        SurfaceColour=colour_rgb,
        Transparency=style.transparency,
        ReflectanceMethod="FLAT",
    )
    surface_style = ifc_file.create_entity(
        "IfcSurfaceStyle",
        Name=None,
        Side="BOTH",
        Styles=[rendering],
    )

    # IFC2X3: IfcStyledItem.Styles must be SET OF IfcPresentationStyleAssignment.
    # IFC4+:  IfcStyledItem.Styles can contain IfcPresentationStyle directly.
    if ifc_file.schema == "IFC2X3":
        style_entry = ifc_file.create_entity(
            "IfcPresentationStyleAssignment",
            Styles=[surface_style],
        )
    else:
        style_entry = surface_style

    ifc_file.create_entity(
        "IfcStyledItem",
        Item=items[0],
        Styles=[style_entry],
        Name=None,
    )
