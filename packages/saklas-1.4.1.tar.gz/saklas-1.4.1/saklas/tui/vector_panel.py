"""Left panel: model info, steering vectors with inline controls, generation config, key reference."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widgets import Static
from textual.widget import Widget

from saklas.tui.utils import build_bar

MAX_ALPHA = 1.0


class LeftPanel(Widget):
    """Entire left column: model, vectors, gen config, keys."""

    def __init__(self, model_info: dict, **kwargs) -> None:
        super().__init__(**kwargs)
        self._model_info = model_info
        self._vectors: list[dict] = []
        self._selected_idx: int = 0
        self._thinking: bool | None = None  # None = model doesn't support it
        self._temperature: float = 1.0
        self._top_p: float = 0.9
        self._max_tokens: int = 1024
        self._system_prompt: str | None = None

    def on_mount(self) -> None:
        self._vectors_header = self.query_one("#vectors-header", Static)
        self._vector_content = self.query_one("#vector-content", Static)
        self._gen_config_widget = self.query_one("#gen-config", Static)

    def compose(self) -> ComposeResult:
        info = self._model_info
        # Model section
        yield Static("[bold]MODEL[/]", classes="section-header")
        model_id = info.get("model_id", "unknown")
        if "/" in model_id:
            model_id = model_id.split("/", 1)[1]
        if len(model_id) > 28:
            model_id = "..." + model_id[-25:]
        params = info.get("param_count", 0)
        param_str = f"{params / 1e9:.1f}B" if params >= 1e9 else f"{params / 1e6:.0f}M"
        yield Static(
            f"{model_id}\n"
            f"{info['num_layers']}L × {info['hidden_dim']}d · {info.get('dtype', '?')}\n"
            f"{info.get('device', '?')} · {info.get('vram_used_gb', 0):.1f} GB · {param_str}",
            id="model-info",
        )
        # Vectors section
        yield Static("[bold]VECTORS[/] [dim]0 total, 0 active[/]",
                      id="vectors-header", classes="section-header")
        yield VerticalScroll(Static("", id="vector-content"), id="vector-scroll")
        yield Static("[dim]⌫ remove · ↩ toggle[/]",
                      id="vector-hints")
        # Generation section
        yield Static("[bold]GENERATION[/]", classes="section-header")
        yield Static("", id="gen-config")
        # Keys section
        yield Static("[bold]KEYS[/]", classes="section-header")
        yield Static(
            "[dim]⇥ focus panels · ⎋ stop gen\n"
            "⌃R regen · ⌃A A/B · ⌃T think\n"
            "⌃Q quit\n"
            "── ⇥ to side panel first ──\n"
            "↑/↓ navigate · ↩ select\n"
            "←/→ alpha\n"
            "[ ] temp · { } top-p[/]",
            id="key-ref",
        )

    def update_vectors(self, vectors: list[dict]) -> None:
        self._vectors = vectors
        if self._vectors:
            self._selected_idx = min(self._selected_idx, len(self._vectors) - 1)
        else:
            self._selected_idx = 0
        self._render_vectors()

    def update_gen_config(self, temperature: float, top_p: float,
                          max_tokens: int, system_prompt: str | None,
                          thinking: bool | None = None) -> None:
        self._temperature = temperature
        self._top_p = top_p
        self._max_tokens = max_tokens
        self._system_prompt = system_prompt
        self._thinking = thinking
        self._render_gen_config()

    def select_next(self) -> None:
        if self._vectors:
            self._selected_idx = (self._selected_idx + 1) % len(self._vectors)
            self._render_vectors()

    def select_prev(self) -> None:
        if self._vectors:
            self._selected_idx = (self._selected_idx - 1) % len(self._vectors)
            self._render_vectors()

    def get_selected(self) -> dict | None:
        if self._vectors and 0 <= self._selected_idx < len(self._vectors):
            return self._vectors[self._selected_idx]
        return None

    def _render_vectors(self) -> None:
        active = sum(1 for v in self._vectors if v.get("enabled", True))
        total = len(self._vectors)
        header = self._vectors_header
        header.update(
            f"[bold]VECTORS[/] [dim]{total} total, {active} active[/]"
        )

        lines: list[str] = []
        for i, v in enumerate(self._vectors):
            is_selected = i == self._selected_idx
            enabled = v.get("enabled", True)
            name = v["name"]
            alpha = v["alpha"]
            peak = v["peak"]
            n_active = v["n_active"]
            layer_tag = f"{n_active}L pk{peak}"

            bar_full, bar_empty = build_bar(alpha, MAX_ALPHA, 16)
            if alpha > 0:
                color = "ansi_green"
            elif alpha < 0:
                color = "ansi_red"
            else:
                color = "ansi_default"

            marker = ">" if is_selected else " "
            dot = "[ansi_green]●[/]" if enabled else "[dim]○[/]"
            hint = " [dim]←/→[/]" if is_selected else ""

            if is_selected and enabled:
                name_str = f"[bold]{name}[/]"
            elif is_selected and not enabled:
                name_str = f"[dim bold]{name}[/]"
            elif not enabled:
                name_str = f"[dim]{name}[/]"
            else:
                name_str = name

            dim_prefix = "dim " if not enabled else ""
            text = (
                f"{marker} {dot} {name_str} [dim]{layer_tag}[/]\n"
                f"  α [{dim_prefix}{color}]{bar_full}[/][dim]{bar_empty}[/] "
                f"[{dim_prefix}{color}]{alpha:+.2f}[/]{hint}"
            )
            lines.append(text)

        content = self._vector_content
        content.update("\n".join(lines))

    def _render_gen_config(self) -> None:
        gen = self._gen_config_widget
        t_full, t_empty = build_bar(self._temperature, 2.0, 20)
        t_bar = t_full + t_empty
        p_full, p_empty = build_bar(self._top_p, 1.0, 20)
        p_bar = p_full + p_empty

        sys_str = self._system_prompt[:15] + "..." if self._system_prompt and len(self._system_prompt) > 15 else (self._system_prompt or "(none)")

        lines = [
            f"Temp  {self._temperature:.2f} [dim]{t_bar}[/] [dim]\\[/][/]",
            f"Top-p {self._top_p:.2f} [dim]{p_bar}[/] [dim]{{/}}[/]",
            f"Max   {self._max_tokens} tok       [dim]/max[/]",
        ]
        if self._thinking is not None:
            think_str = "ON" if self._thinking else "OFF"
            lines.append(f"Think {think_str}            [dim]⌃T[/]")
        lines.append(f"Sys   [dim]{sys_str}[/]    [dim]/sys[/]")
        lines.append("[dim]type /help for commands[/]")

        gen.update("\n".join(lines))
