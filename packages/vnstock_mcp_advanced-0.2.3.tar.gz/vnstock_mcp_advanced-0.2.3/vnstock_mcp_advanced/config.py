"""
Configuration for the vnstock MCP server.

Set USER_TIER to your tier: "free", "bronze", "silver", "golden"
Set API_KEY if you have one (increases rate limits for free tier).
"""

import os
from datetime import date, timedelta

# ── User tier ──────────────────────────────────────────────────────────────
# Options: "free" | "bronze" | "silver" | "golden"
USER_TIER: str = os.getenv("VNSTOCK_USER_TIER", "free").lower()

# Whether the user has a sponsored (paid) subscription
IS_SPONSORED: bool = USER_TIER in ("bronze", "silver", "golden")

# API key (optional for free tier, required for sponsored tier)
API_KEY: str = os.getenv("VNSTOCK_API_KEY", "")

# ── Preferred data sources ─────────────────────────────────────────────────
# Most reliable defaults per documentation
SOURCE_QUOTE: str = "kbs"       # Quote / price history
SOURCE_COMPANY: str = "kbs"     # Company info
SOURCE_FINANCE: str = "vci"     # Financial statements
SOURCE_LISTING: str = "vci"     # Stock listing
SOURCE_TRADING: str = "vci"     # Price board / trading

# ── Date helpers ───────────────────────────────────────────────────────────

def today() -> str:
    return date.today().isoformat()

def one_year_ago() -> str:
    return (date.today() - timedelta(days=365)).isoformat()

def three_months_ago() -> str:
    return (date.today() - timedelta(days=90)).isoformat()
