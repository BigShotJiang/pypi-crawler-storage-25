"""
Quote tools — historical OHLCV, intraday ticks, and order-book depth.

Free tier: uses ``vnstock.Quote``.
Sponsored tier: uses ``vnstock_data.Quote`` automatically when available.
"""

from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records


# ── Length shortcut mapping ────────────────────────────────────────────────
# Lets callers pass length="1Y" instead of start/end.
_LENGTH_DAYS = {
    "1W": 7,
    "2W": 14,
    "1M": 31,
    "2M": 62,
    "3M": 93,
    "6M": 186,
    "1Y": 365,
    "2Y": 730,
    "3Y": 1095,
    "5Y": 1825,
}


def _resolve_range(
    start: Optional[str],
    end: Optional[str],
    length: Optional[str],
) -> tuple[str, str]:
    """Resolve (start, end) using an optional length shortcut."""
    end = end or config.today()
    if start:
        return start, end
    days = _LENGTH_DAYS.get((length or "1Y").upper(), 365)
    start_dt = date.fromisoformat(end) - timedelta(days=days)
    return start_dt.isoformat(), end


def _get_quote_cls():
    """Return the Quote class from the preferred library for the current tier."""
    if config.IS_SPONSORED:
        try:
            from vnstock_data import Quote  # type: ignore
            return Quote
        except ImportError:
            pass
    from vnstock import Quote
    return Quote


# ── Tools ──────────────────────────────────────────────────────────────────

def get_stock_price(
    symbol: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
    length: Optional[str] = None,
    interval: str = "1D",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Fetch historical OHLCV bars for a stock symbol or index.

    Supports daily, weekly, monthly, and intraday intervals. If ``start``/``end``
    are not provided, ``length`` can be used as a shortcut (e.g. "1Y", "6M", "3M").

    Args:
        symbol:   Ticker, e.g. "VCB", or index code "VNINDEX", "VN30".
        start:    Start date "YYYY-MM-DD". Defaults to ``length`` ago.
        end:      End date "YYYY-MM-DD". Defaults to today.
        length:   Lookback shortcut — one of 1W/2W/1M/2M/3M/6M/1Y/2Y/3Y/5Y.
        interval: Bar size — "1m", "5m", "15m", "30m", "1H", "1D", "1W", "1M".
        source:   Data source override ("kbs" or "vci").

    Returns:
        List of dicts with keys ``time, open, high, low, close, volume`` (at minimum).
    """
    src = source or config.SOURCE_QUOTE
    start_resolved, end_resolved = _resolve_range(start, end, length)

    Quote = _get_quote_cls()
    quote = Quote(source=src, symbol=symbol)
    df = quote.history(start=start_resolved, end=end_resolved, interval=interval)
    return df_to_records(df)


def get_intraday_data(
    symbol: str,
    page_size: int = 1000,
    get_all: bool = True,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Fetch tick-by-tick intraday trades for the current session.

    Each tick contains price, volume, timestamp, and a buy/sell tag where
    available. Only returns data during and shortly after market hours.

    Args:
        symbol:    Ticker, e.g. "VCB".
        page_size: Rows per page (upper bound). Default 1000.
        get_all:   If True, paginate until all ticks are returned.
        source:    Data source override.

    Returns:
        List of dicts with tick-level fields.
    """
    src = source or config.SOURCE_QUOTE
    Quote = _get_quote_cls()
    quote = Quote(source=src, symbol=symbol)
    try:
        df = quote.intraday(page_size=page_size, get_all=get_all)
    except TypeError:
        # Some versions don't accept get_all
        df = quote.intraday(page_size=page_size)
    return df_to_records(df)


def get_order_depth(
    symbol: str,
    source: str = "vci",
) -> list[dict]:
    """
    Fetch the accumulated order-book depth (volume by price level).

    Only VCI exposes this endpoint. The returned rows describe how much
    buying/selling volume is resting at each price level, giving a sense
    of near-term support and resistance from actual orders.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source — forced to "vci" since KBS does not support price depth.

    Returns:
        List of dicts with price level and accumulated volume fields.
    """
    Quote = _get_quote_cls()
    quote = Quote(source="vci", symbol=symbol)
    try:
        df = quote.price_depth()
    except AttributeError:
        # Fallback: some versions expose the method differently
        df = quote.depth() if hasattr(quote, "depth") else None
    return df_to_records(df)
