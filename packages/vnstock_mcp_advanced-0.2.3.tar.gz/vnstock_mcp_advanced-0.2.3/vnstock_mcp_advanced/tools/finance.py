"""
Finance tools — income statement, balance sheet, cash flow, ratios, notes.

Works on both tiers. VCI source recommended for standardized output.
Financial notes and annual plan require sponsored tier.
"""

from typing import Optional, Literal
from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def _finance(symbol: str, source: str):
    if config.IS_SPONSORED:
        from vnstock_data import Finance
    else:
        from vnstock import Finance
    return Finance(symbol=symbol, source=source)


def get_financial_statements(
    symbol: str,
    statement: Literal["income", "balance", "cashflow"] = "income",
    period: Literal["quarter", "year"] = "year",
    lang: Literal["vi", "en"] = "en",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get financial statements — income statement, balance sheet, or cash flow.

    Args:
        symbol:    Ticker, e.g. "VCB".
        statement: "income", "balance", or "cashflow".
        period:    "year" or "quarter".
        lang:      Language for column names — "en" (English) or "vi" (Vietnamese).
        source:    Data source override ("vci" or "kbs").

    Returns:
        List of dicts representing the statement rows/periods.
    """
    src = source or config.SOURCE_FINANCE
    fin = _finance(symbol, src)

    method_map = {
        "income": fin.income_statement,
        "balance": fin.balance_sheet,
        "cashflow": fin.cash_flow,
    }
    method = method_map[statement]

    try:
        df = method(period=period, lang=lang)
    except TypeError:
        df = method(period=period)

    return df_to_records(df)


def get_financial_ratios(
    symbol: str,
    period: Literal["quarter", "year"] = "year",
    lang: Literal["vi", "en"] = "en",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get key financial ratios — PE, PB, ROE, ROA, EPS, Debt/Equity,
    dividend yield, current ratio, and more.

    Args:
        symbol: Ticker, e.g. "VCB".
        period: "year" or "quarter".
        lang:   Language for column names.
        source: Data source override.

    Returns:
        List of dicts, one per period, with ratio values.
    """
    src = source or config.SOURCE_FINANCE
    fin = _finance(symbol, src)

    try:
        df = fin.ratio(period=period, lang=lang)
    except TypeError:
        df = fin.ratio(period=period)

    return df_to_records(df)


def get_financial_notes(
    symbol: str,
    period: Literal["quarter", "year"] = "year",
    lang: Literal["vi", "en"] = "en",
    source: str = "vci",
) -> list[dict]:
    """
    Get financial statement notes and disclosures (VCI source, sponsored only).

    Provides accounting policy disclosures, segment breakdowns, and
    management commentary not visible in standard statements.

    Args:
        symbol: Ticker, e.g. "VCB".
        period: "year" or "quarter".
        lang:   Language for column names.
        source: Must be "vci".

    Returns:
        List of dicts with note items and values by period.
    """
    require_sponsored("get_financial_notes")
    from vnstock_data import Finance

    fin = Finance(symbol=symbol, source="vci")
    df = fin.note(period=period, lang=lang)
    return df_to_records(df)


def get_annual_plan(
    symbol: str,
    source: str = "mas",
) -> list[dict]:
    """
    Get management's annual business plan and guidance (MAS source, sponsored only).

    Shows projected revenue, profit targets, and dividend plans that management
    committed to at the AGM — useful for comparing actuals vs guidance.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Must be "mas".

    Returns:
        List of dicts with year, target metrics, and actual vs plan comparison.
    """
    require_sponsored("get_annual_plan")
    from vnstock_data import Finance

    fin = Finance(symbol=symbol, source="mas")
    df = fin.annual_plan()
    return df_to_records(df)
