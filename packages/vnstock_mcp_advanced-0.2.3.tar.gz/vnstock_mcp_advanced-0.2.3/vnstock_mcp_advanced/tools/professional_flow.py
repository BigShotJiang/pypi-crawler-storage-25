"""
Professional flow tools — tick-level smart money detection, institutional
flow pattern matching, and sector rotation analysis using RRG methodology.

These tools answer the questions professional desks actually ask:
  - Who is behind today's move — institutions or retail, and are they agreeing
    with price action or fighting it?
  - What does the current foreign flow pattern historically predict for the
    next 1-2 weeks, and how confident can we be in that forecast?
  - Which sectors are leading, lagging, or rotating — and what stage of the
    market cycle does the current leadership suggest?

Tier requirements:
  - smart_money_flow_detector: FREE
  - institutional_flow_predictor: SPONSORED
  - sector_rotation_radar: FREE (SPONSORED when include_foreign_flow=True)
"""

import math
from collections import defaultdict
from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


# ── Internal helpers ───────────────────────────────────────────────────────

def _days_ago(n: int) -> str:
    return (date.today() - timedelta(days=n)).isoformat()


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _percentile(values: list[float], pct: float) -> float:
    """Linear-interpolation percentile (matches numpy default). pct in [0, 100]."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    rank = (pct / 100.0) * (len(sorted_vals) - 1)
    lower = int(math.floor(rank))
    upper = int(math.ceil(rank))
    if lower == upper:
        return sorted_vals[lower]
    frac = rank - lower
    return sorted_vals[lower] + frac * (sorted_vals[upper] - sorted_vals[lower])


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _stdev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return math.sqrt(sum((v - m) ** 2 for v in values) / (len(values) - 1))


def _median(values: list[float]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    mid = n // 2
    if n % 2:
        return s[mid]
    return (s[mid - 1] + s[mid]) / 2.0


def _euclidean(a: list[float], b: list[float]) -> float:
    n = min(len(a), len(b))
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(n)))


def _pearson(a: list[float], b: list[float]) -> Optional[float]:
    """Pearson correlation; returns None when undefined."""
    n = min(len(a), len(b))
    if n < 3:
        return None
    aa = a[:n]
    bb = b[:n]
    ma = _mean(aa)
    mb = _mean(bb)
    num = sum((aa[i] - ma) * (bb[i] - mb) for i in range(n))
    da = math.sqrt(sum((v - ma) ** 2 for v in aa))
    db = math.sqrt(sum((v - mb) ** 2 for v in bb))
    if da == 0 or db == 0:
        return None
    return num / (da * db)


def _pct_returns(closes: list[float]) -> list[Optional[float]]:
    rets: list[Optional[float]] = [None]
    for i in range(1, len(closes)):
        prev = closes[i - 1]
        if prev and prev != 0:
            rets.append((closes[i] / prev) - 1.0)
        else:
            rets.append(None)
    return rets


def _rolling_sum(values: list[float], window: int) -> list[float]:
    out = []
    for i in range(len(values)):
        lo = max(0, i - window + 1)
        out.append(sum(values[lo : i + 1]))
    return out


def _rolling_zscore(values: list[float], window: int, min_periods: int = 20) -> list[float]:
    out = []
    for i in range(len(values)):
        lo = max(0, i - window + 1)
        win = values[lo : i + 1]
        if len(win) < min_periods:
            out.append(0.0)
            continue
        m = _mean(win)
        s = _stdev(win)
        if s == 0:
            out.append(0.0)
        else:
            out.append((values[i] - m) / s)
    return out


# ── Tool 1: Smart Money Flow Detector ──────────────────────────────────────

def smart_money_flow_detector(
    symbol: str,
    date: Optional[str] = None,
    large_order_threshold_pct: float = 85.0,
    lookback_sessions: int = 5,
) -> dict:
    """
    Classify today's intraday ticks into smart-money (institutional) vs retail
    buckets and detect divergence between flow direction and price action.

    Ticks whose value (price * volume) exceed the given percentile of the
    session's value distribution are flagged as large — a proxy for
    institutional activity. We then compare the net smart-money flow to the
    session's price change to detect accumulation, distribution, or divergence
    setups professional traders use as early reversal signals.

    Signals:
      INSTITUTIONAL_ACCUMULATION — large orders net buying while price rising
      INSTITUTIONAL_DISTRIBUTION — large orders net selling while price falling
      BULLISH_DIVERGENCE         — smart money buying while price drops (reversal setup)
      BEARISH_DIVERGENCE         — smart money selling while price rises (caution)
      RETAIL_DRIVEN_RALLY        — small orders lifting price: watch for reversal
      RETAIL_PANIC_SELLING       — small orders crashing price: potential bottom
      MIXED                      — no clear institutional or retail dominance

    Free tier: available to everyone.

    Args:
        symbol:                    Stock ticker, e.g. "VCB".
        date:                      Session date (unused — always uses latest ticks).
        large_order_threshold_pct: Percentile cutoff for large-order classification
                                   (default 85 = top 15% of trade values).
        lookback_sessions:         Informational only (reported in result).

    Returns:
        Dict with signal, summary, tick counts, smart-money and retail net flows,
        price change, divergence flag, and the large-order threshold value.
    """
    from vnstock_mcp_advanced.tools.quote import get_intraday_data

    sym = symbol.upper()

    try:
        ticks = get_intraday_data(sym, page_size=5000)
    except Exception as e:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "error": str(e),
            "summary": f"Could not fetch intraday tick data for {sym}.",
            "as_of": config.today(),
        }

    if not ticks or len(ticks) < 10:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "summary": f"Insufficient intraday tick data for {sym} (need at least 10 ticks).",
            "as_of": config.today(),
        }

    # ── Auto-detect columns in the tick records ──
    sample = ticks[0]
    keys_lower = {k.lower(): k for k in sample.keys()}

    def _find_key(candidates: list[str]) -> Optional[str]:
        for c in candidates:
            if c in keys_lower:
                return keys_lower[c]
        return None

    price_key = _find_key(["match_price", "price", "avgmatchprice", "close", "last_price"])
    vol_key = _find_key(["match_vol", "volume", "vol", "match_volume"])
    side_key = _find_key(["match_type", "side", "buy_sell", "type", "action"])
    time_key = _find_key(["time", "trading_time", "match_time", "timestamp"])

    if not price_key or not vol_key:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "error": f"Could not locate price/volume columns in tick data. Fields: {list(sample.keys())}",
            "summary": f"Tick data schema not recognised for {sym}.",
            "as_of": config.today(),
        }

    # ── Normalise ticks ──
    cleaned = []
    for row in ticks:
        p = _safe_float(row.get(price_key))
        v = _safe_float(row.get(vol_key))
        if p is None or v is None or p <= 0 or v <= 0:
            continue
        cleaned.append(
            {
                "price": p,
                "vol": v,
                "value": p * v,
                "side_raw": str(row.get(side_key, "")).strip().upper() if side_key else "",
                "time": row.get(time_key) if time_key else None,
            }
        )

    if len(cleaned) < 10:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "summary": f"Only {len(cleaned)} valid ticks after cleaning — insufficient for analysis.",
            "as_of": config.today(),
        }

    # ── Classify ticks as buy or sell ──
    has_side = bool(side_key) and any(t["side_raw"] for t in cleaned)
    buy_tokens = {"BU", "BUY", "B", "BOUGHT", "1"}

    if has_side:
        for t in cleaned:
            t["is_buy"] = t["side_raw"] in buy_tokens
    else:
        # Tick-rule fallback: up-tick from previous price = buy
        prev = cleaned[0]["price"]
        cleaned[0]["is_buy"] = True
        for i in range(1, len(cleaned)):
            cleaned[i]["is_buy"] = cleaned[i]["price"] >= prev
            prev = cleaned[i]["price"]

    # ── Compute large-order threshold ──
    values = [t["value"] for t in cleaned]
    threshold = _percentile(values, large_order_threshold_pct)

    large_buy = 0.0
    large_sell = 0.0
    small_buy = 0.0
    small_sell = 0.0
    large_count = 0
    small_count = 0

    for t in cleaned:
        is_large = t["value"] >= threshold
        if is_large:
            large_count += 1
            if t["is_buy"]:
                large_buy += t["value"]
            else:
                large_sell += t["value"]
        else:
            small_count += 1
            if t["is_buy"]:
                small_buy += t["value"]
            else:
                small_sell += t["value"]

    smart_net = large_buy - large_sell
    smart_total = large_buy + large_sell
    smart_buy_ratio = round(large_buy / smart_total, 4) if smart_total > 0 else 0.5
    retail_net = small_buy - small_sell

    first_price = cleaned[0]["price"]
    last_price = cleaned[-1]["price"]
    price_change_pct = round((last_price - first_price) / first_price * 100, 4) if first_price > 0 else 0.0

    # ── Divergence detection ──
    divergence = "NONE"
    if smart_net > 0 and price_change_pct < -0.5:
        divergence = "BULLISH_DIVERGENCE"
    elif smart_net < 0 and price_change_pct > 0.5:
        divergence = "BEARISH_DIVERGENCE"

    # ── Session classification ──
    if divergence == "BULLISH_DIVERGENCE":
        signal = "BULLISH_DIVERGENCE"
    elif divergence == "BEARISH_DIVERGENCE":
        signal = "BEARISH_DIVERGENCE"
    elif smart_net > 0 and price_change_pct > 0.2:
        signal = "INSTITUTIONAL_ACCUMULATION"
    elif smart_net < 0 and price_change_pct > 0.2:
        signal = "RETAIL_DRIVEN_RALLY"
    elif smart_net < 0 and price_change_pct < -0.2:
        signal = "INSTITUTIONAL_DISTRIBUTION"
    elif retail_net < 0 and price_change_pct < -0.5:
        signal = "RETAIL_PANIC_SELLING"
    else:
        signal = "MIXED"

    # ── Plain-language summary ──
    smart_net_bn = round(smart_net / 1e9, 2)
    retail_net_bn = round(retail_net / 1e9, 2)
    direction_word = "up" if price_change_pct > 0 else ("down" if price_change_pct < 0 else "flat")

    if signal == "INSTITUTIONAL_ACCUMULATION":
        summary = (
            f"Institutional buyers absorbed {abs(smart_net_bn):.1f}B VND on {sym} "
            f"while price rose {price_change_pct:+.2f}% — large orders are accumulating into strength."
        )
    elif signal == "INSTITUTIONAL_DISTRIBUTION":
        summary = (
            f"Institutions net sold {abs(smart_net_bn):.1f}B VND on {sym} as price fell "
            f"{price_change_pct:+.2f}% — classic distribution into weakness."
        )
    elif signal == "BULLISH_DIVERGENCE":
        summary = (
            f"Smart money net bought {abs(smart_net_bn):.1f}B VND of {sym} despite a "
            f"{price_change_pct:+.2f}% drop — bullish divergence, potential reversal setup."
        )
    elif signal == "BEARISH_DIVERGENCE":
        summary = (
            f"Large orders net sold {abs(smart_net_bn):.1f}B VND of {sym} while price rose "
            f"{price_change_pct:+.2f}% — bearish divergence, exercise caution."
        )
    elif signal == "RETAIL_DRIVEN_RALLY":
        summary = (
            f"Retail (small orders) is driving {sym} {price_change_pct:+.2f}% higher while large orders "
            f"are net sellers ({smart_net_bn:+.1f}B VND) — watch for a reversal."
        )
    elif signal == "RETAIL_PANIC_SELLING":
        summary = (
            f"Retail traders are panic-selling {sym} ({retail_net_bn:+.1f}B VND net retail flow) "
            f"as price falls {price_change_pct:+.2f}% — potential capitulation bottom."
        )
    else:
        summary = (
            f"Mixed flow on {sym}: smart money {smart_net_bn:+.1f}B VND, retail {retail_net_bn:+.1f}B VND, "
            f"price {direction_word} {abs(price_change_pct):.2f}% — no clear dominance."
        )

    return {
        "as_of": config.today(),
        "symbol": sym,
        "signal": signal,
        "summary": summary,
        "tick_count": len(cleaned),
        "lookback_sessions": lookback_sessions,
        "large_order_threshold_pct": large_order_threshold_pct,
        "large_order_threshold_value_vnd": round(threshold, 0),
        "smart_money": {
            "buy_value_vnd": round(large_buy, 0),
            "sell_value_vnd": round(large_sell, 0),
            "net_flow_vnd": round(smart_net, 0),
            "net_flow_bn_vnd": smart_net_bn,
            "buy_ratio": smart_buy_ratio,
            "tick_count": large_count,
        },
        "retail": {
            "buy_value_vnd": round(small_buy, 0),
            "sell_value_vnd": round(small_sell, 0),
            "net_flow_vnd": round(retail_net, 0),
            "net_flow_bn_vnd": retail_net_bn,
            "tick_count": small_count,
        },
        "price": {
            "open": round(first_price, 2),
            "close": round(last_price, 2),
            "change_pct": price_change_pct,
        },
        "divergence": divergence,
        "side_source": "side_column" if has_side else "tick_rule",
    }


# ── Tool 2: Institutional Flow Predictor ───────────────────────────────────

def institutional_flow_predictor(
    symbol: str,
    lookback_days: int = 120,
    prediction_horizon: int = 10,
) -> dict:
    """
    Analyze foreign institutional flow history for a stock and predict price
    moves over the next N sessions by matching the current flow pattern to
    historically similar episodes.

    Builds a z-score profile of recent foreign net flow, classifies the current
    regime (sustained buying, accumulation starting, etc.), then scans history
    for episodes with the most similar 10-day flow profile using Euclidean
    distance. The forward returns of those matched episodes produce a
    confidence-weighted directional forecast.

    Signals:
      SUSTAINED_BUYING    — foreign funds accumulating persistently (z > 1 for 5+ days)
      SUSTAINED_SELLING   — foreign funds distributing persistently (z < -1 for 5+ days)
      ACCUMULATION_START  — fresh foreign buying emerging after neutral/negative period
      DISTRIBUTION_START  — fresh foreign selling emerging after neutral/positive period
      NEUTRAL             — no clear foreign flow conviction

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        symbol:             Stock ticker, e.g. "VCB".
        lookback_days:      Days of history to analyse (default 120).
        prediction_horizon: Forward-return window used for historical matches (default 10).

    Returns:
        Dict with signal, summary, flow regime, flow metrics, episode completion,
        top historical pattern matches, lead-lag correlation profile, and a
        confidence-weighted directional prediction.
    """
    require_sponsored("institutional_flow_predictor")
    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.tools.trading import get_foreign_trading

    sym = symbol.upper()
    start = _days_ago(lookback_days + 30)
    end = config.today()

    try:
        flow_records = get_foreign_trading(sym, start=start, end=end)
    except Exception as e:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "error": str(e),
            "summary": f"Could not fetch foreign flow data for {sym}.",
            "as_of": config.today(),
        }

    try:
        price_records = get_stock_price(sym, length="6M", interval="1D")
    except Exception as e:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "error": str(e),
            "summary": f"Could not fetch price history for {sym}.",
            "as_of": config.today(),
        }

    if not flow_records or not price_records:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "summary": f"No foreign flow or price data returned for {sym}.",
            "as_of": config.today(),
        }

    # ── Build time-series from flow records ──
    def _get_date(rec: dict) -> Optional[str]:
        for k in ("time", "date", "trading_date", "tradingDate"):
            if k in rec and rec[k]:
                return str(rec[k])[:10]
        return None

    def _get_net(rec: dict) -> float:
        for k in (
            "fr_net_value_total",
            "foreign_net_value",
            "net_value",
            "fr_net_value",
            "net_val",
        ):
            v = _safe_float(rec.get(k))
            if v is not None:
                return v
        return 0.0

    flow_by_date: dict[str, float] = {}
    for r in flow_records:
        d = _get_date(r)
        if d:
            flow_by_date[d] = _get_net(r)

    price_by_date: dict[str, float] = {}
    for r in price_records:
        d = _get_date(r)
        c = _safe_float(r.get("close"))
        if d and c is not None:
            price_by_date[d] = c

    # Intersect on common dates, sorted
    common_dates = sorted(set(flow_by_date.keys()) & set(price_by_date.keys()))
    if len(common_dates) < 30:
        return {
            "signal": "UNKNOWN",
            "symbol": sym,
            "summary": (
                f"Insufficient aligned history for {sym}: only {len(common_dates)} "
                f"overlapping days of flow+price data (need >= 30)."
            ),
            "as_of": config.today(),
        }

    dates = common_dates
    net_flow = [flow_by_date[d] for d in dates]
    closes = [price_by_date[d] for d in dates]
    returns = _pct_returns(closes)

    # 5-day and 20-day rolling flow
    flow_5d = _rolling_sum(net_flow, 5)
    flow_20d = _rolling_sum(net_flow, 20)

    # Z-score of 5d flow against 60-day rolling window
    flow_z = _rolling_zscore(flow_5d, window=60, min_periods=20)

    # ── Regime classification ──
    last_10_z = flow_z[-10:] if len(flow_z) >= 10 else flow_z[:]
    current_z = float(flow_z[-1])

    def _consecutive(vals: list[float], cond, min_count: int = 5) -> bool:
        count = 0
        for v in reversed(vals):
            if cond(v):
                count += 1
            else:
                break
        return count >= min_count

    regime = "NEUTRAL"
    if _consecutive(last_10_z, lambda v: v > 1.0, 5):
        regime = "SUSTAINED_BUYING"
    elif _consecutive(last_10_z, lambda v: v < -1.0, 5):
        regime = "SUSTAINED_SELLING"
    elif len(last_10_z) >= 10:
        prior = last_10_z[:5]
        last5 = last_10_z[5:]
        if prior and last5:
            mean_prior = _mean(prior)
            if mean_prior < 0 and max(last5) > 1.0:
                regime = "ACCUMULATION_START"
            elif mean_prior > 0 and min(last5) < -1.0:
                regime = "DISTRIBUTION_START"
            elif abs(current_z) < 1.0:
                regime = "NEUTRAL"

    # ── Flow momentum: 5d vs 20d ──
    flow_5d_now = float(flow_5d[-1])
    flow_20d_now = float(flow_20d[-1])
    momentum_ratio = abs(flow_5d_now) / (abs(flow_20d_now) / 4.0 + 1e-9)

    if momentum_ratio > 1.2:
        momentum_signal = "ACCELERATING"
    elif momentum_ratio < 0.8:
        momentum_signal = "DECELERATING"
    else:
        momentum_signal = "STEADY"

    # ── Historical pattern matching ──
    current_pattern = flow_z[-10:]
    if len(current_pattern) < 10:
        current_pattern = [0.0] * (10 - len(current_pattern)) + current_pattern

    matches: list[dict] = []
    search_end = len(flow_z) - prediction_horizon - 5
    for i in range(20, max(20, search_end)):
        window = flow_z[i - 10 : i]
        if len(window) < 10:
            continue
        if any(math.isnan(v) for v in window):
            continue
        dist = _euclidean(current_pattern, window)
        start_price = closes[i]
        if i + prediction_horizon >= len(closes):
            continue
        end_price = closes[i + prediction_horizon]
        fwd_ret = (end_price / start_price - 1.0) if start_price > 0 else 0.0
        matches.append(
            {
                "date": dates[i],
                "distance": round(dist, 4),
                "forward_return_pct": round(fwd_ret * 100, 2),
            }
        )

    matches.sort(key=lambda x: x["distance"])
    top_matches = matches[:7]

    if top_matches:
        fwd_returns = [m["forward_return_pct"] for m in top_matches]
        avg_return = _mean(fwd_returns)
        median_return = _median(fwd_returns)
        win_rate = sum(1 for r in fwd_returns if r > 0) / len(fwd_returns)
    else:
        avg_return = 0.0
        median_return = 0.0
        win_rate = 0.0

    # ── Lead-lag correlation: flow_z vs returns at lags -5..+5 ──
    returns_clean = [r if r is not None else 0.0 for r in returns]
    lead_lag: dict[str, float] = {}
    for lag in range(-5, 6):
        if lag < 0:
            shifted_flow = flow_z[-lag:]
            shifted_rets = returns_clean[: len(returns_clean) + lag]
            corr = _pearson(shifted_flow, shifted_rets)
        elif lag > 0:
            shifted_flow = flow_z[: len(flow_z) - lag]
            shifted_rets = returns_clean[lag:]
            corr = _pearson(shifted_flow, shifted_rets)
        else:
            corr = _pearson(flow_z, returns_clean)
        if corr is not None:
            lead_lag[f"lag_{lag:+d}d"] = round(corr, 3)

    neg_lags = [lead_lag.get(f"lag_{-i:+d}d", 0) or 0 for i in range(1, 6)]
    pos_lags = [lead_lag.get(f"lag_{i:+d}d", 0) or 0 for i in range(1, 6)]
    flow_leads_price = max(neg_lags, default=0) > max(pos_lags, default=0)

    # ── Directional prediction ──
    prediction = "NEUTRAL"
    confidence = 0.0
    if win_rate > 0.6 and momentum_signal == "ACCELERATING" and flow_leads_price:
        if avg_return > 1.0:
            prediction = "BULLISH"
            confidence = min(0.95, win_rate * 0.7 + 0.25)
        elif avg_return < -1.0:
            prediction = "BEARISH"
            confidence = min(0.95, win_rate * 0.7 + 0.25)
    elif win_rate > 0.55:
        if avg_return > 0.5:
            prediction = "MILDLY_BULLISH"
            confidence = min(0.75, win_rate * 0.6 + 0.15)
        elif avg_return < -0.5:
            prediction = "MILDLY_BEARISH"
            confidence = min(0.75, win_rate * 0.6 + 0.15)

    # ── Episode completion estimate ──
    avg_episode_duration = 15
    episode_completion_pct: Optional[float] = None
    if regime in ("SUSTAINED_BUYING", "SUSTAINED_SELLING"):
        threshold_z = 1.0 if regime == "SUSTAINED_BUYING" else -1.0
        cmp_fn = (lambda v: v > threshold_z) if regime == "SUSTAINED_BUYING" else (lambda v: v < threshold_z)
        streak = 0
        for z in reversed(flow_z):
            if cmp_fn(z):
                streak += 1
            else:
                break
        episode_completion_pct = min(100.0, round(streak / avg_episode_duration * 100, 1))

    # ── Plain-language summary ──
    flow_5d_bn = round(flow_5d_now / 1e9, 1)

    if regime == "SUSTAINED_BUYING":
        summary = (
            f"Foreign institutions have been accumulating {sym} for 5+ sessions "
            f"(5d net +{flow_5d_bn:.1f}B VND, z={current_z:+.2f}). "
            f"Historical matches suggest {avg_return:+.1f}% over the next {prediction_horizon} days "
            f"with {win_rate:.0%} win rate."
        )
    elif regime == "SUSTAINED_SELLING":
        summary = (
            f"Foreign institutions have been distributing {sym} for 5+ sessions "
            f"(5d net {flow_5d_bn:+.1f}B VND, z={current_z:+.2f}). "
            f"Similar episodes historically yielded {avg_return:+.1f}% over {prediction_horizon} days."
        )
    elif regime == "ACCUMULATION_START":
        summary = (
            f"Fresh foreign buying emerging in {sym} after a quiet period — 5d net "
            f"{flow_5d_bn:+.1f}B VND, z={current_z:+.2f}. Early institutional entry detected."
        )
    elif regime == "DISTRIBUTION_START":
        summary = (
            f"Fresh foreign selling emerging in {sym} — 5d net {flow_5d_bn:+.1f}B VND, "
            f"z={current_z:+.2f}. Early institutional exit warning."
        )
    else:
        summary = (
            f"No clear foreign flow conviction on {sym}: 5d net {flow_5d_bn:+.1f}B VND, "
            f"z={current_z:+.2f}, momentum {momentum_signal.lower()}."
        )

    return {
        "as_of": config.today(),
        "symbol": sym,
        "signal": regime,
        "summary": summary,
        "lookback_days": lookback_days,
        "prediction_horizon_days": prediction_horizon,
        "current_flow_regime": regime,
        "flow_metrics": {
            "current_z_score": round(current_z, 3),
            "flow_5d_vnd": round(flow_5d_now, 0),
            "flow_20d_vnd": round(flow_20d_now, 0),
            "flow_5d_bn_vnd": flow_5d_bn,
            "momentum_ratio": round(momentum_ratio, 3),
            "momentum_signal": momentum_signal,
        },
        "episode_completion_pct": episode_completion_pct,
        "historical_pattern_match": {
            "matches_found": len(top_matches),
            "top_matches": top_matches,
            "avg_forward_return_pct": round(avg_return, 2),
            "median_forward_return_pct": round(median_return, 2),
            "win_rate": round(win_rate, 2),
        },
        "lead_lag_correlation": lead_lag,
        "flow_leads_price": flow_leads_price,
        "prediction": {
            "direction": prediction,
            "confidence": round(confidence, 2),
            "horizon_days": prediction_horizon,
            "expected_return_pct": round(avg_return, 2),
        },
    }


# ── Tool 3: Sector Rotation Radar ──────────────────────────────────────────

# Rotation phase keyword map for Vietnam market sectors (lowercase matching).
_ROTATION_PHASE_MAP = {
    "EARLY_CYCLICAL": {"ngân hàng", "bất động sản", "xây dựng", "vật liệu xây dựng", "bank", "real estate", "construction"},
    "MID_CYCLE": {"công nghệ", "bán lẻ", "tiêu dùng", "dịch vụ", "technology", "retail", "consumer"},
    "LATE_CYCLE": {"dầu khí", "thép", "hóa chất", "khoáng sản", "oil", "steel", "chemical", "mining"},
    "DEFENSIVE": {"điện", "nước", "viễn thông", "y tế", "thực phẩm", "utilit", "telecom", "health", "food"},
}


def _classify_quadrant(rs: float, momentum: float) -> str:
    if rs >= 1.0 and momentum >= 0:
        return "LEADING"
    if rs >= 1.0 and momentum < 0:
        return "WEAKENING"
    if rs < 1.0 and momentum < 0:
        return "LAGGING"
    return "IMPROVING"


def _detect_rotation_phase(improving_sectors: list[str]) -> str:
    improving_lower = {s.lower() for s in improving_sectors}
    best_phase = "UNKNOWN"
    best_score = 0
    for phase, keywords in _ROTATION_PHASE_MAP.items():
        overlap = sum(1 for kw in keywords if any(kw in sec for sec in improving_lower))
        if overlap > best_score:
            best_score = overlap
            best_phase = phase
    return best_phase


def sector_rotation_radar(
    lookback_weeks: int = 12,
    momentum_period: int = 4,
    min_sector_stocks: int = 5,
    include_foreign_flow: bool = False,
    max_sectors_analyzed: int = 8,
    max_stocks_per_sector: int = 10,
) -> dict:
    """
    Detect sector rotation across HOSE using Relative Rotation Graph (RRG)
    methodology — which sectors are LEADING, WEAKENING, LAGGING, or IMPROVING
    relative to the VNINDEX benchmark.

    For each HOSE sector, builds an equal-weighted weekly sector index from
    its constituents, computes relative strength (RS) vs VNINDEX and RS
    momentum over the given period, then classifies each sector into an RRG
    quadrant. Rotation pairs and the overall market rotation phase are
    inferred from the set of IMPROVING and WEAKENING sectors.

    Signals:
      EARLY_CYCLICAL — banks, real estate, construction leading (recovery phase)
      MID_CYCLE      — consumer, retail, tech leading (expansion phase)
      LATE_CYCLE     — energy, materials, chemicals leading (peak/inflation phase)
      DEFENSIVE      — utilities, telecom, healthcare leading (contraction phase)
      UNKNOWN        — no clear rotation phase

    Free tier by default. SPONSORED when include_foreign_flow=True
    (foreign trading data requires Bronze/Silver/Golden).

    Args:
        lookback_weeks:       Weeks of history used for RRG (default 12).
        momentum_period:      Weeks over which RS momentum is measured (default 4).
        min_sector_stocks:    Minimum constituents required to include a sector (default 5).
        include_foreign_flow: Annotate sectors with foreign flow of top constituents (SPONSORED).
        max_sectors_analyzed: Cap on sectors analysed to prevent runaway API calls (default 8).
        max_stocks_per_sector: Cap on constituents fetched per sector (default 10).

    Returns:
        Dict with signal (rotation phase), summary, quadrant counts, rotation
        pairs, per-sector RS/momentum metrics, and optional foreign-flow context.
    """
    if include_foreign_flow:
        require_sponsored("sector_rotation_radar (with foreign flow)")

    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.tools.listing import get_stock_list

    # ── Step 1: Load HOSE stock list and group by sector ──
    try:
        all_stocks = get_stock_list(exchange="HOSE")
    except Exception as e:
        return {
            "signal": "UNKNOWN",
            "error": str(e),
            "summary": "Could not fetch HOSE stock list.",
            "as_of": config.today(),
        }

    if not all_stocks:
        return {
            "signal": "UNKNOWN",
            "summary": "No HOSE stocks returned from listing API.",
            "as_of": config.today(),
        }

    sector_groups: dict[str, list[str]] = defaultdict(list)
    for row in all_stocks:
        sector = (
            row.get("industry")
            or row.get("sector")
            or row.get("industry_name")
            or row.get("icb_name2")
            or row.get("icb_name3")
        )
        sym = row.get("symbol") or row.get("ticker") or row.get("code")
        if sector and sym:
            sector_groups[str(sector)].append(sym)

    # Filter sectors by minimum constituent count
    eligible_sectors = {s: syms for s, syms in sector_groups.items() if len(syms) >= min_sector_stocks}

    if not eligible_sectors:
        return {
            "signal": "UNKNOWN",
            "summary": (
                f"No HOSE sectors found with >= {min_sector_stocks} stocks. "
                f"Stock list may not include industry classification."
            ),
            "as_of": config.today(),
        }

    # Cap number of sectors analysed (rank by constituent count desc)
    sector_items = sorted(eligible_sectors.items(), key=lambda x: -len(x[1]))[:max_sectors_analyzed]

    # ── Step 2: Fetch VNINDEX weekly benchmark ──
    try:
        bench_records = get_stock_price("VNINDEX", length="6M", interval="1W")
    except Exception as e:
        return {
            "signal": "UNKNOWN",
            "error": str(e),
            "summary": "Could not fetch VNINDEX benchmark.",
            "as_of": config.today(),
        }

    bench_closes = [_safe_float(r.get("close")) for r in bench_records or []]
    bench_closes = [c for c in bench_closes if c is not None and c > 0]

    if len(bench_closes) < momentum_period + 2:
        return {
            "signal": "UNKNOWN",
            "summary": f"Insufficient VNINDEX weekly data ({len(bench_closes)} points).",
            "as_of": config.today(),
        }

    # Normalise benchmark to 1.0 at start
    bench_base = bench_closes[0]
    bench_norm = [c / bench_base for c in bench_closes] if bench_base > 0 else bench_closes[:]

    # ── Step 3: Compute each sector's equal-weight weekly index ──
    def _compute_sector_index(symbols: list[str]) -> Optional[list[float]]:
        sample = symbols[:max_stocks_per_sector]
        series_list: list[list[float]] = []
        for sym in sample:
            try:
                recs = get_stock_price(sym, length="6M", interval="1W")
            except Exception:
                continue
            if not recs:
                continue
            closes = [_safe_float(r.get("close")) for r in recs]
            closes = [c for c in closes if c is not None and c > 0]
            if len(closes) < momentum_period + 2:
                continue
            base = closes[0]
            normalised = [c / base for c in closes]
            series_list.append(normalised)

        if len(series_list) < 3:
            return None

        min_len = min(len(s) for s in series_list)
        aligned = [s[:min_len] for s in series_list]
        sector_index = [sum(s[i] for s in aligned) / len(aligned) for i in range(min_len)]
        return sector_index

    sector_indices: dict[str, list[float]] = {}
    for sector_name, symbols in sector_items:
        idx = _compute_sector_index(symbols)
        if idx:
            sector_indices[sector_name] = idx

    if not sector_indices:
        return {
            "signal": "UNKNOWN",
            "summary": "Could not compute any sector indices (insufficient constituent data).",
            "as_of": config.today(),
        }

    # ── Step 4: Compute RS, momentum, acceleration, and classify quadrants ──
    sector_results: list[dict] = []
    improving_sectors: list[str] = []
    weakening_sectors: list[str] = []
    leading_sectors: list[str] = []
    lagging_sectors: list[str] = []

    for sector_name, sector_idx in sector_indices.items():
        min_len = min(len(sector_idx), len(bench_norm))
        if min_len < momentum_period + 2:
            continue

        s_idx = sector_idx[:min_len]
        b_idx = bench_norm[:min_len]

        # RS = sector / benchmark
        rs_series = [
            (s_idx[i] / b_idx[i]) if b_idx[i] != 0 else 1.0 for i in range(min_len)
        ]

        rs_now = rs_series[-1]

        # RS momentum
        if len(rs_series) > momentum_period:
            rs_prev = rs_series[-momentum_period - 1]
            rs_momentum = (rs_now / rs_prev - 1.0) if rs_prev != 0 else 0.0
        else:
            rs_momentum = 0.0

        # RS acceleration (momentum_now - momentum_1w_ago)
        if len(rs_series) > momentum_period + 1:
            rs_prev_1w = rs_series[-2]
            rs_prev_m1 = rs_series[-momentum_period - 2]
            rs_momentum_1w_ago = (rs_prev_1w / rs_prev_m1 - 1.0) if rs_prev_m1 != 0 else 0.0
            rs_acceleration = rs_momentum - rs_momentum_1w_ago
        else:
            rs_acceleration = 0.0

        quadrant = _classify_quadrant(rs_now, rs_momentum)

        # Breadth approximation: % of recent weekly up-moves
        breadth_window = min(10, len(s_idx))
        stocks_up = sum(
            1 for j in range(1, breadth_window) if s_idx[-j] > s_idx[-j - 1]
        )
        breadth_pct = round(stocks_up / max(breadth_window - 1, 1) * 100, 1)

        entry = {
            "sector": sector_name,
            "stock_count": len(eligible_sectors[sector_name]),
            "rs_ratio": round(rs_now, 4),
            "rs_momentum": round(rs_momentum, 4),
            "rs_acceleration": round(rs_acceleration, 4),
            "quadrant": quadrant,
            "breadth_pct_up": breadth_pct,
        }

        if quadrant == "IMPROVING":
            improving_sectors.append(sector_name)
        elif quadrant == "WEAKENING":
            weakening_sectors.append(sector_name)
        elif quadrant == "LEADING":
            leading_sectors.append(sector_name)
        elif quadrant == "LAGGING":
            lagging_sectors.append(sector_name)

        sector_results.append(entry)

    sector_results.sort(key=lambda x: x["rs_momentum"], reverse=True)

    # ── Step 5: Detect rotation pairs ──
    rotation_pairs: list[dict] = []
    for imp in improving_sectors:
        for weak in weakening_sectors:
            rotation_pairs.append(
                {"rotating_into": imp, "rotating_out_of": weak, "signal": "SECTOR_ROTATION"}
            )

    # ── Step 6: Determine rotation phase ──
    # Use improving + leading sectors to infer rotation phase
    rotation_phase = _detect_rotation_phase(improving_sectors + leading_sectors)

    # ── Step 7 (optional): Foreign flow confirmation for top constituents ──
    foreign_flow_summary: Optional[dict] = None
    if include_foreign_flow:
        from vnstock_mcp_advanced.tools.trading import get_foreign_trading

        fflow_start = _days_ago(7)
        fflow_end = config.today()
        sector_flow: dict[str, float] = {}

        for sector_name, symbols in sector_items:
            top3 = symbols[:3]
            sector_net = 0.0
            fetched = 0
            for sym in top3:
                try:
                    recs = get_foreign_trading(sym, start=fflow_start, end=fflow_end)
                    if not recs:
                        continue
                    net = sum(
                        _safe_float(
                            r.get("fr_net_value_total")
                            or r.get("foreign_net_value")
                            or 0
                        )
                        or 0
                        for r in recs
                    )
                    sector_net += net
                    fetched += 1
                except Exception:
                    continue
            if fetched:
                sector_flow[sector_name] = round(sector_net / 1e9, 2)

        # Annotate sector results with foreign flow
        for entry in sector_results:
            if entry["sector"] in sector_flow:
                entry["foreign_net_7d_bn_vnd"] = sector_flow[entry["sector"]]

        if sector_flow:
            top_foreign_buy = sorted(sector_flow.items(), key=lambda x: -x[1])[:3]
            top_foreign_sell = sorted(sector_flow.items(), key=lambda x: x[1])[:3]
            foreign_flow_summary = {
                "top_sectors_foreign_buying": [
                    {"sector": s, "net_bn_vnd": v} for s, v in top_foreign_buy if v > 0
                ],
                "top_sectors_foreign_selling": [
                    {"sector": s, "net_bn_vnd": v} for s, v in top_foreign_sell if v < 0
                ],
                "note": "Cross-reference with RRG quadrants to confirm rotation conviction.",
            }

    # ── Quadrant summary counts ──
    quadrant_counts: dict[str, int] = defaultdict(int)
    for sr in sector_results:
        quadrant_counts[sr["quadrant"]] += 1

    # ── Plain-language summary ──
    phase_descriptions = {
        "EARLY_CYCLICAL": "early cyclical phase (banking, real estate, construction leading)",
        "MID_CYCLE": "mid-cycle expansion phase (consumer, retail, technology leading)",
        "LATE_CYCLE": "late-cycle peak phase (energy, materials, chemicals leading)",
        "DEFENSIVE": "defensive contraction phase (utilities, telecom, healthcare leading)",
        "UNKNOWN": "no clearly defined rotation phase",
    }
    phase_desc = phase_descriptions.get(rotation_phase, "unclear rotation phase")

    if improving_sectors and weakening_sectors:
        summary = (
            f"{len(improving_sectors)} sector(s) rotating into the IMPROVING quadrant "
            f"({', '.join(improving_sectors[:2])}) while {len(weakening_sectors)} are WEAKENING "
            f"({', '.join(weakening_sectors[:2])}) — market is in {phase_desc}."
        )
    elif improving_sectors:
        summary = (
            f"{', '.join(improving_sectors[:3])} rotating into the IMPROVING quadrant with "
            f"accelerating RS momentum — {phase_desc} confirmed."
        )
    elif leading_sectors:
        summary = (
            f"{len(leading_sectors)} sector(s) LEADING with positive momentum "
            f"({', '.join(leading_sectors[:3])}) — market in {phase_desc}."
        )
    else:
        summary = (
            f"No clear sector rotation detected across {len(sector_results)} HOSE sectors — "
            f"{phase_desc}."
        )

    result = {
        "as_of": config.today(),
        "signal": rotation_phase,
        "summary": summary,
        "analysis_period_weeks": lookback_weeks,
        "momentum_period_weeks": momentum_period,
        "sectors_analyzed": len(sector_results),
        "quadrant_summary": dict(quadrant_counts),
        "rotation_phase": rotation_phase,
        "rotation_pairs": rotation_pairs,
        "sectors": sector_results,
        "leading_sectors": leading_sectors,
        "improving_sectors": improving_sectors,
        "weakening_sectors": weakening_sectors,
        "lagging_sectors": lagging_sectors,
    }

    if foreign_flow_summary is not None:
        result["foreign_flow"] = foreign_flow_summary

    return result
