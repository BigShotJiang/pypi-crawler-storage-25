"""
Flow tools — institutional money flow analysis for near-term forecasting.

These tools aggregate foreign fund and proprietary desk activity to surface
where "smart money" is positioning — before prices fully reflect it.

All tools require sponsored tier (Bronze/Silver/Golden).
"""

from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def _days_ago(n: int) -> str:
    return (date.today() - timedelta(days=n)).isoformat()


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def get_smart_money_flow(
    symbols: Optional[list[str]] = None,
    lookback_days: int = 5,
) -> dict:
    """
    Aggregate foreign fund and proprietary desk net flows across a stock universe
    to determine whether institutional players are collectively buying or selling.

    When both foreign funds AND prop desks are net buyers in sync, it is a
    high-conviction signal that institutional money is accumulating. The opposite
    (both selling) is a distribution warning.

    Uses VN30 as the default universe if no symbols are provided.

    Signals:
      STRONG ACCUMULATION — both foreign and prop buying in sync (3+ of 5 days)
      FOREIGN BUYING      — foreign funds net positive, prop desk mixed
      PROP BUYING         — prop desks net positive, foreign mixed
      DISTRIBUTION        — both sides net selling: institutional exit warning
      NEUTRAL             — mixed signals, no clear direction

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        symbols:      List of tickers to aggregate. Defaults to VN30.
        lookback_days: Days to aggregate flows over (default 5 = 1 week).

    Returns:
        Dict with signal, total net VND billions by source, consensus day count,
        top symbols by each flow, and a plain-language summary.
    """
    require_sponsored("get_smart_money_flow")
    from vnstock_mcp_advanced.tools.trading import get_foreign_trading, get_prop_trading
    from vnstock_mcp_advanced.tools.listing import get_index_members

    # Build universe
    if not symbols:
        try:
            members = get_index_members(index="VN30", source="vci")
            symbols = [m.get("symbol") or m.get("ticker") or m.get("code") for m in members]
            symbols = [s for s in symbols if s]
            universe_name = "VN30"
        except Exception:
            return {"signal": "UNKNOWN", "summary": "Could not load VN30 symbol list."}
    else:
        universe_name = f"{len(symbols)} stocks"

    start = _days_ago(lookback_days + 10)  # buffer for weekends
    end = config.today()

    foreign_by_symbol: dict = {}
    prop_by_symbol: dict = {}

    for sym in symbols:
        try:
            records = get_foreign_trading(sym, start=start, end=end)
            records = records[-lookback_days:]
            net = sum(_safe_float(r.get("fr_net_value_total") or r.get("foreign_net_value") or 0) for r in records)
            foreign_by_symbol[sym] = net
        except Exception:
            foreign_by_symbol[sym] = 0

        try:
            records = get_prop_trading(sym, start=start, end=end)
            records = records[-lookback_days:]
            net = sum(_safe_float(r.get("total_trade_net_value") or r.get("prop_net_value") or 0) for r in records)
            prop_by_symbol[sym] = net
        except Exception:
            prop_by_symbol[sym] = 0

    total_foreign = sum(foreign_by_symbol.values())
    total_prop = sum(prop_by_symbol.values())
    combined = total_foreign + total_prop

    total_foreign_bn = round(total_foreign / 1e9, 1)
    total_prop_bn = round(total_prop / 1e9, 1)
    combined_bn = round(combined / 1e9, 1)

    # Consensus: count symbols where BOTH are same direction
    consensus_buy = sum(
        1 for sym in symbols
        if (foreign_by_symbol.get(sym) or 0) > 0 and (prop_by_symbol.get(sym) or 0) > 0
    )
    consensus_sell = sum(
        1 for sym in symbols
        if (foreign_by_symbol.get(sym) or 0) < 0 and (prop_by_symbol.get(sym) or 0) < 0
    )

    # Top symbols
    top_foreign = sorted(foreign_by_symbol.items(), key=lambda x: -x[1])[:3]
    top_prop = sorted(prop_by_symbol.items(), key=lambda x: -x[1])[:3]
    top_foreign_sell = sorted(foreign_by_symbol.items(), key=lambda x: x[1])[:3]

    # Signal
    if total_foreign > 0 and total_prop > 0 and consensus_buy >= len(symbols) * 0.4:
        signal = "STRONG ACCUMULATION"
    elif total_foreign > 0 and total_prop > 0:
        signal = "BOTH BUYING"
    elif total_foreign > 0 and total_prop <= 0:
        signal = "FOREIGN BUYING"
    elif total_prop > 0 and total_foreign <= 0:
        signal = "PROP BUYING"
    elif total_foreign < 0 and total_prop < 0:
        signal = "DISTRIBUTION"
    else:
        signal = "NEUTRAL"

    if signal in ("STRONG ACCUMULATION", "BOTH BUYING"):
        summary = (
            f"Both foreign funds and prop desks are net buyers across {universe_name} — "
            f"foreign net {total_foreign_bn:+.1f}B VND, prop net {total_prop_bn:+.1f}B VND "
            f"over the last {lookback_days} sessions. Institutional consensus is bullish."
        )
    elif signal == "DISTRIBUTION":
        summary = (
            f"Both foreign funds and prop desks are net sellers across {universe_name} — "
            f"foreign {total_foreign_bn:+.1f}B VND, prop {total_prop_bn:+.1f}B VND. "
            f"Institutional distribution — exercise caution."
        )
    else:
        direction = "buying" if combined_bn > 0 else "selling"
        summary = (
            f"Mixed signals across {universe_name}: foreign {total_foreign_bn:+.1f}B VND, "
            f"prop {total_prop_bn:+.1f}B VND over {lookback_days} sessions. "
            f"Net combined: {combined_bn:+.1f}B VND ({direction})."
        )

    return {
        "as_of": config.today(),
        "universe": universe_name,
        "lookback_days": lookback_days,
        "signal": signal,
        "summary": summary,
        "total_foreign_net_bn_vnd": total_foreign_bn,
        "total_prop_net_bn_vnd": total_prop_bn,
        "combined_smart_money_net_bn_vnd": combined_bn,
        "consensus_buy_symbols": consensus_buy,
        "top_foreign_buys": [s for s, _ in top_foreign if _ > 0],
        "top_prop_buys": [s for s, _ in top_prop if _ > 0],
        "top_foreign_sells": [s for s, _ in top_foreign_sell if _ < 0],
    }


def get_prop_desk_positioning(
    index: str = "VNINDEX",
    lookback_days: int = 5,
    limit: int = 10,
) -> dict:
    """
    Find out what Vietnamese securities firms' own trading desks are buying
    and selling this week — and flag when they are "buying the dip" or
    "selling into a rally" (counter-trend signals often used as leading indicators).

    Uses the top active stocks by volume as the scanning universe.

    Signals:
      PROP BUYING DIP      — prop desk buying while price fell today: smart accumulation
      PROP SELLING RALLY   — prop desk selling while price rose today: distribution into strength
      PROP ACCUMULATING    — sustained multi-day prop net buying
      PROP DISTRIBUTING    — sustained multi-day prop net selling

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        index:        Market scope to scan — "VNINDEX", "HNX", "VN30".
        lookback_days: Days to aggregate prop trading over (default 5).
        limit:        Number of top active stocks to scan (default 10).

    Returns:
        Dict with signal, list of stocks prop desks are accumulating vs distributing,
        highlighted dip-buy and sell-into-rally setups, and a plain-language summary.
    """
    require_sponsored("get_prop_desk_positioning")
    from vnstock_data import TopStock
    from vnstock_mcp_advanced.tools.trading import get_prop_trading
    from vnstock_mcp_advanced.utils.serializer import df_to_records

    start = _days_ago(lookback_days + 10)
    end = config.today()

    # Step 1: Get active universe via volume spike leaders
    try:
        ts = TopStock()
        vol_df = ts.volume(index=index, limit=limit * 2)
        vol_records = df_to_records(vol_df)
    except Exception as e:
        return {"signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch active stock universe."}

    symbols = [r.get("symbol") for r in vol_records if r.get("symbol")][:limit]
    price_changes = {
        r.get("symbol"): _safe_float(r.get("price_change_pct_1d") or r.get("price_change_1d"))
        for r in vol_records if r.get("symbol")
    }

    accumulating = []
    distributing = []

    for sym in symbols:
        try:
            records = get_prop_trading(sym, start=start, end=end)
            records = records[-lookback_days:]
            if not records:
                continue
            net_val = sum(
                _safe_float(r.get("total_trade_net_value") or r.get("prop_net_value") or 0)
                for r in records
            )
            net_bn = round(net_val / 1e9, 2)
            price_chg = price_changes.get(sym) or 0.0

            # Intensity: net vs approximate daily turnover (rough estimate)
            buy_days = sum(
                1 for r in records
                if _safe_float(r.get("total_trade_net_value") or 0) > 0
            )
            sell_days = len(records) - buy_days

            entry = {
                "symbol": sym,
                "prop_net_5d_bn_vnd": net_bn,
                "buy_days": buy_days,
                "sell_days": sell_days,
                "price_change_today_pct": price_chg,
            }

            if net_bn > 0:
                buying_dip = price_chg < -1.0
                entry["buying_the_dip"] = buying_dip
                entry["signal"] = "PROP BUYING DIP" if buying_dip else "PROP ACCUMULATING"
                accumulating.append(entry)
            elif net_bn < 0:
                selling_rally = price_chg > 1.0
                entry["selling_into_strength"] = selling_rally
                entry["signal"] = "PROP SELLING RALLY" if selling_rally else "PROP DISTRIBUTING"
                distributing.append(entry)

        except Exception:
            continue

    # Sort
    accumulating.sort(key=lambda x: -x["prop_net_5d_bn_vnd"])
    distributing.sort(key=lambda x: x["prop_net_5d_bn_vnd"])

    # Headline signal
    dip_buyers = [s for s in accumulating if s["signal"] == "PROP BUYING DIP"]
    rally_sellers = [s for s in distributing if s["signal"] == "PROP SELLING RALLY"]

    if dip_buyers and rally_sellers:
        signal = f"PROP BUYING {', '.join(s['symbol'] for s in dip_buyers[:2])} + SELLING {', '.join(s['symbol'] for s in rally_sellers[:2])}"
    elif dip_buyers:
        signal = f"PROP BUYING DIP: {', '.join(s['symbol'] for s in dip_buyers[:3])}"
    elif accumulating:
        signal = f"PROP ACCUMULATING: {', '.join(s['symbol'] for s in accumulating[:3])}"
    elif rally_sellers:
        signal = f"PROP SELLING INTO RALLY: {', '.join(s['symbol'] for s in rally_sellers[:3])}"
    elif distributing:
        signal = f"PROP DISTRIBUTING: {', '.join(s['symbol'] for s in distributing[:3])}"
    else:
        signal = "NEUTRAL — NO CLEAR PROP POSITIONING"

    # Summary
    acc_names = [s["symbol"] for s in accumulating[:3]]
    dist_names = [s["symbol"] for s in distributing[:3]]
    if acc_names and dist_names:
        summary = (
            f"Prop desks are accumulating {', '.join(acc_names)} while distributing {', '.join(dist_names)} "
            f"over the last {lookback_days} sessions. "
            + (f"Notable dip-buying in: {', '.join(s['symbol'] for s in dip_buyers[:2])}." if dip_buyers else "")
        )
    elif acc_names:
        summary = f"Prop desks are net buyers of {', '.join(acc_names)} over the last {lookback_days} sessions."
    elif dist_names:
        summary = f"Prop desks are net sellers of {', '.join(dist_names)} — a caution signal for those names."
    else:
        summary = f"No clear prop desk positioning detected across {len(symbols)} active stocks."

    return {
        "as_of": config.today(),
        "index": index,
        "lookback_days": lookback_days,
        "symbols_scanned": len(symbols),
        "signal": signal,
        "summary": summary,
        "prop_accumulating": accumulating,
        "prop_distributing": distributing,
        "dip_buyers": dip_buyers,
        "rally_sellers": rally_sellers,
    }
