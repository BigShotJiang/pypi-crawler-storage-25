"""
Insights tools — market movers, top foreign flows (sponsored tier, VND source).

These are high-value one-shot market scanning tools.
"""

from typing import Optional, Literal
from vnstock_mcp_advanced.utils.serializer import df_to_records
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def get_top_movers(
    category: Literal["gainer", "loser", "volume", "value", "deal"] = "gainer",
    index: str = "VNINDEX",
    limit: int = 10,
) -> list[dict]:
    """
    Get top-moving stocks by various criteria (sponsored tier).

    Args:
        category: What to rank by —
                  "gainer"  → highest % price gain today
                  "loser"   → largest % price decline today
                  "volume"  → largest volume spike vs. average
                  "value"   → highest trading value today
                  "deal"    → highest deal-count spike
        index:    Market scope — "VNINDEX", "HNX", "UPCOM", "VN30", etc.
        limit:    Number of stocks to return (default 10).

    Returns:
        List of dicts with symbol, price, change %, volume, value,
        and accumulated stats for each top-ranked stock.
    """
    require_sponsored("get_top_movers")
    from vnstock_data import TopStock

    ts = TopStock()
    method_map = {
        "gainer": ts.gainer,
        "loser": ts.loser,
        "volume": ts.volume,
        "value": ts.value,
        "deal": ts.deal,
    }
    df = method_map[category](index=index, limit=limit)
    return df_to_records(df)


def get_foreign_top_stocks(
    direction: Literal["buy", "sell"] = "buy",
    date: Optional[str] = None,
    limit: int = 10,
) -> list[dict]:
    """
    Get stocks with highest net foreign buying or selling (sponsored tier).

    This is one of the most actionable signals for retail investors —
    persistent foreign buying often precedes price appreciation.

    Args:
        direction: "buy" → top net foreign buyers | "sell" → top net foreign sellers.
        date:      Date to query "YYYY-MM-DD". Defaults to today.
        limit:     Number of stocks to return.

    Returns:
        List of dicts with symbol, foreign_net_volume, foreign_net_value,
        price, change %, and accumulated foreign flow.
    """
    require_sponsored("get_foreign_top_stocks")
    from vnstock_data import TopStock
    from vnstock_mcp_advanced import config

    ts = TopStock()
    query_date = date or config.today()

    if direction == "buy":
        df = ts.foreign_buy(date=query_date, limit=limit)
    else:
        df = ts.foreign_sell(date=query_date, limit=limit)

    return df_to_records(df)

def get_opportunities(
    direction: Literal["buy", "sell"] = "buy",
    date: Optional[str] = None,
) -> list[dict]:
    from vnstock_data import Insights

    ins = Insights()

    # Lấy danh sách cổ phiếu giảm giá mạnh
    losers = ins.ranking().loser()

    # Lấy dữ liệu screener toàn bộ
    screener = ins.screener().filter()

    # Merge tìm cơ hội
    opportunity = losers.merge(
        screener,
        left_on='code',
        right_on='ticker',
        how='inner'
    )
    return opportunity[['ticker', 'pe', 'roe']].head()