"""
Trading tools — real-time price board, foreign flows, insider/prop trading.

Price board works on both tiers.
Foreign/prop trading flows require sponsored tier (vnstock_data).
"""

from typing import Optional
from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def get_price_board(
    symbols: list[str],
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get real-time price board for a list of stock symbols.

    Returns bid/ask levels, last price, change %, foreign net buy/sell,
    volume, and market cap for each symbol.

    Args:
        symbols: List of tickers, e.g. ["VCB", "TCB", "ACB"].
        source:  Data source override ("kbs" or "vci").

    Returns:
        List of dicts — one per symbol with full price board columns.
    """
    src = source or config.SOURCE_TRADING

    if config.IS_SPONSORED:
        from vnstock_data import Trading
    else:
        from vnstock import Trading

    trading = Trading(source=src)
    df = trading.price_board(symbols_list=symbols)
    return df_to_records(df)


def get_foreign_trading(
    symbol: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get historical foreign investor buy/sell activity for a symbol.

    Shows net foreign buy/sell volume and value over time — a key signal
    for tracking institutional flow.

    Args:
        symbol: Ticker, e.g. "VCB".
        start:  Start date "YYYY-MM-DD". Defaults to 3 months ago.
        end:    End date "YYYY-MM-DD". Defaults to today.
        source: Data source override.

    Returns:
        List of dicts with date, foreign_buy_volume, foreign_sell_volume,
        foreign_net_volume, foreign_buy_value, foreign_sell_value, foreign_net_value.
    """
    require_sponsored("get_foreign_trading")
    from vnstock_data import Trading

    src = source or config.SOURCE_TRADING
    start = start or config.three_months_ago()
    end = end or config.today()

    trading = Trading(symbol=symbol, source=src)
    df = trading.foreign_trade(start=start, end=end)
    return df_to_records(df)


def get_prop_trading(
    symbol: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get proprietary (self-dealing) trading activity for a symbol.

    Proprietary trades are placed by securities firms for their own accounts —
    often considered a "smart money" signal.

    Args:
        symbol: Ticker, e.g. "VCB".
        start:  Start date "YYYY-MM-DD". Defaults to 3 months ago.
        end:    End date "YYYY-MM-DD". Defaults to today.
        source: Data source override.

    Returns:
        List of dicts with date, prop_buy_volume, prop_sell_volume, prop_net.
    """
    require_sponsored("get_prop_trading")
    from vnstock_data import Trading

    src = source or config.SOURCE_TRADING
    start = start or config.three_months_ago()
    end = end or config.today()

    trading = Trading(symbol=symbol, source=src)
    df = trading.prop_trade(start=start, end=end)
    return df_to_records(df)


def get_insider_trading(
    symbol: str,
    limit: int = 20,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get insider trading records — transactions by company officers,
    board members, and major shareholders.

    Args:
        symbol: Ticker, e.g. "VCB".
        limit:  Max number of records to return.
        source: Data source override.

    Returns:
        List of dicts with trader name, position, action (buy/sell),
        volume, value, and transaction date.
    """
    require_sponsored("get_insider_trading")
    from vnstock_data import Trading

    src = source or config.SOURCE_TRADING
    trading = Trading(symbol=symbol, source=src)
    df = trading.insider_deal(limit=limit)
    return df_to_records(df)


def get_trading_summary(
    symbol: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get a trading summary (aggregated statistics) for a symbol over a period.

    Args:
        symbol: Ticker, e.g. "VCB".
        start:  Start date "YYYY-MM-DD". Defaults to 3 months ago.
        end:    End date "YYYY-MM-DD". Defaults to today.
        source: Data source override.

    Returns:
        List of dicts with daily summary stats (volume, value, avg price, etc.).
    """
    require_sponsored("get_trading_summary")
    from vnstock_data import Trading

    src = source or config.SOURCE_TRADING
    start = start or config.three_months_ago()
    end = end or config.today()

    trading = Trading(symbol=symbol, source=src)
    df = trading.summary(start=start, end=end)
    return df_to_records(df)
