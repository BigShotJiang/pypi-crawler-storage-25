"""
Investor tools — plain-language signals and summaries for mid-tier retail investors.

These tools combine multiple data sources and apply simple calculations to answer
common investor questions without financial jargon. Every tool returns a `signal`
field (e.g. HEALTHY/WATCH/CAUTION) and a `summary` sentence in plain English.

Categories:
  A. Stock Health Check  — check_stock_health, get_valuation_snapshot
  B. Buy/Sell Signals    — check_price_signal, check_foreign_flow_signal
  C. Dividend & Income   — get_dividend_history, scan_dividend_stocks
  D. Risk Warnings       — check_risk_flags, check_volume_anomaly
  E. Portfolio Watchlist — watchlist_snapshot
"""

from collections import defaultdict
from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


# ── Internal helpers ───────────────────────────────────────────────────────

def _days_ago(n: int) -> str:
    return (date.today() - timedelta(days=n)).isoformat()


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _roe_pct(raw) -> Optional[float]:
    """Normalise ROE to percentage (handles both 0.18 and 18.0 formats)."""
    v = _safe_float(raw)
    if v is None:
        return None
    return v * 100 if abs(v) < 5 else v  # heuristic: <5 is likely a decimal ratio


# ── A. Stock Health Check ──────────────────────────────────────────────────

def check_stock_health(
    symbol: str,
    source: Optional[str] = None,
) -> dict:
    """
    Run a 5-point health check on a stock — profitability, valuation, price
    trend, profit growth, and debt level. Returns a plain-language verdict.

    Each check is pass/fail. The overall signal is:
      HEALTHY (4-5 pass), WATCH (3 pass), CAUTION (0-2 pass).

    Args:
        symbol: Ticker, e.g. "VCB", "HPG", "FPT".
        source: Data source override ("kbs" or "vci").

    Returns:
        Dict with signal, score ("4/5"), summary sentence, individual check
        results, key ratios, and price context (52-week range, 20-day average).
    """
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    # Fetch ratios — use multi-year for YoY profit growth check
    ratios_all, latest, prior = [], {}, {}
    try:
        ratios_all = get_financial_ratios(symbol, period="year", source=source or config.SOURCE_FINANCE)
        if ratios_all:
            latest = ratios_all[-1]
        if len(ratios_all) >= 2:
            prior = ratios_all[-2]
    except Exception:
        pass

    # Fetch 1-year daily prices
    closes, volumes = [], []
    try:
        prices = get_stock_price(symbol, length="1Y", interval="1D", source=source or config.SOURCE_QUOTE)
        closes = [_safe_float(p.get("close")) for p in prices if p.get("close") is not None]
        volumes = [_safe_float(p.get("volume")) for p in prices if p.get("volume") is not None]
    except Exception:
        pass

    current_price = closes[-1] if closes else None
    avg_20d = sum(closes[-20:]) / 20 if len(closes) >= 20 else None
    high_52w = max(closes) if closes else None
    low_52w = min(closes) if closes else None

    checks = {}

    # Check 1 — Profitability: ROE > 10%
    roe_pct = _roe_pct(latest.get("roe") or latest.get("return_on_equity"))
    if roe_pct is not None:
        checks["profitability"] = {
            "pass": roe_pct >= 10,
            "detail": f"ROE {roe_pct:.1f}% — {'above' if roe_pct >= 10 else 'below'} 10% threshold",
        }
    else:
        checks["profitability"] = {"pass": None, "detail": "ROE data not available"}

    # Check 2 — Valuation: PE < 20
    pe = _safe_float(latest.get("pe") or latest.get("price_to_earning"))
    if pe and pe > 0:
        checks["valuation"] = {
            "pass": pe < 20,
            "detail": f"PE {pe:.1f} — {'below' if pe < 20 else 'above'} 20 threshold",
        }
    else:
        checks["valuation"] = {
            "pass": None,
            "detail": "PE unavailable" if pe is None else "Negative PE (loss-making period)",
        }

    # Check 3 — Price trend: above 20-day average
    if current_price and avg_20d:
        above = current_price >= avg_20d
        diff_pct = (current_price - avg_20d) / avg_20d * 100
        checks["price_trend"] = {
            "pass": above,
            "detail": f"Price {current_price:,.0f} is {abs(diff_pct):.1f}% {'above' if above else 'below'} 20-day avg {avg_20d:,.0f}",
        }
    else:
        checks["price_trend"] = {"pass": None, "detail": "Insufficient price data"}

    # Check 4 — Profit growth: EPS improved YoY
    eps_now = _safe_float(latest.get("eps"))
    eps_prev = _safe_float(prior.get("eps"))
    if eps_now is not None and eps_prev is not None and eps_prev != 0:
        growth_pct = (eps_now - eps_prev) / abs(eps_prev) * 100
        checks["profit_growth"] = {
            "pass": growth_pct >= 0,
            "detail": f"EPS {'grew' if growth_pct >= 0 else 'fell'} {abs(growth_pct):.1f}% vs prior year",
        }
    else:
        checks["profit_growth"] = {"pass": None, "detail": "Multi-year EPS data not available"}

    # Check 5 — Debt: Debt/Equity < 3.0
    de = _safe_float(
        latest.get("debt_on_equity") or latest.get("debt_equity") or latest.get("de_ratio")
    )
    if de is not None:
        checks["debt_level"] = {
            "pass": de < 3.0,
            "detail": f"Debt/Equity {de:.2f} — {'within range' if de < 3.0 else 'above 3.0 threshold'}",
        }
    else:
        checks["debt_level"] = {"pass": None, "detail": "Debt/Equity data not available"}

    # Score
    passed = [k for k, v in checks.items() if v.get("pass") is True]
    available = [k for k, v in checks.items() if v.get("pass") is not None]
    score_str = f"{len(passed)}/{len(available)}"

    if not available:
        signal = "UNKNOWN"
    elif len(passed) >= max(len(available) * 0.8, len(available) - 1):
        signal = "HEALTHY"
    elif len(passed) >= len(available) * 0.6:
        signal = "WATCH"
    else:
        signal = "CAUTION"

    trend_word = "above" if checks.get("price_trend", {}).get("pass") else "below"
    roe_str = f"ROE {roe_pct:.1f}%" if roe_pct else "ROE unavailable"
    pe_str = f"PE {pe:.1f}" if pe and pe > 0 else "PE unavailable"
    summary = (
        f"{symbol} passes {score_str} health checks. "
        f"Price is {trend_word} its 20-day average with {roe_str} and {pe_str}."
    )

    return {
        "symbol": symbol,
        "signal": signal,
        "score": score_str,
        "summary": summary,
        "checks": checks,
        "key_ratios": {
            "pe": pe,
            "pb": _safe_float(latest.get("pb") or latest.get("price_to_book")),
            "roe_pct": roe_pct,
            "debt_equity": de,
            "eps": _safe_float(latest.get("eps")),
        },
        "price_context": {
            "current_price": current_price,
            "avg_20d": round(avg_20d, 0) if avg_20d else None,
            "week_52_high": high_52w,
            "week_52_low": low_52w,
            "pct_from_52w_high": round((current_price - high_52w) / high_52w * 100, 1)
            if current_price and high_52w else None,
        },
    }


def get_valuation_snapshot(
    symbol: str,
    years_back: int = 3,
    source: Optional[str] = None,
) -> dict:
    """
    Compare a stock's current PE and PB against its own multi-year history
    to answer: "Is this stock cheap or expensive right now?"

    Signals:
      CHEAP         — current ratio is in the lower third of its historical range
      FAIRLY_VALUED — near the middle of its historical range
      EXPENSIVE     — near the upper third of its historical range

    Args:
        symbol:     Ticker, e.g. "VCB", "FPT".
        years_back: Years of ratio history to compare against (default 3).
        source:     Data source override.

    Returns:
        Dict with signal, PE and PB percentile positions, historical ranges,
        and a plain-language summary.
    """
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios

    try:
        ratios_all = get_financial_ratios(symbol, period="year", source=source or config.SOURCE_FINANCE)
    except Exception as e:
        return {"symbol": symbol, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch ratio data."}

    if not ratios_all:
        return {"symbol": symbol, "signal": "UNKNOWN", "summary": "No ratio data available."}

    history = ratios_all[-years_back:] if len(ratios_all) >= years_back else ratios_all

    def _metric(keys):
        vals = []
        for row in history:
            for k in keys:
                v = _safe_float(row.get(k))
                if v and v > 0:
                    vals.append(v)
                    break
        if not vals:
            return None
        current = vals[-1]
        prior = vals[:-1] if len(vals) > 1 else vals
        avg = sum(prior) / len(prior)
        pct = sum(1 for v in prior if v < current) / len(prior) * 100 if prior else 50.0
        return {
            "current": round(current, 2),
            "avg_history": round(avg, 2),
            "min": round(min(vals), 2),
            "max": round(max(vals), 2),
            "percentile": round(pct, 1),
            "vs_avg_pct": round((current - avg) / avg * 100, 1) if avg else None,
        }

    pe_data = _metric(["pe", "price_to_earning", "p_e"])
    pb_data = _metric(["pb", "price_to_book", "p_b"])

    def _to_signal(pct):
        if pct is None:
            return "UNKNOWN"
        return "CHEAP" if pct <= 33 else "EXPENSIVE" if pct >= 67 else "FAIRLY_VALUED"

    pe_sig = _to_signal(pe_data["percentile"] if pe_data else None)
    pb_sig = _to_signal(pb_data["percentile"] if pb_data else None)
    signal = pe_sig if pe_sig == pb_sig else pe_sig  # PE takes precedence

    if pe_data:
        cheaper_than = round(100 - pe_data["percentile"], 0)
        direction = "near" if abs(pe_data.get("vs_avg_pct") or 0) < 10 else (
            "above" if (pe_data.get("vs_avg_pct") or 0) > 0 else "below"
        )
        summary = (
            f"{symbol}'s current PE of {pe_data['current']} is {direction} its "
            f"{len(history)}-year average of {pe_data['avg_history']}, suggesting it is "
            f"{signal.replace('_', ' ').lower()}. "
            f"It is cheaper than {cheaper_than:.0f}% of its historical PE readings."
        )
    else:
        summary = f"Valuation history limited for {symbol}. Signal: {signal}."

    return {
        "symbol": symbol,
        "signal": signal,
        "summary": summary,
        "pe": pe_data,
        "pb": pb_data,
        "history_years": len(history),
        "note": "Percentile = % of past readings where ratio was lower than today. Lower = cheaper vs own history.",
    }


# ── B. Buy/Sell Signals ────────────────────────────────────────────────────

def check_price_signal(
    symbol: str,
    lookback_days: int = 60,
    source: Optional[str] = None,
) -> dict:
    """
    Generate a simple buy/sell signal from recent price and volume patterns.

    Checks 3 signals:
      1. Trend    — is the 10-day average above the 30-day average?
      2. Momentum — is the price higher than 5 trading days ago?
      3. Volume   — is recent volume at least 20% above the 20-day average?

    Signal logic:
      BUY   — 2+ bullish signals with an uptrend
      SELL  — 2+ bearish signals with a downtrend
      WATCH — mixed signals leaning positive
      HOLD  — mixed or inconclusive

    Args:
        symbol:        Ticker, e.g. "VCB", "HPG".
        lookback_days: Days of price history to use (default 60).
        source:        Data source override.

    Returns:
        Dict with signal, confidence ("2/3 signals positive"), per-signal
        details, breakout flag, and a plain-language summary.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    try:
        prices = get_stock_price(symbol, length="3M", interval="1D", source=source or config.SOURCE_QUOTE)
    except Exception as e:
        return {"symbol": symbol, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch price data."}

    if len(prices) < 30:
        return {"symbol": symbol, "signal": "UNKNOWN", "summary": f"Need at least 30 days of data (got {len(prices)})."}

    closes = [_safe_float(p.get("close")) for p in prices if p.get("close") is not None]
    volumes = [_safe_float(p.get("volume")) for p in prices if p.get("volume") is not None]

    if len(closes) < 30:
        return {"symbol": symbol, "signal": "UNKNOWN", "summary": "Insufficient close price data."}

    current_price = closes[-1]
    avg_10d = sum(closes[-10:]) / 10
    avg_30d = sum(closes[-30:]) / 30
    price_5d_ago = closes[-6] if len(closes) >= 6 else closes[0]
    momentum_pct = (current_price - price_5d_ago) / price_5d_ago * 100

    sigs = {}

    # Signal 1: Trend
    trend_bull = avg_10d > avg_30d
    sigs["trend"] = {
        "bullish": trend_bull,
        "detail": f"10-day avg {avg_10d:,.0f} is {'above' if trend_bull else 'below'} 30-day avg {avg_30d:,.0f}",
    }

    # Signal 2: Momentum
    mom_bull = momentum_pct > 1.0
    sigs["momentum"] = {
        "bullish": mom_bull,
        "detail": f"Price {'up' if momentum_pct >= 0 else 'down'} {abs(momentum_pct):.1f}% over last 5 days",
    }

    # Signal 3: Volume
    if len(volumes) >= 20:
        avg_vol_5d = sum(volumes[-5:]) / 5
        avg_vol_20d = sum(volumes[-20:]) / 20
        vol_ratio = avg_vol_5d / avg_vol_20d if avg_vol_20d > 0 else None
        vol_bull = vol_ratio is not None and vol_ratio >= 1.2
        sigs["volume"] = {
            "bullish": vol_bull,
            "detail": f"Recent volume is {vol_ratio:.1f}x the 20-day average — {'confirms move' if vol_bull else 'no surge'}"
            if vol_ratio else "Volume ratio unavailable",
        }
    else:
        sigs["volume"] = {"bullish": None, "detail": "Insufficient volume data"}

    bullish = sum(1 for s in sigs.values() if s.get("bullish") is True)
    bearish = sum(1 for s in sigs.values() if s.get("bullish") is False)
    available = sum(1 for s in sigs.values() if s.get("bullish") is not None)

    if available == 0:
        signal = "UNKNOWN"
    elif bullish >= 2 and trend_bull:
        signal = "BUY"
    elif bearish >= 2 and not trend_bull:
        signal = "SELL"
    elif bullish > bearish:
        signal = "WATCH"
    else:
        signal = "HOLD"

    breakout_flag = current_price >= max(closes[-20:]) if len(closes) >= 20 else False

    summary = (
        f"{symbol} shows {bullish}/{available} bullish signals. "
        f"Trend is {'up' if trend_bull else 'down'}, price is "
        f"{'up' if momentum_pct >= 0 else 'down'} {abs(momentum_pct):.1f}% over 5 days."
        + (" New 20-day high — possible breakout." if breakout_flag else "")
    )

    return {
        "symbol": symbol,
        "signal": signal,
        "confidence": f"{bullish}/{available} signals positive",
        "summary": summary,
        "signals": sigs,
        "breakout_flag": breakout_flag,
        "price_now": current_price,
        "price_5d_ago": price_5d_ago,
        "pct_change_5d": round(momentum_pct, 2),
    }


def check_foreign_flow_signal(
    symbol: str,
    days: int = 30,
    source: Optional[str] = None,
) -> dict:
    """
    Summarise recent foreign investor buying/selling and assess whether
    it is a positive, neutral, or warning signal.

    Foreign investors are closely watched in Vietnam as an institutional
    flow indicator. Sustained selling can precede price declines.

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        symbol: Ticker, e.g. "VNM", "VIC".
        days:   Trading sessions to analyse (default 30).
        source: Data source override.

    Returns:
        Dict with signal (POSITIVE/NEUTRAL/CAUTION/WARNING), net VND billions,
        buy/sell day counts, recent trend direction, and a plain-language summary.
    """
    require_sponsored("check_foreign_flow_signal")
    from vnstock_mcp_advanced.tools.trading import get_foreign_trading

    start = _days_ago(days + 14)  # buffer for weekends / holidays
    try:
        records = get_foreign_trading(symbol, start=start, end=config.today(), source=source or config.SOURCE_TRADING)
    except Exception as e:
        return {"symbol": symbol, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch foreign trading data."}

    if not records:
        return {"symbol": symbol, "signal": "NEUTRAL", "summary": "No foreign trading data found for this period."}

    records = records[-days:]  # keep at most `days` sessions

    buy_days = sell_days = 0
    total_net = 0.0

    for r in records:
        net = _safe_float(
            r.get("foreign_net_value") or r.get("fr_net_value_total") or r.get("net_value") or 0
        )
        total_net += net or 0
        if net and net > 0:
            buy_days += 1
        elif net and net < 0:
            sell_days += 1

    net_bil = round(total_net / 1e9, 1)

    # Last-5-days trend
    recent_net = sum(
        _safe_float(r.get("foreign_net_value") or r.get("fr_net_value_total") or r.get("net_value") or 0)
        for r in records[-5:]
    )
    recent_bil = round(recent_net / 1e9, 1)

    if total_net > 0 and recent_net > 0:
        trend = "accelerating_buy" if recent_bil > abs(net_bil) * 0.25 else "steady_buy"
    elif total_net < 0 and recent_net < 0:
        trend = "accelerating_sell" if abs(recent_bil) > abs(net_bil) * 0.25 else "steady_sell"
    elif total_net > 0 and recent_net < 0:
        trend = "reversing_to_sell"
    elif total_net < 0 and recent_net > 0:
        trend = "reversing_to_buy"
    else:
        trend = "mixed"

    # Last 3 days direction
    last_3 = []
    for r in records[-3:]:
        nv = _safe_float(r.get("foreign_net_value") or r.get("fr_net_value_total") or r.get("net_value") or 0)
        last_3.append("buy" if nv > 0 else "sell" if nv < 0 else "neutral")

    if buy_days >= sell_days * 2 and net_bil > 0:
        signal = "POSITIVE"
    elif sell_days >= buy_days * 2 and net_bil < 0:
        signal = "WARNING"
    elif net_bil < 0 or trend in ("steady_sell", "accelerating_sell"):
        signal = "CAUTION"
    else:
        signal = "NEUTRAL"

    direction = "buying" if net_bil >= 0 else "selling"
    summary = (
        f"Foreign investors have been net {direction} {symbol} — "
        f"{buy_days} buy days vs {sell_days} sell days over {len(records)} sessions, "
        f"net {'+' if net_bil >= 0 else ''}{net_bil:.1f}B VND. "
        f"Last 5 days: {recent_bil:+.1f}B VND."
    )

    return {
        "symbol": symbol,
        "signal": signal,
        "summary": summary,
        "period_days": len(records),
        "net_value_bil_vnd": net_bil,
        "buy_days": buy_days,
        "sell_days": sell_days,
        "last_5d_net_value_bil_vnd": recent_bil,
        "trend": trend,
        "last_3d_direction": last_3[-1] if last_3 else None,
    }


# ── C. Dividend & Income ───────────────────────────────────────────────────

def get_dividend_history(
    symbol: str,
    years_back: int = 4,
    source: Optional[str] = None,
) -> dict:
    """
    Show dividend payment history — how much was paid per year, when, and
    whether payments are consistent. Also shows estimated yield at current price.

    Signals:
      INCOME_STOCK — paid every year AND yield >= 2%
      MODERATE     — paid most years or yield < 2%
      IRREGULAR    — paid less than half the years
      NO_DIVIDEND  — no cash dividends found

    Args:
        symbol:     Ticker, e.g. "REE", "VNM", "FPT".
        years_back: Years of history to include (default 4).
        source:     Data source override.

    Returns:
        Dict with signal, yield %, annual history table, upcoming dividend events,
        and a plain-language summary.
    """
    from vnstock_mcp_advanced.tools.company import get_company_events
    from vnstock_mcp_advanced.tools.trading import get_price_board

    try:
        all_events = get_company_events(symbol, source=source or config.SOURCE_COMPANY)
    except Exception as e:
        return {"symbol": symbol, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch company events."}

    cutoff_year = date.today().year - years_back
    today_str = config.today()
    div_kw = ["cash dividend", "cổ tức tiền mặt", "dividend", "cổ tức", "chi trả cổ tức"]

    div_events, upcoming = [], []

    for ev in all_events:
        ev_type = str(ev.get("event_type") or ev.get("type") or ev.get("event_name") or "").lower()
        ev_desc = str(ev.get("event_desc") or ev.get("description") or ev.get("title") or "").lower()
        ex_date = str(ev.get("ex_rights_date") or ev.get("ex_date") or ev.get("record_date") or ev.get("date") or "")
        amount_raw = _safe_float(
            ev.get("cash_dividend_ratio") or ev.get("dividend_amount") or ev.get("dividend") or ev.get("value")
        )

        if not any(kw in ev_type or kw in ev_desc for kw in div_kw):
            continue

        try:
            ev_year = int(ex_date[:4]) if len(ex_date) >= 4 else None
        except (ValueError, TypeError):
            ev_year = None

        if ev_year and ev_year < cutoff_year:
            continue

        # Convert ratio (e.g. 0.15 = 15% of 10,000 VND par) to VND per share
        if amount_raw and amount_raw < 10:
            amount_vnd = round(amount_raw * 10_000)
        elif amount_raw:
            amount_vnd = round(amount_raw)
        else:
            amount_vnd = None

        record = {
            "year": ev_year,
            "ex_date": ex_date,
            "amount_vnd_per_share": amount_vnd,
            "event_type": ev.get("event_type") or ev.get("type") or "cash_dividend",
            "status": ev.get("status") or "historical",
        }
        (upcoming if ex_date > today_str else div_events).append(record)

    # Group by year
    by_year: dict = defaultdict(list)
    for ev in div_events:
        if ev["year"]:
            by_year[ev["year"]].append(ev)

    annual_history = []
    for yr in sorted(by_year):
        payments = by_year[yr]
        total_vnd = sum(p["amount_vnd_per_share"] for p in payments if p["amount_vnd_per_share"]) or None
        annual_history.append({
            "year": yr,
            "total_vnd_per_share": total_vnd,
            "payments": len(payments),
            "ex_date": payments[-1]["ex_date"],
        })

    # Current price for yield
    current_price = None
    try:
        board = get_price_board([symbol], source=source or config.SOURCE_TRADING)
        if board:
            current_price = _safe_float(
                board[0].get("close") or board[0].get("last_price") or board[0].get("match_price")
            )
    except Exception:
        pass

    yearly_totals = [y["total_vnd_per_share"] for y in annual_history if y["total_vnd_per_share"]]
    avg_annual = round(sum(yearly_totals) / len(yearly_totals)) if yearly_totals else None
    yield_pct = round(avg_annual / current_price * 100, 2) if avg_annual and current_price else None

    years_paid = len(annual_history)
    if years_paid == 0:
        signal = "NO_DIVIDEND"
        consistency = "no_dividends"
    elif years_paid >= years_back:
        consistency = "paid_every_year"
        signal = "INCOME_STOCK" if (yield_pct or 0) >= 2.0 else "MODERATE"
    elif years_paid >= years_back // 2:
        consistency = "paid_most_years"
        signal = "MODERATE"
    else:
        consistency = "irregular"
        signal = "IRREGULAR"

    if signal == "NO_DIVIDEND":
        summary = f"{symbol} has not paid cash dividends in the last {years_back} years."
    elif signal == "INCOME_STOCK":
        summary = (
            f"{symbol} paid cash dividends every year for {years_paid} years, "
            f"averaging {avg_annual:,} VND/share. "
            f"Estimated yield at current price: {yield_pct:.1f}%."
        )
    else:
        summary = f"{symbol} paid dividends in {years_paid} of the last {years_back} years."

    return {
        "symbol": symbol,
        "signal": signal,
        "summary": summary,
        "dividend_yield_pct": yield_pct,
        "current_price": current_price,
        "avg_annual_dividend_vnd": avg_annual,
        "consistency": consistency,
        "years_analyzed": years_back,
        "history": annual_history,
        "upcoming_events": upcoming,
    }


def scan_dividend_stocks(
    index: str = "VN30",
    min_yield_pct: float = 2.0,
    limit: int = 20,
    source: Optional[str] = None,
) -> dict:
    """
    Scan an index for stocks that have paid cash dividends recently and
    offer at least a minimum dividend yield.

    Makes one batch price board call plus one events call per symbol scanned.
    Use `limit` to control the number of symbols checked (default 20).

    Args:
        index:         Index to scan — "VN30", "HNX30", "VNMID", "VN100".
        min_yield_pct: Minimum yield to include (default 2.0%).
        limit:         Max symbols to scan (default 20).
        source:        Data source override.

    Returns:
        Dict with signal (FOUND/NONE_FOUND), list of qualifying stocks sorted
        by yield descending, and a plain-language summary.
    """
    from vnstock_mcp_advanced.tools.listing import get_index_members
    from vnstock_mcp_advanced.tools.trading import get_price_board
    from vnstock_mcp_advanced.tools.company import get_company_events

    try:
        members = get_index_members(index=index, source=source or config.SOURCE_LISTING)
    except Exception as e:
        return {"index": index, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch index members."}

    symbols = [m.get("symbol") or m.get("ticker") or m.get("code") for m in members]
    symbols = [s for s in symbols if s][:limit]

    if not symbols:
        return {"index": index, "signal": "NONE_FOUND", "summary": "No symbols found in index."}

    # Batch price board
    prices_map: dict = {}
    try:
        for row in get_price_board(symbols=symbols, source=source or config.SOURCE_TRADING):
            sym = row.get("symbol") or row.get("ticker") or row.get("code")
            if sym:
                prices_map[sym] = _safe_float(
                    row.get("close") or row.get("last_price") or row.get("match_price")
                )
    except Exception:
        pass

    div_kw = ["cash dividend", "cổ tức tiền mặt", "dividend", "cổ tức"]
    cutoff_year = date.today().year - 2
    results = []

    for sym in symbols:
        try:
            events = get_company_events(sym, source=source or config.SOURCE_COMPANY)
        except Exception:
            continue

        latest_vnd = None
        paid_recently = False

        for ev in events:
            ev_type = str(ev.get("event_type") or ev.get("type") or "").lower()
            ev_desc = str(ev.get("event_desc") or ev.get("description") or "").lower()
            ex_date = str(ev.get("ex_rights_date") or ev.get("ex_date") or ev.get("date") or "")
            amount_raw = _safe_float(
                ev.get("cash_dividend_ratio") or ev.get("dividend_amount") or ev.get("dividend")
            )

            if not any(kw in ev_type or kw in ev_desc for kw in div_kw):
                continue
            try:
                ev_year = int(ex_date[:4]) if len(ex_date) >= 4 else None
            except (ValueError, TypeError):
                ev_year = None

            if ev_year and ev_year >= cutoff_year:
                paid_recently = True
                if amount_raw:
                    vnd = round(amount_raw * 10_000 if amount_raw < 10 else amount_raw)
                    if latest_vnd is None or vnd > latest_vnd:
                        latest_vnd = vnd

        if not paid_recently or not latest_vnd:
            continue

        price = prices_map.get(sym)
        if not price:
            continue

        yield_pct = round(latest_vnd / price * 100, 2)
        if yield_pct >= min_yield_pct:
            results.append({"symbol": sym, "yield_pct": yield_pct, "last_div_vnd": latest_vnd, "price": price})

    results.sort(key=lambda x: x["yield_pct"], reverse=True)
    signal = "FOUND" if results else "NONE_FOUND"

    if results:
        top = results[0]
        summary = (
            f"Found {len(results)} stocks in {index} with yield above {min_yield_pct}% "
            f"that paid dividends in the last 2 years. "
            f"Top: {top['symbol']} at {top['yield_pct']:.1f}%."
        )
    else:
        summary = f"No stocks in {index} found with dividend yield above {min_yield_pct}%."

    return {
        "index": index,
        "min_yield_pct": min_yield_pct,
        "scan_date": config.today(),
        "signal": signal,
        "summary": summary,
        "results": results,
        "count": len(results),
        "symbols_scanned": len(symbols),
    }


# ── D. Risk Warnings ───────────────────────────────────────────────────────

def check_risk_flags(
    symbol: str,
    source: Optional[str] = None,
) -> dict:
    """
    Check 6 common risk warning signs before buying or holding a stock.

    Flags:
      1. price_drawdown      — stock is down 20%+ from its 52-week high
      2. valuation_stretch   — PE above 30 (expensive)
      3. debt_load           — Debt/Equity above 3.0
      4. dilution_risk       — capital raised in the last 12 months
      5. upcoming_rights     — rights issue or stock dividend in the next 30 days
      6. negative_profit_trend — net profit declined 2 consecutive years

    Signal: LOW_RISK (0 flags), MODERATE_RISK (1-2), HIGH_RISK (3+).

    Args:
        symbol: Ticker, e.g. "NVL", "VCB".
        source: Data source override.

    Returns:
        Dict with signal, flag count, per-flag details with pass/fail, and summary.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios, get_financial_statements
    from vnstock_mcp_advanced.tools.company import get_company_events, get_capital_history

    flags: dict = {}

    # Fetch all data (graceful on failure)
    closes: list = []
    try:
        prices = get_stock_price(symbol, length="1Y", interval="1D", source=source or config.SOURCE_QUOTE)
        closes = [_safe_float(p.get("close")) for p in prices if p.get("close") is not None]
    except Exception:
        pass

    ratios_all: list = []
    latest_ratio: dict = {}
    try:
        ratios_all = get_financial_ratios(symbol, period="year", source=source or config.SOURCE_FINANCE)
        if ratios_all:
            latest_ratio = ratios_all[-1]
    except Exception:
        pass

    events: list = []
    try:
        events = get_company_events(symbol, source=source or config.SOURCE_COMPANY)
    except Exception:
        pass

    cap_history: list = []
    try:
        cap_history = get_capital_history(symbol, source=source or config.SOURCE_COMPANY)
    except Exception:
        pass

    income: list = []
    try:
        income = get_financial_statements(symbol, statement="income", period="year", source=source or config.SOURCE_FINANCE)
    except Exception:
        pass

    # Flag 1 — Price drawdown > 20% from 52-week high
    if closes:
        current = closes[-1]
        high52 = max(closes)
        dd_pct = (current - high52) / high52 * 100
        triggered = dd_pct <= -20
        flags["price_drawdown"] = {
            "triggered": triggered,
            "detail": f"Price {current:,.0f} is {abs(dd_pct):.1f}% below 52-week high {high52:,.0f}"
            if triggered else f"Price is only {abs(dd_pct):.1f}% below 52-week high — no major drawdown",
        }
    else:
        flags["price_drawdown"] = {"triggered": False, "detail": "Price data unavailable"}

    # Flag 2 — Stretched valuation: PE > 30
    pe = _safe_float(latest_ratio.get("pe") or latest_ratio.get("price_to_earning"))
    if pe and pe > 0:
        triggered = pe > 30
        flags["valuation_stretch"] = {
            "triggered": triggered,
            "detail": f"PE {pe:.1f} — {'above 30, stretched valuation' if triggered else 'not stretched'}",
        }
    else:
        flags["valuation_stretch"] = {"triggered": False, "detail": "PE unavailable or negative"}

    # Flag 3 — High debt: Debt/Equity > 3.0
    de = _safe_float(
        latest_ratio.get("debt_on_equity") or latest_ratio.get("debt_equity") or latest_ratio.get("de_ratio")
    )
    if de is not None:
        triggered = de > 3.0
        flags["debt_load"] = {
            "triggered": triggered,
            "detail": f"Debt/Equity {de:.2f} — {'above 3.0 threshold' if triggered else 'within acceptable range'}",
        }
    else:
        flags["debt_load"] = {"triggered": False, "detail": "Debt/Equity data unavailable"}

    # Flag 4 — Recent capital raise (dilution)
    one_year_ago = _days_ago(365)
    recent_raises = [
        ch for ch in cap_history
        if str(ch.get("date") or ch.get("issue_date") or ch.get("record_date") or "") >= one_year_ago
    ]
    triggered = len(recent_raises) > 0
    flags["dilution_risk"] = {
        "triggered": triggered,
        "detail": f"Capital raised {len(recent_raises)} time(s) in the last 12 months — share dilution possible"
        if triggered else "No capital raise detected in the last 12 months",
    }

    # Flag 5 — Upcoming rights issue or stock dividend within 30 days
    today_str = config.today()
    in_30d = (date.today() + timedelta(days=30)).isoformat()
    rights_kw = ["rights issue", "phát hành", "stock dividend", "cổ tức cổ phiếu", "quyền mua"]
    upcoming = [
        ev for ev in events
        if today_str <= str(ev.get("ex_rights_date") or ev.get("ex_date") or ev.get("date") or "") <= in_30d
        and any(kw in str(ev.get("event_type") or ev.get("type") or "").lower() or
                kw in str(ev.get("event_desc") or ev.get("description") or "").lower()
                for kw in rights_kw)
    ]
    triggered = bool(upcoming)
    flags["upcoming_rights"] = {
        "triggered": triggered,
        "detail": "Rights issue or stock dividend ex-date within 30 days — price typically drops on ex-date"
        if triggered else "No rights issue or stock dividend ex-date within 30 days",
        "events": [{"date": str(ev.get("ex_rights_date") or ev.get("ex_date") or ""), "type": str(ev.get("event_type") or "")} for ev in upcoming],
    }

    # Flag 6 — Net profit declined 2 consecutive years
    profit_series = []
    for row in income:
        np_val = _safe_float(
            row.get("net_profit") or row.get("profit_after_tax") or
            row.get("net_income") or row.get("after_tax_profit")
        )
        yr = str(row.get("year") or row.get("period") or "")[:4]
        if np_val is not None and yr:
            profit_series.append((yr, np_val))
    profit_series.sort(key=lambda x: x[0])

    if len(profit_series) >= 3:
        last3 = profit_series[-3:]
        d1 = last3[1][1] < last3[0][1] if last3[0][1] != 0 else False
        d2 = last3[2][1] < last3[1][1] if last3[1][1] != 0 else False
        triggered = d1 and d2
        if triggered:
            p1 = (last3[1][1] - last3[0][1]) / abs(last3[0][1]) * 100
            p2 = (last3[2][1] - last3[1][1]) / abs(last3[1][1]) * 100
            detail = f"Net profit fell {abs(p1):.0f}% in {last3[1][0]} then {abs(p2):.0f}% in {last3[2][0]}"
        else:
            detail = "No consecutive profit declines detected"
        flags["negative_profit_trend"] = {"triggered": triggered, "detail": detail}
    else:
        flags["negative_profit_trend"] = {"triggered": False, "detail": "Insufficient history (need 3 years)"}

    # Score & signal
    n_triggered = sum(1 for f in flags.values() if f.get("triggered"))
    signal = "LOW_RISK" if n_triggered == 0 else "MODERATE_RISK" if n_triggered <= 2 else "HIGH_RISK"

    if n_triggered == 0:
        summary = f"{symbol} passes all 6 risk checks — no warnings detected."
    else:
        names = ", ".join(k.replace("_", " ") for k, v in flags.items() if v.get("triggered"))
        summary = f"{symbol} has {n_triggered} risk warning{'s' if n_triggered > 1 else ''}: {names}. Review before holding."

    return {
        "symbol": symbol,
        "signal": signal,
        "flags_triggered": n_triggered,
        "flags_total": len(flags),
        "summary": summary,
        "flags": flags,
    }


def check_volume_anomaly(
    symbol: str,
    lookback_days: int = 20,
    source: Optional[str] = None,
) -> dict:
    """
    Detect unusual trading volume that may signal breaking news, large
    institutional activity, or the start of a significant price move.

    Compares today's volume against the 20-day average:
      BUYING_SURGE     — 2x+ average volume AND price rising
      SELLING_PRESSURE — 2x+ average volume AND price falling
      UNUSUAL_VOLUME   — 2x+ average volume with no clear price direction
      QUIET            — volume below 50% of average
      NORMAL           — within normal range

    Args:
        symbol:        Ticker, e.g. "SSI", "VCB".
        lookback_days: Days used as the normal volume baseline (default 20).
        source:        Data source override.

    Returns:
        Dict with signal, volume multiple vs baseline, price change, and summary.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    try:
        prices = get_stock_price(symbol, length="1M", interval="1D", source=source or config.SOURCE_QUOTE)
    except Exception as e:
        return {"symbol": symbol, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch price data."}

    if len(prices) < lookback_days:
        return {"symbol": symbol, "signal": "UNKNOWN", "summary": f"Need {lookback_days} days of data (got {len(prices)})."}

    closes = [_safe_float(p.get("close")) for p in prices if p.get("close") is not None]
    volumes = [_safe_float(p.get("volume")) for p in prices if p.get("volume") is not None]

    if not closes or not volumes:
        return {"symbol": symbol, "signal": "UNKNOWN", "summary": "Price or volume data missing."}

    today_vol = volumes[-1]
    today_close = closes[-1]
    prev_close = closes[-2] if len(closes) >= 2 else closes[-1]
    price_chg_pct = (today_close - prev_close) / prev_close * 100 if prev_close else 0

    baseline = volumes[-lookback_days - 1:-1]
    avg_20d = sum(baseline) / len(baseline) if baseline else None
    vol_multiple = round(today_vol / avg_20d, 2) if avg_20d and avg_20d > 0 else None

    vols_5d = volumes[-6:-1] if len(volumes) >= 6 else volumes[:-1]
    avg_5d = sum(vols_5d) / len(vols_5d) if vols_5d else None
    vol_5d_multiple = round(avg_5d / avg_20d, 2) if avg_5d and avg_20d and avg_20d > 0 else None

    if vol_multiple is None:
        signal = "UNKNOWN"
    elif vol_multiple >= 2.0 and price_chg_pct > 1.5:
        signal = "BUYING_SURGE"
    elif vol_multiple >= 2.0 and price_chg_pct < -1.5:
        signal = "SELLING_PRESSURE"
    elif vol_multiple >= 2.0:
        signal = "UNUSUAL_VOLUME"
    elif vol_multiple < 0.5:
        signal = "QUIET"
    else:
        signal = "NORMAL"

    if signal == "BUYING_SURGE":
        summary = f"{symbol} volume is {vol_multiple:.1f}x normal, price up {price_chg_pct:.1f}% — buying surge detected."
    elif signal == "SELLING_PRESSURE":
        summary = f"{symbol} volume is {vol_multiple:.1f}x normal, price down {abs(price_chg_pct):.1f}% — selling pressure detected."
    elif signal == "UNUSUAL_VOLUME":
        summary = f"{symbol} volume is {vol_multiple:.1f}x normal with a small price move ({price_chg_pct:+.1f}%) — unusual activity."
    elif signal == "QUIET":
        summary = f"{symbol} is very quiet — volume is only {vol_multiple:.1f}x of normal today."
    else:
        summary = f"{symbol} volume today ({vol_multiple:.1f}x average) is within normal range."

    last_date = str(prices[-1].get("time") or prices[-1].get("date") or prices[-1].get("trading_date") or "")

    return {
        "symbol": symbol,
        "signal": signal,
        "summary": summary,
        "volume_today": int(today_vol) if today_vol else None,
        "volume_20d_avg": int(avg_20d) if avg_20d else None,
        "volume_multiple": vol_multiple,
        "volume_5d_multiple": vol_5d_multiple,
        "price_change_today_pct": round(price_chg_pct, 2),
        "baseline_days": lookback_days,
        "last_trading_date": last_date[:10] if last_date else None,
    }


# ── E. Portfolio Watchlist ─────────────────────────────────────────────────

def watchlist_snapshot(
    symbols: list[str],
    source: Optional[str] = None,
) -> dict:
    """
    Get a quick daily overview of all stocks on your watchlist — prices,
    daily change, foreign net flow, and key financial ratios in one call.

    One batch price board call + one ratio call per symbol.

    Args:
        symbols: List of tickers, e.g. ["VCB", "FPT", "HPG", "VNM", "MWG"].
        source:  Data source override.

    Returns:
        Dict with market_mood (MOSTLY_UP/MOSTLY_DOWN/MIXED), per-stock status
        with UP/DOWN/FLAT labels and optional flags, and a plain-language summary.
    """
    from vnstock_mcp_advanced.tools.trading import get_price_board
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios

    # Batch price board
    price_map: dict = {}
    try:
        for row in get_price_board(symbols=symbols, source=source or config.SOURCE_TRADING):
            sym = row.get("symbol") or row.get("ticker") or row.get("code")
            if sym:
                price_map[sym] = row
    except Exception:
        pass

    # Ratios per symbol
    ratio_map: dict = {}
    for sym in symbols:
        try:
            ratios = get_financial_ratios(sym, period="year", source=source or config.SOURCE_FINANCE)
            ratio_map[sym] = ratios[-1] if ratios else {}
        except Exception:
            ratio_map[sym] = {}

    stocks = []
    up_count = down_count = flat_count = 0
    top_gainer = {"symbol": None, "change_pct": -999.0}
    top_loser = {"symbol": None, "change_pct": 999.0}

    for sym in symbols:
        pb = price_map.get(sym, {})
        rt = ratio_map.get(sym, {})

        price = _safe_float(pb.get("close") or pb.get("last_price") or pb.get("match_price") or pb.get("price"))
        ref = _safe_float(pb.get("reference_price") or pb.get("ref_price") or pb.get("prev_close"))

        if price and ref and ref > 0:
            change_pct = round((price - ref) / ref * 100, 2)
        else:
            change_pct = _safe_float(pb.get("change_pct") or pb.get("price_change_pct") or pb.get("change_percent")) or 0.0

        if change_pct > 0.3:
            status, up_count = "UP", up_count + 1
        elif change_pct < -0.3:
            status, down_count = "DOWN", down_count + 1
        else:
            status, flat_count = "FLAT", flat_count + 1

        if change_pct > top_gainer["change_pct"]:
            top_gainer = {"symbol": sym, "change_pct": change_pct}
        if change_pct < top_loser["change_pct"]:
            top_loser = {"symbol": sym, "change_pct": change_pct}

        foreign_net = _safe_float(pb.get("foreign_net_value") or pb.get("fr_net_value") or pb.get("foreign_net"))
        foreign_net_bil = round(foreign_net / 1e9, 1) if foreign_net else None

        pe = _safe_float(rt.get("pe") or rt.get("price_to_earning"))
        roe = _roe_pct(rt.get("roe") or rt.get("return_on_equity"))

        flag = None
        if pe and pe > 30:
            flag = "HIGH_PE"
        elif change_pct < -5:
            flag = "BIG_DROP"
        elif foreign_net_bil and foreign_net_bil < -10:
            flag = "FOREIGN_SELLING"
        elif foreign_net_bil and foreign_net_bil > 10:
            flag = "FOREIGN_BUYING"

        stocks.append({
            "symbol": sym,
            "price": price,
            "change_pct": change_pct,
            "status": status,
            "foreign_net_today_bil": foreign_net_bil,
            "pe": pe,
            "roe_pct": roe,
            "flag": flag,
        })

    total = len(symbols)
    if up_count > down_count and up_count > flat_count:
        mood = "MOSTLY_UP"
    elif down_count > up_count and down_count > flat_count:
        mood = "MOSTLY_DOWN"
    else:
        mood = "MIXED"

    g = top_gainer
    l = top_loser
    gainer_str = f"{g['symbol']} +{g['change_pct']:.1f}%" if g["symbol"] else ""
    loser_str = f"{l['symbol']} {l['change_pct']:.1f}%" if l["symbol"] and l["change_pct"] < 0 else ""
    summary = (
        f"{up_count}/{total} stocks up today. "
        + (f"Top gainer: {gainer_str}. " if gainer_str else "")
        + (f"Biggest drop: {loser_str}." if loser_str else "")
    ).strip()

    return {
        "watchlist": symbols,
        "as_of": config.today(),
        "summary": summary,
        "market_mood": mood,
        "stocks": stocks,
        "up_count": up_count,
        "down_count": down_count,
        "flat_count": flat_count,
    }
