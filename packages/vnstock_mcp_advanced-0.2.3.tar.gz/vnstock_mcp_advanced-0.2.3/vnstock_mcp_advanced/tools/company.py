"""
Company tools — profile, shareholders, officers, events, news, subsidiaries.

All tools work on both free and sponsored tiers.
KBS-only methods are noted in their docstrings.
"""

from typing import Optional
from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records, to_serializable


def _company(symbol: str, source: str):
    if config.IS_SPONSORED:
        from vnstock_data import Company
    else:
        from vnstock import Company
    return Company(symbol=symbol, source=source)


def get_company_overview(
    symbol: str,
    source: Optional[str] = None,
) -> dict:
    """
    Get company profile — name, industry, founding year, charter capital,
    employee count, business description, CEO, and exchange listing.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source override ("kbs" or "vci").

    Returns:
        Dict with company profile fields.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    result = co.overview()
    if hasattr(result, "to_dict"):
        return result.iloc[0].to_dict() if len(result) > 0 else {}
    return to_serializable(result)


def get_shareholders(
    symbol: str,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get major shareholders and their ownership percentages.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source override.

    Returns:
        List of dicts with shareholder name, ownership %, and share count.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    return df_to_records(co.shareholders())


def get_company_officers(
    symbol: str,
    filter_by: str = "working",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get board members and executive officers.

    Args:
        symbol:    Ticker, e.g. "VCB".
        filter_by: "working" (current), "resigned", or "all".
        source:    Data source override.

    Returns:
        List of dicts with name, position, ownership %, and employment status.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    try:
        df = co.officers(filter_by=filter_by)
    except TypeError:
        df = co.officers()
    return df_to_records(df)


def get_company_events(
    symbol: str,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get corporate events — dividend announcements, rights issues, stock splits,
    AGM dates, and bond issuances.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source override.

    Returns:
        List of dicts with event type, ex-date, record date, and details.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    return df_to_records(co.events())


def get_company_news(
    symbol: str,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get recent news articles related to the company.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source override.

    Returns:
        List of dicts with title, publish_date, source, and URL.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    return df_to_records(co.news())


def get_subsidiaries(
    symbol: str,
    source: Optional[str] = None,
) -> dict:
    """
    Get subsidiary and affiliated company network.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Data source override.

    Returns:
        Dict with keys "subsidiaries" and "affiliates", each a list of dicts.
    """
    src = source or config.SOURCE_COMPANY
    co = _company(symbol, src)
    return {
        "subsidiaries": df_to_records(co.subsidiaries()),
        "affiliates": df_to_records(co.affiliate()),
    }


def get_capital_history(
    symbol: str,
    source: str = "kbs",
) -> list[dict]:
    """
    Get charter capital increase history (KBS source only).

    Shows when and how much the company raised capital over time —
    useful for tracking dilution risk.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Must be "kbs" (this method is only available on KBS).

    Returns:
        List of dicts with date, capital_before, capital_after, and reason.
    """
    co = _company(symbol, "kbs")
    return df_to_records(co.capital_history())


def get_insider_deals_company(
    symbol: str,
    source: str = "kbs",
) -> list[dict]:
    """
    Get insider trading records from the Company module (KBS source only).

    Complements get_insider_trading() from the Trading module with
    additional company-level context.

    Args:
        symbol: Ticker, e.g. "VCB".
        source: Must be "kbs".

    Returns:
        List of dicts with trader, position, action, volume, and date.
    """
    co = _company(symbol, "kbs")
    return df_to_records(co.insider_trading())
