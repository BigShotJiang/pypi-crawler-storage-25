"""
Commodity tools — gold, oil, and other commodity prices from ``vnstock_data``.

Covers SJC / DOJI gold benchmarks and global commodities. All tools require
sponsored tier.
"""

from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def get_gold_price(
    brand: str = "SJC",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> list[dict]:
    """
    Fetch Vietnamese gold price history from a retail benchmark.

    Args:
        brand: Gold brand — "SJC" or "DOJI". SJC is the most tracked benchmark.
        start: Start date "YYYY-MM-DD". Defaults to 3 months ago.
        end:   End date "YYYY-MM-DD". Defaults to today.

    Returns:
        List of dicts with ``time``, ``buy_price``, ``sell_price`` (VND per tael).
    """
    require_sponsored("get_gold_price")
    from vnstock_data import Commodity  # type: ignore

    start = start or config.three_months_ago()
    end = end or config.today()

    commodity = Commodity()
    fn = getattr(commodity, "gold", None) or getattr(commodity, "gold_price", None)
    if fn is None:
        return [{"error": "gold price method is not available in vnstock_data.Commodity."}]

    try:
        df = fn(brand=brand.upper(), start=start, end=end)
    except TypeError:
        try:
            df = fn(brand=brand.upper())
        except TypeError:
            df = fn()
    return df_to_records(df)


def get_commodity_prices(
    commodity: str = "crude_oil",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> list[dict]:
    """
    Fetch global commodity price history.

    Args:
        commodity: Commodity identifier — "crude_oil", "brent", "natural_gas",
                   "copper", "iron_ore", "rubber", "coffee", "rice".
        start:     Start date "YYYY-MM-DD". Defaults to 3 months ago.
        end:       End date "YYYY-MM-DD". Defaults to today.

    Returns:
        List of dicts with ``time`` and price columns in USD.
    """
    require_sponsored(f"get_commodity_prices({commodity})")
    from vnstock_data import Commodity  # type: ignore

    start = start or config.three_months_ago()
    end = end or config.today()

    c = Commodity()
    name = commodity.lower().strip()
    fn = getattr(c, name, None) or getattr(c, "commodity", None) or getattr(c, "price", None)
    if fn is None:
        return [{"error": f"Commodity '{commodity}' is not available in vnstock_data.Commodity."}]

    try:
        df = fn(start=start, end=end)
    except TypeError:
        try:
            df = fn(commodity=name, start=start, end=end)
        except TypeError:
            df = fn()
    return df_to_records(df)
