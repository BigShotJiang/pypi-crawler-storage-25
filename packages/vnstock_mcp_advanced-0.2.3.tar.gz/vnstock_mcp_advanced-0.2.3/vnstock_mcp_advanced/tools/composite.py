"""
Composite tools — high-value multi-call combinations that synthesize data
from multiple modules into actionable intelligence in a single tool call.
"""

from typing import Optional
from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records, to_serializable


def analyze_stock(symbol: str) -> dict:
    """
    One-shot comprehensive stock analysis combining price, fundamentals,
    company profile, recent events, and financial ratios.

    Makes 5 parallel data fetches for a complete investment brief:
    - Company overview (name, industry, CEO, description)
    - Last 1 year of daily prices
    - Latest annual financial ratios (PE, PB, ROE, ROA, EPS)
    - Last 3 years of annual income statement
    - Upcoming/recent corporate events (dividends, rights)

    Args:
        symbol: Ticker, e.g. "VCB", "ACB", "HPG".

    Returns:
        Dict with keys: overview, price_1y, ratios, income_statement, events.
    """
    from vnstock_mcp_advanced.tools.company import get_company_overview, get_company_events
    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios, get_financial_statements

    result: dict = {"symbol": symbol}

    try:
        result["overview"] = get_company_overview(symbol)
    except Exception as e:
        result["overview"] = {"error": str(e)}

    try:
        result["price_1y"] = get_stock_price(symbol, interval="1D")
    except Exception as e:
        result["price_1y"] = {"error": str(e)}

    try:
        result["ratios"] = get_financial_ratios(symbol, period="year")
    except Exception as e:
        result["ratios"] = {"error": str(e)}

    try:
        result["income_statement"] = get_financial_statements(symbol, statement="income", period="year")
    except Exception as e:
        result["income_statement"] = {"error": str(e)}

    try:
        result["events"] = get_company_events(symbol)
    except Exception as e:
        result["events"] = {"error": str(e)}

    return result


def compare_stocks(symbols: list[str], period: str = "year") -> list[dict]:
    """
    Compare financial ratios side-by-side for multiple stocks.

    Fetches the latest period's ratios for each symbol and returns them
    in a flat list — ideal for peer group comparison or sector screening.

    Args:
        symbols: List of tickers, e.g. ["VCB", "TCB", "ACB", "MBB"].
        period:  "year" or "quarter".

    Returns:
        List of dicts — one per symbol — with symbol name prepended to ratio fields.
        E.g. [{"symbol": "VCB", "pe": 12.3, "pb": 1.8, "roe": 0.18, ...}, ...]
    """
    from vnstock_mcp_advanced.tools.finance import get_financial_ratios

    results = []
    for sym in symbols:
        try:
            ratios = get_financial_ratios(sym, period=period)
            latest = ratios[-1] if ratios else {}
            latest["symbol"] = sym
            results.append(latest)
        except Exception as e:
            results.append({"symbol": sym, "error": str(e)})

    return results


def sector_heatmap(
    index: str = "VN30",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Get a real-time price board for all stocks in a given index or sector.

    Combines get_index_members() + get_price_board() to produce a sector-wide
    snapshot showing which stocks are up, down, and by how much.

    Args:
        index:  Index or group name — "VN30", "HNX30", "VNMID", "HOSE", etc.
        source: Data source override.

    Returns:
        List of dicts with symbol, last price, change %, volume, and value
        for every member of the index.
    """
    from vnstock_mcp_advanced.tools.listing import get_index_members
    from vnstock_mcp_advanced.tools.trading import get_price_board

    members = get_index_members(index=index, source=source)
    symbols = [m.get("symbol") or m.get("ticker") or m.get("code") for m in members]
    symbols = [s for s in symbols if s]

    if not symbols:
        return []

    return get_price_board(symbols=symbols, source=source)


def detect_insider_activity(
    symbol: str,
    lookback_days: int = 90,
) -> dict:
    """
    Cross-reference insider trading, proprietary trading, and foreign flows
    to detect smart money convergence — a high-conviction signal.

    Logic:
        - If all three signals are net positive → "ACCUMULATION" signal
        - If all three are net negative → "DISTRIBUTION" signal
        - Mixed → "MIXED" with breakdown

    Args:
        symbol:        Ticker, e.g. "VCB".
        lookback_days: How many days back to look (default 90).

    Returns:
        Dict with keys: signal ("ACCUMULATION"/"DISTRIBUTION"/"MIXED"),
        insider_net, prop_net, foreign_net, and raw records for each.
    """
    from datetime import date, timedelta
    start = (date.today() - timedelta(days=lookback_days)).isoformat()
    end = config.today()

    result: dict = {"symbol": symbol, "period": f"{start} to {end}"}

    # Foreign trading (sponsored)
    if config.IS_SPONSORED:
        from vnstock_mcp_advanced.tools.trading import get_foreign_trading, get_prop_trading, get_insider_trading

        try:
            foreign = get_foreign_trading(symbol, start=start, end=end)
            foreign_net = sum(
                r.get("foreign_net_volume") or r.get("net_volume") or 0
                for r in foreign
            )
            result["foreign_net_volume"] = foreign_net
            result["foreign_records"] = foreign
        except Exception as e:
            result["foreign_error"] = str(e)
            foreign_net = 0

        try:
            prop = get_prop_trading(symbol, start=start, end=end)
            prop_net = sum(
                r.get("prop_net_volume") or r.get("net_volume") or 0
                for r in prop
            )
            result["prop_net_volume"] = prop_net
            result["prop_records"] = prop
        except Exception as e:
            result["prop_error"] = str(e)
            prop_net = 0

        try:
            insider = get_insider_trading(symbol)
            result["insider_records"] = insider
            insider_net = sum(
                (r.get("volume") or 0) * (1 if str(r.get("action", "")).lower() in ("buy", "mua") else -1)
                for r in insider
            )
            result["insider_net_volume"] = insider_net
        except Exception as e:
            result["insider_error"] = str(e)
            insider_net = 0

        nets = {"foreign": foreign_net, "prop": prop_net, "insider": insider_net}
        positives = sum(1 for v in nets.values() if v > 0)
        negatives = sum(1 for v in nets.values() if v < 0)

        if positives == 3:
            result["signal"] = "ACCUMULATION"
        elif negatives == 3:
            result["signal"] = "DISTRIBUTION"
        else:
            result["signal"] = "MIXED"
            result["breakdown"] = {k: ("positive" if v > 0 else "negative" if v < 0 else "neutral") for k, v in nets.items()}
    else:
        # Free tier: only company-level insider data available
        from vnstock_mcp_advanced.tools.company import get_insider_deals_company
        try:
            insider = get_insider_deals_company(symbol)
            result["insider_records"] = insider
            result["note"] = "Foreign and prop trading signals require sponsored tier."
        except Exception as e:
            result["error"] = str(e)

    return result


def macro_market_overlay(
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> dict:
    """
    Combine VNINDEX price history with key macro indicators aligned on the same
    time axis — GDP growth, CPI, and USD/VND exchange rate (sponsored tier).

    Useful for understanding how macro cycles correspond to market performance.

    Args:
        start: Start date "YYYY-MM-DD". Defaults to 3 years ago.
        end:   End date "YYYY-MM-DD". Defaults to today.

    Returns:
        Dict with keys: vnindex_price, gdp, cpi, exchange_rate.
    """
    from datetime import date, timedelta
    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.tools.macro import get_macro_indicator, get_exchange_rate

    start = start or (date.today() - timedelta(days=3 * 365)).isoformat()
    end = end or config.today()

    result: dict = {}

    try:
        result["vnindex_price"] = get_stock_price("VNINDEX", start=start, end=end, interval="1W")
    except Exception as e:
        result["vnindex_error"] = str(e)

    try:
        result["gdp"] = get_macro_indicator("gdp", start=start, end=end, period="quarter")
    except Exception as e:
        result["gdp_error"] = str(e)

    try:
        result["cpi"] = get_macro_indicator("cpi", start=start, end=end, period="month")
    except Exception as e:
        result["cpi_error"] = str(e)

    try:
        result["exchange_rate"] = get_exchange_rate(start=start, end=end, period="month")
    except Exception as e:
        result["exchange_rate_error"] = str(e)

    return result
