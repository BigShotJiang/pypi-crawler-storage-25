"""
Screening tools — market breadth and setup detection for near-term forecasting.

These tools scan broad market data to answer:
  - Is the current rally/decline broad or narrow?
  - Which stocks are coiling before a potential breakout?
  - Which stocks show both volume spike AND foreign buying simultaneously?

All tools require sponsored tier (Bronze/Silver/Golden).
"""

from typing import Optional
from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def get_market_breadth(
    index: str = "VNINDEX",
    source: Optional[str] = None,
) -> dict:
    """
    Measure whether the current market move is driven by most stocks
    or just a handful of large-caps — a key indicator of rally sustainability.

    A broad rally (many stocks advancing) is healthier and more likely to
    continue than a narrow rally driven by only 5-10 index heavyweights.

    Signals:
      BROAD RALLY   — 2x+ as many advancing as declining, plus ceiling hitters
      ADVANCING     — more stocks up than down: healthy market
      MIXED         — near-equal advancing and declining: wait for clarity
      DECLINING     — more stocks falling than rising: defensive posture
      BROAD SELLOFF — widespread declines with floor hitters: high-risk environment

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        index:  Index to measure — "VNINDEX", "HNX", "VN30", "UPCOM".
        source: Data source override.

    Returns:
        Dict with signal, advancing/declining/unchanged counts, A/D ratio,
        ceiling/floor hitter counts, volume distribution, and a plain-language summary.
    """
    require_sponsored("get_market_breadth")
    from vnstock_mcp_advanced.tools.listing import get_index_members
    from vnstock_mcp_advanced.tools.trading import get_price_board

    src = source or config.SOURCE_TRADING

    # Get index members
    try:
        members = get_index_members(index=index, source=source or config.SOURCE_LISTING)
        symbols = [m.get("symbol") or m.get("ticker") or m.get("code") for m in members]
        symbols = [s for s in symbols if s]
    except Exception as e:
        return {"index": index, "signal": "UNKNOWN", "error": str(e), "summary": "Could not load index members."}

    if not symbols:
        return {"index": index, "signal": "UNKNOWN", "summary": "No symbols found in index."}

    # Batch price board
    try:
        board = get_price_board(symbols=symbols, source=src)
    except Exception as e:
        return {"index": index, "signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch price board."}

    advancing = declining = unchanged = 0
    ceil_hitters = floor_hitters = 0
    advance_volume = decline_volume = 0.0
    total_volume = 0.0

    for row in board:
        price = _safe_float(row.get("match_price") or row.get("close") or row.get("last_price"))
        ref = _safe_float(row.get("reference_price") or row.get("ref_price") or row.get("prev_close"))
        vol = _safe_float(row.get("match_vol") or row.get("volume") or row.get("total_volume") or 0)

        # Compute change pct
        if price and ref and ref > 0:
            chg_pct = (price - ref) / ref * 100
        else:
            chg_pct = _safe_float(
                row.get("change_pct") or row.get("price_change_pct_1d") or row.get("percent_price_change") or 0
            )

        total_volume += vol or 0

        if chg_pct and chg_pct > 0.1:
            advancing += 1
            advance_volume += vol or 0
        elif chg_pct and chg_pct < -0.1:
            declining += 1
            decline_volume += vol or 0
        else:
            unchanged += 1

        # Ceiling/floor: HOSE ±7%, HNX ±10% — use 6.5% / -6.5% as safe threshold
        if chg_pct and chg_pct >= 6.5:
            ceil_hitters += 1
        elif chg_pct and chg_pct <= -6.5:
            floor_hitters += 1

    total_counted = advancing + declining + unchanged
    ad_ratio = round(advancing / max(declining, 1), 2)
    advance_vol_pct = round(advance_volume / max(total_volume, 1) * 100, 1)

    # Signal
    if ad_ratio >= 2.0 and ceil_hitters >= 3:
        signal = "BROAD RALLY"
    elif ad_ratio >= 1.5:
        signal = "ADVANCING"
    elif ad_ratio >= 0.67:
        signal = "MIXED"
    elif ad_ratio >= 0.5 and floor_hitters >= 3:
        signal = "BROAD SELLOFF"
    else:
        signal = "DECLINING"

    # Summary
    if signal == "BROAD RALLY":
        summary = (
            f"{advancing} stocks rising vs {declining} falling in {index} — a broad-based rally. "
            f"{advance_vol_pct:.0f}% of volume is in advancing stocks. "
            f"{ceil_hitters} stocks hit the daily ceiling price."
        )
    elif signal == "BROAD SELLOFF":
        summary = (
            f"{declining} stocks falling vs {advancing} rising in {index} — widespread selling. "
            f"{floor_hitters} stocks hit the daily floor price. High-risk environment."
        )
    elif signal in ("ADVANCING", "DECLINING"):
        direction = "rising" if signal == "ADVANCING" else "falling"
        summary = (
            f"{max(advancing, declining)} stocks {direction} vs {min(advancing, declining)} "
            f"in the other direction across {index}. "
            f"A/D ratio: {ad_ratio:.1f}."
        )
    else:
        summary = (
            f"{advancing} stocks rising and {declining} falling in {index} — market is mixed with no clear direction. "
            f"Wait for clearer breadth confirmation."
        )

    return {
        "as_of": config.today(),
        "index": index,
        "signal": signal,
        "summary": summary,
        "advancing": advancing,
        "declining": declining,
        "unchanged": unchanged,
        "total_symbols": total_counted,
        "ad_ratio": ad_ratio,
        "ad_spread": advancing - declining,
        "ceiling_hitters": ceil_hitters,
        "floor_hitters": floor_hitters,
        "advance_volume_pct": advance_vol_pct,
    }


def scan_breakout_setups(
    index: str = "VNINDEX",
    lookback_days: int = 15,
    limit: int = 10,
) -> dict:
    """
    Scan for stocks that are compressing into a tight price range with
    shrinking volume — the classic "coil" pattern that often precedes
    a significant breakout move in either direction.

    The most powerful setups combine tight range + volume dry-up +
    price close to a recent high (resistance just above).

    Setup signals per stock:
      COILING  — tight range + volume contracting + near 52-week high: highest quality
      BUILDING — tight range + volume contracting, not yet at resistance
      WATCH    — some compression but volume not yet contracting

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        index:         Market scope — "VNINDEX", "HNX", "VN30".
        lookback_days: Sessions used to measure price compression (default 15 = 3 weeks).
        limit:         Maximum setups to return (default 10).

    Returns:
        Dict with signal, list of setup stocks with compression metrics,
        and a plain-language summary of the best candidates.
    """
    require_sponsored("scan_breakout_setups")
    from vnstock_data import TopStock
    from vnstock_mcp_advanced.tools.quote import get_stock_price
    from vnstock_mcp_advanced.utils.serializer import df_to_records

    # Use top-value stocks as our screening universe (liquid names only)
    try:
        ts = TopStock()
        val_df = ts.value(index=index, limit=40)
        universe = df_to_records(val_df)
    except Exception as e:
        return {"signal": "UNKNOWN", "error": str(e), "summary": "Could not load stock universe."}

    candidates = []

    for row in universe:
        sym = row.get("symbol")
        if not sym:
            continue

        try:
            prices = get_stock_price(sym, length="2M", interval="1D")
        except Exception:
            continue

        closes = [_safe_float(p.get("close")) for p in prices if p.get("close")]
        highs = [_safe_float(p.get("high")) for p in prices if p.get("high")]
        lows = [_safe_float(p.get("low")) for p in prices if p.get("low")]
        volumes = [_safe_float(p.get("volume")) for p in prices if p.get("volume")]

        if len(closes) < lookback_days + 10:
            continue

        # Price compression over lookback window
        recent_closes = closes[-lookback_days:]
        recent_highs = highs[-lookback_days:] if highs else recent_closes
        recent_lows = lows[-lookback_days:] if lows else recent_closes

        max_high = max(h for h in recent_highs if h)
        min_low = min(l for l in recent_lows if l)
        avg_close = sum(recent_closes) / len(recent_closes)

        if not avg_close or avg_close == 0:
            continue

        compression_ratio = round((max_high - min_low) / avg_close, 4)

        # Volume dry-up: recent 5d avg vs prior 10d avg
        recent_vols = volumes[-5:] if len(volumes) >= 5 else []
        prior_vols = volumes[-lookback_days:-5] if len(volumes) >= lookback_days else []

        avg_vol_recent = sum(recent_vols) / len(recent_vols) if recent_vols else None
        avg_vol_prior = sum(prior_vols) / len(prior_vols) if prior_vols else None

        if avg_vol_prior and avg_vol_prior > 0:
            vol_ratio = round(avg_vol_recent / avg_vol_prior, 2) if avg_vol_recent else 1.0
            volume_dry_up = vol_ratio < 0.75
        else:
            vol_ratio = None
            volume_dry_up = False

        # Distance from 52-week high (using full history)
        high_52w = max(h for h in highs if h) if highs else max_high
        current_price = closes[-1]
        pct_below_52w_high = round((current_price - high_52w) / high_52w * 100, 2)

        # Classify setup
        is_compressed = compression_ratio <= 0.08
        near_resistance = abs(pct_below_52w_high) <= 8.0

        if is_compressed and volume_dry_up and near_resistance:
            setup_signal = "COILING"
        elif is_compressed and volume_dry_up:
            setup_signal = "BUILDING"
        elif is_compressed:
            setup_signal = "WATCH"
        else:
            continue  # Not compressed enough — skip

        reason = (
            f"{sym} traded in a {compression_ratio * 100:.1f}% range over {lookback_days} days"
            + (f" with volume at {vol_ratio:.0%} of normal (drying up)" if vol_ratio else "")
            + (f" — only {abs(pct_below_52w_high):.1f}% below 52-week high." if near_resistance else ".")
        )

        candidates.append({
            "symbol": sym,
            "last_price": current_price,
            "compression_ratio": compression_ratio,
            "volume_dry_up": volume_dry_up,
            "recent_vol_ratio": vol_ratio,
            "pct_below_52w_high": pct_below_52w_high,
            "signal": setup_signal,
            "reason": reason,
        })

    # Rank: COILING first, then BUILDING, then WATCH; within each by tightest compression
    priority = {"COILING": 0, "BUILDING": 1, "WATCH": 2}
    candidates.sort(key=lambda x: (priority.get(x["signal"], 3), x["compression_ratio"]))
    candidates = candidates[:limit]

    coiling = [c for c in candidates if c["signal"] == "COILING"]
    building = [c for c in candidates if c["signal"] == "BUILDING"]

    if coiling:
        top_names = ", ".join(c["symbol"] for c in coiling[:3])
        signal = f"{len(coiling)} COILING SETUP{'S' if len(coiling) > 1 else ''}: {top_names}"
        summary = (
            f"Found {len(coiling)} stock{'s' if len(coiling) > 1 else ''} in a tight coil with volume drying up near resistance — "
            f"watch {top_names} for a breakout trigger in the next few sessions."
        )
    elif building:
        top_names = ", ".join(c["symbol"] for c in building[:3])
        signal = f"{len(building)} BUILDING SETUP{'S' if len(building) > 1 else ''}: {top_names}"
        summary = (
            f"{len(building)} stock{'s' if len(building) > 1 else ''} are in accumulation phase with tight ranges and contracting volume. "
            f"Not yet at resistance: {top_names}."
        )
    elif candidates:
        signal = f"{len(candidates)} WATCH SETUPS"
        summary = f"{len(candidates)} stocks show some compression but volume has not yet contracted. Monitor {candidates[0]['symbol']} first."
    else:
        signal = "NO SETUPS FOUND"
        summary = f"No compression setups found in the top {len(universe)} most active {index} stocks today."

    return {
        "as_of": config.today(),
        "index": index,
        "lookback_days": lookback_days,
        "signal": signal,
        "summary": summary,
        "setups": candidates,
        "coiling_count": len(coiling),
        "building_count": len(building),
        "symbols_scanned": len(universe),
    }


def screen_quality_momentum(
    index: str = "VNINDEX",
    min_volume_spike_pct: float = 20.0,
    limit: int = 20,
    date: Optional[str] = None,
) -> dict:
    """
    Screen for stocks that have both a volume spike AND net foreign buying
    on the same day — a powerful convergence signal combining momentum
    (unusual activity) with institutional conviction (foreign accumulation).

    Three-tier scoring per stock:
      Score 3 — volume spike + today's foreign buy + multi-day foreign accumulation: STRONG SETUP
      Score 2 — volume spike + foreign buying (one of the two criteria confirmed): DEVELOPING
      Score 1 — only one signal present: WEAK

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        index:                Market scope — "VNINDEX", "HNX", "VN30".
        min_volume_spike_pct: Minimum % volume above 20-day avg to qualify (default 20%).
        limit:                Maximum stocks to scan from each source list (default 20).
        date:                 Date for foreign flow data "YYYY-MM-DD". Defaults to today.

    Returns:
        Dict with signal, list of qualifying stocks with setup score and details,
        and a plain-language summary of the strongest setups.
    """
    require_sponsored("screen_quality_momentum")
    from vnstock_data import TopStock
    from vnstock_mcp_advanced.tools.trading import get_foreign_trading
    from vnstock_mcp_advanced.utils.serializer import df_to_records

    query_date = date or config.today()

    # Step 1: Volume spike universe
    try:
        ts = TopStock()
        vol_df = ts.volume(index=index, limit=limit * 2)
        vol_records = df_to_records(vol_df)
    except Exception as e:
        return {"signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch volume spike data."}

    # Filter by min spike threshold
    vol_map = {}
    for r in vol_records:
        sym = r.get("symbol")
        spike = _safe_float(r.get("volume_spike_20d_pct") or r.get("deal_volume_spike_20d_pct"))
        if sym and spike and spike >= min_volume_spike_pct:
            vol_map[sym] = spike

    # Step 2: Foreign buying today
    try:
        fb_df = ts.foreign_buy(date=query_date, limit=limit * 2)
        fb_records = df_to_records(fb_df)
    except Exception as e:
        return {"signal": "UNKNOWN", "error": str(e), "summary": "Could not fetch foreign buying data."}

    fb_map = {
        r.get("symbol"): _safe_float(r.get("net_value") or 0)
        for r in fb_records if r.get("symbol")
    }

    # Step 3: Intersection — symbols with BOTH volume spike AND foreign buying
    intersection = set(vol_map.keys()) & set(fb_map.keys())

    setups = []

    for sym in intersection:
        score = 0
        criteria = []

        # Criterion 1: Volume spike present
        spike_pct = vol_map.get(sym) or 0
        if spike_pct >= min_volume_spike_pct:
            score += 1
            criteria.append(f"volume +{spike_pct:.0f}% above avg")

        # Criterion 2: Foreign buying today
        fb_val = fb_map.get(sym) or 0
        fb_bn = round(fb_val / 1e9, 2) if fb_val else 0
        if fb_val and fb_val > 0:
            score += 1
            criteria.append(f"foreign bought {fb_bn:.1f}B VND today")

        # Criterion 3: Multi-day foreign accumulation (last 5 sessions)
        multi_day_positive = False
        try:
            start = config.today()
            from datetime import date as dt, timedelta
            start_date = (dt.today() - timedelta(days=10)).isoformat()
            records = get_foreign_trading(sym, start=start_date, end=config.today())
            records = records[-5:]
            multi_day_net = sum(
                _safe_float(r.get("fr_net_value_total") or r.get("foreign_net_value") or 0)
                for r in records
            )
            multi_day_positive = multi_day_net > 0
            if multi_day_positive:
                score += 1
                criteria.append(f"5-day foreign net +{round(multi_day_net/1e9, 1):.1f}B VND")
        except Exception:
            pass

        if score >= 2:
            sig = "STRONG SETUP" if score == 3 else "DEVELOPING"
        else:
            sig = "WEAK"

        reason = f"{sym}: {'; '.join(criteria)}."

        setups.append({
            "symbol": sym,
            "volume_spike_pct": spike_pct,
            "foreign_net_today_bn_vnd": fb_bn,
            "multi_day_foreign_accumulation": multi_day_positive,
            "setup_score": score,
            "signal": sig,
            "reason": reason,
        })

    # Sort by score then volume spike
    setups.sort(key=lambda x: (-x["setup_score"], -x["volume_spike_pct"]))

    strong = [s for s in setups if s["signal"] == "STRONG SETUP"]
    developing = [s for s in setups if s["signal"] == "DEVELOPING"]

    if strong:
        top_names = ", ".join(s["symbol"] for s in strong[:3])
        signal = f"{len(strong)} STRONG SETUP{'S' if len(strong) > 1 else ''}: {top_names}"
        summary = (
            f"{len(strong)} stock{'s' if len(strong) > 1 else ''} show volume breakout confirmed by multi-day foreign accumulation. "
            f"Strongest setups: {top_names}. Institutional money is entering with conviction."
        )
    elif developing:
        top_names = ", ".join(s["symbol"] for s in developing[:3])
        signal = f"{len(developing)} DEVELOPING SETUP{'S' if len(developing) > 1 else ''}: {top_names}"
        summary = (
            f"{len(developing)} stock{'s' if len(developing) > 1 else ''} show volume spikes with today's foreign buying, "
            f"but multi-day accumulation is not yet confirmed. Watch: {top_names}."
        )
    else:
        signal = "NO STRONG SETUPS"
        summary = f"No stocks in {index} currently show both a volume spike ≥{min_volume_spike_pct:.0f}% and foreign buying confirmation today."

    return {
        "as_of": query_date,
        "index": index,
        "min_volume_spike_pct": min_volume_spike_pct,
        "signal": signal,
        "summary": summary,
        "setups": setups,
        "strong_count": len(strong),
        "developing_count": len(developing),
        "volume_spike_universe": len(vol_map),
        "foreign_buying_universe": len(fb_map),
    }
