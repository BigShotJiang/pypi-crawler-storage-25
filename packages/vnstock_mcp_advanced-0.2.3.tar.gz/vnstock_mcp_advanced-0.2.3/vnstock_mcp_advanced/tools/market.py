"""
Market tools — market-wide valuation pulse and sector rotation pulse.

These two tools answer macro timing questions:
  - Is the overall market cheap or expensive vs its own recent history?
  - Which sectors are gaining or losing relative momentum right now?

Both tools require sponsored tier because they rely on ``vnstock_data``.
"""

from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored
from vnstock_mcp_advanced.utils.serializer import df_to_records


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _percentile_rank(values: list[float], target: float) -> float:
    """Return the percentile (0-1) of ``target`` within ``values``."""
    clean = [v for v in values if v is not None]
    if not clean:
        return 0.5
    below = sum(1 for v in clean if v <= target)
    return round(below / len(clean), 4)


# ══════════════════════════════════════════════════════════════════════════
# Tool 1 — get_market_valuation_pulse
# ══════════════════════════════════════════════════════════════════════════

def get_market_valuation_pulse(
    index: str = "VNINDEX",
    lookback_years: int = 3,
) -> dict:
    """
    Compare the current VNINDEX P/E and P/B against its own recent history
    to answer: "Is the market cheap or expensive right now?"

    Returns the current valuation multiples, their percentile rank vs the
    past ``lookback_years``, and the 30-day trend direction (getting more
    expensive or cheaper) so the user can tell whether now is a good time
    to commit fresh capital.

    Signals:
      CHEAP AND RECOVERING    — current P/E below 25th percentile, rising over 30d
      CHEAP                   — current P/E below 25th percentile, flat or falling
      FAIRLY VALUED           — P/E between 25th and 75th percentile
      EXPENSIVE AND COOLING   — P/E above 75th percentile, falling over 30d
      EXPENSIVE               — P/E above 75th percentile, flat or rising

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        index:          Index to measure — "VNINDEX" (default) or "HNX".
        lookback_years: Years of history used for the percentile baseline.

    Returns:
        Dict with signal, current P/E and P/B, percentile ranks, 30-day delta,
        min/median/max over the history, and a plain-language summary.
    """
    require_sponsored("get_market_valuation_pulse")
    from vnstock_data import Market  # type: ignore

    start_dt = date.today() - timedelta(days=lookback_years * 365)
    end_dt = date.today()

    market = Market()

    # Fetch historical PE / PB
    try:
        pe_df = market.pe(index=index, start=start_dt.isoformat(), end=end_dt.isoformat())
    except TypeError:
        try:
            pe_df = market.pe(index=index)
        except Exception as exc:
            return {
                "as_of": config.today(),
                "index": index,
                "signal": "UNKNOWN",
                "error": str(exc),
                "summary": "Could not fetch market P/E history.",
            }
    except Exception as exc:
        return {
            "as_of": config.today(),
            "index": index,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": "Could not fetch market P/E history.",
        }

    pe_records = df_to_records(pe_df)
    try:
        pb_df = market.pb(index=index, start=start_dt.isoformat(), end=end_dt.isoformat())
    except TypeError:
        try:
            pb_df = market.pb(index=index)
        except Exception:
            pb_df = None
    except Exception:
        pb_df = None
    pb_records = df_to_records(pb_df) if pb_df is not None else []

    # Extract the numeric series (column names vary — find a float column)
    def _extract_series(records: list[dict]) -> list[float]:
        if not records:
            return []
        # Find the column that holds the multiple itself (first numeric, non-time column)
        sample = records[-1]
        numeric_key = None
        for key, val in sample.items():
            if key and "time" in key.lower():
                continue
            if key and "date" in key.lower():
                continue
            if isinstance(val, (int, float)) and val is not None:
                numeric_key = key
                break
        if not numeric_key:
            return []
        return [_safe_float(r.get(numeric_key)) for r in records if r.get(numeric_key) is not None]

    pe_series = _extract_series(pe_records)
    pb_series = _extract_series(pb_records)

    if not pe_series:
        return {
            "as_of": config.today(),
            "index": index,
            "signal": "UNKNOWN",
            "summary": "No P/E history available for the requested index.",
        }

    current_pe = pe_series[-1]
    current_pb = pb_series[-1] if pb_series else None

    pe_min, pe_max = min(pe_series), max(pe_series)
    pe_sorted = sorted(pe_series)
    pe_median = pe_sorted[len(pe_sorted) // 2]
    pe_percentile = _percentile_rank(pe_series, current_pe)

    # 30-day direction
    pe_30d_ago = pe_series[-30] if len(pe_series) >= 30 else pe_series[0]
    pe_change_30d_pct = round((current_pe - pe_30d_ago) / pe_30d_ago * 100, 2) if pe_30d_ago else 0.0

    # Classification
    if pe_percentile <= 0.25:
        base = "CHEAP"
    elif pe_percentile >= 0.75:
        base = "EXPENSIVE"
    else:
        base = "FAIRLY VALUED"

    if base == "CHEAP" and pe_change_30d_pct > 1.0:
        signal = "CHEAP AND RECOVERING"
    elif base == "EXPENSIVE" and pe_change_30d_pct < -1.0:
        signal = "EXPENSIVE AND COOLING"
    else:
        signal = base

    # Summary
    summary_map = {
        "CHEAP AND RECOVERING": (
            f"{index} P/E {current_pe:.1f} is at the {pe_percentile * 100:.0f}th percentile of the last "
            f"{lookback_years} years and is trending up (+{pe_change_30d_pct:.1f}% in 30 days). "
            "Historically attractive entry with early signs of re-rating — favourable for adding exposure."
        ),
        "CHEAP": (
            f"{index} P/E {current_pe:.1f} is at the {pe_percentile * 100:.0f}th percentile of the last "
            f"{lookback_years} years — historically cheap. No upward momentum yet, so be patient."
        ),
        "FAIRLY VALUED": (
            f"{index} P/E {current_pe:.1f} is at the {pe_percentile * 100:.0f}th percentile — in line with "
            f"the {lookback_years}-year average. No valuation-based edge either way."
        ),
        "EXPENSIVE AND COOLING": (
            f"{index} P/E {current_pe:.1f} is at the {pe_percentile * 100:.0f}th percentile (rich) but has "
            f"rolled over ({pe_change_30d_pct:.1f}% in 30 days). A compression phase may be starting — be cautious with new longs."
        ),
        "EXPENSIVE": (
            f"{index} P/E {current_pe:.1f} is at the {pe_percentile * 100:.0f}th percentile of the last "
            f"{lookback_years} years — historically expensive. Consider trimming or raising cash."
        ),
    }

    return {
        "as_of": config.today(),
        "index": index,
        "signal": signal,
        "summary": summary_map[signal],
        "current_pe": round(current_pe, 2),
        "current_pb": round(current_pb, 2) if current_pb is not None else None,
        "pe_percentile": pe_percentile,
        "pe_30d_change_pct": pe_change_30d_pct,
        "pe_history": {
            "min": round(pe_min, 2),
            "median": round(pe_median, 2),
            "max": round(pe_max, 2),
            "sample_size": len(pe_series),
            "lookback_years": lookback_years,
        },
    }


# ══════════════════════════════════════════════════════════════════════════
# Tool 2 — get_sector_rotation
# ══════════════════════════════════════════════════════════════════════════

# ICB sector groups used for rotation analysis
_SECTOR_GROUPS = [
    "Financials",
    "Real Estate",
    "Technology",
    "Health Care",
    "Energy",
    "Consumer Staples",
    "Consumer Discretionary",
    "Basic Materials",
]


def get_sector_rotation(
    recent_days: int = 5,
    prior_days: int = 10,
) -> dict:
    """
    Compare the performance of the 8 main ICB sector groups between a recent
    window (last ``recent_days`` sessions) and a prior window (the ``prior_days``
    before that). Surfaces which sectors are gaining momentum (rotation in) and
    which are losing momentum (rotation out) — typically 1-2 weeks ahead of
    individual stock moves.

    Per-sector labels:
      ACCELERATING  — already leading and gaining further momentum
      ROTATING IN   — negative prior period, positive recent: early recovery
      FADING        — positive prior period, negative recent: early weakness
      ROTATING OUT  — already lagging and losing more ground

    Requires sponsored tier (Bronze/Silver/Golden).

    Args:
        recent_days: Most recent trading days to measure (default 5 = 1 week).
        prior_days:  The window before that for comparison (default 10 = 2 weeks).

    Returns:
        Dict with signal, per-sector ranked list with recent vs prior return,
        rotation labels, and a plain-language summary of the rotation map.
    """
    require_sponsored("get_sector_rotation")
    from vnstock_data import Market  # type: ignore

    try:
        market = Market()
    except Exception as exc:
        return {
            "as_of": config.today(),
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": "Could not initialise vnstock_data.Market.",
        }

    # Try to get sector performance directly if the API exposes it
    sector_records: list[dict] = []
    for method_name in ("sector_performance", "sector", "sector_index", "sectors"):
        fn = getattr(market, method_name, None)
        if callable(fn):
            try:
                df = fn()
                sector_records = df_to_records(df)
                if sector_records:
                    break
            except Exception:
                continue

    if not sector_records:
        # Fallback — rely on TopStock sector aggregation
        try:
            from vnstock_data import TopStock  # type: ignore
            ts = TopStock()
            for method_name in ("sector", "sectors", "by_sector"):
                fn = getattr(ts, method_name, None)
                if callable(fn):
                    try:
                        df = fn()
                        sector_records = df_to_records(df)
                        if sector_records:
                            break
                    except Exception:
                        continue
        except ImportError:
            pass

    if not sector_records:
        return {
            "as_of": config.today(),
            "signal": "UNKNOWN",
            "summary": "Sector performance data is not available in the current vnstock_data build.",
            "sectors": [],
        }

    # Normalise rows — find recent-return and prior-return columns
    rotations = []
    for row in sector_records:
        name = (
            row.get("sector")
            or row.get("sector_name")
            or row.get("industry")
            or row.get("icb")
            or row.get("name")
        )
        if not name:
            continue

        recent = _safe_float(
            row.get(f"return_{recent_days}d")
            or row.get("return_1w")
            or row.get("return_5d")
            or row.get("pct_1w")
            or row.get("change_1w")
        )
        prior = _safe_float(
            row.get(f"return_{recent_days + prior_days}d")
            or row.get("return_2w")
            or row.get("return_1m")
            or row.get("pct_1m")
            or row.get("change_1m")
        )

        if recent is None:
            continue
        if prior is None:
            prior = 0.0

        delta = recent - prior
        if recent > 0 and prior > 0 and delta > 0:
            label = "ACCELERATING"
        elif recent > 0 and prior <= 0:
            label = "ROTATING IN"
        elif recent <= 0 and prior > 0:
            label = "FADING"
        else:
            label = "ROTATING OUT"

        rotations.append({
            "sector": name,
            "recent_return_pct": round(recent, 2),
            "prior_return_pct": round(prior, 2),
            "momentum_delta_pct": round(delta, 2),
            "label": label,
        })

    if not rotations:
        return {
            "as_of": config.today(),
            "signal": "UNKNOWN",
            "summary": "Could not parse sector performance fields from the data source.",
            "sectors": [],
        }

    rotations.sort(key=lambda r: r["recent_return_pct"], reverse=True)

    accelerating = [r for r in rotations if r["label"] == "ACCELERATING"]
    rotating_in = [r for r in rotations if r["label"] == "ROTATING IN"]
    fading = [r for r in rotations if r["label"] == "FADING"]

    top_sector = rotations[0]
    bottom_sector = rotations[-1]

    if accelerating:
        signal = f"ACCELERATING: {accelerating[0]['sector']}"
        summary = (
            f"{accelerating[0]['sector']} is accelerating ({accelerating[0]['recent_return_pct']:+.1f}% recent vs "
            f"{accelerating[0]['prior_return_pct']:+.1f}% prior) — money is concentrating into strength. "
            f"Weakest sector: {bottom_sector['sector']} ({bottom_sector['recent_return_pct']:+.1f}%)."
        )
    elif rotating_in:
        names = ", ".join(r["sector"] for r in rotating_in[:3])
        signal = f"ROTATING IN: {rotating_in[0]['sector']}"
        summary = (
            f"Early rotation into {names} — these sectors swung from negative to positive over the last {recent_days} sessions. "
            f"Consider adding exposure ahead of the crowd."
        )
    elif fading:
        names = ", ".join(r["sector"] for r in fading[:3])
        signal = f"FADING: {fading[0]['sector']}"
        summary = (
            f"{names} are starting to fade — previously positive momentum has flipped negative. Consider trimming longs."
        )
    else:
        signal = f"ROTATING OUT: {bottom_sector['sector']}"
        summary = (
            f"No clear leaders — strongest sector {top_sector['sector']} only +{top_sector['recent_return_pct']:.1f}%. "
            f"Defensive posture preferred."
        )

    return {
        "as_of": config.today(),
        "signal": signal,
        "summary": summary,
        "sectors": rotations,
        "accelerating_count": len(accelerating),
        "rotating_in_count": len(rotating_in),
        "fading_count": len(fading),
        "recent_days": recent_days,
        "prior_days": prior_days,
    }
