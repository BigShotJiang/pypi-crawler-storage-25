"""
Professional technical tools — regime detection, multi-timeframe analysis,
Wyckoff phase identification, and liquidity depth for experienced traders.

This module provides four advanced analytical tools targeted at experienced
traders and portfolio managers who need deeper structural insight than simple
price/volume screens can offer:

  - volatility_regime_classifier: classify the current market regime using
    realized vol, vol-of-vol, autocorrelation, Hurst exponent, and ATR%.
  - multi_timeframe_confluence: scan a basket of stocks for signals that align
    across daily, weekly, and monthly timeframes.
  - wyckoff_phase_detector: identify Wyckoff accumulation / distribution phases
    by detecting Selling Climax, Automatic Rally, Secondary Test, Spring,
    Sign of Strength, and Upthrust events.
  - liquidity_depth_analyzer: walk the order book to estimate slippage, classify
    the intraday spread pattern, and recommend an execution strategy.

All tools are FREE tier — no sponsored gating required.
"""

from datetime import date, datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd

from vnstock_mcp_advanced import config


def _safe_float(value, default=None):
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


# ─────────────────────────────────────────────────────────────────────────────
# Volatility regime classifier
# ─────────────────────────────────────────────────────────────────────────────

def _hurst_exponent(series: np.ndarray) -> float:
    """
    Simplified R/S (rescaled-range) Hurst exponent estimator.

    Returns a value in [0, 1]:
      H > 0.5 → trending / persistent
      H < 0.5 → mean-reverting / anti-persistent
      H ≈ 0.5 → random walk
    """
    series = np.asarray(series, dtype=float)
    series = series[~np.isnan(series)]
    n = len(series)
    if n < 10:
        return 0.5

    lags = [2, 4, 8, min(16, n // 2)]
    lags = [lg for lg in lags if lg >= 2 and lg < n]
    if len(lags) < 2:
        return 0.5

    tau = []
    for lag in lags:
        diff = series[lag:] - series[:-lag]
        std = float(np.std(diff))
        tau.append(max(std, 1e-10))

    log_lags = np.log(lags)
    log_tau = np.log(tau)
    try:
        slope = float(np.polyfit(log_lags, log_tau, 1)[0])
    except (np.linalg.LinAlgError, ValueError):
        return 0.5
    return float(np.clip(slope, 0.0, 1.0))


def _length_for_days(days: int) -> str:
    """Pick the smallest length shortcut that covers the requested history."""
    if days <= 30:
        return "1M"
    if days <= 90:
        return "3M"
    if days <= 180:
        return "6M"
    if days <= 260:
        return "1Y"
    if days <= 520:
        return "2Y"
    return "5Y"


def volatility_regime_classifier(
    symbol: str = "VNINDEX",
    lookback_days: int = 252,
) -> dict:
    """
    Classify the current volatility regime of an index or stock.

    Computes five complementary metrics on daily log returns and combines them
    into a regime label. Knowing the regime is critical because different
    strategies work in different regimes — trend-following dies in
    mean-reverting markets, and mean-reversion gets steamrolled in trends.

    Metrics:
      - realized_vol_annualized: stdev(returns) * sqrt(252)
      - vol_of_vol:              stdev of rolling 5-day vol series
      - autocorrelation_lag1:    Pearson corr of returns vs 1-day lag
      - hurst_exponent:          simplified R/S exponent
      - atr_pct:                 ATR(14) / close

    Signals:
      TRENDING_LOW_VOL  — persistent trend with subdued volatility
      TRENDING_HIGH_VOL — persistent trend with elevated volatility
      MEAN_REVERTING    — anti-persistent, negative autocorrelation
      CRISIS            — extreme volatility regime with falling prices
      RANDOM_WALK       — no clear structure

    Args:
        symbol:        Ticker or index, e.g. "VNINDEX", "VCB" (default "VNINDEX").
        lookback_days: Trading days of history to analyse (default 252).

    Returns:
        Dict with signal (regime), summary, metrics dict, strategy implications
        dict (preferred strategies, position sizing, stop-loss style, notes),
        and as_of date.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    sym = symbol.upper()

    try:
        length = _length_for_days(int(lookback_days * 1.6) + 40)
        records = get_stock_price(sym, length=length, interval="1D")
    except Exception as exc:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": f"Could not fetch price history for {sym}.",
        }

    if not records:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": f"No price history available for {sym}.",
        }

    df = pd.DataFrame(records).tail(lookback_days + 40).reset_index(drop=True)
    if len(df) < 40:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": f"Insufficient history for {sym}: {len(df)} bars (need >= 40).",
        }

    try:
        close = df["close"].astype(float)
        high = df["high"].astype(float)
        low = df["low"].astype(float)
    except (KeyError, ValueError) as exc:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": f"Price data for {sym} is missing required OHLC columns.",
        }

    # Log returns
    returns = np.log(close / close.shift(1)).dropna()
    if len(returns) < 25:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": f"Insufficient return history for {sym} ({len(returns)} returns).",
        }

    # Rolling 20-day realised vol (annualised)
    rolling_vol = returns.rolling(20).std() * np.sqrt(252)
    last_rv = rolling_vol.iloc[-1]
    realized_vol = float(last_rv) if pd.notna(last_rv) else 0.0

    # Vol of vol
    rolling_vol_5 = returns.rolling(5).std() * np.sqrt(252)
    vov_series = rolling_vol_5.dropna()
    vol_of_vol = float(vov_series.std()) if len(vov_series) > 1 else 0.0

    # Autocorrelation lag-1 on last 20 returns
    last_returns = returns.tail(20)
    if len(last_returns) >= 3:
        try:
            autocorr = float(last_returns.autocorr(lag=1))
        except Exception:
            autocorr = 0.0
        if np.isnan(autocorr):
            autocorr = 0.0
    else:
        autocorr = 0.0

    # Hurst exponent on last 60 log-prices
    tail_close = close.tail(60).values
    log_close = np.log(tail_close[tail_close > 0]) if len(tail_close) else np.array([])
    hurst = _hurst_exponent(log_close)

    # ATR(14) and ATR%
    prev_close = close.shift(1)
    tr = pd.concat(
        [(high - low), (high - prev_close).abs(), (low - prev_close).abs()],
        axis=1,
    ).max(axis=1)
    atr = tr.rolling(14).mean()
    atr_last_val = atr.iloc[-1]
    atr_last = float(atr_last_val) if pd.notna(atr_last_val) else 0.0
    close_last = float(close.iloc[-1])
    atr_pct = atr_last / close_last if close_last > 0 else 0.0

    # Percentile rank context
    vol_clean = rolling_vol.dropna()
    vov_rank_series = rolling_vol_5.dropna().rolling(20).std().dropna()

    vol_pct_rank = float((vol_clean < realized_vol).mean()) if len(vol_clean) else 0.5
    vov_pct_rank = (
        float((vov_rank_series < vol_of_vol).mean())
        if len(vov_rank_series)
        else 0.5
    )

    recent_return = float(returns.tail(20).sum())

    # Regime classification
    if vol_pct_rank > 0.90 and vov_pct_rank > 0.80 and recent_return < 0:
        regime = "CRISIS"
    elif hurst > 0.55 and autocorr > 0.10 and vol_pct_rank < 0.50:
        regime = "TRENDING_LOW_VOL"
    elif hurst > 0.55 and autocorr > 0.10 and vol_pct_rank >= 0.50:
        regime = "TRENDING_HIGH_VOL"
    elif hurst < 0.45 and autocorr < -0.05:
        regime = "MEAN_REVERTING"
    else:
        regime = "RANDOM_WALK"

    strategy_implications = {
        "TRENDING_LOW_VOL": {
            "preferred_strategies": ["trend_following", "breakout", "momentum"],
            "position_sizing": "normal_to_aggressive",
            "stop_loss": "wide_trailing",
            "notes": "Ideal environment for systematic trend-following and pyramiding winners.",
        },
        "TRENDING_HIGH_VOL": {
            "preferred_strategies": ["momentum", "breakout_with_tight_stops"],
            "position_sizing": "reduced",
            "stop_loss": "tight_volatility_adjusted",
            "notes": "Trends are real but whipsaws are frequent — size down and respect stops.",
        },
        "MEAN_REVERTING": {
            "preferred_strategies": ["fade_extremes", "bollinger_reversion", "pairs_trading"],
            "position_sizing": "normal",
            "stop_loss": "structural_levels",
            "notes": "Counter-trend trades work. Avoid chasing breakouts — they typically fail.",
        },
        "CRISIS": {
            "preferred_strategies": ["cash", "hedges", "tail_risk_protection"],
            "position_sizing": "minimal",
            "stop_loss": "hard_stops",
            "notes": "Correlations converge to 1. Preserve capital — do not average down.",
        },
        "RANDOM_WALK": {
            "preferred_strategies": ["range_trading", "options_premium_selling"],
            "position_sizing": "normal",
            "stop_loss": "range_based",
            "notes": "No statistical edge in direction — focus on risk-defined strategies.",
        },
    }[regime]

    summary_map = {
        "TRENDING_LOW_VOL": (
            f"{sym} is in a TRENDING LOW-VOL regime (annualised vol {realized_vol * 100:.1f}%, "
            f"Hurst {hurst:.2f}) — favour trend-following and breakout strategies with wide trailing stops."
        ),
        "TRENDING_HIGH_VOL": (
            f"{sym} is trending but volatility is elevated ({realized_vol * 100:.1f}% annualised, "
            f"{vol_pct_rank * 100:.0f}th percentile) — size down and use tight volatility-adjusted stops."
        ),
        "MEAN_REVERTING": (
            f"{sym} is MEAN-REVERTING (Hurst {hurst:.2f}, autocorr {autocorr:+.2f}) — "
            f"fade extremes at Bollinger bands and avoid breakout entries."
        ),
        "CRISIS": (
            f"{sym} is in a CRISIS regime — vol at {vol_pct_rank * 100:.0f}th percentile and "
            f"20-day return {recent_return * 100:+.1f}%. Preserve capital and avoid averaging down."
        ),
        "RANDOM_WALK": (
            f"{sym} shows no clear structure (Hurst {hurst:.2f}, autocorr {autocorr:+.2f}) — "
            f"there is no directional edge. Use range-bound or risk-defined strategies."
        ),
    }
    summary = summary_map[regime]

    return {
        "as_of": config.today(),
        "symbol": sym,
        "signal": regime,
        "summary": summary,
        "regime": regime,
        "lookback_days": lookback_days,
        "bars_analyzed": int(len(df)),
        "metrics": {
            "realized_vol_annualized": round(realized_vol, 4),
            "vol_of_vol": round(vol_of_vol, 4),
            "autocorrelation_lag1": round(autocorr, 4),
            "hurst_exponent": round(hurst, 4),
            "atr_pct": round(atr_pct, 4),
            "vol_percentile_rank": round(vol_pct_rank, 4),
            "vov_percentile_rank": round(vov_pct_rank, 4),
            "recent_20d_return": round(recent_return, 4),
        },
        "strategy_implications": strategy_implications,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Multi-timeframe confluence
# ─────────────────────────────────────────────────────────────────────────────

def _rsi_last(close: pd.Series, period: int = 14) -> float:
    if len(close) < period + 1:
        return 50.0
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    last_loss = loss.iloc[-1]
    last_gain = gain.iloc[-1]
    if pd.isna(last_loss) or pd.isna(last_gain):
        return 50.0
    if last_loss == 0:
        return 100.0 if last_gain > 0 else 50.0
    rs = last_gain / last_loss
    return float(100 - (100 / (1 + rs)))


def _macd_state(close: pd.Series) -> tuple[str, float, float]:
    if len(close) < 26:
        return "NEUTRAL", 0.0, 0.0
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal_line = macd.ewm(span=9, adjust=False).mean()
    if len(macd) < 2:
        return "NEUTRAL", 0.0, 0.0
    curr_diff = float(macd.iloc[-1] - signal_line.iloc[-1])
    prev_diff = float(macd.iloc[-2] - signal_line.iloc[-2])
    macd_val = float(macd.iloc[-1])
    if curr_diff > 0 and prev_diff <= 0:
        state = "BULLISH_CROSSOVER"
    elif curr_diff < 0 and prev_diff >= 0:
        state = "BEARISH_CROSSOVER"
    elif macd_val > 0 and curr_diff > 0:
        state = "BULLISH_ABOVE_ZERO"
    elif macd_val < 0 and curr_diff < 0:
        state = "BEARISH_BELOW_ZERO"
    else:
        state = "NEUTRAL"
    return state, macd_val, curr_diff


def _analyze_timeframe(records: list) -> dict:
    """Compute trend / RSI / MACD / SMA checks for a single timeframe."""
    if not records or len(records) < 50:
        return {
            "available": False,
            "bars": len(records) if records else 0,
            "bullish_signals": 0,
            "bearish_signals": 0,
            "total_signals": 0,
        }

    df = pd.DataFrame(records)
    if "close" not in df.columns:
        return {
            "available": False,
            "bars": int(len(df)),
            "bullish_signals": 0,
            "bearish_signals": 0,
            "total_signals": 0,
        }

    close = pd.to_numeric(df["close"], errors="coerce").dropna()
    if len(close) < 50:
        return {
            "available": False,
            "bars": int(len(close)),
            "bullish_signals": 0,
            "bearish_signals": 0,
            "total_signals": 0,
        }

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()

    price = float(close.iloc[-1])
    sma20_last = float(sma20.iloc[-1]) if pd.notna(sma20.iloc[-1]) else price
    sma50_last = float(sma50.iloc[-1]) if pd.notna(sma50.iloc[-1]) else price

    trend_up = price > sma20_last and sma20_last > sma50_last
    trend_down = price < sma20_last and sma20_last < sma50_last

    rsi = _rsi_last(close, 14)
    rsi_bullish = 40 <= rsi <= 70
    rsi_bearish = rsi > 75 or rsi < 30

    macd_state_val, _, _ = _macd_state(close)
    macd_bullish = macd_state_val in ("BULLISH_CROSSOVER", "BULLISH_ABOVE_ZERO")
    macd_bearish = macd_state_val in ("BEARISH_CROSSOVER", "BEARISH_BELOW_ZERO")

    above_sma20 = price > sma20_last
    above_sma50 = price > sma50_last

    bullish = int(trend_up) + int(rsi_bullish) + int(macd_bullish) + int(above_sma20) + int(above_sma50)
    bearish = int(trend_down) + int(rsi_bearish) + int(macd_bearish) + int(not above_sma20) + int(not above_sma50)

    return {
        "available": True,
        "bars": int(len(close)),
        "price": round(price, 2),
        "sma20": round(sma20_last, 2),
        "sma50": round(sma50_last, 2),
        "rsi": round(rsi, 1),
        "macd_state": macd_state_val,
        "trend": "UP" if trend_up else ("DOWN" if trend_down else "SIDEWAYS"),
        "bullish_signals": bullish,
        "bearish_signals": bearish,
        "total_signals": 5,
    }


def multi_timeframe_confluence(
    symbols: list,
    signal_type: str = "ALL",
    min_confluence_score: float = 60.0,
) -> dict:
    """
    Scan stocks for trading signals that align across daily, weekly, and
    monthly timeframes — higher-timeframe alignment drives conviction.

    For every symbol the tool computes SMA20/SMA50 trend, RSI(14), MACD state,
    and price-vs-average checks on each of the three timeframes. A weighted
    confluence score blends the bullish and bearish ratios
    (daily 30% / weekly 40% / monthly 30%) and the result is classified as
    BULLISH_CONFLUENCE, BEARISH_CONFLUENCE, MIXED, or NO_SIGNAL.

    Signals (top-level):
      BULLISH_CONFLUENCE — best candidate has bullish score >= 60 and aligned trends
      BEARISH_CONFLUENCE — best candidate has bearish score >= 60 and aligned trends
      MIXED              — at least one candidate qualifies but direction is split
      NO_SIGNAL          — no symbol cleared the minimum confluence score

    Args:
        symbols:              List of tickers to scan (max 30 processed).
        signal_type:          Filter: "BULLISH", "BEARISH", or "ALL" (default).
        min_confluence_score: Minimum score (0-100) to include in results.

    Returns:
        Dict with top-level signal, summary, per-symbol confluence breakdown
        in `results` (sorted by score), counts scanned / found, and as_of date.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    if not symbols:
        return {
            "as_of": config.today(),
            "signal": "NO_SIGNAL",
            "summary": "No symbols provided — supply a non-empty list of tickers.",
            "results": [],
            "symbols_scanned": 0,
            "results_found": 0,
        }

    sym_list = [s.upper() for s in symbols[:30] if s]
    signal_type_norm = (signal_type or "ALL").upper()

    results: list[dict] = []

    for sym in sym_list:
        try:
            daily_records = get_stock_price(sym, length="3M", interval="1D")
        except Exception:
            daily_records = []
        try:
            weekly_records = get_stock_price(sym, length="1Y", interval="1W")
        except Exception:
            weekly_records = []
        try:
            monthly_records = get_stock_price(sym, length="2Y", interval="1M")
        except Exception:
            monthly_records = []

        daily = _analyze_timeframe(daily_records)
        weekly = _analyze_timeframe(weekly_records)
        monthly = _analyze_timeframe(monthly_records)

        def _ratio(tf: dict, bullish: bool) -> float:
            if not tf["available"] or tf["total_signals"] == 0:
                return 0.0
            if bullish:
                return tf["bullish_signals"] / tf["total_signals"]
            return tf["bearish_signals"] / tf["total_signals"]

        bullish_score = (
            _ratio(daily, True) * 0.30
            + _ratio(weekly, True) * 0.40
            + _ratio(monthly, True) * 0.30
        ) * 100

        bearish_score = (
            _ratio(daily, False) * 0.30
            + _ratio(weekly, False) * 0.40
            + _ratio(monthly, False) * 0.30
        ) * 100

        if bullish_score >= bearish_score:
            confluence_score = bullish_score
            if bullish_score >= 60:
                direction = "BULLISH"
            elif bullish_score >= 40:
                direction = "NO_SIGNAL"
            else:
                direction = "BEARISH"
        else:
            confluence_score = bearish_score
            direction = "BEARISH" if bearish_score >= 60 else "NO_SIGNAL"

        trends = [tf.get("trend") for tf in (daily, weekly, monthly) if tf.get("available")]
        up_count = trends.count("UP")
        down_count = trends.count("DOWN")
        if up_count == 3 or down_count == 3:
            actionability = "HIGH"
        elif up_count == 2 or down_count == 2:
            actionability = "MEDIUM"
        else:
            actionability = "LOW"

        results.append({
            "symbol": sym,
            "confluence_score": round(confluence_score, 2),
            "bullish_score": round(bullish_score, 2),
            "bearish_score": round(bearish_score, 2),
            "direction": direction,
            "actionability": actionability,
            "timeframes": {
                "daily": daily,
                "weekly": weekly,
                "monthly": monthly,
            },
        })

    # Filter
    filtered: list[dict] = []
    for r in results:
        if r["confluence_score"] < min_confluence_score:
            continue
        if signal_type_norm == "BULLISH" and r["direction"] != "BULLISH":
            continue
        if signal_type_norm == "BEARISH" and r["direction"] != "BEARISH":
            continue
        filtered.append(r)

    filtered.sort(key=lambda x: x["confluence_score"], reverse=True)

    # Headline signal from the top candidate (if any)
    if not filtered:
        signal = "NO_SIGNAL"
        summary = (
            f"No stocks in the {len(sym_list)}-symbol watchlist cleared the "
            f"{min_confluence_score:.0f}% confluence threshold — no high-conviction setups right now."
        )
    else:
        top = filtered[0]
        directions = [r["direction"] for r in filtered[:5]]
        bulls = directions.count("BULLISH")
        bears = directions.count("BEARISH")
        if top["direction"] == "BULLISH" and bulls >= bears:
            signal = "BULLISH_CONFLUENCE"
            top_names = ", ".join(r["symbol"] for r in filtered[:3] if r["direction"] == "BULLISH")
            summary = (
                f"{top['symbol']} shows BULLISH confluence across daily, weekly, and monthly "
                f"timeframes (score {top['confluence_score']:.0f}, {top['actionability']} actionability) — "
                f"high-conviction long setup. Other candidates: {top_names}."
            )
        elif top["direction"] == "BEARISH" and bears >= bulls:
            signal = "BEARISH_CONFLUENCE"
            top_names = ", ".join(r["symbol"] for r in filtered[:3] if r["direction"] == "BEARISH")
            summary = (
                f"{top['symbol']} shows BEARISH confluence across multiple timeframes "
                f"(score {top['confluence_score']:.0f}, {top['actionability']} actionability) — "
                f"avoid longs or consider defensive positioning. Other weak names: {top_names}."
            )
        else:
            signal = "MIXED"
            summary = (
                f"{len(filtered)} symbol(s) cleared the confluence threshold but direction is mixed "
                f"({bulls} bullish, {bears} bearish) — wait for cleaner alignment before committing capital."
            )

    return {
        "as_of": config.today(),
        "signal": signal,
        "summary": summary,
        "symbols_scanned": len(sym_list),
        "results_found": len(filtered),
        "filter": {
            "signal_type": signal_type_norm,
            "min_confluence_score": min_confluence_score,
        },
        "results": filtered,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Wyckoff phase detector
# ─────────────────────────────────────────────────────────────────────────────

_WYCKOFF_SENSITIVITY_THRESHOLDS = {
    "LOW": {
        "sc_vol_mult": 3.0, "st_vol_mult": 0.6, "spring_vol_mult": 0.4,
        "sos_vol_mult": 1.8, "upthrust_vol_mult": 1.8,
    },
    "MEDIUM": {
        "sc_vol_mult": 2.5, "st_vol_mult": 0.7, "spring_vol_mult": 0.5,
        "sos_vol_mult": 1.5, "upthrust_vol_mult": 1.5,
    },
    "HIGH": {
        "sc_vol_mult": 2.0, "st_vol_mult": 0.8, "spring_vol_mult": 0.6,
        "sos_vol_mult": 1.3, "upthrust_vol_mult": 1.3,
    },
}

_WYCKOFF_INTERPRETATIONS = {
    "ACCUMULATION_PHASE_A": "Selling climax marks a potential bottom. Wait for range to develop.",
    "ACCUMULATION_PHASE_B": "Range-bound accumulation in progress — smart money absorbing supply.",
    "ACCUMULATION_PHASE_C": "Spring test — often the last shakeout before markup. Key entry zone.",
    "ACCUMULATION_PHASE_D": "Sign of strength confirmed — markup phase imminent.",
    "MARKUP": "Uptrend in progress. Hold longs, buy pullbacks.",
    "DISTRIBUTION_PHASE_A": "Price reaching upper range — watch for an upthrust.",
    "DISTRIBUTION_PHASE_C": "Upthrust after distribution. High risk of markdown.",
    "MARKDOWN": "Downtrend in progress. Avoid or short.",
    "RANGE_BOUND": "No clear Wyckoff signature — stock is in transition.",
    "UNKNOWN": "Insufficient structural information.",
}


def _identify_trading_range(
    close: np.ndarray,
    high: np.ndarray,
    low: np.ndarray,
    window: int = 60,
) -> tuple:
    """Find support/resistance via price-density percentiles over recent window."""
    recent_window = min(window, len(close))
    if recent_window <= 0:
        last = float(close[-1]) if len(close) else 0.0
        return last, last

    prices = np.concatenate([
        high[-recent_window:],
        low[-recent_window:],
        close[-recent_window:],
    ])
    if len(prices) == 0:
        last = float(close[-1])
        return last, last

    support = float(np.percentile(prices, 15))
    resistance = float(np.percentile(prices, 85))
    return support, resistance


def wyckoff_phase_detector(
    symbol: str,
    lookback_days: int = 180,
    sensitivity: str = "MEDIUM",
) -> dict:
    """
    Classify a stock's current Wyckoff market phase.

    Applies Wyckoff methodology to classify price action into accumulation,
    markup, distribution, or markdown phases. The tool scans recent price/volume
    history for six key Wyckoff events, identifies the current trading range,
    computes an effort-vs-result signal, and estimates the probability of a
    markup within the next 30 days.

    Detected events:
      SELLING_CLIMAX   — extreme volume reversal bar at support
      AUTOMATIC_RALLY  — post-SC rally on declining volume
      SECONDARY_TEST   — retest of the SC low on reduced volume
      SPRING           — false breakdown below support (accumulation entry)
      SIGN_OF_STRENGTH — breakout above range on expanding volume
      UPTHRUST         — false breakout above resistance (distribution warning)

    Signals:
      ACCUMULATION_PHASE_A / B / C / D — stages of accumulation
      MARKUP              — uptrend confirmed after accumulation
      DISTRIBUTION_PHASE_A / C         — stages of distribution
      MARKDOWN            — downtrend in progress
      RANGE_BOUND         — no clear Wyckoff signature
      UNKNOWN             — insufficient data

    Args:
        symbol:        Stock ticker (e.g. "VCB").
        lookback_days: Days of daily OHLCV to analyse (default 180).
        sensitivity:   Event detection sensitivity — "LOW", "MEDIUM", or "HIGH".

    Returns:
        Dict with signal (phase), summary, trading_range, events_detected,
        effort_vs_result_signal, probability_markup_within_30d, interpretation,
        and as_of date.
    """
    from vnstock_mcp_advanced.tools.quote import get_stock_price

    sym = symbol.upper()
    sens = (sensitivity or "MEDIUM").upper()
    if sens not in _WYCKOFF_SENSITIVITY_THRESHOLDS:
        sens = "MEDIUM"
    thresholds = _WYCKOFF_SENSITIVITY_THRESHOLDS[sens]

    try:
        length = _length_for_days(lookback_days + 30)
        records = get_stock_price(sym, length=length, interval="1D")
    except Exception as exc:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": f"Could not fetch price history for {sym}.",
        }

    if not records or len(records) < 60:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": (
                f"Insufficient price history for {sym} "
                f"(need >= 60 bars, got {len(records) if records else 0})."
            ),
        }

    df = pd.DataFrame(records).tail(lookback_days).reset_index(drop=True)

    try:
        close = df["close"].astype(float).values
        high = df["high"].astype(float).values
        low = df["low"].astype(float).values
        volume = df["volume"].astype(float).values
    except (KeyError, ValueError) as exc:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": f"Price data for {sym} is missing required OHLCV columns.",
        }

    if len(close) < 60:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": f"Insufficient bars after cleaning for {sym}.",
        }

    vol_ma50 = pd.Series(volume).rolling(50, min_periods=20).mean().values
    price_spread = high - low

    support, resistance = _identify_trading_range(
        close, high, low, window=min(60, len(close))
    )
    midpoint = (support + resistance) / 2
    range_width = resistance - support

    scan_start = max(0, len(close) - 90)
    events: list[dict] = []

    def _bar_date(idx: int) -> str:
        if "time" in df.columns:
            try:
                return str(df["time"].iloc[idx])
            except Exception:
                return f"bar_{idx}"
        return f"bar_{idx}"

    # Selling Climax — highest-volume capitulation reversal bar
    sc_idx = None
    sc_vol = 0.0
    for i in range(scan_start, len(close)):
        if i <= 0 or np.isnan(vol_ma50[i]) or vol_ma50[i] <= 0:
            continue
        vol_mult = volume[i] / vol_ma50[i]
        is_down_bar = close[i] < close[i - 1]
        spread_window = price_spread[max(0, i - 20): i + 1]
        mean_spread = float(np.nanmean(spread_window)) if len(spread_window) else 0.0
        is_wide = price_spread[i] > mean_spread * 1.3 if mean_spread > 0 else False
        is_reversal = (
            close[i] > (low[i] + price_spread[i] * 0.4)
            if price_spread[i] > 0
            else False
        )

        if (
            vol_mult >= thresholds["sc_vol_mult"]
            and is_down_bar
            and is_wide
            and is_reversal
            and vol_mult > sc_vol
        ):
            sc_vol = vol_mult
            sc_idx = i

    if sc_idx is not None:
        events.append({
            "type": "SELLING_CLIMAX",
            "bar_index": int(sc_idx),
            "date": _bar_date(sc_idx),
            "price": round(float(close[sc_idx]), 2),
            "volume_multiplier": round(float(sc_vol), 2),
        })

    # Automatic Rally
    ar_idx = None
    if sc_idx is not None and sc_idx + 5 < len(close):
        post_sc = close[sc_idx + 1: min(sc_idx + 8, len(close))]
        sc_price = float(close[sc_idx])
        if len(post_sc) >= 3 and post_sc[-1] > sc_price:
            ar_idx = sc_idx + int(np.argmax(post_sc)) + 1
            gain_pct = (float(close[ar_idx]) / sc_price - 1) * 100 if sc_price > 0 else 0.0
            events.append({
                "type": "AUTOMATIC_RALLY",
                "bar_index": int(ar_idx),
                "date": _bar_date(ar_idx),
                "price": round(float(close[ar_idx]), 2),
                "gain_from_sc_pct": round(gain_pct, 2),
            })

    # Secondary Tests
    st_count = 0
    if sc_idx is not None and ar_idx is not None:
        sc_price = float(close[sc_idx])
        for i in range(ar_idx + 2, len(close)):
            if np.isnan(vol_ma50[i]) or vol_ma50[i] <= 0 or sc_vol <= 0:
                continue
            if low[i] <= sc_price * 1.03 and low[i] >= sc_price * 0.97:
                ratio = (volume[i] / vol_ma50[i]) / sc_vol
                if ratio < thresholds["st_vol_mult"]:
                    st_count += 1
                    events.append({
                        "type": "SECONDARY_TEST",
                        "bar_index": int(i),
                        "date": _bar_date(i),
                        "price": round(float(close[i]), 2),
                        "volume_ratio_vs_sc": round(float(ratio), 2),
                    })

    # Spring
    spring_idx = None
    for i in range(max(scan_start, 20), len(close)):
        if np.isnan(vol_ma50[i]) or vol_ma50[i] <= 0:
            continue
        broke_below = low[i] < support * 0.995
        closed_inside = close[i] > support
        low_vol = (volume[i] / vol_ma50[i]) < thresholds["spring_vol_mult"]
        if broke_below and closed_inside and low_vol:
            spring_idx = i
            events.append({
                "type": "SPRING",
                "bar_index": int(i),
                "date": _bar_date(i),
                "price": round(float(close[i]), 2),
                "low": round(float(low[i]), 2),
                "support": round(support, 2),
            })
            break

    # Sign of Strength
    sos_idx = None
    for i in range(max(scan_start, 20), len(close)):
        if np.isnan(vol_ma50[i]) or vol_ma50[i] <= 0:
            continue
        broke_above = close[i] > resistance * 1.005
        high_vol = (volume[i] / vol_ma50[i]) > thresholds["sos_vol_mult"]
        if broke_above and high_vol:
            sos_idx = i
            events.append({
                "type": "SIGN_OF_STRENGTH",
                "bar_index": int(i),
                "date": _bar_date(i),
                "price": round(float(close[i]), 2),
                "volume_multiplier": round(float(volume[i] / vol_ma50[i]), 2),
            })
            break

    # Upthrust
    upthrust_idx = None
    for i in range(max(scan_start, 20), len(close)):
        if np.isnan(vol_ma50[i]) or vol_ma50[i] <= 0:
            continue
        broke_above = high[i] > resistance * 1.005
        closed_inside = close[i] < resistance
        high_vol = (volume[i] / vol_ma50[i]) > thresholds["upthrust_vol_mult"]
        if broke_above and closed_inside and high_vol:
            upthrust_idx = i
            events.append({
                "type": "UPTHRUST",
                "bar_index": int(i),
                "date": _bar_date(i),
                "price": round(float(close[i]), 2),
                "high": round(float(high[i]), 2),
                "resistance": round(resistance, 2),
            })
            break

    # Phase classification
    current_price = float(close[-1])
    price_vs_range = (current_price - support) / range_width if range_width > 0 else 0.5

    if sos_idx is not None and current_price > resistance:
        phase = "MARKUP"
    elif upthrust_idx is not None and current_price < resistance:
        phase = "DISTRIBUTION_PHASE_C"
    elif spring_idx is not None:
        phase = "ACCUMULATION_PHASE_C"
    elif sos_idx is not None:
        phase = "ACCUMULATION_PHASE_D"
    elif st_count >= 2:
        phase = "ACCUMULATION_PHASE_B"
    elif sc_idx is not None:
        phase = "ACCUMULATION_PHASE_A"
    elif current_price < support and len(close) >= 20 and close[-1] < close[-20]:
        phase = "MARKDOWN"
    elif price_vs_range > 0.9:
        phase = "DISTRIBUTION_PHASE_A"
    elif price_vs_range < 0.1:
        phase = "ACCUMULATION_PHASE_A"
    else:
        phase = "RANGE_BOUND"

    # Effort vs Result
    er_windows = []
    for i in range(max(len(close) - 20, 5), len(close)):
        if i - 4 < 0:
            continue
        vol_5d = float(np.mean(volume[i - 4: i + 1]))
        spread_5d = float(np.mean(price_spread[i - 4: i + 1]))
        net_move = float(close[i] - close[i - 4])
        if spread_5d > 0:
            er_windows.append({
                "vol": vol_5d,
                "net_move": net_move,
                "effort_vs_result": vol_5d / (abs(net_move) + 1e-9),
            })

    effort_result_signal = "neutral"
    if er_windows:
        last_3 = er_windows[-3:]
        avg_move = float(np.mean([w["net_move"] for w in last_3]))
        avg_vol = float(np.mean([w["vol"] for w in last_3]))
        older_vol = (
            float(np.mean([w["vol"] for w in er_windows[:3]]))
            if len(er_windows) >= 6
            else avg_vol
        )
        if avg_move < 0 and avg_vol < older_vol * 0.85:
            effort_result_signal = "bullish_divergence_volume_drying_on_dips"
        elif avg_move > 0 and avg_vol > older_vol * 1.15:
            effort_result_signal = "bullish_confirmation_volume_expanding_on_ups"
        elif avg_move > 0 and avg_vol < older_vol * 0.85:
            effort_result_signal = "bearish_divergence_rally_on_low_volume"

    # Probability estimate
    prob_markup = 0.15
    if phase == "ACCUMULATION_PHASE_C":
        prob_markup = 0.70
    elif phase == "ACCUMULATION_PHASE_D":
        prob_markup = 0.80
    elif phase == "ACCUMULATION_PHASE_B":
        prob_markup = 0.45
    elif phase == "ACCUMULATION_PHASE_A":
        prob_markup = 0.30
    elif phase == "MARKUP":
        prob_markup = 0.85
    elif phase in ("DISTRIBUTION_PHASE_A", "DISTRIBUTION_PHASE_C"):
        prob_markup = 0.10
    elif phase == "MARKDOWN":
        prob_markup = 0.05

    if effort_result_signal.startswith("bullish"):
        prob_markup = min(1.0, prob_markup + 0.10)
    elif effort_result_signal.startswith("bearish"):
        prob_markup = max(0.0, prob_markup - 0.10)

    interpretation = _WYCKOFF_INTERPRETATIONS.get(phase, "Phase not recognized.")

    # Plain-language summary
    event_types = [e["type"] for e in events]
    event_str = ", ".join(event_types) if event_types else "no notable events"

    if phase == "ACCUMULATION_PHASE_C":
        summary = (
            f"{sym} is in ACCUMULATION PHASE C with a Spring detected — institutional buyers are "
            f"absorbing supply near support ({support:.2f}). Probability of markup within 30 days: "
            f"{prob_markup * 100:.0f}%. Events: {event_str}."
        )
    elif phase == "ACCUMULATION_PHASE_D":
        summary = (
            f"{sym} is in ACCUMULATION PHASE D — Sign of Strength confirmed above {resistance:.2f}. "
            f"Markup phase is imminent (prob {prob_markup * 100:.0f}%). Events: {event_str}."
        )
    elif phase in ("ACCUMULATION_PHASE_A", "ACCUMULATION_PHASE_B"):
        summary = (
            f"{sym} is in {phase.replace('_', ' ').title()} — {interpretation} "
            f"Events: {event_str}. Trading range: {support:.2f}–{resistance:.2f}."
        )
    elif phase == "MARKUP":
        summary = (
            f"{sym} is in MARKUP — uptrend is confirmed above resistance ({resistance:.2f}). "
            f"Hold longs and buy pullbacks. Events: {event_str}."
        )
    elif phase == "DISTRIBUTION_PHASE_A":
        summary = (
            f"{sym} is in DISTRIBUTION PHASE A — price is near the top of its range "
            f"({current_price:.2f} vs resistance {resistance:.2f}). Watch for an upthrust."
        )
    elif phase == "DISTRIBUTION_PHASE_C":
        summary = (
            f"{sym} is in DISTRIBUTION PHASE C with an Upthrust detected — high risk of markdown. "
            f"Events: {event_str}."
        )
    elif phase == "MARKDOWN":
        summary = (
            f"{sym} is in MARKDOWN — downtrend is underway below support ({support:.2f}). "
            f"Avoid longs or consider shorts."
        )
    else:
        summary = (
            f"{sym} shows no clear Wyckoff signature ({phase}) — stock is in transition. "
            f"Events detected: {event_str}."
        )

    return {
        "as_of": config.today(),
        "symbol": sym,
        "signal": phase,
        "summary": summary,
        "phase": phase,
        "lookback_days": lookback_days,
        "sensitivity": sens,
        "trading_range": {
            "support": round(support, 2),
            "resistance": round(resistance, 2),
            "midpoint": round(midpoint, 2),
            "width": round(range_width, 2),
        },
        "current_price": round(current_price, 2),
        "price_position_in_range_pct": round(price_vs_range * 100, 1),
        "events_detected": events,
        "event_count": len(events),
        "effort_vs_result_signal": effort_result_signal,
        "probability_markup_within_30d": round(prob_markup, 2),
        "interpretation": interpretation,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Liquidity depth analyzer
# ─────────────────────────────────────────────────────────────────────────────

def _extract_book_level(record: dict, side: str, level: int) -> tuple:
    """Extract (price, volume) for a given bid/ask level from a price_board row."""
    candidates_price = [
        f"{side}_{level}", f"{side}{level}", f"{side}_price_{level}",
        f"{side}_price{level}", f"match_{side}_{level}",
    ]
    candidates_vol = [
        f"{side}_vol_{level}", f"{side}_volume_{level}", f"{side}_vol{level}",
        f"{side}_volume{level}", f"{side}_{level}_vol", f"{side}{level}_vol",
    ]
    price = None
    vol = None
    for key in candidates_price:
        if key in record and record[key] is not None:
            val = _safe_float(record[key])
            if val is not None:
                price = val
                break
    for key in candidates_vol:
        if key in record and record[key] is not None:
            val = _safe_float(record[key])
            if val is not None:
                vol = val
                break
    return price or 0.0, vol or 0.0


def _walk_order_book(target_value: float, levels: list) -> tuple:
    """
    Walk a list of (price, volume) levels to fill target_value notional.
    Returns (vwap_fill_price, filled_value, fully_filled).
    """
    if target_value <= 0 or not levels:
        return 0.0, 0.0, False

    total_vol = 0.0
    total_notional = 0.0
    remaining = target_value

    for price, vol in levels:
        if price <= 0 or vol <= 0:
            continue
        level_value = price * vol
        take_value = min(remaining, level_value)
        take_vol = take_value / price
        total_vol += take_vol
        total_notional += take_vol * price
        remaining -= take_value
        if remaining <= 0:
            break

    filled_value = target_value - max(remaining, 0.0)
    fully_filled = remaining <= 0
    vwap = total_notional / total_vol if total_vol > 0 else 0.0
    return vwap, filled_value, fully_filled


def liquidity_depth_analyzer(
    symbol: str,
    target_order_value: float = 500_000_000,
    lookback_sessions: int = 5,
) -> dict:
    """
    Analyse the true liquidity and slippage profile of a Vietnamese stock.

    Pulls the current 3-level price board plus intraday tick history, computes
    spread and book imbalance, walks the asks to estimate slippage for the
    requested order, classifies the intraday spread pattern, identifies the
    best 15-minute execution window, and recommends an execution strategy.

    Signals:
      MARKET             — order is small relative to typical 15-min volume
      LIMIT              — place near the touch; expect same-session fill
      TWAP               — slice over multiple intraday windows
      VWAP_MULTI_SESSION — order too large for one session; spread over days
      UNKNOWN            — book data unavailable (likely market closed)

    Args:
        symbol:             Stock ticker (e.g. "VCB").
        target_order_value: Target order notional in VND (default 500,000,000).
        lookback_sessions:  Sessions of intraday history for pattern analysis.

    Returns:
        Dict with signal (execution strategy), summary, quote (best bid/ask,
        spread_bps), book_depth, slippage_estimate, intraday_profile,
        execution_recommendation, and as_of date.
    """
    from vnstock_mcp_advanced.tools.trading import get_price_board
    from vnstock_mcp_advanced.tools.quote import get_intraday_data

    sym = symbol.upper()

    try:
        board_records = get_price_board(symbols=[sym])
    except Exception as exc:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "error": str(exc),
            "summary": f"Could not fetch price board for {sym}.",
        }

    if not board_records:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": f"No price board data for {sym} — market may be closed.",
        }

    board = board_records[0] if board_records else {}

    bid_levels = []
    ask_levels = []
    for lv in (1, 2, 3):
        bp, bv = _extract_book_level(board, "bid", lv)
        ap, av = _extract_book_level(board, "ask", lv)
        if bp > 0 and bv > 0:
            bid_levels.append((bp, bv))
        if ap > 0 and av > 0:
            ask_levels.append((ap, av))

    if not bid_levels or not ask_levels:
        return {
            "as_of": config.today(),
            "symbol": sym,
            "signal": "UNKNOWN",
            "summary": (
                f"Order book for {sym} is unavailable or malformed — "
                "market may be closed."
            ),
            "raw_board_keys": list(board.keys())[:20] if isinstance(board, dict) else [],
        }

    best_bid = bid_levels[0][0]
    best_ask = ask_levels[0][0]
    midpoint = (best_bid + best_ask) / 2
    spread_bps = (best_ask - best_bid) / midpoint * 10000 if midpoint > 0 else 0.0

    bid_depth_total = sum(p * v for p, v in bid_levels)
    ask_depth_total = sum(p * v for p, v in ask_levels)
    total_depth = bid_depth_total + ask_depth_total
    book_imbalance = bid_depth_total / total_depth if total_depth > 0 else 0.5

    if book_imbalance > 0.55:
        imbalance_signal = "buying_pressure"
    elif book_imbalance < 0.45:
        imbalance_signal = "selling_pressure"
    else:
        imbalance_signal = "balanced"

    # Slippage — assume BUY (walk asks)
    vwap_fill, filled_value, fully_filled = _walk_order_book(target_order_value, ask_levels)
    if vwap_fill > 0 and midpoint > 0:
        slippage_bps = (vwap_fill - midpoint) / midpoint * 10000
    else:
        slippage_bps = None

    # Intraday profile
    intraday_pattern = "UNKNOWN"
    avg_spread_bps_hist = None
    best_window_info: Optional[dict] = None
    avg_15min_volume = 0.0

    try:
        intraday_records = get_intraday_data(sym)
    except Exception:
        intraday_records = []

    if isinstance(intraday_records, list) and intraday_records:
        try:
            tick_df = pd.DataFrame(intraday_records)
        except Exception:
            tick_df = pd.DataFrame()

        if not tick_df.empty:
            time_col = next(
                (c for c in ["time", "Time", "trading_time", "timestamp"] if c in tick_df.columns),
                None,
            )
            price_col = next(
                (c for c in ["price", "match_price", "Price", "close"] if c in tick_df.columns),
                None,
            )
            vol_col = next(
                (c for c in ["volume", "match_vol", "Volume", "vol"] if c in tick_df.columns),
                None,
            )

            if time_col and price_col and vol_col:
                try:
                    tick_df[time_col] = pd.to_datetime(tick_df[time_col], errors="coerce")
                    tick_df = tick_df.dropna(subset=[time_col])
                    tick_df[vol_col] = pd.to_numeric(tick_df[vol_col], errors="coerce").fillna(0)
                    tick_df[price_col] = pd.to_numeric(tick_df[price_col], errors="coerce")
                    tick_df["minute_bucket"] = tick_df[time_col].dt.floor("15min")

                    bucketed = tick_df.groupby("minute_bucket").agg(
                        volume=(vol_col, "sum"),
                        high=(price_col, "max"),
                        low=(price_col, "min"),
                        mid=(price_col, "mean"),
                    ).reset_index()
                    bucketed["spread_bps"] = (
                        (bucketed["high"] - bucketed["low"]) / bucketed["mid"] * 10000
                    )
                    bucketed = bucketed.dropna()

                    if not bucketed.empty:
                        avg_15min_volume = float(bucketed["volume"].mean())
                        avg_spread_bps_hist = float(bucketed["spread_bps"].mean())

                        n = len(bucketed)
                        if n >= 6:
                            early = float(bucketed.iloc[:2]["spread_bps"].mean())
                            middle = float(
                                bucketed.iloc[n // 2 - 1: n // 2 + 1]["spread_bps"].mean()
                            )
                            late = float(bucketed.iloc[-2:]["spread_bps"].mean())
                            if middle > 0 and early > middle * 1.3 and late > middle * 1.3:
                                intraday_pattern = "U_SHAPED"
                            elif early > 0 and late > early * 1.3:
                                intraday_pattern = "WIDENING"
                            else:
                                intraday_pattern = "FLAT"

                        max_vol = float(bucketed["volume"].max()) + 1e-9
                        max_spread = float(bucketed["spread_bps"].max()) + 1e-9
                        bucketed["score"] = (
                            bucketed["volume"] / max_vol
                            - bucketed["spread_bps"] / max_spread
                        )
                        best_row = bucketed.loc[bucketed["score"].idxmax()]
                        best_window_info = {
                            "time_bucket": str(best_row["minute_bucket"]),
                            "avg_spread_bps": round(float(best_row["spread_bps"]), 2),
                            "volume": round(float(best_row["volume"]), 0),
                        }
                except Exception:
                    pass

    # Execution strategy recommendation
    target_shares = target_order_value / midpoint if midpoint > 0 else 0.0
    avg_15min_shares = avg_15min_volume if avg_15min_volume > 0 else None

    if avg_15min_shares and avg_15min_shares > 0:
        size_ratio = target_shares / avg_15min_shares
    else:
        size_ratio = target_order_value / (ask_depth_total + 1e-9)

    if size_ratio < 0.5:
        execution_strategy = "MARKET"
        execution_notes = "Order is small relative to typical 15-min volume. Market order acceptable."
        slices = 1
    elif size_ratio < 2.0:
        execution_strategy = "LIMIT"
        execution_notes = "Place limit orders near best bid/ask. Expect same-session fill."
        slices = 2
    elif size_ratio < 5.0:
        execution_strategy = "TWAP"
        slices = max(3, int(size_ratio * 2))
        execution_notes = f"Spread over ~{slices} time-sliced orders within the session."
    else:
        execution_strategy = "VWAP_MULTI_SESSION"
        slices = max(int(size_ratio / 2), 5)
        execution_notes = "Order too large for single session — execute across multiple days."

    anomaly_flag = False
    if avg_spread_bps_hist and spread_bps > avg_spread_bps_hist * 1.5:
        anomaly_flag = True

    # Plain-language summary
    target_m = target_order_value / 1e6
    slip_str = (
        f"est. slippage {slippage_bps:+.0f} bps"
        if slippage_bps is not None
        else "slippage unavailable"
    )
    if execution_strategy == "MARKET":
        summary = (
            f"{sym} has sufficient liquidity for a {target_m:,.0f}M VND order "
            f"(spread {spread_bps:.0f} bps, {slip_str}). Market order is acceptable."
        )
    elif execution_strategy == "LIMIT":
        summary = (
            f"{sym} liquidity supports a {target_m:,.0f}M VND order via LIMIT near the touch "
            f"(spread {spread_bps:.0f} bps, {slip_str}). Expect same-session fill in ~{slices} slices."
        )
    elif execution_strategy == "TWAP":
        summary = (
            f"{sym} requires a TWAP execution across ~{slices} slices for a {target_m:,.0f}M VND order "
            f"(size ≈ {size_ratio:.1f}× typical 15-min volume, {slip_str})."
        )
    else:
        summary = (
            f"{sym} cannot absorb a {target_m:,.0f}M VND order in one session — use VWAP across "
            f"multiple days in ~{slices} slices (size ≈ {size_ratio:.1f}× typical 15-min volume)."
        )
    if anomaly_flag:
        summary += " Current spread is unusually wide vs historical average — execute with caution."

    return {
        "as_of": config.today(),
        "symbol": sym,
        "signal": execution_strategy,
        "summary": summary,
        "timestamp": datetime.now().isoformat(),
        "target_order_value_vnd": target_order_value,
        "quote": {
            "best_bid": round(best_bid, 2),
            "best_ask": round(best_ask, 2),
            "midpoint": round(midpoint, 2),
            "spread_bps": round(spread_bps, 2),
        },
        "book_depth": {
            "bid_levels": [[round(p, 2), round(v, 0)] for p, v in bid_levels],
            "ask_levels": [[round(p, 2), round(v, 0)] for p, v in ask_levels],
            "bid_depth_vnd": round(bid_depth_total, 0),
            "ask_depth_vnd": round(ask_depth_total, 0),
            "imbalance_ratio": round(book_imbalance, 3),
            "imbalance_signal": imbalance_signal,
        },
        "slippage_estimate": {
            "fully_filled_in_book": fully_filled,
            "vwap_fill_price": round(vwap_fill, 2) if vwap_fill else None,
            "slippage_bps": round(slippage_bps, 2) if slippage_bps is not None else None,
            "filled_value_vnd": round(filled_value, 0),
        },
        "intraday_profile": {
            "sessions_analyzed": lookback_sessions,
            "avg_15min_volume_shares": round(avg_15min_volume, 0) if avg_15min_volume else None,
            "avg_spread_bps_historical": round(avg_spread_bps_hist, 2)
            if avg_spread_bps_hist
            else None,
            "spread_pattern": intraday_pattern,
            "best_execution_window": best_window_info,
            "current_spread_anomaly": anomaly_flag,
        },
        "execution_recommendation": {
            "strategy": execution_strategy,
            "suggested_slices": slices,
            "size_to_15min_volume_ratio": round(size_ratio, 2),
            "notes": execution_notes,
        },
    }
