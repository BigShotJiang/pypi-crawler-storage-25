"""
Listing tools — stock universe discovery.

Exposes the vnstock ``Listing`` API for looking up symbols by index group,
exchange, industry, or all instruments.
"""

from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records


def _get_listing_cls():
    """Return the Listing class from the preferred library for the current tier."""
    if config.IS_SPONSORED:
        try:
            from vnstock_data import Listing  # type: ignore
            return Listing
        except ImportError:
            pass
    from vnstock import Listing
    return Listing


def get_stock_list(
    group: Optional[str] = None,
    exchange: Optional[str] = None,
    source: Optional[str] = None,
) -> list[dict]:
    """
    Return the list of available tickers, optionally filtered by index group
    or by exchange.

    Args:
        group:    Index or group filter — e.g. "VN30", "VN100", "HNX30", "VNMID",
                  "VNSML", "ETF". If provided, returns constituents of that group.
        exchange: Exchange filter — "HOSE", "HNX", or "UPCOM". If provided,
                  returns all symbols listed on that exchange.
        source:   Data source override.

    Returns:
        List of dicts — one per symbol. Columns typically include
        ``symbol``, ``organ_name``, ``exchange``, and ``industry``.
    """
    src = source or config.SOURCE_LISTING
    Listing = _get_listing_cls()
    listing = Listing(source=src)

    # 1. Group / index constituents
    if group:
        for method in ("symbols_by_group", "symbols_by_index", "group"):
            fn = getattr(listing, method, None)
            if callable(fn):
                try:
                    df = fn(group)
                    return df_to_records(df)
                except Exception:
                    continue

    # 2. Exchange listing
    if exchange:
        for method in ("symbols_by_exchange", "exchange"):
            fn = getattr(listing, method, None)
            if callable(fn):
                try:
                    df = fn(exchange.upper())
                    return df_to_records(df)
                except Exception:
                    continue

    # 3. Fallback — all symbols
    df = listing.all_symbols() if hasattr(listing, "all_symbols") else None
    return df_to_records(df)


def get_index_members(
    index: str = "VN30",
    source: Optional[str] = None,
) -> list[dict]:
    """
    Return the current constituents of a market index.

    Args:
        index:  Index code — "VN30", "VN100", "HNX30", "VNINDEX", "VNMID", "VNSML".
        source: Data source override.

    Returns:
        List of dicts — one per constituent with symbol and name fields.
    """
    src = source or config.SOURCE_LISTING
    Listing = _get_listing_cls()
    listing = Listing(source=src)

    # Try the common method names used by vnstock for index membership
    for method in ("symbols_by_group", "symbols_by_index", "indices", "index"):
        fn = getattr(listing, method, None)
        if callable(fn):
            try:
                df = fn(index.upper())
                records = df_to_records(df)
                if records:
                    return records
            except Exception:
                continue
    return []


def get_industries(source: Optional[str] = None) -> list[dict]:
    """
    Return the list of industries (ICB classification) with member symbols.

    Args:
        source: Data source override.

    Returns:
        List of dicts with industry code, name, and symbols.
    """
    src = source or config.SOURCE_LISTING
    Listing = _get_listing_cls()
    listing = Listing(source=src)

    for method in ("symbols_by_industries", "industries", "industry_icb"):
        fn = getattr(listing, method, None)
        if callable(fn):
            try:
                df = fn()
                return df_to_records(df)
            except Exception:
                continue
    return []


def get_all_instruments(source: Optional[str] = None) -> list[dict]:
    """
    Return the union of all tradable instruments across stocks, ETFs, derivatives,
    and warrants.

    Args:
        source: Data source override.

    Returns:
        List of dicts — one per instrument.
    """
    src = source or config.SOURCE_LISTING
    Listing = _get_listing_cls()
    listing = Listing(source=src)

    for method in ("all_future_indices", "all_instruments", "all_symbols"):
        fn = getattr(listing, method, None)
        if callable(fn):
            try:
                df = fn()
                records = df_to_records(df)
                if records:
                    return records
            except Exception:
                continue
    return []
