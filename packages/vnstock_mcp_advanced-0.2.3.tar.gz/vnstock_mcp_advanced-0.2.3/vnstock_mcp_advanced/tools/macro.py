"""
Macro tools — Vietnamese macroeconomic indicators from ``vnstock_data``.

Covers GDP, CPI, interest rates, FDI, money supply, and the SBV reference rate
as well as USD/VND exchange rates. All tools require sponsored tier.
"""

from typing import Optional

from vnstock_mcp_advanced import config
from vnstock_mcp_advanced.utils.serializer import df_to_records
from vnstock_mcp_advanced.utils.tier_guard import require_sponsored


def get_macro_indicator(
    indicator: str = "gdp",
    period: str = "quarter",
) -> list[dict]:
    """
    Fetch a Vietnamese macro indicator time series.

    Args:
        indicator: One of — "gdp", "cpi", "fdi", "ppi", "interest_rate",
                   "money_supply", "unemployment". Case-insensitive.
        period:    "quarter", "year", or "month" where applicable.

    Returns:
        List of dicts with ``time`` plus the indicator-specific columns.
    """
    require_sponsored(f"get_macro_indicator({indicator})")
    from vnstock_data import Macro  # type: ignore

    macro = Macro()
    name = indicator.lower().strip()
    method = getattr(macro, name, None)
    if method is None:
        return [{"error": f"Indicator '{indicator}' is not available in vnstock_data.Macro."}]

    try:
        df = method(period=period)
    except TypeError:
        # Some indicators don't take a period parameter
        df = method()
    return df_to_records(df)


def get_exchange_rate(
    currency: str = "USD",
    period: str = "day",
) -> list[dict]:
    """
    Fetch the Vietnamese dong exchange rate vs a reference currency.

    Args:
        currency: Currency code — "USD", "EUR", "JPY", "CNY", "GBP".
        period:   "day" or "month". "day" returns daily spot rates.

    Returns:
        List of dicts with ``time`` and rate columns (buy/sell/mid).
    """
    require_sponsored("get_exchange_rate")
    from vnstock_data import Macro  # type: ignore

    macro = Macro()
    fn = getattr(macro, "exchange_rate", None)
    if fn is None:
        return [{"error": "exchange_rate is not available in vnstock_data.Macro."}]

    try:
        df = fn(currency=currency.upper(), period=period)
    except TypeError:
        try:
            df = fn(currency=currency.upper())
        except TypeError:
            df = fn()
    return df_to_records(df)
