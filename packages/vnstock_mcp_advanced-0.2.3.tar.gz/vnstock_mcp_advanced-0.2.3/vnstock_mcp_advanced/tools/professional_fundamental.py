"""
Professional fundamental tools — forensic accounting red-flag scoring, cashflow
vs earnings divergence detection, and risk-adjusted return screening.

These tools go beyond surface-level ratios to answer deeper questions:
  - Is this company's reported profit backed by real cash flow, or is it
    being propped up by accruals, receivables growth and inventory buildup?
  - Within a universe, which stocks show the widest gap between what they
    earn on paper and what they actually collect — the classic earnings-
    manipulation warning?
  - Which stocks in a universe deliver the best risk-adjusted compounding
    — measured by Sharpe, Sortino, Calmar, drawdown, win rate, and ulcer?

Every function returns a plain dict with `signal`, `summary`, and `as_of` so
the output is consumable by LLM agents without any post-processing.

All tools are FREE tier — no sponsored gating required. They only consume
financial statements, ratios, price history, and index memberships, which
are all available on the free tier of vnstock.
"""

from datetime import date, timedelta
from typing import Optional

from vnstock_mcp_advanced import config


# ── Shared helpers ─────────────────────────────────────────────────────────

def _safe_float(value, default=None):
    """Best-effort float coercion that returns `default` on None / bad input."""
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _col_lookup(row: dict, *keywords: str):
    """
    Find the first dict key whose lowercased name contains any of `keywords`.

    Field names in vnstock financial statements vary between data sources
    (VCI vs KBS) and tiers, so we resolve columns by substring match rather
    than relying on a fixed schema.
    """
    if not row:
        return None
    for key, val in row.items():
        lk = str(key).lower()
        if any(kw in lk for kw in keywords):
            return val
    return None


def _col_lookup_many(rows: list[dict], *keywords: str) -> list:
    """Run `_col_lookup` across a list of rows, returning a list of values."""
    return [_col_lookup(r, *keywords) for r in rows]


def _first_key(rows: list[dict], *keywords: str) -> Optional[str]:
    """Return the first real column name in `rows` that matches any keyword."""
    if not rows:
        return None
    for key in rows[0].keys():
        lk = str(key).lower()
        if any(kw in lk for kw in keywords):
            return str(key)
    return None


def _series(rows: list[dict], key: Optional[str]) -> list[float]:
    """Extract a numeric series for `key`, filtering out None values."""
    if not key or not rows:
        return []
    out = []
    for r in rows:
        v = _safe_float(r.get(key))
        if v is not None:
            out.append(v)
    return out


def _yoy_growth(values: list[float], lag: int = 4) -> Optional[float]:
    """
    Compute the year-over-year growth assuming `values` are in chronological
    order (oldest first). Uses index -1 vs -1-lag so quarterly series with
    `lag=4` compares the most recent quarter to the same quarter last year.
    """
    if len(values) <= lag:
        return None
    latest = values[-1]
    prior = values[-1 - lag]
    if prior == 0:
        return None
    return (latest - prior) / abs(prior)


def _universe_symbols(universe: str, max_symbols: int, source: Optional[str] = None) -> list[str]:
    """Resolve a universe label (VN30, VN100, HNX30 ...) to a capped symbol list."""
    from vnstock_mcp_advanced.tools.listing import get_index_members

    members = get_index_members(index=universe, source=source or config.SOURCE_LISTING)
    symbols: list[str] = []
    for m in members or []:
        sym = m.get("symbol") or m.get("ticker") or m.get("code")
        if sym:
            sym = str(sym).upper().strip()
            if sym and sym not in symbols:
                symbols.append(sym)
        if len(symbols) >= max_symbols:
            break
    return symbols


# ── A. Earnings Quality Scorer ────────────────────────────────────────────

def earnings_quality_scorer(
    symbol: str,
    periods: int = 8,
    source: Optional[str] = None,
) -> dict:
    """
    Score a stock's earnings quality from 0-100 by checking 12 forensic-
    accounting red flags across four categories.

    Category weights:
        Cash Flow Quality     35 %   (3 flags)
        Accrual Quality       25 %   (3 flags)
        Revenue Quality       20 %   (3 flags)
        Balance Sheet Quality 20 %   (3 flags)

    Each triggered flag subtracts its category weight / 3 from the maximum.
    The composite is mapped to a letter grade:

        85-100   A_EXCELLENT         — clean books, earnings backed by cash
        70-84    B_GOOD              — generally healthy with minor concerns
        55-69    C_ADEQUATE          — multiple areas warrant scrutiny
        40-54    D_WEAK              — significant red flags
        0-39     F_SEVERE_RED_FLAGS  — likely manipulation or distress

    Args:
        symbol:  Ticker, e.g. "VCB".
        periods: Number of quarterly reports to inspect (default 8).
        source:  Data source override ("vci" or "kbs").

    Returns:
        Dict with signal (grade label), composite_score (0-100), category
        breakdown, flags_triggered list, flag-by-flag detail, trend vs two
        quarters ago, summary sentence and as_of date.
    """
    from vnstock_mcp_advanced.tools.finance import get_financial_statements, get_financial_ratios

    try:
        src = source or config.SOURCE_FINANCE
        income = get_financial_statements(symbol, statement="income", period="quarter", source=src) or []
        balance = get_financial_statements(symbol, statement="balance", period="quarter", source=src) or []
        ratios = get_financial_ratios(symbol, period="quarter", source=src) or []
        try:
            cashflow = get_financial_statements(symbol, statement="cashflow", period="quarter", source=src) or []
        except Exception:
            cashflow = []

        # Keep the most recent `periods` quarters. vnstock typically returns
        # chronological order (oldest → newest); we tail from the end so the
        # last entry is always the most recent quarter.
        income = income[-periods:] if len(income) > periods else income
        balance = balance[-periods:] if len(balance) > periods else balance
        cashflow = cashflow[-periods:] if len(cashflow) > periods else cashflow
        ratios = ratios[-periods:] if len(ratios) > periods else ratios

        if not income or not balance:
            return {
                "symbol": symbol.upper(),
                "signal": "UNKNOWN",
                "summary": f"{symbol.upper()}: insufficient quarterly statements to score earnings quality.",
                "as_of": config.today(),
            }

        # ── Resolve column keys once, then build numeric series ──
        rev_k = _first_key(income, "revenue", "net_sales", "sales")
        ni_k = _first_key(income, "net_income", "net_profit", "profit_after", "profitfortheperiod")
        op_k = _first_key(income, "operating_profit", "operating_income", "ebit", "profit_from_operating")
        cogs_k = _first_key(income, "cogs", "cost_of_good", "cost_of_sales")
        gross_k = _first_key(income, "gross_profit")
        int_k = _first_key(income, "interest_expense", "financial_expense")

        assets_k = _first_key(balance, "total_asset")
        liab_k = _first_key(balance, "total_liab")
        rec_k = _first_key(balance, "receivable")
        inv_k = _first_key(balance, "inventor")
        debt_k = _first_key(balance, "total_debt", "long_debt", "short_debt", "borrowing")
        other_k = _first_key(balance, "other_asset")

        cfo_k = _first_key(cashflow, "cfo", "operating_cash", "cash_from_operating", "net_cash_from_operating")

        revenue = _series(income, rev_k)
        net_income = _series(income, ni_k)
        operating = _series(income, op_k)
        cogs = _series(income, cogs_k)
        gross = _series(income, gross_k)
        interest = _series(income, int_k)

        assets = _series(balance, assets_k)
        liab = _series(balance, liab_k)
        receivable = _series(balance, rec_k)
        inventory = _series(balance, inv_k)
        debt = _series(balance, debt_k)
        other_assets = _series(balance, other_k)

        cfo = _series(cashflow, cfo_k)

        flags: dict[str, dict] = {}

        def _add(name: str, category: str, triggered: bool, detail: str, weight: float):
            flags[name] = {
                "flagged": bool(triggered),
                "category": category,
                "weight": round(weight, 3),
                "detail": detail,
            }

        cash_w = 35.0 / 3
        accr_w = 25.0 / 3
        rev_w = 20.0 / 3
        bs_w = 20.0 / 3

        # ── A. Cash Flow Quality (35%) ──────────────────────────

        # A1. CFO_NI_DIVERGENCE — CFO / NI below 0.6 for 3+ of last 3 quarters
        # Prefer real cash-flow statement CFO when available; otherwise use
        # operating profit as a proxy.
        triggered = False
        detail = "Insufficient data"
        series_cfo = cfo if len(cfo) >= 3 else operating
        if len(series_cfo) >= 3 and len(net_income) >= 3:
            tail_cfo = series_cfo[-3:]
            tail_ni = net_income[-3:]
            bad = 0
            for c, n in zip(tail_cfo, tail_ni):
                if n and n != 0:
                    ratio = c / n
                    if ratio < 0.6:
                        bad += 1
            triggered = bad >= 3
            detail = f"{bad}/3 recent quarters had CFO/NI < 0.6"
        _add("CFO_NI_DIVERGENCE", "cash_flow", triggered, detail, cash_w)

        # A2. RECEIVABLES_GROWTH — receivables YoY growth exceeds revenue YoY by > 30pp
        triggered = False
        detail = "Insufficient data"
        rec_yoy = _yoy_growth(receivable, lag=4)
        rev_yoy = _yoy_growth(revenue, lag=4)
        if rec_yoy is not None and rev_yoy is not None:
            gap = rec_yoy - rev_yoy
            triggered = gap > 0.30
            detail = f"Receivables YoY {rec_yoy*100:.1f}% vs Revenue YoY {rev_yoy*100:.1f}% (gap {gap*100:.1f}pp)"
        _add("RECEIVABLES_GROWTH", "cash_flow", triggered, detail, cash_w)

        # A3. DEBT_SERVICE — interest expense / operating profit > 0.4
        triggered = False
        detail = "Insufficient data"
        if interest and operating and operating[-1] and operating[-1] > 0:
            ratio = abs(interest[-1]) / operating[-1]
            triggered = ratio > 0.40
            detail = f"Interest coverage burden {ratio*100:.1f}% of operating profit"
        _add("DEBT_SERVICE", "cash_flow", triggered, detail, cash_w)

        # ── B. Accrual Quality (25%) ────────────────────────────

        # B1. ACCRUALS_RATIO — (NI - CFO proxy) / total_assets > 10%
        triggered = False
        detail = "Insufficient data"
        if net_income and assets and assets[-1] and assets[-1] > 0:
            cfo_proxy = cfo[-1] if cfo else (operating[-1] if operating else None)
            if cfo_proxy is not None:
                accrual = (net_income[-1] - cfo_proxy) / assets[-1]
                triggered = abs(accrual) > 0.10
                detail = f"Accruals / assets = {accrual*100:.2f}%"
        _add("ACCRUALS_RATIO", "accrual", triggered, detail, accr_w)

        # B2. INVENTORY_VS_COGS — inventory YoY growth > COGS YoY + 30pp
        triggered = False
        detail = "Insufficient data"
        inv_yoy = _yoy_growth(inventory, lag=4)
        cogs_yoy = _yoy_growth(cogs, lag=4)
        if inv_yoy is not None and cogs_yoy is not None:
            gap = inv_yoy - cogs_yoy
            triggered = gap > 0.30
            detail = f"Inventory YoY {inv_yoy*100:.1f}% vs COGS YoY {cogs_yoy*100:.1f}% (gap {gap*100:.1f}pp)"
        _add("INVENTORY_VS_COGS", "accrual", triggered, detail, accr_w)

        # B3. RECEIVABLE_DAYS — days-sales-outstanding rising 3 quarters in a row
        triggered = False
        detail = "Insufficient data"
        if len(receivable) >= 4 and len(revenue) >= 4:
            days_series = []
            for r, rev in zip(receivable[-4:], revenue[-4:]):
                if rev and rev > 0:
                    days_series.append((r / rev) * 90)
            if len(days_series) >= 3:
                last3 = days_series[-3:]
                triggered = last3[0] < last3[1] < last3[2]
                detail = f"DSO last 3Q: {last3[0]:.0f} → {last3[1]:.0f} → {last3[2]:.0f}"
        _add("RECEIVABLE_DAYS", "accrual", triggered, detail, accr_w)

        # ── C. Revenue Quality (20%) ────────────────────────────

        # C1. REVENUE_VOLATILITY — CV of quarterly revenue > 0.30
        triggered = False
        detail = "Insufficient data"
        if len(revenue) >= 4:
            mean_r = sum(revenue) / len(revenue)
            if mean_r > 0:
                var = sum((x - mean_r) ** 2 for x in revenue) / len(revenue)
                std_r = var ** 0.5
                cv = std_r / mean_r
                triggered = cv > 0.30
                detail = f"Revenue CV {cv*100:.1f}%"
        _add("REVENUE_VOLATILITY", "revenue", triggered, detail, rev_w)

        # C2. GROSS_MARGIN_DECLINE — gross margin falling 3 quarters in a row
        triggered = False
        detail = "Insufficient data"
        if len(gross) >= 3 and len(revenue) >= 3:
            gm_series = []
            for g, r in zip(gross[-3:], revenue[-3:]):
                if r and r != 0:
                    gm_series.append(g / r)
            if len(gm_series) >= 3:
                triggered = gm_series[0] > gm_series[1] > gm_series[2]
                detail = f"Gross margin last 3Q: {gm_series[0]*100:.1f}% → {gm_series[1]*100:.1f}% → {gm_series[2]*100:.1f}%"
        _add("GROSS_MARGIN_DECLINE", "revenue", triggered, detail, rev_w)

        # C3. REVENUE_CONCENTRATION — single quarter > 40 % of trailing 4Q sum
        triggered = False
        detail = "Insufficient data"
        if len(revenue) >= 4:
            last4 = revenue[-4:]
            total = sum(last4)
            if total > 0:
                max_share = max(last4) / total
                triggered = max_share > 0.40
                detail = f"Single quarter = {max_share*100:.1f}% of trailing 4Q revenue"
        _add("REVENUE_CONCENTRATION", "revenue", triggered, detail, rev_w)

        # ── D. Balance Sheet Quality (20%) ──────────────────────

        # D1. DEBT_ACCELERATION — D/E ratio rose > 30 % over window
        triggered = False
        detail = "Insufficient data"
        if len(debt) >= 2 and len(assets) >= 2 and len(liab) >= 2:
            eq_first = assets[0] - liab[0]
            eq_last = assets[-1] - liab[-1]
            if eq_first > 0 and eq_last > 0:
                de_first = debt[0] / eq_first
                de_last = debt[-1] / eq_last
                if de_first > 0:
                    delta = (de_last - de_first) / de_first
                    triggered = delta > 0.30
                    detail = f"D/E {de_first:.2f} → {de_last:.2f} ({delta*100:+.1f}%)"
        _add("DEBT_ACCELERATION", "balance_sheet", triggered, detail, bs_w)

        # D2. ASSET_QUALITY — "other assets" / total assets > 15%
        triggered = False
        detail = "Insufficient data"
        if other_assets and assets and assets[-1] and assets[-1] > 0:
            share = other_assets[-1] / assets[-1]
            triggered = share > 0.15
            detail = f"Other assets = {share*100:.1f}% of total assets"
        _add("ASSET_QUALITY", "balance_sheet", triggered, detail, bs_w)

        # D3. LEVERAGE_RATIO — total liabilities / total assets > 70%
        triggered = False
        detail = "Insufficient data"
        if liab and assets and assets[-1] and assets[-1] > 0:
            lev = liab[-1] / assets[-1]
            triggered = lev > 0.70
            detail = f"Liabilities / assets = {lev*100:.1f}%"
        _add("LEVERAGE_RATIO", "balance_sheet", triggered, detail, bs_w)

        # ── Composite scoring ───────────────────────────────────
        def _compute_score(flag_dict: dict) -> tuple[float, dict]:
            cat_max = {
                "cash_flow": 35.0,
                "accrual": 25.0,
                "revenue": 20.0,
                "balance_sheet": 20.0,
            }
            cat_totals = {k: 0.0 for k in cat_max}
            for _, f in flag_dict.items():
                pts = 0.0 if f["flagged"] else f["weight"]
                cat_totals[f["category"]] += pts
            total = sum(cat_totals.values())
            breakdown = {
                k: {"score": round(v, 2), "max": cat_max[k]}
                for k, v in cat_totals.items()
            }
            return total, breakdown

        composite_score, category_scores = _compute_score(flags)

        # Grade
        if composite_score >= 85:
            grade = "A_EXCELLENT"
        elif composite_score >= 70:
            grade = "B_GOOD"
        elif composite_score >= 55:
            grade = "C_ADEQUATE"
        elif composite_score >= 40:
            grade = "D_WEAK"
        else:
            grade = "F_SEVERE_RED_FLAGS"

        # Trend vs 2 quarters ago — recompute with last two quarters dropped
        trend_delta: Optional[float] = None
        try:
            if len(income) >= 4 and len(balance) >= 4:
                past_income = income[:-2]
                past_balance = balance[:-2]
                past_rev = _series(past_income, rev_k)
                past_ni = _series(past_income, ni_k)
                past_op = _series(past_income, op_k)
                past_gross = _series(past_income, gross_k)
                past_assets = _series(past_balance, assets_k)
                past_liab = _series(past_balance, liab_k)

                past_flags = {k: dict(v) for k, v in flags.items()}

                # Re-evaluate three structural flags with the past window.
                if past_assets and past_liab and past_assets[-1] > 0:
                    past_flags["LEVERAGE_RATIO"]["flagged"] = (past_liab[-1] / past_assets[-1]) > 0.70

                if len(past_rev) >= 4:
                    mean_r = sum(past_rev) / len(past_rev)
                    if mean_r > 0:
                        var = sum((x - mean_r) ** 2 for x in past_rev) / len(past_rev)
                        std_r = var ** 0.5
                        past_flags["REVENUE_VOLATILITY"]["flagged"] = (std_r / mean_r) > 0.30

                if len(past_gross) >= 3 and len(past_rev) >= 3:
                    gm_series = []
                    for g, r in zip(past_gross[-3:], past_rev[-3:]):
                        if r and r != 0:
                            gm_series.append(g / r)
                    if len(gm_series) >= 3:
                        past_flags["GROSS_MARGIN_DECLINE"]["flagged"] = (
                            gm_series[0] > gm_series[1] > gm_series[2]
                        )

                past_score, _ = _compute_score(past_flags)
                trend_delta = round(composite_score - past_score, 2)
        except Exception:
            trend_delta = None

        flagged_list = [name for name, f in flags.items() if f["flagged"]]
        flagged_count = len(flagged_list)

        # Plain-language summary
        sym_u = symbol.upper()
        if flagged_count == 0:
            flag_phrase = "no red flags"
        elif flagged_count == 1:
            flag_phrase = "1 minor red flag"
        elif flagged_count <= 3:
            flag_phrase = f"{flagged_count} minor red flags"
        else:
            flag_phrase = f"{flagged_count} red flags"

        if grade == "A_EXCELLENT":
            verdict = "Overall excellent — earnings look fully backed by cash."
        elif grade == "B_GOOD":
            verdict = "Overall healthy."
        elif grade == "C_ADEQUATE":
            verdict = "Adequate but worth monitoring."
        elif grade == "D_WEAK":
            verdict = "Earnings quality is weak — proceed carefully."
        else:
            verdict = "Severe accounting concerns — high manipulation or distress risk."

        summary = (
            f"{sym_u} scores {composite_score:.0f}/100 on earnings quality "
            f"with {flag_phrase}. {verdict}"
        )

        return {
            "symbol": sym_u,
            "signal": grade,
            "summary": summary,
            "as_of": config.today(),
            "periods_analyzed": len(income),
            "composite_score": round(composite_score, 2),
            "grade": grade,
            "flags_triggered": flagged_list,
            "flagged_count": flagged_count,
            "total_flags": len(flags),
            "category_scores": category_scores,
            "flags": {
                name: {
                    "flagged": f["flagged"],
                    "category": f["category"],
                    "weight": f["weight"],
                    "detail": f["detail"],
                }
                for name, f in flags.items()
            },
            "score_trend_vs_2q_ago": trend_delta,
        }
    except Exception as e:
        return {
            "symbol": symbol.upper(),
            "signal": "UNKNOWN",
            "error": str(e),
            "summary": f"Could not score earnings quality for {symbol.upper()}.",
            "as_of": config.today(),
        }


# ── B. Cash Flow vs Earnings Divergence ───────────────────────────────────

_QUARTER_WEIGHTS = [0.4, 0.3, 0.2, 0.1]


def _analyze_divergence(symbol: str, quarters: int, source: Optional[str]) -> Optional[dict]:
    """Per-symbol divergence analysis used by `cashflow_earnings_divergence`."""
    from vnstock_mcp_advanced.tools.finance import get_financial_statements, get_financial_ratios

    try:
        src = source or config.SOURCE_FINANCE
        income = get_financial_statements(symbol, statement="income", period="quarter", source=src) or []
        balance = get_financial_statements(symbol, statement="balance", period="quarter", source=src) or []
        try:
            cashflow = get_financial_statements(symbol, statement="cashflow", period="quarter", source=src) or []
        except Exception:
            cashflow = []
        try:
            ratios = get_financial_ratios(symbol, period="quarter", source=src) or []
        except Exception:
            ratios = []
    except Exception as e:
        return {"symbol": symbol, "error": str(e)}

    if not income or len(income) < 2:
        return {"symbol": symbol, "error": "insufficient_quarters"}

    # Take the most recent `quarters` rows. Sources return chronological order
    # (oldest → newest), so we tail and then reverse for "most recent first".
    income = income[-quarters:]
    balance = balance[-quarters:] if balance else []
    cashflow = cashflow[-quarters:] if cashflow else []
    ratios = ratios[-quarters:] if ratios else []

    income_recent = list(reversed(income))       # [0] = most recent
    balance_recent = list(reversed(balance))
    cashflow_recent = list(reversed(cashflow))
    ratios_recent = list(reversed(ratios))

    # Column keys
    ni_k = _first_key(income, "net_income", "net_profit", "profit_after", "profitfortheperiod")
    op_k = _first_key(income, "operating_profit", "operating_income", "ebit")
    rev_k = _first_key(income, "revenue", "net_sales", "sales")
    cfo_k = _first_key(cashflow, "cfo", "operating_cash", "cash_from_operating", "net_cash_from_operating")

    if not ni_k:
        return {"symbol": symbol, "error": "missing_net_income"}

    # Per-quarter CFO vs NI ratio (most recent first).
    ratios_list: list[dict] = []
    for idx, row in enumerate(income_recent):
        ni_val = _safe_float(row.get(ni_k))
        if ni_val is None or ni_val == 0:
            continue

        cfo_val: Optional[float] = None
        if cfo_k and idx < len(cashflow_recent):
            cfo_val = _safe_float(cashflow_recent[idx].get(cfo_k))
        if cfo_val is None and op_k:
            cfo_val = _safe_float(row.get(op_k))
        if cfo_val is None:
            continue

        cfo_ni = cfo_val / ni_val
        ratios_list.append({
            "quarter_index": idx,
            "cfo_ni_ratio": cfo_ni,
            "accruals": ni_val - cfo_val,
            "cfo_proxy": cfo_val,
            "net_income": ni_val,
        })

    if len(ratios_list) < 2:
        return {"symbol": symbol, "error": "insufficient_ratio_history"}

    # Weighted divergence score (heaviest weight on most recent quarter).
    weights = _QUARTER_WEIGHTS[: len(ratios_list)]
    wsum = sum(weights)
    divergence_score = sum(
        (r["cfo_ni_ratio"] - 1.0) * w for r, w in zip(ratios_list, weights)
    ) / wsum

    # Linear-regression slope across quarters ordered oldest → newest.
    series = [r["cfo_ni_ratio"] for r in reversed(ratios_list)]
    n = len(series)
    if n >= 2:
        mean_x = (n - 1) / 2.0
        mean_y = sum(series) / n
        num = sum((i - mean_x) * (series[i] - mean_y) for i in range(n))
        den = sum((i - mean_x) ** 2 for i in range(n))
        slope = num / den if den > 0 else 0.0
    else:
        slope = 0.0

    if slope < -0.05:
        trend = "DETERIORATING"
    elif slope > 0.05:
        trend = "IMPROVING"
    else:
        trend = "STABLE"

    # Decompose drivers via balance sheet.
    drivers: list[str] = []
    if balance_recent and len(balance_recent) >= 2:
        rec_k = _first_key(balance, "receivable")
        inv_k = _first_key(balance, "inventor")
        debt_k = _first_key(balance, "total_debt", "long_debt", "borrowing")
        eq_k = _first_key(balance, "equity", "owners_equity", "shareholders")

        prior_idx = min(3, len(balance_recent) - 1)
        prior_inc_idx = min(3, len(income_recent) - 1)

        def _pair(key: Optional[str], src_list: list[dict]) -> tuple[Optional[float], Optional[float]]:
            if not key:
                return None, None
            latest = _safe_float(src_list[0].get(key)) if src_list else None
            prior = _safe_float(src_list[prior_idx].get(key)) if len(src_list) > prior_idx else None
            return latest, prior

        rec_l, rec_p = _pair(rec_k, balance_recent)
        inv_l, inv_p = _pair(inv_k, balance_recent)
        debt_l, debt_p = _pair(debt_k, balance_recent)
        eq_l, eq_p = _pair(eq_k, balance_recent)

        rev_l = _safe_float(income_recent[0].get(rev_k)) if rev_k else None
        rev_p = _safe_float(income_recent[prior_inc_idx].get(rev_k)) if rev_k and len(income_recent) > prior_inc_idx else None

        if rec_l is not None and rec_p and rev_l is not None and rev_p:
            if rec_p > 0 and rev_p > 0:
                rec_g = rec_l / rec_p - 1
                rev_g = rev_l / rev_p - 1
                if rec_g > rev_g + 0.10:
                    drivers.append("RECEIVABLES_GROWING")

        if inv_l is not None and inv_p and rev_l is not None and rev_p:
            if inv_p > 0 and rev_p > 0:
                inv_g = inv_l / inv_p - 1
                rev_g = rev_l / rev_p - 1
                if inv_g > rev_g + 0.15:
                    drivers.append("INVENTORY_BUILDUP")

        if debt_l is not None and debt_p and eq_l is not None and eq_p:
            if eq_l > 0 and eq_p > 0:
                de_l = debt_l / eq_l
                de_p = debt_p / eq_p
                if de_p > 0 and de_l > de_p * 1.15:
                    drivers.append("DEBT_ACCELERATION")

    # PE readout for risk rating.
    pe_value: Optional[float] = None
    if ratios_recent:
        pe_value = _safe_float(
            ratios_recent[0].get("pe")
            or ratios_recent[0].get("price_to_earning")
            or ratios_recent[0].get("pe_ratio")
        )

    negative_quarters = sum(1 for r in ratios_list if r["cfo_ni_ratio"] < 1.0)

    if divergence_score < -0.30 and negative_quarters >= 3:
        risk_rating = "HIGH_NEGATIVE_SURPRISE" if (pe_value and pe_value > 15) else "MODERATE_NEGATIVE"
    elif divergence_score > 0.30:
        risk_rating = "POSITIVE_SURPRISE"
    elif abs(divergence_score) > 0.15:
        risk_rating = "MODERATE"
    else:
        risk_rating = "LOW"

    return {
        "symbol": symbol,
        "divergence_score": round(divergence_score, 4),
        "trend": trend,
        "trend_slope": round(slope, 4),
        "quarters_analyzed": len(ratios_list),
        "negative_quarters": negative_quarters,
        "latest_cfo_ni_ratio": round(ratios_list[0]["cfo_ni_ratio"], 3),
        "latest_accruals": round(ratios_list[0]["accruals"], 0),
        "pe": round(pe_value, 2) if pe_value is not None else None,
        "drivers": drivers,
        "risk_rating": risk_rating,
        "quarterly_ratios": [
            {
                "q_index": r["quarter_index"],
                "cfo_ni_ratio": round(r["cfo_ni_ratio"], 3),
                "accruals": round(r["accruals"], 0),
            }
            for r in ratios_list
        ],
    }


def cashflow_earnings_divergence(
    universe: str = "VN30",
    quarters: int = 8,
    min_divergence_pct: float = 0.20,
    sort_by: str = "ABSOLUTE",
    max_symbols: int = 30,
    source: Optional[str] = None,
) -> dict:
    """
    Rank a universe of stocks by operating cash flow vs net income divergence.

    A CFO/NI ratio materially below 1.0 for multiple quarters is a classic
    earnings-manipulation red flag. A ratio materially above 1.0 means the
    company is collecting more cash than it reports — a potential positive
    surprise candidate.

    For each stock this tool computes:
      - a weighted CFO/NI divergence score (weights 0.4, 0.3, 0.2, 0.1 on the
        four most-recent quarters)
      - a linear-regression trend slope (IMPROVING / STABLE / DETERIORATING)
      - driver decomposition via balance sheet: RECEIVABLES_GROWING,
        INVENTORY_BUILDUP, DEBT_ACCELERATION
      - a risk rating: HIGH_NEGATIVE_SURPRISE, MODERATE_NEGATIVE,
        POSITIVE_SURPRISE, MODERATE or LOW

    Iteration is sequential (no async) and capped at `max_symbols` to keep
    rate-limit usage predictable on the free tier.

    Args:
        universe:           Index label — "VN30", "VN100", "HNX30", etc.
        quarters:           Quarterly periods per stock (default 8).
        min_divergence_pct: Minimum absolute divergence to include (default 0.20).
        sort_by:            NEGATIVE_DIVERGENCE, POSITIVE_DIVERGENCE,
                            ABSOLUTE, or DETERIORATING (default ABSOLUTE).
        max_symbols:        Cap on symbols processed (default 30).
        source:             Data source override.

    Returns:
        Dict with signal, summary, as_of, ranked result list, and counts by
        risk rating.
    """
    try:
        symbols = _universe_symbols(universe, max_symbols=max_symbols, source=source)
    except Exception as e:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "error": str(e),
            "summary": f"Could not resolve universe {universe}.",
            "as_of": config.today(),
        }

    if not symbols:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "summary": f"No symbols found for universe {universe}.",
            "as_of": config.today(),
        }

    sort_key = (sort_by or "ABSOLUTE").upper()

    # Sequential analysis — one symbol at a time, tolerant to per-symbol errors.
    results: list[dict] = []
    errors = 0
    for sym in symbols:
        try:
            res = _analyze_divergence(sym, quarters=quarters, source=source)
        except Exception:
            errors += 1
            continue
        if not res or res.get("error"):
            errors += 1
            continue
        results.append(res)

    if not results:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "summary": f"No {universe} stocks could be analyzed (errors={errors}).",
            "as_of": config.today(),
            "universe_size": len(symbols),
        }

    # Filter and sort
    filtered = [r for r in results if abs(r["divergence_score"]) >= min_divergence_pct]

    if sort_key == "NEGATIVE_DIVERGENCE":
        filtered.sort(key=lambda x: x["divergence_score"])
    elif sort_key == "POSITIVE_DIVERGENCE":
        filtered.sort(key=lambda x: x["divergence_score"], reverse=True)
    elif sort_key == "DETERIORATING":
        filtered.sort(key=lambda x: (x["trend"] != "DETERIORATING", x["trend_slope"]))
    else:
        sort_key = "ABSOLUTE"
        filtered.sort(key=lambda x: abs(x["divergence_score"]), reverse=True)

    neg_count = sum(1 for r in filtered if r["divergence_score"] < 0)
    pos_count = sum(1 for r in filtered if r["divergence_score"] > 0)
    high_risk = sum(1 for r in filtered if r["risk_rating"] == "HIGH_NEGATIVE_SURPRISE")
    high_neg = [r for r in filtered if r["risk_rating"] in ("HIGH_NEGATIVE_SURPRISE", "MODERATE_NEGATIVE")]

    # Top example for summary
    top = filtered[0] if filtered else None

    if high_risk > 0 and top and top["risk_rating"] == "HIGH_NEGATIVE_SURPRISE":
        signal = f"{high_risk}_HIGH_NEGATIVE_SURPRISE"
        consec = top["negative_quarters"]
        summary = (
            f"{top['symbol']} shows a HIGH_NEGATIVE cashflow divergence across "
            f"{consec} quarters (CFO/NI {top['latest_cfo_ni_ratio']}) — elevated "
            f"earnings surprise risk. {high_risk} similar names in {universe}."
        )
    elif neg_count > 0:
        signal = f"{neg_count}_NEGATIVE_DIVERGENCE_FOUND"
        if top:
            summary = (
                f"{neg_count} {universe} stock(s) show negative CFO vs earnings "
                f"divergence beyond {int(min_divergence_pct*100)}%; top is "
                f"{top['symbol']} at {top['divergence_score']:+.2f}."
            )
        else:
            summary = f"{neg_count} {universe} stock(s) show negative divergence."
    elif pos_count > 0:
        signal = f"{pos_count}_POSITIVE_DIVERGENCE_FOUND"
        summary = (
            f"{pos_count} {universe} stock(s) collect more cash than they report — "
            f"top is {top['symbol']} at {top['divergence_score']:+.2f}."
            if top
            else f"{pos_count} {universe} stock(s) show positive divergence."
        )
    else:
        signal = "NO_DIVERGENCE"
        summary = f"No {universe} stocks exceed {int(min_divergence_pct*100)}% CFO vs earnings divergence."

    return {
        "universe": universe,
        "signal": signal,
        "summary": summary,
        "as_of": config.today(),
        "universe_size": len(symbols),
        "stocks_analyzed": len(results),
        "stocks_flagged": len(filtered),
        "errors": errors,
        "parameters": {
            "quarters": quarters,
            "min_divergence_pct": min_divergence_pct,
            "sort_by": sort_key,
            "max_symbols": max_symbols,
        },
        "summary_counts": {
            "negative_divergence_count": neg_count,
            "positive_divergence_count": pos_count,
            "high_risk_count": high_risk,
        },
        "results": filtered,
    }


# ── C. Risk-Adjusted Screener ─────────────────────────────────────────────

_LENGTH_FOR_MONTHS = {
    1: "1M",
    3: "3M",
    6: "6M",
    12: "1Y",
    18: "2Y",
    24: "2Y",
    36: "5Y",
    60: "5Y",
}


def _length_from_months(period_months: int) -> str:
    """Map a month count to the closest vnstock `length` shortcut."""
    if period_months <= 1:
        return "1M"
    if period_months <= 3:
        return "3M"
    if period_months <= 6:
        return "6M"
    if period_months <= 12:
        return "1Y"
    if period_months <= 24:
        return "2Y"
    return "5Y"


def _compute_risk_metrics(
    symbol: str,
    period_months: int,
    risk_free_rate: float,
    source: Optional[str],
) -> Optional[dict]:
    """Compute per-symbol risk-adjusted metrics."""
    try:
        import math
        import numpy as np
        import pandas as pd
    except ImportError:
        return None

    from vnstock_mcp_advanced.tools.quote import get_stock_price

    try:
        length = _length_from_months(period_months)
        prices = get_stock_price(
            symbol,
            length=length,
            interval="1D",
            source=source or config.SOURCE_QUOTE,
        ) or []
    except Exception:
        return None

    if not prices or len(prices) < 60:
        return None

    closes = [_safe_float(p.get("close")) for p in prices]
    closes = [c for c in closes if c is not None and c > 0]
    if len(closes) < 60:
        return None

    times = [p.get("time") or p.get("date") or p.get("datetime") for p in prices]

    close_arr = np.array(closes, dtype=float)
    log_ret = np.log(close_arr[1:] / close_arr[:-1])
    log_ret = log_ret[np.isfinite(log_ret)]
    if log_ret.size == 0:
        return None

    mean_daily = float(np.mean(log_ret))
    std_daily = float(np.std(log_ret, ddof=1)) if log_ret.size > 1 else 0.0

    ann_return = mean_daily * 252
    ann_vol = std_daily * math.sqrt(252) if std_daily > 0 else 0.0

    sharpe = (ann_return - risk_free_rate) / ann_vol if ann_vol > 0 else 0.0

    downside = log_ret[log_ret < 0]
    downside_dev = float(np.std(downside, ddof=1)) * math.sqrt(252) if downside.size > 1 else 0.0
    sortino = (ann_return - risk_free_rate) / downside_dev if downside_dev > 0 else 0.0

    # Max drawdown on cumulative path
    cum = close_arr / close_arr[0]
    peak = np.maximum.accumulate(cum)
    drawdown = (cum - peak) / peak
    max_dd = float(np.min(drawdown))  # negative

    calmar = ann_return / abs(max_dd) if max_dd < 0 else 0.0

    # Ulcer index
    dd_pct = drawdown * 100
    ulcer = float(math.sqrt(np.mean(dd_pct ** 2))) if dd_pct.size > 0 else 0.0

    # Monthly resample for win rate & profit factor
    win_rate = 0.0
    profit_factor = 0.0
    try:
        if any(t for t in times):
            ts = pd.to_datetime(pd.Series(times[: len(closes)]), errors="coerce")
            s = pd.Series(close_arr, index=ts).dropna()
            if not s.empty:
                monthly = s.resample("ME").last() if hasattr(s.index, "freq") or len(s) > 21 else s
                try:
                    monthly = s.resample("ME").last()
                except Exception:
                    monthly = s.resample("M").last()
                monthly_ret = monthly.pct_change().dropna()
                if len(monthly_ret) >= 2:
                    win_rate = float((monthly_ret > 0).mean())
                    pos_sum = float(monthly_ret[monthly_ret > 0].sum())
                    neg_sum = float(monthly_ret[monthly_ret < 0].sum())
                    profit_factor = pos_sum / abs(neg_sum) if neg_sum < 0 else 0.0
        else:
            # Fallback to approximate 21-day buckets
            monthly_close = close_arr[::21]
            if monthly_close.size >= 3:
                mret = (monthly_close[1:] / monthly_close[:-1]) - 1
                win_rate = float((mret > 0).mean())
                pos_sum = float(mret[mret > 0].sum())
                neg_sum = float(mret[mret < 0].sum())
                profit_factor = pos_sum / abs(neg_sum) if neg_sum < 0 else 0.0
    except Exception:
        pass

    # Skew and kurtosis (biased, sample estimators)
    skewness = 0.0
    kurtosis = 0.0
    if log_ret.size > 3 and std_daily > 0:
        centered = log_ret - mean_daily
        m2 = float(np.mean(centered ** 2))
        m3 = float(np.mean(centered ** 3))
        m4 = float(np.mean(centered ** 4))
        if m2 > 0:
            skewness = m3 / (m2 ** 1.5)
            kurtosis = m4 / (m2 ** 2) - 3.0  # excess kurtosis

    return {
        "symbol": symbol,
        "annualized_return": round(ann_return, 4),
        "annualized_volatility": round(ann_vol, 4),
        "sharpe": round(sharpe, 3),
        "sortino": round(sortino, 3),
        "calmar": round(calmar, 3),
        "max_drawdown": round(max_dd, 4),
        "ulcer_index": round(ulcer, 3),
        "win_rate_monthly": round(win_rate, 3),
        "profit_factor": round(profit_factor, 3),
        "skewness": round(skewness, 3),
        "kurtosis": round(kurtosis, 3),
        "bars": int(close_arr.size),
    }


def risk_adjusted_screener(
    universe: str = "VN30",
    period_months: int = 12,
    risk_free_rate: float = 0.045,
    sort_by: str = "composite",
    max_drawdown_limit: float = 0.30,
    top_n: int = 10,
    max_symbols: int = 30,
    source: Optional[str] = None,
) -> dict:
    """
    Screen a stock universe by risk-adjusted performance and return a ranked
    leaderboard with a composite percentile-rank score.

    For every symbol the tool computes:
      - annualized_return, annualized_volatility
      - Sharpe (rf-adjusted return / total vol)
      - Sortino (rf-adjusted return / downside deviation)
      - Calmar (annualized return / |max drawdown|)
      - Max drawdown on cumulative price path
      - Ulcer index (RMS of drawdown)
      - Monthly win rate and profit factor
      - Skewness and excess kurtosis of daily log returns

    It filters out any symbol whose absolute max drawdown exceeds
    `max_drawdown_limit`, then builds a composite score from 0-100 using
    percentile ranks with weights:

        Sharpe           30 %
        Sortino          25 %
        Calmar           20 %
        Win rate         15 %
        Inverse vol      10 %

    Finally it classifies each survivor into one of four risk profiles:
    LOW_RISK_STEADY, MODERATE_CONSISTENT, HIGH_RETURN_VOLATILE, or
    RISKY_INCONSISTENT — and returns the top `top_n` after sorting by the
    requested metric.

    Args:
        universe:           Index label ("VN30", "VN100", "HNX30", ...).
        period_months:      History window, mapped to the closest vnstock
                            `length` shortcut (1M, 3M, 6M, 1Y, 2Y, 5Y).
        risk_free_rate:     Annual risk-free rate for Sharpe/Sortino
                            (default 0.045 = 4.5%).
        sort_by:            composite, sharpe, sortino, calmar, return,
                            or win_rate.
        max_drawdown_limit: Absolute drawdown ceiling, e.g. 0.30 for -30%.
        top_n:              Max results returned.
        max_symbols:        Cap on symbols processed (default 30).
        source:             Data source override.

    Returns:
        Dict with signal (leader + composite), summary, as_of, ranked
        `results` list and scan metadata.
    """
    try:
        import numpy as np
        import pandas as pd  # noqa: F401 — imported so the helper can resample
    except ImportError as e:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "error": f"numpy/pandas required: {e}",
            "summary": "Risk-adjusted screener needs numpy/pandas.",
            "as_of": config.today(),
        }

    try:
        symbols = _universe_symbols(universe, max_symbols=max_symbols, source=source)
    except Exception as e:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "error": str(e),
            "summary": f"Could not resolve universe {universe}.",
            "as_of": config.today(),
        }

    if not symbols:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "summary": f"No symbols found for universe {universe}.",
            "as_of": config.today(),
        }

    # Sequential per-symbol metric computation.
    metrics: list[dict] = []
    for sym in symbols:
        try:
            m = _compute_risk_metrics(sym, period_months, risk_free_rate, source)
        except Exception:
            continue
        if m is not None:
            metrics.append(m)

    if not metrics:
        return {
            "universe": universe,
            "signal": "UNKNOWN",
            "summary": f"No usable price history found for {universe}.",
            "as_of": config.today(),
            "universe_size": len(symbols),
        }

    # Filter by drawdown limit.
    pre_filter = len(metrics)
    survivors = [m for m in metrics if abs(m["max_drawdown"]) <= max_drawdown_limit]

    if not survivors:
        return {
            "universe": universe,
            "signal": "NO_SURVIVORS",
            "summary": (
                f"All {pre_filter} {universe} stocks exceed the "
                f"{int(max_drawdown_limit*100)}% max-drawdown limit."
            ),
            "as_of": config.today(),
            "universe_size": len(symbols),
            "metrics_computed": pre_filter,
            "results_after_filter": 0,
            "parameters": {
                "period_months": period_months,
                "risk_free_rate": risk_free_rate,
                "max_drawdown_limit": max_drawdown_limit,
                "sort_by": sort_by,
                "top_n": top_n,
            },
            "results": [],
        }

    # Composite score via percentile ranks (ordinal average within survivors).
    def _pct_rank(values: list[float]) -> list[float]:
        n = len(values)
        if n == 0:
            return []
        if n == 1:
            return [1.0]
        # Average rank for ties
        order = sorted(range(n), key=lambda i: values[i])
        ranks = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and values[order[j + 1]] == values[order[i]]:
                j += 1
            avg_rank = (i + j) / 2 + 1  # 1-based average
            for k in range(i, j + 1):
                ranks[order[k]] = avg_rank / n
            i = j + 1
        return ranks

    sharpe_vals = [m["sharpe"] for m in survivors]
    sortino_vals = [m["sortino"] for m in survivors]
    calmar_vals = [m["calmar"] for m in survivors]
    winrate_vals = [m["win_rate_monthly"] for m in survivors]
    invvol_vals = [-m["annualized_volatility"] for m in survivors]

    r_sharpe = _pct_rank(sharpe_vals)
    r_sortino = _pct_rank(sortino_vals)
    r_calmar = _pct_rank(calmar_vals)
    r_winrate = _pct_rank(winrate_vals)
    r_invvol = _pct_rank(invvol_vals)

    for i, m in enumerate(survivors):
        composite = (
            r_sharpe[i] * 0.30
            + r_sortino[i] * 0.25
            + r_calmar[i] * 0.20
            + r_winrate[i] * 0.15
            + r_invvol[i] * 0.10
        ) * 100
        m["composite_score"] = round(composite, 2)

        vol = m["annualized_volatility"]
        ret = m["annualized_return"]
        wr = m["win_rate_monthly"]
        if vol < 0.25 and wr >= 0.55:
            m["risk_profile"] = "LOW_RISK_STEADY"
        elif vol < 0.35 and ret > 0.10:
            m["risk_profile"] = "MODERATE_CONSISTENT"
        elif vol >= 0.35 and ret > 0.20:
            m["risk_profile"] = "HIGH_RETURN_VOLATILE"
        else:
            m["risk_profile"] = "RISKY_INCONSISTENT"

    # Sort
    sort_map = {
        "composite": "composite_score",
        "sharpe": "sharpe",
        "sortino": "sortino",
        "calmar": "calmar",
        "return": "annualized_return",
        "win_rate": "win_rate_monthly",
    }
    sort_col = sort_map.get((sort_by or "composite").lower(), "composite_score")
    survivors.sort(key=lambda r: r.get(sort_col, 0.0), reverse=True)

    top_results = survivors[: max(1, top_n)]
    leader = top_results[0] if top_results else None

    if leader:
        signal = f"{leader['symbol']}_{int(round(leader['composite_score']))}_COMPOSITE"
        summary = (
            f"{leader['symbol']} ranks #1 in {universe} with a Sharpe of "
            f"{leader['sharpe']:.2f}, Sortino {leader['sortino']:.2f} and max "
            f"drawdown of {abs(leader['max_drawdown'])*100:.0f}% — best risk-"
            f"adjusted compounder over the last {period_months} month(s)."
        )
    else:
        signal = "NO_LEADER"
        summary = f"No leader identified in {universe}."

    return {
        "universe": universe,
        "signal": signal,
        "summary": summary,
        "as_of": config.today(),
        "universe_size": len(symbols),
        "metrics_computed": pre_filter,
        "results_after_filter": len(survivors),
        "parameters": {
            "period_months": period_months,
            "risk_free_rate": risk_free_rate,
            "max_drawdown_limit": max_drawdown_limit,
            "sort_by": sort_col,
            "top_n": top_n,
            "max_symbols": max_symbols,
        },
        "results": top_results,
    }
