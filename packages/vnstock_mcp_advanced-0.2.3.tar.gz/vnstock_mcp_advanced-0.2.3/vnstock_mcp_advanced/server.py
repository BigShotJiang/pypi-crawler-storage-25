"""
Vietnam Financial MCP Server

Exposes vnstock and vnstock_data as MCP tools for use in Claude Desktop,
the Claude API, or any MCP-compatible client.

Setup:
    pip install vnstock-mcp-advanced
    export VNSTOCK_USER_TIER=free          # or bronze/silver/golden
    export VNSTOCK_API_KEY=your_key_here   # optional

Run:
    vnstock-mcp-advanced
    # or: uvx vnstock-mcp-advanced

Add to Claude Desktop (claude_desktop_config.json):
    {
      "mcpServers": {
        "vnstock": {
          "command": "uvx",
          "args": ["vnstock-mcp-advanced"],
          "env": {
            "VNSTOCK_USER_TIER": "free"
          }
        }
      }
    }
"""

# ── Suppress vnai promotional output ───────────────────────────────────────
# vnai (a dependency of vnstock/vnstock_data) prints promotional content and
# update banners directly to stdout via print().  MCP stdio transport uses
# sys.stdout.buffer for JSON-RPC, so any stray print() corrupts the protocol.
#
# We CANNOT redirect sys.stdout because FastMCP reads sys.stdout.buffer at
# startup.  Instead, we monkeypatch builtins.print to send output to stderr,
# keeping sys.stdout intact for FastMCP.
import builtins as _builtins, sys as _sys, os as _os

_original_print = _builtins.print

def _safe_print(*args, **kwargs):
    """Route all print() calls to stderr so they never hit MCP's stdout."""
    kwargs.setdefault("file", _sys.stderr)
    return _original_print(*args, **kwargs)

_builtins.print = _safe_print
_os.environ.setdefault("VNAI_SILENT", "1")

from fastmcp import FastMCP
from vnstock_mcp_advanced import config

# ── Tool modules ────────────────────────────────────────────────────────────
from vnstock_mcp_advanced.tools.quote import get_stock_price, get_intraday_data, get_order_depth
from vnstock_mcp_advanced.tools.trading import (
    get_price_board,
    get_foreign_trading,
    get_prop_trading,
    get_insider_trading,
    get_trading_summary,
)
from vnstock_mcp_advanced.tools.company import (
    get_company_overview,
    get_shareholders,
    get_company_officers,
    get_company_events,
    get_company_news,
    get_subsidiaries,
    get_capital_history,
    get_insider_deals_company,
)
from vnstock_mcp_advanced.tools.finance import (
    get_financial_statements,
    get_financial_ratios,
    get_financial_notes,
    get_annual_plan,
)
from vnstock_mcp_advanced.tools.listing import (
    get_stock_list,
    get_index_members,
    get_industries,
    get_all_instruments,
)
from vnstock_mcp_advanced.tools.insights import get_top_movers, get_foreign_top_stocks, get_opportunities
from vnstock_mcp_advanced.tools.macro import get_macro_indicator, get_exchange_rate
from vnstock_mcp_advanced.tools.commodity import get_gold_price, get_commodity_prices
from vnstock_mcp_advanced.tools.composite import (
    analyze_stock,
    compare_stocks,
    sector_heatmap,
    detect_insider_activity,
    macro_market_overlay,
)
from vnstock_mcp_advanced.tools.market import get_market_valuation_pulse, get_sector_rotation
from vnstock_mcp_advanced.tools.flow import get_smart_money_flow, get_prop_desk_positioning
from vnstock_mcp_advanced.tools.screening import get_market_breadth, scan_breakout_setups, screen_quality_momentum
from vnstock_mcp_advanced.tools.investor import (
    check_stock_health,
    get_valuation_snapshot,
    check_price_signal,
    check_foreign_flow_signal,
    get_dividend_history,
    scan_dividend_stocks,
    check_risk_flags,
    check_volume_anomaly,
    watchlist_snapshot,
)
from vnstock_mcp_advanced.tools.professional_technical import (
    volatility_regime_classifier,
    multi_timeframe_confluence,
    wyckoff_phase_detector,
    liquidity_depth_analyzer,
)
from vnstock_mcp_advanced.tools.professional_flow import (
    smart_money_flow_detector,
    institutional_flow_predictor,
    sector_rotation_radar,
)
from vnstock_mcp_advanced.tools.professional_fundamental import (
    earnings_quality_scorer,
    cashflow_earnings_divergence,
    risk_adjusted_screener,
)

# ── Server ──────────────────────────────────────────────────────────────────
mcp = FastMCP(
    name="Vietnam Financial Data",
    instructions=(
        f"MCP server for Vietnamese stock market data via vnstock libraries. "
        f"Current user tier: {config.USER_TIER.upper()}. "
        f"{'All features available.' if config.IS_SPONSORED else 'Sponsored features (foreign/prop trading, macro, commodities, insights) require Bronze/Silver/Golden tier.'}"
    ),
)

# ── Register tools ──────────────────────────────────────────────────────────

# Tier 1 — Core Market Data
mcp.tool()(get_stock_price)
mcp.tool()(get_price_board)
mcp.tool()(get_top_movers)
mcp.tool()(get_intraday_data)

# Tier 2 — Company Intelligence
mcp.tool()(get_company_overview)
mcp.tool()(get_financial_statements)
mcp.tool()(get_financial_ratios)
mcp.tool()(get_shareholders)
mcp.tool()(get_company_events)
mcp.tool()(get_company_officers)

# Tier 3 — Trading Intelligence
mcp.tool()(get_foreign_trading)
mcp.tool()(get_insider_trading)
mcp.tool()(get_order_depth)
mcp.tool()(get_prop_trading)
mcp.tool()(get_foreign_top_stocks)
mcp.tool()(get_opportunities)
mcp.tool()(get_trading_summary)

# Tier 4 — Stock Discovery
mcp.tool()(get_stock_list)
mcp.tool()(get_index_members)
mcp.tool()(get_industries)
mcp.tool()(get_company_news)

# Tier 5 — Macro & Commodities
mcp.tool()(get_macro_indicator)
mcp.tool()(get_exchange_rate)
mcp.tool()(get_gold_price)
mcp.tool()(get_commodity_prices)

# Tier 6 — Extended Company Data
mcp.tool()(get_subsidiaries)
mcp.tool()(get_capital_history)
mcp.tool()(get_financial_notes)
mcp.tool()(get_annual_plan)
mcp.tool()(get_all_instruments)
mcp.tool()(get_insider_deals_company)

# Composite — High-value multi-call tools
mcp.tool()(analyze_stock)
mcp.tool()(compare_stocks)
mcp.tool()(sector_heatmap)
mcp.tool()(detect_insider_activity)
mcp.tool()(macro_market_overlay)

# Trading Intelligence & Market Screening — forecast-oriented bronze-tier tools
mcp.tool()(get_market_valuation_pulse)
mcp.tool()(get_sector_rotation)
mcp.tool()(get_smart_money_flow)
mcp.tool()(get_prop_desk_positioning)
mcp.tool()(get_market_breadth)
mcp.tool()(scan_breakout_setups)
mcp.tool()(screen_quality_momentum)

# Retail Investor — plain-language signals and summaries
mcp.tool()(check_stock_health)
mcp.tool()(get_valuation_snapshot)
mcp.tool()(check_price_signal)
mcp.tool()(check_foreign_flow_signal)
mcp.tool()(get_dividend_history)
mcp.tool()(scan_dividend_stocks)
mcp.tool()(check_risk_flags)
mcp.tool()(check_volume_anomaly)
mcp.tool()(watchlist_snapshot)

# Professional Trader — deep-insight quantitative tools for experienced traders
# Technical:  regime detection, multi-timeframe confluence, Wyckoff, liquidity
mcp.tool()(volatility_regime_classifier)
mcp.tool()(multi_timeframe_confluence)
mcp.tool()(wyckoff_phase_detector)
mcp.tool()(liquidity_depth_analyzer)
# Flow:       tick-level smart money, institutional pattern matching, RRG rotation
mcp.tool()(smart_money_flow_detector)
mcp.tool()(institutional_flow_predictor)
mcp.tool()(sector_rotation_radar)
# Fundamental: forensic earnings quality, CFO/NI divergence, risk-adjusted screen
mcp.tool()(earnings_quality_scorer)
mcp.tool()(cashflow_earnings_divergence)
mcp.tool()(risk_adjusted_screener)


def main() -> None:
    """Entry point for the `vnstock-mcp-advanced` console script."""
    mcp.run()


if __name__ == "__main__":
    main()
