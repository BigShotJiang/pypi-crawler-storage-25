"""
Tier gating helper — raise a clear error when a free-tier user tries to call
a sponsored-only tool.

Usage:
    from vnstock_mcp_advanced.utils.tier_guard import require_sponsored

    def my_tool(...):
        require_sponsored("my_tool")
        # ... tool logic ...
"""

from vnstock_mcp_advanced import config


class SponsoredTierRequired(PermissionError):
    """Raised when a sponsored-tier-only tool is invoked on a free tier."""


def require_sponsored(tool_name: str) -> None:
    """
    Raise ``SponsoredTierRequired`` if the current user tier is not Bronze/Silver/Golden.

    Call this as the very first line of any tool that depends on ``vnstock_data``,
    ``vnstock_news``, ``vnstock_ta``, or any other sponsored library.

    Args:
        tool_name: Human-readable name of the tool (used in the error message).
    """
    if not config.IS_SPONSORED:
        raise SponsoredTierRequired(
            f"Tool '{tool_name}' requires a sponsored tier (Bronze/Silver/Golden). "
            f"Current tier: '{config.USER_TIER}'. "
            "Upgrade your subscription or set the VNSTOCK_USER_TIER environment variable "
            "to 'bronze', 'silver', or 'golden' to enable sponsored features."
        )
