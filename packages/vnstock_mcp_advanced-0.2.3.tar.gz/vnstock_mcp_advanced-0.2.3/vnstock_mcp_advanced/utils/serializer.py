"""
Serializer helpers — convert pandas DataFrames and assorted Python/numpy/pandas
types into JSON-safe structures that can be returned to MCP clients.

The core functions are:

    df_to_records(df)     — DataFrame -> list[dict] (NaN -> None, types normalised)
    to_serializable(val)  — Any value -> JSON-safe value
"""

from datetime import date, datetime
from typing import Any


def to_serializable(value: Any) -> Any:
    """
    Coerce a single value into a JSON-serialisable form.

    Handles:
        - None, bool, int, float, str  (passed through)
        - pandas / numpy NaN           -> None
        - pandas Timestamp, datetime   -> ISO string
        - date                         -> ISO string
        - numpy integer / float        -> Python int / float
        - bytes                        -> UTF-8 string
        - fallback                     -> str(value)
    """
    if value is None:
        return None

    # Fast path for common Python primitives
    if isinstance(value, (bool, int, float, str)):
        # Detect float NaN (NaN != NaN)
        if isinstance(value, float) and value != value:
            return None
        return value

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("utf-8", errors="replace")

    # Lazy numpy / pandas imports so the helper works even without them
    try:
        import numpy as np  # type: ignore

        if isinstance(value, np.generic):
            scalar = value.item()
            # Re-run through to_serializable to catch NaN etc.
            return to_serializable(scalar)
        if isinstance(value, np.ndarray):
            return [to_serializable(v) for v in value.tolist()]
    except ImportError:
        pass

    try:
        import pandas as pd  # type: ignore

        if isinstance(value, pd.Timestamp):
            if pd.isna(value):
                return None
            return value.isoformat()
        if value is pd.NaT:
            return None
        if isinstance(value, pd.Timedelta):
            return str(value)
    except ImportError:
        pass

    if isinstance(value, (list, tuple)):
        return [to_serializable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): to_serializable(v) for k, v in value.items()}

    # Last resort — stringify
    return str(value)


def df_to_records(df: Any) -> list[dict]:
    """
    Convert a pandas DataFrame (or anything iterable of rows) into a
    JSON-serialisable ``list[dict]``.

    NaN / NaT values are replaced with ``None``. Timestamps are turned into
    ISO-format strings. Numpy scalars are unwrapped to Python primitives.

    Args:
        df: pandas DataFrame, list of dicts, or None.

    Returns:
        list[dict] — empty list if df is None or empty.
    """
    if df is None:
        return []

    # Already a plain list-of-dicts?
    if isinstance(df, list):
        return [
            {str(k): to_serializable(v) for k, v in row.items()}
            for row in df
            if isinstance(row, dict)
        ]

    try:
        import pandas as pd  # type: ignore
    except ImportError:
        return []

    if not isinstance(df, pd.DataFrame):
        # Best-effort coercion
        try:
            df = pd.DataFrame(df)
        except Exception:
            return []

    if df.empty:
        return []

    # Replace NaN with None via `where`, then normalise every cell
    cleaned = df.where(df.notna(), other=None)
    raw_records = cleaned.to_dict(orient="records")
    return [
        {str(k): to_serializable(v) for k, v in row.items()}
        for row in raw_records
    ]
