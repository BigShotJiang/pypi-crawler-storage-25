# vnstock-mcp-advanced

An MCP (Model Context Protocol) server that exposes Vietnamese stock market data via the [vnstock](https://github.com/thinh-vu/vnstock) libraries to Claude Desktop, Claude Code, Cursor, Windsurf, and any other MCP-compatible client.

Ships ~60 tools covering core market data, company intelligence, trading flows, macro indicators, commodities, plus composite analyses and professional-grade screeners.

## Install

With [uv](https://docs.astral.sh/uv/) (recommended — no permanent install needed):

```bash
uvx vnstock-mcp-advanced
```

Or with pip:

```bash
pip install vnstock-mcp-advanced
vnstock-mcp-advanced
```

## Configuration

| Env var | Description | Default |
| --- | --- | --- |
| `VNSTOCK_USER_TIER` | `free`, `bronze`, `silver`, or `golden` | `free` |
| `VNSTOCK_API_KEY` | Optional API key (higher rate limits) | _unset_ |

Sponsored tiers (bronze/silver/golden) unlock additional tools such as foreign/prop trading flows, macro indicators, commodities, and the insights screener. All libraries (`vnstock` + `vnstock_data`) are bundled — one install gets everything. Your API key and tier control which features are available at runtime.

## Claude Desktop

Add to `claude_desktop_config.json`:

**Free tier** (no API key needed):
```json
{
  "mcpServers": {
    "vnstock": {
      "command": "uvx",
      "args": ["vnstock-mcp-advanced"],
      "env": {
        "VNSTOCK_USER_TIER": "free"
      }
    }
  }
}
```

**Sponsored tiers** (set your tier and API key):
```json
{
  "mcpServers": {
    "vnstock": {
      "command": "uvx",
      "args": ["vnstock-mcp-advanced"],
      "env": {
        "VNSTOCK_USER_TIER": "bronze",
        "VNSTOCK_API_KEY": "your-api-key"
      }
    }
  }
}
```

## Claude Code

```bash
claude mcp add vnstock -- uvx vnstock-mcp-advanced
```

## License

MIT
