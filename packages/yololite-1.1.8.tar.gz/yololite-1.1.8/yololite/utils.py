# yololite/utils.py
import os
import requests
from tqdm import tqdm

def download_weights(url: str, save_path: str):
    """
    Laddar ner en fil från en URL och visar en progress bar, 
    om filen inte redan finns lokalt.
    """
    # 1. Om filen redan finns, gör ingenting (sparar tid och bandbredd)
    if os.path.exists(save_path):
        return save_path
        
    print(f"⬇️ Downloading {os.path.basename(save_path)} from {url}...")
    
    # 2. Skapa mappen om den inte existerar (t.ex. om användaren anger 'weights/modell.pt')
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    
    # 3. Starta nedladdningen som en "stream" så vi inte kraschar RAM-minnet
    response = requests.get(url, stream=True)
    response.raise_for_status()  # Kastar ett fel direkt om länken är död (t.ex. 404)
    
    # 4. Hämta filens totala storlek för att kunna bygga en progress bar
    total_size = int(response.headers.get('content-length', 0))
    block_size = 1024  # Laddar ner 1 KB åt gången
    
    # 5. Ladda ner filen och uppdatera mätaren (tqdm)
    with open(save_path, 'wb') as file, tqdm(
        desc=os.path.basename(save_path),
        total=total_size,
        unit='iB',
        unit_scale=True,
        unit_divisor=1024,
    ) as bar:
        for data in response.iter_content(block_size):
            file.write(data)
            bar.update(len(data))
            
    print(f"✅ Download complete: {save_path}")
    return save_path