import argparse
import os
import time
from pathlib import Path
import cv2
import numpy as np
import torch
import tensorrt as trt
from torch.utils.data import DataLoader
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from tqdm import tqdm

# Vi återanvänder din bevisat fungerande logik från infer_onnx.py
def letterbox(im, new_size=640, color=(114, 114, 114)):
    h, w = im.shape[:2]
    scale = min(new_size / h, new_size / w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    im_resized = cv2.resize(im, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top = (new_size - nh) // 2
    left = (new_size - nw) // 2
    bottom, right = new_size - nh - top, new_size - nw - left
    im_padded = cv2.copyMakeBorder(im_resized, top, bottom, left, right,
                                   cv2.BORDER_CONSTANT, value=color)
    return im_padded, scale, (left, top)

def nms_np(boxes, scores, iou_th=0.5, max_det=300):
    if len(boxes) == 0: return np.array([], dtype=np.int64)
    x1, y1, x2, y2 = boxes.T
    areas = (x2 - x1).clip(0) * (y2 - y1).clip(0)
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        if len(keep) >= max_det: break
        xx1, yy1 = np.maximum(x1[i], x1[order[1:]]), np.maximum(y1[i], y1[order[1:]])
        xx2, yy2 = np.minimum(x2[i], x2[order[1:]]), np.minimum(y2[i], y2[order[1:]])
        w, h = (xx2 - xx1).clip(0), (yy2 - yy1).clip(0)
        iou = (w * h) / (areas[i] + areas[order[1:]] - (w * h) + 1e-6)
        order = order[1:][iou <= iou_th]
    return np.array(keep, dtype=np.int64)

class TRTEvaluator:
    def __init__(self, engine_path):
        self.logger = trt.Logger(trt.Logger.ERROR)
        trt.init_libnvinfer_plugins(self.logger, "")
        with open(engine_path, 'rb') as f, trt.Runtime(self.logger) as runtime:
            self.engine = runtime.deserialize_cuda_engine(f.read())
        self.context = self.engine.create_execution_context()
        self.inputs, self.outputs, self.bindings = [], [], []

        for i in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(i)
            is_input = self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT
            shape = tuple([1 if s == -1 else s for s in self.context.get_tensor_shape(name)])
            dtype = torch.float16 if self.engine.get_tensor_dtype(name) == trt.float16 else torch.float32
            if self.engine.get_tensor_dtype(name) == trt.uint8: dtype = torch.uint8
            
            tensor = torch.empty(shape, dtype=dtype, device='cuda')
            self.bindings.append(tensor.data_ptr())
            if is_input: self.inputs.append({"name": name, "tensor": tensor})
            else: self.outputs.append({"name": name, "tensor": tensor})

    def __call__(self, x):
        self.context.set_input_shape(self.inputs[0]["name"], tuple(x.shape))
        self.inputs[0]["tensor"].copy_(x)
        self.context.execute_v2(self.bindings)
        return {out["name"]: out["tensor"].clone() for out in self.outputs}

def load_labels(path, w, h):
    # Baserad på din fungerande polygon/bbox-laddare
    if not path.exists(): return None
    boxes, labels = [], []
    with open(path, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 5: continue
            c = int(float(parts[0]))
            coords = np.array([float(x) for x in parts[1:]])
            if len(coords) == 4:
                x, y, dw, dh = coords
                x1, y1 = (x - dw/2) * w, (y - dh/2) * h
                x2, y2 = (x + dw/2) * w, (y + dh/2) * h
            else:
                poly = coords.reshape(-1, 2)
                x1, y1 = poly[:, 0].min() * w, poly[:, 1].min() * h
                x2, y2 = poly[:, 0].max() * w, poly[:, 1].max() * h
            boxes.append([x1, y1, x2, y2]); labels.append(c)
    return {"boxes": torch.tensor(boxes), "labels": torch.tensor(labels)}

def main(args):
    model = TRTEvaluator(args.engine)
    metric = MeanAveragePrecision(iou_type=["bbox"])
    img_paths = sorted([p for p in Path(args.img_dir).glob("*") if p.suffix.lower() in ('.jpg','.png')])

    for p in tqdm(img_paths):
        img0 = cv2.imread(str(p))
        if img0 is None: continue
        h0, w0 = img0.shape[:2]

        # Preprocess[cite: 5, 6]
        lb, scale, (padx, pady) = letterbox(img0, args.img_size)
        # Ändra .uint8() till .to(torch.uint8) eller .byte()
        im = torch.from_numpy(cv2.cvtColor(lb, cv2.COLOR_BGR2RGB)).permute(2,0,1).unsqueeze(0).cuda().to(torch.uint8)

        # Inference
        outputs = model(im)
        
        # Postprocess (Hanterar både Decoded och Decoded_NMS format)
        if "output" in outputs:
            dets = outputs["output"][0].cpu().numpy()
            valid = dets[dets[:, 4] >= args.conf]
            boxes_pad, scores, classes = valid[:, :4], valid[:, 4], valid[:, 5].astype(int)
        else:
            boxes = outputs["boxes_xyxy"][0].cpu().numpy()
            logits = outputs["cls_logits"][0].cpu().numpy()
            scores_all = 1 / (1 + np.exp(-logits)) # Sigmoid[cite: 5]
            classes_all = scores_all.argmax(axis=-1)
            conf_all = scores_all.max(axis=-1)
            
            mask = conf_all >= args.conf
            boxes_p, scores_p, cls_p = boxes[mask], conf_all[mask], classes_all[mask]
            
            final_b, final_s, final_c = [], [], []
            for c in np.unique(cls_p):
                mc = (cls_p == c)
                keep = nms_np(boxes_p[mc], scores_p[mc], args.iou, 300)
                final_b.append(boxes_p[mc][keep]); final_s.append(scores_p[mc][keep])
                final_c.append(np.full(len(keep), c))
            
            if final_b:
                boxes_pad = np.concatenate(final_b); scores = np.concatenate(final_s); classes = np.concatenate(final_c)
            else:
                boxes_pad = np.zeros((0,4)); scores = np.array([]); classes = np.array([])

        # Back-map till originalbild[cite: 5, 6]
        boxes_px = boxes_pad.copy()
        boxes_px[:, [0, 2]] -= padx
        boxes_px[:, [1, 3]] -= pady
        boxes_px /= max(scale, 1e-6)
        
        # Update Metric
        gt = load_labels(Path(args.label_dir) / f"{p.stem}.txt", w0, h0)
        if gt:
            metric.update([{"boxes": torch.tensor(boxes_px), "scores": torch.tensor(scores), "labels": torch.tensor(classes)}], 
                          [gt])

    res = metric.compute()
    print(f"\nTRT mAP50: {res['map_50']:.4f} | mAP50-95: {res['map']:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", required=True)
    parser.add_argument("--img_dir", required=True)
    parser.add_argument("--label_dir", required=True)
    parser.add_argument("--img_size", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.001)
    parser.add_argument("--iou", type=float, default=0.6)
    main(parser.parse_args())
