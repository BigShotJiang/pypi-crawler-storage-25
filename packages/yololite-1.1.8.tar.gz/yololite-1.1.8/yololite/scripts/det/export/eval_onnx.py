import numpy as np
import cv2, os, sys
import torch
import time
import argparse
from pathlib import Path
from torchmetrics.detection.mean_ap import MeanAveragePrecision
import onnxruntime as ort
ROOT = os.getcwd()
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))
# Importera hjälpfunktioner direkt från ditt originalscript
from export.infer_onnx import letterbox, nms_np, build_session

class ONNXEvaluator:
    def __init__(self, model_path, providers="cuda", img_size=640, intra=0, inter=0):
        # Bygg session med inställningar från infer_onnx.py[cite: 1]
        self.sess = build_session(model_path, providers, intra, inter)
        self.in_name = self.sess.get_inputs()[0].name
        self.out_names = [o.name for o in self.sess.get_outputs()]
        self.img_size = img_size
        
        # Identifiera modelltyp (med eller utan NMS-graf)[cite: 1]
        self.has_nms = len(self.out_names) == 1 and self.out_names[0] == "output"
        
        # Initiera Torchmetrics mAP (COCO-standard)
        self.metric = MeanAveragePrecision(box_format='xyxy', iou_type='bbox')

    def _process_outputs(self, outputs, conf, iou, scale, padx, pady, w0, h0):
        """Hanterar post-processing baserat på infer_onnx.py logik[cite: 1]"""
        if self.has_nms:
            # Modellen returnerar [Batch, Max_Det, 6] (x1, y1, x2, y2, score, cls)[cite: 1]
            dets = outputs[0][0]
            mask = dets[:, 4] >= conf
            valid_dets = dets[mask]
            boxes_pad = valid_dets[:, :4]
            scores_pad = valid_dets[:, 4]
            classes = valid_dets[:, 5].astype(np.int64)
        else:
            # Decoded modell utan NMS. Outputs = ["boxes_xyxy", "obj_logits", "cls_logits"][cite: 1]
            boxes = outputs[self.out_names.index("boxes_xyxy")][0]
            cls_log = outputs[self.out_names.index("cls_logits")][0]
            
            # Sigmoid och konfidensberäkning[cite: 1]
            cls_sig = 1.0 / (1.0 + np.exp(-np.clip(cls_log, -50, 50)))
            scores = cls_sig.max(axis=-1)
            cls_id = cls_sig.argmax(axis=-1).astype(np.int64)

            m = scores > conf
            boxes_p, scores_p, cls_p = boxes[m], scores[m], cls_id[m]

            # TOP-K PRE FILTER
            topk = 30000

            if scores_p.shape[0] > topk:
                idx = np.argpartition(scores_p, -topk)[-topk:]

                boxes_p = boxes_p[idx]
                scores_p = scores_p[idx]
                cls_p = cls_p[idx]

            final_b, final_s, final_c = [], [], []

            for c in np.unique(cls_p):
                mc = (cls_p == c)

                keep = nms_np(
                    boxes_p[mc],
                    scores_p[mc],
                    iou,
                    300
                )

                if keep.size:
                    final_b.append(boxes_p[mc][keep])
                    final_s.append(scores_p[mc][keep])
                    final_c.append(
                        np.full((keep.size,), int(c), dtype=np.int64)
        )
            if final_b:
                boxes_pad = np.concatenate(final_b, 0)
                scores_pad = np.concatenate(final_s, 0)
                classes = np.concatenate(final_c, 0)
            else:
                boxes_pad = np.zeros((0,4), np.float32)
                scores_pad = np.zeros((0,), np.float32)
                classes = np.zeros((0,), np.int64)

        # Back-map till originalbild (skala och flytta)[cite: 1]
        boxes_px = boxes_pad.copy()
        boxes_px[:, [0, 2]] -= padx
        boxes_px[:, [1, 3]] -= pady
        boxes_px /= max(scale, 1e-6)
        boxes_px[:, [0, 2]] = np.clip(boxes_px[:, [0, 2]], 0, w0 - 1)
        boxes_px[:, [1, 3]] = np.clip(boxes_px[:, [1, 3]], 0, h0 - 1)
        
        return {"boxes": boxes_px, "scores": scores_pad, "labels": classes}

    def _load_yolo_labels(self, path, w, h):
        """Laddar YOLO .txt filer till XYXY format"""
        if not path.exists():
            return {"boxes": np.zeros((0, 4), dtype=np.float32), "labels": np.array([], dtype=np.int64)}
        
        with open(path, 'r') as f:
            lines = [line.split() for line in f.read().strip().splitlines() if line.strip()]
        
        labels, boxes = [], []
        for ln in lines:
            c, x, y, dw, dh = map(float, ln)
            x1 = (x - dw/2) * w
            y1 = (y - dh/2) * h
            x2 = (x + dw/2) * w
            y2 = (y + dh/2) * h
            boxes.append([x1, y1, x2, y2])
            labels.append(int(c))
            
        return {"boxes": np.array(boxes, dtype=np.float32), "labels": np.array(labels, dtype=np.int64)}

    def evaluate(self, img_dir, label_dir, conf_thres=0.001, iou_thres=0.6):
        img_paths = sorted([p for p in Path(img_dir).glob("*") if p.suffix.lower() in ('.jpg', '.jpeg', '.png')])
        
        model_times = []
        e2e_prod_times = [] # För att mäta realistisk hastighet

        for p in img_paths:
            img0 = cv2.imread(str(p))
            if img0 is None: continue
            h0, w0 = img0.shape[:2]

            # --- START E2E TIMER ---
            t_e2e_start = time.perf_counter()

            # 1. Preprocess
            lb, scale, (padx, pady) = letterbox(img0, self.img_size)
            im = cv2.cvtColor(lb, cv2.COLOR_BGR2RGB)
            im = np.transpose(im, (2, 0, 1))[None].astype(np.uint8)

            # 2. Model Inference
            t_inf_start = time.perf_counter()
            outputs = self.sess.run(self.out_names, {self.in_name: im})
            t_inf_end = time.perf_counter()
            
            # 3. Produktions-NMS (Mätning med realistisk tröskel 0.25)
            # Vi gör detta för att få en ärlig bild av hastigheten utan att mAP-tröskeln förstör
            _ = self._process_outputs(outputs, 0.25, iou_thres, scale, padx, pady, w0, h0)
            
            t_e2e_end = time.perf_counter()
            # --- SLUT E2E TIMER ---

            # Spara tider
            model_times.append((t_inf_end - t_inf_start) * 1000)
            e2e_prod_times.append((t_e2e_end - t_e2e_start) * 1000)

            # 4. Validerings-NMS (För mAP, körs utanför tidtagning)
            preds_map = self._process_outputs(outputs, conf_thres, iou_thres, scale, padx, pady, w0, h0)
            
            # Ground Truth och Metric Update
            gt_path = Path(label_dir) / f"{p.stem}.txt"
            targets_np = self._load_yolo_labels(gt_path, w0, h0)
            self.metric.update([self._to_tensor_dict(preds_map)], [self._to_tensor_dict(targets_np, is_gt=True)])

        results = self.metric.compute()
        
        return {
            "mAP_50": float(results["map_50"]),
            "mAP_50_95": float(results["map"]),
            "map_75": float(results["map_75"]),
            "aps": float(results["map_small"]),
            "apm": float(results["map_medium"]),
            "apl": float(results["map_large"]),
            "ars": float(results["mar_small"]),
            "arm": float(results["mar_medium"]),
            "arl": float(results["mar_large"]),
            "model_latency_ms": float(np.mean(model_times)),
            "e2e_latency_ms": float(np.mean(e2e_prod_times)),
            "real_fps": 1000.0 / np.mean(e2e_prod_times),
        }

    def _to_tensor_dict(self, d, is_gt=False):
        out = {
            "boxes": torch.from_numpy(d["boxes"]).float(),
            "labels": torch.from_numpy(d["labels"]).long()
        }
        if not is_gt:
            out["scores"] = torch.from_numpy(d["scores"]).float()
        return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--img_dir", required=True)
    ap.add_argument("--label_dir", required=True)
    ap.add_argument("--img_size", type=int, default=640)
    ap.add_argument("--providers", default="cuda")
    args = ap.parse_args()

    evaluator = ONNXEvaluator(args.model, args.providers, args.img_size)
    metrics = evaluator.evaluate(args.img_dir, args.label_dir)

    print("\n" + "="*30)
    print(f"Resultat för: {Path(args.model).name}")
    print(f"mAP@0.5:      {metrics['mAP_50']:.4f}")
    print(f"mAP@0.5:0.95:  {metrics['mAP_50_95']:.4f}")
    print(f"Inference:     {metrics['e2e_latency_ms']:.2f} ms")
    print(f"Throughput:    {metrics['real_fps']:.2f} FPS")
    print("="*30)

if __name__ == "__main__":
    main()