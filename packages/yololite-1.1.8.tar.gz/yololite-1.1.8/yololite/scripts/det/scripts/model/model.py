import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm


# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def autopad(k, p=None, d=1):
    if p is None:
        p = (k - 1) // 2 * d
    return p


def init_detect_bias(head_moduledict, num_classes, prior_prob=0.01):
    # Utan obj-loss initierar vi klass-biasen så att modellen initialt gissar på "bakgrund" (väldigt låga sannolikheter)
    cls_bias = -math.log((1 - prior_prob) / prior_prob)
    with torch.no_grad():
        # Fyll endast klass- och box-bias, eftersom 'obj' är borta
        head_moduledict["out"]["cls"].bias.fill_(cls_bias)
        head_moduledict["out"]["box"].bias.zero_()


def _flatten_level_outputs(outs, export_concat: bool):
    if not export_concat:
        return outs
    flat = []
    for p in outs:  # [B,A,S,S,E]
        B, A, S, _, E = p.shape
        flat.append(p.view(B, -1, E))
    return torch.cat(flat, dim=1)


def _pick_out_indices(feature_info, take: int = 3):
    n = len(feature_info)
    out_idx = list(range(n - take, n))
    reductions = [feature_info[i]["reduction"] for i in out_idx]
    chs = [feature_info[i]["num_chs"] for i in out_idx]
    return out_idx, reductions, chs


# ---------------------------------------------------------
# Basic blocks
# ---------------------------------------------------------

class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class Bottleneck(nn.Module):
    def __init__(self, c1, c2, shortcut=True, e=0.5):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        y = self.cv2(self.cv1(x))
        return x + y if self.add else y


class C2f(nn.Module):
    """
    YOLOv8-ish C2f block.
    """
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1, 1)
        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut=shortcut, e=1.0) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, dim=1))
        for m in self.m:
            y.append(m(y[-1]))
        return self.cv2(torch.cat(y, dim=1))


class SPPF(nn.Module):
    def __init__(self, c1, c2, k=5):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = self.m(y2)
        return self.cv2(torch.cat([x, y1, y2, y3], dim=1))


class Downsample(nn.Module):
    """
    Standard stride-2 conv.
    """
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = Conv(c1, c2, k=3, s=2)

    def forward(self, x):
        return self.conv(x)


# ---------------------------------------------------------
# Detection head
# ---------------------------------------------------------

def make_head(A, head_depth, C, fpn_channels):
    # En liten gemensam stem för att integrera features från necken
    stem = Conv(fpn_channels, fpn_channels, 3, 1)
    
    # Separata trunks för box och klassificering
    box_trunk = nn.Sequential(*[
        Conv(fpn_channels, fpn_channels, 3, 1) for _ in range(head_depth)
    ])
    cls_trunk = nn.Sequential(*[
        Conv(fpn_channels, fpn_channels, 3, 1) for _ in range(head_depth)
    ])
    
    # Utgångarna (nu endast box och cls)
    out_layers = nn.ModuleDict({
        "box": nn.Conv2d(fpn_channels, A * 4, 1),
        "cls": nn.Conv2d(fpn_channels, A * C, 1),
    })
    
    return nn.ModuleDict({
        "stem": stem,
        "box_trunk": box_trunk, 
        "cls_trunk": cls_trunk, 
        "out": out_layers
    })


# ---------------------------------------------------------
# New YOLOv8-ish Neck
# ---------------------------------------------------------

class NeckV8(nn.Module):
    """
    PAN-FPN neck with concat fusion and C2f blocks.

    Supports:
      - 3 inputs: c3, c4, c5  -> returns p3, p4, p5
      - 4 inputs: c2, c3, c4, c5 -> returns p2, p3, p4, p5
    """
    def __init__(
        self,
        in_channels,
        out_channels=256,
        depth=2,
        hidden_ratio=0.5,
        use_p2=False,
    ):
        super().__init__()
        self.use_p2 = use_p2

        if self.use_p2:
            assert len(in_channels) == 4, f"Expected 4 input channels for P2 mode, got {len(in_channels)}"
            c2, c3, c4, c5 = in_channels
            self.reduce_c2 = Conv(c2, out_channels, 1, 1)
        else:
            assert len(in_channels) == 3, f"Expected 3 input channels, got {len(in_channels)}"
            c3, c4, c5 = in_channels

        self.reduce_c3 = Conv(c3, out_channels, 1, 1)
        self.reduce_c4 = Conv(c4, out_channels, 1, 1)
        self.reduce_c5 = Conv(c5, out_channels, 1, 1)

        self.sppf = SPPF(out_channels, out_channels)

        # Top-down
        self.td_p4 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
        self.td_p3 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
        if self.use_p2:
            self.td_p2 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

        # Bottom-up
        if self.use_p2:
            self.down_p2 = Downsample(out_channels, out_channels)
            self.bu_p3 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

        self.down_p3 = Downsample(out_channels, out_channels)
        self.bu_p4 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

        self.down_p4 = Downsample(out_channels, out_channels)
        self.bu_p5 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

    def _up(self, x, target):
        return F.interpolate(x, size=target.shape[-2:], mode="nearest")

    def forward(self, feats):
        if self.use_p2:
            c2, c3, c4, c5 = feats
            c2 = self.reduce_c2(c2)
        else:
            c3, c4, c5 = feats

        c3 = self.reduce_c3(c3)
        c4 = self.reduce_c4(c4)
        c5 = self.reduce_c5(c5)

        p5 = self.sppf(c5)

        # Top-down
        p4_td = self.td_p4(torch.cat([self._up(p5, c4), c4], dim=1))
        p3_td = self.td_p3(torch.cat([self._up(p4_td, c3), c3], dim=1))

        if self.use_p2:
            p2_td = self.td_p2(torch.cat([self._up(p3_td, c2), c2], dim=1))

            # Bottom-up
            p3_out = self.bu_p3(torch.cat([self.down_p2(p2_td), p3_td], dim=1))
            p4_out = self.bu_p4(torch.cat([self.down_p3(p3_out), p4_td], dim=1))
            p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))

            return p2_td, p3_out, p4_out, p5_out

        # No P2
        p4_out = self.bu_p4(torch.cat([self.down_p3(p3_td), p4_td], dim=1))
        p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))

        return p3_td, p4_out, p5_out


# ---------------------------------------------------------
# Full model
# ---------------------------------------------------------

class YOLOE(nn.Module):
    def __init__(
        self,
        backbone="mobilenetv4_conv_small",
        num_classes=3,
        fpn_channels=256,
        num_anchors_per_level=(1, 1, 1, 1),
        pretrained=True,
        depth_multiple=1.0,
        width_multiple=1.0,
        head_depth=2,
        neck_depth=2,
        neck_hidden_ratio=0.25,
        use_p2=False,
        use_p6=False,
    ):
        super().__init__()

        tmp = timm.create_model(backbone, features_only=True, pretrained=pretrained)
        take = 4 if use_p2 else 3
        out_idx, reductions, chs = _pick_out_indices(tmp.feature_info, take=take)

        self.backbone = timm.create_model(
            backbone,
            features_only=True,
            pretrained=pretrained,
            out_indices=out_idx,
        )

        self.use_p2 = use_p2
        self.use_p6 = use_p6
        self.num_classes = num_classes

        fpn_channels = int(fpn_channels * width_multiple)
        neck_depth = max(1, int(round(neck_depth * depth_multiple)))
        head_depth = max(1, int(round(head_depth * depth_multiple)))

        self.neck = NeckV8(
            in_channels=chs,
            out_channels=fpn_channels,
            depth=neck_depth,
            hidden_ratio=neck_hidden_ratio,
            use_p2=use_p2,
        )

        if self.use_p6:
            self.p6_down = Downsample(fpn_channels, fpn_channels)
            self.p6_c2f = C2f(
                fpn_channels,
                fpn_channels,
                n=max(1, neck_depth - 1),
                shortcut=False,
                e=neck_hidden_ratio,
            )

        self.level_names = (["p2"] if self.use_p2 else []) + ["p3", "p4", "p5"] + (["p6"] if self.use_p6 else [])

        if len(num_anchors_per_level) >= 3:
            A3, A4, A5 = map(int, num_anchors_per_level[:3])
            A2 = A3
            A6 = A5
        else:
            base_a = int(num_anchors_per_level[0]) if len(num_anchors_per_level) else 1
            A2 = A3 = A4 = A5 = A6 = base_a

        anchors_map = {"p2": A2, "p3": A3, "p4": A4, "p5": A5, "p6": A6}
        self.num_anchors_per_level = tuple(anchors_map[name] for name in self.level_names)

        if self.use_p2:
            self.head2 = make_head(anchors_map["p2"], head_depth, num_classes, fpn_channels)
            init_detect_bias(self.head2, num_classes)

        self.head3 = make_head(anchors_map["p3"], head_depth, num_classes, fpn_channels)
        self.head4 = make_head(anchors_map["p4"], head_depth, num_classes, fpn_channels)
        self.head5 = make_head(anchors_map["p5"], head_depth, num_classes, fpn_channels)

        init_detect_bias(self.head3, num_classes)
        init_detect_bias(self.head4, num_classes)
        init_detect_bias(self.head5, num_classes)

        if self.use_p6:
            self.head6 = make_head(anchors_map["p6"], head_depth, num_classes, fpn_channels)
            init_detect_bias(self.head6, num_classes)

        self.fpn_strides = list(reductions) + ([reductions[-1] * 2] if self.use_p6 else [])
        self.export_concat = False

    def _forward_head(self, p, head_dict, A):
        # Passera genom gemensam stem
        p = head_dict["stem"](p)
        
        # Förgrena datan
        p_box = head_dict["box_trunk"](p)
        p_cls = head_dict["cls_trunk"](p)

        # Prediktera (obj är nu borta)
        box = head_dict["out"]["box"](p_box)
        cls = head_dict["out"]["cls"](p_cls)

        B, _, S, _ = box.shape
        box = box.view(B, A, 4, S, S)
        cls = cls.view(B, A, self.num_classes, S, S)

        # Concatenera enbart box (4 koordinater) och cls (C klasser)
        out = torch.cat([box, cls], dim=2)
        return out.permute(0, 1, 3, 4, 2).contiguous()

    def forward(self, x):
        feats = self.backbone(x)
        neck_out = self.neck(feats)

        outs = []

        if self.use_p2:
            p2, p3, p4, p5 = neck_out
            outs.append(self._forward_head(p2, self.head2, self.num_anchors_per_level[0]))
            idx = 1
        else:
            p3, p4, p5 = neck_out
            idx = 0

        outs.append(self._forward_head(p3, self.head3, self.num_anchors_per_level[idx + 0]))
        outs.append(self._forward_head(p4, self.head4, self.num_anchors_per_level[idx + 1]))
        outs.append(self._forward_head(p5, self.head5, self.num_anchors_per_level[idx + 2]))

        if self.use_p6:
            p6 = self.p6_c2f(self.p6_down(p5))
            outs.append(self._forward_head(p6, self.head6, self.num_anchors_per_level[idx + 3]))

        return _flatten_level_outputs(outs, self.export_concat)

    def get_strides(self):
        return list(self.fpn_strides)

    def get_num_anchors_per_level(self):
        return tuple(self.num_anchors_per_level)

    def print_strides(self, img_size=640):
        with torch.no_grad():
            d = next(self.parameters()).device
            x = torch.zeros(1, 3, img_size, img_size, device=d)
            feats = self.backbone(x)
            neck_out = self.neck(feats)

            grid_sizes = [p.shape[-1] for p in neck_out]
            if self.use_p6:
                p5 = neck_out[-1]
                p6 = self.p6_c2f(self.p6_down(p5))
                grid_sizes.append(p6.shape[-1])

            strides = [img_size // s for s in grid_sizes]
            