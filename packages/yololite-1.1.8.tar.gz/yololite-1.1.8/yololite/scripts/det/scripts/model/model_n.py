import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm


# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def autopad(k, p=None, d=1):
    if p is None:
        p = (k - 1) // 2 * d
    return p


def init_detect_bias(head_moduledict, num_classes, prior_prob=0.01):
    # Utan obj-loss initierar vi klass-biasen så att modellen initialt gissar på "bakgrund" (väldigt låga sannolikheter)
    cls_bias = -math.log((1 - prior_prob) / prior_prob)
    with torch.no_grad():
        # Fyll endast klass- och box-bias, eftersom 'obj' är borta
        head_moduledict["out"]["cls"].bias.fill_(cls_bias)
        head_moduledict["out"]["box"].bias.zero_()


def _flatten_level_outputs(outs, export_concat: bool):
    if not export_concat:
        return outs
    flat = []
    for p in outs:  # [B,A,S,S,E]
        B, A, S, _, E = p.shape
        flat.append(p.view(B, -1, E))
    return torch.cat(flat, dim=1)


def _pick_out_indices(feature_info, take: int = 3):
    n = len(feature_info)
    out_idx = list(range(n - take, n))
    reductions = [feature_info[i]["reduction"] for i in out_idx]
    chs = [feature_info[i]["num_chs"] for i in out_idx]
    return out_idx, reductions, chs


import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm

# ... (Håll kvar dina Helpers: autopad, init_detect_bias, _flatten_level_outputs, _pick_out_indices) ...

# ---------------------------------------------------------
# 1. Nano-Specific Building Blocks (Optimized)
# ---------------------------------------------------------
class LightConv(nn.Module):
    """Depthwise Separable Convolution för att kapa FLOPs drastiskt."""
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        # Om k=3, kör vi depthwise. Om k=1, kör vi vanlig (pointwise).
        if k > 1:
            self.conv = nn.Sequential(
                nn.Conv2d(c1, c1, k, s, autopad(k, p), groups=c1, bias=False), # Depthwise
                nn.Conv2d(c1, c2, 1, 1, 0, bias=False), # Pointwise
            )
        else:
            self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), bias=False)
            
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class GhostConv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__()
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, p=None, g=g, act=act)
        self.cv2 = Conv(c_, c_, 3, 1, p=None, g=c_, act=act)

    def forward(self, x):
        y = self.cv1(x)
        return torch.cat([y, self.cv2(y)], 1)

class NanoC2f(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(
            nn.Sequential(
                nn.Conv2d(self.c, self.c, 3, 1, 1, groups=self.c, bias=False),
                nn.BatchNorm2d(self.c),
                nn.SiLU(inplace=True)
            ) for _ in range(n)
        )

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, dim=1))
        for m in self.m:
            y.append(m(y[-1]))
        return self.cv2(torch.cat(y, dim=1))

class SPPF(nn.Module):
    def __init__(self, c1, c2, k=5):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = self.m(y2)
        return self.cv2(torch.cat([x, y1, y2, y3], dim=1))

# ---------------------------------------------------------
# 2. Nano Detection Head
# ---------------------------------------------------------

class NanoHead(nn.Module):
    def __init__(self, in_chs, num_classes, A=1):
        super().__init__()
        # En gemensam lättviktsstem istället för tunga trunks
        self.stem = GhostConv(in_chs, in_chs, 3)
        self.conv_box = nn.Conv2d(in_chs, A * 4, 1)
        self.conv_cls = nn.Conv2d(in_chs, A * num_classes, 1)

    def forward(self, x):
        x = self.stem(x)
        box = self.conv_box(x)
        cls = self.conv_cls(x)
        return box, cls

# ---------------------------------------------------------
# 3. Nano Neck with Asymmetric Scaling
# ---------------------------------------------------------

class NanoNeckV8(nn.Module):
    def __init__(self, in_channels, out_channels=64, depth=2, use_p2=False):
        super().__init__()
        self.use_p2 = use_p2
        
        # Vi skalar kanalerna för att spara FLOPs på hög upplösning (P2)
        self.c_p2 = int(out_channels * 0.5)
        self.c_p3 = int(out_channels * 0.75)
        self.c_p4 = out_channels
        self.c_p5 = int(out_channels * 2.0) 

        if use_p2:
            self.reduce_c2 = LightConv(in_channels[0], self.c_p2, 1, 1)
            self.reduce_c3 = LightConv(in_channels[1], self.c_p3, 1, 1)
            self.reduce_c4 = LightConv(in_channels[2], self.c_p4, 1, 1)
            self.reduce_c5 = LightConv(in_channels[3], self.c_p5, 1, 1)
        else:
            self.reduce_c3 = LightConv(in_channels[0], self.c_p3, 1, 1)
            self.reduce_c4 = LightConv(in_channels[1], self.c_p4, 1, 1)
            self.reduce_c5 = LightConv(in_channels[2], self.c_p5, 1, 1)

        self.sppf = SPPF(self.c_p5, self.c_p5, k=5)

        # Top-down
        self.td_p4 = NanoC2f(self.c_p5 + self.c_p4, self.c_p4, n=depth)
        self.td_p3 = NanoC2f(self.c_p4 + self.c_p3, self.c_p3, n=depth)
        if use_p2:
            self.td_p2 = NanoC2f(self.c_p3 + self.c_p2, self.c_p2, n=depth)

        # Bottom-up
        if use_p2:
            self.down_p2 = LightConv(self.c_p2, self.c_p2, 3, 2)
            self.bu_p3 = NanoC2f(self.c_p2 + self.c_p3, self.c_p3, n=depth)
        
        self.down_p3 = LightConv(self.c_p3, self.c_p3, 3, 2)
        self.bu_p4 = NanoC2f(self.c_p3 + self.c_p4, self.c_p4, n=depth)
        
        self.down_p4 = LightConv(self.c_p4, self.c_p4, 3, 2)
        self.bu_p5 = NanoC2f(self.c_p4 + self.c_p5, self.c_p5, n=depth)

        # För att YOLOE ska veta vilka kanaler som går in i varje huvud
        self.out_channels_list = [self.c_p2, self.c_p3, self.c_p4, self.c_p5] if use_p2 else [self.c_p3, self.c_p4, self.c_p5]

    def _up(self, x, target):
        return F.interpolate(x, size=target.shape[-2:], mode="nearest")

    def forward(self, feats):
        if self.use_p2:
            c2, c3, c4, c5 = feats
            c2, c3, c4, c5 = self.reduce_c2(c2), self.reduce_c3(c3), self.reduce_c4(c4), self.reduce_c5(c5)
        else:
            c3, c4, c5 = feats
            c3, c4, c5 = self.reduce_c3(c3), self.reduce_c4(c4), self.reduce_c5(c5)

        p5 = self.sppf(c5)
        p4_td = self.td_p4(torch.cat([self._up(p5, c4), c4], dim=1))
        p3_td = self.td_p3(torch.cat([self._up(p4_td, c3), c3], dim=1))

        if self.use_p2:
            p2_td = self.td_p2(torch.cat([self._up(p3_td, c2), c2], dim=1))
            p3_out = self.bu_p3(torch.cat([self.down_p2(p2_td), p3_td], dim=1))
            p4_out = self.bu_p4(torch.cat([self.down_p3(p3_out), p4_td], dim=1))
            p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
            return p2_td, p3_out, p4_out, p5_out

        p4_out = self.bu_p4(torch.cat([self.down_p3(p3_td), p4_td], dim=1))
        p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
        return p3_td, p4_out, p5_out

# ---------------------------------------------------------
# 4. Final Integrated Nano YOLOE
# ---------------------------------------------------------

class YOLOE_Nano(nn.Module):
    def __init__(
        self,
        backbone="mobilenetv4_conv_small",
        num_classes=3,
        fpn_channels=128, # Mycket lägre för Nano
        pretrained=True,
        use_p2=False,
    ):
        super().__init__()
        
        # 1. Backbone
        tmp = timm.create_model(backbone, features_only=True, pretrained=pretrained)
        take = 4 if use_p2 else 3
        out_idx, reductions, chs = _pick_out_indices(tmp.feature_info, take=take)
        self.backbone = timm.create_model(backbone, features_only=True, pretrained=pretrained, out_indices=out_idx)

        # 2. Nano Neck
        self.neck = NanoNeckV8(in_channels=chs, out_channels=fpn_channels, use_p2=use_p2)

        # 3. Nano Heads
        self.heads = nn.ModuleList([
            NanoHead(ch, num_classes) for ch in self.neck.out_channels_list
        ])

        # Bias Init
        for m in self.heads:
            # Enkel init för NanoHead (som nu är nn.Module istället för ModuleDict)
            cls_bias = -math.log((1 - 0.01) / 0.01)
            m.conv_cls.bias.data.fill_(cls_bias)
            m.conv_box.bias.data.zero_()

        self.fpn_strides = reductions
        self.num_classes = num_classes

    def forward(self, x):
        feats = self.backbone(x)
        neck_outs = self.neck(feats)

        final_outs = []
        for i, p in enumerate(neck_outs):
            box, cls = self.heads[i](p)
            
            # Shape-hantering för loss (B, A, C+4, S, S)
            B, _, S, _ = box.shape
            # Vi antar A=1 här för Nano
            out = torch.cat([box.view(B, 1, 4, S, S), 
                             cls.view(B, 1, self.num_classes, S, S)], dim=2)
            final_outs.append(out.permute(0, 1, 3, 4, 2).contiguous())

        return _flatten_level_outputs(final_outs, export_concat=False)