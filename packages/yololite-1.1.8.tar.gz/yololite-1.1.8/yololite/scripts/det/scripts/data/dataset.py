import os, sys
import cv2
import torch
import random
import numpy as np
from pathlib import Path
from torch.utils.data import Dataset
from tqdm import tqdm
import psutil

from .augment import get_mosaic_transform

class YoloDataset(Dataset):
    def __init__(self, img_dir, label_dir, transforms, img_size=640, is_train=True, mosaic_p=0.0):
        self.img_dir = Path(img_dir)
        self.label_dir = Path(label_dir)
        self.mosaic_p = mosaic_p
        # --- FIX: Använd os.scandir korrekt ---
        # Vi måste plocka ut .path från entryt, annars får vi <DirEntry object>
        valid_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}
        self.img_files = []
        
        # os.scandir är snabbt, men vi måste hantera det som en iterator
        # Om self.img_dir är ett Path-objekt, konvertera till sträng för os.scandir
        if os.path.exists(self.img_dir):
            with os.scandir(str(self.img_dir)) as entries:
                for entry in entries:
                    if entry.is_file() and os.path.splitext(entry.name)[1].lower() in valid_exts:
                        self.img_files.append(entry.path) # VIKTIGT: .path
        
        # Sortera för att garantera ordning (viktigt för determinism)
        self.img_files.sort()
        
        if len(self.img_files) == 0:
            raise ValueError(f"No images found in {self.img_dir}")

        self.img_size = img_size
        self.is_train = is_train
        self.transforms = transforms
        self.mosaic_transform = get_mosaic_transform(self.img_size)
        # --- RAM-CHECK ---
        # Uppskatta storlek: img_size * img_size * 3 (kanaler) * antal bilder
        # Vi lägger till en marginal (t.ex. 2.0) för Python-overhead och augmentationer
        self.imgs_cache = [None] * len(self.img_files)
        estimated_cache_gb = (len(self.img_files) * (self.img_size**2) * 3 * 2.0) / (1024**3)
        available_ram_gb = psutil.virtual_memory().available / (1024**3)
        
        self.use_cache = True
        if estimated_cache_gb > (available_ram_gb * 0.7): # Använd max 70% av ledigt RAM
            print(f"[Warning] Estimated cache ({estimated_cache_gb:.1f}GB) exceeds safe limit. Disabling image cache.")
            self.use_cache = False
        # --- CACHING ---
        print(f"Caching labels for {len(self.img_files)} images...")
        self.labels_cache = self._cache_labels()

        
    def _cache_labels(self):
        """Läser alla .txt filer och sparar i en lista av np.arrays."""
        cache = []
        # Använd tqdm för att se progress vid start
        for img_path in tqdm(self.img_files, desc="Loading labels"):
            label_path = self.label_dir / (Path(img_path).stem + ".txt")
            boxes = []
            if label_path.exists():
                try:
                    # Snabbare att läsa hela filen och splitta i minnet
                    with open(label_path, 'r') as f:
                        lines = f.readlines()
                    
                    for line in lines:
                        parts = line.strip().split()
                        if len(parts) >= 5: # Klassisk YOLO
                            # Hantera både vanlig YOLO och segmentering (förenklad)
                            cls = int(parts[0])
                            coords = np.array([float(x) for x in parts[1:]], dtype=np.float32)
                            
                            if len(coords) > 4: # Segmentering -> gör om till bbox
                                coords = coords.reshape(-1, 2)
                                xmin, ymin = coords.min(axis=0)
                                xmax, ymax = coords.max(axis=0)
                                xc, yc = (xmin + xmax) / 2, (ymin + ymax) / 2
                                w, h = (xmax - xmin), (ymax - ymin)
                            else:
                                xc, yc, w, h = coords[:4]
                            
                            # Spara normalized [cls, xc, yc, w, h]
                            boxes.append([cls, xc, yc, w, h])
                except Exception:
                    pass
            
            # Spara som numpy array för snabbare indexering senare [N, 5]
            if boxes:
                cache.append(np.array(boxes, dtype=np.float32))
            else:
                cache.append(np.zeros((0, 5), dtype=np.float32))
        return cache
    def get_image_weights(
    self,
    rare_power=0.5,            # 0.5 = 1/sqrt(freq)
    rare_w=1.0,                # hur mycket sällsynta klasser ska påverka
    small_thr=0.01,            # normalized area threshold
    very_small_thr=0.003,
    small_w=0.35,
    very_small_w=0.75,
    count_dampen=0.35,         # dämpar bilder med många objekt
    empty_weight=0.2,          # tomma bilder ska finnas men inte dominera
    min_weight=0.25,
    max_weight=3.0,
                        ):
       
        all_labels = []
        max_cls = 0

        # 1) global klassfrekvens
        for label in self.labels_cache:
            if label.shape[0] > 0:
                cls_ids = label[:, 0].astype(int)
                all_labels.extend(cls_ids.tolist())
                max_cls = max(max_cls, int(cls_ids.max()))

        if not all_labels:
            return torch.ones(len(self), dtype=torch.float32)

        cls_counts = np.bincount(np.array(all_labels, dtype=np.int64), minlength=max_cls + 1)
        cls_counts = np.maximum(cls_counts, 1)

        # sällsynta klasser får högre score
        cls_weights = 1.0 / np.power(cls_counts.astype(np.float32), rare_power)

        image_weights = []

        for label in self.labels_cache:
            if label.shape[0] == 0:
                image_weights.append(empty_weight)
                continue

            cls_ids = label[:, 0].astype(np.int64)
            wh = label[:, 3:5].astype(np.float32)   # normalized w,h
            areas = wh[:, 0] * wh[:, 1]
            num_objects = len(cls_ids)

            # Rare-class score:
            # medel i stället för summa -> mindre bias mot många objekt
            rare_score = float(cls_weights[cls_ids].mean())

            # Small object counts
            num_small = int((areas < small_thr).sum())
            num_very_small = int((areas < very_small_thr).sum())

            # Bygg vikt
            weight = 1.0
            weight += rare_w * rare_score
            weight += small_w * num_small
            weight += very_small_w * num_very_small

            # Dämpa bilder med många objekt
            weight /= max(1.0, float(num_objects) ** count_dampen)

            # Clamp
            weight = float(np.clip(weight, min_weight, max_weight))
            image_weights.append(weight)

        image_weights = np.array(image_weights, dtype=np.float32)

        # Normalisera så medel blir ~1.0
        image_weights = image_weights / max(image_weights.mean(), 1e-6)

        return torch.tensor(image_weights, dtype=torch.float32)
    def __len__(self):
        return len(self.img_files)
    def load_resized_image_and_labels(self, idx):
        # 1. Hämta från cache om det är aktiverat och bilden finns
        if self.use_cache and self.imgs_cache[idx] is not None:
            img, h0, w0 = self.imgs_cache[idx]
            boxes, labels = self.load_label_processed(idx, h0, w0)
            return img.copy(), boxes, labels, h0, w0

        # 2. Ladda och skala om (din optimerade kod)
        img = self.load_image(idx)
        h0, w0 = img.shape[:2]
        r = self.img_size / max(h0, w0)
        
        if r < 1.0:
            new_w, new_h = int(w0 * r), int(h0 * r)
            img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            h0, w0 = new_h, new_w

        # 3. Spara i cache BARA om vakten tillåter det
        if self.use_cache:
            self.imgs_cache[idx] = (img, h0, w0)

        boxes, labels = self.load_label_processed(idx, h0, w0)
        return img.copy(), boxes, labels, h0, w0

    def load_image(self, idx):
        """Läser enbart bilden (I/O tungt)."""
        img = cv2.imread(self.img_files[idx], cv2.IMREAD_COLOR)
        img = img[:, :, ::-1]  # BGR → RGB (view, ingen kopia!)
        if img is None:
            raise ValueError(f"Image not found or corrupt: {self.img_files[idx]}")
        return img

    def load_label_processed(self, idx, img_h, img_w):
        """Hämtar label från cache och konverterar till [x1, y1, x2, y2]."""
        # data är [N, 5] -> cls, xc, yc, w, h (normalized)
        data = self.labels_cache[idx]
        if data.shape[0] == 0:
            return np.zeros((0, 4), dtype=np.float32), np.zeros((0,), dtype=np.int64)

        cls = data[:, 0].astype(np.int64)
        xywh = data[:, 1:]

        # Vektoriserad konvertering xywh -> xyxy
        # x_min = (xc - w/2) * img_w
        x1 = (xywh[:, 0] - xywh[:, 2] / 2) * img_w
        y1 = (xywh[:, 1] - xywh[:, 3] / 2) * img_h
        x2 = (xywh[:, 0] + xywh[:, 2] / 2) * img_w
        y2 = (xywh[:, 1] + xywh[:, 3] / 2) * img_h
        
        boxes = np.stack([x1, y1, x2, y2], axis=1)
        return boxes, cls

    def _clip_boxes(self, boxes, h, w):
        """NumPy optimerad clipping."""
        if len(boxes) == 0:
            return boxes
        # np.clip är extremt snabbt
        boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, w)
        boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, h)
        return boxes
# ------------------ Patch Mosaic (Optimerad för små objekt med dynamisk zoom) ------------------
    def mosaic_v1(self, index):
        indices = [index] + random.choices(range(len(self)), k=3)
        
        # Målet är en canvas på img_size x img_size (t.ex. 640x640)
        s = self.img_size
        patch_s = s  # Varje klipp blir exakt hälften (t.ex. 320x320)
        
        mosaic_img = np.full((s*2, s*2, 3), 114, dtype=np.uint8)
        offsets = [(0, 0), (0, patch_s), (patch_s, 0), (patch_s, patch_s)] 
        
        all_boxes, all_labels = [], []

        for i, idx in enumerate(indices):
            
            img, boxes, labels, h, w = self.load_resized_image_and_labels(idx)
            
            

            # --- 1. SAFE RANDOM RESIZED CROP (Låst till 1:1 Aspect Ratio) ---
            # Vi tillåter att klippa en ruta som är allt från 160x160 upp till originalbildens maxstorlek
            max_possible_crop = min(h, w)
            min_crop = min(int(patch_s * 0.5), max_possible_crop) 
            
            # Välj slumpmässig storlek på utsnittet
            crop_size = random.randint(min_crop, max_possible_crop)
            
            # Slumpa var utsnittet tas
            x_offset = random.randint(0, max(0, w - crop_size))
            y_offset = random.randint(0, max(0, h - crop_size))
            
            crop_img = img[y_offset:y_offset + crop_size, x_offset:x_offset + crop_size]

            # Skala om det dynamiska utsnittet till den fasta patchen (320x320)
            patch = cv2.resize(crop_img, (patch_s, patch_s), interpolation=cv2.INTER_LINEAR)

            # --- 2. Justera Boxarna ---
            if len(boxes) > 0:
                boxes = boxes.copy().astype(np.float32)
                
                # A. Flytta origo så boxarna blir relativa till vårt utsnitt
                boxes[:, [0, 2]] -= x_offset
                boxes[:, [1, 3]] -= y_offset

                # B. Skala boxarna proportionerligt med bilduppskalningen/nedskalningen
                scale_factor = patch_s / float(crop_size)
                boxes *= scale_factor

                # C. Klipp av boxar som hamnar utanför den nya patchens ramar (patch_s)
                boxes[:, [0, 2]] = np.clip(boxes[:, [0, 2]], 0, patch_s)
                boxes[:, [1, 3]] = np.clip(boxes[:, [1, 3]], 0, patch_s)

                # D. Kasta bort "spök-boxar"
                bw = boxes[:, 2] - boxes[:, 0]
                bh = boxes[:, 3] - boxes[:, 1]
                
                # Höjt kravet något (4x4 pixlar) eftersom vi ibland zomar in (skalar upp)
                valid = (bw > 4) & (bh > 4)  
                
                boxes = boxes[valid]
                labels_valid = labels[valid]
            else:
                boxes = np.zeros((0, 4), dtype=np.float32)
                labels_valid = np.zeros((0,), dtype=np.int64)

            # --- 3. Placera i mosaik-canvasen ---
            oy, ox = offsets[i]
            mosaic_img[oy:oy + patch_s, ox:ox + patch_s] = patch

            # Lägg på mosaik-offseten på boxarna
            if len(boxes) > 0:
                boxes[:, [0, 2]] += ox
                boxes[:, [1, 3]] += oy
                
                all_boxes.append(boxes)
                all_labels.append(labels_valid)

        # --- 4. Slå ihop allt med numpy ---
        if all_boxes:
            final_boxes = np.vstack(all_boxes)
            final_labels = np.concatenate(all_labels)
            return mosaic_img, final_boxes, final_labels
        else:
            return mosaic_img, np.zeros((0, 4), dtype=np.float32), np.zeros((0,), dtype=np.int64)
    def mosaic(self, index, dominant_ratio_range=(0.65, 0.8)):
        indices = [index] + random.choices(range(len(self)), k=3)

        s = self.img_size
        mosaic_img = np.full((s * 2, s * 2, 3), 114, dtype=np.uint8)

        all_boxes, all_labels = [], []

        # Hur stor del huvudbilden ska ta
        dom_r = random.uniform(*dominant_ratio_range)

        # Huvudbildens storlek i canvas
        main_w = int(2 * s * dom_r)
        main_h = int(2 * s * dom_r)

        # Begränsa så vi alltid får plats med sidopatchar
        main_w = min(max(main_w, int(1.2 * s)), int(1.7 * s))
        main_h = min(max(main_h, int(1.2 * s)), int(1.7 * s))

        # Layout:
        # [ main      | top-right ]
        # [           |           ]
        # [-----------+-----------]
        # [ bot-left  | bot-right ]
        #
        # Main dominerar övre vänstra delen.
        regions = [
            (0, 0, main_w, main_h),                 # huvudbild
            (0, main_w, 2 * s - main_w, main_h),   # höger uppe
            (main_h, 0, main_w, 2 * s - main_h),   # vänster nere
            (main_h, main_w, 2 * s - main_w, 2 * s - main_h),  # höger nere
        ]

        for i, idx in enumerate(indices):
            img, boxes, labels, h, w = self.load_resized_image_and_labels(idx)

            rx, ry, rw, rh = regions[i][1], regions[i][0], regions[i][2], regions[i][3]

            if rw <= 0 or rh <= 0:
                continue

            # Resize direkt till regionens storlek
            img_resized = cv2.resize(img, (rw, rh))

            if len(boxes) > 0:
                boxes = boxes.copy().astype(np.float32)
                scale_x = rw / w
                scale_y = rh / h
                boxes[:, [0, 2]] *= scale_x
                boxes[:, [1, 3]] *= scale_y

                # Shift till rätt position i mosaic
                boxes[:, [0, 2]] += rx
                boxes[:, [1, 3]] += ry

                # Clip till canvas
                boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, 2 * s)
                boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, 2 * s)

            mosaic_img[ry:ry + rh, rx:rx + rw] = img_resized

            if len(boxes) > 0:
                # filtrera bort trasiga / för små boxar
                bw = boxes[:, 2] - boxes[:, 0]
                bh = boxes[:, 3] - boxes[:, 1]
                valid = (bw > 4) & (bh > 4)
                if valid.any():
                    all_boxes.append(boxes[valid])
                    all_labels.append(labels[valid])

        if all_boxes:
            final_boxes = np.vstack(all_boxes)
            final_labels = np.concatenate(all_labels)
            return mosaic_img, final_boxes, final_labels
        else:
            return mosaic_img, np.zeros((0, 4), dtype=np.float32), np.zeros((0,), dtype=np.int64)


    # ------------------ CutMix (Fokus små) ------------------
    def cutmix_focus_small(self, img, boxes, labels, other_idx, alpha=0.7):
        # Ladda andra bilden
        img2 = self.load_image(other_idx)
        h2, w2 = img2.shape[:2]
        boxes2, labels2 = self.load_label_processed(other_idx, h2, w2)

        if len(boxes2) == 0:
            return img, boxes, labels

        # Hitta minsta box (NumPy style)
        areas = (boxes2[:, 2] - boxes2[:, 0]) * (boxes2[:, 3] - boxes2[:, 1])
        smallest_idx = np.argmin(areas)
        
        # Extrahera data
        x1, y1, x2, y2 = boxes2[smallest_idx].astype(int)
        lbl = labels2[smallest_idx]
        
        patch = img2[y1:y2, x1:x2]
        if patch.size == 0: return img, boxes, labels
        
        ph, pw = patch.shape[:2]
        h, w = img.shape[:2]

        # --- FIX START: Kontrollera att patchen får plats ---
        if ph >= h or pw >= w:
            # Alternativ A: Patchen är större än målbilden -> Hoppa över cutmix denna gång
            return img, boxes, labels
            
            # Alternativ B (om du hellre vill det): Skala ner patchen
            # scale = min(h/ph, w/pw) * 0.9
            # patch = cv2.resize(patch, (int(pw*scale), int(ph*scale)))
            # ph, pw = patch.shape[:2]
        # --- FIX END ---

        # Enkel logik för paste
        cx = random.randint(0, max(0, w - pw))
        cy = random.randint(0, max(0, h - ph))
        
        # Klistra in
        roi = img[cy:cy+ph, cx:cx+pw]
        
        # --- SÄKERHETSCHECK: Om NumPy slicade ROI pga kanterna ---
        if roi.shape[:2] != patch.shape[:2]:
            return img, boxes, labels

        img[cy:cy+ph, cx:cx+pw] = (alpha * patch + (1 - alpha) * roi).astype(np.uint8)

        # Lägg till ny box till existerande (NumPy concat)
        new_box = np.array([[cx, cy, cx+pw, cy+ph]], dtype=np.float32)
        new_lbl = np.array([lbl], dtype=np.int64)
        
        return img, np.vstack([boxes, new_box]), np.concatenate([labels, new_lbl])
    def mosaic_dominant_patches(
    self,
    index,
    dominant_ratio_range=(0.72, 0.85),
    patch_scale_range=(0.18, 0.35),
    context_scale_range=(1.4, 2.2),
    min_box_size=4,
    paste_iou_thresh=0.3,
):
        import random
        import numpy as np
        import cv2

        def box_iou_np(box, boxes):
            # box: [4], boxes: [N,4]
            if len(boxes) == 0:
                return np.zeros((0,), dtype=np.float32)
            xx1 = np.maximum(box[0], boxes[:, 0])
            yy1 = np.maximum(box[1], boxes[:, 1])
            xx2 = np.minimum(box[2], boxes[:, 2])
            yy2 = np.minimum(box[3], boxes[:, 3])

            iw = np.maximum(0.0, xx2 - xx1)
            ih = np.maximum(0.0, yy2 - yy1)
            inter = iw * ih

            area1 = max(0.0, (box[2] - box[0])) * max(0.0, (box[3] - box[1]))
            area2 = np.maximum(0.0, boxes[:, 2] - boxes[:, 0]) * np.maximum(0.0, boxes[:, 3] - boxes[:, 1])
            union = area1 + area2 - inter + 1e-7
            return inter / union

        def clip_boxes_xyxy(boxes, w, h):
            if len(boxes) == 0:
                return boxes
            boxes[:, [0, 2]] = np.clip(boxes[:, [0, 2]], 0, w)
            boxes[:, [1, 3]] = np.clip(boxes[:, [1, 3]], 0, h)
            return boxes

        def valid_boxes_xyxy(boxes, min_size=2):
            if len(boxes) == 0:
                return np.zeros((0,), dtype=bool)
            bw = boxes[:, 2] - boxes[:, 0]
            bh = boxes[:, 3] - boxes[:, 1]
            return (bw >= min_size) & (bh >= min_size)

        def crop_object_patch(img, boxes, labels):
            """
            Välj ett litet/smått objekt, ta ut en crop runt objektet med lite kontext.
            Returnerar patch_img, patch_boxes, patch_labels
            där boxarna är relativa till patchen.
            """
            if len(boxes) == 0:
                return None, None, None

            boxes = boxes.astype(np.float32)
            areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])

            # välj bland de mindre objekten, inte alltid absolut minsta
            order = np.argsort(areas)
            k = max(1, int(len(order) * 0.4))
            candidate_idxs = order[:k]
            chosen = np.random.choice(candidate_idxs)

            x1, y1, x2, y2 = boxes[chosen]
            bw = max(1.0, x2 - x1)
            bh = max(1.0, y2 - y1)
            cx = 0.5 * (x1 + x2)
            cy = 0.5 * (y1 + y2)

            ctx_scale = random.uniform(*context_scale_range)
            crop_w = bw * ctx_scale
            crop_h = bh * ctx_scale

            ih, iw = img.shape[:2]

            crop_x1 = int(max(0, round(cx - crop_w / 2)))
            crop_y1 = int(max(0, round(cy - crop_h / 2)))
            crop_x2 = int(min(iw, round(cx + crop_w / 2)))
            crop_y2 = int(min(ih, round(cy + crop_h / 2)))

            if crop_x2 <= crop_x1 or crop_y2 <= crop_y1:
                return None, None, None

            patch = img[crop_y1:crop_y2, crop_x1:crop_x2].copy()

            # ta med alla boxar som har viss overlap med cropen
            patch_boxes = boxes.copy()
            patch_boxes[:, [0, 2]] -= crop_x1
            patch_boxes[:, [1, 3]] -= crop_y1
            patch_boxes = clip_boxes_xyxy(patch_boxes, patch.shape[1], patch.shape[0])

            valid = valid_boxes_xyxy(patch_boxes, min_size=2)
            if not valid.any():
                return None, None, None

            patch_boxes = patch_boxes[valid]
            patch_labels = labels[valid]

            return patch, patch_boxes, patch_labels

        def resize_patch_keep_aspect(patch, patch_boxes, target_long_side):
            ph, pw = patch.shape[:2]
            if ph <= 0 or pw <= 0:
                return None, None

            scale = float(target_long_side) / max(ph, pw)
            new_w = max(1, int(round(pw * scale)))
            new_h = max(1, int(round(ph * scale)))

            patch_resized = cv2.resize(patch, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            boxes_resized = patch_boxes.copy().astype(np.float32)
            boxes_resized[:, [0, 2]] *= new_w / pw
            boxes_resized[:, [1, 3]] *= new_h / ph
            return patch_resized, boxes_resized

        indices = [index] + random.choices(range(len(self)), k=3)

        # --- SE TILL ATT DESSA RADER ÄR KVAR ---
        s = self.img_size
        canvas_h, canvas_w = 2 * s, 2 * s
        mosaic_img = np.full((canvas_h, canvas_w, 3), 114, dtype=np.uint8)

        all_boxes = []
        all_labels = []

        # -------------------------
        # 1) Lägg in dominant huvudbild
        # -------------------------
        main_idx = indices[0]
        
        # NYTT: Ladda allt på en rad med din optimerade funktion!
        main_img, main_boxes, main_labels, mh0, mw0 = self.load_resized_image_and_labels(main_idx)

        dom_r = random.uniform(*dominant_ratio_range)
        main_target_w = int(canvas_w * dom_r)
        main_target_h = int(canvas_h * dom_r)

        # behåll aspect ratio via letterbox-liknande placering
        scale = min(main_target_w / max(1, mw0), main_target_h / max(1, mh0))
        new_w = max(1, int(round(mw0 * scale)))
        new_h = max(1, int(round(mh0 * scale)))
        main_resized = cv2.resize(main_img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

        # placera dominant bild uppe-vänster men inte nödvändigtvis exakt 0,0
        pad_x = random.randint(0, max(0, main_target_w - new_w))
        pad_y = random.randint(0, max(0, main_target_h - new_h))

        x0 = pad_x
        y0 = pad_y
        x1 = x0 + new_w
        y1 = y0 + new_h

        mosaic_img[y0:y1, x0:x1] = main_resized

        if len(main_boxes) > 0:
            main_boxes = main_boxes.copy().astype(np.float32)
            main_boxes[:, [0, 2]] *= new_w / mw0
            main_boxes[:, [1, 3]] *= new_h / mh0
            main_boxes[:, [0, 2]] += x0
            main_boxes[:, [1, 3]] += y0

            main_boxes = clip_boxes_xyxy(main_boxes, canvas_w, canvas_h)
            valid = valid_boxes_xyxy(main_boxes, min_size=min_box_size)
            if valid.any():
                all_boxes.append(main_boxes[valid])
                all_labels.append(main_labels[valid])

        # samla redan placerade boxar för att undvika hårda krockar
        placed_boxes = np.vstack(all_boxes) if len(all_boxes) > 0 else np.zeros((0, 4), dtype=np.float32)

        # -------------------------
        # 2) Klistra in 3 objektpatchar
        # -------------------------
        for idx in indices[1:]:
            # NYTT: Ladda patch-bilderna med samma optimerade funktion!
            img2, boxes2, labels2, h2, w2 = self.load_resized_image_and_labels(idx)

            if len(boxes2) == 0:
                continue

            patch, patch_boxes, patch_labels = crop_object_patch(img2, boxes2, labels2)
            if patch is None:
                continue

            # välj rimlig storlek på patch relativt canvas
            long_side = int(random.uniform(*patch_scale_range) * s)
            patch_resized, patch_boxes_resized = resize_patch_keep_aspect(patch, patch_boxes, long_side)
            if patch_resized is None:
                continue

            ph, pw = patch_resized.shape[:2]
            if ph < 2 or pw < 2 or ph >= canvas_h or pw >= canvas_w:
                continue

            # försök hitta plats utan för mycket overlap
            pasted = False
            for _ in range(5):
                px = random.randint(0, max(0, canvas_w - pw))
                py = random.randint(0, max(0, canvas_h - ph))

                shifted_boxes = patch_boxes_resized.copy()
                shifted_boxes[:, [0, 2]] += px
                shifted_boxes[:, [1, 3]] += py

                shifted_boxes = clip_boxes_xyxy(shifted_boxes, canvas_w, canvas_h)
                valid = valid_boxes_xyxy(shifted_boxes, min_size=min_box_size)
                if not valid.any():
                    continue

                candidate_boxes = shifted_boxes[valid]
                candidate_labels = patch_labels[valid]

                # undvik total krock med redan lagda boxar
                # kolla max IoU för den "primära" första boxen i patchen
                ref_box = candidate_boxes[0]
                ious = box_iou_np(ref_box, placed_boxes)
                if len(ious) > 0 and ious.max() > paste_iou_thresh:
                    continue

                # hård paste
                mosaic_img[py:py + ph, px:px + pw] = patch_resized

                all_boxes.append(candidate_boxes)
                all_labels.append(candidate_labels)

                if len(placed_boxes) == 0:
                    placed_boxes = candidate_boxes.copy()
                else:
                    placed_boxes = np.vstack([placed_boxes, candidate_boxes])

                pasted = True
                break

            if not pasted:
                continue

        # -------------------------
        # 3) Slå ihop allt
        # -------------------------
        if len(all_boxes) > 0:
            final_boxes = np.vstack(all_boxes).astype(np.float32)
            final_labels = np.concatenate(all_labels).astype(np.int64)

            final_boxes = clip_boxes_xyxy(final_boxes, canvas_w, canvas_h)
            valid = valid_boxes_xyxy(final_boxes, min_size=min_box_size)

            final_boxes = final_boxes[valid]
            final_labels = final_labels[valid]

            return mosaic_img, final_boxes, final_labels

        return mosaic_img, np.zeros((0, 4), dtype=np.float32), np.zeros((0,), dtype=np.int64)
    def __getitem__(self, idx):
        # Default: ladda en bild
        p = random.random()
        if self.is_train and p < self.mosaic_p :
            
            if random.random() < 0.80:
                img, boxes, labels = self.mosaic_v1(idx)
            else:
                img, boxes, labels = self.mosaic_dominant_patches(idx)
            
            # Klipp boxar så de håller sig inom bildens ramar (viktigt efter mosaic/cutmix)
            h, w = img.shape[:2]
            boxes = self._clip_boxes(boxes, h, w)
            transformed = self.mosaic_transform(image=img, bboxes=boxes, class_labels=labels)
            boxes = torch.as_tensor(transformed["bboxes"], dtype=torch.float32)
            labels = torch.as_tensor(transformed["class_labels"], dtype=torch.int64)
            target = {"boxes": boxes, "labels": labels, "image_id": torch.tensor([idx])}
            img = transformed["image"]
            return img, target
        else:
            # 1. Ladda originalbild (t.ex. 1920x1080)
            img, boxes, labels, h, w = self.load_resized_image_and_labels(idx)
            h, w = img.shape[:2]

            try:
                # Albumentations vill ofta ha listor, men klarar numpy. 
                # Vi konverterar till listor enbart för anropet om det krävs, annars kör vi numpy.
                if len(boxes) > 0:
                    transformed = self.transforms(image=img, bboxes=boxes, class_labels=labels)
                    img = transformed["image"]
                    boxes = torch.as_tensor(transformed["bboxes"], dtype=torch.float32)
                    labels = torch.as_tensor(transformed["class_labels"], dtype=torch.int64)
                else:
                    # Hantera tomma fall (albumentations kraschar ibland på tomma listor)
                    transformed = self.transforms(image=img, bboxes=[], class_labels=[])
                    img = transformed["image"]
                    boxes = torch.zeros((0, 4), dtype=torch.float32)
                    labels = torch.zeros((0,), dtype=torch.int64)

                target = {"boxes": boxes, "labels": labels, "image_id": torch.tensor([idx])}
                return img, target

            except Exception as e:
                print(f"[ERROR] {self.img_files[idx]}: {e}")
                # Returnera en tom tensor istället för crash, så DataLoader kan fortsätta

                return torch.zeros((3, self.img_size, self.img_size)), {"boxes": torch.zeros((0,4)), "labels": torch.zeros((0,))}