# augment.py
import cv2
import albumentations as A
from albumentations.pytorch import ToTensorV2

# ---- safe wrappers to handle Albumentations API differences ----
def make_affine(**kw):
    """
    Try modern args first, fall back if not supported:
    - Some versions accept border_mode/cval, others ignore them.
    - We keep the geometric part the same either way.
    """
    try:
        return A.Affine(
            interpolation=cv2.INTER_LINEAR,
            border_mode=cv2.BORDER_CONSTANT,  # newer/most common
            cval=(114, 114, 114),
            fit_output=False,
            **kw
        )
    except TypeError:
        # Fall back: drop cval/border_mode if not accepted
        return A.Affine(fit_output=False, **kw)

def make_pad(img_size):
    try:
        return A.PadIfNeeded(
            min_height=img_size, min_width=img_size,
            border_mode=cv2.BORDER_CONSTANT,
            value=(114, 114, 114)  # some versions accept tuple; others ignore -> still fine
        )
    except TypeError:
        # Fall back without value
        return A.PadIfNeeded(
            min_height=img_size, min_width=img_size,
            border_mode=cv2.BORDER_CONSTANT
        )

def make_gauss_noise(p=0.15):
    try:
        # Common signature
        return A.GaussNoise(var_limit=(5.0, 20.0), p=p)
    except TypeError:
        # Fall back to defaults
        return A.GaussNoise(p=p)

def letterbox_block(img_size):
    return [
        A.LongestMaxSize(max_size=img_size),
        make_pad(img_size),
    ]
def get_mosaic_transform(img_size=640):
    """
    Speciell transform som tar en stor canvas (t.ex. 1280x1280 från Mosaic)
    och klipper ut rätt målstorlek UTAN att skala ner och förstöra små objekt.
    """
    return A.Compose(
        [   
            
            A.RandomResizedCrop(
                size=(img_size, img_size),  # 
                scale=(0.4, 1.0), 
                ratio=(0.75, 1.33), 
                p=1.0               # Kör hårt!
            ),
            # 2. Geometrisk augmentering (Görs EFTER crop så det appliceras över skarvarna)
            A.HorizontalFlip(p=0.5), 
            make_affine(
                rotate=(-5, 5),
                shear=(-5, 5),
                scale=(0.8, 1.2),
                translate_percent=(0.05, 0.05),
                p=0.3,
            ),

            # 3. Optiska effekter
            A.OneOf([
                A.Blur(blur_limit=3, p=1.0),
                A.MedianBlur(blur_limit=3, p=1.0),
                A.MotionBlur(blur_limit=3, p=1.0),
                make_gauss_noise(p=1.0),
            ], p=0.25),

            # 4. Färg och Ljus
            A.OneOf([
                A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2),
                A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05),
                A.CLAHE(clip_limit=2.0, p=1.0),
            ], p=0.5),


            # 5. Normalisering
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc", 
            label_fields=["class_labels"],
            min_visibility=0.1, # Extra viktigt här så vi rensar bort halva avklippta bilar!
            min_area=15,         # Kasta mikroskopiska rester
            clip=True,
            filter_invalid_bboxes=True,
        ),
        p=1.0
    )

def get_base_transform(img_size=416, resize=0.0):
    return A.Compose(
        [   
            #A.Resize(img_size,img_size, interpolation=cv2.INTER_LINEAR, p=resize),
            
            # 1. GEOMETRISK AUGMENTERING (Börja här)
            A.HorizontalFlip(p=0.5), # Höjd sannolikhet för COCO
            
            # RandomResizedCrop ersätter ofta vanlig Resize i träningsfasen.
            # Den tar ett slumpmässigt utsnitt (scale) och ändrar proportionerna (ratio),
            # sen skalar den upp det till img_size.
            A.RandomResizedCrop(
                size=(img_size, img_size),  # <--- Här är ändringen
                scale=(0.4, 1.0), 
                ratio=(0.75, 1.33), 
                p=0.5
            ),


            make_affine(
                rotate=(-15, 15),
                shear=(-5, 5),
                scale=(0.8, 1.2),
                translate_percent=(0.05, 0.05),
                p=0.3,
            ),

            # 2. OPTISKA EFFEKTER (Blur/Brus)
            A.OneOf([
                A.Blur(blur_limit=3, p=1.0),
                A.MedianBlur(blur_limit=3, p=1.0),
                A.MotionBlur(blur_limit=3, p=1.0),
                make_gauss_noise(p=1.0),
            ], p=0.25), # En fjärdedel av bilderna blir lite "stökiga"

            # 3. FÄRG OCH LJUS
            A.OneOf([
                A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2),
                A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05),
                A.CLAHE(clip_limit=2.0, p=1.0), # Bra för att hitta objekt i skuggor
            ], p=0.5),
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size),
            

            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["class_labels"],
            min_visibility=0.1, # Motverkar RuntimeWarning
            min_area=10,        # Rensar bort mikroskopiska rester efter crop
            clip=True,
            filter_invalid_bboxes=True,
        ),
        p=1.0
    )

def get_strong_transform(img_size, resize=0.0):
    return A.Compose([
        # A.Resize(imgsz, imgsz, p=1),
        A.HorizontalFlip(p=0.5),
        A.Affine(
            rotate=(-2, 2),
            shear=(-10, 10),
            scale=(0.95, 1.5),
            translate_percent=(0.05, 0.1),
            p=0.3,
        ),
        A.ElasticTransform(alpha=1, sigma=50, p=0.1),

        A.OneOf([
            A.RandomBrightnessContrast(),
            A.ColorJitter(),
            A.HueSaturationValue(),
            A.RGBShift(),
            A.ChannelShuffle()
        ], p=0.1),

        A.OneOf([
            A.RandomShadow(shadow_roi=(0, 0.5, 1, 1),  shadow_dimension=5),
            A.RandomSunFlare(flare_roi=(0, 0, 1, 0.5), angle_range=(0.0, 1.0))
        ], p=0.2),

        A.CoarseDropout(num_holes_range=(3, 10), hole_height_range=(
            0.01, 0.05), hole_width_range=(0.01, 0.05), p=0.2),

        A.OneOf([
            A.GaussNoise(),
            A.MotionBlur(blur_limit=3)
        ], p=0.3),
        A.LongestMaxSize(max_size=img_size),
        make_pad(img_size),
        A.Normalize(mean=(0.485, 0.456, 0.406),
                    std=(0.229, 0.224, 0.225)),
        ToTensorV2()

    ],
        bbox_params=A.BboxParams(
        format='pascal_voc',
        min_visibility=0.3,
        label_fields=['class_labels'],
        clip=True,
        filter_invalid_bboxes=True
    ),
        is_check_shapes=True,
        p=1.0
    )
def get_lite_transform(img_size=416):
    return A.Compose(
        [   
            # 0. GRUNDLÄGGANDE FORMATERING (Behålls)
            # Samma som innan, bevarar aspect ratio och fyller ut med padding.
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size), 
            
            # 1. GEOMETRISK AUGMENTERING (Mycket mildare)
            A.HorizontalFlip(p=0.5), # Spegling är helt naturligt och säkert att behålla
            
            # Endast lätt förskjutning och mycket försiktig skalning. 
            # Ingen rotation eller skevhet (shear) som förvränger naturliga linjer.
            make_affine(
                rotate=(0, 0),
                shear=(0, 0),
                scale=(0.9, 1.1), 
                translate_percent=(0.05, 0.05),
                p=0.2,
            ),

            # (RandomResizedCrop är helt borttaget härifrån)

            # 2. FÄRG OCH LJUS (Nedskruvat)
            # Vi låter nätverket se lite naturliga ljusvariationer, men stänger av CLAHE.
            A.OneOf([
                A.RandomBrightnessContrast(brightness_limit=0.1, contrast_limit=0.1),
                A.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
            ], p=0.3),

            # (Blur, Noise och CoarseDropout är borttagna)

            # 3. NORMALISERING TILL TENSOR (Behålls orört)
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["class_labels"],
            min_visibility=0.2, # Höjt lite eftersom vi inte croppar lika aggressivt
            min_area=10,        
            clip=True,
            filter_invalid_bboxes=True,
        ),
        p=1.0
    )
def get_val_transform(img_size=416, resize=0.0):
    return A.Compose(
        [
            A.Resize(img_size, img_size, interpolation=cv2.INTER_LINEAR, p=resize),
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size),
            A.Normalize(mean=(0.485, 0.456, 0.406),
                        std=(0.229, 0.224, 0.225)),
            ToTensorV2()
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["class_labels"],
            clip=True,
            filter_invalid_bboxes=True,
        ),
        is_check_shapes=True,
        p=1.0
    )