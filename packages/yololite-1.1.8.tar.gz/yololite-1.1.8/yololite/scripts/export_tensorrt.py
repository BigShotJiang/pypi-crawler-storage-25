# yololite/scripts/export_tensorrt.py
import os
from pathlib import Path

try:
    import tensorrt as trt
except ImportError:
    raise ImportError("The 'tensorrt' python package is not installed. Please install it to build .engine files.")

def build_engine(onnx_path: str, engine_path: str = None, img_size: int = 640, fp16: bool = True) -> str:
    """
    Takes an exported ONNX file and compiles it into a highly optimized TensorRT engine.
    """
    logger = trt.Logger(trt.Logger.INFO)
    builder = trt.Builder(logger)
    config = builder.create_builder_config()
    
    # Set workspace size (4GB, adjust if dealing with massive models)
    config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 4 * 1024 * 1024 * 1024)

    if fp16 and builder.platform_has_fast_fp16:
        logger.log(trt.Logger.INFO, "Enabling FP16 optimization...")
        config.set_flag(trt.BuilderFlag.FP16)

    # Explicit batch is required for modern ONNX models
    network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    parser = trt.OnnxParser(network, logger)

    if not os.path.exists(onnx_path):
        raise FileNotFoundError(f"ONNX file not found: {onnx_path}")

    logger.log(trt.Logger.INFO, f"Parsing ONNX file: {onnx_path}")
    with open(onnx_path, 'rb') as model:
        if not parser.parse(model.read()):
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            raise RuntimeError("Failed to parse the ONNX file.")

    # Optimize for Batch Size = 1
    profile = builder.create_optimization_profile()
    input_tensor = network.get_input(0)
    
    # Define the shape (Batch, Channels, Height, Width)
    shape = (1, 3, img_size, img_size)
    profile.set_shape(input_tensor.name, min=shape, opt=shape, max=shape)
    config.add_optimization_profile(profile)

    logger.log(trt.Logger.INFO, f"Building TensorRT engine for shape {shape}. This may take a few minutes...")
    engine_bytes = builder.build_serialized_network(network, config)
    
    if engine_bytes is None:
        raise RuntimeError("Failed to build TensorRT engine.")

    # If no output path is provided, save it next to the ONNX file
    if engine_path is None:
        engine_path = str(Path(onnx_path).with_suffix('.engine'))

    with open(engine_path, 'wb') as f:
        f.write(engine_bytes)
        
    logger.log(trt.Logger.INFO, f"Done! Engine saved to: {engine_path}")
    return engine_path