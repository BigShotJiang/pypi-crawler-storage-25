# yololite/scripts/evaluate.py
import os
import cv2
import yaml
import time
import numpy as np
from pathlib import Path

import torch
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from tqdm import tqdm
def _next_run_dir(base: str) -> str:
    """
    Skapa och returnera nästa lediga run-mapp som en numerisk subdir under 'base'.
    Ex: base='runs' -> 'runs/1', 'runs/2', ...
        base='runs/weeds' -> 'runs/weeds/1', ...
    """
    root = Path(base)
    root.mkdir(parents=True, exist_ok=True)
    n = 1
    while True:
        cand = root / str(n)
        try:
            cand.mkdir(parents=False, exist_ok=False)
            return str(cand.resolve())
        except FileExistsError:
            n += 1
def load_data_yaml(data_path, split="val"):
    """Parses data.yaml to find the image and label directories."""
    data_path = Path(data_path).resolve()
    
    with open(data_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    # 1. Base path defaults to the directory where data.yaml lives
    base_path = data_path.parent
    
    # 2. If 'path' is in data, resolve it relative to the yaml file, NOT the terminal CWD
    if "path" in data:
        yaml_path = Path(data["path"])
        if yaml_path.is_absolute():
            base_path = yaml_path
        else:
            base_path = (base_path / yaml_path).resolve()
            
    if split not in data:
        raise ValueError(f"Split '{split}' not found in {data_path}. Available: {list(data.keys())}")
        
    split_path = data[split]
    
    # 3. THE FIX: Strip leading '../' from Roboflow exports to prevent 
    # it from escaping the dataset root directory and losing the dataset name.
    if isinstance(split_path, str) and split_path.startswith("../"):
        split_path = split_path[3:]
        
    img_dir = (base_path / split_path).resolve()
    
    # YOLO standard: labels are in a 'labels' folder parallel to 'images'
    label_dir = Path(str(img_dir).replace("images", "labels"))
    
    if not img_dir.exists():
        raise FileNotFoundError(f"Image directory not found: {img_dir}")
        
    return img_dir, label_dir, data.get("names", [])

def load_ground_truth(label_path, h0, w0, task="det"):
    """Loads YOLO format ground truth (bounding boxes and/or polygons)."""
    if not label_path.exists():
        return None
        
    boxes, labels, masks = [], [], []
    
    with open(label_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
                
            cls_id = int(parts[0])
            coords = np.array(parts[1:], dtype=np.float32)
            
            if len(coords) == 4: # Standard BBox
                x, y, w, h = coords
                x1, y1 = (x - w / 2) * w0, (y - h / 2) * h0
                x2, y2 = (x + w / 2) * w0, (y + h / 2) * h0
                
                if task == "seg":
                    # If model is seg but label is bbox, create an empty/dummy mask or skip
                    mask = np.zeros((h0, w0), dtype=bool)
                    masks.append(mask)
                    
            elif len(coords) >= 6: # Polygon (Segmentation)
                poly = coords.reshape(-1, 2)
                poly[:, 0] = np.clip(poly[:, 0] * w0, 0, w0 - 1)
                poly[:, 1] = np.clip(poly[:, 1] * h0, 0, h0 - 1)
                
                x1, y1 = poly[:, 0].min(), poly[:, 1].min()
                x2, y2 = poly[:, 0].max(), poly[:, 1].max()
                
                if task == "seg":
                    mask = np.zeros((h0, w0), dtype=np.uint8)
                    cv2.fillPoly(mask, [poly.astype(np.int32)], 1)
                    masks.append(mask.astype(bool))
            else:
                continue
                
            boxes.append([x1, y1, x2, y2])
            labels.append(cls_id)
            
    if not boxes:
        return None
        
    target = {
        "boxes": torch.tensor(boxes, dtype=torch.float32),
        "labels": torch.tensor(labels, dtype=torch.int64),
    }
    if task == "seg":
        target["masks"] = torch.tensor(np.array(masks), dtype=torch.bool)
        
    return target

import torch
import torchvision
import time
from pathlib import Path
from tqdm import tqdm
import cv2
import json

def compute_tp_fp_fn_batched(pred_boxes, pred_labels, pred_scores, gt_boxes, gt_labels, conf_thresholds, iou_thresh=0.5):
    """
    Räknar TP, FP, FN för F1-kurvan baserat på Bounding Boxes.
    (I YOLO optimeras confidence nästan alltid utifrån boxarna, även för segmentering).
    """
    results = {conf: {"tp": 0, "fp": 0, "fn": 0} for conf in conf_thresholds}
    
    if len(gt_boxes) == 0:
        for conf in conf_thresholds:
            results[conf]["fp"] += (pred_scores >= conf).sum().item()
        return results
        
    unique_classes = torch.unique(torch.cat((pred_labels, gt_labels)))
    
    for c in unique_classes:
        p_mask = pred_labels == c
        g_mask = gt_labels == c
        
        c_pred_boxes = pred_boxes[p_mask]
        c_pred_scores = pred_scores[p_mask]
        c_gt_boxes = gt_boxes[g_mask]
        
        if len(c_gt_boxes) == 0:
            for conf in conf_thresholds:
                results[conf]["fp"] += (c_pred_scores >= conf).sum().item()
            continue
            
        if len(c_pred_boxes) == 0:
            for conf in conf_thresholds:
                results[conf]["fn"] += len(c_gt_boxes)
            continue
            
        ious = torchvision.ops.box_iou(c_pred_boxes, c_gt_boxes)
        sort_idxs = torch.argsort(c_pred_scores, descending=True)
        
        for conf in conf_thresholds:
            matched_gt = set()
            tp, fp = 0, 0
            
            for idx in sort_idxs:
                score = c_pred_scores[idx].item()
                if score < conf:
                    break 
                    
                best_iou, best_gt_idx = ious[idx].max(0)
                best_gt_idx = best_gt_idx.item()
                
                if best_iou >= iou_thresh and best_gt_idx not in matched_gt:
                    tp += 1
                    matched_gt.add(best_gt_idx)
                else:
                    fp += 1
                    
            fn = len(c_gt_boxes) - len(matched_gt)
            results[conf]["tp"] += tp
            results[conf]["fp"] += fp
            results[conf]["fn"] += fn
            
    return results

def run_eval(weights_path, data, task="det", split="val", iou=0.6, img_size=640, device="cuda:0", output_dir="runs/eval"):
    run_dir = _next_run_dir(output_dir)
    output_path = Path(run_dir)
    
    print(f"📊 Startar Avancerad Utvärdering | Task: {task.upper()} | Split: {split}")
    print(f"📁 Resultat sparas i: {output_path}")
    
    img_dir, label_dir, class_names = load_data_yaml(data, split)
    
    # --- EXAKT SOM I DITT ORIGINALSKRIPT ---
    from torchmetrics.detection.mean_ap import MeanAveragePrecision
    iou_types = ["bbox", "segm"] if task == "seg" else ["bbox"]
    metric = MeanAveragePrecision(iou_type=iou_types, class_metrics=True)
    
    from .predictor import YoloPredictor
    predictor = YoloPredictor(weights_path, task=task, device=device, img_size=img_size, conf_thr=0.001, iou_thr=iou, class_names=class_names)

    images = sorted([p for p in img_dir.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}])
    
    conf_thresholds = [round(x * 0.01, 2) for x in range(1, 100)]
    curve_stats = {conf: {"tp": 0, "fp": 0, "fn": 0} for conf in conf_thresholds}
    infer_times = []
    
    for img_path in tqdm(images, desc="Evaluating"):
        img_bgr = cv2.imread(str(img_path))
        if img_bgr is None: continue
        h0, w0 = img_bgr.shape[:2]
        
        t0 = time.perf_counter()
        results, _ = predictor.predict(img_bgr) 
        infer_times.append((time.perf_counter() - t0) * 1000)
        
        # --- EXAKT SOM I DITT ORIGINALSKRIPT ---
        pred_dict = {
            "boxes": torch.from_numpy(results["boxes"]).float() if len(results["boxes"]) else torch.zeros((0, 4)),
            "scores": torch.from_numpy(results["scores"]).float() if len(results["scores"]) else torch.zeros((0,)),
            "labels": torch.from_numpy(results["classes"]).long() if len(results["classes"]) else torch.zeros((0,), dtype=torch.int64),
        }
        if task == "seg":
            pred_dict["masks"] = torch.from_numpy(results["masks"]).bool() if results.get("masks") is not None and len(results["masks"]) else torch.zeros((0, h0, w0), dtype=torch.bool)
            
        gt_dict = load_ground_truth(label_dir / f"{img_path.stem}.txt", h0, w0, task)
        
        if gt_dict is not None:
            metric.update([pred_dict], [gt_dict])
            
            # --- F1-beräkningen läggs till helt oberoende ---
            img_stats = compute_tp_fp_fn_batched(
                pred_dict["boxes"], pred_dict["labels"], pred_dict["scores"],
                gt_dict["boxes"], gt_dict["labels"], conf_thresholds, iou_thresh=0.5
            )
            for conf in conf_thresholds:
                curve_stats[conf]["tp"] += img_stats[conf]["tp"]
                curve_stats[conf]["fp"] += img_stats[conf]["fp"]
                curve_stats[conf]["fn"] += img_stats[conf]["fn"]

    print("Calculating COCO map ...")
    m = metric.compute()
    
    # Fallback-hantering för namn i TorchMetrics
    map_50_95 = m.get("bbox_map", m.get("map", torch.tensor(0.0))).item()
    map_50 = m.get("bbox_map_50", m.get("map_50", torch.tensor(0.0))).item()
    
    # Analysera F1
    best_f1, best_conf, best_precision, best_recall = -1.0, 0.0, 0.0, 0.0
    full_curve_data = {}
    
    for conf in conf_thresholds:
        tp, fp, fn = curve_stats[conf]["tp"], curve_stats[conf]["fp"], curve_stats[conf]["fn"]
        p = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        r = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * (p * r) / (p + r) if (p + r) > 0 else 0.0
        
        full_curve_data[f"{conf:.2f}"] = {"precision": p, "recall": r, "f1": f1, "tp": tp, "fp": fp, "fn": fn}
        
        if f1 > best_f1:
            best_f1, best_conf, best_precision, best_recall = f1, conf, p, r

    avg_ms = sum(infer_times) / len(infer_times)
    
    print("\n" + "="*50)
    print(f"🏆 EVALUATION RESULTS ({task.upper()})")
    print("="*50)
    print(f"Box mAP@50-95:    {map_50_95:.4f}")
    print(f"Box mAP@50:       {map_50:.4f}")
    
    if task == "seg" and "segm_map" in m:
        print("-" * 50)
        print(f"Mask mAP@50-95:   {m['segm_map'].item():.4f}")
        print(f"Mask mAP@50:      {m['segm_map_50'].item():.4f}")
        
    print("-" * 50)
    print(f"🔥 OPTIMAL F1-THRESH:")
    print(f"Best conf:  {best_conf}")
    print(f"Max F1-Score:     {best_f1:.4f}")
    print("="*50)
    
    report_file = output_path / f"eval_report_{split}.txt"
    with open(report_file, "w", encoding="utf-8") as f:
        f.write("="*60 + "\n")
        f.write(f" F1 & mAP EVALUATION REPORT - {task.upper()} ({split.upper()})\n")
        f.write("="*60 + "\n\n")
        f.write(f"Model_path: {weights_path}\n")
        f.write(f"Num images: {len(images)}\n")
        f.write(f"Inference speed:    {avg_ms:.2f} ms / img ({1000/avg_ms:.1f} FPS)\n\n")
        f.write("-" * 40 + "\n")
        f.write(" Metrics (COCO)\n")
        f.write("-" * 40 + "\n")
        f.write(f"Box mAP@50-95:   {map_50_95:.4f}\n")
        f.write(f"Box mAP@50:      {map_50:.4f}\n")
        
        if task == "seg" and "segm_map" in m:
            f.write(f"Mask mAP@50-95:  {m['segm_map'].item():.4f}\n")
            f.write(f"Mask mAP@50:     {m['segm_map_50'].item():.4f}\n")
            
        f.write("\n" + "-" * 40 + "\n")
        f.write(" OPTIMAL CONF THRESH (Found by Grid-Search)\n")
        f.write("-" * 40 + "\n")
        f.write(f"Conf_score (Confidence):          {best_conf}\n")
        f.write(f"F1-Score:                        {best_f1:.4f}\n")
        f.write(f"Precision:                     {best_precision:.4f}\n")
        f.write(f"Recall:                        {best_recall:.4f}\n\n")
        f.write(f"Matrix details F1:   TP={curve_stats[best_conf]['tp']}, FP={curve_stats[best_conf]['fp']}, FN={curve_stats[best_conf]['fn']}\n\n")
        f.write("-" * 40 + "\n")
        f.write(" F1 curve \n")
        f.write("-" * 40 + "\n")
        f.write("Conf\tPrecision\tRecall\t\tF1-Score\n")
        for c in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
            d = full_curve_data[f"{c:.2f}"]
            f.write(f"{c:.1f}\t{d['precision']:.4f}\t\t{d['recall']:.4f}\t\t{d['f1']:.4f}\n")
            
    with open(output_path / f"curve_data_{split}.json", "w") as f:
        json.dump(full_curve_data, f, indent=4)
        
    m["optimal_conf"] = best_conf
    m["max_f1"] = best_f1
    m["precision_at_best"] = best_precision
    m["recall_at_best"] = best_recall
    m["eval_dir"] = str(output_path)
    m["avg_ms"] = avg_ms
    
    return m