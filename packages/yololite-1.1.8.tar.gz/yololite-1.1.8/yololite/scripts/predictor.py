# yololite/scripts/predict.py
import cv2
import numpy as np
import torch

import os
import time
from pathlib import Path
import random
import torch.nn.functional as F
from torchvision.ops import batched_nms


# ---------------------------------------------------------
# TENSORRT WRAPPER (Injected from your code!)
# ---------------------------------------------------------
try:
    import tensorrt as trt
    class TRTWrapper:
        def __init__(self, engine_path: str):
            self.logger = trt.Logger(trt.Logger.ERROR)
            trt.init_libnvinfer_plugins(self.logger, "")
            with open(engine_path, 'rb') as f, trt.Runtime(self.logger) as runtime:
                self.engine = runtime.deserialize_cuda_engine(f.read())
            self.context = self.engine.create_execution_context()
            self.inputs, self.outputs, self.bindings = [], [], []

            for i in range(self.engine.num_io_tensors):
                name = self.engine.get_tensor_name(i)
                is_input = self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT
                shape = tuple([1 if s == -1 else s for s in self.context.get_tensor_shape(name)])
                trt_dtype = self.engine.get_tensor_dtype(name)
                
                if trt_dtype == trt.float32: dtype = torch.float32
                elif trt_dtype == trt.float16: dtype = torch.float16
                elif trt_dtype == trt.uint8: dtype = torch.uint8
                else: dtype = torch.float32

                tensor = torch.empty(shape, dtype=dtype, device='cuda')
                self.bindings.append(tensor.data_ptr())
                if is_input: self.inputs.append({"name": name, "tensor": tensor})
                else: self.outputs.append({"name": name, "tensor": tensor})

        def __call__(self, x: torch.Tensor):
            self.inputs[0]["tensor"].copy_(x)
            self.context.execute_v2(self.bindings)
            return {out["name"]: out["tensor"].clone() for out in self.outputs}
except ImportError:
    TRTWrapper = None

# ---------------------------------------------------------
# PREDICTOR ENGINE
# ---------------------------------------------------------
class YoloPredictor:
    def __init__(self, weights_path, task="det", device="cpu", img_size=640, conf_thr=0.25, iou_thr=0.5, class_names=None):
        self.weights_path = str(weights_path)
        self.task = task
        self.device = device
        self.img_size = img_size
        self.conf_thr = conf_thr
        self.iou_thr = iou_thr
        self.class_names = class_names 
        
        # SMART BACKEND ROUTING
        if self.weights_path.endswith(".onnx"):
            self.backend = "onnx"
        elif self.weights_path.endswith(".engine") or self.weights_path.endswith(".trt"):
            self.backend = "tensorrt"
        else:
            self.backend = "pytorch"
            
        self._load_model()
        
        if self.class_names is None:
            self.class_names = [str(i) for i in range(80)]
            print(f"Warning: No class names provided. Assuming {len(self.class_names)} classes.")
            
        self._init_colors()

    def _init_colors(self):
        self.colors = []
        for i in range(len(self.class_names)):
            random.seed(i * 42)
            self.colors.append((random.randint(50, 255), random.randint(50, 255), random.randint(50, 255)))

    def _load_model(self):
        if self.backend == "onnx":
            import onnxruntime as ort
            print(f"Initializing ONNX Runtime ({self.device})...")
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if "cuda" in self.device else ["CPUExecutionProvider"]
            self.session = ort.InferenceSession(self.weights_path, providers=providers)
            self.in_name = self.session.get_inputs()[0].name
            self.out_names = [o.name for o in self.session.get_outputs()]
            self.has_integrated_nms = "output" in self.out_names
            if isinstance(self.class_names, int): self.class_names = [str(i) for i in range(self.class_names)]
            
        elif self.backend == "tensorrt":
            print(f"Initializing TensorRT on CUDA...")
            if TRTWrapper is None: raise ImportError("TensorRT is not installed!")
            self.trt_model = TRTWrapper(self.weights_path)
            self.in_name = self.trt_model.inputs[0]["name"]
            self.out_names = [o["name"] for o in self.trt_model.outputs]
            self.has_integrated_nms = "output" in self.out_names
            if isinstance(self.class_names, int): self.class_names = [str(i) for i in range(self.class_names)]
            
        elif self.backend == "pytorch":
            print(f"Initializing PyTorch on {self.device}...")
            
            # Tysta varningen om weights_only
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=FutureWarning)
                ckpt = torch.load(self.weights_path, map_location=self.device)
                
            if self.task == "seg":
                from .seg.export.export_onnx_seg import load_model_from_ckpt
            else:
                from .det.export.export_onnx import load_model_from_ckpt
                
            self.model, meta = load_model_from_ckpt(self.weights_path, device=self.device, verbose=False)
            self.model.eval()

            # --- FIX: SMART KLASS-HANTERING ---
            # Kolla först om namnen sparades i config
            if "config" in ckpt and "dataset" in ckpt["config"] and "names" in ckpt["config"]["dataset"]:
                self.class_names = ckpt["config"]["dataset"]["names"]
            # Om namnen saknas (och vi har standardvärdet 80), hämta korrekta antalet från meta
            elif self.class_names is None or len(self.class_names) == 80:
                nc = int(meta.get("num_classes", getattr(self.model, 'num_classes', 80)))
                self.class_names = [str(i) for i in range(nc)]
                
            # Uppdatera färgerna nu när klasserna är korrigerade
            self._init_colors()
    def preprocess(self, img_bgr):
        h0, w0 = img_bgr.shape[:2]
        scale = min(self.img_size / h0, self.img_size / w0)
        nh, nw = int(round(h0 * scale)), int(round(w0 * scale))
        
        img_resized = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_LINEAR)
        top, left = (self.img_size - nh) // 2, (self.img_size - nw) // 2
        bottom, right = self.img_size - nh - top, self.img_size - nw - left
        
        img_padded = cv2.copyMakeBorder(img_resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114,114,114))
        img_rgb = cv2.cvtColor(img_padded, cv2.COLOR_BGR2RGB)
        
        if self.backend in ["onnx", "tensorrt"]:
            blob = np.transpose(img_rgb, (2, 0, 1))
            blob = np.expand_dims(blob, axis=0).astype(np.uint8) 
        else:
            img_float = img_rgb.astype(np.float32) / 255.0
            mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
            std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
            img_norm = (img_float - mean) / std
            blob = np.transpose(img_norm, (2, 0, 1))
            blob = torch.from_numpy(blob).unsqueeze(0).to(self.device)
            
        pad_info = (left, top, nw, nh, scale)
        return blob, pad_info, (h0, w0)

    def predict(self, img_source, visualize=True):
        # --- 1. MÄT PREPROCESSING ---
        t0 = time.perf_counter()
        
        if isinstance(img_source, (str, Path)): 
            img_bgr = cv2.imread(str(img_source))
        else: 
            img_bgr = img_source.copy()

        blob, pad_info, orig_shape = self.preprocess(img_bgr)
        
        t1 = time.perf_counter()

        # --- 2. MÄT INFERENCE & POSTPROCESSING ---
        if self.backend == "onnx":
            outputs = self.session.run(self.out_names, {self.in_name: blob})
            results = self._postprocess_onnx(outputs, pad_info, orig_shape)
            
        elif self.backend == "tensorrt":
            blob_t = torch.from_numpy(blob).cuda() # TensorRT needs CUDA tensor
            trt_dict = self.trt_model(blob_t)
            outputs = [trt_dict[name].cpu().numpy() for name in self.out_names]
            results = self._postprocess_onnx(outputs, pad_info, orig_shape)
            
        else:
            with torch.no_grad(): 
                outputs = self.model(blob)
                
            # KRITISKT: Synkronisera GPU:n för att få korrekt tidtagning!
            if self.device != "cpu" and torch.cuda.is_available():
                torch.cuda.synchronize()
                
            results = self._postprocess_pytorch(outputs, pad_info, orig_shape)

        t2 = time.perf_counter()

        # --- 3. MÄT RITANDET (Valfritt) ---
        if visualize:
            drawn_img = self.draw(img_bgr, results)
        else:
            drawn_img = None
            
        t3 = time.perf_counter()

        # --- SPARA HASTIGHETEN ---
        results["speed"] = {
            "preprocess_ms": round((t1 - t0) * 1000, 2),
            "inference_ms": round((t2 - t1) * 1000, 2),
            "drawing_ms": round((t3 - t2) * 1000, 2),
            "total_ms": round((t3 - t0) * 1000, 2)
        }

        return results, drawn_img

    def _postprocess_onnx(self, outputs, pad_info, orig_shape):
        left, top, nw, nh, scale = pad_info
        h0, w0 = orig_shape
        has_protos = "protos" in self.out_names and self.task == "seg"
        protos_out = outputs[self.out_names.index("protos")][0] if has_protos else None
            
        if self.has_integrated_nms:
            dets = outputs[self.out_names.index("output")][0] 
            mask = dets[:, 4] >= self.conf_thr
            valid_dets = dets[mask]
            boxes_pad = valid_dets[:, :4]
            scores_pad = valid_dets[:, 4]
            classes = valid_dets[:, 5].astype(np.int64)
            mask_coeffs = valid_dets[:, 6:] if (valid_dets.shape[1] > 6 and self.task == "seg") else None
        else:
            boxes = outputs[self.out_names.index("boxes_xyxy")][0]
            cls_log = outputs[self.out_names.index("cls_logits")][0]
            mask_c = outputs[self.out_names.index("mask_coeffs")][0] if has_protos else None
            cls_sig = 1 / (1 + np.exp(-np.clip(cls_log, -88.0, 88.0)))
            scores = cls_sig.max(axis=-1)
            cls_id = cls_sig.argmax(axis=-1).astype(np.int64)

            m = scores > self.conf_thr
            boxes_p, scores_p, cls_p = boxes[m], scores[m], cls_id[m]
            mask_p = mask_c[m] if mask_c is not None else None
            keep = self._nms_np(boxes_p, scores_p, self.iou_thr)
            
            boxes_pad = boxes_p[keep] if len(keep) else np.zeros((0,4))
            scores_pad = scores_p[keep] if len(keep) else np.zeros((0,))
            classes = cls_p[keep] if len(keep) else np.zeros((0,))
            mask_coeffs = mask_p[keep] if (mask_p is not None and len(keep)) else None

        boxes_px = boxes_pad.copy()
        if len(boxes_px) > 0:
            boxes_px[:, [0, 2]] = np.clip((boxes_px[:, [0, 2]] - left) / scale, 0, w0 - 1)
            boxes_px[:, [1, 3]] = np.clip((boxes_px[:, [1, 3]] - top) / scale, 0, h0 - 1)

        final_masks = None
        if has_protos and mask_coeffs is not None and len(mask_coeffs) > 0:
            final_masks = self._process_masks_onnx(protos_out, mask_coeffs, boxes_px, (self.img_size, self.img_size), (h0, w0), pad_info)

        return {"boxes": boxes_px, "scores": scores_pad, "classes": classes, "masks": final_masks}

    def _postprocess_pytorch(self, outputs, pad_info, orig_shape):
        left, top, nw, nh, scale = pad_info
        h0, w0 = orig_shape
        is_seg = isinstance(outputs, dict) and "proto" in outputs and self.task == "seg"
        
        if is_seg:
            from .seg.tools.train import decode_simple_seg 
            boxes_xyxy, coeff_flat, proto, scores, cls_ids = decode_simple_seg(
                outputs, num_classes=len(self.class_names), n_mask=32, img_size=self.img_size, conf_th=self.conf_thr
            )
            coeff_b, proto_b = coeff_flat[0], proto[0]
        else:
            from .det.scripts.helpers.utils_ms import decode_preds_anchorfree 
            decoded_dict = decode_preds_anchorfree(outputs, img_size=self.img_size)
            boxes_xyxy = decoded_dict["box"]
            cls_probs = torch.sigmoid(decoded_dict["cls"])
            scores, cls_ids = torch.max(cls_probs, dim=-1)
            
        boxes_b, scores_b, cls_b = boxes_xyxy[0], scores[0], cls_ids[0]
        score_mask = scores_b > self.conf_thr
        boxes_b, scores_b, cls_b = boxes_b[score_mask], scores_b[score_mask], cls_b[score_mask]
        if is_seg: coeff_b = coeff_b[score_mask]
        
        if len(boxes_b) == 0:
            return {"boxes": np.zeros((0, 4)), "scores": np.zeros((0,)), "classes": np.zeros((0,)), "masks": None}
            
        keep = batched_nms(boxes_b, scores_b, cls_b, iou_threshold=self.iou_thr)[:300]
        boxes_b, scores_b, cls_b = boxes_b[keep], scores_b[keep], cls_b[keep]
        if is_seg: coeff_b = coeff_b[keep]
        
        boxes_b[:, [0, 2]] = torch.clamp((boxes_b[:, [0, 2]] - left) / scale, min=0, max=w0 - 1)
        boxes_b[:, [1, 3]] = torch.clamp((boxes_b[:, [1, 3]] - top) / scale, min=0, max=h0 - 1)
        
        final_masks = None
        if is_seg:
            nm, Hp, Wp = proto_b.shape
            mask_logits = (coeff_b @ proto_b.view(nm, -1)).view(-1, Hp, Wp)
            masks_up = F.interpolate(torch.sigmoid(mask_logits).unsqueeze(1), size=(self.img_size, self.img_size), mode="bilinear", align_corners=False).squeeze(1)
            masks_valid = masks_up[:, top:top+nh, left:left+nw]
            masks_orig = F.interpolate(masks_valid.unsqueeze(1), size=(h0, w0), mode="bilinear", align_corners=False).squeeze(1)
            
            # --- VEKTORISERAD BESKÄRNING PÅ GPU ---
            masks_bin = masks_orig > 0.5
            
            # Skapa koordinat-nätverk
            r = torch.arange(w0, device=self.device).view(1, 1, w0)
            c = torch.arange(h0, device=self.device).view(1, h0, 1)
            
            # Plocka ut box-koordinaterna
            x1 = boxes_b[:, 0].view(-1, 1, 1)
            y1 = boxes_b[:, 1].view(-1, 1, 1)
            x2 = boxes_b[:, 2].view(-1, 1, 1)
            y2 = boxes_b[:, 3].view(-1, 1, 1)
            
            # Skapa en boolesk "inbox"-tensor och applicera på maskerna
            in_box = (r >= x1) & (r < x2) & (c >= y1) & (c < y2)
            final_masks_tensor = masks_bin & in_box
            
            # Flytta till CPU/numpy först HÄR (när all mattematik är klar)
            final_masks = final_masks_tensor.cpu().numpy()
                
        return {
            "boxes": boxes_b.cpu().numpy(), 
            "scores": scores_b.cpu().numpy(), 
            "classes": cls_b.cpu().numpy(), 
            "masks": final_masks
        }

    @staticmethod
    def _nms_np(boxes, scores, iou_th=0.5, max_det=300):
        if len(boxes) == 0: return np.array([], dtype=np.int64)
        x1, y1, x2, y2 = boxes.T
        areas = (x2 - x1).clip(0) * (y2 - y1).clip(0)
        order = scores.argsort()[::-1]
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            if len(keep) >= max_det: break
            xx1, yy1 = np.maximum(x1[i], x1[order[1:]]), np.maximum(y1[i], y1[order[1:]])
            xx2, yy2 = np.minimum(x2[i], x2[order[1:]]), np.minimum(y2[i], y2[order[1:]])
            w, h = (xx2 - xx1).clip(0), (yy2 - yy1).clip(0)
            iou = (w * h) / (areas[i] + areas[order[1:]] - (w * h) + 1e-6)
            order = order[1:][iou <= iou_th]
        return np.array(keep, dtype=np.int64)

    @staticmethod
    def _process_masks_onnx(protos, mask_coeffs, bboxes, img_shape, original_shape, pad_info):
        """100% GPU-Accelererad mask-processering för ONNX & TensorRT"""
        left, top, nw, nh, scale = pad_info
        h0, w0 = original_shape
        
        if mask_coeffs is None or len(mask_coeffs) == 0:
            return np.zeros((0, h0, w0), dtype=bool)

        n, c = mask_coeffs.shape
        _, mh, mw = protos.shape
        if n == 0:
            return np.zeros((0, h0, w0), dtype=bool)

        # 1. Flytta upp allt till GPU direkt för tunga lyft
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        protos_t = torch.from_numpy(protos).to(device)
        coeffs_t = torch.from_numpy(mask_coeffs).to(device)
        bboxes_t = torch.from_numpy(bboxes).to(device)
        
        # 2. Matrismultiplikation & Sigmoid (Inga fler varningar om np.exp!)
        masks = (coeffs_t @ protos_t.view(c, -1)).view(n, mh, mw)
        masks = torch.sigmoid(masks)
        
        # 3. Skala upp till 640x640 (eller img_size) via hårdvaruacceleration
        masks = masks.unsqueeze(1) # [N, 1, H, W]
        masks_up = F.interpolate(masks, size=(img_shape[0], img_shape[1]), mode="bilinear", align_corners=False).squeeze(1)
        
        # 4. Klipp bort padding
        masks_valid = masks_up[:, top:top+nh, left:left+nw]
        
        # 5. Skala upp till bildens verkliga originalupplösning (h0, w0)
        masks_orig = F.interpolate(masks_valid.unsqueeze(1), size=(h0, w0), mode="bilinear", align_corners=False).squeeze(1)
        
        # 6. Binarisera
        masks_bin = masks_orig > 0.5
        
        # 7. VEKTORISERAD Bounding Box Beskärning (Kapar den dyra python for-loopen!)
        r = torch.arange(w0, device=device).view(1, 1, w0)
        c = torch.arange(h0, device=device).view(1, h0, 1)
        
        x1 = bboxes_t[:, 0].view(n, 1, 1)
        y1 = bboxes_t[:, 1].view(n, 1, 1)
        x2 = bboxes_t[:, 2].view(n, 1, 1)
        y2 = bboxes_t[:, 3].view(n, 1, 1)
        
        # Skapa en Boolesk mask för allt innanför boxarna
        in_box = (r >= x1) & (r < x2) & (c >= y1) & (c < y2)
        
        # Applicera beskärningen rent logiskt
        final_masks = masks_bin & in_box
        
        return final_masks.cpu().numpy()

    def draw(self, img, results):
        out = img.copy()
        boxes = results.get("boxes", [])
        scores = results.get("scores", [])
        classes = results.get("classes", [])
        masks = results.get("masks", None)
        
        mask_overlay = np.zeros_like(out)
        
        for i, (b, s, c) in enumerate(zip(boxes, scores, classes)):
            x1, y1, x2, y2 = map(int, b.tolist())
            cls_id = int(c)
            name = self.class_names[cls_id] if 0 <= cls_id < len(self.class_names) else str(cls_id)
            color = self.colors[cls_id % len(self.colors)]
            
            if masks is not None and len(masks) > i: mask_overlay[masks[i]] = color
                
            cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
            label_text = f"{name} {s:.2f}"
            (tw, th), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(out, (x1, max(0, y1 - th - 6)), (x1 + tw + 4, max(th + 6, y1)), color, -1)
            cv2.putText(out, label_text, (x1 + 2, max(th + 3, y1 - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        if masks is not None and len(masks) > 0: out = cv2.addWeighted(out, 1.0, mask_overlay, 0.45, 0)
        return out

def run_predict(weights_path, source, task="det", conf=0.25, iou=0.45, img_size=640, device="cuda:0", save=True, show=False, **kwargs):
    predictor = YoloPredictor(weights_path, task=task, device=device, img_size=img_size, conf_thr=conf, iou_thr=iou)
    source_path = Path(source)
    files = list(source_path.glob("*.*")) if source_path.is_dir() else [source_path]
    save_dir = Path("runs/predict")
    
    if save: save_dir.mkdir(parents=True, exist_ok=True)
    all_results = []

    for f in files:
        if f.suffix.lower() not in ['.jpg', '.jpeg', '.png', '.bmp']: continue
        results, drawn_img = predictor.predict(f)
        results["path"], results["annotated_img"] = str(f), drawn_img 
        all_results.append(results)
        
        if show:
            cv2.imshow("Inference", drawn_img)
            cv2.waitKey(0) 
        if save:
            cv2.imwrite(str(save_dir / f.name), drawn_img)

    if show: cv2.destroyAllWindows()
    return all_results