import argparse
import time
import numpy as np
import torch
import tensorrt as trt

class TRTBenchmarkWrapper:
    def __init__(self, engine_path: str):
        self.logger = trt.Logger(trt.Logger.ERROR)
        trt.init_libnvinfer_plugins(self.logger, "")
        
        with open(engine_path, 'rb') as f, trt.Runtime(self.logger) as runtime:
            self.engine = runtime.deserialize_cuda_engine(f.read())
        self.context = self.engine.create_execution_context()

        self.bindings = []
        self.inputs = []
        self.outputs = []

        # Allokera minne på GPUn baserat på enginens konfiguration
        for i in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(i)
            is_input = self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT
            shape = self.context.get_tensor_shape(name)
            shape = tuple([1 if s == -1 else s for s in shape]) # Lås batch till 1
            trt_dtype = self.engine.get_tensor_dtype(name)
            
            # Konvertera typ
            if trt_dtype == trt.float32: dtype = torch.float32
            elif trt_dtype == trt.float16: dtype = torch.float16
            elif trt_dtype == trt.int32: dtype = torch.int32
            elif trt_dtype == trt.int8: dtype = torch.int8
            elif trt_dtype == trt.uint8: dtype = torch.uint8
            else: dtype = torch.float32

            tensor = torch.empty(shape, dtype=dtype, device='cuda')
            self.bindings.append(tensor.data_ptr())
            
            if is_input: self.inputs.append(tensor)
            else: self.outputs.append(tensor)

    def infer(self):
        # execute_v2 är asynkron, så vi måste synka vid tidtagning
        self.context.execute_v2(self.bindings)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", required=True, help="Sökväg till din .engine fil")
    parser.add_argument("--img-size", type=int, default=640)
    parser.add_argument("--warmup", type=int, default=100, help="Antal uppvärmningskörningar")
    parser.add_argument("--iters", type=int, default=1000, help="Antal mätkörningar")
    args = parser.parse_args()

    print(f"Laddar TensorRT engine: {args.engine}")
    model = TRTBenchmarkWrapper(args.engine)

    # Skapa en statisk dummy-bild direkt på GPUn (uint8, samma som din NormalizeInput förväntar sig)
    dummy_input = torch.zeros((1, 3, args.img_size, args.img_size), dtype=torch.uint8, device='cuda')
    
    # Kopiera in datan en gång till vår pre-allokerade input-buffer
    model.inputs[0].copy_(dummy_input)

    print(f"Värmer upp GPUn ({args.warmup} iterationer)...")
    for _ in range(args.warmup):
        model.infer()

    print(f"Kör hastighetstest ({args.iters} iterationer)...")
    times = []
    
    for _ in range(args.iters):
        # torch.cuda.synchronize() är extremt viktigt! Utan denna mäter vi bara hur 
        # snabbt processorn lägger upp jobbet i kön, inte hur snabbt GPUn kör det.
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        
        model.infer()
        
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        
        times.append((t1 - t0) * 1000) # Spara i millisekunder

    times = np.array(times)
    
    print("\n" + "="*30)
    print(f"⏱️  RESULTAT (Batch Size 1)")
    print("="*30)
    print(f"Genomsnitt:  {times.mean():.3f} ms")
    print(f"Median:      {np.median(times):.3f} ms")
    print(f"Snabbast:    {times.min():.3f} ms")
    print(f"Långsammast: {times.max():.3f} ms")
    print("-" * 30)
    print(f"🚀 FPS:       {1000.0 / times.mean():.1f} bilder/sek")
    print("="*30)

if __name__ == "__main__":
    main()