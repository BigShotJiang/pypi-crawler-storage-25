import argparse, os, sys, time
from pathlib import Path
import numpy as np
import cv2
import onnxruntime as ort

# ============ Utils ============
def next_run_dir(base: str) -> str:
    p = Path(base); p.mkdir(parents=True, exist_ok=True)
    n = 1
    while True:
        cand = p / str(n)
        try:
            cand.mkdir()
            return str(cand.resolve())
        except FileExistsError:
            n += 1

def letterbox(im, new_size=640, color=(114,114,114)):
    h, w = im.shape[:2]
    scale = min(new_size / h, new_size / w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    im_resized = cv2.resize(im, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top = (new_size - nh) // 2
    bottom = new_size - nh - top
    left = (new_size - nw) // 2
    right = new_size - nw - left
    im_padded = cv2.copyMakeBorder(im_resized, top, bottom, left, right,
                                   cv2.BORDER_CONSTANT, value=color)
    return im_padded, scale, (left, top), (nw, nh)

def nms_np(boxes, scores, iou_th=0.5, max_det=300):
    if len(boxes) == 0:
        return np.array([], dtype=np.int64)
    x1, y1, x2, y2 = boxes.T
    areas = (x2 - x1).clip(0) * (y2 - y1).clip(0)
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        if len(keep) >= max_det:
            break
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        w = (xx2 - xx1).clip(0)
        h = (yy2 - yy1).clip(0)
        inter = w * h
        iou = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
        order = order[1:][iou <= iou_th]
    return np.array(keep, dtype=np.int64)

# Färgschema för klasser (upp till 80 färger)
COLORS = np.random.uniform(0, 255, size=(80, 3)).astype(np.uint8)

def draw(img, boxes, scores, classes, masks, names):
    out = img.copy()
    mask_overlay = np.zeros_like(out)
    
    for i, (b, s, c) in enumerate(zip(boxes, scores, classes)):
        x1, y1, x2, y2 = map(int, b.tolist())
        cls_id = int(c)
        name = names[cls_id] if 0 <= cls_id < len(names) else str(cls_id)
        color = COLORS[cls_id % len(COLORS)].tolist()
        
        # Rita bounding box
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        cv2.putText(out, f"{name} {s:.2f}", (x1, max(0, y1-5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Rita mask om de finns
        if masks is not None and len(masks) > i:
            # Masken är binär i originalbildens storlek
            obj_mask = masks[i]
            # Fyll bara i pixlar där masken är 1 (True)
            mask_overlay[obj_mask] = color

    # Lägg maskerna semi-transparent över originalbilden
    if masks is not None and len(masks) > 0:
        out = cv2.addWeighted(out, 1.0, mask_overlay, 0.5, 0)
        
    return out

def process_masks(protos, mask_coeffs, bboxes, img_shape, original_shape, pad_info, no_letterbox):
    """
    Kombinerar prototyper och koefficienter, och skalar om till originalbild.
    protos: [C, MH, MW]
    mask_coeffs: [N, C]
    bboxes: [N, 4] i original_shape (för crop-optimering)
    """
    n, c = mask_coeffs.shape
    _, mh, mw = protos.shape
    
    if n == 0:
        return np.zeros((0, original_shape[0], original_shape[1]), dtype=bool)

    # 1. Multiplicera koefficienter med prototyper: [N, C] @ [C, MH*MW] -> [N, MH*MW]
    masks = mask_coeffs @ protos.reshape(c, -1)
    masks = masks.reshape(n, mh, mw)
    
    # 2. Applicera Sigmoid
    masks = 1 / (1 + np.exp(-masks))
    
    # 3. Skala upp till modellens inspelningsstorlek (t.ex. 640x640)
    masks = masks.transpose(1, 2, 0)  # [MH, MW, N] för cv2.resize
    masks_up = cv2.resize(masks, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_LINEAR)
    if n == 1:
        masks_up = masks_up[..., None]
    masks_up = masks_up.transpose(2, 0, 1)  # Tillbaka till [N, H, W]
    
    # 4. Klipp till originalbilden och skala
    h0, w0 = original_shape
    final_masks = []
    
    if no_letterbox:
        # Om vi ful-skalade bilden, skala bara tillbaka masken
        masks_up = masks_up.transpose(1, 2, 0)
        masks_orig = cv2.resize(masks_up, (w0, h0), interpolation=cv2.INTER_LINEAR)
        if n == 1: masks_orig = masks_orig[..., None]
        masks_orig = masks_orig.transpose(2, 0, 1)
    else:
        left, top, nw, nh = pad_info
        # Beskär bort padding
        masks_valid = masks_up[:, top:top+nh, left:left+nw]
        
        # Skala tillbaka till originalbildens upplösning
        masks_valid = masks_valid.transpose(1, 2, 0)
        masks_orig = cv2.resize(masks_valid, (w0, h0), interpolation=cv2.INTER_LINEAR)
        if n == 1: masks_orig = masks_orig[..., None]
        masks_orig = masks_orig.transpose(2, 0, 1)
        
    # 5. Beskär maskerna till bounding boxen för att ta bort "spök-masker"
    # samt threshold (gör dem binära > 0.5)
    out_masks = np.zeros((n, h0, w0), dtype=bool)
    for i in range(n):
        x1, y1, x2, y2 = map(int, bboxes[i])
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w0, x2), min(h0, y2)
        # Sätt till True bara inom boxen
        out_masks[i, y1:y2, x1:x2] = masks_orig[i, y1:y2, x1:x2] > 0.5
        
    return out_masks

def build_session(model_path, providers, intra, inter):
    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    if intra is not None and intra >= 0: so.intra_op_num_threads = int(intra)
    if inter is not None and inter >= 0: so.inter_op_num_threads = int(inter)

    prov = []
    p = providers.lower()
    if p == "cuda": prov = ["CUDAExecutionProvider", "CPUExecutionProvider"]
    elif p == "tensorrt": prov = ["TensorrtExecutionProvider", "CUDAExecutionProvider", "CPUExecutionProvider"]
    else: prov = ["CPUExecutionProvider"]
    return ort.InferenceSession(str(model_path), sess_options=so, providers=prov)

# ============ Main ============
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Path to .onnx model")
    ap.add_argument("--img", default=None)
    ap.add_argument("--img_dir", default=None)
    ap.add_argument("--img_size", type=int, default=640, help="Must match ONNX img_size")
    ap.add_argument("--conf", type=float, default=0.3)
    ap.add_argument("--iou", type=float, default=0.3)
    ap.add_argument("--max_det", type=int, default=300)
    ap.add_argument("--no_letterbox", action="store_true")
    ap.add_argument("--names", default=None, help="Comma_seperated list or file")
    ap.add_argument("--providers", default="cpu", choices=["cpu","cuda","tensorrt"])
    ap.add_argument("--warmup", type=int, default=10, help="Warmup iterations")
    ap.add_argument("--runs", type=int, default=1, help="Runs per image")
    ap.add_argument("--intra", type=int, default=0, help="intra_op_num_threads")
    ap.add_argument("--inter", type=int, default=0, help="inter_op_num_threads")
    args = ap.parse_args()

    names = []
    if args.names and Path(args.names).exists():
        with open(args.names, "r", encoding="utf-8") as f: names = [ln.strip() for ln in f if ln.strip()]
    elif args.names and "," in args.names:
        names = [s.strip() for s in args.names.split(",")]
    else:
        names = [str(i) for i in range(80)]

    sess = build_session(args.model, args.providers, args.intra, args.inter)
    in_name = sess.get_inputs()[0].name
    out_names = [o.name for o in sess.get_outputs()]
    
    has_nms = "output" in out_names
    has_protos = "protos" in out_names
    
    print(f"Modellformat identifierat som: {'Decoded_NMS (Graph NMS)' if has_nms else 'Decoded (Python NMS)'}")
    print(f"Segmentering (Masker): {'Ja' if has_protos else 'Nej'}")

    run_dir = next_run_dir("runs/onnx_infer")

    if args.img and Path(args.img).exists(): paths = [args.img]
    elif args.img_dir and Path(args.img_dir).exists():
        exts = (".jpg",".jpeg",".png",".bmp")
        paths = sorted([str(p) for p in Path(args.img_dir).glob("*") if p.suffix.lower() in exts])
    else: raise SystemExit("Ange --img eller --img_dir")

    dummy = np.zeros((1, 3, args.img_size, args.img_size), dtype=np.uint8)
    for _ in range(max(0, args.warmup)): _ = sess.run(out_names, {in_name: dummy})

    rows = []
    pre_times = []; infer_times = []; post_times = []; total_times = []

    for p in paths:
        img0 = cv2.imread(p)
        if img0 is None: continue

        # --- Preprocess ---
        t_pre0 = time.perf_counter()
        h0, w0 = img0.shape[:2]

        if args.no_letterbox:
            lb = cv2.resize(img0, (args.img_size, args.img_size), interpolation=cv2.INTER_LINEAR)
            padx = pady = nw = nh = 0
            scale = None
        else:
            lb, scale, (padx, pady), (nw, nh) = letterbox(img0, args.img_size)

        im = cv2.cvtColor(lb, cv2.COLOR_BGR2RGB)
        im = np.transpose(im, (2,0,1))[None].astype(np.uint8) 
        # --- LÄGG TILL DETTA ---
        print(f"DEBUG: Bild min={im.min()}, max={im.max()}, dtype={im.dtype}")
        # ----------------------
        t_pre1 = time.perf_counter()

        for run_idx in range(max(1, args.runs)):
            # --- Inference ---
            t_inf0 = time.perf_counter()
            outputs = sess.run(out_names, {in_name: im})
            t_inf1 = time.perf_counter()

            # --- Postprocess ---
            t_post0 = time.perf_counter()
            
            protos_out = None
            if has_protos:
                protos_out = outputs[out_names.index("protos")][0]
                
            if has_nms:
                dets = outputs[out_names.index("output")][0] 
                mask = dets[:, 4] >= args.conf
                valid_dets = dets[mask]
                
                boxes_pad = valid_dets[:, :4]
                scores_pad = valid_dets[:, 4]
                classes = valid_dets[:, 5].astype(np.int64)
                mask_coeffs = valid_dets[:, 6:] if valid_dets.shape[1] > 6 else None
                
            else:
                boxes = outputs[out_names.index("boxes_xyxy")][0]
                cls_log = outputs[out_names.index("cls_logits")][0]
                mask_c = outputs[out_names.index("mask_coeffs")][0] if has_protos else None
                
                cls_sig = 1 / (1 + np.exp(-cls_log)) 
                scores = cls_sig.max(axis=-1)
                cls_id = cls_sig.argmax(axis=-1).astype(np.int64)

                m = scores > args.conf
                boxes_p = boxes[m]
                scores_p = scores[m]
                cls_p = cls_id[m]
                mask_p = mask_c[m] if mask_c is not None else None
                
                final_b, final_s, final_c, final_m = [], [], [], []
                
                for c in np.unique(cls_p):
                    mc = (cls_p == c)
                    keep = nms_np(boxes_p[mc], scores_p[mc], args.iou, args.max_det)
                    if keep.size:
                        final_b.append(boxes_p[mc][keep])
                        final_s.append(scores_p[mc][keep])
                        final_c.append(np.full((keep.size,), int(c), dtype=np.int64))
                        if mask_p is not None:
                            final_m.append(mask_p[mc][keep])

                if final_b:
                    boxes_pad  = np.concatenate(final_b, 0)
                    scores_pad = np.concatenate(final_s, 0)
                    classes    = np.concatenate(final_c, 0)
                    mask_coeffs= np.concatenate(final_m, 0) if final_m else None
                else:
                    boxes_pad  = np.zeros((0,4), np.float32)
                    scores_pad = np.zeros((0,), np.float32)
                    classes    = np.zeros((0,), np.int64)
                    mask_coeffs= None

            # 1. Back-map boxar till originalbild[cite: 3]
            boxes_px = boxes_pad.copy()
            if len(boxes_px) > 0:
                if args.no_letterbox:
                    sx = w0 / float(args.img_size)
                    sy = h0 / float(args.img_size)
                    boxes_px[:, [0, 2]] *= sx
                    boxes_px[:, [1, 3]] *= sy
                else:
                    boxes_px[:, [0, 2]] -= padx
                    boxes_px[:, [1, 3]] -= pady
                    boxes_px /= max(scale, 1e-6)

                boxes_px[:, [0, 2]] = np.clip(boxes_px[:, [0, 2]], 0, w0 - 1)
                boxes_px[:, [1, 3]] = np.clip(boxes_px[:, [1, 3]], 0, h0 - 1)

            # 2. Processa Masker
            final_masks = None
            if has_protos and mask_coeffs is not None and len(mask_coeffs) > 0:
                pad_info = (padx, pady, nw, nh)
                final_masks = process_masks(
                    protos_out, mask_coeffs, boxes_px, 
                    (args.img_size, args.img_size), (h0, w0), 
                    pad_info, args.no_letterbox
                )

            t_post1 = time.perf_counter()

            pre_ms   = (t_pre1 - t_pre0)*1000.0
            inf_ms   = (t_inf1 - t_inf0)*1000.0
            post_ms  = (t_post1 - t_post0)*1000.0
            total_ms = pre_ms + inf_ms + post_ms

            pre_times.append(pre_ms); infer_times.append(inf_ms); post_times.append(post_ms); total_times.append(total_ms)

        # Rita ut allt på bilden
        vis = img0.copy()
        vis = draw(vis, boxes_px, scores_pad, classes, final_masks, names)
        
        out_img = str(Path(run_dir)/f"{Path(p).stem}_pred.jpg")
        cv2.imwrite(out_img, vis)
        print(f"✓ Bearbetat: {out_img} ({len(boxes_px)} hittade objekt)")

    # --- sammanfattning ---
    def stats(x):
        if not x: return dict(mean=0, std=0, p50=0, p90=0, p95=0)
        x = np.array(x, dtype=np.float64)
        return dict(mean=float(np.mean(x)), std=float(np.std(x)),
                    p50=float(np.percentile(x,50)), p90=float(np.percentile(x,90)), p95=float(np.percentile(x,95)))
    
    summary = {
        "pre_ms": stats(pre_times), "infer_ms": stats(infer_times),
        "post_ms": stats(post_times), "total_ms": stats(total_times),
    }

    print("\n=== Inference timing (ms) ===")
    for k in ["pre_ms","infer_ms","post_ms","total_ms"]:
        s = summary[k]
        print(f"{k:9s} mean {s['mean']:.2f} | std {s['std']:.2f} | p50 {s['p50']:.2f} | p90 {s['p90']:.2f} | p95 {s['p95']:.2f}")
    if total_times:
        print(f"Throughput ≈ {1000.0/(np.mean(total_times)):.2f} img/s")
    print(f"\nSparat till: {run_dir}")

if __name__ == "__main__":
    main()