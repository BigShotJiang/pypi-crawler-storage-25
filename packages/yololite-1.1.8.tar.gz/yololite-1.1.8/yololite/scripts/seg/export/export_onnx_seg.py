# tools/export_onnx.py
import argparse
import os
import sys
from pathlib import Path
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.ops import nms




# ========= util: prints =========
def log(msg: str, verbose: bool):
    print(msg, flush=True) if verbose else None

def must(msg: str):
    print(msg, flush=True)

# ========= run-dir =========
def next_run_dir(base: str) -> str:
    root = Path(base)
    root.mkdir(parents=True, exist_ok=True)
    n = 1
    while True:
        cand = root / str(n)
        try:
            cand.mkdir(parents=False, exist_ok=False)
            return str(cand.resolve())
        except FileExistsError:
            n += 1

# ========= NORMALISERING I GRAFEN =========
class NormalizeInput(nn.Module):
    """
    Konverterar indatan från uint8 [0, 255] till rätt float-typ, 
    samt sköter normaliseringen direkt på GPU/i ONNX-grafen.
    """
    def __init__(self, core_model, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):
        super().__init__()
        self.core_model = core_model
        # Registrerar som buffertar så de inkluderas i ONNX-vikterna
        self.register_buffer('mean', torch.tensor(mean).view(1, 3, 1, 1))
        self.register_buffer('std', torch.tensor(std).view(1, 3, 1, 1))

    def forward(self, x):
        x = x.to(self.mean.dtype) / 255.0 
        x = (x - self.mean) / self.std
        return self.core_model(x)

# ========= decoded wrapper (Segmentering) =========
class AFDecode(nn.Module):
    def __init__(self, img_size: int, num_classes: int, center_mode: str = "v8", wh_mode: str = "softplus"):
        super().__init__()
        self.img_size = int(img_size)
        self.num_classes = num_classes
        self.center_mode = center_mode
        self.wh_mode = wh_mode

    @staticmethod
    def _xywh_to_xyxy(xywh: torch.Tensor) -> torch.Tensor:
        x, y, w, h = xywh.unbind(-1)
        return torch.stack([x - w * 0.5, y - h * 0.5, x + w * 0.5, y + h * 0.5], dim=-1)

    def _decode_level(self, p: torch.Tensor):
        if p.dim() == 4:
            p = p.unsqueeze(1)
        B, A, S, _, D = p.shape
        cell = float(self.img_size) / float(S)

        # --- ONNX-SÄKER MESHGRID ---
        # Istället för torch.meshgrid, skapar vi grid:et mer explicit.
        # Detta undviker kända "Gather"/"Shape" buggar i exporterade ONNX-grafer.
        grid_y = torch.arange(S, device=p.device).float()
        grid_x = torch.arange(S, device=p.device).float()
        
        # Expandera till rätt dimensioner [S, S]
        gy = grid_y.view(-1, 1).expand(S, S)
        gx = grid_x.view(1, -1).expand(S, S)
        # ---------------------------

        tx = p[..., 0]; ty = p[..., 1]
        tw = p[..., 2]; th = p[..., 3]
        
        tcls = p[..., 4 : 4 + self.num_classes]
        tmask = p[..., 4 + self.num_classes :]

        if self.center_mode == "v8":
            px = ((tx.sigmoid() * 2.0 - 0.5) + gx) * cell
            py = ((ty.sigmoid() * 2.0 - 0.5) + gy) * cell
        else:
            px = (tx.sigmoid() + gx) * cell
            py = (ty.sigmoid() + gy) * cell

        if self.wh_mode == "v8":
            pw = (tw.sigmoid() * 2).pow(2) * cell
            ph = (th.sigmoid() * 2).pow(2) * cell
        elif self.wh_mode == "softplus":
            pw = F.softplus(tw) * cell
            ph = F.softplus(th) * cell
        else:
            # EXP kan också vara farligt i ONNX vid höga värden, 
            # men du verkar använda softplus normalt sett.
            pw = tw.clamp(-4, 4).exp() * cell
            ph = th.clamp(-4, 4).exp() * cell

        xyxy = self._xywh_to_xyxy(torch.stack([px, py, pw, ph], dim=-1))
        
        # Clamp kan ibland störa dynamiska axlar, men är oftast OK om img_size är fast.
        xyxy = xyxy.clamp(0, self.img_size - 1)

        xyxy = xyxy.reshape(B, -1, 4)
        cls  = tcls.reshape(B, -1, tcls.shape[-1])
        mask = tmask.reshape(B, -1, tmask.shape[-1])
        return xyxy, cls, mask

    def forward(self, preds):
        if not isinstance(preds, (list, tuple)):
            preds = [preds]
        boxes, clss, masks = [], [], []
        for p in preds:
            b, c, m = self._decode_level(p)
            boxes.append(b); clss.append(c); masks.append(m)
            
        boxes = torch.cat(boxes, dim=1)
        cls   = torch.cat(clss,  dim=1)
        mask  = torch.cat(masks, dim=1)
        return boxes, cls, mask

# ========= build model from meta/config =========
def build_model_from_meta(meta: dict) -> nn.Module:
    # Försöker en mer generell laddning:
    from ..scripts.model.model_v2 import YOLOE_Nano_Seg
    
    cfg  = meta.get("config", {}) or {}
    mcfg = cfg.get("model", {}) or {}
    
    backbone = meta.get("backbone", "mobilenetv4_conv_small")
    num_classes = int(meta.get("num_classes", 3))
    fpn_channels = int(mcfg.get("fpn_channels", 64))
    num_masks = int(mcfg.get("num_masks", 32))
    
    
    model = YOLOE_Nano_Seg(
        backbone=backbone,
        num_classes=num_classes,
        fpn_channels=fpn_channels,
        n_mask=num_masks
    )
    return model

# ========= load ckpt =========
# ========= load ckpt =========
def load_model_from_ckpt(weights: str, device: torch.device, verbose: bool) -> Tuple[nn.Module, dict]:
    if not os.path.isfile(weights):
        raise FileNotFoundError(f"Weights not found: {weights}")
    must(f"• Reading weights: {weights}")
    ckpt = torch.load(weights, map_location=device)
    if not (isinstance(ckpt, dict) and "state_dict" in ckpt and "meta" in ckpt):
        raise RuntimeError("Checkpoint saknar 'state_dict'/'meta' – spara via save_checkpoint_state(...).")
    meta = ckpt["meta"] or {}
    model = build_model_from_meta(meta)
    missing, unexpected = model.load_state_dict(ckpt["state_dict"], strict=False)
    if missing:    must(f"  [load_state_dict] saknade nycklar: {len(missing)}")
    if unexpected: must(f"  [load_state_dict] oväntade nycklar: {len(unexpected)}")
    model.to(device).eval()
    must(f"• Model built: backbone={meta.get('backbone')} nc={meta.get('num_classes')}")
    return model, meta
'''
# ========= load ckpt =========
def load_model_from_ckpt(weights: str, device: torch.device, verbose: bool) -> Tuple[nn.Module, dict]:
    if not os.path.isfile(weights):
        raise FileNotFoundError(f"Viktfil hittas inte: {weights}")
    must(f"• Läser checkpoint: {weights}")
    ckpt = torch.load(weights, map_location=device)
    
    meta = ckpt.get("meta", {})
    log(f"  meta.keys: {list(meta.keys())}", verbose)
    model = build_model_from_meta(meta)

    # 1. Hitta rätt vikter (Prio 1: EMA, Prio 2: model_state_dict, Prio 3: state_dict)
    if "ema_state_dict" in ckpt and ckpt["ema_state_dict"] is not None:
        must("  -> Använder EMA-vikter (Bättre stabilitet och prestanda!)")
        state_dict = ckpt["ema_state_dict"]
    elif "model_state_dict" in ckpt:
        must("  -> Använder model_state_dict")
        state_dict = ckpt["model_state_dict"]
    elif "state_dict" in ckpt:
        must("  -> Använder state_dict")
        state_dict = ckpt["state_dict"]
    else:
        raise RuntimeError("Hittade ingen giltig state_dict i din checkpoint!")

    # 2. Rensa bort eventuella prefix från DDP/EMA (t.ex. "module.", "ema_model.")
    clean_state_dict = {}
    for k, v in state_dict.items():
        new_key = k.replace("ema_model.", "").replace("module.", "").replace("model.", "")
        clean_state_dict[new_key] = v

    # 3. Ladda in med strict=True. Om detta kraschar, MÅSTE vi veta det!
    try:
        model.load_state_dict(clean_state_dict, strict=True)
        must("  [load_state_dict] ✓ Vikter laddades PERFEKT in i grafen!")
    except Exception as e:
        must(f"  [KRITISKT FEL] Vikterna i filen matchar inte YOLOE_Nano_Seg! Felmeddelande:\n{e}")
        raise

    model.to(device).eval()
    must(f"• Modell byggd: backbone={meta.get('backbone')} nc={meta.get('num_classes')}")
    return model, meta
'''
# ========= NMS wrapper for ONNX export =========
class _NMSWrapper(nn.Module):
    def __init__(self, model: nn.Module, decode: nn.Module,
                 max_detections: int = 300,
                 iou_threshold: float = 0.7,
                 score_threshold: float = 0.25,
                 batch_size: int = 1):
        super().__init__()
        self.model = model
        self.decode = decode
        self.max_det = max_detections
        self.iou_threshold = iou_threshold
        self.score_threshold = score_threshold
        self.batch_size = batch_size

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        out_dict = self.model(x)
        raw_det = out_dict["det"]
        protos = out_dict["proto"]
        
        boxes_xyxy, cls_logits, mask_coeffs = self.decode(raw_det)
        
        cls_prob = torch.sigmoid(cls_logits)           # [B, N, C]
        cls_max, cls_idx = cls_prob.max(dim=-1)        # [B, N]
        confidence = cls_max                           # [B, N]

        bs = x.shape[0]
        out_dtype = boxes_xyxy.dtype 
        kwargs = dict(device=x.device, dtype=out_dtype)

        pad_n = self.batch_size - bs
        if pad_n > 0:
            pad_boxes = torch.zeros(pad_n, boxes_xyxy.shape[1], 4, **kwargs)
            pad_conf = torch.zeros(pad_n, confidence.shape[1], **kwargs)
            pad_cls = torch.zeros(pad_n, cls_idx.shape[1], device=x.device, dtype=cls_idx.dtype)
            pad_masks = torch.zeros(pad_n, mask_coeffs.shape[1], mask_coeffs.shape[-1], **kwargs)
            
            boxes_xyxy = torch.cat([boxes_xyxy, pad_boxes])
            confidence = torch.cat([confidence, pad_conf])
            cls_idx = torch.cat([cls_idx, pad_cls])
            mask_coeffs = torch.cat([mask_coeffs, pad_masks])

        # 6 + n_mask (4 box, 1 conf, 1 cls, n_mask mask_coeffs)
        output_dim = 6 + mask_coeffs.shape[-1]
        output = torch.zeros(self.batch_size, self.max_det, output_dim, **kwargs)

        for i in range(bs):
            score = confidence[i]
            score = score * (score > self.score_threshold)
            topk = score.topk(min(self.max_det * 5, score.shape[0])).indices
            
            box = boxes_xyxy[i][topk]
            score = score[topk]
            cls = cls_idx[i][topk]
            m_coeffs = mask_coeffs[i][topk]

            nms_box = box / float(self.decode.img_size)
            keep = nms(nms_box, score, self.iou_threshold)[:self.max_det]
            
            dets = torch.cat([
                box[keep], 
                score[keep].unsqueeze(-1),
                cls[keep].unsqueeze(-1).to(output.dtype),
                m_coeffs[keep]
            ], dim=-1)
            
            output[i] = F.pad(dets, (0, 0, 0, self.max_det - dets.shape[0]))

        # Returnerar utdatan och prototyperna
        return output[:bs], protos[:bs]

# ========= EXPORT FUNKTIONER =========

def export_decoded_onnx(checkpoint_path: str, meta: dict, img_size: int, out_path: str, opset: int = 17, center_mode: str = "v8", wh_mode: str = "softplus", dynamic_batch: bool = True) -> None:
    device = torch.device("cpu")
    model, _ = load_model_from_ckpt(checkpoint_path, device=device, verbose=False)
    
    model_with_norm = NormalizeInput(model)
    num_classes = int(meta.get("num_classes", 3))

    class _DecodedWrapper(nn.Module):
        def __init__(self, core, size, num_classes, center_mode, wh_mode):
            super().__init__()
            self.core = core
            self.decode = AFDecode(img_size=size, num_classes=num_classes, center_mode=center_mode, wh_mode=wh_mode)

        def forward(self, x):
            out_dict = self.core(x)
            boxes, cls, masks = self.decode(out_dict["det"])
            return boxes, cls, masks, out_dict["proto"]

    wrapper = _DecodedWrapper(model_with_norm, img_size, num_classes, center_mode, wh_mode).eval()
    dummy = torch.zeros(1, 3, img_size, img_size, device=device, dtype=torch.uint8)
    
    dynamic_axes = None
    if dynamic_batch:
        dynamic_axes = {
            "images": {0: "batch"}, 
            "boxes_xyxy": {0: "batch"}, 
            "cls_logits": {0: "batch"},
            "mask_coeffs": {0: "batch"},
            "protos": {0: "batch"}
        }
        
    with torch.no_grad():
        torch.onnx.export(
            wrapper, dummy, out_path, opset_version=opset,
            input_names=["images"], output_names=["boxes_xyxy", "cls_logits", "mask_coeffs", "protos"],
            dynamic_axes=dynamic_axes, do_constant_folding=True, external_data=False,
        )

def export_decoded_nms_onnx(checkpoint_path: str, meta: dict, img_size: int, out_path: str, opset: int = 17, center_mode: str = "v8", wh_mode: str = "softplus", max_detections: int = 300, iou_threshold: float = 0.7, score_threshold: float = 0.25, batch_size: int = 1) -> None:
    device = torch.device("cpu")
    model, _ = load_model_from_ckpt(checkpoint_path, device=device, verbose=False)

    model_with_norm = NormalizeInput(model)
    num_classes = int(meta.get("num_classes", 3))

    wrapper = _NMSWrapper(
        model=model_with_norm,
        decode=AFDecode(img_size=img_size, num_classes=num_classes, center_mode=center_mode, wh_mode=wh_mode),
        max_detections=max_detections,
        iou_threshold=iou_threshold,
        score_threshold=score_threshold,
        batch_size=batch_size,
    ).eval()

    dummy = torch.zeros(batch_size, 3, img_size, img_size, device=device, dtype=torch.uint8)
    with torch.no_grad():
        torch.onnx.export(
            wrapper, dummy, out_path, opset_version=opset,
            input_names=["images"], output_names=["output", "protos"],
            dynamic_axes={"images": {0: "batch"}, "output": {0: "batch"}, "protos": {0: "batch"}},
            do_constant_folding=True, external_data=False,
        )

def export_raw_onnx(checkpoint_path: str, img_size: int, out_path: str, opset: int = 17, dynamic_batch: bool = False, dynamic_shape: bool = False, device: str = "cpu", half: bool = False, verbose: bool = False) -> None:
    device_t = torch.device(f"cuda:0" if device != "cpu" and torch.cuda.is_available() else "cpu")
    model, meta = load_model_from_ckpt(checkpoint_path, device=device_t, verbose=verbose)

    if half and device_t.type == "cuda":
        model.half()
        
    model_with_norm = NormalizeInput(model)
    dummy = torch.zeros(1, 3, img_size, img_size, device=device_t, dtype=torch.uint8)

    class _RawWrapper(nn.Module):
        def __init__(self, core):
            super().__init__()
            self.core = core
        def forward(self, x):
            y = self.core(x)
            # YOLOE_Nano_Seg returnerar en dictionary: {"det": [...], "proto": ...}
            # För ONNX export måste vi packa upp den till en tuple
            det_outs = tuple(y["det"]) if isinstance(y["det"], (list, tuple)) else (y["det"],)
            return det_outs + (y["proto"],)

    wrapper = _RawWrapper(model_with_norm)

    with torch.inference_mode():
        outs = wrapper(dummy)
    
    # Namnge utgångarna. De första är detektionsnivåerna, den sista är prototyperna.
    output_names = [f"det_p{i}" for i in range(len(outs) - 1)] + ["protos"]
    log(f"  output_names={output_names}", verbose)

    dynamic_axes = None
    if dynamic_batch or dynamic_shape:
        dynamic_axes = {"images": {0: "batch"}}
        for name in output_names:
            dynamic_axes[name] = {0: "batch"}
        if dynamic_shape:
            dynamic_axes["images"][2] = "height"
            dynamic_axes["images"][3] = "width"

    with torch.no_grad():
        torch.onnx.export(
            wrapper, dummy, out_path, opset_version=opset,
            input_names=["images"], output_names=output_names,
            dynamic_axes=dynamic_axes, do_constant_folding=True, external_data=False,
        )

# ========= top-level callable =========
def run_export(weights: str, out: str = None, img_size: int = 640, format: str = "decoded", opset: int = 17, device: str = "cpu", half: bool = False, simplify: bool = False, dynamic_batch: bool = False, dynamic_shape: bool = False, center_mode: str = "v8", wh_mode: str = "softplus", batch_size: int = 1, max_detections: int = 300, iou_threshold: float = 0.7, score_threshold: float = 0.3, verbose: bool = False) -> str:
    device_t = torch.device("cuda:0" if device != "cpu" and torch.cuda.is_available() else "cpu")
    must(f"• Device: {device_t}")

    model, meta = load_model_from_ckpt(weights, device_t, verbose=verbose)

    meta_img_size = int(meta.get("img_size", img_size))
    resolved_size = int(img_size) if img_size else meta_img_size
    must(f"• img_size: {resolved_size}")

    if half and device_t.type == "cuda":
        model.half()
        must("• FP16: ON")

    dummy = torch.zeros(1, 3, resolved_size, resolved_size, device=device_t, dtype=torch.uint8)
    model_with_norm = NormalizeInput(model)
    
    with torch.inference_mode():
        y = model_with_norm(dummy)
    
    if isinstance(y, dict) and "det" in y and "proto" in y:
        must(f"• Torrkörning OK: Seg-modell identifierad. Det-utgångar: {len(y['det'])}, Protos: {y['proto'].shape}.")
    else:
        must("• Torrkörning OK: 1 utgång (okänt format).")

    export_dir = next_run_dir("runs/export")
    format_names = {"decoded": "model_decoded.onnx", "decoded_nms": "model_decoded_nms.onnx", "raw": "model.onnx"}
    out_path = Path(out) if out else Path(export_dir) / format_names[format]
    must(f"• Export-katalog: {export_dir}")
    must(f"• Skriver: {out_path}")

    try:
        if format == "raw":
            export_raw_onnx(weights, resolved_size, str(out_path), opset, dynamic_batch, dynamic_shape, device, half, verbose)
            must("✓ ONNX export (raw) klar")
        elif format == "decoded_nms":
            export_decoded_nms_onnx(weights, meta, resolved_size, str(out_path), opset, center_mode, wh_mode, max_detections, iou_threshold, score_threshold, batch_size)
            must("✓ ONNX export (decoded + NMS) klar")
        else:  # decoded
            export_decoded_onnx(weights, meta, resolved_size, str(out_path), opset, center_mode, wh_mode, dynamic_batch)
            must("✓ ONNX export (decoded) klar")
    except Exception as e:
        raise RuntimeError(f"ONNX-export ({format}) misslyckades: {e}") from e

    if simplify:
        try:
            import onnx, onnxsim
            model_onnx = onnx.load(str(out_path))
            model_simplified, ok = onnxsim.simplify(model_onnx)
            if ok:
                onnx.save(model_simplified, str(out_path))
                must("✓ ONNX simplified")
            else:
                must("! onnxsim returnerade ok=False (sparar osimplifierad)")
        except Exception as e:
            must(f"! onnxsim misslyckades: {e}")

    must("Klart.")
    return str(out_path)

# ========= CLI =========
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True, help="Path to checkpoint (.pt/.pth)")
    ap.add_argument("--out", default=None, help="save path (.onnx)")
    ap.add_argument("--img-size", type=int, default=640, help="(H=W)")
    ap.add_argument("--device", default="cpu", help="'cpu' or cuda index '0'")
    ap.add_argument("--opset", type=int, default=17)
    ap.add_argument("--half", action="store_true", help="FP16")
    ap.add_argument("--simplify", action="store_true", help="onnxsim after export")
    ap.add_argument("--dynamic-batch", action="store_true", help="Dynamic batch-dimension")
    ap.add_argument("--dynamic-shape", action="store_true", help="Dynamic H/W (raw format only)")
    ap.add_argument("--format", choices=["raw", "decoded", "decoded_nms"], default="decoded_nms")
    ap.add_argument("--center-mode", default="v8", choices=["v8", "sigmoid"])
    ap.add_argument("--wh-mode", default="softplus", choices=["softplus", "v8", "exp"])
    ap.add_argument("--verbose", action="store_true", help="Detailed logg")
    args = ap.parse_args()

    run_export(weights=args.weights, out=args.out, img_size=args.img_size, format=args.format, opset=args.opset, device=args.device, half=args.half, simplify=args.simplify, dynamic_batch=args.dynamic_batch, dynamic_shape=args.dynamic_shape, center_mode=args.center_mode, wh_mode=args.wh_mode, verbose=args.verbose)

if __name__ == "__main__":
    main()