import argparse
import os
import tensorrt as trt

def build_engine(onnx_path: str, engine_path: str, img_size: int = 640, fp16: bool = True):
    logger = trt.Logger(trt.Logger.INFO)
    builder = trt.Builder(logger)
    config = builder.create_builder_config()
    
    # Sätt workspace size (här 4GB, öka om du har komplexa modeller)
    config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 4 * 1024 * 1024 * 1024)

    if fp16 and builder.platform_has_fast_fp16:
        logger.log(trt.Logger.INFO, "Aktiverar FP16-optimering...")
        config.set_flag(trt.BuilderFlag.FP16)

    # Explicita batchar krävs för moderna ONNX-modeller
    network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    parser = trt.OnnxParser(network, logger)

    if not os.path.exists(onnx_path):
        raise FileNotFoundError(f"Hittade inte ONNX-filen: {onnx_path}")

    logger.log(trt.Logger.INFO, f"Tolkar ONNX-fil: {onnx_path}")
    with open(onnx_path, 'rb') as model:
        if not parser.parse(model.read()):
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            raise RuntimeError("Misslyckades att tolka ONNX-filen.")

    # Optimera för Batch Size = 1
    profile = builder.create_optimization_profile()
    input_tensor = network.get_input(0)
    
    # Eftersom din ONNX förväntar sig (B, 3, H, W)
    shape = (1, 3, img_size, img_size)
    profile.set_shape(input_tensor.name, min=shape, opt=shape, max=shape)
    config.add_optimization_profile(profile)

    logger.log(trt.Logger.INFO, f"Bygger TensorRT engine för input shape: {shape}. Detta kan ta några minuter...")
    engine_bytes = builder.build_serialized_network(network, config)
    
    if engine_bytes is None:
        raise RuntimeError("Misslyckades att bygga engine.")

    with open(engine_path, 'wb') as f:
        f.write(engine_bytes)
    logger.log(trt.Logger.INFO, f"Klart! Engine sparad till: {engine_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--onnx", required=True, help="Sökväg till din .onnx")
    parser.add_argument("--out", required=True, help="Sökväg för att spara .engine")
    parser.add_argument("--img-size", type=int, default=640, help="Bildstorlek (H=W)")
    parser.add_argument("--fp16", action="store_true", help="Kompilera i FP16 (Halv precision)")
    args = parser.parse_args()

    build_engine(args.onnx, args.out, args.img_size, args.fp16)