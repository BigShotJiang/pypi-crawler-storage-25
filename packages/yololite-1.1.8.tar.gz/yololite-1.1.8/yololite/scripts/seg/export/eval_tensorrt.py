import argparse
import os
import time
from pathlib import Path
import cv2
import numpy as np
import torch
import tensorrt as trt
from torch.utils.data import Dataset, DataLoader
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from tqdm import tqdm

# ==========================================
# 1. MINIMAL EVAL DATASET
# ==========================================
class SimpleEvalDataset(Dataset):
    """En lättviktig dataset-klass enbart för utvärdering."""
    def __init__(self, img_dir, label_dir, img_size=640):
        self.img_dir = Path(img_dir)
        self.label_dir = Path(label_dir)
        self.img_size = img_size
        
        valid_exts = {".jpg", ".jpeg", ".png"}
        self.images = sorted([p for p in self.img_dir.iterdir() if p.suffix.lower() in valid_exts])
        
        if not self.images:
            raise ValueError(f"Hittade inga bilder i {img_dir}")

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_path = self.images[idx]
        label_path = self.label_dir / f"{img_path.stem}.txt"

        # --- LÄS OCH PREP BILD ---
        img = cv2.imread(str(img_path))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Enkel omkalning (Samma som i din inference logik om du inte kör letterbox)
        img_resized = cv2.resize(img, (self.img_size, self.img_size), interpolation=cv2.INTER_LINEAR)
        
        # Konvertera till Tensor [C, H, W] uint8
        img_tensor = torch.from_numpy(img_resized).permute(2, 0, 1)

        # --- LÄS OCH PREP LABELS ---
        boxes, labels, masks = [], [], []
        
        if label_path.exists():
            with open(label_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
                
            for line in lines:
                parts = line.strip().split()
                if len(parts) < 7: continue
                
                cls_id = int(parts[0])
                coords = np.array(parts[1:], dtype=np.float32).reshape(-1, 2)
                
                if coords.shape[0] < 3: continue
                
                # Skala polygoner från [0, 1] till [0, img_size]
                coords[:, 0] = np.clip(coords[:, 0] * self.img_size, 0, self.img_size - 1)
                coords[:, 1] = np.clip(coords[:, 1] * self.img_size, 0, self.img_size - 1)
                
                # Bounding box [x1, y1, x2, y2]
                x1, y1 = coords[:, 0].min(), coords[:, 1].min()
                x2, y2 = coords[:, 0].max(), coords[:, 1].max()
                
                # Skapa binär mask
                mask = np.zeros((self.img_size, self.img_size), dtype=np.uint8)
                cv2.fillPoly(mask, [coords.astype(np.int32)], 1)
                
                boxes.append([x1, y1, x2, y2])
                labels.append(cls_id)
                masks.append(mask)

        # Formatera för TorchMetrics
        target = {
            "boxes": torch.tensor(boxes, dtype=torch.float32) if boxes else torch.zeros((0, 4), dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.int64) if labels else torch.zeros((0,), dtype=torch.int64),
            "masks": torch.tensor(np.array(masks), dtype=torch.bool) if masks else torch.zeros((0, self.img_size, self.img_size), dtype=torch.bool)
        }

        return img_tensor, target

def collate_fn(batch):
    """Krävs för att returnera en lista med dictionaries via DataLoader."""
    images = torch.stack([b[0] for b in batch])
    targets = [b[1] for b in batch]
    return images, targets


# ==========================================
# 2. TENSORRT WRAPPER
# ==========================================
class TRTWrapper:
    def __init__(self, engine_path: str):
        self.logger = trt.Logger(trt.Logger.ERROR)
        trt.init_libnvinfer_plugins(self.logger, "")
        
        with open(engine_path, 'rb') as f, trt.Runtime(self.logger) as runtime:
            self.engine = runtime.deserialize_cuda_engine(f.read())
        self.context = self.engine.create_execution_context()

        self.inputs, self.outputs, self.bindings = [], [], []

        for i in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(i)
            is_input = self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT
            shape = tuple([1 if s == -1 else s for s in self.context.get_tensor_shape(name)])
            trt_dtype = self.engine.get_tensor_dtype(name)
            
            if trt_dtype == trt.float32: dtype = torch.float32
            elif trt_dtype == trt.float16: dtype = torch.float16
            elif trt_dtype == trt.uint8: dtype = torch.uint8
            else: dtype = torch.float32

            tensor = torch.empty(shape, dtype=dtype, device='cuda')
            self.bindings.append(tensor.data_ptr())
            
            if is_input: self.inputs.append({"name": name, "tensor": tensor})
            else: self.outputs.append({"name": name, "tensor": tensor})

    def __call__(self, x: torch.Tensor):
        self.inputs[0]["tensor"].copy_(x)
        self.context.execute_v2(self.bindings)
        return {out["name"]: out["tensor"].clone() for out in self.outputs}


# ==========================================
# 3. HUVUDPROGRAM
# ==========================================
def main(args):
    device = torch.device("cuda:0")
    print(f"Laddar TensorRT engine: {args.engine}")
    model = TRTWrapper(args.engine)

    # Initiera metric för Box och Mask
    metric = MeanAveragePrecision(iou_type=["bbox", "segm"], class_metrics=True)

    # Ladda Dataset
    print(f"Laddar dataset från: {args.img_dir}")
    dataset = SimpleEvalDataset(args.img_dir, args.label_dir, args.img_size)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_fn, num_workers=2)

    infer_times = []
    print("Startar utvärdering...")
    
    for images, targets in tqdm(dataloader):
        images = images.to(device)
        
        # --- KÖR INFERENS ---
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        outputs = model(images)
        torch.cuda.synchronize()
        infer_times.append((time.perf_counter() - t0) * 1000)

        # --- PROCESSA OUTPUT ---
        protos = outputs.get("protos")

        if "output" in outputs or "output0" in outputs:
            # FORMAT: decoded_nms (2.4 ms versionen)
            out_nms = outputs.get("output", outputs.get("output0"))
            dets = out_nms[0] 
            mask = dets[:, 4] >= args.conf
            valid_dets = dets[mask]

            pred_boxes = valid_dets[:, :4]
            pred_scores = valid_dets[:, 4]
            pred_labels = valid_dets[:, 5].to(torch.int64)
            mask_coeffs = valid_dets[:, 6:] if valid_dets.shape[1] > 6 else None

        elif "boxes_xyxy" in outputs:
            # FORMAT: decoded (1.8 ms versionen utan NMS)
            from torchvision.ops import nms
            
            boxes = outputs["boxes_xyxy"][0]
            cls_logits = outputs["cls_logits"][0]
            mask_coeffs_raw = outputs["mask_coeffs"][0] if "mask_coeffs" in outputs else None
            
            # Applicera sigmoid för att få fram scores och hitta bästa klassen
            cls_prob = torch.sigmoid(cls_logits)
            scores, labels = cls_prob.max(dim=-1)
            
            # 1. Tröskelvärde (Confidence filter)
            conf_mask = scores >= args.conf
            boxes = boxes[conf_mask]
            scores = scores[conf_mask]
            labels = labels[conf_mask]
            if mask_coeffs_raw is not None:
                mask_coeffs_raw = mask_coeffs_raw[conf_mask]
                
            # 2. PyTorch NMS
            keep = nms(boxes, scores, iou_threshold=0.65)
            keep = keep[:300] # Max 300 detektioner per bild
            
            pred_boxes = boxes[keep]
            pred_scores = scores[keep]
            pred_labels = labels[keep]
            mask_coeffs = mask_coeffs_raw[keep] if mask_coeffs_raw is not None else None
            
        else:
            raise RuntimeError(f"Okända utgångar från modellen: {list(outputs.keys())}")

        # --- BYGG MASKER ---
        pred_masks = torch.zeros((0, args.img_size, args.img_size), dtype=torch.bool, device=device)
        if mask_coeffs is not None and len(mask_coeffs) > 0 and protos is not None:
            p = protos[0] # [C, MH, MW]
            c, mh, mw = p.shape
            
            # Matrismultiplikation och Sigmoid
            m = torch.sigmoid((mask_coeffs @ p.view(c, -1)).view(-1, mh, mw))
            
            # Skala upp till bildstorlek
            m_up = torch.nn.functional.interpolate(
                m.unsqueeze(1), size=(args.img_size, args.img_size), mode="bilinear", align_corners=False
            ).squeeze(1)
            
            # Klipp masken strikt inom dess bounding box
            pred_masks = torch.zeros_like(m_up, dtype=torch.bool)
            for i in range(len(pred_boxes)):
                x1, y1, x2, y2 = pred_boxes[i].int().clamp(0, args.img_size)
                pred_masks[i, y1:y2, x1:x2] = m_up[i, y1:y2, x1:x2] > 0.5

        # --- MATER IN I METRICS ---
        preds = [{
            "boxes": pred_boxes,
            "scores": pred_scores,
            "labels": pred_labels,
            "masks": pred_masks
        }]
        
        target_metrics = [{
            "boxes": t["boxes"].to(device),
            "labels": t["labels"].to(device),
            "masks": t["masks"].to(device)
        } for t in targets]

        metric.update(preds, target_metrics)

    # --- RESULTAT ---
    avg_ms = sum(infer_times) / len(infer_times)
    print(f"\nSnitt Inferenstid: {avg_ms:.2f} ms ({1000/avg_ms:.1f} FPS)")
    print("Beräknar mAP (kan ta någon minut)...")
    
    result = metric.compute()
    
    print("\n" + "="*30)
    print("🏆 RESULTAT mAP")
    print("="*30)
    print(f"BBox mAP@50-95: {result['bbox_map'].item():.4f}")
    print(f"BBox mAP@50:    {result['bbox_map_50'].item():.4f}")
    
    if 'segm_map' in result: # Eller kolla i dicten
        print("="*30)
        print(f"Seg mAP@50-95: {result['segm_map'].item():.4f}")
        print(f"Seg mAP@50:    {result['segm_map_50'].item():.4f}")
        
        # torchmetrics returnerar specifika nycklar för segm om så konfigurerat.
    print("="*30)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", required=True)
    parser.add_argument("--img_dir", required=True, help="Mapp med valideringsbilder")
    parser.add_argument("--label_dir", required=True, help="Mapp med validerings-txt-filer")
    parser.add_argument("--img-size", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.001, help="Låg conf_thres rekommenderas starkt för korrekt mAP")
    args = parser.parse_args()
    main(args)