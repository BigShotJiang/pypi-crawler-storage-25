import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm

# ... (Helpers: autopad, _flatten_level_outputs, _pick_out_indices bibehålls från din kod) ...
# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def autopad(k, p=None, d=1):
    if p is None:
        p = (k - 1) // 2 * d
    return p


def init_detect_bias(head_moduledict, num_classes, prior_prob=0.01):
    # Utan obj-loss initierar vi klass-biasen så att modellen initialt gissar på "bakgrund" (väldigt låga sannolikheter)
    cls_bias = -math.log((1 - prior_prob) / prior_prob)
    with torch.no_grad():
        # Fyll endast klass- och box-bias, eftersom 'obj' är borta
        head_moduledict["out"]["cls"].bias.fill_(cls_bias)
        head_moduledict["out"]["box"].bias.zero_()


def _flatten_level_outputs(outs, export_concat: bool):
    if not export_concat:
        return outs
    flat = []
    for p in outs:  # [B,A,S,S,E]
        B, A, S, _, E = p.shape
        flat.append(p.view(B, -1, E))
    return torch.cat(flat, dim=1)


def _pick_out_indices(feature_info, take: int = 3):
    n = len(feature_info)
    out_idx = list(range(n - take, n))
    reductions = [feature_info[i]["reduction"] for i in out_idx]
    chs = [feature_info[i]["num_chs"] for i in out_idx]
    return out_idx, reductions, chs

# ---------------------------------------------------------
# 1. Nano Building Blocks
# ---------------------------------------------------------

class LightConv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        if k > 1:
            self.conv = nn.Sequential(
                nn.Conv2d(c1, c1, k, s, autopad(k, p), groups=c1, bias=False),
                nn.Conv2d(c1, c2, 1, 1, 0, bias=False),
            )
        else:
            self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class GhostConv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__()
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, p=None, g=g, act=act) # <--- Standard Conv (Tung)
        self.cv2 = Conv(c_, c_, 3, 1, p=None, g=c_, act=act)

    def forward(self, x):
        y = self.cv1(x)
        return torch.cat([y, self.cv2(y)], 1)

class NanoC2f(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(
            nn.Sequential(
                nn.Conv2d(self.c, self.c, 3, 1, 1, groups=self.c, bias=False),
                nn.BatchNorm2d(self.c),
                nn.SiLU(inplace=True)
            ) for _ in range(n)
        )

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, dim=1))
        for m in self.m:
            y.append(m(y[-1]))
        return self.cv2(torch.cat(y, dim=1))

class SPPF(nn.Module):
    def __init__(self, c1, c2, k=5):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = self.m(y2)
        return self.cv2(torch.cat([x, y1, y2, y3], dim=1))
# ---------------------------------------------------------
# 2. Proto Head (För segmentering)
# ---------------------------------------------------------

class NanoProto(nn.Module):
    """Lättviktsmask-prototyphuvud för Nano-modeller."""
    def __init__(self, c1, c_=256, c2=32):
        super().__init__()
        self.cv1 = LightConv(c1, c_, 3, 1)
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest') # Upp till 1/4 upplösning
        self.cv2 = LightConv(c_, c_, 3, 1)
        self.cv3 = LightConv(c_, c2, 1, 1) # Ut: 32 prototyper

    def forward(self, x):
        return self.cv3(self.cv2(self.upsample(self.cv1(x))))

# ---------------------------------------------------------
# 3. Nano Segmentation Head
# ---------------------------------------------------------

class NanoSegHead(nn.Module):
    def __init__(self, in_chs, num_classes, n_mask=32, A=1):
        super().__init__()
        # Gemensam stem för att spara FLOPs
        self.stem = GhostConv(in_chs, in_chs, 3)
        
        self.conv_box = nn.Conv2d(in_chs, A * 4, 1)
        self.conv_cls = nn.Conv2d(in_chs, A * num_classes, 1)
        self.conv_mask = nn.Conv2d(in_chs, A * n_mask, 1) # Koefficienter för prototyperna

    def forward(self, x):
        x = self.stem(x)
        return self.conv_box(x), self.conv_cls(x), self.conv_mask(x)

# ---------------------------------------------------------
# 4. Integrated YOLOE Nano Segmentation
# ---------------------------------------------------------

class NanoNeckV8(nn.Module):
    def __init__(self, in_channels, out_channels=64, depth=2, use_p2=False):
        super().__init__()
        self.use_p2 = use_p2
        
        # Vi skalar kanalerna för att spara FLOPs på hög upplösning (P2)
        self.c_p2 = int(out_channels * 0.5)
        self.c_p3 = int(out_channels * 0.75)
        self.c_p4 = out_channels
        self.c_p5 = int(out_channels * 2.0) 

        if use_p2:
            self.reduce_c2 = LightConv(in_channels[0], self.c_p2, 1, 1)
            self.reduce_c3 = LightConv(in_channels[1], self.c_p3, 1, 1)
            self.reduce_c4 = LightConv(in_channels[2], self.c_p4, 1, 1)
            self.reduce_c5 = LightConv(in_channels[3], self.c_p5, 1, 1)
        else:
            self.reduce_c3 = LightConv(in_channels[0], self.c_p3, 1, 1)
            self.reduce_c4 = LightConv(in_channels[1], self.c_p4, 1, 1)
            self.reduce_c5 = LightConv(in_channels[2], self.c_p5, 1, 1)

        self.sppf = SPPF(self.c_p5, self.c_p5, k=5)

        # Top-down
        self.td_p4 = NanoC2f(self.c_p5 + self.c_p4, self.c_p4, n=depth)
        self.td_p3 = NanoC2f(self.c_p4 + self.c_p3, self.c_p3, n=depth)
        if use_p2:
            self.td_p2 = NanoC2f(self.c_p3 + self.c_p2, self.c_p2, n=depth)

        # Bottom-up
        if use_p2:
            self.down_p2 = LightConv(self.c_p2, self.c_p2, 3, 2)
            self.bu_p3 = NanoC2f(self.c_p2 + self.c_p3, self.c_p3, n=depth)
        
        self.down_p3 = LightConv(self.c_p3, self.c_p3, 3, 2)
        self.bu_p4 = NanoC2f(self.c_p3 + self.c_p4, self.c_p4, n=depth)
        
        self.down_p4 = LightConv(self.c_p4, self.c_p4, 3, 2)
        self.bu_p5 = NanoC2f(self.c_p4 + self.c_p5, self.c_p5, n=depth)

        # För att YOLOE ska veta vilka kanaler som går in i varje huvud
        self.out_channels_list = [self.c_p2, self.c_p3, self.c_p4, self.c_p5] if use_p2 else [self.c_p3, self.c_p4, self.c_p5]

    def _up(self, x, target):
        return F.interpolate(x, size=target.shape[-2:], mode="nearest")

    def forward(self, feats):
        if self.use_p2:
            c2, c3, c4, c5 = feats
            c2, c3, c4, c5 = self.reduce_c2(c2), self.reduce_c3(c3), self.reduce_c4(c4), self.reduce_c5(c5)
        else:
            c3, c4, c5 = feats
            c3, c4, c5 = self.reduce_c3(c3), self.reduce_c4(c4), self.reduce_c5(c5)

        p5 = self.sppf(c5)
        p4_td = self.td_p4(torch.cat([self._up(p5, c4), c4], dim=1))
        p3_td = self.td_p3(torch.cat([self._up(p4_td, c3), c3], dim=1))

        if self.use_p2:
            p2_td = self.td_p2(torch.cat([self._up(p3_td, c2), c2], dim=1))
            p3_out = self.bu_p3(torch.cat([self.down_p2(p2_td), p3_td], dim=1))
            p4_out = self.bu_p4(torch.cat([self.down_p3(p3_out), p4_td], dim=1))
            p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
            return p2_td, p3_out, p4_out, p5_out

        p4_out = self.bu_p4(torch.cat([self.down_p3(p3_td), p4_td], dim=1))
        p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
        return p3_td, p4_out, p5_out
class YOLOE_Nano_Seg(nn.Module):
    def __init__(
        self,
        backbone="mobilenetv4_conv_small",
        num_classes=3,
        fpn_channels=128,
        n_mask=32,
        pretrained=True
    ):
        super().__init__()
        
        # 1. Backbone (Hoppar över P2 som tidigare)
        tmp = timm.create_model(backbone, features_only=True, pretrained=pretrained)
        out_idx, reductions, chs = _pick_out_indices(tmp.feature_info, take=3)
        self.backbone = timm.create_model(backbone, features_only=True, pretrained=pretrained, out_indices=out_idx)

        # 2. Nano Neck (Baserad på din vinnande design)
        # Vi använder din NanoNeckV8-klass här (förutsatt att den är definierad som i förra steget)
        
        self.neck = NanoNeckV8(in_channels=chs, out_channels=fpn_channels, use_p2=False)

        # 3. Proto Head (Kopplas till P3 - första utgången från necken)
        self.proto = NanoProto(int(fpn_channels * 0.75), c_=fpn_channels, c2=n_mask)

        # 4. Segmentation Heads
        self.heads = nn.ModuleList([
            NanoSegHead(ch, num_classes, n_mask=n_mask) for ch in self.neck.out_channels_list
        ])

        self.num_classes = num_classes
        self.n_mask = n_mask
        for m in self.heads:
            # Eftersom m är en NanoSegHead
            cls_bias = -math.log((1 - 0.01) / 0.01)
            m.conv_cls.bias.data.fill_(cls_bias)
            m.conv_box.bias.data.zero_()
            m.conv_mask.bias.data.zero_()

    def forward(self, x):
        feats = self.backbone(x)
        neck_outs = self.neck(feats) # P3, P4, P5
        
        # Prototyper baserat på den mest högupplösta särdragskartan (P3)
        protos = self.proto(neck_outs[0])

        final_outs = []
        for i, p in enumerate(neck_outs):
            box, cls, mask_coeff = self.heads[i](p)
            
            B, _, S, _ = box.shape
            # Samla box, cls och mask_coeffs i en tensor per nivå
            # Shape: [B, A, 4 + num_classes + n_mask, S, S]
            out = torch.cat([
                box.view(B, 1, 4, S, S),
                cls.view(B, 1, self.num_classes, S, S),
                mask_coeff.view(B, 1, self.n_mask, S, S)
            ], dim=2)
            final_outs.append(out.permute(0, 1, 3, 4, 2).contiguous())

        # Returnera både prediktioner och prototyper
        # I din loss-funktion multiplicerar du mask_coeff med protos
        return {
            "det": _flatten_level_outputs(final_outs, export_concat=False),
            "proto": protos
        }