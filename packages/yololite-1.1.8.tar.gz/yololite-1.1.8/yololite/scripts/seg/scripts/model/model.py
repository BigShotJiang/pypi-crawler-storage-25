import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm

# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def autopad(k, p=None, d=1):
    if p is None:
        p = (k - 1) // 2 * d
    return p

def init_detect_bias(head_module, num_classes, prior_prob=0.01):
    """Uppdaterad bias-initiering utan 'obj', precis som i v2"""
    cls_bias = -math.log((1 - prior_prob) / prior_prob)
    with torch.no_grad():
        head_module.conv_cls.bias.fill_(cls_bias)
        head_module.conv_box.bias.zero_()
        head_module.conv_mask.bias.zero_()

def _flatten_level_outputs(outs, export_concat: bool):
    if not export_concat:
        return outs
    flat = []
    for p in outs:
        B, A, S, _, E = p.shape
        flat.append(p.view(B, -1, E))
    return torch.cat(flat, dim=1)

def _pick_out_indices(feature_info, take: int = 3):
    n = len(feature_info)
    out_idx = list(range(n - take, n))
    reductions = [feature_info[i]["reduction"] for i in out_idx]
    chs = [feature_info[i]["num_chs"] for i in out_idx]
    return out_idx, reductions, chs

# ---------------------------------------------------------
# Original Building Blocks (Helt oförändrade)
# ---------------------------------------------------------

class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class Bottleneck(nn.Module):
    def __init__(self, c1, c2, shortcut=True, e=0.5):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        y = self.cv2(self.cv1(x))
        return x + y if self.add else y

class C2f(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1, 1)
        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut=shortcut, e=1.0) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, dim=1))
        for m in self.m:
            y.append(m(y[-1]))
        return self.cv2(torch.cat(y, dim=1))

class SPPF(nn.Module):
    def __init__(self, c1, c2, k=5):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = self.m(y2)
        return self.cv2(torch.cat([x, y1, y2, y3], dim=1))

class Downsample(nn.Module):
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = Conv(c1, c2, k=3, s=2)

    def forward(self, x):
        return self.conv(x)

class NeckV8(nn.Module):
    def __init__(self, in_channels, out_channels=256, depth=2, hidden_ratio=0.5, use_p2=False):
        super().__init__()
        self.use_p2 = use_p2

        if self.use_p2:
            assert len(in_channels) == 4
            c2, c3, c4, c5 = in_channels
            self.reduce_c2 = Conv(c2, out_channels, 1, 1)
        else:
            assert len(in_channels) == 3
            c3, c4, c5 = in_channels

        self.reduce_c3 = Conv(c3, out_channels, 1, 1)
        self.reduce_c4 = Conv(c4, out_channels, 1, 1)
        self.reduce_c5 = Conv(c5, out_channels, 1, 1)
        self.sppf = SPPF(out_channels, out_channels)

        self.td_p4 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
        self.td_p3 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
        if self.use_p2:
            self.td_p2 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
            self.down_p2 = Downsample(out_channels, out_channels)
            self.bu_p3 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

        self.down_p3 = Downsample(out_channels, out_channels)
        self.bu_p4 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)
        self.down_p4 = Downsample(out_channels, out_channels)
        self.bu_p5 = C2f(out_channels * 2, out_channels, n=depth, shortcut=False, e=hidden_ratio)

    def _up(self, x, target):
        return F.interpolate(x, size=target.shape[-2:], mode="nearest")

    def forward(self, feats):
        if self.use_p2:
            c2, c3, c4, c5 = feats
            c2 = self.reduce_c2(c2)
        else:
            c3, c4, c5 = feats

        c3 = self.reduce_c3(c3)
        c4 = self.reduce_c4(c4)
        c5 = self.reduce_c5(c5)

        p5 = self.sppf(c5)
        p4_td = self.td_p4(torch.cat([self._up(p5, c4), c4], dim=1))
        p3_td = self.td_p3(torch.cat([self._up(p4_td, c3), c3], dim=1))

        if self.use_p2:
            p2_td = self.td_p2(torch.cat([self._up(p3_td, c2), c2], dim=1))
            p3_out = self.bu_p3(torch.cat([self.down_p2(p2_td), p3_td], dim=1))
            p4_out = self.bu_p4(torch.cat([self.down_p3(p3_out), p4_td], dim=1))
            p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
            return p2_td, p3_out, p4_out, p5_out

        p4_out = self.bu_p4(torch.cat([self.down_p3(p3_td), p4_td], dim=1))
        p5_out = self.bu_p5(torch.cat([self.down_p4(p4_out), p5], dim=1))
        return p3_td, p4_out, p5_out

class ProtoNet(nn.Module):
    def __init__(self, c1, c_=256, nm=32):
        super().__init__()
        self.net = nn.Sequential(
            Conv(c1, c_, 3, 1),
            nn.Upsample(scale_factor=2, mode="nearest"),
            Conv(c_, c_, 3, 1),
            Conv(c_, nm, 1, 1, act=False),
        )

    def forward(self, x):
        return self.net(x)

# ---------------------------------------------------------
# NYTT: Det frikopplade huvudet (Ersätter make_head & make_mask_coeff_head)
# ---------------------------------------------------------

class DecoupledSegHead(nn.Module):
    """
    Ett frikopplat huvud utan 'obj'-gren som använder dina standard Convs som stam, 
    vilket behåller designen från din ursprungliga model.py.
    """
    def __init__(self, in_channels, num_classes, num_masks=32, A=1, head_depth=2):
        super().__init__()
        # Stammen byggs med din ursprungliga head_depth och Conv-klass
        self.stem = nn.Sequential(*[Conv(in_channels, in_channels, 3, 1) for _ in range(head_depth)])
        
        # Tre separata utgångar (utan obj)
        self.conv_box = nn.Conv2d(in_channels, A * 4, 1)
        self.conv_cls = nn.Conv2d(in_channels, A * num_classes, 1)
        self.conv_mask = nn.Conv2d(in_channels, A * num_masks, 1)

    def forward(self, x):
        x = self.stem(x)
        return self.conv_box(x), self.conv_cls(x), self.conv_mask(x)

# ---------------------------------------------------------
# Huvudmodell
# ---------------------------------------------------------

class YOLOESeg(nn.Module):
    def __init__(
        self,
        backbone="mobilenetv4_conv_small",
        num_classes=3,
        fpn_channels=256,
        num_anchors_per_level=(1, 1, 1, 1),
        pretrained=True,
        depth_multiple=1.0,
        width_multiple=1.0,
        head_depth=2,
        neck_depth=2,
        neck_hidden_ratio=0.5,
        use_p2=False,
        use_p6=False,
        num_masks=32,
    ):
        super().__init__()

        tmp = timm.create_model(backbone, features_only=True, pretrained=pretrained)
        take = 4 if use_p2 else 3
        out_idx, _, chs = _pick_out_indices(tmp.feature_info, take=take)

        self.backbone = timm.create_model(
            backbone,
            features_only=True,
            pretrained=pretrained,
            out_indices=out_idx,
        )

        self.use_p2 = use_p2
        self.use_p6 = use_p6
        self.num_classes = num_classes
        self.num_masks = num_masks
        self.export_concat = False

        fpn_channels = int(fpn_channels * width_multiple)
        neck_depth = max(1, int(round(neck_depth * depth_multiple)))
        head_depth = max(1, int(round(head_depth * depth_multiple)))

        self.neck = NeckV8(
            in_channels=chs,
            out_channels=fpn_channels,
            depth=neck_depth,
            hidden_ratio=neck_hidden_ratio,
            use_p2=use_p2,
        )

        if self.use_p6:
            self.p6_down = Downsample(fpn_channels, fpn_channels)
            self.p6_c2f = C2f(fpn_channels, fpn_channels, n=max(1, neck_depth - 1), shortcut=False, e=neck_hidden_ratio)

        self.level_names = (["p2"] if self.use_p2 else []) + ["p3", "p4", "p5"] + (["p6"] if self.use_p6 else [])

        if len(num_anchors_per_level) >= 3:
            A3, A4, A5 = map(int, num_anchors_per_level[:3])
            A2 = A3
            A6 = A5
        else:
            base_a = int(num_anchors_per_level[0]) if len(num_anchors_per_level) else 1
            A2 = A3 = A4 = A5 = A6 = base_a

        anchors_map = {"p2": A2, "p3": A3, "p4": A4, "p5": A5, "p6": A6}
        self.num_anchors_per_level = tuple(anchors_map[name] for name in self.level_names)

        # NYTT: Använd en ModuleList av DecoupledSegHead istället för lösa head2, mask2 etc.
        self.heads = nn.ModuleList()
        for A in self.num_anchors_per_level:
            self.heads.append(DecoupledSegHead(fpn_channels, num_classes, num_masks, A, head_depth))

        self.proto = ProtoNet(fpn_channels, c_=fpn_channels, nm=num_masks)

        # Initiera bias korrekt för alla huvuden
        for m in self.heads:
            init_detect_bias(m, num_classes)

    def forward(self, x):
        feats = self.backbone(x)
        neck_out = list(self.neck(feats)) # Konvertera till lista för att kunna lägga till p6

        if self.use_p6:
            p5 = neck_out[-1]
            p6 = self.p6_c2f(self.p6_down(p5))
            neck_out.append(p6)

        final_outs = []
        for i, p in enumerate(neck_out):
            box, cls, mask_coeff = self.heads[i](p)
            A = self.num_anchors_per_level[i]
            B, _, S, _ = box.shape

            # NYTT: Konkatenera utdatan precis som i model_v2.py
            # Shape före permute: [B, A, (4 + num_classes + num_masks), S, S]
            out = torch.cat([
                box.view(B, A, 4, S, S),
                cls.view(B, A, self.num_classes, S, S),
                mask_coeff.view(B, A, self.num_masks, S, S)
            ], dim=2)
            
            final_outs.append(out.permute(0, 1, 3, 4, 2).contiguous())

        # Plocka ut p3 för proto (index beror på om p2 används eller inte)
        p3_idx = 1 if self.use_p2 else 0
        proto = self.proto(neck_out[p3_idx])

        return {
            "det": _flatten_level_outputs(final_outs, export_concat=self.export_concat),
            "proto": proto,
        }