import math
from typing import List, Dict, Any
import torch
import torch.nn as nn
import torch.nn.functional as F

def decode_preds_for_seg(preds, img_size, center_mode="v8", wh_mode="softplus"):
    device = preds[0].device

    anchors_list = []
    strides_list = []

    for p in preds:
        _, _, h, w, _ = p.shape
        stride = img_size / max(h, w)

        sy, sx = torch.meshgrid(
            torch.arange(h, device=device),
            torch.arange(w, device=device),
            indexing="ij"
        )
        anchors = torch.stack([sx, sy], dim=-1).float().view(-1, 2)
        strides = torch.full((h * w,), stride, device=device)

        anchors_list.append(anchors)
        strides_list.append(strides)

    anchors = torch.cat(anchors_list, dim=0)      # [N,2]
    strides = torch.cat(strides_list, dim=0)      # [N]

    preds_flat = torch.cat([p.flatten(1, 3) for p in preds], dim=1)  # [B,N,E]

    strides_v = strides.view(1, -1, 1)
    anchors_v = anchors.view(1, -1, 2)

    tx = preds_flat[..., 0]
    ty = preds_flat[..., 1]
    tw = preds_flat[..., 2]
    th = preds_flat[..., 3]

    if center_mode == "v8":
        xy = (torch.sigmoid(torch.stack([tx, ty], -1)) * 2.0 - 0.5 + anchors_v) * strides_v
    else:
        xy = (torch.sigmoid(torch.stack([tx, ty], -1)) + anchors_v) * strides_v

    if wh_mode == "v8":
        wh = (torch.sigmoid(torch.stack([tw, th], -1)) * 2).pow(2) * strides_v
    elif wh_mode == "softplus":
        wh = F.softplus(torch.stack([tw, th], -1)) * strides_v
    else:
        wh = torch.exp(torch.stack([tw, th], -1).clamp(-10, 8)) * strides_v

    x1y1 = xy - 0.5 * wh
    x2y2 = xy + 0.5 * wh
    boxes_xyxy = torch.cat([x1y1, x2y2], dim=-1)   # [B,N,4]

    return boxes_xyxy, preds_flat


# --------------------------- Hjälp-funktioner ---------------------------

def bbox_iou_matrix(box1, box2, eps=1e-7):
    b1 = box1.unsqueeze(1)
    b2 = box2.unsqueeze(0)

    inter_x1 = torch.max(b1[..., 0], b2[..., 0])
    inter_y1 = torch.max(b1[..., 1], b2[..., 1])
    inter_x2 = torch.min(b1[..., 2], b2[..., 2])
    inter_y2 = torch.min(b1[..., 3], b2[..., 3])

    inter_w = (inter_x2 - inter_x1).clamp(min=0)
    inter_h = (inter_y2 - inter_y1).clamp(min=0)
    inter = inter_w * inter_h

    area1 = (b1[..., 2] - b1[..., 0]).clamp(min=0) * (b1[..., 3] - b1[..., 1]).clamp(min=0)
    area2 = (b2[..., 2] - b2[..., 0]).clamp(min=0) * (b2[..., 3] - b2[..., 1]).clamp(min=0)
    union = area1 + area2 - inter + eps

    return inter / union

def bbox_ciou_flat(pred_xyxy, target_xyxy, eps=1e-7):
    px1, py1, px2, py2 = pred_xyxy.unbind(-1)
    tx1, ty1, tx2, ty2 = target_xyxy.unbind(-1)

    pw = (px2 - px1).clamp(min=eps)
    ph = (py2 - py1).clamp(min=eps)
    tw = (tx2 - tx1).clamp(min=eps)
    th = (ty2 - ty1).clamp(min=eps)

    inter_w = (torch.min(px2, tx2) - torch.max(px1, tx1)).clamp(min=0)
    inter_h = (torch.min(py2, ty2) - torch.max(py1, ty1)).clamp(min=0)
    inter = inter_w * inter_h
    union = pw * ph + tw * th - inter + eps
    iou = inter / union

    pcx = (px1 + px2) * 0.5
    pcy = (py1 + py2) * 0.5
    tcx = (tx1 + tx2) * 0.5
    tcy = (ty1 + ty2) * 0.5
    center_dist = (pcx - tcx) ** 2 + (pcy - tcy) ** 2

    cw = torch.max(px2, tx2) - torch.min(px1, tx1)
    ch = torch.max(py2, ty2) - torch.min(py1, ty1)
    c2 = cw ** 2 + ch ** 2 + eps

    v = (4 / (math.pi ** 2)) * torch.pow(torch.atan(tw / th) - torch.atan(pw / ph), 2)
    with torch.no_grad():
        alpha = v / (v - iou + 1 + eps)
    return iou - (center_dist / c2) - alpha * v

def _targets_to_xyxy_px(tgt: dict, W: int, H: int, device: torch.device):
    boxes = None
    for k in ("boxes", "bboxes", "xyxy"):
        if k in tgt and tgt[k] is not None:
            boxes = tgt[k]
            break
    if boxes is None:
        return torch.zeros((0, 4), dtype=torch.float32, device=device)

    if isinstance(boxes, torch.Tensor):
        b = boxes.detach().to(device=device, dtype=torch.float32)
    else:
        b = torch.as_tensor(boxes, dtype=torch.float32, device=device)

    if b.numel() == 0:
        return b.view(0, 4)

    b_min, b_max = float(b.min().item()), float(b.max().item())

    def xywh_px_to_xyxy_px(bt):
        x1 = bt[:, 0] - bt[:, 2] * 0.5
        y1 = bt[:, 1] - bt[:, 3] * 0.5
        x2 = bt[:, 0] + bt[:, 2] * 0.5
        y2 = bt[:, 1] + bt[:, 3] * 0.5
        return torch.stack([x1, y1, x2, y2], dim=1)

    if -1e-3 <= b_min <= 1.01 and -1e-3 <= b_max <= 1.01:
        mean_wh = float((b[:, 2] + b[:, 3]).mean().item())
        if mean_wh <= 2.01:
            cx = b[:, 0] * W
            cy = b[:, 1] * H
            ww = b[:, 2] * W
            hh = b[:, 3] * H
            return xywh_px_to_xyxy_px(torch.stack([cx, cy, ww, hh], dim=1))
        else:
            x1 = b[:, 0] * W
            y1 = b[:, 1] * H
            x2 = b[:, 2] * W
            y2 = b[:, 3] * H
            return torch.stack([x1, y1, x2, y2], dim=1)

    likely_xyxy = ((b[:, 2] > b[:, 0]) & (b[:, 3] > b[:, 1])).float().mean().item() > 0.8
    return b if likely_xyxy else xywh_px_to_xyxy_px(b)

def _targets_to_masks(tgt: dict, device: torch.device):
    masks = tgt.get("masks", None)
    if masks is None:
        return torch.zeros((0, 1, 1), dtype=torch.float32, device=device)
    if isinstance(masks, torch.Tensor):
        m = masks.to(device=device, dtype=torch.float32)
    else:
        m = torch.as_tensor(masks, dtype=torch.float32, device=device)
    if m.numel() == 0:
        return m.view(0, 1, 1)
    if m.ndim == 2:
        m = m.unsqueeze(0)
    return m


# --------------------------- LossAF ---------------------------

class LossAF(nn.Module):
    def __init__(self, num_classes: int, img_size: int, lambda_box: float = 5.0, lambda_cls: float = 0.5, assign_cls_weight: float = 0.5, center_mode: str = "v8", wh_mode: str = "softplus", center_radius_cells: float = 2.0, topk_limit: int = 20, focal: bool = False, gamma: float = 2.0, alpha: float = 0.25, area_cells_min: float = 4.0, area_cells_max: float = 256.0, area_tol: float = 1.25, size_prior_w: float = 0.20, ar_prior_w: float = 0.10, iou_cost_w: float = 3.0, center_cost_w: float = 0.5):
        super().__init__()
        self.nc = int(num_classes)
        self.img_size = int(img_size)
        self.lambda_box = float(lambda_box)
        self.lambda_cls = float(lambda_cls)
        self.assign_cls_weight = float(assign_cls_weight)
        self.center_mode = center_mode
        self.wh_mode = wh_mode
        self.center_radius_cells = float(center_radius_cells)
        self.topk_limit = int(topk_limit)
        
        self.focal = focal
        self.gamma = gamma
        self.alpha = alpha
        
        self.area_cells_min = float(area_cells_min) / float(area_tol)
        self.area_cells_max = float(area_cells_max) * float(area_tol)
        self.size_prior_w = size_prior_w
        self.ar_prior_w = ar_prior_w
        self.iou_cost_w = iou_cost_w
        self.center_cost_w = center_cost_w

        self.bce_cls = nn.BCEWithLogitsLoss(reduction="none")
        
        self.anchors = torch.empty(0)
        self.strides = torch.empty(0)

    def _make_anchors(self, preds: List[torch.Tensor], device: torch.device):
        shapes = [p.shape[2:4] for p in preds]
        total = sum(s[0]*s[1] for s in shapes)
        if self.anchors.shape[0] != total or self.anchors.device != device:
            al, sl = [], []
            for p in preds:
                _, _, h, w, _ = p.shape
                stride = self.img_size / max(h, w)
                sy, sx = torch.meshgrid(torch.arange(h, device=device), torch.arange(w, device=device), indexing='ij')
                al.append(torch.stack([sx, sy], dim=-1).float().view(-1, 2))
                sl.append(torch.full((h * w,), stride, device=device))
            self.anchors = torch.cat(al, dim=0)
            self.strides = torch.cat(sl, dim=0)

    def _decode(self, preds_flat):
        strides = self.strides.view(1, -1, 1)
        anchors = self.anchors.view(1, -1, 2)
        tx, ty, tw, th = preds_flat[..., 0], preds_flat[..., 1], preds_flat[..., 2], preds_flat[..., 3]
        if self.center_mode == "v8":
            xy = (torch.sigmoid(torch.stack([tx, ty], -1)) * 2.0 - 0.5 + anchors) * strides
        else:
            xy = (torch.sigmoid(torch.stack([tx, ty], -1)) + anchors) * strides
        if self.wh_mode == "v8":
            wh = (torch.sigmoid(torch.stack([tw, th], -1)) * 2).pow(2) * strides
        elif self.wh_mode == "softplus":
             wh = F.softplus(torch.stack([tw, th], -1)) * strides
        else:
             wh = torch.exp(torch.stack([tw, th], -1).clamp(-10, 8)) * strides
        x1y1 = xy - 0.5 * wh; x2y2 = xy + 0.5 * wh
        return torch.cat([x1y1, x2y2], dim=-1), xy, wh, strides.squeeze(-1)

    def forward(self, preds_in: List[torch.Tensor], targets: List[dict], return_assignments=False):
        device = preds_in[0].device
        self._make_anchors(preds_in, device)
        preds_flat = torch.cat([p.flatten(1, 3) for p in preds_in], dim=1) 
        B, N_total, _ = preds_flat.shape
        pred_xyxy, pred_ctr, pred_wh, _ = self._decode(preds_flat)
        
        # --- VIKTIGT FÖR SEGMENTERING: Klasser är exakt length = self.nc ---
        pred_cls = preds_flat[..., 4 : 4 + self.nc]
        
        loss_box_sum = torch.zeros(1, device=device)
        loss_cls_sum = torch.zeros(1, device=device)
        total_batch_pos = 0.0 
        batch_assignments = []

        for b in range(B):
            tgt_xyxy = _targets_to_xyxy_px(targets[b], self.img_size, self.img_size, device)
            tgt_labels = targets[b]["labels"].to(device).long()
            if tgt_labels.numel() > 0:
                tgt_labels = torch.clamp(tgt_labels, 0, self.nc - 1)
            N_gt = tgt_xyxy.shape[0]

            # --- FALL 1: Inga objekt, ren bakgrund ---
            if N_gt == 0:
                target_cls = torch.zeros_like(pred_cls[b])
                pred_p = torch.sigmoid(pred_cls[b]) 
                
                if self.focal:
                    # FIX: Uppdaterat till samma logik som din loss.py
                    f_weight = torch.abs(target_cls - pred_p).pow(self.gamma)
                    alpha_factor = target_cls * self.alpha + (1 - target_cls) * (1 - self.alpha)
                    f_weight = f_weight * alpha_factor
                    
                    loss_cls_sum += self.lambda_cls * (self.bce_cls(pred_cls[b], target_cls) * f_weight).sum()
                else:
                    loss_cls_sum += self.lambda_cls * self.bce_cls(pred_cls[b], target_cls).sum()
                
                if return_assignments: 
                    batch_assignments.append({"pos_inds": torch.empty(0, device=device)})
                continue

            # --- [SimOTA och Cost Matrix] ---
            iou_matrix = bbox_iou_matrix(pred_xyxy[b], tgt_xyxy)
            gt_ctr = (tgt_xyxy[:, :2] + tgt_xyxy[:, 2:]) * 0.5 
            gt_wh = (tgt_xyxy[:, 2:] - tgt_xyxy[:, :2]).clamp(min=1.0)
            
            dist_sq = (pred_ctr[b].unsqueeze(1) - gt_ctr.unsqueeze(0)).pow(2).sum(-1)
            s_col = self.strides.unsqueeze(1)
            
            raw_r = (self.center_radius_cells * s_col) + 0.10 * gt_wh.max(dim=1).values.unsqueeze(0)
            r_pix = torch.clamp(raw_r, min=15.0) 
            center_mask = dist_sq <= r_pix.pow(2)
            
            gt_area = gt_wh.prod(dim=1).unsqueeze(0)
            area_cells = gt_area / (s_col.pow(2))
            level_mask = (area_cells >= self.area_cells_min) & (area_cells <= self.area_cells_max)
            valid_mask = center_mask & level_mask

            gt_hits = valid_mask.sum(dim=0)
            orphans = gt_hits == 0
            if orphans.any():
                orphan_indices = orphans.nonzero(as_tuple=True)[0]
                nearest_anchor_idx = dist_sq[:, orphan_indices].argmin(dim=0)
                valid_mask[nearest_anchor_idx, orphan_indices] = True

            pred_cls_prob = torch.sigmoid(pred_cls[b])
            class_probs = pred_cls_prob[:, tgt_labels]
            cls_cost = 1.0 - class_probs
            
            p_area = pred_wh[b].prod(dim=1).unsqueeze(1)
            size_cost = (p_area.log() - gt_area.log()).abs() / (1.0 + (p_area.log() - gt_area.log()).abs())
            
            p_ar = (pred_wh[b, :, 0] / pred_wh[b, :, 1]).unsqueeze(1).log()
            g_ar = (gt_wh[:, 0] / gt_wh[:, 1]).unsqueeze(0).log()
            ar_cost = (p_ar - g_ar).abs() / (1.0 + (p_ar - g_ar).abs())
            
            center_norm = dist_sq / (gt_wh[:, 0]**2 + gt_wh[:, 1]**2 + 1e-6).unsqueeze(0)

            cost = (
                self.iou_cost_w * (1.0 - iou_matrix) + 
                self.assign_cls_weight * cls_cost + 
                self.center_cost_w * center_norm +
                self.size_prior_w * size_cost +
                self.ar_prior_w * ar_cost
            )
            cost[~valid_mask] = 1e9

            iou_masked = iou_matrix.masked_fill(~valid_mask, 0.0)
            topk_ious, _ = torch.topk(iou_masked, k=min(self.topk_limit, N_total), dim=0)
            dynamic_ks = topk_ious.sum(dim=0).int().clamp(min=1)
            
            _, indices = torch.topk(cost, k=min(self.topk_limit, N_total), dim=0, largest=False)
            
            match_matrix = torch.zeros_like(cost, dtype=torch.bool)
            for gt_i in range(N_gt):
                k = dynamic_ks[gt_i].item()
                match_matrix[indices[:k, gt_i], gt_i] = True
                
            if match_matrix.sum(dim=1).max() > 1:
                multiple_mask = match_matrix.sum(dim=1) > 1
                c_multi = cost[multiple_mask].clone()
                m_multi = match_matrix[multiple_mask]
                c_multi[~m_multi] = 1e9
                best_gt = c_multi.argmin(dim=1)
                match_matrix[multiple_mask] = False
                match_matrix[multiple_mask, best_gt] = True
            
            pos_mask = match_matrix.any(dim=1)
            pos_inds = pos_mask.nonzero(as_tuple=False).squeeze(1)
            
            target_cls = torch.zeros_like(pred_cls[b])
            
            if pos_inds.numel() > 0:
                total_batch_pos += pos_inds.numel()
                matched_gt_idx = match_matrix[pos_inds].long().argmax(dim=1)
                
                # --- BOX LOSS ---
                target_box = tgt_xyxy[matched_gt_idx]
                pred_box = pred_xyxy[b, pos_inds]
                iou_final = bbox_ciou_flat(pred_box, target_box)
                loss_box_sum += self.lambda_box * (1.0 - iou_final).sum()
                
                # --- Sätt in Soft Labels ---
                iou_target_scores = iou_matrix[pos_inds, matched_gt_idx].detach().clamp(0, 1)
                target_cls[pos_inds, tgt_labels[matched_gt_idx]] = iou_target_scores.to(pred_cls.dtype)
                
                # --- Assignments för Segmentering ---
                if return_assignments:
                    pred_scores = pred_cls_prob[pos_inds].max(dim=-1).values
                    batch_assignments.append({
                        "pos_inds": pos_inds,
                        "matched_gt_idx": matched_gt_idx,
                        "target_boxes": target_box,
                        "pred_scores": pred_scores 
                    })
            else:
                if return_assignments:
                    batch_assignments.append({"pos_inds": torch.empty(0, device=device)})

            # --- CLS LOSS ---
            pred_p = torch.sigmoid(pred_cls[b])
            
            if self.focal:
                # FIX: "Ren Quality Focal Loss" (Samma som i loss.py)
                f_weight = torch.abs(target_cls - pred_p).pow(self.gamma)
                loss_cls_sum += self.lambda_cls * (self.bce_cls(pred_cls[b], target_cls) * f_weight).sum()
            else:
                loss_cls_sum += self.lambda_cls * self.bce_cls(pred_cls[b], target_cls).sum()

        # Global Normalisering
        denom = max(total_batch_pos, B * 1.0) 
        
        final_loss_box = loss_box_sum / denom
        final_loss_cls = loss_cls_sum / denom

        # FIX: Metriker inklusive "pos" är nu returnerade korrekt
        metrics = {
            "box": float(final_loss_box),
            "cls": float(final_loss_cls),
            "pos": total_batch_pos / max(B, 1),
        }

        if return_assignments:
            return final_loss_box + final_loss_cls, metrics, batch_assignments
        return final_loss_box + final_loss_cls, metrics


# --------------------------- SegLoss ---------------------------

class SegLoss(nn.Module):
    def __init__(
        self,
        det_loss,
        lambda_mask=1.0,
        lambda_dice=1.0,
        crop_to_box=True,
    ):
        super().__init__()
        self.det_loss = det_loss
        self.lambda_mask = float(lambda_mask)
        self.lambda_dice = float(lambda_dice)
        self.crop_to_box = bool(crop_to_box)
        self.bce = nn.BCEWithLogitsLoss(reduction="mean")

    def _dice_loss_from_logits(self, logits, targets, eps=1e-6):
        probs = torch.sigmoid(logits)
        probs = probs.flatten(1)
        targets = targets.float().flatten(1)

        intersection = (probs * targets).sum(dim=1)
        union = probs.sum(dim=1) + targets.sum(dim=1)

        dice = (2.0 * intersection + eps) / (union + eps)
        return 1.0 - dice.mean()

    def _crop_mask_loss(self, pred_masks, tgt_masks, tgt_boxes, mask_h, mask_w):
        if pred_masks.numel() == 0:
            z = pred_masks.new_tensor(0.0)
            return z, z

        device = pred_masks.device

        # 1. Skapa koordinat-grid: [1, mask_h, mask_w]
        sy, sx = torch.meshgrid(
            torch.arange(mask_h, device=device),
            torch.arange(mask_w, device=device),
            indexing="ij"
        )
        sx = sx.unsqueeze(0)
        sy = sy.unsqueeze(0)

        # 2. Skala target-boxarna till maskens upplösning
        scale_w = mask_w / self.det_loss.img_size
        scale_h = mask_h / self.det_loss.img_size

        x1 = (tgt_boxes[:, 0] * scale_w).view(-1, 1, 1)
        y1 = (tgt_boxes[:, 1] * scale_h).view(-1, 1, 1)
        x2 = (tgt_boxes[:, 2] * scale_w).view(-1, 1, 1)
        y2 = (tgt_boxes[:, 3] * scale_h).view(-1, 1, 1)

        # 3. Skapa en spatial mask (allt innanför boxarna blir 1, resten 0)
        # Form: [Np, mask_h, mask_w] där Np är antal objekt
        box_mask = (sx >= x1) & (sx < x2) & (sy >= y1) & (sy < y2)
        box_mask = box_mask.float() 

        # Antal pixlar i varje box (för normalisering)
        box_areas = box_mask.sum(dim=(1, 2)).clamp(min=1e-6)

        # 4. --- Beräkna BCE vektoriserat ---
        bce_full = F.binary_cross_entropy_with_logits(pred_masks, tgt_masks, reduction="none")
        # Nollställ BCE utanför boxen, summera och dela på arean (mean per box)
        bce_loss = (bce_full * box_mask).sum(dim=(1, 2)) / box_areas

        # 5. --- Beräkna Dice vektoriserat ---
        pred_probs = torch.sigmoid(pred_masks)
        intersection = (pred_probs * tgt_masks * box_mask).sum(dim=(1, 2))
        union = (pred_probs * box_mask).sum(dim=(1, 2)) + (tgt_masks * box_mask).sum(dim=(1, 2))
        
        dice_loss = 1.0 - (2.0 * intersection + 1e-6) / (union + 1e-6)

        return bce_loss.mean(), dice_loss.mean()

    def forward(self, outputs: Dict[str, Any], targets: List[dict]):
        det_preds = outputs["det"]
        proto = outputs["proto"]
        
        det_total, det_metrics, assignments = self.det_loss(
            det_preds,
            targets,
            return_assignments=True,
        )

        nc = self.det_loss.nc
        preds_flat = torch.cat([p.flatten(1, 3) for p in det_preds], dim=1)
        coeff_flat = preds_flat[..., 4+nc:]  # [B, N, nm]
        
        B, nm, Hp, Wp = proto.shape

        mask_loss = proto.new_tensor(0.0)
        mask_samples = 0

        for b in range(B):
            assign = assignments[b]
            pos_inds = assign["pos_inds"]
            
            # --- FIX: Kontrollera om den är tom INNAN vi hämtar resten ---
            if pos_inds.numel() == 0:
                continue
                
            matched_gt_idx = assign["matched_gt_idx"]
            tgt_boxes = assign["target_boxes"]

            gt_masks = targets[b]["masks"].to(proto.device, dtype=torch.float32)
            if gt_masks.shape[0] == 0:
                continue

            gt_masks = F.interpolate(
                gt_masks.unsqueeze(1),
                size=(Hp, Wp),
                mode="nearest",
            ).squeeze(1)
            
            max_mask_samples_per_image = 32

            if pos_inds.numel() > max_mask_samples_per_image:
                pos_scores = assign["pred_scores"]
                best_idx = torch.topk(
                    pos_scores,
                    k=max_mask_samples_per_image,
                    largest=True
                ).indices
                
                pos_inds = pos_inds[best_idx]
                matched_gt_idx = matched_gt_idx[best_idx]
                tgt_boxes = tgt_boxes[best_idx]
                
            cur_coeff = coeff_flat[b, pos_inds]     # [Np, nm]
            cur_proto = proto[b].view(nm, -1)       # [nm, Hp*Wp]
            pred_masks = cur_coeff @ cur_proto      # [Np, Hp*Wp]
            pred_masks = pred_masks.view(-1, Hp, Wp)

            tgt_masks = gt_masks[matched_gt_idx]

            if self.crop_to_box:
                cur_bce, cur_dice = self._crop_mask_loss(pred_masks, tgt_masks, tgt_boxes, Hp, Wp)
            else:
                cur_bce = self.bce(pred_masks, tgt_masks)
                cur_dice = self._dice_loss_from_logits(pred_masks, tgt_masks)

            cur_loss = cur_bce + self.lambda_dice * cur_dice
            mask_loss = mask_loss + cur_loss

            mask_samples += 1

        if mask_samples > 0:
            mask_loss = mask_loss / mask_samples

        total_loss = det_total + self.lambda_mask * mask_loss
        det_metrics["mask"] = float(mask_loss.detach())
        det_metrics["total"] = float(total_loss.detach())
        
        return total_loss, det_metrics