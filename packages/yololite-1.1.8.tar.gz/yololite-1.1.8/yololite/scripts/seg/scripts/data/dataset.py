import os
import cv2
import torch
import random
import numpy as np
from pathlib import Path
from torch.utils.data import Dataset
from tqdm import tqdm


class YoloSegDataset(Dataset):
    def __init__(
        self,
        img_dir,
        label_dir,
        transforms=None,
        img_size=640,
        is_train=True,
        mask_downsample=4,
        mosaic_p=0.5, # Sannolikhet för mosaic
    ):
        self.img_dir = Path(img_dir)
        self.label_dir = Path(label_dir)
        self.transforms = transforms
        self.img_size = int(img_size)
        self.is_train = is_train
        self.mask_downsample = int(mask_downsample)
        self.mask_size = max(1, self.img_size // self.mask_downsample)
        self.mosaic_p = mosaic_p

        valid_exts = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
        self.img_files = []

        with os.scandir(str(self.img_dir)) as entries:
            for entry in entries:
                if entry.is_file() and os.path.splitext(entry.name)[1].lower() in valid_exts:
                    self.img_files.append(entry.path)

        self.img_files.sort()

        if len(self.img_files) == 0:
            raise ValueError(f"No images found in {self.img_dir}")

        print(f"Caching seg labels for {len(self.img_files)} images...")
        self.labels_cache = self._cache_labels()

    def _cache_labels(self):
        cache = []

        for img_path in tqdm(self.img_files, desc="Loading seg labels"):
            label_path = self.label_dir / (Path(img_path).stem + ".txt")
            items = []

            if label_path.exists():
                try:
                    with open(label_path, "r", encoding="utf-8") as f:
                        lines = f.readlines()

                    for line in lines:
                        parts = line.strip().split()
                        if len(parts) < 7:
                            continue

                        cls = int(parts[0])
                        coords = np.array(parts[1:], dtype=np.float32)

                        if len(coords) % 2 != 0:
                            continue

                        poly = coords.reshape(-1, 2)
                        if poly.shape[0] < 3:
                            continue

                        poly[:, 0] = np.clip(poly[:, 0], 0.0, 1.0)
                        poly[:, 1] = np.clip(poly[:, 1], 0.0, 1.0)

                        items.append({
                            "cls": cls,
                            "poly": poly,
                        })
                except Exception:
                    pass

            cache.append(items)

        return cache
    def get_image_weights(
        self,
        rare_power=0.5,            # 0.5 = 1/sqrt(freq)
        rare_w=1.0,                # hur mycket sällsynta klasser ska påverka
        small_thr=0.01,            # normalized area threshold
        very_small_thr=0.003,
        small_w=0.35,
        very_small_w=0.75,
        count_dampen=0.35,         # dämpar bilder med många objekt
        empty_weight=0.2,          # tomma bilder ska finnas men inte dominera
        min_weight=0.25,
        max_weight=3.0,
    ):
        all_labels = []
        max_cls = 0

        # 1) Global klassfrekvens
        for anns in self.labels_cache:
            if len(anns) > 0: # Använd len() istället för .shape
                cls_ids = [ann["cls"] for ann in anns]
                all_labels.extend(cls_ids)
                max_cls = max(max_cls, max(cls_ids))

        if not all_labels:
            return torch.ones(len(self), dtype=torch.float32)

        cls_counts = np.bincount(np.array(all_labels, dtype=np.int64), minlength=max_cls + 1)
        cls_counts = np.maximum(cls_counts, 1)

        # Sällsynta klasser får högre score
        cls_weights = 1.0 / np.power(cls_counts.astype(np.float32), rare_power)

        image_weights = []

        for anns in self.labels_cache:
            if len(anns) == 0:
                image_weights.append(empty_weight)
                continue

            cls_ids = np.array([ann["cls"] for ann in anns], dtype=np.int64)
            num_objects = len(cls_ids)

            # Räkna ut normaliserade bounding box-areor direkt från polygonerna
            areas = []
            for ann in anns:
                poly = ann["poly"]
                w = poly[:, 0].max() - poly[:, 0].min()
                h = poly[:, 1].max() - poly[:, 1].min()
                areas.append(w * h)
            
            areas = np.array(areas, dtype=np.float32)

            # Rare-class score
            rare_score = float(cls_weights[cls_ids].mean())

            # Small object counts
            num_small = int((areas < small_thr).sum())
            num_very_small = int((areas < very_small_thr).sum())

            # Bygg vikt
            weight = 1.0 + (rare_w * rare_score) + (small_w * num_small) + (very_small_w * num_very_small)

            # Dämpa bilder med många objekt
            weight /= max(1.0, float(num_objects) ** count_dampen)

            # Clamp
            weight = float(np.clip(weight, min_weight, max_weight))
            image_weights.append(weight)

        image_weights = np.array(image_weights, dtype=np.float32)

        # Normalisera så medel blir ~1.0
        image_weights = image_weights / max(image_weights.mean(), 1e-6)

        return torch.tensor(image_weights, dtype=torch.float32)
    def __len__(self):
        return len(self.img_files)

    def load_image(self, idx):
        """Läser enbart bilden (I/O tungt)."""
        img = cv2.imread(self.img_files[idx], cv2.IMREAD_COLOR)
        img = img[:, :, ::-1]  # BGR → RGB (view, ingen kopia!)
        if img is None:
            raise ValueError(f"Image not found or corrupt: {self.img_files[idx]}")
        return img
    @staticmethod
    def _poly_to_box(poly, w, h):
        # poly antar vi är formad (N, 2) med värden mellan 0.0 och 1.0
        px = poly[:, 0]
        py = poly[:, 1]
        
        # Skala x-koordinaterna med bildens bredd (w)
        x1 = px.min() * w
        x2 = px.max() * w
        
        # Skala y-koordinaterna med bildens höjd (h)
        y1 = py.min() * h
        y2 = py.max() * h
        
        return np.array([x1, y1, x2, y2], dtype=np.float32)
    @staticmethod
    def _poly_to_mask(poly, w, h):
        # Skapa en tom mask med rätt rektangulära dimensioner
        mask = np.zeros((h, w), dtype=np.uint8)
        
        # Skala upp polygonen till faktiska pixlar
        poly_pixels = poly.copy()
        poly_pixels[:, 0] *= w
        poly_pixels[:, 1] *= h
        
        # cv2 vill ha heltal i formatet int32
        poly_pixels = poly_pixels.astype(np.int32)
        
        # Rita polygonen (1 för objektet, 0 för bakgrund)
        cv2.fillPoly(mask, [poly_pixels], 1)
        
        return mask

    

   # ------------------ Patch Mosaic för Segmentering (Optimerad för små objekt) ------------------
    def mosaic_v1(self, index):
        import random
        import numpy as np

        indices = [index] + random.choices(range(len(self)), k=3)
        
        # Målet är en canvas på img_size x img_size (t.ex. 640x640)
        s = self.img_size
        patch_s = s // 2  # Varje klipp blir exakt hälften (t.ex. 320x320)
        
        # Skapa canvas (s x s istället för s*2 x s*2)
        mosaic_img = np.full((s, s, 3), 114, dtype=np.uint8)
        
        # Offsets för de 4 kvadranterna: (y, x) i s x s canvasen
        offsets = [(0, 0), (0, patch_s), (patch_s, 0), (patch_s, patch_s)] 
        
        all_anns = []

        for i, idx in enumerate(indices):
            # Ladda bild
            img = self.load_image(idx)
            h, w = img.shape[:2]

            # --- 1. Klipp ut en slumpmässig patch i 1:1 originalskala ---
            x_offset = random.randint(0, max(0, w - patch_s))
            y_offset = random.randint(0, max(0, h - patch_s))
            
            crop_img = img[y_offset:y_offset + patch_s, x_offset:x_offset + patch_s]
            ch, cw = crop_img.shape[:2]

            # Om originalbilden är mindre än patch_s fyller vi ut med grått
            patch = np.full((patch_s, patch_s, 3), 114, dtype=np.uint8)
            patch[:ch, :cw] = crop_img

            # --- 2. Justera Polygonerna ---
            anns = self.labels_cache[idx]
            
            for ann in anns:
                poly = ann["poly"].copy()
                
                # A: Gör om från normaliserade [0, 1] till pixlar (originalupplösning)
                poly[:, 0] *= w
                poly[:, 1] *= h
                
                # B: Subtrahera offset så polygonerna blir relativa till vårt klipp
                poly[:, 0] -= x_offset
                poly[:, 1] -= y_offset
                
                # C: Klipp av vertex-punkter som hamnar utanför patchens ramar
                poly[:, 0] = np.clip(poly[:, 0], 0, cw)
                poly[:, 1] = np.clip(poly[:, 1], 0, ch)
                
                # D: Kontrollera om polygonen "överlevde" klippet (inte är reducerad till en platt linje i kanten)
                bw = poly[:, 0].max() - poly[:, 0].min()
                bh = poly[:, 1].max() - poly[:, 1].min()
                
                # Kräv att utsträckningen är minst 2x2 pixlar för att spara den
                if bw > 2 and bh > 2:
                    # E: Placera polygonen i rätt mosaik-kvadrant
                    oy, ox = offsets[i]
                    poly[:, 0] += ox
                    poly[:, 1] += oy
                    
                    # F: Normalisera om polygonen för den nya canvasen (s x s)
                    poly[:, 0] /= s
                    poly[:, 1] /= s
                    
                    all_anns.append({"cls": ann["cls"], "poly": poly})

            # --- 3. Placera patch i mosaik-canvasen ---
            oy, ox = offsets[i]
            mosaic_img[oy:oy + patch_s, ox:ox + patch_s] = patch

        return mosaic_img, all_anns

    def mosaic(self, index, dominant_ratio_range=(0.65, 0.8)):
        indices = [index] + random.choices(range(len(self)), k=3)
        s = self.img_size
        mosaic_img = np.full((s * 2, s * 2, 3), 114, dtype=np.uint8)

        dom_r = random.uniform(*dominant_ratio_range)
        main_w = int(2 * s * dom_r)
        main_h = int(2 * s * dom_r)

        main_w = min(max(main_w, int(1.2 * s)), int(1.7 * s))
        main_h = min(max(main_h, int(1.2 * s)), int(1.7 * s))

        # (x, y, w, h)
        regions = [
            (0, 0, main_w, main_h),                                # Uppe vänster (Main)
            (main_w, 0, 2 * s - main_w, main_h),                   # Uppe höger
            (0, main_h, main_w, 2 * s - main_h),                   # Nere vänster
            (main_w, main_h, 2 * s - main_w, 2 * s - main_h),      # Nere höger
        ]

        all_anns = []

        for i, idx in enumerate(indices):
            img = self.load_image(idx)
            rx, ry, rw, rh = regions[i]

            if rw <= 0 or rh <= 0:
                continue

            img_resized = cv2.resize(img, (rw, rh))
            mosaic_img[ry:ry + rh, rx:rx + rw] = img_resized

            anns = self.labels_cache[idx]
            for ann in anns:
                poly = ann["poly"].copy()
                # Omskalning baserat på regionens faktiska position och storlek
                poly[:, 0] = (poly[:, 0] * rw + rx) / (2 * s)
                poly[:, 1] = (poly[:, 1] * rh + ry) / (2 * s)
                all_anns.append({"cls": ann["cls"], "poly": poly})

        return mosaic_img, all_anns

    def __getitem__(self, idx):
        use_mosaic = self.is_train and random.random() < self.mosaic_p

        # 1. Hämta bild och annoteringar
        if use_mosaic:
            if random.random() < self.mosaic_p:
                img, anns = self.mosaic(idx)
            else:
                img, anns = self.mosaic_v1(idx)
            
            img = cv2.resize(img, (self.img_size, self.img_size), interpolation=cv2.INTER_LINEAR)
            h0, w0 = self.img_size, self.img_size 
        else:
            img = self.load_image(idx)
            h0, w0 = img.shape[:2] # Behåll originalmått!
            anns = self.labels_cache[idx]

        # 2. Generera bounding boxes och masker utifrån våra polygoner
        boxes = []
        labels = []
        masks_full = []

        for ann in anns:
            cls = ann["cls"]
            poly = ann["poly"]

            # Skala box och mask med faktiska dimensionerna (w0, h0)
            box = self._poly_to_box(poly, w0, h0) 
            x1, y1, x2, y2 = box
            
            if (x2 - x1) < 1.0 or (y2 - y1) < 1.0:
                continue

            mask = self._poly_to_mask(poly, w0, h0)

            boxes.append(box)
            labels.append(cls)
            masks_full.append(mask)

        # 3. Formatera datatyper innan transformering
        if len(boxes) == 0:
            boxes = np.zeros((0, 4), dtype=np.float32)
            labels = np.zeros((0,), dtype=np.int64)
            # VIKTIGT: Tomma masker måste ha originalstorlek här!
            masks_full = np.zeros((0, h0, w0), dtype=np.uint8) 
        else:
            boxes = np.asarray(boxes, dtype=np.float32)
            labels = np.asarray(labels, dtype=np.int64)
            masks_full = np.stack(masks_full, axis=0).astype(np.uint8)

            # VIKTIGT: Klipp boxarna mot h0 och w0, inte mot img_size!
            boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, w0 - 1)
            boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, h0 - 1)

            bw = boxes[:, 2] - boxes[:, 0]
            bh = boxes[:, 3] - boxes[:, 1]
            valid = (bw > 1.0) & (bh > 1.0)

            boxes = boxes[valid]
            labels = labels[valid]
            masks_full = masks_full[valid]

            if len(boxes) == 0:
                boxes = np.zeros((0, 4), dtype=np.float32)
                labels = np.zeros((0,), dtype=np.int64)
                masks_full = np.zeros((0, h0, w0), dtype=np.uint8)

        # 4. Augmenteringar
        if self.transforms is not None:
            transformed = self.transforms(
                image=img,
                bboxes=boxes.tolist(),
                labels=labels.tolist(),
                masks=[m for m in masks_full],
            )

            img = transformed["image"]

            if len(transformed["bboxes"]) == 0:
                boxes = np.zeros((0, 4), dtype=np.float32)
                labels = np.zeros((0,), dtype=np.int64)
                # Efter Albumentations är maskerna garanterat img_size x img_size tack vare padding
                masks_full = np.zeros((0, self.img_size, self.img_size), dtype=np.uint8)
            else:
                boxes = np.asarray(transformed["bboxes"], dtype=np.float32)
                labels = np.asarray(transformed["labels"], dtype=np.int64)
                masks_full = np.stack(transformed["masks"], axis=0).astype(np.uint8)
        else:
            img = torch.from_numpy(img).permute(2, 0, 1).float() / 255.0

        # 5. Skala ner masker för output
        if len(masks_full) == 0:
            masks = np.zeros((0, self.mask_size, self.mask_size), dtype=np.uint8)
        else:
            resized_masks = []
            for m in masks_full:
                rm = cv2.resize(
                    m,
                    (self.mask_size, self.mask_size),
                    interpolation=cv2.INTER_NEAREST,
                )
                resized_masks.append(rm)
            masks = np.stack(resized_masks, axis=0).astype(np.uint8)

        # 6. Bygg target-dictionary
        target = {
            "boxes": torch.as_tensor(boxes, dtype=torch.float32),
            "labels": torch.as_tensor(labels, dtype=torch.int64),
            "masks": torch.as_tensor(masks, dtype=torch.uint8),
            "image_id": torch.tensor([idx], dtype=torch.int64),
            "orig_size": torch.tensor([h0, w0], dtype=torch.int64), # Nu är de tillbaka!
        }

        return img, target