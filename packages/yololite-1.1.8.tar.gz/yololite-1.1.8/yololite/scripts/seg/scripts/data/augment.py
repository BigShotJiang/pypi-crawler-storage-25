import albumentations as A
from albumentations.pytorch import ToTensorV2
import cv2

def make_pad(img_size):
    try:
        return A.PadIfNeeded(
            min_height=img_size, min_width=img_size,
            border_mode=cv2.BORDER_CONSTANT,
            value=(114, 114, 114)  # some versions accept tuple; others ignore -> still fine
        )
    except TypeError:
        # Fall back without value
        return A.PadIfNeeded(
            min_height=img_size, min_width=img_size,
            border_mode=cv2.BORDER_CONSTANT
        )
def make_gauss_noise(p=0.15):
    try:
        # Common signature
        return A.GaussNoise(var_limit=(5.0, 20.0), p=p)
    except TypeError:
        # Fall back to defaults
        return A.GaussNoise(p=p)
# ---- safe wrappers to handle Albumentations API differences ----
def make_affine(**kw):
    """
    Try modern args first, fall back if not supported:
    - Some versions accept border_mode/cval, others ignore them.
    - We keep the geometric part the same either way.
    """
    try:
        return A.Affine(
            interpolation=cv2.INTER_LINEAR,
            border_mode=cv2.BORDER_CONSTANT,  # newer/most common
            cval=(114, 114, 114),
            fit_output=False,
            **kw
        )
    except TypeError:
        # Fall back: drop cval/border_mode if not accepted
        return A.Affine(fit_output=False, **kw)
    
def get_lite_transform(img_size=416):
    return A.Compose(
        [   
            # 0. GRUNDLÄGGANDE FORMATERING (Behålls)
            # Samma som innan, bevarar aspect ratio och fyller ut med padding.
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size), 
            
            # 1. GEOMETRISK AUGMENTERING (Mycket mildare)
            A.HorizontalFlip(p=0.5), # Spegling är helt naturligt och säkert att behålla
            
            # Endast lätt förskjutning och mycket försiktig skalning. 
            # Ingen rotation eller skevhet (shear) som förvränger naturliga linjer.
            make_affine(
                rotate=(0, 0),
                shear=(0, 0),
                scale=(0.9, 1.1), 
                translate_percent=(0.05, 0.05),
                p=0.2,
            ),

            # (RandomResizedCrop är helt borttaget härifrån)

            # 2. FÄRG OCH LJUS (Nedskruvat)
            # Vi låter nätverket se lite naturliga ljusvariationer, men stänger av CLAHE.
            A.OneOf([
                A.RandomBrightnessContrast(brightness_limit=0.1, contrast_limit=0.1),
                A.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
            ], p=0.3),

            # (Blur, Noise och CoarseDropout är borttagna)

            # 3. NORMALISERING TILL TENSOR (Behålls orört)
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["class_labels"],
            min_visibility=0.2, # Höjt lite eftersom vi inte croppar lika aggressivt
            min_area=10,        
            clip=True,
            filter_invalid_bboxes=True,
        ),
        p=1.0
    )
def get_seg_train_transform(img_size):
    return A.Compose(
        [   
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size),

            A.HorizontalFlip(p=0.5), # Höjd sannolikhet för COCO
            
            # RandomResizedCrop ersätter ofta vanlig Resize i träningsfasen.
            # Den tar ett slumpmässigt utsnitt (scale) och ändrar proportionerna (ratio),
            # sen skalar den upp det till img_size.
            A.RandomResizedCrop(
                size=(img_size, img_size),  # <--- Här är ändringen
                scale=(0.5, 1.0), 
                ratio=(0.75, 1.33), 
                p=0.5
            ),


            make_affine(
                rotate=(-10, 10),
                shear=(-5, 5),
                scale=(0.9, 1.1),
                translate_percent=(0.05, 0.05),
                p=0.3,
            ),

            # 2. OPTISKA EFFEKTER (Blur/Brus)
            A.OneOf([
                A.Blur(blur_limit=3, p=1.0),
                A.MedianBlur(blur_limit=3, p=1.0),
                A.MotionBlur(blur_limit=3, p=1.0),
                make_gauss_noise(p=1.0),
            ], p=0.25), # En fjärdedel av bilderna blir lite "stökiga"

            # 4. REGULARISERING (Hindra overfitting på minitrain)
            A.CoarseDropout(
                max_holes=8, 
                max_height=int(img_size * 0.1), 
                max_width=int(img_size * 0.1), 
                p=0.2
            ),
            A.OneOf([
                A.RandomBrightnessContrast(
                    brightness_limit=0.15,
                    contrast_limit=0.15,
                    p=1.0
                ),
                A.RandomGamma(
                    gamma_limit=(85, 115),
                    p=1.0
                ),
                A.CLAHE(
                    clip_limit=(1.0, 3.0),
                    tile_grid_size=(8, 8),
                    p=1.0
                ),
            ], p=0.5),

            A.OneOf([
                A.GaussianBlur(blur_limit=(3, 5), p=1.0),
                A.GaussNoise(std_range=(0.01, 0.03), p=1.0),
            ], p=0.15),

            A.Normalize(
                mean=(0.485, 0.456, 0.406),
                std=(0.229, 0.224, 0.225)
            ),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["labels"],
            min_area=10.0,
            min_visibility=0.1,
            clip=True,
        ),
    )


def get_seg_val_transform(img_size):
    return A.Compose(
        [
            A.LongestMaxSize(max_size=img_size),
            make_pad(img_size),
            A.Normalize(
                mean=(0.485, 0.456, 0.406),
                std=(0.229, 0.224, 0.225)
            ),
            ToTensorV2(),
        ],
        bbox_params=A.BboxParams(
            format="pascal_voc",
            label_fields=["labels"],
            clip=True,
        ),
    )