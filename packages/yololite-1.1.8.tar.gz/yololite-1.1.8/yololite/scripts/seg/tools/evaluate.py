import os
import sys
import csv
import argparse

import torch
import matplotlib
from torch.utils.data import DataLoader

matplotlib.use("Agg")

# Om projektet installeras via pip (t.ex. pip install -e .) behövs sällan detta hack, 
# men vi behåller det som en fallback så länge.
ROOT = os.getcwd()
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Projektets interna importer[cite: 1]
from train import evaluate_segmentation_model, yolo_seg_collate
from export.export_onnx import load_model_from_ckpt
from scripts.data.dataset import YoloSegDataset
from scripts.data.augment import get_seg_val_transform


def evaluate(weights_path, data_dir, img_size, batch_size, csv_log_path, device_override=None):
    """Kör utvärderingen av YOLO-segmenteringsmodellen."""
    
    # Bestäm enhet (GPU/CPU)
    if device_override:
        device = device_override
    else:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Loading model {weights_path} to{device}...")
    model, _ = load_model_from_ckpt(weights_path, device=device, verbose=False)

    print(f"Laddar dataset från {data_dir}...")
    val_ds = YoloSegDataset(
        os.path.join(data_dir, "images"),
        os.path.join(data_dir, "labels"),
        transforms=get_seg_val_transform(img_size),
        img_size=img_size,
        is_train=False,
        mask_downsample=4,
    )
    
    val_loader = DataLoader(
        val_ds, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=0, 
        pin_memory=False, 
        collate_fn=yolo_seg_collate, 
        drop_last=False
    )
    
    print("Startar utvärdering...")
    val_metrics = evaluate_segmentation_model(
        model=model,
        loader=val_loader,
        device=device,
        score_thr=0.01,
        nms_iou=0.7,
        mask_thr=0.5,
        max_det=100,
    )  

    # Skriv headern om filen inte redan finns[cite: 1]
    if not os.path.exists(csv_log_path):
        with open(csv_log_path, mode='w', newline='') as f:
            writer = csv.writer(f)
            header = ['bbox_map', 'bbox_map50', 'bbox_map75', 
                      'segm_map', 'segm_map50', 'segm_map75']
            writer.writerow(header)
            
    # Lägg till resultaten[cite: 1]
    with open(csv_log_path, mode='a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            val_metrics['bbox_map'],
            val_metrics['bbox_map50'],
            val_metrics['bbox_map75'],
            val_metrics['segm_map'],
            val_metrics['segm_map50'],
            val_metrics['segm_map75'],
        ])

    print("\n--- Eval done! ---")
    print(
        f"bbox mAP={val_metrics['bbox_map']:.4f} | "
        f"bbox mAP50={val_metrics['bbox_map50']:.4f}\n"
        f"segm mAP={val_metrics['segm_map']:.4f} | "
        f"segm mAP50={val_metrics['segm_map50']:.4f}"
    )


def main():
    parser = argparse.ArgumentParser(description="Utvärdera en YOLO segmenteringsmodell via CLI.")
    
    # Obligatoriska argument
    parser.add_argument("--weights", type=str, required=True, help="Sökväg till modellvikterna (.pt)")
    parser.add_argument("--data", type=str, required=True, help="Sökväg till valideringsdatasetets mapp")
    
    # Valfria argument med standardvärden
    parser.add_argument("--img-size", type=int, default=640, help="Bildstorlek (standard: 640)")
    parser.add_argument("--batch-size", type=int, default=8, help="Batch size (standard: 8)")
    parser.add_argument("--csv-log", type=str, default="evaluation_metrics.csv", help="Sökväg till CSV-loggen")
    parser.add_argument("--device", type=str, default=None, help="Tvinga körning på specifik enhet ('cpu' eller 'cuda')")

    args = parser.parse_args()

    # Anropa evaluate med CLI-argumenten
    evaluate(
        weights_path=args.weights,
        data_dir=args.data,
        img_size=args.img_size,
        batch_size=args.batch_size,
        csv_log_path=args.csv_log,
        device_override=args.device
    )

if __name__ == "__main__":
    main()