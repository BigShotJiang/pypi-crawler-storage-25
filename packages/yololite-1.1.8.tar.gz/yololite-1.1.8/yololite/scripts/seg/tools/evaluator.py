import time
import torch
import numpy as np
from tqdm.auto import tqdm
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from torch.utils.data import DataLoader

# Dina befintliga importer
from scripts.data.dataset import YoloSegDataset
from scripts.data.augment import get_seg_val_transform
from train import yolo_seg_collate
from predictor import YoloPredictor # Importera klassen vi precis skapade

class YoloEvaluator:
    def __init__(self, predictor: YoloPredictor, data_dir: str, batch_size: int = 1):
        """
        Initierar evaluatorn.
        OBS: Eftersom ONNX oftast körs bild för bild (batch size 1), 
        är default batch_size 1.
        """
        self.predictor = predictor
        self.data_dir = data_dir
        self.batch_size = batch_size
        self.device = "cuda" if "cuda" in predictor.device else "cpu"
        
        # Initiera metrics
        self.bbox_metric = MeanAveragePrecision(iou_type="bbox", backend="pycocotools")
        
        # Vi aktiverar bara segmenterings-metricen om modellen spottar ur sig masker
        self.has_masks = "protos" in getattr(predictor, "out_names", []) or predictor.backend == "pytorch"
        if self.has_masks:
            self.segm_metric = MeanAveragePrecision(iou_type="segm", backend="pycocotools")

        self._prepare_dataloader()

    def _prepare_dataloader(self):
        """Sätter upp validerings-dataloadern med samma transformeringar som i träningen."""
        import os
        val_ds = YoloSegDataset(
            os.path.join(self.data_dir, "images"),
            os.path.join(self.data_dir, "labels"),
            transforms=get_seg_val_transform(self.predictor.img_size),
            img_size=self.predictor.img_size,
            is_train=False,
            mask_downsample=4,
        )
        self.val_loader = DataLoader(
            val_ds, 
            batch_size=self.batch_size, 
            shuffle=False, 
            num_workers=0, 
            collate_fn=yolo_seg_collate, 
            drop_last=False
        )

    def evaluate(self, benchmark=False):
        """
        Kör evalueringen.
        Om benchmark=True, mäts även tiden det tar att pre-processa, inferera och post-processa.
        """
        print(f"Startar evaluering av {self.predictor.backend.upper()}-modell...")
        self.bbox_metric.reset()
        if self.has_masks:
            self.segm_metric.reset()

        total_times = []
        
        pbar = tqdm(self.val_loader, desc="Evaluating", dynamic_ncols=True)
        
        for images, targets in pbar:
            # images är en tensor från dataloadern.
            # Eftersom YoloPredictor är byggd för att ta BGR-bilder (numpy) för flexibilitet,
            # konverterar vi tillbaka dem här för att simulera en riktig inference-pipeline.
            # (Alternativt kan man bygga in stöd i Predictorn för att ta emot färdiga tensorer/batchar).
            
            for i in range(len(images)):
                # Konvertera Tensor till BGR Numpy (som om den lästs med cv2.imread)
                img_bgr = self._tensor_to_bgr(images[i])
                
                # --- START BENCHMARK ---
                if benchmark:
                    t0 = time.perf_counter()
                    
                # Kör prediktionen!
                results, _ = self.predictor.predict(img_bgr)
                
                # --- STOP BENCHMARK ---
                if benchmark:
                    t1 = time.perf_counter()
                    total_times.append((t1 - t0) * 1000.0) # Spara i millisekunder
                
                # Formatera prediktioner för TorchMetrics
                preds = self._format_predictions(results)
                
                # Formatera Ground Truth (Targets) för TorchMetrics
                # Måste matcha den specifika bilden (i)
                tgts = self._format_targets(targets[i], img_bgr.shape[:2])
                
                # Uppdatera metrics
                self.bbox_metric.update([preds], [tgts])
                if self.has_masks:
                    self.segm_metric.update([preds], [tgts])

        # Beräkna slutsiffrorna
        print("\nBeräknar COCO mAP...")
        bbox_res = self.bbox_metric.compute()
        
        results_dict = {
            "bbox_map": float(bbox_res["map"]),
            "bbox_map50": float(bbox_res["map_50"]),
            "bbox_map75": float(bbox_res["map_75"]),
        }
        
        if self.has_masks:
            segm_res = self.segm_metric.compute()
            results_dict.update({
                "segm_map": float(segm_res["map"]),
                "segm_map50": float(segm_res["map_50"]),
                "segm_map75": float(segm_res["map_75"]),
            })

        # Skriv ut resultaten
        self._print_results(results_dict, total_times if benchmark else None)
        
        return results_dict

    def _format_predictions(self, results):
        """Konverterar NumPy arrays från Predictorn till Torch-tensorer för metricen."""
        # TorchMetrics kräver specifika nycklar
        formatted = {
            "boxes": torch.from_numpy(results["boxes"]).float(),
            "scores": torch.from_numpy(results["scores"]).float(),
            "labels": torch.from_numpy(results["classes"]).long(),
        }
        if self.has_masks and len(results["masks"]) > 0:
            formatted["masks"] = torch.from_numpy(results["masks"]).to(torch.uint8)
        elif self.has_masks:
            # Fallback om bilden inte hade några prediktioner alls
            formatted["masks"] = torch.zeros((0, self.predictor.img_size, self.predictor.img_size), dtype=torch.uint8)
            
        return formatted

    def _format_targets(self, target, orig_shape):
        """Hämtar Ground Truth för en bild och anpassar till TorchMetrics."""
        h0, w0 = orig_shape
        
        formatted = {
            "boxes": target["boxes"].float(),
            "labels": target["labels"].long(),
        }
        
        if self.has_masks:
            masks = target.get("masks", None)
            if masks is None or len(masks) == 0:
                formatted["masks"] = torch.zeros((0, h0, w0), dtype=torch.uint8)
            else:
                # Maskerna i datasetet kan vara nedskalade, vi måste skala upp dem till (h0, w0)
                masks = masks.float()
                import torch.nn.functional as F
                masks = F.interpolate(
                    masks.unsqueeze(1),
                    size=(h0, w0),
                    mode="nearest"
                ).squeeze(1)
                formatted["masks"] = (masks > 0.5).to(torch.uint8)
                
        return formatted

    def _tensor_to_bgr(self, img_tensor):
        """Hjälpfunktion för att konvertera datasetets tensor till cv2-format korrekt."""
        img = img_tensor.detach().cpu().permute(1, 2, 0).numpy()
        
        # 1. REVERSERA ImageNet-normaliseringen!
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        img = (img * std) + mean 
        
        # 2. Nu ligger värdena mellan 0 och 1. Skala till 255.
        img = (img * 255.0).clip(0, 255).astype(np.uint8)
        import cv2
        return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    def _print_results(self, metrics, times=None):
        print("\n" + "="*40)
        print("          EVALUERINGSRESULTAT")
        print("="*40)
        print(f"BBox mAP 50-95: {metrics['bbox_map']:.4f}")
        print(f"BBox mAP 50:    {metrics['bbox_map50']:.4f}")
        
        if self.has_masks:
            print("-" * 40)
            print(f"Segm mAP 50-95: {metrics['segm_map']:.4f}")
            print(f"Segm mAP 50:    {metrics['segm_map50']:.4f}")
            
        if times:
            print("-" * 40)
            print("          PRESTANDA (End-to-End)")
            print("-" * 40)
            avg_ms = np.mean(times)
            p90_ms = np.percentile(times, 90)
            fps = 1000.0 / avg_ms
            print(f"Snitt per bild: {avg_ms:.2f} ms ({fps:.1f} FPS)")
            print(f"90:e percentil:  {p90_ms:.2f} ms")
        print("="*40)