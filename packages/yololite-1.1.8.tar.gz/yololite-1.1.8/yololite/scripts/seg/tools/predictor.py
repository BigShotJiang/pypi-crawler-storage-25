
import cv2
import numpy as np
import torch
import onnxruntime as ort
from pathlib import Path
import random
import torch.nn.functional as F
from torchvision.ops import batched_nms
# --- Importera dina befintliga hjälpfunktioner ---
# Från PyTorch-sidan (train.py / evaluate.py)
import os, sys

from ..export.export_onnx import load_model_from_ckpt
from torchvision.ops import batched_nms
from train import decode_simple_seg 

class YoloPredictor:
    def __init__(self, weights_path, device="cpu", img_size=640, conf_thr=0.25, iou_thr=0.5, class_names=None):
        self.weights_path = str(weights_path)
        self.device = device
        self.img_size = img_size
        self.conf_thr = conf_thr
        self.iou_thr = iou_thr
        
        # Används som fallback om varken ONNX-argument eller PT-config har namn
        self.class_names = class_names 
        
        self.backend = "onnx" if self.weights_path.endswith(".onnx") else "pytorch"
        self._load_model()
        
        # Säkerhetskontroll: Har vi klassnamn nu? Om inte, skapa generiska.
        if self.class_names is None:
            # Om det var ONNX och varken namn eller num_classes skickades in, antar vi 80 (COCO)
            self.class_names = [str(i) for i in range(80)]
            print(f"Varning: Inga klassnamn angavs. Antar {len(self.class_names)} klasser.")
            
        self._init_colors()

    def _init_colors(self):
        """Genererar fasta, snygga färger per klass."""
        self.colors = []
        for i in range(len(self.class_names)):
            random.seed(i * 42)
            self.colors.append((
                random.randint(50, 255), 
                random.randint(50, 255), 
                random.randint(50, 255)
            ))

    def _load_model(self):
        """Laddar antingen ONNX-session eller PyTorch-modell."""
        if self.backend == "onnx":
            print("Initierar ONNX Runtime...")
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if "cuda" in self.device else ["CPUExecutionProvider"]
            self.session = ort.InferenceSession(self.weights_path, providers=providers)
            self.in_name = self.session.get_inputs()[0].name
            self.out_names = [o.name for o in self.session.get_outputs()]
            self.has_integrated_nms = "output" in self.out_names
            
            # För ONNX: Om user skickade in class_names som en INT (t.ex. class_names=1)
            if isinstance(self.class_names, int):
                self.class_names = [str(i) for i in range(self.class_names)]
            
        elif self.backend == "pytorch":
            print(f"Initierar PyTorch på {self.device}...")
            
            # 1. Först laddar vi checkpointen manuellt för att tjuvläsa din config
            ckpt = torch.load(self.weights_path, map_location=self.device)
            
            # 2. Hämta klassnamn från configen om de finns
            if "config" in ckpt and "dataset" in ckpt["config"] and "names" in ckpt["config"]["dataset"]:
                saved_names = ckpt["config"]["dataset"]["names"]
                
                # Använd configens namn om inte användaren aktivt skickat in något annat
                if self.class_names is None:
                    self.class_names = saved_names
                    print(f"Hittade klassnamn i .pt-filen: {self.class_names}")
                    
            # 3. Ladda modellen som vanligt
            self.model, _ = load_model_from_ckpt(self.weights_path, device=self.device, verbose=False)
            self.model.eval()
            
            # 4. Sista säkerhetskollen - om vi fortfarande saknar namn, kolla modellens attribut
            if self.class_names is None and hasattr(self.model, 'num_classes'):
                self.class_names = [str(i) for i in range(self.model.num_classes)]

    def preprocess(self, img_bgr):
        """Standardiserad pre-processing med letterbox. Anpassad för inbyggd ONNX-normalisering."""
        h0, w0 = img_bgr.shape[:2]
        
        # 1. Letterbox (bibehåll aspect ratio)
        scale = min(self.img_size / h0, self.img_size / w0)
        nh, nw = int(round(h0 * scale)), int(round(w0 * scale))
        
        img_resized = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_LINEAR)
        
        top = (self.img_size - nh) // 2
        bottom = self.img_size - nh - top
        left = (self.img_size - nw) // 2
        right = self.img_size - nw - left
        
        img_padded = cv2.copyMakeBorder(img_resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114,114,114))
        
        # 2. BGR till RGB
        img_rgb = cv2.cvtColor(img_padded, cv2.COLOR_BGR2RGB)
        
        # 3. Dela upp logiken!
        if self.backend == "onnx":
            # ONNX-grafen sköter all normalisering! Den förväntar sig värden mellan 0 och 255.
            blob = np.transpose(img_rgb, (2, 0, 1))
            
            # OBS: Datatypen här måste matcha din "dummy"-tensor från export_onnx.py!
            # Om du hade dtype=torch.uint8 under exporten -> använd astype(np.uint8)
            # Om du ändrade till dtype=torch.float32 under exporten -> använd astype(np.float32)
            # VÄRDENA ska dock förbli oskalade (dvs. upp till 255).
            blob = np.expand_dims(blob, axis=0).astype(np.uint8) 
            
        else:
            # PyTorch-modellen saknar NormalizeInput. Vi MÅSTE göra matten manuellt i Python.
            img_float = img_rgb.astype(np.float32) / 255.0
            
            mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
            std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
            img_norm = (img_float - mean) / std
            
            blob = np.transpose(img_norm, (2, 0, 1))
            blob = torch.from_numpy(blob).unsqueeze(0).to(self.device)
            
        pad_info = (left, top, nw, nh, scale)
        return blob, pad_info, (h0, w0)

    def predict(self, img_source):
        """Huvudfunktion: Tar en bildsökväg eller numpy-array och returnerar standardiserat resultat."""
        if isinstance(img_source, str) or isinstance(img_source, Path):
            img_bgr = cv2.imread(str(img_source))
        else:
            img_bgr = img_source.copy()

        blob, pad_info, orig_shape = self.preprocess(img_bgr)

        # Inferens
        if self.backend == "onnx":
            outputs = self.session.run(self.out_names, {self.in_name: blob})
            results = self._postprocess_onnx(outputs, pad_info, orig_shape)
        else:
            with torch.no_grad():
                outputs = self.model(blob)
            results = self._postprocess_pytorch(outputs, pad_info, orig_shape)

        return results, img_bgr

    def _postprocess_onnx(self, outputs, pad_info, orig_shape):
        """Hanterar ONNX-specifik postprocessing."""
        left, top, nw, nh, scale = pad_info
        h0, w0 = orig_shape
        
        has_protos = "protos" in self.out_names
        protos_out = None
        if has_protos:
            protos_out = outputs[self.out_names.index("protos")][0]
            
        if self.has_integrated_nms:
            dets = outputs[self.out_names.index("output")][0] 
            mask = dets[:, 4] >= self.conf_thr
            valid_dets = dets[mask]
            
            boxes_pad = valid_dets[:, :4]
            scores_pad = valid_dets[:, 4]
            classes = valid_dets[:, 5].astype(np.int64)
            mask_coeffs = valid_dets[:, 6:] if valid_dets.shape[1] > 6 else None
            
        else:
            boxes = outputs[self.out_names.index("boxes_xyxy")][0]
            cls_log = outputs[self.out_names.index("cls_logits")][0]
            mask_c = outputs[self.out_names.index("mask_coeffs")][0] if has_protos else None
            cls_log = np.clip(cls_log, -88.0, 88.0)
            cls_sig = 1 / (1 + np.exp(-cls_log)) 
            scores = cls_sig.max(axis=-1)
            cls_id = cls_sig.argmax(axis=-1).astype(np.int64)

            m = scores > self.conf_thr
            boxes_p = boxes[m]
            scores_p = scores[m]
            cls_p = cls_id[m]
            mask_p = mask_c[m] if mask_c is not None else None
            
            final_b, final_s, final_c, final_m = [], [], [], []
            
            for c in np.unique(cls_p):
                mc = (cls_p == c)
                keep = self._nms_np(boxes_p[mc], scores_p[mc], self.iou_thr, max_det=300)
                if keep.size:
                    final_b.append(boxes_p[mc][keep])
                    final_s.append(scores_p[mc][keep])
                    final_c.append(np.full((keep.size,), int(c), dtype=np.int64))
                    if mask_p is not None:
                        final_m.append(mask_p[mc][keep])

            if final_b:
                boxes_pad  = np.concatenate(final_b, 0)
                scores_pad = np.concatenate(final_s, 0)
                classes    = np.concatenate(final_c, 0)
                mask_coeffs= np.concatenate(final_m, 0) if final_m else None
            else:
                boxes_pad  = np.zeros((0,4), np.float32)
                scores_pad = np.zeros((0,), np.float32)
                classes    = np.zeros((0,), np.int64)
                mask_coeffs= None

        # 1. Back-map boxar till originalbild
        boxes_px = boxes_pad.copy()
        if len(boxes_px) > 0:
            boxes_px[:, [0, 2]] -= left
            boxes_px[:, [1, 3]] -= top
            boxes_px /= max(scale, 1e-6)

            boxes_px[:, [0, 2]] = np.clip(boxes_px[:, [0, 2]], 0, w0 - 1)
            boxes_px[:, [1, 3]] = np.clip(boxes_px[:, [1, 3]], 0, h0 - 1)

        # 2. Processa Masker
        final_masks = None
        if has_protos and mask_coeffs is not None and len(mask_coeffs) > 0:
            final_masks = self._process_masks_onnx(
                protos_out, mask_coeffs, boxes_px, 
                (self.img_size, self.img_size), (h0, w0), 
                pad_info
            )
        else:
            final_masks = np.zeros((0, h0, w0), dtype=bool)

        return {
            "boxes": boxes_px,
            "scores": scores_pad,
            "classes": classes,
            "masks": final_masks
        }

    @staticmethod
    def _nms_np(boxes, scores, iou_th=0.5, max_det=300):
        if len(boxes) == 0:
            return np.array([], dtype=np.int64)
        x1, y1, x2, y2 = boxes.T
        areas = (x2 - x1).clip(0) * (y2 - y1).clip(0)
        order = scores.argsort()[::-1]
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            if len(keep) >= max_det:
                break
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])
            w = (xx2 - xx1).clip(0)
            h = (yy2 - yy1).clip(0)
            inter = w * h
            iou = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
            order = order[1:][iou <= iou_th]
        return np.array(keep, dtype=np.int64)

    @staticmethod
    def _process_masks_onnx(protos, mask_coeffs, bboxes, img_shape, original_shape, pad_info):
        """Kombinerar prototyper och koefficienter, och skalar om till originalbild."""
        left, top, nw, nh, scale = pad_info
        h0, w0 = original_shape
        
        # Säkerhetskontroll: Om inga masker skickades in, returnera en tom array direkt.
        if mask_coeffs is None or len(mask_coeffs) == 0:
            return np.zeros((0, h0, w0), dtype=bool)

        n, c = mask_coeffs.shape
        _, mh, mw = protos.shape
        
        # Ytterligare en säkerhetskontroll: n kan bli 0 efter filtrering
        if n == 0:
            return np.zeros((0, h0, w0), dtype=bool)

        masks = mask_coeffs @ protos.reshape(c, -1)
        masks = masks.reshape(n, mh, mw)
        
        # Begränsa värdena så np.exp() inte kraschar (Fix för RuntimeWarning)
        masks = np.clip(masks, -88.0, 88.0)
        
        masks = 1 / (1 + np.exp(-masks))
        
        # OpenCV vill ha formatet [H, W, Channels] för resize
        masks = masks.transpose(1, 2, 0) 
        
        # Nu vet vi att masks INTE är tom, så cv2.resize är säkert att anropa
        masks_up = cv2.resize(masks, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_LINEAR)
        
        # Om n == 1 försvinner kanal-dimensionen efter resize, vi måste lägga tillbaka den
        if n == 1:
            masks_up = masks_up[..., None]
            
        masks_up = masks_up.transpose(2, 0, 1) # Tillbaka till [N, H, W]
        
        # Beskär bort padding
        masks_valid = masks_up[:, top:top+nh, left:left+nw]
        
        # Skala tillbaka till originalbildens upplösning
        masks_valid = masks_valid.transpose(1, 2, 0)
        masks_orig = cv2.resize(masks_valid, (w0, h0), interpolation=cv2.INTER_LINEAR)
        
        if n == 1: 
            masks_orig = masks_orig[..., None]
            
        masks_orig = masks_orig.transpose(2, 0, 1)
            
        out_masks = np.zeros((n, h0, w0), dtype=bool)
        for i in range(n):
            x1, y1, x2, y2 = map(int, bboxes[i])
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w0, x2), min(h0, y2)
            out_masks[i, y1:y2, x1:x2] = masks_orig[i, y1:y2, x1:x2] > 0.5
            
        return out_masks
    def _postprocess_pytorch(self, outputs, pad_info, orig_shape):
        left, top, nw, nh, scale = pad_info
        h0, w0 = orig_shape
        
        # 1. Dekoda utdata (B = 1 eftersom vi kör en bild)
        boxes_xyxy, coeff_flat, proto, scores, cls_ids = decode_simple_seg(
            outputs,
            num_classes=len(self.class_names),
            n_mask=32, # Ändra ifall du har fler/färre prototyper
            img_size=self.img_size,
            conf_th=self.conf_thr
        )
        
        boxes_b = boxes_xyxy[0]
        scores_b = scores[0]
        cls_b = cls_ids[0]
        coeff_b = coeff_flat[0]
        proto_b = proto[0]
        
        # 2. Pre-filtrera boxar (för snabbare NMS)
        score_mask = scores_b > self.conf_thr
        boxes_b = boxes_b[score_mask]
        scores_b = scores_b[score_mask]
        cls_b = cls_b[score_mask]
        coeff_b = coeff_b[score_mask]
        
        if len(boxes_b) == 0:
            return {
                "boxes": np.zeros((0, 4), dtype=np.float32),
                "scores": np.zeros((0,), dtype=np.float32),
                "classes": np.zeros((0,), dtype=np.int64),
                "masks": np.zeros((0, h0, w0), dtype=bool)
            }
            
        # 3. NMS (Batched NMS från Torchvision)
        keep = batched_nms(boxes_b, scores_b, cls_b, iou_threshold=self.iou_thr)
        keep = keep[:300] # max_det
        
        boxes_b = boxes_b[keep]
        scores_b = scores_b[keep]
        cls_b = cls_b[keep]
        coeff_b = coeff_b[keep]
        
        # 4. Beräkna Masker (Fortfarande på GPU)
        nm, Hp, Wp = proto_b.shape
        mask_logits = (coeff_b @ proto_b.view(nm, -1)).view(-1, Hp, Wp)
        mask_probs = torch.sigmoid(mask_logits)
        
        # Skala upp maskerna till 640x640 (eller img_size)
        masks_up = F.interpolate(
            mask_probs.unsqueeze(1), 
            size=(self.img_size, self.img_size), 
            mode="bilinear", 
            align_corners=False
        ).squeeze(1) # [N, img_size, img_size]
        
        # Beskär bort padding som lades till i letterbox
        masks_valid = masks_up[:, top:top+nh, left:left+nw]
        
        # Skala till originalbildens form (h0, w0)
        if len(masks_valid) > 0:
            masks_orig = F.interpolate(
                masks_valid.unsqueeze(1),
                size=(h0, w0),
                mode="bilinear",
                align_corners=False
            ).squeeze(1)
        else:
            masks_orig = torch.zeros((0, h0, w0), device=self.device)
            
        # 5. Skala tillbaka bounding boxarna
        boxes_b[:, [0, 2]] -= left
        boxes_b[:, [1, 3]] -= top
        boxes_b /= max(scale, 1e-6)
        boxes_b[:, [0, 2]] = torch.clamp(boxes_b[:, [0, 2]], min=0, max=w0 - 1)
        boxes_b[:, [1, 3]] = torch.clamp(boxes_b[:, [1, 3]], min=0, max=h0 - 1)
        
        # ==========================================
        # Flytta resultaten till CPU / Numpy!
        # ==========================================
        masks_orig_bin = (masks_orig > 0.5)
        
        boxes_np = boxes_b.cpu().numpy()
        scores_np = scores_b.cpu().numpy()
        cls_np = cls_b.cpu().numpy()
        masks_np = masks_orig_bin.cpu().numpy()
        
        # 6. Beskär maskerna innanför bounding boxarna för att ta bort "spök-masker"
        final_masks = np.zeros_like(masks_np, dtype=bool)
        for i in range(len(boxes_np)):
            x1, y1, x2, y2 = map(int, boxes_np[i])
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w0, x2), min(h0, y2)
            final_masks[i, y1:y2, x1:x2] = masks_np[i, y1:y2, x1:x2]

        return {
            "boxes": boxes_np,
            "scores": scores_np,
            "classes": cls_np,
            "masks": final_masks
        }
    def draw(self, img, results):
        """Standardiserad ritfunktion som ser identisk ut för ONNX/PyTorch."""
        out = img.copy()
        boxes = results["boxes"]
        scores = results["scores"]
        classes = results["classes"]
        masks = results["masks"]
        
        mask_overlay = np.zeros_like(out)
        
        for i, (b, s, c) in enumerate(zip(boxes, scores, classes)):
            x1, y1, x2, y2 = map(int, b.tolist())
            cls_id = int(c)
            
            # Hämta namn och färg
            name = self.class_names[cls_id] if 0 <= cls_id < len(self.class_names) else str(cls_id)
            color = self.colors[cls_id % len(self.colors)]
            
            # --- Rita Mask ---
            if masks is not None and len(masks) > i:
                obj_mask = masks[i]
                mask_overlay[obj_mask] = color
                
            # --- Rita Box ---
            cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
            
            # --- Rita Snygg Label med Bakgrund ---
            label_text = f"{name} {s:.2f}"
            (tw, th), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            
            # Rektangel för textbakgrund
            cv2.rectangle(
                out, 
                (x1, max(0, y1 - th - 6)), 
                (x1 + tw + 4, max(th + 6, y1)), 
                color, -1
            )
            # Vit text
            cv2.putText(
                out, 
                label_text, 
                (x1 + 2, max(th + 3, y1 - 3)),
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.5, 
                (255, 255, 255), 
                1
            )

        # Mixa in mask-lagret semi-transparent över bilden
        if masks is not None and len(masks) > 0:
            out = cv2.addWeighted(out, 1.0, mask_overlay, 0.45, 0)
            
        return out