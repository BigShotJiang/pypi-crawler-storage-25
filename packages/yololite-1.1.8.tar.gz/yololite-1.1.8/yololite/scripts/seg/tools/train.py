import os
import sys
import yaml
import math
import copy
import csv
import gc
import random
from pathlib import Path
import torch.nn as nn
from torchvision.ops import batched_nms
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, WeightedRandomSampler
from tqdm.auto import tqdm
import matplotlib
from torchvision.ops import batched_nms
matplotlib.use("Agg")
import torch
import torch.nn.functional as F
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from torchvision.ops import batched_nms
ROOT = os.getcwd()
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from ..scripts.model.model_v2 import YOLOE_Nano_Seg
from ..scripts.model.model import YOLOESeg
from ..scripts.data.dataset import YoloSegDataset
from ..scripts.helpers.schedulers import build_scheduler
from ..scripts.loss.loss import LossAF, SegLoss
from ..scripts.args.build_args import build_argparser, load_configs, apply_overrides
from ..scripts.helpers.helpers import set_seed
from ..scripts.loss.loss import decode_preds_for_seg
from ..scripts.data.augment import get_seg_train_transform, get_seg_val_transform
def seed_worker(worker_id):
    # PyTorch ger varje worker en specifik seed utifrån huvud-seeden + worker_id
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)
class CurriculumController:
    def __init__(self, criterion, warmup_end=10, strict_start=30, verbose=True):
        self.criterion = criterion
        self.det_loss = criterion.det_loss 
        
        self.warmup_end = warmup_end
        self.strict_start = strict_start
        self.verbose = verbose
        
        # 1. Spara originalvärdet för mask-lossen (det du skickade in från config)
        self.target_lambda_mask = self.criterion.lambda_mask
        
        # --- FAS 1: Exploration (Snälla startvärden för max Recall) ---
        self.det_loss.center_radius_cells = 3.5
        self.det_loss.topk_limit = 35
        self.det_loss.iou_cost_w = 1.0
        self.det_loss.lambda_box = 3.0  
        
        # 2. Stryp mask-lossen stenhårt från start (t.ex. 10% av sin normala vikt)
        self.criterion.lambda_mask = self.target_lambda_mask * 0.1
        
        if self.verbose:
            print(f"[Curriculum] Initierad. Mask-loss strypt till {self.criterion.lambda_mask:.3f} "
                  f"| Radie: {self.det_loss.center_radius_cells}")

    def step(self, epoch):
        current_epoch = epoch + 1
        
        # Mask Warmup slutar halvvägs genom den totala warmup-fasen
        mask_warmup_end = max(1, self.warmup_end // 2)

        # --- FAS 1A: Håll Mask låg, låt boxarna ta form ---
        if current_epoch <= mask_warmup_end:
            pass # Gör ingenting, låt lambda_mask ligga kvar på 10%

        # --- FAS 1B: Rampa upp Mask-lossen innan vi stramar åt reglerna ---
        elif mask_warmup_end < current_epoch <= self.warmup_end:
            progress = (current_epoch - mask_warmup_end) / (self.warmup_end - mask_warmup_end)
            
            # Gå från 10% till 100% av target_lambda_mask
            self.criterion.lambda_mask = (self.target_lambda_mask * 0.1) + (progress * self.target_lambda_mask * 0.9)
            
            if self.verbose:
                print(f"[Curriculum] Rampar upp mask-vikt: {self.criterion.lambda_mask:.3f}")

        # --- FAS 2: Stegvis åtstramning av matchning (Exploitation) ---
        elif self.warmup_end < current_epoch <= self.strict_start:
            progress = (current_epoch - self.warmup_end) / (self.strict_start - self.warmup_end)
            
            self.det_loss.center_radius_cells = 3.5 - (progress * 1.0) 
            self.det_loss.topk_limit = int(35 - (progress * 10))       
            self.det_loss.iou_cost_w = 1.0 + (progress * 0.5)          
            self.det_loss.lambda_box = 3.0 + (progress * 4.5)          
            
            if self.verbose:
                print(f"[Curriculum] Stramar åt reglerna: "
                      f"Radie={self.det_loss.center_radius_cells:.2f}, "
                      f"TopK={self.det_loss.topk_limit}")
        
        # --- FAS 3: Färdig ---
        elif current_epoch == self.strict_start + 1:
            if self.verbose:
                print("\n[Curriculum] Övergång klar! Kör nu på strikta targets.")
def save_checkpoint_state_last(
    model, 
    optimizer,            # NYTT
    epoch: int,           # NYTT
    metrics: dict, 
    class_names, 
    config: dict, 
    out_path: str, 
    num_anchors_per_level: tuple,
    scaler=None,          # NYTT (valfritt men rekommenderat)
    ema_model=None        # NYTT (valfritt men rekommenderat)
):
    # Spara modellens vikter
    cpu_state = {k: v.cpu() for k, v in model.state_dict().items()}
    
    # Bygg det stora dictionaryt
    checkpoint = {
        "epoch": epoch,
        "model_state_dict": cpu_state,
        "optimizer_state_dict": optimizer.state_dict(),
        "metrics": metrics,
        "meta": {
            "names": list(class_names) if class_names else None,
            "num_classes": int(config["model"]["num_classes"]),
            "img_size": int(config["training"].get("img_size", 640)),
            "arch": config["model"]["arch"],
            "backbone": config["model"]["backbone"],
            "num_anchors_per_level": num_anchors_per_level,
            "config": config,  
        }
    }

    # Lägg till AMP Scaler om den finns
    if scaler is not None:
        checkpoint["scaler_state_dict"] = scaler.state_dict()

    # Lägg till EMA-modellens vikter om den finns
    if ema_model is not None:
        # Om ema_model är en klass från t.ex. timm, hämta dess state_dict
        checkpoint["ema_state_dict"] = {k: v.cpu() for k, v in ema_model.state_dict().items()}

    # Spara till disk!
    torch.save(checkpoint, out_path)
    
def save_checkpoint_state(model, metrics: dict, class_names, config: dict, out_path: str, num_anchors_per_level: tuple):
    cpu_state = {k: v.cpu() for k, v in model.state_dict().items()}
    meta = {
        "names": list(class_names) if class_names else None,
        "num_classes": int(config["model"]["num_classes"]),
        "img_size": int(config["training"].get("img_size", 640)),
        "arch": config["model"]["arch"],
        "backbone": config["model"]["backbone"],
        "num_anchors_per_level": num_anchors_per_level,
        "config": config,  
    }
    torch.save({"state_dict": cpu_state, "meta": meta}, out_path)
def tensor_to_bgr_image(img_tensor):
    """
    img_tensor: [3, H, W], normaliserad med ImageNet mean/std
    return: uint8 BGR för OpenCV
    """
    img = img_tensor.detach().cpu().permute(1, 2, 0).numpy()

    mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
    std = np.array([0.229, 0.224, 0.225], dtype=np.float32)

    img = (img * std) + mean
    img = (img * 255.0).clip(0, 255).astype(np.uint8)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    return img
@torch.no_grad()
def evaluate_segmentation_model(
    model,
    loader,
    device,
    score_thr=0.25,
    nms_iou=0.5,
    mask_thr=0.5,
    max_det=100,
):
    model.eval()

    bbox_metric = MeanAveragePrecision(iou_type="bbox", backend="pycocotools")
    segm_metric = MeanAveragePrecision(iou_type="segm", backend="pycocotools")

    pbar = tqdm(loader, desc="Evaluating", dynamic_ncols=True)

    for images, targets in pbar:
        images = images.to(device, non_blocking=True)
        targets = [
            {k: (v.to(device, non_blocking=True) if torch.is_tensor(v) else v) for k, v in t.items()}
            for t in targets
        ]

        # Säkerställ att inga gradienter beräknas under evaluering (sparar mycket tid/RAM)
        with torch.no_grad():
            outputs = model(images)

        _, _, H, W = images.shape

        preds = build_batch_predictions_for_map(
            outputs=outputs,
            img_h=H,
            img_w=W,
            num_classes=model.num_classes,
            n_mask=model.n_mask,
            score_thr=score_thr,
            nms_iou=nms_iou,
            mask_thr=mask_thr,
            max_det=max_det,
        )

        tgts = build_batch_targets_for_map(
            targets=targets,
            device=device,
            img_h=H,
            img_w=W,
        )

        bbox_metric.update(preds, tgts)
        segm_metric.update(preds, tgts)

        # Radera lokala variabler för att hålla nere VRAM, men INGEN gc.collect() här inne!
        del preds, tgts, outputs, images, targets

    pbar.set_description("Computing metrics...")
    
    bbox_res = bbox_metric.compute()
    segm_res = segm_metric.compute()

    results = {
        "bbox_map": float(bbox_res["map"]),
        "bbox_map50": float(bbox_res["map_50"]),
        "bbox_map75": float(bbox_res["map_75"]),
        "bbox_maps": float(bbox_res["map_small"]) if bbox_res["map_small"].numel() else -1.0,
        "bbox_mapm": float(bbox_res["map_medium"]) if bbox_res["map_medium"].numel() else -1.0,
        "bbox_mapl": float(bbox_res["map_large"]) if bbox_res["map_large"].numel() else -1.0,

        "segm_map": float(segm_res["map"]),
        "segm_map50": float(segm_res["map_50"]),
        "segm_map75": float(segm_res["map_75"]),
        "segm_maps": float(segm_res["map_small"]) if segm_res["map_small"].numel() else -1.0,
        "segm_mapm": float(segm_res["map_medium"]) if segm_res["map_medium"].numel() else -1.0,
        "segm_mapl": float(segm_res["map_large"]) if segm_res["map_large"].numel() else -1.0,
    }
    
    bbox_metric.reset()
    segm_metric.reset()

    # Tvinga städning EN GÅNG när hela evalueringen är klar
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    return results


def build_batch_predictions_for_map(
    outputs,
    img_h,
    img_w,
    num_classes=3, 
    n_mask=32,     
    score_thr=0.25,
    nms_iou=0.5,
    mask_thr=0.5,
    max_det=100,
):
    boxes_xyxy, coeff_flat, proto, scores, cls_ids = decode_simple_seg(
        outputs,
        num_classes=num_classes,
        n_mask=n_mask,
        img_size=img_w,
        conf_th=score_thr
    )

    B = boxes_xyxy.shape[0]
    preds_out = []
    device = boxes_xyxy.device

    # --- Förberedelser utanför loopen ---
    
    # 1. Meshgrid
    sy, sx = torch.meshgrid(
        torch.arange(img_h, device=device), 
        torch.arange(img_w, device=device), 
        indexing="ij"
    )
    sx = sx.unsqueeze(0)  # [1, H, W]
    sy = sy.unsqueeze(0)  # [1, H, W]

    # 2. Omvandla sannolikhetströskel (mask_thr) till logit-tröskel
    # Detta låter oss skippa torch.sigmoid() helt och hållet.
    epsilon = 1e-6
    safe_mask_thr = max(epsilon, min(1.0 - epsilon, mask_thr))
    logit_thr = math.log(safe_mask_thr / (1.0 - safe_mask_thr))

    for b in range(B):
        score_mask = scores[b] > score_thr

        boxes_b = boxes_xyxy[b][score_mask]
        scores_b = scores[b][score_mask]
        cls_b = cls_ids[b][score_mask]
        coeff_b = coeff_flat[b][score_mask]

        if boxes_b.shape[0] == 0:
            preds_out.append({
                "boxes": torch.zeros((0, 4), dtype=torch.float32, device="cpu"),
                "scores": torch.zeros((0,), dtype=torch.float32, device="cpu"),
                "labels": torch.zeros((0,), dtype=torch.int64, device="cpu"),
                "masks": torch.zeros((0, img_h, img_w), dtype=torch.uint8, device="cpu"),
            })
            continue
        
        keep = batched_nms(boxes_b, scores_b, cls_b, iou_threshold=nms_iou)
        keep = keep[:max_det]

        boxes_b = boxes_b[keep]
        scores_b = scores_b[keep]
        cls_b = cls_b[keep]
        coeff_b = coeff_b[keep]

        proto_b = proto[b]  # [nm, Hp, Wp]

        # Multiplicera coeffs med protos (Vektoriserat)
        mask_logits = coeff_b @ proto_b.view(proto_b.shape[0], -1) 
        mask_logits = mask_logits.view(-1, proto_b.shape[1], proto_b.shape[2]) # [N, Hp, Wp]

        # Skala upp logit-maskerna
        mask_logits = F.interpolate(
            mask_logits.unsqueeze(1),
            size=(img_h, img_w),
            mode="bilinear",
            align_corners=False
        ).squeeze(1) # [N, img_h, img_w]

        # Spatiala gränser för boxarna
        x1 = boxes_b[:, 0].view(-1, 1, 1)
        y1 = boxes_b[:, 1].view(-1, 1, 1)
        x2 = boxes_b[:, 2].view(-1, 1, 1)
        y2 = boxes_b[:, 3].view(-1, 1, 1)

        box_mask = (sx >= x1) & (sx < x2) & (sy >= y1) & (sy < y2)

        # Tröskla direkt på logits och applicera box_mask (INGEN SIGMOID!)
        pred_masks = (mask_logits > logit_thr) & box_mask

        # Kopiera till CPU utan att låsa VRAM (använder detach för säkerhets skull)
        preds_out.append({
            "boxes": boxes_b.detach().cpu(), 
            "scores": scores_b.detach().cpu(), 
            "labels": cls_b.detach().cpu(), 
            "masks": pred_masks.detach().cpu().to(torch.uint8), 
        })

    return preds_out

def build_batch_targets_for_map(targets, device, img_h, img_w):
    out = []
    for t in targets:
        boxes = t["boxes"].to(device=device, dtype=torch.float32, non_blocking=True)
        labels = t["labels"].to(device=device, dtype=torch.int64, non_blocking=True)

        masks = t.get("masks", None)
        if masks is None:
            masks = torch.zeros((0, img_h, img_w), dtype=torch.bool, device=device)
        else:
            masks = masks.to(device=device, dtype=torch.float32, non_blocking=True)
            if masks.numel() > 0:
                masks = F.interpolate(
                    masks.unsqueeze(1),
                    size=(img_h, img_w),
                    mode="nearest"
                ).squeeze(1)
            masks = masks > 0.5

        out.append({
            "boxes": boxes.detach().cpu(),
            "labels": labels.detach().cpu(),
            "masks": masks.detach().cpu().to(torch.uint8), 
        })
    return out
def build_pred_mask_from_coeff(
    coeff,
    proto_b,
    box_xyxy,
    out_h,
    out_w,
    threshold=0.5,
):
    """
    coeff: [nm]
    proto_b: [nm, Hp, Wp]
    box_xyxy: [4] i pixelkoordinater för out_h/out_w
    return: [out_h, out_w] bool mask
    """
    nm, Hp, Wp = proto_b.shape

    pmask = (coeff @ proto_b.view(nm, -1)).view(Hp, Wp).sigmoid()
    pmask = F.interpolate(
        pmask[None, None],
        size=(out_h, out_w),
        mode="bilinear",
        align_corners=False
    )[0, 0]

    pmask = (pmask > threshold)

    x1, y1, x2, y2 = box_xyxy.tolist()
    x1 = int(round(x1))
    y1 = int(round(y1))
    x2 = int(round(x2))
    y2 = int(round(y2))

    x1 = max(0, min(x1, out_w - 1))
    y1 = max(0, min(y1, out_h - 1))
    x2 = max(x1 + 1, min(x2, out_w))
    y2 = max(y1 + 1, min(y2, out_h))

    full_mask = torch.zeros((out_h, out_w), dtype=torch.bool, device=pmask.device)
    full_mask[y1:y2, x1:x2] = pmask[y1:y2, x1:x2]
    return full_mask

  
def decode_simple_seg(outputs, num_classes=3, n_mask=32, img_size=640, conf_th=0.25):
    det_preds = outputs["det"] # Den plattade tensorn [B, N, 4 + C + nm]
    proto = outputs["proto"]

    # 1. Dekoda box-koordinater
    # Returnerar boxes_xyxy [B, N, 4] och det_flat [B, N, total_channels]
    boxes_xyxy, det_flat = decode_preds_for_seg(
        det_preds,
        img_size=img_size,
        center_mode="v8",
        wh_mode="softplus",
    )

    # 2. Skär ut klass-logits (index 4 till 4 + num_classes)
    pred_cls = det_flat[..., 4 : 4 + num_classes].sigmoid()
    
    # 3. Skär ut mask-koefficienter (index 4 + num_classes till slutet)
    # Det är här de 32 koefficienterna bor!
    coeff_flat = det_flat[..., 4 + num_classes :] 

    # 4. Beräkna score (max class probability)
    scores, cls_ids = pred_cls.max(dim=-1)

    return boxes_xyxy, coeff_flat, proto, scores, cls_ids

class ModelEMA:
    def __init__(self, model, total_updates, decay=0.999):
        self.ema = copy.deepcopy(model).eval()
        self.updates = 0
        self.decay = decay
        self.warmup_limit = max(1, min(2000, int(total_updates // 5)))
        for p in self.ema.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        self.updates += 1
        d = self.decay * (1 - math.exp(-self.updates / self.warmup_limit))
        msd = model.state_dict()
        for k, v in self.ema.state_dict().items():
            if v.dtype.is_floating_point:
                v.mul_(d).add_(msd[k].detach(), alpha=1 - d)
            else:
                v.copy_(msd[k])


def yolo_seg_collate(batch):
    images, targets = zip(*batch)
    images = torch.stack(images, dim=0)
    return images, list(targets)


def overlay_mask(img, mask, color=(0, 255, 0), alpha=0.35):
    out = img.copy()
    colored = np.zeros_like(img, dtype=np.uint8)
    colored[mask > 0] = color
    return cv2.addWeighted(out, 1.0, colored, alpha, 0)





# --- Hjälpfunktion för att få snygga, konsekventa färger per klass ---
def get_class_color(cls_id):
    """Genererar en konsekvent BGR-färg baserat på klass-ID."""
    random.seed(cls_id * 42) # Fast seed per klass
    return (
        random.randint(50, 255), 
        random.randint(50, 255), 
        random.randint(50, 255)
    )

def save_eval_debug_grid_with_gt(model, loader, device, out_dir, epoch, max_images=8):
    """
    Kör inferens på val_loader och bygger en grid-bild där varje sample
    visas sida vid sida: [ Ground Truth | Prediktion ]
    """
    model.eval()
    os.makedirs(out_dir, exist_ok=True)
    drawn_images = []

    with torch.no_grad():
        for images, targets in loader:
            images = images.to(device)
            img_size = images.shape[-1]

            outputs = model(images)
            boxes_xyxy, coeff_flat, proto, scores, cls_ids = decode_simple_seg(
                outputs,
                num_classes=model.num_classes,
                n_mask=model.n_mask,
                img_size=img_size,
                conf_th=0.25  
            )

            B = boxes_xyxy.shape[0]
            nm = proto.shape[1]
            Hp, Wp = proto.shape[-2:]

            for b in range(B):
                if len(drawn_images) >= max_images:
                    break

                img_base = tensor_to_bgr_image(images[b])
                H, W = img_base.shape[:2]

                img_gt = img_base.copy()
                img_pred = img_base.copy()

                # ==========================================
                # RITA GROUND TRUTH (Vänster)
                # ==========================================
                t = targets[b]
                gt_boxes = t["boxes"].detach().cpu().numpy()
                gt_labels = t["labels"].detach().cpu().numpy()
                gt_masks = t.get("masks", None)

                if gt_masks is not None and len(gt_masks) > 0:
                    gt_masks_np = gt_masks.cpu().numpy()
                    resized_gt_masks = []
                    for m in gt_masks_np:
                        rm = cv2.resize(m, (W, H), interpolation=cv2.INTER_NEAREST)
                        resized_gt_masks.append(rm)
                    gt_masks_np = np.stack(resized_gt_masks, axis=0)
                else:
                    gt_masks_np = []

                for j in range(len(gt_boxes)):
                    gx1, gy1, gx2, gy2 = gt_boxes[j].astype(int)
                    g_cls = int(gt_labels[j])
                    
                    gx1, gy1 = max(0, min(gx1, W - 1)), max(0, min(gy1, H - 1))
                    gx2, gy2 = max(gx1 + 1, min(gx2, W)), max(gy1 + 1, min(gy2, H))
                    
                    color = get_class_color(g_cls)

                    if len(gt_masks_np) > j:
                        g_mask = gt_masks_np[j]
                        cropped_g_mask = np.zeros((H, W), dtype=np.uint8)
                        cropped_g_mask[gy1:gy2, gx1:gx2] = g_mask[gy1:gy2, gx1:gx2]
                        img_gt = overlay_mask(img_gt, cropped_g_mask, color=color, alpha=0.45)

                    cv2.rectangle(img_gt, (gx1, gy1), (gx2, gy2), color, 2)
                    
                    # Snygg label med bakgrund (GT)
                    label_text = f"GT: {g_cls}"
                    (tw, th), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                    cv2.rectangle(img_gt, (gx1, max(0, gy1 - th - 6)), (gx1 + tw + 4, max(th + 6, gy1)), color, -1)
                    cv2.putText(img_gt, label_text, (gx1 + 2, max(th + 3, gy1 - 3)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

                # ==========================================
                # RITA PREDICTIONS (Höger)
                # ==========================================
                score_mask = scores[b] > 0.25
                p_boxes = boxes_xyxy[b][score_mask]
                p_scores = scores[b][score_mask]
                p_cls_ids = cls_ids[b][score_mask]
                p_coeffs = coeff_flat[b][score_mask]

                cur_proto = proto[b].view(nm, -1)

                if p_boxes.shape[0] > 0:
                    keep = batched_nms(p_boxes, p_scores, p_cls_ids, iou_threshold=0.5)
                    keep = keep[:10]  

                    for i in keep.tolist():
                        box = p_boxes[i].detach().cpu().numpy()
                        sc = float(p_scores[i].item())
                        cls_id = int(p_cls_ids[i].item())
                        coeff = p_coeffs[i]
                        
                        color = get_class_color(cls_id)

                        pmask = (coeff @ cur_proto).view(Hp, Wp).sigmoid()
                        pmask = F.interpolate(pmask[None, None], size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                        pmask = (pmask > 0.5).cpu().numpy().astype(np.uint8)

                        px1, py1, px2, py2 = box[:4]
                        px1, py1 = max(0, min(int(round(px1)), W - 1)), max(0, min(int(round(py1)), H - 1))
                        px2, py2 = max(px1 + 1, min(int(round(px2)), W)), max(py1 + 1, min(int(round(py2)), H))

                        cropped_mask = np.zeros((H, W), dtype=np.uint8)
                        cropped_mask[py1:py2, px1:px2] = pmask[py1:py2, px1:px2]

                        img_pred = overlay_mask(img_pred, cropped_mask, color=color, alpha=0.45)
                        cv2.rectangle(img_pred, (px1, py1), (px2, py2), color, 2)
                        
                        # Snygg label med bakgrund (Pred)
                        label_text = f"P:{cls_id} {sc:.2f}"
                        (tw, th), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                        # Rita ifylld rektangel för texten
                        cv2.rectangle(img_pred, (px1, max(0, py1 - th - 6)), (px1 + tw + 4, max(th + 6, py1)), color, -1)
                        # Rita vit text ovanpå rektangeln
                        cv2.putText(img_pred, label_text, (px1 + 2, max(th + 3, py1 - 3)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

                # ==========================================
                # KOMBINERA OCH LÄGG I LISTA
                # ==========================================
                divider = np.ones((H, 5, 3), dtype=np.uint8) * 255
                combined_img = np.hstack((img_gt, divider, img_pred))
                drawn_images.append(combined_img)

            if len(drawn_images) >= max_images:
                break

    # ==========================================
    # BYGG GRID OCH SPARA (Nu utan dubblettkoden)
    # ==========================================
    if not drawn_images:
        return

    cols = min(2, len(drawn_images)) 
    rows = math.ceil(len(drawn_images) / cols)
    
    H_comb, W_comb = drawn_images[0].shape[:2]
    grid_img = np.zeros((rows * H_comb, cols * W_comb, 3), dtype=np.uint8)
    
    for idx, img_bgr in enumerate(drawn_images):
        r, c = divmod(idx, cols)
        grid_img[r*H_comb:(r+1)*H_comb, c*W_comb:(c+1)*W_comb] = img_bgr
        
    out_path = os.path.join(out_dir, f"eval_gt_vs_pred_epoch_{epoch}.jpg")
    cv2.imwrite(out_path, grid_img)

def save_dataset_debug_grid(loader, out_dir, max_images=16):
    """
    Hämtar bilder direkt från dataloadern (efter augmentering/mosaic)
    och skapar en grid-bild med masker och boxar för att verifiera datasetet.
    """
    os.makedirs(out_dir, exist_ok=True)
    drawn_images = []
    
    for images, targets in loader:
        B, C, H, W = images.shape
        for i in range(B):
            if len(drawn_images) >= max_images:
                break
            
            # 1. Konvertera tillbaka från normaliserad Tensor till BGR Numpy-bild
            img = tensor_to_bgr_image(images[i])
            
            # 2. Hämta datan
            t = targets[i]
            boxes = t["boxes"].numpy()
            labels = t["labels"].numpy()
            masks = t.get("masks", None)
            
            # Maskerna kan vara nerskalade (mask_downsample). Vi uppskalar dem för visualisering.
            if masks is not None and len(masks) > 0:
                masks = masks.clone().unsqueeze(1).float()
                masks = F.interpolate(masks, size=(H, W), mode="nearest").squeeze(1).numpy()
            else:
                masks = []

            # 3. Rita objekt
            for j in range(len(boxes)):
                x1, y1, x2, y2 = boxes[j].astype(int)
                cls_id = int(labels[j])
                
                # Rita färgstark mask
                if len(masks) > j:
                    mask = masks[j]
                    color = [random.randint(50, 255) for _ in range(3)]
                    img = overlay_mask(img, mask, color=color, alpha=0.45)
                
                # Rita box
                cv2.rectangle(img, (x1, y1), (x2, y2), (255, 255, 255), 2)
                
                # Rita label (klass)
                cv2.putText(
                    img, str(cls_id), (x1, max(15, y1 - 5)), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2
                )
                
            drawn_images.append(img)
            
        if len(drawn_images) >= max_images:
            break
            
    if not drawn_images:
        print("Inga bilder hittades för debug-grid!")
        return
        
    # 4. Montera ihop allt till en snygg grid (t.ex. 4x4)
    cols = min(4, len(drawn_images))
    rows = math.ceil(len(drawn_images) / cols)
    
    # Skapa stor tom canvas
    grid_img = np.zeros((rows * H, cols * W, 3), dtype=np.uint8)
    
    for idx, img in enumerate(drawn_images):
        r, c = divmod(idx, cols)
        grid_img[r*H:(r+1)*H, c*W:(c+1)*W] = img
        
    out_path = os.path.join(out_dir, "sanity_check.jpg")
    cv2.imwrite(out_path, grid_img)
    print(f"✅ sanity_check created: {out_path}")


def load_pretrained_weights(model, weights_path, device):
    print(f"Loading pretrained weights: {weights_path}")
    
    # 1. Ladda checkpointen
    ckpt = torch.load(weights_path, map_location=device)
    
    # Hantera om du sparat med din 'save_checkpoint_state' struktur
    if "state_dict" in ckpt:
        pretrained_dict = ckpt["state_dict"]
    else:
        pretrained_dict = ckpt

    model_dict = model.state_dict()

    # 2. Filtrera bort det som inte matchar
    # Vi behåller bara de lager som finns i båda och har samma dimensioner
    # Detta kastar automatiskt bort 'head.out.cls' etc. eftersom num_classes ändrats
    smart_dict = {
        k: v for k, v in pretrained_dict.items()
        if k in model_dict and v.shape == model_dict[k].shape
    }

    # 3. Logga vad som hände så du har koll
    skipped_keys = [k for k in pretrained_dict.keys() if k not in smart_dict]
    print(f"✓ Matched {len(smart_dict)} layers.")
    print(f"✗ Skipped {len(skipped_keys)} layers (new head).")

    # 4. Uppdatera och ladda
    model_dict.update(smart_dict)
    model.load_state_dict(model_dict)
    
    return model
def save_checkpoint(model, path, config):
    cpu_state = {k: v.cpu() for k, v in model.state_dict().items()}
    torch.save({"state_dict": cpu_state, "config": config}, path)

def train_engine_seg (config):

    ap = build_argparser()
    

    set_seed(config["training"].get("seed", 1337))

    log_dir = config["logging"].get("log_dir", "runs/seg")
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    with open(Path(log_dir) / "merged_config.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, sort_keys=False, allow_unicode=True)

    device_idx = config["training"].get("device", 0)
    DEVICE = f"cuda:{device_idx}" if torch.cuda.is_available() else "cpu"

    NUM_CLASSES = int(config["model"]["num_classes"])
    IMG_SIZE = int(config["training"]["img_size"])
    BATCH_SIZE = int(config["training"]["batch_size"])
    EPOCHS = int(config["training"]["epochs"])
    NUM_WORKERS = int(config["training"]["num_workers"])
    MASK_DOWNSAMPLE = int(config["training"]["mask_downsample"])

    g = torch.Generator()
    g.manual_seed(config["training"].get("seed", 1337)) # Byt ut 42 mot din globala seed om du har en
    mosaic_p = config["training"].get("mosaic_p", 0.7)
    train_ds = YoloSegDataset(
    config["dataset"]["train_images"],
    config["dataset"]["train_labels"],
    transforms=get_seg_train_transform(IMG_SIZE),
    img_size=IMG_SIZE,
    is_train=True,
    mask_downsample=MASK_DOWNSAMPLE,
    mosaic_p=mosaic_p
) 

    val_ds = YoloSegDataset(
        config["dataset"]["val_images"],
        config["dataset"]["val_labels"],
        transforms=get_seg_val_transform(IMG_SIZE),
        img_size=IMG_SIZE,
        is_train=False,
        mask_downsample=MASK_DOWNSAMPLE,
    )
    
    # 2. Hämta vikterna från datasetet
    img_weights = train_ds.get_image_weights()
    topk = torch.topk(img_weights, k=min(10, len(img_weights)))
    print("Image weights stats:",
      f"min={img_weights.min().item():.3f}",
      f"mean={img_weights.mean().item():.3f}",
      f"max={img_weights.max().item():.3f}")
    print("Top weighted images:")
    for w, idx in zip(topk.values.tolist(), topk.indices.tolist()):
        print(idx, w, train_ds.img_files[idx])
    # 3. Skapa samplern
    # num_samples=len(train_ds) betyder att en epoch fortfarande är lika lång
    sampler = WeightedRandomSampler(
        weights=img_weights, 
        num_samples=len(train_ds), 
        replacement=True  # Gör att sällsynta bilder kan väljas flera gånger per epoch
    )
    train_loader = DataLoader(
    train_ds,
    batch_size=BATCH_SIZE,
    sampler=sampler,               
    shuffle=False,   
    num_workers=NUM_WORKERS,         
    pin_memory=True,
    persistent_workers=(NUM_WORKERS > 0),
    collate_fn=yolo_seg_collate,
    prefetch_factor=2 if NUM_WORKERS > 0 else None,
    worker_init_fn=seed_worker,  # <--- LÄGG TILL HÄR
    generator=g
)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0, pin_memory=False, collate_fn=yolo_seg_collate, drop_last=False)

    num = config["model"].get("num_anchors_per_level", 1)
    use_p2 = bool(config["training"].get("use_p2", False))
    use_p6 = bool(config["training"].get("use_p6", False))
    if use_p2 and use_p6:
        num_anchors_per_level = (num, num, num, num, num)
    elif use_p2 or use_p6:
        num_anchors_per_level = (num, num, num, num)
    else:
        num_anchors_per_level = (num, num, num)
    if config["model"]["arch"].lower() == 'yoloe_n':
        model = YOLOE_Nano_Seg(
            backbone=config["model"]["backbone"],
            num_classes=NUM_CLASSES,
            fpn_channels=config["model"]["fpn_channels"]
        ).to(DEVICE)
    elif config["model"]["arch"].lower() == 'yoloe':
        model = YOLOESeg(
                backbone=config["model"]["backbone"],
                num_classes=NUM_CLASSES,
                fpn_channels=config["model"]["fpn_channels"],
                num_anchors_per_level= num_anchors_per_level, # t.ex. (3,3,3)
                depth_multiple=config["model"].get("depth_multiple", 1.0),
                width_multiple=config["model"].get("width_multiple", 1.0),
                head_depth=config["model"].get("head_depth", 1),
                use_p6=config["training"]["use_p6"],
                use_p2 = config["training"]["use_p2"],
                neck_hidden_ratio = config["model"]["c2f_ratio"]
                
            ).to(DEVICE)
    weights_path = config["model"].get("weights_path", "")
    if weights_path.endswith(".pt"):
        model = load_pretrained_weights(model, weights_path, DEVICE)
        
    det_loss = LossAF(
        num_classes=NUM_CLASSES,
        img_size=IMG_SIZE,
        lambda_box=config.get("loss", {}).get("lambda_box", 5.0),
        lambda_cls=config.get("loss", {}).get("lambda_cls", 1.0),
        focal=config.get("loss", {}).get("focal", False),
        gamma=config.get("loss", {}).get("gamma", 2.0),
        alpha=config.get("loss", {}).get("alpha", 0.25),
        assign_cls_weight=config.get("loss", {}).get("assign_cls_weight", 0.5),
        center_radius_cells=config.get("loss", {}).get("center_radius_cells", 2.0),
        topk_limit=config.get("loss", {}).get("topk_limit", 20),
        area_cells_min=config.get("loss", {}).get("area_cells_min", 4),
        area_cells_max=config.get("loss", {}).get("area_cells_max", 256),
        area_tol=config.get("loss", {}).get("area_tol", 1.25),
        size_prior_w=config.get("loss", {}).get("size_prior_w", 0.2),
        ar_prior_w=config.get("loss", {}).get("ar_prior_w", 0.1),
        iou_cost_w=config.get("loss", {}).get("iou_cost_w", 3.0),
        center_cost_w=config.get("loss", {}).get("center_cost_w", 0.5),
    )
    criterion = SegLoss(det_loss=det_loss, lambda_mask=config.get("loss", {}).get("lambda_mask", 0.5))

    
    use_ema = config["training"]["ema"]
    # ---- safe float helper ----
    def f(x, default=None):
        if x is None:
            return default
        return float(x)

    # ---- läs och casta från config ----
    base_lr = f(config["training"]["lr"])                
    wd      = f(config["training"].get("weight_decay", 1e-4))

    bb_mult   = f(config["training"].get("bb_lr_mult", 1.0))
    neck_mult = f(config["training"].get("neck_lr_mult", 1.0))
    head_mult = f(config["training"].get("head_lr_mult", 1.0))
    
    lr_bb   = base_lr * bb_mult
    lr_neck = base_lr * neck_mult
    lr_head = base_lr * head_mult
    print(f"LRs: base {base_lr}, bb {lr_bb}, neck {lr_neck}, head {lr_head}")
    # ---- bygg parametergupper ----
    
    backbone_params = list(model.backbone.parameters())

    head_params = []
    
    for hn in ["head", "heads", "head3", "head4", "head5", "head2", "head6"]:
        if hasattr(model, hn):
            head_params += list(getattr(model, hn).parameters())

    collected = {id(p) for p in backbone_params + head_params}
    neck_params = [p for p in model.parameters() if id(p) not in collected]


    # ---- split decay / no_decay från befintliga param-listor ----
    name_lookup = {id(p): n for n, p in model.named_parameters()}

    def split_decay_from_params(params, name_lookup):
        decay, no_decay = [], []
        seen = set()

        for p in params:
            if not p.requires_grad or id(p) in seen:
                continue
            seen.add(id(p))

            name = name_lookup.get(id(p), "").lower()

            # bias, norm och 1D-parametrar -> ingen decay
            if p.ndim == 1 or name.endswith(".bias") or "bn" in name or "norm" in name:
                no_decay.append(p)
            else:
                decay.append(p)

        return decay, no_decay


        # --- 1. Funktion för att räkna träningsbara parametrar ---
    def count_params(param_list):
        return sum(p.numel() for p in param_list if p.requires_grad)

    # --- 2. Din befintliga uppdelning ---
    bb_decay, bb_no_decay = split_decay_from_params(backbone_params, name_lookup)
    neck_decay, neck_no_decay = split_decay_from_params(neck_params, name_lookup)
    head_decay, head_no_decay = split_decay_from_params(head_params, name_lookup)

    # --- 3. Räkna ut totalt antal parametrar i den aktuella modellen ---
    total_params = count_params(bb_decay + bb_no_decay + 
                                neck_decay + neck_no_decay + 
                                head_decay + head_no_decay)

    # --- 4. Dynamisk Weight Decay Skalning ---
    base_wd = wd
    
    base_param_count = 3_234_206  # Sätt detta till antalet parametrar i din Nano/bästa modell

    # Skala wd. Om modellen är större än base_param_count blir scale_factor < 1 (mindre decay).
    scale_factor = math.sqrt(base_param_count / max(1, total_params))
    scaled_wd = base_wd * scale_factor
    head_wd = scaled_wd * 0.5
    print(
        f"Param groups:\n"
        f"  backbone decay={len(bb_decay)} no_decay={len(bb_no_decay)}\n"
        f"  neck     decay={len(neck_decay)} no_decay={len(neck_no_decay)}\n"
        f"  head     decay={len(head_decay)} no_decay={len(head_no_decay)}\n"
        f"  ---\n"
        f"  Total params: {total_params:,}\n"
        f"  Base WD: {base_wd} -> Scaled WD: {scaled_wd:.6f} (Scale factor: {scale_factor:.3f})"
    )

    # --- 5. Använd 'scaled_wd' i din optimizer ---
    opt_name = str(config["training"].get("optimizer", "adamw")).lower()
    # ----- Multiscale training ----

    optimizer = torch.optim.AdamW(
            [
                # Backbone använder scaled_wd
                {"params": bb_decay,      "lr": lr_bb,   "weight_decay": scaled_wd,  "name": "backbone", "base_lr": lr_bb},
                {"params": bb_no_decay,   "lr": lr_bb,   "weight_decay": 0.0,        "name": "backbone", "base_lr": lr_bb},

                # Neck använder scaled_wd
                {"params": neck_decay,    "lr": lr_neck, "weight_decay": scaled_wd,  "name": "neck",     "base_lr": lr_neck},
                {"params": neck_no_decay, "lr": lr_neck, "weight_decay": 0.0,        "name": "neck",     "base_lr": lr_neck},

                # Head använder head_wd (vilket är hälften av scaled_wd)
                {"params": head_decay,    "lr": lr_head, "weight_decay": head_wd,    "name": "head",     "base_lr": lr_head},
                {"params": head_no_decay, "lr": lr_head, "weight_decay": 0.0,        "name": "head",     "base_lr": lr_head},
            ],
            betas=(0.9, 0.999),
        )

    scaler = torch.amp.GradScaler(enabled=(DEVICE.startswith("cuda") and bool(config["training"].get("amp", True))))
    accumulate = int(config["training"]["accumulate"])
    epochs = int(config["training"]["epochs"])
    ema_decay = float(config["training"]["ema_decay"])
    total_updates = (len(train_loader) * epochs)/accumulate
    if use_ema:
        ema = ModelEMA(model, total_updates=total_updates, decay=ema_decay) 


    # ----- Multiscale training ----
    multi_scale_sizes = config["training"].get("multi_scale_sizes", None)


    # ---- scheduler ----
    steps_per_epoch = max(1, len(train_loader))
    scheduler, sched_type = build_scheduler(optimizer, config, steps_per_epoch)
    start_epoch = 0
    if config["training"]["resume"] is not None:
        checkpoint = torch.load(config["training"]["resume"], map_location=DEVICE)

        # 1. Ladda modellvikter
        model.load_state_dict(checkpoint["model_state_dict"])

        # 2. Ladda Optimerarens minne
        #optimizer.load_state_dict(checkpoint["optimizer_state_dict"])


        # 5. Hämta epoch så din loop vet var den ska starta!
        #start_epoch = checkpoint["epoch"] + 1
        ema = ModelEMA(model, total_updates=total_updates, decay=0.995) 

    use_amp = bool(config["training"].get("amp", True)) and (DEVICE == "cuda")
    
    warmup_epochs = int(config["training"].get("warmup_epochs", 0))
    if warmup_epochs > 0:
      for pg in optimizer.param_groups:
        pg["lr"] = pg["initial_lr"] * 0.05  # Starta på 10% av den tänkta hastigheten

    grad_clip = float(config["training"].get("grad_clip", 0.0))
    close_mosaic = config["training"].get("close_mosaic", 10)
    weights_dir = os.path.join(log_dir, "weights")
    debug_dir = os.path.join(log_dir, "eval_debug")
    os.makedirs(weights_dir, exist_ok=True)
    os.makedirs(debug_dir, exist_ok=True)
    freeze_epochs = int(config["training"].get("freeze_backbone_epochs", 5))
    best_box = float(0.0)
    best_seg = float(0.0)
    class_names = config["dataset"]["names"]
        # Definiera var filen ska sparas
    csv_log_path = os.path.join(log_dir, "training_metrics.csv")
    
    
    # Skriv headern om filen inte redan finns
    if not os.path.exists(csv_log_path):
        with open(csv_log_path, mode='w', newline='') as f:
            writer = csv.writer(f)
            # Här definierar vi alla kolumner vi vill spara
            header = ['epoch', 'bbox_map', 'bbox_map50', 'bbox_map75', 
                    'segm_map', 'segm_map50', 'segm_map75', "lr_bb","lr_neck","lr_head", "train_loss"]
            writer.writerow(header)
    save_dataset_debug_grid(train_loader, debug_dir, max_images=16)
    gc.collect()
    for epoch in range(start_epoch, (EPOCHS+start_epoch)):
        model.train()
        pbar = tqdm(enumerate(train_loader), total=len(train_loader), leave=True, desc=f"Epoch {epoch+1}/{EPOCHS}")
        running = 0.0
        #curriculum_ctrl.step(epoch)
        # 1. --- FRYSNINGS-LOGIK (Gör detta absolut först i epoken) ---
        if epoch < freeze_epochs:
            model.backbone.eval()
            for p in model.backbone.parameters():
                p.requires_grad = False
        else:
            model.backbone.train()
            for p in model.backbone.parameters():
                p.requires_grad = True   
        if sched_type == "onecycle":
            pass
        if (epoch+1) == EPOCHS-close_mosaic:
            del train_loader
            train_ds = YoloSegDataset(
              config["dataset"]["train_images"],
              config["dataset"]["train_labels"],
              transforms=get_seg_val_transform(IMG_SIZE),
              img_size=IMG_SIZE,
              is_train=False,
              mask_downsample=MASK_DOWNSAMPLE,
              mosaic_p=0.0
                  ) 
            train_loader = DataLoader(
                train_ds,
                batch_size=BATCH_SIZE,
                sampler=sampler,               
                shuffle=False,   
                num_workers=NUM_WORKERS,         
                pin_memory=True,
                persistent_workers=(NUM_WORKERS > 0),
                collate_fn=yolo_seg_collate,
                prefetch_factor=2 if NUM_WORKERS > 0 else None,
                worker_init_fn=seed_worker,  # <--- LÄGG TILL HÄR
                generator=g
                  )
        if (epoch+1) == 0.30 *EPOCHS:
            del train_loader
            train_ds = YoloSegDataset(
              config["dataset"]["train_images"],
              config["dataset"]["train_labels"],
              transforms=get_seg_train_transform(IMG_SIZE),
              img_size=IMG_SIZE,
              is_train=True,
              mask_downsample=MASK_DOWNSAMPLE,
              mosaic_p=0.3
                  ) 
            train_loader = DataLoader(
                train_ds,
                batch_size=BATCH_SIZE,
                sampler=sampler,               
                shuffle=False,   
                num_workers=NUM_WORKERS,         
                pin_memory=True,
                persistent_workers=(NUM_WORKERS > 0),
                collate_fn=yolo_seg_collate,
    
                prefetch_factor=2 if NUM_WORKERS > 0 else None,
                worker_init_fn=seed_worker,  # <--- LÄGG TILL HÄR
                generator=g
                  )
                
        # 3. --- LEARNING RATE OCH WARMUP LOGIK ---
        if epoch < warmup_epochs:
            # FIX 3: Manuell Warmup som går från 1% till 100% av base_lr
            warmup_factor = 0.1 + (0.99 * (epoch / warmup_epochs))
            for pg in optimizer.param_groups:
                pg["lr"] = pg["base_lr"] * warmup_factor
        else:
            # Efter warmup, låt din valda scheduler ta över
            if sched_type == "onecycle":
                pass # OneCycle hanteras per batch, inte per epok
            elif scheduler is not None and sched_type not in ("reduceonplat", "onecycle"):
                scheduler.step()
                
                # FIX 4: Om du vill ha en mjuk upprampning av backbone när den tinas upp
        if epoch >= freeze_epochs and epoch < (freeze_epochs + 5):
            step = (epoch - freeze_epochs + 1) / 5
            target_bb_lr = lr_bb # Antar att backbone groups har sin base_lr satt till lr_bb
                    
            for pg in optimizer.param_groups:
                if pg.get("name") == "backbone":
                            # Rampar från 10% till 100% av backbonens base_lr över 5 epoker
                    pg["lr"] = target_bb_lr * (0.1 + 0.9 * step)
        
        
        # -------------------- TRAIN --------------------
        for i, (images, targets) in pbar:
            images = images.to(DEVICE, non_blocking=True)
            targets = [{k: (v.to(DEVICE) if torch.is_tensor(v) else v) for k, v in t.items()} for t in targets]
            
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(device_type=DEVICE, enabled=scaler.is_enabled()):
                outputs = model(images)
                loss, loss_dict = criterion(outputs, targets)

            scaler.scale(loss).backward()
             # Uppdatera vikterna BARA när vi nått accumulate-gränsen (eller sista batchen)
            if (i + 1) % accumulate == 0 or (i + 1) == len(train_loader):
                
                # Unscale och Clip (om du använder det)
                if grad_clip > 0:
                    scaler.unscale_(optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
                
                # Ta steget
                scaler.step(optimizer)
                scaler.update()
                
                # Rensa gradienterna HÄR, efter steget!
                optimizer.zero_grad(set_to_none=True)
                
                if use_ema:
                    ema.update(model)
            running += float(loss.item())
            pbar.set_postfix(loss=f"{running / (i + 1):.4f}")

        avg_loss = running / max(1, len(train_loader))
        print(f"Epoch {epoch+1}: train_loss={avg_loss:.5f}")

        eval_model = ema.ema if ema is not None else model
        

        val_metrics = evaluate_segmentation_model(
            model=eval_model,
            loader=val_loader,
            device=DEVICE,
            score_thr=0.25,
            nms_iou=0.7,
            mask_thr=0.5,
            max_det=100,
        )  
        # LOGGNING TILL CSV
        # Hämta ut alla LRs i en lista (detta ger en lista med 6 värden)
        lrs = [pg.get("lr", 0.0) for pg in optimizer.param_groups]
        lr_bb   = lrs[0] if len(lrs) > 0 else 0.0
        lr_neck = lrs[2] if len(lrs) > 2 else 0.0
        lr_head = lrs[4] if len(lrs) > 4 else 0.0
        with open(csv_log_path, mode='a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                epoch + 1,
                val_metrics['bbox_map'],
                val_metrics['bbox_map50'],
                val_metrics['bbox_map75'],
                val_metrics['segm_map'],
                val_metrics['segm_map50'],
                val_metrics['segm_map75'],
                lr_bb, 
                lr_neck, 
                lr_head,
                avg_loss
            ])

        print(
            f"Metrics {epoch+1}:"
            f"bbox mAP={val_metrics['bbox_map']:.4f} "
            f"bbox mAP50={val_metrics['bbox_map50']:.4f} "
            f"segm mAP={val_metrics['segm_map']:.4f} "
            f"segm mAP50={val_metrics['segm_map50']:.4f}"
        )
        # Spara GT vs Pred-bilder t.ex. var 25:e epok ELLER på allra sista epoken.
        if (epoch + 1) % 25 == 0 or (epoch + 1) == EPOCHS:
            save_eval_debug_grid_with_gt(
                eval_model, 
                val_loader, 
                DEVICE, 
                debug_dir, 
                epoch=epoch+1, 
                max_images=6 # 6 stycken blir en perfekt 3x2 grid (där varje ruta innehåller [GT | Pred])
            )
        model_eval_cpu = eval_model.to("cpu").eval()
        save_checkpoint_state_last(model=model,optimizer=optimizer, epoch=epoch, metrics=val_metrics, class_names=class_names, config=config, out_path=os.path.join(weights_dir, "last_model_state.pt"), num_anchors_per_level=num_anchors_per_level, scaler=scaler, ema_model=model_eval_cpu )
        eval_model.to(DEVICE).eval()  
        best_ckpt_path = os.path.join(weights_dir, "best_box_model.pt")
        best_ckpt_path_seg = os.path.join(weights_dir, "best_seg_model.pt")
        if (val_metrics['bbox_map']+val_metrics['bbox_map50']) > best_box:
            best_box = (val_metrics['bbox_map']+val_metrics['bbox_map50'])
            #save_checkpoint_state_last(model=model,optimizer=optimizer, epoch=epoch, metrics=val_metrics, class_names=class_names, config=config, out_path=best_ckpt_path, num_anchors_per_level=num_anchors_per_level, scaler=scaler, ema_model=model_eval_cpu )
            save_checkpoint_state(model_eval_cpu, val_metrics, class_names, config, best_ckpt_path, num_anchors_per_level)
  
        if (val_metrics['segm_map']+val_metrics['segm_map50']) > best_seg:
            best_seg = (val_metrics['segm_map']+val_metrics['segm_map50']) 
            #save_checkpoint_state_last(model=model,optimizer=optimizer, epoch=epoch, metrics=val_metrics, class_names=class_names, config=config, out_path=best_ckpt_path_seg, num_anchors_per_level=num_anchors_per_level, scaler=scaler, ema_model=model_eval_cpu )
            save_checkpoint_state(model_eval_cpu, val_metrics, class_names, config, best_ckpt_path_seg , num_anchors_per_level)
          
if __name__ == "__main__":
    from ..scripts.args.build_args import build_argparser, load_configs, apply_overrides
    ap = build_argparser()
    opt = ap.parse_args()
    config = load_configs(model_yaml=opt.model, train_yaml=opt.train, data_yaml=opt.data)
    config = apply_overrides(config, vars(opt)) # vars(opt) gör om till dict!
    train_engine_seg(config)