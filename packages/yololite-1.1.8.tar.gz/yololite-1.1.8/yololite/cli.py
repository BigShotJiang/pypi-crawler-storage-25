# yololite/cli.py
import sys
from .main import YoloLite

def parse_arbitrary_cli(args_list):
    """Gör om 'nyckel=värde' från terminalen till en dictionary"""
    kwargs = {}
    for arg in args_list:
        if '=' in arg:
            k, v = arg.split('=', 1)
            k = k.lstrip('-') 
            
            # Konvertera strängar till rätt typ (int, float, bool)
            if v.lower() == 'true': v = True
            elif v.lower() == 'false': v = False
            else:
                try: v = int(v)
                except ValueError:
                    try: v = float(v)
                    except ValueError: pass
                    
            kwargs[k] = v
    return kwargs

def entrypoint():
    """Detta är funktionen som körs när någon skriver 'yololite' i terminalen"""
    cli_args = sys.argv[1:]
    
    if len(cli_args) == 0:
        print("Usage: yololite mode=train|predict|export|val model=... [kwargs]")
        sys.exit(1)
        
    kwargs = parse_arbitrary_cli(cli_args)
    
    # 1. Hämta grundinställningar
    mode = kwargs.pop("mode", "train")
    model_path = kwargs.pop("model", "configs/models/yololite_m.yaml")
    
    # Initiera huvudklassen
    model = YoloLite(model_path)
    
    # 2. Skicka vidare till rätt metod
    if mode == "train":
        data_path = kwargs.pop("data", None)
        if not data_path:
            print("❌ Error: You must specify 'data=path/to/data.yaml'")
            sys.exit(1)
        model.train(data=data_path, is_cli=True, **kwargs)
        
    elif mode == "predict":
        source = kwargs.pop("source", None)
        if not source:
            print("❌ Error: You must specify 'source=image.jpg'")
            sys.exit(1)
        model.predict(source=source, is_cli=True, **kwargs)
        
    elif mode == "export":
        format_type = kwargs.pop("format", "decoded_nms")
        model.export(format=format_type, is_cli=True, **kwargs)
        
    elif mode == "val":
        data_path = kwargs.pop("data", None)
        split = kwargs.pop("split", "val")
        if not data_path:
            print("❌ Error: You must specify 'data=path/to/data.yaml'")
            sys.exit(1)
        model.val(data=data_path, split=split, is_cli=True, **kwargs)
        
    else:
        print(f"❌ Error: Unknown mode '{mode}'.")
        sys.exit(1)

if __name__ == "__main__":
    entrypoint()