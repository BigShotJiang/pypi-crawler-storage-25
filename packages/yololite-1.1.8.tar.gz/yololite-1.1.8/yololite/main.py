# yololite/main.py
from typing import Optional
import os
from pathlib import Path
from .scripts.det.scripts.args.build_args import load_configs, apply_overrides
from .scripts.det.tools.train import train_engine
from .scripts.seg.tools.train import train_engine_seg
from .utils import download_weights
from .scripts.predictor import YoloPredictor

from pathlib import Path
import cv2
import numpy as np
# --- KONFIGURATION FÖR NEDLADDNING ---
# Byt ut mot ditt användarnamn och namnet på din release-tagg (t.ex. v1.0.0)
GITHUB_BASE_URL = r"https://github.com/Lillthorin/YoloLite-Official-Repo/releases/download/v2"

# Alla officiella modeller (Detektion + Segmentering)
OFFICIAL_MODELS = {
    "yololite_cs3_n.pt", "yololite_cs3_s.pt", "yololite_cs3_m.pt",
    "yololite_mnv4_n.pt", "yololite_mnv4_s.pt", "yololite_mnv4_m.pt",
    "yololite_hg2_n.pt", "yololite_hg2_s.pt", "yololite_hg2_m.pt",
}

# 1. Hitta mappen där denna fil bor (t.ex. .../site-packages/yololite/)
# Om denna kod ligger i yololite/main.py, är ROOT_DIR = .../yololite/
ROOT_DIR = Path(__file__).resolve().parent

# Skapa de skottsäkra standard-sökvägarna dynamiskt
DEFAULT_DET_CFG = str(ROOT_DIR / "scripts" / "det" / "configs" / "train" / "standard_train.yaml")
DEFAULT_SEG_CFG = str(ROOT_DIR / "scripts" / "seg" / "configs" / "train" / "standard_train.yaml")


class YoloLite:
    def __init__(self, model="yololite_cs3_m.pt", task="det", device: str = "cpu"):
        self.model_path = model
        
        # --- AUTO-DOWNLOAD LOGIK ---
        model_name = os.path.basename(self.model_path)
        
        if not os.path.exists(self.model_path):
            if model_name in OFFICIAL_MODELS:
                url = f"{GITHUB_BASE_URL}/{model_name}"
                # Laddar ner och uppdaterar sökvägen
                self.model_path = download_weights(url=url, save_path=self.model_path)
            elif self.model_path.endswith((".pt", ".onnx", ".engine")):
                print(f"⚠️ Did not find '{self.model_path}' locally, and its not a known offical model for downloading.")
        if task:
            self.task = task
        else:
            self.task = "seg" if "seg" in str(self.model_path).lower() else "det"
        self.device = device
        
        # Håll __init__ blixtsnabb! Vi sparar bara denna som None så länge
        self.predictor = None


    def train(self, data: str, train_cfg: Optional[str] = None, task: Optional[str] = None, **kwargs):
        """
        Starts the training of the model. 

        You can pass optional hyperparameters via **kwargs to dynamically override
        the default settings defined in the train_cfg.

        Args:
            data (str): Path to the dataset YAML file (e.g., 'data.yaml').
            train_cfg (str): Path to the standard training configuration YAML.
            
        Keyword Args (**kwargs):
            -- General Settings --
            epochs (int): Number of training epochs.
            batch_size (int): Number of images per batch.
            img_size (int): Target image resolution (e.g., 640).
            device (str): Device to use for training, e.g., '0', '0,1', or 'cpu'.
            workers (int): Number of dataloader processes (num_workers).
            resume (str): Path to a checkpoint (.pt) to resume an interrupted training session.
            
            -- Optimization & Hyperparameters --
            lr (float): Initial learning rate.
            bb_lr_mult (float): Learning rate multiplier for the backbone.
            head_lr_mult (float): Learning rate multiplier for the head.
            accumulate (int): Number of batches to accumulate before updating gradients.
            warmup_epochs (int): Number of epochs for learning rate warmup.
            freeze_backbone (int): Number of initial epochs to keep the backbone weights frozen.
            
            -- Augmentation --
            augment (bool): Enable or disable standard augmentations.
            mosaic_p (float): Probability (0.0 - 1.0) of applying Mosaic augmentation.
            close_mosaic: Closes the mosaic X epochs before final epoch.
            -- Saving & Logging --
            save_every (int): Save a backup checkpoint every n epochs.
            save_by (str): The metric used to define 'best.pt' (e.g., 'AP', 'AP50', 'AP75').

        Example:
            >>> model = YoloLite("weights/init.pt")
            >>> model.train(data="coco.yaml", epochs=100, batch_size=16, lr=0.01, mosaic_p=0.5)
        """
        
        
        # Spara sökvägen så träningsmotorn hittar vikterna/konfigurationen
        
        self.task = task
        
        if task:
            self.task = task
        else:
            self.task = "seg" if "seg" in str(self.model_path).lower() else "det"
        # -- ROUTING LOGIKEN --
        print(f"🚀 Starting {self.task.upper()} training for {self.model_path}...")
                # Gissa task om användaren inte skrev det
 
        if train_cfg is None:
            train_cfg = DEFAULT_DET_CFG

        if self.task == "det":
            config = load_configs(
                model_yaml=self.model_path, 
                train_yaml=train_cfg, 
                data_yaml=data
            )
            config = apply_overrides(config, kwargs)
            config["model"]["weights_path"] = self.model_path
            train_engine(config)
            
        elif self.task == "seg":
            # Använd den dynamiska sökvägen för segmentering
            config = load_configs(
                model_yaml=self.model_path, 
                train_yaml=DEFAULT_SEG_CFG, 
                data_yaml=data
            )
            config = apply_overrides(config, kwargs)
            config["model"]["weights_path"] = self.model_path
            train_engine_seg(config)
        else:
            raise ValueError(f"Unknown task: {self.task}. Supported tasks are 'det' and 'seg'.")
            
    def export(self, format: str = "decoded_nms", **kwargs):
        """
        Exports the model to an ONNX format for deployment.

        Args:
            format (str): The specific ONNX graph format to export. 
                          Supported: 'raw', 'decoded', 'decoded_nms'. Default is 'decoded_nms'.
            
        Keyword Args (**kwargs):
            img_size (int): Target image resolution to bake into the model (default: 640).
            half (bool): Export in FP16 (half precision) for faster inference (requires CUDA).
            simplify (bool): Run onnxsim to simplify the ONNX graph (highly recommended).
            dynamic_batch (bool): Allow dynamic batch sizes (mostly for 'raw' format).
            dynamic_shape (bool): Allow dynamic image heights and widths (for 'raw' format only).
            device (str): Device to use during export ('cpu' or '0').
            center_mode (str): Bounding box center decoding mode ('v8' or 'sigmoid').
            wh_mode (str): Bounding box width/height decoding mode ('softplus', 'v8', 'exp').
            batch_size (int): Fixed batch size if not using dynamic_batch.
            max_detections (int): Max bounding boxes kept by NMS (default: 300).
            iou_threshold (float): NMS IoU threshold (default: 0.7).
            score_threshold (float): NMS confidence score threshold (default: 0.3).
            verbose (bool): Print detailed logs during the export process.

        Returns:
            str: The absolute path to the exported ONNX file.
            
        Example:
            >>> model = YoloLite("weights/best.pt")
            >>> model.export(format="decoded_nms", half=True, simplify=True, img_size=640)
        """
        print(f"📦 Exporting {self.model_path} (Task: {self.task.upper()}) to {format.upper()} format...")
        
        kwargs["weights"] = self.model_path
        
        # If the user asks for TensorRT, we MUST build 'decoded_nms' ONNX first
        is_tensorrt = format in ["engine", "tensorrt"]
        kwargs["format"] = "decoded" if is_tensorrt else format
        
        
        kwargs.pop("is_cli", None)
        if self.model_path.endswith("pt"):
            # 1. ALWAYS generate the ONNX file first
            if self.task == "det":
                from .scripts.det.export.export_onnx import run_export as export_onnx
                onnx_path = export_onnx(**kwargs)
            elif self.task == "seg":
                from .scripts.seg.export.export_onnx_seg import run_export as export_onnx
                onnx_path = export_onnx(**kwargs)
            else:
                raise ValueError(f"Unknown task: {self.task}")

            # 2. Chain into TensorRT if requested
            if is_tensorrt:
                print(f"🚀 Chaining ONNX into TensorRT builder...")
                from .scripts.export_tensorrt import build_engine
                
                img_size = kwargs.get("img_size", 640)
                half = kwargs.get("half", True) # Default to FP16 for TensorRT
                
                final_engine_path = build_engine(
                    onnx_path=onnx_path, 
                    img_size=img_size, 
                    fp16=half
                )
                return final_engine_path
        elif self.model_path.endswith("onnx"):
            if self.task == "det":
                from .scripts.det.export.export_onnx import run_export as export_onnx
                onnx_path = export_onnx(**kwargs)
            elif self.task == "seg":
                from .scripts.seg.export.export_onnx_seg import run_export as export_onnx
                onnx_path = export_onnx(**kwargs)
            else:
                raise ValueError(f"Unknown task: {self.task}")
        return onnx_path
    def predict(self, source: str, **kwargs):
        """
        Runs high-speed inference (prediction) on an image, video frame, or directory.
        
        The model uses lazy loading; the network is loaded into memory only on the 
        first call to this method. Subsequent calls bypass disk I/O for maximum performance.

        Args:
            source (str | Path | np.ndarray): Path to an image, directory, webcam index, 
                or a direct numpy array (e.g., a frame from cv2.VideoCapture).
            
        Keyword Args (**kwargs):
            conf (float): Confidence threshold (default: 0.25).
            iou (float): NMS IoU threshold (default: 0.45).
            img_size (int): Target image resolution for inference (default: 640).
            device (str): Device to run inference on ('cpu', '0', etc.).
            save (bool): Whether to save annotated images to the runs/predict/ directory (default: False).
            show (bool): Whether to display the image live on screen using cv2.imshow (default: False).
            draw (bool): Whether to render bounding boxes/masks on the image. Set to False 
                to maximize FPS if you only need the raw coordinates (default: True).

        Returns:
            list[dict]: A list of result dictionaries, one for each processed image/frame.
                Each dictionary contains:
                - 'boxes' (np.ndarray): Bounding boxes in xyxy format.
                - 'scores' (np.ndarray): Confidence scores.
                - 'classes' (np.ndarray): Class IDs.
                - 'masks' (np.ndarray | None): Segmentation masks, if task='seg'.
                - 'annotated_img' (np.ndarray | None): The drawn image (if draw=True).
                - 'path' (str): Path to the source file (or 'frame' for array inputs).
                - 'speed' (dict): Profiling data (preprocess, inference, drawing, and total time in ms).
            
        Example:
            >>> model = YoloLite("yololite_cs3_m.pt", task="det")
            >>> results = model.predict(source="test_images/", conf=0.5, save=True, show=False)
            >>> print(results[0]["boxes"])
        """

        
        
        
        kwargs["weights_path"] = self.model_path
        kwargs["task"] = self.task
        kwargs["device"] = kwargs.get("device", self.device)
        kwargs.pop("is_cli", None)

        # LAZY LOADING: Ladda bara första gången!
        if self.predictor is None:
            print(f"🧠 Loading network into memory for {self.task.upper()} (First time execution)...")

            
            self.predictor = YoloPredictor(
                weights_path=self.model_path,
                task=self.task,
                device=kwargs["device"],
                img_size=kwargs.get("img_size", 640),
                conf_thr=kwargs.get("conf", 0.25),
                iou_thr=kwargs.get("iou", 0.45)
            )
        else:
            self.predictor.conf_thr = kwargs.get("conf", self.predictor.conf_thr)
            self.predictor.iou_thr = kwargs.get("iou", self.predictor.iou_thr)
            self.predictor.img_size = kwargs.get("img_size", self.predictor.img_size)

        save = kwargs.get("save", False)
        show = kwargs.get("show", False)
        should_draw = kwargs.get("draw", True)

        import numpy as np
        
        if isinstance(source, np.ndarray):
            # Skickar in framen direkt! Skickar med visualize-flaggan!
            results, drawn_img = self.predictor.predict(source, visualize=should_draw)
            results["annotated_img"] = drawn_img
            results["path"] = "frame"
            
            # Printa hastigheten!
            speed = results["speed"]
            print(f"⏱️ Speed: Pre {speed['preprocess_ms']}ms | Inf {speed['inference_ms']}ms | Draw {speed['drawing_ms']}ms | Total {speed['total_ms']}ms")
            
            return [results]

        # ---------------------------------------------------------------------
        # HANTERA FILER & MAPPAR
        # ---------------------------------------------------------------------
        
        
        source_path = Path(source)
        files = list(source_path.glob("*.*")) if source_path.is_dir() else [source_path]
        
        save_dir = Path("runs/predict")
        if save: 
            save_dir.mkdir(parents=True, exist_ok=True)
            
        all_results = []

        for f in files:
            if f.suffix.lower() not in ['.jpg', '.jpeg', '.png', '.bmp']: 
                continue
                
            # Skicka med visualize-flaggan här också!
            results, drawn_img = self.predictor.predict(f, visualize=should_draw)
            results["path"] = str(f)
            results["annotated_img"] = drawn_img 
            all_results.append(results)
            
            # Printa hastigheten per bild
            speed = results["speed"]
            print(f"⏱️ {f.name} -> Speed: Pre {speed['preprocess_ms']}ms | Inf {speed['inference_ms']}ms | Draw {speed['drawing_ms']}ms | Total {speed['total_ms']}ms")
            
            # Kör bara OpenCV-funktioner om vi faktiskt har en bild att rita
            if drawn_img is not None:
                if show:
                    try:
                        cv2.imshow("Inference", drawn_img)
                        cv2.waitKey(1)
                    except cv2.error:
                        print("⚠️ cv2.imshow misslyckades (Headless miljö?)")
                        
                if save:
                    cv2.imwrite(str(save_dir / f.name), drawn_img)

        # Vi behöver inte stänga fönster om inga har öppnats
        if show and should_draw: 
            try:
                cv2.destroyAllWindows()
            except cv2.error:
                pass
            
        return all_results
    def val(self, data: str, split: str = "val", **kwargs):
        """
        Evaluates the model on a validation or test dataset.

        Args:
            data (str): Path to the dataset YAML file (e.g., 'data.yaml').
            split (str): Which split to evaluate on. Default is 'val'. Can be 'test'.
            
        Keyword Args (**kwargs):
            conf (float): Confidence threshold. Default is 0.001 (standard for mAP calculation).
            iou (float): NMS IoU threshold (default: 0.6).
            img_size (int): Target image resolution for inference (default: 640).
            device (str): Device to run evaluation on ('cpu', 'cuda:0', etc.).

        Returns:
            dict: The computed COCO metrics.
            
        Example:
            >>> model = YoloLite("weights/best.pt")
            >>> metrics = model.val(data="coco.yaml", split="test")
        """
        print(f"🧪 Validating {self.model_path}...")
        
        kwargs["weights_path"] = self.model_path
        kwargs["task"] = self.task
        kwargs.pop("is_cli", None)

        from .scripts.evaluate import run_eval
        return run_eval(data=data, split=split, **kwargs)