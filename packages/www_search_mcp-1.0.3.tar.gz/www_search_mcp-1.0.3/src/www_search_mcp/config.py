"""Environment-driven configuration and shared constants."""

from __future__ import annotations

import logging
import os
import ssl
from pathlib import Path

import truststore

logger = logging.getLogger("www-search-mcp")

# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------

def _env_int(name: str, default: int, lo: int | None = None, hi: int | None = None) -> int:
    try:
        val = int(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %d", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


def _env_float(name: str, default: float, lo: float | None = None, hi: float | None = None) -> float:
    try:
        val = float(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %.1f", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


_TRUE_SET = {"1", "true", "yes", "on", "y", "t"}
_FALSE_SET = {"0", "false", "no", "off", "n", "f"}


def _parse_bool(raw: str) -> bool | None:
    """Parse a string into a bool. Returns None if not recognized."""
    v = raw.strip().lower()
    if v in _TRUE_SET:
        return True
    if v in _FALSE_SET:
        return False
    return None


def _env_bool(name: str, default: bool = True) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    parsed = _parse_bool(raw)
    if parsed is None:
        logger.warning("Environment variable %s=%r not a valid bool, using default %s", name, raw, default)
        return default
    return parsed


# ---------------------------------------------------------------------------
# Resolved settings (read once at import time)
# ---------------------------------------------------------------------------

TIMEOUT: int = _env_int("WEB_TIMEOUT", 30, lo=1)
MAX_RESULTS: int = _env_int("WEB_MAX_RESULTS", 5, lo=1, hi=10)
MAX_FETCH_CHARS: int = _env_int("WEB_MAX_FETCH_CHARS", 200_000, lo=1_000, hi=1_000_000)
RETRIES: int = _env_int("WEB_RETRIES", 2, lo=0, hi=5)
MIN_INTERVAL: float = _env_float("WEB_MIN_INTERVAL", 1.0, lo=0.0)
MAX_DOWNLOAD_MB: int = _env_int("WEB_MAX_DOWNLOAD_MB", 50, lo=1)
MAX_DOWNLOAD_BYTES: int = MAX_DOWNLOAD_MB * 1024 * 1024
SESSION_ENABLED: bool = _env_bool("WEB_SESSION_ENABLED", default=False)
PROXY: str | None = os.getenv("WEB_PROXY", "").strip() or None

SSL_VERIFY: bool = _env_bool("WEB_SSL_VERIFY", default=True)
# Optional path to extra trusted CA certificates (PEM file or directory with
# OpenSSL-hashed certs). Loaded *in addition to* the system trust store, not
# as a replacement. Ignored when SSL_VERIFY is False.
SSL_PATH: str | None = os.getenv("WEB_SSL_PATH", "").strip() or None
if not SSL_VERIFY:
    logger.warning("WEB_SSL_VERIFY=false: TLS certificate verification is DISABLED (insecure)")
elif SSL_PATH:
    logger.info("WEB_SSL_PATH: adding extra CA trust from %r", SSL_PATH)

CHROME_UA: str = os.getenv(
    "WEB_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
)


# ---------------------------------------------------------------------------
# SSL context builder (lazy, cached)
# ---------------------------------------------------------------------------

_SSL_CONTEXT: ssl.SSLContext | None = None


def get_ssl_context() -> ssl.SSLContext:
    """Return the shared SSL context used by all HTTP clients.

    Policy:
      * ``SSL_VERIFY=False`` -> permissive context (CERT_NONE, no hostname check).
      * ``SSL_VERIFY=True`` (default) -> ``truststore.SSLContext`` backed by the
        operating system trust store (macOS Keychain, Windows Cert Store,
        OpenSSL paths on Linux).
      * If ``SSL_PATH`` is set, it is loaded *in addition to* the system
        trust store as an extra CA source (PEM file or OpenSSL-hashed dir).
    """
    global _SSL_CONTEXT
    if _SSL_CONTEXT is not None:
        return _SSL_CONTEXT

    if SSL_VERIFY is False:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        _SSL_CONTEXT = ctx
        return ctx

    ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

    if SSL_PATH:
        p = Path(SSL_PATH).expanduser()
        if not p.exists():
            raise RuntimeError(
                f"WEB_SSL_PATH points to a non-existent path: {p}"
            )
        try:
            if p.is_dir():
                ctx.load_verify_locations(capath=os.fspath(p))
            else:
                ctx.load_verify_locations(cafile=os.fspath(p))
        except ssl.SSLError as exc:
            raise RuntimeError(
                f"Failed to load CA bundle from {p}: {exc}"
            ) from exc

    _SSL_CONTEXT = ctx
    return ctx
