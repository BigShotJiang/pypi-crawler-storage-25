"""Post-install setup for www-search-mcp: installs Playwright browsers."""

import subprocess
import sys


def post_install() -> None:
    subprocess.check_call(
        [sys.executable, "-m", "playwright", "install", "chromium"]
    )


if __name__ == "__main__":
    post_install()
