"""Generic DuckDuckGo search with retry, and GitHub/PyPI API search."""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Callable

import httpx
from ddgs import DDGS
from ddgs.exceptions import DDGSException, RatelimitException, TimeoutException

from .config import CHROME_UA, MAX_RESULTS, PROXY, RETRIES, TIMEOUT, get_ssl_context
from .throttle import request_throttle

logger = logging.getLogger("www-search-mcp")

# Maximum number of results allowed per request
_RESULTS_CAP = 10


def clamp_results(max_results: int) -> int:
    return max(1, min(max_results, _RESULTS_CAP))


# ---------------------------------------------------------------------------
# DuckDuckGo search with retries
# ---------------------------------------------------------------------------

def ddg_search(
    query: str,
    search_method: Callable[..., list],
    *,
    max_results: int = MAX_RESULTS,
) -> list[dict[str, Any]]:
    """Execute a DDG search call with throttling + retries.

    *search_method* is a callable like ``ddgs.text`` that returns a list.
    """
    max_results = clamp_results(max_results)

    for attempt in range(RETRIES + 1):
        try:
            request_throttle.wait()
            return search_method()
        except (TimeoutException, RatelimitException, DDGSException) as exc:
            if "No results found" in str(exc):
                return []
            if attempt >= RETRIES:
                raise _wrap_search_error(exc) from exc
            _log_retry(attempt, exc)
        except Exception as exc:
            if attempt >= RETRIES:
                raise RuntimeError(f"Search failed: {exc}") from exc
            _log_retry(attempt, exc)

    raise RuntimeError("Search failed: exhausted retries")


def ddg_context() -> DDGS:
    """Return a configured DDGS context manager."""
    return DDGS(timeout=TIMEOUT, proxy=PROXY)


# ---------------------------------------------------------------------------
# GitHub API search (with connection pooling)
# ---------------------------------------------------------------------------

_GITHUB_CLIENT: httpx.Client | None = None


def _github_client() -> httpx.Client:
    """Lazy singleton for the GitHub HTTP client (connection pooling)."""
    global _GITHUB_CLIENT
    if _GITHUB_CLIENT is None:
        _GITHUB_CLIENT = httpx.Client(
            timeout=TIMEOUT,
            headers={"User-Agent": CHROME_UA},
            follow_redirects=True,
            proxy=PROXY,
            verify=get_ssl_context(),
        )
    return _GITHUB_CLIENT


def github_search_repos(query: str, max_results: int = MAX_RESULTS) -> list[dict[str, Any]]:
    """Search GitHub repositories via the public API (no token required)."""
    max_results = clamp_results(max_results)
    url = "https://api.github.com/search/repositories"
    params: dict[str, Any] = {
        "q": query,
        "per_page": max_results,
        "sort": "stars",
        "order": "desc",
    }

    for attempt in range(RETRIES + 1):
        try:
            request_throttle.wait()
            resp = _github_client().get(url, params=params)
            resp.raise_for_status()
            return resp.json().get("items", [])
        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            # Don't retry 403 from GitHub — it's rate-limit (60 min window)
            if isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code == 403:
                raise RuntimeError(
                    "GitHub API rate limit exceeded. Try again later or set WEB_GITHUB_TOKEN env var."
                ) from exc
            if attempt >= RETRIES:
                raise RuntimeError(f"GitHub search failed: {exc}") from exc
            _log_retry(attempt, exc)
        except Exception as exc:
            if attempt >= RETRIES:
                raise RuntimeError(f"GitHub search failed: {exc}") from exc
            _log_retry(attempt, exc)

    raise RuntimeError("GitHub search failed: exhausted retries")


# ---------------------------------------------------------------------------
# PyPI package search (DDG discovery + JSON API enrichment)
# ---------------------------------------------------------------------------

_PYPI_PKG_RE = re.compile(r"pypi\.org/project/([^/]+)")


def pypi_search(query: str, max_results: int = MAX_RESULTS) -> list[dict[str, Any]]:
    """Search PyPI packages via DuckDuckGo + enrich with JSON API metadata."""
    max_results = clamp_results(max_results)

    # Step 1: Discover packages via DuckDuckGo
    with ddg_context() as ddgs:
        ddg_items = ddg_search(
            query,
            lambda: ddgs.text(f"site:pypi.org {query}", max_results=max_results, safesearch="off"),
        )

    results: list[dict[str, Any]] = []
    client = _github_client()  # reuse the same httpx.Client (connection pooling)

    for item in ddg_items:
        if not isinstance(item, dict):
            continue

        match = _PYPI_PKG_RE.search(item.get("href", ""))
        if not match:
            continue
        pkg_name = match.group(1)

        # Step 2: Enrich with PyPI JSON API
        try:
            resp = client.get(f"https://pypi.org/pypi/{pkg_name}/json", timeout=TIMEOUT)
            if resp.status_code == 200:
                info = resp.json()["info"]
                project_urls = info.get("project_urls") or {}
                results.append({
                    "name": (info.get("name") or "").strip(),
                    "version": (info.get("version") or "").strip(),
                    "summary": (info.get("summary") or "").strip(),
                    "author": _extract_author(info),
                    "license": (info.get("license_expression") or "").strip(),
                    "requires_python": (info.get("requires_python") or "").strip(),
                    "url": (info.get("project_url") or "").strip(),
                    "repository": (
                        project_urls.get("Source")
                        or project_urls.get("Homepage")
                        or ""
                    ).strip(),
                    "py_versions": [
                        c.split("::")[-1].strip()
                        for c in info.get("classifiers", [])
                        if "Programming Language :: Python :: 3." in c
                    ],
                    "dependencies": [
                        d.split(";")[0].strip()
                        for d in (info.get("requires_dist") or [])
                        if ";" not in d or "extra" not in d
                    ][:10],
                })
                continue
        except Exception as exc:
            logger.warning("PyPI metadata fetch failed for %s: %s", pkg_name, exc)

        # Fallback: DDG-only result
        results.append({
            "name": pkg_name,
            "version": "",
            "summary": (item.get("body") or "").strip(),
            "url": (item.get("href") or "").strip(),
        })

    return results


def _extract_author(info: dict[str, Any]) -> str:
    """Extract a clean author name from PyPI metadata."""
    email = info.get("author_email") or ""
    # "Tom Christie <tom@tomchristie.com>" -> "Tom Christie"
    if "<" in email:
        return email.split("<")[0].strip()
    if email:
        return email.strip()
    return (info.get("author") or "").strip()


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _wrap_search_error(exc: DDGSException | TimeoutException | RatelimitException) -> RuntimeError:
    if isinstance(exc, TimeoutException):
        return RuntimeError("Search timed out.")
    if isinstance(exc, RatelimitException):
        return RuntimeError("Rate-limited. Try later.")
    return RuntimeError(f"Search failed: {exc}")


def _log_retry(attempt: int, exc: Exception) -> None:
    backoff = 0.7 * (2 ** attempt)
    logger.warning(
        "Search attempt %d failed (%s), retrying in %.1fs",
        attempt + 1,
        type(exc).__name__,
        backoff,
    )
    time.sleep(backoff)
