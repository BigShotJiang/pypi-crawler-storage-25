"""HTML to Markdown conversion and text utilities."""

from __future__ import annotations

import logging
import re
from bs4 import BeautifulSoup, Tag
from markdownify import markdownify as _html_to_markdown

logger = logging.getLogger("www-search-mcp")

_NOISE_TAGS = ("script", "style", "noscript", "iframe", "svg", "canvas", "template", "meta", "link")
_LAYOUT_TAGS = ("nav", "header", "footer", "aside")
_KEEP_ATTRS = frozenset({"href", "src", "alt", "title"})


def html_to_markdown(html: str, selector: str = "") -> tuple[str, str]:
    """Parse HTML once, extract title + convert to markdown.

    Returns ``(markdown, title)``.
    """
    try:
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        return html, ""

    title = _extract_title_from_soup(soup)

    # Strip noise tags
    for tag in _NOISE_TAGS:
        for node in soup.find_all(tag):
            node.decompose()

    # Extract specific element or use body
    root = _select_root(soup, selector)

    # Strip layout tags within the root
    for tag in _LAYOUT_TAGS:
        for node in root.find_all(tag):
            node.decompose()

    # Clean attrs
    for node in root.find_all(True):
        node.attrs = {k: v for k, v in node.attrs.items() if k in _KEEP_ATTRS}

    try:
        md = _html_to_markdown(str(root), heading_style="ATX")
    except Exception:
        logger.warning("markdownify failed, returning plain text")
        return root.get_text(separator="\n", strip=True), title

    md = re.sub(r"\n{3,}", "\n\n", md).strip()
    return md, title


def extract_title(html: str) -> str:
    """Extract the ``<title>`` text from raw HTML.

    Convenience wrapper when you only need the title (not the full
    markdown conversion) and don't mind a separate parse.
    """
    try:
        soup = BeautifulSoup(html, "html.parser")
        return _extract_title_from_soup(soup)
    except Exception:
        return ""


def clip_text(text: str, limit: int) -> tuple[str, bool]:
    """Truncate *text* to *limit* chars.  Returns ``(clipped, was_truncated)``."""
    if len(text) <= limit:
        return text, False
    return text[:limit], True


def is_html_response(content_type: str, body: str) -> bool:
    """Heuristic: does the response look like HTML?"""
    if content_type:
        ct = content_type.lower().split(";")[0].strip()
        return ct == "text/html" or ct == "application/xhtml+xml"
    return body.strip().startswith("<")


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _extract_title_from_soup(soup: BeautifulSoup) -> str:
    """Extract ``<title>`` from an already-parsed soup."""
    tag = soup.find("title")
    return tag.get_text(strip=True) if tag else ""


def _select_root(soup: BeautifulSoup, selector: str) -> Tag | BeautifulSoup:
    """Pick the subtree to convert — either a CSS match or the whole body."""
    if selector:
        try:
            el = soup.select_one(selector)
        except Exception:
            logger.warning("Invalid CSS selector %r, falling back to full body", selector)
            el = None
        if el is not None:
            return el
    return soup.body or soup
