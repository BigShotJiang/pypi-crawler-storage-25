"""Thread-safe and async-safe TTL+LRU cache."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections import OrderedDict
from typing import Any

logger = logging.getLogger("www-search-mcp")


class TTLCache:
    """OrderedDict-backed TTL cache with LRU eviction.

    Uses a single ``threading.Lock`` for both sync and async access.
    Async methods (``aget``/``aset``) delegate to the sync methods via
    ``run_in_executor``, guaranteeing that the lock is always acquired
    and released by the same thread.
    """

    def __init__(self, ttl: float = 300.0, maxsize: int = 100) -> None:
        self._store: OrderedDict[str, tuple[float, dict[str, Any]]] = OrderedDict()
        self.ttl = ttl
        self.maxsize = maxsize
        self._lock = threading.Lock()

    # -- key helper ----------------------------------------------------------

    @staticmethod
    def make_key(*parts: Any) -> str:
        return "::".join(str(p) for p in parts)

    # -- sync API (for search tools) -----------------------------------------

    def get(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            return self._get_inner(key)

    def set(self, key: str, value: dict[str, Any]) -> None:
        with self._lock:
            self._set_inner(key, value)

    # -- async API (for fetch/download tools) --------------------------------

    async def aget(self, key: str) -> dict[str, Any] | None:
        return await asyncio.get_running_loop().run_in_executor(None, self.get, key)

    async def aset(self, key: str, value: dict[str, Any]) -> None:
        await asyncio.get_running_loop().run_in_executor(None, self.set, key, value)

    # -- bulk ----------------------------------------------------------------

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    # -- internals -----------------------------------------------------------

    def _get_inner(self, key: str) -> dict[str, Any] | None:
        """Must be called while holding ``_lock``."""
        entry = self._store.get(key)
        if entry is None:
            return None
        ts, value = entry
        if time.monotonic() - ts < self.ttl:
            logger.debug("Cache hit for %s", key)
            self._store.move_to_end(key)
            return value
        del self._store[key]
        return None

    def _set_inner(self, key: str, value: dict[str, Any]) -> None:
        """Must be called while holding ``_lock``."""
        self._store[key] = (time.monotonic(), value)
        self._store.move_to_end(key)
        while len(self._store) > self.maxsize:
            self._store.popitem(last=False)


# ---------------------------------------------------------------------------
# Pre-built cache instances
# ---------------------------------------------------------------------------

search_cache = TTLCache(ttl=300.0, maxsize=100)
fetch_cache = TTLCache(ttl=60.0, maxsize=50)
