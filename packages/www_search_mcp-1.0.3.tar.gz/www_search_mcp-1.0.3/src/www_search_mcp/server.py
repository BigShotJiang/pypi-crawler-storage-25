"""Unified MCP server: web search + fetch + browser fetch + download."""

from __future__ import annotations

import asyncio
import atexit
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from .browser import (
    close_all as close_browser,
    ensure_browser,
    ensure_browser_context,
)
from .cache import TTLCache, fetch_cache, search_cache
from .config import (
    CHROME_UA,
    MAX_DOWNLOAD_BYTES,
    MAX_DOWNLOAD_MB,
    MAX_FETCH_CHARS,
    MAX_RESULTS,
    PROXY,
    SESSION_ENABLED,
    TIMEOUT,
    get_ssl_context,
)
from .html_utils import (
    clip_text,
    html_to_markdown,
    is_html_response,
)
from .search import clamp_results, ddg_context, ddg_search, github_search_repos, pypi_search
from .throttle import request_throttle

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.DEBUG if os.getenv("WEB_DEBUG") else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("www-search-mcp")

# ---------------------------------------------------------------------------
# Shared HTTP client (lazy, for session-mode)
# ---------------------------------------------------------------------------

_HTTP_ASYNC: httpx.AsyncClient | None = None
_HTTP_ASYNC_LOCK = asyncio.Lock()


async def _get_http_async() -> httpx.AsyncClient:
    """Return (or create) the shared async HTTP client."""
    global _HTTP_ASYNC
    if _HTTP_ASYNC is None:
        async with _HTTP_ASYNC_LOCK:
            if _HTTP_ASYNC is None:
                _HTTP_ASYNC = httpx.AsyncClient(
                    follow_redirects=True,
                    timeout=TIMEOUT,
                    headers={"User-Agent": CHROME_UA},
                    proxy=PROXY,
                    verify=get_ssl_context(),
                )
    return _HTTP_ASYNC


# ---------------------------------------------------------------------------
# MCP instance
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="www-search-mcp",
    instructions=(
        "Web search, fetch, and download tools. "
        "\nSearch tools:\n"
        "- web_search: General web search for any topic (use by default for web queries).\n"
        "- web_search_images: Search for images, photos, pictures.\n"
        "- web_search_github: Search GitHub repositories, code, open-source projects.\n"
        "- web_search_pypi: Search Python packages, libraries, pip packages on PyPI. "
        "Use when user asks about Python packages, pip install, libraries, dependencies.\n"
        "\nFetch tools:\n"
        "- web_fetch: Fetch a URL via HTTP, returns markdown (fast, for static pages).\n"
        "- web_fetch_browser: Fetch a URL using a real browser via Playwright (for JS-heavy pages, SPAs, login pages).\n"
        "- web_download: Download files/images by URL and save to disk.\n"
    ),
)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_BINARY_TYPES = frozenset({
    "application/pdf", "application/zip", "application/gzip",
    "application/octet-stream", "application/x-tar",
    "application/x-7z-compressed", "application/x-rar-compressed",
})
_BINARY_PREFIXES = ("image/", "video/", "audio/")


def _is_binary_content(content_type: str) -> bool:
    """Return True if the content type looks like non-text binary data."""
    ct = content_type.lower().split(";")[0].strip()
    if ct in _BINARY_TYPES:
        return True
    # Skip SVG — it's XML/text, not binary
    if ct == "image/svg+xml":
        return False
    return any(ct.startswith(p) for p in _BINARY_PREFIXES)


def _validate_url(url: str) -> str:
    url = url.strip()
    if not url or not (url.startswith("http://") or url.startswith("https://")):
        raise ValueError("url must start with http:// or https://")
    return url


def _resolve_path(file_path: str) -> Path:
    """Resolve save_file: must have a file extension.
    Relative paths are resolved from the user's home directory."""
    p = Path(file_path.strip())
    if not p.suffix:
        raise ValueError(f"save_file must have a file extension: {file_path}")
    if ".." in p.parts:
        raise ValueError(f"save_file contains invalid path traversal: {file_path}")
    if not p.is_absolute():
        p = Path.home() / p
    return p.resolve()


def _build_fetch_result(
    body: str,
    http_status: int,
    url: str,
    content_type: str = "",
    title: str = "",
    truncated: bool = False,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "ok" if http_status < 400 else "http_error",
        "http_status": http_status,
        "url": url,
        "truncated": truncated,
    }
    if title:
        result["title"] = title
    if content_type:
        result["content_type"] = content_type
    result["body"] = body
    return result


def _save_full_body(body: str, save_file: str, base_result: dict[str, Any]) -> dict[str, Any]:
    """Save the *full* (pre-truncation) body to disk, return metadata."""
    target = _resolve_path(save_file)
    target.parent.mkdir(parents=True, exist_ok=True)
    data = body.encode("utf-8", errors="replace")
    target.write_bytes(data)
    result = {k: v for k, v in base_result.items() if k != "body"}
    result["saved_to"] = str(target)
    result["bytes_written"] = len(data)
    return result


def _save_or_return(
    body: str,
    save_file: str,
    http_status: int,
    url: str,
    content_type: str,
    title: str,
) -> dict[str, Any] | None:
    """If *save_file* is set, save full body to disk and return metadata.

    Returns ``None`` when *save_file* is empty, signalling the caller
    should proceed with clipping and caching.
    """
    if not save_file:
        return None
    full_result = _build_fetch_result(
        body=body,
        http_status=http_status,
        url=url,
        content_type=content_type,
        title=title,
    )
    return _save_full_body(body, save_file, full_result)


# ---------------------------------------------------------------------------
# Field mapping for DDG search results
# ---------------------------------------------------------------------------

_FIELD_MAPS: dict[str, dict[str, str]] = {
    "text": {
        "title": "title",
        "url": "href",
        "snippet": "body",
    },
    "images": {
        "title": "title",
        "image": "image",
        "url": "url",
        "thumbnail": "thumbnail",
        "height": "height",
        "width": "width",
        "source": "source",
    },

}


def _map_ddg_item(item: dict, fields: dict[str, str], defaults: dict[str, Any] | None = None) -> dict[str, Any]:
    """Extract named fields from a raw DDG result item."""
    result: dict[str, Any] = {}
    defaults = defaults or {}
    for out_key, ddg_key in fields.items():
        if out_key in defaults:
            val = item.get(ddg_key)
            if val is None:
                val = defaults[out_key]
            if isinstance(val, str):
                val = (val or "").strip()
            result[out_key] = val
        else:
            raw = item.get(ddg_key)
            if raw is None and out_key == "url":
                raw = item.get("href") or item.get("url") or ""
            result[out_key] = (raw or "").strip() if isinstance(raw, str) else (raw or "")
    return result


# ---------------------------------------------------------------------------
# Generic search result builder
# ---------------------------------------------------------------------------

def _search_result(query: str, results: list) -> dict[str, Any]:
    return {
        "status": "ok" if results else "no_results",
        "query": query,
        "result_count": len(results),
        "results": results,
    }


# ---------------------------------------------------------------------------
# Tool 1: web_search
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_search",
    title="Web Search",
    description="Search the web for any topic via DuckDuckGo. Use this as the default search tool. Use when user says 'search for', 'find information', 'look up', 'google', or asks any general question requiring web information. Do NOT use for images (use web_search_images), Python packages (use web_search_pypi), GitHub repos (use web_search_github), or reading a specific URL (use web_fetch). Returns title, url, snippet for each result."
)
def web_search(query: str, max_results: int = MAX_RESULTS) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    max_results = clamp_results(max_results)
    cache_key = TTLCache.make_key("text", query, max_results)

    cached = search_cache.get(cache_key)
    if cached is not None:
        return cached

    logger.info("web_search: query=%r max_results=%d", query, max_results)

    with ddg_context() as ddgs:
        items = ddg_search(
            query,
            lambda: ddgs.text(query, max_results=max_results, safesearch="off"),
        )

    results = [
        _map_ddg_item(item, _FIELD_MAPS["text"])
        for item in items
        if isinstance(item, dict)
    ]

    logger.info("web_search: found %d results", len(results))
    result = _search_result(query, results)
    search_cache.set(cache_key, result)
    return result


# ---------------------------------------------------------------------------
# Tool 2: web_search_images
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_search_images",
    title="Web Image Search",
    description="Search for images, photos, pictures via DuckDuckGo. Use when user says 'find image', 'search pictures', 'image URLs' or needs visual content. Do NOT use for general web search (use web_search). Returns title, image url, source url, thumbnail, dimensions."
)
def web_search_images(query: str, max_results: int = MAX_RESULTS) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    max_results = clamp_results(max_results)
    cache_key = TTLCache.make_key("images", query, max_results)

    cached = search_cache.get(cache_key)
    if cached is not None:
        return cached

    logger.info("web_search_images: query=%r max_results=%d", query, max_results)

    with ddg_context() as ddgs:
        items = ddg_search(
            query,
            lambda: ddgs.images(query, max_results=max_results, safesearch="off"),
        )

    results = [
        _map_ddg_item(item, _FIELD_MAPS["images"], {"height": 0, "width": 0})
        for item in items
        if isinstance(item, dict)
    ]

    logger.info("web_search_images: found %d results", len(results))
    result = _search_result(query, results)
    search_cache.set(cache_key, result)
    return result



# ---------------------------------------------------------------------------
# Tool 6: web_search_github
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_search_github",
    title="GitHub Repository Search",
    description="Search GitHub repositories via the GitHub API. Use when user says 'find repo', 'search github', 'find open-source project', 'github search' or asks about software projects on GitHub specifically. Do NOT use for Python packages (use web_search_pypi) or general web search (use web_search). Returns title, url, description, stars, forks, language."
)
def web_search_github(query: str, max_results: int = MAX_RESULTS) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    max_results = clamp_results(max_results)
    cache_key = TTLCache.make_key("github", query, max_results)

    cached = search_cache.get(cache_key)
    if cached is not None:
        return cached

    logger.info("web_search_github: query=%r max_results=%d", query, max_results)

    items = github_search_repos(query, max_results)
    results = [
        {
            "title": (item.get("name") or "").strip(),
            "url": (item.get("html_url") or "").strip(),
            "description": (item.get("description") or "").strip(),
            "stars": item.get("stargazers_count") or 0,
            "forks": item.get("forks_count") or 0,
            "language": (item.get("language") or "").strip(),
        }
        for item in items
        if isinstance(item, dict)
    ]

    logger.info("web_search_github: found %d results", len(results))
    result = _search_result(query, results)
    search_cache.set(cache_key, result)
    return result


# ---------------------------------------------------------------------------
# Tool 7: web_search_pypi
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_search_pypi",
    title="PyPI Package Search",
    description=(
        "Search Python packages on PyPI (the Python Package Index). "
        "Use when user says 'find pip package', 'search pypi', 'find python library', 'pip install', "
        "or asks about Python dependencies or packages. "
        "Do NOT use for general web search (use web_search) or GitHub repos (use web_search_github). "
        "Returns name, version, summary, author, license, requires_python, url, repository, py_versions, dependencies."
    ),
)
def web_search_pypi(query: str, max_results: int = MAX_RESULTS) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    max_results = clamp_results(max_results)
    cache_key = TTLCache.make_key("pypi", query, max_results)

    cached = search_cache.get(cache_key)
    if cached is not None:
        return cached

    logger.info("web_search_pypi: query=%r max_results=%d", query, max_results)

    items = pypi_search(query, max_results)

    logger.info("web_search_pypi: found %d results", len(items))
    result = _search_result(query, items)
    search_cache.set(cache_key, result)
    return result


# ---------------------------------------------------------------------------
# Tool 8: web_fetch (plain HTTP)
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_fetch",
    title="Web Fetch",
    description=(
        "Fetch a URL via HTTP and return its content as markdown. "
        "Use when user says 'get page content', 'read url', 'fetch page', 'read link', 'show page' or needs to read a web page, article, or documentation. "
        "Fast and lightweight \u2014 ideal for static HTML pages. Returns text/markdown only. "
        "For binary files (images, PDFs, archives) use web_download instead. "
        "For JavaScript-heavy pages, login, or captcha use web_fetch_browser instead. "
        "fetch_div: optional CSS selector (e.g. 'article', '.post-body') to extract only that element. "
        "save_file: optional absolute file path with extension to save content to disk instead of returning in body. "
        "use_session: reuse cookies from previous requests (default follows WEB_SESSION_ENABLED env)."
    ),
)
async def web_fetch(url: str, fetch_div: str = "", save_file: str = "", use_session: bool = False) -> dict[str, Any]:
    clean_url = _validate_url(url)
    session_active = use_session or SESSION_ENABLED
    logger.info("web_fetch: url=%r fetch_div=%r session=%s", clean_url, fetch_div, session_active)

    cache_key = TTLCache.make_key(clean_url, fetch_div, use_session)
    cached = await fetch_cache.aget(cache_key)
    if cached is not None and not save_file:
        return cached

    await request_throttle.await_gap()
    try:
        if session_active:
            client = await _get_http_async()
            resp = await client.get(clean_url)
        else:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=TIMEOUT,
                headers={"User-Agent": CHROME_UA},
                proxy=PROXY,
                verify=get_ssl_context(),
            ) as client:
                resp = await client.get(clean_url)
    except httpx.HTTPError as exc:
        logger.error("web_fetch failed: %s", exc)
        raise RuntimeError(f"Fetch failed: {exc}") from exc

    content_type = resp.headers.get("content-type", "")

    # Reject binary content — user should use web_download instead
    if _is_binary_content(content_type):
        raise RuntimeError(
            f"URL returned binary content ({content_type}). Use web_download instead."
        )

    body = resp.text
    title = ""

    if is_html_response(content_type, body):
        body, title = html_to_markdown(body, fetch_div)

    # BUG FIX: save_file gets the full body BEFORE truncation
    saved = _save_or_return(body, save_file, resp.status_code, str(resp.url), content_type, title)
    if saved is not None:
        return saved

    body, truncated = clip_text(body, MAX_FETCH_CHARS)

    result = _build_fetch_result(
        body=body,
        http_status=resp.status_code,
        url=str(resp.url),
        content_type=content_type,
        title=title,
        truncated=truncated,
    )

    await fetch_cache.aset(cache_key, result)
    return result


# ---------------------------------------------------------------------------
# Tool 9: web_fetch_browser (Playwright)
# ---------------------------------------------------------------------------

@mcp.tool(
    name="web_fetch_browser",
    title="Web Fetch (Browser)",
    description=(
        "Fetch a URL using a real browser (Playwright). "
        "Use ONLY when user explicitly says 'open in browser', 'use real browser', 'render JavaScript', or needs login, captcha, or form filling. "
        "Set headless=false and wait_seconds=20-60 to let user manually log in, solve captcha, or interact with the page before content is captured. "
        "Also use when web_fetch returns incomplete or empty content due to JavaScript rendering. "
        "For most URLs, prefer web_fetch (faster, lighter). "
        "fetch_div: optional CSS selector (e.g. 'article', '.post-body') to extract only that element. "
        "save_file: optional absolute file path with extension to save content to disk instead of returning in body. "
        "headless: show browser window (false) or run hidden (true). Default true. Set to false for manual login or captcha. "
        "wait_seconds: seconds to wait after page load before extracting content. Use 20-60 for login, captcha, or slow pages. "
        "use_session: reuse browser cookies/context from previous requests (default follows WEB_SESSION_ENABLED env)."
    ),
)
async def web_fetch_browser(
    url: str,
    fetch_div: str = "",
    save_file: str = "",
    headless: bool = True,
    wait_seconds: int = 0,
    use_session: bool = False,
) -> dict[str, Any]:
    clean_url = _validate_url(url)
    session_active = use_session or SESSION_ENABLED
    logger.info(
        "web_fetch_browser: url=%r fetch_div=%r headless=%s wait=%d session=%s",
        clean_url, fetch_div, headless, wait_seconds, session_active,
    )

    cache_key = TTLCache.make_key(clean_url, fetch_div, headless, wait_seconds, use_session)
    cached = await fetch_cache.aget(cache_key)
    if cached is not None and not save_file:
        return cached

    await request_throttle.await_gap()

    html = ""
    page_url = clean_url
    page_title = ""
    http_status = 200
    content_type = ""
    page = None

    try:
        if session_active:
            context = await ensure_browser_context(headless=headless)
            page = await context.new_page()
            logger.debug("Using shared browser context for session")
        else:
            browser = await ensure_browser(headless=headless)
            page = await browser.new_page()

        await page.set_extra_http_headers({"User-Agent": CHROME_UA})
        page.set_default_timeout(TIMEOUT * 1000)
        resp = await page.goto(clean_url, wait_until="load")

        if wait_seconds > 0:
            await asyncio.sleep(wait_seconds)

        html = await page.content()
        page_url = page.url
        page_title = await page.title()
        http_status = resp.status if resp else 200
        content_type = resp.headers.get("content-type", "") if resp else ""
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        logger.error("web_fetch_browser failed: %s", exc)
        raise RuntimeError(f"Browser fetch failed: {exc}") from exc
    finally:
        if page is not None:
            await page.close()

    body, _title = html_to_markdown(html, fetch_div)
    # Prefer Playwright's page.title() over HTML-parsed title (more reliable after JS)
    title = page_title or _title

    # BUG FIX: save_file gets the full body BEFORE truncation
    saved = _save_or_return(body, save_file, http_status, page_url or clean_url, content_type, title)
    if saved is not None:
        return saved

    body, truncated = clip_text(body, MAX_FETCH_CHARS)

    result = _build_fetch_result(
        body=body,
        http_status=http_status,
        url=page_url or clean_url,
        content_type=content_type,
        title=title,
        truncated=truncated,
    )

    await fetch_cache.aset(cache_key, result)
    return result


# ---------------------------------------------------------------------------
# Tool 10: web_download
# ---------------------------------------------------------------------------

async def _read_streamed_response(resp: httpx.Response) -> tuple[bytearray, str]:
    """Read a streamed response with size limits.

    Returns ``(data, content_type)``.
    """
    if resp.status_code >= 400:
        raise RuntimeError(f"Download failed: HTTP {resp.status_code}")
    content_type = resp.headers.get("content-type", "")
    data = bytearray()
    async for chunk in resp.aiter_bytes():
        data.extend(chunk)
        if len(data) > MAX_DOWNLOAD_BYTES:
            raise RuntimeError(
                f"File too large: {len(data) / (1024 * 1024):.1f} MB "
                f"(limit {MAX_DOWNLOAD_MB} MB, set WEB_MAX_DOWNLOAD_MB to raise it)"
            )
    return data, content_type


@mcp.tool(
    name="web_download",
    title="Web Download",
    description=(
        "Download any file by URL (images, PDFs, archives, documents, videos, etc.) and save to disk. "
        "Use when user says 'download file', 'save image', 'download pdf', 'save to disk' or wants to save any binary or media content. "
        "Do NOT use for reading page text (use web_fetch). "
        "save_file is required: must be an absolute file path with extension. "
        "use_session: reuse cookies from previous requests (default follows WEB_SESSION_ENABLED env)."
    ),
)
async def web_download(url: str, save_file: str, use_session: bool = False) -> dict[str, Any]:
    clean_url = _validate_url(url)
    target = _resolve_path(save_file)
    session_active = use_session or SESSION_ENABLED
    logger.info("web_download: url=%r -> %s session=%s", clean_url, target, session_active)

    await request_throttle.await_gap()

    try:
        if session_active:
            client = await _get_http_async()
            async with client.stream("GET", clean_url) as resp:
                data, content_type = await _read_streamed_response(resp)
        else:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=TIMEOUT,
                headers={"User-Agent": CHROME_UA},
                proxy=PROXY,
                verify=get_ssl_context(),
            ) as client:
                async with client.stream("GET", clean_url) as resp:
                    data, content_type = await _read_streamed_response(resp)
    except httpx.HTTPError as exc:
        logger.error("web_download failed: %s", exc)
        raise RuntimeError(f"Download failed: {exc}") from exc

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    except OSError as exc:
        logger.error("Failed to write download to %s: %s", target, exc)
        raise RuntimeError(f"Failed to save file {target}: {exc}") from exc

    logger.info("web_download: saved %d bytes to %s", len(data), target)
    return {
        "status": "downloaded",
        "url": clean_url,
        "saved_to": str(target),
        "bytes": len(data),
        "content_type": content_type,
    }


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

async def _async_cleanup() -> None:
    """Close all async resources (HTTP client, browser)."""
    if _HTTP_ASYNC is not None:
        try:
            await _HTTP_ASYNC.aclose()
        except Exception:
            logger.warning("Failed to close async HTTP client", exc_info=True)
    await close_browser()


def _cleanup() -> None:
    global _HTTP_ASYNC
    logger.info("Shutting down www-search-mcp")
    try:
        loop = asyncio.get_running_loop()
        # Loop still running — schedule cleanup task
        loop.create_task(_async_cleanup())
    except RuntimeError:
        # No running loop — create one for cleanup
        try:
            asyncio.run(_async_cleanup())
        except Exception:
            logger.warning("Async cleanup failed", exc_info=True)
    _HTTP_ASYNC = None


def _signal_handler(signum: int, frame: Any) -> None:
    logger.info("Received signal %d, shutting down", signum)
    try:
        _cleanup()
    except Exception:
        pass
    sys.exit(0)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

_CLEANUP_REGISTERED = False


def main() -> None:
    global _CLEANUP_REGISTERED
    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    if not _CLEANUP_REGISTERED:
        atexit.register(_cleanup)
        _CLEANUP_REGISTERED = True
    mcp.run(transport="stdio")
