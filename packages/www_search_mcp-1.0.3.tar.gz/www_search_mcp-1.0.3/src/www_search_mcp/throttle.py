"""Request throttling — unified sync/async with a single lock."""

import asyncio
import threading
import time

from .config import MIN_INTERVAL


class Throttle:
    """Rate-limiter that works for both sync and async callers.

    Uses a single ``threading.Lock`` to protect ``_last_at``.
    The async ``await_gap`` method delegates to the sync ``wait``
    via ``run_in_executor``, so the lock is always acquired and
    released by the same thread.
    """

    def __init__(self, interval: float = MIN_INTERVAL) -> None:
        self.interval = interval
        self._last_at: float = 0.0
        self._lock = threading.Lock()

    def reset(self) -> None:
        """Reset throttle state (useful in tests)."""
        with self._lock:
            self._last_at = 0.0

    # -- sync ----------------------------------------------------------------

    def wait(self) -> None:
        """Block until at least ``interval`` seconds since last request."""
        with self._lock:
            remaining = self.interval - (time.monotonic() - self._last_at)
            if remaining > 0:
                time.sleep(remaining)
            self._last_at = time.monotonic()

    # -- async ---------------------------------------------------------------

    async def await_gap(self) -> None:
        """Coroutine that waits until at least ``interval`` seconds have passed.

        Delegates to the sync ``wait`` via ``run_in_executor`` so that
        the lock is held by a single thread for the entire sleep.
        """
        await asyncio.get_running_loop().run_in_executor(None, self.wait)


# Singleton used across all tools
request_throttle = Throttle()
