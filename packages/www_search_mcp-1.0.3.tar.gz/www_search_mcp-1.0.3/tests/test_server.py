"""Tests for www_search_mcp."""

import asyncio
import time
import uuid
from pathlib import Path

import httpx
import os

import pytest

from www_search_mcp import server as srv
from www_search_mcp.cache import TTLCache, fetch_cache, search_cache
from www_search_mcp.browser import close_all, ensure_browser
from www_search_mcp.html_utils import clip_text, html_to_markdown
from www_search_mcp.server import (
    _build_fetch_result,
    _resolve_path,
    _validate_url,
    web_download,
    web_fetch,
    web_fetch_browser,
    web_search,
    web_search_images,
    web_search_pypi,
)
from www_search_mcp.throttle import request_throttle


@pytest.fixture(autouse=True)
def reset_global_state(monkeypatch):
    """Reset shared mutable state before each test."""
    fetch_cache.clear()
    search_cache.clear()
    request_throttle.reset()
    monkeypatch.setattr("www_search_mcp.server._HTTP_ASYNC", None)
    yield
    fetch_cache.clear()
    search_cache.clear()


@pytest.fixture(autouse=True)
async def cleanup_browser():
    """Close Playwright browser after each async test."""
    yield
    from www_search_mcp import browser as b
    b._browser_context = None
    await close_all()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class TestValidateUrl:
    def test_valid_https(self):
        assert _validate_url("https://example.com") == "https://example.com"

    def test_valid_http(self):
        assert _validate_url("http://example.com") == "http://example.com"

    def test_strips_whitespace(self):
        assert _validate_url("  https://example.com  ") == "https://example.com"

    def test_rejects_ftp(self):
        with pytest.raises(ValueError, match="http:// or https://"):
            _validate_url("ftp://example.com")

    def test_rejects_empty(self):
        with pytest.raises(ValueError, match="http:// or https://"):
            _validate_url("")


class TestResolvePath:
    def test_relative_resolves_to_home(self):
        p = _resolve_path("test.txt")
        assert p.is_absolute()
        assert p.name == "test.txt"

    def test_absolute_preserved(self):
        p = _resolve_path("/tmp/test.txt")
        assert p == Path("/tmp/test.txt").resolve()

    def test_rejects_no_extension(self):
        with pytest.raises(ValueError, match="file extension"):
            _resolve_path("/tmp/noextension")

    def test_rejects_path_traversal(self):
        with pytest.raises(ValueError, match="path traversal"):
            _resolve_path(str(Path.home() / ".." / "etc" / "passwd.txt"))


class TestHtmlToMarkdown:
    def test_basic_conversion(self):
        md, title = html_to_markdown("<h1>Title</h1><p>Paragraph</p>")
        assert "# Title" in md
        assert "Paragraph" in md

    def test_noise_tags_removed(self):
        md, _ = html_to_markdown("<script>alert(1)</script><p>Keep me</p>")
        assert "alert" not in md
        assert "Keep me" in md

    def test_layout_tags_removed(self):
        md, _ = html_to_markdown("<nav>Nav</nav><p>Content</p>")
        assert "Nav" not in md
        assert "Content" in md

    def test_selector_extraction(self):
        html = "<div class='content'><p>Inside</p></div><footer>Out</footer>"
        md, _ = html_to_markdown(html, selector=".content")
        assert "Inside" in md
        assert "Out" not in md

    def test_invalid_selector_fallback(self):
        md, _ = html_to_markdown("<p>Body</p>", selector="[[bad")
        assert "Body" in md

    def test_broken_html_fallback(self):
        result, _ = html_to_markdown("<<<>>>not valid<<<")
        assert isinstance(result, str)

    def test_title_extracted(self):
        _, title = html_to_markdown("<html><head><title>My Page</title></head><body><p>Hi</p></body></html>")
        assert title == "My Page"


class TestClipText:
    def test_no_clip(self):
        clipped, truncated = clip_text("short", 100)
        assert clipped == "short"
        assert truncated is False

    def test_clip(self):
        clipped, truncated = clip_text("1234567890", 5)
        assert len(clipped) == 5
        assert truncated is True


class TestBuildFetchResult:
    def test_ok_status(self):
        r = _build_fetch_result("body", 200, "https://example.com")
        assert r["status"] == "ok"
        assert r["http_status"] == 200

    def test_error_status(self):
        r = _build_fetch_result("err", 500, "https://example.com")
        assert r["status"] == "http_error"

    def test_optional_fields(self):
        r = _build_fetch_result("b", 200, "url", content_type="text/html", title="T")
        assert r["title"] == "T"
        assert r["content_type"] == "text/html"


class TestCache:
    async def test_cache_hit_async(self):
        c = TTLCache(ttl=10, maxsize=10)
        await c.aset("k", {"body": "test"})
        assert await c.aget("k") == {"body": "test"}

    async def test_cache_ttl_expiry(self):
        c = TTLCache(ttl=0.01, maxsize=10)
        await c.aset("k", {"body": "x"})
        await asyncio.sleep(0.02)
        assert await c.aget("k") is None

    async def test_cache_lru_eviction(self):
        c = TTLCache(ttl=10, maxsize=2)
        await c.aset("k1", {"v": 1})
        await c.aset("k2", {"v": 2})
        await c.aset("k3", {"v": 3})
        assert await c.aget("k1") is None
        assert await c.aget("k2") is not None
        assert await c.aget("k3") is not None

    def test_make_key(self):
        k1 = TTLCache.make_key("https://example.com", "", True, 0)
        k2 = TTLCache.make_key("https://example.com", "", False, 0)
        assert k1 != k2

    def test_sync_cache(self):
        c = TTLCache(ttl=10, maxsize=10)
        c.set("k", {"v": 1})
        assert c.get("k") == {"v": 1}


class TestThrottle:
    def test_sync_throttle_delays(self, monkeypatch):
        monkeypatch.setattr(request_throttle, "interval", 0.2)
        request_throttle.reset()
        request_throttle.wait()  # first call -> sets _last_at
        t0 = time.monotonic()
        request_throttle.wait()
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.15

    async def test_async_throttle_delays(self, monkeypatch):
        monkeypatch.setattr(request_throttle, "interval", 0.2)
        request_throttle.reset()
        await request_throttle.await_gap()
        t0 = time.monotonic()
        await request_throttle.await_gap()
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.15


class TestWebSearchPyPI:
    def test_pypi_search_returns_results(self):
        result = web_search_pypi("httpx", max_results=3)
        assert result["status"] in ("ok", "no_results")
        assert result["result_count"] <= 3
        if result["result_count"] > 0:
            first = result["results"][0]
            assert "name" in first
            assert "version" in first
            assert "summary" in first
            assert "url" in first

    def test_pypi_search_cache(self):
        query = f"cache-test-pypi-{uuid.uuid4().hex[:8]}"
        result1 = web_search_pypi(query, max_results=2)
        result2 = web_search_pypi(query, max_results=2)
        assert result1 == result2

    def test_empty_query_raises(self):
        with pytest.raises(ValueError):
            web_search_pypi("   ")


# ---------------------------------------------------------------------------
# Integration tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestWebFetch:
    async def test_fetch_example_com(self):
        result = await web_fetch("https://example.com")
        assert result["status"] == "ok"
        assert result["http_status"] == 200
        assert "Example Domain" in result["body"]

    async def test_fetch_with_div(self):
        result = await web_fetch("https://example.com", fetch_div="body")
        assert result["status"] == "ok"
        assert "Example Domain" in result["body"]

    async def test_fetch_invalid_url(self):
        with pytest.raises(ValueError):
            await web_fetch("not-a-url")

    async def test_fetch_404(self):
        result = await web_fetch("https://example.com/404-not-found")
        assert result["status"] == "http_error"

    async def test_fetch_extracts_title(self):
        result = await web_fetch("https://example.com")
        assert result["status"] == "ok"
        assert result.get("title") == "Example Domain"

    async def test_fetch_cache(self):
        await web_fetch("https://example.com")
        t0 = time.monotonic()
        result = await web_fetch("https://example.com")
        t1 = time.monotonic()
        assert t1 - t0 < 0.05  # cached
        assert result["status"] == "ok"

    async def test_save_file_not_truncated(self, monkeypatch, tmp_path):
        """Regression: save_file must receive the FULL body, not truncated."""
        monkeypatch.setattr("www_search_mcp.server.MAX_FETCH_CHARS", 5)
        target = tmp_path / "page.md"
        result = await web_fetch("https://example.com", save_file=str(target))
        assert result["status"] == "ok"
        assert target.exists()
        # File must contain much more than the 5-char cap
        assert target.stat().st_size > 50


@pytest.mark.asyncio
class TestWebFetchBrowser:
    async def test_browser_fetch_example(self):
        result = await web_fetch_browser("https://example.com")
        assert result["status"] == "ok"
        assert result["http_status"] == 200
        assert result.get("title") == "Example Domain" or result.get("title") is None

    async def test_browser_cache(self):
        await web_fetch_browser("https://example.com")
        t0 = time.monotonic()
        result = await web_fetch_browser("https://example.com")
        t1 = time.monotonic()
        assert t1 - t0 < 0.05
        assert result["status"] == "ok"

    async def test_browser_created(self):
        browser = await ensure_browser(headless=True)
        assert browser.is_connected()

    async def test_browser_fetch_includes_content_type(self):
        result = await web_fetch_browser("https://example.com")
        assert result["status"] == "ok"
        assert "content_type" in result
        assert "text/html" in result["content_type"]


@pytest.mark.asyncio
class TestWebDownload:
    async def test_download_example(self, tmp_path: Path):
        target = tmp_path / "test.html"
        result = await web_download("https://example.com", str(target))
        assert result["status"] == "downloaded"
        assert result["bytes"] > 0
        assert target.exists()

    async def test_download_too_large(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.MAX_DOWNLOAD_BYTES", 10)
        with pytest.raises(RuntimeError, match="too large"):
            await web_download("https://example.com", "/tmp/too_large.html")

    async def test_download_oserror(self, monkeypatch, tmp_path: Path):
        target = tmp_path / "readonly" / "test.html"
        monkeypatch.setattr(
            "www_search_mcp.server.Path.mkdir",
            lambda *args, **kwargs: (_ for _ in ()).throw(PermissionError("read-only")),
        )
        with pytest.raises(RuntimeError, match="Failed to save file"):
            await web_download("https://example.com", str(target))


class TestWebSearch:
    def test_search_returns_results(self):
        result = web_search("python programming", max_results=3)
        assert result["status"] == "ok"
        assert result["result_count"] <= 3
        assert result["result_count"] > 0
        first = result["results"][0]
        assert "title" in first
        assert "url" in first

    def test_empty_query_raises(self):
        with pytest.raises(ValueError):
            web_search("   ")

    def test_no_results_structure(self):
        query = f"no-results-{uuid.uuid4().hex}"
        result = web_search(query, max_results=5)
        assert result["status"] in ("ok", "no_results")
        assert isinstance(result["result_count"], int)


class TestWebSearchImages:
    def test_image_search_returns_results(self):
        result = web_search_images("cat", max_results=3)
        assert result["status"] in ("ok", "no_results")
        assert result["result_count"] <= 3
        if result["result_count"] > 0:
            first = result["results"][0]
            assert "title" in first
            assert "image" in first
            assert "url" in first
            assert "thumbnail" in first

    def test_empty_query_raises(self):
        with pytest.raises(ValueError):
            web_search_images("   ")

    def test_image_search_cache(self):
        query = f"cache-test-{uuid.uuid4().hex}"
        result1 = web_search_images(query, max_results=2)
        result2 = web_search_images(query, max_results=2)
        assert result1 == result2


@pytest.mark.asyncio
class TestBrowserLifecycle:
    async def test_browser_created(self):
        browser = await ensure_browser(headless=True)
        assert browser.is_connected()

    async def test_browser_reused_when_same_headless(self):
        b1 = await ensure_browser(headless=True)
        b2 = await ensure_browser(headless=True)
        assert b1 is b2


def _track_client_inits(monkeypatch):
    created: list[int] = []
    original_init = httpx.AsyncClient.__init__

    def tracking_init(self, *args, **kwargs):
        created.append(1)
        return original_init(self, *args, **kwargs)

    monkeypatch.setattr(httpx.AsyncClient, "__init__", tracking_init)
    return created


@pytest.mark.asyncio
class TestHttpSession:
    async def test_fetch_without_session_creates_new_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", False)
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=False)
        assert result["status"] == "ok"
        assert len(created) == 1

    async def test_fetch_with_session_uses_shared_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", True)
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=True)
        assert result["status"] == "ok"
        first_count = len(created)
        result2 = await web_fetch("https://example.com", use_session=True)
        assert result2["status"] == "ok"
        assert len(created) == first_count

    async def test_session_param_overrides_env_off(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", False)
        await srv._get_http_async()  # pre-warm
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=True)
        assert result["status"] == "ok"
        assert len(created) == 0

    async def test_no_session_param_overrides_env_on(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", True)
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=False)
        assert result["status"] == "ok"
        assert len(created) == 1


@pytest.mark.asyncio
class TestBrowserContextInvalidation:
    @pytest.mark.skipif(
        os.getenv("DISPLAY") is None and os.getenv("WAYLAND_DISPLAY") is None,
        reason="No display server available (headless CI)",
    )
    async def test_context_cleared_when_browser_headless_changes(self):
        from www_search_mcp import browser as b
        await ensure_browser(headless=True)
        b._browser_context = await b._browser.new_context()
        assert b._browser_context is not None
        await ensure_browser(headless=False)
        assert b._browser_context is None

    async def test_context_not_returned_when_browser_disconnected(self, monkeypatch):
        from www_search_mcp import browser as b
        await ensure_browser(headless=True)
        b._browser_context = await b._browser.new_context()
        assert b._browser_context is not None
        monkeypatch.setattr(b._browser, "is_connected", lambda: False)
        from www_search_mcp.browser import ensure_browser_context
        ctx = await ensure_browser_context(headless=True)
        assert ctx is not None


@pytest.mark.asyncio
class TestWebDownloadSession:
    async def test_download_without_session_creates_new_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", False)
        created = _track_client_inits(monkeypatch)
        tmp = Path("/tmp/test_download_session.html")
        result = await web_download("https://example.com", str(tmp), use_session=False)
        assert result["status"] == "downloaded"
        assert len(created) == 1

    async def test_download_with_session_uses_shared_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", True)
        created = _track_client_inits(monkeypatch)
        tmp = Path("/tmp/test_download_shared.html")
        result = await web_download("https://example.com", str(tmp), use_session=True)
        assert result["status"] == "downloaded"
        first_count = len(created)
        result2 = await web_download("https://example.com", str(tmp), use_session=True)
        assert result2["status"] == "downloaded"
        assert len(created) == first_count


class TestProxyConfig:
    def test_proxy_env_read(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.PROXY", "http://proxy.example.com:8080")
        from www_search_mcp import config
        assert config.PROXY == "http://proxy.example.com:8080"

    def test_proxy_env_empty(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.PROXY", None)
        from www_search_mcp import config
        assert config.PROXY is None


@pytest.mark.asyncio
class TestSessions:
    async def test_browser_context_created_with_session(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", True)
        monkeypatch.setattr("www_search_mcp.server.TIMEOUT", 60)
        result = await web_fetch_browser("https://example.com", use_session=True)
        assert result["status"] == "ok"
        from www_search_mcp import browser as b
        assert b._browser_context is not None

    async def test_browser_context_not_created_without_session(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", False)
        result = await web_fetch_browser("https://example.com", use_session=False)
        assert result["status"] == "ok"
        from www_search_mcp import browser as b
        assert b._browser_context is None

    async def test_session_param_overrides_env(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.server.SESSION_ENABLED", False)
        result = await web_fetch_browser("https://example.com", use_session=True)
        assert result["status"] == "ok"
        from www_search_mcp import browser as b
        assert b._browser_context is not None
