"""Tests for ``silly_kicks.spadl.utils.add_possessions`` (added in 1.2.0).

The helper assigns a per-match possession-sequence integer to each SPADL
action via a team-change-with-carve-outs heuristic (locked design 1.2.0):

  - Sort actions by ``(game_id, period_id, action_id)``.
  - Possession boundary on team change, EXCEPT a set-piece restart
    (``freekick_*``, ``corner_*``, ``throw_in``, ``goalkick``) following
    the opposing team's foul retains the previous possession (the team
    that won the foul resumes its sequence).
  - Possession boundary forced at period change (within a game) and at
    time gap >= ``max_gap_seconds`` regardless of team.
  - Counter resets to 0 at each new ``game_id``.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from silly_kicks.spadl import config as spadlconfig
from silly_kicks.spadl.utils import add_possessions

# ---------------------------------------------------------------------------
# Test fixture builder
# ---------------------------------------------------------------------------

_ACT = spadlconfig.actiontype_id
_RES = spadlconfig.result_id
_BP = spadlconfig.bodypart_id


def _make_action(
    *,
    action_id: int,
    game_id: int = 1,
    period_id: int = 1,
    time_seconds: float = 0.0,
    team_id: int = 100,
    player_id: int = 200,
    type_name: str = "pass",
    result_name: str = "success",
    bodypart_name: str = "foot",
    start_x: float = 50.0,
    start_y: float = 34.0,
    end_x: float = 60.0,
    end_y: float = 34.0,
    original_event_id: object = None,
) -> dict[str, object]:
    """Build a minimal valid SPADL action row."""
    return {
        "game_id": game_id,
        "original_event_id": str(action_id) if original_event_id is None else original_event_id,
        "action_id": action_id,
        "period_id": period_id,
        "time_seconds": time_seconds,
        "team_id": team_id,
        "player_id": player_id,
        "start_x": start_x,
        "start_y": start_y,
        "end_x": end_x,
        "end_y": end_y,
        "type_id": _ACT[type_name],
        "result_id": _RES[result_name],
        "bodypart_id": _BP[bodypart_name],
    }


def _df(rows: list[dict[str, object]]) -> pd.DataFrame:
    """Build a SPADL DataFrame from a list of action dicts."""
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Contract: shape + dtype + column preservation
# ---------------------------------------------------------------------------


class TestAddPossessionsContract:
    def test_returns_dataframe(self):
        actions = _df([_make_action(action_id=0)])
        result = add_possessions(actions)
        assert isinstance(result, pd.DataFrame)

    def test_adds_possession_id_column(self):
        actions = _df([_make_action(action_id=0)])
        result = add_possessions(actions)
        assert "possession_id" in result.columns

    def test_possession_id_dtype_is_int64(self):
        actions = _df([_make_action(action_id=0), _make_action(action_id=1, time_seconds=1.0)])
        result = add_possessions(actions)
        assert result["possession_id"].dtype == np.int64

    def test_preserves_all_input_columns(self):
        actions = _df([_make_action(action_id=0)])
        actions["custom_col"] = "preserved"
        result = add_possessions(actions)
        assert "custom_col" in result.columns
        assert list(result["custom_col"]) == ["preserved"]

    def test_empty_input_returns_empty_with_possession_id(self):
        actions = _df([_make_action(action_id=0)]).iloc[0:0]
        result = add_possessions(actions)
        assert "possession_id" in result.columns
        assert len(result) == 0

    def test_does_not_mutate_input(self):
        actions = _df([_make_action(action_id=0)])
        cols_before = list(actions.columns)
        add_possessions(actions)
        assert list(actions.columns) == cols_before, "input df should not be mutated"

    def test_returns_same_row_count(self):
        actions = _df([_make_action(action_id=i, time_seconds=float(i)) for i in range(10)])
        result = add_possessions(actions)
        assert len(result) == len(actions)


# ---------------------------------------------------------------------------
# Same team → same possession
# ---------------------------------------------------------------------------


class TestSameTeamSamePossession:
    def test_two_same_team_passes_share_possession_id(self):
        actions = _df(
            [
                _make_action(action_id=0, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, team_id=100, time_seconds=1.0),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[0] == result["possession_id"].iloc[1]

    def test_long_chain_same_team_one_possession(self):
        actions = _df([_make_action(action_id=i, team_id=100, time_seconds=float(i)) for i in range(20)])
        result = add_possessions(actions)
        assert result["possession_id"].nunique() == 1
        assert (result["possession_id"] == 0).all()


# ---------------------------------------------------------------------------
# Team change → new possession
# ---------------------------------------------------------------------------


class TestTeamChangeNewPossession:
    def test_team_change_increments_possession_id(self):
        # Pass by team A then pass by team B (no set-piece carve-out, no foul) → new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=100, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=200, time_seconds=1.0, type_name="pass"),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[0] == 0
        assert result["possession_id"].iloc[1] == 1

    def test_alternating_teams_unique_possession_ids(self):
        actions = _df([_make_action(action_id=i, team_id=100 + (i % 2) * 100, time_seconds=float(i)) for i in range(6)])
        result = add_possessions(actions)
        # 6 alternating actions → 6 unique possession_ids 0..5
        assert list(result["possession_id"]) == [0, 1, 2, 3, 4, 5]


# ---------------------------------------------------------------------------
# Period change within game → new possession (counter increments, no reset)
# ---------------------------------------------------------------------------


class TestPeriodChange:
    def test_period_change_within_game_increments_counter(self):
        # Same team, new period → still new possession (period restart is a possession boundary).
        actions = _df(
            [
                _make_action(action_id=0, period_id=1, team_id=100, time_seconds=2700.0),
                _make_action(action_id=1, period_id=2, team_id=100, time_seconds=0.0),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[0] == 0
        assert result["possession_id"].iloc[1] == 1, "period change should start a new possession"

    def test_period_does_not_reset_counter(self):
        # Three possessions in period 1, then period 2 → period 2 starts at possession_id=3, not 0.
        actions = _df(
            [
                _make_action(action_id=0, period_id=1, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, period_id=1, team_id=200, time_seconds=1.0),
                _make_action(action_id=2, period_id=1, team_id=100, time_seconds=2.0),
                _make_action(action_id=3, period_id=2, team_id=100, time_seconds=0.0),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 2  # third possession
        assert result["possession_id"].iloc[3] == 3  # period 2 → new possession, counter continues


# ---------------------------------------------------------------------------
# Game change → counter resets to 0
# ---------------------------------------------------------------------------


class TestGameChange:
    def test_game_change_resets_counter_to_zero(self):
        actions = _df(
            [
                _make_action(action_id=0, game_id=1, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, game_id=1, team_id=200, time_seconds=1.0),
                _make_action(action_id=0, game_id=2, team_id=100, time_seconds=0.0),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 0, "new game must reset counter"

    def test_multi_game_counter_independent(self):
        # Game 1: 2 alternating possessions. Game 2: 1 possession. Counter independent per game.
        actions = _df(
            [
                _make_action(action_id=0, game_id=1, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, game_id=1, team_id=200, time_seconds=1.0),
                _make_action(action_id=0, game_id=2, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, game_id=2, team_id=100, time_seconds=1.0),
            ]
        )
        result = add_possessions(actions)
        per_game = result.groupby("game_id")["possession_id"].agg(["min", "max"])
        assert per_game.loc[1, "min"] == 0
        assert per_game.loc[1, "max"] == 1
        assert per_game.loc[2, "min"] == 0
        assert per_game.loc[2, "max"] == 0


# ---------------------------------------------------------------------------
# Time gap → new possession even if same team
# ---------------------------------------------------------------------------


class TestMaxGapTimeout:
    def test_long_gap_starts_new_possession_same_team(self):
        # Same team but >5s gap → still new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, team_id=100, time_seconds=10.0),  # 10s gap
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[0] == 0
        assert result["possession_id"].iloc[1] == 1

    def test_default_5s_threshold_just_under_keeps_possession(self):
        # 4.9s gap < 5.0s default → same possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, team_id=100, time_seconds=4.9),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[0] == result["possession_id"].iloc[1]

    def test_custom_max_gap_seconds(self):
        # Custom 1.0s threshold → 1.5s gap triggers new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, team_id=100, time_seconds=1.5),
            ]
        )
        result = add_possessions(actions, max_gap_seconds=1.0)
        assert result["possession_id"].iloc[0] != result["possession_id"].iloc[1]


# ---------------------------------------------------------------------------
# Set-piece carve-out — foul → opposing-team set-piece retains possession
# ---------------------------------------------------------------------------


class TestSetPieceCarveOut:
    def test_freekick_after_opposing_foul_retains_possession(self):
        # Pass by team B (possession 0), foul by team A (still possession 0 — same team change rule
        # would say new possession but it's still the same SPADL-level possession we're tracking),
        # free kick by team B (carve-out: same possession as before the foul).
        # Actually with team change A->B and current team B taking free kick → carve-out triggers.
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(
                    action_id=2,
                    team_id=200,
                    time_seconds=2.0,
                    type_name="freekick_short",
                ),
            ]
        )
        result = add_possessions(actions)
        # action 0: pass by team B, possession 0
        # action 1: foul by team A — team change → new possession 1
        # action 2: free kick by team B — team change BUT carve-out applies (prev was foul by other team)
        #   → SAME possession as action 1 (possession 1, NOT new possession 2)
        assert result["possession_id"].iloc[0] == 0
        assert result["possession_id"].iloc[1] == 1
        assert result["possession_id"].iloc[2] == 1, (
            "free kick after opposing-team foul should retain the previous possession"
        )

    def test_carve_out_disabled(self):
        # Same scenario but retain_on_set_pieces=False → free kick is a new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(action_id=2, team_id=200, time_seconds=2.0, type_name="freekick_short"),
            ]
        )
        result = add_possessions(actions, retain_on_set_pieces=False)
        # All three possessions distinct.
        assert result["possession_id"].iloc[2] == 2, "carve-out disabled → free kick is new possession"

    def test_corner_after_opposing_clearance_does_not_retain(self):
        # Clearance != foul → carve-out does NOT apply → new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="clearance"),
                _make_action(action_id=2, team_id=200, time_seconds=2.0, type_name="corner_short"),
            ]
        )
        result = add_possessions(actions)
        # Clearance is not a foul → no carve-out → corner is a new possession.
        assert result["possession_id"].iloc[1] == 1
        assert result["possession_id"].iloc[2] == 2

    def test_throw_in_after_foul_retains(self):
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(action_id=2, team_id=200, time_seconds=2.0, type_name="throw_in"),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 1

    def test_goalkick_after_foul_retains(self):
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(action_id=2, team_id=200, time_seconds=2.0, type_name="goalkick"),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 1

    def test_carve_out_does_not_apply_to_normal_pass(self):
        # If current action is a regular pass (not a set piece), team change → new possession even after foul.
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(action_id=2, team_id=200, time_seconds=2.0, type_name="pass"),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 2, "regular pass is not a set-piece restart"


# ---------------------------------------------------------------------------
# Monotonicity invariants
# ---------------------------------------------------------------------------


class TestMonotonic:
    def test_possession_id_monotonic_within_game(self):
        # Build a 30-action mixed sequence; possession_id must be monotonic non-decreasing within game.
        rng = np.random.default_rng(42)
        rows = []
        teams = [100, 200]
        for i in range(30):
            team = int(teams[rng.integers(0, 2)])
            rows.append(_make_action(action_id=i, team_id=team, time_seconds=float(i), type_name="pass"))
        actions = _df(rows)
        result = add_possessions(actions)
        # Possession IDs must be monotonic non-decreasing within each game when sorted.
        ids = result.sort_values(["game_id", "period_id", "action_id"])["possession_id"].to_numpy()
        diffs = np.diff(ids)
        assert (diffs >= 0).all(), f"possession_id must be non-decreasing within game; got diffs {diffs}"

    def test_possession_id_starts_at_zero_per_game(self):
        actions = _df(
            [
                _make_action(action_id=0, game_id=1, team_id=100, time_seconds=0.0),
                _make_action(action_id=0, game_id=2, team_id=200, time_seconds=0.0),
            ]
        )
        result = add_possessions(actions)
        per_game_first = (
            result.sort_values(["game_id", "period_id", "action_id"]).groupby("game_id")["possession_id"].first()
        )
        assert per_game_first.loc[1] == 0
        assert per_game_first.loc[2] == 0


# ---------------------------------------------------------------------------
# Combined scenarios — boundary interactions
# ---------------------------------------------------------------------------


class TestCombinedBoundaries:
    def test_period_change_overrides_set_piece_carve_out(self):
        # Foul at end of period 1, free kick at start of period 2 → period change forces new possession
        # regardless of carve-out.
        actions = _df(
            [
                _make_action(
                    action_id=0,
                    period_id=1,
                    team_id=100,
                    time_seconds=2700.0,
                    type_name="foul",
                    result_name="fail",
                ),
                _make_action(action_id=1, period_id=2, team_id=200, time_seconds=0.0, type_name="freekick_short"),
            ]
        )
        result = add_possessions(actions)
        # Period change forces increment regardless of carve-out — they yield the same answer here
        # but the design intent is that period change wins.
        assert result["possession_id"].iloc[0] == 0
        assert result["possession_id"].iloc[1] == 1

    def test_long_gap_overrides_set_piece_carve_out(self):
        # >5s gap between foul and free kick → long-gap rule forces new possession.
        actions = _df(
            [
                _make_action(action_id=0, team_id=200, time_seconds=0.0, type_name="pass"),
                _make_action(action_id=1, team_id=100, time_seconds=1.0, type_name="foul", result_name="fail"),
                _make_action(action_id=2, team_id=200, time_seconds=10.0, type_name="freekick_short"),
            ]
        )
        result = add_possessions(actions)
        assert result["possession_id"].iloc[2] == 2, "long gap should force new possession"


# ---------------------------------------------------------------------------
# Sort order — input not pre-sorted
# ---------------------------------------------------------------------------


class TestSortOrder:
    def test_unsorted_input_is_sorted_internally(self):
        # Provide actions in reverse order; result should still be canonical.
        actions = _df(
            [
                _make_action(action_id=2, team_id=200, time_seconds=2.0),
                _make_action(action_id=0, team_id=100, time_seconds=0.0),
                _make_action(action_id=1, team_id=100, time_seconds=1.0),
            ]
        )
        result = add_possessions(actions).sort_values("action_id").reset_index(drop=True)
        # Action 0 and 1 are same team → same possession
        # Action 2 is different team → new possession
        assert result["possession_id"].iloc[0] == result["possession_id"].iloc[1]
        assert result["possession_id"].iloc[2] != result["possession_id"].iloc[0]


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


class TestErrors:
    def test_missing_required_column_raises(self):
        # Drop game_id — required for the algorithm.
        actions = _df([_make_action(action_id=0)]).drop(columns=["game_id"])
        with pytest.raises(ValueError, match=r"missing|required"):
            add_possessions(actions)

    def test_negative_max_gap_seconds_raises(self):
        actions = _df([_make_action(action_id=0)])
        with pytest.raises(ValueError, match="max_gap_seconds"):
            add_possessions(actions, max_gap_seconds=-1.0)


# ---------------------------------------------------------------------------
# Helpers — boundary-F1 metric for end-to-end validation
# ---------------------------------------------------------------------------


def _boundary_f1(heuristic: pd.Series, native: pd.Series) -> float:
    """F1 score on possession boundaries (where the id changes between consecutive rows).

    Boundaries are invariant under counter relabeling, so the heuristic's
    possession_id (0-indexed) and the provider's native possession_id
    (whatever offset) compare directly on where they emit a boundary.

    Returns 0.0 when no boundaries exist in either series (degenerate input).
    """
    h_changes = heuristic.ne(heuristic.shift(1)).iloc[1:].to_numpy()
    n_changes = native.ne(native.shift(1)).iloc[1:].to_numpy()

    tp = int((h_changes & n_changes).sum())
    fp = int((h_changes & ~n_changes).sum())
    fn = int((~h_changes & n_changes).sum())

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ---------------------------------------------------------------------------
# End-to-end: heuristic vs StatsBomb native possession_id (requires fixtures)
# ---------------------------------------------------------------------------


@pytest.mark.e2e
class TestBoundaryF1AgainstStatsBombNative:
    """Validate the heuristic against StatsBomb's native possession_id.

    Requires raw StatsBomb event JSON committed at
    ``tests/datasets/statsbomb/raw/events/<MATCH_ID>.json`` — these are
    e2e fixtures not committed to the repo. Skips when absent.

    Procedure (also useful as documentation for downstream consumers
    running this validation against their own StatsBomb data):

    1. Load raw StatsBomb events with the top-level ``possession`` field.
    2. Convert via ``statsbomb.convert_to_actions(events, ...,
       preserve_native=['possession'])``.
    3. Run ``add_possessions(actions)`` to produce the heuristic
       ``possession_id`` column alongside the native ``possession``.
    4. Compute boundary-F1 between the two on the same action stream.

    Published heuristic baselines for similar team-change-with-carve-outs
    approaches sit in the 0.85-0.95 boundary-F1 range vs StatsBomb's
    proprietary possession assignment.
    """

    def test_boundary_f1_against_native_possession_id(self):
        import json
        import os

        fixture_path = os.path.join(
            os.path.dirname(__file__), "..", "datasets", "statsbomb", "raw", "events", "7584.json"
        )
        if not os.path.exists(fixture_path):
            pytest.skip(f"Raw StatsBomb fixture not found at {fixture_path}")

        from silly_kicks.spadl import statsbomb

        with open(fixture_path, encoding="utf-8") as f:
            events_raw = json.load(f)

        # Adapter: StatsBomb open data top-level keys → silly-kicks EXPECTED_INPUT_COLUMNS.
        _top_level_keys = {"id", "period", "timestamp", "team", "player", "type", "location"}
        adapted = pd.DataFrame(
            [
                {
                    "game_id": 7584,
                    "event_id": e.get("id"),
                    "period_id": e.get("period"),
                    "timestamp": e.get("timestamp"),
                    "team_id": (e.get("team") or {}).get("id"),
                    "player_id": (e.get("player") or {}).get("id"),
                    "type_name": (e.get("type") or {}).get("name"),
                    "location": e.get("location"),
                    "extra": {k: v for k, v in e.items() if k not in _top_level_keys},
                    # preserve_native target: top-level possession sequence number.
                    "possession": e.get("possession"),
                }
                for e in events_raw
            ]
        )

        actions, _report = statsbomb.convert_to_actions(
            adapted,
            home_team_id=int(adapted["team_id"].iloc[0]),
            preserve_native=["possession"],
        )

        # Drop synthetic dribbles (NaN original_event_id → no native possession to compare against).
        non_synthetic = actions[actions["possession"].notna()].copy()
        non_synthetic = add_possessions(non_synthetic)

        f1 = _boundary_f1(non_synthetic["possession_id"], non_synthetic["possession"].astype(np.int64))
        # Defensible baseline from published team-change-with-carve-outs literature.
        # Refine threshold to (observed - 0.02) once measured locally on this fixture.
        assert f1 >= 0.80, f"boundary-F1 {f1:.4f} below 0.80 baseline"
