"""Implements a converter for regular SPADL actions to atomic actions."""

import pandas as pd

import silly_kicks.spadl.config as _spadl
from silly_kicks.spadl.base import _add_dribbles
from silly_kicks.spadl.utils import _finalize_output

from . import config as _atomicspadl
from .schema import ATOMIC_SPADL_COLUMNS


def convert_to_atomic(actions: pd.DataFrame) -> pd.DataFrame:
    """Convert regular SPADL actions to atomic actions.

    Parameters
    ----------
    actions : pd.DataFrame
        A SPADL dataframe.

    Returns
    -------
    pd.DataFrame
        The Atomic-SPADL dataframe.
    """
    atomic_actions = actions.copy()
    # Compute all extras from the original actions
    pass_extras = _compute_pass_extras(atomic_actions)
    shot_extras = _compute_shot_extras(atomic_actions)
    foul_extras = _compute_foul_extras(atomic_actions)
    # Single concat + sort + renumber
    atomic_actions = pd.concat(
        [atomic_actions, pass_extras, shot_extras, foul_extras],
        ignore_index=True,
        sort=False,
    )
    atomic_actions = atomic_actions.sort_values(["game_id", "period_id", "action_id"]).reset_index(drop=True)
    atomic_actions["action_id"] = range(len(atomic_actions))
    # Add dribbles (needs correct order)
    atomic_actions = _add_dribbles(atomic_actions)
    atomic_actions = _convert_columns(atomic_actions)
    atomic_actions = _simplify(atomic_actions)
    return _finalize_output(atomic_actions, ATOMIC_SPADL_COLUMNS)


def _compute_pass_extras(actions: pd.DataFrame) -> pd.DataFrame:
    """Compute receival/interception/out/offside extras for pass-like actions."""
    next_actions = actions.shift(-1)
    same_team = actions.team_id == next_actions.team_id

    passlike = [
        "pass",
        "cross",
        "throw_in",
        "freekick_short",
        "freekick_crossed",
        "corner_crossed",
        "corner_short",
        "clearance",
        "goalkick",
    ]
    pass_ids = [_spadl.actiontype_id[ty] for ty in passlike]

    interceptionlike = [
        "interception",
        "tackle",
        "keeper_punch",
        "keeper_save",
        "keeper_claim",
        "keeper_pick_up",
    ]
    interception_ids = [_spadl.actiontype_id[ty] for ty in interceptionlike]

    samegame = actions.game_id == next_actions.game_id
    sameperiod = actions.period_id == next_actions.period_id
    # samephase = next_actions.time_seconds - actions.time_seconds < max_pass_duration
    extra_idx = (
        actions.type_id.isin(pass_ids)
        & samegame
        & sameperiod  # & samephase
        & ~next_actions.type_id.isin(interception_ids)
    )

    prev = actions[extra_idx]
    nex = next_actions[extra_idx]

    extra = pd.DataFrame()
    extra["game_id"] = prev.game_id
    extra["original_event_id"] = prev.original_event_id
    extra["period_id"] = prev.period_id
    extra["action_id"] = prev.action_id + 0.1
    extra["time_seconds"] = (prev.time_seconds + nex.time_seconds) / 2
    extra["start_x"] = prev.end_x
    extra["start_y"] = prev.end_y
    extra["end_x"] = prev.end_x
    extra["end_y"] = prev.end_y
    extra["bodypart_id"] = _atomicspadl.bodypart_id["foot"]
    extra["result_id"] = -1

    offside = prev.result_id == _spadl.result_id["offside"]
    out = ((nex.type_id == _atomicspadl.actiontype_id["goalkick"]) & (~same_team)) | (
        nex.type_id == _atomicspadl.actiontype_id["throw_in"]
    )
    ar = _atomicspadl.actiontype_id
    extra["type_id"] = -1
    extra["type_id"] = (
        extra.type_id.mask(same_team, ar["receival"])
        .mask(~same_team, ar["interception"])
        .mask(out, ar["out"])
        .mask(offside, ar["offside"])
    )
    is_interception = extra["type_id"] == ar["interception"]
    extra["team_id"] = prev.team_id.mask(is_interception, nex.team_id)
    extra["player_id"] = nex.player_id.mask(out | offside, prev.player_id).astype(prev.player_id.dtype)

    return extra


def _compute_shot_extras(actions: pd.DataFrame) -> pd.DataFrame:
    """Compute goal/owngoal/out extras for shot-like actions."""
    next_actions = actions.shift(-1)

    shotlike = ["shot", "shot_freekick", "shot_penalty"]
    shot_ids = [_spadl.actiontype_id[ty] for ty in shotlike]

    samegame = actions.game_id == next_actions.game_id
    sameperiod = actions.period_id == next_actions.period_id

    shot = actions.type_id.isin(shot_ids)
    goal = shot & (actions.result_id == _spadl.result_id["success"])
    owngoal = actions.result_id == _spadl.result_id["owngoal"]
    next_corner_goalkick = next_actions.type_id.isin(
        [
            _atomicspadl.actiontype_id["corner_crossed"],
            _atomicspadl.actiontype_id["corner_short"],
            _atomicspadl.actiontype_id["goalkick"],
        ]
    )
    next_type = next_actions.type_id
    keeper_types = {
        _spadl.actiontype_id["keeper_save"],
        _spadl.actiontype_id["keeper_claim"],
        _spadl.actiontype_id["keeper_punch"],
        _spadl.actiontype_id["keeper_pick_up"],
    }
    next_keeper = next_type.isin(keeper_types)
    out = shot & (next_corner_goalkick | next_keeper) & samegame & sameperiod

    extra_idx = goal | owngoal | out
    prev = actions[extra_idx]

    extra = pd.DataFrame()
    extra["game_id"] = prev.game_id
    extra["original_event_id"] = prev.original_event_id
    extra["period_id"] = prev.period_id
    extra["action_id"] = prev.action_id + 0.1
    extra["time_seconds"] = prev.time_seconds  # + nex.time_seconds) / 2
    extra["start_x"] = prev.end_x
    extra["start_y"] = prev.end_y
    extra["end_x"] = prev.end_x
    extra["end_y"] = prev.end_y
    extra["bodypart_id"] = prev.bodypart_id
    extra["result_id"] = -1
    extra["team_id"] = prev.team_id
    extra["player_id"] = prev.player_id

    ar = _atomicspadl.actiontype_id
    extra["type_id"] = -1
    extra["type_id"] = extra.type_id.mask(out, ar["out"]).mask(goal, ar["goal"]).mask(owngoal, ar["owngoal"])

    return extra


def _compute_foul_extras(actions: pd.DataFrame) -> pd.DataFrame:
    """Compute yellow_card/red_card extras for foul actions."""
    yellow = actions.result_id == _spadl.result_id["yellow_card"]
    red = actions.result_id == _spadl.result_id["red_card"]

    prev = actions[yellow | red]
    extra = pd.DataFrame()
    extra["game_id"] = prev.game_id
    extra["original_event_id"] = prev.original_event_id
    extra["period_id"] = prev.period_id
    extra["action_id"] = prev.action_id + 0.1
    extra["time_seconds"] = prev.time_seconds  # + nex.time_seconds) / 2
    extra["start_x"] = prev.end_x
    extra["start_y"] = prev.end_y
    extra["end_x"] = prev.end_x
    extra["end_y"] = prev.end_y
    extra["bodypart_id"] = prev.bodypart_id
    extra["result_id"] = -1
    extra["team_id"] = prev.team_id
    extra["player_id"] = prev.player_id

    ar = _atomicspadl.actiontype_id
    extra["type_id"] = -1
    extra["type_id"] = extra.type_id.mask(yellow, ar["yellow_card"]).mask(red, ar["red_card"])

    return extra


def _convert_columns(actions: pd.DataFrame) -> pd.DataFrame:
    actions["x"] = actions.start_x
    actions["y"] = actions.start_y
    actions["dx"] = actions.end_x - actions.start_x
    actions["dy"] = actions.end_y - actions.start_y
    return actions[  # type: ignore[reportReturnType]
        [
            "game_id",
            "original_event_id",
            "action_id",
            "period_id",
            "time_seconds",
            "team_id",
            "player_id",
            "x",
            "y",
            "dx",
            "dy",
            "type_id",
            "bodypart_id",
        ]
    ]


def _simplify(actions: pd.DataFrame) -> pd.DataFrame:
    a = actions
    ar = _atomicspadl.actiontype_id

    cornerlike = ["corner_crossed", "corner_short"]
    corner_ids = [_spadl.actiontype_id[ty] for ty in cornerlike]

    freekicklike = ["freekick_crossed", "freekick_short", "shot_freekick"]
    freekick_ids = [_spadl.actiontype_id[ty] for ty in freekicklike]

    a["type_id"] = a.type_id.mask(a.type_id.isin(corner_ids), ar["corner"])
    a["type_id"] = a.type_id.mask(a.type_id.isin(freekick_ids), ar["freekick"])
    return a
