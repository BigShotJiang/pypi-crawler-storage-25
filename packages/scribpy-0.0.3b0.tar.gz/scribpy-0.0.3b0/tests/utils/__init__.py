"""Tests for scribpy.utils."""
