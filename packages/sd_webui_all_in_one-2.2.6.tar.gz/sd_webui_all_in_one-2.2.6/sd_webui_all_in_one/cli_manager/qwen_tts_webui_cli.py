"""Qwen TTS WebUI 命令行工具"""

import argparse
import shlex
import sys
import traceback
from pathlib import Path

from sd_webui_all_in_one.base_manager import (
    install_qwen_tts_webui,
    update_qwen_tts_webui,
    check_qwen_tts_webui_env,
    launch_qwen_tts_webui,
    launch_qwen_tts_webui_version_gui,
    reinstall_pytorch,
)
from sd_webui_all_in_one.config import (
    QWEN_TTS_WEBUI_ROOT_PATH,
    SD_WEBUI_ALL_IN_ONE_RAISE_WEBUI_RUNTIME_ERROR,
    SD_WEBUI_ALL_IN_ONE_RAISE_CHECK_ENV_ERROR_ON_LAUNCH,
    LOGGER_NAME,
    LOGGER_LEVEL,
    LOGGER_COLOR,
)
from sd_webui_all_in_one.model_downloader import (
    MODEL_DOWNLOAD_URL_TYPE_LIST,
    ModelDownloadUrlType,
)
from sd_webui_all_in_one.pytorch_manager import (
    PYTORCH_DEVICE_LIST,
    PyTorchDeviceType,
)
from sd_webui_all_in_one.utils import normalized_filepath
from sd_webui_all_in_one.custom_exceptions import WebUiRuntimeError
from sd_webui_all_in_one.logger import get_logger

logger = get_logger(
    name=LOGGER_NAME,
    level=LOGGER_LEVEL,
    color=LOGGER_COLOR,
)


def install(
    qwen_tts_webui_path: Path,
    pytorch_mirror_type: PyTorchDeviceType | None = None,
    custom_pytorch_package: str | None = None,
    custom_xformers_package: str | None = None,
    use_pypi_mirror: bool | None = True,
    use_uv: bool | None = True,
    use_github_mirror: bool | None = False,
    custom_github_mirror: str | list[str] | None = None,
    model_download_resource_type: ModelDownloadUrlType | None = "modelscope",
) -> None:
    """安装 Qwen TTS WebUI

    Args:
        qwen_tts_webui_path (Path):
            Qwen TTS WebUI 根目录
        pytorch_mirror_type (PyTorchDeviceType | None):
            设置使用的 PyTorch 镜像源类型
        custom_pytorch_package (str | None):
            自定义 PyTorch 软件包版本声明, 例如: `torch==2.3.0+cu118 torchvision==0.18.0+cu118`
        custom_xformers_package (str | None):
            自定义 xFormers 软件包版本声明, 例如: `xformers===0.0.26.post1+cu118`
        use_pypi_mirror (bool | None):
            是否使用国内 PyPI 镜像源
        use_uv (bool | None):
            是否使用 uv 安装 Python 软件包
        use_github_mirror (bool | None):
            是否使用 Github 镜像源
        custom_github_mirror (str | list[str] | None):
            自定义 Github 镜像源
        model_download_resource_type (ModelDownloadUrlType | None):
            默认配置资源来源
    """
    install_qwen_tts_webui(
        qwen_tts_webui_path=qwen_tts_webui_path,
        pytorch_mirror_type=pytorch_mirror_type,
        custom_pytorch_package=custom_pytorch_package,
        custom_xformers_package=custom_xformers_package,
        use_pypi_mirror=use_pypi_mirror,
        use_uv=use_uv,
        use_github_mirror=use_github_mirror,
        custom_github_mirror=custom_github_mirror,
        model_download_resource_type=model_download_resource_type,
    )


def update(
    qwen_tts_webui_path: Path,
    use_github_mirror: bool | None = False,
    custom_github_mirror: str | list[str] | None = None,
) -> None:
    """更新 Qwen TTS WebUI

    Args:
        qwen_tts_webui_path (Path):
            Qwen TTS WebUI 根目录
        use_github_mirror (bool | None):
            是否使用 Github 镜像源
        custom_github_mirror (str | list[str] | None):
            自定义 Github 镜像源
    """
    update_qwen_tts_webui(
        qwen_tts_webui_path=qwen_tts_webui_path,
        use_github_mirror=use_github_mirror,
        custom_github_mirror=custom_github_mirror,
    )


def check_env(
    qwen_tts_webui_path: Path,
    use_uv: bool | None = True,
    use_pypi_mirror: bool | None = False,
    use_github_mirror: bool | None = False,
    custom_github_mirror: str | list[str] | None = None,
) -> None:
    """检查 Qwen TTS WebUI 运行环境

    Args:
        qwen_tts_webui_path (Path):
            Qwen TTS WebUI 根目录
        use_uv (bool | None):
            是否使用 uv 安装 Python 软件包
        use_pypi_mirror (bool | None):
            是否使用国内 PyPI 镜像源
        use_github_mirror (bool | None):
            是否使用 Github 镜像源
        custom_github_mirror (str | list[str] | None):
            自定义 Github 镜像源
    """
    check_qwen_tts_webui_env(
        qwen_tts_webui_path=qwen_tts_webui_path,
        use_uv=use_uv,
        use_pypi_mirror=use_pypi_mirror,
        use_github_mirror=use_github_mirror,
        custom_github_mirror=custom_github_mirror,
    )


def launch(
    qwen_tts_webui_path: Path,
    launch_args: list[str] | None = None,
    use_hf_mirror: bool | None = False,
    custom_hf_mirror: str | list[str] | None = None,
    use_github_mirror: bool | None = False,
    custom_github_mirror: str | list[str] | None = None,
    use_pypi_mirror: bool | None = False,
    use_cuda_malloc: bool | None = True,
    use_uv: bool | None = True,
    check_launch_env: bool | None = True,
    enable_hotpatcher: bool | None = False,
    hotpatcher_config_path: str | Path | None = None,
    hotpatcher_port: int | None = None,
    enable_hotpatcher_runtime: bool | None = False,
) -> None:
    """启动 Qwen TTS WebUI

    Args:
        qwen_tts_webui_path (Path):
            Qwen TTS WebUI 根目录
        launch_args (list[str] | None):
            启动 Qwen TTS WebUI 的参数
        use_hf_mirror (bool | None):
            是否启用 HuggingFace 镜像源
        custom_hf_mirror (str | list[str] | None):
            自定义 HuggingFace 镜像源
        use_github_mirror (bool | None):
            是否启用 Github 镜像源
        custom_github_mirror (str | list[str] | None):
            自定义 Github 镜像源
        use_pypi_mirror (bool | None):
            是否启用 PyPI 镜像源
        use_cuda_malloc (bool | None):
            是否启用 CUDA Malloc 显存优化
        use_uv (bool | None):
            是否使用 uv 安装 Python 软件包
        check_launch_env (bool | None):
            是否在启动前检查运行环境
        enable_hotpatcher (bool | None):
            是否启用补丁系统注入
        hotpatcher_config_path (str | Path | None):
            补丁系统配置文件路径
        hotpatcher_port (int | None):
            补丁系统 runtime 通信端口
        enable_hotpatcher_runtime (bool | None):
            是否启用补丁系统 runtime host 连接
    """
    if check_launch_env:
        try:
            check_qwen_tts_webui_env(
                qwen_tts_webui_path=qwen_tts_webui_path,
                use_uv=use_uv,
                use_pypi_mirror=use_pypi_mirror,
                use_github_mirror=use_github_mirror,
                custom_github_mirror=custom_github_mirror,
            )
        except Exception as e:
            if SD_WEBUI_ALL_IN_ONE_RAISE_CHECK_ENV_ERROR_ON_LAUNCH:
                raise e

            traceback.print_exc()
            logger.error("检查 Qwen TTS WebUI 运行环境时发生了错误: %s", e)
            logger.warning("该问题并非致命, 但这可能会导致 Qwen TTS WebUI 运行时发生问题")

    if isinstance(launch_args, str):
        launch_args = shlex.split(launch_args)
    elif launch_args is None:
        launch_args = []

    try:
        launch_qwen_tts_webui(
            qwen_tts_webui_path=qwen_tts_webui_path,
            launch_args=launch_args,
            use_hf_mirror=use_hf_mirror,
            custom_hf_mirror=custom_hf_mirror,
            use_github_mirror=use_github_mirror,
            custom_github_mirror=custom_github_mirror,
            use_pypi_mirror=use_pypi_mirror,
            use_cuda_malloc=use_cuda_malloc,
            enable_hotpatcher=enable_hotpatcher,
            hotpatcher_config_path=hotpatcher_config_path,
            hotpatcher_port=hotpatcher_port,
            enable_hotpatcher_runtime=enable_hotpatcher_runtime,
        )
    except WebUiRuntimeError as e:
        if SD_WEBUI_ALL_IN_ONE_RAISE_WEBUI_RUNTIME_ERROR:
            raise e

        logger.error("运行 Qwen TTS WebUI 时异常退出: %s", e)
        sys.exit(1)


def launch_version_gui(
    qwen_tts_webui_path: Path,
    use_github_mirror: bool | None = False,
    custom_github_mirror: str | list[str] | None = None,
) -> None:
    """启动 Qwen TTS WebUI 版本管理 GUI"""
    launch_qwen_tts_webui_version_gui(
        qwen_tts_webui_path=qwen_tts_webui_path,
        use_github_mirror=use_github_mirror,
        custom_github_mirror=custom_github_mirror,
    )


def register_qwen_tts_webui(
    subparsers: "argparse._SubParsersAction",
) -> None:
    """注册 Qwen TTS WebUI 模块及其子命令

    Args:
        subparsers (argparse._SubParsersAction):
            子命令行解析器
    """
    qwen_tts_webui_parser: argparse.ArgumentParser = subparsers.add_parser("qwen-tts-webui", help="Qwen TTS WebUI 相关命令")
    qwen_tts_webui_sub = qwen_tts_webui_parser.add_subparsers(dest="qwen_tts_webui_action", required=True)

    # reinstall-pytorch
    reinstall_pytorch_p = qwen_tts_webui_sub.add_parser("reinstall-pytorch", help="重装 PyTorch")
    reinstall_pytorch_p.add_argument("--name", type=str, dest="name", help="PyTorch 版本组合名称")
    reinstall_pytorch_p.add_argument("--index", type=int, dest="index", help="PyTorch 版本组合索引值")
    reinstall_pytorch_p.add_argument("--no-pypi-mirror", action="store_false", dest="use_pypi_mirror", help="不使用国内 PyPI 镜像源")
    reinstall_pytorch_p.add_argument("--no-uv", action="store_false", dest="use_uv", help="不使用 uv 安装 PyTorch 软件包")
    reinstall_pytorch_p.add_argument("--interactive", action="store_true", dest="interactive_mode", help="启用交互模式")
    reinstall_pytorch_p.add_argument("--list-only", action="store_true", dest="list_only", help="列出 PyTorch 列表并退出")
    reinstall_pytorch_p.add_argument("--force-reinstall", action="store_true", dest="force_reinstall", help="强制重装 PyTorch")
    reinstall_pytorch_p.set_defaults(
        func=lambda args: reinstall_pytorch(
            pytorch_name=args.name,
            pytorch_index=args.index,
            use_pypi_mirror=args.use_pypi_mirror,
            use_uv=args.use_uv,
            interactive_mode=args.interactive_mode,
            list_only=args.list_only,
            force_reinstall=args.force_reinstall,
        )
    )

    # install
    install_p = qwen_tts_webui_sub.add_parser("install", help="安装 Qwen TTS WebUI")
    install_p.add_argument("--qwen-tts-webui-path", type=normalized_filepath, required=False, default=QWEN_TTS_WEBUI_ROOT_PATH, dest="qwen_tts_webui_path", help="Qwen TTS WebUI 根目录")
    install_p.add_argument("--pytorch-mirror-type", type=str, dest="pytorch_mirror_type", choices=PYTORCH_DEVICE_LIST, help="PyTorch 镜像源类型")
    install_p.add_argument("--custom-pytorch-package", type=str, dest="custom_pytorch_package", help="自定义 PyTorch 软件包版本声明")
    install_p.add_argument("--custom-xformers-package", type=str, dest="custom_xformers_package", help="自定义 xFormers 软件包版本声明")
    install_p.add_argument("--no-pypi-mirror", action="store_false", dest="use_pypi_mirror", help="不使用国内 PyPI 镜像源")
    install_p.add_argument("--no-uv", action="store_false", dest="use_uv", help="不使用 uv 安装 Python 软件包")
    install_p.add_argument("--no-github-mirror", action="store_false", dest="use_github_mirror", help="不使用 Github 镜像源")
    install_p.add_argument("--custom-github-mirror", type=str, dest="custom_github_mirror", help="自定义 Github 镜像源")
    install_p.add_argument("--model-resource", default="modelscope", dest="model_download_resource_type", choices=MODEL_DOWNLOAD_URL_TYPE_LIST, help="默认配置资源来源")
    install_p.set_defaults(
        func=lambda args: install(
            qwen_tts_webui_path=args.qwen_tts_webui_path,
            pytorch_mirror_type=args.pytorch_mirror_type,
            custom_pytorch_package=args.custom_pytorch_package,
            custom_xformers_package=args.custom_xformers_package,
            use_pypi_mirror=args.use_pypi_mirror,
            use_uv=args.use_uv,
            use_github_mirror=args.use_github_mirror,
            custom_github_mirror=args.custom_github_mirror,
            model_download_resource_type=args.model_download_resource_type,
        )
    )

    # update
    update_p = qwen_tts_webui_sub.add_parser("update", help="更新 Qwen TTS WebUI")
    update_p.add_argument("--qwen-tts-webui-path", type=normalized_filepath, required=False, default=QWEN_TTS_WEBUI_ROOT_PATH, dest="qwen_tts_webui_path", help="Qwen TTS WebUI 根目录")
    update_p.add_argument("--no-github-mirror", action="store_false", dest="use_github_mirror", help="不使用 Github 镜像源")
    update_p.add_argument("--custom-github-mirror", type=str, dest="custom_github_mirror", help="自定义 Github 镜像源")
    update_p.set_defaults(
        func=lambda args: update(
            qwen_tts_webui_path=args.qwen_tts_webui_path,
            use_github_mirror=args.use_github_mirror,
            custom_github_mirror=args.custom_github_mirror,
        )
    )

    # check-env
    check_p = qwen_tts_webui_sub.add_parser("check-env", help="检查 Qwen TTS WebUI 运行环境")
    check_p.add_argument("--qwen-tts-webui-path", type=normalized_filepath, required=False, default=QWEN_TTS_WEBUI_ROOT_PATH, dest="qwen_tts_webui_path", help="Qwen TTS WebUI 根目录")
    check_p.add_argument("--no-uv", action="store_false", dest="use_uv", help="不使用 uv")
    check_p.add_argument("--no-pypi-mirror", action="store_false", dest="use_pypi_mirror", help="不使用国内 PyPI 镜像源")
    check_p.add_argument("--no-github-mirror", action="store_false", dest="use_github_mirror", help="不使用 Github 镜像源")
    check_p.add_argument("--custom-github-mirror", type=str, dest="custom_github_mirror", help="自定义 Github 镜像源")
    check_p.set_defaults(
        func=lambda args: check_env(
            qwen_tts_webui_path=args.qwen_tts_webui_path,
            use_uv=args.use_uv,
            use_pypi_mirror=args.use_pypi_mirror,
            use_github_mirror=args.use_github_mirror,
            custom_github_mirror=args.custom_github_mirror,
        )
    )

    # launch
    launch_p = qwen_tts_webui_sub.add_parser("launch", help="启动 Qwen TTS WebUI")
    launch_p.add_argument("--qwen-tts-webui-path", type=normalized_filepath, required=False, default=QWEN_TTS_WEBUI_ROOT_PATH, dest="qwen_tts_webui_path", help="Qwen TTS WebUI 根目录")
    launch_p.add_argument("--launch-args", type=str, dest="launch_args", help='启动参数 (请使用引号包裹，例如 "--theme dark")')
    launch_p.add_argument("--no-hf-mirror", action="store_false", dest="use_hf_mirror", help="禁用 HuggingFace 镜像源")
    launch_p.add_argument("--custom-hf-mirror", type=str, dest="custom_hf_mirror", help="自定义 HuggingFace 镜像源")
    launch_p.add_argument("--no-github-mirror", action="store_false", dest="use_github_mirror", help="禁用 Github 镜像源")
    launch_p.add_argument("--custom-github-mirror", type=str, dest="custom_github_mirror", help="自定义 Github 镜像源")
    launch_p.add_argument("--no-pypi-mirror", action="store_false", dest="use_pypi_mirror", help="禁用 PyPI 镜像源")
    launch_p.add_argument("--no-cuda-malloc", action="store_false", dest="use_cuda_malloc", help="禁用 CUDA Malloc 优化")
    launch_p.add_argument("--no-check-env", action="store_false", dest="check_env", help="不检查运行环境完整性")
    launch_p.add_argument("--no-hotpatcher", action="store_false", dest="enable_hotpatcher", default=True, help="禁用补丁系统注入")
    launch_p.add_argument("--hotpatcher-runtime", action="store_true", dest="enable_hotpatcher_runtime", default=False, help="启用补丁系统 runtime host 连接")
    launch_p.add_argument("--hotpatcher-config", type=normalized_filepath, dest="hotpatcher_config_path", help="补丁系统配置文件路径")
    launch_p.add_argument("--hotpatcher-port", type=int, dest="hotpatcher_port", help="补丁系统 runtime 通信端口")
    launch_p.set_defaults(
        func=lambda args: launch(
            qwen_tts_webui_path=args.qwen_tts_webui_path,
            launch_args=args.launch_args,
            use_hf_mirror=args.use_hf_mirror,
            custom_hf_mirror=args.custom_hf_mirror,
            use_github_mirror=args.use_github_mirror,
            custom_github_mirror=args.custom_github_mirror,
            use_pypi_mirror=args.use_pypi_mirror,
            use_cuda_malloc=args.use_cuda_malloc,
            check_launch_env=args.check_env,
            enable_hotpatcher=args.enable_hotpatcher,
            enable_hotpatcher_runtime=args.enable_hotpatcher_runtime,
            hotpatcher_config_path=args.hotpatcher_config_path,
            hotpatcher_port=args.hotpatcher_port,
        )
    )

    # gui
    gui_parser = qwen_tts_webui_sub.add_parser("gui", help="图形界面工具")
    gui_sub = gui_parser.add_subparsers(dest="gui_action", required=True)

    version_gui_p = gui_sub.add_parser("version-manager", help="启动 Qwen TTS WebUI 版本管理 GUI")
    version_gui_p.add_argument("--qwen-tts-webui-path", type=normalized_filepath, required=False, default=QWEN_TTS_WEBUI_ROOT_PATH, dest="qwen_tts_webui_path", help="Qwen TTS WebUI 根目录")
    version_gui_p.add_argument("--no-github-mirror", action="store_false", dest="use_github_mirror", help="不使用 Github 镜像源")
    version_gui_p.add_argument("--custom-github-mirror", type=str, dest="custom_github_mirror", help="自定义 Github 镜像源")
    version_gui_p.set_defaults(
        func=lambda args: launch_version_gui(
            qwen_tts_webui_path=args.qwen_tts_webui_path,
            use_github_mirror=args.use_github_mirror,
            custom_github_mirror=args.custom_github_mirror,
        )
    )
