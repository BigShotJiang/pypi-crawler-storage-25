#!/usr/bin/env python3
"""
PTY Capture for Janus Remote

Wraps Claude CLI in a PTY and connects to local Janus via WebSocket
for voice-to-text paste and approval overlay support over SSH.
"""

import sys
import os
import pty
import select
import termios
import tty
from datetime import datetime
import fcntl
import time
import json
import re
import threading
import socket
import signal
import atexit

# WebSocket bridge port (must match Janus Electron)
JANUS_BRIDGE_PORT = 9473

# Hook-based approval IPC paths (written by approval_hook.py)
JANUS_DATA_DIR = os.path.expanduser('~/.janus')
HOOK_PENDING_APPROVAL_FILE = os.path.join(JANUS_DATA_DIR, 'pending_approval.json')  # legacy single-file
HOOK_PENDING_APPROVAL_DIR = os.path.join(JANUS_DATA_DIR, 'pending-approvals')  # queue dir (per-reqId)

def debug_log(msg):
    """Debug logging (file writing disabled)"""
    pass


# Lock for thread-safe terminal writes during raw mode
import threading
_output_lock = threading.Lock()

# Global reference to remote client for sending status via WebSocket
_remote_client = None


def safe_status(msg, color='208', force_terminal=False):
    """Send status message via WebSocket to Janus overlay, or fallback to terminal.

    When connected to Janus, sends status via WebSocket for overlay display.
    Falls back to terminal output during startup (before connection).
    Use force_terminal=True for critical messages that should always show in terminal.
    """
    global _remote_client

    # Try to send via WebSocket if connected (cleaner UI, no terminal corruption)
    if not force_terminal and _remote_client and _remote_client.connected and _remote_client.ws:
        try:
            import json
            _remote_client.ws.send(json.dumps({
                'type': 'status',
                'message': msg,
                'color': color
            }))
            return  # Successfully sent via WebSocket
        except:
            pass  # Fall through to terminal output

    # Fallback to terminal output (during startup or if WebSocket fails)
    with _output_lock:
        output = f"\r\033[K\033[38;5;{color}m[janus-remote]\033[0m {msg}\r\n"
        sys.stderr.write(output)
        sys.stderr.flush()


# Regex to match title escape sequences (for selective filtering)
TITLE_ESCAPE_PATTERN = re.compile(rb'\x1b\][012];[^\x07\x1b]*(?:\x07|\x1b\\)')

# Get Janus title for selective filtering - preserve our title, strip Claude's
JANUS_TITLE = os.environ.get('JANUS_TITLE', '')


def filter_title_sequences(data):
    """
    Selectively filter title escape sequences.
    - Preserve sequences containing JANUS_TITLE (so VSCode tab shows our title)
    - Strip other title sequences (from Claude) to prevent tab name hijacking
    """
    if not JANUS_TITLE:
        # No Janus title set - strip everything (original behavior)
        return TITLE_ESCAPE_PATTERN.sub(b'', data)

    janus_title_bytes = JANUS_TITLE.encode('utf-8')

    def replacer(match):
        seq = match.group(0)
        # Check if this sequence contains our Janus title - keep it!
        if janus_title_bytes in seq:
            return seq
        # Strip all other title sequences (Claude's)
        return b''

    return TITLE_ESCAPE_PATTERN.sub(replacer, data)


class TitleRefresher:
    """Periodically resends terminal title to keep VSCode tab name visible"""

    def __init__(self):
        self.running = True
        self.thread = None
        self.title = JANUS_TITLE

    def start(self):
        if not self.title:
            return  # No title to refresh

        self.thread = threading.Thread(target=self._refresh_loop, daemon=True)
        self.thread.start()

    def _refresh_loop(self):
        """Send title sequence every 5 seconds to maintain VSCode tab name"""
        while self.running:
            if self.title:
                # OSC 0 - Set window and icon title
                title_seq = f"\033]0;{self.title}\007"
                sys.stdout.write(title_seq)
                sys.stdout.flush()
            time.sleep(5)

    def stop(self):
        self.running = False


def get_janus_title():
    """Get session title from environment"""
    return os.environ.get('JANUS_TITLE', '')



class RemotePasteClient:
    """WebSocket client for bidirectional communication with local Janus"""

    def __init__(self, master_fd, port=JANUS_BRIDGE_PORT):
        global _remote_client
        self.master_fd = master_fd
        self.port = port
        self.ws = None
        self.running = True
        self.connected = False
        self.client_thread = None
        self.session_id = os.environ.get('JANUS_SESSION_ID', f"pty-{os.getpid()}-{int(time.time())}")
        self.pending_approval = None
        self.approval_id = 0
        self._approval_lock = threading.RLock()
        self._just_added_whitelist = False  # Track if whitelist was just added (skip "approved" status)
        # Set global reference so safe_status can send via WebSocket
        _remote_client = self

    def start(self):
        """Start the WebSocket client in a background thread"""
        self.client_thread = threading.Thread(target=self._run_client, daemon=True)
        self.client_thread.start()

    def _get_public_ip(self):
        """Get the server's public IP address for SSH config matching"""
        try:
            import urllib.request
            # Try multiple services in case one is down
            services = [
                'https://api.ipify.org',
                'https://ifconfig.me/ip',
                'https://icanhazip.com',
            ]
            for url in services:
                try:
                    with urllib.request.urlopen(url, timeout=3) as response:
                        ip = response.read().decode('utf-8').strip()
                        if ip:
                            return ip
                except:
                    continue
        except:
            pass
        return ''

    def _run_client(self):
        """Main client loop - connect and listen for messages"""
        try:
            import websocket
        except ImportError:
            safe_status("websocket-client not installed. Run: pip install websocket-client", '208')
            return

        while self.running:
            try:
                ws_url = f"ws://localhost:{self.port}"
                safe_status("Connecting to Janus bridge...", '208')

                self.ws = websocket.create_connection(ws_url, timeout=5)
                self.connected = True
                safe_status("\033[1mConnected to Janus bridge!\033[0m \033[38;5;141m<*>\033[0m", '82')

                # Register this session
                my_title = get_janus_title()
                system_hostname = socket.gethostname()

                # Get public IP for automatic SSH config matching
                public_ip = self._get_public_ip()

                # Get explicit SSH host alias (set by --host flag in CLI)
                ssh_host = os.environ.get('JANUS_SSH_HOST', '')

                register_msg = json.dumps({
                    'type': 'register',
                    'sessionId': self.session_id,
                    'title': my_title,
                    'hostname': system_hostname,
                    'publicIP': public_ip,
                    'sshHost': ssh_host,
                    'capabilities': ['paste', 'approval']
                })
                self.ws.send(register_msg)
                if public_ip:
                    safe_status(f"Public IP: {public_ip}", '245')

                # Listen for messages
                while self.running and self.connected:
                    try:
                        self.ws.settimeout(1.0)
                        message = self.ws.recv()
                        if message:
                            self._handle_message(message)
                    except websocket.WebSocketTimeoutException:
                        try:
                            self.ws.send(json.dumps({'type': 'ping'}))
                        except:
                            break
                    except websocket.WebSocketConnectionClosedException:
                        safe_status("Connection closed", '208')
                        break
                    except Exception:
                        break

            except Exception as e:
                if self.running:
                    pass  # Silently retry
                self.connected = False

            if self.running:
                time.sleep(5)

    def _handle_message(self, message):
        """Handle incoming WebSocket message"""
        try:
            msg = json.loads(message)
            msg_type = msg.get('type')

            if msg_type == 'paste':
                text = msg.get('text', '')
                target_title = msg.get('targetTitle', '')
                my_title = get_janus_title()

                # Validate this paste is intended for us (same protection as local)
                if target_title and my_title and target_title != my_title:
                    safe_status(f"Paste rejected - target '{target_title}' != mine '{my_title}'", '208')
                    debug_log(f"[Paste] REJECTED: targetTitle='{target_title}' != myTitle='{my_title}'")
                elif text:
                    safe_status("Voice paste received", '82')
                    self._inject_text(text)

            elif msg_type == 'registered':
                pass  # Already printed connection message

            elif msg_type == 'approval_response':
                # Response from local Janus approval overlay
                action = msg.get('action', 'deny')
                response_approval_id = msg.get('approvalId')

                with self._approval_lock:
                    if self.pending_approval:
                        # Two ids in play here:
                        #   - WS counter id (self.approval_id, also stored as
                        #     pending_approval['id']) — used for stale-response
                        #     dedup against incoming WS approvalId.
                        #   - Hook id (PID-suffixed, set by approval_hook.py
                        #     and passed through raw_context) — this is the
                        #     filename the BLOCKING hook is polling for. We
                        #     MUST use this for the .res.json filename or the
                        #     hook never unblocks → claude waits forever →
                        #     parallel tool calls all hang on each other.
                        pending_id = self.pending_approval.get('id')
                        hook_id = self.pending_approval.get('hook_id') or pending_id
                        if response_approval_id and pending_id and response_approval_id != pending_id:
                            safe_status(f"[!] Stale response ignored (got {response_approval_id}, expected {pending_id})", '208')
                            debug_log(f"[Approval] STALE response: response_id={response_approval_id}, pending_id={pending_id}")
                            return
                        # Write <hookId>.res.json — this is the filename the
                        # blocking-poll hook is sleeping on. Without using
                        # hook_id here, parallel tool calls each generate a
                        # unique hook id, but only ONE gets a matching
                        # .res.json (this one). All others hang until 5min
                        # timeout, claude treats them as denied, run fails.
                        try:
                            os.makedirs(HOOK_PENDING_APPROVAL_DIR, exist_ok=True)
                            res_path = os.path.join(HOOK_PENDING_APPROVAL_DIR, f"{hook_id}.res.json")
                            with open(res_path, 'w') as f:
                                json.dump({
                                    'id': hook_id,
                                    'action': action,
                                    'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
                                    'sessionTitle': self.pending_approval.get('sessionTitle', ''),
                                    'janusTitle': self.pending_approval.get('janusTitle', ''),
                                }, f)
                            debug_log(f"[Approval] wrote res.json for hook_id={hook_id} (action={action})")
                        except Exception as e:
                            debug_log(f"[Approval] queue res-write failed: {e}")
                        # Inject keystroke into TTY for interactive claude.
                        # (Sub-agents have no TTY — write fails silently, which
                        # is fine since the hook is reading the file above.)
                        self._inject_approval_response(action)
                    else:
                        safe_status("[!] No pending approval - ignoring response", '208')
                        debug_log(f"[Approval] No pending approval for response: {action}")

            elif msg_type == 'auto_approve_pattern':
                # Add pattern to local whitelist file
                pattern = msg.get('pattern', {})
                if pattern:
                    self._add_auto_approve_pattern(pattern)

            elif msg_type == 'clear_whitelist':
                self._clear_session_whitelist()

            elif msg_type == 'shutdown':
                reason = msg.get('reason', 'unknown')
                safe_status(f"Shutdown received: {reason}", '196')
                self.running = False
                self.connected = False
                # Signal main process to exit
                os.kill(os.getpid(), signal.SIGTERM)

        except json.JSONDecodeError:
            pass

    def _inject_text(self, text):
        """Inject text directly into the PTY"""
        try:
            encoded = text.encode('utf-8')
            chunk_size = 256
            for i in range(0, len(encoded), chunk_size):
                chunk = encoded[i:i + chunk_size]
                os.write(self.master_fd, chunk)
                if len(encoded) > chunk_size:
                    time.sleep(0.02)

            time.sleep(0.15)
            os.write(self.master_fd, b'\r')
        except OSError as e:
            safe_status(f"Paste error: {e}", '196')

    def _inject_approval_response(self, action):
        """Inject approval response keystroke to Claude"""
        try:
            if action == 'approve':
                os.write(self.master_fd, b'1')
                time.sleep(0.05)
                os.write(self.master_fd, b'\r')
                # Skip "approved" status if whitelist was just added (let whitelist_ack be the notification)
                if self._just_added_whitelist:
                    self._just_added_whitelist = False
                else:
                    safe_status("approved", '82')
            elif action == 'approve_all':
                os.write(self.master_fd, b'2')
                time.sleep(0.05)
                os.write(self.master_fd, b'\r')
                safe_status("approved all", '82')
            elif action == 'deny':
                os.write(self.master_fd, b'\x1b')  # Escape to cancel
                safe_status("[X] Denied", '208')
            elif action.startswith('deny:'):
                feedback = action[5:]
                os.write(self.master_fd, b'3')
                time.sleep(0.1)
                os.write(self.master_fd, b'\r')
                time.sleep(0.2)
                os.write(self.master_fd, feedback.encode('utf-8'))
                time.sleep(0.05)
                os.write(self.master_fd, b'\r')
                safe_status("[X] Denied with feedback", '208')
            else:
                os.write(self.master_fd, b'\x1b')

            self.pending_approval = None

        except OSError as e:
            safe_status(f"Approval inject error: {e}", '196')

    def _clear_session_whitelist(self):
        """Remove all whitelist patterns for this session"""
        whitelist_path = os.path.join(JANUS_DATA_DIR, 'auto-approve-whitelist.json')
        try:
            if os.path.exists(whitelist_path):
                with open(whitelist_path, 'r') as f:
                    wl = json.load(f)
                before = len(wl.get('patterns', []))
                wl['patterns'] = [p for p in wl.get('patterns', []) if p.get('sessionId') != self.session_id]
                removed = before - len(wl['patterns'])
                if removed > 0:
                    with open(whitelist_path, 'w') as f:
                        json.dump(wl, f, indent=2)
                    safe_status(f"Cleared {removed} whitelist patterns", '208')
                    debug_log(f"Cleared {removed} whitelist patterns for session {self.session_id}")
        except Exception as e:
            debug_log(f"Error clearing whitelist: {e}")

    def _add_auto_approve_pattern(self, pattern):
        """Add pattern to local auto-approve whitelist file"""
        whitelist_path = os.path.join(JANUS_DATA_DIR, 'auto-approve-whitelist.json')
        whitelist = {'patterns': []}

        # Ensure directory exists
        os.makedirs(JANUS_DATA_DIR, exist_ok=True)

        # Load existing whitelist
        try:
            if os.path.exists(whitelist_path):
                with open(whitelist_path, 'r') as f:
                    whitelist = json.load(f)
        except Exception as e:
            debug_log(f"Error reading whitelist: {e}")

        # Check if pattern already exists
        exists = False
        for p in whitelist.get('patterns', []):
            if p.get('tool') != pattern.get('tool'):
                continue
            if pattern.get('command_prefix') and p.get('command_prefix') == pattern.get('command_prefix'):
                exists = True
                break
            if pattern.get('file_prefix') and p.get('file_prefix') == pattern.get('file_prefix'):
                exists = True
                break
            if pattern.get('any') and p.get('any'):
                exists = True
                break

        # Format pattern for display
        tool = pattern.get('tool', '?')
        detail = ''
        if pattern.get('command_prefix'):
            detail = f" cmd:{pattern['command_prefix']}"
        elif pattern.get('file_prefix'):
            detail = f" path:{pattern['file_prefix']}"
        elif pattern.get('file_pattern'):
            detail = f" glob:{pattern['file_pattern']}"
        elif pattern.get('any'):
            detail = " (any)"

        if not exists:
            whitelist.setdefault('patterns', []).append(pattern)
            try:
                with open(whitelist_path, 'w') as f:
                    json.dump(whitelist, f, indent=2)
                self._just_added_whitelist = True  # Flag to skip "approved" status
                debug_log(f"Added auto-approve pattern: {json.dumps(pattern)}")
                self._send_whitelist_ack('added', pattern, whitelist_path)
            except Exception as e:
                safe_status(f"Error saving whitelist: {e}", '196')
                debug_log(f"Error saving whitelist: {e}")
        else:
            self._just_added_whitelist = True  # Flag to skip "approved" status (pattern exists)
            debug_log(f"Pattern already exists: {json.dumps(pattern)}")
            self._send_whitelist_ack('exists', pattern, whitelist_path)

    def _send_whitelist_ack(self, status, pattern, whitelist_path):
        """Send acknowledgment back to Janus about whitelist update"""
        if not self.connected or not self.ws:
            return
        try:
            # Read current whitelist to show total patterns
            total_patterns = 0
            try:
                with open(whitelist_path, 'r') as f:
                    wl = json.load(f)
                    total_patterns = len(wl.get('patterns', []))
            except:
                pass

            self.ws.send(json.dumps({
                'type': 'whitelist_ack',
                'sessionId': self.session_id,
                'status': status,
                'pattern': pattern,
                'totalPatterns': total_patterns,
                'whitelistPath': whitelist_path
            }))
        except Exception as e:
            debug_log(f"Error sending whitelist ack: {e}")

    def send_approval_request(self, tool_name, context, raw_context=None, janus_title=None, session_title=None):
        """Send approval request to local Janus for overlay display"""
        if not self.connected or not self.ws:
            return

        # Pull the hook's PID-suffixed id out of the raw approval payload so
        # we can write the response file under the filename the blocking-poll
        # hook is actually listening for. Without this, parallel tool calls
        # all hang waiting for their .res.json (we'd only write one and
        # name it after the WS counter, not the hook id).
        hook_id = None
        if raw_context and isinstance(raw_context, dict):
            hook_id = raw_context.get('id')

        with self._approval_lock:
            self.approval_id += 1
            self.pending_approval = {
                'id': self.approval_id,
                'hook_id': hook_id,           # used to name <hookId>.res.json on response
                'timestamp': datetime.now().isoformat(),
                'tool': tool_name,
                'context': context,
                'sessionTitle': session_title or os.environ.get('JANUS_TITLE', ''),
                'janusTitle': janus_title or '',
            }
            current_id = self.approval_id

        # Get session title from env if not provided
        if not session_title:
            session_title = os.environ.get('JANUS_TITLE', '')

        try:
            self.ws.send(json.dumps({
                'type': 'approval_request',
                'sessionId': self.session_id,
                'approvalId': current_id,
                'tool': tool_name,
                'context': context,
                'rawContext': raw_context or context,
                'hostname': socket.gethostname(),
                'sessionTitle': session_title,
                'janusTitle': janus_title or ''
            }))
            safe_status(f"[!] Approval request sent -> {tool_name}", '141')
        except Exception:
            pass

    def clear_pending_approval(self, reason='manual'):
        """Clear pending approval (user handled it manually) and notify Janus"""
        with self._approval_lock:
            if self.pending_approval and self.connected and self.ws:
                try:
                    self.ws.send(json.dumps({
                        'type': 'approval_cleared',
                        'sessionId': self.session_id,
                        'approvalId': self.pending_approval.get('id') if self.pending_approval else None,
                        'reason': reason
                    }))
                except Exception:
                    pass
            self.pending_approval = None
            if reason == 'denied':
                self._clear_session_whitelist()

    def stop(self):
        """Stop the client"""
        self.running = False
        self.connected = False
        if self.ws:
            try:
                self.ws.close()
            except:
                pass



class HookApprovalWatcher:
    """Watches for hook-based approval requests (from approval_hook.py)"""

    def __init__(self, remote_client):
        self.remote_client = remote_client
        self.running = True
        self.watcher_thread = None
        self.last_approval_id = None

    def start(self):
        """Start watching for hook approval files in background"""
        self.watcher_thread = threading.Thread(target=self._watch_loop, daemon=True)
        self.watcher_thread.start()

    def _watch_loop(self):
        """Poll for hook approvals — both new queue-dir files and legacy single-file."""
        my_session_id = os.environ.get('JANUS_SESSION_ID', '')
        # Make sure the queue dir exists so listdir doesn't error on first poll.
        try:
            os.makedirs(HOOK_PENDING_APPROVAL_DIR, exist_ok=True)
        except Exception:
            pass

        def forward(approval):
            """Try to send the approval over WebSocket. Returns True ONLY if
            the WS request was actually dispatched. If pending_approval is
            already set (another approval in flight), returns False so the
            caller leaves the .req.json file on disk and retries next tick —
            otherwise parallel tool calls get silently eaten when only the
            first one fits through the single-slot pending_approval gate."""
            file_session_id = approval.get('sessionId', '')
            if my_session_id and file_session_id and file_session_id != my_session_id:
                return False  # not ours
            approval_id = approval.get('id')
            if not approval_id or approval_id == self.last_approval_id:
                return False
            tool = approval.get('tool', 'Unknown')
            context = approval.get('context', [])
            janus_title = approval.get('janusTitle', '')
            session_title = approval.get('sessionTitle', '')
            sent = False
            with self.remote_client._approval_lock:
                if not self.remote_client.pending_approval:
                    safe_status(f"Hook approval: {tool} - {janus_title}", '208')
                    self.remote_client.send_approval_request(
                        tool,
                        context,
                        raw_context=approval,
                        janus_title=janus_title,
                        session_title=session_title,
                    )
                    # Only mark this id as last_seen AFTER a successful dispatch.
                    # If we mark it before, a busy-slot retry would skip it
                    # forever (id == last_approval_id check above bails out).
                    self.last_approval_id = approval_id
                    sent = True
            return sent

        while self.running:
            try:
                # Queue-dir flow — multiple .req.json files can coexist; pick
                # the oldest one each tick (deterministic ordering).
                req_files = []
                try:
                    for f in os.listdir(HOOK_PENDING_APPROVAL_DIR):
                        if f.endswith('.req.json'):
                            full = os.path.join(HOOK_PENDING_APPROVAL_DIR, f)
                            try:
                                req_files.append((os.path.getmtime(full), full))
                            except Exception:
                                pass
                except FileNotFoundError:
                    pass
                req_files.sort()
                for _, req_path in req_files:
                    try:
                        with open(req_path, 'r') as f:
                            approval = json.load(f)
                    except (json.JSONDecodeError, FileNotFoundError, PermissionError):
                        continue
                    if forward(approval):
                        # Delete request file so we don't re-fire. Hook waits
                        # for our .res.json — we'll write it from the WS handler.
                        try: os.remove(req_path)
                        except Exception: pass
                        # Only forward one at a time; remote_client locks while
                        # an approval is pending. Next tick picks up the next.
                        break
                    else:
                        # Not ours / dup — leave the file for the right session.
                        pass

                # Legacy single-file fallback (older approval-hook.py versions)
                if os.path.exists(HOOK_PENDING_APPROVAL_FILE):
                    try:
                        with open(HOOK_PENDING_APPROVAL_FILE, 'r') as f:
                            approval = json.load(f)
                    except (json.JSONDecodeError, FileNotFoundError, PermissionError):
                        approval = None
                    if approval:
                        if forward(approval):
                            try: os.remove(HOOK_PENDING_APPROVAL_FILE)
                            except Exception: pass

            except Exception as e:
                debug_log(f"Hook watcher error: {e}")

            time.sleep(0.1)

    def stop(self):
        """Stop the watcher"""
        self.running = False


def run_claude_session(claude_path, args):
    """Run Claude CLI wrapped in PTY with Janus voice paste support"""

    old_tty = termios.tcgetattr(sys.stdin)
    child_pid = None  # Track child for cleanup

    def cleanup_child():
        """Kill child process on parent exit"""
        if child_pid:
            try:
                os.kill(child_pid, signal.SIGTERM)
            except (OSError, ProcessLookupError):
                pass

    def signal_handler(signum, frame):
        """Forward signals to child and exit"""
        cleanup_child()
        # Restore terminal before exit
        try:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_tty)
        except:
            pass
        sys.exit(128 + signum)

    try:
        master_fd, slave_fd = pty.openpty()
        pid = os.fork()

        if pid == 0:  # Child process
            os.close(master_fd)
            os.setsid()

            # On Linux: die when parent dies (PR_SET_PDEATHSIG)
            try:
                import ctypes
                libc = ctypes.CDLL("libc.so.6", use_errno=True)
                PR_SET_PDEATHSIG = 1
                libc.prctl(PR_SET_PDEATHSIG, signal.SIGTERM)
            except (OSError, AttributeError):
                pass  # Not Linux or prctl not available (macOS)

            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            os.execv(claude_path, [claude_path] + args)

        else:  # Parent process
            child_pid = pid

            # Register cleanup handlers to kill child when parent exits
            atexit.register(cleanup_child)
            signal.signal(signal.SIGTERM, signal_handler)
            signal.signal(signal.SIGHUP, signal_handler)
            signal.signal(signal.SIGINT, signal_handler)
            os.close(slave_fd)
            tty.setraw(sys.stdin.fileno())

            flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
            fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

            # Initialize Remote Client, Hook Watcher, and Title Refresher
            remote_client = RemotePasteClient(master_fd)
            remote_client.start()

            # Start hook approval watcher (reads from approval_hook.py output)
            hook_watcher = HookApprovalWatcher(remote_client)
            hook_watcher.start()

            # Start title refresher to keep VSCode tab name visible
            title_refresher = TitleRefresher()
            title_refresher.start()

            line_buffer = b''

            while True:
                rfds, _, _ = select.select([sys.stdin, master_fd], [], [], 0.01)

                pid_status = os.waitpid(pid, os.WNOHANG)
                if pid_status[0] != 0:
                    break

                if sys.stdin in rfds:
                    try:
                        data = os.read(sys.stdin.fileno(), 1024)
                        if data:
                            if remote_client.pending_approval:
                                if data in (b'1', b'2', b'3', b'\r', b'\n', b'\x1b'):
                                    reason = 'denied' if data in (b'3', b'\x1b') else 'manual'
                                    remote_client.clear_pending_approval(reason=reason)
                            elif data == b'\x1b':
                                remote_client.clear_pending_approval(reason='denied')
                            os.write(master_fd, data)
                    except OSError:
                        pass

                if master_fd in rfds:
                    try:
                        data = os.read(master_fd, 4096)
                        if data:
                            data = filter_title_sequences(data)
                            os.write(sys.stdout.fileno(), data)
                    except OSError:
                        pass

            remote_client.stop()
            hook_watcher.stop()
            title_refresher.stop()

            # Child exited - unregister atexit handler since child is dead
            try:
                atexit.unregister(cleanup_child)
            except:
                pass

            _, exit_status = os.waitpid(pid, 0)
            exit_code = os.WEXITSTATUS(exit_status) if os.WIFEXITED(exit_status) else 1

    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_tty)

    print()
    print("\033[38;5;245mSession ended.\033[0m")
    sys.exit(exit_code if 'exit_code' in locals() else 0)


def main():
    """Standalone entry point"""
    from .cli import main as cli_main
    cli_main()


if __name__ == '__main__':
    main()
