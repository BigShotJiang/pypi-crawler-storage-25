#!/usr/bin/env python3
"""
Subagent runner for janus-remote.

Used by Janus app's SshTransport (Phase 2.8) to dispatch a non-interactive
claude sub-agent on a remote machine over SSH. The local Janus reverse-tunnels
its WebSocket bridge port (9473) into the remote so this script can dial back
to the user's local janusapp for approvals AND a live PTY byte mirror so the
user's raw-stream window can show the remote claude session as if SSHed in.

Two channels of output:

  • SSH stdout — claude's stream-json (parsed by janusapp's dispatcher into
    chip + sub-agent sheet UI). Same as pre-PTY behavior — backward compatible.

  • WS pty-bytes — every byte claude writes to its PTY (stream-json AND any
    TTY-aware status messages, ANSI escapes, prompts) gets base64'd and shoved
    over the WS bridge so the local raw-stream window can render a live xterm
    of the remote session. Closes the "what's happening on the remote" gap
    that plain stream-json events leave.

Both channels carry the SAME bytes — duplicated from the PTY master fd:

  PTY master ──► tee ──► sys.stdout (→ ssh stdout → janusapp parser)
                  └───► WS pty-bytes (→ raw-stream xterm)

Outputs claude's stream-json on stdout (the SSH stdout, which janusapp parses).
All janus-remote logging goes to stderr to avoid corrupting the JSON stream.
"""

import sys
import os
import time
import shutil
import argparse
import subprocess
import signal
import threading
import base64

try:
    import pty
    import select
    import fcntl
    import struct
    import termios
    _HAS_PTY = True
except ImportError:
    # Windows or other non-POSIX — fall back to subprocess.Popen w/o PTY.
    _HAS_PTY = False


def _find_claude():
    """Find the claude binary location on the remote machine."""
    p = shutil.which('claude')
    if p:
        return p
    for candidate in [
        '/usr/local/bin/claude',
        '/opt/homebrew/bin/claude',
        os.path.expanduser('~/.local/bin/claude'),
        os.path.expanduser('~/bin/claude'),
        '/usr/bin/claude',
        os.path.expanduser('~/.npm-global/bin/claude'),
    ]:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _stderr(msg):
    """Logging that doesn't corrupt the stream-json on stdout."""
    sys.stderr.write(f"[subagent-run] {msg}\n")
    sys.stderr.flush()


def main(argv=None):
    """Entry point for `janus-remote subagent-run`.

    `argv` is the list of args AFTER the `subagent-run` token. The cli.py
    dispatcher strips that token and hands us the remainder.
    """
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog='janus-remote subagent-run',
        description='Non-interactive claude sub-agent runner for SSH-dispatched Janus deps.',
    )
    parser.add_argument('--bridge-port', type=int, required=True,
                        help='Local TCP port (reverse-tunneled) to dial for the WS bridge.')
    parser.add_argument('--janus-title', required=True,
                        help='JANUS_TITLE for the spawned claude (must start with subagent-).')
    parser.add_argument('--janus-session-id', required=True,
                        help='JANUS_SESSION_ID for routing approvals back to this sub-agent.')
    parser.add_argument('--janus-subagent-dep-id', default='',
                        help='JANUS_SUBAGENT_DEP_ID — read by the hook to load sub-agent profile/memory.')
    parser.add_argument('--janus-subagent-run-id', default='',
                        help='Run id used by the local raw-stream window to route pty-bytes to the correct terminal tab.')
    parser.add_argument('--dep-path', required=True,
                        help='Working directory on the remote (the dep path).')
    parser.add_argument('claude_args', nargs=argparse.REMAINDER,
                        help='Args after `--` are forwarded verbatim to claude.')
    args = parser.parse_args(argv)

    # argparse.REMAINDER includes the leading `--` token if present; drop it.
    claude_args = args.claude_args
    if claude_args and claude_args[0] == '--':
        claude_args = claude_args[1:]

    cwd = os.path.expanduser(args.dep_path)
    if not os.path.isdir(cwd):
        _stderr(f"dep path missing or not a directory: {args.dep_path}")
        sys.exit(2)

    claude_path = _find_claude()
    if not claude_path:
        _stderr("claude binary not found in PATH or common locations")
        sys.exit(127)

    # Set Janus env BEFORE importing pty_capture — it captures JANUS_TITLE at
    # module-load time for title-filter behavior (harmless here, but consistent).
    os.environ['JANUS_TITLE'] = args.janus_title
    os.environ['JANUS_SESSION_ID'] = args.janus_session_id
    if args.janus_subagent_dep_id:
        os.environ['JANUS_SUBAGENT_DEP_ID'] = args.janus_subagent_dep_id
    if args.janus_subagent_run_id:
        os.environ['JANUS_SUBAGENT_RUN_ID'] = args.janus_subagent_run_id
    run_id = args.janus_subagent_run_id or args.janus_title

    # Import lazily so the `--help` path doesn't require websocket-client.
    try:
        from .pty_capture import RemotePasteClient, HookApprovalWatcher
    except ImportError as e:
        _stderr(f"failed to import janus-remote internals: {e}")
        sys.exit(3)

    # Sub-agent variant: no keystroke injection (the .res.json file written by
    # the parent's WS handler unblocks the hook). Adds `send_pty_bytes` so the
    # PTY pump thread can mirror every byte claude writes up to local Janus.
    class SubagentApprovalClient(RemotePasteClient):
        def _inject_approval_response(self, action):
            self.pending_approval = None

        def _inject_text(self, text):
            return  # no TTY-paste path in non-interactive mode

        def send_pty_bytes(self, data, run_id=''):
            if not self.ws or not self.connected or not data:
                return
            try:
                import json
                b64 = base64.b64encode(data).decode('ascii')
                self.ws.send(json.dumps({
                    'type': 'pty-bytes',
                    'sessionId': self.session_id,
                    'runId': run_id,
                    'data': b64,
                }))
            except Exception:
                pass  # WS hiccup; don't crash the whole run over one chunk

    client = SubagentApprovalClient(master_fd=None, port=args.bridge_port)
    client.start()

    watcher = HookApprovalWatcher(client)
    watcher.start()

    # Wait briefly for the WS bridge to register before spawning claude so an
    # immediate tool-use's approval has a path to reach Janus.
    deadline = time.time() + 10
    while not client.connected and time.time() < deadline:
        time.sleep(0.05)
    if not client.connected:
        _stderr("warning: WS bridge not connected after 10s; approvals may time out")

    if not _HAS_PTY:
        # Non-POSIX fallback — straight subprocess pipe, no live terminal mirror.
        _stderr("PTY not available on this platform; falling back to plain subprocess (no live terminal mirror)")
        proc = subprocess.Popen(
            [claude_path] + list(claude_args),
            cwd=cwd,
            env=os.environ.copy(),
            stdin=subprocess.DEVNULL,
        )
        rc = proc.wait()
        sys.exit(rc)

    # PTY-wrap claude. Stdin/stdout/stderr all bind to the slave; we read from
    # master and tee to (1) our own stdout (which is the SSH stdout — janusapp's
    # dispatcher parses stream-json from it) and (2) a WS message stream so the
    # local raw-stream window can render a live xterm of the same bytes.
    master_fd, slave_fd = pty.openpty()
    # Set a sensible PTY size so claude knows the column width (avoids ugly
    # wrap-at-80 in stream-json output of long tool args).
    try:
        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, struct.pack('HHHH', 40, 220, 0, 0))
    except Exception:
        pass

    proc = subprocess.Popen(
        [claude_path] + list(claude_args),
        cwd=cwd,
        env=os.environ.copy(),
        stdin=slave_fd,
        stdout=slave_fd,
        stderr=slave_fd,
        close_fds=True,
    )
    # Parent doesn't need the slave end; closing it ensures we get EOF on
    # the master when claude exits.
    os.close(slave_fd)

    pump_done = threading.Event()

    def pty_pump():
        try:
            while True:
                try:
                    r, _, _ = select.select([master_fd], [], [], 0.5)
                except (OSError, ValueError):
                    break
                if master_fd in r:
                    try:
                        data = os.read(master_fd, 65536)
                    except OSError:
                        break
                    if not data:
                        break  # EOF — claude exited
                    # Tee to ssh stdout (existing stream-json parser).
                    try:
                        sys.stdout.buffer.write(data)
                        sys.stdout.flush()
                    except Exception:
                        pass
                    # Tee to WS for the live xterm mirror.
                    try:
                        client.send_pty_bytes(data, run_id=run_id)
                    except Exception:
                        pass
                elif proc.poll() is not None:
                    # Process exited and master has nothing more to read.
                    break
        finally:
            pump_done.set()

    pump_thread = threading.Thread(target=pty_pump, daemon=True)
    pump_thread.start()

    def _forward_signal(signum, _frame):
        try:
            proc.send_signal(signum)
        except Exception:
            pass

    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        try:
            signal.signal(sig, _forward_signal)
        except Exception:
            pass

    try:
        rc = proc.wait()
    except KeyboardInterrupt:
        try:
            proc.terminate()
            rc = proc.wait(timeout=5)
        except Exception:
            rc = 130
    finally:
        # Give the pump a moment to drain final bytes after claude exits.
        pump_done.wait(timeout=2.0)
        try:
            os.close(master_fd)
        except Exception:
            pass
        watcher.stop()
        client.running = False
        try:
            if client.ws:
                client.ws.close()
        except Exception:
            pass

    sys.exit(rc)


if __name__ == '__main__':
    main()
