"""RSECTION-specific settings."""

import os
from typing import Optional

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class RSECTIONConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RSECTION_", extra="ignore")

    exe_path: str = r"C:\Program Files\Dlubal\RSECTION 1\bin\RSECTION1.exe"
    url: str = "127.0.0.1"
    port: int = 9000
    api_key_name: str = "default"
    api_key: Optional[str] = None

    @model_validator(mode="after")
    def resolve_api_key(self) -> "RSECTIONConfig":
        if self.api_key:
            return self
        env_key = os.environ.get("RSECTION_API_KEY") or os.environ.get("DLUBAL_API_KEY")
        if env_key:
            self.api_key = env_key
            return self
        from dlubal_mcp.core.config import load_api_key_from_ini
        self.api_key = load_api_key_from_ini(self.api_key_name)
        return self
