"""RSECTION gRPC session — new connection per script call via context manager."""

import logging
import threading
import time
from contextlib import contextmanager
from typing import Optional

logger = logging.getLogger("dlubal_mcp.rsection")


class RSECTIONSession:
    """
    Per-call RSECTION connection with a serialising lock.
    Each run_rsection_script() call opens a fresh connection and closes it on exit.
    """

    def __init__(self, api_key_name: str, api_key_value: Optional[str], url: str, port: int):
        self._lock = threading.Lock()
        self._api_key_name = api_key_name
        self._api_key_value = api_key_value or ""
        self._url = url
        self._port = port

    @contextmanager
    def connection(self, timeout: float = 600.0):
        acquired = self._lock.acquire(timeout=timeout)
        if not acquired:
            raise RuntimeError("RSECTION is busy executing another request. Try again when it finishes.")
        app = None
        try:
            for attempt in range(3):
                try:
                    from dlubal.api.rsection.application import Application
                    app = Application(
                        api_key_name=self._api_key_name,
                        api_key_value=self._api_key_value,
                        url=self._url,
                        port=self._port,
                    )
                    break
                except Exception:
                    if attempt == 2:
                        raise
                    time.sleep(0.5)
            yield app
        finally:
            self._lock.release()
            if app is not None:
                try:
                    app.close_connection()
                except Exception as exc:
                    logger.warning("close_connection failed (ignored): %s", exc)

    def is_api_reachable(self) -> bool:
        """Quick non-destructive probe — tries to open and immediately close a connection."""
        try:
            with self.connection(timeout=5.0):
                return True
        except Exception:
            return False
