"""RSECTION MCP tools: rsection_start, rsection_run_script."""

import io
import logging
import os
import queue
import subprocess
import sys
import threading
import time
import traceback

from fastmcp import FastMCP

from dlubal_mcp.core.sandbox import SAFE_BUILTINS, validate_code_ast
from dlubal_mcp.rsection.session import RSECTIONSession

logger = logging.getLogger("dlubal_mcp.rsection")

_EXE_ENV = "RSECTION_EXE_PATH"
_PROCESS_NAME = "RSECTION1.exe"


def _default_exe(config) -> str:
    return os.environ.get(_EXE_ENV, config.exe_path)


def _is_running(exe_name: str = _PROCESS_NAME) -> bool:
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {exe_name}", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        return exe_name in result.stdout
    except Exception:
        return False


def register_tools(mcp: FastMCP, session: RSECTIONSession, config) -> list[str]:
    """Register RSECTION tools on the shared FastMCP instance. Returns list of registered tool names."""

    @mcp.tool(description="Starts RSECTION 1 on the local machine if not already running. Waits until the gRPC API is reachable. Returns a status message.")
    def rsection_start() -> str:
        try:
            with session.connection(timeout=5.0):
                return "RSECTION 1 is already running and API is connected."
        except RuntimeError as exc:
            return str(exc)
        except Exception:
            pass

        already_running = _is_running()
        exe = _default_exe(config)

        if not already_running:
            if not os.path.exists(exe):
                return f"RSECTION 1 executable not found at: {exe}. Set RSECTION_EXE_PATH to override."
            try:
                subprocess.Popen([exe], creationflags=subprocess.DETACHED_PROCESS)
                logger.info("RSECTION 1 process launched.")
            except Exception as exc:
                return f"Failed to start RSECTION 1: {exc}"

        for i in range(22):
            time.sleep(2)
            try:
                with session.connection(timeout=5.0):
                    elapsed = (i + 1) * 2
                    return (
                        f"RSECTION 1 API is now connected (waited ~{elapsed}s)."
                        if already_running
                        else f"RSECTION 1 started and API connected (took ~{elapsed}s)."
                    )
            except RuntimeError as exc:
                return str(exc)
            except Exception:
                continue

        if _is_running():
            return "RSECTION 1 process is running but API is not yet reachable. Try again in a few seconds."
        return "RSECTION 1 could not be started. Check the installation path."

    @mcp.tool(description="""Executes Python code against a live RSECTION 1 connection.

Available objects: 'app' (RSECTION Application), 'rsection' (dlubal.api.rsection module), 'math'.
No imports or 'with' blocks needed. A fresh connection is opened per call and closed automatically.

CRITICAL DATA TYPES (Protobuf gRPC):
- element_nodes, nodes, elements: ALWAYS int lists e.g. [1, 2] — NEVER strings!
- Enum fields: full label string e.g. "ELEMENT_TYPE_LINE", "MATERIAL_TYPE_STEEL"
- thickness values: always float in meters

Example — create a rectangular cross-section:
  app.delete_all_objects()
  app.create_object(rsection.structure_core.Material(no=1, name="S235"))
  app.create_object(rsection.structure_core.Section(no=1, name="My Section"))
  app.create_object(rsection.structure_core.Part(no=1, section=1, material=1))
  app.create_object(rsection.structure_core.Element(no=1, part=1, element_type="ELEMENT_TYPE_LINE", definition_nodes=[1, 2]))
""")
    def rsection_run_script(code: str) -> str:
        from dlubal.api import rsection, common
        from dlubal_mcp.core.logging_config import log_tool_call

        start = time.monotonic()

        error = validate_code_ast(code, available_objects="app, rsection, common, math")
        if error:
            log_tool_call("rsection_run_script", "server", (time.monotonic() - start) * 1000, False)
            return error

        try:
            with session.connection() as active_app:
                safe_globals = {
                    "__builtins__": SAFE_BUILTINS.copy(),
                    "rsection": rsection,
                    "common": common,
                    "app": active_app,
                    "math": __import__("math"),
                }

                capture = io.StringIO()
                result_q: queue.Queue[str] = queue.Queue()

                def _run():
                    orig = sys.stdout
                    sys.stdout = capture
                    try:
                        exec(code, safe_globals, safe_globals)  # noqa: S102
                        result_q.put("Success")
                    except Exception:
                        result_q.put(f"RuntimeError: {traceback.format_exc()}")
                    finally:
                        sys.stdout = orig

                t = threading.Thread(target=_run, daemon=True)
                t.start()
                t.join(timeout=120)

                duration_ms = (time.monotonic() - start) * 1000

                if t.is_alive():
                    log_tool_call("rsection_run_script", "server", duration_ms, False)
                    return "TimeoutError: Script exceeded 120s. Calculation may still be running in the background."

                status = result_q.get()
                output = capture.getvalue()

                if status == "Success":
                    log_tool_call("rsection_run_script", "server", duration_ms, True)
                    return f"Output:\n{output}" if output.strip() else "Command executed. (No textual output)"

                log_tool_call("rsection_run_script", "server", duration_ms, False)
                return status

        except RuntimeError as exc:
            log_tool_call("rsection_run_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: {exc}"
        except Exception as exc:
            log_tool_call("rsection_run_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: Could not connect to RSECTION. Is it running? Error: {exc}"

    return ["rsection_start", "rsection_run_script"]
