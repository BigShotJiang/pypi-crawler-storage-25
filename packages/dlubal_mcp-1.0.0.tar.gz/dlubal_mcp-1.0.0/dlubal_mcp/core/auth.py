"""API key authentication middleware."""

import logging
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger("dlubal_mcp.auth")

_PUBLIC_PATHS = frozenset({"/health", "/favicon.ico"})


class APIKeyAuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, allowed_keys: set[str], require_auth: bool = True):
        super().__init__(app)
        self.allowed_keys = allowed_keys
        self.require_auth = require_auth

    async def dispatch(self, request: Request, call_next):
        if request.url.path in _PUBLIC_PATHS:
            return await call_next(request)

        if not self.require_auth:
            request.state.api_key = "anonymous"
            return await call_next(request)

        api_key = self._extract_key(request)
        if not api_key:
            logger.warning("Missing API key from %s", request.client.host if request.client else "unknown")
            return JSONResponse(
                status_code=401,
                content={"error": "Missing Authorization header. Use: Authorization: Bearer <key>"},
            )

        if api_key not in self.allowed_keys:
            logger.warning("Invalid API key from %s", request.client.host if request.client else "unknown")
            return JSONResponse(status_code=403, content={"error": "Invalid API key."})

        request.state.api_key = api_key
        return await call_next(request)

    @staticmethod
    def _extract_key(request: Request) -> Optional[str]:
        auth = request.headers.get("authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        # SSE clients (browsers) cannot set headers on EventSource
        return request.query_params.get("api_key")
