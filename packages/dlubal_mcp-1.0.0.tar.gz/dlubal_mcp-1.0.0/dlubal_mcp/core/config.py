"""Pydantic settings for the Dlubal MCP server."""

import configparser
import os
import sys
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


def load_api_key_from_ini(key_name: str = "default") -> Optional[str]:
    """Load a Dlubal gRPC API key from config.ini. Returns None if not found."""
    config_ini_path = os.environ.get("DLUBAL_CONFIG_INI_PATH", "dlubal/api")

    candidates: list[Path] = [Path(config_ini_path) / "config.ini"]
    for parent in Path(__file__).parents:
        candidates.append(parent / config_ini_path / "config.ini")
    candidates.append(Path(sys.executable).parent / config_ini_path / "config.ini")

    for candidate in candidates:
        if candidate.exists():
            cfg = configparser.ConfigParser()
            cfg.read(candidate)
            if "api_keys" in cfg and key_name in cfg["api_keys"]:
                return cfg["api_keys"][key_name] or None

    return None


class DlubalMCPSettings(BaseSettings):
    """Unified server settings. All fields are configurable via DLUBAL_MCP_* env vars."""

    model_config = SettingsConfigDict(
        env_prefix="DLUBAL_MCP_",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Server
    host: str = "127.0.0.1"
    port: int = 7130
    transport: str = "streamable-http"
    cors_origins: str = "http://localhost:3001,http://localhost:3100"

    # Inbound auth (clients authenticating TO this server)
    require_auth: bool = False
    allowed_api_keys: str = ""
    rate_limit_rpm: int = 30

    # Logging
    log_level: str = "INFO"
    log_json: bool = True

    def get_allowed_keys(self) -> set[str]:
        """Parse allowed_api_keys into a set."""
        keys: set[str] = set()
        env_keys = os.environ.get("ALLOWED_API_KEYS", self.allowed_api_keys)
        if env_keys:
            keys.update(k.strip() for k in env_keys.split(",") if k.strip())
        return keys
