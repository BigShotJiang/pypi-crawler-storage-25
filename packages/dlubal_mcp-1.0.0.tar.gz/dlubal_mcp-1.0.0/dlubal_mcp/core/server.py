"""FastMCP app factory, product registry, and ASGI app builder."""

import json
import logging
import os
import subprocess
from dataclasses import dataclass, field
from typing import Callable, Optional

from fastmcp import FastMCP
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

from dlubal_mcp.core.auth import APIKeyAuthMiddleware
from dlubal_mcp.core.config import DlubalMCPSettings
from dlubal_mcp.core.rate_limit import RateLimitMiddleware

logger = logging.getLogger("dlubal_mcp")

__version__ = "1.0.0"


@dataclass
class ProductState:
    name: str
    installed: bool
    _is_running_fn: Optional[Callable[[], bool]] = field(default=None, repr=False)

    @property
    def running(self) -> bool:
        if not self.installed or self._is_running_fn is None:
            return False
        return self._is_running_fn()


class ProductRegistry:
    def __init__(self):
        self._products: dict[str, ProductState] = {}
        self._tools: list[str] = []

    def register(self, name: str, exe_path: str, is_running_fn: Optional[Callable] = None) -> ProductState:
        state = ProductState(
            name=name,
            installed=bool(exe_path) and os.path.exists(exe_path),
            _is_running_fn=is_running_fn,
        )
        self._products[name] = state
        return state

    def add_tools(self, names: list[str]) -> None:
        self._tools.extend(names)

    def health_dict(self, require_auth: bool) -> dict:
        products = {}
        for name, state in self._products.items():
            if state.installed:
                products[name] = {"installed": True, "running": state.running}
            else:
                products[name] = {"installed": False}
        return {
            "version": __version__,
            "products": products,
            "tools": list(self._tools),
            "auth_required": require_auth,
        }


def _proc_running(exe_name: str) -> bool:
    try:
        r = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {exe_name}", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        return exe_name in r.stdout
    except Exception:
        return False


def _build_mcp(settings: DlubalMCPSettings, registry: ProductRegistry) -> FastMCP:
    """Instantiate FastMCP and register tools for all products. Mutates registry."""
    mcp = FastMCP("dlubal-mcp")

    # --- RFEM ---
    try:
        from dlubal_mcp.rfem.config import RFEMConfig
        from dlubal_mcp.rfem.session import RFEMSession
        from dlubal_mcp.rfem import tools as rfem_tools
        rfem_cfg = RFEMConfig()
        registry.register("rfem", rfem_cfg.exe_path, lambda: _proc_running("RFEM6.exe"))
        rfem_session = RFEMSession(rfem_cfg.api_key_name, rfem_cfg.api_key, rfem_cfg.url, rfem_cfg.api_port)
        registry.add_tools(rfem_tools.register_tools(mcp, rfem_session, rfem_cfg))
        logger.info("RFEM tools registered.")
    except ImportError:
        registry.register("rfem", "")
        logger.debug("dlubal.api.rfem not available — RFEM tools skipped.")

    # --- RSTAB ---
    try:
        from dlubal_mcp.rstab.config import RSTABConfig
        from dlubal_mcp.rstab.session import RSTABSession
        from dlubal_mcp.rstab import tools as rstab_tools
        rstab_cfg = RSTABConfig()
        registry.register("rstab", rstab_cfg.exe_path, lambda: _proc_running("RSTAB9.exe"))
        rstab_session = RSTABSession(rstab_cfg.api_key_name, rstab_cfg.api_key, rstab_cfg.url, rstab_cfg.port)
        registry.add_tools(rstab_tools.register_tools(mcp, rstab_session, rstab_cfg))
        logger.info("RSTAB tools registered.")
    except ImportError:
        registry.register("rstab", "")
        logger.debug("dlubal.api.rstab not available — RSTAB tools skipped.")

    # --- RSECTION ---
    try:
        from dlubal_mcp.rsection.config import RSECTIONConfig
        from dlubal_mcp.rsection.session import RSECTIONSession
        from dlubal_mcp.rsection import tools as rsection_tools
        rsection_cfg = RSECTIONConfig()
        registry.register("rsection", rsection_cfg.exe_path, lambda: _proc_running("RSECTION1.exe"))
        rsection_session = RSECTIONSession(rsection_cfg.api_key_name, rsection_cfg.api_key, rsection_cfg.url, rsection_cfg.port)
        registry.add_tools(rsection_tools.register_tools(mcp, rsection_session, rsection_cfg))
        logger.info("RSECTION tools registered.")
    except ImportError:
        registry.register("rsection", "")
        logger.debug("dlubal.api.rsection not available — RSECTION tools skipped.")

    # --- health_check MCP tool (AC6) ---
    @mcp.tool(description="Returns server health: installed products, running state, active tools, and auth status.")
    def health_check() -> str:
        return json.dumps(registry.health_dict(settings.require_auth), indent=2)

    return mcp


def create_asgi_app(settings: DlubalMCPSettings):
    """
    Build the full ASGI application.

    Routes (served at DLUBAL_MCP_PORT, default 7130):
      GET  /health     — public health endpoint, no auth
      POST /mcp        — streamable-http MCP transport (default)
      GET  /mcp        — streamable-http SSE stream
      GET  /mcp/sse    — legacy SSE transport fallback
      POST /mcp/messages/ — legacy SSE message posting

    Middleware (applied to all routes except /health):
      APIKeyAuthMiddleware → RateLimitMiddleware
    """
    registry = ProductRegistry()
    mcp = _build_mcp(settings, registry)

    # Public health endpoint — added directly to FastMCP's route list so it lives
    # inside the same Starlette app (no lifespan/mount complexity).
    async def health_endpoint(request: Request) -> JSONResponse:
        return JSONResponse(registry.health_dict(settings.require_auth))

    mcp._additional_http_routes.append(
        Route("/health", health_endpoint, methods=["GET"])
    )

    # SSE fallback transport at /mcp/sse (legacy clients).
    # FastMCP's SSE app has routes at /sse (GET) and /messages/ (POST).
    # Mounting at /mcp exposes them at /mcp/sse and /mcp/messages/.
    sse_sub = mcp.http_app(transport="sse")
    mcp._additional_http_routes.append(Mount("/mcp", app=sse_sub))

    # Build and return the main ASGI app with auth + rate-limit middleware.
    allowed_keys = settings.get_allowed_keys()
    return mcp.http_app(
        transport=settings.transport,
        middleware=[
            Middleware(APIKeyAuthMiddleware, allowed_keys=allowed_keys, require_auth=settings.require_auth),
            Middleware(RateLimitMiddleware, requests_per_minute=settings.rate_limit_rpm),
        ],
    )
