"""RSTAB MCP tools: rstab_start, rstab_run_script."""

import io
import logging
import os
import queue
import subprocess
import sys
import threading
import time
import traceback

from fastmcp import FastMCP

from dlubal_mcp.core.sandbox import SAFE_BUILTINS, validate_code_ast
from dlubal_mcp.rstab.session import RSTABSession

logger = logging.getLogger("dlubal_mcp.rstab")

_EXE_ENV = "RSTAB_EXE_PATH"
_PROCESS_NAME = "RSTAB9.exe"


def _default_exe(config) -> str:
    return os.environ.get(_EXE_ENV, config.exe_path)


def _is_running(exe_name: str = _PROCESS_NAME) -> bool:
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {exe_name}", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        return exe_name in result.stdout
    except Exception:
        return False


def register_tools(mcp: FastMCP, session: RSTABSession, config) -> list[str]:
    """Register RSTAB tools on the shared FastMCP instance. Returns list of registered tool names."""

    @mcp.tool(description="Starts RSTAB 9 on the local machine if not already running. Waits until the gRPC API is reachable. Returns a status message.")
    def rstab_start() -> str:
        try:
            with session.connection(timeout=5.0):
                return "RSTAB 9 is already running and API is connected."
        except RuntimeError as exc:
            return str(exc)
        except Exception:
            pass

        already_running = _is_running()
        exe = _default_exe(config)

        if not already_running:
            if not os.path.exists(exe):
                return f"RSTAB 9 executable not found at: {exe}. Set RSTAB_EXE_PATH to override."
            try:
                subprocess.Popen([exe], creationflags=subprocess.DETACHED_PROCESS)
                logger.info("RSTAB 9 process launched.")
            except Exception as exc:
                return f"Failed to start RSTAB 9: {exc}"

        for i in range(22):
            time.sleep(2)
            try:
                with session.connection(timeout=5.0):
                    elapsed = (i + 1) * 2
                    return (
                        f"RSTAB 9 API is now connected (waited ~{elapsed}s)."
                        if already_running
                        else f"RSTAB 9 started and API connected (took ~{elapsed}s)."
                    )
            except RuntimeError as exc:
                return str(exc)
            except Exception:
                continue

        if _is_running():
            return "RSTAB 9 process is running but API is not yet reachable. Try again in a few seconds."
        return "RSTAB 9 could not be started. Check the installation path."

    @mcp.tool(description="""Executes Python code against a live RSTAB 9 connection.

Available objects: 'app' (RSTAB Application), 'rstab' (dlubal.api.rstab module), 'math'.
No imports or 'with' blocks needed.

CRITICAL DATA TYPES (Protobuf gRPC):
- definition_nodes, nodes, members: ALWAYS int lists e.g. [1, 2] — NEVER strings!
- Enum fields: full label string e.g. "ANALYSIS_TYPE_GEOMETRICALLY_LINEAR", "TYPE_BEAM"
- load_direction: "LOAD_DIRECTION_GLOBAL_Z_OR_USER_DEFINED_W_TRUE_LENGTH"

Example — create a simply supported beam:
  app.delete_all_objects()
  app.create_object(rstab.structure_core.Material(no=1, name="S235"))
  app.create_object(rstab.structure_core.CrossSection(no=1, name="IPE 240", material=1))
  app.create_object(rstab.structure_core.Node(no=1, coordinate_1=0.0, coordinate_2=0.0, coordinate_3=0.0))
  app.create_object(rstab.structure_core.Node(no=2, coordinate_1=6.0, coordinate_2=0.0, coordinate_3=0.0))
  app.create_object(rstab.structure_core.Line(no=1, definition_nodes=[1, 2]))
  app.create_object(rstab.structure_core.Member(no=1, line=1, cross_section_start=1))
""")
    def rstab_run_script(code: str) -> str:
        from dlubal.api import rstab, common
        from dlubal_mcp.core.logging_config import log_tool_call

        start = time.monotonic()

        error = validate_code_ast(code, available_objects="app, rstab, common, math")
        if error:
            log_tool_call("rstab_run_script", "server", (time.monotonic() - start) * 1000, False)
            return error

        try:
            with session.connection() as active_app:
                safe_globals = {
                    "__builtins__": SAFE_BUILTINS.copy(),
                    "rstab": rstab,
                    "common": common,
                    "app": active_app,
                    "math": __import__("math"),
                }

                capture = io.StringIO()
                result_q: queue.Queue[str] = queue.Queue()

                def _run():
                    orig = sys.stdout
                    sys.stdout = capture
                    try:
                        exec(code, safe_globals, safe_globals)  # noqa: S102
                        result_q.put("Success")
                    except Exception:
                        result_q.put(f"RuntimeError: {traceback.format_exc()}")
                    finally:
                        sys.stdout = orig

                t = threading.Thread(target=_run, daemon=True)
                t.start()
                t.join(timeout=120)

                duration_ms = (time.monotonic() - start) * 1000

                if t.is_alive():
                    log_tool_call("rstab_run_script", "server", duration_ms, False)
                    return "TimeoutError: Script exceeded 120s. Calculation may still be running in the background."

                status = result_q.get()
                output = capture.getvalue()

                if status == "Success":
                    log_tool_call("rstab_run_script", "server", duration_ms, True)
                    return f"Output:\n{output}" if output.strip() else "Command executed. (No textual output)"

                log_tool_call("rstab_run_script", "server", duration_ms, False)
                return status

        except RuntimeError as exc:
            log_tool_call("rstab_run_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: {exc}"
        except Exception as exc:
            log_tool_call("rstab_run_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: Could not connect to RSTAB. Is it running? Error: {exc}"

    return ["rstab_start", "rstab_run_script"]
