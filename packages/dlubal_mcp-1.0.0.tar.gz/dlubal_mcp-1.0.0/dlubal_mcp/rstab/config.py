"""RSTAB-specific settings."""

import os
from typing import Optional

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class RSTABConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RSTAB_", extra="ignore")

    exe_path: str = r"C:\Program Files\Dlubal\RSTAB 9\bin\RSTAB9.exe"
    url: str = "127.0.0.1"
    port: int = 9001
    api_key_name: str = "default"
    api_key: Optional[str] = None

    @model_validator(mode="after")
    def resolve_api_key(self) -> "RSTABConfig":
        if self.api_key:
            return self
        env_key = os.environ.get("RSTAB_API_KEY") or os.environ.get("DLUBAL_API_KEY")
        if env_key:
            self.api_key = env_key
            return self
        from dlubal_mcp.core.config import load_api_key_from_ini
        self.api_key = load_api_key_from_ini(self.api_key_name)
        return self
