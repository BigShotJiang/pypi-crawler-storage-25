"""RFEM MCP tools: start_rfem, run_rfem_script."""

import io
import json
import logging
import os
import queue
import subprocess
import sys
import threading
import time
import traceback

from fastmcp import FastMCP

from dlubal_mcp.core.sandbox import SAFE_BUILTINS, validate_code_ast
from dlubal_mcp.rfem.session import RFEMSession

logger = logging.getLogger("dlubal_mcp.rfem")

_EXE_ENV = "RFEM_EXE_PATH"
_PROCESS_NAME = "RFEM6.exe"


def _default_exe(config) -> str:
    return os.environ.get(_EXE_ENV, config.exe_path)


def _is_running(exe_name: str = _PROCESS_NAME) -> bool:
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {exe_name}", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        return exe_name in result.stdout
    except Exception:
        return False


_ORIENTATION_PREAMBLE = """\
try:
    _bd_orient = app.get_base_data()
    z_up = (_bd_orient.general_settings.global_axes_orientation ==
            rfem.BaseData.GeneralSettings.GLOBAL_AXES_ORIENTATION_ZUP)
except Exception:
    z_up = False
gravity_sign = -1 if z_up else 1
z = (lambda h: h) if z_up else (lambda h: -h)
print("[Z-axis: " + ("UP" if z_up else "DOWN") + ", gravity_sign=" + str(gravity_sign) + "]")

def refresh_orientation():
    global z_up, gravity_sign, z
    try:
        _bd2 = app.get_base_data()
        z_up = (_bd2.general_settings.global_axes_orientation ==
                rfem.BaseData.GeneralSettings.GLOBAL_AXES_ORIENTATION_ZUP)
    except Exception:
        z_up = False
    gravity_sign = -1 if z_up else 1
    z = (lambda h: h) if z_up else (lambda h: -h)
    print("[Orientation refreshed: Z-" + ("UP" if z_up else "DOWN") + "]")

"""


def register_tools(mcp: FastMCP, session: RFEMSession, config) -> list[str]:
    """Register RFEM tools on the shared FastMCP instance. Returns list of registered tool names."""

    @mcp.tool(description="Starts RFEM 6 on the local machine if not already running. Waits until the gRPC API is reachable. Returns a status message.")
    def start_rfem() -> str:
        try:
            with session.connection(timeout=5.0):
                return "RFEM 6 is already running and API is connected."
        except RuntimeError as exc:
            return str(exc)
        except Exception:
            pass

        already_running = _is_running()
        exe = _default_exe(config)

        if not already_running:
            if not os.path.exists(exe):
                return f"RFEM 6 executable not found at: {exe}. Set RFEM_EXE_PATH to override."
            try:
                subprocess.Popen([exe], creationflags=subprocess.DETACHED_PROCESS)
                logger.info("RFEM 6 process launched.")
            except Exception as exc:
                return f"Failed to start RFEM 6: {exc}"

        for i in range(22):
            time.sleep(2)
            try:
                with session.connection(timeout=5.0):
                    elapsed = (i + 1) * 2
                    return (
                        f"RFEM 6 API is now connected (waited ~{elapsed}s)."
                        if already_running
                        else f"RFEM 6 started and API connected (took ~{elapsed}s)."
                    )
            except RuntimeError as exc:
                return str(exc)
            except Exception:
                continue

        if _is_running():
            return "RFEM 6 process is running but API is not yet reachable. Try again in a few seconds."
        return "RFEM 6 could not be started. Check the installation path."

    @mcp.tool(description="""Executes Python code against a live RFEM 6 connection.

Available objects: 'app' (RFEM Application), 'rfem' (dlubal.api.rfem module), 'math'.
No imports or 'with' blocks needed.

CRITICAL DATA TYPES (Protobuf gRPC):
- definition_nodes, nodes, members: ALWAYS int lists e.g. [1, 2] — NEVER strings!
- Enum fields: full label string e.g. "ANALYSIS_TYPE_GEOMETRICALLY_LINEAR", "TYPE_BEAM"
- load_direction: "LOAD_DIRECTION_GLOBAL_Z_OR_USER_DEFINED_W_TRUE_LENGTH"

Example — create a simply supported beam:
  app.delete_all_objects()
  app.create_object(rfem.structure_core.Material(no=1, name="S235"))
  app.create_object(rfem.structure_core.CrossSection(no=1, name="IPE 240", material=1))
  app.create_object(rfem.structure_core.Node(no=1, coordinate_1=0.0, coordinate_2=0.0, coordinate_3=0.0))
  app.create_object(rfem.structure_core.Node(no=2, coordinate_1=6.0, coordinate_2=0.0, coordinate_3=0.0))
  app.create_object(rfem.structure_core.Line(no=1, definition_nodes=[1, 2]))
  app.create_object(rfem.structure_core.Member(no=1, line=1, cross_section_start=1))
  app.create_object(rfem.types_for_nodes.NodalSupport(no=1, nodes=[1], spring_x=float('inf'), spring_y=float('inf'), spring_z=float('inf')))
  app.create_object(rfem.types_for_nodes.NodalSupport(no=2, nodes=[2], spring_y=float('inf'), spring_z=float('inf')))
  app.create_object(rfem.loading.StaticAnalysisSettings(no=1, analysis_type="ANALYSIS_TYPE_GEOMETRICALLY_LINEAR"))
  app.create_object(rfem.loading.LoadCase(no=1, name="LC1", static_analysis_settings=1, to_solve=True))
  app.create_object(rfem.loads.MemberLoad(no=1, load_type="LOAD_TYPE_FORCE", members=[1], load_case=1, load_distribution="LOAD_DISTRIBUTION_UNIFORM", load_direction="LOAD_DIRECTION_GLOBAL_Z_OR_USER_DEFINED_W_TRUE_LENGTH", magnitude=-10000))
""")
    def run_rfem_script(code: str) -> str:
        from dlubal.api import rfem, common
        from dlubal_mcp.core.logging_config import log_tool_call

        start = time.monotonic()

        error = validate_code_ast(code, available_objects="app, rfem, common, math")
        if error:
            log_tool_call("run_rfem_script", "server", (time.monotonic() - start) * 1000, False)
            return error

        try:
            with session.connection() as active_app:
                safe_globals = {
                    "__builtins__": SAFE_BUILTINS.copy(),
                    "rfem": rfem,
                    "common": common,
                    "app": active_app,
                    "math": __import__("math"),
                }

                capture = io.StringIO()
                result_q: queue.Queue[str] = queue.Queue()

                def _run():
                    orig = sys.stdout
                    sys.stdout = capture
                    try:
                        exec(_ORIENTATION_PREAMBLE + code, safe_globals, safe_globals)  # noqa: S102
                        result_q.put("Success")
                    except Exception:
                        result_q.put(f"RuntimeError: {traceback.format_exc()}")
                    finally:
                        sys.stdout = orig

                t = threading.Thread(target=_run, daemon=True)
                t.start()
                t.join(timeout=120)

                duration_ms = (time.monotonic() - start) * 1000

                if t.is_alive():
                    log_tool_call("run_rfem_script", "server", duration_ms, False)
                    return "TimeoutError: Script exceeded 120s. Calculation may still be running in the background."

                status = result_q.get()
                output = capture.getvalue()

                if status == "Success":
                    log_tool_call("run_rfem_script", "server", duration_ms, True)
                    return f"Output:\n{output}" if output.strip() else "Command executed. (No textual output)"

                log_tool_call("run_rfem_script", "server", duration_ms, False)
                return status

        except RuntimeError as exc:
            log_tool_call("run_rfem_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: {exc}"
        except Exception as exc:
            log_tool_call("run_rfem_script", "server", (time.monotonic() - start) * 1000, False)
            return f"CRITICAL: Could not connect to RFEM. Is it running? Error: {exc}"

    return ["start_rfem", "run_rfem_script"]
