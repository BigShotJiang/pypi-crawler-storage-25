"""Tests for ExecutorManager autoscaling logic."""
from types import SimpleNamespace
from unittest.mock import MagicMock


from fastpluggy_plugin.tasks_worker.core.executor_manager import ExecutorManager


def _make_autoscale_cfg(**overrides):
    defaults = dict(
        autoscale_enabled=True,
        autoscale_min_capacity=2,
        autoscale_max_capacity=20,
        autoscale_scale_up_threshold=0.9,
        autoscale_scale_down_threshold=0.2,
        autoscale_scale_step=2,
        autoscale_window=3,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_manager(pool_stats, autoscale_cfg=None, capacity_setter=None):
    broker = MagicMock()
    broker.get_all_topic_configs.return_value = {}
    executor = MagicMock()
    executor.get_pool_stats.return_value = pool_stats
    executor.add_topic = MagicMock()
    cfg = autoscale_cfg or _make_autoscale_cfg()
    mgr = ExecutorManager(
        broker=broker,
        executor=executor,
        topics=["default"],
        autoscale_cfg=cfg,
        capacity_setter=capacity_setter,
    )
    return mgr, executor


class TestAutoscaleUp:
    def test_scales_up_after_sustained_high_utilisation(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 8, "running_tasks": 8},
            capacity_setter=lambda c: capacities.append(c),
        )
        # Feed enough high-utilisation ticks (window=3)
        for _ in range(3):
            mgr._autoscale_tick()

        assert len(capacities) == 1
        assert capacities[0] == 10  # 8 + step(2)
        assert executor.max_workers == 10

    def test_does_not_scale_up_before_window(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 8, "running_tasks": 8},
            capacity_setter=lambda c: capacities.append(c),
        )
        # Only 2 ticks, window=3
        mgr._autoscale_tick()
        mgr._autoscale_tick()

        assert len(capacities) == 0

    def test_respects_max_capacity(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 19, "running_tasks": 19},
            autoscale_cfg=_make_autoscale_cfg(autoscale_max_capacity=20),
            capacity_setter=lambda c: capacities.append(c),
        )
        for _ in range(3):
            mgr._autoscale_tick()

        assert capacities[0] == 20  # capped at max


class TestAutoscaleDown:
    def test_scales_down_after_sustained_low_utilisation(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 10, "running_tasks": 1},
            capacity_setter=lambda c: capacities.append(c),
        )
        for _ in range(3):
            mgr._autoscale_tick()

        assert len(capacities) == 1
        assert capacities[0] == 8  # 10 - step(2)
        assert executor.max_workers == 8

    def test_respects_min_capacity(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 3, "running_tasks": 0},
            autoscale_cfg=_make_autoscale_cfg(autoscale_min_capacity=2),
            capacity_setter=lambda c: capacities.append(c),
        )
        for _ in range(3):
            mgr._autoscale_tick()

        assert capacities[0] == 2  # capped at min


class TestAutoscaleStable:
    def test_no_scaling_at_moderate_utilisation(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 10, "running_tasks": 5},  # 50% utilisation
            capacity_setter=lambda c: capacities.append(c),
        )
        for _ in range(5):
            mgr._autoscale_tick()

        assert len(capacities) == 0

    def test_mixed_utilisation_does_not_trigger(self):
        """Alternating high/low should not trigger scaling."""
        capacities = []
        broker = MagicMock()
        broker.get_all_topic_configs.return_value = {}
        executor = MagicMock()
        executor.add_topic = MagicMock()

        cfg = _make_autoscale_cfg()
        mgr = ExecutorManager(
            broker=broker, executor=executor, topics=["default"],
            autoscale_cfg=cfg, capacity_setter=lambda c: capacities.append(c),
        )

        # Alternate between high and low
        for i in range(6):
            if i % 2 == 0:
                executor.get_pool_stats.return_value = {"max_workers": 10, "running_tasks": 10}
            else:
                executor.get_pool_stats.return_value = {"max_workers": 10, "running_tasks": 1}
            mgr._autoscale_tick()

        assert len(capacities) == 0


class TestAutoscaleDisabled:
    def test_disabled_does_not_scale(self):
        capacities = []
        mgr, executor = _make_manager(
            {"max_workers": 8, "running_tasks": 8},
            autoscale_cfg=_make_autoscale_cfg(autoscale_enabled=False),
            capacity_setter=lambda c: capacities.append(c),
        )
        assert not mgr._autoscale_enabled
