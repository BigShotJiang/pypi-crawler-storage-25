import pytest
import os
import logging
import time
from unittest.mock import patch
from fastpluggy_plugin.tasks_worker import start_workers_if_available, TaskWorker
from fastpluggy_plugin.tasks_worker.broker.local import LocalBroker

logger = logging.getLogger(__name__)

# Skip Docker-dependent tests when Docker is not available
try:
    import docker
    _client = docker.from_env()
    _client.ping()
    _has_docker = True
except Exception:
    _has_docker = False

requires_docker = pytest.mark.skipif(not _has_docker, reason="Docker not available")


def _stop_runners(runners):
    """Stop all runners (heartbeat + executor) to avoid leaking threads."""
    for runner in runners:
        try:
            runner.stop()
        except Exception:
            pass


def test_worker_count_local(fast_pluggy):
    """Test that the number of workers started matches WORKER_NUMBER for local broker."""
    worker_count = 3
    env = {"WORKER_NUMBER": str(worker_count), "BROKER_TYPE": "local", "BROKER_DSN": ""}
    with patch.dict(os.environ, env, clear=False):
        TaskWorker._broker = None

        with patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=True), \
             patch("fastpluggy_plugin.tasks_worker.TaskWorker.submit"):

            runners = start_workers_if_available()
            assert runners, "Expected at least one runner"
            assert len(runners) == worker_count

            broker = TaskWorker.get_broker()
            workers = []
            for _ in range(20):  # up to 10 seconds
                time.sleep(0.5)
                workers = broker.get_workers()
                if len(workers) >= worker_count:
                    break

            assert len(workers) >= worker_count
            logger.info(f"Verified {len(workers)} workers registered in LocalBroker")

            _stop_runners(runners)


@requires_docker
def test_worker_count_postgres(fast_pluggy):
    """Test that workers register and are visible in PostgresBroker.

    Uses direct broker API rather than start_workers_if_available to isolate
    the broker registration from the complex init_worker path.
    """
    from testcontainers.postgres import PostgresContainer
    from fastpluggy_plugin.tasks_worker.broker.postgres import PostgresBroker

    worker_count = 2

    with PostgresContainer("postgres:15-alpine") as postgres:
        db_url = postgres.get_connection_url()
        if db_url.startswith("postgresql+psycopg2://"):
            db_url = db_url.replace("postgresql+psycopg2://", "postgresql+psycopg://", 1)
        elif db_url.startswith("postgresql://"):
            db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)

        broker = PostgresBroker(database_url=db_url)
        broker.setup()

        # Register workers directly
        for i in range(worker_count):
            broker.register_worker(
                worker_id=f"test-worker-{i}",
                pid=os.getpid(),
                host="localhost",
                topics=["default"],
                capacity=8,
                role="worker",
            )

        # Workers should be visible immediately (synchronous DB write)
        workers = broker.get_workers()
        assert len(workers) == worker_count, (
            f"Expected {worker_count} workers, got {len(workers)}. "
            f"Worker IDs: {[w.worker_id for w in workers]}"
        )
        logger.info(f"Verified {len(workers)} workers registered in PostgresBroker")
