"""
Tests for TaskRunnerPlugin.get_metrics() — MetricsProvider capability.

Validates that broker stats and telemetry snapshots are correctly
wrapped into MetricsResult entries without requiring a live broker.
"""

from unittest.mock import MagicMock, patch
from dataclasses import dataclass

import pytest

from fastpluggy.core.metrics import MetricEntry, MetricsResult, MetricsProvider
from fastpluggy_plugin.tasks_worker.plugin import TaskRunnerPlugin, _topic_val
from fastpluggy_plugin.tasks_worker.broker.contracts import TopicInfo, TopicConfig


# ── Fixtures ─────────────────────────────────────────────────────────────


@dataclass
class FakeTopicInfo:
    topic: str
    queued: int
    running: int
    dead_letter: int
    subscribers: int


def _make_broker(topics=None, workers=None, locks=None):
    """Create a mock broker with configurable topic/worker/lock data."""
    broker = MagicMock()
    broker.get_topics.return_value = topics or []
    broker.get_workers.return_value = workers or []
    broker.get_locks.return_value = locks or []
    return broker


def _make_plugin():
    """Create a TaskRunnerPlugin instance for testing."""
    return TaskRunnerPlugin()


# ── Protocol conformance ─────────────────────────────────────────────────


def test_plugin_satisfies_metrics_provider_protocol():
    """TaskRunnerPlugin must be a runtime-checkable MetricsProvider."""
    plugin = _make_plugin()
    assert isinstance(plugin, MetricsProvider)


def test_capabilities_includes_metrics():
    plugin = _make_plugin()
    assert "metrics" in plugin.capabilities


# ── Return type ──────────────────────────────────────────────────────────


def test_get_metrics_returns_metrics_result():
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker()
        result = plugin.get_metrics()
    assert isinstance(result, MetricsResult)


# ── Broker metrics: no broker available ──────────────────────────────────


def test_get_metrics_no_broker():
    """When the broker is unavailable, get_metrics() returns empty but valid."""
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.side_effect = Exception("no broker")
        result = plugin.get_metrics()

    assert isinstance(result, MetricsResult)
    assert result.gauges == []
    assert result.counters == []


# ── Broker metrics: empty broker ─────────────────────────────────────────


def test_get_metrics_empty_broker():
    """Broker with no topics/workers/locks yields cluster-level zeros."""
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker()
        result = plugin.get_metrics()

    names = {g.name for g in result.gauges}
    assert "fastpluggy_broker_workers" in names
    assert "fastpluggy_broker_topics" in names
    assert "fastpluggy_broker_messages_queued_total" in names
    assert "fastpluggy_broker_messages_running_total" in names

    # All values should be 0
    by_name = {g.name: g for g in result.gauges}
    assert by_name["fastpluggy_broker_workers"].value == 0.0
    assert by_name["fastpluggy_broker_topics"].value == 0.0
    assert by_name["fastpluggy_broker_messages_queued_total"].value == 0.0
    assert by_name["fastpluggy_broker_messages_running_total"].value == 0.0


# ── Broker metrics: with topics ──────────────────────────────────────────


def test_get_metrics_with_topics_dataclass():
    """Topic data from TopicInfo dataclasses produces per-topic gauges."""
    topics = [
        TopicInfo(topic="default", queued=5, running=2, dead_letter=1, subscribers=3),
        TopicInfo(topic="ia", queued=10, running=0, dead_letter=0, subscribers=1),
    ]
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker(topics=topics)
        result = plugin.get_metrics()

    # Find per-topic entries
    topic_queued = [g for g in result.gauges if g.name == "fastpluggy_broker_topic_queued"]
    assert len(topic_queued) == 2
    by_topic = {g.labels["topic"]: g.value for g in topic_queued}
    assert by_topic["default"] == 5.0
    assert by_topic["ia"] == 10.0

    topic_running = [g for g in result.gauges if g.name == "fastpluggy_broker_topic_running"]
    by_topic_r = {g.labels["topic"]: g.value for g in topic_running}
    assert by_topic_r["default"] == 2.0
    assert by_topic_r["ia"] == 0.0

    # Totals
    by_name = {g.name: g for g in result.gauges if not g.labels}
    assert by_name["fastpluggy_broker_messages_queued_total"].value == 15.0
    assert by_name["fastpluggy_broker_messages_running_total"].value == 2.0
    assert by_name["fastpluggy_broker_topics"].value == 2.0


def test_get_metrics_with_topics_dict():
    """Topic data as dicts (e.g. from a remote broker) is also handled."""
    topics = [
        {"topic": "orders", "queued": 3, "running": 1, "dead_letter": 0, "subscribers": 2},
    ]
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker(topics=topics)
        result = plugin.get_metrics()

    topic_queued = [g for g in result.gauges if g.name == "fastpluggy_broker_topic_queued"]
    assert len(topic_queued) == 1
    assert topic_queued[0].labels["topic"] == "orders"
    assert topic_queued[0].value == 3.0


# ── Broker metrics: workers and locks ────────────────────────────────────


def test_get_metrics_counts_workers():
    workers = [MagicMock(), MagicMock(), MagicMock()]
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker(workers=workers)
        result = plugin.get_metrics()

    by_name = {g.name: g for g in result.gauges}
    assert by_name["fastpluggy_broker_workers"].value == 3.0


def test_get_metrics_counts_locks():
    locks = [MagicMock(), MagicMock()]
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = _make_broker(locks=locks)
        result = plugin.get_metrics()

    lock_metrics = [g for g in result.gauges if g.name == "fastpluggy_broker_locks"]
    assert len(lock_metrics) == 1
    assert lock_metrics[0].value == 2.0


# ── Broker metrics: locks exception ─────────────────────────────────────


def test_get_metrics_locks_exception_ignored():
    """If broker.get_locks() raises, locks metric is omitted gracefully."""
    broker = _make_broker()
    broker.get_locks.side_effect = NotImplementedError
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw:
        tw.get_broker.return_value = broker
        result = plugin.get_metrics()

    lock_metrics = [g for g in result.gauges if g.name == "fastpluggy_broker_locks"]
    assert len(lock_metrics) == 0


# ── Telemetry counters ──────────────────────────────────────────────────


def test_get_metrics_with_telemetry():
    """When a worker bus is available, telemetry counters are included."""
    plugin = _make_plugin()
    mock_telemetry = MagicMock()
    mock_telemetry.snapshot.return_value = {
        "submitted_total": 42,
        "completed_total": 37,
        "running": 5,
    }

    mock_bus = MagicMock()

    def _get_instance(cls):
        from fastpluggy_plugin.tasks_worker.subscribers.telemetry import TaskTelemetry
        if cls is TaskTelemetry:
            return mock_telemetry
        return None

    mock_bus.get_instance.side_effect = _get_instance

    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw, patch(
        "fastpluggy.fastpluggy.FastPluggy"
    ) as fp_cls:
        tw.get_broker.return_value = _make_broker()
        fp_inst = MagicMock()
        fp_inst.get_global.return_value = mock_bus
        fp_cls.return_value = fp_inst

        result = plugin.get_metrics()

    # Check counters
    counter_names = {c.name: c for c in result.counters}
    assert "fastpluggy_tasks_submitted_total" in counter_names
    assert counter_names["fastpluggy_tasks_submitted_total"].value == 42.0
    assert "fastpluggy_tasks_completed_total" in counter_names
    assert counter_names["fastpluggy_tasks_completed_total"].value == 37.0

    # Running is a gauge
    running = [g for g in result.gauges if g.name == "fastpluggy_tasks_running"]
    assert len(running) == 1
    assert running[0].value == 5.0


def test_get_metrics_no_telemetry_bus():
    """When no worker bus is registered, telemetry counters are omitted."""
    plugin = _make_plugin()
    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw, patch(
        "fastpluggy.fastpluggy.FastPluggy"
    ) as fp_cls:
        tw.get_broker.return_value = _make_broker()
        fp_inst = MagicMock()
        fp_inst.get_global.return_value = None
        fp_cls.return_value = fp_inst

        result = plugin.get_metrics()

    assert result.counters == []
    running = [g for g in result.gauges if g.name == "fastpluggy_tasks_running"]
    assert len(running) == 0


# ── MetricEntry field validation ─────────────────────────────────────────


def test_metric_entries_have_correct_types():
    """Every MetricEntry.type must be 'gauge' or 'counter'."""
    plugin = _make_plugin()
    topics = [
        TopicInfo(topic="t1", queued=1, running=0, dead_letter=0, subscribers=1),
    ]
    mock_telemetry = MagicMock()
    mock_telemetry.snapshot.return_value = {
        "submitted_total": 1, "completed_total": 0, "running": 1,
    }
    mock_bus = MagicMock()
    mock_bus.get_instance.return_value = mock_telemetry

    with patch(
        "fastpluggy_plugin.tasks_worker.TaskWorker"
    ) as tw, patch(
        "fastpluggy.fastpluggy.FastPluggy"
    ) as fp_cls:
        tw.get_broker.return_value = _make_broker(topics=topics, locks=[MagicMock()])
        fp_inst = MagicMock()
        fp_inst.get_global.return_value = mock_bus
        fp_cls.return_value = fp_inst

        result = plugin.get_metrics()

    for entry in result.all_entries:
        assert entry.type in ("gauge", "counter", "histogram"), (
            f"Unexpected type {entry.type!r} on {entry.name}"
        )
        assert isinstance(entry.value, float), f"{entry.name} value must be float"
        assert isinstance(entry.name, str) and entry.name, f"name must be non-empty str"


# ── _topic_val helper ────────────────────────────────────────────────────


def test_topic_val_dataclass():
    info = FakeTopicInfo(topic="x", queued=7, running=3, dead_letter=0, subscribers=2)
    assert _topic_val(info, "queued") == 7.0
    assert _topic_val(info, "running") == 3.0


def test_topic_val_dict():
    d = {"queued": 12, "running": 4}
    assert _topic_val(d, "queued") == 12.0
    assert _topic_val(d, "running") == 4.0


def test_topic_val_missing():
    assert _topic_val({}, "queued") == 0.0
    assert _topic_val(FakeTopicInfo(topic="x", queued=0, running=0, dead_letter=0, subscribers=0), "missing_attr") == 0.0


def test_topic_val_none_value():
    d = {"queued": None}
    assert _topic_val(d, "queued") == 0.0
