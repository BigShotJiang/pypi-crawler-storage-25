"""Tests for Phase 2 CLI options: --broker-type, --broker-dsn, --topics, --max-workers."""

import os
import unittest
from unittest.mock import MagicMock, call, patch

from click.testing import CliRunner

from fastpluggy_plugin.tasks_worker.cli import tasks_worker_group


class TestBrokerTypeOption(unittest.TestCase):
    """--broker-type sets BROKER_TYPE env var before workers start."""

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_broker_type_sets_env(self, mock_start):
        runner_mock = MagicMock()
        runner_mock.stop = MagicMock()
        mock_start.return_value = [runner_mock]

        cli = CliRunner()
        # Use a short timeout via SIGTERM simulation — we invoke in isolated mode
        # so we just check env was set before start_workers_if_available was called
        captured_env = {}

        def capture_and_return(**kwargs):
            captured_env["BROKER_TYPE"] = os.environ.get("BROKER_TYPE")
            return [runner_mock]

        mock_start.side_effect = capture_and_return

        # Invoke but send EOF to unblock (CliRunner catches SystemExit)
        # Use patch.dict to prevent BROKER_TYPE from leaking into other tests
        with patch.dict(os.environ, {}, clear=False), \
             patch("threading.Event.wait"):
            result = cli.invoke(
                tasks_worker_group, ["start", "--broker-type", "memory"]
            )

        self.assertEqual(captured_env["BROKER_TYPE"], "memory")
        self.assertEqual(result.exit_code, 0)

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_broker_type_not_set_when_omitted(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        captured_env = {}

        def capture_and_return(**kwargs):
            captured_env["BROKER_TYPE"] = os.environ.get("BROKER_TYPE")
            return [runner_mock]

        mock_start.side_effect = capture_and_return
        env_backup = os.environ.pop("BROKER_TYPE", None)
        try:
            cli = CliRunner()
            with patch("threading.Event.wait"):
                cli.invoke(tasks_worker_group, ["start"])
            # Should not have been set by the CLI
            self.assertIsNone(captured_env["BROKER_TYPE"])
        finally:
            if env_backup is not None:
                os.environ["BROKER_TYPE"] = env_backup


class TestBrokerDsnOption(unittest.TestCase):
    """--broker-dsn sets BROKER_DSN env var."""

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_broker_dsn_sets_env(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        captured_env = {}

        def capture_and_return(**kwargs):
            captured_env["BROKER_DSN"] = os.environ.get("BROKER_DSN")
            return [runner_mock]

        mock_start.side_effect = capture_and_return

        cli = CliRunner()
        # Use patch.dict to prevent BROKER_DSN from leaking into other tests
        with patch.dict(os.environ, {}, clear=False), \
             patch("threading.Event.wait"):
            result = cli.invoke(
                tasks_worker_group,
                ["start", "--broker-dsn", "amqp://guest:guest@localhost"],
            )

        self.assertEqual(captured_env["BROKER_DSN"], "amqp://guest:guest@localhost")
        self.assertEqual(result.exit_code, 0)


class TestTopicsOption(unittest.TestCase):
    """--topics parses comma-separated list and passes to start_workers_if_available."""

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_topics_parsed_and_forwarded(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        cli = CliRunner()
        with patch("threading.Event.wait"):
            result = cli.invoke(
                tasks_worker_group, ["start", "--topics", "email,sms, pdf"]
            )

        mock_start.assert_called_once()
        call_kwargs = mock_start.call_args
        self.assertEqual(call_kwargs.kwargs.get("topics"), ["email", "sms", "pdf"])
        self.assertEqual(result.exit_code, 0)

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_topics_none_when_omitted(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        cli = CliRunner()
        with patch("threading.Event.wait"):
            cli.invoke(tasks_worker_group, ["start"])

        call_kwargs = mock_start.call_args
        self.assertIsNone(call_kwargs.kwargs.get("topics"))


class TestMaxWorkersOption(unittest.TestCase):
    """--max-workers forwards to start_workers_if_available."""

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_max_workers_forwarded(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        cli = CliRunner()
        with patch("threading.Event.wait"):
            result = cli.invoke(
                tasks_worker_group, ["start", "--max-workers", "16"]
            )

        call_kwargs = mock_start.call_args
        self.assertEqual(call_kwargs.kwargs.get("max_workers"), 16)
        self.assertEqual(result.exit_code, 0)

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_max_workers_none_when_omitted(self, mock_start):
        runner_mock = MagicMock()
        mock_start.return_value = [runner_mock]

        cli = CliRunner()
        with patch("threading.Event.wait"):
            cli.invoke(tasks_worker_group, ["start"])

        call_kwargs = mock_start.call_args
        self.assertIsNone(call_kwargs.kwargs.get("max_workers"))


class TestInitWorkerSignature(unittest.TestCase):
    """init_worker() accepts topics and max_workers."""

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.get_broker")
    @patch("fastpluggy.fastpluggy.FastPluggy")
    @patch("fastpluggy_plugin.tasks_worker.core.runner.TaskRunner")
    @patch("fastpluggy_plugin.tasks_worker.core.events.TaskEventBus")
    @patch("fastpluggy_plugin.tasks_worker.subscribers.setup_persistence")
    @patch("fastpluggy_plugin.tasks_worker.config.TasksRunnerSettings")
    def test_init_worker_passes_topics_and_max_workers(
        self,
        mock_settings_cls,
        mock_setup_persistence,
        mock_bus_cls,
        mock_runner_cls,
        mock_fp_cls,
        mock_get_broker,
    ):
        from fastpluggy_plugin.tasks_worker import TaskWorker

        mock_settings = MagicMock()
        mock_settings.enable_auto_task_discovery = False
        mock_settings.discover_celery_tasks = False
        mock_settings_cls.return_value = mock_settings

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_broker = MagicMock()
        mock_get_broker.return_value = mock_broker

        result = TaskWorker.init_worker(topics=["email", "sms"], max_workers=4)

        mock_runner.start_executor.assert_called_once_with(
            broker=mock_broker, topics=["email", "sms"], max_workers=4
        )
        self.assertEqual(result, mock_runner)

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.get_broker")
    @patch("fastpluggy.fastpluggy.FastPluggy")
    @patch("fastpluggy_plugin.tasks_worker.core.runner.TaskRunner")
    @patch("fastpluggy_plugin.tasks_worker.core.events.TaskEventBus")
    @patch("fastpluggy_plugin.tasks_worker.subscribers.setup_persistence")
    @patch("fastpluggy_plugin.tasks_worker.config.TasksRunnerSettings")
    def test_init_worker_defaults(
        self,
        mock_settings_cls,
        mock_setup_persistence,
        mock_bus_cls,
        mock_runner_cls,
        mock_fp_cls,
        mock_get_broker,
    ):
        from fastpluggy_plugin.tasks_worker import TaskWorker

        mock_settings = MagicMock()
        mock_settings.enable_auto_task_discovery = False
        mock_settings.discover_celery_tasks = False
        mock_settings_cls.return_value = mock_settings

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_broker = MagicMock()
        mock_get_broker.return_value = mock_broker

        TaskWorker.init_worker()

        # Default: topics=['*'], no max_workers kwarg
        mock_runner.start_executor.assert_called_once_with(
            broker=mock_broker, topics=["*"]
        )


class TestStartWorkersForwarding(unittest.TestCase):
    """start_workers_if_available() forwards topics/max_workers to init_worker."""

    @patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=True)
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.setup_broker")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.init_worker")
    def test_forwarding(self, mock_init, mock_setup, mock_installed):
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        mock_runner = MagicMock()
        mock_init.return_value = mock_runner

        with patch.dict(os.environ, {"WORKER_NUMBER": "1"}):
            runners = start_workers_if_available(topics=["a", "b"], max_workers=12)

        mock_init.assert_called_once_with(topics=["a", "b"], max_workers=12, beat=False)
        self.assertEqual(runners, [mock_runner])

    @patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=True)
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.setup_broker")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.init_worker")
    def test_forwarding_with_beat(self, mock_init, mock_setup, mock_installed):
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        mock_runner = MagicMock()
        mock_init.return_value = mock_runner

        with patch.dict(os.environ, {"WORKER_NUMBER": "2"}):
            runners = start_workers_if_available(topics=["x"], max_workers=4, beat=True)

        # Only first worker gets beat=True
        calls = mock_init.call_args_list
        assert len(calls) == 2
        assert calls[0] == call(topics=["x"], max_workers=4, beat=True)
        assert calls[1] == call(topics=["x"], max_workers=4, beat=False)
        self.assertEqual(len(runners), 2)


if __name__ == "__main__":
    unittest.main()
