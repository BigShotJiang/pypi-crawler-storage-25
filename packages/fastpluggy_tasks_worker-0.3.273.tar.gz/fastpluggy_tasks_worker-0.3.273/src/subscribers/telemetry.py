# telemetry.py
import time
from dataclasses import dataclass, field
from collections import defaultdict
from typing import Dict, Any

from ..core.events import TaskLifecycleEvent
from ..core.status import TaskStatus


DEFAULT_HISTOGRAM_BUCKETS = (0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30, 60, 120, 300)


@dataclass
class HistogramAccumulator:
    """In-memory histogram tracking bucket counts, sum, and count."""

    bucket_bounds: tuple[float, ...] = DEFAULT_HISTOGRAM_BUCKETS
    _counts: list[int] = field(default_factory=list)
    _sum: float = 0.0
    _count: int = 0

    def __post_init__(self):
        if not self._counts:
            self._counts = [0] * len(self.bucket_bounds)

    def observe(self, value: float) -> None:
        self._sum += value
        self._count += 1
        for i, bound in enumerate(self.bucket_bounds):
            if value <= bound:
                self._counts[i] += 1

    def snapshot(self) -> dict:
        """Return cumulative bucket counts, sum, and count."""
        cumulative = []
        running = 0
        for i, bound in enumerate(self.bucket_bounds):
            running += self._counts[i]
            cumulative.append((bound, running))
        return {
            "buckets": cumulative,
            "sum": self._sum,
            "count": self._count,
        }


@dataclass
class TaskTelemetry:
    # totals
    submitted_total: int = 0
    completed_total: int = 0
    failed_total: int = 0
    running_total: int = 0

    # per-topic breakdown
    running_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    submitted_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    completed_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    failed_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    running_tasks: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # per-status event counts (CREATED, RUNNING, SUCCESS, FAILED, etc.)
    events_by_status: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    # per task_name + status execution counts
    executions_by_name_status: Dict[tuple[str, str], int] = field(
        default_factory=lambda: defaultdict(int)
    )

    # duration tracking
    _start_times: Dict[str, float] = field(default_factory=dict)
    _duration_histograms: Dict[tuple[str, str], HistogramAccumulator] = field(
        default_factory=dict
    )

    # ---- handlers: names must match "on_<TaskStatus.name.lower()>" ----

    def on_created(self, e: TaskLifecycleEvent) -> None:
        self.events_by_status[TaskStatus.CREATED.value] += 1

    def on_queued(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        self.submitted_total += 1
        self.submitted_per_topic[topic] += 1
        self.events_by_status[TaskStatus.QUEUED.value] += 1

    def on_running(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        self.running_total += 1
        self.running_per_topic[topic] += 1
        self.running_tasks[e.task_id] = {
            "task_id": e.task_id,
            "task_name": getattr(e.context, "task_name", "unknown"),
            "topic": topic,
            "broker_msg_id": e.broker_msg_id,
        }
        self.events_by_status[TaskStatus.RUNNING.value] += 1
        self._start_times[e.task_id] = time.time()

    # Final states — SUCCESS, FAILED, CANCELLED, MANUAL_CANCELLED, ERROR, TIMEOUT, DEAD, SKIPPED
    def on_final(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        # Only decrement running counters if this task was actually observed as running.
        # Tasks that fail before emitting RUNNING (e.g. bad payload) must not touch
        # the running counters — doing so would corrupt counts for legitimately running tasks.
        was_running = e.task_id in self.running_tasks
        self.running_tasks.pop(e.task_id, None)

        if was_running:
            if self.running_total > 0:
                self.running_total -= 1
            if self.running_per_topic.get(topic, 0) > 0:
                self.running_per_topic[topic] -= 1
                if self.running_per_topic[topic] == 0:
                    self.running_per_topic.pop(topic, None)

        # completion counters (only if it's a real terminal outcome)
        if e.status in {
            TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.CANCELLED,
            TaskStatus.MANUAL_CANCELLED, TaskStatus.ERROR, TaskStatus.TIMEOUT,
            TaskStatus.DEAD, TaskStatus.SKIPPED
        }:
            self.completed_total += 1
            self.completed_per_topic[topic] += 1

            # Track failures separately
            if e.status in {
                TaskStatus.FAILED, TaskStatus.ERROR, TaskStatus.TIMEOUT, TaskStatus.DEAD
            }:
                self.failed_total += 1
                self.failed_per_topic[topic] += 1

        # Per-status event count
        status_val = getattr(e.status, "value", str(e.status))
        self.events_by_status[status_val] += 1

        # Per-task-name + status execution count
        task_name = getattr(e.context, "task_name", None) or getattr(e.context, "func_name", "task")
        self.executions_by_name_status[(task_name, status_val)] += 1

        # Duration histogram
        start = self._start_times.pop(e.task_id, None)
        if start is not None:
            dur = max(0.0, time.time() - start)
            key = (task_name, status_val)
            if key not in self._duration_histograms:
                self._duration_histograms[key] = HistogramAccumulator()
            self._duration_histograms[key].observe(dur)

    # Optional: logs/progress events (no counters, but you can mine metadata)
    def on_logs(self, e: TaskLifecycleEvent) -> None:
        pass

    def on_progress(self, e: TaskLifecycleEvent) -> None:
        pass

    # Public snapshot for heartbeat/manager/etc.
    def snapshot(self) -> dict:
        return {
            "running": self.running_total,
            "running_per_topic": dict(self.running_per_topic),
            "running_tasks": list(self.running_tasks.values()),
            "submitted_total": self.submitted_total,
            "submitted_per_topic": dict(self.submitted_per_topic),
            "completed_total": self.completed_total,
            "completed_per_topic": dict(self.completed_per_topic),
            "failed_total": self.failed_total,
            "failed_per_topic": dict(self.failed_per_topic),
            "events_by_status": dict(self.events_by_status),
            "executions_by_name_status": {
                f"{name}:{status}": count
                for (name, status), count in self.executions_by_name_status.items()
            },
            "duration_histograms": {
                f"{name}:{status}": hist.snapshot()
                for (name, status), hist in self._duration_histograms.items()
            },
        }
