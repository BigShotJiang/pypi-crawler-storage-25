"""Subscriber that broadcasts task lifecycle events to the broker's fanout exchange.

This makes running/completed/failed tasks visible to all broker instances
(including web UI listeners) via the ``fp.workers`` exchange.
"""
import logging

from ..core.events import TaskLifecycleEvent

log = logging.getLogger("BrokerBroadcast")


class BrokerBroadcastSubscriber:
    """Bridges event bus → broker broadcast for cluster-wide task visibility."""

    def __init__(self):
        self._broker = None

    def set_broker(self, broker):
        self._broker = broker

    def on_queued(self, e: TaskLifecycleEvent) -> None:
        broker = self._broker
        if broker and hasattr(broker, 'broadcast_task_started'):
            topic = getattr(e.context, "topic", "unknown")
            worker_id = e.get_meta("worker_id", "unknown")
            broker.broadcast_task_started(worker_id=worker_id, task_id=e.task_id, topic=topic)

    def on_success(self, e: TaskLifecycleEvent) -> None:
        broker = self._broker
        if broker and hasattr(broker, 'broadcast_task_completed'):
            topic = getattr(e.context, "topic", "unknown")
            worker_id = e.get_meta("worker_id", "unknown")
            broker.broadcast_task_completed(worker_id=worker_id, task_id=e.task_id, topic=topic)

    def on_failed(self, e: TaskLifecycleEvent) -> None:
        broker = self._broker
        if broker and hasattr(broker, 'broadcast_task_failed'):
            topic = getattr(e.context, "topic", "unknown")
            worker_id = e.get_meta("worker_id", "unknown")
            error = str(e.get_meta("exception", ""))
            broker.broadcast_task_failed(worker_id=worker_id, task_id=e.task_id, topic=topic, error=error)
