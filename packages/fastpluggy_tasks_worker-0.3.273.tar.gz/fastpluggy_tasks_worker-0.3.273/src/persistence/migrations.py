"""
Idempotent column migrations for fp_task_reports.

Handles schema evolution between releases:
  - Rename start_time -> execution_start
  - Add enqueued_at (DateTime, nullable)
  - Add published_at (DateTime, nullable)

Works on both SQLite and PostgreSQL.
"""
import logging

from sqlalchemy import inspect, text

logger = logging.getLogger("tasks_worker.migrations")

TABLE = "fp_task_reports"


def _get_column_names(engine):
    """Return the set of column names for TABLE, or empty set if table missing."""
    insp = inspect(engine)
    if not insp.has_table(TABLE):
        return set()
    return {col["name"] for col in insp.get_columns(TABLE)}


def run_migrations(engine):
    """Run all pending column migrations (idempotent)."""
    columns = _get_column_names(engine)
    if not columns:
        logger.debug("Table %s does not exist yet — skipping migrations", TABLE)
        return

    with engine.begin() as conn:
        # --- rename start_time -> execution_start -------------------------
        if "start_time" in columns and "execution_start" not in columns:
            logger.info("Renaming column start_time -> execution_start on %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} RENAME COLUMN start_time TO execution_start")
            )
        elif "execution_start" in columns:
            logger.debug("Column execution_start already exists — skip rename")
        elif "start_time" not in columns and "execution_start" not in columns:
            logger.warning(
                "Neither start_time nor execution_start found on %s — skip rename",
                TABLE,
            )

        # --- add enqueued_at ----------------------------------------------
        if "enqueued_at" not in columns:
            logger.info("Adding column enqueued_at to %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} ADD COLUMN enqueued_at TIMESTAMP")
            )
        else:
            logger.debug("Column enqueued_at already exists — skip add")

        # --- add published_at ---------------------------------------------
        if "published_at" not in columns:
            logger.info("Adding column published_at to %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} ADD COLUMN published_at TIMESTAMP")
            )
        else:
            logger.debug("Column published_at already exists — skip add")

        # --- add progress_pct -----------------------------------------------
        if "progress_pct" not in columns:
            logger.info("Adding column progress_pct to %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} ADD COLUMN progress_pct FLOAT")
            )

        # --- add progress_message -------------------------------------------
        if "progress_message" not in columns:
            logger.info("Adding column progress_message to %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} ADD COLUMN progress_message TEXT")
            )

        # --- add progress_updated_at ----------------------------------------
        if "progress_updated_at" not in columns:
            logger.info("Adding column progress_updated_at to %s", TABLE)
            conn.execute(
                text(f"ALTER TABLE {TABLE} ADD COLUMN progress_updated_at TIMESTAMP")
            )
