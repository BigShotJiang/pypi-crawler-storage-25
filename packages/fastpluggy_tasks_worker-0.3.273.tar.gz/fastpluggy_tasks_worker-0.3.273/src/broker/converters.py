# broker/converters.py
"""
Built-in message converters for foreign broker protocols.

A converter is ``callable(body: bytes, properties) -> dict`` that transforms
a raw AMQP message (body + properties including headers) into the FastPluggy
BrokerMessage wire format dict before deserialization.

The returned dict must have: id, topic, payload, headers, attempts, created_at.
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict


def celery_converter(body: bytes, properties) -> Dict[str, Any]:
    """Convert a Celery v2 protocol message to FastPluggy BrokerMessage format.

    Celery v2 wire format (default since Celery 4.0):

    - **AMQP headers** contain metadata: ``task``, ``id``, ``root_id``,
      ``parent_id``, ``group``, ``retries``, ``eta``, ``expires``,
      ``timelimit``, ``lang``, ``origin``, ``shadow``, ``argsrepr``,
      ``kwargsrepr``.
    - **AMQP properties**: ``correlation_id`` = task id,
      ``content_type`` = serializer mimetype, ``content_encoding``.
    - **Body** is a tuple ``(args, kwargs, embed)`` where ``embed``
      contains workflow routing (callbacks, errbacks, chain, chord).

    Also handles Celery v1 messages (flat dict body with ``task`` key)
    and passes through native FastPluggy messages untouched.

    Only JSON-serialized Celery messages are supported.
    """
    headers = getattr(properties, "headers", None) or {}

    # Detect Celery v2: "task" header present (per spec: "Protocol version
    # detected by the presence of a task message header")
    if "task" in headers:
        return _convert_celery_v2(body, properties, headers)

    # Try JSON decode for v1 or FastPluggy passthrough
    data = json.loads(body.decode("utf-8"))

    # Already a FastPluggy message — passthrough
    if "payload" in data and "topic" in data:
        return data

    # Celery v1: flat dict with "task" in body
    if "task" in data:
        return _convert_celery_v1(data)

    # Unknown format — return as-is, let _deserialize_message handle errors
    return data


def _convert_celery_v2(body: bytes, properties, headers: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Celery v2 protocol message (JSON serializer only)."""
    content_type = getattr(properties, "content_type", "application/json") or "application/json"

    if "json" not in content_type:
        raise ValueError(
            f"Unsupported Celery content_type: {content_type!r}. "
            "Only JSON serialization is supported."
        )

    encoding = getattr(properties, "content_encoding", "utf-8") or "utf-8"
    decoded = json.loads(body.decode(encoding))

    # Body is (args, kwargs, embed) — may be list or tuple
    if isinstance(decoded, (list, tuple)) and len(decoded) >= 2:
        args = decoded[0] or []
        kwargs = decoded[1] or {}
        embed = decoded[2] if len(decoded) > 2 else {}
    else:
        # Unexpected shape — treat as kwargs
        args = []
        kwargs = decoded if isinstance(decoded, dict) else {}
        embed = {}

    task_id = headers.get("id") or getattr(properties, "correlation_id", None) or str(uuid.uuid4())
    func_name = headers.get("task", "")
    task_name = func_name.rsplit(".", 1)[-1] if func_name else "celery_task"

    extra_context = {}
    for key in ("retries", "eta", "expires", "timelimit", "root_id", "parent_id",
                "group", "origin", "lang", "shadow", "argsrepr", "kwargsrepr"):
        if key in headers and headers[key] is not None:
            extra_context[key] = headers[key]

    # Preserve workflow embed data if present
    if embed:
        extra_context["celery_embed"] = embed

    return {
        "id": task_id,
        "topic": headers.get("routing_key", "default"),
        "payload": {
            "task_id": task_id,
            "func_name": func_name,
            "task_name": task_name,
            "args": list(args),
            "kwargs": dict(kwargs),
            "task_origin": "celery",
            "extra_context": extra_context,
        },
        "headers": {k: v for k, v in headers.items()
                    if k not in ("task", "id", "retries", "eta", "expires",
                                 "timelimit", "root_id", "parent_id", "group")},
        "attempts": headers.get("retries", 0) or 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def _convert_celery_v1(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Celery v1 protocol message (flat dict body)."""
    task_id = data.get("id") or str(uuid.uuid4())
    func_name = data.get("task", "")
    task_name = func_name.rsplit(".", 1)[-1] if func_name else "celery_task"

    return {
        "id": task_id,
        "topic": data.get("queue", data.get("routing_key", "default")),
        "payload": {
            "task_id": task_id,
            "func_name": func_name,
            "task_name": task_name,
            "args": data.get("args", []),
            "kwargs": data.get("kwargs", {}),
            "task_origin": "celery",
            "extra_context": {
                k: data[k]
                for k in ("retries", "eta", "expires", "timelimit", "parent_id", "root_id")
                if k in data
            },
        },
        "headers": data.get("headers", {}),
        "attempts": data.get("retries", 0) or 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


# Registry of built-in shorthand names
_BUILTINS: Dict[str, Callable] = {
    "celery": celery_converter,
}


def load_converter(path: str | None) -> Callable | None:
    """Resolve a converter from a dotted path or built-in shorthand.

    Returns None if path is None/empty (no conversion).
    """
    if not path:
        return None

    # Check built-in shorthands first
    if path in _BUILTINS:
        return _BUILTINS[path]

    # Dotted import path
    module_path, _, attr_name = path.rpartition(".")
    if not module_path:
        raise ImportError(f"Invalid converter path: {path!r} (expected 'module.callable')")
    import importlib
    mod = importlib.import_module(module_path)
    return getattr(mod, attr_name)
