# plugin.py
import logging
from typing import Annotated, Any

from fastpluggy.core.menu.schema import MenuItem
from fastpluggy.core.metrics import MetricEntry, MetricsResult
from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.plugin_state import PluginState
from fastpluggy.core.tools.inspect_tools import InjectDependency
from .config import TasksRunnerSettings
from .subscribers import create_tables_for_save

log = logging.getLogger("tasks_worker")


def _topic_val(obj, attr: str) -> float:
    """Extract a numeric field from a TopicInfo dataclass or dict."""
    v = getattr(obj, attr, None)
    if v is None and isinstance(obj, dict):
        v = obj.get(attr, 0)
    try:
        return float(v or 0)
    except Exception:
        return 0.0


def get_router():
#    from .routers.api.notifier import api_notifier_router
    from .routers.api.registry import api_registry_router
    from .routers.api.tasks import api_tasks_router
    from .routers.api.broker import api_broker_router
    from .routers.front.front_lock import front_task_lock_router
    #from .routers.front.front_notifier import front_notifier_router
    from .routers.front.front_tasks import front_task_router
    from .routers.front.front_debug import front_task_debug_router
    from .routers.monitoring.task_duration import monitoring_task_duration

    routers = [
       # api_notifier_router,
        api_registry_router,
        api_tasks_router,
        api_broker_router,
        front_task_lock_router,
      #  front_notifier_router,
        front_task_router,
        front_task_debug_router,
        monitoring_task_duration,
    ]
    settings: TasksRunnerSettings = TasksRunnerSettings()
    if settings.discover_celery_tasks:
        from .celery_compat.router import celery_router
        routers.append(celery_router)

    from .scheduler.routers.front_schedule import front_schedule_task_router
    routers.append(front_schedule_task_router)

    if settings.store_task_db:
        from .scheduler.routers.monitoring import scheduled_tasks_monitoring_router
        routers.append(scheduled_tasks_monitoring_router)

    return routers


class TaskRunnerPlugin(FastPluggyBaseModule):
    module_name: str = "tasks_worker"

    module_menu_name: str = "Task Runner"
    module_menu_type: str = "main"

    module_settings: Any = TasksRunnerSettings
    module_router: Any = get_router

    capabilities: list = ["metrics"]

    extra_js_files: list = []

    depends_on: dict = {
        "crud_tools": ">=0.0.2",
    }

    optional_dependencies: dict = {
        "websocket_tool": ">=0.1.0",
        "ui_tools": ">=0.0.2",
    }

    extra_js_files: list = ['/app_static/tasks_worker/js/tasks.js']

    def after_setup_templates(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]) -> None:
        """
        Add global Jinja template variable for the API URL to trigger tasks.
        """
        # Add URL for task submission endpoint to global Jinja templates
        if fast_pluggy.app:
            task_submit_url=fast_pluggy.app.url_path_for("submit_task")
            fast_pluggy.templates.env.globals["task_submit_url"] = task_submit_url

            # Also expose common URLs into the JS global var for cleaner client-side code
            url_list_available_tasks = fast_pluggy.app.url_path_for("list_available_tasks")
            url_task_details = fast_pluggy.app.url_path_for("task_details", task_id="TASK_ID_REPLACE")
            url_api_task_details = fast_pluggy.app.url_path_for("get_task", task_id="TASK_ID_REPLACE")
            from fastpluggy.fastpluggy import FastPluggy
            FastPluggy.extend_globals('js_global_var', {
                'task_submit_url': task_submit_url,
                'url_list_available_tasks': url_list_available_tasks,
                'url_task_details': url_task_details,
                'url_api_task_details': url_api_task_details,
            })

        if fast_pluggy.templates:
            from .core.status import task_status_badge_class
            fast_pluggy.templates.env.filters["task_status_badge_class"] = task_status_badge_class

    def on_load_complete(
            self,
            fast_pluggy: Annotated["FastPluggy", InjectDependency],
            plugin: Annotated["PluginState", InjectDependency],
    ) -> None:
        # Add UI menu entries
        fast_pluggy.menu_manager.add_parent_item(
            menu_type='main',
            item=MenuItem(label="Task Runner", icon="fa-solid fa-gears", parent_name=self.module_name)
        )

        settings: TasksRunnerSettings = TasksRunnerSettings()

        create_tables_for_save(settings=settings)

        # Discover tasks
        if settings.enable_auto_task_discovery:
            from .registry.discovery import discover_tasks_from_loaded_modules
            discover_tasks_from_loaded_modules(fast_pluggy=fast_pluggy)

        if settings.discover_celery_tasks:
            from .celery_compat.discovery import discover_celery_tasks_from_app
            discover_celery_tasks_from_app(settings.celery_app_path)
        if settings.discover_celery_schedule_enabled_status:
            from .celery_compat.discovery import discover_celery_periodic_tasks
            discover_celery_periodic_tasks(settings.celery_app_path)

        # Start broker in listener mode (monitoring only, no task processing).
        # Run in a background thread so a slow/unreachable broker doesn't
        # block the web server from rendering pages.
        import threading

        def _deferred_broker_setup():
            try:
                from . import TaskWorker
                broker = TaskWorker.get_broker()
                if broker is not None:
                    broker.setup()
            except Exception as e:
                log.warning("Broker listener setup failed: %s", e)

        threading.Thread(
            target=_deferred_broker_setup, daemon=True, name="broker-setup"
        ).start()

        try:
            from fastpluggy_plugin.db_purge.hooks import register_purge_target
            register_purge_target("fp_task_reports", "end_time", default_retention_days=30)
            register_purge_target("fp_task_contexts", "created_at", default_retention_days=30)
        except ImportError:
            pass


    #    # # Register default notifiers
    # from .notifiers.registry import setup_default_notifiers
    # from .notifiers.loader import load_external_notification_config_from_settings
    #
    # setup_default_notifiers()
    # load_external_notification_config_from_settings()
    #
    # # Setup scheduled maintenance tasks
    # if settings.store_task_db:
    #     with session_scope() as db:
    #         from .repository.scheduled import ensure_scheduled_task_exists
    #
    #         if settings.purge_enabled:
    #             from .tasks.maintenance import purge_old_tasks
    #             ensure_scheduled_task_exists(
    #                 db=db,
    #                 function=purge_old_tasks,
    #                 task_name="purge_old_tasks",
    #                 cron="0 4 * * *",  # Every day at 4am
    #             )
    #
    #         # if settings.watchdog_enabled:
    #         # todo : move to worker class to ensure all is always sync
    #         #    from .tasks.watchdog import watchdog_cleanup_stuck_tasks
    #         #    ensure_scheduled_task_exists(
    #         #        db=db,
    #         #        function=watchdog_cleanup_stuck_tasks,
    #         #        task_name="watchdog_cleanup_stuck_tasks",
    #         #        interval=15,  # Every 15 minutes
    #         #    )

    # ── MetricsProvider implementation ───────────────────────────────────

    def get_metrics(self) -> MetricsResult:
        """Collect broker and telemetry metrics into a MetricsResult.

        Wraps existing broker stats (topics, workers, locks) and the
        in-memory telemetry snapshot into the capability-based metrics
        contract so the metrics aggregator plugin can discover them.
        """
        gauges: list[MetricEntry] = []
        counters: list[MetricEntry] = []
        histograms: list[MetricEntry] = []

        # ── Broker metrics ──────────────────────────────────────────────
        try:
            from . import TaskWorker
            broker = TaskWorker.get_broker()
        except Exception:
            broker = None

        if broker is not None:
            # Per-topic gauges
            try:
                topics = broker.get_topics() or []
            except Exception:
                topics = []

            total_queued = 0.0
            total_running = 0.0

            for t in topics:
                topic = getattr(t, "topic", None) or (t.get("topic") if isinstance(t, dict) else None)
                if topic is None:
                    continue

                qv = _topic_val(t, "queued")
                rv = _topic_val(t, "running")
                total_queued += qv
                total_running += rv

                gauges.append(MetricEntry(
                    name="fastpluggy_broker_topic_queued",
                    value=qv,
                    type="gauge",
                    help="Number of queued messages per topic",
                    labels={"topic": topic},
                ))
                gauges.append(MetricEntry(
                    name="fastpluggy_broker_topic_running",
                    value=rv,
                    type="gauge",
                    help="Number of running messages per topic",
                    labels={"topic": topic},
                ))
                gauges.append(MetricEntry(
                    name="fastpluggy_broker_topic_dead_letter",
                    value=_topic_val(t, "dead_letter"),
                    type="gauge",
                    help="Number of dead-letter messages per topic",
                    labels={"topic": topic},
                ))
                gauges.append(MetricEntry(
                    name="fastpluggy_broker_topic_subscribers",
                    value=_topic_val(t, "subscribers"),
                    type="gauge",
                    help="Number of subscribers per topic",
                    labels={"topic": topic},
                ))

            # Cluster-level gauges
            try:
                workers = broker.get_workers(include_tasks=False) or []
            except Exception:
                workers = []

            gauges.append(MetricEntry(
                name="fastpluggy_broker_workers",
                value=float(len(workers)),
                type="gauge",
                help="Number of workers registered in broker",
            ))
            gauges.append(MetricEntry(
                name="fastpluggy_broker_topics",
                value=float(len(topics)),
                type="gauge",
                help="Number of topics registered in broker",
            ))
            gauges.append(MetricEntry(
                name="fastpluggy_broker_messages_queued_total",
                value=total_queued,
                type="gauge",
                help="Total queued messages across all topics",
            ))
            gauges.append(MetricEntry(
                name="fastpluggy_broker_messages_running_total",
                value=total_running,
                type="gauge",
                help="Total running messages across all topics",
            ))

            # Locks gauge
            try:
                locks = broker.get_locks() or []
                gauges.append(MetricEntry(
                    name="fastpluggy_broker_locks",
                    value=float(len(locks)),
                    type="gauge",
                    help="Number of active task locks",
                ))
            except Exception:
                pass

        # ── Telemetry counters (available when a worker runs in-process) ─
        try:
            from fastpluggy.fastpluggy import FastPluggy
            fp = FastPluggy(app=None)
            bus = fp.get_global("tasks_worker.bus")
            if bus is not None:
                from .subscribers.telemetry import TaskTelemetry
                telemetry = bus.get_instance(TaskTelemetry)
                if telemetry is not None:
                    snap = telemetry.snapshot()

                    # Global counters
                    counters.append(MetricEntry(
                        name="fastpluggy_tasks_submitted_total",
                        value=float(snap.get("submitted_total", 0)),
                        type="counter",
                        help="Total number of tasks submitted",
                    ))
                    counters.append(MetricEntry(
                        name="fastpluggy_tasks_completed_total",
                        value=float(snap.get("completed_total", 0)),
                        type="counter",
                        help="Total number of tasks completed (all terminal states)",
                    ))
                    counters.append(MetricEntry(
                        name="fastpluggy_tasks_failed_total",
                        value=float(snap.get("failed_total", 0)),
                        type="counter",
                        help="Total number of tasks failed (FAILED, ERROR, TIMEOUT, DEAD)",
                    ))
                    gauges.append(MetricEntry(
                        name="fastpluggy_tasks_running",
                        value=float(snap.get("running", 0)),
                        type="gauge",
                        help="Number of tasks currently running",
                    ))

                    # Per-topic breakdowns
                    for topic, count in snap.get("submitted_per_topic", {}).items():
                        counters.append(MetricEntry(
                            name="fastpluggy_tasks_submitted_per_topic",
                            value=float(count),
                            type="counter",
                            help="Tasks submitted per topic",
                            labels={"topic": topic},
                        ))
                    for topic, count in snap.get("completed_per_topic", {}).items():
                        counters.append(MetricEntry(
                            name="fastpluggy_tasks_completed_per_topic",
                            value=float(count),
                            type="counter",
                            help="Tasks completed per topic",
                            labels={"topic": topic},
                        ))
                    for topic, count in snap.get("failed_per_topic", {}).items():
                        counters.append(MetricEntry(
                            name="fastpluggy_tasks_failed_per_topic",
                            value=float(count),
                            type="counter",
                            help="Tasks failed per topic",
                            labels={"topic": topic},
                        ))
                    for topic, count in snap.get("running_per_topic", {}).items():
                        gauges.append(MetricEntry(
                            name="fastpluggy_tasks_running_per_topic",
                            value=float(count),
                            type="gauge",
                            help="Tasks currently running per topic",
                            labels={"topic": topic},
                        ))

                    # Per-status event counts
                    for status, count in snap.get("events_by_status", {}).items():
                        counters.append(MetricEntry(
                            name="task_events_total",
                            value=float(count),
                            type="counter",
                            help="Total task lifecycle events by status",
                            labels={"status": status},
                        ))

                    # Per task_name + status execution counts
                    for key, count in snap.get("executions_by_name_status", {}).items():
                        task_name, status = key.rsplit(":", 1)
                        counters.append(MetricEntry(
                            name="task_executions_total",
                            value=float(count),
                            type="counter",
                            help="Task executions by name and status",
                            labels={"task_name": task_name, "status": status},
                        ))

                    # Duration histograms
                    for key, hist_data in snap.get("duration_histograms", {}).items():
                        task_name, status = key.rsplit(":", 1)
                        histograms.append(MetricEntry(
                            name="task_duration_seconds",
                            value=0,
                            type="histogram",
                            help="Task execution duration in seconds",
                            labels={"task_name": task_name, "status": status},
                            buckets=hist_data["buckets"],
                            histogram_sum=hist_data["sum"],
                            histogram_count=hist_data["count"],
                        ))
        except Exception as exc:
            log.debug("Telemetry metrics unavailable: %s", exc)

        return MetricsResult(gauges=gauges, counters=counters, histograms=histograms)
