from enum import Enum


class TaskStatus(str, Enum): # todo : rename to task event
    CREATED ="created"
    QUEUED = "queued"
    RUNNING = "running"

    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    MANUAL_CANCELLED = "manual_cancelled"
    CANCEL_PURGED = "cancel_purged"
    SKIPPED = "skipped"
    ERROR = "error"
    TIMEOUT = "timeout"
    DEAD = "dead"

    UNKNOWN = "unknown"

    LOGS = "logs"
    PROGRESS = "progress" # todo: replace the progress system

    @property
    def badge_class(self):
        return {
            TaskStatus.CREATED: 'bg-secondary-lt',
            TaskStatus.QUEUED: 'bg-info-lt',
            TaskStatus.RUNNING: 'bg-primary-lt',
            TaskStatus.SUCCESS: 'bg-success-lt',
            TaskStatus.FAILED: 'bg-danger-lt',
            TaskStatus.CANCELLED: 'bg-warning-lt',
            TaskStatus.MANUAL_CANCELLED: 'bg-warning-lt',
            TaskStatus.CANCEL_PURGED: 'bg-warning-lt',
            TaskStatus.TIMEOUT: 'bg-warning-lt',
        }.get(self, 'bg-secondary')  # Default to 'bg-secondary' if not found


def task_status_badge_class(status_str):
    try:
        return TaskStatus(status_str).badge_class
    except ValueError:
        return "bg-secondary-lt"

