"""CLI commands for the tasks_worker plugin.

Registered as ``fp tasks-worker <command>`` via the ``fastpluggy.cli``
entry point group.  All heavy imports are lazy (inside command bodies)
so that loading this module is fast and side-effect-free.
"""


import click


@click.group("tasks-worker", invoke_without_command=True)
@click.pass_context
def tasks_worker_group(ctx: click.Context) -> None:
    """Manage FastPluggy background task workers."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@tasks_worker_group.command("start")
@click.option(
    "--workers",
    "-n",
    default=None,
    type=int,
    help="Number of workers to start (default: $WORKER_NUMBER or 1)",
)
@click.option(
    "--log-level",
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"], case_sensitive=False),
    default=None,
    help="Set logging level (default: INFO)",
)
@click.option(
    "--broker-type",
    type=click.Choice(["local", "memory", "rabbitmq", "postgres"], case_sensitive=False),
    default=None,
    help="Broker backend (overrides $BROKER_TYPE)",
)
@click.option(
    "--broker-dsn",
    default=None,
    help="Broker connection DSN (overrides $BROKER_DSN)",
)
@click.option(
    "--topics",
    default=None,
    help="Comma-separated list of topics to consume (default: all)",
)
@click.option(
    "--max-workers",
    type=int,
    default=None,
    help="Thread pool size per worker (default: 8)",
)
@click.option(
    "--beat",
    is_flag=True,
    default=False,
    help="Also start the scheduler (beat) alongside workers",
)
def start(
    workers: int | None,
    log_level: str | None,
    broker_type: str | None,
    broker_dsn: str | None,
    topics: str | None,
    max_workers: int | None,
    beat: bool,
) -> None:
    """Start background task workers as a long-running process.

    The process blocks until interrupted with Ctrl+C or SIGTERM,
    then performs a graceful shutdown of all workers.

    \b
    Examples:
      # Worker only — default broker, all topics
      fastpluggy tasks-worker start

      # Worker + scheduler (beat)
      fastpluggy tasks-worker start --beat

      # RabbitMQ in production
      fastpluggy tasks-worker start --broker-type rabbitmq --broker-dsn amqp://user:pass@rabbit:5672/

      # Consume specific topics with 4 threads
      fastpluggy tasks-worker start --topics email,reports --max-workers 4

      # Verbose logging
      fastpluggy tasks-worker start --log-level DEBUG
    """
    import logging
    import os
    import signal
    import threading

    # Configure logging before anything else
    level = getattr(logging, (log_level or "INFO").upper())
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    )

    # Override broker settings via env vars before any import touches TasksRunnerSettings
    if broker_type is not None:
        os.environ["BROKER_TYPE"] = broker_type
    if broker_dsn is not None:
        os.environ["BROKER_DSN"] = broker_dsn

    if workers is not None:
        os.environ["WORKER_NUMBER"] = str(workers)

    # Parse topics
    topic_list: list[str] | None = None
    if topics is not None:
        topic_list = [t.strip() for t in topics.split(",") if t.strip()]

    try:
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        runners = start_workers_if_available(
            topics=topic_list, max_workers=max_workers, beat=beat,
        )
        if not runners:
            click.echo("tasks_worker plugin is not installed — no workers started.", err=True)
            raise SystemExit(1)

    except ImportError:
        click.echo("tasks_worker plugin is not installed.", err=True)
        raise SystemExit(1)

    # Print startup banner
    effective_broker = os.environ.get("BROKER_TYPE", "local")
    try:
        from fastpluggy_plugin.tasks_worker.config import TasksRunnerSettings
        settings = TasksRunnerSettings()
        effective_broker = settings.BROKER_TYPE
    except Exception:
        pass

    topics_display = ", ".join(topic_list) if topic_list else "*"
    click.echo(f"──────────────────────────────────────────")
    click.echo(f"  tasks_worker — standalone worker process")
    click.echo(f"  PID:     {os.getpid()}")
    click.echo(f"  Broker:  {effective_broker}")
    click.echo(f"  Workers: {len(runners)}")
    click.echo(f"  Topics:  {topics_display}")
    click.echo(f"  Beat:    {'ON' if beat else 'OFF'}")
    click.echo(f"  Log:     {logging.getLevelName(level)}")
    click.echo(f"──────────────────────────────────────────")
    click.echo("Press Ctrl+C to stop.")

    # Block main thread until shutdown signal
    shutdown_event = threading.Event()
    _shutting_down = False

    def _shutdown(signum, frame):
        nonlocal _shutting_down
        sig_name = signal.Signals(signum).name

        if _shutting_down:
            # Second signal — force exit immediately
            click.echo(f"\nReceived {sig_name} again — forcing exit!")
            os._exit(1)

        _shutting_down = True
        click.echo(f"\nReceived {sig_name} — shutting down workers… (press Ctrl+C again to force)")
        # Signal beat thread to stop (if running)
        for runner in runners:
            beat_shutdown = getattr(runner, "_beat_shutdown", None)
            if beat_shutdown is not None:
                beat_shutdown.set()
        for runner in runners:
            try:
                runner.stop()
            except Exception as e:
                logging.getLogger("tasks_worker.cli").warning(
                    "Error stopping runner: %s", e
                )
        shutdown_event.set()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    shutdown_event.wait()
    click.echo("All workers stopped. Goodbye.")


@tasks_worker_group.command("beat")
@click.option(
    "--log-level",
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"], case_sensitive=False),
    default=None,
    help="Set logging level (default: INFO)",
)
@click.option(
    "--broker-type",
    type=click.Choice(["local", "memory", "rabbitmq", "postgres"], case_sensitive=False),
    default=None,
    help="Broker backend (overrides $BROKER_TYPE)",
)
@click.option(
    "--broker-dsn",
    default=None,
    help="Broker connection DSN (overrides $BROKER_DSN)",
)
def beat(
    log_level: str | None,
    broker_type: str | None,
    broker_dsn: str | None,
) -> None:
    """Start the scheduler (beat) as a standalone process.

    The beat process reads scheduled tasks from the database and submits
    them to the broker when they are due. It does NOT consume or execute
    tasks — use ``start`` for that.

    \b
    Examples:
      # Standalone beat (recommended for production)
      fastpluggy tasks-worker beat

      # With specific broker
      fastpluggy tasks-worker beat --broker-type rabbitmq --broker-dsn amqp://user:pass@rabbit:5672/

      # Verbose logging
      fastpluggy tasks-worker beat --log-level DEBUG
    """
    import logging
    import os
    import signal
    import threading
    import time

    # Configure logging
    level = getattr(logging, (log_level or "INFO").upper())
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    )

    # Override broker settings via env vars
    if broker_type is not None:
        os.environ["BROKER_TYPE"] = broker_type
    if broker_dsn is not None:
        os.environ["BROKER_DSN"] = broker_dsn

    try:
        from fastpluggy_plugin.tasks_worker import TaskWorker
        from fastpluggy_plugin.tasks_worker.config import TasksRunnerSettings

        settings = TasksRunnerSettings()

        # Set up broker (needed for TaskWorker.submit)
        TaskWorker.setup_broker()

        # Discover tasks so schedule_loop can resolve function names
        if settings.enable_auto_task_discovery:
            from fastpluggy.fastpluggy import FastPluggy
            from fastpluggy_plugin.tasks_worker.registry.discovery import (
                discover_tasks_from_loaded_modules,
            )
            fast_pluggy = FastPluggy(app=None)
            discover_tasks_from_loaded_modules(fast_pluggy=fast_pluggy)

    except ImportError:
        click.echo("tasks_worker plugin is not installed.", err=True)
        raise SystemExit(1)

    # Resolve effective broker for banner
    effective_broker = os.environ.get("BROKER_TYPE", "local")
    try:
        effective_broker = settings.BROKER_TYPE
    except Exception:
        pass

    # Check for existing live beat before starting
    from fastpluggy.core.tools.system import get_hostname
    from fastpluggy_plugin.tasks_worker.broker.contracts import BrokerUtils
    broker = TaskWorker.get_broker()

    if BrokerUtils.check_existing_beat(broker):
        click.echo("⚠ A live beat worker is already registered — aborting to avoid duplicate submissions.", err=True)
        click.echo("If the previous beat is dead, wait 6s for stale cleanup or restart.", err=True)
        raise SystemExit(1)

    # Register beat worker with the broker for heartbeat/monitoring
    beat_worker_id = f"beat-{get_hostname()}-{os.getpid()}"
    broker.register_worker(
        worker_id=beat_worker_id,
        pid=os.getpid(),
        host=get_hostname(),
        topics=[],
        capacity=0,
        role="beat",
    )

    click.echo(f"──────────────────────────────────────────")
    click.echo(f"  tasks_worker — standalone beat process")
    click.echo(f"  PID:       {os.getpid()}")
    click.echo(f"  Worker ID: {beat_worker_id}")
    click.echo(f"  Broker:    {effective_broker}")
    click.echo(f"  Frequency: {settings.scheduler_frequency}s")
    click.echo(f"  Log:       {logging.getLevelName(level)}")
    click.echo(f"──────────────────────────────────────────")
    click.echo("Press Ctrl+C to stop.")

    # Start a heartbeat thread for the beat worker
    import atexit
    _hb_stop = threading.Event()

    def _beat_heartbeat_loop():
        while not _hb_stop.is_set():
            try:
                broker.heartbeat(beat_worker_id, running=0, capacity=0, role="beat")
            except Exception:
                logging.getLogger("tasks_worker.beat").debug("heartbeat error", exc_info=True)
            _hb_stop.wait(3.0)

    hb_thread = threading.Thread(target=_beat_heartbeat_loop, name="hb:beat", daemon=True)
    hb_thread.start()

    # Shutdown handling
    shutdown_event = threading.Event()
    _shutting_down = False

    def _shutdown(signum, frame):
        nonlocal _shutting_down
        sig_name = signal.Signals(signum).name
        if _shutting_down:
            click.echo(f"\nReceived {sig_name} again — forcing exit!")
            os._exit(1)
        _shutting_down = True
        click.echo(f"\nReceived {sig_name} — shutting down beat…")
        shutdown_event.set()
        _hb_stop.set()
        try:
            broker.unregister_worker(beat_worker_id)
        except Exception:
            pass

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)
    atexit.register(lambda: broker.unregister_worker(beat_worker_id) if not _shutting_down else None)

    # Run schedule_loop directly in main thread with auto-restart
    from fastpluggy_plugin.tasks_worker.tasks.scheduler import schedule_loop

    while not shutdown_event.is_set():
        try:
            schedule_loop(shutdown_event=shutdown_event)
        except Exception:
            logging.getLogger("tasks_worker.beat").exception(
                "schedule_loop crashed — restarting in 10s"
            )
            shutdown_event.wait(10)

    click.echo("Beat stopped. Goodbye.")


@tasks_worker_group.command("workers")
@click.option(
    "--broker-type",
    type=click.Choice(["local", "rabbitmq", "postgres", "memory"], case_sensitive=False),
    default=None,
    help="Broker backend to use",
)
@click.option("--broker-dsn", default=None, help="Broker DSN / connection string")
def list_workers(broker_type, broker_dsn):
    """List registered workers and their status."""
    import os

    if broker_type is not None:
        os.environ["BROKER_TYPE"] = broker_type
    if broker_dsn is not None:
        os.environ["BROKER_DSN"] = broker_dsn

    try:
        from fastpluggy_plugin.tasks_worker import TaskWorker
        from fastpluggy_plugin.tasks_worker.broker.contracts import BrokerUtils

        TaskWorker.setup_broker()
        broker = TaskWorker.get_broker()
        workers = broker.get_workers() or []
    except Exception as e:
        click.echo(f"Error connecting to broker: {e}", err=True)
        raise SystemExit(1)

    if not workers:
        click.echo("No workers registered.")
        return

    # Table header
    click.echo(f"{'Worker ID':<40} {'Role':<14} {'Host':<20} {'PID':<8} {'Cap':<5} {'Run':<5} {'Last Heartbeat'}")
    click.echo("─" * 120)

    now = BrokerUtils.now_utc()
    for w in workers:
        wid = getattr(w, "worker_id", None) or (w.get("worker_id") if isinstance(w, dict) else "?")
        role = BrokerUtils.get_worker_role(w) or "—"
        host = getattr(w, "host", "") or (w.get("host", "") if isinstance(w, dict) else "")
        pid = getattr(w, "pid", "") or (w.get("pid", "") if isinstance(w, dict) else "")
        cap = getattr(w, "capacity", "") or (w.get("capacity", "") if isinstance(w, dict) else "")
        run = getattr(w, "running", "") or (w.get("running", "") if isinstance(w, dict) else "")

        hb = getattr(w, "last_heartbeat", None)
        if hb is None and isinstance(w, dict):
            hb = w.get("last_heartbeat")
        stale = BrokerUtils.compute_stale(hb, now=now, ttl=10.0)
        stale_marker = " ⚠ STALE" if stale else ""

        hb_display = str(hb)[:19] if hb else "—"

        click.echo(f"{str(wid):<40} {str(role):<14} {str(host):<20} {str(pid):<8} {str(cap):<5} {str(run):<5} {hb_display}{stale_marker}")

    click.echo(f"\n{len(workers)} worker(s) registered.")


@tasks_worker_group.command("info")
def broker_info():
    """Show broker configuration and connection status."""
    try:
        from fastpluggy_plugin.tasks_worker.config import TasksRunnerSettings
        settings = TasksRunnerSettings()
    except Exception as e:
        click.echo(f"Error loading settings: {e}", err=True)
        raise SystemExit(1)

    click.echo("Broker Configuration")
    click.echo("─" * 40)
    click.echo(f"  Type:            {settings.BROKER_TYPE}")
    click.echo(f"  DSN:             {settings.BROKER_DSN or '(none — using defaults)'}")
    click.echo(f"  Default topic:   {settings.default_topic}")
    click.echo(f"  Worker ID:       {settings.worker_id or '(auto)'}")
    click.echo(f"  Force topic:     {settings.force_task_topic or '(disabled)'}")
    click.echo(f"  Store in DB:     {settings.store_task_db}")
    click.echo(f"  Auto-discovery:  {settings.enable_auto_task_discovery}")
    click.echo(f"  Scheduler freq:  {settings.scheduler_frequency}s")
    click.echo(f"  Metrics:         {settings.metrics_enabled}")
    click.echo(f"  Celery compat:   {settings.discover_celery_tasks}")

    # Try to connect
    click.echo("")
    try:
        from fastpluggy_plugin.tasks_worker import TaskWorker
        TaskWorker.setup_broker()
        broker = TaskWorker.get_broker()
        click.echo(f"  Connection:      ✅ connected ({type(broker).__name__})")

        try:
            stats = broker.stats()
            topics = getattr(stats, "topics", []) if stats else []
            click.echo(f"  Topics:          {len(topics)}")
            for t in topics:
                name = getattr(t, "name", t.get("name") if isinstance(t, dict) else "?")
                queued = getattr(t, "queued", t.get("queued") if isinstance(t, dict) else 0)
                running = getattr(t, "running", t.get("running") if isinstance(t, dict) else 0)
                click.echo(f"                   {name} (queued={queued}, running={running})")
        except Exception:
            pass

        try:
            workers = broker.get_workers() or []
            click.echo(f"  Workers:         {len(workers)}")
        except Exception:
            pass

    except Exception as e:
        click.echo(f"  Connection:      ❌ failed ({e})")
