import contextvars
import logging
import os
import uuid
from typing import Optional, Tuple, Dict, Any

from fastpluggy.core.database import session_scope
from fastpluggy.core.tools.install import is_installed

from .broker.contracts import Broker
from .plugin import TaskRunnerPlugin

# from .progress import task_progress

current_task_ctx = contextvars.ContextVar(
    "current_task_ctx", default=None
)

# task_context_var.py (continued)
from contextlib import contextmanager


@contextmanager
def set_current_task_ctx(ctx):
    token = current_task_ctx.set(ctx)
    try:
        yield
    finally:
        current_task_ctx.reset(token)

def start_workers_if_available(
    topic_settings=None,
    *,
    topics: list[str] | None = None,
    max_workers: int | None = None,
    beat: bool = False,
):
    """Start task workers and return the list of created TaskRunner instances.

    Returns a list of TaskRunner instances on success, or an empty list if
    the plugin is not installed.

    Args:
        topic_settings: Per-topic broker settings (e.g. concurrency limits).
        topics: Topics for each worker to consume. Forwarded to ``init_worker()``.
        max_workers: Thread pool size per worker. Forwarded to ``init_worker()``.
        beat: If True, start the scheduler on the first worker (avoid duplicates).
    """
    if is_installed("fastpluggy_plugin.tasks_worker"):
        TaskWorker.setup_broker(topic_settings=topic_settings)

        number_worker = int(os.getenv("WORKER_NUMBER", 1))
        runners = []
        for i in range(number_worker):
            # Only the first worker gets beat=True to avoid duplicate schedulers
            worker_beat = beat and (i == 0)
            runner = TaskWorker.init_worker(topics=topics, max_workers=max_workers, beat=worker_beat)
            if runner is not None:
                runners.append(runner)
        logging.info(f"Started {number_worker} fastpluggy TaskWorker(s)")
        return runners
    else:
        logging.warning("fastpluggy_plugin.tasks_worker is not installed; no workers started")
        return []

class TaskWorker:
    _broker: Optional[Broker] = None

    @classmethod
    def get_broker(cls) -> Broker:
        from .broker.factory import get_broker
        if cls._broker is None:
            cls._broker = get_broker()
        return cls._broker

    @staticmethod
    def register(
            name: str = None,
            description: str = "",
            tags: list[str] = None,
            schedule: str = None,
            max_retries: int = 0,
            allow_concurrent: bool = True,
            task_type: str = "native",
            topic: Optional[str] = None,
            **extra: Any,
    ):
        """
        Public wrapper around task_registry.register to decorate a function as a task.
        Mirrors TaskRegistry.register signature.
        """
        from .registry.registry import task_registry

        return task_registry.register(
            name=name,
            description=description,
            tags=tags,
            schedule=schedule,
            max_retries=max_retries,
            allow_concurrent=allow_concurrent,
            task_type=task_type,
            topic=topic,
            **extra,
        )

    @staticmethod
    def submit(
            func,
            args: Optional[Tuple] = None,
            kwargs: Optional[dict] = None,
            task_name: Optional[str] = None,
            topic: Optional[str] = None,
            max_retries: int = 0,
            retry_delay: int = 0,
            parent_task_id: Optional[str] = None,
            task_origin: str = "unk",
            allow_concurrent: Optional[bool] = None,
            extra_context: Optional[dict] = None,
            headers: Optional[Dict[str, Any]] = None,
    ):
        from .core.utils import it_allow_concurrent, func_to_path, get_task_type
        from .core.context import TaskContext

        # inherit parent task if we're inside one
        ctx_parent = current_task_ctx.get()
        if ctx_parent and not parent_task_id:
            parent_task_id = ctx_parent.task_id

        # Determine concurrency setting from function metadata if not explicitly provided
        if allow_concurrent is None:
            allow_concurrent = it_allow_concurrent(func)

        # Topic selection
        try:
            from .config import TasksRunnerSettings
            from fastpluggy.core.tools.system import get_hostname
            from .core.topic import resolve_topic
            settings = TasksRunnerSettings()
            # When force_task_topic is enabled, use hostname for both topic and worker-id routing (override any provided topic)
            if getattr(settings, "force_task_topic", None):
                host = get_hostname()
                topic = host
                try:
                    setattr(settings, "worker_id", host)
                except Exception:
                    pass
            else:
                # Defer to resolve_topic for precedence: explicit arg > func metadata > worker_id > default_topic
                topic = resolve_topic(func, topic=topic, settings=settings)
        except Exception as _e:
            # If settings cannot be loaded, resolve with defaults (this will use function metadata or default settings)
            logging.debug(f"TasksWorker: failed to load settings for topic selection: {_e}")
            from .core.topic import resolve_topic
            topic = resolve_topic(func, topic)

        # Retrieve task_type from task metadata if function is decorated
        task_type = get_task_type(func)

        # Compute per-entity lock info if configured
        lock_name = None
        try:
            from .core.topic import load_lock_key_resolver
            if 'settings' not in locals():
                from .config import TasksRunnerSettings as _TRS2
                settings = _TRS2()
            lk_resolver = load_lock_key_resolver(getattr(settings, "lock_key_resolver", None))
            if lk_resolver:
                lk = lk_resolver(
                    func=func,
                    args=args or (),
                    kwargs=kwargs or {},
                    task_name=task_name or getattr(func, "__name__", "anonymous"),
                    topic=topic,
                    settings=settings,
                )
                if isinstance(lk, str) and lk.strip():
                    ns = getattr(settings, "lock_namespace", "v:lock:")
                    lock_name = f"{ns}{lk.strip()}"
        except Exception as _lk_e:
            logging.debug(f"TasksWorker: lock_key_resolver failed: {_lk_e}")

        # Merge extra_context and inject lock_name if present
        merged_extra_ctx = dict(extra_context or {})
        if lock_name:
            merged_extra_ctx.setdefault("lock_name", lock_name)

        # Also include lock info in headers for observability
        if headers is None:
            headers = {"type": "task"}
        try:
            if lock_name:
                headers.setdefault("lock_name", lock_name)
        except Exception:
            pass

        context = TaskContext(
            task_id=str(uuid.uuid4()),
            task_name=task_name or getattr(func, "__name__", "anonymous"),
            func_name=func_to_path(func) if not isinstance(func, str) else func,
            args=list(args or ()),
            kwargs=dict(kwargs or {}),
            # notifier_config=notify_config or [],
            parent_task_id=parent_task_id,
            max_retries=max_retries,
            retry_delay=retry_delay,
            task_origin=task_origin,
            topic=topic,
            task_type=task_type,
            allow_concurrent=allow_concurrent,
            extra_context=merged_extra_ctx,
        )

        # TODO: Persist context replace with event
        # self.bus.emit(TaskLifecycleEvent(
        #                 status=TaskStatus.CREATED,
        #                 task_id=ctx.task_id,
        #                 context=ctx,
        #                 broker_msg_id=msg.id,
        #             ))
        try:
            # Temporary direct persistence; later this will emit CREATED event to a shared bus
            from .persistence.repository.context import save_context
            save_context(context)
        except Exception as e:
            # Avoid breaking submission if persistence fails
            logging.exception(f"Error on save in database the task : {e}")

        broker = TaskWorker.get_broker()


        # Ensure the topic exists on the broker (no-op for brokers that auto-create)
        try:
            broker.ensure_topic(topic)
        except Exception:
            # Be tolerant: if a broker doesn't implement ensure_topic, continue
            pass

        # Publish the task message
        msg_id = broker.publish(topic=topic, payload=context.to_payload(), headers=headers or {"type": "task"})
        logging.debug(f"broker.publish msg_id : {msg_id} onto topic : {topic}")
        return context.task_id

    # @classmethod
    # def get_all_active_tasks(cls, topic: str = DEFAULT_TOPIC) -> list[Dict[str, Any]]:
    #     """
    #     Convenience method to fetch active tasks from the underlying broker.
    #     Returns a list of dicts with at least: id, topic, payload, headers, attempts, created_at, state.
    #     """
    #     broker = cls._get_broker()
    #     try:
    #         return broker.get_all_active_tasks(topic)
    #     except AttributeError:
    #         # Broker may not implement the optional API
    #         return []

    # @classmethod
    # def start_executor(cls):
    #     pass
    #     # start a task runner

    @classmethod
    def init_worker(cls, *, topics: list[str] | None = None, max_workers: int | None = None, beat: bool = False):
        """
        Initialize a worker and return the TaskRunner instance.

        Args:
            topics: List of topics to consume. Defaults to ``['*']`` (all topics).
            max_workers: Thread pool size per worker. ``None`` uses the runner default (8).
            beat: If True, also start the scheduler loop as a daemon task.
        """
        try:
            from .core.events import TaskEventBus
            bus = TaskEventBus()

            from .subscribers import setup_persistence
            setup_persistence(bus=bus)

            from .config import TasksRunnerSettings
            settings: TasksRunnerSettings = TasksRunnerSettings()

            from .core.runner import TaskRunner
            from fastpluggy.fastpluggy import FastPluggy
            fast_pluggy = FastPluggy(app=None)

            runner = TaskRunner(fp=fast_pluggy, bus=bus)
            runner._worker_role = "worker+beat" if beat else "worker"
            broker = TaskWorker.get_broker()

            # Wire broker broadcast subscriber — makes running tasks visible
            # to all cluster nodes (including web UI listeners) via the
            # fanout exchange.
            from .subscribers.broker_broadcast import BrokerBroadcastSubscriber
            def _make_broadcast_sub():
                sub = BrokerBroadcastSubscriber()
                sub.set_broker(broker)
                return sub
            bus.subscribe_class(BrokerBroadcastSubscriber, factory=_make_broadcast_sub)
            executor_kwargs: dict = {"broker": broker, "topics": topics or ["*"]}
            if max_workers is not None:
                executor_kwargs["max_workers"] = max_workers
            executor = runner.start_executor(**executor_kwargs)

            # Expose references in global registry for reuse and possible shutdown
            fast_pluggy.register_global('tasks_worker.bus', bus)
            fast_pluggy.register_global('tasks_worker.runner', runner)
            fast_pluggy.register_global('tasks_worker.executor', executor)

            # Discover tasks
            if settings.enable_auto_task_discovery:
                from .registry.discovery import discover_tasks_from_loaded_modules
                discover_tasks_from_loaded_modules(fast_pluggy=fast_pluggy)

            if settings.discover_celery_tasks:
                from .celery_compat import init_celery_compat
                init_celery_compat(settings)

            # Launch scheduler in background thread (only when --beat is passed)
            if beat:
                from .broker.contracts import BrokerUtils
                if BrokerUtils.check_existing_beat(broker):
                    logging.warning(
                        "A live beat worker is already registered — skipping beat startup "
                        "to avoid duplicate scheduled task submissions"
                    )
                    beat = False  # fall through without starting beat

            if beat:
                import threading as _threading
                from .tasks.scheduler import schedule_loop

                _beat_shutdown = _threading.Event()
                runner._beat_shutdown = _beat_shutdown  # expose for CLI shutdown handler

                def _beat_loop():
                    while not _beat_shutdown.is_set():
                        try:
                            schedule_loop(shutdown_event=_beat_shutdown)
                        except Exception:
                            logging.exception("Beat schedule_loop crashed — restarting in 10s")
                            _beat_shutdown.wait(10)

                _beat_thread = _threading.Thread(target=_beat_loop, name="beat", daemon=True)
                _beat_thread.start()
                logging.info("Beat scheduler started in background thread")

            return runner

        except Exception as e:
            logging.exception(f"Error while initializing worker : {e}")
            return None

    @staticmethod
    def setup_broker(topic_settings: dict | None = None):
        """
        Construct the configured broker and run its startup hook.
        Use this at application startup (e.g., before launching uvicorn) to ensure
        broker-specific prerequisites are ready. Returns the broker instance.

        New: You can pass per-topic settings, e.g.
            TaskWorker.setup_broker(topic_settings={
                'ia': {'global_concurrency': 1}
            })
        Supported keys per topic dict:
            - global_concurrency (int | None)
        Alternatively, the value for a topic can be an int/None directly.
        """
        from .broker.factory import get_broker
        broker = get_broker()
        if broker:
            # All brokers inherit a default no-op setup(); specific backends can override
            # to perform work (LocalBroker ensures BaseManager is running/connected).
            try:
                broker.setup()
            except Exception as e:
                # Be defensive: setup should not crash the app if a backend chooses no-op behavior
                logging.exception(f"Broker setup failed : {e}")

            # Apply per-topic global concurrency settings if provided
            if topic_settings:
                try:
                    for topic, cfg in (topic_settings or {}).items():
                        limit = None
                        if isinstance(cfg, dict):
                            limit = cfg.get('global_concurrency')
                        else:
                            # accept direct int/None
                            limit = cfg
                        # Normalize and apply
                        try:
                            if limit is None or limit == 'none':
                                broker.set_topic_concurrency_limit(topic, None)
                            else:
                                broker.set_topic_concurrency_limit(topic, int(limit))
                        except Exception as e:
                            logging.warning(f"Failed to apply topic concurrency for '{topic}': {e}")
                except Exception as e:
                    logging.exception(f"Error while applying topic_settings: {e}")
        else:
            logging.warning("No broker configured; tasks will be disabled.")

        return broker

    _last_progress_time: float = 0.0

    @staticmethod
    def set_task_progression(value: float, message: Optional[str] = None, meta: Optional[Dict[str, Any]] = None):
        """
        Update the current task's progress (0..100).
        Automatically resolves current task_id via ContextVar.
        Throttled: emits at most once per second to avoid flooding.
        """
        import time
        now = time.monotonic()
        # Throttle: skip if <1s since last emit (unless 0% or 100%)
        if value not in (0.0, 100.0) and (now - TaskWorker._last_progress_time) < 1.0:
            return
        TaskWorker._last_progress_time = now

        ctx = current_task_ctx.get()
        if ctx is None:
            logging.warning("set_task_progression called outside of a task context")
            return

        from fastpluggy.fastpluggy import FastPluggy
        bus = FastPluggy.get_global("tasks_worker.bus")
        if bus is None:
            return

        from .core.events import TaskLifecycleEvent
        from .core.status import TaskStatus
        event_meta = {"pct": max(0.0, min(100.0, value)), "message": message}
        if meta:
            event_meta.update(meta)
        bus.emit(TaskLifecycleEvent(
            status=TaskStatus.PROGRESS,
            task_id=ctx.task_id,
            context=ctx,
            meta=event_meta,
        ))

    @staticmethod
    def wait_for_task(
        task_id: str,
        timeout: Optional[float] = None,
        poll_interval: float = 0.5
    ) -> Optional[Dict[str, Any]]:
        """
        Wait for a task to finish execution.

        Args:
            task_id (str): The unique identifier of the task to wait for.
            timeout (Optional[float]): Maximum time to wait in seconds. If None, wait indefinitely.
            poll_interval (float): Time in seconds between database checks. Defaults to 0.5s.

        Returns:
            Optional[Dict[str, Any]]: A dictionary containing the final task report data 
            (task_id, status, finished, result, error) if the task finishes within the timeout,
            or None if the timeout is reached.
        """
        from .persistence.repository.report import wait_for_task
        return wait_for_task(task_id, timeout, poll_interval)

    @staticmethod
    def add_scheduled_task(**kwargs):
        from .persistence.repository.scheduled import ensure_scheduled_task_exists
        # Set origin based on whether the function was registered with @register decorator
        if 'origin' not in kwargs:
            func = kwargs.get('function')
            # Check if function has _task_metadata (from @TaskWorker.register)
            if func and callable(func) and hasattr(func, '_task_metadata'):
                kwargs['origin'] = 'code_annotation'
            else:
                kwargs['origin'] = 'code'
        with session_scope() as db_session:
            return ensure_scheduled_task_exists(db=db_session,**kwargs)
