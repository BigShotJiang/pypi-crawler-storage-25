from typing import Type
from urllib.parse import urljoin
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from playwright.sync_api import sync_playwright

class ExportReportsInput(BaseModel):
    """Input schema for ExportReportsTool."""
    login_url: str = Field(..., description="The login URL of the InterEQ Mock Portal.")
    email: str = Field(..., description="The email address used to log in.")
    password: str = Field(..., description="The password used to log in.")

class ExportReportsTool(BaseTool):
    name: str = "Export Reports Tool"
    description: str = "Logs into the InterEQ portal, navigates to reports, and automatically exports all CSV reports in separate tabs."
    args_schema: Type[BaseModel] = ExportReportsInput

    def _run(self, login_url: str, email: str, password: str) -> str:
        REPORTS_SELECTORS = [
            'a:has-text("Reports")',
            '[data-testid="nav-reports"]',
            'a[href*="reports"]',
            'button:has-text("Reports")'
        ]

        REPORT_LINK_SELECTORS = [
            'a[href*="report"]',
            'button:has-text("Report")',
            '.report-link'
        ]

        EXPORT_SELECTORS = [
            '[data-testid="action-export"]',
            'a:has-text("Export")',
            'button:has-text("Export")',
            '#export-btn',
            '[data-testid="export"]',
            'a[href*="export"]'
        ]

        def find_matching_selector(page, selectors):
            for selector in selectors:
                try:
                    loc = page.locator(selector)
                    if loc.count() > 0 and loc.first.is_visible():
                        return selector
                except Exception:
                    continue
            return None

        log_steps = []
        results = []

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context()
                page = context.new_page()

                # 1. Navigation & Login
                page.goto(login_url)
                page.wait_for_load_state("load")

                is_already_logged_in = "portal.html" in page.url or page.locator("#nav-logout").count() > 0
                if is_already_logged_in:
                    log_steps.append("Login (Auto-redirected)")
                else:
                    page.fill("#emailInput", email)
                    page.fill("#passwordInput", password)
                    page.click("#loginBtn")
                    log_steps.append("Login")

                page.wait_for_url("**/portal.html")
                page.wait_for_selector("#nav-logout")

                # 2. Navigation to Reports index
                reports_selector = find_matching_selector(page, REPORTS_SELECTORS)
                if not reports_selector:
                    return "Error: Could not locate Reports navigation link."

                page.click(reports_selector)
                page.wait_for_url("**/reports.html")
                log_steps.append("Reports page")

                # 3. Discover Report Links
                base_url = page.url
                report_links = []
                seen_urls = set()

                for selector in REPORT_LINK_SELECTORS:
                    elements = page.locator(selector).all()
                    for el in elements:
                        try:
                            href = el.get_attribute("href")
                            if href and not href.startswith("#"):
                                abs_url = urljoin(base_url, href)
                                if abs_url == base_url or abs_url.endswith("reports.html"):
                                    continue
                                text = el.inner_text().strip() or href
                                if abs_url not in seen_urls:
                                    seen_urls.add(abs_url)
                                    report_links.append({"text": text, "url": abs_url})
                        except Exception:
                            continue

                # 4. Looping exports
                for report in report_links:
                    r_text = report["text"]
                    r_url = report["url"]

                    try:
                        report_page = context.new_page()
                        report_page.add_init_script("sessionStorage.setItem('iq_auth', '1');")
                        report_page.goto(r_url)
                        report_page.wait_for_load_state("load")

                        # Scroll and find Export button
                        page_height = report_page.evaluate("() => document.body.scrollHeight")
                        current_scroll = 0
                        export_selector = None

                        while current_scroll <= page_height:
                            page_height = report_page.evaluate("() => document.body.scrollHeight")
                            export_selector = find_matching_selector(report_page, EXPORT_SELECTORS)
                            if export_selector:
                                break
                            current_scroll += 300
                            if current_scroll > page_height:
                                break
                            report_page.evaluate(f"window.scrollTo(0, {current_scroll})")
                            report_page.wait_for_timeout(500)

                        if not export_selector:
                            raise Exception("Export button not found in the DOM.")

                        report_page.locator(export_selector).first.scroll_into_view_if_needed()
                        with report_page.expect_download() as download_info:
                            report_page.click(export_selector)

                        download = download_info.value
                        download.save_as(download.suggested_filename)
                        results.append(f"[SUCCESS] {r_text}: Saved as '{download.suggested_filename}'")
                        log_steps.append(f"{r_text} exported")
                    except Exception as err:
                        results.append(f"[FAILED] {r_text}: {err}")
                        log_steps.append(f"{r_text} export failed")
                    finally:
                        try:
                            report_page.close()
                        except Exception:
                            pass

                browser.close()
                log_steps.append("Done")

                sequence_log = " → ".join(log_steps)
                summary_report = "\n".join(results)
                return f"Sequence Log: {sequence_log}\n\nExport Summary:\n{summary_report}"

        except Exception as e:
            return f"Critical error during execution: {e}"
