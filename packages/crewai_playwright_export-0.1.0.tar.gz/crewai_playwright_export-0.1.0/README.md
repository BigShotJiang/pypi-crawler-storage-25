# crewai-playwright-export

A custom CrewAI tool for automated multi-tab report exporting from portals using Playwright. 

This tool logs into a specified web portal, automatically discovers all report subpage links, traverses them in separate browser tabs, performs scroll-based dynamic selector searching, exports the CSV reports, and manages download state and tab lifecycles.

## Features

- **Multi-Tab Execution**: Traverses and exports report pages in isolated browser tabs.
- **Session Auth Injection**: Automatically propagates active session credentials (`sessionStorage`) into newly opened tabs to bypass redirect guards.
- **Automatic Navigation**: Automatically traverses report lists to inner detail pages.
- **Dynamic Scrolling**: Scrolls down in 300px increments to locate Export buttons.
- **Pydantic Validation**: Input argument checking.

## Installation

Install the package using pip:
```bash
pip install crewai-playwright-export
```

Ensure Playwright browser drivers are installed:
```bash
playwright install chromium
```

## Usage

```python
from crewai import Agent, Task, Crew
from crewai_playwright_export import ExportReportsTool

# Instantiate the custom tool
export_tool = ExportReportsTool()

# Define the Agent
automation_agent = Agent(
    role="Data Export Specialist",
    goal="Collect and export all tabular reports from the portal",
    backstory="An automated script operator specialized in extraction.",
    tools=[export_tool],
    verbose=True
)

# Define the Task
export_task = Task(
    description="Export all campaign performance reports from https://gokulraj-v12.github.io/InterEQ/",
    expected_output="Log of successful CSV exports.",
    agent=automation_agent,
)

# Run the Crew
crew = Crew(agents=[automation_agent], tasks=[export_task])
result = crew.kickoff()
print(result)
```
