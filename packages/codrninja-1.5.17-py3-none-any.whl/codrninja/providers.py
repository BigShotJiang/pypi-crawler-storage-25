"""Multi-provider support for codrninja."""

import json
import os
from abc import ABC, abstractmethod
from typing import Dict, Iterator, List, Optional, Any

import requests

from .auth import OAuthFlow, TokenManager


class BaseProvider(ABC):

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    @abstractmethod
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        """Yield dicts: {'delta': str, 'model': str, 'tokens_input': int, 'tokens_output': int, 'done': bool}"""
        pass

    @abstractmethod
    def list_models(self) -> List[str]:
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        pass


# ── Ollama ────────────────────────────────────────────────────────────────────

class OllamaProvider(BaseProvider):

    def _base_url(self) -> str:
        url = self.config.get("url", "http://localhost:11434")
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        return url.rstrip("/")

    def _payload(self, messages, model, stream: bool) -> dict:
        reasoning = self.config.get("reasoning_level", "medium")
        num_ctx_map = {"none": 4096, "low": 8192, "medium": 16384, "high": 32768}
        num_ctx = self.config.get("num_ctx") or num_ctx_map.get(reasoning, 16384)
        return {
            "model": model or self.config.get("model", "codellama"),
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": self.config.get("temperature", 0.7),
                "num_predict": self.config.get("max_tokens", 16384),
                "num_ctx": num_ctx,
            },
        }

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        model = model or self.config.get("model", "codellama")
        try:
            r = requests.post(
                f"{self._base_url()}/api/chat",
                json=self._payload(messages, model, stream=False),
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            return {
                "content": data.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": data.get("prompt_eval_count", 0),
                "tokens_output": data.get("eval_count", 0),
                "done": True,
            }
        except requests.exceptions.ConnectionError:
            return {"error": f"Cannot connect to Ollama at {self._base_url()}", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        model = model or self.config.get("model", "codellama")
        try:
            with requests.post(
                f"{self._base_url()}/api/chat",
                json=self._payload(messages, model, stream=True),
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    delta = data.get("message", {}).get("content", "")
                    tokens_in = data.get("prompt_eval_count", tokens_in)
                    tokens_out = data.get("eval_count", tokens_out)
                    if delta:
                        yield {"delta": delta, "model": model, "tokens_input": tokens_in,
                               "tokens_output": tokens_out, "done": False}
                    if data.get("done"):
                        yield {"delta": "", "model": model, "tokens_input": tokens_in,
                               "tokens_output": tokens_out, "done": True}
                        return
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        try:
            r = requests.get(f"{self._base_url()}/api/tags", timeout=10)
            return [m["name"] for m in r.json().get("models", [])]
        except Exception:
            return ["codellama", "llama2", "mistral"]

    def get_default_model(self) -> str:
        return self.config.get("model", "codellama")


# ── OAuth-capable base ────────────────────────────────────────────────────────

class OAuthCapableProvider(BaseProvider):
    oauth_env_var: str = ""

    def _auth_headers(self) -> Dict[str, str]:
        access_token = self.config.get("access_token")
        if access_token:
            return {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        api_key = self.config.get("api_key") or os.environ.get(self.oauth_env_var)
        if not api_key:
            return {}
        return self._api_key_headers(api_key)

    @abstractmethod
    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        pass


# ── OpenAI ────────────────────────────────────────────────────────────────────

class OpenAIProvider(OAuthCapableProvider):
    oauth_env_var = "OPENAI_API_KEY"
    _BASE = "https://api.openai.com/v1"

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "OpenAI API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "gpt-4o")
        try:
            r = requests.post(
                f"{self._BASE}/chat/completions",
                headers=headers,
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096)},
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": data.get("model", model),
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        headers = self._auth_headers()
        if not headers:
            yield {"error": "OpenAI API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "gpt-4o")
        try:
            with requests.post(
                f"{self._BASE}/chat/completions",
                headers=headers,
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096),
                      "stream": True},
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                actual_model = model
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        yield {"delta": "", "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    try:
                        data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    actual_model = data.get("model", actual_model)
                    usage = data.get("usage") or {}
                    tokens_in = usage.get("prompt_tokens", tokens_in)
                    tokens_out = usage.get("completion_tokens", tokens_out)
                    delta = (data.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                    if delta:
                        yield {"delta": delta, "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        try:
            headers = self._auth_headers()
            if headers:
                r = requests.get(f"{self._BASE}/models", headers=headers, timeout=8)
                if r.ok:
                    ids = sorted(
                        m["id"] for m in r.json().get("data", [])
                        if any(m["id"].startswith(p) for p in ("gpt-", "o1", "o3", "o4", "codex"))
                    )
                    if ids:
                        return ids
        except Exception:
            pass
        return [
            "gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-5.3-codex", "gpt-5.2", "gpt-5",
            "gpt-4.5",
            "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
            "gpt-4o", "gpt-4o-mini",
            "o1", "o1-mini", "o1-pro",
            "o3", "o3-mini", "o4-mini",
            "codex-mini-latest",
        ]

    def get_default_model(self) -> str:
        return self.config.get("model", "gpt-4o")


# ── Anthropic ─────────────────────────────────────────────────────────────────

class AnthropicProvider(OAuthCapableProvider):
    oauth_env_var = "ANTHROPIC_API_KEY"
    _BASE = "https://api.anthropic.com/v1"

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {"x-api-key": api_key, "Content-Type": "application/json",
                "anthropic-version": "2023-06-01"}

    def _auth_headers(self) -> Dict[str, str]:
        headers = super()._auth_headers()
        if headers.get("Authorization"):
            headers["anthropic-version"] = "2023-06-01"
        return headers

    def _split_messages(self, messages):
        system = ""
        user_msgs = []
        for m in messages:
            if m["role"] == "system":
                system = m["content"]
            else:
                user_msgs.append({"role": m["role"], "content": m["content"]})
        return system, user_msgs

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "Anthropic API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "claude-sonnet-4-6")
        system, user_msgs = self._split_messages(messages)
        try:
            r = requests.post(
                f"{self._BASE}/messages",
                headers=headers,
                json={"model": model, "max_tokens": self.config.get("max_tokens", 4096),
                      "temperature": self.config.get("temperature", 0.7),
                      "system": system, "messages": user_msgs},
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            usage = data.get("usage", {})
            content = data.get("content", [{}])
            return {
                "content": content[0].get("text", "") if content else "",
                "model": data.get("model", model),
                "tokens_input": usage.get("input_tokens", 0),
                "tokens_output": usage.get("output_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        headers = self._auth_headers()
        if not headers:
            yield {"error": "Anthropic API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "claude-sonnet-4-6")
        system, user_msgs = self._split_messages(messages)
        try:
            with requests.post(
                f"{self._BASE}/messages",
                headers={**headers, "anthropic-version": "2023-06-01"},
                json={"model": model, "max_tokens": self.config.get("max_tokens", 4096),
                      "temperature": self.config.get("temperature", 0.7),
                      "system": system, "messages": user_msgs, "stream": True},
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                tokens_in = tokens_out = 0
                actual_model = model
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if line.startswith("data: "):
                        try:
                            data = json.loads(line[6:])
                        except json.JSONDecodeError:
                            continue
                        t = data.get("type", "")
                        if t == "content_block_delta":
                            delta = data.get("delta", {}).get("text", "")
                            if delta:
                                yield {"delta": delta, "model": actual_model,
                                       "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                        elif t == "message_delta":
                            usage = data.get("usage", {})
                            tokens_out = usage.get("output_tokens", tokens_out)
                        elif t == "message_start":
                            msg = data.get("message", {})
                            actual_model = msg.get("model", actual_model)
                            usage = msg.get("usage", {})
                            tokens_in = usage.get("input_tokens", tokens_in)
                        elif t == "message_stop":
                            yield {"delta": "", "model": actual_model,
                                   "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                            return
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        return [
            "claude-opus-4-7",
            "claude-sonnet-4-6",
            "claude-haiku-4-5",
            "claude-3-7-sonnet-20250219",
            "claude-3-5-sonnet-20241022",
            "claude-3-5-haiku-20241022",
            "claude-3-opus-20240229",
            "claude-3-haiku-20240307",
        ]

    def get_default_model(self) -> str:
        return self.config.get("model", "claude-sonnet-4-6")


# ── OpenRouter ────────────────────────────────────────────────────────────────

class OpenRouterProvider(BaseProvider):
    _BASE = "https://openrouter.ai/api/v1"

    def _headers(self) -> Dict[str, str]:
        api_key = self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY", "")
        return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        if not (self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")):
            return {"error": "OpenRouter API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "openai/gpt-4o")
        try:
            r = requests.post(
                f"{self._BASE}/chat/completions",
                headers=self._headers(),
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096)},
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": data.get("model", model),
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        if not (self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")):
            yield {"error": "OpenRouter API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "openai/gpt-4o")
        try:
            with requests.post(
                f"{self._BASE}/chat/completions",
                headers=self._headers(),
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096),
                      "stream": True},
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                actual_model = model
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        yield {"delta": "", "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    try:
                        data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    actual_model = data.get("model", actual_model)
                    usage = data.get("usage") or {}
                    tokens_in = usage.get("prompt_tokens", tokens_in)
                    tokens_out = usage.get("completion_tokens", tokens_out)
                    delta = (data.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                    if delta:
                        yield {"delta": delta, "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        try:
            r = requests.get(f"{self._BASE}/models",
                             headers=self._headers(), timeout=8)
            if r.ok:
                return sorted(m["id"] for m in r.json().get("data", []))
        except Exception:
            pass
        return ["openai/gpt-4o", "openai/gpt-4.1", "anthropic/claude-sonnet-4-6",
                "google/gemini-2.5-pro", "meta-llama/llama-3.3-70b-instruct"]

    def get_default_model(self) -> str:
        return self.config.get("model", "openai/gpt-4o")


# ── Claude CLI ───────────────────────────────────────────────────────────────

class ClaudeCliProvider(BaseProvider):
    """Routes via the local `claude` binary — uses your Claude Code subscription, no API key needed."""

    MODELS = [
        "claude-opus-4-7",
        "claude-sonnet-4-6",
        "claude-haiku-4-5",
        "claude-3-7-sonnet-20250219",
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
    ]

    def _binary(self) -> str:
        import shutil
        return self.config.get("binary") or shutil.which("claude") or "claude"

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        content = ""
        tokens_in = tokens_out = 0
        for chunk in self.chat_stream(messages, model):
            if chunk.get("error"):
                return {"error": chunk["error"], "content": ""}
            content += chunk.get("delta", "")
            tokens_in = chunk.get("tokens_input", tokens_in)
            tokens_out = chunk.get("tokens_output", tokens_out)
        return {
            "content": content,
            "model": model or self.get_default_model(),
            "tokens_input": tokens_in,
            "tokens_output": tokens_out,
            "done": True,
        }

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        import subprocess, json as _json
        binary = self._binary()
        model = model or self.get_default_model()
        prompt = messages[-1]["content"] if messages else ""
        cmd = [
            binary, "--print",
            "--output-format", "stream-json",
            "--verbose",
            "--model", model,
            "--dangerously-skip-permissions",
        ]
        tokens_in = tokens_out = 0
        try:
            proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, text=True,
            )
            proc.stdin.write(prompt)
            proc.stdin.close()
            for line in proc.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = _json.loads(line)
                except ValueError:
                    continue
                typ = obj.get("type", "")
                if typ == "assistant":
                    for block in obj.get("message", {}).get("content", []):
                        if block.get("type") == "text":
                            yield {"delta": block["text"], "model": model,
                                   "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                elif typ == "result":
                    usage = obj.get("usage", {})
                    tokens_in = usage.get("input_tokens", 0)
                    tokens_out = usage.get("output_tokens", 0)
            proc.wait()
        except FileNotFoundError:
            yield {"delta": "[claude CLI not found — install Claude Code first]",
                   "model": model, "tokens_input": 0, "tokens_output": 0, "done": False}
        yield {"delta": "", "model": model, "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}

    def list_models(self) -> List[str]:
        return self.MODELS

    def get_default_model(self) -> str:
        return self.config.get("model", "claude-sonnet-4-6")


# ── Manager ───────────────────────────────────────────────────────────────────

class ProviderManager:

    PROVIDERS = {
        "ollama":      OllamaProvider,
        "openai":      OpenAIProvider,
        "anthropic":   AnthropicProvider,
        "openrouter":  OpenRouterProvider,
        "claude-cli":  ClaudeCliProvider,
    }

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.current_provider = config.get("provider", "ollama")
        self.token_manager = TokenManager()
        self.oauth_buffer_minutes = int(config.get("oauth", {}).get("refresh_buffer_minutes", 5))

    def _provider_config(self, name: str) -> Dict[str, Any]:
        return dict(self.config.get("providers", {}).get(name, {}))

    def _inject_oauth(self, name: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
        if name not in {"openai", "anthropic"}:
            return cfg
        tokens = self.token_manager.get_tokens(name)
        if not tokens:
            return cfg
        if self.token_manager.is_token_expired(tokens, buffer_minutes=self.oauth_buffer_minutes):
            rt = tokens.get("refresh_token")
            if rt:
                try:
                    refreshed = OAuthFlow(name).refresh(rt, metadata=tokens.get("metadata", {}))
                    if not refreshed.get("refresh_token"):
                        refreshed["refresh_token"] = rt
                    self.token_manager.store_tokens(name, refreshed)
                    tokens = refreshed
                except Exception:
                    pass
        if tokens.get("access_token"):
            cfg["access_token"] = tokens["access_token"]
        return cfg

    def get_provider(self, name: Optional[str] = None) -> BaseProvider:
        name = name or self.current_provider
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}. Available: {list(self.PROVIDERS.keys())}")
        return self.PROVIDERS[name](self._inject_oauth(name, self._provider_config(name)))

    def set_provider(self, name: str):
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}")
        self.current_provider = name

    def list_providers(self) -> List[str]:
        return list(self.PROVIDERS.keys())

    def list_models(self, provider: Optional[str] = None) -> List[str]:
        return self.get_provider(provider).list_models()
