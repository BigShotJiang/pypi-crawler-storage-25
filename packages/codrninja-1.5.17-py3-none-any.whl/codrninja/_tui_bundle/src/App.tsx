import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Box, Text } from 'ink';
import { createSession, deleteSession, fetchConfig, fetchProviders, fetchSession, fetchSessions, fetchVersion, Session } from './api.js';
import { SessionList } from './SessionList.js';
import { ChatView } from './ChatView.js';
import { ModelSelect } from './ModelSelect.js';
import { ProviderSelect } from './ProviderSelect.js';
import { ProviderConfig } from './ProviderConfig.js';
import { ProviderInfo } from './api.js';
import { ChatMessage, Screen } from './types.js';

export function App() {
  const [screen, setScreen] = useState<Screen>('sessions');
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeName, setActiveName] = useState<string | null>(null);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [config, setConfig] = useState<Record<string, string>>({});
  const [prevScreen, setPrevScreen] = useState<Screen>('sessions');
  const [configProvider, setConfigProvider] = useState<ProviderInfo | null>(null);
  const [loadError, setLoadError] = useState('');
  const [loading, setLoading] = useState(true);
  const [sessionModel, setSessionModelState] = useState<string>('');
  const [sessionProvider, setSessionProviderState] = useState<string>('');
  const [providers, setProviders] = useState<ProviderInfo[]>([]);
  const [version, setVersion] = useState<string>('');

  // stable ref so openSession callback doesn't need sessions in its deps
  const sessionsRef = useRef<Session[]>([]);
  useEffect(() => { sessionsRef.current = sessions; }, [sessions]);

  const openSession = useCallback(async (name: string) => {
    try {
      const data = await fetchSession(name);
      const msgs: ChatMessage[] = (data.messages ?? [])
        .filter((m) => m.role === 'user' || m.role === 'assistant')
        .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
      const s = sessionsRef.current.find((x) => x.name === name);
      setSessionModelState(s?.model ?? '');
      setSessionProviderState(s?.provider ?? '');
      setHistory(msgs);
      setActiveName(name);
      setScreen('chat');
    } catch {
      setHistory([]);
      setActiveName(name);
      setScreen('chat');
    }
  }, []);

  useEffect(() => {
    async function init() {
      try {
        const [cfg, sess, provs, ver] = await Promise.all([
          fetchConfig(), fetchSessions(), fetchProviders(), fetchVersion(),
        ]);
        setProviders(provs.providers ?? []);
        setVersion(ver);
        setConfig(cfg);
        setSessions(sess);

        const autoSession = process.env['CODRNINJA_SESSION'];
        if (autoSession) {
          const exists = sess.find((s) => s.name === autoSession);
          if (!exists) await createSession(autoSession);
          await openSession(autoSession);
          return;
        }
      } catch (e) {
        setLoadError(
          `Cannot reach server. Start it with: codrninja serve\n  ${String(e)}`,
        );
      } finally {
        setLoading(false);
      }
    }
    void init();
  }, [openSession]);

  async function newSession(name: string) {
    try {
      await createSession(name);
      const sess = await fetchSessions();
      setSessions(sess);
      await openSession(name);
    } catch (e) {
      setLoadError(String(e));
    }
  }

  function backToSessions() {
    setScreen('sessions');
    fetchSessions().then(setSessions).catch(() => {});
  }

  async function handleDeleteSession(name: string) {
    try {
      await deleteSession(name);
      const sess = await fetchSessions();
      setSessions(sess);
    } catch { /* ignore */ }
  }

  function openModelSelect() {
    setPrevScreen(screen);
    setScreen('model-select');
  }

  function onModelSelected(model: string, provider: string) {
    if (prevScreen === 'chat' && activeName) {
      // Re-open session so ChatView remounts with full backend history
      setSessionModelState(model);
      setSessionProviderState(provider);
      void openSession(activeName);
    } else {
      setConfig((c) => ({ ...c, model, provider }));
      setScreen(prevScreen);
    }
  }

  function openProviderSelect() {
    setPrevScreen(screen);
    setScreen('provider-select');
  }

  function onProviderChosen(p: ProviderInfo) {
    setConfigProvider(p);
    setScreen('provider-config');
  }

  function onProviderConfigDone(newProvider: string, newModel?: string) {
    setConfig((c) => ({
      ...c,
      provider: newProvider,
      ...(newModel ? { model: newModel } : {}),
    }));
    if (prevScreen === 'chat' && activeName) {
      void openSession(activeName);
    } else {
      setScreen(prevScreen);
    }
  }

  if (loading) {
    return (
      <Box paddingX={2}>
        <Text dimColor>Connecting to server…</Text>
      </Box>
    );
  }

  if (loadError) {
    return (
      <Box flexDirection="column" paddingX={2}>
        <Text bold color="red">Error</Text>
        <Text>{loadError}</Text>
      </Box>
    );
  }

  if (screen === 'provider-select') {
    return (
      <ProviderSelect
        onSelect={onProviderChosen}
        onCancel={() => setScreen(prevScreen)}
      />
    );
  }

  if (screen === 'provider-config' && configProvider) {
    return (
      <ProviderConfig
        provider={configProvider}
        onDone={onProviderConfigDone}
        onCancel={() => setScreen(prevScreen)}
      />
    );
  }

  if (screen === 'model-select') {
    const fromChat = prevScreen === 'chat';
    return (
      <ModelSelect
        currentModel={fromChat ? (sessionModel || (config['model'] ?? '')) : (config['model'] ?? '')}
        currentProvider={fromChat ? (sessionProvider || (config['provider'] ?? '')) : (config['provider'] ?? '')}
        sessionName={fromChat && activeName ? activeName : undefined}
        onSelect={onModelSelected}
        onCancel={() => setScreen(prevScreen)}
      />
    );
  }

  if (screen === 'chat' && activeName) {
    return (
      <ChatView
        sessionName={activeName}
        history={history}
        onBack={backToSessions}
        onOpenModelSelect={openModelSelect}
        onOpenProviderSelect={openProviderSelect}
        provider={sessionProvider || (config['provider'] ?? '')}
        model={sessionModel || (config['model'] ?? '')}
      />
    );
  }

  return (
    <SessionList
      sessions={sessions}
      onSelect={openSession}
      onNew={newSession}
      onDelete={handleDeleteSession}
      error={loadError}
      version={version}
      providers={providers}
    />
  );
}
