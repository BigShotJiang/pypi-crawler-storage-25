export type Screen = 'sessions' | 'chat' | 'model-select' | 'provider-select' | 'provider-config';

export interface ToolCall {
  call_id: string;
  tool: string;
  args: Record<string, unknown>;
  step: number;
  output?: string;
  success?: boolean;
  done: boolean;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'tool';
  content: string;
  streaming?: boolean;
  toolData?: ToolCall;
  tokens?: number;
  isThinkingComplete?: boolean;
  thinkingMs?: number;
  thinkingLabel?: string;
}
