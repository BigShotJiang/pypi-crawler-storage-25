from __future__ import annotations

from typing import Any, cast

import httpx
import structlog
from jose import jwt as jose_jwt

logger = structlog.get_logger(__name__)


class PulseEngineClient:
    """Client used inside container stages to call Pulse Engine REST API."""

    def __init__(
        self,
        base_url: str,
        token: str,
        job_id: str,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._job_id = job_id
        # Decode token without verification to read backend claims
        # (signature was already verified by Pulse Engine before injecting the token)
        try:
            self._token_claims: dict[str, Any] = jose_jwt.get_unverified_claims(token)
        except Exception:
            self._token_claims = {}
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    @property
    def job_id(self) -> str:
        return self._job_id

    async def report_status(
        self,
        stage: str,
        status: str,
        error: str | None = None,
        result_summary: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Report stage status back to Pulse Engine."""
        payload: dict[str, Any] = {"stage": stage, "status": status}
        if error is not None:
            payload["error"] = error
        if result_summary is not None:
            payload["result_summary"] = result_summary
        resp = await self._client.post(
            f"/api/v1/jobs/{self._job_id}/status",
            json=payload,
        )
        resp.raise_for_status()
        return cast(dict[str, Any], resp.json())

    async def store_documents(self, documents: list[dict[str, Any]]) -> dict[str, Any]:
        """Store processed documents in the knowledge base."""
        resp = await self._client.post(
            "/api/v1/kb/documents",
            json={"documents": documents},
        )
        resp.raise_for_status()
        return cast(dict[str, Any], resp.json())

    async def trigger_next_stage(
        self,
        product: str,
        next_stage: str,
        chain: bool = True,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Trigger the next stage, forwarding the same orchestrator+compute backend."""
        payload: dict[str, Any] = {
            "product": product,
            "stage": next_stage,
            "chain": chain,
            "job_id": self._job_id,
            "orchestrator": self._token_claims.get("orchestrator", "prefect"),
            "compute": self._token_claims.get("compute", "ecs"),
        }
        if config:
            payload["config"] = config
        resp = await self._client.post("/api/v1/jobs/", json=payload)
        resp.raise_for_status()
        return cast(dict[str, Any], resp.json())

    async def close(self) -> None:
        await self._client.aclose()
