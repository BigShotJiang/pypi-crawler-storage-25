"""BatcherAdapter — splits a list of items into fixed-size batches."""

from __future__ import annotations

from typing import Any


class BatcherAdapter:
    """Split a flat list of items into batches of a fixed size.

    Usage::

        adapter = BatcherAdapter(batch_size=50)
        result = adapter.batch(items)
        # result == {"batches": [[...], [...]]}
    """

    def __init__(self, batch_size: int = 50) -> None:
        if batch_size < 1:
            raise ValueError(f"batch_size must be >= 1, got {batch_size}")
        self.batch_size = batch_size

    def batch(self, items: list[Any]) -> dict[str, list[list[Any]]]:
        """Split items into batches.

        Args:
            items: Flat list of items to batch.

        Returns:
            {"batches": [[item, ...], ...]}
        """
        batches = [
            items[i : i + self.batch_size]
            for i in range(0, len(items), self.batch_size)
        ]
        return {"batches": batches}
