"""Fetches and extracts text content from speech PDFs."""

from __future__ import annotations

import asyncio
import re

import httpx
import structlog

from .models import SpeechContent, SpeechMetadata, SpeechResult

logger = structlog.get_logger(__name__)

_DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; PulseBot/1.0)"}
_DEVANAGARI_RE = re.compile(r"[\u0900-\u097F]")


def _detect_language(text: str) -> str:
    deva = len(_DEVANAGARI_RE.findall(text))
    total = len(text.replace(" ", ""))
    if not total:
        return "en"
    ratio = deva / total
    if ratio > 0.4:
        return "hi"
    if ratio > 0.1:
        return "mixed"
    return "en"


class SpeechContentAdapter:
    """Fetches PDF text for speeches discovered by ``SpeechMetadataAdapter``.

    Mirrors the ``DigitalNewsAdapter`` interface: call ``fetch()`` for a single
    speech or ``fetch_many()`` for a batch.

    Requires ``pymupdf`` (``fitz``) to be installed for PDF extraction.

    Usage::

        adapter = SpeechContentAdapter()
        content = await adapter.fetch(metadata)

        results = await adapter.fetch_many(metadata_list, concurrency=4)
    """

    def __init__(self, concurrency: int = 4, timeout: float = 60.0) -> None:
        self._default_concurrency = concurrency
        self._timeout = timeout

    async def fetch(self, speech: SpeechMetadata) -> SpeechContent:
        """Download and extract text from a single speech PDF. Raises on failure."""
        if not speech.pdf_url:
            raise ValueError(f"No PDF URL for speech: {speech.url}")

        logger.info("speech_content_fetch_started", url=speech.url, pdf=speech.pdf_url)
        text = await self._extract_pdf(speech.pdf_url)
        if not text:
            raise RuntimeError(
                f"PDF extraction returned empty text for {speech.pdf_url}"
            )

        language = _detect_language(text)
        logger.info(
            "speech_content_fetch_completed",
            url=speech.url,
            chars=len(text),
            language=language,
        )
        return SpeechContent(text=text, language=language, pdf_url=speech.pdf_url)

    async def fetch_many(
        self,
        speeches: list[SpeechMetadata],
        concurrency: int | None = None,
    ) -> list[SpeechResult]:
        """Extract content from multiple speeches concurrently.

        Speeches without a PDF URL are returned immediately as errors.
        Preserves input order.
        """
        if not speeches:
            return []

        sem = asyncio.Semaphore(concurrency or self._default_concurrency)

        async def _guarded(speech: SpeechMetadata) -> SpeechResult:
            async with sem:
                try:
                    content = await self.fetch(speech)
                    return SpeechResult(url=speech.url, content=content, error=None)
                except Exception as exc:
                    logger.warning(
                        "speech_content_fetch_failed",
                        url=speech.url,
                        error=str(exc),
                    )
                    return SpeechResult(url=speech.url, content=None, error=str(exc))

        tasks = [_guarded(s) for s in speeches]
        return list(await asyncio.gather(*tasks))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _extract_pdf(self, pdf_url: str) -> str:
        """Download PDF bytes and extract plain text via pymupdf."""
        try:
            import fitz  # pymupdf
        except ImportError:
            raise RuntimeError(
                "pymupdf is required for PDF extraction: pip install pymupdf"
            )

        async with httpx.AsyncClient(
            follow_redirects=True, headers=_DEFAULT_HEADERS, timeout=self._timeout
        ) as client:
            resp = await client.get(pdf_url)
            resp.raise_for_status()
            pdf_bytes = resp.content

        def _parse() -> str:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            pages = [page.get_text() for page in doc if page.get_text().strip()]
            doc.close()
            return "\n\n".join(pages).strip()

        return await asyncio.to_thread(_parse)
