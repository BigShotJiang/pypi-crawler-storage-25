"""Fetches article content via Cloudflare Browser Rendering and LLM extraction."""

import asyncio
import os
from typing import Any

import httpx
import structlog
from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import BaseModel, Field

from .models import ArticleContent, ArticleResult

logger = structlog.get_logger(__name__)

_CF_MARKDOWN_URL = (
    "https://api.cloudflare.com/client/v4/accounts"
    "/{account_id}/browser-rendering/markdown"
)

_EXTRACTION_PROMPT = (
    "Extract the article title and the main body content verbatim. "
    "Ignore ads, navigation, comments, and unrelated sections. "
    "Return clean readable text."
)


class _ArticleSchema(BaseModel):
    """Schema for structured LLM output."""

    title: str = Field(description="The main headline of the article")
    content: str = Field(description="The full main article text content")


class DigitalNewsAdapter:
    """Fetches article content via Cloudflare Browser Rendering + LLM.

    Accepts any LangChain BaseChatModel — works with OpenAI, Anthropic,
    Ollama, Gemini, or any provider LangChain supports.

    Usage:
        # With explicit LLM
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI(model="gpt-5.4-nano")
        adapter = DigitalNewsAdapter(llm=llm)

        # With project default (from get_llm())
        from pulse_engine.processor.llm.provider import get_llm
        adapter = DigitalNewsAdapter(llm=get_llm())

        # Ollama
        from langchain_ollama import ChatOllama
        adapter = DigitalNewsAdapter(llm=ChatOllama(model="llama3"))
    """

    def __init__(
        self,
        llm: Any,
        cloudflare_timeout: float = 60.0,
    ) -> None:
        self._llm = llm
        self._cloudflare_timeout = cloudflare_timeout

        self._account_id = os.environ.get("CLOUDFLARE_ACCOUNT_ID")
        if not self._account_id:
            raise OSError("CLOUDFLARE_ACCOUNT_ID environment variable is required")

        self._bearer_token = os.environ.get("CLOUDFLARE_BEARER_TOKEN")
        if not self._bearer_token:
            raise OSError("CLOUDFLARE_BEARER_TOKEN environment variable is required")

    async def fetch(self, url: str) -> ArticleContent:
        """Fetch and extract content from a single article URL."""
        markdown = await self._fetch_markdown(url)
        return await self._extract_content(markdown)

    async def fetch_many(
        self,
        urls: list[str],
        concurrency: int = 5,
    ) -> list[ArticleResult]:
        """Fetch multiple articles concurrently, preserving input order."""
        if not urls:
            return []

        semaphore = asyncio.Semaphore(concurrency)

        async def _guarded(u: str) -> ArticleResult:
            async with semaphore:
                try:
                    content = await self.fetch(u)
                    return ArticleResult(url=u, content=content, error=None)
                except Exception as exc:
                    logger.warning("fetch_failed", url=u, error=str(exc))
                    return ArticleResult(url=u, content=None, error=str(exc))

        tasks = [_guarded(u) for u in urls]
        return list(await asyncio.gather(*tasks))

    async def _fetch_markdown(self, url: str) -> str:
        cf_url = _CF_MARKDOWN_URL.format(account_id=self._account_id)
        async with httpx.AsyncClient(
            timeout=self._cloudflare_timeout, follow_redirects=True
        ) as client:
            resp = await client.post(
                cf_url,
                headers={
                    "Authorization": f"Bearer {self._bearer_token}",
                    "Content-Type": "application/json",
                },
                json={"url": url},
            )
            resp.raise_for_status()

        data = resp.json()
        markdown: str = data.get("result", "")
        if not markdown or not markdown.strip():
            raise RuntimeError(f"Empty markdown returned by Cloudflare for {url}")
        return markdown

    async def _extract_content(self, markdown: str) -> ArticleContent:
        structured_llm = self._llm.with_structured_output(_ArticleSchema)
        messages = [
            SystemMessage(content=_EXTRACTION_PROMPT),
            HumanMessage(content=markdown),
        ]
        result: _ArticleSchema = await structured_llm.ainvoke(messages)
        return ArticleContent(title=result.title, content=result.content)
