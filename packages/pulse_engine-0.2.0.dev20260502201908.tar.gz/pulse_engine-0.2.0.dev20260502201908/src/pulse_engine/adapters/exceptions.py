"""Custom exceptions for digital news adapters."""


class SitemapDiscoveryError(Exception):
    """Raised when sitemap discovery fails for a domain."""

    def __init__(self, domain: str, reason: str) -> None:
        self.domain = domain
        self.reason = reason
        super().__init__(f"Sitemap discovery failed for {domain}: {reason}")
