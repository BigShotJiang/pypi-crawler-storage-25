"""YouTube audio downloader adapter (yt-dlp only)."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

import structlog

from pulse_engine.secrets import fetch_secret

logger = structlog.get_logger(__name__)

# Default yt-dlp player clients. "tv_embedded" returns audio-only streams for
# age-restricted videos when cookies are provided. Override via YT_DLP_PLAYER_CLIENTS.
_DEFAULT_PLAYER_CLIENTS = ["tv_embedded", "web"]


def _build_yt_dlp_opts(
    output_template: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build yt-dlp option dict, merging env defaults with caller overrides."""
    raw_clients = os.environ.get("YT_DLP_PLAYER_CLIENTS", "").strip()
    clients: list[str] = (
        [c.strip() for c in raw_clients.split(",") if c.strip()]
        if raw_clients
        else _DEFAULT_PLAYER_CLIENTS
    )

    opts: dict[str, Any] = {
        "format": "bestaudio/best",
        "outtmpl": output_template,
        "postprocessors": [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "64",
            }
        ],
        "quiet": True,
        "no_warnings": True,
        # Fetch updated EJS challenge solver from GitHub when bundled version
        # can't handle the current YouTube player's n-challenge.
        # Must be a set — passing a string causes it to be iterated as chars.
        "remote_components": {"ejs:github"},
        "extractor_args": {
            "youtube": {
                "player_client": clients,
            }
        },
    }

    if not extra:
        return opts

    override = dict(extra)
    # cookies_content is handled separately — materialised to a temp file.
    override.pop("cookies_content", None)
    ea = override.pop("extractor_args", None)
    opts.update(override)
    if isinstance(ea, dict):
        existing = opts.get("extractor_args") or {}
        merged: dict[str, Any] = {**existing}
        for k, v in ea.items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k] = {**merged[k], **v}
            else:
                merged[k] = v
        opts["extractor_args"] = merged

    return opts


class YouTubeDownloader:
    """Downloads audio from YouTube via yt-dlp, returning a Path to an mp3 file.

    Environment variables:
        - ``YT_DLP_PLAYER_CLIENTS``    — comma-separated yt-dlp client list
        - ``YT_DLP_COOKIES_SECRET_ID`` — Secrets Manager secret name/ARN for cookies.txt
        - ``AWS_REGION``               — region for Secrets Manager (default: us-east-1)
    """

    def __init__(self, yt_dlp_opts: dict[str, Any] | None = None) -> None:
        self._yt_dlp_opts = yt_dlp_opts or {}
        self._cookies_secret_id: str = os.environ.get(
            "YT_DLP_COOKIES_SECRET_ID", ""
        ).strip()
        self._aws_region: str = os.environ.get("AWS_REGION", "us-east-1").strip()
        self._cookies_cache: str | None = None  # lazily populated

    async def download(self, video_id: str, output_dir: str) -> Path | None:
        """Download audio for *video_id* into *output_dir*, returning path to mp3.

        Returns ``None`` if the download fails for any reason.
        """
        url = f"https://www.youtube.com/watch?v={video_id}"
        logger.info("youtube_download_started", video_id=video_id)

        result = await self._download_audio(url, output_dir)
        if result is None:
            logger.warning("youtube_download_failed", video_id=video_id)
        else:
            logger.info("youtube_download_completed", video_id=video_id, path=str(result))
        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _resolve_cookies(self) -> str:
        """Return cookies.txt content, fetching from Secrets Manager if configured.

        Result is cached after the first successful fetch so subsequent videos
        in the same adapter instance don't make redundant API calls.
        """
        if self._cookies_cache is not None:
            return self._cookies_cache

        if not self._cookies_secret_id:
            self._cookies_cache = ""
            return ""

        logger.debug(
            "youtube_cookies_fetching_secret",
            secret_id=self._cookies_secret_id,
            region=self._aws_region,
        )
        import json as _json

        raw = await fetch_secret(self._cookies_secret_id, self._aws_region)
        # Secret may be stored as {"YT_DLP_COOKIES_SECRET_ID": "<netscape txt>"}
        try:
            parsed = _json.loads(raw)
            if isinstance(parsed, dict):
                for v in parsed.values():
                    if isinstance(v, str):
                        raw = v
                        break
        except ValueError:
            pass
        cookies = raw
        self._cookies_cache = cookies
        logger.info(
            "youtube_cookies_loaded_from_secrets_manager",
            secret_id=self._cookies_secret_id,
            chars=len(cookies),
        )
        return cookies

    async def _download_audio(self, url: str, output_dir: str) -> Path | None:
        """Download audio from a YouTube URL to *output_dir* via yt-dlp."""
        try:
            import yt_dlp
        except ImportError:
            logger.warning("yt_dlp_not_installed", url=url)
            return None

        output_template = str(Path(output_dir) / "%(id)s.%(ext)s")
        ydl_opts = _build_yt_dlp_opts(output_template, extra=self._yt_dlp_opts)

        # Resolve cookies (priority: Secrets Manager > env var).
        cookies_content = await self._resolve_cookies()
        if cookies_content and "cookiefile" not in ydl_opts:
            cookies_path = Path(output_dir) / "cookies.txt"
            cookies_path.write_text(cookies_content, encoding="utf-8")
            try:
                import os as _os
                _os.chmod(cookies_path, 0o600)
            except OSError:
                pass
            ydl_opts["cookiefile"] = str(cookies_path)

        def _download() -> Path | None:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                candidate = Path(output_dir) / f"{info.get('id', '')}.mp3"
                return candidate if candidate.exists() else None

        try:
            return await asyncio.to_thread(_download)
        except Exception:
            logger.warning("youtube_audio_download_failed", url=url, exc_info=True)
            return None
