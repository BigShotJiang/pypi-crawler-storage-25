"""Discovers speech metadata from inc.in listing pages."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime, timedelta

import httpx
import structlog

from .models import SpeechMetadata

logger = structlog.get_logger(__name__)

_INC_BASE = "https://www.inc.in/media/speeches"
_MEDIA_PATH = "/media/speeches/"
_MAX_PAGES = 200

_DATE_RE = re.compile(r"\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b")
_YT_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)"
    r"([\w\-]{11})",
    re.I,
)
_PDF_RE = re.compile(r"https?://[^\s'\"]+?\.pdf(?:\?[^'\"\s]*)?", re.I)
_DATE_FORMATS = [
    "%d %B %Y",
    "%d %b %Y",
    "%B %d, %Y",
    "%b %d, %Y",
    "%Y-%m-%d",
    "%d/%m/%Y",
]

_DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; PulseBot/1.0)"}


def _parse_date(text: str | None) -> datetime | None:
    if not text:
        return None
    m = _DATE_RE.search(text)
    if m:
        text = f"{m.group(1)} {m.group(2)} {m.group(3)}"
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(text.strip(), fmt).replace(tzinfo=UTC)
        except ValueError:
            continue
    return None


def _scan_for_media(obj: object) -> tuple[str | None, str | None]:
    """Recursively scan a JSON object for PDF and YouTube URLs."""
    pdf: str | None = None
    yt: str | None = None

    def walk(node: object) -> None:
        nonlocal pdf, yt
        if pdf and yt:
            return
        if isinstance(node, str):
            if not pdf and ".pdf" in node.lower():
                m = _PDF_RE.search(node)
                if m:
                    pdf = m.group(0)
            if not yt:
                m = _YT_RE.search(node)
                if m:
                    yt = f"https://www.youtube.com/watch?v={m.group(1)}"
        elif isinstance(node, dict):
            if not pdf:
                u = node.get("url", "")
                if isinstance(u, str) and ".pdf" in u.lower() and u.startswith("http"):
                    pdf = u
            if not yt:
                _yt_keys = (
                    "youtube_url",
                    "youtube",
                    "video_url",
                    "video_link",
                    "embed_url",
                )
                for k in _yt_keys:
                    v = node.get(k)
                    if isinstance(v, str):
                        m = _YT_RE.search(v)
                        if m:
                            yt = f"https://www.youtube.com/watch?v={m.group(1)}"
                            break
            for v in node.values():
                walk(v)
        elif isinstance(node, list | tuple):
            for v in node:
                walk(v)

    walk(obj)
    return pdf, yt


class SpeechMetadataAdapter:
    """Discovers speech metadata from the inc.in speeches listing.

    Mirrors the ``DigitalNewsMetadataAdapter`` interface: construct with
    optional filters, call ``fetch()`` to get a list of ``SpeechMetadata``.

    Each entry contains the speech URL, title, speaker, date, PDF URL, and
    YouTube URL (when present). Content extraction (PDF text) is handled
    separately by ``SpeechContentAdapter``.

    Usage::

        adapter = SpeechMetadataAdapter()
        speeches = await adapter.fetch(since=timedelta(days=7), speaker="rahul")
    """

    def __init__(self, base_url: str = _INC_BASE) -> None:
        self._base_url = base_url.rstrip("/")

    async def fetch(
        self,
        since: timedelta | None = None,
        speaker: str | None = None,
    ) -> list[SpeechMetadata]:
        """Discover and return filtered speech metadata.

        Args:
            since: Only return speeches published within this window.
            speaker: Case-insensitive substring match against speaker name.

        Returns:
            List of ``SpeechMetadata``, ordered as discovered from listing.
        """
        logger.info(
            "speech_metadata_fetch_started",
            since=str(since),
            speaker=speaker,
        )
        cutoff = (datetime.now(UTC) - since) if since is not None else None
        urls = await self._discover_urls()
        logger.info("speech_urls_discovered", count=len(urls))

        entries = await self._parse_pages(urls)
        logger.info("speech_pages_parsed", total=len(entries))

        filtered = self._apply_filters(entries, cutoff=cutoff, speaker=speaker)
        logger.info(
            "speech_metadata_fetch_completed",
            before=len(entries),
            after=len(filtered),
        )
        return filtered

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    async def _discover_urls(self) -> list[str]:
        seen: set[str] = set()

        async with httpx.AsyncClient(
            follow_redirects=True, headers=_DEFAULT_HEADERS, timeout=30
        ) as client:
            # Page 1 — also extract buildId for JSON API route.
            build_id = await self._scrape_html_page(client, self._base_url, seen)

            if isinstance(build_id, str):
                # JSON API is complete — no need for HTML pagination.
                await self._scrape_json_pages(client, build_id, seen)
            else:
                # JSON unavailable — fall back to HTML pagination.
                # Break as soon as a page returns no speech links at all.
                for page in range(2, _MAX_PAGES + 1):
                    url = f"{self._base_url}/page/{page}"
                    had_links = await self._scrape_html_page(
                        client, url, seen, return_had_links=True
                    )
                    if not had_links:
                        break

        return list(seen)

    async def _scrape_html_page(
        self,
        client: httpx.AsyncClient,
        url: str,
        seen: set[str],
        return_had_links: bool = False,
    ) -> str | None | bool:
        """Scrape one HTML listing page, add speech URLs to *seen*.

        When *return_had_links* is True, returns a bool indicating whether any
        speech links were found on the page (used to detect end of pagination).
        Otherwise returns the Next.js buildId if found, else None.
        """
        try:
            resp = await client.get(url)
            if resp.status_code != 200:
                return False if return_had_links else None
        except httpx.HTTPError:
            return False if return_had_links else None

        from bs4 import BeautifulSoup

        soup = BeautifulSoup(resp.text, "html.parser")
        had_links = False
        for a in soup.find_all("a", href=True):
            href = str(a["href"])
            if href.startswith(_MEDIA_PATH) and href.count("/") >= 3:
                seen.add(f"https://www.inc.in{href}")
                had_links = True

        if return_had_links:
            return had_links

        build_id: str | None = None
        script = soup.find("script", id="__NEXT_DATA__", type="application/json")
        if script:
            try:
                data = json.loads(script.string or script.get_text())
                build_id = data.get("buildId")
                self._collect_urls_from_obj(data, seen)
            except (json.JSONDecodeError, AttributeError):
                pass
        return build_id

    async def _scrape_json_pages(
        self,
        client: httpx.AsyncClient,
        build_id: str,
        seen: set[str],
    ) -> None:
        base = f"https://www.inc.in/_next/data/{build_id}/media/speeches.json"
        no_progress = 0
        for page in range(1, _MAX_PAGES + 1):
            try:
                resp = await client.get(f"{base}?page={page}")
                if resp.status_code != 200:
                    break
                before = len(seen)
                self._collect_urls_from_obj(resp.json(), seen)
                added = len(seen) - before
                logger.debug("json_page", page=page, added=added, total=len(seen))
                no_progress = 0 if added else no_progress + 1
                if no_progress >= 2:
                    break
            except Exception:
                logger.debug("json_page_failed", page=page, exc_info=True)
                break

    @staticmethod
    def _collect_urls_from_obj(obj: object, seen: set[str]) -> None:
        if isinstance(obj, dict):
            uid = obj.get("uid")
            if isinstance(uid, str) and uid and "/" not in uid.strip("/"):
                seen.add(f"https://www.inc.in{_MEDIA_PATH}{uid.strip('/')}")
            for v in obj.values():
                SpeechMetadataAdapter._collect_urls_from_obj(v, seen)
        elif isinstance(obj, list | tuple):
            for v in obj:
                SpeechMetadataAdapter._collect_urls_from_obj(v, seen)
        elif isinstance(obj, str) and obj.strip().startswith(_MEDIA_PATH):
            seen.add(f"https://www.inc.in{obj.strip()}")

    # ------------------------------------------------------------------
    # Page parsing
    # ------------------------------------------------------------------

    async def _parse_pages(self, urls: list[str]) -> list[SpeechMetadata]:
        async with httpx.AsyncClient(
            follow_redirects=True, headers=_DEFAULT_HEADERS, timeout=30
        ) as client:
            import asyncio

            tasks = [self._parse_one(client, url) for url in urls]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        entries: list[SpeechMetadata] = []
        for url, result in zip(urls, results):
            if isinstance(result, BaseException):
                logger.warning("speech_page_parse_failed", url=url, error=str(result))
            elif result is not None:
                entries.append(result)
        return entries

    async def _parse_one(
        self, client: httpx.AsyncClient, url: str
    ) -> SpeechMetadata | None:
        try:
            resp = await client.get(url)
            if resp.status_code != 200:
                return None
        except httpx.HTTPError as exc:
            logger.debug("speech_page_http_error", url=url, error=str(exc))
            return None

        from bs4 import BeautifulSoup

        soup = BeautifulSoup(resp.text, "html.parser")
        title = speaker = date_raw = pdf_url = yt_url = None

        script = soup.find("script", id="__NEXT_DATA__", type="application/json")
        if script:
            try:
                data = json.loads(script.string or script.get_text())
                pp = (data.get("props") or {}).get("pageProps") or {}
                obj = (
                    pp.get("objspeeches")
                    or pp.get("objSpeeches")
                    or pp.get("speech")
                    or pp
                )
                if isinstance(obj, dict):
                    speaker = obj.get("title") or obj.get("speaker")
                    title = obj.get("expert") or obj.get("title") or obj.get("heading")
                    date_raw = (
                        obj.get("publishdate")
                        or obj.get("publishedate")
                        or obj.get("date")
                    )
                    speech_doc = obj.get("SpeechDocument")
                    if isinstance(speech_doc, dict):
                        pdf_url = speech_doc.get("url")
                    yt_url = obj.get("video_link")
                _pdf, _yt = _scan_for_media(data)
                pdf_url = pdf_url or _pdf
                yt_url = yt_url or _yt
            except (json.JSONDecodeError, AttributeError):
                pass

        if not title:
            h = soup.find(["h1", "h2"])
            title = h.get_text(strip=True) if h else None
        if not date_raw:
            m = _DATE_RE.search(soup.get_text(" ", strip=True))
            if m:
                date_raw = f"{m.group(1)} {m.group(2)} {m.group(3)}"

        return SpeechMetadata(
            url=url,
            title=title,
            speaker=speaker,
            speech_date=_parse_date(date_raw),
            pdf_url=pdf_url,
            youtube_url=yt_url,
            language=None,  # detected after content extraction
        )

    # ------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_filters(
        entries: list[SpeechMetadata],
        cutoff: datetime | None,
        speaker: str | None,
    ) -> list[SpeechMetadata]:
        result = entries

        if cutoff is not None:
            result = [
                e for e in result if e.speech_date is None or e.speech_date >= cutoff
            ]

        if speaker is not None:
            kw = speaker.lower()
            result = [
                e
                for e in result
                if kw in (e.speaker or "").lower() or kw in (e.title or "").lower()
            ]

        return result
