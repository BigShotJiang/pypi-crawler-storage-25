import time

from fastapi import APIRouter, Depends

from pulse_engine.dependencies import get_processing_pipeline
from pulse_engine.middleware.tenant import get_tenant_id
from pulse_engine.processor.core.analysis import (
    classify_sentiment,
    extract_entities,
    extract_topics,
    summarize,
)
from pulse_engine.processor.core.chunking import chunk_content
from pulse_engine.processor.pipeline import ProcessingPipeline
from pulse_engine.processor.postprocessor.tasks import (
    run_postprocessing,
)
from pulse_engine.processor.preprocessor.tasks import (
    clean_html,
    detect_language,
    normalize_text,
    validate_content,
)
from pulse_engine.processor.schemas import (
    AnalyzeRequest,
    AnalyzeResponse,
    ChunkItem,
    ChunkRequest,
    ChunkResponse,
    PipelineRequest,
    PipelineResponse,
    PostprocessRequest,
    PostprocessResponse,
    PreprocessRequest,
    PreprocessResponse,
    ProcessingContext,
)

router = APIRouter(prefix="/process", tags=["Processor"])


@router.post("/pipeline", response_model=PipelineResponse)
async def run_pipeline(
    body: PipelineRequest,
    tenant_id: str = Depends(get_tenant_id),
    pipeline: ProcessingPipeline = Depends(get_processing_pipeline),
) -> PipelineResponse:
    start = time.monotonic()

    ctx = ProcessingContext(
        source_id=body.source_id,
        source_type=body.source_type,
        product=body.product,
        tenant_id=tenant_id,
        job_id=body.job_id,
        raw_content=body.content,
        options=body.options,
    )

    ctx = await pipeline.run(ctx)

    elapsed_ms = int((time.monotonic() - start) * 1000)

    doc_count = len(ctx.documents)
    chunk_count = len(ctx.chunks)
    total_chunks = chunk_count + (
        doc_count - chunk_count if doc_count != chunk_count else 0
    )
    stored = len(ctx.documents) if ctx.options.store_results else 0
    deduped = max(0, total_chunks - len(ctx.chunks))

    languages = [ctx.language] if ctx.language and ctx.language != "unknown" else []

    return PipelineResponse(
        source_id=ctx.source_id,
        chunks_produced=len(ctx.chunks),
        chunks_stored=stored,
        chunks_deduplicated=deduped,
        processing_time_ms=elapsed_ms,
        summary=ctx.summary,
        languages_detected=languages,
        entities_found=len(ctx.entities),
        stages_completed=ctx.stages_completed,
    )


@router.post("/preprocess", response_model=PreprocessResponse)
async def preprocess(
    body: PreprocessRequest,
    tenant_id: str = Depends(get_tenant_id),
) -> PreprocessResponse:
    cleaned = clean_html(body.content)
    cleaned = normalize_text(cleaned)
    lang = detect_language(cleaned) if validate_content(cleaned) else None
    is_valid = validate_content(cleaned)

    return PreprocessResponse(
        cleaned_content=cleaned,
        language=lang,
        is_valid=is_valid,
    )


@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze(
    body: AnalyzeRequest,
    tenant_id: str = Depends(get_tenant_id),
) -> AnalyzeResponse:
    chunks = chunk_content(
        text=body.content,
        source_id="analyze-temp",
        strategy=body.options.chunk_strategy,
        chunk_size=body.options.chunk_size,
        overlap=body.options.chunk_overlap,
    )

    for c in chunks:
        if body.options.enable_ner:
            c.entities = extract_entities(c.content)
        if body.options.enable_sentiment:
            c.sentiment = classify_sentiment(c.content)
        if body.options.enable_topics:
            c.topics = extract_topics(c.content)

    entities = extract_entities(body.content) if body.options.enable_ner else []
    sentiment = (
        classify_sentiment(body.content) if body.options.enable_sentiment else None
    )
    topics = extract_topics(body.content) if body.options.enable_topics else []
    summary_text = summarize(body.content)

    return AnalyzeResponse(
        chunks=chunks,
        entities=entities,
        sentiment=sentiment,
        topics=topics,
        summary=summary_text,
    )


@router.post("/postprocess", response_model=PostprocessResponse)
async def postprocess(
    body: PostprocessRequest,
    tenant_id: str = Depends(get_tenant_id),
) -> PostprocessResponse:
    ctx = ProcessingContext(
        source_id=body.source_id,
        source_type=body.source_type,
        product=body.product,
        tenant_id=body.tenant_id or tenant_id,
        raw_content=body.content,
        cleaned_content=body.content,
        chunks=body.chunks,
        options=body.options,
    )

    ctx = run_postprocessing(ctx)

    return PostprocessResponse(
        documents_created=len(ctx.documents),
        embeddings_generated=len(ctx.embeddings),
        quality_scores=ctx.quality_scores,
    )


@router.post("/chunk", response_model=ChunkResponse)
async def chunk(
    body: ChunkRequest,
    tenant_id: str = Depends(get_tenant_id),
) -> ChunkResponse:
    chunks = chunk_content(
        text=body.content,
        source_id="chunk-temp",
        strategy=body.strategy,
        chunk_size=body.chunk_size,
        overlap=body.overlap,
    )

    items = [
        ChunkItem(
            index=c.chunk_index,
            content=c.content,
            token_count=c.token_count,
        )
        for c in chunks
    ]

    return ChunkResponse(
        chunks=items,
        total_chunks=len(items),
        strategy=body.strategy,
    )
