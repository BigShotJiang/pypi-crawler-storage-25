"""Default preprocessor — wraps the existing run_preprocessing function."""

from __future__ import annotations

from pulse_engine.processor.base import BasePreprocessor
from pulse_engine.processor.preprocessor.tasks import run_preprocessing
from pulse_engine.processor.schemas import ProcessingContext


class DefaultPreprocessor(BasePreprocessor):
    def process(self, ctx: ProcessingContext) -> ProcessingContext:
        return run_preprocessing(ctx)
