"""Default postprocessor — wraps the existing run_postprocessing function."""

from __future__ import annotations

from pulse_engine.processor.base import BasePostprocessor
from pulse_engine.processor.postprocessor.tasks import run_postprocessing
from pulse_engine.processor.schemas import ProcessingContext


class DefaultPostprocessor(BasePostprocessor):
    def process(self, ctx: ProcessingContext) -> ProcessingContext:
        return run_postprocessing(ctx)
