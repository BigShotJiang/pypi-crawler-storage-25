"""Default core processor — wraps the existing run_core_processing function."""

from __future__ import annotations

from pulse_engine.processor.base import BaseCoreProcessor
from pulse_engine.processor.core.analysis import run_core_processing
from pulse_engine.processor.schemas import ProcessingContext


class DefaultCoreProcessor(BaseCoreProcessor):
    def process(self, ctx: ProcessingContext) -> ProcessingContext:
        return run_core_processing(ctx)
