from typing import Any

from pydantic import BaseModel, Field


class ProcessingOptions(BaseModel):
    chunk_strategy: str = "token_count"
    chunk_size: int = 512
    chunk_overlap: int = 50
    enable_ner: bool = True
    enable_sentiment: bool = True
    enable_topics: bool = True
    enable_embedding: bool = True
    enable_dedup: bool = True
    store_results: bool = True
    embedding_model: str = "text-embedding-3-small"
    embedding_provider: str | None = None  # None = use config default


class Entity(BaseModel):
    name: str
    type: str  # PERSON, ORGANIZATION, LOCATION, DATE, etc.
    start: int = 0
    end: int = 0


class ContentChunk(BaseModel):
    chunk_index: int
    content: str
    token_count: int
    parent_source_id: str
    entities: list[Entity] = Field(default_factory=list)
    sentiment: str | None = None
    topics: list[str] = Field(default_factory=list)


class ProcessingError(BaseModel):
    stage: str
    task: str
    message: str


class ProcessingContext(BaseModel):
    source_id: str
    source_type: str
    product: str
    tenant_id: str
    job_id: str | None = None
    raw_content: str
    cleaned_content: str | None = None
    language: str | None = None
    chunks: list[ContentChunk] = Field(default_factory=list)
    entities: list[Entity] = Field(default_factory=list)
    sentiment: str | None = None
    topics: list[str] = Field(default_factory=list)
    summary: str | None = None
    embeddings: list[list[float]] = Field(default_factory=list)
    quality_scores: list[float] = Field(default_factory=list)
    documents: list[Any] = Field(default_factory=list)  # Final Document objects
    options: ProcessingOptions = Field(default_factory=ProcessingOptions)
    stages_completed: list[str] = Field(default_factory=list)
    errors: list[ProcessingError] = Field(default_factory=list)


# API Request/Response schemas


class PipelineRequest(BaseModel):
    content: str
    source_id: str
    source_type: str = "text"
    product: str = ""
    job_id: str | None = None
    options: ProcessingOptions = Field(default_factory=ProcessingOptions)


class PipelineResponse(BaseModel):
    source_id: str
    chunks_produced: int
    chunks_stored: int
    chunks_deduplicated: int
    processing_time_ms: int
    summary: str | None = None
    languages_detected: list[str] = Field(default_factory=list)
    entities_found: int
    stages_completed: list[str] = Field(default_factory=list)


class ChunkRequest(BaseModel):
    content: str
    strategy: str = "token_count"
    chunk_size: int = 512
    overlap: int = 50


class ChunkItem(BaseModel):
    index: int
    content: str
    token_count: int


class ChunkResponse(BaseModel):
    chunks: list[ChunkItem]
    total_chunks: int
    strategy: str


class PreprocessRequest(BaseModel):
    content: str
    source_type: str = "text"


class PreprocessResponse(BaseModel):
    cleaned_content: str
    language: str | None = None
    is_valid: bool


class AnalyzeRequest(BaseModel):
    content: str
    options: ProcessingOptions = Field(default_factory=ProcessingOptions)


class AnalyzeResponse(BaseModel):
    chunks: list[ContentChunk]
    entities: list[Entity]
    sentiment: str | None = None
    topics: list[str]
    summary: str | None = None


class PostprocessRequest(BaseModel):
    content: str
    chunks: list[ContentChunk]
    source_id: str
    source_type: str = "text"
    product: str = ""
    tenant_id: str = ""
    options: ProcessingOptions = Field(default_factory=ProcessingOptions)


class PostprocessResponse(BaseModel):
    documents_created: int
    embeddings_generated: int
    quality_scores: list[float]


class TopicShift(BaseModel):
    index: int
    reason: str  # "Topic A to Topic B"


class TopicSplitResult(BaseModel):
    topic_shifts: list[TopicShift] = Field(default_factory=list)


class OCRInput(BaseModel):
    """Input for an OCR extraction request."""

    file_path: str | None = None
    file_bytes: bytes | None = None
    mime_type: str = "application/pdf"
    prompt: str = ""
    temperature: float = 0.1
    model: str = "gemini-2.5-flash"
    api_key: str = ""
    max_output_tokens: int = 65536
