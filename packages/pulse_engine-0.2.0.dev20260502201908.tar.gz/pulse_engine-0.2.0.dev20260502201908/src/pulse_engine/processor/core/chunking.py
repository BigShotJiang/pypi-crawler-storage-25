from __future__ import annotations

import re
from collections.abc import Callable

import tiktoken

from pulse_engine.processor.schemas import ContentChunk

_encoding: tiktoken.Encoding | None = None


def _get_encoding() -> tiktoken.Encoding:
    global _encoding
    if _encoding is None:
        _encoding = tiktoken.get_encoding("cl100k_base")
    return _encoding


def _count_tokens(text: str) -> int:
    return len(_get_encoding().encode(text))


def chunk_content(
    text: str,
    source_id: str,
    strategy: str = "token_count",
    chunk_size: int = 512,
    overlap: int = 50,
) -> list[ContentChunk]:
    """Dispatch to the appropriate chunking strategy."""
    if not text or not text.strip():
        return []

    def _token_chunker(t: str, sid: str) -> list[ContentChunk]:
        return _chunk_by_token_count(t, sid, chunk_size, overlap)

    def _sliding_chunker(t: str, sid: str) -> list[ContentChunk]:
        return _chunk_by_sliding_window(t, sid, chunk_size, overlap)

    strategies: dict[str, Callable[[str, str], list[ContentChunk]]] = {
        "paragraph": _chunk_by_paragraph,
        "token_count": _token_chunker,
        "sentence": _chunk_by_sentence,
        "sliding_window": _sliding_chunker,
    }

    chunker = strategies.get(strategy)
    if chunker is None:
        chunker = _token_chunker

    return chunker(text, source_id)


def _chunk_by_paragraph(
    text: str, source_id: str, chunk_size: int = 512
) -> list[ContentChunk]:
    """Split text on double newlines into paragraph-based chunks."""
    paragraphs = re.split(r"\n\n+", text.strip())
    paragraphs = [p.strip() for p in paragraphs if p.strip()]

    if not paragraphs:
        return []

    chunks: list[ContentChunk] = []
    for i, para in enumerate(paragraphs):
        chunks.append(
            ContentChunk(
                chunk_index=i,
                content=para,
                token_count=_count_tokens(para),
                parent_source_id=source_id,
            )
        )
    return chunks


def _chunk_by_token_count(
    text: str, source_id: str, chunk_size: int = 512, overlap: int = 50
) -> list[ContentChunk]:
    """Chunk by token count using tiktoken cl100k_base encoding."""
    tokens = _get_encoding().encode(text)
    if not tokens:
        return []

    chunks: list[ContentChunk] = []
    start = 0
    idx = 0

    while start < len(tokens):
        end = min(start + chunk_size, len(tokens))
        chunk_tokens = tokens[start:end]
        chunk_text = _get_encoding().decode(chunk_tokens)
        chunks.append(
            ContentChunk(
                chunk_index=idx,
                content=chunk_text,
                token_count=len(chunk_tokens),
                parent_source_id=source_id,
            )
        )
        idx += 1
        if end >= len(tokens):
            break
        # Ensure forward progress: overlap must be less than chunk_size
        effective_overlap = min(overlap, chunk_size - 1)
        start = end - effective_overlap

    return chunks


def _chunk_by_sentence(text: str, source_id: str) -> list[ContentChunk]:
    """Split text into sentence-level chunks."""
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]

    chunks: list[ContentChunk] = []
    for i, sentence in enumerate(sentences):
        chunks.append(
            ContentChunk(
                chunk_index=i,
                content=sentence,
                token_count=_count_tokens(sentence),
                parent_source_id=source_id,
            )
        )
    return chunks


def _chunk_by_sliding_window(
    text: str, source_id: str, chunk_size: int = 512, overlap: int = 50
) -> list[ContentChunk]:
    """Sliding window chunking with overlap (token-based)."""
    tokens = _get_encoding().encode(text)
    if not tokens:
        return []

    chunks: list[ContentChunk] = []
    step = max(chunk_size - overlap, 1)
    idx = 0

    for start in range(0, len(tokens), step):
        end = min(start + chunk_size, len(tokens))
        chunk_tokens = tokens[start:end]
        chunk_text = _get_encoding().decode(chunk_tokens)
        chunks.append(
            ContentChunk(
                chunk_index=idx,
                content=chunk_text,
                token_count=len(chunk_tokens),
                parent_source_id=source_id,
            )
        )
        idx += 1
        if end >= len(tokens):
            break

    return chunks
