from __future__ import annotations

import re

from pulse_engine.processor.core.chunking import chunk_content
from pulse_engine.processor.schemas import (
    Entity,
    ProcessingContext,
    ProcessingError,
)

# Simple stop words for topic extraction
_STOP_WORDS = frozenset(
    "the a an and or but in on at to for of is it this that with from by as are was "
    "were be been being have has had do does did will would could should may might can "
    "shall not no nor so if then than too very just about also more other some such "
    "only over after before between through during each every all both few most own "
    "same any many much how what which who whom when where why again further once here "
    "there their them they he she his her its our your we you i me my".split()
)

_POSITIVE_WORDS = frozenset(
    "good great excellent amazing wonderful fantastic positive happy love beautiful "
    "best brilliant superb outstanding perfect delightful pleasant remarkable "
    "awesome terrific marvelous fabulous incredible impressive magnificent".split()
)

_NEGATIVE_WORDS = frozenset(
    "bad terrible awful horrible negative sad hate ugly worst poor pathetic "
    "dreadful disappointing unpleasant atrocious abysmal horrendous disgusting "
    "miserable wretched appalling lousy inferior".split()
)


def extract_entities(text: str) -> list[Entity]:
    """Extract entities using regex patterns: capitalized multi-word names, dates."""
    entities: list[Entity] = []
    seen: set[str] = set()

    # Find capitalized multi-word sequences (2+ words starting with uppercase)
    for m in re.finditer(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", text):
        name = m.group(1)
        if name not in seen:
            seen.add(name)
            entities.append(
                Entity(name=name, type="PERSON", start=m.start(), end=m.end())
            )

    # Find dates in YYYY-MM-DD format
    for m in re.finditer(r"\b(\d{4}-\d{2}-\d{2})\b", text):
        date_str = m.group(1)
        if date_str not in seen:
            seen.add(date_str)
            entities.append(
                Entity(name=date_str, type="DATE", start=m.start(), end=m.end())
            )

    return entities


def classify_sentiment(text: str) -> str:
    """Classify sentiment using keyword matching: positive/negative/neutral."""
    words = set(re.findall(r"\b[a-z]+\b", text.lower()))
    pos_count = len(words & _POSITIVE_WORDS)
    neg_count = len(words & _NEGATIVE_WORDS)

    if pos_count > neg_count:
        return "positive"
    elif neg_count > pos_count:
        return "negative"
    return "neutral"


def extract_topics(text: str, max_topics: int = 5) -> list[str]:
    """Extract topics based on most frequent significant words."""
    words = re.findall(r"\b[a-z]{3,}\b", text.lower())
    filtered = [w for w in words if w not in _STOP_WORDS]

    freq: dict[str, int] = {}
    for w in filtered:
        freq[w] = freq.get(w, 0) + 1

    sorted_words = sorted(freq, key=freq.__getitem__, reverse=True)
    return sorted_words[:max_topics]


def summarize(text: str, max_sentences: int = 3) -> str:
    """Extractive summarization: return the first N sentences."""
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    selected = sentences[:max_sentences]
    return " ".join(selected) if selected else text


def run_core_processing(ctx: ProcessingContext) -> ProcessingContext:
    """Run chunking and analysis on the processing context."""
    try:
        content = ctx.cleaned_content or ctx.raw_content

        # Chunking
        ctx.chunks = chunk_content(
            text=content,
            source_id=ctx.source_id,
            strategy=ctx.options.chunk_strategy,
            chunk_size=ctx.options.chunk_size,
            overlap=ctx.options.chunk_overlap,
        )

        # Analyze each chunk
        all_entities: list[Entity] = []
        for chunk in ctx.chunks:
            if ctx.options.enable_ner:
                chunk.entities = extract_entities(chunk.content)
                all_entities.extend(chunk.entities)

            if ctx.options.enable_sentiment:
                chunk.sentiment = classify_sentiment(chunk.content)

            if ctx.options.enable_topics:
                chunk.topics = extract_topics(chunk.content)

        # Global analysis on full content
        if ctx.options.enable_ner:
            ctx.entities = extract_entities(content)
            # Merge with chunk-level entities (deduplicated)
            seen = {e.name for e in ctx.entities}
            for e in all_entities:
                if e.name not in seen:
                    seen.add(e.name)
                    ctx.entities.append(e)

        if ctx.options.enable_sentiment:
            ctx.sentiment = classify_sentiment(content)

        if ctx.options.enable_topics:
            ctx.topics = extract_topics(content)

        ctx.summary = summarize(content)

        ctx.stages_completed.append("core_processing")
    except Exception as e:
        ctx.errors.append(
            ProcessingError(
                stage="core_processing", task="run_core_processing", message=str(e)
            )
        )

    return ctx
