from __future__ import annotations

import re

from langchain_core.prompts import ChatPromptTemplate

from pulse_engine.processor.core.prompts import (
    TRANSCRIPT_SPLITTER_EXAMPLES,
    TRANSCRIPT_SPLITTER_PROMPT,
)
from pulse_engine.processor.llm.provider import get_llm
from pulse_engine.processor.schemas import TopicSplitResult


class TopicSplitter:
    """LLM-backed topic splitter that detects topic shift points.

    Accepts either a plain string (split into paragraphs) or a list of
    ``(index, text)`` tuples.  Returns a :class:`TopicSplitResult` with
    the detected shift indexes and reasons.
    """

    def __init__(
        self,
        provider: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
        temperature: float | None = None,
        interaction_title: str = "",
        account: str = "",
        client: str = "",
        account_attendees: str = "",
        client_attendees: str = "",
    ) -> None:
        self._provider = provider
        self._model = model
        self._api_key = api_key
        self._temperature = temperature
        self.interaction_title = interaction_title
        self.account = account
        self.client = client
        self.account_attendees = account_attendees
        self.client_attendees = client_attendees

    def split(self, content: str | list[tuple[int, str]]) -> TopicSplitResult:
        """Detect topic shifts in *content*.

        Parameters
        ----------
        content:
            Either a plain string (paragraphs separated by blank lines)
            or a list of ``(index, text)`` tuples.

        Returns
        -------
        TopicSplitResult
            Detected topic shifts with indexes and reasons.
        """
        tuples = self._normalize_input(content)
        if len(tuples) <= 1:
            return TopicSplitResult()
        return self._call_llm(tuples)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_input(
        content: str | list[tuple[int, str]],
    ) -> list[tuple[int, str]]:
        if isinstance(content, list):
            return content
        paragraphs = re.split(r"\n\n+", content.strip())
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        return [(i + 1, p) for i, p in enumerate(paragraphs)]

    def _call_llm(self, tuples: list[tuple[int, str]]) -> TopicSplitResult:
        llm = get_llm(
            provider=self._provider,
            model=self._model,
            api_key=self._api_key,
            temperature=self._temperature,
        )

        prompt = ChatPromptTemplate.from_template(TRANSCRIPT_SPLITTER_PROMPT)
        structured_llm = llm.with_structured_output(TopicSplitResult)
        chain = prompt | structured_llm

        transcript_str = "\n".join(f'({idx}, "{text}")' for idx, text in tuples)
        max_idx = max(idx for idx, _ in tuples)

        result: TopicSplitResult = chain.invoke(
            {
                "examples": TRANSCRIPT_SPLITTER_EXAMPLES,
                "transcript": transcript_str,
                "max_idx": max_idx,
                "interaction_title": self.interaction_title,
                "account": self.account,
                "client": self.client,
                "account_attendees": self.account_attendees,
                "client_attendees": self.client_attendees,
            }
        )
        return result
