# ruff: noqa: E501
TRANSCRIPT_SPLITTER_EXAMPLES = """**Example 1:**
transcript:
[
  (1, "Emily, 2025-01-20T13:59:50Z => Hi Robert, hope you're doing well today."),
  (2, "Robert, 2025-01-20T13:59:55Z => Hi Emily, I'm doing great, thanks! How about you?"),
  (3, "Emily, 2025-01-20T14:00:01Z => I'm good, thanks. Our January performance data shows improved CPCs and stable ROAS."),
  (4, "Robert, 2025-01-20T14:00:05Z => The generator campaign delivered a 20% increase in impressions."),
  (5, "Emily, 2025-01-20T14:00:11Z => Should we allocate more budget to capitalize on this trend?"),
  (6, "Robert, 2025-01-20T14:00:15Z => Yes, I'll add a new generator SKU to our campaign."),
  (7, "Emily, 2025-01-20T14:00:21Z => Inventory levels are robust, so extra budget makes sense."),
  (8, "Robert, 2025-01-20T14:00:25Z => I'll update our bid strategy and reallocate funds from underperforming items."),
  (9, "Emily, 2025-01-20T14:00:31Z => Let's closely monitor the updated CPC and ROAS."),
  (10, "Robert, 2025-01-20T14:00:35Z => I'll track performance and adjust bids as needed."),
  (11, "Emily, 2025-01-20T14:00:41Z => Great, we'll reconvene next week to review the impact."),
  (12, "Robert, 2025-01-20T14:00:45Z => Agreed. I'll send over the updated campaign metrics.")
]


output :
```json
{{{{
  "topic_shifts" : [
    {{{{
      "index": 3,
      "reason": "Shift from introductory greetings to discussing performance metrics."
    }}}},
    {{{{
      "index": 5,
      "reason": "Shift from discussing performance metrics and campaign results to budget allocation and campaign modifications."
    }}}},
    {{{{
      "index": 11,
      "reason": "Transition from budget discussion to scheduling a follow-up review call."
    }}}}
  ]
}}}}
```

**Example 2:**
transcript:
[
  (1, "Alex, 2025-02-10T10:59:50Z => so that"),
  (2, "Alex, 2025-02-10T10:59:50Z => Hey Taylor, how's your morning going?"),
  (3, "Taylor, 2025-02-10T10:59:55Z => Busy but good, Alex! Ready to dive in."),
  (4, "Alex, 2025-02-10T11:00:02Z => Perfect. Let's review our current campaign strategy and segmentation."),
  (5, "Taylor, 2025-02-10T11:00:05Z => I've noticed several ad groups are underperforming."),
  (6, "Alex, 2025-02-10T11:00:10Z => The sponsored video campaign isn't engaging our audience well."),
  (7, "Taylor, 2025-02-10T11:00:13Z => I propose testing alternative creatives for the SV ads."),
  (8, "Alex, 2025-02-10T11:00:18Z => We should reallocate the budget from low performers to our top sellers."),
  (9, "Taylor, 2025-02-10T11:00:21Z => I'm setting up A/B tests for the new SV creative approaches."),
  (10, "Alex, 2025-02-10T11:00:26Z => When can we expect preliminary results?"),
  (11, "Taylor, 2025-02-10T11:00:29Z => Initial data should be ready within three days."),
  (12, "Alex, 2025-02-10T11:00:34Z => Let's schedule a review call after the tests are complete."),
  (13, "Taylor, 2025-02-10T11:00:37Z => Agreed. I'll coordinate the meeting and share test outcomes.")
]


output :
```json
{{{{
  "topic_shifts" : [
      {{{{
        "index": 4,
        "reason": "Shift from greetings to discussing campaign strategy and segmentation."
      }}}},
      {{{{
        "index": 8,
        "reason": "Shift from discussing campaign strategy and creative testing to budget reallocation for top sellers."
      }}}},
      {{{{
        "index": 10,
        "reason": "Transition from budget reallocation to discussing test timelines and scheduling a review call."
      }}}}
    ]
}}}}
```
"""

TRANSCRIPT_SPLITTER_PROMPT = """**Role:** Assume you are an expert meeting transcript summarizer specialized in identifying topic switches happening in the transcript.

**Inputs:**
 **transcript:** A sequence of strings in the following format: Index number followed by speaker name followed by a label to indicate which business entity they belong to (for ex: account or client or guest or name of a company)[Account/client/guest - buisness entity]. This will then be followed by a start and end time stamp and finally the utterance by the speaker. You will be provided with these strings for a full meeting discussion.
* **Transcript Format:** `Speaker Name [Label - Entity], StartTime, EndTime => Utterance`
**Interaction details: The interaction {interaction_title} is between  business entity {account} and business entity {client}. The attendees from the account side are {account_attendees} and the attendees from the client/prospect/vendor/partner side are {client_attendees}.
**Note -  that the entities involved in the conversation should not be interchanged while generating the topics.

**Task:** Your task is twofold:
  1.  First, generate clear, concise topics from the provided meeting transcript. Each topic should capture one distinct discussion agendas.
  2. Then, analyze the transcript to determine the exact indexes where there is a shift between the identified topics.

**Instructions to generate distinct discussion agendas**:
  1. Read the transcript in chronological order.
  2. Maintain a running understanding of the CURRENT TOPIC.
  3. For each new utterance:
    - Decide whether it CONTINUES the current topic, or
    - INTRODUCES A NEW TOPIC.
  4. A new topic should ONLY be created if the discussion theme clearly changes.
  5. Do NOT create a new topic for:
    - Short acknowledgements or confirmations
    - Examples or clarifications within the same discussion
    - Repetition or rephrasing of the same idea
  6. All the distinct discussion agendas must be captured.

**Examples:**
{examples}

**Guidelines:**
1. **Topic Generation:**
    - Extract clear and concise topics that capture generic, high-level themes from the transcript.
    - Avoid overly specific keypoints; instead, group related details into broad discussion topics within the context.
    - Each topic item should capture the essence of the discussion.

2. **Topic Shift Identification:**
    - Identify the transcript indexes where the discussion shifts from one agenda to another.
    - Use the exact `index` numbers from the input transcript tuples.
    - The `index` value should not be more than the maximum value of index from input tuple which is {max_idx}.
    - Each identified shift should be explained briefly in the "reason" field.

**Transcript:**
{transcript}
"""


TOPIC_GENERATOR_EXAMPLES = """Examples :
Example 1 :
transcript: ```
Alice (Sales Lead): Good morning everyone, I'm Alice from Acme Corp—thanks for joining.
Bob (CFO, Beta Inc): Hi Alice—Bob here. Also with me is Carol, our AR manager.
Carol (AR Manager): Morning! We handle all our invoicing and collections in-house right now.
Alice: Got it. To kick off, what are your biggest pain points with that process today?
Bob: It's entirely manual—spreadsheets, email threads, no visibility. We miss follow-ups and collections lag by 15+ days.
Carol: And we don't have a unified dashboard, so leadership can't track daily cash inflows.
Alice: Understood. Our solution automates invoice generation, sends smart reminders, and offers real-time cash-flow dashboards.
Alice: Does that address the issues you just described?
Bob: Absolutely—that's exactly what we need.
Alice: Great. Would you be open to a tailored demo next Wednesday at 10 AM?
Bob: That works. Please send an invite.  ```
Interaction_type: Sales_Discovery_Call
Playbook : ```Introductions - who is present in the Interaction
Probing for pain point in the prospect
Providing a quick overview of the Product and Capabilities
Confirming the pain point experienced by the prospect
Gauging the interest in moving to the next step
Setting Clear Next Steps with Dates```

output : [
    "Introductions and Attendees",
    "Pain Points: Manual invoicing, email-based follow-ups, lack of visibility",
    "Solution Overview: Invoice automation, smart reminders, dashboards",
    "Solution Fit Validation",
    "Next-Step Commitment"
  ]

Example 2 :
transcript: ```
Chris: Good morning team—let's run through our sprint items.
Dana: Yesterday I finished the homepage redesign and updated the style guide.
Eli: API integration is 80% complete; I need specs for the new endpoint.
Fran: QA passed the login workflow, but there's a minor bug on password reset.
Chris: Noted. Any blockers?
Dana: Waiting on final copy from content.
Eli: No blockers on my end.
Fran: I need test user credentials from IT.
Chris: Deal—I'll follow up after this call.
 ```
Interaction_type: Sales_Discovery_Call
Playbook : ```Introductions - who is present in the Interaction
Probing for pain point in the prospect
Providing a quick overview of the Product and Capabilities
Confirming the pain point experienced by the prospect
Gauging the interest in moving to the next step
Setting Clear Next Steps with Dates```

output : [
  "Sprint Progress & Outcomes",
  "Risks, Blockers & Dependencies",
  "Follow-Up Actions"
  ]
"""

TOPIC_GENERATOR_PROMPT = """**Role:**
You are an expert language model specialized in extracting and summarizing clear, concise discussion topics from meeting transcripts.

**Inputs:**

* **Transcript:** A sequence of strings in this format: There will be a speaker name followed by a label to indicate which business entity they belong to (for ex: account or client or guest or name of a company)[Account/client/guest - buisness entity]. This will then be followed by a start and end time stamp and finally the utterance by the speaker. You will be provided with these strings for a full meeting discussion.
* **Transcript Format:** `Speaker Name [Label - Entity], StartTime, EndTime => Utterance`
* **Interaction Type:**
  Examples include:

  * Sales: `Introductory_Discovery_Call`, `Demo_Call`, `Follow_Up_Call`, `Finalization_Close_Call`
  * Services: `Recurring_Update`, `performance_update_call`, `Problem_Resolution_Call`, `Implementation_Call`
  * Generic: `generic`

* **Playbook:** A predefined list of agenda topics related to the specified interaction type.

**Interaction details: The interaction {{interaction_title}} is between  business entity account: {{account}} and business entity
client/prospect/vendor/partner :{{client}}. The attendees from the account side are {{account_attendees}} and the attendees from the
client/prospect/vendor/partner side are {{client_attendees}}.
**Note -  that the entities involved in the conversation should not be interchanged while generating the topics.

**Task:**
**Instructions to generate distinct discussion agendas**:
  1. Read the complete transcript in chronological order.
  2. You are given the business entities involved in the discussion so identify and maintain the entities involved in the conversation. While generating the topics do not interchange the business entities involved in the conversation
  3. Determine the interaction type on the basis of agendas discussed in the conversation.
  4. Now Generate the topics on the basis of interaction type that best summarize the distinct discussion agendas from the transcript.
  5. while generating the topics do not interchange the entities involved in the conversation

* Identify and clearly extract a concise list of distinct topics discussed in the provided transcript.
* Topics may or may not match exactly with items listed in the provided playbook; both scenarios are acceptable.

Examples : {{examples}}


**Guidelines:**

* Each topic should summarize a distinct, meaningful segment of the discussion.
***Limit the total number of topics to 3-8.**
***Merge overlapping or closely related points into single high-level topics.**
* Avoid overly specific details or fragmented items; group related details into broader, logical topics.
"""


TOPIC_AND_EXCERPT_MAPPER_PROMPT = """**Role:**
You are an expert classification model specialized in mapping excerpts from meeting transcripts to predefined discussion topics.

**Inputs:**

* **Excerpt:** A single text excerpt from a meeting transcript which is a discussion topic from the meeting and each line of the excerpt will be a speaker name followed by a label to indicate which business entity they belong to (for ex: account or client or guest or name of a company)[Account/client/guest - buisness entity]. This will then be followed by a start and end time stamp and finally the utterance by the speaker.
* **Excerpt Format:** `Speaker Name [Label - Entity], StartTime, EndTime => Utterance`
* **Topics:** A predefined list of topics.

**Interaction details: The interaction {{interaction_title}} is between  business entity {{account}} and business entity {{client}}. The attendees from the account side are {{account_attendees}} and the attendees from the client/prospect/vendor/partner side are {{client_attendees}}.
**Note -  that the entities involved in the conversation should not be interchanged while mapping the excerpt to topics.

**Task:**
* Read the excerpt carefully and identify its primary intent.
* Select the single topic that best and most completely represents the intent of the excerpt.
* Classify the excerpt strictly based on the central theme of its content.
* Ensure the excerpt aligns clearly and fully with the thematic focus of exactly one of the provided topics.
* Only assign multiple topics if the excerpt explicitly and unquestionably addresses more than one distinct theme.
* If the excerpt's central theme does not match clearly and confidently to any of the provided topics, return an empty array (`[]`).

**Guidelines:**

* Prioritize thematic alignment over keyword matching.
* Assign topics only when the thematic relevance is absolutely certain.
* If there's any ambiguity or doubt regarding thematic alignment, omit the topic.

**Output Format (JSON):**

{{{{
  "mapped_topics": ["<Topic_1>", "<Topic_2>", "..."] // empty array [] if no confident thematic mapping found
}}}}
"""


EXCERPT_SPLITTER_EXAMPLES = """**Example 1:**
Topics: ["Greetings", "Performance Review", "Budget Allocation"]
Excerpt:
[
  (1, "Hi Robert, hope you're doing well today."),
  (2, "Hi Emily, I'm doing great, thanks! How about you?"),
  (3, "Our January performance data shows improved CPCs and stable ROAS."),
  (4, "The generator campaign delivered a 20% increase in impressions."),
  (5, "Should we allocate more budget to capitalize on this trend?"),
  (6, "Yes, I'll add a new generator SKU to our campaign."),
  (7, "Inventory levels are robust, so extra budget makes sense."),
  (8, "I'll update our bid strategy and reallocate funds from underperforming items."),
  (9, "Let's closely monitor the updated CPC and ROAS."),
  (10,"I'll track performance and adjust bids as needed."),
  (11,"Great, we'll reconvene next week to review the impact."),
  (12,"Agreed. I'll send over the updated campaign metrics.")
]


output :
```json
{{
  "segments": [
    {{ "start_index": 1,  "end_index": 2,  "topic": "Greetings" }},
    {{ "start_index": 3,  "end_index": 4,  "topic": "Performance Review" }},
    {{ "start_index": 5,  "end_index": 12, "topic": "Budget Allocation" }}
  ]
}}
```

**Example 2:**
Topics: ["Project Kickoff", "Technical Issue", "Next Steps"]
Excerpt:
[
  (1, "Let's review the project scope and deliverables."),
  (2, "We need API integration with the payment gateway."),
  (3, "Our dev server is down, error 502."),
  (4, "Engineers are already investigating the 502 gateway timeout."),
  (5, "Once it's back up, we'll resume the integration tests."),
  (6, "Agreed—then we can draft the rollout plan."),
  (7, "I'll schedule the next status call for Monday.")
]

output :
```json
{{
  "segments": [
    {{ "start_index": 1, "end_index": 2, "topic": "Project Kickoff" }},
    {{ "start_index": 3, "end_index": 5, "topic": "Technical Issue" }},
    {{ "start_index": 6, "end_index": 7, "topic": "Next Steps" }}
  ]
}}
```
"""


EXCERPT_SPLITTER_PROMPT = """You are an `expert` meeting-transcript summarizer specialized in slicing a transcript into contiguous topic segments.

**Inputs:**
* **excerpt:** A list of (index: int, text: str) tuples  a focused segment of the meeting  which contains a speaker name followed by a label to indicate which business entity they belong to (for ex: account or client or guest or name of a company)[Account/client/guest - buisness entity]. This will then be followed by a start and end time stamp and finally the utterance by the speaker.
* Excerpt Format: `Speaker Name [Label - Entity], StartTime, EndTime => Utterance`
* **topics:**  A list of strings which contains topics identified in that meeting conversation.

**Interaction details: The interaction {{interaction_title}} is between  business entity {{account}} and business entity {{client}}. The attendees from the account side are {{account_attendees}} and the attendees from the client/prospect/vendor/partner side are {{client_attendees}}.
**Note -  that the entities involved in the conversation should not be interchanged while segmenting the excerpt into topics.

**Task:**
Partition `excerpt` into contiguous segments such that each segment corresponds to one of the provided topics.
For each segment, return `start_index`, `end_index`, and the `topic` being discussed.

**Guidelines:**

* A segment begins when discussion clearly shifts into one of the topics and ends just before it shifts to another.
* If a message doesn't map to any topic, it should be grouped with the previous segment.
* Do not overlap segments; cover the transcript in order.
* Use the largest possible spans under a single topic before splitting.
* Never Make up any information.
* Do not repeat topics.

Examples : {{examples}}
"""
