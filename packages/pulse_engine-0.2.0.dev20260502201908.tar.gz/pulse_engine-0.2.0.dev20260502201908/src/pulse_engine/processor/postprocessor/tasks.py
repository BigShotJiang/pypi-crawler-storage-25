from __future__ import annotations

import math
from typing import Any

from pulse_engine.processor.postprocessor.embeddings import generate_embedding
from pulse_engine.processor.schemas import (
    ContentChunk,
    ProcessingContext,
    ProcessingError,
)
from pulse_engine.storage.schemas import Document, DocumentSource


def format_for_storage(ctx: ProcessingContext) -> list[Document]:
    """Convert processing context chunks into Document objects for storage."""
    # Map source types to DocumentSource enum
    source_map: dict[str, DocumentSource] = {
        "speech": DocumentSource.speech,
        "tweet": DocumentSource.tweet,
        "youtube": DocumentSource.youtube,
        "processed": DocumentSource.processed,
    }
    doc_source = source_map.get(ctx.source_type, DocumentSource.processed)

    documents: list[Document] = []
    for i, chunk in enumerate(ctx.chunks):
        metadata: dict[str, Any] = {
            "source_type": ctx.source_type,
            "product": ctx.product,
            "tenant_id": ctx.tenant_id,
            "language": ctx.language,
        }

        metadata_chunk: dict[str, Any] = {
            "chunk_index": chunk.chunk_index,
            "token_count": chunk.token_count,
            "sentiment": chunk.sentiment,
            "topics": chunk.topics,
            "entities": [e.model_dump() for e in chunk.entities],
        }

        # Get embeddings if available
        content_embedding = ctx.embeddings[i] if i < len(ctx.embeddings) else None

        doc = Document(
            doc_id=ctx.source_id,
            source=doc_source,
            chunk_id=str(chunk.chunk_index),
            content=chunk.content,
            metadata=metadata,
            metadata_chunk=metadata_chunk,
            content_summary=ctx.summary,
            content_title=None,
            embedding=content_embedding,
            content_embeddings=content_embedding,
            content_summary_embeddings=None,
            content_title_embeddings=None,
        )
        documents.append(doc)

    return documents


def compute_quality_score(chunk: ContentChunk) -> float:
    """Compute a heuristic quality score for a chunk (0.0 - 1.0)."""
    score = 0.0

    # Content length factor (0 - 0.4)
    length = len(chunk.content)
    if length >= 100:
        score += 0.4
    elif length >= 50:
        score += 0.3
    elif length >= 20:
        score += 0.2
    else:
        score += 0.1

    # Entity count factor (0 - 0.2)
    entity_count = len(chunk.entities)
    score += min(entity_count * 0.05, 0.2)

    # Topic count factor (0 - 0.2)
    topic_count = len(chunk.topics)
    score += min(topic_count * 0.04, 0.2)

    # Token count factor (0 - 0.2) — prefer chunks with reasonable token counts
    if 50 <= chunk.token_count <= 512:
        score += 0.2
    elif chunk.token_count > 0:
        score += 0.1

    return min(score, 1.0)


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def deduplicate(embeddings: list[list[float]], threshold: float = 0.95) -> list[bool]:
    """
    Check for duplicate embeddings using cosine similarity.
    Returns list of bools: True = keep, False = duplicate.
    """
    if not embeddings:
        return []

    n = len(embeddings)
    keep = [True] * n

    if n <= 1:
        return keep

    for i in range(n):
        if not keep[i]:
            continue
        for j in range(i + 1, n):
            if not keep[j]:
                continue
            if _cosine_similarity(embeddings[i], embeddings[j]) >= threshold:
                keep[j] = False

    return keep


def run_postprocessing(ctx: ProcessingContext) -> ProcessingContext:
    """Run all postprocessing tasks on the context."""
    try:
        # Generate embeddings
        if ctx.options.enable_embedding:
            for chunk in ctx.chunks:
                emb = generate_embedding(
                    chunk.content,
                    ctx.options.embedding_model,
                    provider=ctx.options.embedding_provider,
                )
                ctx.embeddings.append(emb)

        # Compute quality scores
        for chunk in ctx.chunks:
            score = compute_quality_score(chunk)
            ctx.quality_scores.append(score)

        # Deduplication
        if ctx.options.enable_dedup and ctx.embeddings:
            keep_flags = deduplicate(ctx.embeddings)
            # Filter out duplicates
            new_chunks = []
            new_embeddings = []
            new_scores = []
            for i, keep in enumerate(keep_flags):
                if keep:
                    new_chunks.append(ctx.chunks[i])
                    if i < len(ctx.embeddings):
                        new_embeddings.append(ctx.embeddings[i])
                    if i < len(ctx.quality_scores):
                        new_scores.append(ctx.quality_scores[i])
            ctx.chunks = new_chunks
            ctx.embeddings = new_embeddings
            ctx.quality_scores = new_scores

        # Format for storage
        ctx.documents = format_for_storage(ctx)

        ctx.stages_completed.append("postprocessing")
    except Exception as e:
        ctx.errors.append(
            ProcessingError(
                stage="postprocessing", task="run_postprocessing", message=str(e)
            )
        )

    return ctx
