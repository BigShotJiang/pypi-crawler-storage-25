from __future__ import annotations

from typing import Any

from pulse_engine.config import get_settings


def generate_embedding(
    text: str,
    model_name: str = "text-embedding-3-small",
    provider: str | None = None,
) -> list[float]:
    """Generate embedding for *text* using OpenAI.

    Parameters
    ----------
    text:
        The text to embed.
    model_name:
        Ignored (kept for backward compatibility). Model is read from settings.
    provider:
        Ignored (kept for backward compatibility). Always uses OpenAI.
    """
    settings = get_settings()
    return _openai_embedding(text, settings)


def _openai_embedding(text: str, settings: Any) -> list[float]:
    from langchain_openai import OpenAIEmbeddings

    api_key = settings.pulse_openai_api_key or settings.pulse_llm_api_key
    model = settings.pulse_openai_embedding_model
    embedder = OpenAIEmbeddings(model=model, api_key=api_key)
    return list(embedder.embed_query(text))
