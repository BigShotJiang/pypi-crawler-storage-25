from __future__ import annotations

import re
import unicodedata

from bs4 import BeautifulSoup
from langdetect import detect
from langdetect.lang_detect_exception import LangDetectException

from pulse_engine.processor.schemas import ProcessingContext, ProcessingError


def clean_html(text: str) -> str:
    """Strip HTML tags, decode entities, and normalize whitespace."""
    soup = BeautifulSoup(text, "html.parser")
    cleaned = str(soup.get_text(separator=" "))
    # Normalize whitespace
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def normalize_text(text: str) -> str:
    """Apply Unicode NFC normalization and strip control characters."""
    text = unicodedata.normalize("NFC", text)
    # Remove control characters except newlines and tabs
    text = "".join(
        ch
        for ch in text
        if not unicodedata.category(ch).startswith("C") or ch in "\n\t"
    )
    return text


def detect_language(text: str) -> str:
    """Detect language using langdetect, return ISO 639-1 code."""
    try:
        return str(detect(text))
    except LangDetectException:
        return "unknown"


def validate_content(text: str, min_length: int = 10) -> bool:
    """Reject empty or too-short content."""
    if not text or not text.strip():
        return False
    return len(text.strip()) >= min_length


def run_preprocessing(ctx: ProcessingContext) -> ProcessingContext:
    """Run all preprocessing tasks in sequence on the context."""
    try:
        cleaned = clean_html(ctx.raw_content)
        cleaned = normalize_text(cleaned)
        ctx.cleaned_content = cleaned

        if validate_content(cleaned):
            ctx.language = detect_language(cleaned)
        else:
            ctx.language = "unknown"

        ctx.stages_completed.append("preprocessing")
    except Exception as e:
        ctx.errors.append(
            ProcessingError(
                stage="preprocessing",
                task="run_preprocessing",
                message=str(e),
            )
        )

    return ctx
