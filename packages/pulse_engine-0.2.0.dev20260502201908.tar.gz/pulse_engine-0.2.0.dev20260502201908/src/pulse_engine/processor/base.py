"""Base ABCs for the three-stage processing pipeline."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pulse_engine.processor.schemas import OCRInput, ProcessingContext


class BasePreprocessor(ABC):
    """Preprocessing stage: cleaning, normalisation, language detection."""

    @abstractmethod
    def process(self, ctx: ProcessingContext) -> ProcessingContext: ...


class BaseCoreProcessor(ABC):
    """Core processing stage: chunking, NER, sentiment, topics, summarisation."""

    @abstractmethod
    def process(self, ctx: ProcessingContext) -> ProcessingContext: ...


class BasePostprocessor(ABC):
    """Post-processing stage: embeddings, quality scoring, dedup, storage formatting."""

    @abstractmethod
    def process(self, ctx: ProcessingContext) -> ProcessingContext: ...


class BaseOCRProvider(ABC):
    """Base class that all OCR providers must implement."""

    @abstractmethod
    def extract(self, ocr_input: OCRInput) -> Any: ...
