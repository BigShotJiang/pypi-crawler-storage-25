"""Processing pipeline — orchestrates pre-processing, core, and post-processing.

Stages are pluggable via the base ABCs.  Pass ``None`` to skip a stage,
or omit (use the sentinel default) to get the engine's built-in implementation.
"""

from __future__ import annotations

from typing import Any

import structlog

from pulse_engine.processor.base import (
    BaseCoreProcessor,
    BasePostprocessor,
    BasePreprocessor,
)
from pulse_engine.processor.schemas import ProcessingContext, ProcessingError
from pulse_engine.storage.knowledge_base import KnowledgeBaseService

logger = structlog.get_logger()

_SENTINEL: Any = object()


class ProcessingPipeline:
    def __init__(
        self,
        kb_service: KnowledgeBaseService | None = None,
        preprocessor: BasePreprocessor | None = _SENTINEL,
        core_processor: BaseCoreProcessor | None = _SENTINEL,
        postprocessor: BasePostprocessor | None = _SENTINEL,
    ) -> None:
        from pulse_engine.processor.defaults import (
            DefaultCoreProcessor,
            DefaultPostprocessor,
            DefaultPreprocessor,
        )

        self._kb_service = kb_service
        self._preprocessor = (
            DefaultPreprocessor() if preprocessor is _SENTINEL else preprocessor
        )
        self._core_processor = (
            DefaultCoreProcessor() if core_processor is _SENTINEL else core_processor
        )
        self._postprocessor = (
            DefaultPostprocessor() if postprocessor is _SENTINEL else postprocessor
        )

    async def run(self, ctx: ProcessingContext) -> ProcessingContext:
        """Run the full 3-stage pipeline."""
        ctx = await self.run_preprocess(ctx)
        ctx = await self.run_core(ctx)
        ctx = await self.run_postprocess(ctx)

        if ctx.options.store_results and self._kb_service and ctx.documents:
            try:
                await self._kb_service.store_documents(ctx.tenant_id, ctx.documents)
            except Exception as e:
                logger.warning("storage_failed", error=str(e))
                ctx.errors.append(
                    ProcessingError(
                        stage="storage", task="store_documents", message=str(e)
                    )
                )

        return ctx

    async def run_preprocess(self, ctx: ProcessingContext) -> ProcessingContext:
        if self._preprocessor is None:
            return ctx
        try:
            ctx = self._preprocessor.process(ctx)
        except Exception as e:
            ctx.errors.append(
                ProcessingError(
                    stage="preprocessing", task="run_preprocess", message=str(e)
                )
            )
        return ctx

    async def run_core(self, ctx: ProcessingContext) -> ProcessingContext:
        if self._core_processor is None:
            return ctx
        try:
            ctx = self._core_processor.process(ctx)
        except Exception as e:
            ctx.errors.append(
                ProcessingError(
                    stage="core_processing", task="run_core", message=str(e)
                )
            )
        return ctx

    async def run_postprocess(self, ctx: ProcessingContext) -> ProcessingContext:
        if self._postprocessor is None:
            return ctx
        try:
            ctx = self._postprocessor.process(ctx)
        except Exception as e:
            ctx.errors.append(
                ProcessingError(
                    stage="postprocessing", task="run_postprocess", message=str(e)
                )
            )
        return ctx
