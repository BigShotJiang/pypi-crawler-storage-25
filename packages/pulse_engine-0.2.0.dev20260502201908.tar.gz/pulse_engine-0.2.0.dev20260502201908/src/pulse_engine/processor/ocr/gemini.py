"""Gemini OCR provider using Google Generative AI."""

from pathlib import Path
from typing import Any

from google import genai
from google.genai import types

from pulse_engine.processor.base import BaseOCRProvider
from pulse_engine.processor.schemas import OCRInput


class GeminiOCRProvider(BaseOCRProvider):
    """OCR provider powered by Google Gemini's vision capabilities."""

    def _get_client(self, api_key: str) -> Any:
        return genai.Client(api_key=api_key)

    def _read_file_bytes(self, ocr_input: OCRInput) -> bytes:
        if ocr_input.file_bytes:
            return ocr_input.file_bytes
        if ocr_input.file_path:
            return Path(ocr_input.file_path).read_bytes()
        msg = "OCRInput must provide either file_bytes or file_path."
        raise ValueError(msg)

    def extract(self, ocr_input: OCRInput) -> Any:
        file_bytes = self._read_file_bytes(ocr_input)
        client = self._get_client(ocr_input.api_key)

        response = client.models.generate_content(
            model=ocr_input.model,
            contents=[
                types.Content(
                    role="user",
                    parts=[
                        types.Part.from_bytes(
                            data=file_bytes,
                            mime_type=ocr_input.mime_type,
                        ),
                        types.Part.from_text(text=ocr_input.prompt),
                    ],
                ),
            ],
            config=types.GenerateContentConfig(
                temperature=ocr_input.temperature,
                max_output_tokens=ocr_input.max_output_tokens,
                response_mime_type="application/json",
            ),
        )

        return response
