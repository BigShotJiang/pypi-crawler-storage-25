"""Pulse Engine CLI — scaffold, validate, and run products."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Annotated

import typer

app = typer.Typer(name="pulse", help="Pulse Engine CLI", no_args_is_help=True)


# ---------------------------------------------------------------------------
# pulse init
# ---------------------------------------------------------------------------


@app.command()
def init(
    product_name: Annotated[
        str, typer.Argument(help="Name of the new product (e.g. 'political')")
    ],
    output_dir: Annotated[
        Path, typer.Option("--output-dir", "-o", help="Where to scaffold")
    ] = Path("."),
) -> None:
    """Scaffold a new Pulse product from the built-in template."""
    from cookiecutter.main import cookiecutter

    template_dir = str(Path(__file__).parent / "templates")

    # Normalise name: lowercase, underscores for Python
    slug = product_name.lower().replace("-", "_").replace(" ", "_")
    display = slug.replace("_", "-")

    result = cookiecutter(
        template_dir,
        output_dir=str(output_dir),
        no_input=True,
        extra_context={
            "product_name": display,
            "product_slug": slug,
        },
    )
    typer.echo(f"Scaffolded product at {result}")


# ---------------------------------------------------------------------------
# pulse validate
# ---------------------------------------------------------------------------


@app.command()
def validate(
    module: Annotated[
        str,
        typer.Argument(
            help="Dotted import path to the manifest (e.g. 'pulse_political.manifest')"
        ),
    ] = "",
) -> None:
    """Import a product manifest and run validation checks."""
    from pulse_engine.registry import discover_products, validate_manifest

    manifests = []

    if module:
        mod = importlib.import_module(module)
        manifest = getattr(mod, "manifest", None)
        if manifest is None:
            typer.echo(f"No 'manifest' attribute found in {module}", err=True)
            raise typer.Exit(code=1)
        manifests = [manifest]
    else:
        manifests = discover_products()
        if not manifests:
            typer.echo("No products discovered via entry points.", err=True)
            raise typer.Exit(code=1)

    all_ok = True
    for m in manifests:
        errors = validate_manifest(m)
        if errors:
            all_ok = False
            typer.echo(f"[FAIL] {m.name} v{m.version}:")
            for e in errors:
                typer.echo(f"  - {e}")
        else:
            typer.echo(f"[OK] {m.name} v{m.version}")

    if not all_ok:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# pulse run
# ---------------------------------------------------------------------------


@app.command()
def run(
    host: Annotated[str, typer.Option(help="Bind host")] = "0.0.0.0",
    port: Annotated[int, typer.Option(help="Bind port")] = 8000,
    reload: Annotated[bool, typer.Option(help="Enable auto-reload")] = False,
) -> None:
    """Discover the product manifest and start the FastAPI server."""
    import uvicorn

    from pulse_engine.registry import discover_products

    products = discover_products()
    manifest = products[0] if products else None

    if manifest:
        typer.echo(f"Starting {manifest.name} v{manifest.version}")

    # We use a factory string so uvicorn can import and call create_app
    uvicorn.run(
        "pulse_engine.main:create_app",
        factory=True,
        host=host,
        port=port,
        reload=reload,
    )


# ---------------------------------------------------------------------------
# pulse run-worker
# ---------------------------------------------------------------------------


@app.command()
def run_worker() -> None:
    """Discover the product manifest and start the Celery worker."""
    from pulse_engine.config import get_settings
    from pulse_engine.registry import discover_products
    from pulse_engine.worker import create_celery_app

    products = discover_products()
    manifest = products[0] if products else None

    settings = get_settings()
    celery_app = create_celery_app(settings, manifest)

    celery_app.worker_main(["worker", "--loglevel=info"])


# ---------------------------------------------------------------------------
# pulse run-mcp
# ---------------------------------------------------------------------------


@app.command()
def run_mcp() -> None:
    """Discover the product manifest and start the MCP server."""
    import asyncio

    from pulse_engine.mcp.server import run_mcp_server
    from pulse_engine.registry import discover_products

    products = discover_products()
    manifest = products[0] if products else None

    asyncio.run(run_mcp_server(manifest))


if __name__ == "__main__":
    app()
