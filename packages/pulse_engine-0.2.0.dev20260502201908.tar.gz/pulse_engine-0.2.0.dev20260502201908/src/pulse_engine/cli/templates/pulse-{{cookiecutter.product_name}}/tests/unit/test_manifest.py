"""Tests for the product manifest."""

from pulse_engine.registry import validate_manifest

from pulse_{{cookiecutter.product_slug}} import manifest


def test_manifest_is_valid() -> None:
    errors = validate_manifest(manifest)
    assert errors == [], f"Manifest validation failed: {errors}"


def test_manifest_metadata() -> None:
    assert manifest.name == "{{cookiecutter.product_name}}"
    assert manifest.version == "0.1.0"
