"""Pulse product: {{cookiecutter.product_name}}."""

from pulse_engine.registry import ProductManifest

manifest = ProductManifest(
    name="{{cookiecutter.product_name}}",
    version="0.1.0",
)
