"""Product manifest declaration, validation, and discovery."""

from __future__ import annotations

import importlib.metadata
from dataclasses import dataclass, field
from types import EllipsisType
from typing import Any

from pulse_engine.extractor.base import BaseExtractor
from pulse_engine.processor.base import (
    BaseCoreProcessor,
    BasePostprocessor,
    BasePreprocessor,
)


@dataclass
class ProductManifest:
    """Declarative manifest that a product uses to register with the engine.

    For processor stages, the convention is:
      - ``...`` (Ellipsis) → use the engine's default implementation
      - ``None`` → skip the stage entirely
      - an instance → use the provided custom implementation
    """

    name: str
    version: str
    extractors: list[type[BaseExtractor]] = field(default_factory=list)
    preprocessor: BasePreprocessor | None | EllipsisType = ...
    core_processor: BaseCoreProcessor | None | EllipsisType = ...
    postprocessor: BasePostprocessor | None | EllipsisType = ...
    settings_class: type[Any] | None = None
    routers: list[Any] = field(default_factory=list)
    mcp_tool_modules: list[str] = field(default_factory=list)
    celery_task_modules: list[str] = field(default_factory=list)
    athena_database: str = ""


class ManifestValidationError(Exception):
    """Raised when a product manifest fails validation."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(f"Manifest validation failed: {'; '.join(errors)}")


def validate_manifest(manifest: ProductManifest) -> list[str]:
    """Validate a ProductManifest and return a list of error strings (empty = valid)."""
    errors: list[str] = []

    if not manifest.name:
        errors.append("manifest.name is required")
    if not manifest.version:
        errors.append("manifest.version is required")

    # Validate extractors implement BaseExtractor
    seen_job_types: set[str] = set()
    for i, ext_cls in enumerate(manifest.extractors):
        if not (isinstance(ext_cls, type) and issubclass(ext_cls, BaseExtractor)):
            errors.append(
                f"extractors[{i}] ({ext_cls!r}) must be a subclass of BaseExtractor"
            )
            continue

        # Check for duplicate job_types
        try:
            config = ext_cls().get_config()
            if config.job_type in seen_job_types:
                errors.append(
                    f"Duplicate job_type '{config.job_type}' "
                    f"from extractor '{ext_cls.__name__}'"
                )
            seen_job_types.add(config.job_type)
        except Exception as exc:
            errors.append(
                f"extractors[{i}] ({ext_cls.__name__}).get_config() raised: {exc}"
            )

    # Validate processor stages (must be correct ABC or None or Ellipsis)
    _validate_stage(manifest.preprocessor, BasePreprocessor, "preprocessor", errors)
    _validate_stage(
        manifest.core_processor, BaseCoreProcessor, "core_processor", errors
    )
    _validate_stage(manifest.postprocessor, BasePostprocessor, "postprocessor", errors)

    return errors


def _validate_stage(
    value: Any,
    abc: type[Any],
    name: str,
    errors: list[str],
) -> None:
    if value is ... or value is None:
        return
    if not isinstance(value, abc):
        errors.append(
            f"{name} must be an instance of {abc.__name__}, None, or ... (Ellipsis); "
            f"got {type(value).__name__}"
        )


def discover_products() -> list[ProductManifest]:
    """Discover installed products via ``pulse_engine.products`` entry-point group."""
    manifests: list[ProductManifest] = []
    eps = importlib.metadata.entry_points()
    group = eps.select(group="pulse_engine.products")
    for ep in group:
        obj = ep.load()
        if isinstance(obj, ProductManifest):
            manifests.append(obj)
        elif callable(obj):
            manifests.append(obj())
    return manifests
