"""MCP tools for Job operations."""

from typing import Any

from pulse_engine.core.exceptions import ServiceUnavailableError
from pulse_engine.extractor.repository import JobRepository
from pulse_engine.extractor.schemas import (
    CreateJobRequest,
    JobPriority,
    StatusUpdateRequest,
)
from pulse_engine.extractor.service import JobService
from pulse_engine.mcp.server import get_container, handle_mcp_errors, mcp


def _build_job_service(
    session: Any,
    container: Any,
) -> JobService:
    repo = JobRepository(session)
    return JobService(
        repository=repo,
        orchestrator=container.orchestrator_adapter,
        settings=container.settings,
    )


@mcp.tool()
@handle_mcp_errors
async def jobs_register(
    tenant_id: str,
    job_type: str,
    product: str,
    priority: str = "normal",
    orchestrator_run_id: str | None = None,
    parameters: dict[str, Any] | None = None,
    callback_url: str | None = None,
) -> dict[str, Any]:
    """Register a new extraction job for a tenant."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        request = CreateJobRequest(
            job_type=job_type,
            product=product,
            priority=JobPriority(priority),
            orchestrator_run_id=orchestrator_run_id,
            parameters=parameters or {},
            callback_url=callback_url,
        )
        result = await service.register_job(tenant_id, request)
        return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def jobs_get(
    tenant_id: str,
    job_id: str,
) -> dict[str, Any]:
    """Get details of a specific job."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        result = await service.get_job(tenant_id, job_id)
        return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def jobs_list(
    tenant_id: str,
    status: str | None = None,
    product: str | None = None,
    job_type: str | None = None,
    limit: int = 20,
    offset: int = 0,
    sort_by: str = "created_at",
    order: str = "desc",
) -> dict[str, Any]:
    """List jobs for a tenant with optional filters."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        result = await service.list_jobs(
            tenant_id,
            status=status,
            product=product,
            job_type=job_type,
            limit=limit,
            offset=offset,
            sort_by=sort_by,
            order=order,
        )
        return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def jobs_push_status(
    tenant_id: str,
    job_id: str,
    status: str,
    result_summary: dict[str, Any] | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    """Push a status update for a job."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        from pulse_engine.extractor.schemas import JobStatus

        request = StatusUpdateRequest(
            status=JobStatus(status),
            result_summary=result_summary,
            error=error,
        )
        result = await service.push_status(tenant_id, job_id, request)
        return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def jobs_cancel(
    tenant_id: str,
    job_id: str,
) -> dict[str, Any]:
    """Cancel a running or pending job."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        result = await service.cancel_job(tenant_id, job_id)
        return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def jobs_delete(
    tenant_id: str,
    job_id: str,
) -> dict[str, Any]:
    """Delete a job record."""
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")
    async with container.db_session_factory() as session:
        service = _build_job_service(session, container)
        deleted = await service.delete_job(tenant_id, job_id)
        return {"deleted": deleted, "job_id": job_id}
