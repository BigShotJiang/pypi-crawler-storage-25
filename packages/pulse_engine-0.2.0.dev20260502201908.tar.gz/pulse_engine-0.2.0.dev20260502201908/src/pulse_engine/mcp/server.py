"""MCP server for Pulse Platform.

Exposes KB, Jobs, Processor, Pipeline, and Module tools.
"""

from __future__ import annotations

import functools
import importlib
from collections.abc import Callable
from typing import Any, TypeVar

from mcp.server.fastmcp import FastMCP
from pydantic import ValidationError

from pulse_engine.config import get_settings as _get_settings
from pulse_engine.core.exceptions import (
    AppError,
    NotFoundError,
    ServiceUnavailableError,
    TooManyRequestsError,
)
from pulse_engine.services.bootstrap import ServiceContainer

_s = _get_settings()
mcp = FastMCP("Pulse Platform", host=_s.mcp_sse_host, port=_s.mcp_sse_port)

_container: ServiceContainer | None = None


def get_container() -> ServiceContainer:
    if _container is None:
        raise RuntimeError("MCP server not initialized — no service container")
    return _container


F = TypeVar("F", bound=Callable[..., Any])


def handle_mcp_errors(fn: F) -> F:
    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return await fn(*args, **kwargs)
        except NotFoundError as e:
            return {"error": True, "error_type": "NotFoundError", "message": e.message}
        except TooManyRequestsError as e:
            return {
                "error": True,
                "error_type": "TooManyRequestsError",
                "message": e.message,
            }
        except ServiceUnavailableError as e:
            return {
                "error": True,
                "error_type": "ServiceUnavailableError",
                "message": e.message,
            }
        except ValidationError as e:
            return {
                "error": True,
                "error_type": "ValidationError",
                "message": str(e),
            }
        except AppError as e:
            return {
                "error": True,
                "error_type": type(e).__name__,
                "message": e.message,
            }

    return wrapper  # type: ignore[return-value]


def create_mcp_server(
    manifest: Any | None = None,
) -> FastMCP:
    """Return the module-level FastMCP instance, optionally loading product tools."""
    if manifest:
        for module_path in manifest.mcp_tool_modules:
            importlib.import_module(module_path)
    return mcp


async def run_mcp_server(manifest: Any | None = None) -> None:
    global _container

    from pulse_engine.config import get_settings
    from pulse_engine.services.bootstrap import bootstrap_services

    settings = get_settings()

    async with bootstrap_services(settings, manifest) as container:
        _container = container

        # Import engine tool modules to trigger @mcp.tool() registrations
        import pulse_engine.mcp.tools_jobs  # noqa: F401
        import pulse_engine.mcp.tools_kb  # noqa: F401
        import pulse_engine.mcp.tools_modules  # noqa: F401
        import pulse_engine.mcp.tools_pipelines  # noqa: F401
        import pulse_engine.mcp.tools_processor  # noqa: F401

        # Import product tool modules
        if manifest:
            for module_path in manifest.mcp_tool_modules:
                importlib.import_module(module_path)

        await mcp.run_sse_async()
