"""MCP tools for Knowledge Base operations."""

from typing import Any

from pulse_engine.mcp.server import get_container, handle_mcp_errors, mcp
from pulse_engine.storage.schemas import Document, SearchQuery, SearchQueryType


@mcp.tool()
@handle_mcp_errors
async def kb_store_documents(
    tenant_id: str,
    documents: list[dict[str, Any]],
) -> dict[str, Any]:
    """Store documents in the Knowledge Base for a tenant."""
    container = get_container()
    docs = [Document(**d) for d in documents]
    result = await container.kb_service.store_documents(tenant_id, docs)
    return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def kb_retrieve_document(
    tenant_id: str,
    document_id: str,
) -> dict[str, Any]:
    """Retrieve a single document by ID from the Knowledge Base."""
    container = get_container()
    doc = await container.kb_service.retrieve_document(tenant_id, document_id)
    return doc.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def kb_search(
    tenant_id: str,
    query_text: str,
    query_type: str = "text",
    filters: dict[str, Any] | None = None,
    size: int = 10,
) -> dict[str, Any]:
    """Search documents in the Knowledge Base."""
    container = get_container()
    query = SearchQuery(
        query_type=SearchQueryType(query_type),
        query_text=query_text,
        filters=filters or {},
        size=size,
    )
    result = await container.kb_service.search(tenant_id, query)
    return result.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def kb_delete_document(
    tenant_id: str,
    document_id: str,
) -> dict[str, Any]:
    """Delete a document from the Knowledge Base."""
    container = get_container()
    await container.kb_service.delete_document(tenant_id, document_id)
    return {"deleted": True, "document_id": document_id}


@mcp.tool()
@handle_mcp_errors
async def kb_get_stats(
    tenant_id: str,
) -> dict[str, Any]:
    """Get Knowledge Base statistics for a tenant."""
    container = get_container()
    stats = await container.kb_service.get_stats(tenant_id)
    return stats.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def kb_run_query(
    tenant_id: str,
    sql: str,
    parameters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute an Athena SQL query against the Knowledge Base."""
    container = get_container()
    result = await container.kb_service.execute_query(tenant_id, sql, parameters)
    return result.model_dump(mode="json")
