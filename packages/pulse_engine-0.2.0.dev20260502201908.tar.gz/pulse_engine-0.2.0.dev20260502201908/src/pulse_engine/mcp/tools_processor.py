"""MCP tools for Processor operations."""

import time
from typing import Any

from pulse_engine.mcp.server import get_container, handle_mcp_errors, mcp
from pulse_engine.processor.core.analysis import (
    classify_sentiment,
    extract_entities,
    extract_topics,
    summarize,
)
from pulse_engine.processor.core.chunking import chunk_content
from pulse_engine.processor.postprocessor.tasks import run_postprocessing
from pulse_engine.processor.preprocessor.tasks import (
    clean_html,
    detect_language,
    normalize_text,
    validate_content,
)
from pulse_engine.processor.schemas import (
    ContentChunk,
    ProcessingContext,
    ProcessingOptions,
)


@mcp.tool()
@handle_mcp_errors
async def process_pipeline(
    tenant_id: str,
    content: str,
    source_id: str,
    source_type: str = "text",
    product: str = "",
    job_id: str | None = None,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run the full processing pipeline (preprocess → analyze → postprocess)."""
    from pulse_engine.processor.pipeline import ProcessingPipeline

    container = get_container()
    pipeline = ProcessingPipeline(kb_service=container.kb_service)

    opts = ProcessingOptions(**(options or {}))
    ctx = ProcessingContext(
        source_id=source_id,
        source_type=source_type,
        product=product,
        tenant_id=tenant_id,
        job_id=job_id,
        raw_content=content,
        options=opts,
    )

    start = time.monotonic()
    ctx = await pipeline.run(ctx)
    elapsed_ms = int((time.monotonic() - start) * 1000)

    doc_count = len(ctx.documents)
    chunk_count = len(ctx.chunks)
    total_chunks = chunk_count + (
        doc_count - chunk_count if doc_count != chunk_count else 0
    )
    stored = len(ctx.documents) if ctx.options.store_results else 0
    deduped = max(0, total_chunks - len(ctx.chunks))
    languages = [ctx.language] if ctx.language and ctx.language != "unknown" else []

    return {
        "source_id": ctx.source_id,
        "chunks_produced": len(ctx.chunks),
        "chunks_stored": stored,
        "chunks_deduplicated": deduped,
        "processing_time_ms": elapsed_ms,
        "summary": ctx.summary,
        "languages_detected": languages,
        "entities_found": len(ctx.entities),
        "stages_completed": ctx.stages_completed,
    }


@mcp.tool()
@handle_mcp_errors
async def process_preprocess(
    tenant_id: str,
    content: str,
    source_type: str = "text",
) -> dict[str, Any]:
    """Clean, normalize, and validate content."""
    cleaned = clean_html(content)
    cleaned = normalize_text(cleaned)
    lang = detect_language(cleaned) if validate_content(cleaned) else None
    is_valid = validate_content(cleaned)

    return {
        "cleaned_content": cleaned,
        "language": lang,
        "is_valid": is_valid,
    }


@mcp.tool()
@handle_mcp_errors
async def process_analyze(
    tenant_id: str,
    content: str,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Chunk content and run NER, sentiment, topic extraction, and summarization."""
    opts = ProcessingOptions(**(options or {}))

    chunks = chunk_content(
        text=content,
        source_id="analyze-temp",
        strategy=opts.chunk_strategy,
        chunk_size=opts.chunk_size,
        overlap=opts.chunk_overlap,
    )

    for c in chunks:
        if opts.enable_ner:
            c.entities = extract_entities(c.content)
        if opts.enable_sentiment:
            c.sentiment = classify_sentiment(c.content)
        if opts.enable_topics:
            c.topics = extract_topics(c.content)

    entities = extract_entities(content) if opts.enable_ner else []
    sentiment = classify_sentiment(content) if opts.enable_sentiment else None
    topics = extract_topics(content) if opts.enable_topics else []
    summary_text = summarize(content)

    return {
        "chunks": [c.model_dump(mode="json") for c in chunks],
        "entities": [e.model_dump(mode="json") for e in entities],
        "sentiment": sentiment,
        "topics": topics,
        "summary": summary_text,
    }


@mcp.tool()
@handle_mcp_errors
async def process_postprocess(
    tenant_id: str,
    content: str,
    chunks: list[dict[str, Any]],
    source_id: str,
    source_type: str = "text",
    product: str = "",
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run postprocessing: embeddings, quality scoring, dedup, document formatting."""
    opts = ProcessingOptions(**(options or {}))
    chunk_objs = [ContentChunk(**c) for c in chunks]

    ctx = ProcessingContext(
        source_id=source_id,
        source_type=source_type,
        product=product,
        tenant_id=tenant_id,
        raw_content=content,
        cleaned_content=content,
        chunks=chunk_objs,
        options=opts,
    )

    ctx = run_postprocessing(ctx)

    return {
        "documents_created": len(ctx.documents),
        "embeddings_generated": len(ctx.embeddings),
        "quality_scores": ctx.quality_scores,
    }


@mcp.tool()
@handle_mcp_errors
async def process_chunk(
    tenant_id: str,
    content: str,
    strategy: str = "token_count",
    chunk_size: int = 512,
    overlap: int = 50,
) -> dict[str, Any]:
    """Split content into chunks using the specified strategy."""
    chunks = chunk_content(
        text=content,
        source_id="chunk-temp",
        strategy=strategy,
        chunk_size=chunk_size,
        overlap=overlap,
    )

    items = [
        {
            "index": c.chunk_index,
            "content": c.content,
            "token_count": c.token_count,
        }
        for c in chunks
    ]

    return {
        "chunks": items,
        "total_chunks": len(items),
        "strategy": strategy,
    }
