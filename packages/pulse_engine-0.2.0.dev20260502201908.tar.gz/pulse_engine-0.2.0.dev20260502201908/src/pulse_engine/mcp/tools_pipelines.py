"""MCP tools for Pipeline operations."""

from typing import Any

from pulse_engine.core.exceptions import NotFoundError, ServiceUnavailableError
from pulse_engine.mcp.server import get_container, handle_mcp_errors, mcp
from pulse_engine.pipeline.config_parser import (
    PipelineConfigError,
    parse_pipeline_config,
)
from pulse_engine.pipeline.repositories import (
    ModuleRegistryRepository,
    PipelineRunRepository,
)
from pulse_engine.pipeline.schemas import PipelineRunStatus, PipelineStatusResponse
from pulse_engine.pipeline.service import PipelineService


def _build_pipeline_service(
    session: Any,
    container: Any,
) -> PipelineService:
    return PipelineService(
        module_repo=ModuleRegistryRepository(session),
        run_repo=PipelineRunRepository(session),
        translators=container.pipeline_translators,
        status_providers=container.pipeline_status_providers,
        settings=container.settings,
        token_issuer=container.token_issuer,
    )


@mcp.tool()
@handle_mcp_errors
async def pipelines_trigger(
    tenant_id: str,
    product: str,
    orchestrator: str,
    pipeline_yaml: str,
    input_data: list[dict[str, Any]] | None = None,
    global_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Trigger a pipeline run.

    Args:
        tenant_id: Tenant identifier.
        product: Product name (must have modules registered).
        orchestrator: Orchestrator backend ("prefect").
        pipeline_yaml: Pipeline definition as a YAML string.
        input_data: Input data for the first step (e.g. [{"s3_key": "s3://..."}]).
        global_config: Config passed to all steps (e.g. {"s3_bucket": "my-bucket"}).

    Returns:
        {"run_id": "<uuid>"} on success.
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    try:
        config = parse_pipeline_config(pipeline_yaml)
    except PipelineConfigError as e:
        return {"error": True, "error_type": "PipelineConfigError", "errors": e.errors}

    async with container.db_session_factory() as session:
        service = _build_pipeline_service(session, container)
        run_id = await service.trigger(
            tenant_id=tenant_id,
            product=product,
            orchestrator=orchestrator,
            config=config,
            input_data=input_data or [],
            global_config=global_config or {},
        )
        return {"run_id": run_id}


@mcp.tool()
@handle_mcp_errors
async def pipelines_status(
    tenant_id: str,
    run_id: str,
) -> dict[str, Any]:
    """Get the status and step details of a pipeline run.

    Args:
        tenant_id: Tenant identifier.
        run_id: Pipeline run ID (from pipelines_trigger).

    Returns:
        Pipeline status with run_id, product, orchestrator, status, and steps.
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        service = _build_pipeline_service(session, container)
        run = await service.get_run(tenant_id, run_id)
        if run is None:
            raise NotFoundError("Pipeline run not found", run_id=run_id)

        pipeline_status = await service.get_status(tenant_id, run_id)

        resp = PipelineStatusResponse(
            run_id=run.id,
            product=run.product,
            orchestrator=run.orchestrator,
            status=PipelineRunStatus(
                pipeline_status.status if pipeline_status else run.status
            ),
            started_at=pipeline_status.started_at if pipeline_status else None,  # type: ignore[arg-type]
            steps=pipeline_status.steps if pipeline_status else [],
        )
        return resp.model_dump(mode="json")


@mcp.tool()
@handle_mcp_errors
async def pipelines_list(
    tenant_id: str,
    product: str | None = None,
    status: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """List pipeline runs for a tenant.

    Args:
        tenant_id: Tenant identifier.
        product: Filter by product name.
        status: Filter by status (pending, running, completed, failed).
        limit: Max results to return.
        offset: Pagination offset.

    Returns:
        {"items": [...], "total": N, "limit": N, "offset": N}
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        service = _build_pipeline_service(session, container)
        runs, total = await service.list_runs(
            tenant_id, product=product, status=status, limit=limit, offset=offset
        )
        items = [
            {
                "run_id": r.id,
                "product": r.product,
                "orchestrator": r.orchestrator,
                "status": r.status,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in runs
        ]
        return {"items": items, "total": total, "limit": limit, "offset": offset}


@mcp.tool()
@handle_mcp_errors
async def pipelines_cancel(
    tenant_id: str,
    run_id: str,
) -> dict[str, Any]:
    """Cancel a running pipeline.

    Args:
        tenant_id: Tenant identifier.
        run_id: Pipeline run ID to cancel.

    Returns:
        {"run_id": "...", "status": "cancelled"} on success.
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        service = _build_pipeline_service(session, container)
        result = await service.cancel(tenant_id, run_id)
        if not result:
            raise NotFoundError(
                "Pipeline run not found or cannot be cancelled", run_id=run_id
            )
        return {"run_id": run_id, "status": "cancelled"}


@mcp.tool()
@handle_mcp_errors
async def pipelines_steps(
    tenant_id: str,
    run_id: str,
) -> dict[str, Any]:
    """Get detailed step execution info for a pipeline run.

    Args:
        tenant_id: Tenant identifier.
        run_id: Pipeline run ID.

    Returns:
        {"run_id": "...", "steps": [{step, module, status, started_at}, ...]}
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        service = _build_pipeline_service(session, container)
        pipeline_status = await service.get_status(tenant_id, run_id)
        if pipeline_status is None:
            raise NotFoundError("Pipeline run not found", run_id=run_id)

        return {
            "run_id": run_id,
            "steps": [s.model_dump(mode="json") for s in pipeline_status.steps],
        }
