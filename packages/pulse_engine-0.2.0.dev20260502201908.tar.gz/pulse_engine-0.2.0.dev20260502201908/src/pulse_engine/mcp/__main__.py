import asyncio

from pulse_engine.mcp.server import run_mcp_server

asyncio.run(run_mcp_server())
