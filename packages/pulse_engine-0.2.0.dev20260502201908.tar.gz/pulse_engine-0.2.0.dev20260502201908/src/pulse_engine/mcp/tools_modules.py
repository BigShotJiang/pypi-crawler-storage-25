"""MCP tools for Module Registry operations."""

from typing import Any

from pulse_engine.core.exceptions import NotFoundError, ServiceUnavailableError
from pulse_engine.mcp.server import get_container, handle_mcp_errors, mcp
from pulse_engine.pipeline.repositories import ModuleRegistryRepository


@mcp.tool()
@handle_mcp_errors
async def modules_register(
    tenant_id: str,
    product: str,
    modules: dict[str, dict[str, str]],
) -> dict[str, Any]:
    """Register pipeline module images for a product.

    Args:
        tenant_id: Tenant identifier.
        product: Product name (e.g. "sample-product").
        modules: Map of module name to {"image": "<ecr-uri>:<tag>"}.
            Example: {"extractor": {"image": "123.ecr/extractor:latest"}}

    Returns:
        {"product": "...", "modules": {"extractor": {"status": "registered"}, ...}}
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        repo = ModuleRegistryRepository(session)
        result_modules: dict[str, dict[str, str]] = {}

        for module_name, module_def in modules.items():
            image = module_def.get("image", "")
            if not image:
                result_modules[module_name] = {
                    "status": "error",
                    "detail": "missing image",
                }
                continue
            await repo.upsert(tenant_id, product, module_name, image)
            result_modules[module_name] = {"status": "registered"}

        return {"product": product, "modules": result_modules}


@mcp.tool()
@handle_mcp_errors
async def modules_list(
    tenant_id: str,
    product: str,
) -> dict[str, Any]:
    """List registered modules for a product.

    Args:
        tenant_id: Tenant identifier.
        product: Product name.

    Returns:
        {"product": "...", "modules": [{"name": "...", "image": "..."}, ...]}
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        repo = ModuleRegistryRepository(session)
        entries = await repo.list_by_product(tenant_id, product)
        return {
            "product": product,
            "modules": [
                {
                    "name": e.module_name,
                    "image": e.image,
                    "updated_at": e.updated_at.isoformat() if e.updated_at else None,
                }
                for e in entries
            ],
        }


@mcp.tool()
@handle_mcp_errors
async def modules_delete(
    tenant_id: str,
    product: str,
    module_name: str,
) -> dict[str, Any]:
    """Delete a module registration.

    Args:
        tenant_id: Tenant identifier.
        product: Product name.
        module_name: Module to delete.

    Returns:
        {"deleted": true, "product": "...", "module_name": "..."}
    """
    container = get_container()
    if container.db_session_factory is None:
        raise ServiceUnavailableError("Database not configured")

    async with container.db_session_factory() as session:
        repo = ModuleRegistryRepository(session)
        deleted = await repo.delete(tenant_id, product, module_name)
        if not deleted:
            raise NotFoundError(
                f"Module '{module_name}' not found for product '{product}'",
                product=product,
                module_name=module_name,
            )
        return {"deleted": True, "product": product, "module_name": module_name}
