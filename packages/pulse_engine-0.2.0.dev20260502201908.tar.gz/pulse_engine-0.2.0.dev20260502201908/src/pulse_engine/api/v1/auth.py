"""Authentication endpoint — exchanges email/password for Cognito tokens."""

import base64
import hashlib
import hmac

import boto3
import structlog
from botocore.exceptions import ClientError
from fastapi import APIRouter, HTTPException, Request
from jose import jwt as jose_jwt
from pydantic import BaseModel, EmailStr, Field

from pulse_engine.config import get_settings
from pulse_engine.middleware.rate_limit import check_rate_limit

logger = structlog.get_logger()

router = APIRouter(prefix="/auth", tags=["Auth"])


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginResponse(BaseModel):
    id_token: str
    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"
    tenant_id: str
    email: str


def _compute_secret_hash(email: str, client_id: str, client_secret: str) -> str:
    message = email + client_id
    digest = hmac.new(
        client_secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    return base64.b64encode(digest).decode("utf-8")


@router.post("/login", response_model=LoginResponse)
async def login(request: Request, body: LoginRequest) -> LoginResponse:
    """Authenticate with email and password, returns JWT tokens."""
    # Strict per-IP rate limit: 5 attempts per 60 seconds
    check_rate_limit(request, scope="login", max_requests=5, window_seconds=60)
    settings = get_settings()

    client_id = settings.cognito_app_client_id
    client_secret = settings.cognito_app_client_secret

    auth_params: dict[str, str] = {
        "USERNAME": body.email,
        "PASSWORD": body.password,
    }

    if client_secret:
        auth_params["SECRET_HASH"] = _compute_secret_hash(
            body.email, client_id, client_secret
        )

    try:
        cognito = boto3.client("cognito-idp", region_name=settings.aws_region)
        result = cognito.initiate_auth(
            ClientId=client_id,
            AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters=auth_params,
        )
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code in ("NotAuthorizedException", "UserNotFoundException"):
            raise HTTPException(status_code=401, detail="Invalid email or password")
        logger.error("cognito_auth_error", error=str(e), code=code)
        raise HTTPException(status_code=500, detail="Authentication service error")

    auth = result["AuthenticationResult"]
    # Decode id_token (without verification) to extract tenant_id
    claims = jose_jwt.get_unverified_claims(auth["IdToken"])
    return LoginResponse(
        id_token=auth["IdToken"],
        access_token=auth["AccessToken"],
        refresh_token=auth["RefreshToken"],
        expires_in=auth["ExpiresIn"],
        tenant_id=claims.get("custom:tenant_id", ""),
        email=claims.get("email", body.email),
    )
