import httpx
import structlog
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from pulse_engine.config import Settings, get_settings
from pulse_engine.services.opensearch import OpenSearchService

router = APIRouter()
logger = structlog.get_logger()


class ServiceHealth(BaseModel):
    opensearch: str
    prefect: str


class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str
    services: ServiceHealth


async def _check_opensearch(opensearch: OpenSearchService) -> str:
    if await opensearch.ping():
        return "up"
    return "down"


async def _check_prefect(url: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{url}/health")
            resp.raise_for_status()
            return "up"
    except Exception:
        logger.warning("prefect_health_check_failed", url=url)
        return "down"


@router.get("/health", response_model=HealthResponse)
async def health_check(
    request: Request,
    settings: Settings = Depends(get_settings),
) -> HealthResponse:
    opensearch: OpenSearchService = request.app.state.opensearch
    opensearch_status = await _check_opensearch(opensearch)
    prefect_status = await _check_prefect(settings.prefect_api_url)

    all_up = opensearch_status == "up" and prefect_status == "up"
    overall = "ok" if all_up else "degraded"

    return HealthResponse(
        status=overall,
        version=settings.app_version,
        environment=settings.app_env,
        services=ServiceHealth(
            opensearch=opensearch_status,
            prefect=prefect_status,
        ),
    )
