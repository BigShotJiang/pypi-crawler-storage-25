from fastapi import APIRouter

from pulse_engine.api.v1.auth import router as auth_router
from pulse_engine.api.v1.health import router as health_router
from pulse_engine.deployment.router import router as deployments_router
from pulse_engine.extractor.router import router as jobs_router
from pulse_engine.processor.router import router as process_router
from pulse_engine.storage.router import router as kb_router

v1_router = APIRouter(prefix="/api/v1")
v1_router.include_router(auth_router)
v1_router.include_router(health_router)
v1_router.include_router(kb_router)
v1_router.include_router(jobs_router)
v1_router.include_router(process_router)
v1_router.include_router(deployments_router)
