"""Jobs API router."""

from typing import Literal

from fastapi import APIRouter, Depends, Query
from starlette.responses import JSONResponse

from pulse_engine.core.scope import require_scope
from pulse_engine.dependencies import get_job_service
from pulse_engine.extractor.schemas import (
    CreateJobRequest,
    CreateJobResponse,
    JobListResponse,
    JobResponse,
    StatusUpdateRequest,
    StatusUpdateResponse,
)
from pulse_engine.extractor.service import JobService
from pulse_engine.middleware.tenant import get_tenant_id

router = APIRouter(prefix="/jobs", tags=["Jobs"])


@router.post(
    "/",
    response_model=CreateJobResponse,
    status_code=202,
    dependencies=[require_scope("jobs:trigger_next")],
)
async def register_job(
    body: CreateJobRequest,
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
) -> CreateJobResponse:
    return await service.register_job(tenant_id, body)


@router.get("/{job_id}", response_model=JobResponse, status_code=200)
async def get_job(
    job_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
) -> JobResponse:
    return await service.get_job(tenant_id, job_id)


@router.get("/", response_model=JobListResponse, status_code=200)
async def list_jobs(
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
    status: str | None = Query(None),
    product: str | None = Query(None),
    job_type: str | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    sort_by: str = Query("created_at"),
    order: Literal["asc", "desc"] = Query("desc"),
) -> JobListResponse:
    return await service.list_jobs(
        tenant_id,
        status=status,
        product=product,
        job_type=job_type,
        limit=limit,
        offset=offset,
        sort_by=sort_by,
        order=order,
    )


@router.post(
    "/{job_id}/status",
    response_model=StatusUpdateResponse,
    status_code=200,
    dependencies=[require_scope("jobs:status")],
)
async def push_status(
    job_id: str,
    body: StatusUpdateRequest,
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
) -> StatusUpdateResponse:
    return await service.push_status(tenant_id, job_id, body)


@router.post("/{job_id}/cancel", response_model=JobResponse, status_code=200)
async def cancel_job(
    job_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
) -> JobResponse:
    return await service.cancel_job(tenant_id, job_id)


@router.delete("/{job_id}", status_code=204)
async def delete_job(
    job_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: JobService = Depends(get_job_service),
) -> JSONResponse:
    await service.delete_job(tenant_id, job_id)
    return JSONResponse(status_code=204, content=None)
