"""Pydantic request/response schemas for the Jobs API."""

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class JobPriority(str, Enum):
    low = "low"
    normal = "normal"
    high = "high"


class CreateJobRequest(BaseModel):
    product: str
    stage: Literal["extractor", "processor", "storage"] = "extractor"
    orchestrator: str = "prefect"
    compute: str = "ecs"
    chain: bool = True
    job_id: str | None = None  # reuse existing job for isolation runs
    config: dict[str, Any] = Field(default_factory=dict)
    # Retained for backwards compatibility:
    job_type: str | None = None
    priority: JobPriority = JobPriority.normal
    orchestrator_run_id: str | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    callback_url: str | None = None


class CreateJobResponse(BaseModel):
    job_id: str
    job_type: str
    product: str
    stage: str
    status: str
    created_at: datetime


class StatusUpdateRequest(BaseModel):
    status: JobStatus
    stage: str | None = None
    result_summary: dict[str, Any] | None = None
    error: str | None = None


class StatusUpdateResponse(BaseModel):
    job_id: str
    status: str
    updated_at: datetime


class JobStageResponse(BaseModel):
    stage: str
    status: str
    prefect_flow_run_id: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None


class JobResponse(BaseModel):
    job_id: str
    job_type: str
    product: str
    tenant_id: str
    status: str
    priority: str
    parameters: dict[str, Any]
    orchestrator_run_id: str | None = None
    callback_url: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    result_summary: dict[str, Any] | None = None
    error: str | None = None
    stages: list[JobStageResponse] = Field(default_factory=list)


class JobListResponse(BaseModel):
    total: int
    jobs: list[JobResponse]
    limit: int
    offset: int
