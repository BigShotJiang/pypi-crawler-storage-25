"""Job record ORM model."""

import uuid
from datetime import datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from pulse_engine.database import Base


class JobRecordModel(Base):
    __tablename__ = "job_records"

    job_id: Mapped[str] = mapped_column(
        sa.String, primary_key=True, default=lambda: str(uuid.uuid4())
    )
    job_type: Mapped[str] = mapped_column(sa.String, nullable=False)
    product: Mapped[str] = mapped_column(sa.String, nullable=False)
    tenant_id: Mapped[str] = mapped_column(sa.String, nullable=False, index=True)
    status: Mapped[str] = mapped_column(sa.String, nullable=False, default="pending")
    priority: Mapped[str] = mapped_column(sa.String, nullable=False, default="normal")
    parameters: Mapped[dict[str, Any]] = mapped_column(
        sa.JSON, nullable=False, default=dict
    )
    orchestrator_run_id: Mapped[str | None] = mapped_column(
        sa.String, nullable=True, default=None
    )
    callback_url: Mapped[str | None] = mapped_column(
        sa.String, nullable=True, default=None
    )
    created_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
    )
    started_at: Mapped[datetime | None] = mapped_column(
        sa.DateTime(timezone=True), nullable=True, default=None
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        sa.DateTime(timezone=True), nullable=True, default=None
    )
    result_summary: Mapped[dict[str, Any] | None] = mapped_column(
        sa.JSON, nullable=True, default=None
    )
    error: Mapped[str | None] = mapped_column(sa.String, nullable=True, default=None)

    __table_args__ = (
        sa.Index("ix_job_records_tenant_status", "tenant_id", "status"),
        sa.Index("ix_job_records_tenant_product", "tenant_id", "product"),
    )
