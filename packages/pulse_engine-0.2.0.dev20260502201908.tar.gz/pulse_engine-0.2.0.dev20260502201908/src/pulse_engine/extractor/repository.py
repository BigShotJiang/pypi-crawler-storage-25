"""Job repository — data access layer for job records."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy.engine import CursorResult
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.core.exceptions import BadRequestError
from pulse_engine.extractor.models import JobRecordModel

# Explicit allowlist of columns permitted for sort_by queries
_ALLOWED_SORT_FIELDS: set[str] = {
    "created_at",
    "status",
    "product",
    "job_type",
    "priority",
}


class JobRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(
        self,
        tenant_id: str,
        job_type: str,
        product: str,
        priority: str = "normal",
        parameters: dict[str, Any] | None = None,
        orchestrator_run_id: str | None = None,
        callback_url: str | None = None,
    ) -> JobRecordModel:
        record = JobRecordModel(
            job_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            job_type=job_type,
            product=product,
            priority=priority,
            parameters=parameters or {},
            orchestrator_run_id=orchestrator_run_id,
            callback_url=callback_url,
            status="pending",
            created_at=datetime.now(UTC),
        )
        self._session.add(record)
        await self._session.commit()
        await self._session.refresh(record)
        return record

    async def get(self, job_id: str, tenant_id: str) -> JobRecordModel | None:
        stmt = sa.select(JobRecordModel).where(
            JobRecordModel.job_id == job_id,
            JobRecordModel.tenant_id == tenant_id,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_jobs(
        self,
        tenant_id: str,
        status: str | None = None,
        product: str | None = None,
        job_type: str | None = None,
        limit: int = 20,
        offset: int = 0,
        sort_by: str = "created_at",
        order: str = "desc",
    ) -> tuple[list[JobRecordModel], int]:
        base = sa.select(JobRecordModel).where(
            JobRecordModel.tenant_id == tenant_id,
        )
        count_base = (
            sa.select(sa.func.count())
            .select_from(JobRecordModel)
            .where(
                JobRecordModel.tenant_id == tenant_id,
            )
        )

        if status:
            base = base.where(JobRecordModel.status == status)
            count_base = count_base.where(JobRecordModel.status == status)
        if product:
            base = base.where(JobRecordModel.product == product)
            count_base = count_base.where(JobRecordModel.product == product)
        if job_type:
            base = base.where(JobRecordModel.job_type == job_type)
            count_base = count_base.where(JobRecordModel.job_type == job_type)

        # Sorting — validate against allowlist to prevent column-name injection
        if sort_by not in _ALLOWED_SORT_FIELDS:
            raise BadRequestError(
                f"Invalid sort field: {sort_by!r}. "
                f"Allowed: {', '.join(sorted(_ALLOWED_SORT_FIELDS))}"
            )
        sort_col = getattr(JobRecordModel, sort_by)
        if order == "asc":
            base = base.order_by(sa.asc(sort_col))
        else:
            base = base.order_by(sa.desc(sort_col))

        base = base.offset(offset).limit(limit)

        result = await self._session.execute(base)
        jobs = list(result.scalars().all())

        count_result = await self._session.execute(count_base)
        total = count_result.scalar_one()

        return jobs, total

    async def update_status(
        self,
        job_id: str,
        tenant_id: str,
        status: str,
        **fields: object,
    ) -> JobRecordModel | None:
        record = await self.get(job_id, tenant_id)
        if record is None:
            return None

        record.status = status
        for key, value in fields.items():
            if hasattr(record, key):
                setattr(record, key, value)

        await self._session.commit()
        await self._session.refresh(record)
        return record

    async def delete(self, job_id: str, tenant_id: str) -> bool:
        stmt = sa.delete(JobRecordModel).where(
            JobRecordModel.job_id == job_id,
            JobRecordModel.tenant_id == tenant_id,
        )
        result: CursorResult[Any] = await self._session.execute(stmt)  # type: ignore[assignment]
        await self._session.commit()
        return bool(result.rowcount > 0)

    async def count_active(self, tenant_id: str) -> int:
        stmt = (
            sa.select(sa.func.count())
            .select_from(JobRecordModel)
            .where(
                JobRecordModel.tenant_id == tenant_id,
                JobRecordModel.status.in_(["pending", "running"]),
            )
        )
        result = await self._session.execute(stmt)
        return result.scalar_one()

    async def get_by_id(self, job_id: str) -> JobRecordModel | None:
        stmt = sa.select(JobRecordModel).where(JobRecordModel.job_id == job_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
