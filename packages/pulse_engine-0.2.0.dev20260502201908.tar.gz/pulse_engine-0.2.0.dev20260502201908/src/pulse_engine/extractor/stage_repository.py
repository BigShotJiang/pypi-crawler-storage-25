"""Data access layer for job stage records."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.extractor.stage_models import JobStageModel


class StageRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(
        self,
        job_id: str,
        stage: str,
        prefect_flow_run_id: str | None = None,
    ) -> JobStageModel:
        record = JobStageModel(
            id=str(uuid.uuid4()),
            job_id=job_id,
            stage=stage,
            status="pending",
            prefect_flow_run_id=prefect_flow_run_id,
        )
        self._session.add(record)
        await self._session.commit()
        await self._session.refresh(record)
        return record

    async def update_status(
        self,
        stage_id: str,
        status: str,
        error: str | None = None,
    ) -> JobStageModel:
        stmt = sa.select(JobStageModel).where(JobStageModel.id == stage_id)
        result = await self._session.execute(stmt)
        record = result.scalar_one()

        now = datetime.now(UTC)
        record.status = status
        if status == "running" and record.started_at is None:
            record.started_at = now
        if status in ("completed", "failed", "cancelled"):
            record.completed_at = now
        if error is not None:
            record.error = error

        await self._session.commit()
        await self._session.refresh(record)
        return record

    async def get_stages_for_job(self, job_id: str) -> list[JobStageModel]:
        stmt = (
            sa.select(JobStageModel)
            .where(JobStageModel.job_id == job_id)
            .order_by(JobStageModel.started_at.asc().nulls_last())
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_by_flow_run_id(self, flow_run_id: str) -> JobStageModel | None:
        stmt = sa.select(JobStageModel).where(
            JobStageModel.prefect_flow_run_id == flow_run_id
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_running_stages(self) -> list[JobStageModel]:
        stmt = sa.select(JobStageModel).where(
            JobStageModel.status == "running",
            JobStageModel.prefect_flow_run_id.isnot(None),
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_completed_unchained_stages(self) -> list[JobStageModel]:
        """Get completed extraction/processing stages where the next stage
        has NOT been triggered yet (no row exists for the downstream stage)."""
        from sqlalchemy.orm import aliased

        NextStage = aliased(JobStageModel)
        _NEXT = {"extraction": "processing", "processing": "storage"}

        results: list[JobStageModel] = []
        for current, downstream in _NEXT.items():
            next_exists = (
                sa.select(sa.literal(1))
                .where(
                    NextStage.job_id == JobStageModel.job_id,
                    NextStage.stage == downstream,
                )
                .correlate(JobStageModel)
                .exists()
            )
            stmt = sa.select(JobStageModel).where(
                JobStageModel.status == "completed",
                JobStageModel.stage == current,
                ~next_exists,
            )
            result = await self._session.execute(stmt)
            results.extend(result.scalars().all())
        return results
