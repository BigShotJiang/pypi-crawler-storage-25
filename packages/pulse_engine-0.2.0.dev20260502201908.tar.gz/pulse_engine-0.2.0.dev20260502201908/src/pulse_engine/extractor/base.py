"""Base extractor ABC and supporting types for product extractors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExtractorConfig:
    """Configuration for a product extractor."""

    name: str
    job_type: str
    schedule: str | None = None
    timeout_seconds: int = 3600
    max_retries: int = 3


@dataclass
class ExtractionResult:
    """A single extracted item from a source."""

    raw_content: str
    source_id: str
    source_type: str
    metadata: dict[str, Any] = field(default_factory=dict)


class BaseExtractor(ABC):
    """Abstract base class that all product extractors must implement."""

    @abstractmethod
    def get_config(self) -> ExtractorConfig:
        """Return the static configuration for this extractor."""

    @abstractmethod
    async def extract(
        self, tenant_id: str, parameters: dict[str, Any]
    ) -> list[ExtractionResult]:
        """Run extraction and return a list of results."""

    async def on_success(self, tenant_id: str, results: list[ExtractionResult]) -> None:
        """Hook called after successful extraction. Override for custom behaviour."""

    async def on_failure(self, tenant_id: str, error: Exception) -> None:
        """Hook called after extraction failure. Override for custom behaviour."""
