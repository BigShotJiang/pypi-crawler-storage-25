from __future__ import annotations

import base64
from typing import Any

import httpx
import structlog

from pulse_engine.extractor.base import BaseExtractor
from pulse_engine.extractor.orchestrator.base import (
    BaseOrchestratorAdapter,
    OrchestratorRunStatus,
)

logger = structlog.get_logger(__name__)

# Map Prefect flow-run state types to canonical job statuses
_PREFECT_STATE_MAP: dict[str, str] = {
    "COMPLETED": "completed",
    "FAILED": "failed",
    "CRASHED": "failed",
    "CANCELLED": "cancelled",
    "CANCELLING": "cancelled",
    "RUNNING": "running",
    "PENDING": "pending",
    "SCHEDULED": "pending",
}


class PrefectAdapter(BaseOrchestratorAdapter):
    """Adapter for querying Prefect server API."""

    def __init__(self, api_url: str, api_key: str | None = None) -> None:
        self._api_url = api_url.rstrip("/")
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            encoded = base64.b64encode(api_key.encode()).decode()
            headers["Authorization"] = f"Basic {encoded}"
        self._client = httpx.AsyncClient(
            base_url=self._api_url, headers=headers, timeout=10.0
        )

    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        try:
            resp = await self._client.get(f"/flow_runs/{run_id}")
            resp.raise_for_status()
            data = resp.json()
            raw_state = data.get("state", {}).get("type", "UNKNOWN")
            canonical = _PREFECT_STATE_MAP.get(raw_state.upper(), "unknown")
            return OrchestratorRunStatus(
                run_id=run_id, status=canonical, raw_state=raw_state
            )
        except Exception:
            logger.warning("prefect_status_fetch_failed", run_id=run_id, exc_info=True)
            return OrchestratorRunStatus(run_id=run_id, status="unknown")

    async def cancel_run(self, run_id: str) -> bool:
        try:
            resp = await self._client.post(
                f"/flow_runs/{run_id}/set_state",
                json={"state": {"type": "CANCELLED"}},
            )
            return resp.is_success
        except Exception:
            logger.warning("prefect_cancel_failed", run_id=run_id, exc_info=True)
            return False

    async def health_check(self) -> bool:
        try:
            resp = await self._client.get("/health")
            return resp.is_success
        except Exception:
            return False

    async def register_extractors(
        self,
        extractors: list[type[BaseExtractor]],
        pipeline: Any = None,
    ) -> list[str]:
        """Create Prefect deployments for each registered extractor.

        Returns a list of deployment IDs created.
        """
        deployment_ids: list[str] = []
        for ext_cls in extractors:
            ext = ext_cls()
            config = ext.get_config()
            payload: dict[str, Any] = {
                "name": config.name,
                "flow_name": f"extract_{config.job_type}",
                "parameters": {
                    "extractor_cls": f"{ext_cls.__module__}.{ext_cls.__qualname__}",
                },
                "tags": ["pulse-engine", config.job_type],
            }
            if config.schedule:
                payload["schedule"] = {"cron": config.schedule}

            try:
                resp = await self._client.post("/deployments/", json=payload)
                resp.raise_for_status()
                dep_id = resp.json().get("id", "")
                deployment_ids.append(dep_id)
                logger.info(
                    "extractor_registered",
                    extractor=config.name,
                    job_type=config.job_type,
                    deployment_id=dep_id,
                )
            except Exception:
                logger.warning(
                    "extractor_registration_failed",
                    extractor=config.name,
                    exc_info=True,
                )

        return deployment_ids

    async def _get_or_create_flow_id(self, flow_name: str) -> str:
        """Return the UUID of a Prefect flow, creating it if it doesn't exist."""
        resp = await self._client.post("/flows/", json={"name": flow_name})
        resp.raise_for_status()
        return str(resp.json()["id"])

    async def create_or_update_deployment(
        self,
        name: str,
        flow_entrypoint: str,
        image: str,
        work_pool_name: str = "products-worker-pool",
    ) -> tuple[str, str]:
        """Create or update a Prefect deployment.

        Returns (deployment_id, deployment_name).
        """
        flow_id = await self._get_or_create_flow_id(name)
        payload: dict[str, Any] = {
            "name": name,
            "flow_id": flow_id,
            "entrypoint": flow_entrypoint,
            "work_pool_name": work_pool_name,
            "job_variables": {"image": image},
        }
        resp = await self._client.post("/deployments/", json=payload)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["id"]), str(data.get("name", name))

    async def create_flow_run(
        self,
        deployment_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        """Trigger a flow run from a deployment. Returns the flow run ID."""
        payload: dict[str, Any] = {}
        if parameters:
            payload["parameters"] = parameters
        resp = await self._client.post(
            f"/deployments/{deployment_id}/create_flow_run",
            json=payload,
        )
        resp.raise_for_status()
        return str(resp.json()["id"])
