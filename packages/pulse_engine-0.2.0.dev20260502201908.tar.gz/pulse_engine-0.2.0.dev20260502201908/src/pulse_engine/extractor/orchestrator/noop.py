import uuid
from typing import Any

from pulse_engine.extractor.orchestrator.base import (
    BaseOrchestratorAdapter,
    OrchestratorRunStatus,
)


class NoopAdapter(BaseOrchestratorAdapter):
    """No-op adapter used when no orchestrator is configured."""

    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        return OrchestratorRunStatus(run_id=run_id, status="unknown")

    async def cancel_run(self, run_id: str) -> bool:
        return False

    async def health_check(self) -> bool:
        return True

    async def create_flow_run(
        self,
        deployment_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        return ""

    async def create_or_update_deployment(
        self,
        name: str,
        flow_entrypoint: str,
        image: str,
        work_pool_name: str = "products-worker-pool",
    ) -> tuple[str, str]:
        """Return a generated ID and the name — no actual orchestrator registration."""
        return str(uuid.uuid4()), name
