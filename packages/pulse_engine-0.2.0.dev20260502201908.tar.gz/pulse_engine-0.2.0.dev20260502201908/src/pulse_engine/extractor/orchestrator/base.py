from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class OrchestratorRunStatus:
    run_id: str
    status: str  # pending, running, completed, failed, cancelled, unknown
    raw_state: str | None = None


class BaseOrchestratorAdapter(ABC):
    """Abstraction over any external job orchestrator (Prefect, Airflow, etc.)."""

    @abstractmethod
    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        """Fetch the current status of an orchestrator run by its external ID."""

    @abstractmethod
    async def cancel_run(self, run_id: str) -> bool:
        """Request cancellation of an orchestrator run."""

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the orchestrator is reachable."""

    @abstractmethod
    async def create_flow_run(
        self,
        deployment_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        """Create a new flow run for the given deployment and return its run ID."""
