from pulse_engine.config import Settings
from pulse_engine.extractor.orchestrator.base import BaseOrchestratorAdapter
from pulse_engine.extractor.orchestrator.noop import NoopAdapter


def get_orchestrator_adapter(settings: Settings) -> BaseOrchestratorAdapter:
    backend = settings.pulse_orchestrator_backend.lower()
    if backend == "prefect":
        from pulse_engine.extractor.orchestrator.prefect import PrefectAdapter

        return PrefectAdapter(
            api_url=settings.prefect_api_url,
            api_key=settings.prefect_api_key or None,
        )
    return NoopAdapter()
