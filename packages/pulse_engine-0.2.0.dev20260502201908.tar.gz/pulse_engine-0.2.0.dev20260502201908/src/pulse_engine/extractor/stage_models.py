"""Per-stage tracking model for pipeline jobs."""

import uuid
from datetime import datetime

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from pulse_engine.database import Base


class JobStageModel(Base):
    __tablename__ = "job_stages"

    id: Mapped[str] = mapped_column(
        sa.String, primary_key=True, default=lambda: str(uuid.uuid4())
    )
    job_id: Mapped[str] = mapped_column(
        sa.String, sa.ForeignKey("job_records.job_id"), nullable=False, index=True
    )
    stage: Mapped[str] = mapped_column(sa.String(50), nullable=False)
    status: Mapped[str] = mapped_column(
        sa.String(50), nullable=False, default="pending"
    )
    prefect_flow_run_id: Mapped[str | None] = mapped_column(
        sa.String(255), nullable=True, default=None
    )
    started_at: Mapped[datetime | None] = mapped_column(
        sa.DateTime, nullable=True, default=None
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        sa.DateTime, nullable=True, default=None
    )
    error: Mapped[str | None] = mapped_column(sa.Text, nullable=True, default=None)

    __table_args__ = (sa.Index("ix_job_stages_job_id_stage", "job_id", "stage"),)
