import time as _time
from dataclasses import dataclass
from typing import Any, Protocol

import httpx
from jose import JWTError, jwt

from pulse_engine.core.exceptions import UnauthorizedError
from pulse_engine.core.job_token import JobClaims

_JWKS_TTL_SECONDS = 3600  # Re-fetch JWKS every hour


@dataclass
class CognitoClaims:
    sub: str
    email: str
    tenant_id: str
    raw: dict[str, Any]


class TokenVerifier(Protocol):
    async def verify(self, token: str) -> CognitoClaims | JobClaims: ...


class CognitoTokenVerifier:
    def __init__(self, jwks_url: str, issuer: str, audience: str) -> None:
        self._jwks_url = jwks_url
        self._issuer = issuer
        self._audience = audience
        self._jwks: dict[str, Any] | None = None
        self._jwks_fetched_at: float = 0.0

    async def _get_jwks(self, *, force_refresh: bool = False) -> dict[str, Any]:
        """Return cached JWKS, refreshing when the TTL has elapsed or forced."""
        now = _time.monotonic()
        if (
            self._jwks is None
            or force_refresh
            or (now - self._jwks_fetched_at) > _JWKS_TTL_SECONDS
        ):
            async with httpx.AsyncClient() as client:
                resp = await client.get(self._jwks_url)
                resp.raise_for_status()
                self._jwks = resp.json()
                self._jwks_fetched_at = now
        assert self._jwks is not None  # guaranteed by the branch above
        return self._jwks

    async def verify(self, token: str) -> CognitoClaims:
        try:
            jwks = await self._get_jwks()
            unverified_header = jwt.get_unverified_header(token)
            kid = unverified_header.get("kid")
            key = self._find_key(jwks, kid)

            # On key miss, attempt a one-time forced refresh (handles key rotation)
            if key is None:
                jwks = await self._get_jwks(force_refresh=True)
                key = self._find_key(jwks, kid)

            if key is None:
                raise UnauthorizedError("Invalid token: signing key not found")

            payload = jwt.decode(
                token,
                key,
                algorithms=["RS256"],
                audience=self._audience,
                issuer=self._issuer,
            )
        except JWTError as e:
            raise UnauthorizedError("Invalid token") from e

        tenant_id = payload.get("custom:tenant_id")
        if not tenant_id:
            raise UnauthorizedError("Token missing tenant_id claim")

        return CognitoClaims(
            sub=payload.get("sub", ""),
            email=payload.get("email", ""),
            tenant_id=tenant_id,
            raw=payload,
        )

    @staticmethod
    def _find_key(jwks: dict[str, Any], kid: str | None) -> dict[str, Any] | None:
        for k in jwks.get("keys", []):
            if k.get("kid") == kid:
                return k  # type: ignore[no-any-return]
        return None


class MockTokenVerifier:
    def __init__(self, secret: str, audience: str, issuer: str) -> None:
        self._secret = secret
        self._audience = audience
        self._issuer = issuer

    async def verify(self, token: str) -> CognitoClaims:
        try:
            payload = jwt.decode(
                token,
                self._secret,
                algorithms=["HS256"],
                audience=self._audience,
                issuer=self._issuer,
            )
        except JWTError as e:
            raise UnauthorizedError("Invalid token") from e

        tenant_id = payload.get("custom:tenant_id")
        if not tenant_id:
            raise UnauthorizedError("Token missing tenant_id claim")

        return CognitoClaims(
            sub=payload.get("sub", ""),
            email=payload.get("email", ""),
            tenant_id=tenant_id,
            raw=payload,
        )


def extract_bearer_token(authorization: str | None) -> str:
    if not authorization:
        raise UnauthorizedError("Missing authorization header")
    parts = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise UnauthorizedError("Invalid authorization header format")
    return parts[1]
