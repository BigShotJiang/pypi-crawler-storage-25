from typing import Any


class AppError(Exception):
    status_code: int = 500
    is_operational: bool = True

    def __init__(self, message: str = "Internal server error", **context: Any) -> None:
        self.message = message
        self.context = context
        super().__init__(message)


class BadRequestError(AppError):
    status_code = 400

    def __init__(self, message: str = "Bad request", **context: Any) -> None:
        super().__init__(message, **context)


class UnauthorizedError(AppError):
    status_code = 401

    def __init__(self, message: str = "Unauthorized", **context: Any) -> None:
        super().__init__(message, **context)


class ForbiddenError(AppError):
    status_code = 403

    def __init__(self, message: str = "Forbidden", **context: Any) -> None:
        super().__init__(message, **context)


class NotFoundError(AppError):
    status_code = 404

    def __init__(self, message: str = "Not found", **context: Any) -> None:
        super().__init__(message, **context)


class ConflictError(AppError):
    status_code = 409

    def __init__(self, message: str = "Conflict", **context: Any) -> None:
        super().__init__(message, **context)


class UnprocessableEntityError(AppError):
    status_code = 422

    def __init__(self, message: str = "Unprocessable entity", **context: Any) -> None:
        super().__init__(message, **context)


class TooManyRequestsError(AppError):
    status_code = 429

    def __init__(self, message: str = "Too many requests", **context: Any) -> None:
        super().__init__(message, **context)


class ServiceUnavailableError(AppError):
    status_code = 503

    def __init__(self, message: str = "Service unavailable", **context: Any) -> None:
        super().__init__(message, **context)
