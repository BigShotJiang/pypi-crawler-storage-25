# src/pulse_engine/core/job_token.py
"""Job-scoped JWT issuance and verification for container callbacks."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from jose import JWTError, jwt

from pulse_engine.core.exceptions import UnauthorizedError

_ALGORITHM = "HS256"
_DEFAULT_TTL = 86400  # 24 hours


@dataclass
class JobClaims:
    """Claims extracted from a job-scoped JWT."""

    sub: str  # "job:{job_id}"
    tenant_id: str
    product: str
    stage: str  # "extraction" | "processing" | "storage"
    scope: list[str]
    orchestrator: str = "prefect"
    compute: str = "ecs"
    raw: dict[str, Any] = field(default_factory=dict)


class JobTokenIssuer:
    """Issues HMAC-signed JWTs scoped to a single job stage."""

    def __init__(self, secret: str) -> None:
        self._secret = secret

    def issue(
        self,
        job_id: str,
        tenant_id: str,
        product: str,
        stage: str,
        scope: list[str],
        orchestrator: str = "prefect",
        compute: str = "ecs",
        ttl_seconds: int = _DEFAULT_TTL,
    ) -> str:
        now = int(time.time())
        payload: dict[str, Any] = {
            "sub": f"job:{job_id}",
            "custom:tenant_id": tenant_id,
            "product": product,
            "stage": stage,
            "scope": scope,
            "orchestrator": orchestrator,
            "compute": compute,
            "iat": now,
            "exp": now + ttl_seconds,
        }
        return jwt.encode(payload, self._secret, algorithm=_ALGORITHM)

    def issue_token(
        self,
        pipeline_run_id: str,
        tenant_id: str,
        ttl_seconds: int = _DEFAULT_TTL,
    ) -> str:
        """Issue a run-scoped token for pipeline orchestration."""
        return self.issue(
            job_id=pipeline_run_id,
            tenant_id=tenant_id,
            product="pipeline",
            stage="pipeline",
            scope=["pipeline:run"],
            ttl_seconds=ttl_seconds,
        )


class JobTokenVerifier:
    """Verifies HMAC-signed job-scoped JWTs."""

    def __init__(self, secret: str) -> None:
        self._secret = secret

    async def verify(self, token: str) -> JobClaims:
        try:
            payload = jwt.decode(token, self._secret, algorithms=[_ALGORITHM])
        except JWTError as e:
            raise UnauthorizedError(f"Invalid token: {e}") from e

        sub = payload.get("sub", "")
        if not sub.startswith("job:"):
            raise UnauthorizedError("Not a job-scoped token")

        tenant_id = payload.get("custom:tenant_id")
        if not tenant_id:
            raise UnauthorizedError("Token missing tenant_id claim")

        return JobClaims(
            sub=sub,
            tenant_id=tenant_id,
            product=payload.get("product", ""),
            stage=payload.get("stage", ""),
            scope=payload.get("scope", []),
            orchestrator=payload.get("orchestrator", "prefect"),
            compute=payload.get("compute", "ecs"),
            raw=payload,
        )
