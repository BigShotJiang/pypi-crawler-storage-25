"""Scope enforcement for job-scoped tokens."""

from typing import Any

from fastapi import Depends, Request

from pulse_engine.core.exceptions import ForbiddenError
from pulse_engine.core.job_token import JobClaims


def require_scope(scope: str) -> Any:
    """FastAPI dependency that enforces scope on job-scoped tokens.

    Cognito-authenticated requests bypass the check (no scope field).
    """

    def _check(request: Request) -> None:
        claims = getattr(request.state, "user_claims", None)
        if isinstance(claims, JobClaims):
            if scope not in claims.scope:
                raise ForbiddenError(f"Token missing required scope: {scope}")

    return Depends(_check)
