import structlog
from fastapi import Request
from jose import jwt as jose_jwt
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

from pulse_engine.core.exceptions import UnauthorizedError
from pulse_engine.core.job_token import JobClaims
from pulse_engine.core.security import (
    CognitoClaims,
    TokenVerifier,
    extract_bearer_token,
)

logger = structlog.get_logger()

PUBLIC_PATHS = {
    "/api/v1/health",
    "/api/v1/auth/login",
    # OpenAPI/Swagger docs — only reachable in non-production environments
    # because create_app() sets docs_url/redoc_url/openapi_url to None in production.
    "/docs",
    "/docs/oauth2-redirect",
    "/openapi.json",
    "/redoc",
}


class TenantMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app: ASGIApp,
        verifier: TokenVerifier,
        job_token_secret: str = "",
    ) -> None:
        super().__init__(app)
        self._verifier = verifier
        self._job_token_secret = job_token_secret

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        if request.url.path in PUBLIC_PATHS:
            return await call_next(request)

        try:
            token = extract_bearer_token(request.headers.get("authorization"))
            claims = await self._resolve_token(token)
            request.state.tenant_id = claims.tenant_id
            request.state.user_claims = claims
        except UnauthorizedError as e:
            request_id = getattr(request.state, "request_id", "unknown")
            return JSONResponse(
                status_code=401,
                content={
                    "success": False,
                    "error": e.message,
                    "request_id": request_id,
                },
            )

        return await call_next(request)

    async def _resolve_token(self, token: str) -> CognitoClaims | JobClaims:
        """Dispatch to job-token or Cognito verifier based on sub prefix."""
        if self._job_token_secret:
            try:
                unverified = jose_jwt.get_unverified_claims(token)
                sub = unverified.get("sub", "")
                if sub.startswith("job:"):
                    from pulse_engine.core.job_token import JobTokenVerifier

                    verifier = JobTokenVerifier(secret=self._job_token_secret)
                    return await verifier.verify(token)
            except UnauthorizedError:
                raise
            except Exception as exc:
                logger.debug(
                    "job_token_parse_failed_falling_back_to_cognito",
                    error=str(exc),
                )
        return await self._verifier.verify(token)


def get_tenant_id(request: Request) -> str:
    tenant_id: str | None = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise UnauthorizedError("Tenant context not available")
    return tenant_id
