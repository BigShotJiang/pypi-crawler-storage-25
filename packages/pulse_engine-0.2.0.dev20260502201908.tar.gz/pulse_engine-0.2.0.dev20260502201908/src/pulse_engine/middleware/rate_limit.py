"""In-memory sliding-window rate limiter.

Provides per-key rate limiting without external dependencies.  Suitable for
single-instance deployments; for multi-instance, swap the storage backend
to Redis.
"""

from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


class _SlidingWindowCounter:
    """Thread-safe sliding-window counter."""

    def __init__(self) -> None:
        self._windows: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def hit(self, key: str, max_requests: int, window_seconds: int) -> bool:
        """Record a hit and return True if under the limit, False if exceeded."""
        now = time.monotonic()
        cutoff = now - window_seconds

        with self._lock:
            timestamps = self._windows[key]
            # Prune expired entries
            self._windows[key] = timestamps = [t for t in timestamps if t > cutoff]
            if len(timestamps) >= max_requests:
                return False
            timestamps.append(now)
            return True

    def remaining(self, key: str, max_requests: int, window_seconds: int) -> int:
        """Return remaining requests in the current window."""
        now = time.monotonic()
        cutoff = now - window_seconds

        with self._lock:
            timestamps = self._windows[key]
            active = [t for t in timestamps if t > cutoff]
            return max(0, max_requests - len(active))

    def reset(self) -> None:
        """Clear all counters — intended for use in tests only."""
        with self._lock:
            self._windows.clear()


# Global singleton — shared across middleware and endpoint decorators
_counter = _SlidingWindowCounter()


def _client_ip(request: Request) -> str:
    """Extract the client IP, respecting X-Forwarded-For behind a proxy."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    client = request.client
    return client.host if client else "unknown"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Global per-IP rate limiting middleware.

    Args:
        app: ASGI application.
        max_requests: Maximum requests per window (default 100).
        window_seconds: Window duration in seconds (default 60).
        counter: Optional counter instance; defaults to the shared module-level
            singleton.  Pass a fresh ``_SlidingWindowCounter()`` in tests to
            keep state isolated between test cases.
    """

    def __init__(
        self,
        app: Any,
        max_requests: int = 100,
        window_seconds: int = 60,
        counter: _SlidingWindowCounter | None = None,
    ) -> None:
        super().__init__(app)
        self._max = max_requests
        self._window = window_seconds
        self._counter = counter if counter is not None else _counter

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        key = f"global:{_client_ip(request)}"
        allowed = self._counter.hit(key, self._max, self._window)
        remaining = self._counter.remaining(key, self._max, self._window)

        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "success": False,
                    "error": "Rate limit exceeded. Try again later.",
                },
                headers={
                    "Retry-After": str(self._window),
                    "X-RateLimit-Limit": str(self._max),
                    "X-RateLimit-Remaining": "0",
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(self._max)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response


def check_rate_limit(
    request: Request,
    *,
    scope: str,
    max_requests: int,
    window_seconds: int,
) -> None:
    """Check rate limit for a specific scope.  Raises 429 via JSONResponse.

    Usage in endpoints::

        @router.post("/login")
        async def login(request: Request, body: LoginRequest):
            check_rate_limit(request, scope="login", max_requests=5, window_seconds=60)
            ...
    """
    key = f"{scope}:{_client_ip(request)}"
    allowed = _counter.hit(key, max_requests, window_seconds)
    if not allowed:
        from pulse_engine.core.exceptions import TooManyRequestsError

        raise TooManyRequestsError(
            f"Too many requests. Try again in {window_seconds} seconds."
        )
