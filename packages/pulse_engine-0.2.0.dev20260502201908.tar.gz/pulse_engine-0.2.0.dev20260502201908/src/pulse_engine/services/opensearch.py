from typing import Any

import structlog
from opensearchpy import AsyncOpenSearch

logger = structlog.get_logger()


class OpenSearchService:
    def __init__(
        self,
        url: str,
        http_auth: tuple[str, str] | None = None,
        use_ssl: bool = False,
        verify_certs: bool = True,
        ssl_show_warn: bool = True,
    ) -> None:
        hosts = [url]
        kwargs: dict[str, Any] = {
            "hosts": hosts,
            "use_ssl": use_ssl,
            "verify_certs": verify_certs,
            "ssl_show_warn": ssl_show_warn,
        }
        if http_auth:
            kwargs["http_auth"] = http_auth

        self._client = AsyncOpenSearch(**kwargs)

    async def ping(self) -> bool:
        try:
            return bool(await self._client.ping())
        except Exception:
            logger.warning("opensearch_ping_failed")
            return False

    async def index_document(
        self, index: str, doc_id: str | None, body: dict[str, Any]
    ) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.index(
            index=index, id=doc_id, body=body
        )
        return result

    async def get_document(self, index: str, doc_id: str) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.get(index=index, id=doc_id)
        return result

    async def search(self, index: str, query: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.search(index=index, body=query)
        return result

    async def delete_document(self, index: str, doc_id: str) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.delete(index=index, id=doc_id)
        return result

    async def create_index(
        self, index: str, body: dict[str, Any]
    ) -> dict[str, Any] | None:
        if await self._client.indices.exists(index=index):
            logger.info("index_already_exists", index=index)
            return None
        result: dict[str, Any] = await self._client.indices.create(
            index=index, body=body
        )
        return result

    async def delete_index(self, index: str) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.indices.delete(index=index)
        return result

    async def bulk(self, body: list[dict[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.bulk(body=body)
        return result

    async def index_stats(self, index: str) -> dict[str, Any]:
        result: dict[str, Any] = await self._client.indices.stats(index=index)
        return result

    async def index_exists(self, index: str) -> bool:
        return bool(await self._client.indices.exists(index=index))

    async def close(self) -> None:
        await self._client.close()
