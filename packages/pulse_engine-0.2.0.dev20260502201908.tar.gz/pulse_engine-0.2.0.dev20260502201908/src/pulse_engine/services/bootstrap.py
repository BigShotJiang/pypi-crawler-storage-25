"""Shared service initialization for FastAPI and MCP entry points."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from types import EllipsisType
from typing import TYPE_CHECKING, Any

import boto3

from pulse_engine.config import Settings
from pulse_engine.core.logging import setup_logging
from pulse_engine.database import build_async_engine, build_session_factory
from pulse_engine.extractor.orchestrator import get_orchestrator_adapter
from pulse_engine.processor.base import (
    BaseCoreProcessor,
    BasePostprocessor,
    BasePreprocessor,
)
from pulse_engine.processor.pipeline import _SENTINEL, ProcessingPipeline
from pulse_engine.services.opensearch import OpenSearchService
from pulse_engine.storage.connectors.athena import AthenaConnector
from pulse_engine.storage.connectors.opensearch import OpenSearchConnector
from pulse_engine.storage.knowledge_base import KnowledgeBaseService

if TYPE_CHECKING:
    from celery import Celery
    from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

    from pulse_engine.extractor.orchestrator.base import BaseOrchestratorAdapter
    from pulse_engine.registry import ProductManifest


@dataclass
class ServiceContainer:
    settings: Settings
    opensearch: OpenSearchService
    kb_service: KnowledgeBaseService
    db_session_factory: async_sessionmaker[AsyncSession] | None
    orchestrator_adapter: BaseOrchestratorAdapter
    pipeline: ProcessingPipeline | None = None
    celery_app: Celery | None = None
    s3_client: Any = None
    token_issuer: Any = None
    pipeline_translators: dict[str, Any] = field(default_factory=dict)
    pipeline_status_providers: dict[str, Any] = field(default_factory=dict)
    _engine: AsyncEngine | None = field(default=None, repr=False)
    _opensearch_connector: OpenSearchConnector | None = field(default=None, repr=False)
    _athena_connector: AthenaConnector | None = field(default=None, repr=False)


def _resolve_stage(
    value: Any,
) -> Any:
    """Convert manifest Ellipsis convention into pipeline sentinel."""
    if isinstance(value, EllipsisType):
        return _SENTINEL
    return value


def _build_celery(
    settings: Settings, manifest: ProductManifest | None = None
) -> Celery:
    from pulse_engine.worker import create_celery_app

    return create_celery_app(settings, manifest)


@asynccontextmanager
async def bootstrap_services(
    settings: Settings,
    manifest: ProductManifest | None = None,
) -> AsyncIterator[ServiceContainer]:
    setup_logging(log_level=settings.log_level, env=settings.app_env)

    # OpenSearch — connect with auth if credentials provided
    http_auth: tuple[str, str] | None = None
    if settings.opensearch_username and settings.opensearch_password:
        http_auth = (settings.opensearch_username, settings.opensearch_password)

    opensearch = OpenSearchService(
        url=settings.opensearch_url,
        http_auth=http_auth,
        use_ssl=settings.opensearch_use_ssl,
        verify_certs=settings.opensearch_verify_certs,
    )

    opensearch_connector = OpenSearchConnector(
        opensearch,
        settings.embedding_dimension,
        index_prefix=settings.opensearch_index_prefix,
    )
    await opensearch_connector.initialize()

    # Athena — uses its own AWS credentials; product specifies the database
    athena_connector: AthenaConnector | None = None
    if settings.athena_output_location:
        athena_kwargs: dict[str, str] = {"region_name": settings.aws_region}
        if settings.athena_aws_access_key_id:
            athena_kwargs["aws_access_key_id"] = settings.athena_aws_access_key_id
            athena_kwargs["aws_secret_access_key"] = (
                settings.athena_aws_secret_access_key
            )
        athena_client = boto3.client("athena", **athena_kwargs)  # type: ignore[call-overload]
        athena_connector = AthenaConnector(
            athena_client=athena_client,
            database=manifest.athena_database if manifest else "",
            output_location=settings.athena_output_location,
            workgroup=settings.athena_workgroup,
            query_timeout_seconds=settings.athena_query_timeout_seconds,
        )
        await athena_connector.initialize()

    kb_service = KnowledgeBaseService(opensearch_connector, athena_connector)

    engine = None
    db_session_factory = None
    if settings.database_url:
        engine = build_async_engine(settings.database_url)
        db_session_factory = build_session_factory(engine)

    orchestrator_adapter = get_orchestrator_adapter(settings)

    # Celery / Redis
    celery_app = _build_celery(settings, manifest) if settings.redis_url else None

    # S3 client for inter-stage data
    s3_client = None
    if settings.pulse_s3_bucket:
        s3_client = boto3.client(
            "s3",
            region_name=settings.aws_region,
            aws_access_key_id=settings.aws_access_key_id or None,
            aws_secret_access_key=settings.aws_secret_access_key or None,
        )

    # Job token issuer
    token_issuer = None
    if settings.pulse_job_token_secret:
        from pulse_engine.core.job_token import JobTokenIssuer

        token_issuer = JobTokenIssuer(
            secret=settings.pulse_job_token_secret,
        )

    # Pipeline orchestration translators and status providers
    pipeline_translators: dict[str, Any] = {}
    pipeline_status_providers: dict[str, Any] = {}
    if settings.prefect_api_url:
        from pulse_engine.pipeline.translators.prefect_status import (
            PrefectStatusProvider,
        )
        from pulse_engine.pipeline.translators.prefect_translator import (
            PrefectTranslator,
        )

        pipeline_translators["prefect"] = PrefectTranslator(
            prefect_api_url=settings.prefect_api_url,
            prefect_api_key=settings.prefect_api_key,
            work_pool_name=settings.prefect_ecs_work_pool_name,
            engine_image=settings.prefect_engine_image,
        )
        pipeline_status_providers["prefect"] = PrefectStatusProvider(
            prefect_api_url=settings.prefect_api_url,
            prefect_api_key=settings.prefect_api_key,
        )

    # Build pluggable pipeline
    pre: BasePreprocessor | None = _SENTINEL
    core: BaseCoreProcessor | None = _SENTINEL
    post: BasePostprocessor | None = _SENTINEL
    if manifest:
        pre = _resolve_stage(manifest.preprocessor)
        core = _resolve_stage(manifest.core_processor)
        post = _resolve_stage(manifest.postprocessor)

    pipeline = ProcessingPipeline(
        kb_service=kb_service,
        preprocessor=pre,
        core_processor=core,
        postprocessor=post,
    )

    container = ServiceContainer(
        settings=settings,
        opensearch=opensearch,
        kb_service=kb_service,
        db_session_factory=db_session_factory,
        orchestrator_adapter=orchestrator_adapter,
        pipeline=pipeline,
        celery_app=celery_app,
        s3_client=s3_client,
        token_issuer=token_issuer,
        pipeline_translators=pipeline_translators,
        pipeline_status_providers=pipeline_status_providers,
        _engine=engine,
        _opensearch_connector=opensearch_connector,
        _athena_connector=athena_connector,
    )

    try:
        yield container
    finally:
        if engine:
            await engine.dispose()
        await opensearch_connector.teardown()
        if athena_connector:
            await athena_connector.teardown()
        await opensearch.close()
