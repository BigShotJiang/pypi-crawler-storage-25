from fastapi import APIRouter, Depends
from starlette.responses import JSONResponse

from pulse_engine.core.scope import require_scope
from pulse_engine.dependencies import get_knowledge_base
from pulse_engine.middleware.tenant import get_tenant_id
from pulse_engine.storage.knowledge_base import KnowledgeBaseService
from pulse_engine.storage.schemas import (
    Document,
    KBStatsResponse,
    QueryRequest,
    QueryResult,
    SearchQuery,
    SearchResult,
    StoreRequest,
    StoreResult,
)

router = APIRouter(prefix="/kb", tags=["Knowledge Base"])


@router.post(
    "/documents",
    response_model=StoreResult,
    status_code=201,
    dependencies=[require_scope("kb:write")],
)
async def store_documents(
    body: StoreRequest,
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> StoreResult:
    return await kb.store_documents(tenant_id, body.documents)


@router.get("/documents/{document_id}", response_model=Document)
async def retrieve_document(
    document_id: str,
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> Document:
    return await kb.retrieve_document(tenant_id, document_id)


@router.post("/search", response_model=SearchResult)
async def search_documents(
    body: SearchQuery,
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> SearchResult:
    return await kb.search(tenant_id, body)


@router.delete("/documents/{document_id}", status_code=204)
async def delete_document(
    document_id: str,
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> JSONResponse:
    await kb.delete_document(tenant_id, document_id)
    return JSONResponse(status_code=204, content=None)


@router.get("/stats", response_model=KBStatsResponse)
async def get_stats(
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> KBStatsResponse:
    return await kb.get_stats(tenant_id)


@router.post("/query", response_model=QueryResult)
async def run_query(
    body: QueryRequest,
    tenant_id: str = Depends(get_tenant_id),
    kb: KnowledgeBaseService = Depends(get_knowledge_base),
) -> QueryResult:
    return await kb.execute_query(tenant_id, body.sql, body.parameters)
