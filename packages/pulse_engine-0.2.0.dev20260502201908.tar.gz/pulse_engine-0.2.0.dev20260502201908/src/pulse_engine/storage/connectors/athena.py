import asyncio
import re
import time
from typing import Any

import structlog

from pulse_engine.core.exceptions import (
    AppError,
    BadRequestError,
    ServiceUnavailableError,
)
from pulse_engine.storage.connectors.base import BaseStorageConnector
from pulse_engine.storage.schemas import (
    ConnectorHealth,
    Document,
    QueryResult,
    SearchQuery,
    SearchResult,
    StoreResult,
)

logger = structlog.get_logger()

_TENANT_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,128}$")

# SQL keywords that are forbidden in user-supplied queries
_FORBIDDEN_SQL_RE = re.compile(
    r"""
    \b(
        INSERT\s+INTO | UPDATE\s+\S+\s+SET | DELETE\s+FROM |
        DROP\s+(TABLE|DATABASE|INDEX|VIEW|SCHEMA) |
        ALTER\s+(TABLE|DATABASE|INDEX|VIEW|SCHEMA) |
        CREATE\s+(TABLE|DATABASE|INDEX|VIEW|SCHEMA) |
        TRUNCATE | GRANT | REVOKE | EXEC | EXECUTE |
        MERGE\s+INTO | CALL
    )\b
    """,
    re.IGNORECASE | re.VERBOSE,
)

# Detect multiple SQL statements (semicolons not inside string literals)
_MULTI_STATEMENT_RE = re.compile(r";\s*\S")

# Detect UNION-based injection attempts
_UNION_RE = re.compile(r"\bUNION\b\s+(ALL\s+)?\bSELECT\b", re.IGNORECASE)


class AthenaConnector(BaseStorageConnector):
    def __init__(
        self,
        athena_client: Any,
        database: str,
        output_location: str,
        workgroup: str = "primary",
        query_timeout_seconds: int = 60,
    ) -> None:
        self._client = athena_client
        self._database = database
        self._output_location = output_location
        self._workgroup = workgroup
        self._query_timeout = query_timeout_seconds

    async def initialize(self) -> None:
        logger.info("athena_connector_initialized")

    async def store(self, tenant_id: str, documents: list[Document]) -> StoreResult:
        raise NotImplementedError("Athena connector does not support store operations")

    async def retrieve(self, tenant_id: str, doc_id: str) -> Document | None:
        raise NotImplementedError(
            "Athena connector does not support retrieve operations"
        )

    async def search(self, tenant_id: str, query: SearchQuery) -> SearchResult:
        raise NotImplementedError("Athena connector does not support search operations")

    @staticmethod
    def _validate_sql(sql: str) -> None:
        """Reject dangerous SQL patterns before execution.

        Only SELECT statements are permitted. DDL, DML mutations,
        multi-statement payloads, and UNION injections are blocked.
        """
        stripped = sql.strip().rstrip(";").strip()

        if not stripped.upper().startswith("SELECT"):
            raise BadRequestError("Only SELECT queries are allowed against Athena")

        if _FORBIDDEN_SQL_RE.search(stripped):
            raise BadRequestError("Query contains forbidden SQL keywords")

        if _MULTI_STATEMENT_RE.search(stripped):
            raise BadRequestError("Multiple SQL statements are not allowed")

        if _UNION_RE.search(stripped):
            raise BadRequestError("UNION SELECT queries are not allowed")

    @staticmethod
    def _inject_tenant_filter(sql: str, tenant_id: str) -> str:
        if not _TENANT_ID_RE.match(tenant_id):
            raise BadRequestError("Invalid tenant ID format")
        where_pattern = re.compile(r"\bWHERE\b", re.IGNORECASE)
        match = where_pattern.search(sql)
        tenant_clause = f"tenant_id = '{tenant_id}'"

        if match:
            insert_pos = match.end()
            return f"{sql[:insert_pos]} {tenant_clause} AND{sql[insert_pos:]}"
        else:
            order_pattern = re.compile(
                r"\b(ORDER BY|GROUP BY|HAVING|LIMIT)\b", re.IGNORECASE
            )
            order_match = order_pattern.search(sql)
            if order_match:
                insert_pos = order_match.start()
                return f"{sql[:insert_pos]}WHERE {tenant_clause} {sql[insert_pos:]}"
            return f"{sql} WHERE {tenant_clause}"

    async def execute_query(
        self,
        tenant_id: str,
        sql: str,
        parameters: dict[str, Any] | None = None,
        database: str | None = None,
    ) -> QueryResult:
        """Execute an Athena SQL query.

        Args:
            database: The Athena database to query. Products specify this at
                query time; falls back to the connector-level default.
        """
        self._validate_sql(sql)
        filtered_sql = self._inject_tenant_filter(sql, tenant_id)
        target_database = database or self._database

        try:
            start = time.monotonic()
            query_kwargs: dict[str, Any] = {
                "QueryString": filtered_sql,
                "ResultConfiguration": {"OutputLocation": self._output_location},
                "WorkGroup": self._workgroup,
            }
            if target_database:
                query_kwargs["QueryExecutionContext"] = {"Database": target_database}

            response = await asyncio.to_thread(
                self._client.start_query_execution,
                **query_kwargs,
            )
            query_id = response["QueryExecutionId"]

            elapsed = 0.0
            wait = 0.5
            while elapsed < self._query_timeout:
                status_resp = await asyncio.to_thread(
                    self._client.get_query_execution,
                    QueryExecutionId=query_id,
                )
                state = status_resp["QueryExecution"]["Status"]["State"]

                if state == "SUCCEEDED":
                    break
                elif state == "FAILED":
                    reason = status_resp["QueryExecution"]["Status"].get(
                        "StateChangeReason", "Query failed"
                    )
                    logger.error(
                        "athena_query_failed", reason=reason, query_id=query_id
                    )
                    raise AppError("Query execution failed")
                elif state == "CANCELLED":
                    raise AppError("Athena query was cancelled")

                await asyncio.sleep(wait)
                elapsed += wait
                wait = min(wait * 2, 5.0)
            else:
                raise ServiceUnavailableError("Athena query timed out")

            results_resp = await asyncio.to_thread(
                self._client.get_query_results,
                QueryExecutionId=query_id,
            )

            result_set = results_resp["ResultSet"]
            columns = [
                col["Label"] for col in result_set["ResultSetMetadata"]["ColumnInfo"]
            ]

            rows: list[list[Any]] = []
            data_rows = result_set.get("Rows", [])
            for row in data_rows[1:]:
                rows.append([d.get("VarCharValue", "") for d in row["Data"]])

            execution_time_ms = int((time.monotonic() - start) * 1000)

            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time_ms=execution_time_ms,
            )
        except (AppError, ServiceUnavailableError):
            raise
        except Exception as e:
            logger.error("athena_query_error", exc_info=True)
            raise ServiceUnavailableError("Query execution unavailable") from e

    async def delete(self, tenant_id: str, doc_id: str) -> bool:
        raise NotImplementedError("Athena connector does not support delete operations")

    async def health_check(self) -> ConnectorHealth:
        start = time.monotonic()
        try:
            await asyncio.to_thread(self._client.list_work_groups)
            latency = (time.monotonic() - start) * 1000
            return ConnectorHealth(connector="athena", status="up", latency_ms=latency)
        except Exception:
            latency = (time.monotonic() - start) * 1000
            return ConnectorHealth(
                connector="athena", status="down", latency_ms=latency
            )

    async def teardown(self) -> None:
        logger.info("athena_connector_teardown")
