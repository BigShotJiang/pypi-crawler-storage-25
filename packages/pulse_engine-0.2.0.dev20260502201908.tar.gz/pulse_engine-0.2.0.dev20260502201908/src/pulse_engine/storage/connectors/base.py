from abc import ABC, abstractmethod

from pulse_engine.storage.schemas import (
    ConnectorHealth,
    Document,
    SearchQuery,
    SearchResult,
    StoreResult,
)


class BaseStorageConnector(ABC):
    @abstractmethod
    async def initialize(self) -> None: ...

    @abstractmethod
    async def store(self, tenant_id: str, documents: list[Document]) -> StoreResult: ...

    @abstractmethod
    async def retrieve(self, tenant_id: str, doc_id: str) -> Document | None: ...

    @abstractmethod
    async def search(self, tenant_id: str, query: SearchQuery) -> SearchResult: ...

    @abstractmethod
    async def delete(self, tenant_id: str, doc_id: str) -> bool: ...

    @abstractmethod
    async def health_check(self) -> ConnectorHealth: ...

    @abstractmethod
    async def teardown(self) -> None: ...
