from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class DocumentSource(str, Enum):
    speech = "speech"
    tweet = "tweet"
    youtube = "youtube"
    processed = "processed"


class Document(BaseModel):
    doc_id: str
    source: DocumentSource
    chunk_id: str | None = None
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    metadata_chunk: dict[str, Any] = Field(default_factory=dict)
    content_summary: str | None = None
    content_title: str | None = None
    embedding: list[float] | None = None
    content_embeddings: list[float] | None = None
    content_summary_embeddings: list[float] | None = None
    content_title_embeddings: list[float] | None = None


class SearchQueryType(str, Enum):
    text = "text"
    semantic = "semantic"
    hybrid = "hybrid"


class SearchQuery(BaseModel):
    query_type: SearchQueryType = SearchQueryType.text
    query_text: str | None = None
    vector: list[float] | None = None
    filters: dict[str, Any] = Field(default_factory=dict)
    size: int = Field(default=10, ge=1, le=100)
    from_: int = Field(default=0, ge=0, alias="from")

    model_config = {"populate_by_name": True}


class StoreRequest(BaseModel):
    documents: list[Document]


class StoreResult(BaseModel):
    stored_count: int
    failed_count: int
    errors: list[str] = Field(default_factory=list)


class SearchHit(BaseModel):
    doc_id: str
    score: float
    source: DocumentSource
    content: str
    highlights: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SearchResult(BaseModel):
    hits: list[SearchHit]
    total: int
    took_ms: int


class ConnectorHealth(BaseModel):
    connector: str
    status: str = Field(pattern=r"^(up|down|degraded)$")
    latency_ms: float | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class QueryRequest(BaseModel):
    sql: str
    parameters: dict[str, Any] = Field(default_factory=dict)


class QueryResult(BaseModel):
    columns: list[str]
    rows: list[list[Any]]
    row_count: int
    execution_time_ms: int


class KBStatsResponse(BaseModel):
    document_count: int
    index_size_bytes: int
    sources: dict[str, int] = Field(default_factory=dict)
