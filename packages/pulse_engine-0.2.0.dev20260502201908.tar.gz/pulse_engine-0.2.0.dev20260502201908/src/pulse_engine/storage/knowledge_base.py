from typing import Any

import structlog

from pulse_engine.core.exceptions import NotFoundError, ServiceUnavailableError
from pulse_engine.storage.connectors.athena import AthenaConnector
from pulse_engine.storage.connectors.opensearch import OpenSearchConnector
from pulse_engine.storage.schemas import (
    Document,
    KBStatsResponse,
    QueryResult,
    SearchQuery,
    SearchResult,
    StoreResult,
)

logger = structlog.get_logger()


class KnowledgeBaseService:
    def __init__(
        self,
        opensearch_connector: OpenSearchConnector,
        athena_connector: AthenaConnector | None = None,
    ) -> None:
        self._opensearch = opensearch_connector
        self._athena = athena_connector

    async def store_documents(
        self, tenant_id: str, documents: list[Document]
    ) -> StoreResult:
        return await self._opensearch.store(tenant_id, documents)

    async def retrieve_document(self, tenant_id: str, doc_id: str) -> Document:
        result = await self._opensearch.retrieve(tenant_id, doc_id)
        if result is None:
            raise NotFoundError(f"Document {doc_id} not found")
        return result

    async def search(self, tenant_id: str, query: SearchQuery) -> SearchResult:
        return await self._opensearch.search(tenant_id, query)

    async def delete_document(self, tenant_id: str, doc_id: str) -> None:
        deleted = await self._opensearch.delete(tenant_id, doc_id)
        if not deleted:
            raise NotFoundError(f"Document {doc_id} not found")

    async def get_stats(self, tenant_id: str) -> KBStatsResponse:
        index = self._opensearch._index_name(tenant_id)
        try:
            stats = await self._opensearch._opensearch.index_stats(index)
            total = stats.get("_all", {}).get("primaries", {})
            doc_count = total.get("docs", {}).get("count", 0)
            size_bytes = total.get("store", {}).get("size_in_bytes", 0)
            return KBStatsResponse(
                document_count=doc_count,
                index_size_bytes=size_bytes,
            )
        except Exception as e:
            logger.warning("stats_fetch_failed", error=str(e))
            return KBStatsResponse(document_count=0, index_size_bytes=0)

    async def execute_query(
        self, tenant_id: str, sql: str, parameters: dict[str, Any] | None = None
    ) -> QueryResult:
        if self._athena is None:
            raise ServiceUnavailableError("Athena connector is not configured")
        return await self._athena.execute_query(tenant_id, sql, parameters)
