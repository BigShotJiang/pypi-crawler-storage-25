"""Background task that monitors Prefect for stalled or failed chained flows."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from pulse_engine.config import Settings
    from pulse_engine.deployment.job_launcher import JobLauncher
    from pulse_engine.extractor.orchestrator.base import BaseOrchestratorAdapter
    from pulse_engine.extractor.repository import JobRepository
    from pulse_engine.extractor.stage_repository import StageRepository

logger = structlog.get_logger(__name__)

_NEXT_STAGE = {
    "extraction": ("processor", "processing"),
    "processing": ("storage", "storage"),
}


class ChainRecoveryTask:
    """Polls Prefect for stalled chained flows and auto-recovers."""

    def __init__(
        self,
        stage_repo: StageRepository,
        job_repo: JobRepository,
        job_launcher: JobLauncher,
        orchestrator: BaseOrchestratorAdapter,
        settings: Settings,
    ) -> None:
        self._stage_repo = stage_repo
        self._job_repo = job_repo
        self._job_launcher = job_launcher
        self._orchestrator = orchestrator
        self._grace_seconds = settings.pulse_chain_grace_period_seconds

    async def check_once(self) -> None:
        """Check running stages against Prefect for failures."""
        stages = await self._stage_repo.get_running_stages()
        for stage in stages:
            if not stage.prefect_flow_run_id:
                continue
            try:
                run_status = await self._orchestrator.get_run_status(
                    stage.prefect_flow_run_id
                )
                if run_status.status in ("failed", "cancelled"):
                    await self._stage_repo.update_status(
                        stage.id,
                        run_status.status,
                    )
                    job = await self._job_repo.get_by_id(stage.job_id)
                    if job:
                        await self._job_repo.update_status(
                            stage.job_id, job.tenant_id, "failed"
                        )
                    logger.warning(
                        "chain_recovery_stage_failed",
                        job_id=stage.job_id,
                        stage=stage.stage,
                        flow_run_status=run_status.status,
                    )
            except Exception:
                logger.warning(
                    "chain_recovery_check_error",
                    stage_id=stage.id,
                    exc_info=True,
                )

    async def check_stalled_chains(self) -> None:
        """Auto-trigger next stage for completed stages where chain stalled."""
        cutoff = datetime.now(UTC) - timedelta(
            seconds=self._grace_seconds,
        )
        stages = await self._stage_repo.get_completed_unchained_stages()

        for stage in stages:
            if stage.completed_at and stage.completed_at < cutoff:
                next_info = _NEXT_STAGE.get(stage.stage)
                if not next_info:
                    continue

                next_stage_key, next_stage_name = next_info
                job = await self._job_repo.get_by_id(stage.job_id)
                if not job:
                    continue

                params = getattr(job, "parameters", {}) or {}
                if not params.get("chain", False):
                    continue

                orchestrator = params.get("orchestrator", "prefect")
                compute = params.get("compute", "ecs")

                try:
                    result = await self._job_launcher.launch(
                        job_id=job.job_id,
                        tenant_id=job.tenant_id,
                        product=job.product,
                        stage=next_stage_key,
                        orchestrator=orchestrator,
                        compute=compute,
                        chain=True,
                        config=params.get("config", {}),
                    )

                    await self._stage_repo.create(
                        job_id=job.job_id,
                        stage=next_stage_name,
                        prefect_flow_run_id=result.flow_run_id,
                    )

                    logger.info(
                        "chain_recovery_triggered_next_stage",
                        job_id=job.job_id,
                        from_stage=stage.stage,
                        to_stage=next_stage_name,
                        flow_run_id=result.flow_run_id,
                    )
                except Exception:
                    logger.warning(
                        "chain_recovery_trigger_error",
                        job_id=stage.job_id,
                        stage=stage.stage,
                        exc_info=True,
                    )
