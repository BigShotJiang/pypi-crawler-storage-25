"""S3-backed inter-stage data exchange with NDJSON format and _SUCCESS sentinel."""

from __future__ import annotations

import json
from typing import Any

from botocore.exceptions import ClientError


class StageDataNotReady(Exception):
    """Raised when the upstream _SUCCESS sentinel is missing."""


class S3Stage:
    """Read/write NDJSON data between pipeline stages via S3."""

    def __init__(self, bucket: str, job_id: str, s3_client: Any) -> None:
        self._bucket = bucket
        self._job_id = job_id
        self._s3 = s3_client

    @property
    def raw_prefix(self) -> str:
        return f"jobs/{self._job_id}/raw/"

    @property
    def processed_prefix(self) -> str:
        return f"jobs/{self._job_id}/processed/"

    def write_raw(self, documents: list[dict[str, Any]]) -> None:
        self._write(self.raw_prefix, documents)

    def write_processed(self, documents: list[dict[str, Any]]) -> None:
        self._write(self.processed_prefix, documents)

    def read_raw(self) -> list[dict[str, Any]]:
        return self._read(self.raw_prefix)

    def read_processed(self) -> list[dict[str, Any]]:
        return self._read(self.processed_prefix)

    def _write(self, prefix: str, documents: list[dict[str, Any]]) -> None:
        ndjson = "\n".join(json.dumps(doc) for doc in documents)
        self._s3.put_object(
            Bucket=self._bucket,
            Key=f"{prefix}data.ndjson",
            Body=ndjson.encode(),
            ContentType="application/x-ndjson",
        )
        self._s3.put_object(
            Bucket=self._bucket,
            Key=f"{prefix}_SUCCESS",
            Body=b"",
        )

    def _read(self, prefix: str) -> list[dict[str, Any]]:
        # Check sentinel — only catch 404; let other S3 errors propagate
        try:
            self._s3.head_object(Bucket=self._bucket, Key=f"{prefix}_SUCCESS")
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                msg = (
                    f"Sentinel {prefix}_SUCCESS not found"
                    " — upstream stage may not be complete"
                )
                raise StageDataNotReady(msg) from e
            raise  # re-raise permissions errors, network errors, etc.

        resp = self._s3.get_object(Bucket=self._bucket, Key=f"{prefix}data.ndjson")
        body = resp["Body"].read().decode()
        return [json.loads(line) for line in body.strip().split("\n") if line.strip()]
