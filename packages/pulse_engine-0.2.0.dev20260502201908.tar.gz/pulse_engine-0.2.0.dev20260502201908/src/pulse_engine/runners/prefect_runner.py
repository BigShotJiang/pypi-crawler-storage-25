"""Prefect flow wrapper for product containers.

This module is the ONLY place in the engine that imports Prefect.
Product containers must NOT import prefect directly — they expose a plain
`entrypoint:run` function and this runner wraps it with @flow at runtime.

All Prefect-based backends (ECS, Kubernetes) use this as the flow entrypoint:
    pulse_engine.runners.prefect_runner:main
"""

from typing import Any

from prefect import flow


@flow(name="pulse-stage-runner")  # type: ignore[untyped-decorator]
def main(
    job_id: str,
    chain: bool,
    config: dict[str, Any],
    pulse_api_token: str,
    pulse_engine_url: str,
) -> None:
    """Engine-owned Prefect flow. Delegates to the product's plain entrypoint."""
    from entrypoint import run  # imported at call time from the product container

    run(
        job_id=job_id,
        chain=chain,
        config=config,
        pulse_api_token=pulse_api_token,
        pulse_engine_url=pulse_engine_url,
    )
