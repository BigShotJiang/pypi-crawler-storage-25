"""Lambda handler wrapper for product containers.

This is the Lambda handler pointed to by Terraform for native Lambda compute.
Product containers must NOT add any orchestration logic — they expose a plain
`entrypoint:run` function and this runner unpacks the event and calls it.

Terraform Lambda resource handler:
    pulse_engine.runners.lambda_runner.handler
"""

from __future__ import annotations

from typing import Any


def handler(event: dict[str, Any], context: object) -> None:
    """Engine-owned Lambda handler. Delegates to the product's plain entrypoint."""
    from entrypoint import run  # imported at call time from the product container

    run(
        job_id=event["job_id"],
        chain=event["chain"],
        config=event["config"],
        pulse_api_token=event["pulse_api_token"],
        pulse_engine_url=event["pulse_engine_url"],
    )
