"""Generic runner for pipeline module containers.

This module provides the entrypoint shim that the engine's runner package
(pulse-engine-runner) uses to call the product's entrypoint.run() function
with the new pipeline contract.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any


class RunnerError(Exception):
    pass


def execute_step(
    entrypoint_fn: Callable[..., dict[str, Any]],
    job_id: str,
    input_ref: dict[str, Any],
    config: dict[str, Any],
    pipeline_run_id: str,
    pulse_engine_url: str,
    pulse_api_token: str,
) -> dict[str, Any]:
    """Call the product's entrypoint with the pipeline contract and validate output."""
    result = entrypoint_fn(
        job_id=job_id,
        input_ref=input_ref,
        config=config,
        pipeline_run_id=pipeline_run_id,
        pulse_engine_url=pulse_engine_url,
        pulse_api_token=pulse_api_token,
    )

    if not isinstance(result, dict):
        raise RunnerError(
            f"Module entrypoint must return a dict (output reference), "
            f"got {type(result).__name__}"
        )

    return result
