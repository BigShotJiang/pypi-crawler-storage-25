from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.config import Settings, get_settings
from pulse_engine.core.job_token import JobClaims
from pulse_engine.core.security import (
    CognitoClaims,
    CognitoTokenVerifier,
    TokenVerifier,
    extract_bearer_token,
)
from pulse_engine.services.opensearch import OpenSearchService
from pulse_engine.storage.knowledge_base import KnowledgeBaseService

if TYPE_CHECKING:
    from pulse_engine.deployment.backends.registry import BackendRegistry
    from pulse_engine.deployment.job_launcher import JobLauncher
    from pulse_engine.deployment.service import DeploymentService
    from pulse_engine.extractor.orchestrator.base import BaseOrchestratorAdapter
    from pulse_engine.extractor.repository import JobRepository
    from pulse_engine.extractor.service import JobService
    from pulse_engine.processor.pipeline import ProcessingPipeline


def get_token_verifier(
    settings: Settings = Depends(get_settings),
) -> TokenVerifier:
    return CognitoTokenVerifier(
        jwks_url=settings.cognito_jwks_url,
        issuer=settings.cognito_issuer,
        audience=settings.cognito_app_client_id,
    )


async def get_current_user(
    request: Request,
    verifier: TokenVerifier = Depends(get_token_verifier),
) -> CognitoClaims | JobClaims:
    token = extract_bearer_token(request.headers.get("authorization"))
    return await verifier.verify(token)


def get_opensearch(request: Request) -> OpenSearchService:
    return request.app.state.opensearch  # type: ignore[no-any-return]


def get_knowledge_base(request: Request) -> KnowledgeBaseService:
    return request.app.state.knowledge_base  # type: ignore[no-any-return]


async def get_db_session(request: Request) -> AsyncIterator[AsyncSession]:
    factory = request.app.state.db_session_factory
    if factory is None:
        from pulse_engine.core.exceptions import ServiceUnavailableError

        raise ServiceUnavailableError("Database not configured")
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


def get_orchestrator(request: Request) -> "BaseOrchestratorAdapter":
    return request.app.state.orchestrator_adapter  # type: ignore[no-any-return]


def get_job_repository(
    session: AsyncSession = Depends(get_db_session),
) -> "JobRepository":
    from pulse_engine.extractor.repository import JobRepository

    return JobRepository(session)


def get_backend_registry(
    request: Request,
    settings: Settings = Depends(get_settings),
) -> "BackendRegistry":
    # Cache on app state to avoid recreating on each request
    if not hasattr(request.app.state, "backend_registry"):
        from pulse_engine.deployment.backends.registry import BackendRegistry

        request.app.state.backend_registry = BackendRegistry(settings)
    return request.app.state.backend_registry  # type: ignore[no-any-return]


def get_job_launcher(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
    registry: "BackendRegistry" = Depends(get_backend_registry),
    settings: Settings = Depends(get_settings),
) -> "JobLauncher":
    from pulse_engine.core.exceptions import ServiceUnavailableError
    from pulse_engine.core.job_token import JobTokenIssuer
    from pulse_engine.deployment.backend_deployment_repository import (
        BackendDeploymentRepository,
    )
    from pulse_engine.deployment.job_launcher import JobLauncher
    from pulse_engine.deployment.repository import RegistrationRepository

    reg_repo = RegistrationRepository(session)
    backend_repo = BackendDeploymentRepository(session)
    if not settings.pulse_job_token_secret:
        raise ServiceUnavailableError("PULSE_JOB_TOKEN_SECRET is not configured")
    token_issuer = JobTokenIssuer(secret=settings.pulse_job_token_secret)
    return JobLauncher(
        registration_repo=reg_repo,
        backend_deployment_repo=backend_repo,
        registry=registry,
        token_issuer=token_issuer,
        settings=settings,
    )


def get_job_service(
    request: Request,
    repo: "JobRepository" = Depends(get_job_repository),
    orchestrator: "BaseOrchestratorAdapter" = Depends(get_orchestrator),
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_db_session),
    job_launcher: "JobLauncher" = Depends(get_job_launcher),
) -> "JobService":
    from pulse_engine.extractor.service import JobService
    from pulse_engine.extractor.stage_repository import StageRepository

    stage_repo = StageRepository(session)
    # NOTE: deployment_repository and token_issuer are intentionally NOT passed here.
    # JobLauncher handles all triggering. The legacy path in _trigger_stage is
    # disabled in production by omitting these args.
    return JobService(
        repository=repo,
        orchestrator=orchestrator,
        settings=settings,
        stage_repository=stage_repo,
        job_launcher=job_launcher,
    )


def get_processing_pipeline(request: Request) -> "ProcessingPipeline":
    from pulse_engine.processor.pipeline import ProcessingPipeline

    kb = request.app.state.knowledge_base
    return ProcessingPipeline(kb_service=kb)


def get_deployment_service(
    session: AsyncSession = Depends(get_db_session),
) -> "DeploymentService":
    from pulse_engine.deployment.backend_deployment_repository import (
        BackendDeploymentRepository,
    )
    from pulse_engine.deployment.repository import RegistrationRepository
    from pulse_engine.deployment.service import DeploymentService

    reg_repo = RegistrationRepository(session)
    backend_repo = BackendDeploymentRepository(session)
    return DeploymentService(
        registration_repo=reg_repo,
        backend_deployment_repo=backend_repo,
    )
