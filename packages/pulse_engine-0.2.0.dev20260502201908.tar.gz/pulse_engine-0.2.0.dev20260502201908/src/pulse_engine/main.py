from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

from pulse_engine.api.v1.router import v1_router
from pulse_engine.config import Settings, get_settings
from pulse_engine.core.error_handlers import register_exception_handlers
from pulse_engine.core.security import (
    CognitoTokenVerifier,
    MockTokenVerifier,
    TokenVerifier,
)
from pulse_engine.middleware.rate_limit import RateLimitMiddleware
from pulse_engine.middleware.request_id import RequestIDMiddleware
from pulse_engine.middleware.security_headers import SecurityHeadersMiddleware
from pulse_engine.middleware.tenant import TenantMiddleware
from pulse_engine.pipeline.router_modules import router as pipeline_modules_router
from pulse_engine.pipeline.router_pipelines import router as pipeline_pipelines_router
from pulse_engine.services.bootstrap import bootstrap_services

if TYPE_CHECKING:
    from pulse_engine.registry import ProductManifest


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings: Settings = app.state.settings
    manifest: ProductManifest | None = getattr(app.state, "manifest", None)

    async with bootstrap_services(settings, manifest) as container:
        app.state.opensearch = container.opensearch
        app.state.knowledge_base = container.kb_service
        app.state.db_session_factory = container.db_session_factory
        app.state.orchestrator_adapter = container.orchestrator_adapter
        app.state.celery_app = container.celery_app
        app.state.pipeline = container.pipeline
        app.state.s3_client = container.s3_client
        app.state.token_issuer = container.token_issuer
        app.state.pipeline_translators = container.pipeline_translators
        app.state.pipeline_status_providers = container.pipeline_status_providers

        # Start chain recovery polling if configured
        recovery_task = None
        if (
            container.db_session_factory
            and container.token_issuer
            and settings.pulse_engine_url
            and settings.pulse_job_token_secret
        ):

            async def _recovery_loop() -> None:
                from pulse_engine.chain_recovery import ChainRecoveryTask
                from pulse_engine.deployment.backend_deployment_repository import (
                    BackendDeploymentRepository,
                )
                from pulse_engine.deployment.backends.registry import BackendRegistry
                from pulse_engine.deployment.job_launcher import JobLauncher
                from pulse_engine.deployment.repository import (
                    RegistrationRepository,
                )
                from pulse_engine.extractor.repository import JobRepository
                from pulse_engine.extractor.stage_repository import (
                    StageRepository,
                )

                registry = BackendRegistry(settings)
                factory = container.db_session_factory
                assert factory is not None
                while True:
                    try:
                        async with factory() as session:
                            job_launcher = JobLauncher(
                                registration_repo=RegistrationRepository(session),
                                backend_deployment_repo=BackendDeploymentRepository(
                                    session
                                ),
                                registry=registry,
                                token_issuer=container.token_issuer,
                                settings=settings,
                            )
                            task = ChainRecoveryTask(
                                stage_repo=StageRepository(session),
                                job_repo=JobRepository(session),
                                job_launcher=job_launcher,
                                orchestrator=container.orchestrator_adapter,
                                settings=settings,
                            )
                            await task.check_once()
                            await task.check_stalled_chains()
                    except Exception:
                        import structlog

                        structlog.get_logger().warning(
                            "chain_recovery_loop_error",
                            exc_info=True,
                        )
                    await asyncio.sleep(60)

            recovery_task = asyncio.create_task(_recovery_loop())

        try:
            yield
        finally:
            if recovery_task:
                recovery_task.cancel()


def _build_verifier(settings: Settings) -> TokenVerifier:
    if settings.mock_jwt_secret:
        return MockTokenVerifier(
            secret=settings.mock_jwt_secret,
            audience=settings.cognito_app_client_id,
            issuer=settings.cognito_issuer,
        )
    return CognitoTokenVerifier(
        jwks_url=settings.cognito_jwks_url,
        issuer=settings.cognito_issuer,
        audience=settings.cognito_app_client_id,
    )


def create_app(
    settings: Settings | None = None,
    token_verifier: TokenVerifier | None = None,
    manifest: ProductManifest | None = None,
) -> FastAPI:
    if settings is None:
        settings = get_settings()

    if manifest:
        from pulse_engine.registry import ManifestValidationError, validate_manifest

        errors = validate_manifest(manifest)
        if errors:
            raise ManifestValidationError(errors)

    app = FastAPI(
        title="Pulse Platform",
        version=settings.app_version,
        lifespan=lifespan,
        docs_url=None if settings.app_env == "production" else "/docs",
        redoc_url=None if settings.app_env == "production" else "/redoc",
        openapi_url=None if settings.app_env == "production" else "/openapi.json",
    )

    app.state.settings = settings
    app.state.manifest = manifest

    register_exception_handlers(app)

    verifier = token_verifier or _build_verifier(settings)

    # Middleware is applied in reverse order — outermost first
    app.add_middleware(
        TenantMiddleware,
        verifier=verifier,
        job_token_secret=settings.pulse_job_token_secret,
    )
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=(
            ["*"]
            if settings.app_env == "development"
            else [settings.pulse_engine_url]
            if settings.pulse_engine_url
            else []
        ),
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
        expose_headers=["X-Request-ID"],
    )
    app.add_middleware(
        RateLimitMiddleware,
        max_requests=100,
        window_seconds=60,
    )

    app.include_router(v1_router)
    app.include_router(pipeline_modules_router)
    app.include_router(pipeline_pipelines_router)

    if manifest:
        for router in manifest.routers:
            app.include_router(router, prefix="/api/v1")

    return app
