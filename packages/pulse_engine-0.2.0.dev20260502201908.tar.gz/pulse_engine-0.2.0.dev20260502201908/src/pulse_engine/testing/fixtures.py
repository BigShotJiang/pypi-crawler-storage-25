"""Reusable pytest fixtures for products that depend on pulse-engine.

Products import these in their ``conftest.py``::

    from pulse_engine.testing.fixtures import *  # noqa: F401, F403
"""

from __future__ import annotations

import pytest

from pulse_engine.processor.pipeline import ProcessingPipeline
from pulse_engine.storage.knowledge_base import KnowledgeBaseService
from pulse_engine.testing.mocks import (
    MockExtractor,
    MockOrchestratorAdapter,
    MockStorageConnector,
)


@pytest.fixture()
def mock_storage_connector() -> MockStorageConnector:
    return MockStorageConnector()


@pytest.fixture()
def mock_orchestrator() -> MockOrchestratorAdapter:
    return MockOrchestratorAdapter()


@pytest.fixture()
def mock_extractor() -> MockExtractor:
    return MockExtractor()


@pytest.fixture()
def kb_service(mock_storage_connector: MockStorageConnector) -> KnowledgeBaseService:
    """KnowledgeBaseService backed by an in-memory mock connector."""
    return KnowledgeBaseService(
        opensearch_connector=mock_storage_connector,  # type: ignore[arg-type]
        athena_connector=None,
    )


@pytest.fixture()
def processing_pipeline(
    kb_service: KnowledgeBaseService,
) -> ProcessingPipeline:
    """Pipeline using all default stages and the mock KB service."""
    return ProcessingPipeline(kb_service=kb_service)
