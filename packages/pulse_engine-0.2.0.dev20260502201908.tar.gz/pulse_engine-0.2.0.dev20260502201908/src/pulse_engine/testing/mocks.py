"""Mock implementations of engine ABCs for product testing."""

from __future__ import annotations

from typing import Any

from pulse_engine.extractor.base import BaseExtractor, ExtractionResult, ExtractorConfig
from pulse_engine.extractor.orchestrator.base import (
    BaseOrchestratorAdapter,
    OrchestratorRunStatus,
)
from pulse_engine.storage.connectors.base import BaseStorageConnector
from pulse_engine.storage.schemas import (
    ConnectorHealth,
    Document,
    SearchQuery,
    SearchResult,
    StoreResult,
)


class MockStorageConnector(BaseStorageConnector):
    """In-memory storage connector for testing."""

    def __init__(self) -> None:
        self._documents: dict[str, dict[str, Document]] = {}

    async def initialize(self) -> None:
        pass

    async def store(self, tenant_id: str, documents: list[Document]) -> StoreResult:
        bucket = self._documents.setdefault(tenant_id, {})
        stored = 0
        for doc in documents:
            key = f"{doc.doc_id}:{doc.chunk_id}" if doc.chunk_id else doc.doc_id
            bucket[key] = doc
            stored += 1
        return StoreResult(stored_count=stored, failed_count=0)

    async def retrieve(self, tenant_id: str, doc_id: str) -> Document | None:
        bucket = self._documents.get(tenant_id, {})
        return bucket.get(doc_id)

    async def search(self, tenant_id: str, query: SearchQuery) -> SearchResult:
        return SearchResult(hits=[], total=0, took_ms=0)

    async def delete(self, tenant_id: str, doc_id: str) -> bool:
        bucket = self._documents.get(tenant_id, {})
        return bucket.pop(doc_id, None) is not None

    async def health_check(self) -> ConnectorHealth:
        return ConnectorHealth(connector="mock", status="up", latency_ms=0.0)

    async def teardown(self) -> None:
        self._documents.clear()


class MockOrchestratorAdapter(BaseOrchestratorAdapter):
    """No-op orchestrator adapter for testing."""

    def __init__(self) -> None:
        self._runs: dict[str, str] = {}

    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        status = self._runs.get(run_id, "unknown")
        return OrchestratorRunStatus(run_id=run_id, status=status)

    async def cancel_run(self, run_id: str) -> bool:
        self._runs[run_id] = "cancelled"
        return True

    async def health_check(self) -> bool:
        return True

    async def create_flow_run(
        self,
        deployment_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        return ""


class MockExtractor(BaseExtractor):
    """A configurable mock extractor for testing."""

    def __init__(
        self,
        name: str = "mock",
        job_type: str = "mock_extract",
        results: list[ExtractionResult] | None = None,
    ) -> None:
        self._name = name
        self._job_type = job_type
        self._results = results or []
        self.extract_calls: list[tuple[str, dict[str, Any]]] = []

    def get_config(self) -> ExtractorConfig:
        return ExtractorConfig(name=self._name, job_type=self._job_type)

    async def extract(
        self, tenant_id: str, parameters: dict[str, Any]
    ) -> list[ExtractionResult]:
        self.extract_calls.append((tenant_id, parameters))
        return self._results
