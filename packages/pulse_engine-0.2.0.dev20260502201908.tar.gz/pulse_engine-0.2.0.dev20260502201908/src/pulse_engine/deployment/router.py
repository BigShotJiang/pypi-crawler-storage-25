"""Deployments API router."""

from fastapi import APIRouter, Depends

from pulse_engine.dependencies import get_deployment_service
from pulse_engine.deployment.schemas import (
    RegisterDeploymentRequest,
    RegisterDeploymentResponse,
)
from pulse_engine.deployment.service import DeploymentService
from pulse_engine.middleware.tenant import get_tenant_id

router = APIRouter(prefix="/deployments", tags=["Deployments"])


@router.post("/", response_model=RegisterDeploymentResponse, status_code=201)
async def register_deployment(
    body: RegisterDeploymentRequest,
    tenant_id: str = Depends(get_tenant_id),
    service: DeploymentService = Depends(get_deployment_service),
) -> RegisterDeploymentResponse:
    return await service.register(body)
