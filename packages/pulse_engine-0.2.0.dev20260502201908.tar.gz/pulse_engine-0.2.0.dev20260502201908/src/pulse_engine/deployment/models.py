"""ORM models for product registrations and backend deployment cache."""

from datetime import datetime

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from pulse_engine.database import Base


class ProductRegistrationModel(Base):
    """Stores product stage images registered via POST /api/v1/deployments."""

    __tablename__ = "product_registrations"

    product: Mapped[str] = mapped_column(sa.String(100), primary_key=True)
    stage: Mapped[str] = mapped_column(sa.String(50), primary_key=True)
    image: Mapped[str] = mapped_column(sa.String(500), nullable=False)
    registered_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True),
        server_default=sa.func.now(),
        onupdate=sa.func.now(),
        nullable=False,
    )


class ProductBackendDeploymentModel(Base):
    """Lazy cache: Prefect deployment IDs per deployment dimension tuple."""

    __tablename__ = "product_deployments"

    product: Mapped[str] = mapped_column(sa.String(100), primary_key=True)
    stage: Mapped[str] = mapped_column(sa.String(50), primary_key=True)
    orchestrator: Mapped[str] = mapped_column(sa.String(50), primary_key=True)
    compute: Mapped[str] = mapped_column(sa.String(50), primary_key=True)
    deployment_id: Mapped[str] = mapped_column(sa.String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True),
        server_default=sa.func.now(),
        onupdate=sa.func.now(),
        nullable=False,
    )
