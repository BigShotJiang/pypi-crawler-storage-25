# src/pulse_engine/deployment/schemas.py
"""Pydantic schemas for the Deployments API."""

from pydantic import BaseModel


class StageDefinition(BaseModel):
    image: str  # ECR URI


class RegisterDeploymentRequest(BaseModel):
    product: str
    stages: dict[str, StageDefinition]  # key: "extractor" | "processor" | "storage"


class RegisterDeploymentResponse(BaseModel):
    product: str
    stages: dict[str, dict[str, str]]  # {"extractor": {"status": "registered"}, ...}
