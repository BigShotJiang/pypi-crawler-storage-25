"""Central dispatch for job triggering across all runner backends."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import structlog

from pulse_engine.core.exceptions import (
    BadRequestError,
    NotFoundError,
    UnprocessableEntityError,
)
from pulse_engine.deployment.backends.exceptions import BackendNotAvailableError

if TYPE_CHECKING:
    from pulse_engine.config import Settings
    from pulse_engine.core.job_token import JobTokenIssuer
    from pulse_engine.deployment.backend_deployment_repository import (
        BackendDeploymentRepository,
    )
    from pulse_engine.deployment.backends.registry import BackendRegistry
    from pulse_engine.deployment.repository import RegistrationRepository

logger = structlog.get_logger(__name__)

# The engine-owned Prefect flow entrypoint. All product containers must expose
# entrypoint:run as a plain function; this wrapper (shipped with the engine)
# decorates it with @flow so product code stays Prefect-free.
PULSE_FLOW_ENTRYPOINT = "pulse_engine.runners.prefect_runner:main"

_STAGE_NAME_MAP = {
    "extractor": "extraction",
    "processor": "processing",
    "storage": "storage",
}


@dataclass
class LaunchResult:
    flow_run_id: str
    token: str


class JobLauncher:
    """Orchestrates the full job trigger sequence.

    Steps:
    1. Look up product registration -> image
    2. Resolve backend from registry
    3. prepare() — work pool setup or no-op
    4. register() — upsert backend run unit (cached)
    5. Issue job-scoped JWT
    6. trigger() — fire the run, return run ID
    7. Return LaunchResult
    """

    def __init__(
        self,
        registration_repo: RegistrationRepository,
        backend_deployment_repo: BackendDeploymentRepository,
        registry: BackendRegistry,
        token_issuer: JobTokenIssuer,
        settings: Settings,
    ) -> None:
        self._reg_repo = registration_repo
        self._backend_repo = backend_deployment_repo
        self._registry = registry
        self._token_issuer = token_issuer
        self._settings = settings

    async def launch(
        self,
        job_id: str,
        tenant_id: str,
        product: str,
        stage: str,
        orchestrator: str,
        compute: str,
        chain: bool,
        config: dict[str, Any],
    ) -> LaunchResult:
        # 1. Look up registration
        registration = await self._reg_repo.get(product, stage)
        if registration is None:
            raise NotFoundError(
                f"No deployment registered for {product}/{stage}",
                product=product,
                stage=stage,
            )

        # 2. Resolve backend (raises 422 if unsupported)
        try:
            backend = self._registry.get(orchestrator, compute)
        except BackendNotAvailableError as exc:
            logger.warning(
                "backend_not_available",
                orchestrator=orchestrator,
                compute=compute,
                exc_info=True,
            )
            raise UnprocessableEntityError(
                "Unsupported orchestrator/compute combination"
            ) from exc

        # 3. prepare() — idempotent setup (work pool creation, no-op for native)
        await backend.prepare()

        # 4. register() — cached; Prefect gets image + entrypoint, native Lambda
        # derives function name from product+stage convention.
        # NOTE: Concurrent callers may both see a cache miss and both call register().
        # This is safe: upsert() uses ON CONFLICT DO UPDATE, and register()
        # is idempotent.
        cached = await self._backend_repo.get(product, stage, orchestrator, compute)
        if cached:
            handle = cached.deployment_id
        else:
            handle = await backend.register(
                product=product,
                stage=stage,
                image=registration.image,
                entrypoint=PULSE_FLOW_ENTRYPOINT,
            )
            await self._backend_repo.upsert(
                product=product,
                stage=stage,
                orchestrator=orchestrator,
                compute=compute,
                deployment_id=handle,
            )

        # 5. Issue job-scoped JWT
        stage_name = _STAGE_NAME_MAP.get(stage)
        if stage_name is None:
            raise BadRequestError(
                f"Unknown stage: {stage!r}. Must be one of: {list(_STAGE_NAME_MAP)}"
            )
        scope = ["jobs:status"]
        if stage == "storage":
            scope.append("kb:write")
        if chain:
            scope.append("jobs:trigger_next")

        token = self._token_issuer.issue(
            job_id=job_id,
            tenant_id=tenant_id,
            product=product,
            stage=stage_name,
            scope=scope,
            orchestrator=orchestrator,
            compute=compute,
        )

        # 6. trigger() — returns run ID (UUID for native Lambda, Prefect flow
        # run UUID for Prefect)
        run_id = await backend.trigger(
            handle,
            {
                "job_id": job_id,
                "chain": chain,
                "config": config,
                "pulse_api_token": token,
                "pulse_engine_url": self._settings.pulse_engine_url,
            },
        )

        logger.info(
            "job_launched",
            job_id=job_id,
            product=product,
            stage=stage_name,
            orchestrator=orchestrator,
            compute=compute,
            run_id=run_id,
        )

        return LaunchResult(flow_run_id=run_id, token=token)
