"""Registry mapping (orchestrator, compute) pairs to BaseRunnerBackend instances."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from pulse_engine.deployment.backends.base import BaseRunnerBackend
from pulse_engine.deployment.backends.exceptions import BackendNotAvailableError

if TYPE_CHECKING:
    from pulse_engine.config import Settings


class BackendRegistry:
    """Lazy-initializing registry. Backends are instantiated on first get()."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._instances: dict[tuple[str, str], BaseRunnerBackend] = {}

    def get(self, orchestrator: str, compute: str) -> BaseRunnerBackend:
        key = (orchestrator, compute)
        if key not in self._instances:
            self._instances[key] = self._create(orchestrator, compute)
        return self._instances[key]

    def available_backends(self) -> list[tuple[str, str]]:
        return [
            ("prefect", "ecs"),
            ("prefect", "kubernetes"),
            ("native", "lambda"),
        ]

    def _create(self, orchestrator: str, compute: str) -> BaseRunnerBackend:
        from pulse_engine.deployment.backends.native_lambda import NativeLambdaBackend
        from pulse_engine.deployment.backends.prefect_ecs import PrefectECSBackend
        from pulse_engine.deployment.backends.prefect_k8s import PrefectK8sBackend

        # IMPORTANT: use lambdas so only the matched backend is instantiated.
        # A plain dict literal would call all three constructors on every _create().
        factories: dict[tuple[str, str], Callable[[], BaseRunnerBackend]] = {
            ("prefect", "ecs"): lambda: PrefectECSBackend(self._settings),
            ("prefect", "kubernetes"): lambda: PrefectK8sBackend(self._settings),
            ("native", "lambda"): lambda: NativeLambdaBackend(self._settings),
        }
        if (orchestrator, compute) not in factories:
            available = [f"{o}×{c}" for o, c in self.available_backends()]
            raise BackendNotAvailableError(orchestrator, compute, available)
        return factories[(orchestrator, compute)]()
