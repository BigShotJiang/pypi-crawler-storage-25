"""Exceptions for runner backends."""


class BackendNotAvailableError(Exception):
    """Raised when a requested (orchestrator, compute) backend is not available."""

    def __init__(
        self,
        orchestrator: str,
        compute: str,
        available: list[str],
    ) -> None:
        self.orchestrator = orchestrator
        self.compute = compute
        self.available = available
        msg = (
            f"Backend not available: orchestrator={orchestrator!r}, "
            f"compute={compute!r}. Available: {', '.join(available)}"
        )
        super().__init__(msg)
