"""Prefect + ECS runner backend."""

from __future__ import annotations

import base64
from typing import TYPE_CHECKING, Any

import httpx
import structlog

from pulse_engine.deployment.backends.base import BaseRunnerBackend
from pulse_engine.extractor.orchestrator.base import OrchestratorRunStatus

if TYPE_CHECKING:
    from pulse_engine.config import Settings

logger = structlog.get_logger(__name__)

_PREFECT_STATE_MAP: dict[str, str] = {
    "COMPLETED": "completed",
    "FAILED": "failed",
    "CRASHED": "failed",
    "CANCELLED": "cancelled",
    "CANCELLING": "cancelled",
    "RUNNING": "running",
    "PENDING": "pending",
    "SCHEDULED": "pending",
}


class PrefectECSBackend(BaseRunnerBackend):
    """Runs Prefect flow runs on an ECS work pool."""

    def __init__(self, settings: Settings) -> None:
        self._work_pool_name = settings.prefect_ecs_work_pool_name
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if settings.prefect_api_key:
            encoded = base64.b64encode(settings.prefect_api_key.encode()).decode()
            headers["Authorization"] = f"Basic {encoded}"
        self._client = httpx.AsyncClient(
            base_url=settings.prefect_api_url.rstrip("/"),
            headers=headers,
            timeout=10.0,
        )

    async def prepare(self) -> None:
        resp = await self._client.get(f"/work_pools/{self._work_pool_name}")
        if resp.is_success:
            return
        payload: dict[str, Any] = {
            "name": self._work_pool_name,
            "type": "ecs",
        }
        resp = await self._client.post("/work_pools/", json=payload)
        resp.raise_for_status()

    async def register(
        self,
        product: str,
        stage: str,
        image: str,
        entrypoint: str | None = None,
    ) -> str:
        name = f"{product}-{stage}"
        flow_id = await self._get_or_create_flow_id(name)
        payload: dict[str, Any] = {
            "name": name,
            "flow_id": flow_id,
            "entrypoint": entrypoint,
            "work_pool_name": self._work_pool_name,
            "job_variables": {"image": image},
        }
        resp = await self._client.post("/deployments/", json=payload)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["id"])

    async def trigger(self, handle: str, parameters: dict[str, Any]) -> str:
        resp = await self._client.post(
            f"/deployments/{handle}/create_flow_run",
            json={"parameters": parameters},
        )
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["id"])

    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        try:
            resp = await self._client.get(f"/flow_runs/{run_id}")
            resp.raise_for_status()
            data = resp.json()
            raw_state = data.get("state", {}).get("type", "UNKNOWN")
            canonical = _PREFECT_STATE_MAP.get(raw_state.upper(), "unknown")
            return OrchestratorRunStatus(
                run_id=run_id, status=canonical, raw_state=raw_state
            )
        except Exception:
            logger.warning("ecs_backend_status_failed", run_id=run_id, exc_info=True)
            return OrchestratorRunStatus(run_id=run_id, status="unknown")

    async def cancel_run(self, run_id: str) -> bool:
        try:
            resp = await self._client.post(
                f"/flow_runs/{run_id}/set_state",
                json={"state": {"type": "CANCELLED"}},
            )
            return resp.is_success
        except Exception:
            logger.warning("ecs_backend_cancel_failed", run_id=run_id, exc_info=True)
            return False

    async def _get_or_create_flow_id(self, flow_name: str) -> str:
        resp = await self._client.post("/flows/", json={"name": flow_name})
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["id"])
