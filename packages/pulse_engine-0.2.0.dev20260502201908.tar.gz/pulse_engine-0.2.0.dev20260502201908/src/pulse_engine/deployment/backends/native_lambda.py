"""Native Lambda runner backend — invokes Lambda directly via boto3.

When InfraProvisioner is configured, Lambda functions are auto-provisioned
from container images at registration time. Otherwise falls back to
expecting pre-provisioned functions (backward compatible).
"""

from __future__ import annotations

import json
import uuid
from typing import TYPE_CHECKING, Any

import boto3
import structlog

from pulse_engine.deployment.backends.base import BaseRunnerBackend
from pulse_engine.extractor.orchestrator.base import OrchestratorRunStatus

if TYPE_CHECKING:
    from pulse_engine.config import Settings

logger = structlog.get_logger(__name__)


class NativeLambdaBackend(BaseRunnerBackend):
    """Invokes Lambda functions directly via boto3 (no Prefect involved).

    Lambda functions follow the naming convention: {product}-{stage}.
    If pipeline infrastructure settings are configured, functions are
    auto-provisioned from container images. Otherwise they must be
    pre-provisioned by Terraform.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._region = settings.aws_region
        self._provisioner: Any = None

    def _get_provisioner(self) -> Any:
        if self._provisioner is not None:
            return self._provisioner
        role_arn = getattr(self._settings, "lambda_execution_role_arn", "")
        if not isinstance(role_arn, str) or not role_arn:
            return None
        try:
            from pulse_engine.deployment.infra_provisioner import InfraProvisioner

            self._provisioner = InfraProvisioner(
                region=self._settings.aws_region,
                pipeline_cluster_name=self._settings.pipeline_cluster_name,
                pipeline_execution_role_arn=self._settings.pipeline_execution_role_arn,
                pipeline_task_role_arn=self._settings.pipeline_task_role_arn,
                pipeline_log_group=self._settings.pipeline_log_group,
                pipeline_subnets=self._settings.pipeline_subnet_list,
                pipeline_security_groups=self._settings.pipeline_sg_list,
                lambda_execution_role_arn=self._settings.lambda_execution_role_arn,
                lambda_subnets=self._settings.lambda_subnet_list,
                lambda_security_groups=self._settings.lambda_sg_list,
                lambda_log_group=self._settings.lambda_log_group,
            )
            return self._provisioner
        except Exception:
            logger.warning("Failed to create InfraProvisioner", exc_info=True)
            return None

    async def prepare(self) -> None:
        pass

    async def register(
        self,
        product: str,
        stage: str,
        image: str,
        entrypoint: str | None = None,
    ) -> str:
        func_name = f"{product}-{stage}"

        # Auto-provision Lambda function from container image
        provisioner = self._get_provisioner()
        if provisioner and image:
            provisioner.ensure_lambda_function(func_name, image)
            logger.info(
                "lambda_auto_provisioned",
                function=func_name,
                image=image,
            )

        return func_name

    async def trigger(self, handle: str, parameters: dict[str, Any]) -> str:
        from botocore.exceptions import ClientError

        from pulse_engine.core.exceptions import NotFoundError

        run_id = str(uuid.uuid4())
        payload = {**parameters, "run_id": run_id}
        client = boto3.client("lambda", region_name=self._region)
        try:
            client.invoke(
                FunctionName=handle,
                InvocationType="Event",  # async fire-and-forget
                Payload=json.dumps(payload),
            )
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code == "ResourceNotFoundException":
                raise NotFoundError(
                    f"Lambda function not found: {handle}. "
                    "Ensure pipeline infrastructure settings are configured "
                    "or the function is deployed manually.",
                    function=handle,
                ) from exc
            raise
        logger.info("lambda_triggered", function=handle, run_id=run_id)
        return run_id

    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        # Status arrives via Lambda callback to POST /jobs/{id}/status
        # The engine's job record is the source of truth — not Lambda
        return OrchestratorRunStatus(run_id=run_id, status="unknown")

    async def cancel_run(self, run_id: str) -> bool:
        # Async Lambda invocations cannot be cancelled post-fire
        return False
