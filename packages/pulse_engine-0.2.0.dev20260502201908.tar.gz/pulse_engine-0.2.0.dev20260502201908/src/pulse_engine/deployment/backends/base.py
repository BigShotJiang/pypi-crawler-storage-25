"""Abstract base class for runner backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pulse_engine.extractor.orchestrator.base import OrchestratorRunStatus


class BaseRunnerBackend(ABC):
    """One implementation per (orchestrator, compute) pair.

    Responsible for: backend setup, run-unit registration,
    run triggering, status querying, and cancellation.
    """

    @abstractmethod
    async def prepare(self) -> None:
        """One-time setup before triggering (e.g. work pool creation).
        No-op for backends that don't require it."""

    @abstractmethod
    async def register(
        self,
        product: str,
        stage: str,
        image: str,
        entrypoint: str | None = None,
    ) -> str:
        """Register or update a runnable unit for this product+stage.

        Returns a stable handle the launcher caches.
        - Prefect backends: Prefect deployment UUID
        - Native Lambda: "{product}-{stage}" (function name by convention)

        entrypoint is required for Prefect backends, ignored for native backends.
        """

    @abstractmethod
    async def trigger(self, handle: str, parameters: dict[str, Any]) -> str:
        """Trigger a run. Returns a run ID for correlation."""

    @abstractmethod
    async def get_run_status(self, run_id: str) -> OrchestratorRunStatus:
        """Fetch current status of a run."""

    @abstractmethod
    async def cancel_run(self, run_id: str) -> bool:
        """Request cancellation. Return True if accepted."""
