"""Data access layer for product registrations."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.deployment.models import ProductRegistrationModel


class RegistrationRepository:
    """CRUD for product_registrations table."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(
        self,
        product: str,
        stage: str,
        image: str,
    ) -> ProductRegistrationModel:
        existing = await self.get(product, stage)
        if existing:
            existing.image = image
            await self._session.commit()
            await self._session.refresh(existing)
            return existing
        record = ProductRegistrationModel(
            product=product,
            stage=stage,
            image=image,
        )
        self._session.add(record)
        await self._session.commit()
        await self._session.refresh(record)
        return record

    async def get(self, product: str, stage: str) -> ProductRegistrationModel | None:
        stmt = sa.select(ProductRegistrationModel).where(
            ProductRegistrationModel.product == product,
            ProductRegistrationModel.stage == stage,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_by_product(self, product: str) -> list[ProductRegistrationModel]:
        stmt = (
            sa.select(ProductRegistrationModel)
            .where(ProductRegistrationModel.product == product)
            .order_by(ProductRegistrationModel.stage)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
