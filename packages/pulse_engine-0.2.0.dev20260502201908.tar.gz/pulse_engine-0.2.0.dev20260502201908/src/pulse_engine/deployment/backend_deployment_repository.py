"""Data access layer for the product_deployments lazy cache table."""

from __future__ import annotations

from datetime import UTC, datetime

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.deployment.models import ProductBackendDeploymentModel


class BackendDeploymentRepository:
    """CRUD for product_deployments — the per-backend Prefect deployment ID cache.

    Owns all reads, writes, and deletes for this table.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get(
        self,
        product: str,
        stage: str,
        orchestrator: str,
        compute: str,
    ) -> ProductBackendDeploymentModel | None:
        stmt = sa.select(ProductBackendDeploymentModel).where(
            ProductBackendDeploymentModel.product == product,
            ProductBackendDeploymentModel.stage == stage,
            ProductBackendDeploymentModel.orchestrator == orchestrator,
            ProductBackendDeploymentModel.compute == compute,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def upsert(
        self,
        product: str,
        stage: str,
        orchestrator: str,
        compute: str,
        deployment_id: str,
    ) -> None:
        """Insert or update deployment_id using SQL-level ON CONFLICT DO UPDATE.

        Safe under concurrent triggers — two concurrent callers both complete
        without IntegrityError; the last write wins.
        """
        now = datetime.now(UTC)
        stmt = (
            pg_insert(ProductBackendDeploymentModel)
            .values(
                product=product,
                stage=stage,
                orchestrator=orchestrator,
                compute=compute,
                deployment_id=deployment_id,
                created_at=now,
                updated_at=now,
            )
            .on_conflict_do_update(
                index_elements=["product", "stage", "orchestrator", "compute"],
                set_={"deployment_id": deployment_id, "updated_at": now},
            )
        )
        await self._session.execute(stmt)
        await self._session.commit()

    async def delete_by_product_stage(self, product: str, stage: str) -> None:
        """Delete all cached deployment IDs for this product+stage.

        Called by DeploymentService when a product re-registers with a new image,
        so JobLauncher recreates Prefect deployments on the next trigger.
        """
        stmt = sa.delete(ProductBackendDeploymentModel).where(
            ProductBackendDeploymentModel.product == product,
            ProductBackendDeploymentModel.stage == stage,
        )
        await self._session.execute(stmt)
        await self._session.commit()
