# src/pulse_engine/deployment/service.py
"""Business logic for registering product stage deployments."""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog

from pulse_engine.deployment.schemas import (
    RegisterDeploymentRequest,
    RegisterDeploymentResponse,
)

if TYPE_CHECKING:
    from pulse_engine.deployment.backend_deployment_repository import (
        BackendDeploymentRepository,
    )
    from pulse_engine.deployment.repository import RegistrationRepository

logger = structlog.get_logger(__name__)


class DeploymentService:
    """Stores product stage image registrations. Does not create Prefect deployments.

    Prefect deployments are created lazily by JobLauncher on first trigger.
    When a product re-registers, all cached backend deployment IDs for that
    product+stage are invalidated so JobLauncher recreates them with the new image.
    """

    def __init__(
        self,
        registration_repo: RegistrationRepository,
        backend_deployment_repo: BackendDeploymentRepository,
    ) -> None:
        self._repo = registration_repo
        self._backend_repo = backend_deployment_repo

    async def register(
        self, request: RegisterDeploymentRequest
    ) -> RegisterDeploymentResponse:
        result_stages: dict[str, dict[str, str]] = {}

        for stage_name, stage_def in request.stages.items():
            await self._repo.upsert(
                product=request.product,
                stage=stage_name,
                image=stage_def.image,
            )
            # Invalidate cached Prefect deployment IDs — image may have changed
            await self._backend_repo.delete_by_product_stage(
                request.product, stage_name
            )
            result_stages[stage_name] = {"status": "registered"}
            logger.info(
                "stage_registration_stored",
                product=request.product,
                stage=stage_name,
            )

        return RegisterDeploymentResponse(
            product=request.product,
            stages=result_stages,
        )
