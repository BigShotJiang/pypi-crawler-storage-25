from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.dependencies import get_db_session
from pulse_engine.middleware.tenant import get_tenant_id
from pulse_engine.pipeline.repositories import ModuleRegistryRepository
from pulse_engine.pipeline.schemas import (
    RegisterModulesRequest,
    RegisterModulesResponse,
)

router = APIRouter(prefix="/api/v1/modules", tags=["modules"])


async def get_module_registry_repo(
    session: AsyncSession = Depends(get_db_session),
) -> ModuleRegistryRepository:
    return ModuleRegistryRepository(session)


@router.post(
    "/register",
    status_code=status.HTTP_201_CREATED,
    response_model=RegisterModulesResponse,
)
async def register_modules(
    body: RegisterModulesRequest,
    tenant_id: str = Depends(get_tenant_id),
    repo: ModuleRegistryRepository = Depends(get_module_registry_repo),
) -> RegisterModulesResponse:
    result_modules: dict[str, dict[str, str]] = {}
    for module_name, module_def in body.modules.items():
        await repo.upsert(tenant_id, body.product, module_name, module_def.image)
        result_modules[module_name] = {"status": "registered"}

    return RegisterModulesResponse(product=body.product, modules=result_modules)


@router.get("/{product}")
async def list_modules(
    product: str,
    tenant_id: str = Depends(get_tenant_id),
    repo: ModuleRegistryRepository = Depends(get_module_registry_repo),
) -> dict[str, Any]:
    modules = await repo.list_by_product(tenant_id, product)
    return {
        "product": product,
        "modules": {m.module_name: {"image": m.image} for m in modules},
    }


@router.delete("/{product}/{module_name}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_module(
    product: str,
    module_name: str,
    tenant_id: str = Depends(get_tenant_id),
    repo: ModuleRegistryRepository = Depends(get_module_registry_repo),
) -> Response:
    deleted = await repo.delete(tenant_id, product, module_name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Module '{module_name}' not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
