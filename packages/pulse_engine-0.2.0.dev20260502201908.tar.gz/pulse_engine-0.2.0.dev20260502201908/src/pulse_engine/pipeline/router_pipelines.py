from __future__ import annotations

import json
from typing import Annotated, Any

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Request,
    UploadFile,
    status,
)
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.dependencies import get_db_session
from pulse_engine.middleware.tenant import get_tenant_id
from pulse_engine.pipeline.config_parser import (
    PipelineConfigError,
    parse_pipeline_config,
)
from pulse_engine.pipeline.schemas import (
    PipelineRunListResponse,
    PipelineRunStatus,
    PipelineStatusResponse,
    TriggerPayload,
    TriggerResponse,
)
from pulse_engine.pipeline.service import (
    PipelineService,
    PipelineServiceError,
    PipelineSubmissionError,
)

router = APIRouter(prefix="/api/v1/pipelines", tags=["pipelines"])


async def get_pipeline_service(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> PipelineService:
    """Build PipelineService from app.state services initialised at startup."""
    from pulse_engine.pipeline.repositories import (
        ModuleRegistryRepository,
        PipelineRunRepository,
    )

    app = request.app
    return PipelineService(
        module_repo=ModuleRegistryRepository(session),
        run_repo=PipelineRunRepository(session),
        translators=getattr(app.state, "pipeline_translators", {}),
        status_providers=getattr(app.state, "pipeline_status_providers", {}),
        settings=app.state.settings,
        token_issuer=getattr(app.state, "token_issuer", None),
    )


@router.post(
    "/trigger",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=TriggerResponse,
)
async def trigger_pipeline(
    pipeline_file: Annotated[UploadFile, File()],
    payload: Annotated[str, Form()] = "{}",
    tenant_id: Annotated[str, Depends(get_tenant_id)] = "",
    service: Annotated[PipelineService, Depends(get_pipeline_service)] = None,  # type: ignore[assignment]
) -> TriggerResponse:
    # Parse YAML config first — product/orchestrator can be inferred from it
    yaml_content = (await pipeline_file.read()).decode("utf-8")
    try:
        config = parse_pipeline_config(yaml_content)
    except PipelineConfigError as e:
        raise HTTPException(status_code=400, detail={"errors": e.errors})

    # Parse optional JSON payload; fall back to values from the pipeline yaml
    try:
        payload_data = TriggerPayload(**json.loads(payload))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON payload: {e}")

    product = payload_data.product or config.name
    orchestrator = payload_data.orchestrator or config.infra.orchestrator

    try:
        run_id = await service.trigger(
            tenant_id=tenant_id,
            product=product,
            orchestrator=orchestrator,
            config=config,
            input_data=payload_data.input,
            global_config=payload_data.config,
        )
    except PipelineServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except PipelineSubmissionError as e:
        raise HTTPException(status_code=502, detail=str(e))

    return TriggerResponse(run_id=run_id)


@router.get("/{run_id}/status", response_model=PipelineStatusResponse)
async def get_pipeline_status(
    run_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: PipelineService = Depends(get_pipeline_service),
) -> PipelineStatusResponse:
    run = await service.get_run(tenant_id, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Pipeline run not found")

    pipeline_status = await service.get_status(tenant_id, run_id)

    return PipelineStatusResponse(
        run_id=run.id,
        product=run.product,
        orchestrator=run.orchestrator,
        status=PipelineRunStatus(
            pipeline_status.status if pipeline_status else run.status
        ),
        started_at=pipeline_status.started_at if pipeline_status else None,  # type: ignore[arg-type]
        steps=pipeline_status.steps if pipeline_status else [],
    )


@router.get("/{run_id}/steps")
async def get_pipeline_steps(
    run_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: PipelineService = Depends(get_pipeline_service),
) -> dict[str, Any]:
    pipeline_status = await service.get_status(tenant_id, run_id)
    if pipeline_status is None:
        raise HTTPException(status_code=404, detail="Pipeline run not found")

    return {"run_id": run_id, "steps": [s.model_dump() for s in pipeline_status.steps]}


@router.post("/{run_id}/cancel")
async def cancel_pipeline(
    run_id: str,
    tenant_id: str = Depends(get_tenant_id),
    service: PipelineService = Depends(get_pipeline_service),
) -> dict[str, str]:
    result = await service.cancel(tenant_id, run_id)
    if not result:
        raise HTTPException(
            status_code=404,
            detail="Pipeline run not found or cannot be cancelled",
        )
    return {"run_id": run_id, "status": "cancelled"}


@router.get("/", response_model=PipelineRunListResponse)
async def list_pipelines(
    tenant_id: str = Depends(get_tenant_id),
    product: str | None = None,
    pipeline_status: str | None = None,
    limit: int = 20,
    offset: int = 0,
    service: PipelineService = Depends(get_pipeline_service),
) -> PipelineRunListResponse:
    runs, total = await service.list_runs(
        tenant_id, product=product, status=pipeline_status, limit=limit, offset=offset
    )
    items = [
        PipelineStatusResponse(
            run_id=r.id,
            product=r.product,
            orchestrator=r.orchestrator,
            status=PipelineRunStatus(r.status),
        )
        for r in runs
    ]
    return PipelineRunListResponse(items=items, total=total, limit=limit, offset=offset)
