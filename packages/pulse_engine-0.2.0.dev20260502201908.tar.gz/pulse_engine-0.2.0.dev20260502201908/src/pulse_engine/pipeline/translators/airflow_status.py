from __future__ import annotations

from pulse_engine.pipeline.translators.base import BaseStatusProvider, PipelineStatus


class AirflowStatusProvider(BaseStatusProvider):
    async def get_status(self, orchestrator_run_id: str) -> PipelineStatus:
        raise NotImplementedError("Airflow status provider is not yet implemented.")

    async def cancel(self, orchestrator_run_id: str) -> bool:
        raise NotImplementedError("Airflow cancel is not yet implemented.")
