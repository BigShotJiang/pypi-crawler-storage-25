from __future__ import annotations

from typing import Any

from pulse_engine.pipeline.translators.base import BaseStatusProvider, BaseTranslator

__all__ = [
    "BaseTranslator",
    "BaseStatusProvider",
    "get_translator",
    "get_status_provider",
]


def get_translator(orchestrator: str, **kwargs: Any) -> BaseTranslator:
    if orchestrator == "prefect":
        from pulse_engine.pipeline.translators.prefect_translator import (
            PrefectTranslator,
        )

        return PrefectTranslator(**kwargs)
    elif orchestrator == "airflow":
        from pulse_engine.pipeline.translators.airflow_translator import (
            AirflowTranslator,
        )

        return AirflowTranslator()
    raise ValueError(f"Unknown orchestrator: {orchestrator}")


def get_status_provider(orchestrator: str, **kwargs: Any) -> BaseStatusProvider:
    if orchestrator == "prefect":
        from pulse_engine.pipeline.translators.prefect_status import (
            PrefectStatusProvider,
        )

        return PrefectStatusProvider(**kwargs)
    elif orchestrator == "airflow":
        from pulse_engine.pipeline.translators.airflow_status import (
            AirflowStatusProvider,
        )

        return AirflowStatusProvider()
    raise ValueError(f"Unknown orchestrator: {orchestrator}")
