from __future__ import annotations

import base64

import httpx

from pulse_engine.pipeline.schemas import StepStatus
from pulse_engine.pipeline.translators.base import BaseStatusProvider, PipelineStatus

_PREFECT_STATE_MAP: dict[str, str] = {
    "COMPLETED": "completed",
    "FAILED": "failed",
    "CANCELLED": "cancelled",
    "CANCELLING": "cancelled",
    "RUNNING": "running",
    "PENDING": "pending",
    "SCHEDULED": "pending",
}


class PrefectStatusProvider(BaseStatusProvider):
    def __init__(
        self,
        prefect_api_url: str,
        prefect_api_key: str,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_url = prefect_api_url.rstrip("/")
        self._api_key = prefect_api_key
        self._client = http_client

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        auth_header = base64.b64encode(f":{self._api_key}".encode()).decode()
        return httpx.AsyncClient(
            headers={"Authorization": f"Basic {auth_header}"},
            timeout=30.0,
        )

    async def get_status(self, orchestrator_run_id: str) -> PipelineStatus:
        client = self._get_client()
        try:
            resp = await client.get(f"{self._api_url}/flow_runs/{orchestrator_run_id}")
            resp.raise_for_status()
            flow_run = resp.json()

            prefect_state = flow_run.get("state", {}).get("type", "PENDING")
            status = _PREFECT_STATE_MAP.get(prefect_state, "pending")
            started_at = flow_run.get("start_time")

            task_resp = await client.post(
                f"{self._api_url}/task_runs/filter",
                json={"flow_runs": {"id": {"any_": [orchestrator_run_id]}}},
            )
            task_resp.raise_for_status()
            task_runs = task_resp.json()

            steps: list[StepStatus] = []
            for task in task_runs:
                task_state = task.get("state", {}).get("type", "PENDING")
                steps.append(
                    StepStatus(
                        step=task.get("name", "unknown"),
                        module=task.get("name", "unknown"),
                        status=_PREFECT_STATE_MAP.get(task_state, "pending"),
                        started_at=task.get("start_time"),
                    )
                )

            return PipelineStatus(
                status=status,
                started_at=started_at,
                steps=steps,
            )
        finally:
            if self._client is None:
                await client.aclose()

    async def cancel(self, orchestrator_run_id: str) -> bool:
        client = self._get_client()
        try:
            resp = await client.post(
                f"{self._api_url}/flow_runs/{orchestrator_run_id}/set_state",
                json={"state": {"type": "CANCELLED"}},
            )
            resp.raise_for_status()
            return True
        except httpx.HTTPStatusError:
            return False
        finally:
            if self._client is None:
                await client.aclose()
