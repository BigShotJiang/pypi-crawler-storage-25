from __future__ import annotations

import yaml  # type: ignore[import-untyped]
from pydantic import ValidationError

from pulse_engine.pipeline.expression import parse_expression
from pulse_engine.pipeline.schemas import PipelineConfig


class PipelineConfigError(Exception):
    """Raised when pipeline config is invalid."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(f"Pipeline config validation failed: {'; '.join(errors)}")


def parse_pipeline_config(yaml_content: str) -> PipelineConfig:
    """Parse YAML string into validated PipelineConfig."""
    try:
        raw = yaml.safe_load(yaml_content)
    except yaml.YAMLError as e:
        raise PipelineConfigError([f"YAML parse error: {e}"]) from e

    if not isinstance(raw, dict):
        raise PipelineConfigError(["YAML content must be a mapping"])

    try:
        config = PipelineConfig(**raw)
    except ValidationError as e:
        errors = [f"{err['loc']}: {err['msg']}" for err in e.errors()]
        raise PipelineConfigError(errors) from e

    validate_dag(config)
    return config


def validate_dag(config: PipelineConfig) -> None:
    """Validate DAG structure for v2 pipelines."""
    errors: list[str] = []
    module_names = {m.name for m in config.modules}
    module_map = {m.name: m for m in config.modules}
    step_names: set[str] = set()

    # Pass 1: duplicate steps + module reference check
    for s in config.dag:
        if s.step in step_names:
            errors.append(f"Duplicate step: '{s.step}'")
        step_names.add(s.step)

        if s.module not in module_names:
            errors.append(f"Step '{s.step}' references unknown module '{s.module}'")

    # Pass 2: expression + collect_from validation
    for s in config.dag:
        # Validate collect_from references
        if s.collect_from is not None:
            refs = (
                [s.collect_from]
                if isinstance(s.collect_from, str)
                else list(s.collect_from)
            )
            for ref in refs:
                if ref not in step_names:
                    errors.append(
                        f"Step '{s.step}' collect_from references unknown step '{ref}'"
                    )

        # Validate for_each expression
        if s.for_each is not None:
            module = module_map.get(s.module)
            try:
                expr = parse_expression(s.for_each)

                if expr.source == "args":
                    # $args.X requires module to have arg X
                    if module is not None and expr.field not in module.args:
                        errors.append(
                            f"Step '{s.step}' for_each '{s.for_each}' but "
                            f"module has no arg '{expr.field}'"
                        )
                    # $args fan-out cannot be combined with collect_from
                    if s.collect_from is not None:
                        errors.append(
                            f"Step '{s.step}' cannot combine '$args' fan-out "
                            f"with collect_from"
                        )

                elif expr.source == "steps":
                    if expr.step not in step_names:
                        errors.append(
                            f"Step '{s.step}' for_each references unknown step "
                            f"'{expr.step}'"
                        )

                elif expr.source == "collect":
                    if s.collect_from is None:
                        errors.append(
                            f"Step '{s.step}' uses '$collect.{expr.field}' "
                            f"but has no collect_from"
                        )

            except ValueError as exc:
                errors.append(f"Step '{s.step}' has invalid for_each expression: {exc}")

    # Cycle detection via Kahn's algorithm
    # Edges: collect_from deps + for_each $steps.S.* deps
    in_degree: dict[str, int] = {s.step: 0 for s in config.dag}
    adjacency: dict[str, list[str]] = {s.step: [] for s in config.dag}

    for s in config.dag:
        deps: set[str] = set()

        if s.collect_from is not None:
            refs = (
                [s.collect_from]
                if isinstance(s.collect_from, str)
                else list(s.collect_from)
            )
            deps.update(r for r in refs if r in step_names)

        if s.for_each is not None:
            try:
                expr = parse_expression(s.for_each)
                if expr.source == "steps" and expr.step and expr.step in step_names:
                    deps.add(expr.step)
            except ValueError:
                pass

        for dep in deps:
            adjacency[dep].append(s.step)
            in_degree[s.step] += 1

    queue = [name for name, deg in in_degree.items() if deg == 0]
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for neighbor in adjacency[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if visited != len(config.dag):
        errors.append("Circular dependency detected in DAG")

    if errors:
        raise PipelineConfigError(errors)
