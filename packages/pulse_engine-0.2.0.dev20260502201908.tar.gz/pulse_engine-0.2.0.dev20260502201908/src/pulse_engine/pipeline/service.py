from __future__ import annotations

from typing import Any

from pulse_engine.pipeline.models import PipelineRunModel
from pulse_engine.pipeline.repositories import (
    ModuleRegistryRepository,
    PipelineRunRepository,
)
from pulse_engine.pipeline.schemas import PipelineConfig
from pulse_engine.pipeline.translators.base import (
    BaseStatusProvider,
    BaseTranslator,
    PipelineStatus,
)


class PipelineServiceError(Exception):
    pass


class PipelineSubmissionError(PipelineServiceError):
    pass


class PipelineService:
    def __init__(
        self,
        module_repo: ModuleRegistryRepository,
        run_repo: PipelineRunRepository,
        translators: dict[str, BaseTranslator],
        status_providers: dict[str, BaseStatusProvider],
        settings: Any,
        token_issuer: Any,
    ) -> None:
        self._module_repo = module_repo
        self._run_repo = run_repo
        self._translators = translators
        self._status_providers = status_providers
        self._settings = settings
        self._token_issuer = token_issuer

    async def trigger(
        self,
        tenant_id: str,
        product: str,
        orchestrator: str,
        config: PipelineConfig,
        input_data: list[dict[str, Any]],
        global_config: dict[str, Any],
    ) -> str:
        """Trigger a pipeline. Returns the pipeline run ID."""
        # Validate orchestrator
        if orchestrator not in self._translators:
            raise PipelineServiceError(f"Unsupported orchestrator: '{orchestrator}'")

        # Resolve module images
        images = await self._module_repo.get_images_map(tenant_id, product)
        missing = [m.name for m in config.modules if m.module not in images]
        if missing:
            raise PipelineServiceError(
                f"Modules not registered for product '{product}': {missing}"
            )

        # Create pipeline run record
        run = await self._run_repo.create(
            tenant_id=tenant_id,
            product=product,
            orchestrator=orchestrator,
            config_snapshot=config.model_dump(mode="json", by_alias=True),
            input_snapshot=input_data,
            global_config=global_config,
        )

        # Issue run-scoped token
        token = self._token_issuer.issue_token(
            pipeline_run_id=run.id,
            tenant_id=tenant_id,
        )

        # Submit to orchestrator
        translator = self._translators[orchestrator]
        try:
            orchestrator_run_id = await translator.submit(
                pipeline_run_id=run.id,
                parsed_config=config,
                module_images=images,
                input_data=input_data,
                global_config=global_config,
                tenant_id=tenant_id,
                pulse_engine_url=self._settings.pulse_engine_url,
                pulse_api_token=token,
            )
        except Exception as e:
            await self._run_repo.update_status(run.id, "submission_failed")
            raise PipelineSubmissionError(
                f"Failed to submit pipeline to {orchestrator}: {e}"
            ) from e

        await self._run_repo.set_orchestrator_run_id(run.id, orchestrator_run_id)
        await self._run_repo.update_status(run.id, "running")
        return run.id

    async def get_run(self, tenant_id: str, run_id: str) -> PipelineRunModel | None:
        """Get a pipeline run record."""
        return await self._run_repo.get(run_id, tenant_id)

    async def get_status(self, tenant_id: str, run_id: str) -> PipelineStatus | None:
        """Get normalized pipeline status."""
        run = await self._run_repo.get(run_id, tenant_id)
        if run is None:
            return None

        if run.orchestrator_run_id is None:
            return PipelineStatus(status=run.status, steps=[])

        provider = self._status_providers.get(run.orchestrator)
        if provider is None:
            return PipelineStatus(status=run.status, steps=[])

        status = await provider.get_status(run.orchestrator_run_id)

        # Cache top-level status
        if status.status != run.status:
            await self._run_repo.update_status(run_id, status.status)

        return status

    async def cancel(self, tenant_id: str, run_id: str) -> bool:
        """Cancel a running pipeline."""
        run = await self._run_repo.get(run_id, tenant_id)
        if run is None:
            return False

        if run.orchestrator_run_id is None:
            await self._run_repo.update_status(run_id, "cancelled")
            return True

        provider = self._status_providers.get(run.orchestrator)
        if provider is None:
            return False

        result = await provider.cancel(run.orchestrator_run_id)
        if result:
            await self._run_repo.update_status(run_id, "cancelled")
        return result

    async def list_runs(
        self,
        tenant_id: str,
        product: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[PipelineRunModel], int]:
        return await self._run_repo.list_runs(
            tenant_id, product=product, status=status, limit=limit, offset=offset
        )
