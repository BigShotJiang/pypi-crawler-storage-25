# Gittchi 🐾

> 내 GitHub를 이해하는 AI 펫 — 혼자 개발하는 사람의 유일한 동반자

---

## 왜 만드는가

혼자 사이드 프로젝트를 하다 보면 아무도 봐주지 않고, 반응도 없고, 결국 동기부여가 사라져 포기하게 된다.
Gittchi는 git commit을 먹이로 자라는 AI 펫을 통해 이 외로움과 동기부여 문제를 해결한다.

---

## One-liner

**"커밋할 때마다 반응하고, 나의 개발 여정을 기억하는 AI 동반자"**

---

## 핵심 가치

| 문제 | Gittchi 해결 |
|------|---------------|
| 혼자 개발 → 외로움 | 펫이 커밋마다 반응 |
| 동기부여 사라짐 | 상태 시스템 (방치하면 아파함) |
| 나의 성장이 안 보임 | `/petinfo` 포트폴리오 자동 생성 |
| 경쟁/자극 없음 | 글로벌 랭킹 (v2) |

---

## 차별점

기존 펫 툴들은 커밋 횟수를 세는 단순한 다마고치다.

Gittchi는 다르다:
- **커밋 내용을 읽는다** — 숫자가 아닌 맥락을 이해
- **개발자를 기억한다** — 과거 레포 분석으로 나를 파악
- **시간이 쌓일수록 나를 더 잘 안다** — 단순 도구가 아닌 동반자

```
기존 툴: "커밋 감사해요! +10 행복"
Gittchi: "오 드디어 그 인증 버그 고쳤네. 저번에 힘들어 보였는데."
```

---

## 대상 사용자

- 사이드 프로젝트를 혼자 진행하는 개발자
- 꾸준히 커밋하는 습관을 만들고 싶은 개발자
- 포트폴리오 자동 정리가 필요한 취준생

---

## 펫 종류 (4종)

| 펫 | 성격 | 특징 |
|----|------|------|
| 🐶 강아지 | 열정형 | 커밋마다 폭발적 반응, 오랜만에 오면 난리남 |
| 🐱 고양이 | 츤데레 | 칭찬 아끼지만 은근 응원, 오랜만에 오면 슬며시 다가옴 |
| 🐰 토끼 | 감성형 | 섬세하고 공감 잘함, 새벽 커밋에 걱정해줌 |
| 🐻 곰 | 듬직형 | 과묵하지만 깊은 응원, 묵묵히 옆에 있어줌 |

---

## 상태 시스템

기준 시간은 설정으로 조정 가능 (기본값 기준).

### 지속 상태 (커밋 빈도 기반)

| 상태 | 이모지 | 트리거 |
|------|--------|--------|
| 보통 | 😐 | 기본 상태 |
| 행복 | 😊 | 오늘 커밋 있음 |
| 신남 | 😄 | 3일 연속 커밋 |
| 최고 | 🥰 | 7일 연속 커밋 |
| 배고픔 | 😮‍💨 | 마지막 커밋 2일 이상 |
| 슬픔 | 😢 | 마지막 커밋 5일 이상 |
| 아픔 | 🤒 | 마지막 커밋 7일 이상 |
| 위중 | 😷 | 마지막 커밋 10일 이상 |

### 일시적 상태

| 상태 | 이모지 | 트리거 | 지속 |
|------|--------|--------|------|
| 화남 | 😤 | 빈 커밋 메시지, 같은 버그 반복 | 다음 커밋까지만 |

**회복:** 어떤 커밋이든 하면 지속 상태 회복 (feat/fix → 빠른 회복, chore/docs → 느린 회복)

---

## 커밋 타입별 효과

Conventional Commits 규약(`feat:`, `fix:` 등)을 사용할수록 XP 혜택이 크다.
규약을 쓰지 않으면 chore 수준의 기본 XP만 지급된다.

| 커밋 | 음식 비유 | XP |
|------|----------|----|
| feat | 🍖 영양식 | 창의력 +15 |
| fix  | 💊 약 | 문제해결 +15 |
| refactor | 🥗 건강식 | 완성도 +12 |
| test | 🥦 보약 | 신뢰도 +20 |
| docs | 🍵 차 | 소통력 +8 |
| chore | 🍬 간식 | 소량 회복 |
| 규약 없는 메시지 | 🍺 정크푸드 | chore 수준 최소 XP |
| 빈 메시지 | ☠️ 독 | XP 없음 + 화남 트리거 |

---

## 커맨드

```bash
gittchi init          # 최초 설정 (이름, 펫 선택, GitHub 연동) + global hook 자동 설치
gittchi attach        # 팀 레포 등 global hook 외 추가 레포에 hook 설치
gittchi hello         # 펫 불러오기 (대화)
gittchi petinfo       # 내 개발자 프로필 + 포트폴리오
gittchi status        # 펫 상태 확인
gittchi uninstall     # 작별 인사 후 삭제
```

---

## git hook 설치 방식

`gittchi init` 시 다음을 수행한다:

1. `~/.gittchi/hooks/post-commit` 에 global hook 설치
2. `git config --global core.hooksPath ~/.gittchi/hooks` 설정
3. 직전 `core.hooksPath` 값이 있었다면 `config.json` 에 저장 (uninstall 시 복원용 + hook 체이닝용)

이후 모든 레포에서 커밋 시 자동으로 반응한다.

> `~/.config/git/hooks/`를 쓰지 않는 이유: macOS/Linux 모두 `core.hooksPath`가 명시적으로 설정되지 않으면 무시되며, Gittchi 전용 디렉터리를 소유하는 편이 사용자 기존 hook과 충돌하지 않는다.

### 기존 hook 체이닝

사용자가 이미 다른 도구로 `core.hooksPath` 를 쓰고 있을 수 있다. Gittchi의 `post-commit` 은 직전 hook을 먼저 실행한 뒤 자기 반응을 출력한다 — 사용자 기존 워크플로 보존.

`gittchi attach`는 global hook이 적용되지 않는 특수 환경(팀 레포에서 `core.hooksPath` override, 다른 git config 등)에서만 사용한다.

---

## 사용 시나리오

### 첫 설치
```bash
pip install gittchi
gittchi init

🥚 Gittchi에 오신 걸 환영합니다!
펫의 이름을 지어주세요: > 코코

어떤 펫으로 키울까요?
[🐶 강아지] [🐱 고양이] [🐰 토끼] [🐻 곰]
> 🐱

GitHub username: > tpwls9494
AI API 키를 입력해주세요 (Gemini/Claude/GPT): > ...
코코가 당신의 GitHub를 분석 중입니다...

코코: "...생각보다 열심히 했네. Python이 제일 많고 주로 새벽에 코딩하더라."
```

### 커밋 시 자동 반응
```bash
$ git commit -m "feat: 로그인 기능 추가"
[main 3f2a1c] feat: 로그인 기능 추가

코코: "오 드디어 로그인 됐어? 저번에 힘들어 보였는데. 나쁘지 않아."
      [😊 행복] [창의력 XP +15] [Lv.3 → Lv.4]
```

### /hello 대화
```bash
$ gittchi hello
코코: "왜 불렀어"
> 오늘 뭐 할까?
코코: "어제 feat 커밋하고 오늘 아무것도 안 했잖아. 그 기능 테스트는 짰어?"
> 아직...
코코: "...그럴 줄 알았어. Python은 잘하면서 테스트는 항상 미루더라."
```

### 오랜만에 복귀 (고양이)
```bash
$ gittchi hello
코코: "...왔어?"
      "...딱히 기다린 건 아니거든."
      [😢 슬픔 — 커밋하면 회복됩니다]
```

### /petinfo — 포트폴리오 자동 생성
```bash
$ gittchi petinfo

╔══════════════════════════════════════════════╗
║  🐱 코코 (Lv.12)          주인: tpwls9494   ║
║  함께한 기간: 127일        총 커밋: 342개    ║
╚══════════════════════════════════════════════╝

🧠 Developer DNA
  "AI 백엔드 빌더 — 빠른 프로토타입과 LLM에 강점"
  주로 새벽에 집중, 아이디어를 빠르게 MVP로 만드는 스타일

🛠 Tech Stack
  ┌─────────────────────────────────────┐
  │ Python      ████████░░  82%  Expert │
  │ FastAPI     ███████░░░  71%  Strong │
  │ LangChain   ███████░░░  68%  Strong │
  │ React       █████░░░░░  53%  Mid    │
  │ Docker      ████░░░░░░  41%  Basic  │
  └─────────────────────────────────────┘

⚡ 강점
  · LLM/RAG 파이프라인 설계 (프로젝트 4개)
  · 빠른 MVP 구현 (평균 2주 내 배포)
  · API 설계 및 백엔드 아키텍처

⚠️  개선 포인트
  · 테스트 코드 비율 3% (업계 평균 20%)
  · 프론트엔드 커밋 비율 낮음

📅 활동 패턴
  · 주 활동: 화~목 / 주로 오후 10시~새벽 2시
  · 평균 커밋 간격: 1.2일
  · 가장 많이 쓰는 커밋: feat (41%), fix (28%)

📁 대표 프로젝트
  ┌─────────────────────────────────────────────────┐
  │ PASS       AI 특허 명세서 자동 생성 시스템      │
  │            Python · FastAPI · Qwen3 · FAISS     │
  │                                                 │
  │ Shop-RAG   이커머스 AI 고객 상담 플랫폼         │
  │            LangGraph · FastAPI · Supabase       │
  │                                                 │
  │ Zivo       한일 항공권 최저가 조합 서비스        │
  │            Next.js · FastAPI · PostgreSQL       │
  └─────────────────────────────────────────────────┘

🏷️  한줄 소개 (포트폴리오용)
  "LLM/RAG 기반 AI 백엔드 개발자.
   아이디어를 빠르게 프로덕트로 만드는 것을 좋아하며
   Python과 FastAPI로 3개 이상의 AI 서비스를 배포한 경험 보유."
```

---

## 메모리 시스템

```
단기 기억  →  최근 커밋 50개 (상세)
중기 기억  →  월별 활동 요약 (최근 6개월)
장기 기억  →  개발자 프로필 (압축된 핵심 특성)
대화 기억  →  최근 10턴

커밋 50개 초과 → 월별 요약으로 자동 압축
월별 요약 6개 초과 → 분기 요약으로 압축
```

---

## 기술 스택

```
Python + Typer    → CLI 인터페이스
Rich              → 터미널 UI (ASCII 펫, 색상, 패널)
LiteLLM           → AI 멀티 프로바이더 (Gemini, Claude, GPT 등)
GitPython         → 로컬 git 히스토리/diff 읽기
requests          → GitHub API 호출
python-dotenv     → 환경변수 관리
HMAC + JSON       → 상태 저장 + 변조 감지
pyproject.toml    → pip 패키지 빌드
```

### AI 프로바이더 선택 (BYOK — Bring Your Own Key)

유저가 직접 API 키를 제공한다. 커밋마다 1회 호출.

```bash
gittchi init --model gemini/gemini-2.5-flash  # 기본값 (무료 티어 활용 가능)
gittchi init --model claude-sonnet-4-6
gittchi init --model gpt-4o
```

---

## 파일 구조

```
~/.gittchi/
├── pet.json          # 펫 상태 (HMAC 서명 포함)
├── memory.json       # 커밋 기억 (3단계)
├── config.json       # API 키, 모델 설정, 상태 시스템 기준 시간, prev_hooks_path
├── .hmac_key         # HMAC 키 (chmod 600)
└── hooks/
    └── post-commit   # global hook (gittchi init 시 자동 설치)
                      # git config --global core.hooksPath ~/.gittchi/hooks
```

---

## MVP 범위

### Priority 1 (반드시)
- 온보딩 (이름 + 펫 선택 + GitHub 연동 + API 키 입력)
- global git hook + 커밋 자동 반응
- `/hello` 맥락 있는 대화
- `/petinfo` 포트폴리오 생성 ← 시간 부족 시 가장 먼저 제외
- 변조 감지 (HMAC)

### Priority 2 (시간 되면)
- 상태 시스템 (방치 → 아픔 → 회복)
- `uninstall` 작별 메시지

### v2 (해커톤 이후)
- 글로벌 랭킹 (`/rank`)
- 웹 대시보드
- 멀티 프로젝트 지원

---

## 변조 감지

- `pet.json` HMAC 서명으로 직접 XP/레벨 수정 감지
- 변조 감지 시 펫 초기화 (벌칙)
- 재설치 = 새 펫 시작 (이전 펫과 작별)
- 완전한 보안이 아닌 캐주얼한 조작 방지 목적
