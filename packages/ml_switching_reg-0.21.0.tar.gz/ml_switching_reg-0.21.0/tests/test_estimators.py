import numpy as np
import pandas as pd
import pytest

from ml_switching_reg.irls import IRLSScoreWildBootstrap, MLSwitchingRegIRLS
from ml_switching_reg.mle import (
    DriverSpecificProbUberMLE,
    get_mle_betas,
    get_mle_sigmas,
)


pytestmark = pytest.mark.filterwarnings(
    "ignore:df_resid differs from nobs - k_params:UserWarning"
)

R = 2
P = 2
N_DRIVERS = 40
TIME_PERIODS = 3


def _make_panel_dataset(time_periods=TIME_PERIODS, seed=123):
    rng = np.random.default_rng(seed)
    n_obs = N_DRIVERS * time_periods
    driver_ids = np.repeat(np.arange(N_DRIVERS), time_periods)
    time_ids = np.tile(np.arange(time_periods), N_DRIVERS)

    x = rng.standard_normal(n_obs)
    X = np.column_stack([np.ones(n_obs), x])
    X_list = [X.copy() for _ in range(R)]

    true_beta = np.array([[1.0, -1.5], [3.0, 2.0]])
    regime_per_driver = rng.integers(0, R, size=N_DRIVERS)
    regime_per_obs = regime_per_driver[driver_ids]
    y = np.array([X[i] @ true_beta[regime_per_obs[i]] for i in range(n_obs)])
    y += rng.normal(0.0, 0.8, size=n_obs)

    cm_raw = np.array([[0.8, 0.2], [0.2, 0.8]], dtype=float)
    cm = cm_raw / cm_raw.sum(axis=0)

    cp_driver = np.zeros((N_DRIVERS, R))
    for d, regime in enumerate(regime_per_driver):
        cp_driver[d, regime] = 0.85
        cp_driver[d, 1 - regime] = 0.15
    cp_driver += rng.uniform(0.0, 0.02, size=(N_DRIVERS, R))
    cp_driver /= cp_driver.sum(axis=1, keepdims=True)
    cp = cp_driver[driver_ids]

    beta_init = np.zeros((R, P))
    hard_regime = cp.argmax(axis=1)
    for regime in range(R):
        mask = hard_regime == regime
        beta_init[regime] = np.linalg.lstsq(X[mask], y[mask], rcond=None)[0]

    df = pd.DataFrame(
        {
            "driver": driver_ids,
            "time": time_ids,
            "y": y,
            "x": x,
        }
    ).set_index(["driver", "time"])

    return {
        "y": y,
        "X_list": X_list,
        "cp": cp,
        "cm": cm,
        "driver_ids": driver_ids,
        "beta_init": beta_init,
        "df": df,
        "n_obs": n_obs,
        "time_periods": time_periods,
    }


def _fit_irls(dataset, use_driver_ids):
    driver_ids = dataset["driver_ids"] if use_driver_ids else None
    mod = MLSwitchingRegIRLS(
        dataset["y"],
        dataset["X_list"],
        dataset["cp"],
        dataset["cm"],
        driver_ids=driver_ids,
    )
    beta, sigma2 = mod.fit(
        dataset["beta_init"].copy(),
        float(np.var(dataset["y"])),
        tol=1e-10,
        max_iter=500,
    )
    return {"mod": mod, "beta": beta, "sigma2": sigma2}


def _make_shared_beta_dataset(time_periods=TIME_PERIODS, seed=456):
    rng = np.random.default_rng(seed)
    n_obs = N_DRIVERS * time_periods
    driver_ids = np.repeat(np.arange(N_DRIVERS), time_periods)
    time_ids = np.tile(np.arange(time_periods), N_DRIVERS)

    shock_0 = rng.standard_normal(n_obs)
    shock_1 = rng.standard_normal(n_obs)
    shock_lag_0 = np.roll(shock_0, 1)
    shock_lag_1 = np.roll(shock_1, 1)

    for d in range(N_DRIVERS):
        first = d * time_periods
        shock_lag_0[first] = 0.0
        shock_lag_1[first] = 0.0

    X_list = [
        np.column_stack([np.ones(n_obs), shock_0, shock_lag_0]),
        np.column_stack([np.ones(n_obs), shock_1, shock_lag_1]),
    ]

    true_beta = np.array([0.75, 1.4, -0.6])
    regime_per_driver = rng.integers(0, R, size=N_DRIVERS)
    regime_per_obs = regime_per_driver[driver_ids]
    y = np.array([X_list[regime_per_obs[i]][i] @ true_beta for i in range(n_obs)])
    y += rng.normal(0.0, 0.6, size=n_obs)

    cm_raw = np.array([[0.82, 0.18], [0.18, 0.82]], dtype=float)
    cm = cm_raw / cm_raw.sum(axis=0)

    cp_driver = np.zeros((N_DRIVERS, R))
    for d, regime in enumerate(regime_per_driver):
        cp_driver[d, regime] = 0.88
        cp_driver[d, 1 - regime] = 0.12
    cp_driver += rng.uniform(0.0, 0.02, size=(N_DRIVERS, R))
    cp_driver /= cp_driver.sum(axis=1, keepdims=True)
    cp = cp_driver[driver_ids]

    df = pd.DataFrame(
        {
            "driver": driver_ids,
            "time": time_ids,
            "y": y,
            "shock_0": shock_0,
            "shock_lag_0": shock_lag_0,
            "shock_1": shock_1,
            "shock_lag_1": shock_lag_1,
        }
    ).set_index(["driver", "time"])

    return {
        "y": y,
        "X_list": X_list,
        "cp": cp,
        "cm": cm,
        "driver_ids": driver_ids,
        "beta_init": true_beta + np.array([0.1, -0.1, 0.05]),
        "df": df,
    }


def _fit_mle(dataset, beta, sigma2, use_driver_ids):
    driver_ids = dataset["driver_ids"] if use_driver_ids else None
    start_params = np.append(beta.flatten(), np.sqrt(max(sigma2, 1e-8)))
    mod = DriverSpecificProbUberMLE.from_arrays(
        dataset["y"],
        dataset["X_list"],
        dataset["cp"],
        dataset["cm"],
        start_params=start_params,
        driver_ids=driver_ids,
    )
    res, _ = mod.fit(disp=0, maxiter=500)
    params = np.asarray(res.params, dtype=float)
    return {
        "mod": mod,
        "res": res,
        "params": params,
        "beta": params[:-1].reshape(R, P),
        "sigma2": float(params[-1]) ** 2,
    }


def _fit_pair(dataset, use_driver_ids):
    irls = _fit_irls(dataset, use_driver_ids=use_driver_ids)
    mle = _fit_mle(dataset, irls["beta"], irls["sigma2"], use_driver_ids=use_driver_ids)
    return {"irls": irls, "mle": mle}


def _fit_shared_beta_pair(dataset, use_driver_ids):
    driver_ids = dataset["driver_ids"] if use_driver_ids else None
    irls_mod = MLSwitchingRegIRLS(
        dataset["y"],
        dataset["X_list"],
        dataset["cp"],
        dataset["cm"],
        driver_ids=driver_ids,
        shared_beta=True,
    )
    irls_beta, irls_sigma2 = irls_mod.fit(
        dataset["beta_init"],
        float(np.var(dataset["y"])),
        tol=1e-10,
        max_iter=500,
    )

    start_params = np.append(irls_beta, np.sqrt(max(irls_sigma2, 1e-8)))
    mle_mod = DriverSpecificProbUberMLE.from_arrays(
        dataset["y"],
        dataset["X_list"],
        dataset["cp"],
        dataset["cm"],
        start_params=start_params,
        driver_ids=driver_ids,
        shared_beta=True,
    )
    mle_res, _ = mle_mod.fit(disp=0, maxiter=500)
    params = np.asarray(mle_res.params, dtype=float)
    return {
        "irls": {"mod": irls_mod, "beta": irls_beta, "sigma2": irls_sigma2},
        "mle": {
            "mod": mle_mod,
            "res": mle_res,
            "params": params,
            "beta": params[:-1],
            "sigma2": float(params[-1]) ** 2,
        },
    }


@pytest.fixture(scope="module")
def panel_dataset():
    return _make_panel_dataset(time_periods=TIME_PERIODS, seed=123)


@pytest.fixture(scope="module")
def driver_level_fit(panel_dataset):
    return _fit_pair(panel_dataset, use_driver_ids=True)


@pytest.fixture(scope="module")
def obs_level_fit(panel_dataset):
    return _fit_pair(panel_dataset, use_driver_ids=False)


@pytest.fixture(scope="module")
def formula_fit(panel_dataset):
    formula = "y ~ x"

    irls_arrays = _fit_irls(panel_dataset, use_driver_ids=True)

    irls_formula_mod = MLSwitchingRegIRLS.from_formula(
        formula,
        panel_dataset["df"],
        panel_dataset["cp"],
        panel_dataset["cm"],
    )
    irls_formula_beta, irls_formula_sigma2 = irls_formula_mod.fit(
        panel_dataset["beta_init"].copy(),
        float(np.var(panel_dataset["y"])),
        tol=1e-10,
        max_iter=500,
    )

    start_params = np.append(
        irls_arrays["beta"].flatten(), np.sqrt(max(irls_arrays["sigma2"], 1e-8))
    )
    mle_arrays = DriverSpecificProbUberMLE.from_arrays(
        panel_dataset["y"],
        panel_dataset["X_list"],
        panel_dataset["cp"],
        panel_dataset["cm"],
        start_params=start_params,
        driver_ids=panel_dataset["driver_ids"],
    )
    mle_arrays_res, _ = mle_arrays.fit(disp=0, maxiter=500)

    mle_formula = DriverSpecificProbUberMLE.from_formula_arrays(
        formula,
        panel_dataset["df"],
        panel_dataset["cp"],
        panel_dataset["cm"],
        start_params=start_params,
    )
    mle_formula_res, _ = mle_formula.fit(disp=0, maxiter=500)

    return {
        "irls_arrays": irls_arrays,
        "irls_formula": {
            "mod": irls_formula_mod,
            "beta": irls_formula_beta,
            "sigma2": irls_formula_sigma2,
        },
        "mle_arrays": {"mod": mle_arrays, "res": mle_arrays_res},
        "mle_formula": {"mod": mle_formula, "res": mle_formula_res},
    }


@pytest.fixture(scope="module")
def t1_equivalence_fit():
    dataset = _make_panel_dataset(time_periods=1, seed=999)
    return {
        "obs": _fit_pair(dataset, use_driver_ids=False),
        "driver": _fit_pair(dataset, use_driver_ids=True),
    }


@pytest.fixture(scope="module")
def shared_beta_dataset():
    return _make_shared_beta_dataset(time_periods=TIME_PERIODS, seed=456)


@pytest.fixture(scope="module")
def shared_beta_fit(shared_beta_dataset):
    return _fit_shared_beta_pair(shared_beta_dataset, use_driver_ids=True)


class TestIRLS:
    def test_fit_sets_expected_attributes(self, driver_level_fit):
        mod = driver_level_fit["irls"]["mod"]
        np.testing.assert_allclose(mod.beta_, driver_level_fit["irls"]["beta"])
        assert mod.sigma2_ == pytest.approx(driver_level_fit["irls"]["sigma2"])
        assert mod.history
        assert mod.history[-1] < 1e-8

    def test_estep_returns_probabilities(self, driver_level_fit, panel_dataset):
        mod = driver_level_fit["irls"]["mod"]
        rrh = mod._estep(driver_level_fit["irls"]["beta"], driver_level_fit["irls"]["sigma2"])
        assert rrh.shape == (R, panel_dataset["n_obs"])
        assert np.all(rrh >= 0)
        np.testing.assert_allclose(rrh.sum(axis=0), np.ones(panel_dataset["n_obs"]))

    def test_rejects_varying_driver_weights(self):
        rng = np.random.default_rng(321)
        y = rng.standard_normal(6)
        X = np.column_stack([np.ones(6), rng.standard_normal(6)])
        cp = np.array(
            [
                [0.9, 0.1],
                [0.8, 0.2],
                [0.85, 0.15],
                [0.2, 0.8],
                [0.1, 0.9],
                [0.3, 0.7],
            ]
        )
        cm = np.eye(R)
        driver_ids = np.repeat(np.arange(2), 3)

        with pytest.raises(AssertionError, match="weighted_cm not constant within driver"):
            MLSwitchingRegIRLS(y, [X, X], cp, cm, driver_ids=driver_ids)


class TestIRLSInference:
    def test_score_obs_rows_match_independent_units(self, driver_level_fit, obs_level_fit):
        driver_scores = driver_level_fit["irls"]["mod"].score_obs()
        obs_scores = obs_level_fit["irls"]["mod"].score_obs()

        assert driver_scores.shape == (N_DRIVERS, R * P + 1)
        assert obs_scores.shape == (N_DRIVERS * TIME_PERIODS, R * P + 1)

    def test_score_is_near_zero_at_solution(self, driver_level_fit):
        score = driver_level_fit["irls"]["mod"].score_obs().sum(axis=0)
        np.testing.assert_allclose(score, np.zeros(R * P + 1), atol=1e-7)

    def test_louis_information_decomposition(self, driver_level_fit):
        mod = driver_level_fit["irls"]["mod"]
        observed = mod.information(kind="louis")
        complete = mod.information(kind="uncorrected")
        missing = mod.information(kind="missing")

        np.testing.assert_allclose(observed, complete - missing, atol=1e-10)
        assert observed.shape == (R * P + 1, R * P + 1)

    def test_louis_and_uncorrected_standard_errors_are_finite(self, driver_level_fit):
        mod = driver_level_fit["irls"]["mod"]
        bse_louis = mod.bse(kind="louis", transform="sigma")
        bse_uncorrected = mod.bse(kind="uncorrected", transform="sigma")

        assert bse_louis.shape == (R * P + 1,)
        assert bse_uncorrected.shape == (R * P + 1,)
        assert np.all(np.isfinite(bse_louis))
        assert np.all(np.isfinite(bse_uncorrected))
        assert np.all(bse_louis > 0)
        assert np.all(bse_uncorrected > 0)
        assert not np.allclose(bse_louis, bse_uncorrected)

    def test_sandwich_bse_matches_mle_robust_bse(self, driver_level_fit):
        irls_bse = driver_level_fit["irls"]["mod"].bse(
            kind="sandwich", transform="sigma"
        )
        mle_bse = np.asarray(driver_level_fit["mle"]["res"].bse, dtype=float)

        np.testing.assert_allclose(irls_bse, mle_bse, atol=1e-6, rtol=1e-5)

    def test_param_names_and_transforms(self, driver_level_fit):
        mod = driver_level_fit["irls"]["mod"]
        assert mod.param_names(transform="sigma")[-1] == "sigma"
        assert mod.param_names(transform="sigma2")[-1] == "sigma2"
        assert mod.param_names(transform="eta")[-1] == "eta"
        assert len(mod.params(transform="sigma")) == R * P + 1

    def test_score_bootstrap_method_sets_attributes(self, driver_level_fit):
        mod = driver_level_fit["irls"]["mod"]
        swb = mod.score_bootstrap(bootstrap_num=5, n_jobs=1, seed=11)

        assert isinstance(swb, IRLSScoreWildBootstrap)
        assert swb.wald_boot_.shape == (5, R * P + 1)
        assert swb.pvalues_.shape == (R * P + 1,)
        assert swb.bse_boot_.shape == (R * P + 1,)
        assert swb.conf_int_boot_.shape == (R * P + 1, 2)


class TestMLE:
    def test_fit_returns_named_params_and_finite_standard_errors(self, driver_level_fit):
        res = driver_level_fit["mle"]["res"]
        assert isinstance(res.params, pd.Series)
        assert list(res.params.index) == [
            "beta_0_0",
            "beta_0_1",
            "beta_1_0",
            "beta_1_1",
            "sigma",
        ]
        assert bool(res.mle_retvals["converged"])
        assert np.all(np.isfinite(np.asarray(res.bse)))
        assert abs(float(res.params["sigma"])) > 0

    def test_helper_extractors_match_fitted_result(self, driver_level_fit):
        res = driver_level_fit["mle"]["res"]
        beta0, beta1, flat = get_mle_betas(res, regimes=R)
        expected_beta = driver_level_fit["mle"]["beta"]

        np.testing.assert_allclose(beta0, expected_beta[:, 0])
        np.testing.assert_allclose(beta1, expected_beta[:, 1])
        np.testing.assert_allclose(flat, np.append(expected_beta[:, 0], expected_beta[:, 1]))

        sigma = abs(float(res.params["sigma"]))
        np.testing.assert_allclose(get_mle_sigmas(res, regimes=R), np.full(R, sigma))
        assert get_mle_sigmas(res) == pytest.approx(sigma)


class TestEstimatorAgreement:
    def test_driver_level_mle_matches_irls(self, driver_level_fit):
        np.testing.assert_allclose(
            driver_level_fit["mle"]["beta"],
            driver_level_fit["irls"]["beta"],
            atol=1e-10,
            rtol=1e-10,
        )
        assert driver_level_fit["mle"]["sigma2"] == pytest.approx(
            driver_level_fit["irls"]["sigma2"], abs=1e-10
        )

    def test_observation_level_mle_matches_irls(self, obs_level_fit):
        np.testing.assert_allclose(
            obs_level_fit["mle"]["beta"],
            obs_level_fit["irls"]["beta"],
            atol=1e-10,
            rtol=1e-10,
        )
        assert obs_level_fit["mle"]["sigma2"] == pytest.approx(
            obs_level_fit["irls"]["sigma2"], abs=1e-10
        )

    def test_formula_interfaces_match_arrays(self, formula_fit):
        np.testing.assert_allclose(
            formula_fit["irls_formula"]["beta"],
            formula_fit["irls_arrays"]["beta"],
            atol=1e-10,
            rtol=1e-10,
        )
        assert formula_fit["irls_formula"]["sigma2"] == pytest.approx(
            formula_fit["irls_arrays"]["sigma2"], abs=1e-10
        )

        np.testing.assert_allclose(
            np.asarray(formula_fit["mle_formula"]["res"].params, dtype=float),
            np.asarray(formula_fit["mle_arrays"]["res"].params, dtype=float),
            atol=1e-10,
            rtol=1e-10,
        )

    def test_driver_ids_change_the_likelihood_when_t_is_greater_than_one(
        self, driver_level_fit, obs_level_fit
    ):
        assert driver_level_fit["mle"]["mod"].nobs == float(N_DRIVERS)
        assert obs_level_fit["mle"]["mod"].nobs == float(N_DRIVERS * TIME_PERIODS)

        irls_gap = np.max(
            np.abs(driver_level_fit["irls"]["beta"] - obs_level_fit["irls"]["beta"])
        )
        mle_gap = np.max(
            np.abs(driver_level_fit["mle"]["params"] - obs_level_fit["mle"]["params"])
        )

        assert irls_gap > 1e-3
        assert mle_gap > 1e-3

    def test_t1_driver_and_observation_likelihoods_are_equivalent(
        self, t1_equivalence_fit
    ):
        obs = t1_equivalence_fit["obs"]
        driver = t1_equivalence_fit["driver"]

        np.testing.assert_allclose(obs["irls"]["beta"], driver["irls"]["beta"], atol=1e-10)
        assert obs["irls"]["sigma2"] == pytest.approx(driver["irls"]["sigma2"], abs=1e-10)

        np.testing.assert_allclose(obs["mle"]["params"], driver["mle"]["params"], atol=1e-10)
        assert obs["mle"]["res"].llf == pytest.approx(driver["mle"]["res"].llf, abs=1e-10)
        np.testing.assert_allclose(obs["mle"]["res"].bse, driver["mle"]["res"].bse, atol=1e-8)


class TestSharedBeta:
    def test_irls_returns_shared_vector(self, shared_beta_fit):
        beta = shared_beta_fit["irls"]["beta"]
        assert beta.shape == (3,)
        np.testing.assert_allclose(shared_beta_fit["irls"]["mod"].beta_, beta)

    def test_mle_returns_shared_param_names(self, shared_beta_fit):
        res = shared_beta_fit["mle"]["res"]
        assert list(res.params.index) == [
            "beta_shared_0",
            "beta_shared_1",
            "beta_shared_2",
            "sigma",
        ]

    def test_driver_level_mle_matches_irls(self, shared_beta_fit):
        np.testing.assert_allclose(
            shared_beta_fit["mle"]["beta"],
            shared_beta_fit["irls"]["beta"],
            atol=1e-10,
            rtol=1e-10,
        )
        assert shared_beta_fit["mle"]["sigma2"] == pytest.approx(
            shared_beta_fit["irls"]["sigma2"], abs=1e-10
        )

    def test_formula_interfaces_match_arrays_for_templated_shared_beta(
        self, shared_beta_dataset, shared_beta_fit
    ):
        formula = "y ~ shock_{r} + shock_lag_{r}"

        irls_formula_mod = MLSwitchingRegIRLS.from_formula(
            formula,
            shared_beta_dataset["df"],
            shared_beta_dataset["cp"],
            shared_beta_dataset["cm"],
            shared_beta=True,
        )
        irls_formula_beta, irls_formula_sigma2 = irls_formula_mod.fit(
            shared_beta_dataset["beta_init"],
            float(np.var(shared_beta_dataset["y"])),
            tol=1e-10,
            max_iter=500,
        )

        start_params = np.append(
            shared_beta_fit["irls"]["beta"],
            np.sqrt(max(shared_beta_fit["irls"]["sigma2"], 1e-8)),
        )
        mle_formula_mod = DriverSpecificProbUberMLE.from_formula_arrays(
            formula,
            shared_beta_dataset["df"],
            shared_beta_dataset["cp"],
            shared_beta_dataset["cm"],
            start_params=start_params,
            shared_beta=True,
        )
        mle_formula_res, _ = mle_formula_mod.fit(disp=0, maxiter=500)

        np.testing.assert_allclose(
            irls_formula_beta,
            shared_beta_fit["irls"]["beta"],
            atol=1e-10,
            rtol=1e-10,
        )
        assert irls_formula_sigma2 == pytest.approx(
            shared_beta_fit["irls"]["sigma2"], abs=1e-10
        )
        np.testing.assert_allclose(
            np.asarray(mle_formula_res.params, dtype=float),
            shared_beta_fit["mle"]["params"],
            atol=1e-10,
            rtol=1e-10,
        )

    def test_formula_requires_varying_template(self, shared_beta_dataset):
        with pytest.raises(ValueError, match="templated formula"):
            MLSwitchingRegIRLS.from_formula(
                "y ~ shock_0 + shock_lag_0",
                shared_beta_dataset["df"],
                shared_beta_dataset["cp"],
                shared_beta_dataset["cm"],
                shared_beta=True,
            )
