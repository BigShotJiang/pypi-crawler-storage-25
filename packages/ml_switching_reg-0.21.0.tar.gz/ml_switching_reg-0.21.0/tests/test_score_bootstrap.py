"""Unit tests for ScoreWildBootstrap."""

import numpy as np
import pandas as pd
import pytest

from ml_switching_reg.mle import DriverSpecificProbUberMLE, ScoreWildBootstrap

# ---------------------------------------------------------------------------
# Shared fixture helpers
# ---------------------------------------------------------------------------

N_DRIVERS = 15
T = 4  # time periods per driver
R = 2  # regimes
P = 2  # params per regime (intercept + slope)
BOOT = 10  # small bootstrap_num for speed


def _make_result(driver_level=True, seed=0):
    """Return (mod, fitted_result, driver_ids) for a small 2-regime model."""
    rng = np.random.default_rng(seed)
    N = N_DRIVERS * T

    X = np.column_stack([np.ones(N), rng.standard_normal(N)])
    X_list = [X] * R

    true_betas = np.array([[2.0, 1.0], [-1.0, 0.5]])
    driver_ids = np.repeat(np.arange(N_DRIVERS), T)
    regime_per_driver = rng.integers(0, R, size=N_DRIVERS)
    regime_per_obs = regime_per_driver[driver_ids]

    y = np.array([X[i] @ true_betas[regime_per_obs[i]] for i in range(N)])
    y += rng.normal(0, 0.5, N)

    # column-normalised confusion matrix
    cm_raw = np.array([[0.8, 0.2], [0.2, 0.8]])
    cm = cm_raw / cm_raw.sum(axis=0)

    if driver_level:
        cp_driver = np.zeros((N_DRIVERS, R))
        for d in range(N_DRIVERS):
            tr = regime_per_driver[d]
            cp_driver[d, tr] = 0.8
            cp_driver[d, 1 - tr] = 0.2
        cp_driver += rng.uniform(0, 0.05, (N_DRIVERS, R))
        cp_driver /= cp_driver.sum(axis=1, keepdims=True)
        cp = cp_driver[driver_ids]
    else:
        cp = np.zeros((N, R))
        for i in range(N):
            tr = regime_per_obs[i]
            cp[i, tr] = 0.8
            cp[i, 1 - tr] = 0.2
        cp += rng.uniform(0, 0.05, (N, R))
        cp /= cp.sum(axis=1, keepdims=True)

    start = np.zeros(R * P + 1)
    for r in range(R):
        mask = regime_per_obs == r
        if mask.sum() > P:
            start[r * P : (r + 1) * P] = np.linalg.lstsq(
                X[mask], y[mask], rcond=None
            )[0]
    start[-1] = float(np.std(y))

    mod = DriverSpecificProbUberMLE.from_arrays(
        y,
        X_list,
        cp,
        cm,
        start_params=start,
        driver_ids=driver_ids if driver_level else None,
    )
    result, _ = mod.fit()
    return mod, result, driver_ids


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def driver_level_result():
    return _make_result(driver_level=True, seed=42)


@pytest.fixture(scope="module")
def obs_level_result():
    return _make_result(driver_level=False, seed=42)


@pytest.fixture(scope="module")
def swb_driver(driver_level_result):
    _, result, _ = driver_level_result
    swb = ScoreWildBootstrap(result)
    swb.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=0)
    return swb


@pytest.fixture(scope="module")
def swb_obs_explicit_clusters(obs_level_result):
    _, result, driver_ids = obs_level_result
    swb = ScoreWildBootstrap(result, clusters=driver_ids)
    swb.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=0)
    return swb


# ---------------------------------------------------------------------------
# __init__ tests
# ---------------------------------------------------------------------------


class TestInit:
    def test_driver_level_uses_singleton_clusters(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        assert swb._singleton_clusters is True
        assert swb.num_clusters == N_DRIVERS

    def test_driver_level_cluster_ids_are_arange(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        np.testing.assert_array_equal(swb.cluster_ids, np.arange(N_DRIVERS))

    def test_obs_level_no_clusters_uses_singleton(self, obs_level_result):
        _, result, _ = obs_level_result
        swb = ScoreWildBootstrap(result)
        assert swb._singleton_clusters is True
        assert swb.num_clusters == N_DRIVERS * T

    def test_explicit_clusters_multi_obs(self, obs_level_result):
        _, result, driver_ids = obs_level_result
        swb = ScoreWildBootstrap(result, clusters=driver_ids)
        assert swb._singleton_clusters is False
        assert swb.num_clusters == N_DRIVERS
        np.testing.assert_array_equal(swb.cluster_obs, np.full(N_DRIVERS, T))

    def test_param_names_set(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        assert len(swb.param_names_) == R * P + 1
        assert "sigma" in swb.param_names_

    def test_beta_hat_is_numpy(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        assert isinstance(swb.beta_hat, np.ndarray)
        assert swb.beta_hat.shape == (R * P + 1,)

    def test_mod_is_model(self, driver_level_result):
        mod, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        assert swb.mod is mod

    def test_driver_level_score_obs_rows_match_drivers(self, driver_level_result):
        mod, result, _ = driver_level_result
        score_obs = mod.score_obs(np.asarray(result.params))
        assert score_obs.shape == (N_DRIVERS, R * P + 1)

    def test_obs_level_score_obs_rows_match_observations(self, obs_level_result):
        mod, result, _ = obs_level_result
        score_obs = mod.score_obs(np.asarray(result.params))
        assert score_obs.shape == (N_DRIVERS * T, R * P + 1)


class TestDriverWeightValidation:
    def test_rejects_varying_weights_with_driver_ids(self):
        rng = np.random.default_rng(123)
        N = 6
        X = np.column_stack([np.ones(N), rng.standard_normal(N)])
        X_list = [X] * R
        y = rng.standard_normal(N)
        cp = np.array(
            [
                [0.9, 0.1],
                [0.8, 0.2],
                [0.85, 0.15],
                [0.2, 0.8],
                [0.1, 0.9],
                [0.3, 0.7],
            ]
        )
        cm = np.eye(R)
        driver_ids = np.repeat(np.arange(2), 3)

        with pytest.raises(ValueError, match="constant within driver"):
            DriverSpecificProbUberMLE.from_arrays(
                y,
                X_list,
                cp,
                cm,
                driver_ids=driver_ids,
            )


# ---------------------------------------------------------------------------
# get_analytical_wald tests
# ---------------------------------------------------------------------------


class TestAnalyticalWald:
    def test_shape(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        aw = swb.get_analytical_wald()
        assert len(aw) == R * P + 1

    def test_all_non_negative(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        aw = np.asarray(swb.get_analytical_wald())
        assert np.all(aw >= 0)


# ---------------------------------------------------------------------------
# wald_test tests
# ---------------------------------------------------------------------------


class TestWaldTest:
    def test_singleton_returns_finite_scalar(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        K = len(swb.beta_hat)
        R_vec = np.identity(K)[0]
        W = np.ones(swb.num_clusters)
        val = swb.wald_test(W=W, R=R_vec)
        assert np.isfinite(val)

    def test_multi_obs_returns_finite_scalar(self, obs_level_result):
        _, result, driver_ids = obs_level_result
        swb = ScoreWildBootstrap(result, clusters=driver_ids)
        K = len(swb.beta_hat)
        R_vec = np.identity(K)[0]
        W = np.ones(swb.num_clusters)
        val = swb.wald_test(W=W, R=R_vec)
        assert np.isfinite(val)

    def test_non_negative(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        K = len(swb.beta_hat)
        R_vec = np.identity(K)[0]
        rng = np.random.default_rng(7)
        W = rng.choice([-1, 1], size=swb.num_clusters)
        val = swb.wald_test(W=W, R=R_vec)
        assert val >= 0


# ---------------------------------------------------------------------------
# get_pvalue tests
# ---------------------------------------------------------------------------


class TestGetPvalue:
    def test_pvalue_shape(self, swb_driver):
        assert swb_driver.pvalues_.shape == (R * P + 1,)

    def test_pvalues_in_unit_interval(self, swb_driver):
        assert np.all(swb_driver.pvalues_ >= 0)
        assert np.all(swb_driver.pvalues_ <= 1)

    def test_wald_boot_shape(self, swb_driver):
        assert swb_driver.wald_boot_.shape == (BOOT, R * P + 1)

    def test_wald_boot_non_negative(self, swb_driver):
        assert np.all(swb_driver.wald_boot_ >= 0)

    def test_bse_boot_shape(self, swb_driver):
        assert swb_driver.bse_boot_.shape == (R * P + 1,)

    def test_bse_boot_positive(self, swb_driver):
        assert np.all(swb_driver.bse_boot_ > 0)

    def test_conf_int_shape(self, swb_driver):
        assert swb_driver.conf_int_boot_.shape == (R * P + 1, 2)

    def test_conf_int_ordering(self, swb_driver):
        lo = swb_driver.conf_int_boot_[:, 0]
        hi = swb_driver.conf_int_boot_[:, 1]
        assert np.all(lo < hi)

    def test_returns_same_as_pvalues_attr(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        pv = swb.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=99)
        np.testing.assert_array_equal(pv, swb.pvalues_)

    def test_multi_obs_path_runs(self, swb_obs_explicit_clusters):
        assert swb_obs_explicit_clusters.pvalues_.shape == (R * P + 1,)
        assert np.all(swb_obs_explicit_clusters.pvalues_ >= 0)

    def test_reproducibility_with_seed(self, driver_level_result):
        _, result, _ = driver_level_result
        swb1 = ScoreWildBootstrap(result)
        pv1 = swb1.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=123)
        swb2 = ScoreWildBootstrap(result)
        pv2 = swb2.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=123)
        np.testing.assert_allclose(pv1, pv2)


# ---------------------------------------------------------------------------
# summary_table tests
# ---------------------------------------------------------------------------


class TestSummaryTable:
    def test_raises_before_get_pvalue(self, driver_level_result):
        _, result, _ = driver_level_result
        swb = ScoreWildBootstrap(result)
        with pytest.raises(RuntimeError, match="get_pvalue"):
            swb.summary_table()

    def test_returns_dataframe(self, swb_driver):
        df = swb_driver.summary_table()
        assert isinstance(df, pd.DataFrame)

    def test_expected_columns(self, swb_driver):
        df = swb_driver.summary_table()
        for col in ("param", "coef", "bse_ols", "bse_boot", "ci_low", "ci_high", "pvalue"):
            assert col in df.columns

    def test_row_count(self, swb_driver):
        df = swb_driver.summary_table()
        assert len(df) == R * P + 1

    def test_sigma_row_present(self, swb_driver):
        df = swb_driver.summary_table()
        assert "sigma" in df["param"].values


# ---------------------------------------------------------------------------
# score_bootstrap convenience method
# ---------------------------------------------------------------------------


class TestScoreBootstrapMethod:
    def test_returns_score_wild_bootstrap(self, driver_level_result):
        mod, result, _ = driver_level_result
        swb = mod.score_bootstrap(result, bootstrap_num=BOOT, n_jobs=1, seed=0)
        assert isinstance(swb, ScoreWildBootstrap)

    def test_attributes_set(self, driver_level_result):
        mod, result, _ = driver_level_result
        swb = mod.score_bootstrap(result, bootstrap_num=BOOT, n_jobs=1, seed=0)
        assert hasattr(swb, "pvalues_")
        assert hasattr(swb, "bse_boot_")
        assert hasattr(swb, "conf_int_boot_")
        assert hasattr(swb, "wald_boot_")

    def test_consistent_with_direct(self, driver_level_result):
        mod, result, _ = driver_level_result
        swb_via_method = mod.score_bootstrap(result, bootstrap_num=BOOT, n_jobs=1, seed=5)
        swb_direct = ScoreWildBootstrap(result)
        swb_direct.get_pvalue(bootstrap_num=BOOT, n_jobs=1, seed=5)
        np.testing.assert_allclose(swb_via_method.pvalues_, swb_direct.pvalues_)
