# ml-switching-reg

`ml-switching-reg` estimates switching regressions when regime labels come from a
misclassified machine-learning classifier instead of being observed perfectly.

The package currently ships three main pieces of functionality:

- `MLSwitchingRegIRLS`: EM/IRLS estimation for switching regression with soft
  misclassification probabilities.
- `DriverSpecificProbUberMLE`: full maximum likelihood estimation for the same
  model, including driver-level panel likelihood.
- `ScoreWildBootstrap`: score wild bootstrap inference for fitted MLE models.

## Documentation Website

The repository now includes a documentation website under `docs/`.

- Serve locally: `uv run --group docs mkdocs serve`
- Build static site: `uv run --group docs mkdocs build`

The site includes:

- package overview and estimator selection guidance
- installation and usage examples
- the mathematical setup behind the likelihood and EM updates
- an API reference for the public estimator classes and helper functions
