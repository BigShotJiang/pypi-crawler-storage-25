"""
MLSwitchingRegIRLS — EM/IRLS estimator for switching regression with soft ML misclassification.

Interface:

    y               : (N,)
    X_list          : list of R arrays each (N, p)  — regime-specific design matrix, all obs
    classifier_pred : (N, R)  — soft ML predictions P(r̃=j) per obs
    cm              : (R, R)  — column-normalized confusion matrix, cm[k,j] = P(true=k | pred=j)

Usage
-----
mod = MLSwitchingRegIRLS(y, X_list, classifier_pred, cm)
beta, sigma2 = mod.fit(beta_0, sigma2_0, l2_lambda=0, tol=1e-6)
"""

import numpy as np
from joblib import Parallel, delayed
from scipy.special import ndtri
from scipy.special import logsumexp


class IRLSScoreWildBootstrap:
    """Score wild bootstrap for fitted :class:`MLSwitchingRegIRLS` models.

    The bootstrap uses the one-step score perturbation
    ``theta_b = theta_hat + H^{-1} sum_g xi_g S_g`` where ``H`` is the
    Louis-corrected observed information and ``S_g`` are independent-unit scores.
    When the IRLS model was fit with ``driver_ids``, scores are already returned
    one row per driver. Otherwise scores are one row per observation and optional
    ``clusters`` can be supplied to aggregate them.
    """

    def __init__(self, fitted_model, clusters=None, transform="sigma"):
        if not hasattr(fitted_model, "beta_") or not hasattr(fitted_model, "sigma2_"):
            raise RuntimeError("Fit MLSwitchingRegIRLS before bootstrapping")

        self.mod = fitted_model
        self.transform = transform
        self.beta_hat = self.mod.params(transform=transform)
        self.param_names_ = self.mod.param_names(transform=transform)

        score_obs = self.mod.score_obs()  # eta parameterization
        cov_louis_eta = self.mod.cov_params(kind="louis", transform="eta")
        self._jac = self.mod._transform_jacobian(transform)
        self._score_obs_eta = score_obs
        self._score_obs_at_hat = score_obs
        self._hessian_inv_eta = cov_louis_eta
        self._hessian_left = self._jac @ self._hessian_inv_eta

        n_score_rows = score_obs.shape[0]
        if clusters is None:
            self.clusters = np.arange(n_score_rows)
        else:
            self.clusters = np.asarray(clusters)
            if len(self.clusters) != n_score_rows:
                raise ValueError("clusters must have one entry per score_obs row")

        self.cluster_ids, self.cluster_obs = np.unique(
            self.clusters, return_counts=True
        )
        self.num_clusters = len(self.cluster_ids)
        self._singleton_clusters = bool(np.all(self.cluster_obs == 1))

        _cluster_to_idx = {c: i for i, c in enumerate(self.cluster_ids)}
        self._obs_cluster_idx = np.array([_cluster_to_idx[c] for c in self.clusters])

        if not self._singleton_clusters:
            G = self.num_clusters
            N = len(self.clusters)
            self._L = np.zeros((N, G), dtype=float)
            self._L[np.arange(N), self._obs_cluster_idx] = 1.0
            _cs = self._L.sum(axis=0)
            self._L_scaled = self._L / (_cs - 1)

        if self._singleton_clusters:
            cluster_scores = self._score_obs_at_hat
        else:
            cluster_scores = self._L.T @ self._score_obs_at_hat
        G = self.num_clusters
        if G > 1:
            demeaned_cs = cluster_scores - cluster_scores.mean(axis=0)
            opg_cluster = demeaned_cs.T @ demeaned_cs * G / (G - 1)
        else:
            opg_cluster = cluster_scores.T @ cluster_scores
        V_cluster = self._hessian_left @ opg_cluster @ self._hessian_left.T
        self._bse_cluster = np.sqrt(np.abs(np.diag(V_cluster)))
        with np.errstate(invalid="ignore", divide="ignore"):
            self._wald_cluster = np.where(
                self._bse_cluster > 0,
                (self.beta_hat / self._bse_cluster) ** 2,
                0.0,
            )

    def get_analytical_wald(self):
        """Cluster-robust analytical Wald statistic (t²) for each parameter."""
        return self._wald_cluster

    def wald_test(self, W, R, r=None):
        """Wald statistic for one bootstrap draw."""
        W_flat = np.asarray(W).flatten()
        W_obs = W_flat[self._obs_cluster_idx]

        if self._singleton_clusters:
            perturbed_score_obs = self._score_obs_at_hat * W_obs[:, np.newaxis]
            perturbed_score = perturbed_score_obs.sum(axis=0)
            pmean = perturbed_score_obs.mean(axis=0)
            demeaned = perturbed_score_obs - pmean
            opg_centered = demeaned.T @ demeaned
        else:
            W_Jn = W_obs[:, np.newaxis]
            perturbed_score_obs = self._score_obs_at_hat * W_Jn
            pmean = (self._L_scaled.T @ perturbed_score_obs).mean(axis=0)
            demeaned = perturbed_score_obs - pmean
            demeaned_L = self._L.T @ demeaned
            perturbed_score = perturbed_score_obs.sum(axis=0)
            opg_centered = demeaned_L.T @ demeaned_L

        R = np.asarray(R, dtype=float)
        bread = R @ self._hessian_left @ perturbed_score
        meat = R @ self._hessian_left @ opg_centered @ self._hessian_left.T @ R.T

        if isinstance(bread, np.ndarray) and bread.ndim > 0:
            return float(bread.T @ np.linalg.inv(meat) @ bread)
        return float(bread) ** 2 / float(meat)

    def bootstrap(self, R, W=None, n_jobs=-1, seed=None, bootstrap_num=100):
        """Draw bootstrapped Wald statistics for a restriction."""

        def _bootstrapper(b):
            _rng = np.random.default_rng(None if seed is None else int(seed) + b)
            _W = W
            if _W is None:
                _W = _rng.choice([-1, 1], size=self.num_clusters)
            return self.wald_test(W=_W, R=R)

        return np.array(
            Parallel(n_jobs=n_jobs, backend="loky")(
                delayed(_bootstrapper)(b) for b in range(bootstrap_num)
            )
        )

    def get_wald_boot(self, n_jobs=-1, bootstrap_num=100, seed=None, W=None):
        """Bootstrapped Wald statistics for every parameter separately."""
        K = len(self.beta_hat)
        R_eye = np.identity(K)
        wald_boot = np.zeros((bootstrap_num, K))
        for i, R_vec in enumerate(R_eye):
            wald_boot[:, i] = self.bootstrap(
                R=R_vec,
                n_jobs=n_jobs,
                seed=seed,
                bootstrap_num=bootstrap_num,
                W=W,
            )
        return wald_boot

    def get_pvalue(self, pval_type="two-tailed", alpha=0.05, **kwargs):
        """Run bootstrap and compute p-values plus percentile-t intervals."""
        wald_boot = self.get_wald_boot(**kwargs)
        analytical_wald = np.asarray(self.get_analytical_wald())

        if pval_type == "two-tailed":
            pvalue = (wald_boot > analytical_wald).mean(axis=0)
        elif pval_type == "equal-tailed":
            pl = (wald_boot > analytical_wald).mean(axis=0)
            ph = (wald_boot < analytical_wald).mean(axis=0)
            pvalue = 2 * np.minimum(pl, ph)
        elif pval_type == ">":
            pvalue = (wald_boot > analytical_wald).mean(axis=0)
        else:
            pvalue = (wald_boot < analytical_wald).mean(axis=0)

        z_crit = float(ndtri(1.0 - alpha / 2))
        c_boot = np.percentile(
            np.sqrt(np.abs(wald_boot)), 100.0 * (1.0 - alpha / 2), axis=0
        )

        self.wald_boot_ = wald_boot
        self.pvalues_ = pvalue
        self.bse_boot_ = self._bse_cluster * c_boot / z_crit
        self.conf_int_boot_ = np.column_stack(
            [
                self.beta_hat - c_boot * self._bse_cluster,
                self.beta_hat + c_boot * self._bse_cluster,
            ]
        )
        return pvalue


class MLSwitchingRegIRLS:
    """
    EM/IRLS estimator for the switching regression with soft ML misclassification.

    Parameters
    ----------
    y : (N,) or (N, 1)
        Outcome variable.
    X_list : list of R arrays each (N, p)
        Regime-specific design matrices. Each array covers ALL N observations.
    classifier_pred : (N, R)
        Soft ML predictions: classifier_pred[n, j] = P(r̃=j | obs n).
    cm : (R, R)
        Column-normalized confusion matrix: cm[k, j] = P(true=k | predicted=j).
        Compute as  mw / mw.sum(axis=0)  from the row-stochastic mw.
    """

    def __init__(
        self, y, X_list, classifier_pred, cm, driver_ids=None, shared_beta=False
    ):
        self.y = np.asarray(y).flatten()  # (N,)
        self.X_list = [np.asarray(x) for x in X_list]
        self.n_regimes = len(X_list)
        self.num_params = X_list[0].shape[1]
        self.shared_beta = bool(shared_beta)
        # weighted_cm[n, k] = Σ_j P(r̃=j) · P(true=k | pred=j)
        self.weighted_cm = np.asarray(classifier_pred) @ np.asarray(cm).T  # (N, R)
        self.driver_ids = driver_ids  # (N,) or None
        if driver_ids is not None:
            _ids = np.asarray(driver_ids)
            self._unique_drivers = np.unique(_ids)
            self._n_drivers = len(self._unique_drivers)
            _map = {d: idx for idx, d in enumerate(self._unique_drivers)}
            self._obs_to_driver = np.array([_map[d] for d in _ids])
            self._driver_indices = {
                d: np.where(_ids == d)[0] for d in self._unique_drivers
            }
            # Runtime assertion: weighted_cm must be constant within driver
            for _d in self._unique_drivers:
                _idx = self._driver_indices[_d]
                assert np.allclose(self.weighted_cm[_idx[0]], self.weighted_cm[_idx]), (
                    f"weighted_cm not constant within driver {_d}"
                )

    # ------------------------------------------------------------------
    # E-step
    # ------------------------------------------------------------------

    def _coerce_beta(self, beta):
        beta = np.asarray(beta, dtype=float)
        if not self.shared_beta:
            return beta.reshape(self.n_regimes, self.num_params)
        if beta.size == self.num_params:
            return beta.reshape(self.num_params)
        if beta.size == self.n_regimes * self.num_params:
            return beta.reshape(self.n_regimes, self.num_params).mean(axis=0)
        raise ValueError("shared_beta=True expects beta_0 with length p or R*p")

    def _linear_predictor(self, beta):
        if self.shared_beta:
            return np.array([self.X_list[r] @ beta for r in range(self.n_regimes)])
        return np.array([self.X_list[r] @ beta[r] for r in range(self.n_regimes)])

    def _estep(self, beta, sigma2):
        """
        Soft posterior P(true=r | y_n, classifier output).

        Returns rrh (R, N): rrh[r, n] = P(true=r | y_n, r̃_n).
        """
        sigma2 = max(float(sigma2), 1e-8)
        xb = self._linear_predictor(beta)

        if self.driver_ids is None:
            # Observation-level (original behavior, unchanged)
            regimes = np.exp(-((self.y[None, :] - xb) ** 2) / (2 * sigma2))
            unnorm = regimes * self.weighted_cm.T  # (R, N)
            return unnorm / (unnorm.sum(axis=0) + 1e-300)  # (R, N)

        # --- Driver-level E-step ---
        R = self.n_regimes
        D = self._n_drivers

        # Step 1: Per-observation log-densities (R, N)
        # Omit -0.5*log(2*pi*sigma2) since it cancels in the ratio
        log_f = -((self.y[None, :] - xb) ** 2) / (2 * sigma2)  # (R, N)

        # Step 2: Sum log-densities within each driver → (R, D)
        log_prod = np.zeros((R, D))
        np.add.at(log_prod.T, self._obs_to_driver, log_f.T)

        # Step 3: Add log-weights → (R, D)
        # weighted_cm is (N, R); constant within driver, take first obs
        first_obs = np.array([self._driver_indices[d][0] for d in self._unique_drivers])
        log_w = np.log(self.weighted_cm[first_obs, :].T + 1e-300)  # (R, D)

        unnorm_log = log_w + log_prod  # (R, D)

        # Step 4: Log-sum-exp normalization
        log_denom = logsumexp(unnorm_log, axis=0)  # (D,)
        tau_driver = np.exp(unnorm_log - log_denom[np.newaxis, :])  # (R, D)

        # Step 5: Broadcast back to (R, N)
        tau_obs = tau_driver[:, self._obs_to_driver]  # (R, N)

        return tau_obs

    # ------------------------------------------------------------------
    # M-step helpers
    # ------------------------------------------------------------------

    def _beta_h(self, r, rrh, l2_lambda):
        """WLS estimate for regime r given posterior weights rrh (R, N)."""
        Wr = self.X_list[r]  # (N, p)
        wt = rrh[r]  # (N,)
        A = (Wr * wt[:, None]).T @ Wr + l2_lambda * np.eye(self.num_params)
        b = (Wr * wt[:, None]).T @ self.y
        return np.linalg.solve(A, b)

    def _beta_shared_h(self, rrh, l2_lambda):
        """Pooled WLS estimate for one coefficient vector shared across regimes."""
        A = l2_lambda * np.eye(self.num_params)
        b = np.zeros(self.num_params)
        for r in range(self.n_regimes):
            Wr = self.X_list[r]
            wt = rrh[r]
            A += (Wr * wt[:, None]).T @ Wr
            b += (Wr * wt[:, None]).T @ self.y
        return np.linalg.solve(A, b)

    def _sigma2_h(self, rrh, beta, l2_lambda):
        """Pooled sigma² update.

        The denominator uses ``(rrh.sum() + 2 * l2_lambda)`` rather than
        ``rrh.sum()`` (= N when l2_lambda=0) because the ridge penalty
        ``l2_lambda * ||β||²`` in the M-step objective contributes an extra
        ``2 * l2_lambda`` to the effective degrees of freedom, analogous to
        the standard OLS ridge-regression variance adjustment.
        """
        if self.shared_beta:
            resid2 = sum(
                rrh[r] * (self.y - self.X_list[r] @ beta) ** 2
                for r in range(self.n_regimes)
            )
        else:
            resid2 = sum(
                rrh[r] * (self.y - self.X_list[r] @ beta[r]) ** 2
                for r in range(self.n_regimes)
            )
        return float(resid2.sum() / (rrh.sum() + 2 * l2_lambda))

    # ------------------------------------------------------------------
    # EM iteration
    # ------------------------------------------------------------------

    def _step(self, beta, sigma2, l2_lambda):
        """One EM step. Returns (new_beta (R, p), new_sigma2)."""
        rrh = self._estep(beta, sigma2)
        if self.shared_beta:
            new_beta = self._beta_shared_h(rrh, l2_lambda)
        else:
            new_beta = np.array(
                [self._beta_h(r, rrh, l2_lambda) for r in range(self.n_regimes)]
            )
        new_sigma2 = self._sigma2_h(rrh, new_beta, l2_lambda)
        return new_beta, new_sigma2

    def _irls(self, beta_0, sigma2_0, l2_lambda, max_iter, tol, verbose):
        beta = self._coerce_beta(beta_0)
        sigma2 = float(sigma2_0)

        history = []
        for i in range(max_iter):
            new_beta, new_sigma2 = self._step(beta, sigma2, l2_lambda)
            delta = float(np.linalg.norm(new_beta - beta)) + abs(new_sigma2 - sigma2)
            history.append(delta)
            if verbose:
                print(f"Iter {i:4d}  |Δθ| = {delta:.3e}")
            beta, sigma2 = new_beta, new_sigma2
            if delta < tol:
                if verbose:
                    print(f"IRLS converged in {i + 1} iterations (|Δθ|={delta:.2e})")
                break
        else:
            if verbose:
                print(
                    f"IRLS did not converge after {max_iter} iterations (|Δθ|={delta:.2e})"
                )

        self.beta_ = beta  # (R, p)
        self.sigma2_ = sigma2
        self.history = history
        return beta, sigma2

    def fit(
        self, beta_0, sigma2_0, max_iter=1000, tol=1e-6, l2_lambda=0, verbose=False
    ):
        """
        Fit the model.

        Parameters
        ----------
        beta_0 : (R, p) or (R*p,)
            Initial beta values. When ``shared_beta=True``, `(p,)` is also
            accepted, and `(R, p)` or `(R*p,)` inputs are averaged across
            regimes to produce one pooled starting vector.
        sigma2_0 : float
            Initial sigma².
        max_iter, tol, l2_lambda, verbose : convergence / regularisation controls.

        Returns
        -------
        beta : (R, p) when ``shared_beta=False`` and `(p,)` when
            ``shared_beta=True``
        sigma2 : float
        """
        return self._irls(beta_0, sigma2_0, l2_lambda, max_iter, tol, verbose)

    # ------------------------------------------------------------------
    # Inference helpers
    # ------------------------------------------------------------------

    def _require_fitted(self):
        if not hasattr(self, "beta_") or not hasattr(self, "sigma2_"):
            raise RuntimeError("Fit MLSwitchingRegIRLS before requesting inference")

    @staticmethod
    def _safe_inv(mat):
        try:
            return np.linalg.inv(mat)
        except np.linalg.LinAlgError:
            return np.linalg.pinv(mat)

    @property
    def _theta_dim(self):
        return (self.num_params + 1) if self.shared_beta else (
            self.n_regimes * self.num_params + 1
        )

    def _beta_slice(self, r):
        if self.shared_beta:
            return slice(0, self.num_params)
        start = r * self.num_params
        return slice(start, start + self.num_params)

    def _coerce_inference_params(self, params=None):
        self._require_fitted()
        if params is None:
            return self._coerce_beta(self.beta_), float(self.sigma2_)
        params = np.asarray(params, dtype=float).flatten()
        expected = self._theta_dim
        if len(params) != expected:
            raise ValueError(f"Expected params with length {expected}, got {len(params)}")
        beta = self._coerce_beta(params[:-1])
        sigma2 = float(np.exp(params[-1]))
        return beta, sigma2

    def _transform_jacobian(self, transform="eta"):
        self._require_fitted()
        K = self._theta_dim
        jac = np.eye(K)
        transform = transform.lower()
        if transform == "eta":
            jac[-1, -1] = 1.0
        elif transform == "sigma2":
            jac[-1, -1] = float(self.sigma2_)
        elif transform == "sigma":
            jac[-1, -1] = float(np.sqrt(max(self.sigma2_, 0.0))) / 2.0
        else:
            raise ValueError("transform must be one of 'eta', 'sigma2', or 'sigma'")
        return jac

    def param_names(self, transform="eta"):
        """Return parameter names matching :meth:`params` and :meth:`bse`."""
        if self.shared_beta:
            names = [f"beta_shared_{i}" for i in range(self.num_params)]
        else:
            names = [
                f"beta_{r}_{i}"
                for r in range(self.n_regimes)
                for i in range(self.num_params)
            ]
        transform = transform.lower()
        if transform not in {"eta", "sigma2", "sigma"}:
            raise ValueError("transform must be one of 'eta', 'sigma2', or 'sigma'")
        return names + [transform]

    def params(self, transform="eta"):
        """Return fitted parameters under the requested variance parameterization."""
        self._require_fitted()
        beta_flat = np.asarray(self.beta_, dtype=float).flatten()
        transform = transform.lower()
        if transform == "eta":
            last = np.log(float(self.sigma2_))
        elif transform == "sigma2":
            last = float(self.sigma2_)
        elif transform == "sigma":
            last = float(np.sqrt(max(self.sigma2_, 0.0)))
        else:
            raise ValueError("transform must be one of 'eta', 'sigma2', or 'sigma'")
        return np.append(beta_flat, last)

    def _unit_indices(self):
        if self.driver_ids is None:
            return [np.array([i]) for i in range(len(self.y))]
        return [self._driver_indices[d] for d in self._unique_drivers]

    def _score_information_components(self, params=None):
        """Return scores and Louis information pieces in eta parameterization."""
        beta, sigma2 = self._coerce_inference_params(params)
        sigma2 = max(float(sigma2), 1e-12)
        rrh = self._estep(beta, sigma2)  # (R, N), driver posteriors broadcast if needed
        K = self._theta_dim
        R = self.n_regimes

        scores = []
        observed_info = np.zeros((K, K))
        complete_info = np.zeros((K, K))
        missing_info = np.zeros((K, K))

        for idx in self._unit_indices():
            a = np.zeros((R, K))
            C = np.zeros((R, K, K))
            for r in range(R):
                Xr = self.X_list[r][idx]
                beta_r = beta if self.shared_beta else beta[r]
                resid = self.y[idx] - Xr @ beta_r
                beta_score = Xr.T @ resid / sigma2
                eta_score = (float(resid @ resid) - len(idx) * sigma2) / (2 * sigma2)

                sl = self._beta_slice(r)
                a[r, sl] += beta_score
                a[r, -1] = eta_score

                C[r, sl, sl] += Xr.T @ Xr / sigma2
                C[r, sl, -1] += beta_score
                C[r, -1, sl] += beta_score
                C[r, -1, -1] += float(resid @ resid) / (2 * sigma2)

            tau = rrh[:, idx[0]]
            score_i = tau @ a
            complete_i = np.tensordot(tau, C, axes=(0, 0))
            weighted_outer = sum(tau[r] * np.outer(a[r], a[r]) for r in range(R))
            missing_i = weighted_outer - np.outer(score_i, score_i)
            observed_i = complete_i - missing_i

            scores.append(score_i)
            complete_info += complete_i
            missing_info += missing_i
            observed_info += observed_i

        return {
            "scores": np.asarray(scores),
            "observed": observed_info,
            "complete": complete_info,
            "missing": missing_info,
        }

    def score_obs(self, params=None):
        """Observed score contributions, one row per independent likelihood unit.

        Returns driver-level rows when ``driver_ids`` were supplied and observation
        rows otherwise. Scores are in the internal ``eta=log(sigma2)``
        parameterization.
        """
        return self._score_information_components(params)["scores"]

    def information(self, params=None, kind="louis"):
        """Return an information matrix in the internal eta parameterization.

        Parameters
        ----------
        kind : {'louis', 'observed', 'corrected', 'uncorrected', 'complete', 'missing'}
            ``'louis'``/``'observed'`` returns the observed information
            ``complete - missing``. ``'uncorrected'``/``'complete'`` returns the
            final fixed-weight M-step information.
        """
        comps = self._score_information_components(params)
        kind = kind.lower()
        if kind in {"louis", "observed", "corrected"}:
            return comps["observed"]
        if kind in {"uncorrected", "complete", "wls"}:
            return comps["complete"]
        if kind == "missing":
            return comps["missing"]
        raise ValueError(
            "kind must be 'louis', 'observed', 'corrected', 'uncorrected', "
            "'complete', 'wls', or 'missing'"
        )

    def cov_params(self, kind="louis", transform="eta", small_sample=False):
        """Return covariance matrix for fitted IRLS parameters.

        ``kind='uncorrected'`` uses the final fixed-weight M-step Hessian.
        ``kind='louis'`` uses the Louis-corrected observed information.
        ``kind='sandwich'`` uses the Louis bread and OPG meat from independent
        likelihood-unit scores.
        """
        comps = self._score_information_components()
        kind = kind.lower()
        if kind in {"uncorrected", "complete", "wls"}:
            cov_eta = self._safe_inv(comps["complete"])
        elif kind in {"louis", "observed", "corrected"}:
            cov_eta = self._safe_inv(comps["observed"])
        elif kind in {"sandwich", "robust"}:
            bread_inv = self._safe_inv(comps["observed"])
            scores = comps["scores"]
            meat = scores.T @ scores
            if small_sample and len(scores) > 1:
                meat *= len(scores) / (len(scores) - 1)
            cov_eta = bread_inv @ meat @ bread_inv
        else:
            raise ValueError(
                "kind must be 'louis', 'observed', 'corrected', 'uncorrected', "
                "'complete', 'wls', 'sandwich', or 'robust'"
            )

        jac = self._transform_jacobian(transform)
        return jac @ cov_eta @ jac.T

    def bse(self, kind="louis", transform="sigma"):
        """Return standard errors for fitted IRLS parameters."""
        return np.sqrt(np.abs(np.diag(self.cov_params(kind=kind, transform=transform))))

    def score_bootstrap(self, clusters=None, transform="sigma", **kwargs):
        """Run score wild bootstrap for a fitted IRLS model.

        Parameters are passed to :meth:`IRLSScoreWildBootstrap.get_pvalue`, for
        example ``bootstrap_num``, ``seed``, ``n_jobs``, and ``alpha``.
        """
        swb = IRLSScoreWildBootstrap(self, clusters=clusters, transform=transform)
        swb.get_pvalue(**kwargs)
        return swb

    @classmethod
    def from_formula(
        cls,
        formula,
        data,
        classifier_pred,
        cm,
        entity_effects=False,
        time_effects=False,
        panel_likelihood=True,
        shared_beta=False,
        regime_labels=None,
        **kwargs,
    ):
        """
        Construct from a formula string and a DataFrame.

        The same design matrix is shared across all regimes.

        Parameters
        ----------
        formula : str
            Formulaic formula, e.g. ``"y ~ drought_0 + drought_1"``.
        data : DataFrame with (driver, time) MultiIndex
        classifier_pred : (N, R) array or DataFrame of soft ML predictions
        cm : (R, R) column-normalised confusion matrix
        entity_effects : bool
            If True, within-demean y and X by entity (driver) before fitting.
            The intercept is dropped when demeaning is applied.
        time_effects : bool
            If True, within-demean y and X by time period before fitting.
        panel_likelihood : bool, default True
            If True, use driver-level likelihood (marginalize over regimes at
            the driver level).  Passes driver_ids to the constructor.
        shared_beta : bool, default False
            If True, estimate one coefficient vector shared across all regimes.
            Provide a templated formula like ``"y ~ drought_{r} + drought_lag_{r}"``
            so that each regime receives its own design matrix.
        regime_labels : sequence, optional
            Labels used to expand the formula template. Defaults to ``range(R)``.
        **kwargs
            Passed through to ``__init__`` (e.g. no extra args currently).
        """
        from formulaic import Formula
        import pandas as pd

        flat = data.reset_index()
        R = np.asarray(cm).shape[0]
        cp = np.asarray(classifier_pred, dtype=float)
        labels = list(range(R)) if regime_labels is None else list(regime_labels)
        if len(labels) != R:
            raise ValueError("regime_labels must have length equal to the number of regimes")

        def _expand_formula(label, index):
            return formula.format(r=index, regime=index, label=label, region=label)

        if shared_beta:
            expanded_formulas = [_expand_formula(label, idx) for idx, label in enumerate(labels)]
            if len(set(expanded_formulas)) == 1:
                raise ValueError(
                    "shared_beta=True requires a templated formula that varies across regimes"
                )
            parsed_list = [Formula(f).get_model_matrix(flat) for f in expanded_formulas]
            y = np.asarray(parsed_list[0].lhs).flatten()
            X_list = [np.asarray(parsed.rhs) for parsed in parsed_list]
        else:
            parsed = Formula(formula).get_model_matrix(flat)
            y = np.asarray(parsed.lhs).flatten()
            X = np.asarray(parsed.rhs)  # (N, p) including intercept

        if entity_effects or time_effects:
            y_s = pd.Series(y)
            if entity_effects:
                g = pd.Series(data.index.get_level_values(0).values)
                y_s = y_s - y_s.groupby(g).transform("mean")
            if time_effects:
                g = pd.Series(data.index.get_level_values(1).values)
                y_s = y_s - y_s.groupby(g).transform("mean")
            y = y_s.values
            if shared_beta:
                X_list = [pd.DataFrame(X_r[:, 1:]) for X_r in X_list]
                if entity_effects:
                    g = pd.Series(data.index.get_level_values(0).values)
                    X_list = [X_r.subtract(X_r.groupby(g).transform("mean")) for X_r in X_list]
                if time_effects:
                    g = pd.Series(data.index.get_level_values(1).values)
                    X_list = [X_r.subtract(X_r.groupby(g).transform("mean")) for X_r in X_list]
                X_list = [X_r.values for X_r in X_list]
            else:
                X_no_int = pd.DataFrame(X[:, 1:])  # drop intercept — absorbed by FE
                if entity_effects:
                    g = pd.Series(data.index.get_level_values(0).values)
                    X_no_int = X_no_int.subtract(X_no_int.groupby(g).transform("mean"))
                if time_effects:
                    g = pd.Series(data.index.get_level_values(1).values)
                    X_no_int = X_no_int.subtract(X_no_int.groupby(g).transform("mean"))
                X_list = [X_no_int.values] * R
        elif not shared_beta:
            X_list = [X] * R

        driver_ids = data.index.get_level_values(0).values if panel_likelihood else None
        return cls(
            y,
            X_list,
            cp,
            np.asarray(cm, dtype=float),
            driver_ids=driver_ids,
            shared_beta=shared_beta,
            **kwargs,
        )
