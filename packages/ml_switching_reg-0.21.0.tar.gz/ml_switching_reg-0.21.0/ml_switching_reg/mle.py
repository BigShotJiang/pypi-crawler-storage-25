# %%
import os

os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
from joblib import delayed, Parallel

import numpy as np
import pandas as pd
from scipy.special import logsumexp

# from scipy.stats import norm as norm_scipy
from numba_stats import norm
from statsmodels.base.model import GenericLikelihoodModel
import warnings

np.errstate(all="raise")
import functools
import re
from formulaic import Formula, ModelMatrix

from linearmodels.panel.data import PanelData
from linearmodels import PanelOLS
from linearmodels.panel.model import PanelFormulaParser
from linearmodels.panel.utility import (
    check_absorbed,
    not_absorbed,
    AbsorbingEffectError,
)
from .cm import cm_4, cm_10

from functools import reduce
import pyhdfe


class UnequalRowException(Exception):
    pass


def get_mle_betas(res, regimes=None):

    params = res.params.drop("sigma", errors="ignore")

    if params.index.str.contains("misclass_regime_").any():
        beta0_mle = params.loc[lambda s: ~s.index.str.contains("drought_")].values
        beta1_mle = params.loc[
            lambda s: s.index.str.contains("misclass_regime_[0-9]:drought_")
        ].values
    else:
        R = regimes
        p = len(params) // R
        beta0_mle = np.array([params.iloc[r * p] for r in range(R)])
        beta1_mle = np.array([params.iloc[r * p + 1] for r in range(R)])

    return beta0_mle, beta1_mle, np.append(beta0_mle, beta1_mle)


def get_mle_sigmas(res, regimes=None):
    """
    Get sigmas from MLE estimation, then transform back (take absolute value)
    """

    sigma = np.abs(res.params.loc["sigma"])
    if regimes is not None:
        return np.full(regimes, sigma)
    return sigma


def _reorganize_gaul_ind(ind):
    ind[5], ind[6] = ind[6], ind[5]
    ind[8], ind[9] = ind[9], ind[8]
    return ind


class ScoreWildBootstrap:
    """Score wild bootstrap for MLE models (Kline & Santos 2012).

    Accepts an already-fitted statsmodels result object.  When the underlying
    model is a ``DriverSpecificProbUberMLE`` with driver-level likelihood,
    cluster membership is detected automatically (one cluster per driver).

    Parameters
    ----------
    fitted_result : statsmodels GenericLikelihoodModelResults
        The fitted result from ``DriverSpecificProbUberMLE.fit()[0]``.
    clusters : array-like of shape (N,), optional
        Cluster membership for each *row* returned by ``score_obs``.
        If None and the model has ``_driver_ids``, each driver becomes its
        own singleton cluster (score_obs already returns per-driver rows).
        If None and no driver IDs, each observation is its own cluster
        (heteroskedasticity-robust).
    """

    def __init__(self, fitted_result, clusters=None):
        self.fitted_mod = fitted_result
        self.mod = fitted_result.model
        self.beta_hat = np.asarray(fitted_result.params)

        if clusters is None and getattr(self.mod, "_driver_ids", None) is not None:
            self.clusters = np.arange(self.mod._n_drivers)
        elif clusters is not None:
            self.clusters = np.asarray(clusters)
        else:
            self.clusters = np.arange(int(self.mod.nobs))

        self.cluster_ids, self.cluster_obs = np.unique(
            self.clusters, return_counts=True
        )
        self.num_clusters = len(self.cluster_ids)
        self._singleton_clusters = bool(np.all(self.cluster_obs == 1))

        if hasattr(self.mod, "_param_order"):
            self.param_names_ = list(self.mod._param_order)
        elif hasattr(fitted_result.params, "index"):
            self.param_names_ = list(fitted_result.params.index)
        else:
            self.param_names_ = [f"param_{i}" for i in range(len(self.beta_hat))]

        # obs → cluster index mapping (used to broadcast W to observations)
        _cluster_to_idx = {c: i for i, c in enumerate(self.cluster_ids)}
        self._obs_cluster_idx = np.array(
            [_cluster_to_idx[c] for c in self.clusters]
        )  # (G,) singleton | (N,) multi-obs

        # For multi-obs clusters: precompute membership and HC scaling matrices
        if not self._singleton_clusters:
            G = self.num_clusters
            N = len(self.clusters)
            self._L = np.zeros((N, G), dtype=float)
            self._L[np.arange(N), self._obs_cluster_idx] = 1.0
            _cs = self._L.sum(axis=0)  # (G,) cluster sizes
            self._L_scaled = self._L / (_cs - 1)  # (N, G) HC recentering weights

        # Precompute expensive quantities — computed ONCE, reused every draw
        self._hessian_inv = -np.linalg.inv(self.mod.hessian(self.beta_hat))
        self._score_obs_at_hat = self.mod.score_obs(self.beta_hat)  # (G or N, K)

        # Cluster-robust OPG and SEs (must match scale of bootstrap Wald stats)
        G = self.num_clusters
        if self._singleton_clusters:
            cluster_scores = self._score_obs_at_hat  # (G, K) already per-cluster
        else:
            cluster_scores = self._L.T @ self._score_obs_at_hat  # (G, K)
        if G > 1:
            demeaned_cs = cluster_scores - cluster_scores.mean(axis=0)
            opg_cluster = demeaned_cs.T @ demeaned_cs * G / (G - 1)
        else:
            opg_cluster = cluster_scores.T @ cluster_scores
        V_cluster = self._hessian_inv @ opg_cluster @ self._hessian_inv
        self._bse_cluster = np.sqrt(np.abs(np.diag(V_cluster)))
        with np.errstate(invalid="ignore", divide="ignore"):
            self._wald_cluster = np.where(
                self._bse_cluster > 0,
                (self.beta_hat / self._bse_cluster) ** 2,
                0.0,
            )

    # ------------------------------------------------------------------
    def get_analytical_wald(self):
        """Cluster-robust analytical Wald statistic (t²) for each parameter."""
        return self._wald_cluster

    # ------------------------------------------------------------------
    def wald_test(self, W, restricted_residuals=False, R=None, r=None):
        """Wald statistic for one bootstrap draw.

        Parameters
        ----------
        W : array-like of shape (num_clusters,)
            Rademacher weights, one per cluster.
        R : array-like
            Restriction vector/matrix (shape (K,) for a single test).
        r : scalar, optional
            Restriction value (only needed for ``restricted_residuals=True``).
        """
        hessian_inv = self._hessian_inv  # precomputed in __init__

        if restricted_residuals:
            if r is None:
                raise ValueError(
                    "Must specify coefficient constraint r for restricted_residuals=True"
                )
            score_beta = self.beta_hat.copy()
            score_beta[np.where(R == 1)[0]] = 1
            score_obs_bread = self.mod.score_obs(score_beta)
        else:
            score_obs_bread = self._score_obs_at_hat  # cache hit

        # Broadcast cluster weights to observations: W_obs[i] = W[cluster(i)]
        W_flat = np.asarray(W).flatten()  # (G,)
        W_obs = W_flat[self._obs_cluster_idx]  # (G,) singleton | (N,) multi-obs

        if self._singleton_clusters:
            # score_obs returns (G, K) — one row per independent unit
            perturbed_score_obs = (
                self._score_obs_at_hat * W_obs[:, np.newaxis]
            )  # (G, K)
            perturbed_score = (
                score_obs_bread * W_obs[:, np.newaxis]
            ).sum(axis=0)  # (K,)
            pmean = perturbed_score_obs.mean(axis=0)
            demeaned = perturbed_score_obs - pmean  # (G, K)
            opg_centered = demeaned.T @ demeaned  # (K, K)
        else:
            # Multi-obs clusters — Kline-Santos HC recentering (precomputed L)
            W_Jn = W_obs[:, np.newaxis]  # (N, 1)
            perturbed_score_obs = (
                self._score_obs_at_hat * W_Jn
            )  # (N, K)
            pmean = (
                self._L_scaled.T @ perturbed_score_obs
            ).mean(axis=0)  # (K,)
            demeaned = perturbed_score_obs - pmean  # (N, K)
            demeaned_L = self._L.T @ demeaned  # (G, K)
            perturbed_score = (
                score_obs_bread * W_Jn
            ).sum(axis=0)  # (K,)
            opg_centered = demeaned_L.T @ demeaned_L  # (K, K)

        bread = R @ hessian_inv @ perturbed_score
        meat = R @ hessian_inv @ opg_centered @ hessian_inv @ R.T

        if isinstance(bread, np.ndarray) and bread.ndim > 0:
            return float(bread.T @ np.linalg.inv(meat) @ bread)
        else:
            return float(bread) ** 2 / float(meat)

    # ------------------------------------------------------------------
    def bootstrap(
        self,
        R,
        W=None,
        r=None,
        n_jobs=-1,
        rng=None,
        seed=None,
        bootstrap_num=100,
        restricted_residuals=False,
        full_enumeration=False,
    ):
        """Draw ``bootstrap_num`` bootstrapped Wald statistics.

        Parameters
        ----------
        R : array-like
            Restriction vector/matrix for the test.
        seed : int, optional
            If provided, draw b-th weight with seed ``seed + b`` for reproducibility.
        """

        def _bootstrapper(b):
            _rng = np.random.default_rng(
                None if seed is None else int(seed) + b
            )
            _W = W
            if _W is None:
                if full_enumeration:
                    from itertools import product as _product

                    all_ws = np.array(
                        list(_product([-1, 1], repeat=self.num_clusters))
                    )
                    _W = all_ws[b % len(all_ws)]
                else:
                    _W = _rng.choice([-1, 1], size=self.num_clusters)
            return self.wald_test(
                W=_W, restricted_residuals=restricted_residuals, R=R, r=r
            )

        walds = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(_bootstrapper)(b) for b in range(bootstrap_num)
        )
        return np.array(walds)

    # ------------------------------------------------------------------
    def get_wald_boot(
        self,
        n_jobs=-1,
        bootstrap_num=100,
        restricted_residuals=False,
        full_enumeration=False,
        rng=None,
        seed=None,
        W=None,
    ):
        """Bootstrapped Wald statistics for every parameter separately.

        Returns
        -------
        wald_boot : ndarray of shape (bootstrap_num, K)
        """
        K = len(self.beta_hat)
        R_eye = np.identity(K)
        wald_boot = np.zeros((bootstrap_num, K))
        for i, R_vec in enumerate(R_eye):
            wald_boot[:, i] = self.bootstrap(
                R=R_vec,
                r=0,
                n_jobs=n_jobs,
                rng=rng,
                seed=seed,
                bootstrap_num=bootstrap_num,
                restricted_residuals=restricted_residuals,
                full_enumeration=full_enumeration,
                W=W,
            )
        return wald_boot

    # ------------------------------------------------------------------
    def get_pvalue(self, pval_type="two-tailed", alpha=0.05, **kwargs):
        """Run bootstrap and compute p-values plus auxiliary inference objects.

        After this call the following attributes are set:

        ``wald_boot_``
            (B, K) array of bootstrapped Wald statistics.
        ``pvalues_``
            (K,) p-values.
        ``bse_boot_``
            (K,) implied bootstrapped SEs via the percentile-t formula.
        ``conf_int_boot_``
            (K, 2) percentile-t confidence intervals.

        Parameters
        ----------
        pval_type : {'two-tailed', 'equal-tailed', '>', '<'}
        alpha : float, default 0.05
            Significance level used for CI and implied SE.
        **kwargs
            Passed to ``get_wald_boot`` (e.g. ``bootstrap_num``, ``seed``).
        """
        from scipy.special import ndtri as _ndtri

        wald_boot = self.get_wald_boot(**kwargs)
        analytical_wald = np.asarray(self.get_analytical_wald())

        if pval_type == "two-tailed":
            pvalue = (wald_boot > analytical_wald).mean(axis=0)
        elif pval_type == "equal-tailed":
            pl = (wald_boot > analytical_wald).mean(axis=0)
            ph = (wald_boot < analytical_wald).mean(axis=0)
            pvalue = 2 * np.minimum(pl, ph)
        elif pval_type == ">":
            pvalue = (wald_boot > analytical_wald).mean(axis=0)
        else:
            pvalue = (wald_boot < analytical_wald).mean(axis=0)

        bse_cluster = self._bse_cluster  # cluster-robust SEs, consistent with bootstrap
        z_crit = float(_ndtri(1.0 - alpha / 2))  # 1.96 for alpha=0.05
        c_boot = np.percentile(
            np.sqrt(np.abs(wald_boot)), 100.0 * (1.0 - alpha / 2), axis=0
        )  # (K,)

        self.wald_boot_ = wald_boot
        self.pvalues_ = pvalue
        self.bse_boot_ = bse_cluster * c_boot / z_crit
        self.conf_int_boot_ = np.column_stack(
            [
                self.beta_hat - c_boot * bse_cluster,
                self.beta_hat + c_boot * bse_cluster,
            ]
        )

        return pvalue

    # ------------------------------------------------------------------
    def summary_table(self, alpha=0.05, title=None):
        """Print a Markdown results table and return the underlying DataFrame.

        Requires ``get_pvalue()`` to have been called first.

        Columns: param, coef, bse_ols, bse_boot, ci_low, ci_high, pvalue

        Returns
        -------
        pd.DataFrame
        """
        if not hasattr(self, "pvalues_"):
            raise RuntimeError("Call get_pvalue() before summary_table().")

        title = title or "Score Wild Bootstrap Results"

        try:
            llf = float(self.fitted_mod.llf)
            aic = float(self.fitted_mod.aic)
            bic = float(self.fitted_mod.bic)
        except Exception:
            llf = aic = bic = float("nan")

        n_clusters = self.num_clusters
        n_obs = getattr(self.mod, "_n_obs_total", int(self.mod.nobs))

        bse_ols = np.asarray(self.fitted_mod.bse)

        df = pd.DataFrame(
            {
                "param": self.param_names_,
                "coef": self.beta_hat,
                "bse_ols": bse_ols,
                "bse_boot": self.bse_boot_,
                "ci_low": self.conf_int_boot_[:, 0],
                "ci_high": self.conf_int_boot_[:, 1],
                "pvalue": self.pvalues_,
            }
        )

        gof_line = (
            f"Log-Likelihood: {llf:.3f}  |  AIC: {aic:.3f}  |  BIC: {bic:.3f}  |  "
            f"N obs: {n_obs}  |  N clusters: {n_clusters}"
        )

        try:
            md_table = df.to_markdown(index=False, floatfmt=".4f")
        except ImportError:
            header = "| " + " | ".join(df.columns) + " |"
            sep = "|" + "|".join(["---"] * len(df.columns)) + "|"
            rows = [
                "| "
                + " | ".join(
                    f"{v:.4f}" if isinstance(v, float) else str(v)
                    for v in row
                )
                + " |"
                for row in df.itertuples(index=False)
            ]
            md_table = "\n".join([header, sep] + rows)

        print(f"## {title}")
        print(gof_line)
        print()
        print(md_table)

        return df


class DriverSpecificProbUberMLE(GenericLikelihoodModel):
    """An Uber MLE with two things different:
    - Gets rid of lambda as parameters
    - Uses driver-specific probabilities in likelihood
    - Uses bounding and constrained optimization for probabilities

    Uses full probabilities in classifier cols, not categoricals

    Can be constructed via the standard __init__ (requires panel DataFrames)
    or via the classmethod `from_arrays` which accepts raw numpy arrays directly.
    """

    @classmethod
    def from_arrays(
        cls,
        y,
        X_list,
        classifier_pred,
        cm,
        start_params=None,
        soft=True,
        hdfe=True,
        fast_xb=False,
        entity_effects=False,
        time_effects=False,
        other_effects=None,
        weights=None,
        drop_absorbed=False,
        check_rank=True,
        singletons=True,
        check_absorbed=True,
        driver_ids=None,
        shared_beta=False,
        **kwargs,
    ):
        """
        Construct from numpy arrays, bypassing all DataFrame/MultiIndex/PanelOLS machinery.

        Parameters
        ----------
        y : (N,)
            Outcome variable.
        X_list : list of R arrays each (N, p)
            Regime-specific design matrices. Each array covers ALL N observations.
        classifier_pred : (N, R)
            Soft ML predictions: classifier_pred[n, j] = P(r̃=j | obs n).
        cm : (R, R)
            Column-normalized confusion matrix: cm[k, j] = P(true=k | predicted=j).
        start_params : array of shape (R*p + 1,), optional
            Starting values [beta_0_0, ..., beta_{R-1}_{p-1}, sigma].
            If None, initialise with OLS per predicted-regime group.
            When ``shared_beta=True``, the preferred shape is `(p + 1,)`. A
            regime-specific vector of shape `(R*p + 1,)` is also accepted and
            collapsed to one pooled coefficient vector by averaging across regimes.
        soft : bool, default True
            If True, use the full soft classifier probabilities when computing the
            weighted confusion matrix (p @ cm.T).  If False, collapse to a hard
            argmax assignment before weighting (replicates the pre-soft behaviour).
        hdfe, fast_xb, entity_effects, time_effects, other_effects, weights,
        drop_absorbed, check_rank, singletons, check_absorbed :
            Same as __init__; stored on the object for completeness.  Most are only
            meaningful when the DataFrame/__init__ path is used.
        """
        obj = cls.__new__(cls)

        R = len(X_list)
        N, p = X_list[0].shape

        obj._arrays_mode = True
        obj._soft = soft
        obj.shared_beta = bool(shared_beta)
        obj._y_arr = np.asarray(y, dtype=float).flatten()  # (N,)
        obj._X_arr = np.stack([np.asarray(x, dtype=float) for x in X_list])  # (R, N, p)
        obj._classifier_pred_arr = np.asarray(classifier_pred, dtype=float)  # (N, R)
        obj._cm_arr = np.asarray(cm, dtype=float)  # (R, R)

        _p = obj._classifier_pred_arr
        if soft:
            obj._weighted_cm_arr = _p @ obj._cm_arr.T  # (N, R) soft
        else:
            _row_maxes = _p.max(axis=1, keepdims=True)
            _class_ind = np.where(_p == _row_maxes, _p, 0)  # hard argmax mask
            obj._weighted_cm_arr = _class_ind @ obj._cm_arr.T  # (N, R) hard

        obj.n_regimes = R
        obj._n_obs = N
        obj._n_params_per_regime = p

        # auto-generated parameter names: beta_{regime}_{covariate_idx}, then sigma
        if obj.shared_beta:
            obj._param_names_arr = [f"beta_shared_{i}" for i in range(p)] + ["sigma"]
        else:
            obj._param_names_arr = [f"beta_{r}_{i}" for r in range(R) for i in range(p)] + [
                "sigma"
            ]
        obj._param_order = pd.Index(obj._param_names_arr)

        obj._user_start_params = (
            np.asarray(start_params, dtype=float) if start_params is not None else None
        )

        # Attributes expected by statsmodels GenericLikelihoodModel
        obj.nobs = float(N)
        obj.nparams = (p + 1) if obj.shared_beta else (R * p + 1)
        obj.k_extra = 0
        obj.df_model = obj.nparams - 1
        obj.df_resid = N - obj.nparams

        # Driver-level likelihood support
        obj._driver_ids = driver_ids
        if driver_ids is not None:
            _ids = np.asarray(driver_ids)
            _unique = np.unique(_ids)
            obj._unique_drivers = _unique
            obj._n_drivers = len(_unique)
            _map = {d: idx for idx, d in enumerate(_unique)}
            obj._obs_to_driver = np.array([_map[d] for d in _ids])
            obj._driver_indices = {d: np.where(_ids == d)[0] for d in _unique}

            for _d in _unique:
                _idx = obj._driver_indices[_d]
                if not np.allclose(
                    obj._weighted_cm_arr[_idx[0]], obj._weighted_cm_arr[_idx]
                ):
                    raise ValueError(
                        "weighted_cm must be constant within driver when using driver-level likelihood"
                    )

            # Precompute driver-level weights (D, R) — constant within driver
            _first_obs = np.array([obj._driver_indices[d][0] for d in _unique])
            obj._w_driver = obj._weighted_cm_arr[_first_obs, :]  # (D, R)
            obj._log_w_driver = np.log(obj._w_driver + 1e-300)  # (D, R)

            # Correct nobs for standard errors: D independent units, not N
            obj._n_obs_total = len(y)
            obj.nobs = float(obj._n_drivers)
            obj.df_resid = obj._n_drivers - obj.nparams
        else:
            obj._n_drivers = None

        # Required by statsmodels Model base class
        obj.endog = obj._y_arr  # (N,)
        obj.exog = obj._X_arr[0]  # (N, p) placeholder
        obj.data = type(
            "_Data",
            (),
            {
                "ynames": "y",
                "xnames": obj._param_names_arr,
            },
        )()

        # __init__-compatible attributes
        obj.hdfe = hdfe
        obj.fast_xb = fast_xb
        obj.entity_effects = entity_effects
        obj.time_effects = time_effects
        obj.other_effects = other_effects
        obj.weights = weights
        obj.check_absorbed = check_absorbed

        # Placeholders so shared methods don't crash
        obj._drop_absorbed = drop_absorbed
        obj._get_vars_index = []
        obj._get_vars = []
        obj.k_constant = 1  # intercept is included in X_list

        return obj

    @classmethod
    def from_formula_arrays(
        cls,
        formula,
        data,
        classifier_pred,
        cm,
        entity_effects=False,
        time_effects=False,
        start_params=None,
        soft=True,
        panel_likelihood=True,
        shared_beta=False,
        regime_labels=None,
        **kwargs,
    ):
        """
        Arrays-mode constructor from a formula string and a DataFrame.

        Parses the formula to extract ``y`` and ``X``, applies optional
        entity/time within-demeaning, then delegates to :meth:`from_arrays`.
        The intercept is dropped when any FE demeaning is applied.

        Parameters
        ----------
        formula : str
            Formulaic formula, e.g. ``"y ~ drought_0 + drought_1"``.
        data : DataFrame with (driver, time) MultiIndex
        classifier_pred : (N, R) array or DataFrame of soft ML predictions
        cm : (R, R) column-normalised confusion matrix
        entity_effects : bool
            Within-demean by entity (driver).
        time_effects : bool
            Within-demean by time period.
        start_params : array of shape (R*p + 1,), optional
        soft : bool, default True
            Passed to :meth:`from_arrays`.
        panel_likelihood : bool, default True
            If True, use driver-level likelihood.
        shared_beta : bool, default False
            If True, estimate one coefficient vector shared across all regimes.
            Provide a templated formula like ``"y ~ drought_{r} + drought_lag_{r}"``
            so that each regime receives its own design matrix.
        regime_labels : sequence, optional
            Labels used to expand the formula template. Defaults to ``range(R)``.
        """
        from formulaic import Formula
        import pandas as pd

        flat = data.reset_index()
        R = np.asarray(cm).shape[0]
        cp = np.asarray(classifier_pred, dtype=float)
        labels = list(range(R)) if regime_labels is None else list(regime_labels)
        if len(labels) != R:
            raise ValueError("regime_labels must have length equal to the number of regimes")

        def _expand_formula(label, index):
            return formula.format(r=index, regime=index, label=label, region=label)

        if shared_beta:
            expanded_formulas = [_expand_formula(label, idx) for idx, label in enumerate(labels)]
            if len(set(expanded_formulas)) == 1:
                raise ValueError(
                    "shared_beta=True requires a templated formula that varies across regimes"
                )
            parsed_list = [Formula(f).get_model_matrix(flat) for f in expanded_formulas]
            y = np.asarray(parsed_list[0].lhs).flatten()
            X_list = [np.asarray(parsed.rhs) for parsed in parsed_list]
        else:
            parsed = Formula(formula).get_model_matrix(flat)
            y = np.asarray(parsed.lhs).flatten()
            X = np.asarray(parsed.rhs)  # (N, p) including intercept

        if entity_effects or time_effects:
            y_s = pd.Series(y)
            if entity_effects:
                g = pd.Series(data.index.get_level_values(0).values)
                y_s = y_s - y_s.groupby(g).transform("mean")
            if time_effects:
                g = pd.Series(data.index.get_level_values(1).values)
                y_s = y_s - y_s.groupby(g).transform("mean")
            y = y_s.values
            if shared_beta:
                X_list = [pd.DataFrame(X_r[:, 1:]) for X_r in X_list]
                if entity_effects:
                    g = pd.Series(data.index.get_level_values(0).values)
                    X_list = [X_r.subtract(X_r.groupby(g).transform("mean")) for X_r in X_list]
                if time_effects:
                    g = pd.Series(data.index.get_level_values(1).values)
                    X_list = [X_r.subtract(X_r.groupby(g).transform("mean")) for X_r in X_list]
                X_list = [X_r.values for X_r in X_list]
            else:
                X_no_int = pd.DataFrame(X[:, 1:])  # drop intercept — absorbed by FE
                if entity_effects:
                    g = pd.Series(data.index.get_level_values(0).values)
                    X_no_int = X_no_int.subtract(X_no_int.groupby(g).transform("mean"))
                if time_effects:
                    g = pd.Series(data.index.get_level_values(1).values)
                    X_no_int = X_no_int.subtract(X_no_int.groupby(g).transform("mean"))
                X_list = [X_no_int.values] * R
        elif not shared_beta:
            X_list = [X] * R

        return cls.from_arrays(
            y,
            X_list,
            cp,
            np.asarray(cm, dtype=float),
            start_params=start_params,
            soft=soft,
            shared_beta=shared_beta,
            driver_ids=data.index.get_level_values(0).values
            if panel_likelihood
            else None,
            **kwargs,
        )

    def __init__(
        self,
        endog,
        exog,
        classifier_pred,
        classifier_true_ind=None,
        classifier_ind=None,
        classifier_ind_name=None,
        entity_effects=False,
        time_effects=False,
        other_effects=None,
        weights=None,
        drop_absorbed=False,
        check_rank=True,
        singletons=True,
        check_absorbed=True,
        cm=None,
        hdfe=True,
        fast_xb=False,
        soft=True,
        **kwargs,
    ):

        print("Initializing...")

        self.hdfe = hdfe
        self.fast_xb = fast_xb
        self._soft = soft

        if isinstance(endog, ModelMatrix):
            endog = endog[endog.keys()]
        if isinstance(exog, ModelMatrix):
            exog = exog[exog.keys()]

        if other_effects is not None:
            self.other_effects_name = other_effects.columns.tolist()[0]
            if isinstance(other_effects, ModelMatrix):
                other_effects = other_effects[self.other_effects_name]
                self.other_effects = other_effects
            else:
                self.other_effects = other_effects
        else:
            self.other_effects = None

        self.entity_effects = entity_effects
        self.time_effects = time_effects

        self.check_absorbed = check_absorbed
        self.classifier_true_ind = classifier_true_ind
        if classifier_true_ind is not None:
            self._classifier_true_ind_name = classifier_true_ind.name

        if classifier_ind is None:
            self._group = endog.index.get_level_values(2).name
            if self._group == "gaul":
                self.classifer_ind = _reorganize_gaul_ind(
                    endog.index.get_level_values(2).unique().tolist()
                )
            endog.reset_index(2, inplace=True)
            exog.reset_index(2, inplace=True)
        else:
            self.classifier_ind = classifier_ind
            self._group = classifier_ind_name

        if not all([classifier_ind is not None, classifier_ind_name]):
            raise Exception(
                "If either `classifier_ind` or `classifier_ind_name` is defined, the other must be defined as well "
            )

        self.classifier_pred = classifier_pred
        if self.classifier_pred is not None:
            self.classifier_map = {
                k: v
                for k, v in zip(
                    self.classifier_pred.columns, self.classifier_ind.cat.categories
                )
            }

        endog_cat = (
            endog.assign(gaul_class=self.ind)
            .assign(gaul=self.classifier_ind)
            .query("gaul==gaul_class")
            .drop(columns=["gaul", "gaul_class"])
        )

        if self.other_effects is not None:
            eex_o = exog.assign(**{self.other_effects_name: self.other_effects})
        else:
            eex_o = exog

        exog_cat = (
            eex_o.assign(gaul_class=self.ind)
            .assign(gaul=self.classifier_ind)
            .query("gaul==gaul_class")
            .drop(columns=["gaul", "gaul_class"])
        )

        if self.other_effects is not None:
            ex = exog_cat.drop(columns=self.other_effects_name)
            ex_o = exog_cat[self.other_effects_name]
        else:
            ex = exog_cat
            ex_o = None

        try:
            self.p_model = PanelOLS(
                dependent=endog_cat,
                exog=ex,
                weights=weights,
                entity_effects=entity_effects,
                time_effects=time_effects,
                other_effects=ex_o,
                singletons=singletons,
                drop_absorbed=drop_absorbed,
                check_rank=check_rank,
            )
        except ValueError as e:
            print(e, "skipping...")

        self.p_model_full = PanelOLS(
            dependent=endog,
            exog=exog,
            weights=weights,
            entity_effects=entity_effects,
            time_effects=time_effects,
            other_effects=other_effects,
            singletons=singletons,
            drop_absorbed=drop_absorbed,
            check_rank=check_rank,
        )

        self.endog_cat = self.p_model_full.dependent.dataframe
        self.exog_cat = self.p_model_full.exog.dataframe

        self.endog_full = self.p_model_full.dependent.dataframe.assign(
            **{self._group: self.classifier_ind}
        )
        self.exog_full = self.p_model_full.exog.dataframe.assign(
            **{self._group: self.classifier_ind}
        )

        super().__init__(endog=endog_cat, exog=ex, **kwargs)

        if self.entity_effects and self.time_effects:
            self.demean = "both"
        elif self.entity_effects and not self.time_effects:
            self.demean = "entity"
        elif not self.entity_effects and self.time_effects:
            self.demean = "time"
        else:
            self.demean = None

        # modify degrees of freedom from way that statsmodels does it, to account for the fact that we're estimating sigma
        self.nparams = self.nparams + 1
        self.df_model = self.df_model + 1
        self.df_resid = self.df_resid - 1

        if self.entity_effects or time_effects:
            # Check for multiindex
            if not isinstance(exog.index, pd.MultiIndex):
                raise Exception("Dataframe not a multi-index")

        self.n_regimes = classifier_ind.nunique()

        if cm is None:
            if self.n_regimes == 4:
                self.cm = cm_4
            elif self.n_regimes == 10:
                self.cm = cm_10
        else:
            self.cm = cm.astype(float)

        self._drop_absorbed = drop_absorbed

        self._equal_regime = True
        if (
            self.endog_full.groupby(self._group)[self.p_model_full.dependent.vars[0]]
            .count()
            .nunique()
            > 1
        ):
            warnings.warn(
                "Warning: observations across regimes is not the same, switching to slower method..."
            )
            self._equal_regime = False

        self._get_vars_index = []
        self._get_vars = []
        self.entity, self.time = self.endog_cat.index.names

    @classmethod
    def from_formula(
        cls,
        formula,
        data,
        classifier_pred=None,
        classifier_true_ind=None,
        weights=None,
        drop_absorbed=False,
        check_rank=True,
        singletons=True,
        check_absorbed=True,
        cm=None,
        **kwargs,
    ):

        data, classifier_ind_name = (
            data.reset_index(2),
            data.index.get_level_values(2).name,
        )

        if classifier_ind_name == "gaul":
            classifier_ind = data[classifier_ind_name].unique().tolist()
            classifier_ind = _reorganize_gaul_ind(classifier_ind)
        else:
            classifier_ind = data[classifier_ind_name].unique().tolist()

        if classifier_pred is None:
            print(
                "individual level predictions not provided, will only use confusion matrix"
            )

        if classifier_pred is None and classifier_true_ind is None:
            raise Exception(
                "Must specify either classifier_pred or classifier_true_ind"
            )

        entity_effects = "EntityEffects" in formula
        time_effects = "TimeEffects" in formula

        # now get new formula without entity or time keywords
        formula = re.sub(r"(\+\s+EntityEffects)", "", formula)
        formula = re.sub(r"(\+\s+TimeEffects)", "", formula)

        parser = Formula(formula).get_model_matrix(data)

        endog = parser.lhs
        if isinstance(parser.rhs, pd.DataFrame):
            exog = parser.rhs
            other_effects = None
        else:
            exog, other_effects = parser.rhs

        mod = cls(
            endog=endog,
            exog=exog,
            classifier_pred=classifier_pred,
            classifier_true_ind=classifier_true_ind,
            classifier_ind=data[classifier_ind_name].astype(
                pd.CategoricalDtype(classifier_ind, ordered=True)
            ),
            classifier_ind_name=classifier_ind_name,
            entity_effects=entity_effects,
            time_effects=time_effects,
            other_effects=other_effects,
            weights=weights,
            drop_absorbed=drop_absorbed,
            check_rank=check_rank,
            singletons=singletons,
            check_absorbed=check_absorbed,
            cm=cm,
            **kwargs,
        )

        mod.formula = formula

        return mod

    def _hdfe_data(self, data):
        hdfe = pyhdfe.create(np.array(data.index.to_list()), drop_singletons=False)

        return pd.DataFrame(
            hdfe.residualize(data), columns=data.columns, index=data.index
        )

    def demean_data(self, data):

        if self.hdfe:
            return self._hdfe_data(data)
        else:
            if self.demean == "entity":
                new_data = data.groupby(self.entity).transform(lambda x: x - x.mean())
            elif self.demean == "time":
                new_data = data.groupby(self.time).transform(lambda x: x - x.mean())
            elif self.demean == "both":
                new_data = (
                    data.groupby(self.entity)
                    .transform(lambda x: x - x.mean())
                    .groupby(self.time)
                    .transform(lambda x: x - x.mean())
                )
            else:
                new_data = data

            if self.other_effects is not None:
                new_data_index_names = new_data.index.names
                new_data = (
                    new_data.assign(
                        other=self.other_effects.reset_index()
                        .drop_duplicates()
                        .set_index(new_data_index_names)
                    )
                    .groupby("other")
                    .transform(lambda x: x - x.mean())
                )

            return new_data

    @functools.lru_cache(maxsize=128)
    def _regime_list(self, lm):
        return np.array(
            [
                group.drop(columns=self._group).pipe(self.demean_data).values
                for _, group in getattr(self, lm).groupby(self._group)
            ]
        )

    @functools.cached_property
    def X(self):
        if getattr(self, "_arrays_mode", False):
            return self._X_arr  # (R, N, p) — all obs under each regime

        X = self._regime_list("exog_full")

        if self.check_absorbed:
            exception_flag = False
            for i, regime in enumerate(X):
                try:
                    check_absorbed(regime, self.exog_full.columns.tolist())
                except AbsorbingEffectError as e:
                    get_vars = {
                        v for v in self.exog_full.columns.tolist() if v in str(e)
                    }
                    get_vars.discard("Intercept")
                    print(
                        f"Multicollinearity Alert!\n  Regime: {list(self.classifier_map.values())[i]}\n  {get_vars}"
                    )
                    if self._drop_absorbed:
                        self._get_vars_index.append(
                            self.exog_full.columns.get_indexer(get_vars)
                        )
                        self._get_vars.append(get_vars)
                    else:
                        exception_flag = True
            if exception_flag:
                raise AbsorbingEffectError
            if self._get_vars and reduce(
                lambda x, y: x.intersection(y), self._get_vars
            ):
                raise AbsorbingEffectError(
                    f"Common Absorbed Variables across regimes: "
                    f"{reduce(lambda x, y: x.intersection(y), self._get_vars)}"
                )

        if X.ndim == 1:
            raise Exception("Regimes not of equal size...")
        return X

    @functools.cached_property
    def y(self):
        if getattr(self, "_arrays_mode", False):
            return self._y_arr  # (N,)
        return np.squeeze(self._regime_list("endog_full"))

    @functools.cached_property
    def ind(self):
        if self.classifier_pred is not None:
            return self.classifier_pred.idxmax(axis=1).map(self.classifier_map)
        else:
            return self.classifier_true_ind.reset_index(self._group, drop=True)

    @functools.cached_property
    def p(self):
        if self.classifier_pred is not None:
            return self.classifier_pred.values
        else:
            return np.ones((self.y.shape[0], self.n_regimes))

    @functools.cached_property
    def _weighted_cm(self):
        """Precomputed (N, R) weight matrix.
        soft=True  → p @ cm.T  (full soft probabilities)
        soft=False → hard argmax mask @ cm.T  (pre-soft behaviour)
        Constant across optimizer iterations; cached on first access."""
        if getattr(self, "_arrays_mode", False):
            return self._weighted_cm_arr  # (N, R), already computed in from_arrays
        p = self.p
        if getattr(self, "_soft", True):
            return p @ self.cm.T
        else:
            row_maxes = p.max(axis=1, keepdims=True)
            class_ind = np.where(p == row_maxes, p, 0)
            return class_ind @ self.cm.T

    def _ll(self, params):
        X = self.X  # (R, N, p) in arrays_mode; (R, N/R, p) in DataFrame mode

        results_df = pd.Series(params, index=self._param_order)
        beta_df = results_df.loc[results_df.index != "sigma"]
        sigma = results_df.loc[results_df.index == "sigma"].values[0]

        if getattr(self, "_arrays_mode", False):
            R = self.n_regimes
            p = self._n_params_per_regime
            if getattr(self, "shared_beta", False):
                beta_vec = beta_df.values  # (p,)
                Xb = np.einsum("rni,i->rn", X, beta_vec)  # (R, N)
            else:
                # Per-regime betas: reshape [beta_0_0, ..., beta_{R-1}_{p-1}] → (R, p)
                beta_mat = beta_df.values.reshape(R, p)  # (R, p)
                Xb = np.einsum("rni,ri->rn", X, beta_mat)  # (R, N)
            rnl = norm.pdf(self.y[None, :] - Xb, 0, scale=np.abs(sigma)).T  # (N, R)
        elif self._drop_absorbed and self._get_vars_index:
            Xb = np.empty((self.n_regimes, self.exog.shape[0]))
            for i, (x, no_retain, no_retain_names) in enumerate(
                zip(X, self._get_vars_index, self._get_vars)
            ):
                beta_vec = beta_df.loc[
                    lambda df: ~df.index.isin(no_retain_names)
                ].values
                Xb[i, :] = np.delete(x, no_retain, axis=1) @ beta_vec
            rnl = norm.pdf(self.y - Xb, 0, scale=np.abs(sigma)).T
        else:
            if self.fast_xb:
                Xb = X @ beta_df.values
            else:
                beta_vec = beta_df.values[:, np.newaxis]
                Xb = np.einsum("ijk,kl -> ijl", X, beta_vec)[..., 0]
            rnl = norm.pdf(self.y - Xb, 0, scale=np.abs(sigma)).T

        # rnl is (N, R) at this point — per-obs densities

        if getattr(self, "_driver_ids", None) is None:
            # Observation-level (original)
            return np.log((rnl * self._weighted_cm).sum(axis=1))

        # --- Driver-level likelihood ---
        D = self._n_drivers
        R = self.n_regimes

        # Compute log-densities directly (avoids log(pdf) roundtrip)
        log_f = np.log(rnl + 1e-300)  # (N, R)

        # Sum log-densities within each driver → (D, R)
        log_prod = np.zeros((D, R))
        np.add.at(log_prod, self._obs_to_driver, log_f)

        # log L_i = log[ Σ_r w_i(r) · exp(log_prod_i(r)) ]
        # = log[ Σ_r exp( log w_i(r) + log_prod_i(r) ) ]
        log_terms = self._log_w_driver + log_prod  # (D, R)

        # Log-sum-exp across regimes
        ll_driver = logsumexp(log_terms, axis=1)  # (D,)

        return ll_driver

    def _params_to_ll(self, params):

        # Since we always put the covariates at the end, take them out from the end
        # regime_params = res.params.values[:-num_covariates]

        beta_vec = params[:-1]
        sigma_vec = params[-1]

        return beta_vec, sigma_vec

    def nloglikeobs(self, params):
        """Negative log-likelihood for an observation. The params matrix is the strange thing here
        and needs to be better defined.

        Args:
            params (ndarray): The matrix of parameters to optimize

        """

        # beta_vec, sigma_vec = self._params_to_ll(params)

        ll = self._ll(params=params)

        return -ll

    def bounds(self, num_exog, sigma_bound):

        # Now set up bounds on variables
        beta_bounds = [(None, None) for _ in range(num_exog - 1)]

        sigma_bounds = [sigma_bound if sigma_bound is not None else (None, None)]

        bounds = tuple(beta_bounds + sigma_bounds)

        return bounds

    def _start_params(self, show_ols=False, cluster_var=None, start_params_res=None):
        """Runs OLS regression to get start params for MLE coefficients"""

        print("Creating starting values...")

        if start_params_res is not None:
            res = start_params_res
        else:
            if cluster_var is None:
                res = self.p_model.fit()
            else:
                res = self.p_model.fit(cov_type="clustered", clusters=cluster_var)

        # Now get sigma
        sigma = self.endog.std()

        results_df = pd.concat([res.params, pd.DataFrame([sigma], index=["sigma"])])
        if show_ols:
            print(res.summary)

        return results_df, res

    def fit(
        self,
        method=None,
        maxiter=10000,
        maxfun=5000,
        sigma_bound=None,
        cluster_var=None,
        show_ols=False,
        start_params=None,
        start_params_res=None,
        **kwds,
    ):
        def _normalize_arrays_start_params(params):
            sp_arr = np.asarray(params, dtype=float)
            if not getattr(self, "_arrays_mode", False):
                return sp_arr

            p = self._n_params_per_regime
            R = self.n_regimes
            expected = (p + 1) if getattr(self, "shared_beta", False) else (R * p + 1)
            if len(sp_arr) == expected:
                return sp_arr
            if getattr(self, "shared_beta", False) and len(sp_arr) == (R * p + 1):
                shared_beta = sp_arr[:-1].reshape(R, p).mean(axis=0)
                return np.append(shared_beta, sp_arr[-1])
            raise ValueError(
                f"Expected start_params with length {expected}, got {len(sp_arr)}"
            )

        # Resolve starting parameters
        _user_sp = (
            start_params
            if start_params is not None
            else getattr(self, "_user_start_params", None)
        )

        if _user_sp is not None:
            sp_arr = _normalize_arrays_start_params(_user_sp)
            results_df = pd.Series(sp_arr, index=self._param_order)
            pols_res = None
        elif getattr(self, "_arrays_mode", False):
            R = self.n_regimes
            p = self._n_params_per_regime
            if getattr(self, "shared_beta", False):
                A = np.zeros((p, p))
                b = np.zeros(p)
                for r in range(R):
                    wt = self._weighted_cm_arr[:, r]
                    X_r = self._X_arr[r]
                    A += (X_r * wt[:, None]).T @ X_r
                    b += (X_r * wt[:, None]).T @ self._y_arr
                beta_init = np.linalg.solve(A, b)
                resid2 = np.zeros(self._n_obs)
                for r in range(R):
                    resid2 += self._weighted_cm_arr[:, r] * (
                        self._y_arr - self._X_arr[r] @ beta_init
                    ) ** 2
                sigma_init = float(np.sqrt(np.mean(resid2)))
                sp_arr = np.append(beta_init, sigma_init)
            else:
                # arrays_mode without user start_params: OLS per predicted-regime group
                beta_init = np.zeros(R * p)
                R_pred = self._classifier_pred_arr.argmax(axis=1)
                for r in range(R):
                    mask = R_pred == r
                    if mask.sum() > p:
                        X_r = self._X_arr[r][mask]
                        beta_init[r * p : (r + 1) * p] = np.linalg.lstsq(
                            X_r, self._y_arr[mask], rcond=None
                        )[0]
                _resid = np.zeros_like(self._y_arr)
                for r in range(R):
                    mask = R_pred == r
                    if mask.sum() > p:
                        _resid[mask] = (
                            self._y_arr[mask]
                            - self._X_arr[r][mask] @ beta_init[r * p : (r + 1) * p]
                        )
                sigma_init = float(np.sqrt(np.mean(_resid**2)))
                sp_arr = np.append(beta_init, sigma_init)
            results_df = pd.Series(sp_arr, index=self._param_order)
            pols_res = None
        else:
            results_df, pols_res = self._start_params(
                show_ols=show_ols,
                cluster_var=cluster_var,
                start_params_res=start_params_res,
            )

        self._param_order = results_df.index

        if cluster_var is not None:
            cov_type = "cluster"
            cov_kwds = {
                "groups": cluster_var,
                "df_correction": True,
                "use_correction": True,
            }
        else:
            cov_type = "HC1"
            cov_kwds = kwds.pop("cov_kwds", None)

        _method = method if method is not None else "lbfgs"
        _bounds = self.bounds(num_exog=len(results_df), sigma_bound=sigma_bound)
        _fit_kwds = dict(
            start_params=results_df.values,
            maxiter=maxiter,
            maxfun=maxfun,
            bounds=_bounds,
            cov_type=cov_type,
            use_t=True,
        )
        if _method != "lbfgs":
            _fit_kwds["eps"] = 1e-08
            _fit_kwds["ftol"] = 1e-10
        else:
            _fit_kwds["pgtol"] = 1e-10
        if cov_kwds is not None:
            _fit_kwds["cov_kwds"] = cov_kwds
        _fit_kwds.update(kwds)
        optimize = super().fit(method=_method, **_fit_kwds)

        # Wrap params as a named Series so callers can access by name (e.g. res.params["sigma"])
        if optimize is not None and not isinstance(optimize.params, pd.Series):
            optimize.params = pd.Series(
                np.asarray(optimize.params), index=self._param_order
            )

        return optimize, pols_res

    def score_bootstrap(self, fitted_result, clusters=None, **kwargs):
        """Run score wild bootstrap on an already-fitted result.

        Parameters
        ----------
        fitted_result : statsmodels result object
            The first element returned by ``self.fit()``.
        clusters : array-like, optional
            Explicit cluster IDs.  If None and the model uses driver-level
            likelihood, each driver is treated as its own singleton cluster.
        **kwargs
            Passed to ``ScoreWildBootstrap.get_pvalue()`` (e.g.
            ``bootstrap_num``, ``seed``, ``alpha``).

        Returns
        -------
        ScoreWildBootstrap
            Instance with ``pvalues_``, ``bse_boot_``, ``conf_int_boot_``,
            ``wald_boot_``, and ``param_names_`` attributes set.
        """
        swb = ScoreWildBootstrap(fitted_result, clusters=clusters)
        swb.get_pvalue(**kwargs)
        return swb
