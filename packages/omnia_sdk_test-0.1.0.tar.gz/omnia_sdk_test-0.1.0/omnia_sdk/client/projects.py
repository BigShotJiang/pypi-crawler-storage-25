from __future__ import annotations

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.chat import Chat
from omnia_sdk.models.project import Project


class ProjectsClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def list_projects(self, user_id: str, search: str = "", limit: int = 50) -> list[Project]:
        params: dict = {"limit": limit}
        if search:
            params["search"] = search
        data = self._base.request("GET", f"/api/v1/app/users/{user_id}/projects", params=params)
        return [Project.model_validate(p) for p in data.get("projects", [])]

    def create_project(self, user_id: str, name: str, description: str = "") -> Project:
        payload: dict = {"user_id": user_id, "name": name}
        if description:
            payload["description"] = description
        data = self._base.request("POST", f"/api/v1/app/users/{user_id}/projects", json=payload)
        return Project.model_validate(data.get("project", data))

    def get_project(self, user_id: str, project_id: str) -> Project:
        data = self._base.request("GET", f"/api/v1/app/users/{user_id}/projects/{project_id}")
        return Project.model_validate(data.get("project", data))

    def delete_project(self, user_id: str, project_id: str) -> dict:
        return self._base.request("DELETE", f"/api/v1/app/users/{user_id}/projects/{project_id}")

    def list_chats(self, user_id: str, project_id: str) -> list[Chat]:
        data = self._base.request(
            "GET", f"/api/v1/app/users/{user_id}/projects/{project_id}/chats"
        )
        return [Chat.model_validate(c) for c in data.get("chats", [])]

    def create_chat(self, user_id: str, project_id: str, name: str = "Chat") -> Chat:
        data = self._base.request(
            "POST",
            f"/api/v1/app/users/{user_id}/projects/{project_id}/chats",
            json={"user_id": user_id, "project_id": project_id, "name": name},
        )
        return Chat.model_validate(data.get("chat", data))

    def get_or_create_chat(self, user_id: str, project_id: str) -> Chat:
        chats = self.list_chats(user_id, project_id)
        if chats:
            return max(chats, key=lambda c: str(c.updated_at or c.created_at or ""))
        return self.create_chat(user_id, project_id)

    def create_project_with_chat(self, user_id: str, name: str) -> tuple[Project, Chat]:
        project = self.create_project(user_id, name)
        chat = self.create_chat(user_id, project.id)
        return project, chat
