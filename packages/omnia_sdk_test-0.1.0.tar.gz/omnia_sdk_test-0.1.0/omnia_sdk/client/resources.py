from __future__ import annotations

from pathlib import Path

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.resource import Resource


class ResourcesClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def list_resources(self, user_id: str, project_id: str) -> list[Resource]:
        data = self._base.request(
            "GET", f"/api/v1/app/users/{user_id}/projects/{project_id}/resources"
        )
        return [Resource.model_validate(r) for r in data.get("resources", [])]

    def upload_resource(self, user_id: str, project_id: str, file_path: Path) -> Resource:
        with open(file_path, "rb") as fh:
            files = {"file": (file_path.name, fh, "application/octet-stream")}
            data = self._base.request(
                "POST",
                f"/api/v1/app/users/{user_id}/projects/{project_id}/resources",
                files=files,
                timeout=120.0,
            )
        return Resource.model_validate(data.get("resource", data))

    def delete_resource(self, user_id: str, project_id: str, resource_id: str) -> dict:
        return self._base.request(
            "DELETE",
            f"/api/v1/app/users/{user_id}/projects/{project_id}/resources/{resource_id}",
        )
