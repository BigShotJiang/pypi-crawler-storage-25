"""
Base HTTP client. Holds credentials and provides request/stream methods.
All sub-clients receive an instance of this class.
"""

from __future__ import annotations

import json as _json
import os
from contextlib import contextmanager
from typing import Any, Generator, Iterator

import httpx

_RETRY_CODES = {429, 502, 503, 504}
_MAX_RETRIES = 2

_ENV_URLS = {
    "prod": "https://api.omniasec.ai",
    "dev": "http://localhost:8000",
}

_FRONTEND_URLS = {
    "prod": "https://app.omniasec.ai",
    "dev": "http://localhost:5173",
}


class OmniaAPIError(Exception):
    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class NotConfiguredError(Exception):
    pass


class BaseClient:
    def __init__(
        self,
        api_key: str,
        api_url: str,
        default_model: str,
        default_provider: str,
    ) -> None:
        self._api_key = api_key
        self._api_url = api_url
        self.default_model = default_model
        self.default_provider = default_provider

    def _url(self, path: str) -> str:
        return self._api_url.rstrip("/") + path

    def _auth_headers(self) -> dict[str, str]:
        if not self._api_key:
            raise NotConfiguredError(
                "No API key set. Pass api_key to OmniaClient() or set OMNIA_API_TOKEN."
            )
        if " " not in self._api_key.strip():
            return {"X-API-Key": self._api_key}
        return {"Authorization": self._api_key}

    def _handle_response(self, response: httpx.Response) -> None:
        if response.is_success:
            return
        try:
            response.read()
        except Exception:
            pass
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise OmniaAPIError(response.status_code, str(detail))

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict | None = None,
        files: dict | None = None,
        data: dict | None = None,
        timeout: float = 30.0,
        auth: bool = True,
    ) -> Any:
        headers = self._auth_headers() if auth else {}
        last_exc: Exception | None = None
        for attempt in range(_MAX_RETRIES + 1):
            try:
                with httpx.Client(headers=headers, timeout=timeout, follow_redirects=True) as client:
                    resp = client.request(
                        method, self._url(path),
                        json=json, params=params, files=files, data=data,
                    )
                self._handle_response(resp)
                return resp.json()
            except OmniaAPIError as exc:
                if exc.status_code not in _RETRY_CODES or attempt == _MAX_RETRIES:
                    raise
                last_exc = exc
            except httpx.RequestError as exc:
                if attempt == _MAX_RETRIES:
                    raise
                last_exc = exc
        raise last_exc  # type: ignore[misc]

    @contextmanager
    def stream_request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        timeout: float = 120.0,
    ) -> Generator[httpx.Response, None, None]:
        headers = self._auth_headers()
        with httpx.Client(headers=headers, timeout=timeout, follow_redirects=True) as client:
            with client.stream(method, self._url(path), json=json) as response:
                self._handle_response(response)
                yield response

    @staticmethod
    def iter_sse(response: httpx.Response) -> Iterator[dict]:
        buffer = ""
        for chunk in response.iter_text():
            buffer += chunk
            while "\n" in buffer:
                event_str, buffer = buffer.split("\n", 1)
                for line in event_str.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    raw = line[5:].strip() if line.startswith("data:") else line
                    if raw and raw != "[DONE]":
                        try:
                            yield _json.loads(raw)
                        except _json.JSONDecodeError:
                            pass
