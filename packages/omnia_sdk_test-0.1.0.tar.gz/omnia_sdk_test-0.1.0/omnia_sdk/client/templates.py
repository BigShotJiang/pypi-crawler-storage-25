from __future__ import annotations

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.template import Template


class TemplatesClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def list_templates(self, user_id: str, search: str = "") -> list[Template]:
        params = {"search": search} if search else None
        data = self._base.request("GET", f"/api/v1/app/users/{user_id}/templates", params=params)
        return [Template.model_validate(t) for t in data.get("templates", [])]

    def get_template(self, user_id: str, template_id: str) -> Template:
        return Template.model_validate(
            self._base.request("GET", f"/api/v1/app/users/{user_id}/templates/{template_id}")
        )

    def create_template(self, user_id: str, payload: dict) -> Template:
        return Template.model_validate(
            self._base.request("POST", f"/api/v1/app/users/{user_id}/templates", json=payload)
        )

    def update_template(self, user_id: str, template_id: str, payload: dict) -> Template:
        return Template.model_validate(
            self._base.request(
                "PATCH",
                f"/api/v1/app/users/{user_id}/templates/{template_id}",
                json=payload,
            )
        )

    def delete_template(self, user_id: str, template_id: str) -> dict:
        return self._base.request(
            "DELETE", f"/api/v1/app/users/{user_id}/templates/{template_id}"
        )

    def fork_template(self, user_id: str, template_id: str) -> Template:
        return Template.model_validate(
            self._base.request(
                "POST",
                f"/api/v1/app/users/{user_id}/templates/fork",
                json={"template_id": template_id},
            )
        )
