from __future__ import annotations

from omnia_sdk.client.base import BaseClient


class WorkflowsClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def run_file_analysis(
        self,
        user_id: str,
        project_id: str,
        resource_hash: str,
        chat_id: str,
    ) -> dict:
        return self._base.request(
            "POST",
            "/api/v1/workflows/FileAnalysisWorkflow/run",
            json={
                "user_id": user_id,
                "project_id": project_id,
                "resource_hash": resource_hash,
                "chat_id": chat_id,
            },
        )
