from __future__ import annotations

import json as _json

from omnia_sdk.client.base import BaseClient


class PublicClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def get_api_version(self) -> dict:
        return self._base.request("GET", "/api/versions", auth=False)

    def get_public_analysis(self, analysis_id: str) -> dict:
        return self._base.request("GET", f"/api/v1/public/analysis/{analysis_id}", auth=False)

    def get_public_analysis_children(self, analysis_id: str) -> list[dict]:
        data = self._base.request(
            "GET", f"/api/v1/public/analysis/{analysis_id}/children", auth=False
        )
        return data.get("analyses", [])

    def get_public_template(self, template_id: str) -> dict:
        return self._base.request(
            "GET", f"/api/v1/public/templates/{template_id}", auth=False
        )

    def search_market(self, query: str, page: int = 1, limit: int = 20) -> dict:
        return self._base.request(
            "GET",
            "/api/v1/public/market-intelligence/search",
            params={"search_expression": query, "page": page, "limit": limit},
            auth=False,
        )

    def get_market_package(self, market: str, market_id: str, version: str = "") -> dict:
        params = {"version": version} if version else None
        return self._base.request(
            "GET",
            f"/api/v1/public/market-intelligence/package/{market}/{market_id}",
            params=params,
            auth=False,
        )

    def get_market_package_versions(self, market: str, market_id: str) -> dict:
        return self._base.request(
            "GET",
            f"/api/v1/public/market-intelligence/package/{market}/{market_id}/versions",
            auth=False,
        )

    def get_shared_chat(self, token: str) -> dict:
        data = self._base.request(
            "GET", f"/api/v1/public/project_backups/{token}/preview", auth=False
        )
        raw = data.get("project_backup_preview", data)
        if isinstance(raw, str):
            raw = _json.loads(raw)
        return raw
