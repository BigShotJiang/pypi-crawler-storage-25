from __future__ import annotations

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.user import User


class AuthClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def get_me(self) -> User:
        return User.model_validate(self._base.request("GET", "/api/v1/app/users/me"))

    def get_agents(self) -> list[dict]:
        data = self._base.request("GET", "/api/v1/agents")
        return data.get("agents", [])

    def get_last_user_settings(self, user_id: str) -> dict:
        data = self._base.request("GET", f"/api/v1/app/users/{user_id}/last_settings")
        return data.get("settings", {})

    def update_user_settings(self, user_id: str, settings: dict) -> dict:
        data = self._base.request(
            "PATCH",
            f"/api/v1/app/users/{user_id}/last_settings",
            json=settings,
        )
        return data.get("settings", {})
