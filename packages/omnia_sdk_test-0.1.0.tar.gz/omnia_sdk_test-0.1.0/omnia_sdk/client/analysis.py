from __future__ import annotations

from pathlib import Path

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.analysis import Analysis


class AnalysisClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def list_analyses(self, user_id: str, shared: bool = False) -> list[Analysis]:
        path = f"/api/v1/app/users/{user_id}/analysis"
        if shared:
            path += "/shared"
        data = self._base.request("GET", path)
        raw = data if isinstance(data, list) else data.get("analysis", data.get("analyses", []))
        return [Analysis.model_validate(a) for a in raw]

    def get_analysis(self, analysis_id: str) -> Analysis:
        return Analysis.model_validate(self._base.request("GET", f"/api/v1/app/analysis/{analysis_id}"))

    def get_analysis_children(self, analysis_id: str) -> list[Analysis]:
        data = self._base.request("GET", f"/api/v1/app/analysis/{analysis_id}/childs")
        return [Analysis.model_validate(a) for a in data.get("childs", data.get("analyses", []))]

    def upload_file(self, user_id: str, file_path: Path) -> Analysis:
        with open(file_path, "rb") as fh:
            files = {"file": (file_path.name, fh, "application/octet-stream")}
            data = self._base.request(
                "POST",
                f"/api/v1/app/users/{user_id}/launch/analysis",
                files=files,
                timeout=120.0,
            )
        return Analysis.model_validate(data.get("analysis", data))
