from __future__ import annotations

from collections.abc import Iterator
from typing import Optional

from omnia_sdk.client.base import BaseClient
from omnia_sdk.models.message import ChatMessage


class MessagesClient:
    def __init__(self, base: BaseClient) -> None:
        self._base = base

    def list_messages(
        self,
        user_id: str,
        project_id: str,
        chat_id: str,
        tag: str = "frontend,agent_launch,workflow_launch",
    ) -> list[ChatMessage]:
        data = self._base.request(
            "GET",
            f"/api/v1/app/users/{user_id}/projects/{project_id}/chats/{chat_id}/messages",
            params={"tag": tag},
        )
        raw = data.get("messages", data.get("chat_messages", []))
        return [ChatMessage.model_validate(m) for m in raw]

    def delete_message(
        self, user_id: str, project_id: str, chat_id: str, message_id: str
    ) -> dict:
        return self._base.request(
            "PATCH",
            f"/api/v1/app/users/{user_id}/projects/{project_id}/chats/{chat_id}/messages/{message_id}",
            json={"deleted": True},
        )

    def stream_message(
        self,
        user_id: str,
        project_id: str,
        chat_id: str,
        query: str,
        *,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        mcp_servers: Optional[list] = None,
        resources_in_context: Optional[list] = None,
        native_tools: Optional[list] = None,
        knowledges: Optional[list] = None,
        skill_ids: Optional[list] = None,
        agent_launch_id: Optional[str] = None,
        additional_info: str = "",
        user_settings: Optional[dict] = None,
    ) -> Iterator[dict]:
        payload = self._build_payload(
            user_id, project_id, chat_id, query,
            model=model, provider=provider,
            mcp_servers=mcp_servers, resources_in_context=resources_in_context,
            native_tools=native_tools, knowledges=knowledges,
            skill_ids=skill_ids, agent_launch_id=agent_launch_id,
            additional_info=additional_info, user_settings=user_settings,
            streaming=True,
        )
        with self._base.stream_request(
            "POST", "/api/v1/agents/OmniaMainAgent/a1/chat/run", json=payload
        ) as response:
            yield from self._base.iter_sse(response)

    def send_message(
        self,
        user_id: str,
        project_id: str,
        chat_id: str,
        query: str,
        **kwargs,
    ) -> dict:
        payload = self._build_payload(user_id, project_id, chat_id, query, streaming=False, **kwargs)
        return self._base.request(
            "POST", "/api/v1/agents/OmniaMainAgent/a1/chat/run", json=payload, timeout=120.0
        )

    def launch_workflow(
        self,
        agent_name: str,
        workflow_endpoint: str,
        user_id: str,
        project_id: str,
        chat_id: str,
        workflow_template_id: str,
        written_params: dict,
        *,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        user_settings: Optional[dict] = None,
    ) -> dict:
        _model = model or self._base.default_model
        _provider = provider or self._base.default_provider
        payload = {
            "query": "",
            "user_id": user_id,
            "project_id": project_id,
            "chat_id": chat_id,
            "workflow_template_id": workflow_template_id,
            "written_params": written_params,
            "mcp_servers": [],
            "additional_info": "",
            "config": {
                "selected_model": _model,
                "selected_provider": _provider,
                "user_settings": user_settings or {},
            },
        }
        return self._base.request(
            "POST", f"/api/v1/agents/{agent_name}{workflow_endpoint}", json=payload, timeout=120.0
        )

    def _build_payload(
        self,
        user_id: str,
        project_id: str,
        chat_id: str,
        query: str,
        *,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        mcp_servers: Optional[list] = None,
        resources_in_context: Optional[list] = None,
        native_tools: Optional[list] = None,
        knowledges: Optional[list] = None,
        skill_ids: Optional[list] = None,
        agent_launch_id: Optional[str] = None,
        additional_info: str = "",
        streaming: bool = True,
        user_settings: Optional[dict] = None,
    ) -> dict:
        _model = model or self._base.default_model
        _provider = provider or self._base.default_provider
        payload = {
            "query": query,
            "user_id": user_id,
            "project_id": project_id,
            "chat_id": chat_id,
            "model": _model,
            "provider": _provider,
            "mcp_servers": mcp_servers or [],
            "resources_in_context": resources_in_context or [],
            "native_tools": native_tools or ["all"],
            "knowledges": knowledges or [],
            "skill_ids": skill_ids or [],
            "additional_info": additional_info,
            "streaming": streaming,
            "config": {
                "selected_model": _model,
                "selected_provider": _provider,
                "user_settings": user_settings or {},
            },
        }
        if agent_launch_id:
            payload["agent_launch_id"] = agent_launch_id
        return payload
