from __future__ import annotations

from datetime import datetime

from omnia_sdk.models.common import AnalysisStatus, AnalysisVerdict, OmniaModel


class Analysis(OmniaModel):
    user_id: str
    project_id: str
    file_id: str
    chat_id: str | None = None
    message_id: str | None = None
    status: AnalysisStatus | None = None
    verdict: AnalysisVerdict | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    visible_by_groups: list[str] = []
