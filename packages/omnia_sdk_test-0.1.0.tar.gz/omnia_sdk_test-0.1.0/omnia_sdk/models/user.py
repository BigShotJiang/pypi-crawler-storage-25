from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import OmniaModel


class User(OmniaModel):
    email: str
    name: str | None = None
    roles: list[str] = []
    status: str | None = None
    groups: list[str] = []


class UserUpdate(BaseModel):
    output_queue: str | None = None
    queue_type: str | None = None
