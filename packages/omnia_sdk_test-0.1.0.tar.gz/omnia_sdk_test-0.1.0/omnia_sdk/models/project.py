from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import AnalysisVerdict, OmniaModel, ProjectExecutionTag


class Project(OmniaModel):
    user_id: str
    name: str
    description: str | None = None
    folder_tag: str | None = None
    verdict: AnalysisVerdict | None = None
    verdict_reason: str | None = None
    unread_messages: int = 0
    project_execution_tag: ProjectExecutionTag | None = None
    template_run_id: str | None = None


class ProjectCreate(BaseModel):
    user_id: str
    name: str
    description: str | None = None


class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    folder_tag: str | None = None
