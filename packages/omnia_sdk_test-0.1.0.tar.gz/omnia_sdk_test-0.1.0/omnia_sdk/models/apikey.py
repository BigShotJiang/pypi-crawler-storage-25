from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import ApiKeyRole, OmniaModel


class ApiKey(OmniaModel):
    user_id: str
    key: str | None = None  # only present on creation
    tag: ApiKeyRole | None = None
    name: str | None = None


class ApiKeyCreate(BaseModel):
    tag: ApiKeyRole = ApiKeyRole.user
    name: str | None = None
