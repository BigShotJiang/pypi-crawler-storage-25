from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import OmniaModel


class Chat(OmniaModel):
    user_id: str
    project_id: str
    name: str | None = None
    description: str | None = None


class ChatCreate(BaseModel):
    user_id: str
    project_id: str
    name: str = "Chat"
    description: str | None = None


class ChatUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
