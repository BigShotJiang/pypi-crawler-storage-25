"""Shared enums and base model used across all SDK models."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel


class OmniaModel(BaseModel):
    """Base model for all Omnia SDK response objects."""

    model_config = {"extra": "allow"}

    id: str
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AnalysisVerdict(str, Enum):
    malicious = "malicious"
    risky = "risky"
    undetected = "undetected"


class AnalysisStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"


class ChatMessageStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    error = "error"


class ChatMessageTag(str, Enum):
    frontend = "frontend"
    backend = "backend"
    deleted = "deleted"
    agent_launch = "agent_launch"
    workflow_launch = "workflow_launch"


class ChatMessageType(str, Enum):
    surveillance = "surveillance"
    user = "user"
    assistant = "assistant"
    file = "file"
    task = "task"
    code = "code"
    report = "report"
    agent_launch = "agent_launch"
    workflow_launch = "workflow_launch"
    workflow_end = "workflow_end"
    context_file = "context_file"
    side_by_side = "side_by_side"
    analysis = "analysis"


class TemplateType(str, Enum):
    GUIDELINE = "GUIDELINE"
    PROMPT = "PROMPT"
    REPORT_FORMAT = "REPORT_FORMAT"
    AGENT_RECIPE = "AGENT_RECIPE"
    AGENT_WORKFLOW = "AGENT_WORKFLOW"
    KNOWLEDGE = "KNOWLEDGE"
    MCP = "MCP"
    SKILL = "SKILL"


class TemplateStatus(str, Enum):
    ENABLED = "ENABLED"
    DISABLED = "DISABLED"
    PROCESSING = "PROCESSING"
    FAILED = "FAILED"


class TemplateConfidenceLevel(str, Enum):
    TEST = "TEST"
    DEVELOPMENT = "DEVELOPMENT"
    PRODUCTION = "PRODUCTION"


class ResourceType(str, Enum):
    unknown = "unknown"
    global_file = "global_file"
    url = "url"
    report = "report"


class MessageStepType(str, Enum):
    agent = "agent"
    user = "user"


class MessageStepStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    error = "error"


class ProjectExecutionTag(str, Enum):
    user = "user"
    batch = "batch"
    bot = "bot"
    analysis = "analysis"


class ApiKeyRole(str, Enum):
    user = "user"
    bot = "bot"
    cli = "cli"
