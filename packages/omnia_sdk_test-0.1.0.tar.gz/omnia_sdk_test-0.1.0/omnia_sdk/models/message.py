from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import (
    ChatMessageStatus,
    ChatMessageTag,
    ChatMessageType,
    MessageStepStatus,
    MessageStepType,
    OmniaModel,
)


class ChatMessage(OmniaModel):
    user_id: str
    project_id: str
    chat_id: str
    content: str
    tag: ChatMessageTag | None = None
    component_type: ChatMessageType | None = None
    status: ChatMessageStatus | None = None
    timestamp: float | None = None
    associated_resource_paths: list[str] = []
    use_in_context: bool = False
    interact_with_resources: bool = False
    framework: str | None = None
    memory: str | None = None
    knowledge_content: str | None = None
    used_knowledge_ids: list[str] = []
    template_run_id: str | None = None
    template_run_step_id: str | None = None


class ChatMessageUpdate(BaseModel):
    content: str | None = None
    status: ChatMessageStatus | None = None
    deleted: bool | None = None


class MessageStep(OmniaModel):
    user_id: str
    project_id: str
    chat_id: str
    message_id: str
    content: str
    step_type: MessageStepType | None = None
    status: MessageStepStatus | None = None
    timestamp: float | None = None


class MessageStepUpdate(BaseModel):
    content: str | None = None
    status: MessageStepStatus | None = None
