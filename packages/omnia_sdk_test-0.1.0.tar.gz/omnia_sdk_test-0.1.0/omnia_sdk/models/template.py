from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import (
    OmniaModel,
    TemplateConfidenceLevel,
    TemplateStatus,
    TemplateType,
)


class TemplateStep(BaseModel):
    step_type: str | None = None
    step_number: int | None = None
    title: str | None = None
    content: str | None = None
    depends_on_steps: list[str] = []
    jump_to_step: str | None = None
    gui_info: dict = {}


class Template(OmniaModel):
    user_id: str
    title: str
    template_type: TemplateType | None = None
    status: TemplateStatus | None = None
    confidence_level: TemplateConfidenceLevel | None = None
    description: str | None = None
    author_name: str | None = None
    stars: float = 0
    tags: list[str] = []
    prompt: str = ""
    guidelines: str = ""
    report_format: str = ""
    params: dict = {}
    version: str | None = None
    visible_by_groups: list[str] = []
    origin_template_id: str | None = None
    origin_user_id: str | None = None
    origin_author_name: str | None = None
    tools: list[str] = []
    steps: list[TemplateStep] = []
    shortcut: str | None = None
    agent_knowledge: list[str] = []
    agent_skills: list[str] = []
    mcp_url: str | None = None


class TemplateCreate(BaseModel):
    user_id: str
    title: str
    template_type: TemplateType | None = None
    description: str | None = None
    prompt: str = ""
    tags: list[str] = []
    params: dict = {}
    steps: list[TemplateStep] = []
    tools: list[str] = []
    agent_knowledge: list[str] = []
    agent_skills: list[str] = []
    visible_by_groups: list[str] = []


class TemplateUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    prompt: str | None = None
    tags: list[str] | None = None
    status: TemplateStatus | None = None
    params: dict | None = None
    steps: list[TemplateStep] | None = None
    tools: list[str] | None = None
    agent_knowledge: list[str] | None = None
    agent_skills: list[str] | None = None
    visible_by_groups: list[str] | None = None
