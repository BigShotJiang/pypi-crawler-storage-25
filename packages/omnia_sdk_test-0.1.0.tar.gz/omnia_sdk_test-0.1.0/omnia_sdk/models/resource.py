from __future__ import annotations

from pydantic import BaseModel

from omnia_sdk.models.common import OmniaModel, ResourceType


class Resource(OmniaModel):
    user_id: str
    project_id: str
    filename: str
    description: str | None = None
    resource_type: ResourceType | None = None
    global_file_id: str | None = None
    is_root_resource: bool = True


class ResourceUpdate(BaseModel):
    description: str | None = None
    resource_type: ResourceType | None = None
