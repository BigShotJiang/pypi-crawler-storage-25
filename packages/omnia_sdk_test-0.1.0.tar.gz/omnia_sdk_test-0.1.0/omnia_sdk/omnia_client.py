from __future__ import annotations

import os

from omnia_sdk.client.analysis import AnalysisClient
from omnia_sdk.client.auth import AuthClient
from omnia_sdk.client.base import BaseClient
from omnia_sdk.client.messages import MessagesClient
from omnia_sdk.client.projects import ProjectsClient
from omnia_sdk.client.public import PublicClient
from omnia_sdk.client.resources import ResourcesClient
from omnia_sdk.client.templates import TemplatesClient
from omnia_sdk.client.workflows import WorkflowsClient

_ENV_URLS = {
    "prod": "https://api.omniasec.ai",
    "dev": "http://localhost:8000",
}


def _resolve_api_url() -> str:
    if url := os.getenv("OMNIA_API_URL"):
        return url.rstrip("/")
    env = os.getenv("OMNIA_ENV", "prod").lower()
    return _ENV_URLS.get(env, _ENV_URLS["prod"])


class OmniaClient:
    """
    Main entry point for the Omnia SDK.

    Usage:
        client = OmniaClient(api_key="your-key")
        me = client.auth.get_me()
        project, chat = client.projects.create_project_with_chat(me.id, "My project")
        for event in client.messages.stream_message(me.id, project.id, chat.id, "Hello"):
            print(event)
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_url: str | None = None,
        default_model: str | None = None,
        default_provider: str | None = None,
    ) -> None:
        base = BaseClient(
            api_key=api_key or os.getenv("OMNIA_API_TOKEN", ""),
            api_url=api_url or _resolve_api_url(),
            default_model=default_model or os.getenv("OMNIA_DEFAULT_MODEL", "gemini-2.5-pro"),
            default_provider=default_provider or os.getenv("OMNIA_DEFAULT_PROVIDER", "google"),
        )

        self.auth = AuthClient(base)
        self.projects = ProjectsClient(base)
        self.messages = MessagesClient(base)
        self.analysis = AnalysisClient(base)
        self.resources = ResourcesClient(base)
        self.templates = TemplatesClient(base)
        self.workflows = WorkflowsClient(base)
        self.public = PublicClient(base)
