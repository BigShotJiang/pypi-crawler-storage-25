# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-14

### Added
- `OmniaClient` as the main instanciable entry point
- `AuthClient` — get current user, agents, and user settings
- `ProjectsClient` — create, list, get, delete projects and chats
- `MessagesClient` — send messages, stream responses (SSE), launch workflows
- `ResourcesClient` — upload, list, delete project files
- `AnalysisClient` — upload files for analysis, list and retrieve analyses
- `TemplatesClient` — CRUD and fork for templates (prompts, workflows, skills, MCP...)
- `WorkflowsClient` — run built-in workflows (e.g. `FileAnalysisWorkflow`)
- `PublicClient` — unauthenticated endpoints (market intelligence, shared analyses, public templates)
- Pydantic v2 models for all API responses
- Automatic retries on `429`, `502`, `503`, `504` status codes
- SSE streaming support via `iter_sse`
- Environment-based API URL resolution (`OMNIA_ENV=dev` points to `localhost:8000`)
