"""BuildAI client — the public interface for the data product.

Usage::

    from buildai import BuildAI

    client = BuildAI(api_key="build_data_xxxx")
    client.download(hours=10, output_dir="/data/buildai/")
    client.visualize(source="/data/buildai/")
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import httpx

from buildai._http import ApiError, HttpTransport

# 8 MB streaming chunks — balances syscall overhead vs memory usage.
_CHUNK_SIZE = 8 * 1024 * 1024


class BuildAI:
    """Client for the BuildAI data product API.

    Authenticates with an API key issued at signup. All data access — allocation,
    billing, and signed URL generation — goes through the API. The SDK never
    touches GCS directly.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float | None = None,
    ) -> None:
        resolved_key = api_key or os.getenv("BUILDAI_API_KEY")
        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set BUILDAI_API_KEY. "
                "Get one at https://build.ai"
            )
        self._http = HttpTransport(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
        )

    # ── Download ───────────────────────────────────────────────────────

    def download(
        self,
        hours: int,
        output_dir: str = "./buildai-data",
        *,
        workers: int = 8,
        verify_checksum: bool = True,
    ) -> Path:
        """Download shards from the BuildAI data product.

        Allocates ``hours`` new shards (1 shard = 1 hour), downloads them to
        ``output_dir``, and returns the output directory path. Each call gets
        new shards the user has never downloaded before.

        Downloads stream to ``.part`` files and atomically rename on completion.
        Interrupted downloads resume from where they left off via HTTP Range
        requests. SHA-256 is verified after each shard.

        Increase ``workers`` to saturate faster links (try 16–32 for 10Gbps+).
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        state = _DownloadState(out)

        # 1. Allocate
        _log(f"Allocating {hours} hours of data...")
        allocation = self._http.post("/downloads", json={"hours": hours})
        download_id = allocation["download_id"]
        shard_indices = allocation["shard_indices"]
        total_cents = allocation["total_cents"]
        _log(f"  {len(shard_indices)} shards allocated (${total_cents / 100:.2f})")

        # 2. Download in paginated batches of signed URLs
        total = len(shard_indices)
        downloaded: list[int] = []
        failed: list[int] = []
        t0 = time.monotonic()
        total_bytes = 0
        offset = 0
        batch_size = 50

        progress = _Progress(total)

        while offset < total:
            batch = self._http.get(
                f"/downloads/{download_id}/shards",
                params={"offset": offset, "limit": batch_size},
            )
            shards = batch["shards"]
            if not shards:
                break

            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(
                        self._download_shard, s, out, verify_checksum, state
                    ): s
                    for s in shards
                }
                for future in as_completed(futures):
                    shard = futures[future]
                    idx = shard["shard_index"]
                    try:
                        nbytes = future.result()
                        downloaded.append(idx)
                        total_bytes += nbytes
                        progress.advance(nbytes)
                    except Exception as e:
                        failed.append(idx)
                        progress.error(idx, e)

            offset += batch_size

        # 3. Ack successful downloads
        if downloaded:
            self._http.post(
                f"/downloads/{download_id}/ack",
                json={"shard_indices": downloaded},
            )

        # 4. Summary
        elapsed = time.monotonic() - t0
        speed = total_bytes / elapsed if elapsed > 0 else 0
        progress.finish()
        _log(
            f"  Done. {len(downloaded)}/{total} shards "
            f"({_human_bytes(total_bytes)}) in {_human_time(elapsed)} "
            f"— {_human_bytes(speed)}/s"
        )
        if failed:
            _log(f"  {len(failed)} shards failed: {failed}", err=True)

        return out

    def _download_shard(
        self,
        shard: dict[str, Any],
        output_dir: Path,
        verify: bool,
        state: "_DownloadState",
    ) -> int:
        """Download a single shard to a .part file, verify, and atomically rename.

        Returns bytes downloaded (0 if skipped). Supports HTTP Range resume
        for interrupted downloads — restarts from the last byte in the .part file.
        """
        idx = shard["shard_index"]
        url = shard["url"]
        expected_sha = shard.get("checksum_sha256")
        expected_size = shard.get("size_bytes", 0)
        dest = output_dir / f"shard-{idx:06d}.tar"
        part = dest.with_suffix(".tar.part")

        # Already downloaded and verified
        if state.is_complete(idx):
            if dest.exists():
                return 0
        if dest.exists() and verify and expected_sha:
            if _sha256(dest) == expected_sha:
                state.mark_complete(idx, expected_sha)
                return 0

        # Resume from .part if it exists
        existing_bytes = part.stat().st_size if part.exists() else 0
        headers: dict[str, str] = {}
        if existing_bytes > 0 and expected_size > 0 and existing_bytes < expected_size:
            headers["Range"] = f"bytes={existing_bytes}-"

        # Stream download
        downloaded_bytes = existing_bytes
        with httpx.stream(
            "GET", url, headers=headers, timeout=600, follow_redirects=True
        ) as resp:
            # Server doesn't support Range or file changed — start over
            if resp.status_code == 200 and existing_bytes > 0:
                existing_bytes = 0
                downloaded_bytes = 0

            resp.raise_for_status()
            mode = "ab" if resp.status_code == 206 else "wb"

            with open(part, mode) as f:
                for chunk in resp.iter_bytes(chunk_size=_CHUNK_SIZE):
                    f.write(chunk)
                    downloaded_bytes += len(chunk)

        # Verify checksum
        if verify and expected_sha:
            actual = _sha256(part)
            if actual != expected_sha:
                part.unlink(missing_ok=True)
                state.mark_failed(idx)
                raise ValueError(
                    f"Checksum mismatch for shard {idx}: "
                    f"expected {expected_sha[:16]}..., got {actual[:16]}..."
                )

        # Atomic rename .part → .tar
        part.rename(dest)
        state.mark_complete(idx, expected_sha or "")
        return downloaded_bytes

    # ── Loader ─────────────────────────────────────────────────────────

    @staticmethod
    def loader(
        source: str = "./buildai-data",
        batch_size: int = 32,
        **kwargs: Any,
    ) -> Any:
        """Create a PyTorch DataLoader that streams clips from downloaded shards.

        Returns batches with ``.video`` (B, T, 3, H, W) and ``.imu`` (B, T, 6)
        as float32 tensors. Requires ``pip install buildai-data[torch]``.

        Keyword args are forwarded to the loader (shuffle, num_workers,
        clip_slice_frames).
        """
        from buildai._loader import loader as _make_loader

        return _make_loader(source, batch_size=batch_size, **kwargs)

    # ── Visualize ──────────────────────────────────────────────────────

    @staticmethod
    def visualize(source: str = "./buildai-data", port: int = 0) -> None:
        """Open a browser-based viewer for downloaded shards.

        Shows a grid of all clips across all shard tars in the source
        directory. Click a clip to watch the video with accelerometer
        and gyroscope data graphed below, time-synced.

        No data is uploaded — everything runs locally. Press Ctrl+C to stop.
        """
        from buildai._visualizer import serve

        serve(source, port=port)

    # ── Account ────────────────────────────────────────────────────────

    @property
    def account(self) -> dict[str, Any]:
        """Fetch the authenticated user's account info and usage."""
        return self._http.get("/account")

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._http.close()

    def __enter__(self) -> BuildAI:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return "BuildAI()"


# ── Download state ─────────────────────────────────────────────────────────


class _DownloadState:
    """Tracks completed shards in a JSON manifest for resume across sessions.

    Stored as ``buildai-state.json`` in the output directory. Each entry
    records the shard index, SHA-256, and completion timestamp so restarted
    downloads skip already-verified shards instantly.
    """

    def __init__(self, output_dir: Path) -> None:
        self._path = output_dir / "buildai-state.json"
        self._data: dict[str, Any] = {"completed": {}, "failed": []}
        if self._path.exists():
            try:
                self._data = json.loads(self._path.read_text())
            except (json.JSONDecodeError, OSError):
                pass

    def is_complete(self, shard_index: int) -> bool:
        return str(shard_index) in self._data.get("completed", {})

    def mark_complete(self, shard_index: int, sha256: str) -> None:
        self._data.setdefault("completed", {})[str(shard_index)] = {
            "sha256": sha256,
            "completed_at": time.time(),
        }
        self._save()

    def mark_failed(self, shard_index: int) -> None:
        failed = self._data.setdefault("failed", [])
        if shard_index not in failed:
            failed.append(shard_index)
        self._save()

    def _save(self) -> None:
        try:
            self._path.write_text(json.dumps(self._data, indent=2))
        except OSError:
            pass


# ── Progress ───────────────────────────────────────────────────────────────


class _Progress:
    """Live progress display for shard downloads.

    Uses rich if available (multi-bar with speed/ETA), falls back to a
    simple single-line progress bar on plain terminals. Suppresses output
    entirely when stdout is not a TTY (piped/redirected).
    """

    def __init__(self, total_shards: int) -> None:
        self._total = total_shards
        self._done = 0
        self._is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

    def advance(self, nbytes: int = 0) -> None:
        self._done += 1
        if self._is_tty:
            pct = self._done / self._total * 100
            bar_len = 30
            filled = int(bar_len * self._done / self._total)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(
                f"\r  [{bar}] {self._done}/{self._total} shards ({pct:.0f}%)",
                end="",
                flush=True,
            )

    def error(self, shard_index: int, exc: Exception) -> None:
        self._done += 1
        _log(f"  Error shard {shard_index}: {exc}", err=True)

    def finish(self) -> None:
        if self._is_tty:
            print()  # newline after progress bar


# ── Helpers ────────────────────────────────────────────────────────────────


def _sha256(path: Path) -> str:
    """Compute SHA-256 hex digest of a file, streaming in 64KB blocks."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _human_bytes(n: float) -> str:
    """Format byte count as human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _human_time(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _log(msg: str, *, err: bool = False) -> None:
    """Print a log message to stdout or stderr."""
    print(msg, file=sys.stderr if err else sys.stdout, flush=True)
