"""Local visualizer for downloaded BuildAI shards.

Opens a browser-based viewer showing a grid of clips from downloaded tars.
Click a clip to watch the video with IMU data graphed below, time-synced.

No external dependencies beyond numpy (already required for IMU).
Serves everything from a local HTTP server on an ephemeral port.
"""

from __future__ import annotations

import io
import json
import mimetypes
import os
import tarfile
import threading
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

import numpy as np

# ── Shard indexing ───────────────────────────────────────────────────────────


def _index_shards(source_dir: Path) -> list[dict[str, Any]]:
    """Scan tar files and build an index of clips without extracting.

    Returns a list of shard dicts, each containing clip entries with
    their byte offsets inside the tar for on-demand extraction.
    """
    shards = []
    for tar_path in sorted(source_dir.glob("shard-*.tar")):
        shard_name = tar_path.stem
        clips: dict[str, dict] = {}

        with tarfile.open(str(tar_path), "r") as tf:
            for member in tf.getmembers():
                name = member.name
                if name.endswith(".mp4"):
                    clip_num = name.replace(".mp4", "")
                    clips.setdefault(clip_num, {})["mp4"] = True
                elif name.endswith(".imu.npy"):
                    clip_num = name.replace(".imu.npy", "")
                    clips.setdefault(clip_num, {})["imu"] = True

        shard_clips = []
        for clip_num in sorted(clips.keys()):
            c = clips[clip_num]
            if c.get("mp4") and c.get("imu"):
                shard_clips.append({"id": clip_num, "shard": shard_name})

        if shard_clips:
            shards.append({
                "name": shard_name,
                "path": str(tar_path),
                "clips": shard_clips,
                "count": len(shard_clips),
            })

    return shards


def _extract_file(tar_path: str, filename: str) -> bytes | None:
    """Extract a single file from a tar archive by name."""
    try:
        with tarfile.open(tar_path, "r") as tf:
            member = tf.getmember(filename)
            f = tf.extractfile(member)
            if f:
                return f.read()
    except (KeyError, tarfile.TarError):
        pass
    return None


def _imu_to_json(npy_bytes: bytes) -> str:
    """Convert IMU numpy bytes to JSON arrays for the chart."""
    arr = np.load(io.BytesIO(npy_bytes))  # (5400, 6) float32
    # Downsample to 540 points (every 10th frame) for smooth charting
    step = 10
    downsampled = arr[::step]
    timestamps = [round(i * step / 30, 2) for i in range(len(downsampled))]

    return json.dumps({
        "timestamps": timestamps,
        "acc_x": [round(float(v), 3) for v in downsampled[:, 0]],
        "acc_y": [round(float(v), 3) for v in downsampled[:, 1]],
        "acc_z": [round(float(v), 3) for v in downsampled[:, 2]],
        "gyro_x": [round(float(v), 3) for v in downsampled[:, 3]],
        "gyro_y": [round(float(v), 3) for v in downsampled[:, 4]],
        "gyro_z": [round(float(v), 3) for v in downsampled[:, 5]],
    })


# ── HTML templates ───────────────────────────────────────────────────────────

_INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>BuildAI Data Viewer</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0a0a0a; color: #e0e0e0; }
.header { padding: 24px 32px; border-bottom: 1px solid #222; }
.header h1 { font-size: 20px; font-weight: 600; color: #fff; }
.header p { font-size: 13px; color: #888; margin-top: 4px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 12px; padding: 24px 32px; }
.clip { background: #161616; border: 1px solid #222; border-radius: 8px;
        cursor: pointer; overflow: hidden; transition: border-color 0.15s; }
.clip:hover { border-color: #555; }
.clip video { width: 100%; aspect-ratio: 16/9; object-fit: cover; background: #000; }
.clip .label { padding: 8px 12px; font-size: 12px; color: #999; }
.clip .label span { color: #ccc; }

/* Viewer overlay */
.viewer { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
          background: #0a0a0aee; z-index: 100; overflow-y: auto; }
.viewer.active { display: flex; flex-direction: column; align-items: center;
                 padding: 32px; }
.viewer .close { position: fixed; top: 16px; right: 24px; font-size: 28px;
                 color: #888; cursor: pointer; z-index: 101; }
.viewer .close:hover { color: #fff; }
.viewer video { max-width: 960px; width: 100%; border-radius: 8px;
                background: #000; }
.viewer .meta { font-size: 13px; color: #888; margin: 12px 0; }
.chart-container { max-width: 960px; width: 100%; margin-top: 16px; }
.chart-container canvas { width: 100%; height: 180px; border-radius: 6px;
                          background: #111; }
.chart-label { font-size: 11px; color: #666; margin: 8px 0 4px; }
</style>
</head>
<body>
<div class="header">
  <h1>BuildAI Data Viewer</h1>
  <p id="summary"></p>
</div>
<div class="grid" id="grid"></div>

<div class="viewer" id="viewer">
  <span class="close" onclick="closeViewer()">&times;</span>
  <video id="vplayer" controls></video>
  <div class="meta" id="vmeta"></div>
  <div class="chart-container">
    <div class="chart-label">Accelerometer (m/s&sup2;)</div>
    <canvas id="accChart"></canvas>
    <div class="chart-label">Gyroscope (rad/s)</div>
    <canvas id="gyroChart"></canvas>
  </div>
</div>

<script>
let shards = __SHARD_DATA__;
let summary = document.getElementById('summary');
let totalClips = shards.reduce((s, sh) => s + sh.clips.length, 0);
summary.textContent = shards.length + ' shards, ' + totalClips + ' clips';

let grid = document.getElementById('grid');
shards.forEach(shard => {
  shard.clips.forEach(clip => {
    let div = document.createElement('div');
    div.className = 'clip';
    div.innerHTML = '<video src="/video/' + shard.name + '/' + clip.id +
      '" preload="metadata" muted></video>' +
      '<div class="label">Clip <span>' + clip.id + '</span></div>';
    div.onclick = () => openViewer(shard.name, clip.id);
    grid.appendChild(div);
  });
});

function openViewer(shard, clipId) {
  document.getElementById('viewer').classList.add('active');
  let vp = document.getElementById('vplayer');
  vp.src = '/video/' + shard + '/' + clipId;
  vp.play();
  document.getElementById('vmeta').textContent =
    'Clip ' + clipId + ' — 3 min, H.265, 1080p, 30fps';

  fetch('/imu/' + shard + '/' + clipId)
    .then(r => r.json())
    .then(data => {
      drawChart('accChart', data.timestamps,
        [{d: data.acc_x, c: '#4fc3f7'}, {d: data.acc_y, c: '#81c784'},
         {d: data.acc_z, c: '#ffb74d'}]);
      drawChart('gyroChart', data.timestamps,
        [{d: data.gyro_x, c: '#ce93d8'}, {d: data.gyro_y, c: '#f06292'},
         {d: data.gyro_z, c: '#fff176'}]);
    });

  vp.ontimeupdate = () => {
    // Sync indicator could go here
  };
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('active');
  document.getElementById('vplayer').pause();
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeViewer();
});

function drawChart(canvasId, timestamps, series) {
  let canvas = document.getElementById(canvasId);
  let ctx = canvas.getContext('2d');
  let w = canvas.width = canvas.offsetWidth * 2;
  let h = canvas.height = canvas.offsetHeight * 2;
  ctx.scale(2, 2);
  let cw = w / 2, ch = h / 2;
  ctx.clearRect(0, 0, cw, ch);

  // Find range
  let allVals = series.flatMap(s => s.d);
  let minV = Math.min(...allVals), maxV = Math.max(...allVals);
  let range = maxV - minV || 1;
  let pad = range * 0.1;
  minV -= pad; maxV += pad; range = maxV - minV;

  // Grid lines
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= 4; i++) {
    let y = ch - (i / 4) * ch;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(cw, y); ctx.stroke();
  }

  // Data
  series.forEach(s => {
    ctx.strokeStyle = s.c;
    ctx.lineWidth = 1;
    ctx.beginPath();
    s.d.forEach((v, i) => {
      let x = (i / (s.d.length - 1)) * cw;
      let y = ch - ((v - minV) / range) * ch;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
  });
}
</script>
</body>
</html>"""


# ── HTTP Server ──────────────────────────────────────────────────────────────


def _make_handler(source_dir: Path, shards: list[dict]):
    """Create a request handler closure over the shard index."""

    # Build lookup: shard_name → tar_path
    shard_paths = {s["name"]: s["path"] for s in shards}
    # Strip internal fields before sending to browser
    client_shards = [
        {"name": s["name"], "clips": s["clips"], "count": s["count"]}
        for s in shards
    ]

    class Handler(SimpleHTTPRequestHandler):
        """Serves the viewer UI, video files, and IMU data from tars."""

        def log_message(self, fmt, *args):
            pass  # suppress request logs

        def do_GET(self):
            path = self.path

            if path == "/" or path == "/index.html":
                html = _INDEX_HTML.replace(
                    "__SHARD_DATA__", json.dumps(client_shards)
                )
                self._respond(200, "text/html", html.encode())

            elif path.startswith("/video/"):
                # /video/{shard_name}/{clip_id}
                parts = path.split("/")
                if len(parts) >= 4:
                    shard_name = parts[2]
                    clip_id = parts[3]
                    tar_path = shard_paths.get(shard_name)
                    if tar_path:
                        data = _extract_file(tar_path, f"{clip_id}.mp4")
                        if data:
                            self._respond(200, "video/mp4", data)
                            return
                self._respond(404, "text/plain", b"Not found")

            elif path.startswith("/imu/"):
                # /imu/{shard_name}/{clip_id}
                parts = path.split("/")
                if len(parts) >= 4:
                    shard_name = parts[2]
                    clip_id = parts[3]
                    tar_path = shard_paths.get(shard_name)
                    if tar_path:
                        data = _extract_file(tar_path, f"{clip_id}.imu.npy")
                        if data:
                            imu_json = _imu_to_json(data)
                            self._respond(
                                200, "application/json", imu_json.encode()
                            )
                            return
                self._respond(404, "text/plain", b"Not found")

            else:
                self._respond(404, "text/plain", b"Not found")

        def _respond(self, code: int, content_type: str, body: bytes):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            if content_type == "video/mp4":
                self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            self.wfile.write(body)

    return Handler


def serve(source_dir: str | Path, port: int = 0) -> None:
    """Start the visualizer server and open the browser.

    Scans all shard-*.tar files in source_dir, builds a clip index,
    and serves a local web UI. Videos and IMU data are extracted
    on-demand from tars — nothing is written to disk.

    Port 0 picks an available ephemeral port.
    """
    source = Path(source_dir)
    if not source.is_dir():
        raise FileNotFoundError(f"Source directory not found: {source}")

    print(f"Scanning shards in {source}...")
    shards = _index_shards(source)

    if not shards:
        print("No shard-*.tar files found.")
        return

    total_clips = sum(s["count"] for s in shards)
    print(f"Found {len(shards)} shards, {total_clips} clips")

    handler = _make_handler(source, shards)
    server = HTTPServer(("127.0.0.1", port), handler)
    actual_port = server.server_address[1]

    url = f"http://127.0.0.1:{actual_port}"
    print(f"Viewer running at {url}")
    print("Press Ctrl+C to stop\n")

    webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
