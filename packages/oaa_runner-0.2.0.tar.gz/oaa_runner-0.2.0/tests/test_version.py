from oaa.run import main


def test_version_flag_short(capsys):
    main(['-v'])
    captured = capsys.readouterr()
    assert captured.out.strip() != ''


def test_version_flag_long(capsys):
    main(['--version'])
    captured = capsys.readouterr()
    assert captured.out.strip() != ''
