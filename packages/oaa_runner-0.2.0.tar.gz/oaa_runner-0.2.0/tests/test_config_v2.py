from oaa.run import main
from pathlib import Path
from oaa.settings import Config
from oaa.settings_utils import SourceType
import pytest
import os


requires_db = pytest.mark.skipif(
    not os.environ.get("DB_PASSWORD"),
    reason="requires DB_PASSWORD environment variable",
)


LOG_LEVELS = ["DEBUG", "INFO", "TRACE", "ERROR"]


def test_run_help(capsys):

    main(cli_args=["custom_app", "--help"])

    captured = capsys.readouterr()

    output_expected = [
        "oaa",
        "--help",
        "COMMAND is one of the following:",
    ]

    for output in output_expected:
        # print(captured.out)
        assert output in captured.out

    # print('-' * 20)


@requires_db
def test_run_with_config(capsys):

    from pathlib import Path
    import os

    BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))

    main(
        cli_args=[
            "custom_app",
            "show_config",
            "--config-file",
            str(BASE_DIR / "configs" / "config-v2.yaml"),
            "--config-file-yaml",
            "true",
        ]
    )

    captured = capsys.readouterr()

    output_expected = [
        '"log_level"',
        "config_file",
    ]

    for output in output_expected:
        # print(captured.out)
        assert output in captured.out

    # print('-' * 20)


@pytest.mark.parametrize("log_level", LOG_LEVELS)
def test_new_singleton_config(log_level, config):
    os.environ["log_level"] = log_level
    assert os.getenv("log_level") == log_level
    config.update()
    assert Config.get("log_level") == log_level
    assert config.get("log_level") == log_level


@pytest.mark.parametrize("log_level", LOG_LEVELS)
def test_new_singleton_config_2(log_level, config):
    os.environ["log_level"] = log_level
    assert os.getenv("log_level") == log_level
    config.update()
    assert Config.get("log_level") == log_level
    assert config.LOG_LEVEL == log_level


@requires_db
def test_load_from_config_file(config):
    config.update(config_file="./tests/configs/config-v2.yaml")

    assert config.LOG_LEVEL == "ERROR"

    should_be = Path(os.path.dirname(__file__)) / "data/resources_mapping.csv"
    assert config.sources["apps"].mapping_filepath == should_be


@requires_db
def test_mod_folder(config):
    """
    We can write custom functions for manipulating data as needed.

    A mod function is created by decorating a function with the @transformer
    decorator found in oaa.utils

    The decorator takes two parameters:
    :table: the stream of data
    :config: the configuration object

    The mod function must return a streaming object
    """
    from oaa.settings_v2 import ConfigV2

    config.update(config_file="./tests/configs/config-v2.yaml", config_format="yaml")
    assert config.version == "v2"
    assert isinstance(config._CONFIG, ConfigV2)
    assert config.MODULE_DIRECTORY
    assert config.module_directory
    mod_folder_should_be = Path(os.path.dirname(__file__)) / "modules"

    assert config.module_directory == mod_folder_should_be


# ============================================================================
# Tests for ConfigV2.post_update() model_validator
# ============================================================================


def _make_post_update_config(sources: dict):
    """Build a minimal ConfigV2 with the given sources dict.

    Uses source_type=VEZA_API which requires no filepath — avoids the
    destination=None bypass and keeps sources realistic.
    """
    from oaa.config import ConfigV2
    return ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'sources': sources,
    })


def test_post_update_sets_source_names():
    """source_name is populated from the config key for each source."""
    config = _make_post_update_config({
        'employees': {'source_type': 'VEZA_API'},
        'roles': {'source_type': 'VEZA_API'},
    })

    assert config.sources['employees'].source_name == 'employees'
    assert config.sources['roles'].source_name == 'roles'


def test_post_update_sets_is_csv_push_when_present():
    """is_csv_push is True when at least one source has source_type=csv_push."""
    config = _make_post_update_config({
        'employees': {'source_type': 'VEZA_API'},
        'org_chart': {'source_type': 'CSV_PUSH'},
    })

    assert config.is_csv_push is True


def test_post_update_keeps_is_csv_push_false():
    """is_csv_push stays False when no csv_push sources exist."""
    config = _make_post_update_config({
        'employees': {'source_type': 'VEZA_API'},
        'roles': {'source_type': 'VEZA_API'},
    })

    assert config.is_csv_push is False


# ============================================================================
# Tests for issue #54: quoted VEZA_URL / VEZA_API_KEY values
# ============================================================================

def _make_veza_config(veza_url=None, veza_api_key=None):
    from oaa.config import ConfigV2
    data = {'version': 'v2', 'runner_type': 'HRIS'}
    if veza_url is not None:
        data['VEZA_URL'] = veza_url
    if veza_api_key is not None:
        data['VEZA_API_KEY'] = veza_api_key
    return ConfigV2.model_validate(data)


@pytest.mark.parametrize('raw_url', [
    '"https://example.vezacloud.com"',
    "'https://example.vezacloud.com'",
    'https://example.vezacloud.com',
])
def test_veza_url_quoted_values_are_accepted(raw_url):
    """VEZA_URL with surrounding quotes should parse correctly."""
    cfg = _make_veza_config(veza_url=raw_url)
    assert cfg.VEZA_URL is not None
    assert 'example.vezacloud.com' in str(cfg.VEZA_URL)


def test_veza_api_key_quoted_value_is_stripped():
    """VEZA_API_KEY with surrounding quotes should have quotes stripped."""
    cfg = _make_veza_config(veza_api_key='"my-secret-key"')
    assert cfg.VEZA_API_KEY == 'my-secret-key'


# ============================================================================
# Tests for issue #53: permission_to_veza_map error messages
# ============================================================================

def test_permission_to_veza_map_new_format_accepted():
    """Object format (the correct format) is accepted."""
    from oaa.config import ConfigV2
    cfg = ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'permission_to_veza_map': {
            'read': {'permissions': ['DataRead']},
        },
    })
    assert cfg.permission_to_veza_map['read'].permissions


def test_permission_to_veza_map_old_list_format_raises_clear_error():
    """Old list format raises a ValueError with migration instructions."""
    from oaa.config import ConfigV2
    with pytest.raises(Exception) as exc_info:
        ConfigV2.model_validate({
            'version': 'v2',
            'runner_type': 'HRIS',
            'permission_to_veza_map': {'read': ['DataRead']},
        })
    assert 'permission_to_veza_map' in str(exc_info.value)
    assert 'permissions' in str(exc_info.value)


# ============================================================================
# Tests for issue #60: datasource field on App and Source models
# ============================================================================

def test_app_datasource_field_is_parsed():
    """App model accepts and stores a datasource field."""
    from oaa.config import ConfigV2
    cfg = ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'app': {'name': 'MyApp', 'datasource': 'My Custom Datasource'},
    })
    assert cfg.app.datasource == 'My Custom Datasource'


def test_app_datasource_defaults_to_none():
    """App.datasource defaults to None when not specified."""
    from oaa.config import ConfigV2
    cfg = ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'app': {'name': 'MyApp'},
    })
    assert cfg.app.datasource is None


def test_source_datasource_field_is_parsed():
    """Source model accepts and stores a datasource field."""
    from oaa.config import ConfigV2
    cfg = ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'sources': {
            'users': {'source_type': 'VEZA_API', 'datasource': 'Users Datasource'},
        },
    })
    assert cfg.sources['users'].datasource == 'Users Datasource'


def test_source_datasource_defaults_to_none():
    """Source.datasource defaults to None when not specified."""
    from oaa.config import ConfigV2
    cfg = ConfigV2.model_validate({
        'version': 'v2',
        'runner_type': 'HRIS',
        'sources': {'users': {'source_type': 'VEZA_API'}},
    })
    assert cfg.sources['users'].datasource is None
