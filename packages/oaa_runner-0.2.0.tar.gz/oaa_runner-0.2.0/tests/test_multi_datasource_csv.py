import os
import pytest
from pathlib import Path
from oaa.app_runners.custom_app import CustomAppRunner

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))
CONFIG_FILE = BASE_DIR / 'configs' / 'config-v2-multi-datasource-csv.yaml'


@pytest.fixture
def multi_ds_config(config):
    config.update(
        config_file=CONFIG_FILE,
        config_format='yaml',
        config_version='v2',
    )
    yield config
    config.reset()


# ── datasource field parsing ─────────────────────────────────────────

def test_admin_users_datasource(multi_ds_config):
    assert multi_ds_config.sources['admin_users'].datasource == 'admins'


def test_non_admin_users_datasource(multi_ds_config):
    assert multi_ds_config.sources['non_admin_users'].datasource == 'non-admins'


def test_base_users_has_no_datasource(multi_ds_config):
    assert multi_ds_config.sources['all_users'].datasource is None


def test_admin_groups_datasource(multi_ds_config):
    assert multi_ds_config.sources['admin_groups'].datasource == 'admins'


def test_non_admin_groups_datasource(multi_ds_config):
    assert multi_ds_config.sources['non_admin_groups'].datasource == 'non-admins'


def test_base_groups_has_no_datasource(multi_ds_config):
    assert multi_ds_config.sources['all_groups'].datasource is None


def test_admin_roles_datasource(multi_ds_config):
    assert multi_ds_config.sources['admin_roles'].datasource == 'admins'


def test_non_admin_roles_datasource(multi_ds_config):
    assert multi_ds_config.sources['non_admin_roles'].datasource == 'non-admins'


def test_base_roles_has_no_datasource(multi_ds_config):
    assert multi_ds_config.sources['all_roles'].datasource is None


# ── _get_effective_datasource ────────────────────────────────────────

def test_effective_datasource_admin_users(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['admin_users']
    ) == 'admins'


def test_effective_datasource_non_admin_users(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['non_admin_users']
    ) == 'non-admins'


def test_effective_datasource_admin_groups(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['admin_groups']
    ) == 'admins'


def test_effective_datasource_non_admin_groups(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['non_admin_groups']
    ) == 'non-admins'


def test_effective_datasource_admin_roles(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['admin_roles']
    ) == 'admins'


def test_effective_datasource_non_admin_roles(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['non_admin_roles']
    ) == 'non-admins'


def test_effective_datasource_base_uses_default(multi_ds_config):
    runner = CustomAppRunner(dry_run=True)
    assert runner._get_effective_datasource(
        multi_ds_config.sources['all_users']
    ) == 'My App Datasource'
