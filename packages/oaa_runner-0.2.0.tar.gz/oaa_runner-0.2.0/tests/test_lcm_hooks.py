import json
import sys
import io
import pytest
from oaa.app_runners.custom_app import CustomAppRunner
from oaa.hooks.decorators import HOOK_EVENTS, OAAHookEvent
import logging
logging.basicConfig(log_level=logging.debug)
logger = logging.getLogger(__name__)


@pytest.fixture
def _config(config):
    HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results'] = []
    config.update(config_file='./tests/configs/config-lcm-sources.yaml')

    yield config
    config.reset()


# If hooks are defined in a logic module, then we should be able to find them
# in oaa.app_runners.decorators.HOOK_EVENTS


def test_lcm_create_user_in_events(_config):
    assert _config.sources
    import lcm_test
    assert HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['hooks']
    assert lcm_test.hook_create_user in HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['hooks']
    assert HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results'] == []


def test_hooks_run(_config, monkeypatch, capsys):
    """lcm_create_user reads payload from stdin and emits JSON to stdout."""
    assert _config.sources
    runner = CustomAppRunner()

    payload = json.dumps({'user': {'username': 'kevin'}, 'action': None})
    monkeypatch.setattr('sys.stdin', io.StringIO(payload))

    runner.lcm_create_user()

    assert ['kevin'] == HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results']

    captured = capsys.readouterr()
    # The hook itself prints a debug line before the JSON result line;
    # use the last non-empty line which is always the JSON output.
    last_line = [l for l in captured.out.splitlines() if l.strip()][-1]
    output = json.loads(last_line)
    assert output['success'] is True
    assert output['results'] == ['kevin']


def test_lcm_modify_user_stdin(_config, monkeypatch, capsys):
    """lcm_modify_user reads payload from stdin and emits JSON to stdout."""
    assert _config.sources
    runner = CustomAppRunner()

    payload = json.dumps({
        'user': {'email': 'alice@example.com'},
        'action': {'type': 'deprovision'},
    })
    monkeypatch.setattr('sys.stdin', io.StringIO(payload))

    runner.lcm_modify_user()

    captured = capsys.readouterr()
    output = json.loads(captured.out.strip())
    assert output['success'] is True


def test_lcm_get_metadata_dispatches_correct_event(_config, capsys):
    """lcm_get_metadata fires LCM_GET_METADATA (not LCM_MODIFY_USER) and
    prints the result dict as JSON to stdout."""
    # Reset state for this event so prior test runs don't pollute results
    HOOK_EVENTS[OAAHookEvent.LCM_GET_METADATA]['hooks'] = []
    HOOK_EVENTS[OAAHookEvent.LCM_GET_METADATA]['results'] = []

    assert _config.sources
    runner = CustomAppRunner()

    # Register a LCM_GET_METADATA hook for this test
    from oaa.hooks.decorators import hook

    @hook(event=OAAHookEvent.LCM_GET_METADATA)
    def _get_meta(**kwargs):
        return {
            'user_type': 'OAA.TestApp.LocalUser',
            'unique_id_attribute': 'email',
        }

    meta = runner.lcm_get_metadata()

    captured = capsys.readouterr()
    stdout_data = json.loads(captured.out.strip())

    assert stdout_data['user_type'] == 'OAA.TestApp.LocalUser'
    assert stdout_data['unique_id_attribute'] == 'email'
    assert meta == stdout_data


def test_lcm_get_metadata_no_hooks(_config, capsys):
    """lcm_get_metadata with no registered hooks prints an empty JSON object."""
    # Clear any registered LCM_GET_METADATA hooks
    HOOK_EVENTS[OAAHookEvent.LCM_GET_METADATA]['hooks'] = []
    HOOK_EVENTS[OAAHookEvent.LCM_GET_METADATA]['results'] = []

    runner = CustomAppRunner()
    meta = runner.lcm_get_metadata()

    captured = capsys.readouterr()
    assert json.loads(captured.out.strip()) == {}
    assert meta == {}


def test_lcm_write_back_email(_config, monkeypatch, capsys):
    """lcm_write_back_email reads entity_id/email from stdin and emits
    {"success": true/false} to stdout based on hook return value."""
    from oaa.hooks.decorators import hook

    HOOK_EVENTS[OAAHookEvent.LCM_WRITE_BACK_EMAIL]['hooks'] = []
    HOOK_EVENTS[OAAHookEvent.LCM_WRITE_BACK_EMAIL]['results'] = []

    # Register a write-back hook that returns True
    @hook(event=OAAHookEvent.LCM_WRITE_BACK_EMAIL)
    def _write_back(entity_id=None, email=None, attributes=None, **kwargs):
        return True

    assert _config.sources
    runner = CustomAppRunner()

    payload = json.dumps({
        'entity_id': 'emp-001',
        'email': 'alice.new@example.com',
        'attributes': {'first_name': 'Alice'},
    })
    monkeypatch.setattr('sys.stdin', io.StringIO(payload))

    result = runner.lcm_write_back_email()

    captured = capsys.readouterr()
    output = json.loads(captured.out.strip())
    assert output['success'] is True
    assert result is True


def test_lcm_write_back_email_hook_returns_false(_config, monkeypatch, capsys):
    """lcm_write_back_email emits {"success": false} when hook returns False."""
    from oaa.hooks.decorators import hook, HOOK_EVENTS, OAAHookEvent

    HOOK_EVENTS[OAAHookEvent.LCM_WRITE_BACK_EMAIL]['hooks'] = []
    HOOK_EVENTS[OAAHookEvent.LCM_WRITE_BACK_EMAIL]['results'] = []

    @hook(event=OAAHookEvent.LCM_WRITE_BACK_EMAIL)
    def _write_back_fail(entity_id=None, email=None, attributes=None, **kwargs):
        return False

    runner = CustomAppRunner()

    payload = json.dumps({
        'entity_id': 'emp-002',
        'email': 'bob.new@example.com',
    })
    monkeypatch.setattr('sys.stdin', io.StringIO(payload))

    result = runner.lcm_write_back_email()

    captured = capsys.readouterr()
    output = json.loads(captured.out.strip())
    assert output['success'] is False
    assert result is False
