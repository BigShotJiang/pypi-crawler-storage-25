import json
import os
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch, call
from oaa.app_runners.custom_app import CustomAppRunner

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


@pytest.fixture
def api_config(config):
    config.update(
        config_file=BASE_DIR / 'configs' / 'config-v2-2.yaml',
        config_format='yaml',
        config_version='v2',
    )
    yield config
    config.reset()


@pytest.fixture
def no_push_runner(api_config):
    runner = CustomAppRunner(no_push=True, save_json=False)
    yield runner


@pytest.fixture
def no_push_save_json_runner(api_config):
    runner = CustomAppRunner(no_push=True, save_json=True)
    yield runner


def test_no_push_does_not_call_get_oaa_client(no_push_runner, tmp_path, monkeypatch):
    '''no_push=True must never call get_oaa_client, even without Veza credentials.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client') as mock_get_client:
        no_push_runner.run()

    mock_get_client.assert_not_called()


def test_no_push_with_save_json_writes_file(no_push_save_json_runner, tmp_path, monkeypatch):
    '''no_push=True + save_json=True should write JSON to disk without calling get_oaa_client.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client') as mock_get_client:
        no_push_save_json_runner.run()

    mock_get_client.assert_not_called()

    json_files = list(tmp_path.glob('*.json'))
    assert len(json_files) == 1, 'Expected exactly one JSON file to be written'

    payload = json.loads(json_files[0].read_text())
    assert 'applications' in payload
    assert 'permissions' in payload


def test_no_push_with_save_json_filename_contains_datasource(no_push_save_json_runner, tmp_path, monkeypatch):
    '''The saved filename should include the datasource name.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        no_push_save_json_runner.run()

    json_files = list(tmp_path.glob('*.json'))
    assert len(json_files) == 1
    assert no_push_save_json_runner._datasource_name in json_files[0].name


def test_no_push_without_save_json_writes_no_file(no_push_runner, tmp_path, monkeypatch):
    '''no_push=True + save_json=False should not write any JSON file.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        no_push_runner.run()

    json_files = list(tmp_path.glob('*.json'))
    assert len(json_files) == 0, 'Expected no JSON files to be written'


def test_no_push_provider_object_is_created(no_push_runner, tmp_path, monkeypatch):
    '''no_push=True should still create the in-memory provider object so transforms work.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        no_push_runner.run()

    assert no_push_runner._provider_object is not None


def test_no_push_false_uses_veza_client(api_config, tmp_path, monkeypatch):
    '''no_push=False (default) should still call get_oaa_client as normal.'''
    monkeypatch.chdir(tmp_path)

    mock_veza = MagicMock()
    mock_veza.get_provider.return_value = None
    mock_veza.create_provider.return_value = {'id': 'test-provider-id', 'name': 'test'}
    mock_veza.get_data_source.return_value = None
    mock_veza.create_datasource.return_value = {'id': 'test-ds-id', 'name': 'test-ds'}
    mock_veza.push_application.return_value = {'warnings': []}

    runner = CustomAppRunner(no_push=False, save_json=False)

    with patch('oaa.oaa_utils.get_oaa_client', return_value=mock_veza) as mock_get_client:
        runner.run()

    assert mock_get_client.called, 'get_oaa_client should be called when no_push=False'
    mock_veza.push_application.assert_called_once()
