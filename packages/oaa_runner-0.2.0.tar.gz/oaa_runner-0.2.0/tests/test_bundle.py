"""Tests for the `oaa custom_app bundle` command (#76)."""
import base64
import subprocess
import sys
import zipfile
import json
import io
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from oaa.app_runners.custom_app import CustomAppRunner


@pytest.fixture
def integration_dir(tmp_path):
    """A minimal integration directory without a requirements.txt."""
    (tmp_path / 'modules').mkdir()
    (tmp_path / 'config.yaml').write_text('version: v2\n')
    return tmp_path


@pytest.fixture
def integration_dir_with_requirements(tmp_path):
    """An integration directory with a requirements.txt."""
    (tmp_path / 'modules').mkdir()
    (tmp_path / 'config.yaml').write_text('version: v2\n')
    (tmp_path / 'requirements.txt').write_text('humanize\n')
    return tmp_path


def test_bundle_no_requirements(integration_dir, capsys):
    """bundle() with no requirements.txt skips install and passes validation."""
    runner = CustomAppRunner.__new__(CustomAppRunner)
    runner.bundle(integration_dir=str(integration_dir))

    captured = capsys.readouterr()
    assert 'No requirements.txt found' in captured.out
    assert 'validation passed' in captured.out


def test_bundle_nonexistent_dir(capsys):
    """bundle() exits non-zero when the integration directory does not exist."""
    runner = CustomAppRunner.__new__(CustomAppRunner)
    with pytest.raises(SystemExit) as exc_info:
        runner.bundle(integration_dir='/does/not/exist/at/all')
    assert exc_info.value.code != 0


def test_bundle_detects_compiled_extension(integration_dir, capsys):
    """bundle() exits non-zero and names the offending file when a .so is found."""
    # Place a fake compiled extension inside modules/
    so_file = integration_dir / 'modules' / '_greenlet.cpython-312-linux-x86_64.so'
    so_file.write_bytes(b'\x7fELF')

    runner = CustomAppRunner.__new__(CustomAppRunner)
    with pytest.raises(SystemExit) as exc_info:
        runner.bundle(integration_dir=str(integration_dir))

    assert exc_info.value.code != 0
    captured = capsys.readouterr()
    assert 'Compiled extension' in captured.out
    assert '_greenlet.cpython-312-linux-x86_64.so' in captured.out


def test_bundle_detects_pyd_extension(integration_dir, capsys):
    """bundle() exits non-zero when a .pyd file is found (Windows extension)."""
    pyd_file = integration_dir / 'modules' / '_foo.pyd'
    pyd_file.write_bytes(b'MZ')

    runner = CustomAppRunner.__new__(CustomAppRunner)
    with pytest.raises(SystemExit) as exc_info:
        runner.bundle(integration_dir=str(integration_dir))

    assert exc_info.value.code != 0
    captured = capsys.readouterr()
    assert '_foo.pyd' in captured.out


def test_bundle_zip_flag(integration_dir, capsys):
    """bundle(zip=True) prints base64-encoded ZIP to stdout."""
    # Add a dummy hook file so the ZIP is non-trivial
    (integration_dir / 'modules' / 'my_hooks.py').write_text(
        'def fetch(**kwargs): pass\n'
    )

    runner = CustomAppRunner.__new__(CustomAppRunner)
    runner.bundle(integration_dir=str(integration_dir), zip=True)

    captured = capsys.readouterr()
    # stdout contains diagnostic messages followed by the base64 ZIP on the
    # last line; extract just the last non-empty line.
    b64_output = [l for l in captured.out.splitlines() if l.strip()][-1]
    zip_bytes = base64.b64decode(b64_output)

    assert zip_bytes[:2] == b'PK', 'Output should be a valid ZIP (PK magic bytes)'

    # The ZIP should contain config.yaml and the hook file
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        names = zf.namelist()

    assert any('config.yaml' in n for n in names)
    assert any('my_hooks.py' in n for n in names)


def test_bundle_zip_excludes_pycache(integration_dir, capsys):
    """bundle(zip=True) must not include __pycache__ or .pyc files."""
    modules = integration_dir / 'modules'
    pycache = modules / '__pycache__'
    pycache.mkdir()
    (pycache / 'my_hooks.cpython-312.pyc').write_bytes(b'\x00')
    (modules / 'my_hooks.py').write_text('pass\n')

    runner = CustomAppRunner.__new__(CustomAppRunner)
    runner.bundle(integration_dir=str(integration_dir), zip=True)

    captured = capsys.readouterr()
    b64_output = [l for l in captured.out.splitlines() if l.strip()][-1]
    zip_bytes = base64.b64decode(b64_output)

    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        names = zf.namelist()

    assert not any('__pycache__' in n for n in names)
    assert not any('.pyc' in n for n in names)


def test_bundle_pip_install_called(integration_dir_with_requirements, capsys):
    """bundle() invokes pip install with the correct arguments when
    requirements.txt is present."""
    runner = CustomAppRunner.__new__(CustomAppRunner)

    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = 'Successfully installed humanize-4.9.0'
    mock_result.stderr = ''

    with patch('subprocess.run', return_value=mock_result) as mock_run:
        runner.bundle(integration_dir=str(integration_dir_with_requirements))

    call_args = mock_run.call_args[0][0]  # first positional arg is the command list
    assert call_args[2] == 'pip'
    assert '--no-deps' in call_args
    assert '--target' in call_args
    assert '-r' in call_args

    captured = capsys.readouterr()
    assert 'Successfully installed' in captured.out
    assert 'validation passed' in captured.out


def test_bundle_pip_install_failure(integration_dir_with_requirements, capsys):
    """bundle() exits non-zero when pip install returns a non-zero exit code."""
    runner = CustomAppRunner.__new__(CustomAppRunner)

    mock_result = MagicMock()
    mock_result.returncode = 1
    mock_result.stdout = ''
    mock_result.stderr = 'ERROR: Could not find a version that satisfies...'

    with patch('subprocess.run', return_value=mock_result):
        with pytest.raises(SystemExit) as exc_info:
            runner.bundle(integration_dir=str(integration_dir_with_requirements))

    assert exc_info.value.code != 0
    captured = capsys.readouterr()
    assert 'pip install failed' in captured.out
