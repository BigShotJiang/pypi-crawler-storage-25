import pytest
from oaa.hooks.mock_responses import (
    mock_response,
    get_sideeffect,
    OAAMockException,
    MOCK_RESPONSES,
    current_request_url,
)


@pytest.fixture(autouse=True)
def clear_registry():
    """Reset MOCK_RESPONSES between every test."""
    MOCK_RESPONSES.clear()
    yield
    MOCK_RESPONSES.clear()


# ---------------------------------------------------------------------------
# Req 1 — existing path-only behavior is preserved
# ---------------------------------------------------------------------------

def test_path_only_registration_matches_bare_path():
    @mock_response(path='/api/users')
    def handler():
        return {'users': []}

    res = get_sideeffect('/api/users')
    assert res.json() == {'users': []}


def test_path_only_registration_matches_full_url():
    @mock_response(path='/api/users')
    def handler():
        return {'users': []}

    res = get_sideeffect('https://host/api/users')
    assert res.json() == {'users': []}


def test_path_only_registration_matches_when_caller_adds_query_params():
    """Path-only mocks must still fire when the caller adds query params."""
    @mock_response(path='/api/users')
    def handler():
        return {'users': []}

    res = get_sideeffect('https://host/api/users?page=2')
    assert res.json() == {'users': []}


# ---------------------------------------------------------------------------
# Req 1 — query-param-aware matching
# ---------------------------------------------------------------------------

def test_query_param_registration_matches_exact_path_and_query():
    @mock_response(path='/api/users?role=admin')
    def handler():
        return {'role': 'admin'}

    res = get_sideeffect('https://host/api/users?role=admin')
    assert res.json() == {'role': 'admin'}


def test_query_param_registration_does_not_match_different_query():
    @mock_response(path='/api/users?role=admin')
    def handler():
        return {'role': 'admin'}

    with pytest.raises(OAAMockException):
        get_sideeffect('https://host/api/users?role=viewer')


def test_query_param_registration_does_not_match_missing_query():
    @mock_response(path='/api/users?role=admin')
    def handler():
        return {'role': 'admin'}

    with pytest.raises(OAAMockException):
        get_sideeffect('https://host/api/users')


def test_path_and_query_mock_preferred_over_path_only():
    """When both are registered, the more specific path+query wins."""
    @mock_response(path='/api/users')
    def base():
        return {'source': 'path-only'}

    @mock_response(path='/api/users?role=admin')
    def specific():
        return {'source': 'path-and-query'}

    res = get_sideeffect('https://host/api/users?role=admin')
    assert res.json()['source'] == 'path-and-query'


def test_path_only_mock_used_when_no_query_specific_mock():
    @mock_response(path='/api/users')
    def base():
        return {'source': 'path-only'}

    @mock_response(path='/api/users?role=admin')
    def specific():
        return {'source': 'path-and-query'}

    res = get_sideeffect('https://host/api/users?role=viewer')
    assert res.json()['source'] == 'path-only'


# ---------------------------------------------------------------------------
# Req 2 — wildcard matching (fnmatch)
# ---------------------------------------------------------------------------

def test_wildcard_matches_single_path_segment():
    @mock_response(path='/report/*')
    def handler():
        return {'ok': True}

    res = get_sideeffect('https://host/report/EntityConfiguration')
    assert res.json() == {'ok': True}


def test_wildcard_matches_any_value_in_segment():
    @mock_response(path='/v7/users/*')
    def handler():
        return {'found': True}

    res = get_sideeffect('https://host/v7/users/42')
    assert res.json() == {'found': True}


def test_wildcard_does_not_cross_path_separator():
    """fnmatch * does not match /."""
    @mock_response(path='/report/*')
    def handler():
        return {'ok': True}

    with pytest.raises(OAAMockException):
        get_sideeffect('https://host/report/sub/deep')


def test_exact_match_preferred_over_wildcard():
    @mock_response(path='/report/exact')
    def exact():
        return {'source': 'exact'}

    @mock_response(path='/report/*')
    def wildcard():
        return {'source': 'wildcard'}

    res = get_sideeffect('https://host/report/exact')
    assert res.json()['source'] == 'exact'


# ---------------------------------------------------------------------------
# Req 2 — regex matching (keys wrapped in /pattern/)
# ---------------------------------------------------------------------------

def test_regex_path_matches_pattern():
    @mock_response(path='re:/report/EntityConfiguration.*')
    def handler():
        return {'entity': True}

    res = get_sideeffect('https://host/report/EntityConfigurationV2')
    assert res.json() == {'entity': True}


def test_regex_matches_across_segments():
    @mock_response(path='re:/report/.*')
    def handler():
        return {'ok': True}

    res = get_sideeffect('https://host/report/sub/deep')
    assert res.json() == {'ok': True}


def test_regex_does_not_match_wrong_pattern():
    @mock_response(path='re:/report/Entity.*')
    def handler():
        return {'ok': True}

    with pytest.raises(OAAMockException):
        get_sideeffect('https://host/report/User')


def test_exact_match_preferred_over_regex():
    @mock_response(path='/report/EntityConfiguration')
    def exact():
        return {'source': 'exact'}

    @mock_response(path='re:/report/.*')
    def regex():
        return {'source': 'regex'}

    res = get_sideeffect('https://host/report/EntityConfiguration')
    assert res.json()['source'] == 'exact'


# ---------------------------------------------------------------------------
# Req 3 — request context available without importing mock module
# ---------------------------------------------------------------------------

def test_current_request_url_set_to_full_url_during_mock():
    captured = []

    @mock_response(path='/api/items')
    def handler():
        captured.append(current_request_url.get())
        return []

    get_sideeffect('https://host/api/items?page=3')
    assert captured[0] == 'https://host/api/items?page=3'


def test_current_request_url_includes_query_string():
    captured = []

    @mock_response(path='/report/*')
    def handler():
        captured.append(current_request_url.get())
        return {}

    get_sideeffect('https://host/report/EntityConfiguration?q=User')
    assert 'q=User' in captured[0]


def test_current_request_url_importable_without_mock_module():
    """Simulate consumer importing current_request_url independently."""
    from oaa.hooks.mock_responses import current_request_url as ctx

    @mock_response(path='/ctx/test')
    def handler():
        return {'url': ctx.get()}

    res = get_sideeffect('https://host/ctx/test?x=1')
    assert res.json()['url'] == 'https://host/ctx/test?x=1'


# ---------------------------------------------------------------------------
# General — error handling and status codes
# ---------------------------------------------------------------------------

def test_no_match_raises_oaa_mock_exception():
    with pytest.raises(OAAMockException):
        get_sideeffect('https://host/not/registered')


def test_status_code_preserved():
    @mock_response(path='/api/gone', status_code=410)
    def handler():
        return {}

    res = get_sideeffect('https://host/api/gone')
    assert res.status_code == 410


def test_mock_response_requires_path():
    with pytest.raises(Exception, match='path'):
        @mock_response()
        def handler():
            return {}
