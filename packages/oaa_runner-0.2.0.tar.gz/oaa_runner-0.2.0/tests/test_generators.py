"""
Tests for the generator feature.

Generators read a field value from each source record and dynamically create
OAA objects (LocalGroup, LocalRole) from unique values, without needing a
separate source for those objects.

qvia-users.csv has these known unique values:
  USER_TYPE: EXT, FED, INT  → 3 LocalGroups expected
  ROLE_TYPE: Reader, Admin   → 2 LocalRoles expected
"""
import os
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from pydantic import ValidationError

from oaa.models import GeneratorConfig, GeneratorType
from oaa.settings_config import ConfigV2
from oaa.app_runners.custom_app import CustomAppRunner

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))

# Fake Veza API responses used in integration tests
_FAKE_PROVIDER = {'id': 'test-provider-id', 'name': 'Generator Test App'}
_FAKE_DATASOURCE = {'id': 'test-ds-id', 'name': 'Generator Test App Datasource'}


def _make_veza_mock():
    """Return a MagicMock that satisfies the runner's Veza API calls."""
    veza = MagicMock()
    veza.get_provider.return_value = _FAKE_PROVIDER
    veza.get_data_source.return_value = _FAKE_DATASOURCE
    return veza


# ============================================================================
# Config / model validation tests
# ============================================================================


def test_generator_type_enum_values():
    """GeneratorType enum has the expected members."""
    assert GeneratorType.local_group == 'local_group'
    assert GeneratorType.local_role == 'local_role'


def test_generator_config_parses_from_dict():
    """GeneratorConfig validates correctly from a plain dict."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'department',
    })

    assert cfg.generator_type == GeneratorType.local_group
    assert cfg.source_field == 'department'


def test_generator_config_defaults():
    """GeneratorConfig defaults: skip_empty=True, add_membership=True,
    name_template='{{value}}', unique_id_template='{{value}}'."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'title',
    })

    assert cfg.skip_empty is True
    assert cfg.add_membership is True
    assert cfg.name_template == '{{value}}'
    assert cfg.unique_id_template == '{{value}}'
    assert cfg.field_mapping is None


def test_generator_config_custom_templates():
    """Generator name and unique_id templates can be overridden."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'department',
        'name_template': 'Dept: {{value}}',
        'unique_id_template': 'dept_{{value}}',
    })

    assert cfg.name_template == 'Dept: {{value}}'
    assert cfg.unique_id_template == 'dept_{{value}}'


def test_generator_config_add_membership_false():
    """add_membership can be disabled."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'department',
        'add_membership': False,
    })

    assert cfg.add_membership is False


def test_generator_config_invalid_type_raises():
    """An unknown generator_type raises a ValidationError."""
    with pytest.raises(ValidationError):
        GeneratorConfig.model_validate({
            'generator_type': 'unknown_type',
            'source_field': 'department',
        })


def test_generator_config_missing_source_field_raises():
    """source_field is required; omitting it raises a ValidationError."""
    with pytest.raises(ValidationError):
        GeneratorConfig.model_validate({
            'generator_type': 'local_group',
        })


def test_generator_type_normalizes_case():
    """generator_type is normalized to lowercase before validation."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'LOCAL_GROUP',
        'source_field': 'department',
    })

    assert cfg.generator_type == GeneratorType.local_group


def test_generator_on_source_parses(config):
    """A source with a generators dict parses correctly via config.update()."""
    config.update(config_file=BASE_DIR / 'config-with-generators.yaml')

    source = config.sources['users']
    assert source.generators
    assert 'user_type_groups' in source.generators
    assert 'role_type_roles' in source.generators


def test_generator_config_parsed_correctly(config):
    """Generator configs are parsed into GeneratorConfig objects."""
    config.update(config_file=BASE_DIR / 'config-with-generators.yaml')

    group_gen = config.sources['users'].generators['user_type_groups']
    assert group_gen.generator_type == GeneratorType.local_group
    assert group_gen.source_field == 'user_type'
    assert group_gen.unique_id_template == 'usertype_{{value}}'
    assert group_gen.add_membership is True
    assert group_gen.skip_empty is True

    role_gen = config.sources['users'].generators['role_type_roles']
    assert role_gen.generator_type == GeneratorType.local_role
    assert role_gen.source_field == 'role_type'
    assert role_gen.unique_id_template == 'roletype_{{value}}'


def test_source_without_generators_has_empty_dict(config):
    """Sources with no generators field default to an empty dict."""
    config.update(config_file=BASE_DIR / 'config-basic-custom-fields.yaml')

    source = config.sources['users']
    assert source.generators == {} or source.generators is None


def test_post_update_warns_when_source_field_not_in_field_mapping(caplog):
    """ConfigV2.post_update() logs a warning when generator source_field is
    not present in the source's field_mapping."""
    import logging

    with caplog.at_level(logging.WARNING, logger='oaa.settings_config'):
        ConfigV2.model_validate({
            'version': 'v2',
            'runner_type': 'HRIS',
            'sources': {
                'employees': {
                    'source_type': 'VEZA_API',
                    'field_mapping': {
                        'EMAIL': {'destination_field': 'unique_id'},
                    },
                    'generators': {
                        'dept_groups': {
                            'generator_type': 'local_group',
                            'source_field': 'DEPARTMENT',  # not in field_mapping
                        }
                    },
                }
            },
        })

    assert any(
        'DEPARTMENT' in record.message and 'dept_groups' in record.message
        for record in caplog.records
    )


# ============================================================================
# Runtime / integration tests
# ============================================================================


@pytest.fixture
def _generator_config(config):
    """Load the generator test config."""
    config.update(config_file=BASE_DIR / 'config-with-generators.yaml')
    return config


def _run_generator_pipeline(config):
    """Run the full custom-app pipeline with a mocked Veza connection.

    Returns the CustomAppRunner instance so callers can inspect
    _provider_object.
    """
    with patch('oaa.oaa_utils.get_oaa_client', return_value=_make_veza_mock()):
        runner = CustomAppRunner()
        runner.run(push_to_oaa=False)

    return runner


def test_generator_creates_local_groups(_generator_config):
    """Unique USER_TYPE values each produce a LocalGroup."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # qvia-users.csv USER_TYPE values: EXT, FED, INT
    assert 'usertype_EXT' in provider.local_groups
    assert 'usertype_FED' in provider.local_groups
    assert 'usertype_INT' in provider.local_groups


def test_generator_creates_local_roles(_generator_config):
    """Unique ROLE_TYPE values each produce a LocalRole."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # qvia-users.csv ROLE_TYPE values: Reader, Admin
    assert 'roletype_Reader' in provider.local_roles
    assert 'roletype_Admin' in provider.local_roles


def test_generator_deduplicates_objects(_generator_config):
    """Multiple users with the same USER_TYPE produce exactly one LocalGroup."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # There are 3 unique USER_TYPE values, no more
    user_type_groups = [
        uid for uid in provider.local_groups if uid.startswith('usertype_')
    ]
    assert len(user_type_groups) == 3


def test_generator_group_name_matches_template(_generator_config):
    """Generated group name matches name_template rendered with the field value."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    group = provider.local_groups['usertype_EXT']
    assert group.name == 'EXT'


def test_generator_role_name_matches_template(_generator_config):
    """Generated role name matches name_template rendered with the field value."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    role = provider.local_roles['roletype_Reader']
    assert role.name == 'Reader'


def test_generator_adds_group_membership(_generator_config):
    """With add_membership=True, each user is a member of their USER_TYPE group."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # iqviasda2@yahoo.com has USER_TYPE=EXT
    user = provider.local_users['iqviasda2@yahoo.com']
    assert 'usertype_EXT' in user.groups


def test_generator_adds_role_membership(_generator_config):
    """With add_membership=True, each user is assigned their ROLE_TYPE role."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # iqviasda2@yahoo.com has ROLE_TYPE=Reader
    # Roles are stored in role_assignments (not a 'roles' attribute)
    user = provider.local_users['iqviasda2@yahoo.com']
    assert 'roletype_Reader' in user.role_assignments


def test_generator_no_membership_when_disabled(config):
    """With add_membership=False, groups are created but users are not assigned."""
    config.update(config_file=BASE_DIR / 'config-with-generators.yaml')

    # Disable membership on both generators
    config.sources['users'].generators['user_type_groups'].add_membership = False
    config.sources['users'].generators['role_type_roles'].add_membership = False

    runner = _run_generator_pipeline(config)
    provider = runner._provider_object

    # Groups/roles should still be created
    assert 'usertype_EXT' in provider.local_groups
    assert 'roletype_Reader' in provider.local_roles

    # But user should not be a member of any generator group/role
    user = provider.local_users['iqviasda2@yahoo.com']
    # groups is None when no groups assigned, otherwise a list
    assert not user.groups or 'usertype_EXT' not in user.groups
    # role_assignments is {} when no roles assigned
    assert 'roletype_Reader' not in user.role_assignments


def test_generator_skip_empty_skips_blank_values(config):
    """Records with a blank source_field value are not used to create objects."""
    config.update(config_file=BASE_DIR / 'config-with-generators.yaml')

    # Force the source_field for the group generator to a non-existent field
    # so all values will be blank/None — no groups should be created
    config.sources['users'].generators['user_type_groups'].source_field = 'no_such_field'
    config.sources['users'].generators['role_type_roles'].add_membership = False

    runner = _run_generator_pipeline(config)
    provider = runner._provider_object

    user_type_groups = [
        uid for uid in provider.local_groups if uid.startswith('usertype_')
    ]
    assert len(user_type_groups) == 0


# ============================================================================
# multi_value option tests
# ============================================================================


def test_generator_config_multi_value_default():
    """multi_value defaults to False."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tags',
    })
    assert cfg.multi_value is False


def test_generator_config_multi_value_true():
    """multi_value: true parses correctly."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tag_ids',
        'multi_value': True,
    })
    assert cfg.multi_value is True


def test_multi_value_list_creates_one_group_per_element(_generator_config):
    """multi_value=True: a list field creates one group per list element."""
    runner = _run_generator_pipeline(_generator_config)

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tag_ids',
        'unique_id_template': 'tag_{{value}}',
        'multi_value': True,
    })

    source = MagicMock()
    source.generators = {'tag_groups': gen}

    record = MagicMock()
    record.get.side_effect = (
        lambda field: [10, 20, 30] if field == 'tag_ids' else None
    )

    primary_user = runner._provider_object.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    assert 'tag_10' in runner._provider_object.local_groups
    assert 'tag_20' in runner._provider_object.local_groups
    assert 'tag_30' in runner._provider_object.local_groups


def test_multi_value_assigns_membership_for_each_element(_generator_config):
    """multi_value=True: user gets group membership for each list element."""
    runner = _run_generator_pipeline(_generator_config)

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tag_ids',
        'unique_id_template': 'tag_{{value}}',
        'multi_value': True,
        'add_membership': True,
    })

    source = MagicMock()
    source.generators = {'tag_groups': gen}

    record = MagicMock()
    record.get.side_effect = (
        lambda field: [10, 20, 30] if field == 'tag_ids' else None
    )

    primary_user = runner._provider_object.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    assert 'tag_10' in primary_user.groups
    assert 'tag_20' in primary_user.groups
    assert 'tag_30' in primary_user.groups


def test_multi_value_empty_list_creates_nothing(_generator_config):
    """multi_value=True with an empty list does not create any groups."""
    runner = _run_generator_pipeline(_generator_config)

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tag_ids',
        'unique_id_template': 'tag_{{value}}',
        'multi_value': True,
        'skip_empty': True,
    })

    source = MagicMock()
    source.generators = {'tag_groups': gen}

    record = MagicMock()
    record.get.return_value = []

    before_count = len(runner._provider_object.local_groups)
    primary_user = runner._provider_object.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    assert len(runner._provider_object.local_groups) == before_count


def test_multi_value_scalar_wrapped_as_single_element(_generator_config):
    """multi_value=True but field is a scalar — treated as a single value."""
    runner = _run_generator_pipeline(_generator_config)

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'tag_id',
        'unique_id_template': 'tag_{{value}}',
        'multi_value': True,
    })

    source = MagicMock()
    source.generators = {'tag_groups': gen}

    record = MagicMock()
    record.get.return_value = 99  # scalar, not a list

    primary_user = runner._provider_object.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    assert 'tag_99' in runner._provider_object.local_groups


# ============================================================================
# create_if_missing option tests
# ============================================================================


def test_generator_config_create_if_missing_default():
    """create_if_missing defaults to True."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'role_id',
    })
    assert cfg.create_if_missing is True


def test_generator_config_create_if_missing_false():
    """create_if_missing: false parses correctly."""
    cfg = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'role_id',
        'create_if_missing': False,
    })
    assert cfg.create_if_missing is False


def test_create_if_missing_false_links_existing_role(_generator_config):
    """create_if_missing=False links user to pre-existing role."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # Pre-create a role directly on the provider
    provider.add_local_role(name='Viewer', unique_id='role_viewer')

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'role_uid',
        'unique_id_template': '{{value}}',
        'create_if_missing': False,
        'add_membership': True,
    })

    source = MagicMock()
    source.generators = {'role_link': gen}

    record = MagicMock()
    record.get.return_value = 'role_viewer'

    primary_user = provider.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    # The role already existed — it must not be duplicated
    role_ids = [uid for uid in provider.local_roles if uid == 'role_viewer']
    assert len(role_ids) == 1
    # And the user must have the role assigned
    assert 'role_viewer' in primary_user.role_assignments


def test_create_if_missing_false_skips_nonexistent_role(
    _generator_config, caplog
):
    """create_if_missing=False skips unknown unique_ids with a warning."""
    import logging
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'role_uid',
        'unique_id_template': '{{value}}',
        'create_if_missing': False,
        'add_membership': True,
    })

    source = MagicMock()
    source.generators = {'role_link': gen}

    record = MagicMock()
    record.get.return_value = 'role_does_not_exist'

    primary_user = provider.local_users['iqviasda2@yahoo.com']

    with caplog.at_level(logging.WARNING, logger='oaa.app_runners.custom_app'):
        runner._run_generators_for_record(source, record, primary_user)

    assert 'role_does_not_exist' not in provider.local_roles
    assert any(
        'role_does_not_exist' in r.message and 'create_if_missing' in r.message
        for r in caplog.records
    )


def test_create_if_missing_false_links_existing_group(_generator_config):
    """create_if_missing=False links user to pre-existing group."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    provider.add_local_group(name='Beta Testers', unique_id='group_beta')

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'grp_uid',
        'unique_id_template': '{{value}}',
        'create_if_missing': False,
        'add_membership': True,
    })

    source = MagicMock()
    source.generators = {'grp_link': gen}

    record = MagicMock()
    record.get.return_value = 'group_beta'

    primary_user = provider.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    assert 'group_beta' in provider.local_groups
    assert 'group_beta' in primary_user.groups


def test_create_if_missing_false_skips_nonexistent_group(
    _generator_config, caplog
):
    """create_if_missing=False skips unknown group unique_ids with a warning."""
    import logging
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_group',
        'source_field': 'grp_uid',
        'unique_id_template': '{{value}}',
        'create_if_missing': False,
    })

    source = MagicMock()
    source.generators = {'grp_link': gen}

    record = MagicMock()
    record.get.return_value = 'group_ghost'

    primary_user = provider.local_users['iqviasda2@yahoo.com']

    with caplog.at_level(logging.WARNING, logger='oaa.app_runners.custom_app'):
        runner._run_generators_for_record(source, record, primary_user)

    assert 'group_ghost' not in provider.local_groups
    assert any(
        'group_ghost' in r.message and 'create_if_missing' in r.message
        for r in caplog.records
    )


def test_multi_value_create_if_missing_false(_generator_config):
    """multi_value=True + create_if_missing=False links to each existing role."""
    runner = _run_generator_pipeline(_generator_config)
    provider = runner._provider_object

    # Pre-create two roles
    provider.add_local_role(name='Editor', unique_id='role_editor')
    provider.add_local_role(name='Viewer', unique_id='role_viewer')

    gen = GeneratorConfig.model_validate({
        'generator_type': 'local_role',
        'source_field': 'role_ids',
        'unique_id_template': '{{value}}',
        'multi_value': True,
        'create_if_missing': False,
        'add_membership': True,
    })

    source = MagicMock()
    source.generators = {'api_roles': gen}

    record = MagicMock()
    record.get.return_value = ['role_editor', 'role_viewer', 'role_missing']

    primary_user = provider.local_users['iqviasda2@yahoo.com']
    runner._run_generators_for_record(source, record, primary_user)

    # Only the two pre-existing roles should be assigned
    assert 'role_editor' in primary_user.role_assignments
    assert 'role_viewer' in primary_user.role_assignments
    # Missing role must NOT be created
    assert 'role_missing' not in provider.local_roles
