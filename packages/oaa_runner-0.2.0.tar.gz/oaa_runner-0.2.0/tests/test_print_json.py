import json
import os
import sys
import pytest
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch
from oaa.app_runners.custom_app import CustomAppRunner

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def single_ds_config(config):
    """Single-datasource config (one provider_objects entry)."""
    config.update(
        config_file=BASE_DIR / 'configs' / 'config-v2-2.yaml',
        config_format='yaml',
        config_version='v2',
    )
    yield config
    config.reset()


@pytest.fixture
def multi_ds_config(config):
    """Multi-datasource config: produces 'datasource-a' and 'datasource-b'."""
    config.update(
        config_file=BASE_DIR / 'configs' / 'config-multi-ds-runnable.yaml',
        config_format='yaml',
        config_version='v2',
    )
    yield config
    config.reset()


@pytest.fixture
def print_json_runner(single_ds_config):
    runner = CustomAppRunner(no_push=True, print_json=True)
    yield runner


@pytest.fixture
def print_json_multi_runner(multi_ds_config):
    runner = CustomAppRunner(no_push=True, print_json=True)
    yield runner


# ---------------------------------------------------------------------------
# --print-json basic output
# ---------------------------------------------------------------------------

def test_print_json_outputs_valid_json(print_json_runner, tmp_path, monkeypatch, capsys):
    '''--print-json should write valid JSON with an applications key to stdout.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        print_json_runner.run()

    captured = capsys.readouterr()
    assert captured.out.strip(), 'Expected non-empty stdout'
    payload = json.loads(captured.out.strip())
    assert 'applications' in payload


def test_print_json_no_log_noise_on_stdout(print_json_runner, tmp_path, monkeypatch, capsys):
    '''stdout must contain only JSON — no log lines — when --print-json is active.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        print_json_runner.run()

    captured = capsys.readouterr()
    for line in captured.out.strip().splitlines():
        # Every non-empty line must be parseable as JSON
        if line.strip():
            json.loads(line)  # raises if not valid JSON


def test_print_json_writes_no_file(print_json_runner, tmp_path, monkeypatch, capsys):
    '''--print-json alone (save_json=False) must not write any .json files.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        print_json_runner.run()

    json_files = list(tmp_path.glob('*.json'))
    assert len(json_files) == 0, 'Expected no JSON files on disk'


# ---------------------------------------------------------------------------
# --print-json + --no-push
# ---------------------------------------------------------------------------

def test_print_json_with_no_push(print_json_runner, tmp_path, monkeypatch, capsys):
    '''--no-push --print-json: no Veza call, valid JSON on stdout.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client') as mock_client:
        print_json_runner.run()

    mock_client.assert_not_called()
    captured = capsys.readouterr()
    payload = json.loads(captured.out.strip())
    assert 'applications' in payload


# ---------------------------------------------------------------------------
# --print-json + --save-json
# ---------------------------------------------------------------------------

def test_print_json_with_save_json(single_ds_config, tmp_path, monkeypatch, capsys):
    '''--print-json --save-json: file written AND stdout populated.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner(no_push=True, print_json=True, save_json=True)

    with patch('oaa.oaa_utils.get_oaa_client'):
        runner.run()

    # File written
    json_files = list(tmp_path.glob('*.json'))
    assert len(json_files) == 1, 'Expected exactly one JSON file on disk'

    # Stdout populated
    captured = capsys.readouterr()
    payload = json.loads(captured.out.strip())
    assert 'applications' in payload


# ---------------------------------------------------------------------------
# --print-json with live push (no --no-push)
# ---------------------------------------------------------------------------

def test_print_json_with_live_push(single_ds_config, tmp_path, monkeypatch, capsys):
    '''--print-json without --no-push: push happens AND payload printed to stdout.'''
    monkeypatch.chdir(tmp_path)

    mock_veza = MagicMock()
    mock_veza.get_provider.return_value = None
    mock_veza.create_provider.return_value = {'id': 'pid', 'name': 'test'}
    mock_veza.get_data_source.return_value = None
    mock_veza.create_datasource.return_value = {'id': 'dsid', 'name': 'ds'}
    mock_veza.push_application.return_value = {'warnings': []}

    runner = CustomAppRunner(no_push=False, print_json=True)

    with patch('oaa.oaa_utils.get_oaa_client', return_value=mock_veza):
        runner.run()

    mock_veza.push_application.assert_called_once()
    captured = capsys.readouterr()
    payload = json.loads(captured.out.strip())
    assert 'applications' in payload


# ---------------------------------------------------------------------------
# Duplicate output guard
# ---------------------------------------------------------------------------

def test_print_json_no_duplicate_output(print_json_runner, tmp_path, monkeypatch, capsys):
    '''The same datasource must not appear twice on stdout even if run() is called twice.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        print_json_runner.run()
        print_json_runner.run()

    captured = capsys.readouterr()
    lines = [l for l in captured.out.strip().splitlines() if l.strip()]
    assert len(lines) == 1, 'Expected exactly one JSON object on stdout'


# ---------------------------------------------------------------------------
# get_payload() failure — nothing written to stdout
# ---------------------------------------------------------------------------

def test_print_json_get_payload_failure_no_stdout(print_json_runner, capsys):
    '''If json.dumps() fails on the metadata, nothing must be written to stdout.'''
    # An object that raises on JSON serialization simulates a bad payload
    class Unserializable:
        def __repr__(self):
            return 'Unserializable()'

    print_json_runner._emit_json_to_stdout('test-ds', Unserializable())

    captured = capsys.readouterr()
    assert captured.out.strip() == '', 'Expected empty stdout on serialization failure'


# ---------------------------------------------------------------------------
# Multi-datasource: no --datasource → exit(1)
# ---------------------------------------------------------------------------

def test_print_json_multi_datasource_no_filter_exits(
    print_json_multi_runner, tmp_path, monkeypatch
):
    '''Multi-datasource + --print-json without --datasource must exit non-zero.'''
    monkeypatch.chdir(tmp_path)

    with patch('oaa.oaa_utils.get_oaa_client'):
        with pytest.raises(SystemExit) as exc_info:
            print_json_multi_runner.run()

    assert exc_info.value.code != 0


# ---------------------------------------------------------------------------
# Multi-datasource: --datasource filter
# ---------------------------------------------------------------------------

def test_print_json_datasource_filter(multi_ds_config, tmp_path, monkeypatch, capsys):
    '''--datasource should only emit the matching datasource payload on stdout.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner(no_push=True, print_json=True, datasource='datasource-a')

    with patch('oaa.oaa_utils.get_oaa_client'):
        runner.run()

    captured = capsys.readouterr()
    lines = [l for l in captured.out.strip().splitlines() if l.strip()]
    assert len(lines) == 1, 'Expected exactly one JSON object for the filtered datasource'
    payload = json.loads(lines[0])
    assert 'applications' in payload


# ---------------------------------------------------------------------------
# list_datasources
# ---------------------------------------------------------------------------

def test_list_datasources_returns_json_array(single_ds_config, tmp_path, monkeypatch, capsys):
    '''list_datasources() should print a valid JSON array to stdout.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner()

    with patch('oaa.oaa_utils.get_oaa_client'):
        runner.list_datasources()

    captured = capsys.readouterr()
    result = json.loads(captured.out.strip())
    assert isinstance(result, list)
    assert len(result) >= 1


def test_list_datasources_no_veza_connection(single_ds_config, tmp_path, monkeypatch):
    '''list_datasources() must never call get_oaa_client.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner()

    with patch('oaa.oaa_utils.get_oaa_client') as mock_client:
        runner.list_datasources()

    mock_client.assert_not_called()


def test_list_datasources_single_datasource(single_ds_config, tmp_path, monkeypatch, capsys):
    '''Single-datasource config must produce a single-element JSON array.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner()

    with patch('oaa.oaa_utils.get_oaa_client'):
        runner.list_datasources()

    captured = capsys.readouterr()
    result = json.loads(captured.out.strip())
    assert len(result) == 1


def test_list_datasources_multi_datasource(multi_ds_config, tmp_path, monkeypatch, capsys):
    '''Multi-datasource config must list all datasource names.'''
    monkeypatch.chdir(tmp_path)

    runner = CustomAppRunner()

    with patch('oaa.oaa_utils.get_oaa_client'):
        runner.list_datasources()

    captured = capsys.readouterr()
    result = json.loads(captured.out.strip())
    assert isinstance(result, list)
    assert 'datasource-a' in result
    assert 'datasource-b' in result
    assert len(result) >= 2
