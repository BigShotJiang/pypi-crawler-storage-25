import importlib
import types
from unittest.mock import MagicMock, patch

import pytest

from oaa.modules.exceptions import (
    ConfigurationError,
    DataTransformError,
    SourceConnectionError,
    VezaAPIError,
)
from oaa.app_runners import hook_executor_mixin
from oaa import utils


def test_configuration_error_is_exception():
    with pytest.raises(ConfigurationError):
        raise ConfigurationError('missing required param')


def test_source_connection_error_is_exception():
    with pytest.raises(SourceConnectionError):
        raise SourceConnectionError('failed to connect to source')


def test_data_transform_error_is_exception():
    with pytest.raises(DataTransformError):
        raise DataTransformError('transform failed on field x')


def test_veza_api_error_is_exception():
    with pytest.raises(VezaAPIError):
        raise VezaAPIError('Veza API returned 500')


def test_all_exceptions_inherit_from_exception():
    assert issubclass(ConfigurationError, Exception)
    assert issubclass(SourceConnectionError, Exception)
    assert issubclass(DataTransformError, Exception)
    assert issubclass(VezaAPIError, Exception)


def test_exception_messages_are_preserved():
    msg = 'detailed error message'
    for exc_class in (
        ConfigurationError,
        SourceConnectionError,
        DataTransformError,
        VezaAPIError,
    ):
        exc = exc_class(msg)
        assert str(exc) == msg


def test_optional_db_imports_do_not_raise():
    """Import guards for optional DB drivers should not raise on missing deps."""
    # These try/except ImportError blocks in runner_base.py should always be
    # importable even when the optional drivers are not installed.
    try:
        from oaa.app_runners import runner_base  # noqa: F401
    except ImportError as e:
        pytest.fail(f'runner_base failed to import due to missing optional dep: {e}')


# ---------------------------------------------------------------------------
# _get_stream: SourceConnectionError is caught and returns None
# ---------------------------------------------------------------------------

def test_get_stream_returns_none_on_source_connection_error():
    """_get_stream catches SourceConnectionError and returns None gracefully."""
    from oaa.app_runners.db_connection_mixin import DBConnectionMixin

    mixin = DBConnectionMixin.__new__(DBConnectionMixin)

    with patch.object(mixin, '_get_connection',
                      side_effect=SourceConnectionError('db unavailable')):
        result = mixin._get_stream(query='SELECT 1')

    assert result is None


# ---------------------------------------------------------------------------
# _get_logic_modules: AssertionError from validation is non-fatal
# ---------------------------------------------------------------------------

def test_get_logic_modules_continues_on_invalid_module():
    """_get_logic_modules catches AssertionError and still returns the module."""
    from oaa.app_runners.hook_executor_mixin import HookExecutorMixin
    from oaa.settings import Config

    mixin = HookExecutorMixin()
    fake_module = MagicMock()
    fake_module.__name__ = 'fake_module'

    mock_config = MagicMock()
    mock_config.LOGIC_MODULES = ['fake_module']

    with patch.object(Config, '_CONFIG', mock_config), \
         patch('oaa.app_runners.hook_executor_mixin.utils.validate_logic_module',
               side_effect=AssertionError('bad module')), \
         patch('oaa.app_runners.hook_executor_mixin.importlib.import_module',
               return_value=fake_module):
        modules = mixin._get_logic_modules()

    assert fake_module in modules


# ---------------------------------------------------------------------------
# _push_csv_file: OAAClientError / OAAResponseError are caught gracefully
# ---------------------------------------------------------------------------

def test_push_csv_file_catches_oaa_client_error():
    """_push_csv_file catches OAAClientError without propagating."""
    from oaa.app_runners.provider_manager_mixin import ProviderManagerMixin
    from oaaclient.client import OAAClientError

    mixin = ProviderManagerMixin()
    mock_client = MagicMock()
    mock_client.api_post.side_effect = OAAClientError(
        'push_error', 'push failed', status_code=500, details=[]
    )

    fake_source = MagicMock()

    with patch('oaa.app_runners.provider_manager_mixin.oaa_utils.get_oaa_client',
               return_value=mock_client), \
         patch('oaa.app_runners.provider_manager_mixin.oaa_utils.make_csv_upload_payload',
               return_value={}):
        result = mixin._push_csv_file(
            {'id': 'p-1'}, {'id': 'ds-1'}, fake_source
        )

    assert result is None


def test_push_csv_file_catches_oaa_response_error():
    """_push_csv_file catches OAAResponseError without propagating."""
    from oaa.app_runners.provider_manager_mixin import ProviderManagerMixin
    from oaaclient.client import OAAResponseError

    mixin = ProviderManagerMixin()
    mock_client = MagicMock()
    err = OAAResponseError.__new__(OAAResponseError)
    err.details = 'bad response'
    mock_client.api_post.side_effect = err

    fake_source = MagicMock()

    with patch('oaa.app_runners.provider_manager_mixin.oaa_utils.get_oaa_client',
               return_value=mock_client), \
         patch('oaa.app_runners.provider_manager_mixin.oaa_utils.make_csv_upload_payload',
               return_value={}):
        result = mixin._push_csv_file(
            {'id': 'p-1'}, {'id': 'ds-1'}, fake_source
        )

    assert result is None


# ---------------------------------------------------------------------------
# validate_fetch_module
# ---------------------------------------------------------------------------

def test_validate_fetch_module_passes_for_valid_module():
    """validate_fetch_module returns True for a module with correct fetch() signature."""
    from oaa import utils

    mod = types.ModuleType('fake_fetch')
    mod.fetch = lambda connection, source, **kwargs: []

    assert utils.validate_fetch_module(mod) is True


def test_validate_fetch_module_raises_when_fetch_missing():
    """validate_fetch_module raises AssertionError when fetch() is absent."""
    from oaa import utils

    mod = types.ModuleType('no_fetch_module')

    with pytest.raises(AssertionError, match='missing a fetch\\(\\) function'):
        utils.validate_fetch_module(mod)


def test_validate_fetch_module_raises_for_wrong_signature():
    """validate_fetch_module raises AssertionError when fetch() has wrong params."""
    from oaa import utils

    mod = types.ModuleType('bad_sig_module')
    mod.fetch = lambda url, token: []  # wrong args

    with pytest.raises(AssertionError, match='missing required parameters'):
        utils.validate_fetch_module(mod)
