"""
OAA Modules - Reusable utilities for oaa-runner integrations.

Available modules:
    - BaseURLSession: requests.Session with automatic base URL joining
    - lazy_dict_table: Memory-efficient PETL table from dict generators
    - params_or_env: Get config values from env/connection/source params
    - ConfigurationError: Exception for configuration issues

Example:
    from oaa.modules import BaseURLSession, lazy_dict_table, params_or_env
    from oaa.modules.exceptions import ConfigurationError
"""

from .base_url_session import BaseURLSession
from .lazy_dicts import lazy_dict_table
from .params_or_env import params_or_env
from .exceptions import ConfigurationError

__all__ = [
    "BaseURLSession",
    "lazy_dict_table",
    "params_or_env",
    "ConfigurationError",
]
