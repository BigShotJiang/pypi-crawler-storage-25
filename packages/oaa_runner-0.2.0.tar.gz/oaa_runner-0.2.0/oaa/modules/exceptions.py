"""
Custom exceptions for oaa-runner modules.

These exceptions can be caught and handled downstream in integration code.
"""


class ConfigurationError(Exception):
    """
    Raised when a module is misconfigured or missing required parameters.

    This exception is raised when:
    - Required configuration values are None or empty
    - Connection parameters are invalid or missing
    - Source parameters are incomplete

    Example:
        from oaa.modules.exceptions import ConfigurationError

        try:
            session = BaseURLSession(None)
        except ConfigurationError as e:
            logger.error(f"Configuration error: {e}")
            # Handle gracefully
    """

    pass


class SourceConnectionError(Exception):
    """Raised when a connection to a source system fails."""

    pass


class DataTransformError(Exception):
    """Raised when a data transformation operation fails."""

    pass


class VezaAPIError(Exception):
    """Raised when a Veza API call fails."""

    pass
