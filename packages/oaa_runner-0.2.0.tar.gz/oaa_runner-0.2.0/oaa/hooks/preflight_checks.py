"""
Preflight check registry for OAA Runner.

Provides the ``@preflight`` decorator for registering validation functions
that run before each sync. All registered checks are stored in ``preflights``
and executed together via ``run_preflights()``.
"""
from functools import wraps
import logging
logger = logging.getLogger(__name__)


preflights = []
preflight_conditions = {}


def preflight(_func=None, *args, require_config=True, **kwargs):
    """Decorator that registers a function as a preflight check.

    Decorated functions are appended to ``preflights`` and called by
    ``run_preflights()`` before each sync. Set ``require_config=False``
    to allow the check to run even when config is not yet loaded.
    """
    def inner(func):

        @wraps(func)
        def wrapper(runner, *args, **kwargs):
            """A wrapper function"""
            from oaa.settings import config

            # Extend some capabilities of func
            logger.debug('running %s preflight', func.__name__)

            if 'config' not in preflight_conditions:
                preflight_conditions['config'] = config

            if require_config:
                if not config:
                    return ['invalid configuration - preflight check'
                            f'[{func.__name__}] cannot run']

                return func(runner, *args, config=config,
                            preflight_conditions=preflight_conditions,
                            **kwargs)

            return func(runner, *args,
                        preflight_conditions=preflight_conditions,
                        **kwargs)

        preflights.append(wrapper)

        return wrapper

    if _func is None:
        return inner

    return inner(_func)


def run_preflights(runner):
    """Run all registered preflight checks and return a combined list of problems."""
    problems = []

    for pf in preflights:
        problems.extend(pf(runner))

    return problems
