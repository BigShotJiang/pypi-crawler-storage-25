"""
Mock HTTP response framework for OAA Runner integration testing.

Use ``@mock_response(path='/some/path')`` to register a handler that returns
a fake response for that path. ``maybe_mock_it()`` activates mocking on a
connection object when ``MOCK_RESULTS=true`` is set in params or environment.
Supports exact paths, wildcard (fnmatch) patterns, and regex (``re:`` prefix).
"""
import re
import fnmatch
import urllib.parse
import logging
from contextvars import ContextVar
from functools import wraps
from unittest.mock import MagicMock
from oaa.modules.params_or_env import params_or_env
logger = logging.getLogger(__name__)


MOCK_RESPONSES = {}

_current_request_url: ContextVar[str] = ContextVar(
    '_current_request_url', default=''
)
# Public alias — consumers can import this to read the active request URL
# inside a mock handler without importing anything from the main module.
current_request_url = _current_request_url


class MockResponse:
    def __init__(self, resp, status_code=200):
        """Wrap a response dict and status code to mimic a requests.Response."""
        self.response = resp
        self._status_code = status_code

    # @classmethod
    def json(self, *args):
        return self.response

    @property
    def status_code(self):
        return self._status_code


def mock_response(_func=None, path=None, status_code=200, **kwargs):
    """Decorator that registers a function as the mock handler for a given path.

    The decorated function should return the response payload dict.
    Raises if ``path`` is not provided.
    """
    def inner(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            """A wrapper function"""

            # Extend some capabilities of func
            res = MockResponse(func(*args, **kwargs), status_code=status_code)
            logger.debug('returning mocked response for %s -- %s', path, res)

            return res

        if not path:
            raise Exception(
                f'You must define an overrided path for mocks({path})'
            )

        logger.debug('preparing mock response for %s', path)
        MOCK_RESPONSES[path] = wrapper

        return MOCK_RESPONSES[path]

    if _func is None:
        return inner

    return inner(_func)


class OAAMockException(Exception):
    """Raised when a request path has no registered mock handler."""
    pass


def _fnmatch_path(path, pattern):
    """Segment-aware fnmatch: ``*`` and ``?`` do not cross ``/``.

    :param path: URL path string (e.g. ``/report/EntityConfiguration``).
    :param pattern: Pattern using ``*`` / ``?`` wildcards.
    :returns: True if every path segment matches the corresponding pattern
              segment, and the number of segments is equal.
    """
    path_parts = path.split('/')
    pattern_parts = pattern.split('/')
    if len(path_parts) != len(pattern_parts):
        return False
    return all(
        fnmatch.fnmatch(p, pat)
        for p, pat in zip(path_parts, pattern_parts)
    )


def _resolve_path(path):
    """Return the MOCK_RESPONSES key that matches *path*, or None.

    Fallback order (first match wins):
      1. Exact full URL (e.g. ``https://host/path?q=v``)
      2. Path + query string (e.g. ``/path?q=v``)
      3. Path only (e.g. ``/path``) — preserves all existing behaviour
      4. Wildcard / regex scan against path-only:
           - Keys prefixed with ``re:`` are treated as ``re.fullmatch``
             (e.g. ``re:/report/EntityConfiguration.*``)
           - Other keys are matched with segment-aware fnmatch (``*`` / ``?``
             do not cross ``/``, e.g. ``/report/*``)

    :param path: Raw URL or path string passed to :func:`get_sideeffect`.
    :returns: Matching key from ``MOCK_RESPONSES``, or ``None``.
    """
    parsed = urllib.parse.urlparse(path)
    path_only = parsed.path
    path_and_query = (
        path_only + ('?' + parsed.query if parsed.query else '')
    )

    for candidate in (path, path_and_query, path_only):
        if candidate in MOCK_RESPONSES:
            return candidate

    for key in MOCK_RESPONSES:
        if key.startswith('re:'):
            # Regex form: re:/pattern
            if re.fullmatch(key[3:], path_only):
                return key
        else:
            # Wildcard form: * and ? match within a single path segment only.
            if _fnmatch_path(path_only, key):
                return key

    return None


def call_response(path):
    """Look up and invoke the mock registered for *path*.

    :param path: URL or path string to resolve.
    :returns: :class:`MockResponse` instance from the registered handler.
    :raises OAAMockException: When no matching mock is registered.
    """
    key = _resolve_path(path)
    if key is None:
        raise OAAMockException(f'no overridden path provided for {path}')
    return MOCK_RESPONSES[key]()


def get_sideeffect(path, *args, **kwargs):
    """Side-effect function used by :func:`maybe_mock_it`.

    Stores the raw request URL in :data:`current_request_url` so mock
    handlers can inspect it, then delegates to :func:`call_response`.

    :param path: Full URL passed by the mocked HTTP method.
    :returns: :class:`MockResponse` from the matching handler.
    :raises OAAMockException: When no matching mock is registered.
    """
    try:
        _current_request_url.set(path)
    except Exception as e:
        print('path', path, e)
    logger.debug('getting response for %s', path)
    res = call_response(path)

    if res is None:
        raise OAAMockException(f'no mocked response for path {path}')

    return res


def maybe_mock_it(mocked_object, method, connection, source):
    """Patch ``method`` on ``mocked_object`` with the mock side-effect if MOCK_RESULTS=true."""
    if str(params_or_env(connection, source, 'MOCK_RESULTS')).lower() == 'true':
        setattr(mocked_object, method, MagicMock(side_effect=get_sideeffect))
