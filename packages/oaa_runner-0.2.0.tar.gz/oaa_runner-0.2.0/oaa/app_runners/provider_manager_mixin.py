import json
import logging
import sys
from datetime import datetime

import petl
from oaaclient.client import OAAClientError, OAAResponseError
from oaaclient.utils import encode_icon_file

from oaa import oaa_utils
from oaa.settings import config
from oaa.config import App

logger = logging.getLogger(__name__)


class ProviderManagerMixin:

    def _emit_json_to_stdout(self, ds_name, metadata):
        """Write the OAA payload for ds_name to stdout as newline-delimited JSON.

        Guards against duplicate output and handles serialization errors
        and broken pipes safely.

        :param ds_name: Datasource name (used to deduplicate output)
        :param metadata: The payload dict from provider_obj.get_payload()
        """
        if not self._print_json:
            return
        if ds_name in self._printed_datasources:
            return
        # Re-scan for handlers added after __init__ to keep stdout clean
        import logging as _logging
        for handler in _logging.root.handlers:
            if hasattr(handler, 'stream') and handler.stream is sys.stdout:
                handler.stream = sys.stderr
        try:
            sys.stdout.write(json.dumps(metadata) + '\n')
            sys.stdout.flush()
            self._printed_datasources.add(ds_name)
        except BrokenPipeError:
            sys.exit(0)
        except Exception as e:
            logger.error(
                'Failed to serialize payload to stdout: %s', e
            )

    def _get_push_options(self):
        """Return the options dict for push calls (e.g. priority_push flag)."""
        options = {
            'priority_push': self._priority_push
        }

        return options

    def _get_or_create_datasource(self, name=None, **kwargs):
        """Fetch or create a Veza datasource under the current provider; caches by name in self._datasources."""
        name = name or self._datasource_name
        if not hasattr(self, '_datasources'):
            self._datasources = {}

        if name not in self._datasources:
            veza_con = oaa_utils.get_oaa_client(runner=self)
            datasource = veza_con.get_data_source(
                name=name,
                provider_id=self._provider_object.provider['id'],
            )

            if not datasource:
                datasource = veza_con.create_datasource(
                    name=name,
                    provider_id=self._provider_object.provider['id'],
                )

            self._datasources[name] = datasource
            if name == self._datasource_name:
                self._datasource = datasource

        return self._datasources[name]

    def _get_or_create_provider(self, **kwargs):
        """Fetch or create a Veza provider, optionally uploading an icon. Sets self._provider_object."""
        if not self._provider_object:
            if config.is_csv_push:
                self._set('_created_provider', False)

                return
            logger.info(f'Creating provider for {self._provider_name}')
            provider_cls = self._get_provider_type()

            if isinstance(kwargs, App):
                kwargs = kwargs.model_dump()

            options = {}

            if kwargs.get('options'):
                options = kwargs.pop('options')
            kwargs = {k: v for k, v in kwargs.items() if v and k not in ('datasource', 'options')}

            self._provider_object = provider_cls(**kwargs)

            self._custom_provider_actions(
                provider_object=self._provider_object
            )

            if hasattr(self, '_provider_objects'):
                self._provider_objects[self._datasource_name] = self._provider_object

            if self._no_push:
                logger.info(
                    'Skipping Veza provider sync (no_push=True)'
                )
            else:
                veza_con = oaa_utils.get_oaa_client(runner=self)
                provider = veza_con.get_provider(self._provider_name)

                if not provider:
                    logger.info(
                        f'Creating new provider {self._provider_name}'
                    )
                    try:
                        provider = veza_con.create_provider(
                            self._provider_name,
                            self._provider_object.TEMPLATE,
                            options=options,
                        )
                        logger.debug(f"Provider created with options{options}")
                        logger.info(f"Provider created {provider['id']}")
                    except OAAResponseError as err:
                        logger.error(str(err.details))
                self._provider_object.provider = provider

                if config.HRIS_ICON_B64_PATH:
                    veza_con.update_provider_icon(
                        provider['id'],
                        encode_icon_file(config.HRIS_ICON_B64_PATH),
                    )  # noqa E501

            logger.info('template: %s', self._provider_object.TEMPLATE)

        return self._provider_object

    def _push_csv_file(self, provider, datasource, source):
        """Assemble a CSV payload and push it to Veza as a datasource update."""
        payload = oaa_utils.make_csv_upload_payload(
            provider['id'], datasource['id'], source.stream
        )

        oaaclient = oaa_utils.get_oaa_client()

        path = (
            f'/api/v1/providers/custom/{provider["id"]}'
            f'/datasources/{datasource["id"]}:push_csv'
        )
        logger.info('path: %s', path)

        try:
            response = oaaclient.api_post(path, payload)

            return response
        except (OAAClientError, OAAResponseError) as exc:
            logger.error(exc.details)

    def _push_to_oaa(self):
        """Push CSV sources. Non-CSV pushes are handled via _push_single_datasource."""
        if self._no_push:
            logger.info('Skipping CSV push to Veza (no_push=True)')
            return None, None

        response = None
        datasource_id = None

        for source_name, source in config.sources.items():
            ds_name = source.datasource or (
                config.app.datasource if config.app else None
            )
            datasource = source.upsert_datasource(datasource_name=ds_name)
            datasource_id = datasource['id']

            has_problems, errors = source.validate_to_api_csv_mapping()

            if not errors:
                response = self._push_csv_file(
                    source.get_provider(), datasource, source
                )
            else:
                logger.error(
                    'csv file for source[%s:%s] is not valid',
                    source_name,
                    source.csv_filepath,
                )

        return datasource_id, response

    def _push_single_datasource(self, ds_name, provider_obj):
        """Push one non-CSV datasource group to Veza."""
        response = None
        datasource_id = None

        if self._no_push:
            logger.info('Skipping push to Veza (no_push=True)')
            if self._save_json or self._print_json:
                metadata = provider_obj.get_payload()
                if self._save_json:
                    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
                    out_name = f'{ds_name}-{ts}.json'
                    with open(out_name, 'w') as f:
                        f.write(json.dumps(metadata, indent=2))
                    logger.info(f'no_push payload saved to {out_name}')
                self._emit_json_to_stdout(ds_name, metadata)
            return datasource_id, response

        veza_con = oaa_utils.get_oaa_client(runner=self)

        try:
            if not self._dry_run:
                logger.info('Sending to Veza')

                datasource = self._get_or_create_datasource(name=ds_name)
                datasource_id = datasource['id']
                response = veza_con.push_application(
                    self._provider_name,
                    ds_name,
                    provider_obj,
                    save_json=self._save_json,
                    options=self._get_push_options(),
                )

                if response.get('warnings', None):
                    logger.warning('Push succeeded with warnings')
                    for w in response['warnings']:
                        logger.warning(w)
                logger.info('Success')

                if self._print_json:
                    metadata = provider_obj.get_payload()
                    self._emit_json_to_stdout(ds_name, metadata)
            else:
                logger.info('Would have sent a payload to Veza')
                if self._save_json or self._print_json:
                    metadata = provider_obj.get_payload()
                    if self._save_json:
                        ts = datetime.now().strftime('%Y%m%d-%H%M%S')
                        out_name = f'{ds_name}-{ts}.json'
                        with open(out_name, 'w') as f:
                            f.write(json.dumps(metadata, indent=2))
                        logger.info(f'Dry run payload saved to {out_name}')
                    self._emit_json_to_stdout(ds_name, metadata)
        except OAAResponseError as e:
            logger.error(e.details)
        except OAAClientError as e:
            logger.error(
                f'Error during push {e.message} {e.status_code}'
            )
            if e.details:
                from pprint import pprint
                pprint(e.details)
            logger.error('exiting with error')
            sys.exit(1)

        return datasource_id, response
