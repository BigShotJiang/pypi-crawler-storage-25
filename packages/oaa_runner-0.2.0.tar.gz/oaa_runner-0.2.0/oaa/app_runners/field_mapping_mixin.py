import json
import logging

from oaa.settings import config

logger = logging.getLogger(__name__)


def fmapper(source_f):
    """Take source field, then return rec[source_f]"""

    return lambda val, rec: rec[source_f]


def add_missing_fields(stream, should_be_list, current_list):
    """Add any destination fields missing from the stream, padding with empty strings."""
    missing_list = set(should_be_list) - set(current_list)

    for destination_field in missing_list:
        stream = stream.addfield(destination_field, '')

    return stream


class FieldMappingMixin:

    def show_field_mapping(self):
        """Print field mapping configuration for each source to stdout."""
        for n, s in config.sources.items():
            print('=' * 25)
            print('source', n)
            print('=' * 25)

            for fm, f in s.field_mappings().items():
                print('mapping name: ', fm)
                print('source_field: ', f.source_field or fm)
                print('destination_field: ', f.destination_field)
                print('transforms: ', [t.name for t in f.transforms])
                print('')
                print('-' * 25)

    def field_mappings(self, output_format=None, source=None):
        """Field Mappings moved to the settings.Source object."""

        if isinstance(source, str):
            source = config.sources[source]
        mappings = source.field_mappings()

        if output_format == 'table':
            return mappings

        elif output_format == 'json':
            return json.dumps(mappings, indent=2)

        return mappings
