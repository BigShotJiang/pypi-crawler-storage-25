import logging
import petl

from oaa import utils
from oaa.hooks.decorators import OAAHookEvent, run_hooks
from oaa.modules.exceptions import DataTransformError
from oaa.settings import config
from .field_mapping_mixin import fmapper, add_missing_fields

logger = logging.getLogger(__name__)


class TransformPipelineMixin:

    def _run_transforms(self):
        """Run field transforms for all sources and fire POST_TRANSFORM hooks."""
        for name, source in config.sources.items():
            self._run_transform(source)

            run_hooks(
                event=OAAHookEvent.POST_TRANSFORM,
                config=config,
                provider=self._provider_object,
                sources=config.sources,
                source=source,
            )

    def _run_transform(self, source):
        """Run the Transforms on the source fields.

        This function also populates the source->destination mapping.
        """

        logger.debug('run transforms for source %s', source.source_name)
        run_hooks(
            event=OAAHookEvent.PRE_TRANSFORM,
            config=config,
            provider=self._provider_object,
            source=source,
        )

        run_hooks(
            event=OAAHookEvent.RECORD_TRANSFORM_STREAM,
            config=config,
            source=source,
            provider=self._provider_object,
        )

        fields_to_cutout = set()

        try:
            field_mappings = self.field_mappings(source=source)
        except DataTransformError as e:
            logger.error('Failed to load field mappings for source %s: %s',
                         source.source_name, e, exc_info=True)

        header_list = petl.header(source.stream)
        initial_fieldnames_list = set(header_list)

        for fieldname_label, field in field_mappings.items():
            logger.debug('checking %s [%s]', fieldname_label, field)

            if not field.include:
                continue

            fieldname = field.source_field or fieldname_label
            destination = field.destination_field
            deferred_converts = []

            for transform_obj in field.transforms:
                transform = transform_obj.name
                field_options = transform_obj.options
                func_obj = utils.transformers.get(transform, None)

                if func_obj:
                    func = func_obj['func']
                    mode = func_obj['mode']
                    func = func(options=field_options)

                    if mode == 'convert':
                        if fieldname != destination:
                            deferred_converts.append(func)
                        else:
                            source._stream = source.stream.convert(
                                fieldname, func, pass_row=True
                            )

                    elif mode == 'add':
                        source._stream = source.stream.addfield(destination, func)
                        initial_fieldnames_list.add(destination)
                        fieldname = destination
                    elif mode == 'select':
                        source._stream = source.stream.select(fieldname, func)
                elif transform == 'ignore':
                    fields_to_cutout.add(fieldname)
                elif transform == 'distinct':
                    source._stream = source.stream.distinct(fieldname)

            logger.debug('transforming field %s', destination)

            if field.is_custom:
                source.custom_attrs_map[destination] = field
            else:
                if fieldname != destination:
                    source.attributes[destination] = destination
                else:
                    source.attributes[destination] = fieldname

            if fieldname != destination:
                if destination not in initial_fieldnames_list:
                    source._stream = source.stream.addfield(destination, '')

                source._stream = source.stream.convert(
                    destination, fmapper(fieldname), pass_row=True
                )

                for func in deferred_converts:
                    source._stream = source.stream.convert(
                        destination, func, pass_row=True
                    )

        necessary_destinations = [
            f.destination_field for idx, f in field_mappings.items()
        ]
        initial_fieldnames_list.update(necessary_destinations)
        final_fieldnames_list = list(initial_fieldnames_list)

        source._stream = add_missing_fields(
            source.stream, necessary_destinations, initial_fieldnames_list
        )

        filtered_fieldnames = filter(
            lambda f: f in final_fieldnames_list, fields_to_cutout
        )

        for fieldname in filtered_fieldnames:
            source._stream = source.stream.cutout(fieldname)

        null_to_blank_func = utils.transformers.get('null_to_blank', None)['func']
        source._stream = source.stream.convertall(null_to_blank_func(options={}))
