import importlib
import logging

from oaa import utils

logger = logging.getLogger(__name__)

LOGIC_MODULE_REQUIRED_ARGS = ['config', 'streams']


class HookExecutorMixin:

    def _hook_pre_oaa(self, *args, **kwargs):
        """If a runner overrides this function, it can do data manipulation of
        the stream(s) before the OAA objects are created.
        """

        return

    def _get_logic_modules(self):
        """Get any custom logic modules for this runner.

        :returns: list of imported modules
        """
        from oaa.settings import config

        logic_modules = config.LOGIC_MODULES or []

        modules = []

        for module in logic_modules:
            imported_module = importlib.import_module(module)

            try:
                assert utils.validate_logic_module(imported_module)
            except AssertionError:
                logger.debug(
                    'you may consider defining a function called `run` '
                    f' in the {module} module and it must take the '
                    'following arguments: '
                    f' {LOGIC_MODULE_REQUIRED_ARGS}'
                )

            modules.append(imported_module)

        return modules
