import logging

import petl

from oaa.modules.exceptions import SourceConnectionError

try:
    import pymssql
except ImportError:
    pymssql = None
try:
    import oracledb
except ImportError:
    oracledb = None
try:
    import psycopg
except ImportError:
    psycopg = None

logger = logging.getLogger(__name__)


class DBConnectionMixin:

    def _get_stream(self, query=None, source=None):
        '''The default is to load data from a DB.

        Overide this method to make it do something different.
        '''
        try:
            conn = self._get_connection()

            if conn:
                table = petl.fromdb(conn, query)

                return table
        except SourceConnectionError as exc:
            logger.error(exc)

            return

    def _get_connection(self):
        """Open and return a DB connection based on DB_DIALECT (SQLSERVER, ORACLE, POSTGRES)."""
        from oaa.settings import config

        if config.DB_DIALECT == 'SQLSERVER':
            try:
                connection = pymssql.connect(config.DB_SERVER,
                                             config.DB_USER,
                                             config.DB_PASSWORD,
                                             config.DB_NAME)
            except pymssql.exceptions.OperationalError as err:
                logger.error(err)

                return
        elif config.DB_DIALECT == 'ORACLE':
            '''
            Supported ORACLE Versions

            https://python-oracledb.readthedocs.io/en/latest/user_guide/installation.html#supported-oracle-database-versions # noqa E501
            '''
            connection = oracledb.connect(user=config.DB_USER,
                                          password=config.DB_PASSWORD,
                                          dsn=config.DB_SERVER)
        elif config.DB_DIALECT == 'POSTGRES':
            connect_obj = dict(
                user=config.DB_USER,
                password=config.DB_PASSWORD,
                host=config.DB_SERVER,
                port=8307,
                dbname=config.DB_NAME)
            connection = psycopg.connect(**connect_obj)

        return connection
