import json
import logging
import sys

from .runner_base import BaseRunner
from .field_mapping_mixin import FieldMappingMixin
from .transform_pipeline_mixin import TransformPipelineMixin
from .data_pusher_mixin import DataPusherMixin
from oaa.settings import config
from oaa import utils
from oaa import oaa_utils
from oaa.models import GeneratorType, VezaObjectType
import petl
from oaaclient.templates import (
    CustomApplication,
    CustomIdPProvider,
    HRISProvider,
    OAAPropertyType,
)
from oaa.utils import simple_jinja_render
from oaa.settings_config import DestinationType

# from oaa.models import DynamicTranformOptions_Enum
from oaa.hooks.decorators import OAAHookEvent, run_hooks
from oaa.hooks.preflight_checks import run_preflights

logger = logging.getLogger(__name__)


class LCMMixin:
    def lcm_create_user(self, **kwargs):
        payload = json.loads(sys.stdin.read())
        user = payload['user']
        action = payload.get('action')
        try:
            results = run_hooks(
                event=OAAHookEvent.LCM_CREATE_USER,
                config=config,
                sources=config.sources,
                provider=self._provider_object,
                user=user,
                action=action,
            )
            print(json.dumps({'success': True, 'results': results}))
            return results
        except Exception as err:
            print(json.dumps({'success': False, 'error': str(err)}))
            raise

    def lcm_modify_user(self, **kwargs):
        payload = json.loads(sys.stdin.read())
        user = payload['user']
        action = payload.get('action')
        try:
            results = run_hooks(
                event=OAAHookEvent.LCM_MODIFY_USER,
                config=config,
                sources=config.sources,
                provider=self._provider_object,
                user=user,
                action=action,
            )
            print(json.dumps({'success': True, 'results': results}))
            return results
        except Exception as err:
            print(json.dumps({'success': False, 'error': str(err)}))
            raise

    def lcm_get_metadata(self, **kwargs):
        results = run_hooks(
            event=OAAHookEvent.LCM_GET_METADATA,
            config=config,
            sources=config.sources,
            provider=self._provider_object,
        )
        meta = results[0] if results else {}
        print(json.dumps(meta))
        return meta

    def lcm_write_back_email(self, **kwargs):
        payload = json.loads(sys.stdin.read())
        entity_id = payload['entity_id']
        email = payload['email']
        attributes = payload.get('attributes', {})
        try:
            results = run_hooks(
                event=OAAHookEvent.LCM_WRITE_BACK_EMAIL,
                config=config,
                sources=config.sources,
                provider=self._provider_object,
                entity_id=entity_id,
                attributes=attributes,
                email=email,
            )
            success = bool(results and results[0])
            print(json.dumps({'success': success}))
            return success
        except Exception as err:
            print(json.dumps({'success': False, 'error': str(err)}))
            raise


class CustomAppRunner(
    DataPusherMixin,
    TransformPipelineMixin,
    FieldMappingMixin,
    LCMMixin,
    BaseRunner,
):
    """
    A Runner for doing pushes of Custom app data to Veza

    If you want to omit custom attributes, even if mapped in the file, pass
    in the argument --do-custom-attributes=False.

    Include --dry-run=True to make this do all of the parsing but not send the
    payload to Veza.

    >>> oaa custom_app --config-file ./path/to/config.yaml run


    """

    runner_type = "Custom"

    def _post_init(
        self,
        *args,
        **kwargs,
    ):

        if not config.valid():
            logger.error("configuration is not valid")
            exit(1)
        else:
            if config.app:
                self._provider_name = config.app.name
                self._datasource_name = (
                    config.app.datasource or f"{config.app.name} Datasource"
                )

        self._provider_objects = {}
        self._datasources = {}
        self._set("provider", None)
        self._set("_created_provider", None)
        self._set("_created_oaa_objects", None)
        self._get_logic_modules()

    def _get_effective_datasource(self, source):
        return source.datasource or config.app.datasource or self._datasource_name

    def preflight(self):
        """
        Run preflight checks.

        This function will run several preflight checks on the configuration.
        It should be a pretty good indication of the readiness of the script to
        run.

        """
        problems = run_preflights(self)
        logger.debug("preflight problems: %s", problems)

    def validate(self, config=None, test_connectivity=False):
        """Validate the configuration file without running a full sync.

        This command validates the config.yaml file by:
        1. Validating the config structure (Pydantic validation)
        2. Checking that custom connection modules can be imported
        3. Running preflight checks
        4. Optionally testing connectivity to data sources

        :param config: Path to the config.yaml file (or use -c/--config)
        :param test_connectivity: If True, test actual connections to dbs/APIs.
                                 Defaults to False for faster validation.
        :returns: Tuple of (is_valid, messages)

        Example:
            oaa custom_app -c ./config.yaml validate

            # With connectivity testing:
            oaa custom_app -c ./config.yaml validate --test_connectivity=True
        """
        from oaa.hooks.preflight_validate import validate_config

        config_file = config or self._config_file_yaml or self._config_file

        is_valid, messages = validate_config(
            config_file, test_connectivity=test_connectivity
        )

        for msg in messages:
            print(msg)

        return is_valid, messages

    def list_datasources(self):
        """List available datasource names as a JSON array.

        Parses config and builds the provider objects without making any
        Veza API calls or requiring credentials. Prints a JSON array of
        datasource name strings to stdout.

        Example:
            oaa custom_app --config-file config.yaml list-datasources
        """
        _original_no_push = self._no_push
        self._no_push = True
        try:
            self._get_or_create_provider(**config.app.model_dump())
            self._run_transforms()
            self._create_oaa_objects()
        finally:
            self._no_push = _original_no_push

        explicit_datasources = {
            source.datasource for source in config.sources.values()
            if source.datasource
        }
        if explicit_datasources:
            names = [n for n in self._provider_objects.keys() if n in explicit_datasources]
        else:
            names = list(self._provider_objects.keys())
        sys.stdout.write(json.dumps(names) + '\n')
        sys.stdout.flush()
        return names

    def run(self, push_to_oaa=True):
        return_value = {"status": True, "report": []}
        try:
            self._get_or_create_provider(**config.app.model_dump())

            self._run_transforms()
            self._create_oaa_objects()

            run_hooks(
                event=OAAHookEvent.RECORD_TRANSFORM,
                config=config,
                sources=config.sources,
                provider=self._provider_object,
            )

            self._hook_post_oaa()

            if config.is_csv_push:
                prepush_responses = run_hooks(
                    event=OAAHookEvent.PRE_PUSH_OAA,
                    config=config,
                    sources=config.sources,
                    provider=self._provider_object,
                )

                do_push = not any((r is False for r in prepush_responses))

                response = None
                datasource_id = None

                if push_to_oaa and do_push:
                    datasource_id, response = self._push_to_oaa()

                run_hooks(
                    event=OAAHookEvent.POST_PUSH_OAA,
                    response=response,
                    config=config,
                    provider=self._provider_object,
                    datasource_id=datasource_id,
                )
            else:
                if self._print_json and self._datasource_filter is None \
                        and len(self._provider_objects) > 1:
                    names = list(self._provider_objects.keys())
                    logger.error(
                        '--print-json with multiple datasources requires '
                        '--datasource. Available: %s. '
                        'Use list-datasources to see all options.',
                        json.dumps(names)
                    )
                    sys.exit(1)

                for ds_name, provider_obj in self._provider_objects.items():
                    if self._datasource_filter and \
                            ds_name != self._datasource_filter:
                        continue

                    prepush_responses = run_hooks(
                        event=OAAHookEvent.PRE_PUSH_OAA,
                        config=config,
                        sources=config.sources,
                        provider=provider_obj,
                    )

                    do_push = not any((r is False for r in prepush_responses))

                    response = None
                    datasource_id = None

                    if push_to_oaa and do_push:
                        datasource_id, response = self._push_single_datasource(
                            ds_name, provider_obj
                        )

                    run_hooks(
                        event=OAAHookEvent.POST_PUSH_OAA,
                        response=response,
                        config=config,
                        provider=provider_obj,
                        datasource_id=datasource_id,
                    )

        except Exception as _err:
            logger.error("error running %s", _err, exc_info=True)
            return_value["status"] = "exception"
            return_value["report"].append(_err)

        if self._print_json:
            return None
        return return_value

    def _hook_post_oaa(self):

        for module in self._get_logic_modules():
            if hasattr(module, "run"):
                module.run(
                    self._provider_object,
                    sources=config.sources,
                    config=config,
                )

    def _run_generators_for_record(self, source, record, primary_obj, provider_obj=None):
        """Create OAA objects from field values on a single source record.

        For each generator defined on the source, reads the source_field value
        from the record and creates (or retrieves) the corresponding OAA object.
        Optionally links the primary OAA object as a member of the generated
        object when add_membership is True.

        Supports ``multi_value=True`` (source_field is a Python list; each
        element is processed independently) and ``create_if_missing=False``
        (link-only mode: look up existing objects, warn and skip if not found).

        Only convert-mode transforms are applied when processing
        generator field_mapping entries.

        :param source: The Source config object containing generators.
        :param record: The current petl Record for this row.
        :param primary_obj: The primary OAA object already created for this
            record (e.g. a LocalUser instance).
        """
        if not source.generators:
            return

        for gen_name, gen in source.generators.items():
            raw_value = record.get(gen.source_field)

            # Normalise to a list of values to process
            if gen.multi_value:
                if isinstance(raw_value, list):
                    values = raw_value
                elif raw_value is None or raw_value == "":
                    values = []
                else:
                    # Scalar found where list expected — wrap it
                    logger.warning(
                        "generator [%s]: multi_value=True but source_field "
                        '"%s" is not a list (got %s) — treating as single '
                        "value",
                        gen_name,
                        gen.source_field,
                        type(raw_value).__name__,
                    )
                    values = [raw_value]
            else:
                values = [raw_value]

            for value in values:
                self._process_single_generator_value(
                    gen_name, gen, value, record, primary_obj, provider_obj
                )

    def _process_single_generator_value(
        self, gen_name, gen, value, record, primary_obj, provider_obj=None
    ):
        """Process one scalar value through a generator.

        Renders templates, resolves or creates the OAA object, assigns
        membership, and applies any generator field_mapping.

        :param gen_name: Generator key name (for logging).
        :param gen: The GeneratorConfig instance.
        :param value: The scalar value extracted from the source field.
        :param record: The current petl Record for this row.
        :param primary_obj: The primary OAA object for membership assignment.
        """
        if gen.skip_empty and (value is None or value == ""):
            logger.debug(
                'generator [%s]: skipping empty value for field "%s"',
                gen_name,
                gen.source_field,
            )
            return

        context = {"value": value, "row": record}
        gen_name_str = simple_jinja_render(gen.name_template, context)
        gen_uid_str = simple_jinja_render(gen.unique_id_template, context)

        if not gen_uid_str:
            logger.warning(
                'generator [%s]: rendered empty unique_id for value "%s" — skipping',
                gen_name,
                value,
            )
            return

        if not gen_name_str:
            # Fall back to uid as name rather than failing entirely
            gen_name_str = gen_uid_str

        generated_obj = self._resolve_generator_obj(
            gen_name, gen, gen_name_str, gen_uid_str, provider_obj
        )
        if generated_obj is None:
            return

        if gen.add_membership:
            self._assign_generator_membership(gen_name, gen, gen_uid_str, primary_obj)

        if gen.field_mapping:
            self._apply_generator_field_mapping(gen, record, generated_obj)

    def _resolve_generator_obj(self, gen_name, gen, gen_name_str, gen_uid_str, provider_obj=None):  # noqa E501
        """Look up or create the OAA object for a generator value.

        When ``create_if_missing=True`` (default), a new object is created if
        one with ``gen_uid_str`` does not yet exist.  When
        ``create_if_missing=False``, an existing object is required — if none
        is found a warning is logged and ``None`` is returned.

        :param gen_name: Generator key name (for logging).
        :param gen: The GeneratorConfig instance.
        :param gen_name_str: Rendered name string for the object.
        :param gen_uid_str: Rendered unique_id string for the object.
        :param provider_obj: The CustomApplication to resolve/create objects on.
        :returns: The resolved OAA object, or None if not found in
            link-only mode.
        """
        if provider_obj is None:
            provider_obj = self._provider_object

        if gen.generator_type == GeneratorType.local_group:
            store = provider_obj.local_groups
            obj = store.get(gen_uid_str)
            if obj is None:
                if not gen.create_if_missing:
                    logger.warning(
                        'generator [%s]: local_group "%s" does not exist '
                        "and create_if_missing=False — skipping",
                        gen_name,
                        gen_uid_str,
                    )
                    return None
                obj = provider_obj.add_local_group(
                    name=gen_name_str,
                    unique_id=gen_uid_str,
                )
            return obj

        elif gen.generator_type == GeneratorType.local_role:
            store = provider_obj.local_roles
            obj = store.get(gen_uid_str)
            if obj is None:
                if not gen.create_if_missing:
                    logger.warning(
                        'generator [%s]: local_role "%s" does not exist '
                        "and create_if_missing=False — skipping",
                        gen_name,
                        gen_uid_str,
                    )
                    return None
                obj = provider_obj.add_local_role(
                    name=gen_name_str,
                    unique_id=gen_uid_str,
                )
            return obj

        return None

    def _assign_generator_membership(self, gen_name, gen, gen_uid_str, primary_obj):
        """Assign the primary OAA object as a member of the generated object.

        :param gen_name: Generator key name (for logging).
        :param gen: The GeneratorConfig instance.
        :param gen_uid_str: unique_id of the generated object.
        :param primary_obj: The primary OAA object to assign membership to.
        """
        if gen.generator_type == GeneratorType.local_group:
            if hasattr(primary_obj, "add_group"):
                primary_obj.add_group(gen_uid_str)
            else:
                logger.debug(
                    "generator [%s]: primary object type %s does not "
                    "support add_group — skipping membership",
                    gen_name,
                    type(primary_obj).__name__,
                )
        elif gen.generator_type == GeneratorType.local_role:
            if hasattr(primary_obj, "add_role"):
                primary_obj.add_role(
                    gen_uid_str,
                    apply_to_application=True,
                )
            else:
                logger.debug(
                    "generator [%s]: primary object type %s does not "
                    "support add_role — skipping membership",
                    gen_name,
                    type(primary_obj).__name__,
                )

    def _apply_generator_field_mapping(self, gen, record, generated_obj):
        """Apply a generator's field_mapping to set properties on the
        generated OAA object using values from the current source record.

        Only convert-mode transforms are applied here; add-mode and
        select-mode transforms are not supported in this context and will
        be logged as a warning.

        :param gen: The GeneratorConfig instance.
        :param record: The current petl Record for this row.
        :param generated_obj: The generated OAA object (LocalGroup or
            LocalRole) to set properties on.
        """
        for mapping_key, field in gen.field_mapping.items():
            source_field = field.source_field or mapping_key
            destination = field.destination_field
            value = record.get(source_field) or ""

            for transform_obj in field.transforms:
                transform = transform_obj.name
                func_obj = utils.transformers.get(transform)

                if not func_obj:
                    continue

                mode = func_obj["mode"]

                if mode == "convert":
                    func = func_obj["func"](options=transform_obj.options)
                    value = func(value, record)
                else:
                    logger.warning(
                        'generator field_mapping [%s]: transform "%s" '
                        'uses mode "%s" which is not supported in a '
                        "generator field_mapping — skipping",
                        mapping_key,
                        transform,
                        mode,
                    )

            if field.is_custom:
                generated_obj.set_property(destination.lower(), value)
            else:
                try:
                    setattr(generated_obj, destination, value)
                except AttributeError:
                    logger.warning(
                        'generator field_mapping: cannot set "%s" on %s',
                        destination,
                        type(generated_obj).__name__,
                    )

    def bundle(self, integration_dir='.', zip=False):
        """Bundle an integration directory for use with the OAA Runner connector.

        Reads requirements.txt (if present) from the integration directory,
        installs all dependencies with ``pip install --no-deps --target ./modules``
        into the integration's ``modules/`` subdirectory, then validates that no
        compiled extensions (.so, .pyd, .dylib) were installed.  Compiled
        extensions are platform-specific and will fail on a different OS/arch
        at connector runtime.

        With ``--zip``, produces a ZIP archive of the integration directory
        (excluding __pycache__, *.pyc, *.dist-info) and prints its base64-encoded
        contents to stdout — ready to paste directly into the connector config as
        ``integration_zip``.

        :param integration_dir: Path to the integration directory (default: .)
        :param zip: If True, produce a base64-encoded ZIP to stdout after bundling

        Example::

            oaa custom_app bundle
            oaa custom_app bundle --integration-dir ./my-integration
            oaa custom_app bundle --zip | pbcopy
        """
        import subprocess
        import zipfile
        import base64
        import tempfile
        from pathlib import Path

        integ_path = Path(integration_dir).resolve()
        modules_dir = integ_path / 'modules'
        requirements_file = integ_path / 'requirements.txt'

        if not integ_path.is_dir():
            print(
                'ERROR: integration directory does not exist: {}'.format(integ_path)
            )
            sys.exit(1)

        # Install dependencies into modules/ if requirements.txt exists
        if requirements_file.exists():
            modules_dir.mkdir(exist_ok=True)
            print('Installing dependencies from requirements.txt into modules/ ...')
            result = subprocess.run(
                [
                    sys.executable, '-m', 'pip', 'install',
                    '--no-deps',
                    '--target', str(modules_dir),
                    '-r', str(requirements_file),
                ],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print('ERROR: pip install failed:')
                print(result.stderr)
                sys.exit(1)
            print(result.stdout.strip())
        else:
            print('No requirements.txt found — skipping dependency install.')

        # Validate: no compiled extensions
        compiled_extensions = ('.so', '.pyd', '.dylib')
        offending = []
        if modules_dir.is_dir():
            for f in modules_dir.rglob('*'):
                if f.suffix in compiled_extensions:
                    offending.append(
                        str(f.relative_to(integ_path))
                    )

        if offending:
            print('ERROR: Compiled extension(s) found in modules/:')
            for path in offending:
                print('  {}'.format(path))
            print(
                'Compiled extensions are platform-specific and cannot be '
                'bundled for the OAA Runner connector.\n'
                'Only pure-Python packages are supported.'
            )
            sys.exit(1)

        print('Bundle validation passed — no compiled extensions found.')

        if not zip:
            print(
                'Integration at {} is ready to zip.'.format(integ_path)
            )
            return

        # Build ZIP, excluding noisy artifacts
        exclude_patterns = {'__pycache__', '.pyc', '.dist-info', '.DS_Store'}

        def _should_exclude(path):
            for part in path.parts:
                if part in exclude_patterns:
                    return True
            return path.suffix == '.pyc'

        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            tmp_path = Path(tmp.name)

        with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(integ_path.rglob('*')):
                rel = f.relative_to(integ_path.parent)
                if _should_exclude(rel):
                    continue
                if f.is_file():
                    zf.write(f, rel)

        encoded = base64.b64encode(tmp_path.read_bytes()).decode('ascii')
        tmp_path.unlink()

        sys.stdout.write(encoded + '\n')
        sys.stdout.flush()

    def show_field_mapping(self):
        for n, s in config.sources.items():
            print("=" * 25)
            print("source", n)
            print("=" * 25)

            for fm, f in s.field_mappings().items():
                print("mapping name: ", fm)
                print("source_field: ", f.source_field or fm)
                print("destination_field: ", f.destination_field)
                print("transforms: ", [t.name for t in f.transforms])
                print("")
                print("-" * 25)

    # Consider caching this method. It's only used once, for now, but it may be
    # called multiple times in the future
    def field_mappings(self, output_format=None, source=None):
        """
        Field Mappings moved to the settings.Source object.
        """

        if isinstance(source, str):
            source = config.sources[source]
        mappings = source.field_mappings()

        if output_format == "table":
            return mappings

        elif output_format == "json":
            return json.dumps(mappings, indent=2)

        return mappings

    def _get_provider_type(self):

        if config.destination_type == DestinationType.CUSTOM_APP:
            return CustomApplication
        elif config.destination_type == DestinationType.IDP:
            return CustomIdPProvider
        elif config.destination_type == DestinationType.HRIS:
            return HRISProvider

        if not config.destination_type:
            return CustomApplication

    def _custom_provider_actions(self, provider_object=None):
        # Multiple types can be added by running `add_idp_type` multiple times
        # with different IdPProviderType enums
        # provider_object.system.add_idp_type(config.IDP_PROVIDER_TYPE)
        pass

    def _create_oaa_objects(self):

        if config.is_csv_push:
            self._set("_created_oaa_objects", False)

            return

        provider_cls = self._get_provider_type()

        for source_name, source in config.sources.items():
            ds_name = self._get_effective_datasource(source)

            if ds_name not in self._provider_objects:
                if ds_name == self._datasource_name:
                    self._provider_objects[ds_name] = self._provider_object
                else:
                    app_kwargs = {
                        k: v for k, v in config.app.model_dump().items()
                        if v and k not in ('datasource', 'options')
                    }
                    new_obj = provider_cls(**app_kwargs)
                    if hasattr(self._provider_object, 'provider'):
                        new_obj.provider = self._provider_object.provider
                    self._provider_objects[ds_name] = new_obj

            provider_obj = self._provider_objects[ds_name]

            responses = run_hooks(
                event=OAAHookEvent.PRE_CREATE_OAA,
                provider=provider_obj,
                config=config,
                sources=config.sources,
                source=source,
            )

            # set do_oaa_create to False if any responses are False
            do_oaa_create = not any((r is False for r in responses))

            # if any((r is False for r in responses)):
            #     do_oaa_create = False

            # if do_create:
            #     self._create_oaa_objects()

            logger.info(
                f"Loading {source.destination} records for {source.source_name}"
            )

            if source.destination != VezaObjectType.none:
                for prop_name, field in source.custom_attrs_map.items():
                    # Map type to an actual type
                    destination = field.destination_field

                    logger.debug("destination: %s", destination)
                    logger.debug("field: %s", field)
                    logger.debug(
                        "creating custom_property %s as type: %s",
                        destination,
                        field.veza_field_type.upper(),
                    )
                    upper_field_type = field.veza_field_type.upper()
                    try:
                        field_type = getattr(OAAPropertyType, upper_field_type)
                    except AttributeError as err:
                        valid_types = [p.name for p in OAAPropertyType]
                        logger.error(err)
                        logger.error(
                            "Invalid custom property type %s:  Must be one of %s",
                            upper_field_type,
                            valid_types,
                        )
                        exit()
                    definer_map = {
                        VezaObjectType.LocalUser: "define_local_user_property",
                        VezaObjectType.LocalGroup: "define_local_group_property",
                        VezaObjectType.LocalRole: "define_local_role_property",
                        VezaObjectType.Resource: "define_resource_property",
                        VezaObjectType.User: "define_user_property",
                        VezaObjectType.Group: "define_group_property",
                        VezaObjectType.Employee: "define_employee_property",
                    }
                    attr = definer_map.get(source.destination)

                    if attr:
                        definer = getattr(
                            provider_obj.property_definitions,
                            definer_map.get(source.destination),
                            None,
                        )

                        if definer:
                            if source.destination == VezaObjectType.Resource:
                                definer(
                                    property_type=field_type,
                                    name=prop_name,
                                    resource_type=source.resource_type,
                                )
                            else:
                                definer(property_type=field_type, name=prop_name)
                            # resource_type=source.resource_type)

            if "row" not in petl.header(source.stream):
                source._stream = source._stream.addrownumbers()

            if source.destination != VezaObjectType.none:
                # import bpdb; bpdb.set_trace()  # noqa: E702

                for r in source.records:
                    logger.debug("%s: working on row %s", source.source_name, r.row)

                    # for f_name in r.flds:
                    #     assert not callable(r[f_name])

                    object_with_required_fields = {}
                    required_fields_tmp = []

                    temp_oaa_obj = None

                    # if source.destination != VezaObjectType.LocalUser:
                    #     import bpdb; bpdb.set_trace()  # noqa: E702

                    # if source.destination != VezaObjectType.none:
                    required_fields_tmp = oaa_utils.REQUIRED_FIELDS[
                        source.destination.name
                    ]  # noqa E501

                    for req_field in required_fields_tmp:
                        # req_field_to_map = req_field

                        if isinstance(req_field, tuple):
                            # one of these fields is required, not both
                            found_in_mapping = 0

                            for f in req_field:
                                if (
                                    f in source.attributes
                                    and source.attributes[f] in r.flds
                                ):  # noqa E501
                                    found_in_mapping += 1
                                    req_field = f

                            if found_in_mapping > len(req_field):
                                logger.error(
                                    "only one of these %s can be mapped",  # noqa E501
                                    req_field,
                                )
                                exit()

                            if found_in_mapping == 0:
                                logger.error("one of %s must be mapped", req_field)  # noqa E501
                                exit()

                        else:
                            if not source.attributes:
                                logger.error(
                                    "something is wrong, source.attributes is empty"
                                )  # noqa E501

                            logger.debug(
                                "attributes in mapping: %s", source.attributes.keys()
                            )

                            req_field_dest = source.attributes.get(req_field)

                            if not req_field_dest:
                                logger.error(
                                    "required field %s is not mapped", req_field
                                )
                                exit()

                            if req_field_dest not in r.flds:
                                # print(source.attributes)
                                logger.error(
                                    "%s not in attributes on record: %s",
                                    req_field_dest,
                                    r.flds,
                                )
                                exit()

                                # exit()
                        object_with_required_fields[req_field] = r[
                            source.attributes[req_field]
                        ]  # noqa E501

                    if do_oaa_create:
                        # change this based on the source.destination

                        if source.destination == VezaObjectType.LocalUser:
                            # print(object_with_required_fields)
                            user_id = object_with_required_fields["unique_id"]
                            temp_oaa_obj = provider_obj.local_users.get(
                                user_id
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = provider_obj.add_local_user(
                                    **object_with_required_fields
                                )  # noqa E501
                            # required_fields = oaa_utils.REQUIRED_FIELDS['LocalUser']
                        elif source.destination == VezaObjectType.User:
                            user_id = object_with_required_fields["identity"]
                            temp_oaa_obj = provider_obj.users.get(user_id)

                            if not temp_oaa_obj:
                                # import bpdb; po = self._provider_object; bpdb.set_trace()  # noqa: E702
                                temp_oaa_obj = provider_obj.add_user(
                                    **object_with_required_fields
                                )  # noqa E501
                        elif source.destination == VezaObjectType.Group:
                            temp_oaa_obj = provider_obj.groups.get(
                                object_with_required_fields["unique_id"]
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = provider_obj.add_group(
                                    **object_with_required_fields
                                )  # noqa E501
                                # import bpdb; bpdb.set_trace()  # noqa: E702
                            # required_fields = oaa_utils.REQUIRED_FIELDS['LocalUser']

                        elif source.destination == VezaObjectType.LocalGroup:
                            temp_oaa_obj = provider_obj.local_groups.get(
                                object_with_required_fields["unique_id"]
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = provider_obj.add_local_group(
                                    **object_with_required_fields
                                )  # noqa E501
                                # import bpdb; bpdb.set_trace()  # noqa: E702
                            # required_fields = oaa_utils.REQUIRED_FIELDS['LocalUser']
                        elif source.destination == VezaObjectType.Employee:
                            if (
                                object_with_required_fields["unique_id"]
                                not in provider_obj.employees
                            ):
                                # print(object_with_required_fields)
                                # import bpdb; bpdb.set_trace()  # noqa: E702
                                temp_oaa_obj = provider_obj.add_employee(
                                    **object_with_required_fields
                                )  # noqa E501

                        elif source.destination == VezaObjectType.LocalRole:
                            if (
                                object_with_required_fields["unique_id"]
                                not in provider_obj.local_roles
                            ):
                                temp_oaa_obj = provider_obj.add_local_role(
                                    **object_with_required_fields
                                )  # noqa E501
                        elif source.destination == VezaObjectType.Resource:
                            if (
                                object_with_required_fields["unique_id"]
                                not in provider_obj.resources
                            ):
                                temp_oaa_obj = provider_obj.add_resource(
                                    resource_type=source.resource_type,
                                    **object_with_required_fields,
                                )  # noqa E501
                        # Add other attributes

                        # These are those not already added as required
                        filtered_fields = filter(
                            lambda f: f not in required_fields_tmp, source.attributes
                        )  # noqa E501

                        if temp_oaa_obj:
                            for update_field in filtered_fields:
                                attr_source = source.attributes[update_field]

                                setattr(temp_oaa_obj, update_field, r[attr_source])

                            # custom properties are set using the `set_property` method
                            # with the name of the property and value

                            for property_name, f in source.custom_attrs_map.items():
                                source_field = f.source_field or f.destination_field

                                if r.get(source_field) in [None, ""]:
                                    logger.debug(
                                        "field [%s] is blank on %s", source_field, r.row
                                    )
                                else:
                                    logger.debug(
                                        "adding %s=%s to object [%s]",
                                        source_field,
                                        r[source_field],
                                        r.row,
                                    )

                                    temp_oaa_obj.set_property(
                                        property_name.lower(), r[source_field]
                                    )  # noqa E501

                        # Run generators: create OAA objects from field
                        # values and optionally assign membership
                        if source.generators and temp_oaa_obj:
                            self._run_generators_for_record(
                                source, r, temp_oaa_obj, provider_obj
                            )

            logger.info(
                f"Finished loading {source.destination} for {source.source_name}"
            )
