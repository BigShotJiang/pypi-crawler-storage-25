import logging
import petl

from oaaclient.templates import (
    CustomApplication,
    CustomIdPProvider,
    HRISProvider,
    OAAPropertyType,
)
from oaa import oaa_utils
from oaa.hooks.decorators import OAAHookEvent, run_hooks
from oaa.models import VezaObjectType
from oaa.settings import config
from oaa.config import DestinationType

logger = logging.getLogger(__name__)


class DataPusherMixin:

    def _get_provider_type(self):
        """Return the OAA provider class to instantiate based on destination_type config."""
        if config.destination_type == DestinationType.CUSTOM_APP:
            return CustomApplication
        elif config.destination_type == DestinationType.IDP:
            return CustomIdPProvider
        elif config.destination_type == DestinationType.HRIS:
            return HRISProvider

        if not config.destination_type:
            return CustomApplication

    def _custom_provider_actions(self, provider_object=None):
        """Hook for subclasses to apply extra actions to the provider before push. No-op by default."""
        pass

    def _create_oaa_objects(self):
        """Create OAA user/group/resource objects on the provider from source records."""
        if config.is_csv_push:
            self._set('_created_oaa_objects', False)

            return

        for source_name, source in config.sources.items():
            responses = run_hooks(
                event=OAAHookEvent.PRE_CREATE_OAA,
                provider=self._provider_object,
                config=config,
                sources=config.sources,
                source=source,
            )

            do_oaa_create = not any((r is False for r in responses))

            logger.info(
                f'Loading {source.destination} records for {source.source_name}'
            )

            if source.destination != VezaObjectType.none:
                for prop_name, field in source.custom_attrs_map.items():
                    destination = field.destination_field

                    logger.debug('destination: %s', destination)
                    logger.debug('field: %s', field)
                    logger.debug(
                        'creating custom_property %s as type: %s',
                        destination,
                        field.veza_field_type.upper(),
                    )
                    upper_field_type = field.veza_field_type.upper()
                    try:
                        field_type = getattr(OAAPropertyType, upper_field_type)
                    except AttributeError as err:
                        valid_types = [p.name for p in OAAPropertyType]
                        logger.error(err)
                        logger.error(
                            'Invalid custom property type %s:  Must be one of %s',
                            upper_field_type,
                            valid_types,
                        )
                        exit()
                    definer_map = {
                        VezaObjectType.LocalUser: 'define_local_user_property',
                        VezaObjectType.LocalGroup: 'define_local_group_property',
                        VezaObjectType.LocalRole: 'define_local_role_property',
                        VezaObjectType.Resource: 'define_resource_property',
                        VezaObjectType.User: 'define_user_property',
                        VezaObjectType.Group: 'define_group_property',
                        VezaObjectType.Employee: 'define_employee_property',
                    }
                    attr = definer_map.get(source.destination)

                    if attr:
                        definer = getattr(
                            self._provider_object.property_definitions,
                            definer_map.get(source.destination),
                            None,
                        )

                        if definer:
                            if source.destination == VezaObjectType.Resource:
                                definer(
                                    property_type=field_type,
                                    name=prop_name,
                                    resource_type=source.resource_type,
                                )
                            else:
                                definer(property_type=field_type, name=prop_name)

            if 'row' not in petl.header(source.stream):
                source._stream = source._stream.addrownumbers()

            if source.destination != VezaObjectType.none:
                for r in source.records:
                    logger.debug(
                        '%s: working on row %s', source.source_name, r.row
                    )

                    object_with_required_fields = {}
                    required_fields_tmp = []
                    temp_oaa_obj = None

                    required_fields_tmp = oaa_utils.REQUIRED_FIELDS[
                        source.destination.name
                    ]

                    for req_field in required_fields_tmp:
                        if isinstance(req_field, tuple):
                            found_in_mapping = 0

                            for f in req_field:
                                if (
                                    f in source.attributes
                                    and source.attributes[f] in r.flds
                                ):
                                    found_in_mapping += 1
                                    req_field = f

                            if found_in_mapping > len(req_field):
                                logger.error(
                                    'only one of these %s can be mapped',
                                    req_field,
                                )
                                exit()

                            if found_in_mapping == 0:
                                logger.error(
                                    'one of %s must be mapped', req_field
                                )
                                exit()

                        else:
                            if not source.attributes:
                                logger.error(
                                    'something is wrong, source.attributes is empty'
                                )

                            logger.debug(
                                'attributes in mapping: %s',
                                source.attributes.keys(),
                            )

                            req_field_dest = source.attributes.get(req_field)

                            if not req_field_dest:
                                logger.error(
                                    'required field %s is not mapped', req_field
                                )
                                exit()

                            if req_field_dest not in r.flds:
                                logger.error(
                                    '%s not in attributes on record: %s',
                                    req_field_dest,
                                    r.flds,
                                )
                                exit()

                        object_with_required_fields[req_field] = r[
                            source.attributes[req_field]
                        ]

                    if do_oaa_create:
                        if source.destination == VezaObjectType.LocalUser:
                            user_id = object_with_required_fields['unique_id']
                            temp_oaa_obj = self._provider_object.local_users.get(
                                user_id
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = self._provider_object.add_local_user(
                                    **object_with_required_fields
                                )
                        elif source.destination == VezaObjectType.User:
                            user_id = object_with_required_fields['identity']
                            temp_oaa_obj = self._provider_object.users.get(user_id)

                            if not temp_oaa_obj:
                                temp_oaa_obj = self._provider_object.add_user(
                                    **object_with_required_fields
                                )
                        elif source.destination == VezaObjectType.Group:
                            temp_oaa_obj = self._provider_object.groups.get(
                                object_with_required_fields['unique_id']
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = self._provider_object.add_group(
                                    **object_with_required_fields
                                )

                        elif source.destination == VezaObjectType.LocalGroup:
                            temp_oaa_obj = self._provider_object.local_groups.get(
                                object_with_required_fields['unique_id']
                            )

                            if not temp_oaa_obj:
                                temp_oaa_obj = self._provider_object.add_local_group(
                                    **object_with_required_fields
                                )
                        elif source.destination == VezaObjectType.Employee:
                            if (
                                object_with_required_fields['unique_id']
                                not in self._provider_object.employees
                            ):
                                temp_oaa_obj = self._provider_object.add_employee(
                                    **object_with_required_fields
                                )

                        elif source.destination == VezaObjectType.LocalRole:
                            if (
                                object_with_required_fields['unique_id']
                                not in self._provider_object.local_roles
                            ):
                                temp_oaa_obj = self._provider_object.add_local_role(
                                    **object_with_required_fields
                                )
                        elif source.destination == VezaObjectType.Resource:
                            if (
                                object_with_required_fields['unique_id']
                                not in self._provider_object.resources
                            ):
                                temp_oaa_obj = self._provider_object.add_resource(
                                    resource_type=source.resource_type,
                                    **object_with_required_fields,
                                )

                        filtered_fields = filter(
                            lambda f: f not in required_fields_tmp,
                            source.attributes,
                        )

                        if temp_oaa_obj:
                            for update_field in filtered_fields:
                                attr_source = source.attributes[update_field]
                                setattr(
                                    temp_oaa_obj, update_field, r[attr_source]
                                )

                            for property_name, f in source.custom_attrs_map.items():
                                source_field = f.source_field or f.destination_field

                                if r.get(source_field) in [None, '']:
                                    logger.debug(
                                        'field [%s] is blank on %s',
                                        source_field,
                                        r.row,
                                    )
                                else:
                                    logger.debug(
                                        'adding %s=%s to object [%s]',
                                        source_field,
                                        r[source_field],
                                        r.row,
                                    )

                                    temp_oaa_obj.set_property(
                                        property_name.lower(), r[source_field]
                                    )

            logger.info(
                f'Finished loading {source.destination} for {source.source_name}'
            )
