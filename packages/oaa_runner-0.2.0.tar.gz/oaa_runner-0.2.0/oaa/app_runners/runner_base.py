import sys
import os
import json
from datetime import datetime
from pathlib import Path

import petl
from oaaclient.templates import OAAPropertyType
from oaa import utils
from oaa import oaa_utils
from oaa.config import DestinationType, App
from oaa.settings import config
from oaa.utils import jinja_env

from oaa.models import FieldMapping
import logging

from .hook_executor_mixin import HookExecutorMixin
from .provider_manager_mixin import ProviderManagerMixin

# Make the help output directly to the screen rather than getting stuck in a
# pager. See https://stackoverflow.com/questions/58299680/help-gets-stuck-in-command-line-for-fire-module
os.environ['PAGER'] = 'cat'

logger = logging.getLogger(__name__)
petl.config.failonerror = True

# -----


class BaseRunner(ProviderManagerMixin, HookExecutorMixin):
    ''' We create a base runner class so that we can re-use logic that is
    shared across the different types.
    '''
    source_type = None

    def __init__(self,
                 dry_run=False,
                 do_custom_attributes=True,
                 save_json=False,  # whether to save a local copy of
                                   # the payload on push
                 no_push=False,    # skip all Veza API calls entirely
                 print_json=False,  # print OAA payload JSON to stdout
                 datasource=None,  # filter run to a single datasource
                 config_file=None,
                 config_file_yaml=None,
                 config_content=None,
                 config_url=None,
                 priority_push=False,
                 # env_file=None,
                 **kwargs
                 ):
        self.__kwargs = kwargs

        self._config_file = config_file
        self._config_file_yaml = config_file_yaml
        self._config_content = config_content
        self._config_url = config_url
        self._priority_push = priority_push

        if self._config_file:
            config.update(config_file=self._config_file,
                          source_type=self.source_type)

        if self._config_content:
            config.update(config_content=self._config_content,
                          source_type=self.source_type)

        if self._config_url:
            config.update(config_url=self._config_url,
                          source_type=self.source_type)

        if self._config_file_yaml:
            config.update(config_file=self._config_file_yaml,
                          config_format='yaml',
                          source_type=self.source_type)

        self._dry_run = dry_run
        self._do_custom_attributes = do_custom_attributes
        self._save_json = save_json
        self._no_push = no_push
        self._print_json = print_json
        self._datasource_filter = datasource
        self._printed_datasources = set()

        import logging as _logging
        for handler in _logging.root.handlers:
            if hasattr(handler, 'stream') and handler.stream is sys.stdout:
                handler.stream = sys.stderr

        if not config:
            logger.error('configuration is not valid')

        self._attributes = {}
        self._custom_attrs_map = {}
        self.oaa = oaa_utils.FUNCS
        self._provider_object = None
        self._storage = {}
        self._datasource_name = None
        self._datasource = None

        self._post_init()

    def _get(self, key, default=None):
        return self._storage.get(key, default)

    def _set(self, key, value):
        self._storage[key] = value

    def _post_init(self, *args, **kwargs):
        pass

    def _get_provider_type(self):
        '''Implement this methods to return the provider class to use when
        creating the provider here.
        '''
        raise NotImplementedError

    def _custom_provider_actions(self, provider_object=None):
        '''Action to take on the provider after the object is instantiated,
        before it is sent to Veza.
        '''
        raise NotImplementedError

    def utils(self):
        '''
        List utility functions.

        These functions are those that are available as transforms in the
        mapping document.
        '''

        return utils.transformers

    def show_config(self):

        return config._CONFIG.model_dump_json(indent=2)

    # Consider caching this method. It's only used once, for now, but it may be
    # called multiple times in the future
    def field_mappings(self,
                       output_format=None,
                       field_mapping_filepath=None):
        '''
        Field Mappings

        View all of the current field mappings. This output of this function
        defaults to json. If pass --output=table then it will output it in a
        text table. The output is really wide, especially when there are long
        notes or field_options, so I'm not really sure how useful it is.

        ¯\\_(ツ)_/¯

        '''
        mappings = {}

        if not field_mapping_filepath:
            field_mapping_filepath = config.SOURCE_MAPPING_FILEPATH

        fields = petl.fromcsv(config.SOURCE_MAPPING_FILEPATH)

        for idx, field in enumerate(fields.dicts()):

            ctx = {'row_num': idx+1}
            field = FieldMapping.model_validate(field,
                                                context=ctx).model_dump()

            mappings[field['source_field'] or field['destination_field']] = field  # noqa E501

        if output_format == 'table':

            return fields.look(200)

        elif output_format == 'json':

            return json.dumps(mappings, indent=2)

        return mappings

    def gen_config(self, app_name, num_sources=5):
        template = jinja_env.get_template('sample_config.yaml')

        context = {
            'app_name': app_name,
            'num_sources': num_sources,
            'os': os
        }

        return template.render(**context)

    def gen_oaa(self, app_name, num_sources=5, folder_location=None, **kwargs):

        project_dir = Path(
            folder_location or self.__kwargs.get(
                'folder_location', Path(os.getcwd())
            )
        )

        logger.info('project folder %s', project_dir)
        templates = [
            ('README.md', f'{app_name}/README.md'),
            ('sample_config.yaml', f'{app_name}/config.yaml'),
            ('sample.env', f'{app_name}/sample.env'),
            ('requirements.txt', f'{app_name}/requirements.txt'),
            ('modules/appname.py', f'{app_name}/modules/{app_name}.py'),
            ('modules/appname_hooks.py',
             f'{app_name}/modules/{app_name}_hooks.py'),
            ('modules/appname_mocks.py',
             f'{app_name}/modules/{app_name}_mocks.py')
        ]

        context = {
            'app_name': app_name,
            'num_sources': num_sources,
            'os': os
        }
        try:
            for t, destination in templates:

                destination = project_dir / destination
                Path(os.path.dirname(destination)).mkdir(
                    parents=True, exist_ok=True
                )
                logger.info('creating: %s', destination)
                with open(destination, 'w+') as f:
                    f.write(jinja_env.get_template(t).render(**context))

        except OSError as e:
            logger.error(
                'Failed to create oaa project: %s', e, exc_info=True
            )

        return 'Done!'

    def _create_oaa_objects(self, table):
        """Create the OAA objects. Every runner needs to define this."""
        logger.info('Starting submission, provider name '
                    f'{self._provider_object.name}')

        for prop_name, field in self._custom_attrs_map.items():

            destination = field['destination_field']

            logger.debug('destination: %s', destination)
            logger.debug('field: %s', field)
            logger.debug('creating custom_property %s as type: %s',
                         destination, field['veza_field_type'].upper())
            upper_field_type = field['veza_field_type'].upper()
            try:
                field_type = getattr(OAAPropertyType, upper_field_type)
            except AttributeError as err:

                valid_types = [p.name for p in OAAPropertyType]
                logger.error(err)
                logger.error('Invalid custom property type %s:  '
                             'Must be one of %s',
                             upper_field_type,
                             valid_types)
                exit()
            self._provider_object.property_definitions.define_employee_property(  # noqa E501
                prop_name, field_type
            )
        self._create_oaa_objects_custom(table)

    def _create_oaa_objects_custom(self, table):
        raise NotImplementedError
