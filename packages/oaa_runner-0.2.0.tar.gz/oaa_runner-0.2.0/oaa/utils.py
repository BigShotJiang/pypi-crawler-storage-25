"""
Data transformation utilities for OAA Runner.

This module provides the transformer registry and all built-in transform
functions used in field_mapping pipelines (e.g. date_convert, email_convert,
lowercase, jinja_render). It also contains validation helpers for logic
modules (validate_logic_module) and fetch modules (validate_fetch_module).

The ``FUNCS`` dict maps transform name strings (as used in config.yaml) to
their callable implementations and is the primary lookup table used by the
transform pipeline at runtime.
"""
import os
import hashlib
import re
import inspect
import logging
import json

# import petl
from datetime import datetime, date
from functools import wraps
from email_validator import validate_email, EmailNotValidError
from dateutil import parser as date_parser
from datetime import timezone
from jinja2 import Environment, BaseLoader, FileSystemLoader

# jinja_env = Environment(loader=BaseLoader())
# jinja_env = Environment(loader=BaseLoader())

from pathlib import Path

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))

jinja_env = Environment(loader=FileSystemLoader([BASE_DIR / "templates"]))

# from oaa.settings import config
logger = logging.getLogger(__name__)

# pattern for NON_NUMBERS
NON_NUMBER = re.compile(r"[^0-9]+")

VALID_BOOL_VALUES = {
    'true': (
        'true',
        True,
        'yes',
        'Yes',
        'y',
        '1',
        'active',
        'enabled',
        'TRUE'
    ),
    'false': (
        'false',
        False,
        'inactive',
        'disabled'
        '0',
        'f',
        'no',
        'No',
        'n',
        'FALSE'
    )
}
transformers = {}


def transformer(*args, mode="convert", has_inner=True, **kwargs):
    """Register a function as a named transform in the ``transformers`` registry.

    Supports two usage styles via ``has_inner``:

    - ``has_inner=True`` (default): the decorated function is a **factory** — it
      receives options at decoration time and must return an inner callable that
      performs the actual conversion. Used by transforms that need configuration
      (e.g. ``date_convert``, ``jinja_render``).

    - ``has_inner=False``: the decorated function **is** the transform — it takes
      a value directly and returns the converted value. Prefer
      ``@transformer_simple`` for this style.

    The ``mode`` parameter controls how petl applies the transform:

    - ``"convert"`` — ``petl.convert(fieldname, func)``
    - ``"add"``     — ``petl.addfield(fieldname, func)``
    - ``"select"``  — ``petl.select(fieldname, func)``

    .. note::
        This decorator handles being called with or without parentheses
        (``@transformer`` vs ``@transformer(mode="add")``) via a callable-check
        hack: if the first positional argument is itself callable, it was used as
        a bare decorator; otherwise it was called as a factory. This is a known
        but messy Python pattern. If the decorator machinery here is confusing,
        prefer adding new simple transforms with ``@transformer_simple`` and
        factory transforms with ``@transformer(mode=...)`` (always with parens).
    """

    def decorator(func):

        @wraps(func)
        def wrapper(*args2, **kwargs2):
            if has_inner:
                # Factory style: pass args/kwargs through to the decorated
                # function so it can configure itself and return an inner callable.
                return func(*args2, **kwargs2)

            # Simple style: wrap the function so that when called with options
            # (e.g. func(options={})) it returns an inner(value) callable that
            # closes over those options. This lets the transform pipeline call
            # func(options=...) uniformly regardless of style.
            def inner(value, *args3, **kwargs3):
                return func(value, *args3, **{**kwargs2, **kwargs3})

            return inner

        transformers[func.__name__] = {"func": wrapper, "mode": mode}

        return wrapper

    if args:
        function = args[0]

        if callable(function):
            # Called as a bare decorator (@transformer with no parens).
            # The decorated function is args[0], so apply decorator directly.
            return decorator(function)

    # Called as a decorator factory (@transformer(...) with parens).
    # Return the decorator so Python can apply it to the function next.
    return decorator


def transformer_simple(*args, mode="convert", **kwargs):
    """Shorthand for ``@transformer(has_inner=False)``.

    Use this for transforms that take a value directly and return a converted
    value, with no need for an options-factory step. Equivalent to::

        @transformer(mode=mode, has_inner=False)
        def my_transform(value, *args, **kwargs):
            ...
    """
    return transformer(*args, mode=mode, has_inner=False, **kwargs)


@transformer_simple
def make_hash(value, *args, **kwargs):
    """
    This transform will hash the value for security:

    .. code:: yaml

        transforms:
          - name: make_hash

    """

    if value is not None:
        return hashlib.sha256(str(value).encode("utf-8")).hexdigest()

    return value


@transformer_simple
def to_string(value, *args, **kwargs):

    if value is not None:
        return str(value)

    return value


@transformer_simple
def static_value(value, *args, **kwargs):

    if value is not None:
        return str(value) 

    return value


# def date_convert(fieldname, self, *args, **kwargs):
@transformer(has_inner=True)
def date_convert(**kwargs):
    options = kwargs.get("options")  # noqa F841

    def inner(value, *args, **kwargs):
        """My schema had the date fields already mapped as data types. I need
        to ask if they are that way in their system.
        """

        # works
        # return '2023-04-12T15:34:56.123456789Z'

        # if value is None:
        #     logger.debug('fieldname %s: (%s) is null', fieldname, value)

        #     return ''

        # if not value:
        #     import bpdb; bpdb.set_trace()  # noqa: E702

        if isinstance(value, str):
            value = value.strip()

        if not value:
            return value

        if type(value) not in (date, datetime):
            # Try parsing it
            value = date_parser.parse(value)

            if type(value) not in (date, datetime):
                logger.warning(
                    "Invalid date value: %s, %s - returning blank", value, type(value)
                )

                return ""

        # Add time to the date if it isn't a datetime
        # Note: don't test if is date instance, datetime is a subclass of date

        if not isinstance(value, datetime):
            value = datetime.combine(value, datetime.min.time())
            # 2006-01-02T15:04:05Z07:00

        if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
            # datetimes is naive, add timezone=UTC
            value = value.replace(tzinfo=timezone.utc)

        # new_value = f"{value.isoformat()}{config.OAA_TIME_ZONE}"
        # logger.debug('%s converted to string %s', value, new_value)

        # convert '+00:00' to 'Z' Is this really necessary?

        return value.isoformat().replace("+00:00", "Z")

    return inner


@transformer_simple
def epoch_ms_to_iso(value, *args, **kwargs):
    """Convert a Unix epoch-millisecond integer to an ISO 8601 UTC string."""
    if value is None:
        return None
    return (
        datetime.fromtimestamp(int(value) / 1000, tz=timezone.utc)
        .isoformat()
        .replace('+00:00', 'Z')
    )


@transformer_simple
def email_convert(email, *args, **kwargs):
    """The value can be either null or a valid email address. Log an error if
    value is invalid email.
    """

    try:
        # Check that the email address is valid. Turn on check_deliverability
        # for first-time validations like on account creation pages (but not
        # login pages).
        emailinfo = validate_email(email, check_deliverability=False)

        # After this point, use only the normalized form of the email address,
        # especially before going to a database query.

        # if email == 'KAJIGGA@gmail.com':
        #     import bpdb; bpdb.set_trace()  # noqa: E702
        email = emailinfo.normalized.lower()

    except EmailNotValidError as e:
        # The exception message is human-readable explanation of why it's
        # not a valid (or deliverable) email address.

        if email in (None, "null"):
            email = ""
        else:
            logger.warning("%s", e)

    return email


@transformer_simple
def remove_diacritic(value):
    """Pass-through placeholder; diacritic removal is not yet implemented."""
    return value


@transformer_simple
def make_number(value, *args, **kwargs):
    """Format the value as only digits, stripping everything else out."""

    return int(NON_NUMBER.sub("", str(value)))


@transformer(has_inner=True)
def replace(*args, options={}, **kwargs):
    string = options["options"]["string"]

    def inner(value, rec=None):
        if isinstance(value, str):
            return value.replace(string)

        return value

    return inner


@transformer(has_inner=True)
def join_fields(*args, options=None, **kwargs):
    options = options or {}

    join_char, fields_to_join = options["options"]  # noqa E501

    def inner(value, rec):
        """Inner function to do join_fields with context

        :value: current value of field, not used when joining fields
        :rec: the current record. the fields_to_join should be there
        :returns: string

        """

        # all of the values in fields_to_join must be strings and they must
        # exist in the record.

        for f in fields_to_join:
            if f not in rec.flds:
                logger.error(
                    f"the field {f} is not a valid field. The record"
                    f" only has the following fields {rec.flds}"
                    " available"
                )

        # valid_fields = list(filter(lambda f: bool(f), fields_to_join))

        return_value = join_char.join(
            [rec[f] for f in filter(lambda f: bool(f), fields_to_join)]
        )  # noqa E501

        return return_value

    return inner


def simple_jinja_render(template_str, context={}):
    """Render a Jinja2 template string with a context dict. Returns the rendered string."""
    template = jinja_env.from_string(template_str)

    return template.render(**context)


@transformer(mode="add", has_inner=True)
def jinja_render(*args, options=None, **kwargs):
    """Add a new field by rendering a Jinja2 template; the full record is available as `row`."""
    options = options or {}

    if isinstance(options, dict):
        template_str = options["template"]
    else:
        template_str = options
    try:
        template = jinja_env.from_string(template_str)

        def inner(rec):

            val = template.render(row=rec)
            # import bpdb; bpdb.set_trace()  # noqa: E702

            return val

    except TypeError as err:
        logger.error(err)
        logger.error("cannot compile the template: [%s]", template_str)
        # import bpdb; bpdb.set_trace()  # noqa: E702

        def inner(rec):
            raise Exception("cannot compile template [%s]", template_str)

    return inner


@transformer(mode="convert", has_inner=True)
def jinja_render_convert(*args, options=None, **kwargs):
    """Convert a field value by rendering it through a Jinja2 template with the record as `row`."""
    options = options or {}

    if isinstance(options, dict):
        template_str = options["template"]
    else:
        template_str = options
    template = jinja_env.from_string(template_str)

    def inner(value, rec):
        return template.render(row=rec, value=value)

    return inner


@transformer(mode="add", has_inner=True)
def join_fields_add(options=None, **kwargs):
    """Add a new field by joining multiple existing fields with a delimiter."""
    options = options or {}
    join_char, fields_to_join = options["options"]

    def inner(rec):

        joined_value = join_char.join([rec[f] for f in fields_to_join])

        return joined_value

    return inner


@transformer
def validate_boolean(*args, **kwargs):
    def inner(value, *args, **kwargs):

        # import bpdb; bpdb.set_trace()  # noqa: E702
        # print('value', value)
        # ret_value = None

        # if type(value) in (int, str):
        #     value = value.lower()
        #     ret_value = value

        #     if value in VALID_BOOL_VALUES['true']:
        #         ret_value = True

        #     elif value in VALID_BOOL_VALUES['false']:

        #         ret_value = False
        #     else:

        #         ret_value = False
        #         logger.error('%s is not a valid option for a boolean field', value)

        # elif isinstance(value, bool):
        #     ret_value = value

        # assert isinstance(ret_value, bool)

        return value in VALID_BOOL_VALUES["true"]

    return inner


@transformer(has_inner=True)
def maybe_length(options=None, *args, **kwargs):
    if not options:
        options = {}
    length = int(options["options"])  # noqa E501

    def inner(value):
        return value

    return inner


@transformer(mode="add", has_inner=True)
def pull_from(*args, options=None, **kwargs):
    """Add a new field by copying the value from another field in the record."""
    options = options or {}

    field_to_pull = options.get("options", options.get("pull_from", ""))

    def inner(rec):

        return rec.get(field_to_pull)

    return inner


@transformer(has_inner=True)
def lookup(options=None, **kwargs):
    """Map a field value through a lookup table; returns the original value if not found."""
    options = options or {}
    lookup_table = options.get("lookup", options)

    def inner(value, rec, *args, **kwargs):
        # return the same value without converting it?
        if lookup_table is None:
            return value

        return lookup_table.get(value, value)

    return inner


@transformer(mode="add", has_inner=True)
def pull_from_lookup(*args, options=None, **kwargs):
    """Add a new field by pulling a value from another field and mapping it through a lookup table."""
    # func = func(_options['pull_from'], _options['lookup'])
    field_to_pull = options["pull_from"]
    lookup_table = options["lookup"]
    # import bpdb; bpdb.set_trace()  # noqa: E702

    def inner(rec):
        temp_options = {"options": field_to_pull}
        # import bpdb; bpdb.set_trace()  # noqa: E702
        value = str(pull_from(options=temp_options)(rec))
        value = lookup(lookup_table)(value.lower())

        return value

    return inner


@transformer(mode="select", has_inner=True)
def filter_by_field(options):
    """Keep only records where the field value matches one of the allowed options."""
    filter_options = [f.strip() for f in options["options"].split(",")]  # noqa E501

    def inner(value):
        if options:
            return value in filter_options

        return True

    return inner


def util_null_to_blank(value):
    if value is None:
        return ""

    return value


@transformer_simple
def null_to_blank(value, *args, **kwargs):
    return util_null_to_blank(value)


@transformer_simple
def ignore(value, *args, **kwargs):
    return value


@transformer_simple
def none(value, *args, **kwargs):
    return value


@transformer_simple
def lowercase(value, *args, **kwargs):
    # import bpdb; bpdb.set_trace()  # noqa: E702

    return value.lower()


@transformer_simple
def dummy_permission(value, *args, **kwargs):
    from oaaclient.templates import OAAPermission

    print(value, args, kwargs)
    return OAAPermission.DataCreate


@transformer_simple
def debug(value, *args, **kwargs):
    print(value, args, kwargs)

    return value


@transformer_simple
def listify(value, *args, **kwargs):
    if value is None or value == '':
        return []
    options = kwargs.get('options') or {}
    delimiter = options.get('delimiter')
    identity_type = options.get('identity_type')
    if delimiter and isinstance(value, str):
        values = [v.strip() for v in value.split(delimiter) if v.strip()]
        if identity_type:
            return [{identity_type: v} for v in values]
        return values
    if isinstance(value, list):
        if identity_type:
            return [{identity_type: v} for v in value]
        return value
    if isinstance(value, int):
        value = str(value)
    if identity_type:
        return [{identity_type: value}]
    return [value]


# full_func_list = locals()
# FUNCS = {func:func for func in transformers}  # noqa E501
FUNCS = transformers

LOGIC_MODULE_ARGS = ["provider", "sources", "config"]
FETCH_MODULE_ARGS = ['connection', 'source']


def validate_fetch_module(module):
    """Validate that a module implements the fetch() interface.

    :param module: Imported Python module
    :returns: True if valid
    :raises AssertionError: with a descriptive message if invalid
    """
    assert hasattr(module, 'fetch'), (
        f'Module "{module.__name__}" is missing a fetch() function. '
        f'Custom modules must implement fetch(connection, source, **kwargs).'
    )
    argsinfo = inspect.getfullargspec(module.fetch)
    missing = [arg for arg in FETCH_MODULE_ARGS if arg not in argsinfo.args]
    assert not missing, (
        f'Module "{module.__name__}" fetch() is missing required parameters: '
        f'{missing}. Expected signature: fetch(connection, source, **kwargs).'
    )
    return True


def validate_logic_module(custom_module):
    """Validate that a module implements the hook or run(provider, sources, config) interface."""
    if hasattr(custom_module, "hook"):
        return True

    assert hasattr(custom_module, "run")
    argsinfo = inspect.getfullargspec(custom_module.run)

    args_good = all(map(lambda f: f in argsinfo.args, LOGIC_MODULE_ARGS))

    return args_good


def json_print(obj):
    print(json.dumps(obj, indent=2))
    # return json.dumps(obj, indent=2)


# Backward compatibility: Import BaseURLSession from modules
# (The canonical implementation is in oaa.modules.base_url_session)
from oaa.modules.base_url_session import BaseURLSession  # noqa: F401
