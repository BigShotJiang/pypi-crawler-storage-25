#!/usr/bin/env python
# -*- coding: utf-8 -*-

import fire
import logging
import sys
from importlib.metadata import version, PackageNotFoundError

# from pathlib import Path

# utils.py contains field transform functions
# oaa_utils.py contains functions specifically related to oaa
# cli_runner.py is the CLI logic
# from . import cli_runner
# from oaa.app_runners.hris_single_source import HRISRunner
# from oaa.app_runners.idp_runner import IdPRunner
from oaa.app_runners.custom_app import CustomAppRunner
from oaa.hooks.preflight_validate import validate_config as _validate_config
from . import oaa_utils

logger = logging.getLogger(__name__)

# Set the Provider Type to link HRIS employees to. This should be the type of
# the primary IdP for the environment
# Current Options include:
# ACTIVE_DIRECTORY
# ANY
# AZURE_AD
# CUSTOM
# GOOGLE_WORKSPACE
# OKTA
# ONE_LOGIN


# try:
#     IDP_PROVIDER_TYPE = getattr(IdPProviderType, IDP_PROVIDER_TYPE.upper())
# except AttributeError as err:

#     logger.error('Invalid IdPProviderType type %s:  '
#                  'Must be one of %s',
#                  IDP_PROVIDER_TYPE,
#                  oaa_utils.idp_provider_types())
#     logger.error(err)
#     exit(1)

# Provide a path to an icon.  Icon should either be SVG or PNG and less than
# 64KB
# NOTE This is not implemented in this script yet.
# HRIS_ICON_B64_PATH = ""

# GROUP_TYPE = os.getenv('GROUP_TYPE', 'Department')

# what is the unique identifier field?
# HRIS_UNIQUE_ID_FIELD = os.environ['HRIS_UNIQUE_ID_FIELD']  # , 'EMP_NO')

def validate_config(config_file, test_connectivity=False):
    """Validate a config.yaml file without running a full sync.

    Checks config structure, connection modules, and preflight conditions,
    then prints a summary of any issues found.

    :param config_file: Path to the config.yaml file
    :param test_connectivity: If True, also test live connections to data sources

    Example::

        oaa validate_config --config_file=./config.yaml
        oaa validate_config --config_file=./config.yaml --test_connectivity=True
    """
    is_valid, messages = _validate_config(
        config_file, test_connectivity=test_connectivity
    )

    for msg in messages:
        print(msg)

    return is_valid


def main(cli_args=None):
    """Entry point for the oaa CLI.

    :returns: None
    """
    args = cli_args if cli_args is not None else sys.argv[1:]
    if '-v' in args or '--version' in args:
        try:
            print(version('oaa-runner'))
        except PackageNotFoundError:
            print('unknown')
        return

    payload = {
            # 'hris': HRISRunner,
            # 'idp': IdPRunner,
            'custom_app': CustomAppRunner,
            'validate_config': validate_config,
            'oaa_utils': oaa_utils.FUNCS,
        }

    if cli_args:
        fire.Fire(payload, cli_args)
    else:
        fire.Fire(payload)


def direct_run(cli_args=None):
    if cli_args:
        fire.Fire(CustomAppRunner)
    else:
        fire.Fire(CustomAppRunner, cli_args)


if __name__ == "__main__":
    main()
