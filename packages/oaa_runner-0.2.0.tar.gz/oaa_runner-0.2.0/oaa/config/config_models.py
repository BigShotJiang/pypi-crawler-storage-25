import logging
import os
import sys
from typing import Any, Optional

from oaaclient.templates import IdPProviderType, OAAPermission
from pydantic import (
    Field,
    HttpUrl,
    DirectoryPath,
    constr,
    field_validator,
    model_validator,
)

from ..settings_utils import (
    ConfigBase,
    LogLevel,
    RunnerType,
    SourceType,
    VersionEnum,
    make_abs,
)
from .connection_models import (
    APIConnection,
    Connection,
    CustomConnection,
    DBConnection,
    VezaAPIConnection,
)
from .source_models import App, DestinationType, PermissionMapping, Source

logger = logging.getLogger(__name__)


class ConfigV2(ConfigBase):
    version: VersionEnum = VersionEnum.v2
    runner_type: RunnerType = RunnerType.custom_app

    log_level: Optional[LogLevel] = Field(default=LogLevel.info)
    oaa_time_zone: constr(to_upper=True) = 'Z'

    VEZA_URL: Optional[HttpUrl] = None
    VEZA_API_KEY: Optional[str] = None

    provider_icon_path: Optional[str] = None

    enable_multipart: Optional[bool] = False

    destination_type: Optional[DestinationType] = None

    GROUP_TYPE: str = 'Department'

    idp_provider_type: Optional[IdPProviderType] = IdPProviderType.OKTA

    app: Optional[App] = None

    sources: Optional[dict[str, Source]] = Field(default_factory=lambda: {})
    is_csv_push: Optional[bool] = Field(default=False)
    connections: Optional[dict[str, Connection]] = None

    permission_to_veza_map: Optional[dict[str, PermissionMapping]] = Field(
        default_factory=lambda: {}
    )

    module_directory: Optional[DirectoryPath] = None
    logic_modules: Optional[list[str]] = Field(default_factory=lambda: [])

    @field_validator('VEZA_URL', 'VEZA_API_KEY', mode='before')
    @classmethod
    def strip_surrounding_quotes(cls, v):
        if isinstance(v, str):
            v = v.strip('"\'')
        return v or None

    @field_validator('permission_to_veza_map', mode='before')
    @classmethod
    def validate_permission_map_format(cls, v):
        if not isinstance(v, dict):
            return v
        for key, val in v.items():
            if isinstance(val, list):
                raise ValueError(
                    f"permission_to_veza_map['{key}'] uses the old list format."
                    ' Update to the object format: '
                    f"{{'permissions': {val!r}}}. "
                    'See docs/reference/configuration-schema.md for details.'
                )
        return v


    @field_validator('runner_type', mode='before')
    @classmethod
    def validate_runnertype(cls, runner_type, values):
        return runner_type.upper()

    @field_validator('destination_type', mode='before')
    @classmethod
    def validate_destination_type(cls, destination_type, values):
        if destination_type:
            destination_type = destination_type.upper()
        return destination_type

    @model_validator(mode='after')
    def post_update(self) -> 'ConfigV2':
        """Post-validation processing of config.

        Sets source_name on each source and marks is_csv_push if any source
        uses csv_push source type.
        """
        for source_name, source in self.sources.items():
            source.source_name = source_name

            if source.source_type == SourceType.csv_push:
                self.is_csv_push = True

        return self

    @field_validator('app', mode='after')
    @classmethod
    def validate_app(cls, app, values):
        if values.data['runner_type'] == RunnerType.custom_app:
            pre_config = values.context.get('pre-config')

            if not app and not pre_config:
                raise Exception('app required when runnertype=custom_app')

        return app

    @field_validator('connections', mode='before')
    @classmethod
    def validate_connections(cls, connections, values):
        if isinstance(connections, dict):
            for name, connection_info in connections.items():
                connection_type = connection_info['connection_type'].upper()

                if connection_type == SourceType.db:
                    connections[name] = DBConnection.model_validate(connection_info)
                elif connection_type == SourceType.api:
                    connections[name] = APIConnection.model_validate(connection_info)
                elif connection_type == SourceType.veza_api:
                    connections[name] = VezaAPIConnection.model_validate(
                        connection_info
                    )
                elif connection_type == SourceType.custom:
                    connections[name] = CustomConnection.model_validate(connection_info)
                else:
                    c_type = {connection_info['connection_type']}
                    raise Exception(f'invalid connection type: {c_type}')

        return connections

    @field_validator('module_directory', mode='before')
    @classmethod
    def validate_module_directory(cls, module_path: str, values: dict[str, Any]) -> str:
        if module_path:
            from oaa.settings import Config

            module_path = make_abs(module_path, Config.BASE_DIR)
            logger.debug('new module_path %s', module_path)
            logger.debug('exists and is director %s', os.path.isdir(module_path))
            sys.path.append(str(module_path))

        return module_path

    @field_validator('idp_provider_type', mode='before')
    @classmethod
    def transform(cls, raw: str) -> str:
        return raw.lower()

    def lookup_perms(self, perm_name, default=None):
        """Look up the permissions list for a given permission name.

        :param perm_name: Permission name to look up in permission_to_veza_map.
        :param default: Default permission list if not found (defaults to NonData).
        :returns: List of OAAPermission values.
        """
        perm_list = [OAAPermission.NonData]

        if default is not None and type(default) in (list, tuple):
            perm_list = default

        if self.permission_to_veza_map:
            perm = self.permission_to_veza_map.get(perm_name)

            if perm:
                perm_list = perm.permissions

        return perm_list
