import importlib
import logging
import os
from enum import Enum
from typing import Any, Optional

import petl
from pydantic import (
    BaseModel,
    ConfigDict,
    FilePath,
    constr,
    field_validator,
    model_validator,
)
from typing_extensions import Self

from oaa.hooks.decorators import OAAHookEvent, run_hooks

from ..settings_utils import (
    ConfigBase,
    QueryStream,
    SourceType,
    make_abs,
)

try:
    import pymssql
except ImportError:
    pymssql = None
try:
    import oracledb
except ImportError:
    oracledb = None
try:
    import psycopg

    from oaa.modules.pg_logging_cursor import LoggingPGCursor
except ImportError:
    psycopg = None


logger = logging.getLogger(__name__)


class Connection(BaseModel):
    name: Optional[str] = None
    model_config = ConfigDict(validate_default=True)


class RequestMethod(str, Enum):
    get = "GET"
    post = "POST"


class CSVConnection(Connection):
    def fetch(self, source):
        """Load the CSV file and return it as a petl table."""
        return petl.fromcsv(source.csv_filepath, encoding='utf-8-sig')


class APIConnection(Connection):
    model_config = ConfigDict(validate_default=True)
    uri: str
    method: Optional[RequestMethod] = RequestMethod.get
    params: Optional[dict] = None
    auth: Optional[dict] = None
    fetch_module: str
    max_results: Optional[int] = None

    @field_validator('method', mode='before')
    @classmethod
    def method_uppercase(cls, value):
        if value:
            value = value.upper()
        return value

    def fetch(self, **kwargs):
        """Import fetch_module and call its fetch() to retrieve data from the API."""
        fetch_module = importlib.import_module(self.fetch_module)
        results = fetch_module.fetch(self, **kwargs)

        if results:
            table = petl.fromdicts(results)
            return table


class VezaAPIConnection(APIConnection):
    uri: Optional[str] = None
    path: str
    response_type: Optional[str] = 'list'
    fetch_module: Optional[str] = None
    max_results: Optional[int] = None

    def fetch(self, **kwargs):
        fetch_module = importlib.import_module('veza_api_fetch')
        results = fetch_module.fetch(self)

        if results:
            table = petl.fromdicts(results)
            return table


class CustomConnection(Connection):
    query: Optional[str] = None
    custom_module: str
    params: Optional[dict[str, Any]] = None

    def fetch(self, source=None, **kwargs):
        module_import_paths = [self.custom_module, f'oaa.modules.{self.custom_module}']

        for module_path in module_import_paths:
            try:
                fetch_module = importlib.import_module(module_path)
                break
            except ModuleNotFoundError as exc:
                logger.error(exc)
                logger.debug(
                    'custom module %s not found, looking internally',
                    self.custom_module,
                )

        from oaa import utils
        try:
            utils.validate_fetch_module(fetch_module)
        except AssertionError as exc:
            logger.error('Invalid custom module: %s', exc)
            return None

        results = fetch_module.fetch(connection=self, source=source, **kwargs)
        return results or None


class DBConnection(Connection):
    connection_type: Optional[str] = None
    DB_PASSWORD: Optional[str] = '!env'
    DB_USER: Optional[str] = None
    DB_SERVER: Optional[str] = None
    DB_PORT: Optional[int] = None
    DB_NAME: Optional[str] = None
    DB_DIALECT: constr(to_upper=True) = 'SQLSERVER'
    QUERY_PATH: Optional[FilePath] = None
    QUERY: Optional[str] = None
    QUERY_STREAMS: Optional[list[QueryStream]] = None

    @model_validator(mode='after')
    def db_values_query_or_query_path(self) -> Self:
        if self.connection_type == SourceType.db:
            if not any((self.QUERY_STREAMS, self.QUERY, self.QUERY_PATH)):
                raise ValueError('QUERY or QUERY_PATH must be defined for DB sources')
        return self

    @field_validator('QUERY_PATH', mode='before')
    @classmethod
    def query_path_make_absolute(cls, value, info: dict[str, Any]):
        if value:
            value = make_abs(value, info.data['base_dir'])
        return value

    @field_validator('QUERY', mode='after')
    @classmethod
    def query_read_from_query_path(cls, value, info: dict[str, Any]):
        if not value:
            if info.data['QUERY_PATH']:
                value = open(info.data['QUERY_PATH']).read()
        return value

    @field_validator(
        'DB_PASSWORD', 'DB_USER', 'DB_SERVER', 'DB_NAME', 'DB_DIALECT', mode='before'
    )
    def after_validate_db_vars(cls, var_value: Any, values: dict[str, Any]) -> Any:
        if var_value == '!env':
            env_value = os.getenv(values.field_name)
            var_value = env_value

        if not var_value:
            raise ValueError('value must be set when source_type=db')

        return var_value

    def _get_connection(self):
        db_dialect = self.DB_DIALECT.lower()
        connection = None

        if db_dialect == 'sqlserver':
            try:
                connection = pymssql.connect(
                    host=self.DB_SERVER,
                    user=self.DB_USER,
                    password=self.DB_PASSWORD,
                    database=self.DB_NAME,
                    port=self.DB_PORT,
                )
            except pymssql.exceptions.OperationalError as err:
                logger.error(err)
                return
        elif db_dialect == 'sqlserver.odbc':
            from fabric_odbc import fetch

            try:
                connection = fetch(connection=self, source=self)
            except Exception as err:
                logger.error(err)
                return
        elif db_dialect == 'oracle':
            connection = oracledb.connect(
                user=self.DB_USER, password=self.DB_PASSWORD, dsn=self.DB_SERVER
            )
        elif db_dialect == 'postgres':
            connect_obj = dict(
                user=self.DB_USER,
                password=self.DB_PASSWORD,
                host=self.DB_SERVER,
                port=self.DB_PORT,
                dbname=self.DB_NAME,
            )
            logging.getLogger('psycopg').setLevel(logging.DEBUG)
            connection = psycopg.connect(
                cursor_factory=LoggingPGCursor, **connect_obj
            )

        run_hooks(
            event=OAAHookEvent.POST_DB_CONNECT, connection=connection, conx_config=self
        )

        return connection
