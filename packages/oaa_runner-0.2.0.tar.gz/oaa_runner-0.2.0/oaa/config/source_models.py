import logging
from enum import Enum
from typing import Any, Optional

import petl
from oaaclient.templates import OAAPermission
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FilePath,
    field_validator,
)

from oaa.models import FieldMapping, GeneratorConfig, Provider, VezaObjectType
from oaa.oaa_utils import get_oaa_client, get_or_create_data_source

from ..settings_utils import SourceType, make_abs
from .connection_models import CustomConnection

logger = logging.getLogger(__name__)


class Tree(BaseModel):
    id_field: str
    parent_id_field: str
    sub_fieldname: Optional[str] = "sub_resources"


class Source(BaseModel):
    """Source configuration for data ingestion.

    Note: The `field_mapping` (inline) configuration is preferred over the
    deprecated `mapping_filepath` (CSV file). Using inline field_mapping provides
    better validation, version control, and self-contained configuration.
    """

    model_config = ConfigDict(validate_default=True)

    destination: Optional[VezaObjectType] = None
    source_type: SourceType
    source_name: Optional[str] = None
    source: Optional[str] = None
    tree: Optional[Tree] = None
    query: Optional[str] = None
    field_mapping: Optional[dict[str, FieldMapping]] = None
    mapping_filepath: Optional[FilePath] = None
    csv_filepath: Optional[FilePath] = None
    csv_provider_id: Optional[str] = None
    resource_type: Optional[str] = None
    connection: Optional[str] = None
    _stream: Optional[Any] = None

    stream_set: Optional[bool] = False

    custom_attrs_map: dict[str, FieldMapping] = Field(default_factory=lambda: {})
    attributes: dict[str, str] = Field(default_factory=lambda: {})
    params: Optional[dict[str, Any]] = None
    record_transforms: Optional[list[str]] = Field(default_factory=lambda: [])
    record_transforms_non_stream: Optional[list[str]] = Field(
        default_factory=lambda: []
    )

    generators: Optional[dict[str, GeneratorConfig]] = Field(default_factory=dict)

    datasource: Optional[str] = None

    def upsert_datasource(self, datasource_name=None):
        provider = self.get_provider()

        if not datasource_name:
            datasource_name = self.datasource or f"{provider['name']} - Datasource"
        datasource, created = get_or_create_data_source(
            datasource_name, provider['id']
        )

        return datasource

    def get_provider(self):
        veza_con = get_oaa_client()
        provider = veza_con.get_provider_by_id(self.csv_provider_id)

        if provider:
            logger.info("Found existing provider")
            return provider

    def validate_to_api_csv_mapping(self):
        """Validate this source by downloading the current mapping in Veza and
        running through the file to check that it is valid.
        """
        mapping = self.get_api_mapping()

        constraints = []
        table = self.get_stream()
        header_errors = []

        for cm in mapping.column_mappings:
            if cm.column_name:
                if cm.column_name not in table.fieldnames():
                    header_errors.append(f"{cm} missing")
                constraints.append(
                    {"name": cm.column_name, "field": cm.column_name, "test": bool}
                )

        if not header_errors:
            errors = table.validate(constraints=constraints)
            has_problems = errors.nrows() >= 1
        else:
            has_problems = True
            errors = header_errors

        return not has_problems, errors

    def get_api_mapping(self):
        """Query the Veza API to get the current CSV field mappings."""
        oaa_client = get_oaa_client()
        path = f"/api/v1/providers/custom/{self.csv_provider_id}"

        try:
            provider_response = oaa_client.api_get(path)
            provider = Provider.model_validate(provider_response)
            return provider.csv_mapping_configuration
        except Exception as err:
            logger.error(err)

    def field_mappings(self):
        """Return all field mappings for this source."""
        if self.destination == VezaObjectType.none and not self.field_mapping:
            self.field_mapping = {}
            return self.field_mapping

        if not self.field_mapping:
            mappings = {}

            if self.source_type == SourceType.csv_push:
                for idx, field in enumerate(self.get_api_mapping().column_mappings):
                    ctx = {"row_num": idx + 1}
                    field_dict = {
                        "source_field": field.column_name,
                        "destination_field": field.destination_property or "None",
                    }

                    if field.custom_property:
                        field_dict.update(
                            {
                                "is_custom": bool(field.custom_property),
                                "veza_field_type": field.custom_property["type"],
                            }
                        )
                    field = FieldMapping.model_validate(field_dict, context=ctx)
                    mappings[field.source_field or field.destination_field] = field
            else:
                fields = petl.fromcsv(self.mapping_filepath)

                for idx, field in enumerate(fields.dicts()):
                    ctx = {"row_num": idx + 1}
                    field = FieldMapping.model_validate(field, context=ctx)
                    mappings[field.source_field or field.destination_field] = field

            self.field_mapping = mappings

        return self.field_mapping

    def get_stream(self):
        from oaa.settings import config

        if not self.stream_set:
            if self.source_type == SourceType.db:
                connection = config.connections[self.connection]
                conn = connection._get_connection()

                if conn:
                    table = petl.fromdb(conn, self.query)
                else:
                    raise Exception("unable to connect to DB")
            elif self.source_type in (SourceType.csv, SourceType.csv_push):
                connection = CustomConnection(
                    name="csv-loader", custom_module="oaa.modules.csv_connector"
                )
                table = connection.fetch(source=self)
            elif self.source_type == SourceType.source:
                table = config.sources[self.source].get_stream()
            elif self.source_type in [SourceType.api, SourceType.veza_api]:
                connection = config.connections[self.connection]
                table = connection.fetch(source=self)
            elif self.source_type in [SourceType.custom]:
                connection = config.connections[self.connection]
                logger.debug("fetching custom stream from module")
                table = connection.fetch(source=self)

            if not table:
                logger.error("Unable to fetch data for source %s", self.source_name)
                raise Exception(f"Unable to fetch data for source {self.source_name}")
            else:
                if "row" not in petl.header(table):
                    table = table.addrownumbers()

                self.stream_set = True
                self._stream = table

        return self._stream

    @property
    def stream(self):
        """Get the stream for this object."""
        if self.stream_set:
            return self._stream

        return self.get_stream()

    @property
    def records(self):
        return petl.records(self.stream)

    @field_validator("source_type", mode="before")
    def validate_SOURCE_TYPE(cls, source_type):
        if source_type:
            return source_type.upper()
        return source_type

    @field_validator("mapping_filepath", "csv_filepath", mode="before")
    @classmethod
    def validate_source_mapping_filepath(
        cls, filepath: str, values: dict[str, Any]
    ) -> str:
        if values.data.get("destination") != VezaObjectType.none:
            if values.field_name == "csv_filepath":
                if values.data.get("source_type") in (SourceType.csv,):
                    if not filepath:
                        raise ValueError(
                            "csv_filepath required when "
                            "source_type is "
                            f"{values.data['source_type']}"
                        )

            if not values.data.get("field_mapping"):
                if values.field_name == "mapping_filepath":
                    if values.data.get("source_type") in (
                        SourceType.csv,
                        SourceType.db,
                        SourceType.api,
                        SourceType.custom,
                    ):
                        if not filepath and not values.data.get("field_mapping"):
                            raise ValueError(
                                "mapping_filepath required when "
                                "source_type is "
                                f"{values.data['source_type']}"
                            )

        if filepath:
            from oaa.settings import Config

            base_dir = Config.BASE_DIR

            if filepath[:4] != "http":
                filepath = make_abs(filepath, base_dir)
            logger.debug("base_dir: %s", Config.BASE_DIR)
            logger.debug(
                "fieldname: %s - source.filepath %s", values.field_name, filepath
            )

        return filepath


class ExternalLifecycleManagementType(str, Enum):
    SEND_REST_PAYLOAD = "SEND_REST_PAYLOAD"
    SCIM = "SCIM"


class PropertyMatcher(BaseModel):
    source_property: str = "EMAIL",
    destination_property: str = "EMAIL"

    
class IdentityMapping(BaseModel):
    # IdPProviderType
    # I need to lookup what datasource types are supported here
    destination_datasource_type: str = "OKTA"
    type: str = "EQUAL"
    transformations: list[str]  # ["IGNORE_DOMAIN"],
    property_matchers: list[PropertyMatcher]


class HRISIdentityModel(BaseModel):
    use_email: bool = Field(default=True)
    mappings: list[IdentityMapping]


class App(BaseModel):
    name: str
    application_type: Optional[str] = None
    domain: Optional[str] = None
    idp_type: Optional[str] = None
    hris_type: Optional[str] = None
    # identity_mapping_configuration: Optional[HRISIdentityModel] = Field(default=None)
    url: Optional[str] = None
    options: dict[str, Any] = Field(default_factory=lambda: {})
    provisioning: Optional[bool] = False
    external_lifecycle_management_type: Optional[ExternalLifecycleManagementType] = None
    data_plane_id: Optional[str] = False
    datasource: Optional[str] = None

    @field_validator("external_lifecycle_management_type", mode="before")
    @classmethod
    def validate_runnertype(cls, external_lifecycle_management_type, values):
        return external_lifecycle_management_type.upper()


class DestinationType(str, Enum):
    IDP = "IDP"
    HRIS = "HRIS"
    CUSTOM_APP = "CUSTOM_APP"


class PermissionMapping(BaseModel):
    name: Optional[str] = None
    permissions: list[OAAPermission]
