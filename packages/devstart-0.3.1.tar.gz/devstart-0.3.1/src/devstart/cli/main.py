"""Typer CLI entry point for devstart."""

import keyword
import re
import sys
from pathlib import Path
from typing import Annotated, NoReturn

import click
import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.theme import Theme
from rich.tree import Tree

from devstart import __app_name__, __version__
from devstart.config import ProjectConfig
from devstart.defaults import (
    DEFAULT_AUTHOR,
    DEFAULT_DESCRIPTION,
    DEFAULT_PROJECT_NAME,
    SUPPORTED_PYTHON_VERSIONS,
)
from devstart.generators.project import generate_project
from devstart.prompts.interactive import prompt_for_config
from devstart.python_version import resolve_patch_version

_RESERVED_NAMES: set[str] = {
    "__init__",
    "__main__",
    "__pycache__",
    "test",
    "tests",
    "setup",
    "site",
}

_VALID_IDENTIFIER_PATTERN: re.Pattern[str] = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
_NON_IDENTIFIER_CHARS_PATTERN: re.Pattern[str] = re.compile(r"[^a-zA-Z0-9_]")
_GITHUB_NAME_PATTERN: re.Pattern[str] = re.compile(r"^[a-zA-Z0-9._-]+$")
_GITHUB_NAME_MAX_LENGTH: int = 100

_theme = Theme(
    {
        "info": "cyan",
        "success": "bold green",
        "error": "bold red",
        "heading": "bold bright_blue",
        "key": "cyan",
        "value": "white",
        "dim": "dim",
    }
)

console = Console(theme=_theme, highlight=False)

app = typer.Typer(
    name="devstart",
    help="Scaffold Python projects with all dev tooling pre-configured.",
    no_args_is_help=True,
)


def _print_version_and_exit(value: bool) -> None:
    """Print version and exit when --version flag is passed."""
    if value:
        console.print(f"[heading]{__app_name__}[/heading] [dim]v{__version__}[/dim]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[  # noqa: ARG001 — handled by eager callback
        bool | None,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=_print_version_and_exit,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """devstart — scaffold Python projects with dev tooling pre-configured."""


@app.command()
def new(
    name: Annotated[str | None, typer.Argument(help="Project name")] = None,
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Project description"),
    ] = None,
    author: Annotated[
        str | None,
        typer.Option("--author", "-a", help="Author name"),
    ] = None,
    python: Annotated[
        str | None,
        typer.Option(
            "--python",
            help="Python version",
            click_type=click.Choice(SUPPORTED_PYTHON_VERSIONS),
        ),
    ] = None,
    no_interactive: Annotated[
        bool,
        typer.Option(
            "--no-interactive",
            "-y",
            help="Use defaults, skip all prompts",
        ),
    ] = False,
) -> None:
    """Create a new Python project with dev tooling pre-configured."""
    config: ProjectConfig = _resolve_project_config(
        name, description, author, python, no_interactive
    )
    _validate_project_name(config.project_name)
    _print_config_summary(config)
    created_paths: list[Path] = _generate_with_spinner(config)
    _print_file_tree(config.workspace_dir_name, created_paths)
    _print_success(config)


# ── Config building ───────────────────────────────────────────────────────────


def _resolve_project_config(
    name: str | None,
    description: str | None,
    author: str | None,
    python: str | None,
    is_non_interactive: bool,
) -> ProjectConfig:
    """Assemble a ProjectConfig from CLI args, prompts, or defaults."""
    resolved_name: str | None = name
    should_use_cwd: bool = False

    if name == ".":
        resolved_name, should_use_cwd = _derive_name_from_cwd()

    partial_config: dict[str, str | bool | None] = {
        "name": resolved_name,
        "description": description,
        "author": author,
        "python": python,
    }

    if is_non_interactive:
        partial_config = _apply_non_interactive_defaults(partial_config)
    else:
        partial_config = prompt_for_config(partial_config)

    return _build_project_config(partial_config, should_use_cwd)


def _derive_name_from_cwd() -> tuple[str, bool]:
    """Return the current directory name verbatim (validated/normalized later)."""
    return Path.cwd().name, True


def _normalize_to_package_name(raw_name: str) -> str:
    """Convert a GitHub-valid name into a lowercase Python package identifier."""
    sanitized_name: str = _NON_IDENTIFIER_CHARS_PATTERN.sub("_", raw_name).lower()
    if not sanitized_name:
        return DEFAULT_PROJECT_NAME
    if sanitized_name[0].isdigit():
        return f"_{sanitized_name}"
    return sanitized_name


def _validate_workspace_dir_name(name: str, *, is_cwd: bool) -> None:
    """Exit if name is not a valid GitHub-compatible directory name."""
    if (
        not name
        or len(name) > _GITHUB_NAME_MAX_LENGTH
        or name in {".", ".."}
        or not _GITHUB_NAME_PATTERN.match(name)
    ):
        if is_cwd:
            _exit_with_error(
                f"Current directory '{name}' is not a valid project root."
                f" Rename it to use only letters, digits, hyphens,"
                f" underscores, or periods (max {_GITHUB_NAME_MAX_LENGTH}"
                f" chars), then re-run."
            )
        _exit_with_error(
            f"Invalid project name '{name}'."
            f" Use only letters, digits, hyphens, underscores,"
            f" or periods (GitHub-compatible, max"
            f" {_GITHUB_NAME_MAX_LENGTH} chars)."
        )


def _apply_non_interactive_defaults(
    partial_config: dict[str, str | bool | None],
) -> dict[str, str | bool | None]:
    """Return a copy of partial_config with missing values filled by defaults."""
    return {
        **partial_config,
        "name": partial_config["name"] or DEFAULT_PROJECT_NAME,
        "description": partial_config["description"] or DEFAULT_DESCRIPTION,
        "author": partial_config["author"] or DEFAULT_AUTHOR,
    }


def _build_project_config(
    partial_config: dict[str, str | bool | None],
    should_use_cwd: bool,
) -> ProjectConfig:
    """Build a ProjectConfig from a fully-populated partial dict."""
    raw_name: str = _require_string_field(
        partial_config, "name", "Project name is required."
    )
    _validate_workspace_dir_name(raw_name, is_cwd=should_use_cwd)
    python_version: str = _require_string_field(
        partial_config, "python", "Python version is required (use --python)."
    )
    project_name: str = _normalize_to_package_name(raw_name)
    workspace_dir_name: str = raw_name
    return ProjectConfig(
        project_name=project_name,
        workspace_dir_name=workspace_dir_name,
        description=str(partial_config["description"]),
        author=str(partial_config["author"]),
        python_version=python_version,
        python_version_full=resolve_patch_version(python_version),
        should_use_cwd=should_use_cwd,
    )


def _require_string_field(
    partial_config: dict[str, str | bool | None],
    field_name: str,
    missing_message: str,
) -> str:
    """Return the string value of a partial-config field, exiting if absent."""
    value: str | bool | None = partial_config[field_name]
    if not isinstance(value, str):
        _exit_with_error(missing_message)
    return value


# ── Validation ────────────────────────────────────────────────────────────────


def _validate_project_name(name: str) -> None:
    """Validate that the project name is a valid Python identifier."""
    _reject_invalid_identifier(name)
    _reject_python_keyword(name)
    _reject_dunder_name(name)
    _reject_reserved_name(name)


def _reject_invalid_identifier(name: str) -> None:
    """Exit if name is not a valid Python identifier."""
    if not _VALID_IDENTIFIER_PATTERN.match(name):
        suggested_name: str = _NON_IDENTIFIER_CHARS_PATTERN.sub("_", name)
        _exit_with_error(
            f"Invalid project name '{name}'."
            f" Only letters, digits, and underscores"
            f" are allowed (cannot start with a digit)."
            f" Hint: try [bold]'{suggested_name}'[/bold]."
        )


def _reject_python_keyword(name: str) -> None:
    """Exit if name is a Python keyword."""
    if keyword.iskeyword(name):
        _exit_with_error(
            f"Invalid project name '{name}'. Python keywords are not allowed."
        )


def _reject_dunder_name(name: str) -> None:
    """Exit if name is a dunder name."""
    if name.startswith("__") and name.endswith("__"):
        _exit_with_error(
            f"Invalid project name '{name}'. Dunder names are reserved by Python."
        )


def _reject_reserved_name(name: str) -> None:
    """Exit if name conflicts with stdlib or reserved names."""
    if name in _RESERVED_NAMES or name in sys.stdlib_module_names:
        _exit_with_error(
            f"Invalid project name '{name}'."
            f" This name conflicts with a Python"
            f" standard library module or reserved name."
        )


# ── Output: configuration summary ─────────────────────────────────────────────


def _print_config_summary(config: ProjectConfig) -> None:
    """Print a Rich table summarising the project configuration."""
    console.print()
    console.rule("[heading]Configuration[/heading]")
    console.print()
    console.print(_build_config_table(config))


def _build_config_table(config: ProjectConfig) -> Table:
    """Build a Rich table with configuration key-value rows."""
    table = Table(
        box=box.SIMPLE,
        show_header=False,
        padding=(0, 2),
        expand=False,
    )
    table.add_column("Setting", style="key")
    table.add_column("Value", style="value")
    table.add_row("Project", f"[bold]{config.project_name}[/bold]")
    table.add_row("Description", config.description)
    table.add_row("Author", config.author)
    table.add_row("Python", config.python_version)
    return table


# ── Generation with status spinner ────────────────────────────────────────────


def _generate_with_spinner(config: ProjectConfig) -> list[Path]:
    """Run project generation with a Rich spinner and error handling."""
    console.print()
    try:
        with console.status(
            "[heading]Generating project...[/heading]",
            spinner="dots",
        ):
            return generate_project(config)
    except (FileExistsError, OSError) as error:
        _exit_with_error(str(error), prefix="  ✘ ")


# ── Output: file tree ─────────────────────────────────────────────────────────


def _print_file_tree(root_label: str, created_paths: list[Path]) -> None:
    """Print a Rich tree of all generated files."""
    console.print()
    console.rule("[heading]Project Structure[/heading]")
    console.print()
    console.print(_build_file_tree(root_label, created_paths))


def _build_file_tree(root_label: str, created_paths: list[Path]) -> Tree:
    """Build a Rich Tree representation of all created paths."""
    tree = Tree(
        f"[bold bright_blue]{root_label}/[/bold bright_blue]",
        guide_style="bright_blue",
    )
    nodes_by_path_key: dict[str, Tree] = {}
    for path in sorted(created_paths):
        _add_path_to_tree(path, tree, nodes_by_path_key)
    return tree


def _add_path_to_tree(
    path: Path,
    tree_root: Tree,
    nodes_by_path_key: dict[str, Tree],
) -> None:
    """Insert each path component into the tree, reusing existing nodes."""
    current_node: Tree = tree_root
    path_components: tuple[str, ...] = path.parts
    for index, path_component in enumerate(path_components):
        path_key: str = "/".join(path_components[: index + 1])
        if path_key not in nodes_by_path_key:
            is_leaf: bool = index == len(path_components) - 1
            nodes_by_path_key[path_key] = current_node.add(
                _format_tree_label(path_component, is_leaf=is_leaf)
            )
        current_node = nodes_by_path_key[path_key]


def _format_tree_label(path_component: str, *, is_leaf: bool) -> str:
    """Return a styled label for a tree node based on whether it is a file."""
    if is_leaf:
        return f"[green]{path_component}[/green]"
    return f"[bold]{path_component}/[/bold]"


# ── Output: success panel ─────────────────────────────────────────────────────


def _print_success(config: ProjectConfig) -> None:
    """Print the success panel with next-steps instructions."""
    console.print()
    console.print(_build_success_panel(config))


def _build_success_panel(config: ProjectConfig) -> Panel:
    """Build the success panel summarising completion and next steps."""
    next_steps: str = _format_next_steps(config)
    body: str = (
        f"[success]✔ Project [bold]'{config.project_name}'[/bold]"
        f" created successfully![/success]"
        f"\n\n[dim]Next steps:[/dim]\n{next_steps}"
    )
    return Panel(
        body,
        border_style="green",
        padding=(1, 2),
        expand=False,
    )


def _format_next_steps(config: ProjectConfig) -> str:
    """Return the indented, newline-joined list of next-step shell commands."""
    next_step_lines: list[str] = []
    if not config.should_use_cwd:
        next_step_lines.append(f"  [bold]$[/bold] cd {config.workspace_dir_name}")
    next_step_lines.append("  [bold]$[/bold] make setup")
    next_step_lines.append(f"  [bold]$[/bold] uv run python -m {config.project_name}")
    return "\n".join(next_step_lines)


# ── Errors ───────────────────────────────────────────────────────────────────


def _exit_with_error(message: str, *, prefix: str = "") -> NoReturn:
    """Print an error message and exit with code 1."""
    console.print(f"\n[error]{prefix}✘ {message}[/error]")
    raise typer.Exit(code=1)
