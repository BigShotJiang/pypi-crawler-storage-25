"""Context preparation facade that composes compaction primitives.

Composes #791 (budget/state), #792 (offload/prune/repair),
and #793 (compaction) into a single pipeline.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from aip_agents.context.budget import (
    CompactionDecision,
    ContextBudgetConfig,
    decide_compaction,
    estimate_message_token_counts,
)
from aip_agents.context.compaction import (
    CompactionSummary,
    CompressionResult,
    ContextCompressor,
)
from aip_agents.context.offload import (
    OffloadedPayloadRef,
    offload_oversized_payloads,
    prune_duplicate_tool_outputs,
    repair_tool_result_pairing,
)
from aip_agents.context.state import CompactionState

if TYPE_CHECKING:
    from aip_agents.context.prompt import PromptBuildContext


_SUMMARY_MESSAGE_ROLE = "assistant"

_ADMIN_TAG = "compact_summary"


@dataclass(frozen=True)
class ContextPreparationResult:
    """Single output of the context preparation pipeline.

    Composes all compaction primitives into one result object
    so runtime code calls one facade instead of orchestrating
    budget, offload, prune, repair, and summary individually.

    Attributes:
        messages: Provider-ready messages after context preparation.
        prompt_context: Prompt assembly context used to build the system prompt.
        decision: Budget decision that determined whether compaction was needed.
        state: Safe compaction metadata for logging and observability.
        offloaded_refs: Payload references produced by lossless offloading.
        summary: Reference-only compaction summary inserted into context, if any.
    """

    messages: list[Any]
    prompt_context: PromptBuildContext | None = None
    decision: CompactionDecision | None = None
    state: CompactionState | None = None
    offloaded_refs: tuple[OffloadedPayloadRef, ...] = field(default_factory=tuple)
    summary: CompactionSummary | None = None


def _build_summary_message(summary: CompactionSummary) -> dict[str, Any]:
    """Build a replacement message from a compaction summary."""
    return {
        "role": _SUMMARY_MESSAGE_ROLE,
        "content": f"[Previous conversation context summarized: {summary.body}]",
        "type": _ADMIN_TAG,
        "summary_id": summary.summary_id,
    }


def prepare_context(
    messages: Sequence[Any],
    *,
    config: ContextBudgetConfig | None = None,
    backend: Any | None = None,
    model_context_tokens: int | None = None,
    summarizer: Any | None = None,
    previous_summary: CompactionSummary | None = None,
    focus_topic: str | None = None,
) -> ContextPreparationResult:
    """Run the full context preparation pipeline.

    Args:
        messages: Full message sequence to prepare for model invocation.
        config: Budget configuration for compaction decisions.
        backend: Optional backend for offloading oversized payloads.
        model_context_tokens: Provider model context window size, if known.
        summarizer: Optional external summarizer client.
        previous_summary: Previous compaction summary for incremental update.
        focus_topic: Optional focus topic for manual/guided compaction.

    Returns:
        ContextPreparationResult with processed messages and metadata.

    Order of operations:
    1. Budget decision (estimate tokens, decide if compaction needed)
    2. Lossless offload (oversized payloads to backend, if backend provided)
    3. Prune duplicate tool outputs
    4. Repair tool-result pairing
    5. Generate compaction summary (if should_compact)
    6. Assemble final messages (head + summary + tail)
    """
    cfg = config or ContextBudgetConfig()

    # 1. Budget decision
    token_counts = list(estimate_message_token_counts(messages))
    estimated_prompt_tokens = sum(token_counts)

    decision = decide_compaction(
        messages,
        config=cfg,
        model_context_tokens=model_context_tokens,
    )

    # 2-4: Always apply offload/prune/repair
    transformed = list(messages)

    offloaded_refs: tuple[OffloadedPayloadRef, ...] = ()
    if backend is not None:
        transformed, offloaded_refs = offload_oversized_payloads(
            transformed, backend=backend,
        )

    protected_tail_start = (
        decision.summary_insertion_point.protected_tail_start_index
        if decision.summary_insertion_point is not None
        else len(transformed)
    )
    transformed = prune_duplicate_tool_outputs(
        transformed, protected_tail_start_index=protected_tail_start,
    )
    transformed = repair_tool_result_pairing(transformed)

    # 5-6: Compaction summary + assembly
    summary: CompactionSummary | None = None
    state = CompactionState()

    if decision.should_compact:
        compressor = ContextCompressor(summarizer=summarizer)
        try:
            compression_result: CompressionResult = compressor.compress(
                transformed,
                focus_topic=decision.focus_topic or focus_topic,
                previous_summary=previous_summary,
            )
            summary = compression_result.summary

            sip = decision.summary_insertion_point
            if sip is not None:
                summary_message = _build_summary_message(summary)
                head = list(transformed[:sip.replace_start_index])
                tail = list(transformed[sip.replace_end_index:])
                transformed = head + [summary_message] + tail

            post_compact_tokens = sum(estimate_message_token_counts(transformed))
            state = CompactionState(
                compaction_count=1,
                last_summary_status="succeeded",
                offloaded_ref_count=len(offloaded_refs),
                estimated_token_savings=estimated_prompt_tokens - post_compact_tokens,
                last_reason=decision.reason,
            )
        except Exception as exc:
            state = CompactionState(
                compaction_count=1,
                last_summary_status="failed",
                offloaded_ref_count=len(offloaded_refs),
                last_reason=decision.reason,
                last_error_code=str(type(exc).__name__),
            )

    return ContextPreparationResult(
        messages=transformed,
        decision=decision,
        state=state,
        offloaded_refs=offloaded_refs,
        summary=summary,
    )
