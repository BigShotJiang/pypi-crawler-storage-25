from _typeshed import Incomplete
from langchain_core.tools import BaseTool
from pydantic import BaseModel
from typing import Any

__all__ = ['ReadImageTool', 'VisionMiddleware', 'VisionToolConfig']

class ReadImageInput(BaseModel):
    """Input schema for read_image."""
    image: str
    query: str | None

class VisionToolConfig(BaseModel):
    """Configuration for the vision model used by read_image."""
    model: str | None
    api_key: str | None
    base_url: str | None
    detail: VisionDetail

class ReadImageTool(BaseTool):
    """Analyze a registered image and return text context."""
    name: str
    description: str
    args_schema: type[BaseModel]
    vision_config: VisionToolConfig
    vision_analyzer: Any | None

class VisionMiddleware:
    """Middleware that contributes the read_image tool."""
    tools: list[BaseTool]
    system_prompt_additions: Incomplete
    def __init__(self, vision_config: dict[str, Any] | VisionToolConfig | None = None, vision_analyzer: Any | None = None) -> None:
        """Initialize the middleware with optional model config or analyzer hook."""
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op model hook for middleware manager compatibility."""
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async no-op model hook for middleware manager compatibility."""
    def modify_model_request(self, request: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
        """Return model requests unchanged."""
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op after-model hook for middleware manager compatibility."""
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async no-op after-model hook for middleware manager compatibility."""
