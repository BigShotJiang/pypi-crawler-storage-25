import typer
from rich.table import Table

from ..utils.config import (
    CONTEXTS,
    get_current_context,
    set_current_context,
    get_context_urls,
    get_all_contexts,
    create_context,
    delete_context,
    get_organization_id,
    set_organization_id,
    SUCCESS_STYLE,
    ERROR_STYLE,
    TITLE_STYLE,
    INFO_STYLE,
)
from ..entities.user import get_current_user
from ..utils.utils import console, is_uuid, make_request

app = typer.Typer(help="Manage API context for different environments.")


@app.command("list")
def list_contexts():
    """List all available contexts and show the current one."""
    current = get_current_context()
    all_contexts = get_all_contexts()
    
    table = Table(title="Available Contexts")
    table.add_column("Context", style=TITLE_STYLE)
    table.add_column("API URL", style=INFO_STYLE)
    table.add_column("Frontend URL", style=INFO_STYLE)
    table.add_column("Type", style=INFO_STYLE)
    table.add_column("Current", style=SUCCESS_STYLE)

    for name, urls in all_contexts.items():
        is_current = "✓" if name == current else ""
        context_type = "predefined" if name in CONTEXTS else "user-defined"
        table.add_row(name, urls["api_url"], urls["frontend_url"], context_type, is_current)

    # Check if using custom URL
    api_url, frontend_url = get_context_urls()
    if current not in all_contexts or api_url not in [ctx["api_url"] for ctx in all_contexts.values()]:
        table.add_row("custom", api_url, frontend_url, "custom", "✓" if current == "custom" else "")
    
    console.print(table)


def _format_org_label(org_id: str, name_by_id: dict) -> str:
    """Render an org as `Name (id)` when we know the name, else fall back to the id."""
    name = name_by_id.get(org_id)
    return f"{name} ({org_id})" if name else org_id


@app.command("current")
def show_current():
    """Show the current context, URLs, and session info."""
    current = get_current_context()
    api_url, frontend_url = get_context_urls()
    org_id = get_organization_id()
    user = get_current_user(include_org_id=False)

    console.print(f"[{SUCCESS_STYLE}]Context:[/{SUCCESS_STYLE}] {current}")
    console.print(f"[{INFO_STYLE}]API URL:[/{INFO_STYLE}] {api_url}")
    console.print(f"[{INFO_STYLE}]Frontend URL:[/{INFO_STYLE}] {frontend_url}")

    if user:
        # Look up org names for any ids we're about to display. Swallow
        # failures — the session info should still render even if the
        # memberships endpoint is unreachable.
        name_by_id: dict[str, str] = {}
        try:
            response = make_request("/v1/me/organizations")
            for org in (response or {}).get("data", []) or []:
                if org.get("id") and org.get("name"):
                    name_by_id[org["id"]] = org["name"]
        except Exception:
            pass

        # "Current Organization" = whichever org the CLI is sending X-Org-Id
        # for. If the user has a local override (set via `context set-org`),
        # that wins; otherwise the server falls back to their default.
        effective = org_id or user.organization_id

        console.print()
        console.print(f"[{SUCCESS_STYLE}]Signed in as:[/{SUCCESS_STYLE}] {user.name} ({user.email})")
        if effective:
            console.print(f"[{INFO_STYLE}]Current Organization:[/{INFO_STYLE}] {_format_org_label(effective, name_by_id)}")
        if user.is_admin:
            console.print(f"[{INFO_STYLE}]Admin:[/{INFO_STYLE}] true")
    else:
        console.print()
        console.print(f"[{INFO_STYLE}]Not signed in[/{INFO_STYLE}]")


@app.command("switch")
def switch_context(
    context_name: str = typer.Argument(help="Context name to switch to")
):
    """Switch to a different context."""
    all_contexts = get_all_contexts()
    if context_name in all_contexts:
        set_current_context(context_name)
        api_url, frontend_url = get_context_urls()
        console.print(f"[{SUCCESS_STYLE}]Switched to {context_name} context[/{SUCCESS_STYLE}]")
        console.print(f"[{INFO_STYLE}]API URL:[/{INFO_STYLE}] {api_url}")
        console.print(f"[{INFO_STYLE}]Frontend URL:[/{INFO_STYLE}] {frontend_url}")
    else:
        console.print(f"[{ERROR_STYLE}]Unknown context: {context_name}[/{ERROR_STYLE}]")
        console.print(f"[{INFO_STYLE}]Available contexts: {', '.join(all_contexts.keys())}[/{INFO_STYLE}]")
        raise typer.Exit(1)


@app.command("create")
def create_new_context(
    name: str = typer.Argument(help="Name for the new context"),
    api_url: str = typer.Argument(help="API URL for the context"),
    frontend_url: str = typer.Argument(help="Frontend URL for the context")
):
    """Create a new context."""
    if not api_url.startswith(('http://', 'https://')):
        console.print(f"[{ERROR_STYLE}]API URL must start with http:// or https://[/{ERROR_STYLE}]")
        raise typer.Exit(1)
    
    if not frontend_url.startswith(('http://', 'https://')):
        console.print(f"[{ERROR_STYLE}]Frontend URL must start with http:// or https://[/{ERROR_STYLE}]")
        raise typer.Exit(1)
    
    all_contexts = get_all_contexts()
    if name in all_contexts:
        console.print(f"[{ERROR_STYLE}]Context '{name}' already exists[/{ERROR_STYLE}]")
        raise typer.Exit(1)
    
    create_context(name, api_url, frontend_url)
    console.print(f"[{SUCCESS_STYLE}]Created context '{name}'[/{SUCCESS_STYLE}]")
    console.print(f"[{INFO_STYLE}]API URL:[/{INFO_STYLE}] {api_url}")
    console.print(f"[{INFO_STYLE}]Frontend URL:[/{INFO_STYLE}] {frontend_url}")


@app.command("delete")
def delete_existing_context(
    name: str = typer.Argument(help="Name of the context to delete")
):
    """Delete a user-defined context."""
    success, message = delete_context(name)
    if success:
        console.print(f"[{SUCCESS_STYLE}]{message}[/{SUCCESS_STYLE}]")
    else:
        console.print(f"[{ERROR_STYLE}]{message}[/{ERROR_STYLE}]")
        raise typer.Exit(1)


@app.command("set-url")
def set_custom_url(
    api_url: str = typer.Argument(help="Custom API URL to use")
):
    """Set a custom API URL."""
    if not api_url.startswith(('http://', 'https://')):
        console.print(f"[{ERROR_STYLE}]API URL must start with http:// or https://[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    set_current_context("custom", api_url)
    _, frontend_url = get_context_urls()
    console.print(f"[{SUCCESS_STYLE}]Set custom API URL[/{SUCCESS_STYLE}]")
    console.print(f"[{INFO_STYLE}]API URL:[/{INFO_STYLE}] {api_url}")
    console.print(f"[{INFO_STYLE}]Frontend URL:[/{INFO_STYLE}] {frontend_url}")


@app.command("set-org")
def set_org(
    name_or_id: str = typer.Argument(help="Organization name or ID (pass empty string to clear)")
):
    """Set the effective organization for CLI requests."""
    user = get_current_user()
    if not user:
        console.print(f"[{ERROR_STYLE}]Not signed in[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if not name_or_id:
        set_organization_id(None)
        console.print(f"[{SUCCESS_STYLE}]Cleared effective organization[/{SUCCESS_STYLE}]")
        return

    # UUID → pass through untouched. The server validates membership on the
    # next request, and super-admins who want to target an org they aren't
    # a member of can still do so this way.
    # Name → resolve against the caller's memberships via /v1/me/organizations.
    resolved_id: str | None = None
    resolved_name: str | None = None
    if is_uuid(name_or_id):
        resolved_id = name_or_id
    else:
        response = make_request("/v1/me/organizations")
        organizations = (response or {}).get("data", []) or []
        match = next((o for o in organizations if o.get("name") == name_or_id), None)
        if not match:
            console.print(
                f"[{ERROR_STYLE}]Organization '{name_or_id}' not found in your memberships. "
                f"Pass the organization ID directly to target an org you are not a member of.[/{ERROR_STYLE}]"
            )
            raise typer.Exit(1)
        resolved_id = match.get("id")
        resolved_name = match.get("name")

    set_organization_id(resolved_id)
    console.print(f"[{SUCCESS_STYLE}]Set effective organization[/{SUCCESS_STYLE}]")
    if resolved_name:
        console.print(f"[{INFO_STYLE}]Organization:[/{INFO_STYLE}] {resolved_name} ({resolved_id})")
    else:
        console.print(f"[{INFO_STYLE}]Organization ID:[/{INFO_STYLE}] {resolved_id}")


if __name__ == "__main__":
    app()