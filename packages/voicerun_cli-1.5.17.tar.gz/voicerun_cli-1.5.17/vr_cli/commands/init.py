"""
vr init command - Initialize a new voice agent project.
"""

import re
from pathlib import Path
from typing import Optional, List

import questionary
import typer

from vr_cli.utils.utils import (
    console,
    print_success,
    print_error,
    prompt,
)
from ..entities.agent_template import AgentTemplateRepository

START_FROM_SCRATCH = "Start from scratch"


def _humanize_template_name(name: str) -> str:
    """Convert a template name like 'vr-retail-cart-agent' to 'Retail Cart Agent'."""
    name = name.removeprefix("vr-")
    return name.replace("-", " ").replace("_", " ").title()


def get_template_path() -> Path:
    """Get the path to the templates directory."""
    return Path(__file__).parent.parent / "templates"


def render_template(content: str, **kwargs) -> str:
    """Render a template with the given variables.

    Uses simple {variable} replacement to avoid conflicts with Go/Helm templates
    that use {{ }} syntax.
    """
    for key, value in kwargs.items():
        # Only replace {key} patterns that are not part of {{ }} (Go templates)
        # Match {key} but not {{key}} or {key}}
        pattern = r'(?<!\{)\{' + re.escape(key) + r'\}(?!\})'
        content = re.sub(pattern, str(value), content)

    return content


def get_dest_path(template_rel_path: str) -> str:
    """Convert template path to destination path.

    Handles special cases:
    - 'gitignore' -> '.gitignore'
    - 'vrignore' -> '.vrignore'
    - 'voicerun/' -> '.voicerun/'
    """
    dest = template_rel_path

    # Handle gitignore -> .gitignore
    if dest == "gitignore":
        dest = ".gitignore"

    # Handle vrignore -> .vrignore
    if dest == "vrignore":
        dest = ".vrignore"

    # Handle voicerun/ -> .voicerun/
    if dest.startswith("voicerun/"):
        dest = ".voicerun/" + dest[len("voicerun/"):]

    return dest


def init(
    name: str = typer.Argument(
        None,
        help="Project name. Creates a folder with this name.",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip prompts and use default values.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing project files.",
    ),
    template: Optional[str] = typer.Option(
        None,
        "--template",
        "-t",
        help="Initialize from a template (name or ID).",
    ),
    var: Optional[List[str]] = typer.Option(
        None,
        "--var",
        help="Template variable as key=value (can be repeated).",
    ),
):
    """Initialize a new voice agent project with handler and configuration files."""

    if template:
        # Template-based initialization
        repo = AgentTemplateRepository()
        template_entity = repo.get_by_name_or_id(template)

        if not template_entity:
            print_error(f"Template not found: {template}")
            raise typer.Exit(1)

        # Fetch full template (with files from GCS) via getById
        template_entity = repo.get_by_id(template_entity.id)

        # Use name argument or default to template name
        project_name = name or template_entity.name

        # Collect variable values from --var args
        template_vars = {}
        if var:
            for v in var:
                if "=" not in v:
                    print_error(f"Invalid variable format: {v}. Use key=value.")
                    raise typer.Exit(1)
                key, value = v.split("=", 1)
                template_vars[key] = value

        # Prompt for any missing required variables
        variables = template_entity.variables or []
        for variable in variables:
            var_name = variable if isinstance(variable, str) else variable.get("name", "")
            if var_name and var_name not in template_vars:
                if yes:
                    print_error(f"Missing required variable: {var_name}. Use --var {var_name}=value")
                    raise typer.Exit(1)
                template_vars[var_name] = prompt(f"{var_name}")

        # Create project directory
        project_dir = Path.cwd() / project_name

        if project_dir.exists():
            if any(project_dir.iterdir()):
                if not force:
                    print_error(
                        f"Directory '{project_name}' exists and is not empty. "
                        "Use --force to overwrite."
                    )
                    raise typer.Exit(1)
        else:
            project_dir.mkdir(parents=True)

        # Render template files
        created_files = []
        files = template_entity.files or {}

        for file_path, content in files.items():
            # Replace variables in both path and content
            rendered_path = render_template(file_path, **template_vars)
            rendered_content = render_template(content, **template_vars)

            # Override agent name in agent.yaml with the user's project name
            if rendered_path.endswith("agent.yaml"):
                rendered_content = re.sub(
                    r'^name:.*$', f'name: {project_name}', rendered_content, count=1, flags=re.MULTILINE
                )

            dest_path = project_dir / rendered_path
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            with open(dest_path, "w") as f:
                f.write(rendered_content)

            created_files.append(rendered_path)

        _scaffold_agent_instructions(project_dir, created_files)

        # Print summary
        console.print()
        print_success(f"Project '{project_name}' initialized from template '{template_entity.name}'!")
        console.print()
        console.print("[bold]Created files:[/bold]")
        for file in created_files:
            console.print(f"  [cyan]{file}[/cyan]")

        console.print()
        console.print("[dim]Next steps:[/dim]")
        console.print(f"  1. [cyan]cd {project_name}[/cyan]")
        console.print("  2. Edit [cyan]handler.py[/cyan] to customize your logic")
        console.print("  3. Run [cyan]vr push[/cyan] to push your agent to the server")
        return

    # Default behavior: interactive wizard (or scaffold with defaults via --yes)

    # Get project name
    if not name:
        if yes:
            print_error("Project name is required when using --yes")
            raise typer.Exit(1)
        name = prompt("Project name")

    project_name = name

    # Gather additional configuration
    if yes:
        description = ""
    else:
        description = typer.prompt(
            "Description (optional)",
            default="",
            show_default=False,
        )
        console.print()

    # --- Wizard: template selection ---
    selected_template_name = None

    if not yes:
        # Fetch available templates
        try:
            repo = AgentTemplateRepository()
            templates = repo.get()
        except Exception:
            templates = []

        template_choices = [questionary.Choice(title=START_FROM_SCRATCH, value=START_FROM_SCRATCH)]
        for t in templates:
            display_name = t.description or _humanize_template_name(t.name)
            template_choices.append(questionary.Choice(title=display_name, value=t.name))

        selected_template_name = questionary.select(
            "Start from scratch or choose a template:",
            choices=template_choices,
            default=START_FROM_SCRATCH,
        ).ask()

        if selected_template_name is None:
            raise typer.Abort()

    # --- If a template was selected, use the template-based init path ---
    if selected_template_name and selected_template_name != START_FROM_SCRATCH:
        repo = AgentTemplateRepository()
        template_entity = repo.get_by_name_or_id(selected_template_name)

        if not template_entity:
            print_error(f"Template not found: {selected_template_name}")
            raise typer.Exit(1)

        template_entity = repo.get_by_id(template_entity.id)

        # Collect variable values from --var args
        template_vars = {}
        if var:
            for v in var:
                if "=" not in v:
                    print_error(f"Invalid variable format: {v}. Use key=value.")
                    raise typer.Exit(1)
                key, value = v.split("=", 1)
                template_vars[key] = value

        # Prompt for any missing required variables
        variables = template_entity.variables or []
        for variable in variables:
            var_name = variable if isinstance(variable, str) else variable.get("name", "")
            if var_name and var_name not in template_vars:
                template_vars[var_name] = prompt(f"{var_name}")

        # Create project directory
        project_dir = Path.cwd() / project_name

        if project_dir.exists():
            if any(project_dir.iterdir()):
                if not force:
                    print_error(
                        f"Directory '{project_name}' exists and is not empty. "
                        "Use --force to overwrite."
                    )
                    raise typer.Exit(1)
        else:
            project_dir.mkdir(parents=True)

        # Render template files
        created_files = []
        files = template_entity.files or {}

        for file_path, content in files.items():
            rendered_path = render_template(file_path, **template_vars)
            rendered_content = render_template(content, **template_vars)

            if rendered_path.endswith("agent.yaml"):
                rendered_content = re.sub(
                    r'^name:.*$', f'name: {project_name}', rendered_content, count=1, flags=re.MULTILINE
                )

            dest_path = project_dir / rendered_path
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            with open(dest_path, "w") as f:
                f.write(rendered_content)

            created_files.append(rendered_path)

        _scaffold_agent_instructions(project_dir, created_files)

        # Print summary
        console.print()
        print_success(f"Project '{project_name}' initialized from template '{template_entity.name}'!")
        _print_created_files(created_files)
        _print_next_steps(project_name)
        return

    # --- "Start from scratch" or --yes: scaffold from local templates ---

    # Create project directory
    project_dir = Path.cwd() / project_name

    if project_dir.exists():
        if any(project_dir.iterdir()):
            if not force:
                print_error(
                    f"Directory '{project_name}' exists and is not empty. "
                    "Use --force to overwrite."
                )
                raise typer.Exit(1)
    else:
        project_dir.mkdir(parents=True)

    # Template variables
    template_vars = {
        "project_name": project_name,
        "description": description or f"Voice agent project: {project_name}",
    }

    # Walk templates directory and copy files
    templates_dir = get_template_path()
    created_files = []

    TEMPLATE_EXTENSIONS = {".md", ".py", ".txt", ".yaml", ".yml"}
    TEMPLATE_NAMES = {"gitignore", "vrignore"}
    for template_file in sorted(templates_dir.rglob("*")):
        if template_file.is_dir():
            continue

        # Only process known text template files
        if template_file.suffix not in TEMPLATE_EXTENSIONS and template_file.name not in TEMPLATE_NAMES:
            continue

        # Get relative path from templates dir
        rel_path = template_file.relative_to(templates_dir)

        # Convert to destination path
        dest_rel_path = get_dest_path(str(rel_path))
        dest_path = project_dir / dest_rel_path

        # Create parent directories
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        # Read template content
        try:
            with open(template_file, "r") as f:
                content = f.read()
        except UnicodeDecodeError:
            console.print(f"  [yellow]Skipping non-text file: {rel_path}[/yellow]")
            continue

        # Render template variables
        content = render_template(content, **template_vars)

        # Write to destination
        with open(dest_path, "w") as f:
            f.write(content)

        created_files.append(dest_rel_path)

    _scaffold_agent_instructions(project_dir, created_files)

    # Print summary
    console.print()
    print_success(f"Project '{project_name}' initialized successfully!")
    _print_created_files(created_files)
    _print_next_steps(project_name)


_AGENT_INSTRUCTIONS = """\
When you need VoiceRun documentation, use the `vr docs` CLI commands via Bash. Do not use MCP tools or fetch docs from the web.

Available commands:
- `vr docs topics` — list all doc topics
- `vr docs topic <name>` — list pages in a topic
- `vr docs search "<query>"` — search docs
- `vr docs read <slug>` — read a doc page
"""


def _scaffold_agent_instructions(project_dir: Path, created_files: list):
    """Create .claude/CLAUDE.md and AGENTS.md with VoiceRun-specific instructions."""
    # .claude/CLAUDE.md for Claude Code
    claude_dir = project_dir / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)
    claude_md = claude_dir / "CLAUDE.md"
    claude_md.write_text(_AGENT_INSTRUCTIONS)
    created_files.append(".claude/CLAUDE.md")

    # AGENTS.md for Codex and OpenClaw
    agents_md = project_dir / "AGENTS.md"
    agents_md.write_text(_AGENT_INSTRUCTIONS)
    created_files.append("AGENTS.md")


FILE_DESCRIPTIONS = {
    "handler.py": "your agent's main logic",
    "config.py": "agent configuration and settings",
    "tools.py": "tool definitions for LLM function calling",
    "requirements.txt": "Python dependencies",
    "agent.yaml": "agent metadata",
    ".gitignore": "git ignore rules",
    ".vrignore": "deploy ignore rules",
    "CLAUDE.md": "instructions for Claude Code",
    "AGENTS.md": "instructions for Codex and OpenClaw",
}


def _print_created_files(created_files: list):
    """Print the created files list with descriptions for key files."""
    console.print()
    console.print("[bold]Created files:[/bold]")
    for file in created_files:
        basename = str(file).split("/")[-1]
        desc = FILE_DESCRIPTIONS.get(basename, "")
        if desc:
            console.print(f"  [cyan]{file}[/cyan] [dim]— {desc}[/dim]")
        else:
            console.print(f"  [cyan]{file}[/cyan]")


def _print_next_steps(project_name: str):
    """Print the common next-steps block."""
    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print(f"  1. [cyan]cd {project_name}[/cyan]")
    console.print("  2. Edit [cyan]handler.py[/cyan] to customize your logic")
    console.print("  3. Run [cyan]vr push[/cyan] to upload your agent")
    console.print("  4. Run [cyan]vr debug[/cyan] to test your agent interactively")
    console.print("  5. Configure STT, recording, and phone numbers at")
    console.print("     [cyan]app.voicerun.com[/cyan] > Agents > your agent > Environments > Edit")
    console.print()
    console.print("Docs: [cyan]https://docs.voicerun.com[/cyan]")
