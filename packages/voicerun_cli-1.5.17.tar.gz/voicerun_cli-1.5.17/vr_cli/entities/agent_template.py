from typing import List, Optional
from urllib.parse import urlencode

from ..utils.utils import is_uuid, make_request
from .base import BaseEntity, BaseRepository


class AgentTemplate(BaseEntity):
    def __init__(
        self,
        id: str = None,
        name: str = None,
        description: str = None,
        category: str = None,
        is_public: bool = False,
        variables: list = None,
        files: dict = None,
        code: str = None,
        organization_id: str = None,
        created_by: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        super().__init__(id=id, created_at=created_at, updated_at=updated_at, deleted_at=deleted_at, **kwargs)
        self.name = name
        self.description = description
        self.category = category
        self.is_public = is_public
        self.variables = variables
        self.files = files
        self.code = code
        self.organization_id = organization_id
        self.created_by = created_by


class AgentTemplateRepository(BaseRepository):
    def __init__(self):
        super().__init__(
            name="agent_template",
            endpoint="/v1/agent-templates",
            entity_class=AgentTemplate,
        )

    def get(self, query: Optional[dict] = None) -> List[AgentTemplate]:
        """Override to send plain query params instead of filters[key]=value.

        The /v1/agent-templates list endpoint reads its filter via
        @QueryParam('name'), i.e. ?name=X. That's different from the nested
        ?filters[name]=X format BaseRepository.get uses by default (and that
        other controllers like sessions, invites, and deployments DO parse).
        Overriding here keeps the plain format scoped to templates so other
        entity repositories aren't affected.
        """
        query = query or {}
        filtered = {k: v for k, v in query.items() if v is not None}
        query_string = urlencode(filtered)
        url = f"{self.endpoint}?{query_string}" if query_string else self.endpoint
        response = make_request(url)

        if not response or "data" not in response:
            return []

        data = response["data"]
        if not isinstance(data, list):
            data = [data]
        return [self._create_entity(item) for item in data]

    def get_by_name_or_id(self, name_or_id: str) -> AgentTemplate:
        """Resolve a template by id or name, preferring the non-public match when both exist.

        The API now guarantees (name, organizationId) uniqueness among non-deleted
        templates, so within the caller's visible set there is at most one public
        and one org-private template that share a name. If both are visible (e.g.
        an org has a private template named the same as a public one), prefer the
        private one — it's the more specific match and is what a user typically
        means when scaffolding from their own org's templates.
        """
        if is_uuid(name_or_id):
            return self.get_by_id(name_or_id)

        matches = [entity for entity in self.get() if entity.name == name_or_id]
        if not matches:
            return None

        return next(
            (entity for entity in matches if not getattr(entity, "is_public", False)),
            matches[0],
        )
