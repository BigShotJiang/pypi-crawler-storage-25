---
name: vr-review-docs
description: Read VoiceRun documentation using the vr docs CLI. Use this to learn about events, context, LLM completions, TTS, STT, and agent patterns. NEVER fetch docs from the web — always use vr docs commands.
---

# Review VoiceRun Documentation

You are helping the user explore VoiceRun documentation. Use the `vr docs` CLI commands to find and read docs. **NEVER** fetch docs from the web or use MCP tools — always use `vr docs`.

## Available commands

```bash
# List all documentation topics
vr docs topics

# List pages within a topic
vr docs topic <topic-name>

# Search docs by keyword
vr docs search "<query>"

# Read a specific doc page
vr docs read <slug>
```

## Workflow

1. **Start by listing topics** to see what's available:

```bash
vr docs topics
```

2. **Browse a topic** to see its pages:

```bash
vr docs topic events
vr docs topic context
vr docs topic agent-building
```

3. **Search for something specific**:

```bash
vr docs search "tool calling"
vr docs search "text to speech"
vr docs search "background tasks"
```

4. **Read a page** using the slug returned by topic or search:

```bash
vr docs read <slug>
```

## Common topics

| Topic | What it covers |
|-------|---------------|
| `agent-building` | Core agent development, handler functions, architecture |
| `events` | Input/output events (StartEvent, TextEvent, TimeoutEvent, etc.) |
| `context` | Session state, data management, background tasks, A/B testing |
| `primfunctions_completions` | LLM access (OpenAI, Anthropic, Google) with streaming and tool calling |
| `speech-to-text` | STT models, configuration, transcription events |
| `voices` | TTS voices, providers, voice configuration |
| `examples` | Working code examples (greeting, LLM integration, tool calling) |
| `integrations` | Webhooks, telephony providers (Twilio, Telnyx), React SDK |
| `getting-started` | Setup and onboarding guides |

## Tips

- If the user asks "how do I do X?", search first, then read the most relevant page
- Read the full page before summarizing — don't guess from titles alone
- If a page references another page, read that too for complete context
- When helping with code, cross-reference the `examples` topic for working patterns
