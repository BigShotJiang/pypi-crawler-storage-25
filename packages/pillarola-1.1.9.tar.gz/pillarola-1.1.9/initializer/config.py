import os
import platform

APP_NAME = "pillarola"


def get_base_dir():
    system = platform.system()

    if system == "Windows":
        return os.path.join(os.getenv("LOCALAPPDATA"), APP_NAME)

    elif system == "Darwin":  # macOS
        return os.path.join(os.path.expanduser("~/Library/Application Support"), APP_NAME)

    else:  # Linux + others
        return os.path.join(os.path.expanduser("~/.local/share"), APP_NAME)


BASE_DIR = get_base_dir()

FFMPEG_DIR = os.path.join(BASE_DIR, "ffmpeg")

FFMPEG_EXE = "ffmpeg.exe" if platform.system() == "Windows" else "ffmpeg"

FFMPEG_PATH = os.path.join(FFMPEG_DIR, FFMPEG_EXE)