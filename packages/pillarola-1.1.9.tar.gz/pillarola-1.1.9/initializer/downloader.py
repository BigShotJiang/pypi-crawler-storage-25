import os
import yt_dlp
import shutil


print("Establishing connection to server...")


# -----------------------------
# FORMAT HANDLER
# -----------------------------
def get_format():
    if shutil.which("ffmpeg"):
        return "bestvideo+bestaudio/best"
    return "best"


# -----------------------------
# PROGRESS HOOK
# -----------------------------
def progress_hook(d):
    if d["status"] == "downloading":
        percent = d.get("_percent_str", "").strip()
        speed = d.get("_speed_str", "N/A")
        eta = d.get("_eta_str", "N/A")
        print(f"\r📥 {percent} | ⚡ {speed} | ⏳ {eta}", end="", flush=True)

    elif d["status"] == "finished":
        print("\n✅ Download complete! Processing...")


# -----------------------------
# MAIN DOWNLOAD FUNCTION
# -----------------------------
def download_video(url: str, audio_only: bool = False):
    downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(downloads_dir, exist_ok=True)

    ffmpeg_path = shutil.which("ffmpeg")

    ydl_opts = {
        "format": "bestaudio/best" if audio_only else get_format(),
        "outtmpl": os.path.join(downloads_dir, "%(title).50s.%(ext)s"),
        "restrictfilenames": True,
        "progress_hooks": [progress_hook],
        "noplaylist": True,
        "quiet": True,
    }

    # only set ffmpeg if available
    if ffmpeg_path:
        ydl_opts["ffmpeg_location"] = ffmpeg_path

    if not audio_only:
        ydl_opts["merge_output_format"] = "mp4"

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            print(f"\n🚀 Starting: {info.get('title', 'Unknown')}")
            ydl.download([url])

    except Exception as e:
        print(f"\n❌ Download failed: {e}")