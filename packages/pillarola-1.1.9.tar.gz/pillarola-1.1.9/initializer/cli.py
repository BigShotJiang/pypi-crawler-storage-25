import typer

from .ffmpeg import ensure_ffmpeg
from initializer.downloader import download_video
from .ui import banner, start_download, success, error

app = typer.Typer()


@app.command(help="⚡ Download videos instantly from any URL")
def main(
    url: str = typer.Argument(..., help="Video URL to download"),
    audio: bool = typer.Option(False, "--audio", help="Download audio only"),
):
    """
    Main download command
    """
    pass
    banner()

    try:
        ffmpeg_path = ensure_ffmpeg()

        start_download(url)

        download_video(
            url=url,
            ffmpeg_path=ffmpeg_path,
            audio_only=audio
        )

        success()

    except Exception as e:
        error(str(e))


if __name__ == "__main__":
    app()