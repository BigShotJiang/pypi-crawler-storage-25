"""RunLLM Lite engine client."""

from __future__ import annotations

import asyncio
import contextlib
import json
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from loguru import logger
from websockets.asyncio.client import connect as ws_connect
from websockets.exceptions import ConnectionClosed

from runllm_lite_cli import __version__
from runllm_lite_cli.archive import (
    RepoSnapshotReuse,
    collect_git_repo_metadata,
    create_repo_archive,
)
from runllm_lite_cli.config import CliConfig
from runllm_lite_cli.protocol import (
    CloseSessionMessage,
    CommandRequestMessage,
    CommandResultMessage,
    ErrorMessage,
    FinalRcaMessage,
    OpenCodeEventMessage,
    ProgressMessage,
    RepoMetadata,
    RepoUploadCompleteMessage,
    ResumeSessionMessage,
    SessionAcceptedMessage,
    SessionInitMessage,
    UserMessage,
    parse_engine_message,
)
from runllm_lite_cli.session_window import SessionWindow
from runllm_lite_cli.tools import configured_tool_capabilities, execute_tool_request

ARCHIVE_CHUNK_BYTES = 512 * 1024
WEBSOCKET_PING_INTERVAL_SEC = 10
WEBSOCKET_PING_TIMEOUT_SEC = 20
WEBSOCKET_RECONNECT_RETRY_SEC = 2
WEBSOCKET_RECONNECT_MAX_WAIT_SEC = 60
PROACTIVE_GCP_DISCOVERY_PROMPT = """This is a proactive RunLLM discovery shown before the user asks their first question.

Inspect the user's configured GCP observability data using as few tool calls as possible. Find one recent meaningful Error Reporting group or recent high-severity logging signal. Explain what it appears to be about in a helpful, non-alarming tone.

Format the final answer for proactive surfacing:
- Start with: "I proactively checked recent GCP signals and found..."
- Keep it under 5 sentences.
- Mention the evidence source briefly.
- If there is no recent signal, say that clearly and suggest what the user can ask next.
- Do not use RCA formatting unless there is a clear incident-like signal.
"""


class EngineClientError(Exception):
    """Raised when the CLI cannot talk to the Lite engine."""


class ProactiveDiscoverySession:
    """Background RunLLM session that surfaces one proactive discovery result."""

    def __init__(self, config: CliConfig, repo_path: Path, api_key: str, prompt_text: str) -> None:
        self.config = config
        self.repo_path = repo_path
        self.api_key = api_key
        self.prompt_text = prompt_text
        self.ready_event = threading.Event()
        self.final_text: str | None = None
        self.error: str | None = None
        self._closed_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run_thread,
            name="runllm-proactive-discovery",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def discard(self) -> None:
        self._closed_event.set()

    def close(self) -> None:
        self._closed_event.set()

    def _run_thread(self) -> None:
        try:
            asyncio.run(self._run())
        except Exception as e:
            logger.warning("Proactive discovery failed: error={}\n", e)
            self.error = str(e)
            self.ready_event.set()

    async def _close_ws(self, ws: Any, *, reason: str) -> None:
        try:
            await _send_json(ws, CloseSessionMessage(reason=reason))
        except Exception as e:
            logger.debug("Failed to send proactive discovery close message: {}\n", e)
        finally:
            await ws.close()

    async def _wait_for_close(self) -> None:
        while not self._closed_event.is_set():
            await asyncio.sleep(0.2)

    async def _run(self) -> None:
        archive = None
        ws: Any | None = None
        try:
            repo_metadata = collect_git_repo_metadata(self.repo_path)
            if self._closed_event.is_set():
                return
            repo_snapshot = (
                lookup_repo_snapshot(self.config, self.api_key, repo_metadata)
                if repo_metadata is not None
                else None
            )
            if self._closed_event.is_set():
                return
            if repo_snapshot is None:
                archive = create_repo_archive(self.repo_path)
                repo_metadata = archive.metadata
            if self._closed_event.is_set():
                return
            session_id, session_token = create_session(self.config, self.api_key)
            logger.info(
                "Starting proactive discovery session: session_id={} repo_path={}\n",
                session_id,
                self.repo_path,
            )
            ws = await _open_websocket(self.config, session_id, session_token)
            if self._closed_event.is_set():
                await self._close_ws(ws, reason="proactive_discovery_discarded")
                ws = None
                return
            await _send_json(
                ws,
                SessionInitMessage(
                    question=self.prompt_text,
                    cli_version=__version__,
                    repo=repo_metadata,
                    repo_snapshot_id=repo_snapshot.repo_snapshot_id if repo_snapshot else None,
                    available_tools=configured_tool_capabilities(self.config),
                ),
            )
            if archive is not None:
                await _upload_archive(ws, archive.path)
            response_task = asyncio.create_task(_run_until_final(ws, self.config))
            close_task = asyncio.create_task(self._wait_for_close())
            done, pending = await asyncio.wait(
                {response_task, close_task},
                return_when=asyncio.FIRST_COMPLETED,
            )
            if close_task in done and self._closed_event.is_set():
                response_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await response_task
                await self._close_ws(ws, reason="proactive_discovery_discarded")
                ws = None
                return
            close_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await close_task
            for task in pending:
                task.cancel()
            self.final_text = response_task.result()
            self.ready_event.set()
            await ws.close()
            ws = None
        finally:
            if ws is not None:
                await ws.close()
            if archive is not None:
                archive.path.unlink(missing_ok=True)


def _request_headers(api_key: str | None = None) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["x-api-key"] = api_key
    return headers


def _websocket_url(config: CliConfig, session_id: str, session_token: str) -> str:
    parsed = urllib.parse.urlparse(config.engine_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    path = f"/v1/sessions/{session_id}/ws"
    query = urllib.parse.urlencode({"session_token": session_token})
    return urllib.parse.urlunparse((scheme, parsed.netloc, path, "", query, ""))


async def _open_websocket(config: CliConfig, session_id: str, session_token: str) -> Any:
    ws_url = _websocket_url(config, session_id, session_token)
    logger.info("Connecting to Lite engine WebSocket: session_id={} url={}\n", session_id, ws_url)
    return await ws_connect(
        ws_url,
        additional_headers=_request_headers(),
        close_timeout=0.1,
        open_timeout=30,
        ping_interval=WEBSOCKET_PING_INTERVAL_SEC,
        ping_timeout=WEBSOCKET_PING_TIMEOUT_SEC,
        max_size=None,
    )


async def _resume_websocket(config: CliConfig, session_id: str, session_token: str) -> Any:
    deadline = asyncio.get_running_loop().time() + WEBSOCKET_RECONNECT_MAX_WAIT_SEC
    while True:
        ws: Any | None = None
        try:
            ws = await _open_websocket(config, session_id, session_token)
            await _send_json(ws, ResumeSessionMessage())
            while True:
                raw = await ws.recv()
                if not isinstance(raw, str):
                    continue
                message = parse_engine_message(raw)
                if isinstance(message, SessionAcceptedMessage):
                    continue
                if isinstance(message, ProgressMessage) and message.message == "Session resumed":
                    logger.info("Resumed Lite engine WebSocket: session_id={}\n", session_id)
                    return ws
                if isinstance(message, ErrorMessage):
                    if message.code == "session_already_attached":
                        await ws.close()
                        break
                    await ws.close()
                    raise EngineClientError(f"{message.code}: {message.message}")
        except ConnectionClosed:
            if ws is not None:
                await ws.close()
        if asyncio.get_running_loop().time() >= deadline:
            raise EngineClientError("Timed out waiting to resume Lite engine session.")
        await asyncio.sleep(WEBSOCKET_RECONNECT_RETRY_SEC)


def create_session(config: CliConfig, api_key: str) -> tuple[str, str]:
    url = f"{config.engine_url}/v1/sessions"
    request = urllib.request.Request(
        url,
        data=b"{}",
        headers=_request_headers(api_key),
        method="POST",
    )
    logger.info("Creating Lite investigation session: url={}\n", url)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise EngineClientError(f"Engine rejected session creation: {e.code} {body}") from e
    except Exception as e:
        raise EngineClientError(f"Failed to create engine session: {e}") from e

    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        raise EngineClientError(f"Engine returned invalid session response: {payload}")
    session_token = payload.get("session_token")
    if not isinstance(session_token, str) or not session_token:
        raise EngineClientError(f"Engine returned invalid session token response: {payload}")
    logger.info("Created Lite investigation session: session_id={}\n", session_id)
    return session_id, session_token


def lookup_repo_snapshot(
    config: CliConfig,
    api_key: str,
    repo_metadata: RepoMetadata,
) -> RepoSnapshotReuse | None:
    if not repo_metadata.root_name or not repo_metadata.commit:
        return None
    url = f"{config.engine_url}/v1/repo-snapshots/lookup"
    request = urllib.request.Request(
        url,
        data=json.dumps({"repo": repo_metadata.model_dump(mode="json")}).encode("utf-8"),
        headers=_request_headers(api_key),
        method="POST",
    )
    logger.info(
        "Looking up reusable repo snapshot: url={} root_name={} commit={}\n",
        url,
        repo_metadata.root_name,
        repo_metadata.commit,
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        logger.warning("Repo snapshot lookup failed: status={} body={}\n", e.code, body)
        return None
    except Exception as e:
        logger.warning("Repo snapshot lookup failed: error={}\n", e)
        return None

    if not payload.get("matched"):
        return None
    repo_snapshot_id = payload.get("repo_snapshot_id")
    object_uri = payload.get("object_uri")
    if not isinstance(repo_snapshot_id, int) or not isinstance(object_uri, str):
        logger.warning("Ignoring invalid repo snapshot lookup response: payload={}\n", payload)
        return None
    logger.info(
        "Reusing repo snapshot: repo_snapshot_id={} object_uri={}\n",
        repo_snapshot_id,
        object_uri,
    )
    return RepoSnapshotReuse(repo_snapshot_id=repo_snapshot_id, object_uri=object_uri)


async def _send_json(ws: Any, model: Any) -> None:
    payload = model.model_dump(mode="json")
    await ws.send(json.dumps(payload))


async def _upload_archive(ws: Any, archive_path: Path) -> None:
    total_bytes = archive_path.stat().st_size
    sent_bytes = 0
    chunk_count = 0
    logger.info("Uploading repo archive: archive={} total_bytes={}\n", archive_path, total_bytes)
    with archive_path.open("rb") as file:
        while True:
            chunk = file.read(ARCHIVE_CHUNK_BYTES)
            if not chunk:
                break
            await ws.send(chunk)
            sent_bytes += len(chunk)
            chunk_count += 1
            logger.info(
                "Uploaded repo archive chunk: chunk_count={} sent_bytes={} total_bytes={}\n",
                chunk_count,
                sent_bytes,
                total_bytes,
            )
    await _send_json(ws, RepoUploadCompleteMessage())
    logger.info(
        "Repo archive upload complete: archive={} total_bytes={} chunk_count={}\n",
        archive_path,
        total_bytes,
        chunk_count,
    )


async def _execute_tool_request_with_window(
    config: CliConfig,
    message: CommandRequestMessage,
    window: SessionWindow | None,
) -> CommandResultMessage:
    started_at = window.render_tool_start(message) if window is not None else None
    result = await execute_tool_request(config, message)
    if window is not None and started_at is not None:
        window.render_tool_result(message, result, started_at)
    return result


async def _run_until_final(
    ws: Any,
    config: CliConfig,
) -> str:
    async for raw in ws:
        if not isinstance(raw, str):
            logger.warning("Ignoring unexpected binary message from engine: bytes={}\n", len(raw))
            continue
        message = parse_engine_message(raw)
        if isinstance(message, SessionAcceptedMessage):
            logger.info("Engine accepted session: session_id={}\n", message.session_id)
        elif isinstance(message, ProgressMessage):
            logger.info(
                "Engine progress: session_id={} message={} metadata={}\n",
                message.session_id,
                message.message,
                message.metadata,
            )
        elif isinstance(message, CommandRequestMessage):
            result = await execute_tool_request(config, message)
            await _send_json(ws, result)
        elif isinstance(message, OpenCodeEventMessage):
            logger.debug(
                "OpenCode event received: session_id={} keys={}\n",
                message.session_id,
                sorted(message.event.keys()),
            )
        elif isinstance(message, FinalRcaMessage):
            logger.info(
                "RunLLM response received: session_id={} metadata={} bytes={}\n",
                message.session_id,
                message.metadata,
                len(message.rca.encode()),
            )
            return message.rca
        elif isinstance(message, ErrorMessage):
            logger.warning(
                "Engine error: session_id={} code={} message={} metadata={}\n",
                message.session_id,
                message.code,
                message.message,
                message.metadata,
            )
            raise EngineClientError(f"{message.code}: {message.message}")
    raise EngineClientError("Engine WebSocket closed before RunLLM returned a response.")


async def run_session(
    config: CliConfig,
    question: str,
    repo_path: Path,
    *,
    api_key: str,
    interactive: bool,
) -> int:
    archive = None
    ws: Any | None = None
    window = SessionWindow(show_initial_header=not interactive)
    try:
        repo_metadata = collect_git_repo_metadata(repo_path)
        available_tools = configured_tool_capabilities(config)
        window.start_session(repo=repo_metadata, tools=available_tools, cli_version=__version__)
        window.start_turn(question)
        repo_snapshot = (
            lookup_repo_snapshot(config, api_key, repo_metadata)
            if repo_metadata is not None
            else None
        )
        if repo_snapshot is None:
            archive = create_repo_archive(repo_path)
            repo_metadata = archive.metadata
            window.start_session(repo=repo_metadata, tools=available_tools, cli_version=__version__)
            window.render_progress("Repo archive stored")
        session_id, session_token = create_session(config, api_key)
    except Exception as e:
        window.render_error("setup_failed", str(e))
        window.complete_turn()
        raise
    try:
        ws = await _open_websocket(config, session_id, session_token)
        window.set_connected(True)
        await _send_json(
            ws,
            SessionInitMessage(
                question=question,
                cli_version=__version__,
                repo=repo_metadata,
                repo_snapshot_id=repo_snapshot.repo_snapshot_id if repo_snapshot else None,
                available_tools=available_tools,
            ),
        )
        logger.info(
            "Sent session init: session_id={} question_bytes={}\n",
            session_id,
            len(question.encode()),
        )
        if archive is not None:
            window.render_progress("Uploading repository snapshot")
            await _upload_archive(ws, archive.path)

        while True:
            if ws is None:
                ws = await _resume_websocket(config, session_id, session_token)
                window.set_connected(True)
            raw = await ws.recv()
            if not isinstance(raw, str):
                logger.warning(
                    "Ignoring unexpected binary message from engine: bytes={}\n", len(raw)
                )
                continue
            message = parse_engine_message(raw)
            if isinstance(message, SessionAcceptedMessage):
                logger.info("Engine accepted session: session_id={}\n", message.session_id)
            elif isinstance(message, ProgressMessage):
                logger.info(
                    "Engine progress: session_id={} message={} metadata={}\n",
                    message.session_id,
                    message.message,
                    message.metadata,
                )
                window.render_progress(message.message)
            elif isinstance(message, CommandRequestMessage):
                result = await _execute_tool_request_with_window(config, message, window)
                await _send_json(ws, result)
            elif isinstance(message, OpenCodeEventMessage):
                logger.debug(
                    "OpenCode event received: session_id={} keys={}\n",
                    message.session_id,
                    sorted(message.event.keys()),
                )
                window.render_opencode_event(message.event)
            elif isinstance(message, FinalRcaMessage):
                logger.info(
                    "RunLLM response received: session_id={} metadata={} bytes={}\n",
                    message.session_id,
                    message.metadata,
                    len(message.rca.encode()),
                )
                window.render_final_response(message.rca, message.metadata)
                if not interactive:
                    window.complete_turn()
                    return 0
                await ws.close()
                window.set_connected(False)
                ws = None
                window.complete_turn()
                try:
                    next_prompt = await asyncio.to_thread(window.read_prompt)
                except KeyboardInterrupt:
                    logger.info(
                        "Interactive session interrupted by user: session_id={}\n", session_id
                    )
                    raise SystemExit(130)
                if next_prompt is None:
                    ws = await _resume_websocket(config, session_id, session_token)
                    window.set_connected(True)
                    await _send_json(ws, CloseSessionMessage(reason="user_exit"))
                    return 0
                ws = await _resume_websocket(config, session_id, session_token)
                window.set_connected(True)
                window.start_turn(next_prompt)
                try:
                    await _send_json(ws, UserMessage(message=next_prompt))
                except ConnectionClosed:
                    ws = await _resume_websocket(config, session_id, session_token)
                    window.set_connected(True)
                    await _send_json(ws, UserMessage(message=next_prompt))
            elif isinstance(message, ErrorMessage):
                logger.warning(
                    "Engine error: session_id={} code={} message={} metadata={}\n",
                    message.session_id,
                    message.code,
                    message.message,
                    message.metadata,
                )
                window.render_error(message.code, message.message)
                window.complete_turn()
                return 1
    except ConnectionClosed as e:
        logger.info("Engine WebSocket closed: session_id={} error={}\n", session_id, e)
        if interactive:
            window.render_error(
                "connection_closed",
                "Engine connection closed during a response. Try another prompt to resume.",
            )
        else:
            window.render_error(
                "connection_closed",
                "Engine connection closed. Start a new session with `runllm`.",
            )
        window.complete_turn()
        return 1
    finally:
        if ws is not None:
            await ws.close()
        if archive is not None:
            archive.path.unlink(missing_ok=True)


async def run_ask(config: CliConfig, question: str, repo_path: Path, api_key: str) -> int:
    return await run_session(config, question, repo_path, api_key=api_key, interactive=False)


async def run_interactive(config: CliConfig, question: str, repo_path: Path, api_key: str) -> int:
    return await run_session(config, question, repo_path, api_key=api_key, interactive=True)
