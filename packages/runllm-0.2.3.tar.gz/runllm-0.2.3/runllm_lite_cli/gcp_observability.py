"""Local Google Cloud observability execution for engine-requested tool calls."""

from __future__ import annotations

import json
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from loguru import logger

from runllm_lite_cli.config import CliConfig, GcpObservabilityConfig
from runllm_lite_cli.kubectl import _truncate_output
from runllm_lite_cli.protocol import (
    CommandRequestMessage,
    CommandResultMessage,
    ToolActionCapability,
    ToolCapability,
)

GCP_OBSERVABILITY_TOOL_NAME = "gcp_observability"
CLOUD_ERROR_REPORTING_BASE_URL = "https://clouderrorreporting.googleapis.com/v1beta1"
CLOUD_MONITORING_BASE_URL = "https://monitoring.googleapis.com/v3"
ERROR_REPORTING_TIME_RANGE_ALIASES = {
    "1h": "PERIOD_1_HOUR",
    "6h": "PERIOD_6_HOURS",
    "1d": "PERIOD_1_DAY",
    "7d": "PERIOD_1_WEEK",
    "30d": "PERIOD_30_DAYS",
    "PERIOD_7_DAYS": "PERIOD_1_WEEK",
    "PERIOD_1_WEEK": "PERIOD_1_WEEK",
    "PERIOD_30_DAYS": "PERIOD_30_DAYS",
    "PERIOD_1_DAY": "PERIOD_1_DAY",
    "PERIOD_6_HOURS": "PERIOD_6_HOURS",
    "PERIOD_1_HOUR": "PERIOD_1_HOUR",
}


def _schema(properties: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": required or [],
    }


def gcp_observability_capability() -> ToolCapability:
    return ToolCapability(
        tool=GCP_OBSERVABILITY_TOOL_NAME,
        description=(
            "Read Google Cloud logs, Error Reporting data, metrics, and alert policies using "
            "the user's local gcloud authentication."
        ),
        actions=[
            ToolActionCapability(
                name="read_logs",
                description="Read Cloud Logging entries with a Logging query filter.",
                input_schema=_schema(
                    {
                        "filter": {"type": "string"},
                        "limit": {"type": "integer", "default": 50},
                        "format": {"type": "string", "default": "json"},
                        "freshness": {
                            "type": "string",
                            "description": "Cloud Logging freshness duration, for example 30d or 12h.",
                        },
                        "project": {"type": "string"},
                    },
                    ["filter"],
                ),
                examples=[
                    'runllm_tool gcp_observability read_logs \'{"filter":"severity>=ERROR","limit":50}\'',
                    (
                        "runllm_tool gcp_observability read_logs "
                        "'{\"filter\":\"resource.type=\\\"k8s_container\\\"\",\"limit\":20}'"
                    ),
                ],
            ),
            ToolActionCapability(
                name="list_log_names",
                description="List Cloud Logging log names for a project.",
                input_schema=_schema(
                    {
                        "project": {"type": "string"},
                        "limit": {"type": "integer", "default": 100},
                    }
                ),
                examples=["runllm_tool gcp_observability list_log_names '{}'"],
            ),
            ToolActionCapability(
                name="list_error_group_logs",
                description="Read log entries belonging to a specific Error Reporting group ID.",
                input_schema=_schema(
                    {
                        "group_id": {"type": "string"},
                        "project": {"type": "string"},
                        "limit": {"type": "integer", "default": 50},
                        "format": {"type": "string", "default": "json"},
                        "freshness": {"type": "string", "default": "30d"},
                    },
                    ["group_id"],
                ),
                examples=[
                    (
                        "runllm_tool gcp_observability list_error_group_logs "
                        "'{\"group_id\":\"COLhwYuQyNXfdQ\",\"limit\":20}'"
                    )
                ],
            ),
            ToolActionCapability(
                name="list_error_events",
                description="List Error Reporting sample events for a specific error group ID.",
                input_schema=_schema(
                    {
                        "group_id": {"type": "string"},
                        "project": {"type": "string"},
                        "page_size": {"type": "integer", "default": 20},
                        "time_range": {"type": "string", "default": "PERIOD_30_DAYS"},
                    },
                    ["group_id"],
                ),
            ),
            ToolActionCapability(
                name="list_error_group_stats",
                description="List Error Reporting groups and aggregate stats for a project.",
                input_schema=_schema(
                    {
                        "project": {"type": "string"},
                        "page_size": {"type": "integer", "default": 20},
                        "time_range": {
                            "type": "string",
                            "default": "PERIOD_30_DAYS",
                            "enum": [
                                "PERIOD_1_HOUR",
                                "PERIOD_6_HOURS",
                                "PERIOD_1_DAY",
                                "PERIOD_1_WEEK",
                                "PERIOD_30_DAYS",
                            ],
                        },
                        "service": {"type": "string"},
                    }
                ),
            ),
            ToolActionCapability(
                name="list_metric_descriptors",
                description="List Cloud Monitoring metric descriptors matching an optional filter.",
                input_schema=_schema(
                    {
                        "project": {"type": "string"},
                        "filter": {"type": "string"},
                        "page_size": {"type": "integer", "default": 50},
                    }
                ),
            ),
            ToolActionCapability(
                name="list_time_series",
                description="List Cloud Monitoring time series for a metric filter and time interval.",
                input_schema=_schema(
                    {
                        "project": {"type": "string"},
                        "filter": {"type": "string"},
                        "start_time": {
                            "type": "string",
                            "description": "RFC3339 timestamp, for example 2026-05-06T20:00:00Z.",
                        },
                        "end_time": {
                            "type": "string",
                            "description": "RFC3339 timestamp, for example 2026-05-06T21:00:00Z.",
                        },
                        "view": {"type": "string", "default": "FULL"},
                        "page_size": {"type": "integer", "default": 50},
                    },
                    ["filter", "start_time", "end_time"],
                ),
            ),
            ToolActionCapability(
                name="list_alert_policies",
                description="List Cloud Monitoring alert policies for a project.",
                input_schema=_schema(
                    {
                        "project": {"type": "string"},
                        "filter": {"type": "string"},
                        "page_size": {"type": "integer", "default": 50},
                    }
                ),
            ),
        ],
    )


def _error_result(request: CommandRequestMessage, message: str, exit_code: int = 2) -> CommandResultMessage:
    return CommandResultMessage(
        request_id=request.request_id,
        success=False,
        exit_code=exit_code,
        stderr=message.rstrip() + "\n",
    )


def _optional_string(arguments: dict[str, Any], key: str) -> str | None:
    value = arguments.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string.")
    return value


def _required_string(arguments: dict[str, Any], key: str) -> str:
    value = _optional_string(arguments, key)
    if value is None or not value.strip():
        raise ValueError(f"{key} is required.")
    return value


def _optional_int(arguments: dict[str, Any], key: str, default: int) -> int:
    value = arguments.get(key, default)
    if not isinstance(value, int):
        raise ValueError(f"{key} must be an integer.")
    return value


def _error_reporting_time_range(value: str | None, default: str) -> str:
    if value is None or not value.strip():
        return default
    normalized = ERROR_REPORTING_TIME_RANGE_ALIASES.get(value.strip())
    if normalized is None:
        raise ValueError(
            f"time_range must be one of {sorted(set(ERROR_REPORTING_TIME_RANGE_ALIASES.values()))}"
        )
    return normalized


def _run_gcloud_command(
    *,
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    args: list[str],
) -> tuple[int, str, str]:
    completed = subprocess.run(
        [gcp_config.gcloud_path, *args],
        capture_output=True,
        text=True,
        timeout=config.command_timeout_sec,
        check=False,
    )
    return completed.returncode, completed.stdout, completed.stderr


def _resolve_project(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    arguments: dict[str, Any],
) -> str:
    project = _optional_string(arguments, "project") or gcp_config.project_id
    if project:
        return project
    exit_code, stdout, stderr = _run_gcloud_command(
        config=config,
        gcp_config=gcp_config,
        args=["config", "get-value", "project", "--quiet"],
    )
    if exit_code != 0:
        raise ValueError(f"Could not determine gcloud project: {stderr.strip()}")
    project = stdout.strip()
    if not project or project == "(unset)":
        raise ValueError("No GCP project configured. Pass project or run configure with --project.")
    return project


def _access_token(config: CliConfig, gcp_config: GcpObservabilityConfig) -> str:
    exit_code, stdout, stderr = _run_gcloud_command(
        config=config,
        gcp_config=gcp_config,
        args=["auth", "print-access-token"],
    )
    if exit_code != 0:
        raise ValueError(f"Failed to get gcloud access token: {stderr.strip()}")
    token = stdout.strip()
    if not token:
        raise ValueError("gcloud returned an empty access token.")
    return token


def _api_get(
    *,
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    url: str,
    query: dict[str, Any],
) -> dict[str, Any]:
    clean_query = {
        key: value
        for key, value in query.items()
        if value is not None and value != "" and str(value).lower() != "none"
    }
    full_url = f"{url}?{urllib.parse.urlencode(clean_query)}" if clean_query else url
    request = urllib.request.Request(
        full_url,
        headers={"Authorization": f"Bearer {_access_token(config, gcp_config)}"},
        method="GET",
    )
    with urllib.request.urlopen(request, timeout=config.command_timeout_sec) as response:
        return json.loads(response.read().decode("utf-8"))


def _failure_result(
    request: CommandRequestMessage,
    *,
    message: str,
    duration_ms: int,
    metadata: dict[str, Any] | None = None,
) -> CommandResultMessage:
    return CommandResultMessage(
        request_id=request.request_id,
        success=False,
        exit_code=1,
        stderr=message.rstrip() + "\n",
        duration_ms=duration_ms,
        metadata={key: str(value) for key, value in (metadata or {}).items()},
    )


def _run_read_logs(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    log_filter = _required_string(request.arguments, "filter")
    limit = _optional_int(request.arguments, "limit", 50)
    output_format = _optional_string(request.arguments, "format") or "json"
    freshness = _optional_string(request.arguments, "freshness")
    project = _resolve_project(config, gcp_config, request.arguments)
    args = [
        "logging",
        "read",
        log_filter,
        "--limit",
        str(limit),
        "--format",
        output_format,
        "--project",
        project,
    ]
    if freshness:
        args.extend(["--freshness", freshness])
    return _run_gcloud_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        args=args,
        log_metadata={
            "filter_bytes": len(log_filter.encode()),
            "limit": limit,
            "format": output_format,
            "freshness": freshness or "",
            "project": project,
        },
    )


def _run_list_log_names(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    limit = _optional_int(request.arguments, "limit", 100)
    return _run_gcloud_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        args=[
            "logging",
            "logs",
            "list",
            "--limit",
            str(limit),
            "--format",
            "json",
            "--project",
            project,
        ],
        log_metadata={"limit": limit, "project": project},
    )


def _run_error_group_logs(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    group_id = _required_string(request.arguments, "group_id")
    arguments = dict(request.arguments)
    arguments["filter"] = f'errorGroups.id="{group_id}"'
    arguments.setdefault("freshness", "30d")
    compatible_request = request.model_copy(update={"arguments": arguments})
    return _run_read_logs(config, gcp_config, compatible_request)


def _run_api_result(
    *,
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
    url: str,
    query: dict[str, Any],
    log_metadata: dict[str, Any],
) -> CommandResultMessage:
    started_at = time.monotonic()
    try:
        payload = _api_get(config=config, gcp_config=gcp_config, url=url, query=query)
    except urllib.error.HTTPError as e:
        duration_ms = int((time.monotonic() - started_at) * 1000)
        error_body = e.read().decode("utf-8", errors="replace")
        logger.info(
            "GCP API request failed: request_id={} action={} status_code={} reason={} body={} metadata={}\n",
            request.request_id,
            request.action,
            e.code,
            e.reason,
            error_body[:1_000],
            log_metadata,
        )
        return _failure_result(
            request,
            message=f"GCP API request failed with HTTP {e.code}: {error_body or e.reason}",
            duration_ms=duration_ms,
            metadata=log_metadata,
        )
    except Exception as e:
        duration_ms = int((time.monotonic() - started_at) * 1000)
        logger.info(
            "GCP API request failed: request_id={} action={} error={} metadata={}\n",
            request.request_id,
            request.action,
            e,
            log_metadata,
        )
        return _failure_result(
            request,
            message=f"GCP API request failed: {e}",
            duration_ms=duration_ms,
            metadata=log_metadata,
        )
    stdout = json.dumps(payload, indent=2, sort_keys=True)
    stdout, stdout_truncated = _truncate_output(stdout, config.command_output_limit_bytes)
    duration_ms = int((time.monotonic() - started_at) * 1000)
    logger.info(
        "GCP API request complete: request_id={} action={} duration_ms={} stdout_bytes={} truncated={} metadata={}\n",
        request.request_id,
        request.action,
        duration_ms,
        len(stdout.encode()),
        stdout_truncated,
        log_metadata,
    )
    return CommandResultMessage(
        request_id=request.request_id,
        success=True,
        exit_code=0,
        stdout=stdout,
        duration_ms=duration_ms,
        truncated=stdout_truncated,
        data=payload,
        metadata={key: str(value) for key, value in log_metadata.items()},
    )


def _run_error_events(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    group_id = _required_string(request.arguments, "group_id")
    page_size = _optional_int(request.arguments, "page_size", 20)
    time_range = _error_reporting_time_range(
        _optional_string(request.arguments, "time_range"),
        "PERIOD_30_DAYS",
    )
    return _run_api_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        url=f"{CLOUD_ERROR_REPORTING_BASE_URL}/projects/{urllib.parse.quote(project)}/events",
        query={"groupId": group_id, "pageSize": page_size, "timeRange.period": time_range},
        log_metadata={"project": project, "group_id": group_id, "page_size": page_size},
    )


def _run_error_group_stats(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    page_size = _optional_int(request.arguments, "page_size", 20)
    time_range = _error_reporting_time_range(
        _optional_string(request.arguments, "time_range"),
        "PERIOD_30_DAYS",
    )
    service = _optional_string(request.arguments, "service")
    return _run_api_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        url=f"{CLOUD_ERROR_REPORTING_BASE_URL}/projects/{urllib.parse.quote(project)}/groupStats",
        query={
            "pageSize": page_size,
            "timeRange.period": time_range,
            "serviceFilter.service": service,
        },
        log_metadata={"project": project, "page_size": page_size, "service": service or ""},
    )


def _run_metric_descriptors(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    page_size = _optional_int(request.arguments, "page_size", 50)
    metric_filter = _optional_string(request.arguments, "filter")
    return _run_api_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        url=f"{CLOUD_MONITORING_BASE_URL}/projects/{urllib.parse.quote(project)}/metricDescriptors",
        query={"pageSize": page_size, "filter": metric_filter},
        log_metadata={"project": project, "page_size": page_size, "filter": metric_filter or ""},
    )


def _run_time_series(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    metric_filter = _required_string(request.arguments, "filter")
    start_time = _required_string(request.arguments, "start_time")
    end_time = _required_string(request.arguments, "end_time")
    page_size = _optional_int(request.arguments, "page_size", 50)
    view = _optional_string(request.arguments, "view") or "FULL"
    return _run_api_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        url=f"{CLOUD_MONITORING_BASE_URL}/projects/{urllib.parse.quote(project)}/timeSeries",
        query={
            "filter": metric_filter,
            "interval.startTime": start_time,
            "interval.endTime": end_time,
            "view": view,
            "pageSize": page_size,
        },
        log_metadata={
            "project": project,
            "filter_bytes": len(metric_filter.encode()),
            "start_time": start_time,
            "end_time": end_time,
            "page_size": page_size,
        },
    )


def _run_alert_policies(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    project = _resolve_project(config, gcp_config, request.arguments)
    page_size = _optional_int(request.arguments, "page_size", 50)
    policy_filter = _optional_string(request.arguments, "filter")
    return _run_api_result(
        config=config,
        gcp_config=gcp_config,
        request=request,
        url=f"{CLOUD_MONITORING_BASE_URL}/projects/{urllib.parse.quote(project)}/alertPolicies",
        query={"pageSize": page_size, "filter": policy_filter},
        log_metadata={"project": project, "page_size": page_size, "filter": policy_filter or ""},
    )


def _run_gcloud_result(
    *,
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
    args: list[str],
    log_metadata: dict[str, Any],
) -> CommandResultMessage:
    started_at = time.monotonic()
    try:
        exit_code, stdout, stderr = _run_gcloud_command(
            config=config,
            gcp_config=gcp_config,
            args=args,
        )
    except subprocess.TimeoutExpired as e:
        exit_code = 124
        stdout = e.stdout if isinstance(e.stdout, str) else ""
        stderr = e.stderr if isinstance(e.stderr, str) else ""
        stderr = stderr + "\n[runllm: gcloud command timed out]\n"
    stdout, stdout_truncated = _truncate_output(stdout, config.command_output_limit_bytes)
    stderr, stderr_truncated = _truncate_output(stderr, config.command_output_limit_bytes)
    duration_ms = int((time.monotonic() - started_at) * 1000)
    logger.info(
        "GCP gcloud request complete: request_id={} action={} exit_code={} duration_ms={} stdout_bytes={} stderr_bytes={} truncated={} metadata={}\n",
        request.request_id,
        request.action,
        exit_code,
        duration_ms,
        len(stdout.encode()),
        len(stderr.encode()),
        stdout_truncated or stderr_truncated,
        log_metadata,
    )
    return CommandResultMessage(
        request_id=request.request_id,
        success=exit_code == 0,
        exit_code=exit_code,
        stdout=stdout,
        stderr=stderr,
        duration_ms=duration_ms,
        truncated=stdout_truncated or stderr_truncated,
        metadata={key: str(value) for key, value in log_metadata.items()},
    )


def run_gcp_observability_tool(
    config: CliConfig,
    gcp_config: GcpObservabilityConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    logger.info(
        "Executing GCP observability request: request_id={} tool={} action={} arg_keys={}\n",
        request.request_id,
        request.tool,
        request.action,
        sorted(request.arguments.keys()),
    )
    try:
        if request.action == "read_logs":
            return _run_read_logs(config, gcp_config, request)
        if request.action == "list_log_names":
            return _run_list_log_names(config, gcp_config, request)
        if request.action == "list_error_group_logs":
            return _run_error_group_logs(config, gcp_config, request)
        if request.action == "list_error_events":
            return _run_error_events(config, gcp_config, request)
        if request.action == "list_error_group_stats":
            return _run_error_group_stats(config, gcp_config, request)
        if request.action == "list_metric_descriptors":
            return _run_metric_descriptors(config, gcp_config, request)
        if request.action == "list_time_series":
            return _run_time_series(config, gcp_config, request)
        if request.action == "list_alert_policies":
            return _run_alert_policies(config, gcp_config, request)
        return _error_result(request, f"Unsupported GCP observability action: {request.action}")
    except ValueError as e:
        return _error_result(request, str(e))
    except Exception as e:
        logger.exception(
            "GCP observability request failed: request_id={} action={} error={}\n",
            request.request_id,
            request.action,
            e,
        )
        return _error_result(request, f"runllm failed to execute GCP observability request: {e}", 1)
