"""Local RunLLM API key credential storage."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path

from pydantic import BaseModel

CREDENTIALS_DIR = Path.home() / ".config" / "runllm"
CREDENTIALS_PATH = CREDENTIALS_DIR / "credentials.json"


class Credentials(BaseModel):
    api_key: str
    key_prefix: str | None = None


def load_credentials() -> Credentials | None:
    if not CREDENTIALS_PATH.exists():
        return None
    return Credentials.model_validate_json(CREDENTIALS_PATH.read_text())


def save_credentials(credentials: Credentials) -> None:
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps(credentials.model_dump(mode="json"), indent=2))
    os.chmod(CREDENTIALS_PATH, 0o600)


def validate_api_key(engine_url: str, api_key: str) -> Credentials:
    request = urllib.request.Request(
        f"{engine_url.rstrip('/')}/v1/api-keys/validate",
        data=b"{}",
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise ValueError(f"Engine rejected API key: {e.code} {body}") from e
    except Exception as e:
        raise ValueError(f"Failed to validate API key: {e}") from e
    key_prefix = payload.get("key_prefix")
    return Credentials(
        api_key=api_key,
        key_prefix=key_prefix if isinstance(key_prefix, str) else None,
    )
