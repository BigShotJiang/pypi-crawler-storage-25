"""Local kubectl execution for engine-requested commands."""

from __future__ import annotations

import subprocess
import time

from loguru import logger

from runllm_lite_cli.config import CliConfig, KubectlConfig
from runllm_lite_cli.protocol import (
    CommandRequestMessage,
    CommandResultMessage,
    ToolActionCapability,
    ToolCapability,
)


def _truncate_output(value: str, limit_bytes: int) -> tuple[str, bool]:
    encoded = value.encode("utf-8", errors="replace")
    if len(encoded) <= limit_bytes:
        return value, False
    truncated = encoded[:limit_bytes].decode("utf-8", errors="replace")
    return truncated + "\n[runllm: output truncated]\n", True


def kubectl_capability() -> ToolCapability:
    return ToolCapability(
        tool="kubectl",
        description="Run local kubectl commands using the user's kubeconfig.",
        actions=[
            ToolActionCapability(
                name="execute",
                description="Execute a kubectl command locally. Pass argv without the kubectl binary.",
                input_schema={
                    "type": "object",
                    "properties": {"argv": {"type": "array", "items": {"type": "string"}}},
                    "required": ["argv"],
                },
                examples=["kubectl get pods -A", "kubectl describe pod pod-name -n namespace"],
            )
        ],
    )


def run_kubectl_command(config: CliConfig, request: CommandRequestMessage) -> CommandResultMessage:
    kubectl_config = config.tools.kubectl
    if kubectl_config is None or not kubectl_config.enabled:
        return CommandResultMessage(
            request_id=request.request_id,
            success=False,
            exit_code=1,
            stderr="kubectl is not configured for this RunLLM session.\n",
        )
    return run_kubectl_tool(config, kubectl_config, request)


def run_kubectl_tool(
    config: CliConfig,
    kubectl_config: KubectlConfig,
    request: CommandRequestMessage,
) -> CommandResultMessage:
    started_at = time.monotonic()
    argv = request.arguments.get("argv")
    if not isinstance(argv, list) or not all(isinstance(item, str) for item in argv):
        return CommandResultMessage(
            request_id=request.request_id,
            success=False,
            exit_code=2,
            stderr="kubectl execute requires arguments.argv as a list of strings.\n",
        )
    command = [kubectl_config.kubectl_path]
    if kubectl_config.kubeconfig_path:
        command.extend(["--kubeconfig", kubectl_config.kubeconfig_path])
    command.extend(argv)

    logger.info(
        "Executing kubectl request: request_id={} argv={}\n",
        request.request_id,
        argv,
    )
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=config.command_timeout_sec,
            check=False,
        )
        exit_code = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
    except subprocess.TimeoutExpired as e:
        exit_code = 124
        stdout = e.stdout if isinstance(e.stdout, str) else ""
        stderr = e.stderr if isinstance(e.stderr, str) else ""
        stderr = stderr + "\n[runllm: kubectl command timed out]\n"
    except Exception as e:
        exit_code = 1
        stdout = ""
        stderr = f"runllm failed to execute kubectl: {e}\n"

    stdout, stdout_truncated = _truncate_output(stdout, config.command_output_limit_bytes)
    stderr, stderr_truncated = _truncate_output(stderr, config.command_output_limit_bytes)
    duration_ms = int((time.monotonic() - started_at) * 1000)
    logger.info(
        "Kubectl request complete: request_id={} exit_code={} duration_ms={} stdout_bytes={} stderr_bytes={} truncated={}\n",
        request.request_id,
        exit_code,
        duration_ms,
        len(stdout.encode()),
        len(stderr.encode()),
        stdout_truncated or stderr_truncated,
    )
    return CommandResultMessage(
        request_id=request.request_id,
        success=exit_code == 0,
        exit_code=exit_code,
        stdout=stdout,
        stderr=stderr,
        duration_ms=duration_ms,
        truncated=stdout_truncated or stderr_truncated,
        metadata={
            "stdout_bytes": str(len(stdout.encode())),
            "stderr_bytes": str(len(stderr.encode())),
        },
    )
