"""Local configuration for the RunLLM Lite CLI."""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from urllib.parse import urlparse

from loguru import logger
from pydantic import BaseModel, Field, model_validator

CONFIG_DIR = Path.home() / ".runllm-lite"
CONFIG_PATH = CONFIG_DIR / "config.json"
LOG_DIR = CONFIG_DIR / "logs"
LOG_PATH = LOG_DIR / "runllm-lite-cli.log"


class KubectlConfig(BaseModel):
    enabled: bool = True
    kubectl_path: str
    kubeconfig_path: str | None = None


class GrafanaConfig(BaseModel):
    enabled: bool = True
    mcp_grafana_path: str
    grafana_url: str
    service_account_token: str


class GcpObservabilityConfig(BaseModel):
    enabled: bool = True
    gcloud_path: str
    project_id: str | None = None


class ToolConfigs(BaseModel):
    kubectl: KubectlConfig | None = None
    grafana: GrafanaConfig | None = None
    gcp_observability: GcpObservabilityConfig | None = None


class CliConfig(BaseModel):
    engine_url: str
    repo_path: str
    auth_url: str = "https://auth.runllm.com"
    command_timeout_sec: int = 120
    command_output_limit_bytes: int = 2_000_000
    tools: ToolConfigs = Field(default_factory=ToolConfigs)
    created_by_version: str | None = None
    metadata: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def migrate_flat_tool_config(cls, data: object) -> object:
        if not isinstance(data, dict):
            return data
        if "tools" in data:
            return data
        kubectl_path = data.pop("kubectl_path", None)
        kubeconfig_path = data.pop("kubeconfig_path", None)
        if kubectl_path is not None:
            data["tools"] = {
                "kubectl": {
                    "enabled": True,
                    "kubectl_path": kubectl_path,
                    "kubeconfig_path": kubeconfig_path,
                }
            }
        return data


def configure_logging(verbose: bool = False) -> None:
    logger.remove()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger.add(
        LOG_PATH,
        level="DEBUG",
        rotation="10 MB",
        retention=5,
        enqueue=True,
    )
    logger.add(
        sink=lambda message: print(message, end=""),
        level="DEBUG" if verbose else "WARNING",
        format="<level>{message}</level>",
    )


def _default_kubeconfig_path() -> Path | None:
    kubeconfig_env = os.getenv("KUBECONFIG")
    if kubeconfig_env:
        first_path = kubeconfig_env.split(os.pathsep)[0]
        if first_path:
            return Path(first_path).expanduser()
    default_path = Path.home() / ".kube" / "config"
    return default_path if default_path.exists() else None


def validate_engine_url(engine_url: str) -> str:
    parsed = urlparse(engine_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Engine URL must be an http(s) URL, for example http://127.0.0.1:5099")
    return engine_url.rstrip("/")


def validate_repo_path(repo_path: str) -> Path:
    path = Path(repo_path).expanduser().resolve()
    if not path.exists():
        raise ValueError(f"Repo path does not exist: {path}")
    if not path.is_dir():
        raise ValueError(f"Repo path is not a directory: {path}")
    return path


def validate_kubectl() -> str:
    kubectl_path = shutil.which("kubectl")
    if kubectl_path is None:
        raise ValueError("kubectl was not found on PATH. Install kubectl before configuring RunLLM.")
    return kubectl_path


def validate_binary(binary_name: str, configured_path: str | None = None) -> str:
    if configured_path:
        path = Path(configured_path).expanduser().resolve()
        if not path.exists():
            raise ValueError(f"{binary_name} path does not exist: {path}")
        if not path.is_file():
            raise ValueError(f"{binary_name} path is not a file: {path}")
        if not os.access(path, os.X_OK):
            raise ValueError(f"{binary_name} path is not executable: {path}")
        return str(path)
    binary_path = shutil.which(binary_name)
    if binary_path is None:
        raise ValueError(f"{binary_name} was not found on PATH.")
    return binary_path


def validate_kubeconfig(kubeconfig_path: str | None) -> Path | None:
    selected = Path(kubeconfig_path).expanduser() if kubeconfig_path else _default_kubeconfig_path()
    if selected is None:
        logger.warning("No kubeconfig path was found. kubectl may still use its own defaults.")
        return None
    selected = selected.resolve()
    if not selected.exists():
        raise ValueError(f"Kubeconfig path does not exist: {selected}")
    if not selected.is_file():
        raise ValueError(f"Kubeconfig path is not a file: {selected}")
    if not os.access(selected, os.R_OK):
        raise ValueError(f"Kubeconfig path is not readable: {selected}")
    return selected


def save_config(config: CliConfig) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config.model_dump(mode="json"), indent=2, sort_keys=True))
    logger.info("Saved RunLLM Lite config to {}\n", CONFIG_PATH)


def load_config() -> CliConfig:
    if not CONFIG_PATH.exists():
        raise ValueError("Run `runllm configure` before running an investigation.")
    config = CliConfig.model_validate_json(CONFIG_PATH.read_text())
    logger.info(
        "Loaded RunLLM Lite config: engine_url={} repo_path={} enabled_tools={}\n",
        config.engine_url,
        config.repo_path,
        [
            name
            for name, tool_config in config.tools.model_dump().items()
            if tool_config is not None and tool_config.get("enabled")
        ],
    )
    return config
