"""Local copy of the RunLLM Lite WebSocket protocol."""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, TypeAdapter

PROTOCOL_VERSION = "2026-05-06"


class ClientMessageType(str, Enum):
    SESSION_INIT = "session_init"
    RESUME_SESSION = "resume_session"
    REPO_UPLOAD_COMPLETE = "repo_upload_complete"
    COMMAND_RESULT = "command_result"
    USER_MESSAGE = "user_message"
    CLOSE_SESSION = "close_session"
    CANCEL = "cancel"


class EngineMessageType(str, Enum):
    SESSION_ACCEPTED = "session_accepted"
    PROGRESS = "progress"
    COMMAND_REQUEST = "command_request"
    OPENCODE_EVENT = "opencode_event"
    FINAL_RCA = "final_rca"
    ERROR = "error"


class RepoMetadata(BaseModel):
    root_name: str | None = None
    branch: str | None = None
    commit: str | None = None
    total_bytes: int | None = None
    file_count: int | None = None


class ToolActionCapability(BaseModel):
    name: str
    description: str
    input_schema: dict[str, Any] = Field(default_factory=dict)
    examples: list[str] = Field(default_factory=list)


class ToolCapability(BaseModel):
    tool: str
    description: str
    actions: list[ToolActionCapability]


class SessionInitMessage(BaseModel):
    type: Literal[ClientMessageType.SESSION_INIT] = ClientMessageType.SESSION_INIT
    version: str = PROTOCOL_VERSION
    question: str
    cli_version: str | None = None
    repo: RepoMetadata | None = None
    repo_snapshot_id: int | None = None
    available_tools: list[ToolCapability] = Field(default_factory=list)


class ResumeSessionMessage(BaseModel):
    type: Literal[ClientMessageType.RESUME_SESSION] = ClientMessageType.RESUME_SESSION
    version: str = PROTOCOL_VERSION


class RepoUploadCompleteMessage(BaseModel):
    type: Literal[ClientMessageType.REPO_UPLOAD_COMPLETE] = ClientMessageType.REPO_UPLOAD_COMPLETE
    version: str = PROTOCOL_VERSION


class CommandResultMessage(BaseModel):
    type: Literal[ClientMessageType.COMMAND_RESULT] = ClientMessageType.COMMAND_RESULT
    version: str = PROTOCOL_VERSION
    request_id: str
    success: bool = True
    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""
    duration_ms: int | None = None
    truncated: bool = False
    data: Any | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class UserMessage(BaseModel):
    type: Literal[ClientMessageType.USER_MESSAGE] = ClientMessageType.USER_MESSAGE
    version: str = PROTOCOL_VERSION
    message: str


class CloseSessionMessage(BaseModel):
    type: Literal[ClientMessageType.CLOSE_SESSION] = ClientMessageType.CLOSE_SESSION
    version: str = PROTOCOL_VERSION
    reason: str | None = None


class SessionAcceptedMessage(BaseModel):
    type: Literal[EngineMessageType.SESSION_ACCEPTED]
    version: str = PROTOCOL_VERSION
    session_id: str


class ProgressMessage(BaseModel):
    type: Literal[EngineMessageType.PROGRESS]
    version: str = PROTOCOL_VERSION
    session_id: str
    message: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class CommandRequestMessage(BaseModel):
    type: Literal[EngineMessageType.COMMAND_REQUEST]
    version: str = PROTOCOL_VERSION
    session_id: str
    request_id: str
    tool: str
    action: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class OpenCodeEventMessage(BaseModel):
    type: Literal[EngineMessageType.OPENCODE_EVENT]
    version: str = PROTOCOL_VERSION
    session_id: str
    event: dict[str, Any]


class FinalRcaMessage(BaseModel):
    type: Literal[EngineMessageType.FINAL_RCA]
    version: str = PROTOCOL_VERSION
    session_id: str
    rca: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ErrorMessage(BaseModel):
    type: Literal[EngineMessageType.ERROR]
    version: str = PROTOCOL_VERSION
    session_id: str | None = None
    message: str
    code: str = "internal_error"
    metadata: dict[str, Any] = Field(default_factory=dict)


EngineMessage = (
    SessionAcceptedMessage
    | ProgressMessage
    | CommandRequestMessage
    | OpenCodeEventMessage
    | FinalRcaMessage
    | ErrorMessage
)


def parse_engine_message(raw: str) -> EngineMessage:
    adapter: TypeAdapter[EngineMessage] = TypeAdapter(EngineMessage)
    return adapter.validate_json(raw)
