"""CLI-side registry for customer-local tools."""

from __future__ import annotations

import asyncio

from runllm_lite_cli.config import CliConfig
from runllm_lite_cli.gcp_observability import (
    GCP_OBSERVABILITY_TOOL_NAME,
    gcp_observability_capability,
    run_gcp_observability_tool,
)
from runllm_lite_cli.grafana import grafana_capability, run_grafana_tool
from runllm_lite_cli.kubectl import kubectl_capability, run_kubectl_command
from runllm_lite_cli.protocol import CommandRequestMessage, CommandResultMessage, ToolCapability


def configured_tool_capabilities(config: CliConfig) -> list[ToolCapability]:
    capabilities: list[ToolCapability] = []
    if config.tools.kubectl is not None and config.tools.kubectl.enabled:
        capabilities.append(kubectl_capability())
    if config.tools.grafana is not None and config.tools.grafana.enabled:
        capabilities.append(grafana_capability())
    if (
        config.tools.gcp_observability is not None
        and config.tools.gcp_observability.enabled
    ):
        capabilities.append(gcp_observability_capability())
    return capabilities


async def execute_tool_request(config: CliConfig, request: CommandRequestMessage) -> CommandResultMessage:
    if request.tool == "kubectl":
        return await asyncio.to_thread(run_kubectl_command, config, request)
    if request.tool == "grafana":
        return await run_grafana_tool(config, request)
    if request.tool == GCP_OBSERVABILITY_TOOL_NAME:
        gcp_config = config.tools.gcp_observability
        if gcp_config is None or not gcp_config.enabled:
            return CommandResultMessage(
                request_id=request.request_id,
                success=False,
                exit_code=1,
                stderr="GCP observability is not configured for this RunLLM session.\n",
            )
        return await asyncio.to_thread(run_gcp_observability_tool, config, gcp_config, request)
    return CommandResultMessage(
        request_id=request.request_id,
        success=False,
        exit_code=1,
        stderr=f"Unsupported RunLLM local tool: {request.tool}\n",
    )
