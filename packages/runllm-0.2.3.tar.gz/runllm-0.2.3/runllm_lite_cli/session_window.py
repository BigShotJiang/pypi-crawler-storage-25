"""Terminal session window for RunLLM investigations."""

from __future__ import annotations

import atexit
import importlib
import re
import shlex
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

from rich import box
from rich.console import Console, Group
from rich.live import Live
from rich.markdown import Markdown
from rich.padding import Padding
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from runllm_lite_cli.config import CONFIG_DIR
from runllm_lite_cli.protocol import (
    CommandRequestMessage,
    CommandResultMessage,
    RepoMetadata,
    ToolCapability,
)

SURFACE = "#0F2744"
PANEL_BG = "#0A1422"
ACCENT = "#2563EB"
ACCENT_RGB = "37;99;235"
LINK = "#93C5FD"
MUTED = "#8AACCC"
TEXT = "#E6EDF7"
OK = "#4ADE80"
WARN = "#FBBF24"
ERR = "#F87171"
DIM = "#6E7F7F"

ASCII_BANNER = r"""
 ____              _     _     __  __
|  _ \ _   _ _ __ | |   | |   |  \/  |
| |_) | | | | '_ \| |   | |   | |\/| |
|  _ <| |_| | | | | |___| |___| |  | |
|_| \_\\__,_|_| |_|_____|_____|_|  |_|
""".strip("\n")

EXIT_COMMANDS = {"/exit", "exit", "quit", "/quit"}
LOCAL_COMMAND_DESCRIPTIONS = (
    ("/help", "Show these local CLI commands."),
    ("/tools", "List configured local tools and supported actions."),
    ("/history", "Show recent RunLLM prompts from local history."),
    ("/clear", "Clear the visible session log and redraw the header."),
    ("/share", "Export a Markdown transcript for sharing."),
    ("/exit", "Close the interactive session."),
)
PROMPT_HISTORY_PATH = CONFIG_DIR / "history"
PROMPT_HISTORY_LENGTH = 200
SHARE_DIR = CONFIG_DIR / "shares"
SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
SPINNER_INTERVAL_SEC = 0.12


def _load_readline() -> Any | None:
    try:
        return importlib.import_module("readline")
    except ImportError:
        return None


_READLINE = _load_readline()
_PROMPT_HISTORY_INITIALIZED = False


@dataclass
class ToolCard:
    request_id: str
    name: str
    summary: str
    status: str = "running"
    duration_sec: float | None = None
    success: bool | None = None


@dataclass
class TranscriptTurn:
    question: str
    response: str | None = None
    error: str | None = None
    tool_summaries: list[str] | None = None


class SessionWindow:
    """Renders the inline RunLLM session window from protocol events."""

    def __init__(self, *, show_initial_header: bool = True) -> None:
        self.console = Console()
        self.repo: RepoMetadata | None = None
        self.tools: list[ToolCapability] = []
        self.cli_version: str | None = None
        self.connected = False
        self.question = ""
        self.thinking = ""
        self.tool_cards: list[ToolCard] = []
        self.notes: list[str] = []
        self.response = ""
        self.response_metadata: dict[str, Any] = {}
        self.error: str | None = None
        self.transcript_turns: list[TranscriptTurn] = []
        self._live: Live | None = None
        self._current_turn: TranscriptTurn | None = None
        self._show_initial_header = show_initial_header
        self._has_rendered_turn = False
        self._show_session_header = True
        self._spinner_index = 0
        self._spinner_stop_event = threading.Event()
        self._spinner_thread: threading.Thread | None = None
        self._status_live: Live | None = None

    def start_session(
        self,
        *,
        repo: RepoMetadata | None,
        tools: list[ToolCapability],
        cli_version: str,
    ) -> None:
        self.repo = repo
        self.tools = tools
        self.cli_version = cli_version

    def render_idle_prompt(self) -> None:
        self.console.print(
            Group(
                self._chrome(),
                self._banner(),
                self._session_meta(),
                self._divider(),
            )
        )

    def clear_session_log(self) -> None:
        self.console.clear()
        self.render_idle_prompt()

    def start_turn(self, question: str) -> None:
        self._show_session_header = self._show_initial_header and not self._has_rendered_turn
        self._has_rendered_turn = True
        self.question = question
        self.thinking = "Investigating request -- gathering repo context and available tools..."
        self.tool_cards = []
        self.notes = []
        self.response = ""
        self.response_metadata = {}
        self.error = None
        self._current_turn = TranscriptTurn(question=question)
        self._start_live()
        self.refresh()

    def set_connected(self, connected: bool) -> None:
        self.connected = connected
        self.refresh()

    def render_progress(self, message: str) -> None:
        self.thinking = _friendly_progress(message)
        self.refresh()

    def render_tool_start(self, request: CommandRequestMessage) -> float:
        self.tool_cards.append(
            ToolCard(
                request_id=request.request_id,
                name=f"{request.tool}.{request.action}",
                summary=_format_tool_command(request),
            )
        )
        self.refresh()
        return time.monotonic()

    def render_tool_result(
        self,
        request: CommandRequestMessage,
        result: CommandResultMessage,
        started_at: float,
    ) -> None:
        card = self._find_tool_card(request.request_id)
        if card is None:
            card = ToolCard(
                request_id=request.request_id,
                name=f"{request.tool}.{request.action}",
                summary=_format_tool_command(request),
            )
            self.tool_cards.append(card)
        card.status = "done" if result.success and result.exit_code == 0 else "failed"
        card.success = result.success and result.exit_code == 0
        card.duration_sec = (
            (result.duration_ms / 1000)
            if result.duration_ms is not None
            else time.monotonic() - started_at
        )
        self.refresh()

    def render_opencode_event(self, event: dict[str, Any]) -> None:
        note = _extract_display_text(event)
        if note is None:
            return
        if note not in self.notes:
            self.notes.append(note)
            self.notes = self.notes[-4:]
            self.refresh()

    def render_final_response(self, response: str, metadata: dict[str, Any] | None = None) -> None:
        self.thinking = "Response drafted"
        self.response = response
        self.response_metadata = metadata or {}
        if self._current_turn is not None:
            self._current_turn.response = response
        self.refresh()

    def render_error(self, code: str, message: str) -> None:
        self.error = f"{code}: {message}"
        if self._current_turn is not None:
            self._current_turn.error = self.error
        if self._live is None:
            self.console.print(self._error_panel())
            return
        self.refresh()

    def complete_turn(self) -> None:
        self._record_current_turn()
        self._stop_live()

    def render_static_response(
        self,
        *,
        title: str,
        response: str | None,
    ) -> None:
        self.response = response or "RunLLM completed without returning a response."
        self.response_metadata = {}
        self.console.print(Rule(title, style=MUTED))
        self.console.print(self._response_panel())

    def start_status(self, *, title: str, message: str) -> None:
        self.stop_status()
        self._status_live = Live(
            self._status_panel(title=title, message=message),
            console=self.console,
            refresh_per_second=10,
            transient=True,
        )
        self._status_live.start()

    def update_status(self, *, title: str, message: str) -> None:
        if self._status_live is None:
            return
        self._spinner_index += 1
        self._status_live.update(self._status_panel(title=title, message=message), refresh=True)

    def stop_status(self) -> None:
        if self._status_live is not None:
            self._status_live.stop()
            self._status_live = None

    def read_prompt(self) -> str | None:
        _initialize_prompt_history()
        while True:
            try:
                value = self._read_prompt_value().strip()
            except EOFError:
                return None
            if value in EXIT_COMMANDS:
                return None
            if value:
                _clear_previous_prompt_line()
                if self.handle_local_command(value):
                    continue
                _add_prompt_history(value)
                return value

    def record_prompt_history(self, value: str) -> None:
        _initialize_prompt_history()
        _add_prompt_history(value)

    def handle_local_command(self, value: str) -> bool:
        if not value.startswith("/"):
            return False
        command = value.split(maxsplit=1)[0]
        if command == "/clear":
            self.clear_session_log()
            return True
        if command == "/share":
            self._render_share()
            return True
        if command == "/help":
            self._render_command_help()
            return True
        if command == "/history":
            self._render_prompt_history()
            return True
        if command == "/tools":
            self._render_tools()
            return True
        self._render_unknown_command(command)
        return True

    def _read_prompt_value(self) -> str:
        value = _read_prompt_with_command_menu(
            prompt_fragments=self._prompt_fragments(),
            history_items=_prompt_history_items(limit=PROMPT_HISTORY_LENGTH),
        )
        if value is not None:
            return value
        return input(self._prompt_text())

    def _status_panel(self, *, title: str, message: str) -> Padding:
        body = Text()
        body.append(f"{self._loading_icon()} ", style=ACCENT)
        body.append(message, style=MUTED)
        return Padding(
            Panel(
                body,
                title=Text(title, style=MUTED),
                title_align="left",
                box=box.ROUNDED,
                border_style="#1D3B63",
                style=f"{TEXT} on {PANEL_BG}",
            ),
            (0, 2, 1, 2),
        )

    def _start_live(self) -> None:
        self._stop_live()
        self._live = Live(
            self._render(),
            console=self.console,
            refresh_per_second=10,
            transient=False,
        )
        self._live.start()
        self._start_spinner()

    def _stop_live(self) -> None:
        self._stop_spinner()
        if self._live is not None:
            self._live.stop()
            self._live = None

    def refresh(self) -> None:
        if self._live is not None:
            self._live.update(self._render(), refresh=True)

    def _start_spinner(self) -> None:
        if self._spinner_thread is not None and self._spinner_thread.is_alive():
            return
        self._spinner_stop_event.clear()
        self._spinner_thread = threading.Thread(
            target=self._run_spinner,
            name="runllm-session-window-spinner",
            daemon=True,
        )
        self._spinner_thread.start()

    def _stop_spinner(self) -> None:
        self._spinner_stop_event.set()
        if self._spinner_thread is not None:
            self._spinner_thread.join(timeout=1)
            self._spinner_thread = None

    def _run_spinner(self) -> None:
        while not self._spinner_stop_event.wait(SPINNER_INTERVAL_SEC):
            if not self._is_animating():
                continue
            self._spinner_index += 1
            self.refresh()

    def _is_animating(self) -> bool:
        return bool(
            self._live is not None
            and self.error is None
            and not self.response
            and (self.thinking or any(card.status == "running" for card in self.tool_cards))
        )

    def _render(self) -> Group:
        parts: list[Any] = []
        if self._show_session_header:
            parts.extend(
                [
                    self._chrome(),
                    self._banner(),
                    self._session_meta(),
                    self._divider(),
                ]
            )
        parts.extend([self._user_turn(), self._thinking_line()])
        if self.tool_cards:
            parts.append(self._tool_cards())
        if self.response:
            parts.extend(self._response_sections())
        if self.error:
            parts.append(self._error_panel())
        parts.append(self._divider())
        return Group(*parts)

    def _chrome(self) -> Panel:
        title = Text()
        title.append("●  ", style=ERR)
        title.append("●  ", style=WARN)
        title.append("●  ", style=OK)
        title.append(" runllm -- agent session", style=f"bold {MUTED}")
        title.append(f" -- {self.console.size.width}x{self.console.size.height}", style=DIM)
        return Panel(
            title,
            box=box.SQUARE,
            padding=(0, 1),
            style=f"{MUTED} on {SURFACE}",
            border_style=SURFACE,
        )

    def _banner(self) -> Padding:
        banner = Text()
        banner_lines = ASCII_BANNER.splitlines()
        for index, line in enumerate(banner_lines):
            banner.append(line, style=f"bold {ACCENT}")
            if index == len(banner_lines) - 1:
                banner.append("  beta", style=f"bold {WARN}")
            banner.append("\n")
        banner.rstrip()
        subtitle = Text()
        subtitle.append("AI SRE agent", style=MUTED)
        subtitle.append(f" v{self.cli_version or 'unknown'}", style=TEXT)
        subtitle.append(" · ask a question or type ", style=MUTED)
        subtitle.append("/help", style=LINK)
        subtitle.append(" or ", style=MUTED)
        subtitle.append("/exit", style=LINK)
        return Padding(Group(banner, subtitle), (1, 2, 0, 2))

    def _session_meta(self) -> Padding:
        repo_name = self.repo.root_name if self.repo and self.repo.root_name else "workspace"
        branch = self.repo.branch if self.repo and self.repo.branch else "unknown"
        files = _format_count(self.repo.file_count) if self.repo and self.repo.file_count else "0"
        integration_count = len(self.tools)
        status = "connected" if self.connected else "not connected"
        meta = Text()
        meta.append(f"□ {repo_name}", style=MUTED)
        meta.append("    ")
        meta.append(f"□ {branch}", style=MUTED)
        meta.append("    ")
        meta.append(f"□ {files} files indexed", style=MUTED)
        meta.append("    ")
        meta.append(f"□ {integration_count} integrations", style=MUTED)
        meta.append(" " * 6)
        meta.append(status, style=OK if self.connected else WARN)
        return Padding(meta, (1, 2, 0, 2))

    def _divider(self) -> Rule:
        return Rule(style=f"dim {SURFACE}")

    def _user_turn(self) -> Padding:
        line = Text()
        line.append("> ", style=ACCENT)
        line.append(self.question, style=TEXT)
        return Padding(line, (1, 2, 0, 2))

    def _thinking_line(self) -> Padding:
        line = Text()
        line.append("│  ", style=ACCENT)
        icon = self._loading_icon() if self._is_animating() else "□"
        line.append(f"{icon} ", style=ACCENT if self._is_animating() else MUTED)
        line.append(self.thinking, style=f"italic {MUTED}")
        return Padding(line, (0, 2, 1, 2))

    def _tool_cards(self) -> Padding:
        table = Table.grid(expand=True)
        table.add_column()
        for card in self.tool_cards:
            table.add_row(self._tool_card(card))
        return Padding(table, (0, 2, 1, 2))

    def _tool_card(self, card: ToolCard) -> Panel:
        status_style = OK if card.status == "done" else WARN if card.status == "running" else ERR
        duration = "running" if card.duration_sec is None else f"{card.duration_sec:.1f}s"
        icon = (
            self._loading_icon()
            if card.status == "running"
            else "✓"
            if card.status == "done"
            else "✕"
        )
        panel_bg = SURFACE if card.status == "running" else PANEL_BG
        border_style = ACCENT if card.status == "running" else OK if card.status == "done" else ERR
        body = Text()
        body.append(f"{icon}  ", style=ACCENT if card.status == "running" else MUTED)
        body.append(card.name, style=f"bold {TEXT}")
        body.append("\n   ")
        body.append("command  ", style=DIM)
        body.append(card.summary, style=MUTED)
        body.append("\n")
        body.append(" " * 3)
        body.append(f"{card.status} · {duration}", style=status_style)
        return Panel(
            body,
            box=box.ROUNDED,
            padding=(0, 1),
            style=f"{TEXT} on {panel_bg}",
            border_style=border_style,
        )

    def _response_sections(self) -> list[Any]:
        sections: list[Any] = []
        sections.append(self._response_panel(self.response))
        citations = _extract_citations(self.response_metadata)
        if citations:
            sections.append(self._citations_panel(citations))
        return sections

    def _response_panel(self, response_text: str | None = None) -> Padding:
        response_text = response_text if response_text is not None else self.response
        content = Markdown(response_text or "RunLLM completed without returning a response.")
        title = Text("RunLLM Answer", style=f"bold {MUTED}")
        return Padding(
            Panel(
                Padding(content, (1, 1)),
                title=title,
                title_align="left",
                box=box.ROUNDED,
                border_style=ACCENT,
                style=f"{TEXT} on {PANEL_BG}",
            ),
            (0, 2, 1, 2),
        )

    def _render_command_help(self) -> None:
        body = Text()
        for command, description in LOCAL_COMMAND_DESCRIPTIONS:
            body.append(f"{command:<10}", style=LINK)
            body.append(description, style=MUTED)
            body.append("\n")
        self._print_command_panel("local commands", body)

    def _render_tools(self) -> None:
        if not self.tools:
            self._print_command_panel("tools", Text("No local tools are configured.", style=MUTED))
            return
        table = Table.grid(expand=True)
        table.add_column(ratio=1)
        table.add_column(ratio=3)
        for tool in self.tools:
            action_names = ", ".join(action.name for action in tool.actions) or "no actions"
            name = Text(tool.tool, style=f"bold {TEXT}")
            details = Text()
            details.append(tool.description, style=MUTED)
            details.append("\n")
            details.append(action_names, style=LINK)
            table.add_row(name, details)
        self._print_command_panel("configured tools", table)

    def _render_prompt_history(self) -> None:
        history_items = _prompt_history_items(limit=10)
        if not history_items:
            self._print_command_panel("history", Text("No prompt history yet.", style=MUTED))
            return
        body = Text()
        for index, item in enumerate(history_items, start=1):
            body.append(f"{index:>2}. ", style=MUTED)
            body.append(item, style=TEXT)
            body.append("\n")
        self._print_command_panel("recent prompts", body)

    def _render_share(self) -> None:
        if not self.transcript_turns:
            self._print_command_panel(
                "share",
                Text("No completed turns to share yet.", style=MUTED),
            )
            return
        share_path = self._write_share_markdown()
        body = Text()
        body.append("Saved Markdown transcript:\n", style=MUTED)
        body.append(str(share_path), style=LINK)
        self._print_command_panel("share", body)

    def _render_unknown_command(self, command: str) -> None:
        body = Text()
        body.append(f"Unknown command: {command}\n", style=WARN)
        body.append("Type ", style=MUTED)
        body.append("/help", style=LINK)
        body.append(" to see available commands.", style=MUTED)
        self._print_command_panel("command", body)

    def _print_command_panel(self, title: str, renderable: Any) -> None:
        self.console.print(
            Padding(
                Panel(
                    renderable,
                    title=Text(title, style=MUTED),
                    title_align="left",
                    box=box.ROUNDED,
                    border_style="#1D3B63",
                    style=f"{TEXT} on {PANEL_BG}",
                ),
                (0, 2, 1, 2),
            )
        )

    def _citations_panel(self, citations: list[str]) -> Padding:
        text = Text()
        for citation in citations:
            text.append("□ ", style=ACCENT)
            text.append(citation, style=LINK)
            text.append("\n")
        return Padding(
            Panel(
                text,
                title=Text("citations", style=MUTED),
                title_align="left",
                box=box.ROUNDED,
                border_style="#1D3B63",
                style=f"{TEXT} on {PANEL_BG}",
            ),
            (0, 2, 1, 2),
        )

    def _prompt_text(self) -> str:
        if _READLINE is not None:
            return f"  \001\033[38;2;{ACCENT_RGB}m\002>\001\033[0m\002 "
        return f"  \033[38;2;{ACCENT_RGB}m>\033[0m "

    def _prompt_fragments(self) -> list[tuple[str, str]]:
        return [("", "  "), ("class:prompt", "> ")]

    def _loading_icon(self) -> str:
        return SPINNER_FRAMES[self._spinner_index % len(SPINNER_FRAMES)]

    def _record_current_turn(self) -> None:
        if self._current_turn is None:
            return
        if self.tool_cards:
            self._current_turn.tool_summaries = [
                _format_transcript_tool_summary(card) for card in self.tool_cards
            ]
        if self._current_turn.response or self._current_turn.error:
            self.transcript_turns.append(self._current_turn)
        self._current_turn = None

    def _write_share_markdown(self) -> Path:
        SHARE_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc)
        share_path = SHARE_DIR / f"runllm-share-{timestamp.strftime('%Y%m%d-%H%M%S')}.md"
        share_path.write_text(self._share_markdown(timestamp), encoding="utf-8")
        return share_path

    def _share_markdown(self, timestamp: datetime) -> str:
        repo_name = self.repo.root_name if self.repo and self.repo.root_name else "workspace"
        branch = self.repo.branch if self.repo and self.repo.branch else "unknown"
        commit = self.repo.commit if self.repo and self.repo.commit else "unknown"
        tool_names = ", ".join(tool.tool for tool in self.tools) or "none"
        lines = [
            "# RunLLM Investigation Share",
            "",
            f"- Exported at: {timestamp.isoformat()}",
            f"- Repository: {repo_name}",
            f"- Branch: {branch}",
            f"- Commit: {commit}",
            f"- CLI version: {self.cli_version or 'unknown'}",
            f"- Local tools: {tool_names}",
            "",
        ]
        for index, turn in enumerate(self.transcript_turns, start=1):
            lines.extend(
                [
                    f"## Turn {index}",
                    "",
                    "### Question",
                    "",
                    turn.question,
                    "",
                ]
            )
            if turn.tool_summaries:
                lines.extend(["### Tool Calls", ""])
                lines.extend(f"- {summary}" for summary in turn.tool_summaries)
                lines.append("")
            if turn.response:
                lines.extend(["### RunLLM Response", "", turn.response.strip(), ""])
            if turn.error:
                lines.extend(["### Error", "", turn.error, ""])
        return "\n".join(lines).rstrip() + "\n"

    def _error_panel(self) -> Padding:
        return Padding(
            Panel(
                Text(self.error or "Unknown error", style=ERR),
                title=Text("error", style=ERR),
                title_align="left",
                box=box.ROUNDED,
                border_style=ERR,
                style=f"{TEXT} on {PANEL_BG}",
            ),
            (0, 2, 1, 2),
        )

    def _find_tool_card(self, request_id: str) -> ToolCard | None:
        for card in self.tool_cards:
            if card.request_id == request_id:
                return card
        return None


def _friendly_progress(message: str) -> str:
    friendly_messages = {
        "Session initialized": "Investigating -- preparing session context...",
        "Repo upload complete": "Repository uploaded -- indexing code context...",
        "Repo archive stored": "Repository snapshot stored -- starting analysis...",
        "Repo archive reused": "Using cached repository snapshot -- starting analysis...",
        "Creating investigation workspace": "Creating investigation workspace...",
        "Workspace ready": "Workspace ready -- running investigation...",
        "Starting RunLLM response": "Drafting response...",
        "Session resumed": "Session resumed -- continuing investigation...",
    }
    return friendly_messages.get(message, message)


def _initialize_prompt_history() -> None:
    global _PROMPT_HISTORY_INITIALIZED
    if _READLINE is None or _PROMPT_HISTORY_INITIALIZED:
        return
    try:
        _READLINE.read_history_file(str(PROMPT_HISTORY_PATH))
    except FileNotFoundError:
        pass
    except OSError:
        pass
    try:
        _READLINE.set_history_length(PROMPT_HISTORY_LENGTH)
    except AttributeError:
        pass
    atexit.register(_save_prompt_history)
    _PROMPT_HISTORY_INITIALIZED = True


def _add_prompt_history(value: str) -> None:
    if _READLINE is None:
        return
    try:
        history_length = _READLINE.get_current_history_length()
        if history_length > 0 and _READLINE.get_history_item(history_length) == value:
            return
        _READLINE.add_history(value)
        _save_prompt_history()
    except AttributeError:
        return
    except OSError:
        return


def _read_prompt_with_command_menu(
    *,
    prompt_fragments: list[tuple[str, str]],
    history_items: list[str],
) -> str | None:
    session = _create_prompt_toolkit_session(history_items)
    if session is None:
        return None
    return cast(str, session.prompt(prompt_fragments))


def _create_prompt_toolkit_session(history_items: list[str]) -> Any | None:
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.document import Document
        from prompt_toolkit.history import InMemoryHistory
        from prompt_toolkit.styles import Style
    except ImportError:
        return None

    class SlashCommandCompleter(Completer):
        def get_completions(
            self,
            document: Document,
            _complete_event: object,
        ) -> Any:
            text = document.text_before_cursor
            if not text.startswith("/"):
                return
            for command, description in LOCAL_COMMAND_DESCRIPTIONS:
                if command.startswith(text):
                    yield Completion(
                        command,
                        start_position=-len(text),
                        display=command,
                        display_meta=description,
                    )

    history = InMemoryHistory()
    for item in history_items:
        history.append_string(item)
    session: Any = PromptSession(
        completer=SlashCommandCompleter(),
        complete_while_typing=True,
        history=history,
        style=Style.from_dict({"prompt": ACCENT}),
    )
    return session


def _prompt_history_items(*, limit: int) -> list[str]:
    if _READLINE is None:
        return []
    items: list[str] = []
    try:
        history_length = _READLINE.get_current_history_length()
        for index in range(history_length, 0, -1):
            item = _READLINE.get_history_item(index)
            if not item or item.startswith("/"):
                continue
            items.append(item)
            if len(items) >= limit:
                break
    except AttributeError:
        return []
    return list(reversed(items))


def _clear_previous_prompt_line() -> None:
    sys.stdout.write("\033[1A\033[2K\r")
    sys.stdout.flush()


def _save_prompt_history() -> None:
    if _READLINE is None:
        return
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _READLINE.write_history_file(str(PROMPT_HISTORY_PATH))
    except OSError:
        return


def _format_tool_command(request: CommandRequestMessage) -> str:
    argv = request.arguments.get("argv")
    if request.tool == "kubectl" and request.action == "execute" and _is_string_list(argv):
        argv_list = cast(list[str], argv)
        return shlex.join(["kubectl", *argv_list])
    return _format_tool_arguments(request.arguments)


def _format_tool_arguments(arguments: dict[str, Any]) -> str:
    if not arguments:
        return "no arguments"
    parts: list[str] = []
    for key, value in arguments.items():
        if isinstance(value, (dict, list)):
            rendered = str(value)
        else:
            rendered = shlex.quote(str(value))
        parts.append(f"{key}:{rendered}")
    return " ".join(parts)


def _is_string_list(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


def _format_transcript_tool_summary(card: ToolCard) -> str:
    duration = "running" if card.duration_sec is None else f"{card.duration_sec:.1f}s"
    return f"{card.name} [{card.status}, {duration}]: {card.summary}"


def _extract_display_text(event: dict[str, Any]) -> str | None:
    line = event.get("line")
    if isinstance(line, str) and line.strip():
        return _compact_line(line)

    part = event.get("part")
    if isinstance(part, dict):
        metadata = part.get("metadata")
        if isinstance(metadata, dict):
            openai_metadata = metadata.get("openai")
            if isinstance(openai_metadata, dict) and openai_metadata.get("phase") == "final_answer":
                return None
        value = part.get("text")
        if isinstance(value, str) and value.strip():
            return _compact_line(value)
    for key in ("text", "content", "message", "output"):
        value = event.get(key)
        if isinstance(value, str) and value.strip():
            return _compact_line(value)
    return None


def _compact_line(value: str) -> str:
    line = " ".join(value.split())
    return line[:160] + ("..." if len(line) > 160 else "")


def _extract_citations(metadata: dict[str, Any]) -> list[str]:
    raw = metadata.get("citations") or metadata.get("sources")
    if not isinstance(raw, list):
        return []
    citations: list[str] = []
    for item in raw:
        if isinstance(item, str):
            citations.append(item)
        elif isinstance(item, dict):
            label = item.get("title") or item.get("name") or item.get("url") or item.get("source")
            if isinstance(label, str):
                citations.append(label)
    return citations[:5]


def _format_count(value: int | None) -> str:
    if value is None:
        return "0"
    return f"{value:,}"
