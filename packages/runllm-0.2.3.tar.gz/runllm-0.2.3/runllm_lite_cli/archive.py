"""Repository archive creation for RunLLM Lite investigations."""

from __future__ import annotations

import subprocess
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from runllm_lite_cli.protocol import RepoMetadata

EXCLUDED_DIR_NAMES = {
    ".git",
    ".mypy_cache",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "env",
    "node_modules",
    "venv",
}
EXCLUDED_FILE_SUFFIXES = {
    ".7z",
    ".egg-info",
    ".gz",
    ".log",
    ".pyc",
    ".pyo",
    ".rar",
    ".tar",
    ".tgz",
    ".whl",
    ".zip",
}
ARCHIVE_PROGRESS_FILE_INTERVAL = 1_000
SCAN_PROGRESS_FILE_INTERVAL = 25_000
GIT_COMMAND_TIMEOUT_SEC = 300


@dataclass(frozen=True)
class RepoArchive:
    path: Path
    metadata: RepoMetadata


@dataclass(frozen=True)
class RepoSnapshotReuse:
    repo_snapshot_id: int
    object_uri: str


def _run_git(repo_path: Path, args: list[str]) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception as e:
        logger.debug("Git metadata command failed: repo_path={} args={} error={}", repo_path, args, e)
        return None
    if result.returncode != 0:
        return None
    value = result.stdout.strip()
    return value or None


def _run_git_command(repo_path: Path, args: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo_path,
        capture_output=True,
        text=True,
        timeout=timeout_sec,
        check=False,
    )


def _git_head_file_count(repo_path: Path) -> int | None:
    try:
        result = _run_git_command(
            repo_path,
            ["ls-tree", "-r", "--name-only", "HEAD"],
            timeout_sec=GIT_COMMAND_TIMEOUT_SEC,
        )
    except Exception as e:
        logger.debug("Failed to count git HEAD files: repo_path={} error={}", repo_path, e)
        return None
    if result.returncode != 0:
        logger.debug(
            "Failed to count git HEAD files: repo_path={} stderr={}",
            repo_path,
            result.stderr.strip(),
        )
        return None
    return len([line for line in result.stdout.splitlines() if line.strip()])


def _create_git_archive(repo_path: Path, archive_path: Path) -> RepoArchive | None:
    metadata = collect_git_repo_metadata(repo_path)
    if metadata is None or metadata.commit is None:
        return None

    logger.info(
        "Creating repo archive with git archive: repo_path={} archive={} commit={}\n",
        repo_path,
        archive_path,
        metadata.commit,
    )
    try:
        result = _run_git_command(
            repo_path,
            ["archive", "--format=tar.gz", "--output", str(archive_path), "HEAD"],
            timeout_sec=GIT_COMMAND_TIMEOUT_SEC,
        )
    except Exception as e:
        logger.warning(
            "git archive failed before completion, falling back to filesystem archive: repo_path={} error={}\n",
            repo_path,
            e,
        )
        archive_path.unlink(missing_ok=True)
        return None
    if result.returncode != 0:
        logger.warning(
            "git archive failed, falling back to filesystem archive: repo_path={} stderr={}\n",
            repo_path,
            result.stderr.strip(),
        )
        archive_path.unlink(missing_ok=True)
        return None

    total_bytes = archive_path.stat().st_size
    metadata = metadata.model_copy(update={"total_bytes": total_bytes})
    logger.info(
        "Repo git archive ready: archive={} total_bytes={} file_count={} branch={} commit={}\n",
        archive_path,
        total_bytes,
        metadata.file_count,
        metadata.branch,
        metadata.commit,
    )
    return RepoArchive(path=archive_path, metadata=metadata)


def collect_git_repo_metadata(repo_path: Path) -> RepoMetadata | None:
    commit = _run_git(repo_path, ["rev-parse", "--verify", "HEAD"])
    if commit is None:
        return None
    return RepoMetadata(
        root_name=repo_path.name,
        branch=_run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"]),
        commit=commit,
        total_bytes=None,
        file_count=_git_head_file_count(repo_path),
    )


def _should_skip_path(repo_path: Path, path: Path) -> bool:
    relative_parts = path.relative_to(repo_path).parts
    if any(part in EXCLUDED_DIR_NAMES for part in relative_parts):
        return True
    return any(path.name.endswith(suffix) for suffix in EXCLUDED_FILE_SUFFIXES)


def _iter_repo_files(repo_path: Path) -> list[Path]:
    files: list[Path] = []
    visited_paths = 0
    skipped_paths = 0
    for path in repo_path.rglob("*"):
        visited_paths += 1
        if _should_skip_path(repo_path, path):
            skipped_paths += 1
            continue
        if path.is_file() or path.is_symlink():
            files.append(path)
        if visited_paths % SCAN_PROGRESS_FILE_INTERVAL == 0:
            logger.info(
                "Scanning repo for archive: repo_path={} visited_paths={} included_files={} skipped_paths={}\n",
                repo_path,
                visited_paths,
                len(files),
                skipped_paths,
            )
    logger.info(
        "Finished repo scan: repo_path={} visited_paths={} included_files={} skipped_paths={}\n",
        repo_path,
        visited_paths,
        len(files),
        skipped_paths,
    )
    return files


def create_repo_archive(repo_path: Path) -> RepoArchive:
    archive_file = tempfile.NamedTemporaryFile(
        prefix=f"runllm_lite_repo_{repo_path.name}_",
        suffix=".tar.gz",
        delete=False,
    )
    archive_file.close()
    archive_path = Path(archive_file.name)
    git_archive = _create_git_archive(repo_path, archive_path)
    if git_archive is not None:
        return git_archive

    files = _iter_repo_files(repo_path)
    logger.info(
        "Creating repo archive: repo_path={} archive={} file_count={}\n",
        repo_path,
        archive_path,
        len(files),
    )

    with tarfile.open(archive_path, "w:gz") as archive:
        for index, path in enumerate(files, start=1):
            archive.add(path, arcname=str(path.relative_to(repo_path)), recursive=False)
            if index % ARCHIVE_PROGRESS_FILE_INTERVAL == 0:
                logger.info(
                    "Writing repo archive: archive={} added_files={} total_files={} current_size_bytes={}\n",
                    archive_path,
                    index,
                    len(files),
                    archive_path.stat().st_size if archive_path.exists() else 0,
                )

    total_bytes = archive_path.stat().st_size
    metadata = RepoMetadata(
        root_name=repo_path.name,
        branch=_run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"]),
        commit=_run_git(repo_path, ["rev-parse", "HEAD"]),
        total_bytes=total_bytes,
        file_count=len(files),
    )
    logger.info(
        "Repo archive ready: archive={} total_bytes={} file_count={} branch={} commit={}\n",
        archive_path,
        total_bytes,
        len(files),
        metadata.branch,
        metadata.commit,
    )
    return RepoArchive(path=archive_path, metadata=metadata)
