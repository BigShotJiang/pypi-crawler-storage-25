"""Local Grafana MCP execution for engine-requested tool calls."""

from __future__ import annotations

import asyncio
import json
import os
import time
import urllib.request
from pathlib import Path
from typing import Any

from loguru import logger

from runllm_lite_cli.config import CONFIG_DIR, CliConfig, GrafanaConfig, validate_binary
from runllm_lite_cli.protocol import (
    CommandRequestMessage,
    CommandResultMessage,
    ToolActionCapability,
    ToolCapability,
)

MCP_GRAFANA_DOWNLOAD_URL = (
    "https://github.com/grafana/mcp-grafana/releases/latest/download/mcp-grafana_Linux_x86_64.tar.gz"
)


def grafana_capability() -> ToolCapability:
    return ToolCapability(
        tool="grafana",
        description="Query the user's Grafana instance through the local mcp-grafana binary.",
        actions=[
            ToolActionCapability(
                name="list_tools",
                description="List Grafana MCP tools available from the configured Grafana server.",
                input_schema={"type": "object", "properties": {}},
            ),
            ToolActionCapability(
                name="call_tool",
                description="Call one Grafana MCP tool by name with JSON arguments.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "arguments": {"type": "object"},
                    },
                    "required": ["name"],
                },
                examples=[
                    'grafana.call_tool name=search_dashboards arguments={"query":"errors"}'
                ],
            ),
        ],
    )


def default_mcp_grafana_install_path() -> Path:
    return CONFIG_DIR / "bin" / "mcp-grafana"


def ensure_mcp_grafana(installed_path: str | None = None, *, auto_install: bool) -> str:
    try:
        return validate_binary("mcp-grafana", installed_path)
    except ValueError:
        if not auto_install:
            raise
    target = default_mcp_grafana_install_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    archive_path = target.parent / "mcp-grafana.tar.gz"
    logger.info("Downloading mcp-grafana: url={} archive={}\n", MCP_GRAFANA_DOWNLOAD_URL, archive_path)
    urllib.request.urlretrieve(MCP_GRAFANA_DOWNLOAD_URL, archive_path)
    import tarfile

    with tarfile.open(archive_path, "r:gz") as archive:
        member = next(
            (item for item in archive.getmembers() if Path(item.name).name == "mcp-grafana"),
            None,
        )
        if member is None:
            raise ValueError("Downloaded mcp-grafana archive did not contain mcp-grafana binary.")
        member.name = Path(member.name).name
        archive.extract(member, target.parent)
    extracted = target.parent / "mcp-grafana"
    extracted.chmod(0o700)
    archive_path.unlink(missing_ok=True)
    return str(extracted)


async def _read_json_line(stream: asyncio.StreamReader) -> dict[str, Any]:
    line = await stream.readline()
    if not line:
        raise RuntimeError("mcp-grafana exited before returning a response.")
    return json.loads(line.decode("utf-8"))


async def _send_json_line(process: asyncio.subprocess.Process, payload: dict[str, Any]) -> None:
    if process.stdin is None:
        raise RuntimeError("mcp-grafana stdin is not available.")
    process.stdin.write(json.dumps(payload).encode("utf-8") + b"\n")
    await process.stdin.drain()


async def _run_mcp_request(
    grafana_config: GrafanaConfig,
    action: str,
    arguments: dict[str, Any],
    timeout_sec: int,
) -> dict[str, Any]:
    env = os.environ.copy()
    env["GRAFANA_URL"] = grafana_config.grafana_url
    env["GRAFANA_SERVICE_ACCOUNT_TOKEN"] = grafana_config.service_account_token
    process = await asyncio.create_subprocess_exec(
        grafana_config.mcp_grafana_path,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    try:
        await _send_json_line(
            process,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "runllm-lite-cli", "version": "dev"},
            },
        },
        )
        await asyncio.wait_for(_read_json_line(process.stdout), timeout=timeout_sec)
        await _send_json_line(
            process,
            {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}},
        )
        if action == "list_tools":
            await _send_json_line(
                process,
                {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
            )
        elif action == "call_tool":
            name = arguments.get("name")
            if not isinstance(name, str) or not name:
                raise ValueError("grafana.call_tool requires arguments.name.")
            tool_arguments = arguments.get("arguments")
            if tool_arguments is None:
                tool_arguments = {}
            if not isinstance(tool_arguments, dict):
                raise ValueError("grafana.call_tool arguments.arguments must be an object.")
            await _send_json_line(
                process,
                {
                    "jsonrpc": "2.0",
                    "id": 2,
                    "method": "tools/call",
                    "params": {"name": name, "arguments": tool_arguments},
                },
            )
        else:
            raise ValueError(f"Unsupported Grafana action: {action}")
        return await asyncio.wait_for(_read_json_line(process.stdout), timeout=timeout_sec)
    finally:
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=2)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()


async def run_grafana_tool(config: CliConfig, request: CommandRequestMessage) -> CommandResultMessage:
    started_at = time.monotonic()
    grafana_config = config.tools.grafana
    if grafana_config is None or not grafana_config.enabled:
        return CommandResultMessage(
            request_id=request.request_id,
            success=False,
            exit_code=1,
            stderr="Grafana is not configured for this RunLLM session.\n",
        )
    logger.info(
        "Executing Grafana request: request_id={} action={} args_keys={}\n",
        request.request_id,
        request.action,
        sorted(request.arguments.keys()),
    )
    try:
        payload = await _run_mcp_request(
            grafana_config,
            request.action,
            request.arguments,
            config.command_timeout_sec,
        )
        stdout = json.dumps(payload, indent=2, sort_keys=True)
        stderr = ""
        result = payload.get("result")
        is_tool_error = isinstance(result, dict) and result.get("isError") is True
        exit_code = 0 if "error" not in payload and not is_tool_error else 1
    except Exception as e:
        stdout = ""
        stderr = f"runllm failed to execute Grafana MCP request: {e}\n"
        payload = None
        exit_code = 1
    duration_ms = int((time.monotonic() - started_at) * 1000)
    logger.info(
        "Grafana request complete: request_id={} exit_code={} duration_ms={} stdout_bytes={} stderr_bytes={}\n",
        request.request_id,
        exit_code,
        duration_ms,
        len(stdout.encode()),
        len(stderr.encode()),
    )
    return CommandResultMessage(
        request_id=request.request_id,
        success=exit_code == 0,
        exit_code=exit_code,
        stdout=stdout,
        stderr=stderr,
        duration_ms=duration_ms,
        data=payload,
    )
