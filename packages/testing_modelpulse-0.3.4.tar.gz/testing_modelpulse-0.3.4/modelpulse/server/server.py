"""
modelpulse.server.server
Shim module that re-exports the CLI for backwards compatibility.
"""
from modelpulse.server.cli import cli, main

__all__ = ["cli", "main"]