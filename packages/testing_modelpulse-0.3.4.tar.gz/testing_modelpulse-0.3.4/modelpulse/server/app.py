"""
modelpulse.server.app
FastAPI application factory — all HTTP routes and the WebSocket endpoint.
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
import struct
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated, Any, Optional

from fastapi import (
    FastAPI, File, Form, HTTPException, Request,
    UploadFile, WebSocket, WebSocketDisconnect,
)
from fastapi.responses import FileResponse, JSONResponse

from modelpulse.server.connection import ConnectionManager
from modelpulse.server.helpers import _sha256_of_file, _sha256_of_upload
from modelpulse.shared.ws_protocol import MsgType, WsMessage

log = logging.getLogger("modelpulse.server")

PING_INTERVAL: float = 20.0
DELTA_MANIFEST_FILE: str = "delta_manifest.json"


def create_app(
    shard_dir: Path,
    metrics_log: Path,
    *,
    port: int = 8000,
    ping_interval: float = PING_INTERVAL,
) -> FastAPI:

    # active model state
    _state: dict[str, Any] = {
        "model_id": "",
        "iteration": 0,
    }

    # helpers
    def _model_dir(model_id: str) -> Path:
        return shard_dir / model_id

    def _active_dir() -> Path:
        mid = _state["model_id"]
        if mid:
            d = _model_dir(mid)
            if d.exists():
                return d
        return shard_dir

    def _load_manifest() -> dict | None:
        p = _active_dir() / "manifest.json"
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

    def _load_delta_manifest(model_id: str) -> dict | None:
        p = _model_dir(model_id) / DELTA_MANIFEST_FILE
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

    def _log_metrics(payload: dict) -> None:
        with open(metrics_log, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload) + "\n")

    # lifespan
    manager: ConnectionManager | None = None

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        nonlocal manager
        manager = ConnectionManager()
        app.state.manager = manager

        async def _ping_task():
            while True:
                await asyncio.sleep(ping_interval)
                if manager.count:
                    await manager.broadcast(WsMessage.ping())

        task = asyncio.create_task(_ping_task())
        try:
            yield
        finally:
            task.cancel()

    app = FastAPI(title="modelpulse / Device A", version="0.3.0", lifespan=lifespan)

    def _mgr() -> ConnectionManager:
        return app.state.manager

    # Health
    @app.get("/health")
    def health():
        return {
            "status": "ok",
            "active_model_id": _state["model_id"],
            "active_iteration": _state["iteration"],
            "shard_dir": str(shard_dir),
            "ws_clients": _mgr().count,
        }

    # Manifest & shards
    @app.get("/manifest")
    def get_manifest():
        m = _load_manifest()
        if m is None:
            raise HTTPException(404, "No manifest.json for the active model")
        return JSONResponse(content=m)

    @app.get("/shards/{filename}")
    def get_shard(filename: str):
        if "/" in filename or ".." in filename or "\\" in filename:
            raise HTTPException(400, "Invalid filename")
        if not filename.endswith(".shard"):
            raise HTTPException(400, "Only .shard files are served")
        p = _active_dir() / filename
        if not p.exists():
            raise HTTPException(404, f"Not found: {filename}")
        return FileResponse(str(p), media_type="application/octet-stream", filename=filename)

    # Delta manifest & delta shards
    @app.get("/shards/delta/{model_id}/manifest")
    def get_delta_manifest(model_id: str):
        dm = _load_delta_manifest(model_id)
        if dm is None:
            raise HTTPException(404, f"No delta manifest for model_id={model_id!r}")
        return JSONResponse(content=dm)

    @app.get("/shards/delta/{model_id}/{filename}")
    def get_delta_shard(model_id: str, filename: str):
        if "/" in filename or ".." in filename or "\\" in filename:
            raise HTTPException(400, "Invalid filename")
        if not filename.endswith(".shard"):
            raise HTTPException(400, "Only .shard files are served")

        dm = _load_delta_manifest(model_id)
        if dm is None:
            raise HTTPException(404, f"No delta manifest for model_id={model_id!r}")

        changed = dm.get("changed_shards", {})
        is_changed = (filename in changed) or any(s.get("file") == filename for s in changed.values())
        if not is_changed:
            raise HTTPException(404, f"{filename!r} is not listed as a changed shard")

        p = _model_dir(model_id) / filename
        if not p.exists():
            raise HTTPException(404, f"Shard file missing: {filename}")
        return FileResponse(str(p), media_type="application/octet-stream", filename=filename)

    # Metrics
    @app.post("/metrics")
    async def post_metrics(request: Request):
        _log_metrics(await request.json())
        return {"status": "received"}

    @app.get("/results")
    def get_all_results():
        if not metrics_log.exists(): return []
        return [json.loads(l) for l in metrics_log.read_text(encoding="utf-8").splitlines() if l.strip()]

    @app.get("/results/latest")
    def get_latest_result():
        if not metrics_log.exists(): raise HTTPException(404, "No metrics yet")
        lines = [l for l in metrics_log.read_text(encoding="utf-8").splitlines() if l.strip()]
        if not lines: raise HTTPException(404, "No metrics yet")
        return json.loads(lines[-1])

    # Full model upload
    @app.post("/models/upload")
    async def upload_model(
        model_id: Annotated[str, Form()],
        manifest_file: Annotated[UploadFile, File(alias="manifest")],
        shard_files: Annotated[list[UploadFile], File(alias="shards")],
    ):
        if not model_id or any(c in model_id for c in (".", "/", "\\", "..")):
            raise HTTPException(400, f"Invalid model_id: {model_id!r}")

        dest = _model_dir(model_id)
        dest.mkdir(parents=True, exist_ok=True)

        written = []
        try:
            for upload in [manifest_file, *shard_files]:
                dest_path = dest / upload.filename
                with open(dest_path, "wb") as fh:
                    while chunk := await upload.read(65_536):
                        fh.write(chunk)
                written.append(upload.filename)
        except Exception as exc:
            log.exception("write error for model=%s: %s", model_id, exc)
            raise HTTPException(500, f"Write error: {exc}")

        manifest_path = dest / "manifest.json"
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise HTTPException(422, f"manifest.json is not valid JSON: {exc}")

        if not manifest.get("model_id"):
            manifest["model_id"] = model_id
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        _state["model_id"] = model_id
        _state["iteration"] = 0
        log.info("Full model active: %s", model_id)

        msg = WsMessage.model_ready({}, model_id=model_id, update_type="full", base_model_id=None)
        reached = await _mgr().broadcast(msg)

        return {
            "status": "uploaded",
            "update_type": "full",
            "model_id": model_id,
            "iteration": 0,
            "files_written": written,
            "clients_notified": reached,
        }

    # Delta upload
    @app.post("/models/delta")
    async def upload_delta(
        model_id: Annotated[str, Form()],
        base_model_id: Annotated[str, Form()],
        shard_files: Annotated[list[UploadFile], File(alias="shards")],
    ):
        base_dir = _model_dir(base_model_id)
        if not base_dir.exists():
            raise HTTPException(404, f"base_model_id={base_model_id!r} not found")

        dest = _model_dir(model_id)
        if dest.exists(): shutil.rmtree(dest)
        shutil.copytree(base_dir, dest)

        manifest_path = dest / "manifest.json"
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            file_to_tensor = {s["file"]: name for name, s in manifest.get("shards", {}).items()}
        except Exception:
            file_to_tensor = {}

        changed_shards: dict[str, dict] = {}
        written = []

        try:
            for upload in shard_files:
                fname = upload.filename
                raw = await upload.read()
                dest_path = dest / fname
                dest_path.write_bytes(raw)
                written.append(fname)

                new_sha = _sha256_of_upload(upload, raw)
                tensor_key = file_to_tensor.get(fname, fname)
                changed_shards[tensor_key] = {
                    "file": fname,
                    "sha256": new_sha,
                    "nbytes": len(raw),
                }

                if len(raw) >= 12 and raw[:4] == b"SHRD":
                    try:
                        hdr_len = struct.unpack("<I", raw[8:12])[0]
                        hdr_json = json.loads(raw[12:12 + hdr_len].decode("utf-8"))
                        if tensor_key in manifest.get("shards", {}):
                            s_info = manifest["shards"][tensor_key]
                            s_info["nbytes"] = hdr_json.get("nbytes", s_info["nbytes"])
                            s_info["sha256"] = hdr_json.get("sha256", s_info["sha256"])
                    except Exception: pass

        except Exception as exc:
            log.exception("delta write error for model=%s: %s", model_id, exc)
            shutil.rmtree(dest, ignore_errors=True)
            raise HTTPException(500, f"Write error: {exc}")

        manifest["model_id"] = model_id
        manifest["base_model_id"] = base_model_id
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        prev_iteration = _state["iteration"] if _state["model_id"] == base_model_id else 0
        new_iteration = prev_iteration + 1

        delta_manifest = {
            "base_model_id": base_model_id,
            "delta_model_id": model_id,
            "iteration": new_iteration,
            "changed_shards": changed_shards,
            "timestamp": time.time(),
        }
        (dest / DELTA_MANIFEST_FILE).write_text(json.dumps(delta_manifest, indent=2), encoding="utf-8")

        _state["model_id"] = model_id
        _state["iteration"] = new_iteration
        if not written:
            log.info("Model identity activated (no changes): %s (base=%s)", model_id, base_model_id)
        else:
            log.info("Delta model active: %s (base=%s, shards=%d)", model_id, base_model_id, len(written))

        msg = WsMessage.model_ready({}, model_id=model_id, update_type="delta", base_model_id=base_model_id)
        reached = await _mgr().broadcast(msg)

        return {
            "status": "delta_uploaded",
            "update_type": "delta",
            "model_id": model_id,
            "iteration": new_iteration,
            "files_written": written,
            "clients_notified": reached,
        }

    # Admin
    @app.post("/models/notify")
    async def notify_clients():
        m = _load_manifest()
        if m is None: raise HTTPException(404, "No active model")
        model_id = _state["model_id"] or m.get("model_id", "")
        dm = _load_delta_manifest(model_id)
        update_type = "delta" if dm is not None else "full"
        base_model_id = dm.get("base_model_id") if dm else None

        msg = WsMessage.model_ready({}, model_id=model_id, update_type=update_type, base_model_id=base_model_id)
        reached = await _mgr().broadcast(msg)
        return {"status": "broadcast", "clients_reached": reached}

    @app.get("/models")
    def list_models():
        models = []
        for d in sorted(shard_dir.iterdir()):
            if not d.is_dir(): continue
            models.append({"model_id": d.name, "active": d.name == _state["model_id"]})
        return {"active_model_id": _state["model_id"], "models": models}

    @app.get("/ws/clients")
    def ws_clients():
        return {"count": _mgr().count, "client_ids": _mgr().client_ids()}

    # WebSocket
    @app.websocket("/ws")
    async def websocket_endpoint(ws: WebSocket):
        client_id = "unknown"
        try:
            await ws.accept()
            raw = await ws.receive_text()
            hello = WsMessage.from_json(raw)
            if hello.type != MsgType.HELLO:
                await ws.close(code=1002); return

            client_id = hello.payload.get("client_id", "unknown")
            await _mgr().connect(ws, client_id)

            if _state["model_id"]:
                mid = _state["model_id"]
                dm = _load_delta_manifest(mid)
                await _mgr().send(ws, WsMessage.model_ready(
                    {}, model_id=mid, update_type="delta" if dm else "full", 
                    base_model_id=dm.get("base_model_id") if dm else None
                ))

            async for raw_msg in ws.iter_text():
                msg = WsMessage.from_json(raw_msg)
                if msg.type == MsgType.METRICS:
                    _log_metrics(msg.payload.get("data", {}))
                    await _mgr().send(ws, WsMessage.ack(msg.msg_id))
                elif msg.type == MsgType.PONG: pass
                elif msg.type == MsgType.ACK: pass
                elif msg.type == MsgType.BYE: break
                else: await _mgr().send(ws, WsMessage.error(f"Unhandled type: {msg.type!r}"))

        except WebSocketDisconnect: pass
        except Exception as exc: log.exception("WS error: %s", exc)
        finally: await _mgr().disconnect(ws)

    return app
