"""
modelpulse.server.connection
WebSocket connection manager — tracks all live /ws connections.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import WebSocket

from modelpulse.shared.ws_protocol import WsMessage

log = logging.getLogger("modelpulse.server")


class ConnectionManager:
    def __init__(self) -> None:
        self._connections: dict[WebSocket, str] = {}
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket, client_id: str) -> None:
        async with self._lock:
            self._connections[ws] = client_id
        log.info("WS connected  client_id=%s  total=%d", client_id, self.count)

    async def disconnect(self, ws: WebSocket) -> None:
        async with self._lock:
            cid = self._connections.pop(ws, "?")
        log.info("WS disconnected  client_id=%s  total=%d", cid, self.count)

    async def send(self, ws: WebSocket, msg: WsMessage) -> bool:
        try:
            await ws.send_text(msg.to_json())
            return True
        except Exception as exc:
            log.warning("send failed → %s: %s", self._connections.get(ws, "?"), exc)
            return False

    async def broadcast(self, msg: WsMessage) -> int:
        async with self._lock:
            targets = list(self._connections.items())

        ok, dead = 0, []
        for ws, cid in targets:
            try:
                await ws.send_text(msg.to_json())
                ok += 1
            except Exception as exc:
                log.warning("broadcast failed → %s: %s", cid, exc)
                dead.append(ws)

        async with self._lock:
            for ws in dead:
                self._connections.pop(ws, None)
        return ok

    @property
    def count(self) -> int:
        return len(self._connections)

    def client_ids(self) -> list[str]:
        return list(self._connections.values())
