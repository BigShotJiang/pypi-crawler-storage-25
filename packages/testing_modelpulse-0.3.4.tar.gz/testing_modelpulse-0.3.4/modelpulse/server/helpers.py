"""
modelpulse.server.helpers
SHA-256 and fast-ID utilities shared by the server app and CLI.
"""
from __future__ import annotations

import hashlib
import struct
from pathlib import Path


def _sha256_of_upload(upload, data: bytes) -> str:
    """Return hex SHA-256 of raw shard payload (strip SHRD header if present)."""
    if len(data) >= 12 and data[:4] == b"SHRD":
        hdr_len = struct.unpack("<I", data[8:12])[0]
        payload = data[12 + hdr_len:]
    else:
        payload = data
    return hashlib.sha256(payload).hexdigest()


def _sha256_of_file(path: Path) -> str:
    """Return hex SHA-256 of the tensor payload stored in a .shard file."""
    data = path.read_bytes()
    if len(data) >= 12 and data[:4] == b"SHRD":
        hdr_len = struct.unpack("<I", data[8:12])[0]
        payload = data[12 + hdr_len:]
    else:
        payload = data
    return hashlib.sha256(payload).hexdigest()


def _get_fast_id(p: Path) -> str:
    """Return size-hash(head) string for fast shard comparison (no full read)."""
    if not p.is_file():
        return "MISSING"
    size = p.stat().st_size
    with open(p, "rb") as f:
        head = f.read(65536)
        h = hashlib.sha256(head).hexdigest()
    return f"{size}-{h}"
