"""
test_synthetic.py
Creates a minimal but structurally valid GGUF file, runs the full
convert → shard → overwrite-one-shard → assemble pipeline, and
validates the output at every step.

Run: python test_synthetic.py
No external dependencies, no real model needed.
"""

import struct
import json
import hashlib
import os
import sys
import shutil
import tempfile
from pathlib import Path

# Add parent dir to path so we can import our modules
sys.path.insert(0, str(Path(__file__).parent))
from modelpulse.tools.gguf_parser import GGUFReader, ggml_tensor_nbytes
from modelpulse.tools.gguf_to_shards import convert, assemble, read_shard, write_shard


# ── GGUF synthetic writer ─────────────────────────────────────────────────────

GGUF_MAGIC = 0x46554747
ALIGNMENT  = 32

def _pack_str(s: str) -> bytes:
    b = s.encode("utf-8")
    return struct.pack("<Q", len(b)) + b

def _pack_u32(v: int) -> bytes: return struct.pack("<I", v)
def _pack_u64(v: int) -> bytes: return struct.pack("<Q", v)
def _pack_f32(v: float) -> bytes: return struct.pack("<f", v)


def make_synthetic_gguf(path: Path):
    """
    Write a minimal GGUF v3 file with a realistic (but tiny) transformer layout.

    Tensors (all Q8_0, block=32, 34 bytes per block):
      token_embd.weight         [vocab=128, dim=64]   → 128*64 = 8192 elements → 256 blocks → 8704 bytes
      blk.0.attn_q.weight       [64, 64]              → 4096 elements → 128 blocks → 4352 bytes
      blk.0.attn_k.weight       [64, 64]              → 4096 → 4352 bytes
      blk.0.attn_v.weight       [64, 64]              → 4096 → 4352 bytes
      blk.0.attn_output.weight  [64, 64]              → 4096 → 4352 bytes
      blk.0.ffn_up.weight       [128, 64]             → 8192 elements → 256 blocks → 8704 bytes
      blk.0.ffn_down.weight     [64, 128]             → 8192 → 8704 bytes
      blk.0.attn_norm.weight    [64]   F32            → 64*4 = 256 bytes
      blk.1.attn_q.weight       [64, 64]              → 4352 bytes
      blk.1.ffn_up.weight       [128, 64]             → 8704 bytes
      blk.1.ffn_down.weight     [64, 128]             → 8704 bytes
      output.weight             [128, 64]             → 8704 bytes
    """
    Q8_0 = 8   # ggml type id
    F32  = 0

    tensors = [
        # (name,                      type,  dims)
        ("token_embd.weight",          Q8_0, [128, 64]),
        ("blk.0.attn_q.weight",        Q8_0, [64, 64]),
        ("blk.0.attn_k.weight",        Q8_0, [64, 64]),
        ("blk.0.attn_v.weight",        Q8_0, [64, 64]),
        ("blk.0.attn_output.weight",   Q8_0, [64, 64]),
        ("blk.0.ffn_up.weight",        Q8_0, [128, 64]),
        ("blk.0.ffn_down.weight",      Q8_0, [64, 128]),
        ("blk.0.attn_norm.weight",     F32,  [64]),
        ("blk.1.attn_q.weight",        Q8_0, [64, 64]),
        ("blk.1.ffn_up.weight",        Q8_0, [128, 64]),
        ("blk.1.ffn_down.weight",      Q8_0, [64, 128]),
        ("output.weight",              Q8_0, [128, 64]),
    ]

    # Compute sizes and data
    tensor_data = []
    for name, ttype, dims in tensors:
        nbytes = ggml_tensor_nbytes(ttype, dims)
        # fill with deterministic pseudo-random bytes so we can verify
        seed = sum(ord(c) for c in name)
        data = bytes((seed * 7 + i * 13 + i // 256) % 256 for i in range(nbytes))
        tensor_data.append((name, ttype, dims, nbytes, data))

    # ── build tensor_info array with computed offsets ──
    running = 0
    offsets = []
    for _, _, _, nbytes, _ in tensor_data:
        # align each tensor
        pad = (ALIGNMENT - (running % ALIGNMENT)) % ALIGNMENT if running % ALIGNMENT else 0
        running += pad
        offsets.append(running)
        running += nbytes

    # ── assemble header bytes ──
    hdr = bytearray()

    # magic + version
    hdr.extend(struct.pack("<I", GGUF_MAGIC))
    hdr.extend(struct.pack("<I", 3))          # version 3

    # tensor_count + kv_count
    hdr.extend(struct.pack("<Q", len(tensors)))
    hdr.extend(struct.pack("<Q", 3))           # 3 metadata KVs

    # ── metadata KVs ──
    # KV: general.architecture = "llama"   (STRING, type=8)
    hdr.extend(_pack_str("general.architecture"))
    hdr.extend(_pack_u32(8))
    hdr.extend(_pack_str("synthetic_test"))

    # KV: general.name = "synthetic_model"  (STRING, type=8)
    hdr.extend(_pack_str("general.name"))
    hdr.extend(_pack_u32(8))
    hdr.extend(_pack_str("synthetic_model_v1"))

    # KV: llama.context_length = 512  (UINT32, type=4)
    hdr.extend(_pack_str("llama.context_length"))
    hdr.extend(_pack_u32(4))
    hdr.extend(_pack_u32(512))

    # ── tensor_info array ──
    for (name, ttype, dims, nbytes, _), offset in zip(tensor_data, offsets):
        hdr.extend(_pack_str(name))
        hdr.extend(_pack_u32(len(dims)))
        for d in dims:
            hdr.extend(_pack_u64(d))
        hdr.extend(_pack_u32(ttype))
        hdr.extend(_pack_u64(offset))

    # alignment padding
    pos = len(hdr)
    pad = (ALIGNMENT - (pos % ALIGNMENT)) % ALIGNMENT
    hdr.extend(b"\x00" * pad)

    # ── write file ──
    with open(path, "wb") as f:
        f.write(hdr)
        written = 0
        for (name, _, _, nbytes, data), offset in zip(tensor_data, offsets):
            # pad to declared offset
            pad_needed = offset - written
            f.write(b"\x00" * pad_needed)
            written += pad_needed
            f.write(data)
            written += len(data)

    return {t[0]: t[4] for t in tensor_data}   # name → original bytes


# ── test helpers ──────────────────────────────────────────────────────────────

PASS = "\033[32m✓ PASS\033[0m"
FAIL = "\033[31m✗ FAIL\033[0m"

def check(label: str, condition: bool, detail: str = ""):
    status = PASS if condition else FAIL
    print(f"  {status}  {label}" + (f"  [{detail}]" if detail else ""))
    if not condition:
        raise AssertionError(f"FAILED: {label}")


# ── test suite ────────────────────────────────────────────────────────────────

def run_tests():
    tmp = Path(tempfile.mkdtemp(prefix="gguf_test_"))
    print(f"\n\033[1mTest workspace:\033[0m  {tmp}\n")

    try:
        # ────────────────────────────────────────────────────────────────────
        print("\033[1m[1] Generating synthetic GGUF\033[0m")
        gguf_path = tmp / "synthetic.gguf"
        original_tensors = make_synthetic_gguf(gguf_path)
        gguf_size = gguf_path.stat().st_size
        check("GGUF file created", gguf_path.exists())
        check("GGUF size > 0", gguf_size > 0, f"{gguf_size} bytes")
        print(f"  created {gguf_path.name}  ({gguf_size:,} bytes, {len(original_tensors)} tensors)")

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[2] Parse round-trip: parser reads back synthetic GGUF\033[0m")
        with GGUFReader(gguf_path) as r:
            gguf = r.parse()
            # Verify every tensor's data matches what we wrote
            for t in gguf.tensors:
                data = r.read_tensor_data(gguf, t)
                expected = original_tensors[t.name]
                check(
                    f"tensor data matches: {t.name}",
                    data == expected,
                    f"{len(data)} bytes"
                )
        check("tensor count correct", len(gguf.tensors) == len(original_tensors))
        check("metadata present", "general.architecture" in gguf.metadata)
        check("alignment set", gguf.alignment == ALIGNMENT)
        print(f"  data_offset = {gguf.data_offset} bytes")

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[3] Convert GGUF → shard store\033[0m")
        shard_dir = tmp / "shards"
        manifest = convert(gguf_path, shard_dir, verbose=True)

        check("manifest.json created", (shard_dir / "manifest.json").exists())
        check("shard count matches", manifest["tensor_count"] == len(original_tensors))
        for name, entry in manifest["shards"].items():
            shard_path = shard_dir / entry["file"]
            check(f"shard exists: {entry['file']}", shard_path.exists())

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[4] Verify each shard: magic, version, sha256, data integrity\033[0m")
        for name, entry in manifest["shards"].items():
            shard_path = shard_dir / entry["file"]
            hdr, data  = read_shard(shard_path)   # raises if sha256 fails
            check(f"sha256 valid: {name}", hdr["sha256"] == entry["sha256"])
            check(f"data matches original: {name}", data == original_tensors[name])
            check(f"dims match: {name}", hdr["dims"] == entry["dims"])
            check(f"nbytes match: {name}", hdr["nbytes"] == len(data))

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[5] Simulate OTA update: overwrite blk.1.ffn_up.weight shard\033[0m")
        target_name  = "blk.1.ffn_up.weight"
        target_entry = manifest["shards"][target_name]
        target_path  = shard_dir / target_entry["file"]
        old_size     = target_path.stat().st_size

        # Create "new" quantized version — different bytes, same dims
        # (in practice llama-quantize would produce this)
        new_nbytes = target_entry["nbytes"]  # same size for Q8_0→Q8_0 test
        new_data   = bytes((i * 17 + 99) % 256 for i in range(new_nbytes))

        # Build a fake GGUFTensorInfo-like object for write_shard
        from modelpulse.tools.gguf_parser import GGUFTensorInfo
        fake_tensor = GGUFTensorInfo(
            name      = target_name,
            dims      = target_entry["dims"],
            ggml_type = target_entry["ggml_type"],
            offset    = 0,
            nbytes    = new_nbytes,
        )
        new_sha256 = write_shard(target_path, fake_tensor, new_data)

        # Update manifest
        manifest["shards"][target_name]["sha256"] = new_sha256
        with open(shard_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)

        check("shard file still exists after overwrite", target_path.exists())
        new_size = target_path.stat().st_size
        check("overwritten shard is self-contained", new_size > 0, f"{new_size} bytes")
        print(f"  shard size: {old_size} → {new_size} bytes  (same quant type in test)")

        # Verify the overwritten shard reads back correctly
        hdr2, data2 = read_shard(target_path)
        check("overwritten shard sha256 valid", hdr2["sha256"] == new_sha256)
        check("overwritten shard data correct", data2 == new_data)
        print(f"  updated manifest sha256 for {target_name}")

        # Other shards untouched
        for name, entry in manifest["shards"].items():
            if name == target_name:
                continue
            hdr, data = read_shard(shard_dir / entry["file"])
            check(f"adjacent shard untouched: {name}", data == original_tensors[name])

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[6] Reassemble shard store → new GGUF\033[0m")
        reassembled_path = tmp / "reassembled.gguf"
        assemble(shard_dir, reassembled_path, verbose=True)

        check("reassembled GGUF exists", reassembled_path.exists())

        # Parse reassembled and verify all tensors
        with GGUFReader(reassembled_path) as r:
            gguf2 = r.parse()
            check("tensor count preserved", len(gguf2.tensors) == len(original_tensors))
            for t in gguf2.tensors:
                data = r.read_tensor_data(gguf2, t)
                if t.name == target_name:
                    check(f"updated tensor correct: {t.name}", data == new_data)
                else:
                    check(f"unchanged tensor correct: {t.name}", data == original_tensors[t.name])

        # ────────────────────────────────────────────────────────────────────
        print("\n\033[1m[7] SHA-256 corruption detection\033[0m")
        # Corrupt one byte in a shard and check that read_shard raises
        some_shard = shard_dir / manifest["shards"]["blk.0.attn_q.weight"]["file"]
        raw = bytearray(some_shard.read_bytes())
        raw[-1] ^= 0xFF   # flip last byte
        some_shard.write_bytes(raw)
        try:
            read_shard(some_shard)
            check("corruption detected", False, "should have raised ValueError")
        except ValueError as e:
            check("corruption detected", True, str(e)[:50])

        # ────────────────────────────────────────────────────────────────────
        print(f"\n{'═'*62}")
        print(f"\033[1;32m  ALL TESTS PASSED\033[0m")
        print(f"{'═'*62}")
        print(f"\n  Workspace: {tmp}")
        print("  (not deleted — inspect files freely)\n")

    except AssertionError as e:
        print(f"\n\033[1;31m  TESTS FAILED: {e}\033[0m\n")
        sys.exit(1)


if __name__ == "__main__":
    run_tests()