"""Database models for AIPM"""
from datetime import datetime, date, timezone, timedelta
from typing import Optional
from sqlalchemy import Column, String, Text, Integer, DateTime, Date, ForeignKey, Boolean, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declared_attr

from aipm.database import Base

# 本地时区 (Asia/Shanghai, UTC+8)
LOCAL_TZ = timezone(timedelta(hours=8))

def local_now() -> datetime:
    """返回当前本地时间 (Asia/Shanghai)"""
    return datetime.now(LOCAL_TZ)


def generate_id(prefix: str) -> str:
    """Generate unique ID with prefix"""
    import uuid
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class TimestampMixin:
    """Mixin for created_at and updated_at timestamps"""
    
    @declared_attr
    def created_at(cls):
        return Column(DateTime, default=local_now, nullable=False)
    
    @declared_attr
    def updated_at(cls):
        return Column(DateTime, default=local_now, onupdate=local_now, nullable=False)


class User(Base):
    """User model"""
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("user"))
    name = Column(String, nullable=False)
    role = Column(String, default="member")  # 'pm' | 'member'
    created_at = Column(DateTime, default=local_now, nullable=False)
    
    # Relationships
    channels = relationship("UserChannel", back_populates="user", cascade="all, delete-orphan")
    projects = relationship("Project", back_populates="pm", foreign_keys="Project.pm_user_id")
    tasks = relationship("Task", back_populates="assignee_user", foreign_keys="Task.assignee")
    progress_updates = relationship("ProgressHistory", back_populates="updated_by_user")


class UserChannel(Base):
    """User channel binding (supports multiple channels)"""
    __tablename__ = "user_channels"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("channel"))
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    channel = Column(String, nullable=False)  # 'wecom' | 'whatsapp' | 'email'
    channel_user_id = Column(String, nullable=False)  # User ID in the channel
    created_at = Column(DateTime, default=local_now, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="channels")
    
    # Unique constraint on (channel, channel_user_id) is handled by database index


class Project(Base, TimestampMixin):
    """Project model"""
    __tablename__ = "projects"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("proj"))
    name = Column(String, nullable=False)
    channel = Column(String, nullable=False)  # 'wecom' | 'whatsapp'
    group_id = Column(String)  # Group ID in the channel
    webhook_url = Column(String)  # Webhook URL for sending messages (e.g. WeCom robot webhook)
    pm_user_id = Column(String, ForeignKey("users.id"))  # Project manager
    background = Column(Text)  # Project background
    objective = Column(Text)  # Project objective
    deadline = Column(Date)  # Project deadline
    status = Column(String, default="active")  # 'active' | 'completed' | 'paused"
    
    # Relationships
    pm = relationship("User", back_populates="projects", foreign_keys=[pm_user_id])
    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    collection_sessions = relationship("ProgressCollectSession", back_populates="project", cascade="all, delete-orphan")


class Task(Base, TimestampMixin):
    """Task model"""
    __tablename__ = "tasks"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("task"))
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text)
    assignee = Column(String, ForeignKey("users.id"))  # User ID
    deadline = Column(Date)
    priority = Column(String, default="medium")  # 'high' | 'medium' | 'low'
    status = Column(String, default="pending")  # 'pending' | 'in_progress' | 'completed' | 'blocked'
    progress = Column(Integer, default=0)  # 0-100
    
    # Relationships
    project = relationship("Project", back_populates="tasks")
    assignee_user = relationship("User", back_populates="tasks", foreign_keys=[assignee])
    progress_history = relationship("ProgressHistory", back_populates="task", cascade="all, delete-orphan")
    collection_details = relationship("ProgressCollectDetail", back_populates="task", cascade="all, delete-orphan")


class Notification(Base, TimestampMixin):
    """Notification queue model"""
    __tablename__ = "notifications"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("notif"))
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    task_id = Column(String, ForeignKey("tasks.id"), nullable=True)
    
    # 通知目标
    channel = Column(String, nullable=False)  # 'wecom' | 'whatsapp' | 'telegram' | 'email'
    target_type = Column(String, nullable=False)  # 'group' | 'user'
    target_id = Column(String, nullable=False)  # 群ID 或 用户ID
    
    # 发送配置（用于 @ 人等特殊功能）
    webhook_url = Column(String)  # 群机器人 webhook URL（用于发送 text 消息 + mentioned_list）
    mention_userid = Column(String)  # 需要通知的用户 userid（用于 @ 人）
    
    # 通知内容
    message = Column(Text, nullable=False)
    priority = Column(String, default="normal")  # 'high' | 'normal' | 'low'
    notification_type = Column(String, nullable=False)  # 'overdue_warning' | 'progress_collect' | 'weekly_report' | 'reminder'
    
    # 状态
    status = Column(String, default="pending")  # 'pending' | 'sent' | 'failed'
    sent_at = Column(DateTime)
    error_message = Column(Text)
    
    # 关联
    project = relationship("Project", backref="notifications")
    task = relationship("Task", backref="notifications")


class ProgressHistory(Base):
    """Progress history model"""
    __tablename__ = "progress_history"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("prog"))
    task_id = Column(String, ForeignKey("tasks.id"), nullable=False)
    progress = Column(Integer, nullable=False)  # 0-100
    note = Column(Text)
    updated_by = Column(String, ForeignKey("users.id"))  # User who updated
    feedback_method = Column(String)  # 'chat' | 'form'
    created_at = Column(DateTime, default=local_now, nullable=False)
    
    # Relationships
    task = relationship("Task", back_populates="progress_history")
    updated_by_user = relationship("User", back_populates="progress_updates")


class ProgressCollectSession(Base):
    """Progress collection session model"""
    __tablename__ = "progress_collect_sessions"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("session"))
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    started_at = Column(DateTime, default=local_now, nullable=False)
    status = Column(String, default="active")  # 'active' | 'completed' | 'escalated'
    tasks_count = Column(Integer, default=0)
    responded_count = Column(Integer, default=0)
    reminder_count = Column(Integer, default=0)
    last_reminder_at = Column(DateTime)
    next_reminder_at = Column(DateTime)
    escalated_at = Column(DateTime)
    created_at = Column(DateTime, default=local_now, nullable=False)
    
    # Relationships
    project = relationship("Project", back_populates="collection_sessions")
    details = relationship("ProgressCollectDetail", back_populates="session", cascade="all, delete-orphan")


class ProgressCollectDetail(Base):
    """Progress collection detail model"""
    __tablename__ = "progress_collect_details"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("detail"))
    session_id = Column(String, ForeignKey("progress_collect_sessions.id"), nullable=False)
    task_id = Column(String, ForeignKey("tasks.id"), nullable=False)
    assignee = Column(String)  # User ID
    status = Column(String, default="pending")  # 'pending' | 'responded' | 'escalated'
    feedback_method = Column(String)  # 'chat' | 'form'
    responded_at = Column(DateTime)
    created_at = Column(DateTime, default=local_now, nullable=False)
    
    # Relationships
    session = relationship("ProgressCollectSession", back_populates="details")
    task = relationship("Task", back_populates="collection_details")


class ScheduledTaskConfig(Base, TimestampMixin):
    """Scheduled task configuration model"""
    __tablename__ = "scheduled_task_configs"
    
    id = Column(String, primary_key=True, default=lambda: generate_id("config"))
    task_id = Column(String, unique=True, nullable=False)  # 'daily_check' | 'progress_collect' | 'weekly_report'
    name = Column(String, nullable=False)
    trigger_time = Column(String, nullable=False)  # HH:MM format
    trigger_days = Column(JSON, nullable=False)  # List of days: ["monday", "tuesday", ...]
    timezone = Column(String, default="Asia/Shanghai")
    enabled = Column(Boolean, default=True)
    params = Column(JSON)  # Task-specific parameters