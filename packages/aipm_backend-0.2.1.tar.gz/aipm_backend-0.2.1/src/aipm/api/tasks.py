"""Task management API endpoints"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from aipm.database import get_db
from aipm.schemas import (
    TaskCreate, TaskUpdate, ProgressUpdate, TaskResponse,
    ProgressHistoryResponse, SuccessResponse
)
from aipm.services import TaskService, CollectionService

router = APIRouter()


@router.post("", response_model=dict, status_code=201)
def add_task(
    task_data: TaskCreate,
    db: Session = Depends(get_db)
):
    """Add a new task"""
    service = TaskService(db)
    task_id = service.add_task(task_data)
    return {"task_id": task_id}


@router.get("", response_model=list[TaskResponse])
def get_tasks(
    project_id: Optional[str] = Query(None, description="Filter by project ID"),
    status: Optional[str] = Query(None, description="Filter by status"),
    assignee: Optional[str] = Query(None, description="Filter by assignee"),
    db: Session = Depends(get_db)
):
    """Get tasks with optional filters"""
    service = TaskService(db)
    tasks = service.get_tasks(project_id=project_id, status=status, assignee=assignee)
    return tasks


@router.get("/{task_id}", response_model=TaskResponse)
def get_task(
    task_id: str,
    db: Session = Depends(get_db)
):
    """Get task by ID"""
    service = TaskService(db)
    task = service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@router.patch("/{task_id}/progress", response_model=SuccessResponse)
def update_progress(
    task_id: str,
    progress_data: ProgressUpdate,
    db: Session = Depends(get_db)
):
    """Update task progress"""
    task_service = TaskService(db)
    collection_service = CollectionService(db)
    
    # Update progress
    success = task_service.update_progress(task_id, progress_data)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Mark as responded in active collection if exists
    collection_service.mark_responded(task_id, progress_data.feedback_method)
    
    return SuccessResponse(success=True, message="Progress updated successfully")


@router.patch("/{task_id}", response_model=SuccessResponse)
def update_task(
    task_id: str,
    task_data: TaskUpdate,
    db: Session = Depends(get_db)
):
    """Update task"""
    service = TaskService(db)
    success = service.update_task(task_id, task_data)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return SuccessResponse(success=True, message="Task updated successfully")


@router.delete("/{task_id}", response_model=SuccessResponse)
def delete_task(
    task_id: str,
    db: Session = Depends(get_db)
):
    """Delete task"""
    service = TaskService(db)
    success = service.delete_task(task_id)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return SuccessResponse(success=True, message="Task deleted successfully")


@router.get("/{task_id}/history", response_model=list[ProgressHistoryResponse])
def get_progress_history(
    task_id: str,
    db: Session = Depends(get_db)
):
    """Get progress history for a task"""
    service = TaskService(db)
    # Verify task exists
    task = service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    history = service.get_progress_history(task_id)
    return history