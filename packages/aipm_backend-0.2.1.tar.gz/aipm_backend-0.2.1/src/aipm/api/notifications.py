"""Notification queue API endpoints - for Agent to fetch pending notifications"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
import requests

from aipm.database import get_db
from aipm.schemas import (
    NotificationCreate, NotificationPendingResponse,
    NotificationListResponse, SuccessResponse
)
from aipm.services.notification_service import NotificationService
from aipm.services.user_service import UserService
from aipm.services.project_service import ProjectService

router = APIRouter()


# ========== Manual notification interface ==========

class ManualNotificationRequest(BaseModel):
    """Manual notification request"""
    target_name: str = ""               # Target user name (optional, for @ mention)
    project_id: str                     # Project ID (for webhook_url)
    message: str                        # Message content
    channel: str = "wecom"              # Channel (default: wecom)


def build_message(target_name: str, message: str) -> str:
    """Build message with To field"""
    if target_name:
        if target_name.upper() in ['ALL', '所有人', '全体']:
            return f"To: ALL\n内容: {message}"
        else:
            return f"To: {target_name}\n内容: {message}"
    return message


@router.post("/notify")
def send_notification_manually(
    data: ManualNotificationRequest,
    db: Session = Depends(get_db)
):
    """Send notification manually (human triggered)
    
    Usage: User says "remind someone", Agent calls this API
    
    Special target_name values:
    - 'ALL' / '所有人' / '全体': Broadcast to all members (@ all)
    
    Difference from /ack:
    - /notify: Create and send new notification (human trigger)
    - /ack: Confirm queue notification delivered (Agent response)
    """
    user_service = UserService(db)
    project_service = ProjectService(db)
    notification_service = NotificationService(db)
    
    # 1. Get target user's userid (optional, only if target_name provided)
    userid = None
    is_broadcast = False
    if data.target_name:
        if data.target_name.upper() in ['ALL', '所有人', '全体']:
            is_broadcast = True
        else:
            userid = user_service.get_channel_user_id(data.target_name, data.channel)
    
    # 2. Get project webhook_url
    project = project_service.get_project(data.project_id)
    if not project:
        return {
            "status": "failed",
            "message": f"Project '{data.project_id}' not found"
        }
    
    webhook_url = project.webhook_url
    
    # 3. Build message
    full_message = build_message(data.target_name, data.message)
    
    # 4. Send notification
    if webhook_url:
        try:
            # Build payload
            payload = {
                "msgtype": "text",
                "text": {
                    "content": full_message
                }
            }
            
            # Add mentioned_list (only for specific users, not for broadcast)
            if userid:
                payload["text"]["mentioned_list"] = [userid]
            
            response = requests.post(
                webhook_url,
                json=payload,
                timeout=10
            )
            result = response.json()
            
            if result.get("errcode") == 0:
                mention_info = "ALL members" if is_broadcast else (data.target_name if userid else "no @ mention")
                return {
                    "status": "success",
                    "message": f"Notification sent to group (@ {mention_info})",
                    "details": {
                        "method": "webhook",
                        "target_name": data.target_name,
                        "userid": userid,
                        "is_broadcast": is_broadcast,
                        "mentioned": is_broadcast or userid is not None,
                        "errcode": result.get("errcode")
                    }
                }
            else:
                # Webhook failed, write to queue
                notification = notification_service.create_notification(
                    channel=data.channel,
                    target_type="group",
                    target_id=project.group_id,
                    message=full_message,
                    notification_type="manual",
                    mention_userid="all" if is_broadcast else userid,
                    project_id=data.project_id,
                    priority="high"
                )
                return {
                    "status": "partial",
                    "message": f"Webhook failed, queued for agent to send",
                    "details": {
                        "method": "queue",
                        "notification_id": notification.id,
                        "webhook_error": result.get("errmsg")
                    }
                }
        except Exception as e:
            # Network error, write to queue
            notification = notification_service.create_notification(
                channel=data.channel,
                target_type="group",
                target_id=project.group_id,
                message=full_message,
                notification_type="manual",
                mention_userid="all" if is_broadcast else userid,
                project_id=data.project_id,
                priority="high"
            )
            return {
                "status": "partial",
                "message": f"Webhook error, queued for agent",
                "details": {
                    "method": "queue",
                    "notification_id": notification.id,
                    "error": str(e)
                }
            }
    else:
        # No webhook, write to queue
        notification = notification_service.create_notification(
            channel=data.channel,
            target_type="group",
            target_id=project.group_id,
            message=full_message,
            notification_type="manual",
            mention_userid="all" if is_broadcast else userid,
            project_id=data.project_id,
            priority="high"
        )
        mention_info = "ALL members" if is_broadcast else (data.target_name if userid else "group")
        return {
            "status": "success",
            "message": f"Notification queued for agent to send to {mention_info}",
            "details": {
                "method": "queue",
                "notification_id": notification.id,
                "target_name": data.target_name,
                "userid": userid,
                "is_broadcast": is_broadcast
            }
        }


# ========== Notification queue interfaces ==========

@router.get("/pending", response_model=NotificationListResponse)
def get_pending_notifications(
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """Get pending notifications (Agent calls this to fetch)
    
    Returns notifications sorted by priority (high first) and creation time (oldest first)
    """
    service = NotificationService(db)
    notifications = service.get_pending_notifications(limit)
    
    return NotificationListResponse(
        count=len(notifications),
        notifications=[NotificationPendingResponse.model_validate(n) for n in notifications]
    )


@router.post("/{notification_id}/ack", response_model=SuccessResponse)
def acknowledge_notification_delivered(
    notification_id: str,
    db: Session = Depends(get_db)
):
    """Acknowledge notification delivered (Agent response)
    
    Usage: Agent calls this after successfully sending notification
    Effect: Directly delete notification, no need to keep sent status
    
    Difference from /notify:
    - /notify: Create and send new notification (human trigger)
    - /ack: Confirm queue notification delivered (Agent response)
    """
    service = NotificationService(db)
    success = service.delete_notification(notification_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Notification not found")
    
    return SuccessResponse(success=True, message="Notification delivered and deleted")


@router.post("/{notification_id}/failed", response_model=SuccessResponse)
def mark_notification_failed(
    notification_id: str,
    error_message: str = "",
    db: Session = Depends(get_db)
):
    """Mark notification as failed (Agent calls this if delivery failed)"""
    service = NotificationService(db)
    success = service.mark_failed(notification_id, error_message)
    
    if not success:
        raise HTTPException(status_code=404, detail="Notification not found")
    
    return SuccessResponse(success=True, message="Notification marked as failed")


@router.delete("/cleanup", response_model=SuccessResponse)
def cleanup_stale_notifications(
    hours: int = 24,
    db: Session = Depends(get_db)
):
    """Cleanup stale pending notifications (over specified hours still pending)
    
    Usage: Cleanup notifications that may have failed but Agent didn't report
    Params: hours=24 means cleanup pending notifications over 24 hours
    """
    service = NotificationService(db)
    deleted_count = service.cleanup_stale_notifications(hours)
    
    return SuccessResponse(success=True, message=f"Deleted {deleted_count} stale pending notifications")


@router.post("/", response_model=NotificationPendingResponse)
def create_notification(
    data: NotificationCreate,
    db: Session = Depends(get_db)
):
    """Create a notification (internal use, called by scheduler)"""
    service = NotificationService(db)
    notification = service.create_notification(
        channel=data.channel,
        target_type=data.target_type,
        target_id=data.target_id,
        message=data.message,
        notification_type=data.notification_type,
        project_id=data.project_id,
        task_id=data.task_id,
        priority=data.priority
    )
    
    return NotificationPendingResponse.model_validate(notification)


@router.get("/stats")
def get_notification_stats(
    db: Session = Depends(get_db)
):
    """Get notification queue statistics"""
    service = NotificationService(db)
    return service.get_stats()