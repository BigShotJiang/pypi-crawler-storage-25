"""Progress collection API endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from aipm.database import get_db
from aipm.schemas import (
    CollectionStartRequest, CollectionStartResponse,
    CollectionCheckRequest, CollectionStatusResponse,
    ChatFeedbackRequest, FormFeedbackRequest,
    SuccessResponse
)
from aipm.services import CollectionService, TaskService

router = APIRouter()


@router.post("/start", response_model=CollectionStartResponse)
def start_collection(
    request: CollectionStartRequest,
    db: Session = Depends(get_db)
):
    """Start a progress collection session"""
    service = CollectionService(db)
    try:
        result = service.start_collection(request.project_id)
        return CollectionStartResponse(
            session_id=result["session_id"],
            tasks_count=result["tasks_count"],
            notifications=result["notifications"]
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/check", response_model=dict)
def check_collection(
    request: CollectionCheckRequest,
    db: Session = Depends(get_db)
):
    """Check collection status and send reminders if needed"""
    service = CollectionService(db)
    try:
        result = service.check_collection(request.session_id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/status/{session_id}", response_model=CollectionStatusResponse)
def get_collection_status(
    session_id: str,
    db: Session = Depends(get_db)
):
    """Get collection session status"""
    service = CollectionService(db)
    try:
        status = service.get_collection_status(session_id)
        return CollectionStatusResponse(**status)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/feedback/chat", response_model=SuccessResponse)
def chat_feedback(
    request: ChatFeedbackRequest,
    db: Session = Depends(get_db)
):
    """Submit progress feedback via chat"""
    task_service = TaskService(db)
    collection_service = CollectionService(db)
    
    # Create progress update data
    from aipm.schemas import ProgressUpdate
    progress_data = ProgressUpdate(
        progress=request.progress,
        note=request.note,
        user_id=request.user_id,
        feedback_method="chat"
    )
    
    # Update progress
    success = task_service.update_progress(request.task_id, progress_data)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Mark as responded in active collection
    collection_service.mark_responded(request.task_id, "chat")
    
    return SuccessResponse(success=True, message="Feedback submitted successfully")


@router.post("/feedback/form/{session_id}/{task_id}", response_model=SuccessResponse)
def form_feedback(
    session_id: str,
    task_id: str,
    request: FormFeedbackRequest,
    db: Session = Depends(get_db)
):
    """Submit progress feedback via form"""
    task_service = TaskService(db)
    collection_service = CollectionService(db)
    
    # Create progress update data
    from aipm.schemas import ProgressUpdate
    progress_data = ProgressUpdate(
        progress=request.progress,
        note=request.note,
        user_id=request.user_id,
        feedback_method="form"
    )
    
    # Update progress
    success = task_service.update_progress(task_id, progress_data)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Mark as responded in active collection
    collection_service.mark_responded(task_id, "form")
    
    return SuccessResponse(success=True, message="Feedback submitted successfully")