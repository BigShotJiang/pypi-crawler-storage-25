"""API routes for AIPM"""
from fastapi import APIRouter
from aipm.api.projects import router as projects_router
from aipm.api.tasks import router as tasks_router
from aipm.api.collection import router as collection_router
from aipm.api.reports import router as reports_router
from aipm.api.scheduled import router as scheduled_router
from aipm.api.notifications import router as notifications_router
from aipm.api.users import router as users_router

api_router = APIRouter()

api_router.include_router(projects_router, prefix="/projects", tags=["Projects"])
api_router.include_router(tasks_router, prefix="/tasks", tags=["Tasks"])
api_router.include_router(collection_router, prefix="/collection", tags=["Collection"])
api_router.include_router(reports_router, prefix="/reports", tags=["Reports"])
api_router.include_router(scheduled_router, prefix="/scheduled", tags=["Scheduled"])
api_router.include_router(notifications_router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(users_router, prefix="/users", tags=["Users"])