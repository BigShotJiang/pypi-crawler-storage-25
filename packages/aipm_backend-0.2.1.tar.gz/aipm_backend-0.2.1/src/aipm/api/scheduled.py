"""Scheduled task API endpoints"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import requests

from aipm.database import get_db
from aipm.schemas import (
    ScheduledTaskConfigResponse, ScheduledTaskConfigUpdate,
    ScheduledTaskResult, SuccessResponse
)
from aipm.services import TaskService, ProjectService, ReportService, CollectionService, NotificationService, UserService
from aipm.models import ScheduledTaskConfig, Project
from aipm.config import settings

router = APIRouter()


def send_via_webhook(webhook_url: str, message: str, mention_userid: str) -> dict:
    """直接通过 webhook 发送消息（支持 @ 人）
    
    Args:
        webhook_url: 企业微信群机器人 webhook URL
        message: 消息内容（已包含真实名字，不含 <@xxx> 标记）
        mention_userid: 要 @ 的用户 userid
        
    Returns:
        发送结果
    """
    # 消息内容直接发送，@ 功能通过 mentioned_list 实现
    try:
        response = requests.post(
            webhook_url,
            json={
                "msgtype": "text",
                "text": {
                    "content": message,  # 直接发送消息内容
                    "mentioned_list": [mention_userid]  # 通过 mentioned_list @ 人
                }
            },
            timeout=10
        )
        
        result = response.json()
        if result.get("errcode") == 0:
            return {"status": "sent"}
        else:
            return {"status": "failed", "error": result.get("errmsg", "Unknown error")}
            
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.post("/check-overdue", response_model=ScheduledTaskResult)
def check_overdue(
    days_threshold: int = 3,
    progress_threshold: int = 70,
    db: Session = Depends(get_db)
):
    """Execute overdue task check
    
    逻辑：
    - 有 webhook_url → 直接发送（支持 @）
    - 无 webhook_url → 写入通知队列
    """
    task_service = TaskService(db)
    notification_service = NotificationService(db)
    project_service = ProjectService(db)
    user_service = UserService(db)
    
    overdue_tasks = task_service.get_overdue_tasks(
        days_threshold=days_threshold,
        progress_threshold=progress_threshold
    )
    
    if not overdue_tasks:
        return ScheduledTaskResult(
            status="success",
            message="No overdue tasks found",
            details={"checked_count": 0}
        )
    
    notifications_created = []
    notifications_sent = []
    
    for task_info in overdue_tasks:
        project = project_service.get_project(task_info["project_id"])
        assignee_name = task_info.get('assignee', '未指定') or '未指定'
        
        # 获取企业微信 userid 用于 @ 人
        wecom_userid = user_service.get_channel_user_id(assignee_name, 'wecom')
        mention_str = f"<@{wecom_userid}>" if wecom_userid else assignee_name
        
        if task_info["days_remaining"] <= 1:
            # Critical warning - notify group
            # 显示用真实名字，@ 用 userid
            display_name = assignee_name
            message = f"⚠️ 【{display_name}】任务即将逾期！\n\n📌 任务：{task_info['task_title']}\n👤 责任人：{display_name}\n📁 项目：{task_info['project_name']}\n⏰ 剩余：{task_info['days_remaining']}天\n📊 进度：{task_info['progress']}%\n\n🔥 请尽快处理！"
            
            # 如果项目有 webhook_url + 有 userid → 直接发送
            if project.webhook_url and wecom_userid:
                result = send_via_webhook(project.webhook_url, message, wecom_userid)
                if result["status"] == "sent":
                    notifications_sent.append({
                        "target": "group",
                        "channel": project.channel,
                        "mention": wecom_userid
                    })
                else:
                    # 发送失败，写入队列
                    notification_service.create_notification(
                        channel=project.channel,
                        target_type="group",
                        target_id=project.group_id,
                        message=message,
                        notification_type="overdue_warning",
                        project_id=task_info["project_id"],
                        task_id=task_info["task_id"],
                        priority="high"
                    )
                    notifications_created.append({
                        "target": "group",
                        "channel": project.channel,
                        "priority": "high",
                        "reason": "webhook_failed"
                    })
            else:
                # 没有 webhook 或没有 userid → 写入通知队列
                notification_service.create_notification(
                    channel=project.channel,
                    target_type="group",
                    target_id=project.group_id,
                    message=message,
                    notification_type="overdue_warning",
                    project_id=task_info["project_id"],
                    task_id=task_info["task_id"],
                    priority="high"
                )
                notifications_created.append({
                    "target": "group",
                    "channel": project.channel,
                    "priority": "high",
                    "reason": "no_webhook"
                })
        else:
            # Regular warning - notify assignee (user)
            # 显示用真实名字，@ 用 userid
            display_name = assignee_name
            message = f"⏰ 【{display_name}】任务预警\n\n📌 任务：{task_info['task_title']}\n👤 责任人：{display_name}\n📁 项目：{task_info['project_name']}\n⏰ 剩余：{task_info['days_remaining']}天\n📊 进度：{task_info['progress']}%\n\n💡 请注意进度！"
            
            # 用户通知写入队列
            notification_service.create_notification(
                channel=project.channel,
                target_type="user",
                target_id=task_info["assignee"],
                message=message,
                notification_type="overdue_warning",
                project_id=task_info["project_id"],
                task_id=task_info["task_id"],
                priority="normal"
            )
            notifications_created.append({
                "target": "user",
                "channel": project.channel,
                "priority": "normal"
            })
    
    return ScheduledTaskResult(
        status="success",
        message=f"Found {len(overdue_tasks)} overdue tasks: sent {len(notifications_sent)} via webhook, created {len(notifications_created)} in queue",
        details={
            "checked_count": len(overdue_tasks),
            "notifications_sent": notifications_sent,
            "notifications_created": notifications_created
        }
    )


@router.post("/weekly-report", response_model=ScheduledTaskResult)
def generate_weekly_report(
    db: Session = Depends(get_db)
):
    """Generate weekly report for all active projects"""
    project_service = ProjectService(db)
    report_service = ReportService(db)
    
    projects = project_service.get_projects(status="active")
    
    if not projects:
        return ScheduledTaskResult(
            status="success",
            message="No active projects found",
            details={"projects_count": 0}
        )
    
    notifications = []
    for project in projects:
        report_content = report_service.generate_report(project.id, "weekly")
        notifications.append({
            "target": "group",
            "channel": project.channel,
            "group_id": project.group_id,
            "message": report_content
        })
    
    return ScheduledTaskResult(
        status="success",
        message=f"Generated weekly reports for {len(projects)} projects",
        details={
            "projects_count": len(projects),
            "notifications": notifications
        }
    )


@router.post("/collect-progress", response_model=ScheduledTaskResult)
def collect_progress(
    db: Session = Depends(get_db)
):
    """Start progress collection for all active projects"""
    project_service = ProjectService(db)
    collection_service = CollectionService(db)
    
    projects = project_service.get_projects(status="active")
    
    if not projects:
        return ScheduledTaskResult(
            status="success",
            message="No active projects found",
            details={"projects_count": 0}
        )
    
    total_notifications = 0
    for project in projects:
        result = collection_service.start_collection(project.id)
        total_notifications += result["tasks_count"]
    
    return ScheduledTaskResult(
        status="success",
        message=f"Started progress collection for {len(projects)} projects",
        details={
            "projects_count": len(projects),
            "total_tasks": total_notifications
        }
    )


@router.get("/config", response_model=list[ScheduledTaskConfigResponse])
def get_scheduled_configs(
    db: Session = Depends(get_db)
):
    """Get all scheduled task configurations"""
    configs = db.query(ScheduledTaskConfig).all()
    return configs


@router.patch("/config/{task_id}", response_model=SuccessResponse)
def update_scheduled_config(
    task_id: str,
    config_data: ScheduledTaskConfigUpdate,
    db: Session = Depends(get_db)
):
    """Update scheduled task configuration"""
    config = db.query(ScheduledTaskConfig).filter(
        ScheduledTaskConfig.task_id == task_id
    ).first()
    
    if not config:
        raise HTTPException(status_code=404, detail="Scheduled task config not found")
    
    update_data = config_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(config, key, value)
    
    db.commit()
    return SuccessResponse(success=True, message="Scheduled task config updated successfully")