"""User management API endpoints"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from aipm.database import get_db
from aipm.schemas import (
    UserCreate, UserResponse, UserChannelCreate, UserChannelResponse,
    SuccessResponse
)
from aipm.services.user_service import UserService

router = APIRouter()


@router.post("", response_model=dict, status_code=201)
def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db)
):
    """Create a new user"""
    service = UserService(db)
    user_id = service.create_user(user_data)
    return {"user_id": user_id}


@router.get("/{user_id}", response_model=UserResponse)
def get_user(
    user_id: str,
    db: Session = Depends(get_db)
):
    """Get user by ID"""
    service = UserService(db)
    user = service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.get("", response_model=list[UserResponse])
def get_users(
    role: Optional[str] = Query(None, description="Filter by role"),
    db: Session = Depends(get_db)
):
    """Get all users, optionally filtered by role"""
    service = UserService(db)
    users = service.get_users(role=role)
    return users


@router.post("/channels", response_model=dict, status_code=201)
def add_user_channel(
    channel_data: UserChannelCreate,
    db: Session = Depends(get_db)
):
    """Add user channel binding"""
    service = UserService(db)
    # Verify user exists
    user = service.get_user(channel_data.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    channel_id = service.add_user_channel(channel_data)
    return {"channel_id": channel_id}


@router.get("/{user_id}/channels", response_model=list[UserChannelResponse])
def get_user_channels(
    user_id: str,
    db: Session = Depends(get_db)
):
    """Get user's channel bindings"""
    service = UserService(db)
    # Verify user exists
    user = service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    channels = service.get_user_channels(user_id)
    return channels