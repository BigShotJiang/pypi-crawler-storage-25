"""Report generation API endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from aipm.database import get_db
from aipm.schemas import ReportGenerateRequest, ReportGenerateResponse
from aipm.services import TaskService, ReportService

router = APIRouter()


@router.post("", response_model=ReportGenerateResponse)
def generate_report(
    request: ReportGenerateRequest,
    db: Session = Depends(get_db)
):
    """Generate project report"""
    service = ReportService(db)
    try:
        report_content = service.generate_report(request.project_id, request.report_type)
        return ReportGenerateResponse(report_content=report_content)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/overdue", response_model=list[dict])
def get_overdue_tasks(
    days_threshold: int = 3,
    progress_threshold: int = 70,
    db: Session = Depends(get_db)
):
    """Get overdue/warning tasks"""
    service = TaskService(db)
    overdue_tasks = service.get_overdue_tasks(
        days_threshold=days_threshold,
        progress_threshold=progress_threshold
    )
    return overdue_tasks