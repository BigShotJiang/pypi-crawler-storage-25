"""Project management API endpoints"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from aipm.database import get_db
from aipm.schemas import (
    ProjectCreate, ProjectUpdate, ProjectResponse, SuccessResponse
)
from aipm.services import ProjectService

router = APIRouter()


@router.post("", response_model=dict, status_code=201)
def create_project(
    project_data: ProjectCreate,
    db: Session = Depends(get_db)
):
    """Create a new project"""
    service = ProjectService(db)
    project_id = service.create_project(project_data)
    return {"project_id": project_id}


@router.get("/{project_id}", response_model=ProjectResponse)
def get_project(
    project_id: str,
    db: Session = Depends(get_db)
):
    """Get project by ID"""
    service = ProjectService(db)
    project = service.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.get("", response_model=list[ProjectResponse])
def get_projects(
    status: Optional[str] = Query(None, description="Filter by status"),
    db: Session = Depends(get_db)
):
    """Get all projects, optionally filtered by status"""
    service = ProjectService(db)
    projects = service.get_projects(status=status)
    return projects


@router.patch("/{project_id}", response_model=SuccessResponse)
def update_project(
    project_id: str,
    project_data: ProjectUpdate,
    db: Session = Depends(get_db)
):
    """Update project"""
    service = ProjectService(db)
    success = service.update_project(project_id, project_data)
    if not success:
        raise HTTPException(status_code=404, detail="Project not found")
    return SuccessResponse(success=True, message="Project updated successfully")


@router.delete("/{project_id}", response_model=SuccessResponse)
def delete_project(
    project_id: str,
    db: Session = Depends(get_db)
):
    """Delete project"""
    service = ProjectService(db)
    success = service.delete_project(project_id)
    if not success:
        raise HTTPException(status_code=404, detail="Project not found")
    return SuccessResponse(success=True, message="Project deleted successfully")