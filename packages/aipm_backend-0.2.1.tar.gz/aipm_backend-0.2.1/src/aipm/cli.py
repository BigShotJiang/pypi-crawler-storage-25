"""CLI entry point for AIPM"""
import argparse
import sys
from typing import Optional

import uvicorn


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="AIPM - AI Project Manager Backend",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aipm                          Start server on default port 8000
  aipm --port 9000              Start server on port 9000
  aipm --host 0.0.0.0           Start server accessible from network
  aipm --db sqlite:///custom.db Use custom SQLite database
  aipm --no-scheduler           Start without scheduler
        """
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to run the server on (default: 8000)"
    )
    
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind the server to (default: 127.0.0.1)"
    )
    
    parser.add_argument(
        "--db",
        type=str,
        default=None,
        help="Database URL (default: sqlite:///./aipm.db)"
    )
    
    parser.add_argument(
        "--no-scheduler",
        action="store_true",
        help="Disable built-in scheduler"
    )
    
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development"
    )
    
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of worker processes (default: 1)"
    )
    
    args = parser.parse_args()
    
    # Set environment variables if provided
    if args.db:
        import os
        os.environ["AIPM_DATABASE__DATABASE_URL"] = args.db
    
    if args.no_scheduler:
        import os
        os.environ["AIPM_SCHEDULER__SCHEDULER_ENABLED"] = "false"
    
    # Print startup info
    print(f"""
╔════════════════════════════════════════╗
║     AIPM - AI Project Manager         ║
║     Version: 0.1.0                    ║
╚════════════════════════════════════════╝

Server starting on http://{args.host}:{args.port}
API docs: http://{args.host}:{args.port}/docs
Database: {args.db or 'sqlite:///./aipm.db'}
Scheduler: {'disabled' if args.no_scheduler else 'enabled'}

Press Ctrl+C to stop the server
""")
    
    # Run uvicorn
    uvicorn.run(
        "aipm.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers if not args.reload else 1
    )


if __name__ == "__main__":
    main()