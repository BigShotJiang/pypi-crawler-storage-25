"""Scheduler for scheduled tasks using APScheduler"""
from datetime import datetime
from typing import Optional
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.orm import Session

from aipm.config import settings
from aipm.database import SessionLocal, init_db
from aipm.models import ScheduledTaskConfig
from aipm.services import TaskService, ProjectService, ReportService, CollectionService, NotificationService, UserService
from aipm.models import Project


class AipmScheduler:
    """Scheduler for AIPM scheduled tasks"""
    
    def __init__(self):
        self.scheduler = BackgroundScheduler(timezone=settings.scheduler.scheduler_timezone)
        self._initialized = False
    
    def init_default_configs(self, db: Session):
        """Initialize default scheduled task configs in database"""
        # Check if configs exist
        existing_configs = db.query(ScheduledTaskConfig).count()
        if existing_configs > 0:
            return
        
        # Create default configs
        default_configs = [
            ScheduledTaskConfig(
                task_id="daily_check",
                name="每日预警检查",
                trigger_time="09:00",
                trigger_days=["monday", "tuesday", "wednesday", "thursday", "friday"],
                timezone="Asia/Shanghai",
                enabled=True,
                params={"days_threshold": 3, "progress_threshold": 70}
            ),
            ScheduledTaskConfig(
                task_id="progress_collect",
                name="进展收集",
                trigger_time="09:00",
                trigger_days=["wednesday"],
                timezone="Asia/Shanghai",
                enabled=True,
                params={"max_reminders": 3}
            ),
            ScheduledTaskConfig(
                task_id="weekly_report",
                name="周报生成",
                trigger_time="17:00",
                trigger_days=["friday"],
                timezone="Asia/Shanghai",
                enabled=True,
                params={}
            )
        ]
        
        for config in default_configs:
            db.add(config)
        
        db.commit()
    
    def load_configs_from_db(self, db: Session):
        """Load scheduled task configs from database"""
        configs = db.query(ScheduledTaskConfig).filter(
            ScheduledTaskConfig.enabled == True
        ).all()
        
        for config in configs:
            self.add_job_from_config(config)
    
    def add_job_from_config(self, config: ScheduledTaskConfig):
        """Add a scheduled job from config"""
        # Parse trigger time
        hour, minute = config.trigger_time.split(":")
        hour = int(hour)
        minute = int(minute)
        
        WEEKDAY_MAP = {
            "monday": "mon",
            "tuesday": "tue",
            "wednesday": "wed",
            "thursday": "thu",
            "friday": "fri",
            "saturday": "sat",
            "sunday": "sun"
        }
        
        day_of_week = config.trigger_days
        if isinstance(day_of_week, list):
            day_of_week = ",".join([WEEKDAY_MAP.get(d.lower(), d) for d in day_of_week])
        elif isinstance(day_of_week, str):
            day_of_week = WEEKDAY_MAP.get(day_of_week.lower(), day_of_week)
            
        trigger = CronTrigger(
            day_of_week=day_of_week,
            hour=hour,
            minute=minute,
            timezone=config.timezone
        )
        
        # Map task_id to job function
        job_func_map = {
            "daily_check": self._daily_check_job,
            "progress_collect": self._progress_collect_job,
            "weekly_report": self._weekly_report_job
        }
        
        job_func = job_func_map.get(config.task_id)
        if job_func:
            # Remove existing job if exists
            try:
                self.scheduler.remove_job(config.task_id)
            except:
                pass
            
            # Add new job
            self.scheduler.add_job(
                job_func,
                trigger=trigger,
                id=config.task_id,
                args=[config.params],
                name=config.name
            )
    
    def _send_via_webhook(self, webhook_url: str, message: str, mention_userid: str) -> dict:
        """直接通过 webhook 发送消息（支持 @ 人）
        
        Args:
            webhook_url: 企业微信群机器人 webhook URL
            message: 消息内容（已包含真实名字，不含 <@xxx> 标记）
            mention_userid: 要 @ 的用户 userid
            
        Returns:
            发送结果
        """
        # 消息内容直接发送，@ 功能通过 mentioned_list 实现
        try:
            response = requests.post(
                webhook_url,
                json={
                    "msgtype": "text",
                    "text": {
                        "content": message,  # 直接发送消息内容
                        "mentioned_list": [mention_userid]  # 通过 mentioned_list @ 人
                    }
                },
                timeout=10
            )
            
            result = response.json()
            if result.get("errcode") == 0:
                return {"status": "sent", "msgid": result.get("msgid")}
            else:
                return {"status": "failed", "error": result.get("errmsg", "Unknown error")}
                
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def _daily_check_job(self, params: dict):
        """Execute daily check job
        
        逻辑：
        - 有 webhook_url → 直接发送（支持 @）
        - 无 webhook_url → 写入通知队列（等待 skill 发送）
        """
        db = SessionLocal()
        try:
            task_service = TaskService(db)
            notification_service = NotificationService(db)
            project_service = ProjectService(db)
            user_service = UserService(db)
            
            days_threshold = params.get("days_threshold", 3)
            progress_threshold = params.get("progress_threshold", 70)
            
            overdue_tasks = task_service.get_overdue_tasks(
                days_threshold=days_threshold,
                progress_threshold=progress_threshold
            )
            
            print(f"[{datetime.now()}] Daily check: found {len(overdue_tasks)} overdue tasks")
            
            notifications_created = 0
            notifications_sent = 0
            
            for task_info in overdue_tasks:
                project = project_service.get_project(task_info["project_id"])
                assignee_name = task_info.get('assignee', '未指定') or '未指定'
                
                # 获取企业微信 userid 用于 @ 人
                wecom_userid = user_service.get_channel_user_id(assignee_name, 'wecom')
                mention_str = f"<@{wecom_userid}>" if wecom_userid else assignee_name
                
                if task_info["days_remaining"] <= 1:
                    # Critical warning - notify group
                    # 显示用真实名字，@ 用 userid
                    display_name = assignee_name  # 显示名字：黄明通
                    message = f"⚠️ 【{display_name}】任务即将逾期！\n\n📌 任务：{task_info['task_title']}\n👤 责任人：{display_name}\n📁 项目：{task_info['project_name']}\n⏰ 剩余：{task_info['days_remaining']}天\n📊 进度：{task_info['progress']}%\n\n🔥 请尽快处理！"
                    
                    # 如果项目有 webhook_url + 有 userid → 直接发送
                    if project.webhook_url and wecom_userid:
                        result = self._send_via_webhook(project.webhook_url, message, wecom_userid)
                        if result["status"] == "sent":
                            notifications_sent += 1
                            print(f"[{datetime.now()}] Sent via webhook with mention: {wecom_userid}")
                        else:
                            print(f"[{datetime.now()}] Webhook send failed: {result.get('error')}")
                            # 发送失败，写入队列作为备份
                            notification_service.create_notification(
                                channel=project.channel,
                                target_type="group",
                                target_id=project.group_id,
                                message=message,
                                notification_type="overdue_warning",
                                project_id=task_info["project_id"],
                                task_id=task_info["task_id"],
                                priority="high"
                            )
                            notifications_created += 1
                    else:
                        # 没有 webhook 或没有 userid → 写入通知队列
                        notification_service.create_notification(
                            channel=project.channel,
                            target_type="group",
                            target_id=project.group_id,
                            message=message,
                            notification_type="overdue_warning",
                            project_id=task_info["project_id"],
                            task_id=task_info["task_id"],
                            priority="high"
                        )
                        notifications_created += 1
                        print(f"[{datetime.now()}] Created notification in queue (no webhook/userid)")
                        
                else:
                    # Regular warning - notify assignee (user)
                    # 显示用真实名字，@ 用 userid
                    display_name = assignee_name
                    message = f"⏰ 【{display_name}】任务预警\n\n📌 任务：{task_info['task_title']}\n👤 责任人：{display_name}\n📁 项目：{task_info['project_name']}\n⏰ 剩余：{task_info['days_remaining']}天\n📊 进度：{task_info['progress']}%\n\n💡 请注意进度！"
                    
                    # 用户通知不使用 webhook，写入队列
                    notification_service.create_notification(
                        channel=project.channel,
                        target_type="user",
                        target_id=task_info["assignee"],
                        message=message,
                        notification_type="overdue_warning",
                        project_id=task_info["project_id"],
                        task_id=task_info["task_id"],
                        priority="normal"
                    )
                    notifications_created += 1
                    print(f"[{datetime.now()}] Created user notification in queue")
            
            print(f"[{datetime.now()}] Daily check completed: sent {notifications_sent} via webhook, created {notifications_created} in queue")
            
        finally:
            db.close()
    
    def _progress_collect_job(self, params: dict):
        """Execute progress collection job"""
        db = SessionLocal()
        try:
            project_service = ProjectService(db)
            collection_service = CollectionService(db)
            
            projects = project_service.get_projects(status="active")
            
            for project in projects:
                result = collection_service.start_collection(project.id)
                print(f"[{datetime.now()}] Progress collection for {project.name}: "
                      f"{result['tasks_count']} tasks notified")
            
        finally:
            db.close()
    
    def _weekly_report_job(self, params: dict):
        """Execute weekly report generation job"""
        db = SessionLocal()
        try:
            project_service = ProjectService(db)
            report_service = ReportService(db)
            
            projects = project_service.get_projects(status="active")
            
            for project in projects:
                report_content = report_service.generate_report(project.id, "weekly")
                print(f"[{datetime.now()}] Weekly report generated for {project.name}")
            
        finally:
            db.close()
    
    def start(self):
        """Start the scheduler"""
        if not self._initialized:
            # Initialize database tables
            init_db()
            
            # Initialize default configs
            db = SessionLocal()
            try:
                self.init_default_configs(db)
                self.load_configs_from_db(db)
            finally:
                db.close()
            
            self._initialized = True
        
        if settings.scheduler.scheduler_enabled:
            self.scheduler.start()
            print(f"[{datetime.now()}] Scheduler started")
        else:
            print(f"[{datetime.now()}] Scheduler disabled (scheduler_enabled=False)")
    
    def shutdown(self):
        """Shutdown the scheduler"""
        if self.scheduler.running:
            self.scheduler.shutdown()
            print(f"[{datetime.now()}] Scheduler shutdown")
    
    def reload_jobs(self):
        """Reload jobs from database config"""
        db = SessionLocal()
        try:
            # Remove all existing jobs
            for job in self.scheduler.get_jobs():
                self.scheduler.remove_job(job.id)
            
            # Reload from database
            self.load_configs_from_db(db)
            
            print(f"[{datetime.now()}] Jobs reloaded from database")
        finally:
            db.close()


# Global scheduler instance
scheduler = AipmScheduler()