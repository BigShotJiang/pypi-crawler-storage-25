"""Task management service"""
from typing import List, Optional
from datetime import datetime, date
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from aipm.models import Task, ProgressHistory, ProgressCollectDetail, Project, local_now
from aipm.schemas import TaskCreate, TaskUpdate, ProgressUpdate


class TaskService:
    """Service for task management"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def add_task(self, task_data: TaskCreate) -> str:
        """Add a new task
        
        Args:
            task_data: Task creation data
            
        Returns:
            Task ID
        """
        task = Task(
            project_id=task_data.project_id,
            title=task_data.title,
            description=task_data.description,
            assignee=task_data.assignee,
            deadline=task_data.deadline,
            priority=task_data.priority,
            status="pending",
            progress=0
        )
        self.db.add(task)
        self.db.commit()
        self.db.refresh(task)
        return task.id
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get task by ID
        
        Args:
            task_id: Task ID
            
        Returns:
            Task object or None
        """
        return self.db.query(Task).filter(Task.id == task_id).first()
    
    def get_tasks(
        self,
        project_id: Optional[str] = None,
        status: Optional[str] = None,
        assignee: Optional[str] = None
    ) -> List[Task]:
        """Get tasks with optional filters
        
        Args:
            project_id: Optional project ID filter
            status: Optional status filter
            assignee: Optional assignee filter
            
        Returns:
            List of tasks
        """
        query = self.db.query(Task)
        
        if project_id:
            query = query.filter(Task.project_id == project_id)
        if status:
            query = query.filter(Task.status == status)
        if assignee:
            query = query.filter(Task.assignee == assignee)
        
        query = query.order_by(Task.created_at.desc())
        return query.all()
    
    def update_task(self, task_id: str, task_data: TaskUpdate) -> bool:
        """Update task
        
        Args:
            task_id: Task ID
            task_data: Update data
            
        Returns:
            True if successful, False if task not found
        """
        task = self.get_task(task_id)
        if not task:
            return False
        
        update_data = task_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(task, key, value)
        
        task.updated_at = local_now()
        self.db.commit()
        return True
    
    def update_progress(self, task_id: str, progress_data: ProgressUpdate) -> bool:
        """Update task progress
        
        Args:
            task_id: Task ID
            progress_data: Progress update data
            
        Returns:
            True if successful, False if task not found
        """
        task = self.get_task(task_id)
        if not task:
            return False
        
        # Update task progress
        old_progress = task.progress
        task.progress = progress_data.progress
        
        # Update task status based on progress
        if progress_data.progress == 100:
            task.status = "completed"
        elif progress_data.progress > 0:
            task.status = "in_progress"
        
        task.updated_at = local_now()
        
        # Create progress history
        history = ProgressHistory(
            task_id=task_id,
            progress=progress_data.progress,
            note=progress_data.note,
            updated_by=progress_data.user_id,
            feedback_method=progress_data.feedback_method
        )
        self.db.add(history)
        
        # Mark collection detail as responded if exists
        active_details = self.db.query(ProgressCollectDetail).filter(
            and_(
                ProgressCollectDetail.task_id == task_id,
                ProgressCollectDetail.status == "pending"
            )
        ).all()
        
        for detail in active_details:
            detail.status = "responded"
            detail.responded_at = local_now()
            detail.feedback_method = progress_data.feedback_method
        
        self.db.commit()
        return True
    
    def delete_task(self, task_id: str) -> bool:
        """Delete task
        
        Args:
            task_id: Task ID
            
        Returns:
            True if successful, False if task not found
        """
        task = self.get_task(task_id)
        if not task:
            return False
        
        self.db.delete(task)
        self.db.commit()
        return True
    
    def get_overdue_tasks(
        self,
        days_threshold: int = 3,
        progress_threshold: int = 70
    ) -> List[dict]:
        """Get overdue/warning tasks
        
        Args:
            days_threshold: Days remaining threshold for warning
            progress_threshold: Progress threshold for warning
            
        Returns:
            List of overdue task info dicts
        """
        # Calculate threshold date
        from datetime import timedelta
        threshold_date = date.today() + timedelta(days=days_threshold)
        
        # Query tasks that:
        # 1. Have deadline within threshold_date
        # 2. Progress is below threshold
        # 3. Status is not completed
        tasks = self.db.query(Task).join(Project).filter(
            and_(
                Task.deadline != None,
                Task.deadline <= threshold_date,
                Task.progress < progress_threshold,
                Task.status != "completed"
            )
        ).all()
        
        result = []
        for task in tasks:
            project = task.project
            days_remaining = (task.deadline - date.today()).days if task.deadline else None
            
            result.append({
                "task_id": task.id,
                "task_title": task.title,
                "project_id": project.id,
                "project_name": project.name,
                "assignee": task.assignee,
                "deadline": task.deadline,
                "progress": task.progress,
                "days_remaining": days_remaining,
                "group_id": project.group_id
            })
        
        return result
    
    def get_progress_history(self, task_id: str) -> List[ProgressHistory]:
        """Get progress history for a task
        
        Args:
            task_id: Task ID
            
        Returns:
            List of progress history records
        """
        return self.db.query(ProgressHistory).filter(
            ProgressHistory.task_id == task_id
        ).order_by(ProgressHistory.created_at.desc()).all()