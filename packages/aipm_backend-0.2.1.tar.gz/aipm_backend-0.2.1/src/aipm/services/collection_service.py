"""Progress collection service"""
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_

from aipm.models import (
    Task, ProgressCollectSession, ProgressCollectDetail,
    Project, User, UserChannel, local_now
)
from aipm.schemas import NotificationResponse


class CollectionService:
    """Service for progress collection management"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def start_collection(self, project_id: str) -> Dict[str, Any]:
        """Start a progress collection session
        
        Args:
            project_id: Project ID
            
        Returns:
            Dict with session_id, tasks_count, and notifications
        """
        # Get project
        project = self.db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise ValueError(f"Project {project_id} not found")
        
        # Get all active tasks for the project
        tasks = self.db.query(Task).filter(
            and_(
                Task.project_id == project_id,
                Task.status != "completed"
            )
        ).all()
        
        if not tasks:
            return {
                "session_id": None,
                "tasks_count": 0,
                "notifications": []
            }
        
        # Create collection session
        session = ProgressCollectSession(
            project_id=project_id,
            started_at=local_now(),
            status="active",
            tasks_count=len(tasks),
            responded_count=0,
            reminder_count=0
        )
        self.db.add(session)
        self.db.flush()  # Get session.id
        
        # Create collection details for each task
        notifications = []
        for task in tasks:
            detail = ProgressCollectDetail(
                session_id=session.id,
                task_id=task.id,
                assignee=task.assignee,
                status="pending"
            )
            self.db.add(detail)
            
            # Generate notification for this task
            if task.assignee:
                # Get user's channel info
                user_channel = self.db.query(UserChannel).join(User).filter(
                    User.id == task.assignee
                ).first()
                
                notification = NotificationResponse(
                    target="user",
                    channel=project.channel,
                    user_id=task.assignee,
                    group_id=None,
                    message=f"📋 请更新任务进展\n\n"
                           f"项目：{project.name}\n"
                           f"任务：{task.title}\n"
                           f"截止：{task.deadline or '未设置'}\n"
                           f"当前进度：{task.progress}%\n\n"
                           f"请回复进度更新，例如：'{task.title}进度60%'"
                )
                notifications.append(notification)
        
        # Calculate next reminder time (e.g., 6 hours later)
        session.next_reminder_at = local_now() + timedelta(hours=6)
        
        self.db.commit()
        self.db.refresh(session)
        
        return {
            "session_id": session.id,
            "tasks_count": len(tasks),
            "notifications": [n.model_dump() for n in notifications]
        }
    
    def check_collection(self, session_id: str) -> Dict[str, Any]:
        """Check collection status and send reminders if needed
        
        Args:
            session_id: Session ID
            
        Returns:
            Dict with status info and any new notifications
        """
        # Get session
        session = self.db.query(ProgressCollectSession).filter(
            ProgressCollectSession.id == session_id
        ).first()
        
        if not session:
            raise ValueError(f"Session {session_id} not found")
        
        if session.status != "active":
            return {
                "status": session.status,
                "message": "Session is not active",
                "notifications": []
            }
        
        # Check if it's time for reminder
        now = local_now()
        if session.next_reminder_at and now < session.next_reminder_at:
            return {
                "status": "waiting",
                "message": f"Next reminder at {session.next_reminder_at}",
                "notifications": []
            }
        
        # Get pending tasks
        pending_details = self.db.query(ProgressCollectDetail).filter(
            and_(
                ProgressCollectDetail.session_id == session_id,
                ProgressCollectDetail.status == "pending"
            )
        ).all()
        
        if not pending_details:
            # All tasks responded, mark session as completed
            session.status = "completed"
            self.db.commit()
            return {
                "status": "completed",
                "message": "All tasks responded",
                "notifications": []
            }
        
        # Get project info
        project = session.project
        
        # Check if we've exceeded max reminders
        max_reminders = 3  # Could be configurable
        if session.reminder_count >= max_reminders:
            # Escalate
            session.status = "escalated"
            session.escalated_at = now
            
            # Generate escalation notifications
            notifications = []
            for detail in pending_details:
                task = detail.task
                notification = NotificationResponse(
                    target="group",
                    channel=project.channel,
                    user_id=None,
                    group_id=project.group_id,
                    message=f"⚠️ 任务未反馈进展升级通知\n\n"
                           f"项目：{project.name}\n"
                           f"任务：{task.title}\n"
                           f"责任人：{task.assignee or '未分配'}\n"
                           f"连续未反馈次数：{session.reminder_count}\n\n"
                           f"请项目经理跟进处理"
                )
                notifications.append(notification)
            
            self.db.commit()
            return {
                "status": "escalated",
                "message": f"Escalated {len(pending_details)} pending tasks",
                "notifications": [n.model_dump() for n in notifications]
            }
        
        # Send reminder
        notifications = []
        for detail in pending_details:
            task = detail.task
            notification = NotificationResponse(
                target="user",
                channel=project.channel,
                user_id=detail.assignee,
                group_id=None,
                message=f"⏰ 提醒：请更新任务进展\n\n"
                       f"项目：{project.name}\n"
                       f"任务：{task.title}\n"
                       f"截止：{task.deadline or '未设置'}\n"
                       f"当前进度：{task.progress}%\n\n"
                       f"请及时更新进展"
            )
            notifications.append(notification)
        
        # Update session
        session.reminder_count += 1
        session.last_reminder_at = now
        session.next_reminder_at = now + timedelta(hours=6)
        
        self.db.commit()
        
        return {
            "status": "reminder_sent",
            "message": f"Sent reminder #{session.reminder_count} for {len(pending_details)} pending tasks",
            "notifications": [n.model_dump() for n in notifications]
        }
    
    def get_collection_status(self, session_id: str) -> Dict[str, Any]:
        """Get collection session status
        
        Args:
            session_id: Session ID
            
        Returns:
            Dict with session status info
        """
        session = self.db.query(ProgressCollectSession).filter(
            ProgressCollectSession.id == session_id
        ).first()
        
        if not session:
            raise ValueError(f"Session {session_id} not found")
        
        # Get pending tasks
        pending_details = self.db.query(ProgressCollectDetail).filter(
            and_(
                ProgressCollectDetail.session_id == session_id,
                ProgressCollectDetail.status == "pending"
            )
        ).all()
        
        pending_task_ids = [detail.task_id for detail in pending_details]
        
        return {
            "session_id": session.id,
            "project_id": session.project_id,
            "status": session.status,
            "tasks_count": session.tasks_count,
            "responded_count": session.responded_count,
            "reminder_count": session.reminder_count,
            "pending_tasks": pending_task_ids,
            "created_at": session.created_at
        }
    
    def mark_responded(self, task_id: str, feedback_method: str = "chat") -> bool:
        """Mark a task as responded in active collection
        
        Args:
            task_id: Task ID
            feedback_method: Feedback method ('chat' | 'form')
            
        Returns:
            True if successful
        """
        # Find active collection details for this task
        active_details = self.db.query(ProgressCollectDetail).join(
            ProgressCollectSession
        ).filter(
            and_(
                ProgressCollectDetail.task_id == task_id,
                ProgressCollectDetail.status == "pending",
                ProgressCollectSession.status == "active"
            )
        ).all()
        
        now = local_now()
        for detail in active_details:
            detail.status = "responded"
            detail.responded_at = now
            detail.feedback_method = feedback_method
            
            # Update session responded count
            session = detail.session
            session.responded_count += 1
        
        self.db.commit()
        return True