"""Report generation service"""
from typing import Dict, Any
from datetime import datetime, date, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_

from aipm.models import Project, Task, ProgressHistory


class ReportService:
    """Service for report generation"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def generate_report(self, project_id: str, report_type: str = "weekly") -> str:
        """Generate project report
        
        Args:
            project_id: Project ID
            report_type: Report type ('daily' | 'weekly' | 'monthly')
            
        Returns:
            Report content as string
        """
        # Get project
        project = self.db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise ValueError(f"Project {project_id} not found")
        
        # Get all tasks for the project
        tasks = self.db.query(Task).filter(Task.project_id == project_id).all()
        
        if not tasks:
            return f"# {project.name} - {report_type.capitalize()}报告\n\n暂无任务数据"
        
        # Calculate date range based on report type
        end_date = date.today()
        if report_type == "daily":
            start_date = end_date
        elif report_type == "weekly":
            start_date = end_date - timedelta(days=7)
        elif report_type == "monthly":
            start_date = end_date - timedelta(days=30)
        else:
            start_date = end_date - timedelta(days=7)
        
        # Task statistics
        total_tasks = len(tasks)
        completed_tasks = [t for t in tasks if t.status == "completed"]
        in_progress_tasks = [t for t in tasks if t.status == "in_progress"]
        pending_tasks = [t for t in tasks if t.status == "pending"]
        blocked_tasks = [t for t in tasks if t.status == "blocked"]
        
        # Calculate average progress
        avg_progress = sum(t.progress for t in tasks) / total_tasks if total_tasks > 0 else 0
        
        # Get progress updates in the period
        progress_updates = self.db.query(ProgressHistory).join(Task).filter(
            and_(
                Task.project_id == project_id,
                ProgressHistory.created_at >= datetime.combine(start_date, datetime.min.time())
            )
        ).order_by(ProgressHistory.created_at.desc()).all()
        
        # Build report
        report_lines = [
            f"# {project.name} - {report_type.capitalize()}报告",
            f"",
            f"**报告日期**：{end_date.strftime('%Y-%m-%d')}",
            f"",
            f"## 项目概况",
            f"",
            f"- **项目状态**：{project.status}",
            f"- **项目目标**：{project.objective or '未设置'}",
            f"- **截止日期**：{project.deadline or '未设置'}",
            f"",
            f"## 任务统计",
            f"",
            f"| 指标 | 数量 |",
            f"|------|------|",
            f"| 总任务数 | {total_tasks} |",
            f"| 已完成 | {len(completed_tasks)} |",
            f"| 进行中 | {len(in_progress_tasks)} |",
            f"| 待开始 | {len(pending_tasks)} |",
            f"| 已阻塞 | {len(blocked_tasks)} |",
            f"| 平均进度 | {avg_progress:.1f}% |",
            f"",
        ]
        
        # Task list
        report_lines.append("## 任务列表")
        report_lines.append("")
        
        # Completed tasks
        if completed_tasks:
            report_lines.append("### ✅ 已完成")
            report_lines.append("")
            for task in completed_tasks:
                report_lines.append(f"- {task.title} ({task.assignee or '未分配'})")
            report_lines.append("")
        
        # In progress tasks
        if in_progress_tasks:
            report_lines.append("### 🔄 进行中")
            report_lines.append("")
            for task in in_progress_tasks:
                report_lines.append(
                    f"- {task.title} ({task.assignee or '未分配'}) - {task.progress}%"
                )
            report_lines.append("")
        
        # Pending tasks
        if pending_tasks:
            report_lines.append("### 📋 待开始")
            report_lines.append("")
            for task in pending_tasks:
                deadline_str = f"截止：{task.deadline}" if task.deadline else ""
                report_lines.append(
                    f"- {task.title} ({task.assignee or '未分配'}) {deadline_str}"
                )
            report_lines.append("")
        
        # Blocked tasks
        if blocked_tasks:
            report_lines.append("### ⚠️ 已阻塞")
            report_lines.append("")
            for task in blocked_tasks:
                report_lines.append(f"- {task.title} ({task.assignee or '未分配'})")
            report_lines.append("")
        
        # Recent progress updates
        if progress_updates:
            report_lines.append("## 最近进展更新")
            report_lines.append("")
            for update in progress_updates[:10]:  # Show last 10 updates
                task = update.task
                report_lines.append(
                    f"- **{task.title}** → {update.progress}% "
                    f"({update.created_at.strftime('%m-%d %H:%M')})"
                )
                if update.note:
                    report_lines.append(f"  - {update.note}")
            report_lines.append("")
        
        # Risk tasks (deadline in 3 days and progress < 70%)
        risk_tasks = [t for t in tasks if t.deadline and 
                      (t.deadline - date.today()).days <= 3 and 
                      t.progress < 70 and 
                      t.status != "completed"]
        
        if risk_tasks:
            report_lines.append("## ⚠️ 风险任务")
            report_lines.append("")
            for task in risk_tasks:
                days_remaining = (task.deadline - date.today()).days
                report_lines.append(
                    f"- {task.title} - 剩余{days_remaining}天，当前进度{task.progress}%"
                )
            report_lines.append("")
        
        report_lines.append("---")
        report_lines.append(f"*报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
        
        return "\n".join(report_lines)