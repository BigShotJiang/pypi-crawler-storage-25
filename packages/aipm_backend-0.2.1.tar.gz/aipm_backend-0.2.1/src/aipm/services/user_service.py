"""User management service"""
from typing import List, Optional
from sqlalchemy.orm import Session

from aipm.models import User, UserChannel
from aipm.schemas import UserCreate, UserChannelCreate


class UserService:
    """Service for user management"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_user(self, user_data: UserCreate) -> str:
        """Create a new user
        
        Args:
            user_data: User creation data
            
        Returns:
            User ID
        """
        user = User(
            name=user_data.name,
            role=user_data.role
        )
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user.id
    
    def get_user(self, user_id: str) -> Optional[User]:
        """Get user by ID
        
        Args:
            user_id: User ID
            
        Returns:
            User object or None
        """
        return self.db.query(User).filter(User.id == user_id).first()
    
    def get_users(self, role: Optional[str] = None) -> List[User]:
        """Get all users, optionally filtered by role
        
        Args:
            role: Optional role filter ('pm' | 'member')
            
        Returns:
            List of users
        """
        query = self.db.query(User)
        if role:
            query = query.filter(User.role == role)
        query = query.order_by(User.created_at.desc())
        return query.all()
    
    def add_user_channel(self, channel_data: UserChannelCreate) -> str:
        """Add user channel binding
        
        Args:
            channel_data: User channel creation data
            
        Returns:
            Channel binding ID
        """
        channel = UserChannel(
            user_id=channel_data.user_id,
            channel=channel_data.channel,
            channel_user_id=channel_data.channel_user_id
        )
        self.db.add(channel)
        self.db.commit()
        self.db.refresh(channel)
        return channel.id
    
    def get_user_channels(self, user_id: str) -> List[UserChannel]:
        """Get user's channel bindings
        
        Args:
            user_id: User ID
            
        Returns:
            List of user channel bindings
        """
        return self.db.query(UserChannel).filter(
            UserChannel.user_id == user_id
        ).all()
    
    def get_user_by_channel_id(self, channel: str, channel_user_id: str) -> Optional[User]:
        """Get user by channel user ID
        
        Args:
            channel: Channel type ('wecom' | 'whatsapp' | 'email')
            channel_user_id: User ID in the channel
            
        Returns:
            User object or None
        """
        channel_binding = self.db.query(UserChannel).filter(
            UserChannel.channel == channel,
            UserChannel.channel_user_id == channel_user_id
        ).first()
        
        if channel_binding:
            return self.get_user(channel_binding.user_id)
        return None
    
    def get_channel_user_id(self, user_name: str, channel: str) -> Optional[str]:
        """Get channel user ID by user name
        
        Args:
            user_name: User name (e.g. '黄明通')
            channel: Channel type ('wecom' | 'whatsapp' | 'email')
            
        Returns:
            Channel user ID (e.g. 'HuangMingTong') or None
        """
        # Find user by name
        user = self.db.query(User).filter(User.name == user_name).first()
        if not user:
            return None
        
        # Find channel binding
        channel_binding = self.db.query(UserChannel).filter(
            UserChannel.user_id == user.id,
            UserChannel.channel == channel
        ).first()
        
        if channel_binding:
            return channel_binding.channel_user_id
        return None