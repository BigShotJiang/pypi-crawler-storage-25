"""Project management service"""
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from aipm.models import Project, User, UserChannel, local_now
from aipm.schemas import ProjectCreate, ProjectUpdate


class ProjectService:
    """Service for project management"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_project(self, project_data: ProjectCreate) -> str:
        """Create a new project
        
        Args:
            project_data: Project creation data
            
        Returns:
            Project ID
        """
        project = Project(
            name=project_data.name,
            channel=project_data.channel,
            group_id=project_data.group_id,
            pm_user_id=project_data.pm_user_id,
            background=project_data.background,
            objective=project_data.objective,
            deadline=project_data.deadline,
            status="active"
        )
        self.db.add(project)
        self.db.commit()
        self.db.refresh(project)
        return project.id
    
    def get_project(self, project_id: str) -> Optional[Project]:
        """Get project by ID
        
        Args:
            project_id: Project ID
            
        Returns:
            Project object or None
        """
        return self.db.query(Project).filter(Project.id == project_id).first()
    
    def get_projects(self, status: Optional[str] = None) -> List[Project]:
        """Get all projects, optionally filtered by status
        
        Args:
            status: Optional status filter ('active' | 'completed' | 'paused')
            
        Returns:
            List of projects
        """
        query = self.db.query(Project)
        if status:
            query = query.filter(Project.status == status)
        query = query.order_by(Project.created_at.desc())
        return query.all()
    
    def update_project(self, project_id: str, project_data: ProjectUpdate) -> bool:
        """Update project
        
        Args:
            project_id: Project ID
            project_data: Update data
            
        Returns:
            True if successful, False if project not found
        """
        project = self.get_project(project_id)
        if not project:
            return False
        
        update_data = project_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(project, key, value)
        
        project.updated_at = local_now()
        self.db.commit()
        return True
    
    def delete_project(self, project_id: str) -> bool:
        """Delete project
        
        Args:
            project_id: Project ID
            
        Returns:
            True if successful, False if project not found
        """
        project = self.get_project(project_id)
        if not project:
            return False
        
        self.db.delete(project)
        self.db.commit()
        return True
    
    def get_project_by_name(self, name: str) -> Optional[Project]:
        """Get project by name
        
        Args:
            name: Project name
            
        Returns:
            Project object or None
        """
        return self.db.query(Project).filter(Project.name == name).first()