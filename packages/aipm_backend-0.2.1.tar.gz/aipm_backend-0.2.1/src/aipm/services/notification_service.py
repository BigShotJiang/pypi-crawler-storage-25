"""Notification service - manage notification queue"""
from datetime import datetime, timedelta
from typing import List, Optional
from sqlalchemy.orm import Session

from aipm.models import Notification, local_now


class NotificationService:
    """Service for managing notification queue"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_notification(
        self,
        channel: str,
        target_type: str,
        target_id: str,
        message: str,
        notification_type: str,
        project_id: Optional[str] = None,
        task_id: Optional[str] = None,
        priority: str = "normal",
        webhook_url: Optional[str] = None,
        mention_userid: Optional[str] = None
    ) -> Notification:
        """Create a new notification in queue"""
        notification = Notification(
            channel=channel,
            target_type=target_type,
            target_id=target_id,
            message=message,
            notification_type=notification_type,
            project_id=project_id,
            task_id=task_id,
            priority=priority,
            webhook_url=webhook_url,
            mention_userid=mention_userid,
            status="pending"
        )
        self.db.add(notification)
        self.db.commit()
        self.db.refresh(notification)
        return notification
    
    def get_pending_notifications(self, limit: int = 10) -> List[Notification]:
        """Get pending notifications (for Agent to fetch)"""
        notifications = self.db.query(Notification).filter(
            Notification.status == "pending"
        ).order_by(
            Notification.priority.desc(),  # high first
            Notification.created_at.asc()   # oldest first
        ).limit(limit).all()
        return notifications
    
    def mark_sent(self, notification_id: str) -> bool:
        """Mark notification as sent"""
        notification = self.db.query(Notification).filter(
            Notification.id == notification_id
        ).first()
        
        if not notification:
            return False
        
        notification.status = "sent"
        notification.sent_at = local_now()
        self.db.commit()
        return True
    
    def mark_failed(self, notification_id: str, error_message: str) -> bool:
        """Mark notification as failed"""
        notification = self.db.query(Notification).filter(
            Notification.id == notification_id
        ).first()
        
        if not notification:
            return False
        
        notification.status = "failed"
        notification.error_message = error_message
        self.db.commit()
        return True
    
    def get_stats(self) -> dict:
        """Get notification queue statistics"""
        pending_count = self.db.query(Notification).filter(
            Notification.status == "pending"
        ).count()
        
        sent_count = self.db.query(Notification).filter(
            Notification.status == "sent"
        ).count()
        
        failed_count = self.db.query(Notification).filter(
            Notification.status == "failed"
        ).count()
        
        return {
            "pending": pending_count,
            "sent": sent_count,
            "failed": failed_count,
            "total": pending_count + sent_count + failed_count
        }
    
    def cleanup_old_notifications(self, days: int = 7) -> int:
        """Clean up old sent/failed notifications"""
        cutoff_date = local_now() - timedelta(days=days)
        
        deleted = self.db.query(Notification).filter(
            Notification.status.in_(["sent", "failed"]),
            Notification.created_at < cutoff_date
        ).delete()
        
        self.db.commit()
        return deleted
    # ========== 新增方法：简化流程 ==========

    def delete_notification(self, notification_id: str) -> bool:
        """直接删除通知（发送成功后调用）"""
        notification = self.db.query(Notification).filter(
            Notification.id == notification_id
        ).first()

        if not notification:
            return False

        self.db.delete(notification)
        self.db.commit()
        return True

    def cleanup_stale_notifications(self, hours: int = 24) -> int:
        """清理长时间未发送的通知（超过指定小时仍 pending）"""
        cutoff_time = local_now() - timedelta(hours=hours)

        deleted = self.db.query(Notification).filter(
            Notification.status == "pending",
            Notification.created_at < cutoff_time
        ).delete()

        self.db.commit()
        return deleted
