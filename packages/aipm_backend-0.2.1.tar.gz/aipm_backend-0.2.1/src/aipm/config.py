"""Configuration management for AIPM"""
from pathlib import Path
from typing import Optional, List, Dict, Any
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class DatabaseSettings(BaseSettings):
    """Database configuration"""
    database_url: str = Field(
        default="sqlite:///./aipm.db",
        description="Database connection URL (SQLite or PostgreSQL)"
    )
    database_echo: bool = Field(
        default=False,
        description="Enable SQLAlchemy echo for debugging"
    )


class SchedulerSettings(BaseSettings):
    """Scheduler configuration"""
    scheduler_enabled: bool = Field(
        default=True,
        description="Enable built-in scheduler"
    )
    scheduler_timezone: str = Field(
        default="Asia/Shanghai",
        description="Scheduler timezone"
    )


class DailyCheckSettings(BaseSettings):
    """Daily check task configuration"""
    trigger_time: str = Field(default="09:00", description="Trigger time (HH:MM)")
    trigger_days: List[str] = Field(
        default=["monday", "tuesday", "wednesday", "thursday", "friday"],
        description="Days to trigger"
    )
    enabled: bool = Field(default=True, description="Enable this task")
    params: Dict[str, Any] = Field(
        default_factory=lambda: {
            "days_threshold": 3,
            "progress_threshold": 70
        }
    )


class ProgressCollectSettings(BaseSettings):
    """Progress collection task configuration"""
    trigger_time: str = Field(default="09:00", description="Trigger time (HH:MM)")
    trigger_days: List[str] = Field(
        default=["wednesday"],
        description="Days to trigger"
    )
    enabled: bool = Field(default=True, description="Enable this task")
    reminder_config: Dict[str, Any] = Field(
        default_factory=lambda: {
            "morning_time": "09:00",
            "afternoon_time": "15:00",
            "max_reminders": 3
        }
    )
    escalation_config: Dict[str, Any] = Field(
        default_factory=lambda: {
            "escalate_after": 3,
            "notify_pm": True,
            "notify_group": True
        }
    )


class WeeklyReportSettings(BaseSettings):
    """Weekly report task configuration"""
    trigger_time: str = Field(default="17:00", description="Trigger time (HH:MM)")
    trigger_days: List[str] = Field(
        default=["friday"],
        description="Days to trigger"
    )
    enabled: bool = Field(default=True, description="Enable this task")


class ScheduledTasksSettings(BaseSettings):
    """Scheduled tasks configuration"""
    daily_check: DailyCheckSettings = Field(default_factory=DailyCheckSettings)
    progress_collect: ProgressCollectSettings = Field(default_factory=ProgressCollectSettings)
    weekly_report: WeeklyReportSettings = Field(default_factory=WeeklyReportSettings)


class Settings(BaseSettings):
    """Main application settings"""
    app_name: str = Field(default="AIPM", description="Application name")
    app_version: str = Field(default="0.1.0", description="Application version")
    debug: bool = Field(default=False, description="Debug mode")
    
    # Database settings
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    
    # Scheduler settings
    scheduler: SchedulerSettings = Field(default_factory=SchedulerSettings)
    
    # Scheduled tasks settings
    scheduled_tasks: ScheduledTasksSettings = Field(default_factory=ScheduledTasksSettings)
    
    # API settings
    api_prefix: str = Field(default="/api/v1", description="API prefix")
    
    # Gateway settings for message sending
    gateway_url: str = Field(
        default="http://127.0.0.1:18789",
        description="OpenClaw Gateway URL for message sending"
    )
    gateway_token: str = Field(
        default="",
        description="OpenClaw Gateway auth token"
    )
    
    model_config = SettingsConfigDict(
        env_prefix="AIPM_",
        env_nested_delimiter="__",
        case_sensitive=False,
        env_file=".env",
        env_file_encoding="utf-8"
    )


# Global settings instance
settings = Settings()