"""Pydantic schemas for API request/response models"""
from datetime import datetime, date
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ==================== User Schemas ====================

class UserCreate(BaseModel):
    """Create user request"""
    name: str = Field(..., description="User name")
    role: str = Field(default="member", description="User role: 'pm' | 'member'")


class UserResponse(BaseModel):
    """User response"""
    id: str
    name: str
    role: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class UserChannelCreate(BaseModel):
    """Create user channel binding"""
    user_id: str = Field(..., description="User ID")
    channel: str = Field(..., description="Channel type: 'wecom' | 'whatsapp' | 'email'")
    channel_user_id: str = Field(..., description="User ID in the channel")


class UserChannelResponse(BaseModel):
    """User channel response"""
    id: str
    user_id: str
    channel: str
    channel_user_id: str
    created_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Project Schemas ====================

class ProjectCreate(BaseModel):
    """Create project request"""
    name: str = Field(..., description="Project name")
    channel: str = Field(..., description="Channel type: 'wecom' | 'whatsapp'")
    group_id: Optional[str] = Field(None, description="Group ID in the channel")
    webhook_url: Optional[str] = Field(None, description="Webhook URL for sending messages")
    pm_user_id: Optional[str] = Field(None, description="Project manager user ID")
    background: Optional[str] = Field(None, description="Project background")
    objective: Optional[str] = Field(None, description="Project objective")
    deadline: Optional[date] = Field(None, description="Project deadline")


class ProjectUpdate(BaseModel):
    """Update project request"""
    channel: Optional[str] = None
    group_id: Optional[str] = None
    webhook_url: Optional[str] = None
    name: Optional[str] = None
    pm_user_id: Optional[str] = None
    background: Optional[str] = None
    objective: Optional[str] = None
    deadline: Optional[date] = None
    status: Optional[str] = Field(None, description="Project status: 'active' | 'completed' | 'paused'")


class ProjectResponse(BaseModel):
    """Project response"""
    id: str
    name: str
    channel: str
    group_id: Optional[str]
    webhook_url: Optional[str]
    pm_user_id: Optional[str]
    background: Optional[str]
    objective: Optional[str]
    deadline: Optional[date]
    status: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Task Schemas ====================

class TaskCreate(BaseModel):
    """Create task request"""
    project_id: str = Field(..., description="Project ID")
    title: str = Field(..., description="Task title")
    description: Optional[str] = Field(None, description="Task description")
    assignee: Optional[str] = Field(None, description="Assignee user ID")
    deadline: Optional[date] = Field(None, description="Task deadline")
    priority: str = Field(default="medium", description="Priority: 'high' | 'medium' | 'low'")


class TaskUpdate(BaseModel):
    """Update task request"""
    title: Optional[str] = None
    description: Optional[str] = None
    assignee: Optional[str] = None
    deadline: Optional[date] = None
    priority: Optional[str] = None
    status: Optional[str] = Field(None, description="Task status: 'pending' | 'in_progress' | 'completed' | 'blocked'")
    progress: Optional[int] = Field(None, ge=0, le=100, description="Progress percentage (0-100)")


class ProgressUpdate(BaseModel):
    """Update progress request"""
    progress: int = Field(..., ge=0, le=100, description="Progress percentage (0-100)")
    note: Optional[str] = Field(None, description="Progress note")
    user_id: str = Field(..., description="User ID who updated the progress")
    feedback_method: str = Field(default="chat", description="Feedback method: 'chat' | 'form'")


class TaskResponse(BaseModel):
    """Task response"""
    id: str
    project_id: str
    title: str
    description: Optional[str]
    assignee: Optional[str]
    deadline: Optional[date]
    priority: str
    status: str
    progress: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Progress History Schemas ====================

class ProgressHistoryResponse(BaseModel):
    """Progress history response"""
    id: str
    task_id: str
    progress: int
    note: Optional[str]
    updated_by: Optional[str]
    feedback_method: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Collection Schemas ====================

class NotificationResponse(BaseModel):
    """Notification response"""
    target: str = Field(..., description="'user' or 'group'")
    channel: str = Field(..., description="Channel type")
    user_id: Optional[str] = Field(None, description="User ID if target is 'user'")
    group_id: Optional[str] = Field(None, description="Group ID if target is 'group'")
    message: str = Field(..., description="Notification message")


class CollectionStartRequest(BaseModel):
    """Start collection request"""
    project_id: str = Field(..., description="Project ID")


class CollectionStartResponse(BaseModel):
    """Start collection response"""
    session_id: str
    tasks_count: int
    notifications: List[NotificationResponse]


class CollectionCheckRequest(BaseModel):
    """Check collection request"""
    session_id: str = Field(..., description="Session ID")


class CollectionStatusResponse(BaseModel):
    """Collection status response"""
    session_id: str
    project_id: str
    status: str
    tasks_count: int
    responded_count: int
    reminder_count: int
    pending_tasks: List[str]
    created_at: datetime


# ==================== Feedback Schemas ====================

class ChatFeedbackRequest(BaseModel):
    """Chat feedback request"""
    task_id: str = Field(..., description="Task ID")
    progress: int = Field(..., ge=0, le=100, description="Progress percentage")
    note: Optional[str] = Field(None, description="Progress note")
    user_id: str = Field(..., description="User ID")


class FormFeedbackRequest(BaseModel):
    """Form feedback request"""
    progress: int = Field(..., ge=0, le=100, description="Progress percentage")
    note: Optional[str] = Field(None, description="Progress note")
    user_id: str = Field(..., description="User ID")


# ==================== Report Schemas ====================

class ReportGenerateRequest(BaseModel):
    """Generate report request"""
    project_id: str = Field(..., description="Project ID")
    report_type: str = Field(default="weekly", description="Report type: 'daily' | 'weekly' | 'monthly'")


class ReportGenerateResponse(BaseModel):
    """Generate report response"""
    report_content: str


# ==================== Overdue Schemas ====================

class OverdueTaskResponse(BaseModel):
    """Overdue task response"""
    task_id: str
    task_title: str
    project_id: str
    project_name: str
    assignee: Optional[str]
    deadline: Optional[date]
    progress: int
    days_remaining: int
    group_id: Optional[str]


# ==================== Scheduled Task Schemas ====================

class ScheduledTaskConfigResponse(BaseModel):
    """Scheduled task config response"""
    id: str
    task_id: str
    name: str
    trigger_time: str
    trigger_days: List[str]
    timezone: str
    enabled: bool
    params: Optional[Dict[str, Any]]
    
    class Config:
        from_attributes = True


class ScheduledTaskConfigUpdate(BaseModel):
    """Update scheduled task config request"""
    trigger_time: Optional[str] = None
    trigger_days: Optional[List[str]] = None
    enabled: Optional[bool] = None
    params: Optional[Dict[str, Any]] = None


class ScheduledTaskResult(BaseModel):
    """Scheduled task execution result"""
    status: str = Field(..., description="'success' | 'failed'")
    message: str = Field(..., description="Result message")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")


# ==================== Notification Schemas ====================

class NotificationCreate(BaseModel):
    """Create notification request"""
    project_id: Optional[str] = Field(None, description="Project ID")
    task_id: Optional[str] = Field(None, description="Task ID")
    channel: str = Field(..., description="Channel: 'wecom' | 'whatsapp' | 'telegram' | 'email'")
    target_type: str = Field(..., description="Target type: 'group' | 'user'")
    target_id: str = Field(..., description="Target ID (group or user)")
    message: str = Field(..., description="Notification message")
    priority: str = Field(default="normal", description="Priority: 'high' | 'normal' | 'low'")
    notification_type: str = Field(..., description="Type: 'overdue_warning' | 'progress_collect' | 'weekly_report' | 'reminder'")
    webhook_url: Optional[str] = Field(None, description="Webhook URL for sending text message")
    mention_userid: Optional[str] = Field(None, description="Userid to mention (@)")


class NotificationPendingResponse(BaseModel):
    """Pending notification response (for Agent to fetch)"""
    id: str
    channel: str
    target_type: str
    target_id: str
    message: str
    priority: str
    notification_type: str
    project_id: Optional[str]
    task_id: Optional[str]
    webhook_url: Optional[str]
    mention_userid: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


class NotificationListResponse(BaseModel):
    """Notification list response"""
    count: int
    notifications: List[NotificationPendingResponse]


# ==================== Generic Response ====================

class SuccessResponse(BaseModel):
    """Generic success response"""
    success: bool = True
    message: Optional[str] = None