"""Database configuration and session management"""
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from typing import Generator
from contextlib import contextmanager

from aipm.config import settings

# Create engine
engine = create_engine(
    settings.database.database_url,
    echo=settings.database.database_echo,
    connect_args={"check_same_thread": False} if "sqlite" in settings.database.database_url else {}
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create base class for models
Base = declarative_base()


def get_db() -> Generator[Session, None, None]:
    """Dependency to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def get_db_context() -> Generator[Session, None, None]:
    """Context manager for database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database tables"""
    # Import all models here to ensure they are registered
    from aipm.models import (  # noqa: F401
        User, UserChannel, Project, Task,
        ProgressHistory, ProgressCollectSession, ProgressCollectDetail,
        ScheduledTaskConfig
    )
    Base.metadata.create_all(bind=engine)