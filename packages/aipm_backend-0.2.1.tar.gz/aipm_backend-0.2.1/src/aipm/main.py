"""FastAPI application entry point"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from aipm.config import settings
from aipm.database import init_db
from aipm.api import api_router
from aipm.scheduler import scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    init_db()
    
    # Start scheduler if enabled
    if settings.scheduler.scheduler_enabled:
        scheduler.start()
    
    yield
    
    # Shutdown
    scheduler.shutdown()


def create_app() -> FastAPI:
    """Create FastAPI application"""
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="AI Project Manager - REST API backend for project and task management",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include API router
    app.include_router(api_router, prefix=settings.api_prefix)
    
    # Add health check endpoint
    @app.get("/health")
    def health_check():
        return {"status": "healthy", "app": settings.app_name, "version": settings.app_version}
    
    # Add root endpoint
    @app.get("/")
    def root():
        return {
            "app": settings.app_name,
            "version": settings.app_version,
            "docs": "/docs",
            "api_prefix": settings.api_prefix
        }
    
    return app


# Create application instance
app = create_app()