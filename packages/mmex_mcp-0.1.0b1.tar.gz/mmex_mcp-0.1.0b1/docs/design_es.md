# Diseño Técnico - MMEX MCP Server 🛠️

## 1. Configuración de Conexión

### Variables de Entorno

| Variable | Descripción | Requerido |
|----------|-------------|-----------|
| `MMEX_DB_PATH` | Ruta al archivo .mmb | Opcional* |
| `MMEX_DB_KEY` | Contraseña SQLCipher | Opcional |

*Si no está definido, `db_path` es obligatorio en cada tool call.

### Lógica de Resolución

```
db_path_resuelto = tool_call.db_path ?? env.MMEX_DB_PATH
db_key_resuelto  = tool_call.db_key  ?? env.MMEX_DB_KEY  ?? None

if db_path_resuelto is None:
    raise Error("db_path requerido")
```

### Singleton Engine

El `MmexEngine` se instancia una vez por combinación `(db_path, db_key)` y se cachea para reutilización.

```python
class EngineManager:
    _instances: dict[tuple[str, str | None], MmexEngine] = {}
    
    @classmethod
    def get_engine(cls, db_path: str, db_key: str | None) -> MmexEngine:
        key = (db_path, db_key)
        if key not in cls._instances:
            cls._instances[key] = MmexEngine(db_path, db_key)
        return cls._instances[key]
```

## 2. Estructura de Directorios

```
mmex_mcp/
├── pyproject.toml
├── .python-version
├── src/
│   └── mmex_mcp/
│       ├── __init__.py
│       ├── server.py              # Entry point, registra tools
│       ├── config.py              # Configuración desde ENV
│       ├── engine.py              # EngineManager (singleton)
│       └── tools/
│           ├── __init__.py        # Exporta todas las tools
│           ├── _base.py           # Helpers comunes (serialización)
│           ├── support.py         # mmex_support_get_db_version
│           ├── currencies.py      # mmex_currencies_*
│           ├── tags.py            # mmex_tags_*
│           ├── categories.py      # mmex_categories_*
│           ├── payees.py          # mmex_payees_*
│           ├── accounts.py        # mmex_accounts_*
│           ├── assets.py          # mmex_assets_*
│           ├── stocks.py          # mmex_stocks_*
│           ├── transactions.py    # mmex_transactions_*
│           └── scheduled.py       # mmex_scheduled_*
```

## 3. Convenciones de Nombres de Herramientas

### Patrón

```
mmex_{entidad}_{accion}
```

### Acciones CRUD Estándar

| Acción | Herramienta | Descripción |
|--------|------|-------------|
| List | `mmex_{entity}_list` | Obtener todos los registros |
| Get | `mmex_{entity}_get` | Obtener por ID |
| Create | `mmex_{entity}_create` | Crear nuevo registro |
| Update | `mmex_{entity}_update` | Actualizar registro existente |
| Delete | `mmex_{entity}_delete` | Eliminar registro |

### Acciones Especiales

| Entidad | Herramienta | Descripción |
|---------|------|-------------|
| accounts | `mmex_accounts_balance` | Obtener balance de cuenta |
| categories | `mmex_categories_subcategories` | Listar subcategorías |
| transactions | `mmex_transactions_splits` | Obtener desgloses |
| transactions | `mmex_transactions_add_split` | Agregar desglose |
| transactions | `mmex_transactions_update_split` | Actualizar desglose |
| transactions | `mmex_transactions_delete_split` | Eliminar desglose |
| transactions | `mmex_transactions_tags` | Obtener tags de transacción |
| transactions | `mmex_transactions_link_tag` | Vincular tag |
| transactions | `mmex_transactions_unlink_tag` | Desvincular tag |
| tags | `mmex_tags_for_reference` | Tags por referencia |
| tags | `mmex_tags_link` | Vincular tag a referencia |
| tags | `mmex_tags_unlink` | Desvincular tag |
| currencies | `mmex_currencies_by_symbol` | Buscar por símbolo |

## 4. Parámetros Comunes

Todas las herramientas aceptan estos parámetros opcionales:

```python
db_path: str | None = None   # Ruta a la DB (usa ENV si no se provee)
db_key: str | None = None    # Contraseña (usa ENV si no se provee)
```

## 5. Modelos de Datos

### Enfoque de Serialización

**IMPORTANTE:** No utilizamos los métodos `*_json` de mmex_lib. En su lugar:
1. Usamos los métodos que retornan objetos Python (`get_all`, `get_by_id`, etc.)
2. Convertimos manualmente los objetos UniFFI a diccionarios para MCP

### Mapeo de Tipos Rust → Python → MCP

| Rust | Python (UniFFI) | MCP Schema |
|------|-----------------|------------|
| `i64` | `int` | `number` |
| `String` | `str` | `string` |
| `Option<T>` | `T | None` | `T` (optional) |
| `bool` | `bool` | `boolean` |
| `f64` | `float` | `number` |
| `Money` | `Money(v1=str)` | `string` (decimal como string) |
| `MmexDate` | `MmexDate(v1=str)` | `string` (ISO 8601) |
| `Enum` | Enum class | `string` (valor del enum) |
| `Record` | Clase con atributos | `object` (dict) |

### Helper de Serialización

```python
# src/mmex_mcp/tools/_base.py

def serialize(obj) -> Any:
    """Convierte objetos UniFFI a tipos serializables para MCP."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    if hasattr(obj, '__dict__'):
        result = {}
        for key, value in obj.__dict__.items():
            result[key] = serialize(value)
        return result
    return str(obj)
```

### Tipos Wrapper (IDs y valores)

Estos tipos tienen un único campo `v1`:

```python
AccountId(v1: int)
TransactionId(v1: int)
TagId(v1: int)
PayeeId(v1: int)
CategoryId(v1: int)
CurrencyId(v1: int)
StockId(v1: int)
AssetId(v1: int)
Money(v1: str)        # Decimal como string: "100.50"
MmexDate(v1: str)     # ISO 8601: "2024-01-15"
```

### Enums

#### AccountType
```
Cash, Checking, Term, Investment, CreditCard, Loan, Asset, Shares, Unknown(String)
```

#### AccountStatus
```
Open, Closed, Unknown(String)
```

#### TransactionCode
```
Withdrawal, Deposit, Transfer, Unknown(String)
```

#### TransactionStatus
```
None, Reconciled, Void, FollowUp, Duplicate, Unknown(String)
```

#### AssetStatus
```
Open, Closed, Unknown(String)
```

### Estructuras Principales

#### Currency
```python
Currency(
    id=CurrencyId(v1=1),
    name="US Dollar",
    pfx_symbol="$",                    # Optional[str]
    sfx_symbol=None,                   # Optional[str]
    decimal_point=".",                 # Optional[str]
    group_separator=",",               # Optional[str]
    unit_name="Dollar",                # Optional[str]
    cent_name="Cent",                  # Optional[str]
    scale=100,                         # i32
    base_conv_rate=Money(v1="1.0"),
    symbol="USD",                      # str
    currency_type="Fiat"               # str
)
```

#### Tag
```python
Tag(
    id=TagId(v1=1),
    name="importante"
)
```

#### Category
```python
Category(
    id=CategoryId(v1=1),
    name="Alimentación",
    active=True,
    parent_id=None                     # Optional[CategoryId] - None si es raíz
)
```

#### Payee
```python
Payee(
    id=PayeeId(v1=1),
    name="Supermercado XYZ",
    category_id=5,                     # Optional[i64]
    number=None,                       # Optional[str]
    website="https://example.com",     # Optional[str]
    notes="Supermercado principal",    # Optional[str]
    active=True,
    pattern=None                       # Optional[str]
)
```

#### Account
```python
Account(
    id=AccountId(v1=1),
    name="Cuenta Corriente",
    account_type=AccountType.Checking,
    account_num="123456789",           # Optional[str]
    status=AccountStatus.Open,
    notes="Cuenta principal",          # Optional[str]
    initial_balance=Money(v1="1000.00"),
    currency_id=CurrencyId(v1=1),
    favorite=True
)
```

#### AccountBalance
```python
AccountBalance(
    account_id=AccountId(v1=1),
    initial_balance=Money(v1="1000.00"),
    total_deposits=Money(v1="5000.00"),
    total_withdrawals=Money(v1="3500.00"),
    current_balance=Money(v1="2500.00")
)
```

#### Transaction
```python
Transaction(
    id=TransactionId(v1=1),
    account_id=AccountId(v1=1),
    to_account_id=None,                # Optional[AccountId] - para transfers
    payee_id=PayeeId(v1=5),
    trans_code=TransactionCode.Withdrawal,
    amount=Money(v1="50.00"),
    status=TransactionStatus.None,
    transaction_number=None,           # Optional[str]
    notes="Compras del supermercado",  # Optional[str]
    category_id=CategoryId(v1=10),     # Optional[CategoryId]
    date=MmexDate(v1="2024-01-15"),    # Optional[MmexDate]
    to_amount=None                     # Optional[Money] - para transfers
)
```

#### SplitTransaction
```python
SplitTransaction(
    id=1,                              # i64
    transaction_id=TransactionId(v1=1),
    category_id=CategoryId(v1=10),     # Optional[CategoryId]
    amount=Money(v1="30.00"),
    notes="Parte de la transacción"    # Optional[str]
)
```

#### Asset
```python
Asset(
    id=AssetId(v1=1),
    name="Departamento",
    start_date=MmexDate(v1="2020-01-01"),
    status=AssetStatus.Open,
    currency_id=CurrencyId(v1=1),      # Optional[CurrencyId]
    value_change_mode="Percentage",    # Optional[str] - Percentage, Linear
    value=Money(v1="150000.00"),
    value_change="Appreciates",        # Optional[str] - None, Appreciates, Depreciates
    notes="Departamento en renta",     # Optional[str]
    value_change_rate=0.05,            # f64
    asset_type="Property"              # Optional[str]
)
```

#### Stock
```python
Stock(
    id=StockId(v1=1),
    held_at=1,                         # i64 - referencia a Account
    purchase_date=MmexDate(v1="2024-01-15"),
    name="Apple Inc.",
    symbol="AAPL",                     # Optional[str]
    num_shares=Money(v1="10"),
    purchase_price=Money(v1="150.00"),
    notes="Compra inicial",            # Optional[str]
    current_price=Money(v1="180.00"),
    value=Money(v1="1800.00"),
    commission=Money(v1="5.00")
)
```

#### ScheduledTransaction
```python
ScheduledTransaction(
    id=1,                              # i64
    account_id=AccountId(v1=1),
    to_account_id=None,                # Optional[AccountId]
    payee_id=PayeeId(v1=5),
    trans_code=TransactionCode.Withdrawal,
    amount=Money(v1="100.00"),
    status=TransactionStatus.None,
    transaction_number=None,           # Optional[str]
    notes="Alquiler mensual",          # Optional[str]
    category_id=CategoryId(v1=15),     # Optional[CategoryId]
    trans_date=MmexDate(v1="2024-01-01"),       # Optional[MmexDate]
    next_occurrence_date=MmexDate(v1="2024-02-01"),  # Optional[MmexDate]
    repeats=1,                         # i32 - frecuencia
    num_occurrences=0,                 # i32 - 0 = infinito
    to_trans_amount=None               # Optional[Money]
)
```

## 6. Manejo de Errores

### Excepciones de mmex_lib

| Error | Descripción | Acción MCP |
|-------|-------------|------------|
| `MmexError.Database` | Error de conexión/SQL | INVALID_PARAMS |
| `MmexError.Internal` | Error interno | INTERNAL_ERROR |
| `AccountError.NotFound` | Cuenta no encontrada | INVALID_PARAMS |
| `AccountError.NameRequired` | Nombre requerido | INVALID_PARAMS |
| `CurrencyError.NotFound` | Moneda no encontrada | INVALID_PARAMS |
| `CurrencyError.NameRequired` | Nombre requerido | INVALID_PARAMS |
| `TagError.NotFound` | Tag no encontrado | INVALID_PARAMS |
| `TagError.NameRequired` | Nombre requerido | INVALID_PARAMS |
| `CategoryError.NotFound` | Categoría no encontrada | INVALID_PARAMS |
| `CategoryError.NameRequired` | Nombre requerido | INVALID_PARAMS |
| `PayeeError.NotFound` | Beneficiario no encontrado | INVALID_PARAMS |
| `PayeeError.NameRequired` | Nombre requerido | INVALID_PARAMS |
| `TransactionError.NotFound` | Transacción no encontrada | INVALID_PARAMS |
| `TransactionError.InvalidAmount` | Monto inválido | INVALID_PARAMS |
| `TransactionError.SplitError` | Error en split | INVALID_PARAMS |
| `AssetError.NotFound` | Activo no encontrado | INVALID_PARAMS |
| `StockError.NotFound` | Acción no encontrada | INVALID_PARAMS |
| `ScheduledError.NotFound` | Programada no encontrada | INVALID_PARAMS |

### Formato de Error en MCP

```python
from mcp.types import McpError
from mcp.shared.exceptions import ErrorCodes

raise McpError(
    code=ErrorCodes.INVALID_PARAMS,
    message=f"Account not found: {account_id}"
)
```

## 7. Dependencias

```toml
[project]
dependencies = [
    "mcp[cli]>=1.0.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

Nota: `mmex_lib` se instala como dependencia local desde `../mmex_lib`.

## 8. Punto de Entrada

```python
# src/mmex_mcp/server.py
import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server

from mmex_mcp.tools import register_all_tools

app = Server("mmex-mcp")

register_all_tools(app)

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
```

## 9. Pruebas

```bash
# Probar con mcp inspector
mcp dev src/mmex_mcp/server.py

# Pruebas directas
uv run python -m mmex_mcp.server
```
