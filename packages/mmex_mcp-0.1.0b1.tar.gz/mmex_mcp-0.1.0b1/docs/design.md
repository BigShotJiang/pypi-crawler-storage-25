# Technical Design - MMEX MCP Server

## 1. Connection Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|-----------|
| `MMEX_DB_PATH` | Path to the .mmb file | Optional* |
| `MMEX_DB_KEY` | SQLCipher password | Optional |

*If not defined, `db_path` is mandatory in each tool call.

### Resolution Logic

```
resolved_db_path = tool_call.db_path ?? env.MMEX_DB_PATH
resolved_db_key  = tool_call.db_key  ?? env.MMEX_DB_KEY  ?? None

if resolved_db_path is None:
    raise Error("db_path required")
```

### Singleton Engine

The `MmexEngine` is instantiated once per `(db_path, db_key)` combination and cached for reuse.

```python
class EngineManager:
    _instances: dict[tuple[str, str | None], MmexEngine] = {}
    
    @classmethod
    def get_engine(cls, db_path: str, db_key: str | None) -> MmexEngine:
        key = (db_path, db_key)
        if key not in cls._instances:
            cls._instances[key] = MmexEngine(db_path, db_key)
        return cls._instances[key]
```

## 2. Directory Structure

```
mmex_mcp/
├── pyproject.toml
├── .python-version
├── src/
│   └── mmex_mcp/
│       ├── __init__.py
│       ├── server.py              # Entry point, registers tools
│       ├── config.py              # Configuration from ENV
│       ├── engine.py              # EngineManager (singleton)
│       └── tools/
│           ├── __init__.py        # Exports all tools
│           ├── _base.py           # Common helpers (serialization)
│           ├── support.py         # mmex_support_get_db_version
│           ├── currencies.py      # mmex_currencies_*
│           ├── tags.py            # mmex_tags_*
│           ├── categories.py      # mmex_categories_*
│           ├── payees.py          # mmex_payees_*
│           ├── accounts.py        # mmex_accounts_*
│           ├── assets.py          # mmex_assets_*
│           ├── stocks.py          # mmex_stocks_*
│           ├── transactions.py    # mmex_transactions_*
│           └── scheduled.py       # mmex_scheduled_*
```

## 3. Tool Naming Conventions

### Pattern

```
mmex_{entity}_{action}
```

### Standard CRUD Actions

| Action | Tool | Description |
|--------|------|-------------|
| List | `mmex_{entity}_list` | Get all records |
| Get | `mmex_{entity}_get` | Get by ID |
| Create | `mmex_{entity}_create` | Create new record |
| Update | `mmex_{entity}_update` | Update existing record |
| Delete | `mmex_{entity}_delete` | Delete record |

### Special Actions

| Entity | Tool | Description |
|---------|------|-------------|
| accounts | `mmex_accounts_balance` | Get account balance |
| categories | `mmex_categories_subcategories` | List subcategories |
| transactions | `mmex_transactions_splits` | Get splits |
| transactions | `mmex_transactions_add_split` | Add split |
| transactions | `mmex_transactions_update_split` | Update split |
| transactions | `mmex_transactions_delete_split` | Delete split |
| transactions | `mmex_transactions_tags` | Get transaction tags |
| transactions | `mmex_transactions_link_tag` | Link tag |
| transactions | `mmex_transactions_unlink_tag` | Unlink tag |
| tags | `mmex_tags_for_reference` | Tags by reference |
| tags | `mmex_tags_link` | Link tag to reference |
| tags | `mmex_tags_unlink` | Unlink tag |
| currencies | `mmex_currencies_by_symbol` | Search by symbol |

## 4. Common Parameters

All tools accept these optional parameters:

```python
db_path: str | None = None   # Path to DB (uses ENV if not provided)
db_key: str | None = None    # Password (uses ENV if not provided)
```

## 5. Data Models

### Serialization Approach

**IMPORTANT:** We do not use the `*_json` methods of mmex_lib. Instead:
1. We use methods that return Python objects (`get_all`, `get_by_id`, etc.)
2. We manually convert UniFFI objects to dictionaries for MCP

### Mapping Types Rust → Python → MCP

| Rust | Python (UniFFI) | MCP Schema |
|------|-----------------|------------|
| `i64` | `int` | `number` |
| `String` | `str` | `string` |
| `Option<T>` | `T | None` | `T` (optional) |
| `bool` | `bool` | `boolean` |
| `f64` | `float` | `number` |
| `Money` | `Money(v1=str)` | `string` (decimal as string) |
| `MmexDate` | `MmexDate(v1=str)` | `string` (ISO 8601) |
| `Enum` | Enum class | `string` (enum value) |
| `Record` | Class with attributes | `object` (dict) |

### Serialization Helper

```python
# src/mmex_mcp/tools/_base.py

def serialize(obj) -> Any:
    """Converts UniFFI objects to serializable types for MCP."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    if hasattr(obj, '__dict__'):
        result = {}
        for key, value in obj.__dict__.items():
            result[key] = serialize(value)
        return result
    return str(obj)
```

### Wrapper Types (IDs and values)

These types have a single `v1` field:

```python
AccountId(v1: int)
TransactionId(v1: int)
TagId(v1: int)
PayeeId(v1: int)
CategoryId(v1: int)
CurrencyId(v1: int)
StockId(v1: int)
AssetId(v1: int)
Money(v1: str)        # Decimal as string: "100.50"
MmexDate(v1: str)     # ISO 8601: "2024-01-15"
```

### Enums

#### AccountType
```
Cash, Checking, Term, Investment, CreditCard, Loan, Asset, Shares, Unknown(String)
```

#### AccountStatus
```
Open, Closed, Unknown(String)
```

#### TransactionCode
```
Withdrawal, Deposit, Transfer, Unknown(String)
```

#### TransactionStatus
```
None, Reconciled, Void, FollowUp, Duplicate, Unknown(String)
```

#### AssetStatus
```
Open, Closed, Unknown(String)
```

### Main Structures

#### Currency
```python
Currency(
    id=CurrencyId(v1=1),
    name="US Dollar",
    pfx_symbol="$",                    # Optional[str]
    sfx_symbol=None,                   # Optional[str]
    decimal_point=".",                 # Optional[str]
    group_separator=",",               # Optional[str]
    unit_name="Dollar",                # Optional[str]
    cent_name="Cent",                  # Optional[str]
    scale=100,                         # i32
    base_conv_rate=Money(v1="1.0"),
    symbol="USD",                      # str
    currency_type="Fiat"               # str
)
```

#### Tag
```python
Tag(
    id=TagId(v1=1),
    name="important"
)
```

#### Category
```python
Category(
    id=CategoryId(v1=1),
    name="Food",
    active=True,
    parent_id=None                     # Optional[CategoryId] - None if root
)
```

#### Payee
```python
Payee(
    id=PayeeId(v1=1),
    name="Supermarket XYZ",
    category_id=5,                     # Optional[i64]
    number=None,                       # Optional[str]
    website="https://example.com",     # Optional[str]
    notes="Main supermarket",          # Optional[str]
    active=True,
    pattern=None                       # Optional[str]
)
```

#### Account
```python
Account(
    id=AccountId(v1=1),
    name="Checking Account",
    account_type=AccountType.Checking,
    account_num="123456789",           # Optional[str]
    status=AccountStatus.Open,
    notes="Main account",              # Optional[str]
    initial_balance=Money(v1="1000.00"),
    currency_id=CurrencyId(v1=1),
    favorite=True
)
```

#### AccountBalance
```python
AccountBalance(
    account_id=AccountId(v1=1),
    initial_balance=Money(v1="1000.00"),
    total_deposits=Money(v1="5000.00"),
    total_withdrawals=Money(v1="3500.00"),
    current_balance=Money(v1="2500.00")
)
```

#### Transaction
```python
Transaction(
    id=TransactionId(v1=1),
    account_id=AccountId(v1=1),
    to_account_id=None,                # Optional[AccountId] - for transfers
    payee_id=PayeeId(v1=5),
    trans_code=TransactionCode.Withdrawal,
    amount=Money(v1="50.00"),
    status=TransactionStatus.None,
    transaction_number=None,           # Optional[str]
    notes="Supermarket shopping",      # Optional[str]
    category_id=CategoryId(v1=10),     # Optional[CategoryId]
    date=MmexDate(v1="2024-01-15"),    # Optional[MmexDate]
    to_amount=None                     # Optional[Money] - for transfers
)
```

#### SplitTransaction
```python
SplitTransaction(
    id=1,                              # i64
    transaction_id=TransactionId(v1=1),
    category_id=CategoryId(v1=10),     # Optional[CategoryId]
    amount=Money(v1="30.00"),
    notes="Part of transaction"        # Optional[str]
)
```

#### Asset
```python
Asset(
    id=AssetId(v1=1),
    name="Apartment",
    start_date=MmexDate(v1="2020-01-01"),
    status=AssetStatus.Open,
    currency_id=CurrencyId(v1=1),      # Optional[CurrencyId]
    value_change_mode="Percentage",    # Optional[str] - Percentage, Linear
    value=Money(v1="150000.00"),
    value_change="Appreciates",        # Optional[str] - None, Appreciates, Depreciates
    notes="Rental apartment",          # Optional[str]
    value_change_rate=0.05,            # f64
    asset_type="Property"              # Optional[str]
)
```

#### Stock
```python
Stock(
    id=StockId(v1=1),
    held_at=1,                         # i64 - reference to Account
    purchase_date=MmexDate(v1="2024-01-15"),
    name="Apple Inc.",
    symbol="AAPL",                     # Optional[str]
    num_shares=Money(v1="10"),
    purchase_price=Money(v1="150.00"),
    notes="Initial purchase",          # Optional[str]
    current_price=Money(v1="180.00"),
    value=Money(v1="1800.00"),
    commission=Money(v1="5.00")
)
```

#### ScheduledTransaction
```python
ScheduledTransaction(
    id=1,                              # i64
    account_id=AccountId(v1=1),
    to_account_id=None,                # Optional[AccountId]
    payee_id=PayeeId(v1=5),
    trans_code=TransactionCode.Withdrawal,
    amount=Money(v1="100.00"),
    status=TransactionStatus.None,
    transaction_number=None,           # Optional[str]
    notes="Monthly rent",              # Optional[str]
    category_id=CategoryId(v1=15),     # Optional[CategoryId]
    trans_date=MmexDate(v1="2024-01-01"),       # Optional[MmexDate]
    next_occurrence_date=MmexDate(v1="2024-02-01"),  # Optional[MmexDate]
    repeats=1,                         # i32 - frequency
    num_occurrences=0,                 # i32 - 0 = infinite
    to_trans_amount=None               # Optional[Money]
)
```

## 6. Error Handling

### Exceptions from mmex_lib

| Error | Description | MCP Action |
|-------|-------------|------------|
| `MmexError.Database` | Connection/SQL error | INVALID_PARAMS |
| `MmexError.Internal` | Internal error | INTERNAL_ERROR |
| `AccountError.NotFound` | Account not found | INVALID_PARAMS |
| `AccountError.NameRequired` | Name required | INVALID_PARAMS |
| `CurrencyError.NotFound` | Currency not found | INVALID_PARAMS |
| `CurrencyError.NameRequired` | Name required | INVALID_PARAMS |
| `TagError.NotFound` | Tag not found | INVALID_PARAMS |
| `TagError.NameRequired` | Name required | INVALID_PARAMS |
| `CategoryError.NotFound` | Category not found | INVALID_PARAMS |
| `CategoryError.NameRequired` | Name required | INVALID_PARAMS |
| `PayeeError.NotFound` | Payee not found | INVALID_PARAMS |
| `PayeeError.NameRequired` | Name required | INVALID_PARAMS |
| `TransactionError.NotFound` | Transaction not found | INVALID_PARAMS |
| `TransactionError.InvalidAmount` | Invalid amount | INVALID_PARAMS |
| `TransactionError.SplitError` | Split error | INVALID_PARAMS |
| `AssetError.NotFound` | Asset not found | INVALID_PARAMS |
| `StockError.NotFound` | Stock not found | INVALID_PARAMS |
| `ScheduledError.NotFound` | Scheduled not found | INVALID_PARAMS |

### MCP Error Format

```python
from mcp.types import McpError
from mcp.shared.exceptions import ErrorCodes

raise McpError(
    code=ErrorCodes.INVALID_PARAMS,
    message=f"Account not found: {account_id}"
)
```

## 7. Dependencies

```toml
[project]
dependencies = [
    "mcp[cli]>=1.0.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

Note: `mmex_lib` is installed as a local dependency from `../mmex_lib`.

## 8. Entry Point

```python
# src/mmex_mcp/server.py
import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server

from mmex_mcp.tools import register_all_tools

app = Server("mmex-mcp")

register_all_tools(app)

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
```

## 9. Testing

```bash
# Test with mcp inspector
mcp dev src/mmex_mcp/server.py

# Direct test
uv run python -m mmex_mcp.server
```
