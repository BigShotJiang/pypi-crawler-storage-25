# MMEX MCP Server 🚀

Servidor MCP (Model Context Protocol) para interactuar con bases de datos de Money Manager EX.

## Descripción

Este proyecto expone las funcionalidades de `mmex_lib` (librería Rust con bindings Python) a través del protocolo MCP, permitiendo que asistentes de IA como Claude interactúen con datos financieros de MMEX de forma segura y controlada.

## Arquitectura

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   MCP Client    │────▶│   mmex_mcp      │────▶│   mmex_lib      │
│   (Claude/etc)  │     │   (Python)      │     │   (Rust/Python) │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                │                        │
                                │                        ▼
                                │                 ┌─────────────────┐
                                │                 │   SQLite DB     │
                                │                 │   (.mmb file)   │
                                └────────────────▶└─────────────────┘
```

## Características

- **CRUD completo** para todas las entidades de MMEX
- **Consultas y balances** de cuentas
- **Soporte para bases cifradas** (SQLCipher)
- **Configuración flexible** vía variables de entorno o parámetros
- **60 herramientas** disponibles

## Entidades Soportadas

| Entidad | Descripción | Herramientas |
|---------|-------------|-------|
| Currencies | Monedas y tipos de cambio | 6 |
| Tags | Etiquetas para categorizar | 8 |
| Categories | Categorías y subcategorías | 6 |
| Payees | Beneficiarios | 5 |
| Accounts | Cuentas bancarias | 7 |
| Assets | Activos fijos | 5 |
| Stocks | Acciones y valores | 5 |
| Transactions | Transacciones y desgloses | 12 |
| Scheduled | Transacciones programadas | 5 |
| Support | Metadatos de BD | 1 |

## Requisitos

- Python 3.10+
- `mmex_lib` instalado (desde `../mmex_lib`)
- Base de datos MMEX (.mmb)
- uv package manager

## Instalación

```bash
cd mmex_mcp
uv sync
```

## Configuración

### Variables de Entorno

| Variable | Descripción | Requerido |
|----------|-------------|-----------|
| `MMEX_DB_PATH` | Ruta al archivo .mmb | Opcional* |
| `MMEX_DB_KEY` | Contraseña SQLCipher | Opcional |

*Si no está definido, `db_path` es obligatorio en cada tool call.

## Pruebas

### Usando MCP Inspector (Recomendado)

El MCP Inspector proporciona una interfaz web para probar todas las tools:

```bash
cd mmex_mcp
MMEX_DB_PATH=/path/to/file.mmb uv run mcp dev src/mmex_mcp/server.py
```

Esto:
1. Inicia el servidor MCP
2. Lanza el MCP Inspector web UI
3. Abre tu navegador en `http://localhost:6274`

### Solución de Problemas de Puertos

Si el puerto está en uso:

```bash
# Matar procesos existentes
pkill -f "mcp|inspector|node"

# Esperar un momento
sleep 2

# Intentar de nuevo
MMEX_DB_PATH=/path/to/file.mmb uv run mcp dev src/mmex_mcp/server.py
```

### Ejecución Directa

Para usar con clientes MCP:

```bash
cd mmex_mcp
MMEX_DB_PATH=/path/to/file.mmb uv run mmex-mcp
```

## Uso con Clientes MCP

### Claude Desktop

Agregar a tu config de Claude Desktop (`~/Library/Application Support/Claude/claude_desktop_config.json` en macOS):

```json
{
  "mcpServers": {
    "mmex-mcp": {
      "command": "uv",
      "args": ["--directory", "/path/to/mmex_mcp", "run", "mmex-mcp"],
      "env": {
        "MMEX_DB_PATH": "/path/to/your/database.mmb"
      }
    }
  }
}
```

### Otros Clientes MCP

Para clientes que soportan servidores MCP stdio:

```bash
MMEX_DB_PATH=/path/to/file.mmb uv run mmex-mcp
```

## Comportamiento de Conexión

Las tools aceptan parámetros opcionales `db_path` y `db_key`:

- Si no se proveen → usan variables de entorno `MMEX_DB_PATH` y `MMEX_DB_KEY`
- Si se proveen → tienen prioridad sobre las variables de entorno

Esto permite:
- Configurar una BD por defecto vía ENV
- Conectar a diferentes BDs en cada tool call si es necesario

## Documentación

- [Diseño Técnico](./design_es.md) - Arquitectura, modelos de datos, manejo de errores
- [Plan de Implementación](./implementation-plan_es.md) - Fases, tools por entidad
