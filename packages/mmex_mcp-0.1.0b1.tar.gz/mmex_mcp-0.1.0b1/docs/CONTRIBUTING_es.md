# Guía de Contribución para MMEX MCP 🤝

¡Gracias for your interest in contributing to MMEX MCP! As a bridge project that connects MMEX with AI assistants via MCP, your contributions are fundamental.

## 🏗 Arquitectura y Diseño

The project follows a layered architecture that connects directly to `mmex_lib`:
1. **Engine Layer**: Handles database connections and caching
2. **Tool Layer**: Implements MCP tools for each entity
3. **Serialization**: Converts UniFFI objects to MCP-compatible formats

## 🛠 Proceso de Desarrollo

### 1. Requisitos
- Python 3.10+
- `mmex_lib` installed (from `../mmex_lib`)
- uv package manager

### 2. Flujo de Trabajo
1. **Crea una rama** para tu funcionalidad o corrección: `git checkout -b feat/nueva-funcionalidad`
2. **Escribe código idiomático**: Sigue las convenciones de Python y usa un formateador si es necesario
3. **Pruebas**: Asegúrate de probar tus cambios con el MCP Inspector
4. **Documentación**: Actualiza la documentación relevante si es necesario

### 3. Testing
```bash
# Test con mcp inspector
cd mmex_mcp
MMEX_DB_PATH=/path/to/file.mmb uv run mcp dev src/mmex_mcp/server.py

# Test directo
uv run python -m mmex_mcp.server
```

## 📝 Convenciones de Código

- **Nombramiento**: `snake_case` para funciones/variables, `PascalCase` para clases.
- **Documentación**: Usa docstrings para documentar todas las herramientas.
- **Commits**: Mensajes claros y descriptivos.

## 🚀 Envío de Cambios

1. Asegúrate de que las pruebas pasen correctamente.
2. Asegúrate de que el código esté formateado.
3. Envía tu Pull Request con una descripción detallada de los cambios.

---

Al contribuir, aceptas que tu código estará bajo la misma licencia que el proyecto original.
