# Plan de Implementación - MMEX MCP Server 📝

## Fase 0: Setup Inicial

### Tareas
- [x] Crear `pyproject.toml` con uv
- [x] Crear estructura de directorios
- [x] Implementar `config.py` (lectura de ENV)
- [x] Implementar `engine.py` (EngineManager singleton)
- [x] Implementar `server.py` (entry point básico)
- [x] Crear `tools/__init__.py`
- [x] Crear `tools/_base.py` (helpers de serialización y conexión)

### Archivos Creados
```
mmex_mcp/
├── pyproject.toml
├── .python-version
└── src/mmex_mcp/
    ├── __init__.py
    ├── config.py
    ├── engine.py
    ├── server.py
    └── tools/
        ├── __init__.py
        └── _base.py
```

### tools/_base.py - Contenido

```python
"""Helpers comunes para todas las tools."""

import os
from functools import wraps
from typing import Any, Callable

from mmex_lib import MmexEngine

from mmex_mcp.config import get_db_key, get_db_path


def serialize(obj: Any) -> Any:
    """
    Convierte objetos UniFFI a tipos serializables para MCP.
    
    NO usar los métodos *_json de mmex_lib. Esta función
    maneja la serialización manualmente.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    if hasattr(obj, '__dict__'):
        result = {}
        for key, value in obj.__dict__.items():
            result[key] = serialize(value)
        return result
    if hasattr(obj, 'v1'):
        return {"v1": serialize(obj.v1)}
    return str(obj)


def serialize_enum(obj: Any) -> str:
    """Convierte un enum UniFFI a string."""
    if obj is None:
        return None
    return str(obj)


class EngineManager:
    """Maneja instancias singleton de MmexEngine por (db_path, db_key)."""
    
    _instances: dict[tuple[str, str | None], MmexEngine] = {}
    
    @classmethod
    def get_engine(cls, db_path: str | None, db_key: str | None) -> MmexEngine:
        resolved_path = db_path or get_db_path()
        resolved_key = db_key if db_key is not None else get_db_key()
        
        if resolved_path is None:
            raise ValueError("db_path is required (set MMEX_DB_PATH or pass db_path parameter)")
        
        key = (resolved_path, resolved_key)
        if key not in cls._instances:
            cls._instances[key] = MmexEngine(resolved_path, resolved_key)
        return cls._instances[key]
    
    @classmethod
    def clear(cls):
        """Limpia todas las instancias cacheadas."""
        cls._instances.clear()


def with_engine(func: Callable) -> Callable:
    """
    Decorador que inyecta el engine resuelto a la función.
    
    La función decorada debe aceptar db_path y db_key como parámetros.
    """
    @wraps(func)
    def wrapper(db_path: str | None = None, db_key: str | None = None, *args, **kwargs):
        engine = EngineManager.get_engine(db_path, db_key)
        return func(engine, *args, **kwargs)
    return wrapper
```

### config.py - Contenido

```python
"""Configuración desde variables de entorno."""

import os


def get_db_path() -> str | None:
    """Obtiene la ruta de la DB desde MMEX_DB_PATH."""
    return os.environ.get("MMEX_DB_PATH")


def get_db_key() -> str | None:
    """Obtiene la clave de cifrado desde MMEX_DB_KEY."""
    return os.environ.get("MMEX_DB_KEY")
```

### Dependencias
- `mcp[cli]>=1.0.0`
- `mmex_lib` (path dependency desde `../mmex_lib`)

---

## Fase 1: Support Tools
- [x] `mmex_support_get_db_version`: Obtiene versión del esquema.

---

## Fase 2: Currencies
- [x] Herramientas CRUD para monedas.
- [x] Búsqueda por símbolo.

---

## Fase 3: Tags
- [x] Herramientas CRUD para etiquetas.
- [x] Herramientas de vinculación/desvinculación.

---

## Fase 4: Categories
- [x] Herramientas CRUD para categorías.
- [x] Listado de subcategorías.

---

## Fase 5: Payees
- [x] Herramientas CRUD para beneficiarios.

---

## Fase 6: Accounts
- [x] Herramientas CRUD para cuentas.
- [x] Herramienta de balance de cuenta.

---

## Fase 7: Assets
- [x] Herramientas CRUD para activos.

---

## Fase 8: Stocks
- [x] Herramientas CRUD para acciones.

---

## Fase 9: Transactions
- [x] Herramientas CRUD para transacciones.
- [x] Gestión de desgloses (add/update/delete/list).
- [x] Vinculación/desvinculación de tags para transacciones.

---

## Fase 10: Scheduled Transactions
- [x] Herramientas CRUD para transacciones programadas.

---

## Resumen de Dependencias

```
Fase 0: Setup
   │
   ├──▶ Fase 1: Support (0 deps)
   │
   ├──▶ Fase 2: Currencies (0 deps) ──┬──▶ Fase 6: Accounts
   │                                   ├──▶ Fase 7: Assets
   │                                   │
   ├──▶ Fase 3: Tags (0 deps) ────────┼──▶ Fase 9: Transactions
   │                                   │
   ├──▶ Fase 4: Categories (0 deps) ──┼──▶ Fase 5: Payees
   │                                   │
   │                                   └──▶ Fase 10: Scheduled
   │
   └──▶ Fase 8: Stocks (Accounts)
```

## Comandos Útiles

```bash
# Inicializar proyecto
cd mmex_mcp
uv init

# Agregar dependencias
uv add "mcp[cli]"

# Agregar mmex_lib como dependencia local
uv add ../mmex_lib

# Ejecutar servidor
uv run mmex-mcp

# Probar con inspector
mcp dev src/mmex_mcp/server.py

# Instalar en Claude Desktop
mcp install src/mmex_mcp/server.py
```
