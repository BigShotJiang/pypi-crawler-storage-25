# Implementation Plan - MMEX MCP Server

## Phase 0: Initial Setup

### Tasks
- [x] Create `pyproject.toml` with uv
- [x] Create directory structure
- [x] Implement `config.py` (read ENV)
- [x] Implement `engine.py` (EngineManager singleton)
- [x] Implement `server.py` (basic entry point)
- [x] Create `tools/__init__.py`
- [x] Create `tools/_base.py` (serialization and connection helpers)

### Files to Create
```
mmex_mcp/
├── pyproject.toml
├── .python-version
└── src/mmex_mcp/
    ├── __init__.py
    ├── config.py
    ├── engine.py
    ├── server.py
    └── tools/
        ├── __init__.py
        └── _base.py
```

### tools/_base.py - Content

```python
"""Common helpers for all tools."""

import os
from functools import wraps
from typing import Any, Callable

from mmex_lib import MmexEngine

from mmex_mcp.config import get_db_key, get_db_path


def serialize(obj: Any) -> Any:
    """
    Converts UniFFI objects to serializable types for MCP.
    
    DO NOT use mmex_lib's *_json methods. This function
    handles serialization manually.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    if hasattr(obj, '__dict__'):
        result = {}
        for key, value in obj.__dict__.items():
            result[key] = serialize(value)
        return result
    if hasattr(obj, 'v1'):
        return {"v1": serialize(obj.v1)}
    return str(obj)


def serialize_enum(obj: Any) -> str:
    """Converts a UniFFI enum to string."""
    if obj is None:
        return None
    return str(obj)


class EngineManager:
    """Handles MmexEngine singleton instances by (db_path, db_key)."""
    
    _instances: dict[tuple[str, str | None], MmexEngine] = {}
    
    @classmethod
    def get_engine(cls, db_path: str | None, db_key: str | None) -> MmexEngine:
        resolved_path = db_path or get_db_path()
        resolved_key = db_key if db_key is not None else get_db_key()
        
        if resolved_path is None:
            raise ValueError("db_path is required (set MMEX_DB_PATH or pass db_path parameter)")
        
        key = (resolved_path, resolved_key)
        if key not in cls._instances:
            cls._instances[key] = MmexEngine(resolved_path, resolved_key)
        return cls._instances[key]
    
    @classmethod
    def clear(cls):
        """Clears all cached instances."""
        cls._instances.clear()


def with_engine(func: Callable) -> Callable:
    """
    Decorator that injects the resolved engine into the function.
    
    The decorated function must accept db_path and db_key as parameters.
    """
    @wraps(func)
    def wrapper(db_path: str | None = None, db_key: str | None = None, *args, **kwargs):
        engine = EngineManager.get_engine(db_path, db_key)
        return func(engine, *args, **kwargs)
    return wrapper
```

### config.py - Content

```python
"""Configuration from environment variables."""

import os


def get_db_path() -> str | None:
    """Gets the DB path from MMEX_DB_PATH."""
    return os.environ.get("MMEX_DB_PATH")


def get_db_key() -> str | None:
    """Gets the encryption key from MMEX_DB_KEY."""
    return os.environ.get("MMEX_DB_KEY")
```

### Dependencies
- `mcp[cli]>=1.0.0`
- `mmex_lib` (path dependency from `../mmex_lib`)

---

## Phase 1: Support Tools
- [x] `mmex_support_get_db_version`: Get schema version.

---

## Phase 2: Currencies
- [x] CRUD tools for currencies.
- [x] Search by symbol.

---

## Phase 3: Tags
- [x] CRUD tools for tags.
- [x] Linking/Unlinking tools.

---

## Phase 4: Categories
- [x] CRUD tools for categories.
- [x] Subcategories listing.

---

## Phase 5: Payees
- [x] CRUD tools for payees.

---

## Phase 6: Accounts
- [x] CRUD tools for accounts.
- [x] Account balance tool.

---

## Phase 7: Assets
- [x] CRUD tools for assets.

---

## Phase 8: Stocks
- [x] CRUD tools for stocks.

---

## Phase 9: Transactions
- [x] CRUD tools for transactions.
- [x] Split management (add/update/delete/list).
- [x] Tag linking/unlinking for transactions.

---

## Phase 10: Scheduled Transactions
- [x] CRUD tools for scheduled transactions.

---

## Dependency Summary

```
Phase 0: Setup
   │
   ├──▶ Phase 1: Support (0 deps)
   │
   ├──▶ Phase 2: Currencies (0 deps) ──┬──▶ Phase 6: Accounts
   │                                   ├──▶ Phase 7: Assets
   │                                   │
   ├──▶ Phase 3: Tags (0 deps) ────────┼──▶ Phase 9: Transactions
   │                                   │
   ├──▶ Phase 4: Categories (0 deps) ──┼──▶ Phase 5: Payees
   │                                   │
   │                                   └──▶ Phase 10: Scheduled
   │
   └──▶ Phase 8: Stocks (Accounts)
```

## Useful Commands

```bash
# Initialize project
cd mmex_mcp
uv init

# Add dependencies
uv add "mcp[cli]"

# Add mmex_lib as local dependency
uv add ../mmex_lib

# Run server
uv run mmex-mcp

# Test with inspector
mcp dev src/mmex_mcp/server.py

# Install in Claude Desktop
mcp install src/mmex_mcp/server.py
```
