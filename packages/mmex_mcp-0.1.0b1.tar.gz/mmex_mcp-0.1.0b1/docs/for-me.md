# Personal Notes

The server is working correctly. The command to test with the MCP inspector is:

```bash
cd /home/patriciorios/Proyectos/mmex_workarea/mmex_mcp
MMEX_DB_PATH=/home/patriciorios/Proyectos/mmex_workarea/mmex_lib/cp_of_personal_finance.mmb .venv/bin/mcp dev src/mmex_mcp/server.py
```

This will open the MCP Inspector in your browser where you can test all tools.

**Note:** Make sure ports 6274-6277 are not in use. If they are, kill previous processes:

```bash
pkill -f "mcp\|inspector"
```

---

mmex-mcp MCP error -32000: Connection closed
