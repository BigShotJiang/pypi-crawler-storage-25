# MMEX MCP Server

MCP (Model Context Protocol) Server to interact with Money Manager EX databases.

## Description

This project exposes the functionalities of `mmex_lib` (Rust library with Python bindings) through the MCP protocol, allowing AI assistants like Claude to interact with MMEX financial data securely and in a controlled manner.

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   MCP Client    │────▶│   mmex_mcp      │────▶│   mmex_lib      │
│   (Claude/etc)  │     │   (Python)      │     │   (Rust/Python) │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                │                        │
                                │                        ▼
                                │                 ┌─────────────────┐
                                │                 │   SQLite DB     │
                                │                 │   (.mmb file)   │
                                └────────────────▶└─────────────────┘
```

## Features

- **Full CRUD** for all MMEX entities
- **Account queries and balances**
- **Support for encrypted databases** (SQLCipher)
- **Flexible configuration** via environment variables or parameters
- **60 tools** available

## Supported Entities

| Entity | Description | Tools |
|---------|-------------|-------|
| Currencies | Currencies and exchange rates | 6 |
| Tags | Tags for categorization | 8 |
| Categories | Categories and subcategories | 6 |
| Payees | Payees | 5 |
| Accounts | Bank accounts | 7 |
| Assets | Fixed assets | 5 |
| Stocks | Stocks and shares | 5 |
| Transactions | Transactions and splits | 12 |
| Scheduled | Scheduled transactions | 5 |
| Support | DB metadata | 1 |

## Requirements

- Python 3.10+
- `mmex_lib` installed (from `../mmex_lib`)
- MMEX database (.mmb)
- uv package manager

## Installation

```bash
cd mmex_mcp
uv sync
```

## Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|-----------|
| `MMEX_DB_PATH` | Path to the .mmb file | Optional* |
| `MMEX_DB_KEY` | SQLCipher password | Optional |

*If not defined, `db_path` is mandatory in each tool call.

## Testing

### Using MCP Inspector (Recommended)

The MCP Inspector provides a web interface to test all tools:

```bash
cd mmex_mcp
MMEX_DB_PATH=/path/to/file.mmb uv run mcp dev src/mmex_mcp/server.py
```

This:
1. Starts the MCP server
2. Launches the MCP Inspector web UI
3. Opens your browser at `http://localhost:6274`

### Port Troubleshooting

If the port is in use:

```bash
# Kill existing processes
pkill -f "mcp|inspector|node"

# Wait a moment
sleep 2

# Try again
MMEX_DB_PATH=/path/to/file.mmb uv run mcp dev src/mmex_mcp/server.py
```

### Direct Execution

To use with MCP clients:

```bash
cd mmex_mcp
MMEX_DB_PATH=/path/to/file.mmb uv run mmex-mcp
```

## Using with MCP Clients

### Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "mmex-mcp": {
      "command": "uv",
      "args": ["--directory", "/path/to/mmex_mcp", "run", "mmex-mcp"],
      "env": {
        "MMEX_DB_PATH": "/path/to/your/database.mmb"
      }
    }
  }
}
```

### Other MCP Clients

For clients that support stdio MCP servers:

```bash
MMEX_DB_PATH=/path/to/file.mmb uv run mmex-mcp
```

## Connection Behavior

The tools accept optional `db_path` and `db_key` parameters:

- If not provided → they use `MMEX_DB_PATH` and `MMEX_DB_KEY` environment variables
- If provided → they take precedence over environment variables

This allows:
- Configuring a default DB via ENV
- Connecting to different DBs in each tool call if necessary

## Documentation

- [Technical Design](./design.md) - Architecture, data models, error handling
- [Implementation Plan](./implementation-plan.md) - Phases, tools per entity
