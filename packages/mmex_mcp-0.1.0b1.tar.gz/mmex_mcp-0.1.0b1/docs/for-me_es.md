# Notas Personales 📓

El servidor está funcionando correctamente. El comando para probar con el inspector de MCP es:

```bash
cd /home/patriciorios/Proyectos/mmex_workarea/mmex_mcp
MMEX_DB_PATH=/home/patriciorios/Proyectos/mmex_workarea/mmex_lib/cp_of_personal_finance.mmb .venv/bin/mcp dev src/mmex_mcp/server.py
```

Esto abrirá el MCP Inspector en tu navegador donde podrás probar todas las tools.

**Nota:** Asegúrate de que el puerto 6274-6277 no esté en uso. Si lo está, mata los procesos anteriores:

```bash
pkill -f "mcp\|inspector"
```

---

mmex-mcp MCP error -32000: Connection closed
