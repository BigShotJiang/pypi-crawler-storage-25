# Servidor MCP de MMEX 🚀

Servidor MCP (Model Context Protocol) para Money Manager EX.

---

### 🌐 Documentation in English
All detailed documentation and guides in English are available at:
👉 **[README.md](README.md)**

---

## Requisitos

- Python 3.10+
- Gestor de paquetes `uv`
- `mmex_lib` instalado (desde `../mmex_lib`)
- Un archivo de base de datos de Money Manager EX (.mmb)

## Instalación

```bash
cd mmex_mcp
uv sync
```

## Configuración

Establece la variable de entorno `MMEX_DB_PATH` para que apunte a tu base de datos:

```bash
export MMEX_DB_PATH=/ruta/a/tu/base_de_datos.mmb
```

Para bases de datos cifradas, también establece `MMEX_DB_KEY`:

```bash
export MMEX_DB_KEY=tu_contraseña
```

## Pruebas

### Usando MCP Inspector (Recomendado)

El MCP Inspector proporciona una interfaz web para probar todas las herramientas de forma interactiva:

```bash
cd mmex_mcp
MMEX_DB_PATH=/ruta/al/archivo.mmb uv run mcp dev src/mmex_mcp/server.py
```

Esto:
1. Iniciará el servidor MCP
2. Lanzará la interfaz web de MCP Inspector
3. Abrirá tu navegador en `http://localhost:6274`

**Nota:** Si el puerto está en uso, finaliza los procesos existentes:

```bash
pkill -f "mcp|inspector|node"
```

### Ejecución Directa

Para ejecutar el servidor directamente (para usar con clientes MCP):

```bash
cd mmex_mcp
MMEX_DB_PATH=/ruta/al/archivo.mmb uv run mmex-mcp
```

## Uso con Clientes MCP

### Claude Desktop

Añade lo siguiente a tu configuración de Claude Desktop (`~/Library/Application Support/Claude/claude_desktop_config.json` en macOS):

```json
{
  "mcpServers": {
    "mmex-mcp": {
      "command": "uv",
      "args": ["--directory", "/ruta/a/mmex_mcp", "run", "mmex-mcp"],
      "env": {
        "MMEX_DB_PATH": "/ruta/a/tu/base_de_datos.mmb"
      }
    }
  }
}
```

### Otros Clientes MCP

Para clientes que soportan servidores MCP a través de stdio:

```bash
MMEX_DB_PATH=/ruta/al/archivo.mmb uv run mmex-mcp
```

## Herramientas Disponibles

| Categoría | Herramientas |
|----------|-------|
| **Soporte** | `mmex_support_get_db_version` |
| **Monedas** | `mmex_currencies_list`, `mmex_currencies_get`, `mmex_currencies_by_symbol`, `mmex_currencies_create`, `mmex_currencies_update`, `mmex_currencies_delete` |
| **Etiquetas** | `mmex_tags_list`, `mmex_tags_get`, `mmex_tags_create`, `mmex_tags_update`, `mmex_tags_delete`, `mmex_tags_for_reference`, `mmex_tags_link`, `mmex_tags_unlink` |
| **Categorías** | `mmex_categories_list`, `mmex_categories_get`, `mmex_categories_subcategories`, `mmex_categories_create`, `mmex_categories_update`, `mmex_categories_delete` |
| **Beneficiarios** | `mmex_payees_list`, `mmex_payees_get`, `mmex_payees_create`, `mmex_payees_update`, `mmex_payees_delete` |
| **Cuentas** | `mmex_accounts_list`, `mmex_accounts_get`, `mmex_accounts_balance`, `mmex_accounts_create`, `mmex_accounts_update`, `mmex_accounts_update_partial`, `mmex_accounts_delete` |
| **Activos** | `mmex_assets_list`, `mmex_assets_get`, `mmex_assets_create`, `mmex_assets_update`, `mmex_assets_delete` |
| **Acciones** | `mmex_stocks_list`, `mmex_stocks_get`, `mmex_stocks_create`, `mmex_stocks_update`, `mmex_stocks_delete` |
| **Transacciones** | `mmex_transactions_list`, `mmex_transactions_get`, `mmex_transactions_create`, `mmex_transactions_update`, `mmex_transactions_delete`, `mmex_transactions_splits`, `mmex_transactions_add_split`, `mmex_transactions_update_split`, `mmex_transactions_delete_split`, `mmex_transactions_tags`, `mmex_transactions_link_tag`, `mmex_transactions_unlink_tag` |
| **Programadas** | `mmex_scheduled_list`, `mmex_scheduled_get`, `mmex_scheduled_create`, `mmex_scheduled_update`, `mmex_scheduled_delete` |

**Total: 60 herramientas**

## Documentación

Consulta [docs/](docs/) para obtener documentación detallada:
- [docs/README.md](docs/README.md) - Overview (English)
- [docs/design.md](docs/design.md) - Technical Design (English)
- [docs/implementation-plan.md](docs/implementation-plan.md) - Implementation Plan (English)
- [docs/README_es.md](docs/README_es.md) - Visión General (Español)
- [docs/design_es.md](docs/design_es.md) - Diseño Técnico (Español)
- [docs/implementation-plan_es.md](docs/implementation-plan_es.md) - Plan de Implementación (Español)
- [docs/for-me_es.md](docs/for-me_es.md) - Notas Personales y Comandos Útiles (Español)
