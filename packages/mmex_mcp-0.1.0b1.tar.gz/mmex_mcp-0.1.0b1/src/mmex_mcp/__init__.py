"""MMEX MCP Server - Model Context Protocol server for Money Manager EX."""

__version__ = "0.1.0b1"
