"""Engine manager for MmexEngine singleton instances."""

from mmex_lib import MmexEngine

from mmex_mcp.config import get_db_key, get_db_path


class EngineManager:
    """Manages singleton instances of MmexEngine per (db_path, db_key) combination."""

    _instances: dict[tuple[str, str | None], MmexEngine] = {}

    @classmethod
    def get_engine(
        cls, db_path: str | None = None, db_key: str | None = None
    ) -> MmexEngine:
        """
        Get or create an MmexEngine instance.

        Resolution order:
        1. Use provided db_path/db_key if given
        2. Fall back to environment variables MMEX_DB_PATH/MMEX_DB_KEY

        Args:
            db_path: Path to the .mmb database file
            db_key: Optional encryption key for SQLCipher databases

        Returns:
            MmexEngine instance

        Raises:
            ValueError: If no db_path is available (neither parameter nor env var)
        """
        resolved_path = db_path or get_db_path()
        resolved_key = db_key if db_key is not None else get_db_key()

        if resolved_path is None:
            raise ValueError(
                "db_path is required. Set MMEX_DB_PATH environment variable "
                "or pass db_path parameter."
            )

        key = (resolved_path, resolved_key)
        if key not in cls._instances:
            cls._instances[key] = MmexEngine(resolved_path, resolved_key)
        return cls._instances[key]

    @classmethod
    def clear(cls) -> None:
        """Clear all cached engine instances."""
        cls._instances.clear()
