"""Configuration from environment variables."""

import os


def get_db_path() -> str | None:
    """Get database path from MMEX_DB_PATH environment variable."""
    return os.environ.get("MMEX_DB_PATH")


def get_db_key() -> str | None:
    """Get encryption key from MMEX_DB_KEY environment variable."""
    return os.environ.get("MMEX_DB_KEY")
