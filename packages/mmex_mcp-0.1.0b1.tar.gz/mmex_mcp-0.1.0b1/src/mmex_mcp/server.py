"""MCP Server entry point for MMEX."""

import logging

from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastMCP("mmex-mcp")


from mmex_mcp.tools import register_all_tools

register_all_tools(app)


def main() -> None:
    """Main entry point."""
    app.run()


if __name__ == "__main__":
    main()
