"""Currency tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import Currency, CurrencyId, Money, CurrencyUpdate


def register(app: FastMCP) -> None:
    """Register currency tools with the FastMCP server."""

    @app.tool()
    def mmex_currencies_list(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """List all currencies in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        currencies = engine.currencies().get_all()
        return str(serialize(currencies))

    @app.tool()
    def mmex_currencies_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a currency by its ID.

        Args:
            id: The currency ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.currencies().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_currencies_by_symbol(
        symbol: str, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a currency by its symbol (e.g., USD, EUR).

        Args:
            symbol: The currency symbol (e.g., USD, EUR).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.currencies().get_by_symbol(symbol)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_currencies_create(
        name: str,
        symbol: str,
        pfx_symbol: str | None = None,
        sfx_symbol: str | None = None,
        decimal_point: str | None = None,
        group_separator: str | None = None,
        unit_name: str | None = None,
        cent_name: str | None = None,
        scale: int = 100,
        base_conv_rate: str = "1.0",
        currency_type: str = "Fiat",
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new currency in the MMEX database.

        Args:
            name: Currency name (e.g., US Dollar).
            symbol: Currency symbol (e.g., USD).
            pfx_symbol: Prefix symbol (e.g., $).
            sfx_symbol: Suffix symbol.
            decimal_point: Decimal separator (e.g., .).
            group_separator: Group separator (e.g., ,).
            unit_name: Name of the main unit (e.g., Dollar).
            cent_name: Name of the fractional unit (e.g., Cent).
            scale: Number of fractional units per main unit (e.g., 100).
            base_conv_rate: Base conversion rate as decimal string (e.g., 1.0).
            currency_type: Type of currency (Fiat or Crypto).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        currency = Currency(
            id=CurrencyId(v1=0),
            name=name,
            pfx_symbol=pfx_symbol,
            sfx_symbol=sfx_symbol,
            decimal_point=decimal_point,
            group_separator=group_separator,
            unit_name=unit_name,
            cent_name=cent_name,
            scale=scale,
            base_conv_rate=Money(v1=base_conv_rate),
            symbol=symbol,
            currency_type=currency_type,
        )
        result = engine.currencies().create(currency)
        return str(serialize(result))

    @app.tool()
    def mmex_currencies_update(
        id: int,
        name: str | None = None,
        symbol: str | None = None,
        pfx_symbol: str | None = None,
        sfx_symbol: str | None = None,
        decimal_point: str | None = None,
        group_separator: str | None = None,
        unit_name: str | None = None,
        cent_name: str | None = None,
        scale: int | None = None,
        base_conv_rate: str | None = None,
        currency_type: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing currency in the MMEX database.

        Args:
            id: The currency ID to update.
            name: Currency name.
            symbol: Currency symbol.
            pfx_symbol: Prefix symbol.
            sfx_symbol: Suffix symbol.
            decimal_point: Decimal separator.
            group_separator: Group separator.
            unit_name: Name of the main unit.
            cent_name: Name of the fractional unit.
            scale: Number of fractional units per main unit.
            base_conv_rate: Base conversion rate.
            currency_type: Type of currency.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        currency = Currency(
            id=CurrencyId(v1=id),
            name=name or "",
            pfx_symbol=pfx_symbol,
            sfx_symbol=sfx_symbol,
            decimal_point=decimal_point,
            group_separator=group_separator,
            unit_name=unit_name,
            cent_name=cent_name,
            scale=scale if scale is not None else 100,
            base_conv_rate=Money(v1=base_conv_rate or "1.0"),
            symbol=symbol or "",
            currency_type=currency_type or "Fiat",
        )
        engine.currencies().update(currency)
        return "true"

    @app.tool()
    def mmex_currencies_update_partial(
        id: int,
        name: str | None = None,
        symbol: str | None = None,
        pfx_symbol: str | None = None,
        sfx_symbol: str | None = None,
        decimal_point: str | None = None,
        group_separator: str | None = None,
        unit_name: str | None = None,
        cent_name: str | None = None,
        scale: int | None = None,
        base_conv_rate: str | None = None,
        currency_type: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing currency in the MMEX database partially.

        Args:
            id: The currency ID to update.
            name: Currency name.
            symbol: Currency symbol.
            pfx_symbol: Prefix symbol.
            sfx_symbol: Suffix symbol.
            decimal_point: Decimal separator.
            group_separator: Group separator.
            unit_name: Name of the main unit.
            cent_name: Name of the fractional unit.
            scale: Number of fractional units per main unit.
            base_conv_rate: Base conversion rate.
            currency_type: Type of currency.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = CurrencyUpdate(
            name=name,
            pfx_symbol=pfx_symbol,
            sfx_symbol=sfx_symbol,
            decimal_point=decimal_point,
            group_separator=group_separator,
            unit_name=unit_name,
            cent_name=cent_name,
            scale=scale,
            base_conv_rate=Money(v1=base_conv_rate) if base_conv_rate else None,
            symbol=symbol,
            currency_type=currency_type,
        )
        engine.currencies().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_currencies_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a currency from the MMEX database.

        Args:
            id: The currency ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.currencies().delete(id)
        return "true"
