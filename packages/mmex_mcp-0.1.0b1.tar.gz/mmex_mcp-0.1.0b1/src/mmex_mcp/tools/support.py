"""Support tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager


def register(app: FastMCP) -> None:
    """Register support tools with the FastMCP server."""

    @app.tool()
    def mmex_support_get_db_version(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get the database schema version of the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        return engine.support().get_db_version()
