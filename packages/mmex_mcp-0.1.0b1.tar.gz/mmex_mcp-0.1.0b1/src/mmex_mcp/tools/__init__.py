"""MMEX MCP Tools package."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.tools import support
from mmex_mcp.tools import currencies
from mmex_mcp.tools import tags
from mmex_mcp.tools import categories
from mmex_mcp.tools import payees
from mmex_mcp.tools import accounts
from mmex_mcp.tools import assets
from mmex_mcp.tools import stocks
from mmex_mcp.tools import transactions
from mmex_mcp.tools import scheduled

__all__ = ["register_all_tools"]


def register_all_tools(app: FastMCP) -> None:
    """Register all tools with the FastMCP server."""
    support.register(app)
    currencies.register(app)
    tags.register(app)
    categories.register(app)
    payees.register(app)
    accounts.register(app)
    assets.register(app)
    stocks.register(app)
    transactions.register(app)
    scheduled.register(app)
