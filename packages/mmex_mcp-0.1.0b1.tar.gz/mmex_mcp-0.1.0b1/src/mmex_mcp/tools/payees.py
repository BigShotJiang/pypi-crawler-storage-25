"""Payee tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import Payee, PayeeId, PayeeUpdate


def register(app: FastMCP) -> None:
    """Register payee tools with the FastMCP server."""

    @app.tool()
    def mmex_payees_list(db_path: str | None = None, db_key: str | None = None) -> str:
        """List all payees in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        payees = engine.payees().get_all()
        return str(serialize(payees))

    @app.tool()
    def mmex_payees_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a payee by its ID.

        Args:
            id: The payee ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.payees().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_payees_create(
        name: str,
        category_id: int | None = None,
        number: str | None = None,
        website: str | None = None,
        notes: str | None = None,
        active: bool = True,
        pattern: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new payee in the MMEX database.

        Args:
            name: The payee name.
            category_id: Default category ID.
            number: Payee number/reference.
            website: Payee website.
            notes: Notes about the payee.
            active: Whether the payee is active.
            pattern: Pattern for auto-categorization.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        payee = Payee(
            id=PayeeId(v1=0),
            name=name,
            category_id=category_id,
            number=number,
            website=website,
            notes=notes,
            active=active,
            pattern=pattern,
        )
        result = engine.payees().create(payee)
        return str(serialize(result))

    @app.tool()
    def mmex_payees_update(
        id: int,
        name: str | None = None,
        category_id: int | None = None,
        number: str | None = None,
        website: str | None = None,
        notes: str | None = None,
        active: bool | None = None,
        pattern: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing payee.

        Args:
            id: The payee ID.
            name: The payee name.
            category_id: Default category ID.
            number: Payee number/reference.
            website: Payee website.
            notes: Notes about the payee.
            active: Whether the payee is active.
            pattern: Pattern for auto-categorization.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        payee = Payee(
            id=PayeeId(v1=id),
            name=name or "",
            category_id=category_id,
            number=number,
            website=website,
            notes=notes,
            active=active if active is not None else True,
            pattern=pattern,
        )
        engine.payees().update(payee)
        return "true"

    @app.tool()
    def mmex_payees_update_partial(
        id: int,
        name: str | None = None,
        category_id: int | None = None,
        number: str | None = None,
        website: str | None = None,
        notes: str | None = None,
        active: bool | None = None,
        pattern: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing payee partially.

        Args:
            id: The payee ID.
            name: The payee name.
            category_id: Default category ID.
            number: Payee number/reference.
            website: Payee website.
            notes: Notes about the payee.
            active: Whether the payee is active.
            pattern: Pattern for auto-categorization.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = PayeeUpdate(
            name=name,
            category_id=category_id,
            number=number,
            website=website,
            notes=notes,
            active=active,
            pattern=pattern,
        )
        engine.payees().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_payees_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a payee from the MMEX database.

        Args:
            id: The payee ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.payees().delete(id)
        return "true"
