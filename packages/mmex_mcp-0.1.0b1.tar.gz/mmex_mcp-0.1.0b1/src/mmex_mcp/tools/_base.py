"""Common helpers for all tools."""

from typing import Any


def serialize(obj: Any) -> Any:
    """
    Convert UniFFI objects to MCP-serializable types.

    Does NOT use the *_json methods from mmex_lib.
    Handles serialization manually for full control.

    Args:
        obj: Any object to serialize

    Returns:
        JSON-serializable representation
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    if isinstance(obj, dict):
        return {key: serialize(value) for key, value in obj.items()}
    if hasattr(obj, "__dict__"):
        result = {}
        for key, value in obj.__dict__.items():
            result[key] = serialize(value)
        return result
    if hasattr(obj, "v1"):
        return {"v1": serialize(obj.v1)}
    return str(obj)
