"""Asset tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import (
    Asset,
    AssetId,
    AssetStatus,
    CurrencyId,
    MmexDate,
    Money,
    AssetUpdate,
)


def _parse_asset_status(value: str | None) -> AssetStatus | None:
    if value is None:
        return None
    return AssetStatus.CLOSED() if value == "Closed" else AssetStatus.OPEN()


def register(app: FastMCP) -> None:
    """Register asset tools with the FastMCP server."""

    @app.tool()
    def mmex_assets_list(db_path: str | None = None, db_key: str | None = None) -> str:
        """List all assets in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        assets = engine.assets().get_all()
        return str(serialize(assets))

    @app.tool()
    def mmex_assets_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get an asset by its ID.

        Args:
            id: The asset ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.assets().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_assets_create(
        name: str,
        start_date: str,
        value: str,
        status: str = "Open",
        currency_id: int | None = None,
        value_change_mode: str | None = None,
        value_change: str | None = None,
        notes: str | None = None,
        value_change_rate: float = 0.0,
        asset_type: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new asset in the MMEX database.

        Args:
            name: The asset name.
            start_date: Start date (YYYY-MM-DD).
            value: Asset value as decimal string.
            status: Asset status: Open or Closed.
            currency_id: Currency ID.
            value_change_mode: Value change mode: Percentage or Linear.
            value_change: Value change: None, Appreciates, or Depreciates.
            notes: Notes about the asset.
            value_change_rate: Value change rate.
            asset_type: Asset type (e.g., Property, Automobile).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        asset = Asset(
            id=AssetId(v1=0),
            name=name,
            start_date=MmexDate(v1=start_date),
            status=_parse_asset_status(status),
            currency_id=CurrencyId(v1=currency_id) if currency_id is not None else None,
            value_change_mode=value_change_mode,
            value=Money(v1=value),
            value_change=value_change,
            notes=notes,
            value_change_rate=value_change_rate,
            asset_type=asset_type,
        )
        result = engine.assets().create(asset)
        return str(serialize(result))

    @app.tool()
    def mmex_assets_update(
        id: int,
        name: str | None = None,
        start_date: str | None = None,
        status: str | None = None,
        currency_id: int | None = None,
        value_change_mode: str | None = None,
        value: str | None = None,
        value_change: str | None = None,
        notes: str | None = None,
        value_change_rate: float | None = None,
        asset_type: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing asset.

        Args:
            id: The asset ID.
            name: The asset name.
            start_date: Start date (YYYY-MM-DD).
            status: Asset status.
            currency_id: Currency ID.
            value_change_mode: Value change mode.
            value: Asset value.
            value_change: Value change.
            notes: Notes.
            value_change_rate: Value change rate.
            asset_type: Asset type.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        asset = Asset(
            id=AssetId(v1=id),
            name=name or "",
            start_date=MmexDate(v1=start_date or "1970-01-01"),
            status=_parse_asset_status(status) or AssetStatus.OPEN(),
            currency_id=CurrencyId(v1=currency_id) if currency_id is not None else None,
            value_change_mode=value_change_mode,
            value=Money(v1=value or "0"),
            value_change=value_change,
            notes=notes,
            value_change_rate=value_change_rate
            if value_change_rate is not None
            else 0.0,
            asset_type=asset_type,
        )
        engine.assets().update(asset)
        return "true"

    @app.tool()
    def mmex_assets_update_partial(
        id: int,
        name: str | None = None,
        start_date: str | None = None,
        status: str | None = None,
        currency_id: int | None = None,
        value_change_mode: str | None = None,
        value: str | None = None,
        value_change: str | None = None,
        notes: str | None = None,
        value_change_rate: float | None = None,
        asset_type: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing asset partially.

        Args:
            id: The asset ID.
            name: The asset name.
            start_date: Start date (YYYY-MM-DD).
            status: Asset status.
            currency_id: Currency ID.
            value_change_mode: Value change mode.
            value: Asset value.
            value_change: Value change.
            notes: Notes.
            value_change_rate: Value change rate.
            asset_type: Asset type.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = AssetUpdate(
            name=name,
            start_date=MmexDate(v1=start_date) if start_date else None,
            status=_parse_asset_status(status),
            currency_id=CurrencyId(v1=currency_id) if currency_id is not None else None,
            value_change_mode=value_change_mode,
            value=Money(v1=value) if value else None,
            value_change=value_change,
            notes=notes,
            value_change_rate=value_change_rate,
            asset_type=asset_type,
        )
        engine.assets().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_assets_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete an asset from the MMEX database.

        Args:
            id: The asset ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.assets().delete(id)
        return "true"
