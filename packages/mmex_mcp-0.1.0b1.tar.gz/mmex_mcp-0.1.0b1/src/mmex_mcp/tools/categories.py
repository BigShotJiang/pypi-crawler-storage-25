"""Category tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import Category, CategoryId, CategoryUpdate


def register(app: FastMCP) -> None:
    """Register category tools with the FastMCP server."""

    @app.tool()
    def mmex_categories_list(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """List all categories in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        categories = engine.categories().get_all()
        return str(serialize(categories))

    @app.tool()
    def mmex_categories_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a category by its ID.

        Args:
            id: The category ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.categories().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_categories_subcategories(
        parent_id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get all subcategories of a parent category.

        Args:
            parent_id: The parent category ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.categories().get_subcategories(parent_id)
        return str(serialize(result))

    @app.tool()
    def mmex_categories_create(
        name: str,
        parent_id: int | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new category in the MMEX database.

        Args:
            name: The category name.
            parent_id: Parent category ID (optional for root categories).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.categories().create(name, parent_id)
        return str(serialize(result))

    @app.tool()
    def mmex_categories_update(
        id: int,
        name: str | None = None,
        active: bool | None = None,
        parent_id: int | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing category.

        Args:
            id: The category ID.
            name: The category name.
            active: Whether the category is active.
            parent_id: Parent category ID (null for root).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        category = Category(
            id=CategoryId(v1=id),
            name=name or "",
            active=active if active is not None else True,
            parent_id=CategoryId(v1=parent_id) if parent_id is not None else None,
        )
        engine.categories().update(category)
        return "true"

    @app.tool()
    def mmex_categories_update_partial(
        id: int,
        name: str | None = None,
        active: bool | None = None,
        parent_id: int | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing category partially.

        Args:
            id: The category ID.
            name: The category name.
            active: Whether the category is active.
            parent_id: Parent category ID (null for root).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = CategoryUpdate(
            name=name,
            active=active,
            parent_id=CategoryId(v1=parent_id) if parent_id is not None else None,
        )
        engine.categories().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_categories_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a category from the MMEX database.

        Args:
            id: The category ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.categories().delete(id)
        return "true"
