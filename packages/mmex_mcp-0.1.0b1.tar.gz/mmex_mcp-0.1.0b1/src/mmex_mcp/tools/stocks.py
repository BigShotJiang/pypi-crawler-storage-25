"""Stock tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import Stock, StockId, MmexDate, Money, StockUpdate


def register(app: FastMCP) -> None:
    """Register stock tools with the FastMCP server."""

    @app.tool()
    def mmex_stocks_list(db_path: str | None = None, db_key: str | None = None) -> str:
        """List all stocks in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        stocks = engine.stocks().get_all()
        return str(serialize(stocks))

    @app.tool()
    def mmex_stocks_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a stock by its ID.

        Args:
            id: The stock ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.stocks().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_stocks_create(
        held_at: int,
        purchase_date: str,
        name: str,
        num_shares: str,
        purchase_price: str,
        current_price: str,
        value: str,
        commission: str,
        symbol: str | None = None,
        notes: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new stock in the MMEX database.

        Args:
            held_at: Account ID where the stock is held.
            purchase_date: Purchase date (YYYY-MM-DD).
            name: Stock name.
            num_shares: Number of shares as decimal string.
            purchase_price: Purchase price per share.
            current_price: Current price per share.
            value: Current total value.
            commission: Commission paid.
            symbol: Stock symbol (e.g., AAPL).
            notes: Notes about the stock.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        stock = Stock(
            id=StockId(v1=0),
            held_at=held_at,
            purchase_date=MmexDate(v1=purchase_date),
            name=name,
            symbol=symbol,
            num_shares=Money(v1=num_shares),
            purchase_price=Money(v1=purchase_price),
            notes=notes,
            current_price=Money(v1=current_price),
            value=Money(v1=value),
            commission=Money(v1=commission),
        )
        result = engine.stocks().create(stock)
        return str(serialize(result))

    @app.tool()
    def mmex_stocks_update(
        id: int,
        held_at: int | None = None,
        purchase_date: str | None = None,
        name: str | None = None,
        symbol: str | None = None,
        num_shares: str | None = None,
        purchase_price: str | None = None,
        notes: str | None = None,
        current_price: str | None = None,
        value: str | None = None,
        commission: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing stock.

        Args:
            id: The stock ID.
            held_at: Account ID where the stock is held.
            purchase_date: Purchase date.
            name: Stock name.
            symbol: Stock symbol.
            num_shares: Number of shares.
            purchase_price: Purchase price per share.
            notes: Notes.
            current_price: Current price per share.
            value: Current total value.
            commission: Commission paid.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        stock = Stock(
            id=StockId(v1=id),
            held_at=held_at or 0,
            purchase_date=MmexDate(v1=purchase_date or "1970-01-01"),
            name=name or "",
            symbol=symbol,
            num_shares=Money(v1=num_shares or "0"),
            purchase_price=Money(v1=purchase_price or "0"),
            notes=notes,
            current_price=Money(v1=current_price or "0"),
            value=Money(v1=value or "0"),
            commission=Money(v1=commission or "0"),
        )
        engine.stocks().update(stock)
        return "true"

    @app.tool()
    def mmex_stocks_update_partial(
        id: int,
        held_at: int | None = None,
        purchase_date: str | None = None,
        name: str | None = None,
        symbol: str | None = None,
        num_shares: str | None = None,
        purchase_price: str | None = None,
        notes: str | None = None,
        current_price: str | None = None,
        value: str | None = None,
        commission: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing stock partially.

        Args:
            id: The stock ID.
            held_at: Account ID where the stock is held.
            purchase_date: Purchase date.
            name: Stock name.
            symbol: Stock symbol.
            num_shares: Number of shares.
            purchase_price: Purchase price per share.
            notes: Notes.
            current_price: Current price per share.
            value: Current total value.
            commission: Commission paid.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = StockUpdate(
            held_at=held_at,
            purchase_date=MmexDate(v1=purchase_date) if purchase_date else None,
            name=name,
            symbol=symbol,
            num_shares=Money(v1=num_shares) if num_shares else None,
            purchase_price=Money(v1=purchase_price) if purchase_price else None,
            notes=notes,
            current_price=Money(v1=current_price) if current_price else None,
            value=Money(v1=value) if value else None,
            commission=Money(v1=commission) if commission else None,
        )
        engine.stocks().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_stocks_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a stock from the MMEX database.

        Args:
            id: The stock ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.stocks().delete(id)
        return "true"
