"""Tag tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize


from mmex_lib import TagUpdate, TagId


def register(app: FastMCP) -> None:
    """Register tag tools with the FastMCP server."""

    @app.tool()
    def mmex_tags_list(db_path: str | None = None, db_key: str | None = None) -> str:
        """List all tags in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        tags = engine.tags().get_all()
        return str(serialize(tags))

    @app.tool()
    def mmex_tags_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a tag by its ID.

        Args:
            id: The tag ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.tags().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_tags_create(
        name: str, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Create a new tag in the MMEX database.

        Args:
            name: The tag name.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.tags().create(name)
        return str(serialize(result))

    @app.tool()
    def mmex_tags_update(
        id: int,
        name: str,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update a tag's name.

        Args:
            id: The tag ID to update.
            name: The new tag name.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.tags().update(id, name)
        return "true"

    @app.tool()
    def mmex_tags_update_partial(
        id: int,
        name: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update a tag's name partially.

        Args:
            id: The tag ID to update.
            name: The new tag name.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = TagUpdate(name=name)
        engine.tags().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_tags_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a tag from the MMEX database.

        Args:
            id: The tag ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.tags().delete(id)
        return "true"

    @app.tool()
    def mmex_tags_for_reference(
        ref_type: str,
        ref_id: int,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Get all tags linked to a reference (e.g., a transaction).

        Args:
            ref_type: Reference type (e.g., 'Transaction').
            ref_id: Reference ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        tags = engine.tags().get_for_reference(ref_type, ref_id)
        return str(serialize(tags))

    @app.tool()
    def mmex_tags_link(
        ref_type: str,
        ref_id: int,
        tag_id: int,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Link a tag to a reference (e.g., a transaction).

        Args:
            ref_type: Reference type (e.g., 'Transaction').
            ref_id: Reference ID.
            tag_id: Tag ID to link.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.tags().link_to_reference(ref_type, ref_id, tag_id)
        return "true"

    @app.tool()
    def mmex_tags_unlink(
        ref_type: str,
        ref_id: int,
        tag_id: int,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Unlink a tag from a reference.

        Args:
            ref_type: Reference type (e.g., 'Transaction').
            ref_id: Reference ID.
            tag_id: Tag ID to unlink.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.tags().unlink_from_reference(ref_type, ref_id, tag_id)
        return "true"
