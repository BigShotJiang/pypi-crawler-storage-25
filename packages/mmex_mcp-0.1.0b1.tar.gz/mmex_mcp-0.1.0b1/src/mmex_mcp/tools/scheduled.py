"""Scheduled transaction tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import (
    ScheduledTransaction,
    ScheduledUpdate,
    AccountId,
    PayeeId,
    CategoryId,
    TransactionCode,
    TransactionStatus,
    MmexDate,
    Money,
)

_TRANS_CODE_MAP = {
    "Withdrawal": TransactionCode.WITHDRAWAL(),
    "Deposit": TransactionCode.DEPOSIT(),
    "Transfer": TransactionCode.TRANSFER(),
}

_TRANS_STATUS_MAP = {
    "": TransactionStatus.NONE(),
    "None": TransactionStatus.NONE(),
    "Reconciled": TransactionStatus.RECONCILED(),
    "Void": TransactionStatus.VOID(),
    "Follow up": TransactionStatus.FOLLOW_UP(),
    "Duplicate": TransactionStatus.DUPLICATE(),
}


def _parse_trans_code(value: str | None) -> TransactionCode | None:
    if value is None:
        return None
    return _TRANS_CODE_MAP.get(value, TransactionCode.WITHDRAWAL())


def _parse_trans_status(value: str | None) -> TransactionStatus | None:
    if value is None:
        return None
    return _TRANS_STATUS_MAP.get(value, TransactionStatus.NONE())


def register(app: FastMCP) -> None:
    """Register scheduled transaction tools with the FastMCP server."""

    @app.tool()
    def mmex_scheduled_list(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """List all scheduled transactions in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        scheduled = engine.scheduled().get_all()
        return str(serialize(scheduled))

    @app.tool()
    def mmex_scheduled_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a scheduled transaction by its ID.

        Args:
            id: The scheduled transaction ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.scheduled().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_scheduled_create(
        account_id: int,
        payee_id: int,
        trans_code: str,
        amount: str,
        repeats: int,
        to_account_id: int | None = None,
        status: str = "",
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        trans_date: str | None = None,
        next_occurrence_date: str | None = None,
        num_occurrences: int = 0,
        to_trans_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new scheduled transaction in the MMEX database.

        Args:
            account_id: Account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount as decimal string.
            repeats: Repeat frequency (0=None, 1=Weekly, 2=Bi-Weekly, 3=Monthly, etc.).
            to_account_id: Destination account ID (for transfers).
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number/reference.
            notes: Notes.
            category_id: Category ID.
            trans_date: First transaction date (YYYY-MM-DD).
            next_occurrence_date: Next occurrence date (YYYY-MM-DD).
            num_occurrences: Number of occurrences (0=infinite).
            to_trans_amount: Destination amount (for transfers).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        scheduled = ScheduledTransaction(
            id=0,
            account_id=AccountId(v1=account_id),
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id),
            trans_code=_parse_trans_code(trans_code),
            amount=Money(v1=amount),
            status=_parse_trans_status(status),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            trans_date=MmexDate(v1=trans_date) if trans_date else None,
            next_occurrence_date=MmexDate(v1=next_occurrence_date)
            if next_occurrence_date
            else None,
            repeats=repeats,
            num_occurrences=num_occurrences,
            to_trans_amount=Money(v1=to_trans_amount) if to_trans_amount else None,
        )
        result = engine.scheduled().create(scheduled)
        return str(serialize(result))

    @app.tool()
    def mmex_scheduled_update(
        id: int,
        account_id: int | None = None,
        to_account_id: int | None = None,
        payee_id: int | None = None,
        trans_code: str | None = None,
        amount: str | None = None,
        status: str | None = None,
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        trans_date: str | None = None,
        next_occurrence_date: str | None = None,
        repeats: int | None = None,
        num_occurrences: int | None = None,
        to_trans_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing scheduled transaction.

        Args:
            id: The scheduled transaction ID.
            account_id: Account ID.
            to_account_id: Destination account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount.
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number.
            notes: Notes.
            category_id: Category ID.
            trans_date: First transaction date.
            next_occurrence_date: Next occurrence date.
            repeats: Repeat frequency.
            num_occurrences: Number of occurrences.
            to_trans_amount: Destination amount.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        scheduled = ScheduledTransaction(
            id=id,
            account_id=AccountId(v1=account_id or 0),
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id or 0),
            trans_code=_parse_trans_code(trans_code) or TransactionCode.WITHDRAWAL(),
            amount=Money(v1=amount or "0"),
            status=_parse_trans_status(status) or TransactionStatus.NONE(),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            trans_date=MmexDate(v1=trans_date) if trans_date else None,
            next_occurrence_date=MmexDate(v1=next_occurrence_date)
            if next_occurrence_date
            else None,
            repeats=repeats if repeats is not None else 0,
            num_occurrences=num_occurrences if num_occurrences is not None else 0,
            to_trans_amount=Money(v1=to_trans_amount) if to_trans_amount else None,
        )
        engine.scheduled().update(scheduled)
        return "true"

    @app.tool()
    def mmex_scheduled_update_partial(
        id: int,
        account_id: int | None = None,
        to_account_id: int | None = None,
        payee_id: int | None = None,
        trans_code: str | None = None,
        amount: str | None = None,
        status: str | None = None,
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        trans_date: str | None = None,
        next_occurrence_date: str | None = None,
        repeats: int | None = None,
        num_occurrences: int | None = None,
        to_trans_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing scheduled transaction partially.

        Args:
            id: The scheduled transaction ID.
            account_id: Account ID.
            to_account_id: Destination account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount.
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number.
            notes: Notes.
            category_id: Category ID.
            trans_date: First transaction date.
            next_occurrence_date: Next occurrence date.
            repeats: Repeat frequency.
            num_occurrences: Number of occurrences.
            to_trans_amount: Destination amount.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = ScheduledUpdate(
            account_id=AccountId(v1=account_id) if account_id is not None else None,
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id) if payee_id is not None else None,
            trans_code=_parse_trans_code(trans_code),
            amount=Money(v1=amount) if amount else None,
            status=_parse_trans_status(status),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            trans_date=MmexDate(v1=trans_date) if trans_date else None,
            next_occurrence_date=MmexDate(v1=next_occurrence_date)
            if next_occurrence_date
            else None,
            repeats=repeats,
            num_occurrences=num_occurrences,
            to_trans_amount=Money(v1=to_trans_amount) if to_trans_amount else None,
        )
        engine.scheduled().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_scheduled_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a scheduled transaction from the MMEX database.

        Args:
            id: The scheduled transaction ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.scheduled().delete(id)
        return "true"
