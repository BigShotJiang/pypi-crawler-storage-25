"""Account tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import (
    Account,
    AccountId,
    AccountType,
    AccountStatus,
    CurrencyId,
    Money,
    AccountUpdate,
)


def _parse_account_type(value: str | None) -> AccountType | None:
    if value is None:
        return None
    return _ACCOUNT_TYPE_MAP.get(value, AccountType.CHECKING())


def _parse_account_status(value: str | None) -> AccountStatus | None:
    if value is None:
        return None
    return AccountStatus.CLOSED() if value == "Closed" else AccountStatus.OPEN()


def register(app: FastMCP) -> None:
    """Register account tools with the FastMCP server."""

    @app.tool()
    def mmex_accounts_list(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """List all accounts in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        accounts = engine.accounts().get_all()
        return str(serialize(accounts))

    @app.tool()
    def mmex_accounts_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get an account by its ID.

        Args:
            id: The account ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.accounts().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_accounts_balance(
        account_id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get the balance of an account.

        Args:
            account_id: The account ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.accounts().get_balance(account_id)
        return str(serialize(result))

    @app.tool()
    def mmex_accounts_create(
        name: str,
        currency_id: int,
        account_type: str = "Checking",
        account_num: str | None = None,
        status: str = "Open",
        notes: str | None = None,
        initial_balance: str = "0",
        favorite: bool = False,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new account in the MMEX database.

        Args:
            name: The account name.
            currency_id: Currency ID.
            account_type: Account type: Cash, Checking, Term, Investment, CreditCard, Loan, Asset, Shares.
            account_num: Account number.
            status: Account status: Open or Closed.
            notes: Notes about the account.
            initial_balance: Initial balance as decimal string (e.g., '1000.00').
            favorite: Whether the account is a favorite.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        account = Account(
            id=AccountId(v1=0),
            name=name,
            account_type=_parse_account_type(account_type),
            account_num=account_num,
            status=_parse_account_status(status),
            notes=notes,
            initial_balance=Money(v1=initial_balance),
            currency_id=CurrencyId(v1=currency_id),
            favorite=favorite,
        )
        result = engine.accounts().create(account)
        return str(serialize(result))

    @app.tool()
    def mmex_accounts_update(
        id: int,
        name: str | None = None,
        account_type: str | None = None,
        account_num: str | None = None,
        status: str | None = None,
        notes: str | None = None,
        initial_balance: str | None = None,
        currency_id: int | None = None,
        favorite: bool | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing account.

        Args:
            id: The account ID.
            name: The account name.
            account_type: Account type.
            account_num: Account number.
            status: Account status.
            notes: Notes about the account.
            initial_balance: Initial balance.
            currency_id: Currency ID.
            favorite: Whether the account is a favorite.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        account = Account(
            id=AccountId(v1=id),
            name=name or "",
            account_type=_parse_account_type(account_type) or AccountType.CHECKING(),
            account_num=account_num,
            status=_parse_account_status(status) or AccountStatus.OPEN(),
            notes=notes,
            initial_balance=Money(v1=initial_balance or "0"),
            currency_id=CurrencyId(v1=currency_id or 1),
            favorite=favorite if favorite is not None else False,
        )
        engine.accounts().update(account)
        return "true"

    @app.tool()
    def mmex_accounts_update_partial(
        id: int,
        name: str | None = None,
        account_type: str | None = None,
        account_num: str | None = None,
        status: str | None = None,
        notes: str | None = None,
        initial_balance: str | None = None,
        currency_id: int | None = None,
        favorite: bool | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing account partially.

        Args:
            id: The account ID.
            name: The account name.
            account_type: Account type.
            account_num: Account number.
            status: Account status.
            notes: Notes about the account.
            initial_balance: Initial balance.
            currency_id: Currency ID.
            favorite: Whether the account is a favorite.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = AccountUpdate(
            name=name,
            account_type=_parse_account_type(account_type),
            account_num=account_num,
            status=_parse_account_status(status),
            notes=notes,
            initial_balance=Money(v1=initial_balance) if initial_balance else None,
            currency_id=CurrencyId(v1=currency_id) if currency_id is not None else None,
            favorite=favorite,
        )
        engine.accounts().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_accounts_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete an account from the MMEX database.

        Args:
            id: The account ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.accounts().delete(id)
        return "true"
