"""Transaction tools for MMEX."""

from mcp.server.fastmcp import FastMCP

from mmex_mcp.engine import EngineManager
from mmex_mcp.tools._base import serialize
from mmex_lib import (
    Transaction,
    TransactionId,
    AccountId,
    PayeeId,
    CategoryId,
    TransactionCode,
    TransactionStatus,
    MmexDate,
    Money,
    SplitTransaction,
    TransactionUpdate,
)

_TRANS_CODE_MAP = {
    "Withdrawal": TransactionCode.WITHDRAWAL(),
    "Deposit": TransactionCode.DEPOSIT(),
    "Transfer": TransactionCode.TRANSFER(),
}

_TRANS_STATUS_MAP = {
    "None": TransactionStatus.NONE(),
    "N": TransactionStatus.NONE(),
    "": TransactionStatus.NONE(),
    "Reconciled": TransactionStatus.RECONCILED(),
    "R": TransactionStatus.RECONCILED(),
    "Void": TransactionStatus.VOID(),
    "V": TransactionStatus.VOID(),
    "Follow up": TransactionStatus.FOLLOW_UP(),
    "F": TransactionStatus.FOLLOW_UP(),
    "Duplicate": TransactionStatus.DUPLICATE(),
    "D": TransactionStatus.DUPLICATE(),

}


def _parse_trans_code(value: str | None) -> TransactionCode | None:
    if value is None:
        return None
    return _TRANS_CODE_MAP.get(value, TransactionCode.WITHDRAWAL())


def _parse_trans_status(value: str | None) -> TransactionStatus | None:
    if value is None:
        return None
    return _TRANS_STATUS_MAP.get(value, TransactionStatus.NONE())


def register(app: FastMCP) -> None:
    """Register transaction tools with the FastMCP server."""

    @app.tool()
    def mmex_transactions_list(
        db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """List all transactions in the MMEX database.

        Args:
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        transactions = engine.transactions().get_all()
        return str(serialize(transactions))

    @app.tool()
    def mmex_transactions_get(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get a transaction by its ID.

        Args:
            id: The transaction ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        result = engine.transactions().get_by_id(id)
        return str(serialize(result)) if result else "null"

    @app.tool()
    def mmex_transactions_create(
        account_id: int,
        payee_id: int,
        trans_code: str,
        amount: str,
        to_account_id: int | None = None,
        status: str = "",
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        date: str | None = None,
        to_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Create a new transaction in the MMEX database.

        Args:
            account_id: Account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount as decimal string.
            to_account_id: Destination account ID (for transfers).
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number/reference.
            notes: Notes.
            category_id: Category ID.
            date: Transaction date (YYYY-MM-DD).
            to_amount: Destination amount (for transfers).
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        transaction = Transaction(
            id=TransactionId(v1=0),
            account_id=AccountId(v1=account_id),
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id),
            trans_code=_parse_trans_code(trans_code),
            amount=Money(v1=amount),
            status=_parse_trans_status(status),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            date=MmexDate(v1=date) if date else None,
            to_amount=Money(v1=to_amount) if to_amount else None,
        )
        result = engine.transactions().create(transaction)
        return str(serialize(result))

    @app.tool()
    def mmex_transactions_update(
        id: int,
        account_id: int | None = None,
        to_account_id: int | None = None,
        payee_id: int | None = None,
        trans_code: str | None = None,
        amount: str | None = None,
        status: str | None = None,
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        date: str | None = None,
        to_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing transaction.

        Args:
            id: The transaction ID.
            account_id: Account ID.
            to_account_id: Destination account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount.
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number.
            notes: Notes.
            category_id: Category ID.
            date: Transaction date.
            to_amount: Destination amount.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        transaction = Transaction(
            id=TransactionId(v1=id),
            account_id=AccountId(v1=account_id or 0),
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id or 0),
            trans_code=_parse_trans_code(trans_code) or TransactionCode.WITHDRAWAL(),
            amount=Money(v1=amount or "0"),
            status=_parse_trans_status(status) or TransactionStatus.NONE(),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            date=MmexDate(v1=date) if date else None,
            to_amount=Money(v1=to_amount) if to_amount else None,
        )
        engine.transactions().update(transaction)
        return "true"

    @app.tool()
    def mmex_transactions_update_partial(
        id: int,
        account_id: int | None = None,
        to_account_id: int | None = None,
        payee_id: int | None = None,
        trans_code: str | None = None,
        amount: str | None = None,
        status: str | None = None,
        transaction_number: str | None = None,
        notes: str | None = None,
        category_id: int | None = None,
        date: str | None = None,
        to_amount: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing transaction partially.

        Args:
            id: The transaction ID.
            account_id: Account ID.
            to_account_id: Destination account ID.
            payee_id: Payee ID.
            trans_code: Transaction type. Valid values: "Withdrawal", "Deposit", "Transfer".
            amount: Amount.
            status: Transaction status. Valid values: "" (None), "Reconciled", "Void", "Follow up", "Duplicate".
            transaction_number: Transaction number.
            notes: Notes.
            category_id: Category ID.
            date: Transaction date.
            to_amount: Destination amount.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        update = TransactionUpdate(
            account_id=AccountId(v1=account_id) if account_id is not None else None,
            to_account_id=AccountId(v1=to_account_id)
            if to_account_id is not None
            else None,
            payee_id=PayeeId(v1=payee_id) if payee_id is not None else None,
            trans_code=_parse_trans_code(trans_code),
            amount=Money(v1=amount) if amount else None,
            status=_parse_trans_status(status),
            transaction_number=transaction_number,
            notes=notes,
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            date=MmexDate(v1=date) if date else None,
            to_amount=Money(v1=to_amount) if to_amount else None,
        )
        engine.transactions().update_partial(id, update)
        return "true"

    @app.tool()
    def mmex_transactions_delete(
        id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a transaction from the MMEX database.

        Args:
            id: The transaction ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.transactions().delete(id)
        return "true"

    @app.tool()
    def mmex_transactions_splits(
        transaction_id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get all splits for a transaction.

        Args:
            transaction_id: The transaction ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        splits = engine.transactions().get_splits(transaction_id)
        return str(serialize(splits))

    @app.tool()
    def mmex_transactions_add_split(
        transaction_id: int,
        amount: str,
        category_id: int | None = None,
        notes: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Add a split to a transaction.

        Args:
            transaction_id: Transaction ID.
            amount: Split amount.
            category_id: Category ID.
            notes: Notes.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        split = SplitTransaction(
            id=0,
            transaction_id=TransactionId(v1=transaction_id),
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            amount=Money(v1=amount),
            notes=notes,
        )
        result = engine.transactions().add_split(split)
        return str(serialize(result))

    @app.tool()
    def mmex_transactions_update_split(
        split_id: int,
        transaction_id: int,
        amount: str,
        category_id: int | None = None,
        notes: str | None = None,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Update an existing split.

        Args:
            split_id: Split ID.
            transaction_id: Transaction ID.
            amount: Split amount.
            category_id: Category ID.
            notes: Notes.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        split = SplitTransaction(
            id=split_id,
            transaction_id=TransactionId(v1=transaction_id),
            category_id=CategoryId(v1=category_id) if category_id is not None else None,
            amount=Money(v1=amount),
            notes=notes,
        )
        engine.transactions().update_split(split)
        return "true"

    @app.tool()
    def mmex_transactions_delete_split(
        split_id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Delete a split from a transaction.

        Args:
            split_id: Split ID to delete.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.transactions().delete_split(split_id)
        return "true"

    @app.tool()
    def mmex_transactions_tags(
        transaction_id: int, db_path: str | None = None, db_key: str | None = None
    ) -> str:
        """Get all tags for a transaction.

        Args:
            transaction_id: The transaction ID.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        tags = engine.transactions().get_tags(transaction_id)
        return str(serialize(tags))

    @app.tool()
    def mmex_transactions_link_tag(
        transaction_id: int,
        tag_id: int,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Link a tag to a transaction.

        Args:
            transaction_id: Transaction ID.
            tag_id: Tag ID to link.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.transactions().link_tag(transaction_id, tag_id)
        return "true"

    @app.tool()
    def mmex_transactions_unlink_tag(
        transaction_id: int,
        tag_id: int,
        db_path: str | None = None,
        db_key: str | None = None,
    ) -> str:
        """Unlink a tag from a transaction.

        Args:
            transaction_id: Transaction ID.
            tag_id: Tag ID to unlink.
            db_path: Path to the .mmb database file. Optional if MMEX_DB_PATH env var is set.
            db_key: Encryption key for SQLCipher databases. Optional if MMEX_DB_KEY env var is set.
        """
        engine = EngineManager.get_engine(db_path, db_key)
        engine.transactions().unlink_tag(transaction_id, tag_id)
        return "true"
