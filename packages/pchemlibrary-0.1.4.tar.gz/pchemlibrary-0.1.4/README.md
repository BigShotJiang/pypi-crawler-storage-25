This is a library of python functions that support Python-language codes for teaching physical chemistry.

# Installation
This has been packaged on PyPI. To install, run
```sh
python -m pip install pchemlibrary
```

# Usage
See examples in the examples folder.
