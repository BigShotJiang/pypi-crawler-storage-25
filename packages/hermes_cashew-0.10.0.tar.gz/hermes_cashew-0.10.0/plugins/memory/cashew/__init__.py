# plugins/memory/cashew/__init__.py
# Source: Pattern mirrored from plugins/memory/hindsight/__init__.py (NousResearch/hermes-agent@main)
from __future__ import annotations

import logging
import os
import pathlib
import queue
import threading  # Phase 4: non-daemon worker for sync_turn drain
from typing import Any, Callable, Dict, List

try:
    from agent.memory_provider import MemoryProvider
except ImportError:
    MemoryProvider = object  # Hermes not installed — allows module to load for discovery/wheel-smoke; is_available() gates real usage

from .config import (
    CashewConfig,
    get_config_schema as _config_get_config_schema,
    get_user_domain,
    get_ai_domain,
    load_config,
    resolve_config_path,
    resolve_db_path,
    save_config as _config_save_config,
)

try:
    from core.context import ContextRetriever
except ImportError:
    # Cashew not installed — plugin still loads (for wheel-smoke + discovery paths).
    # initialize() will silent-degrade if ContextRetriever is unavailable at runtime.
    ContextRetriever = None  # type: ignore[assignment,misc]

from .tools import (
    CASHEW_EXTRACT_SCHEMA,
    CASHEW_QUERY_SCHEMA,
    build_error_envelope,
    build_extract_error_envelope,
    build_extract_success_envelope,
    build_success_envelope,
)

logger = logging.getLogger(__name__)

# Issue #18: sentence-transformers emits INFO-level progress bars and BertModel
# load reports directly to the terminal during embedding. That noise leaks into
# the Hermes UI and looks like broken output. Raise its logger to WARNING once
# at module load so every embed_text / end_session call downstream stays quiet.
# Leaves WARNING/ERROR from sentence_transformers untouched so real failures
# (e.g. model file missing) still surface.
logging.getLogger("sentence_transformers").setLevel(logging.WARNING)


_SHUTDOWN = object()
"""Unique sentinel for graceful sync worker exit.

Compared with `is` (identity), never `==`. Never None — None collides with
legitimate test-code payloads and with Python 3.13's queue.Queue.shutdown()
signal path. See 04-RESEARCH.md §6.4 for rationale.
"""

# ── on_pre_compress prompt template ──────────────────────────────────────────
# Dedicated prompt for forest-level conversation-arc extraction.
# Not a reuse of end_session's prompt — asks about meta-patterns, not content.
PRE_COMPRESS_PROMPT_TEMPLATE = """You are analyzing a conversation about to be compressed.
Your job is to identify the forest-level patterns — signals visible across
multiple turns that no single turn would reveal.

For each signal, produce a JSON object with:
- "type": one of "insight" or "observation" (use insight for non-obvious connections)
- "domain": "{user_domain}" if about the human, "{ai_domain}" if about the system
- "content": standalone statement capturing the cross-turn pattern
- "tags": short descriptive labels (e.g. "communication_style", "topic_shift", "decision")
- "keep": true/false

Look for:
- **Topic arc**: what was this conversation *really* about? Topic shifts vs. deep dives.
- **Framing shifts**: did someone change their stance or framing as the conversation progressed?
- **Implicit decisions**: choices made without explicit deliberation
- **Unstated subjects**: topics conspicuously present in subtext but never named
- **Structural gaps**: what wasn't asked / what was assumed
- **Recurring patterns**: interaction patterns that recurred across multiple exchanges

BAD: "The user asked about X and the assistant explained Y" (turn-level summary)
BAD: "They discussed embeddings" (too vague — what *about* embeddings?)
OK: "Discussion shifted from architecture to cost 3 times — cost is the binding constraint"
GOOD: "User challenges assumptions by asking 'why' before accepting any solution — recurring pattern across topics"

Respond with ONLY a JSON array. No markdown, no explanation, no code fences.

Conversation about to be compressed:
{messages_text}
"""


# ── First-load bootstrap helpers ──────────────────────────────────────


def _ensure_config_file(hermes_home: pathlib.Path) -> None:
    """Write default cashew.json if none exists (first-load bootstrap).

    Uses generate_default_config from config.py which never overwrites
    an existing file. Safe to call on every initialize() — no-op after
    the first run.
    """
    from .config import generate_default_config

    generate_default_config(hermes_home)


def _ensure_auxiliary_memory(hermes_home: pathlib.Path) -> None:
    """Auto-populate auxiliary.memory in Hermes config.yaml if absent.

    When llm_aux_role="memory" is set (the new default) but the user has
    no auxiliary.memory section in their Hermes config.yaml, the plugin
    reads the main model config (provider, model, base_url) and creates an
    auxiliary.memory section with matching settings. This makes LLM-powered
    extraction work out of the box without manual config editing.

    Safe to call repeatedly — only writes when auxiliary.memory is absent
    and the main model config provides usable values. Never overwrites an
    existing auxiliary.memory section.
    """
    config_path = hermes_home / "config.yaml"
    if not config_path.exists():
        return

    try:
        import yaml

        raw = config_path.read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
    except Exception:
        logger.warning(
            "failed to read %s for auxiliary.memory auto-population",
            config_path,
            exc_info=True,
        )
        return

    # Don't touch existing auxiliary.memory config
    aux = data.get("auxiliary", {})
    if "memory" in aux:
        return

    model_section = data.get("model", {})
    provider = model_section.get("provider")
    default_model = model_section.get("default")
    base_url = model_section.get("base_url")

    if not provider or not default_model:
        logger.info(
            "cannot auto-populate auxiliary.memory: "
            "model.provider=%r model.default=%r",
            provider,
            default_model,
        )
        return

    # Build the auxiliary.memory section
    memory_config: dict[str, str | int] = {
        "provider": provider,
        "model": default_model,
    }
    if base_url:
        memory_config["base_url"] = base_url

    if "auxiliary" not in data:
        data["auxiliary"] = {}
    data["auxiliary"]["memory"] = memory_config

    try:
        config_path.write_text(
            yaml.safe_dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        logger.info(
            "auto-populated auxiliary.memory from main model config: "
            "provider=%s model=%s",
            provider,
            default_model,
        )
    except Exception:
        logger.warning(
            "failed to write auxiliary.memory to %s",
            config_path,
            exc_info=True,
        )


# ── on_pre_compress prompt template ──────────────────────────────────
class CashewMemoryProvider(MemoryProvider):
    """Cashew thought-graph memory provider for Hermes Agent."""

    def __init__(self) -> None:
        # Phase 3 — eager lifecycle: constructed in initialize() once _db_path is
        # known, cleared in shutdown(). None during Phase 2 half-state (corrupt
        # config) so prefetch() + handle_tool_call() can short-circuit uniformly.
        self._retriever: "ContextRetriever | None" = None
        # Phase 2 lifecycle state (None until initialize() runs)
        self._hermes_home: pathlib.Path | None = None
        self._config: CashewConfig | None = None
        self._db_path: pathlib.Path | None = None
        self._sync_queue: queue.Queue | None = None
        self._session_id: str = ""
        self._sync_worker: "threading.Thread | None" = None
        # Phase 4: non-daemon worker that drains _sync_queue. Started in
        # initialize() only on happy path (Pitfall 4). Joined in shutdown()
        # with bounded timeout. See 04-RESEARCH.md §§6.5, 6.6.
        self._dropped_turn_count: int = 0
        # Phase 4: monotonic counter of drop-oldest events on the sync queue.
        # Incremented inside sync_turn's overflow branch each time a queued
        # turn is evicted to make room for a new one. Exposed for Plan 04-04's
        # test_burst_default_queue_drops_oldest_cleanly to assert counter
        # matches the WARNING-log count. See B-02 revision in
        # PHASE_DESIGN_NOTES (2026-04-20).
        self._model_fn: Callable[[str], str] | None = None
        # Prefetch warm cache: cue → formatted context string.
        # Populated by queue_prefetch(), consumed by prefetch(), cleared in
        # shutdown(). Ephemeral per-turn state — never persisted.
        self._warm_cache: dict[str, str] = {}
        # Staging slot for background prefetch results. The queue_prefetch
        # background thread writes here; prefetch() atomically swaps it into
        # _warm_cache at the start of its call. This avoids concurrent access
        # between the daemon thread and the main agent loop.
        self._prefetch_pending: str | None = None
        # Last assistant response, buffered from sync_turn for use by
        # queue_prefetch's LLM cue extraction.
        self._last_assistant: str = ""

    @property
    def name(self) -> str:
        return "cashew"

    def is_available(self) -> bool:
        """Return True iff the provider can be initialized.

        Two-path check:
        1. Config file exists under hermes_home (legacy fast path)
        2. Plugin dependencies are importable (first-load path) — if cashew-brain
           was installed successfully, ContextRetriever was set at module import
           time, and initialize() will generate defaults on first run.

        The second path ensures a fresh install shows green in `hermes memory
        status` without requiring manual cashew.json creation.
        """
        # Fast path: config file exists
        if self._hermes_home is not None:
            if resolve_config_path(self._hermes_home).exists():
                return True
        else:
            try:
                from hermes_constants import get_hermes_home  # type: ignore[import-untyped]
                if resolve_config_path(get_hermes_home()).exists():
                    return True
            except Exception:
                pass

        # Fallback: deps are importable — initialize() will generate defaults
        return ContextRetriever is not None

    def get_config_schema(self) -> Dict[str, Any]:
        """Return the JSON-Schema-shaped dict Hermes uses to drive `hermes memory setup` (CONF-01)."""
        return _config_get_config_schema()

    def save_config(self, values: Dict[str, Any], hermes_home: str) -> None:
        """Persist the four-key Cashew config to $HERMES_HOME/cashew.json (CONF-02).

        Delegates to plugins.memory.cashew.config.save_config which merges over
        DEFAULTS, drops unknown keys, and writes UTF-8 / 2-space-indent / sorted-keys
        JSON. The ABC method returns None; we discard the helper's return path.
        """
        _config_save_config(values, hermes_home)

    def initialize(self, session_id: str, **kwargs: Any) -> None:
        """Wire the provider to a hermes_home (ABC-04).

        Reads kwargs["hermes_home"] (KeyError if absent — surfaces actionable
        message because Hermes always passes it; the only way it's missing is a
        test / programmer error). Loads config, resolves DB path, creates the
        bounded sync queue. Does NOT start a worker thread — Phase 4 owns that.
        Does NOT touch the Cashew runtime — Phase 3 owns the ContextRetriever.

        Cashew/load failures degrade silently per PROJECT.md Key Decisions:
        WARNING is logged with exc_info=True and self._config stays None;
        is_available() will still answer correctly because it probes the file
        directly, not self._config.
        """
        if "hermes_home" not in kwargs:
            raise KeyError(
                "CashewMemoryProvider.initialize requires hermes_home in kwargs; "
                "Hermes Agent passes it as a keyword. Got: " + repr(sorted(kwargs.keys()))
            )
        self._session_id = session_id
        self._hermes_home = pathlib.Path(kwargs["hermes_home"])
        # Queue is created here so config-driven sizing/timeout values are wired in.
        # Phase 4 adds the non-daemon worker thread that drains it (see CLAUDE.md ### Threading Rule).
        self._sync_queue = queue.Queue(maxsize=16)
        try:
            self._config = load_config(self._hermes_home)
            # First-load bootstrap: generate default cashew.json and
            # auto-populate auxiliary.memory if absent. Safe to call
            # on every initialize() — no-op after the first run.
            _ensure_config_file(self._hermes_home)
            if self._config.llm_aux_role:
                _ensure_auxiliary_memory(self._hermes_home)
            self._db_path = resolve_db_path(self._hermes_home, self._config.cashew_db_path)
            # Phase 3 eager construction (PHASE_DESIGN_NOTES Decision Point 1).
            # ContextRetriever.__init__ is lazy — no SQLite open, no embedding load yet.
            # Guard against the defensive-import fallback (ContextRetriever = None).
            if ContextRetriever is None:
                raise RuntimeError(
                    "core.context.ContextRetriever unavailable at import time; "
                    "cashew-brain dependency missing"
                )
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            self._ensure_db_schema(self._db_path)
            self._retriever = ContextRetriever(db_path=str(self._db_path))
            self._model_fn = self._build_model_fn()
            # Phase 4: start the sync worker AFTER all worker-read state
            # is populated (db_path, session_id, sync_queue). Pitfall 4.
            self._start_sync_worker()
        except Exception:
            logger.warning(
                "cashew initialize failed at %s; provider will report unavailable until fixed",
                resolve_config_path(self._hermes_home),
                exc_info=True,
            )
            self._config = None
            self._db_path = None
            self._retriever = None
            self._sync_worker = None

    def _start_sync_worker(self) -> None:
        """Launch the non-daemon worker. Called from initialize() only on happy path.

        MUST run AFTER self._db_path / self._session_id / self._sync_queue are set
        (Pitfall 4). daemon=False is load-bearing (PROJECT.md Key Decision).
        """
        self._sync_worker = threading.Thread(
            target=self._worker_loop,
            name=f"cashew-sync-{self._session_id}",
            daemon=True,
        )
        self._sync_worker.start()

    # LLM integration via auxiliary.memory convention
    # ------------------------------------------------------------------

    # Well-known provider-to-env-var mappings for API key resolution.
    # Used when the auxiliary config does not explicitly provide an api_key.
    _PROVIDER_ENV_MAP: dict[str, str] = {
        "openai": "OPENAI_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "opencode-go": "OPENCODE_GO_API_KEY",
        "opencode-zen": "OPENCODE_ZEN_API_KEY",
        "deepseek": "DEEPSEEK_API_KEY",
        "google": "GOOGLE_API_KEY",
        "xai": "XAI_API_KEY",
        "github": "COPILOT_GITHUB_TOKEN",
        "huggingface": "HF_TOKEN",
    }

    def _build_model_fn(self) -> Callable[[str], str] | None:
        """Construct an LLM callable from the configured auxiliary.memory role.

        Reads Hermes' own config.yaml to find the auxiliary.<role> section,
        resolves the API key from config or well-known env vars, and returns
        an OpenAI-compatible callable. Returns None when:
        - No llm_aux_role is configured (heuristic-only mode)
        - The auxiliary section or API key cannot be found (logs warning)
        """
        role = self._config.llm_aux_role if self._config else None
        if not role:
            return None

        config_path = self._hermes_home / "config.yaml" if self._hermes_home else pathlib.Path()
        if not config_path or not config_path.exists():
            logger.info(
                "llm_aux_role=%r but %s not found; falling back to heuristic extraction",
                role, config_path,
            )
            return None

        try:
            import yaml
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            aux_config = (raw or {}).get("auxiliary", {}).get(role, {})
        except Exception:
            logger.warning(
                "llm_aux_role=%r: failed to parse %s; falling back to heuristic extraction",
                role, config_path, exc_info=True,
            )
            return None

        model = aux_config.get("model")
        if not model:
            logger.warning(
                "llm_aux_role=%r: no model in auxiliary.%r config; "
                "falling back to heuristic extraction", role, role,
            )
            return None

        provider = aux_config.get("provider", "openai")
        base_url = aux_config.get("base_url", "https://api.openai.com/v1").rstrip("/")

        # Resolve API key: explicit config > env var by provider convention
        api_key = aux_config.get("api_key")
        if not api_key:
            env_var = self._PROVIDER_ENV_MAP.get(provider)
            if env_var:
                api_key = os.environ.get(env_var)

        if not api_key:
            logger.warning(
                "llm_aux_role=%r: no API key for provider=%r; "
                "falling back to heuristic extraction", role, provider,
            )
            return None

        logger.info(
            "llm_aux_role=%r: using %s %s via %s",
            role, provider, model, base_url,
        )

        def _model_fn(prompt: str) -> str:
            """OpenAI-compatible chat completion callable for upstream cashew-brain."""
            try:
                import httpx
                resp = httpx.post(
                    f"{base_url}/chat/completions",
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": prompt}],
                    },
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=120,
                )
                resp.raise_for_status()
                return resp.json()["choices"][0]["message"]["content"]
            except Exception:
                logger.warning(
                    "LLM call failed for llm_aux_role=%r (model=%s)",
                    role, model, exc_info=True,
                )
                return ""

        return _model_fn

    def sync_turn(self, user_content: str, assistant_content: str, session_id: str = "") -> None:
        """Hot-path enqueue of a completed turn (SYNC-01).

        Contract: returns in <10ms. Never raises. If the queue is full, drops the
        OLDEST queued turn, logs a WARNING, and enqueues the new one (drop-oldest
        policy, 04-RESEARCH.md §6.3). If somehow still full after the drop (rare
        worker-draining race), drops the NEW turn with a second WARNING.

        Half-state (_sync_queue is None) is a silent no-op.
        """
        # Buffer assistant content for queue_prefetch cue extraction.
        # Must happen BEFORE the half-state guard so the most recent turn's
        # assistant content is always available, even if the queue is not.
        if assistant_content:
            self._last_assistant = assistant_content
        if self._sync_queue is None:
            return  # not initialized or silent-degraded; no worker to feed
        turn = (user_content, assistant_content, session_id)
        try:
            self._sync_queue.put_nowait(turn)
        except queue.Full:
            # Drop-oldest (04-RESEARCH.md §6.3 + Pitfall 3).
            try:
                self._sync_queue.get_nowait()
                self._sync_queue.task_done()  # balance the drop (EXACTLY ONCE)
            except queue.Empty:
                pass  # worker drained between Full and get_nowait — rare race; no-op
            self._dropped_turn_count += 1  # per-drop counter — asserted by Plan 04-04 burst test
            logger.warning(
                "cashew sync queue overflow (maxsize=%d); dropped oldest turn",
                self._sync_queue.maxsize,
            )
            try:
                self._sync_queue.put_nowait(turn)
            except queue.Full:
                logger.warning("cashew sync queue still full after drop-oldest; dropping new turn")

    def _worker_loop(self) -> None:
        """Background drain loop. Entry point for self._sync_worker.

        Sentinel check BEFORE try (Pitfall 1 — must not be reachable from the
        exception path). task_done() ALWAYS in finally (Pitfall 2). Per-iteration
        except catches all Cashew failures (SYNC-06) without poisoning the queue.

        Plan 04-04 race fix: binds the queue reference to a local `q` at loop
        entry. If shutdown() times out waiting for this worker, it clears
        `self._sync_queue = None` and abandons the worker. Without this local
        bind, the abandoned worker's `finally: self._sync_queue.task_done()`
        would raise AttributeError on NoneType. Using `q` keeps task_done()
        bound to the queue the worker was actually draining, race-free.
        """
        q = self._sync_queue  # bind once; shutdown may clear self._sync_queue before we exit
        assert q is not None  # invariant: worker only starts when queue exists
        while True:
            item = q.get()
            if item is _SHUTDOWN:
                q.task_done()
                return
            try:
                self._drain_once(item)
            except Exception:
                logger.warning("cashew sync worker: turn failed", exc_info=True)
            finally:
                q.task_done()

    def _ensure_db_schema(self, db_path: pathlib.Path) -> None:
        """Create or migrate Cashew schema tables.

        Delegates to cashew-brain's core.db.ensure_schema() which handles
        upstream table creation (thought_nodes, derivation_edges, embeddings,
        hotspots, metrics), column migrations, index creation, and schema
        version stamping (PRAGMA user_version = 3). Then applies hermes-specific
        extensions (vec_embeddings virtual table for sqlite-vec).
        """
        from core.db import ensure_schema
        ensure_schema(str(db_path))

        import sqlite3
        conn = sqlite3.connect(str(db_path))
        try:
            try:
                conn.enable_load_extension(True)
                try:
                    import sqlite_vec
                    sqlite_vec.load(conn)
                except (ImportError, AttributeError):
                    conn.load_extension("vec0")
            except Exception:
                pass  # sqlite-vec not available; individual callers handle their own fallback
            self._migrate_vec_embeddings(conn)
            self._create_vec_embeddings(conn)
            # Hermes provider metadata store (persistent counters, flags)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS hermes_provider_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def _migrate_vec_embeddings(self, conn: sqlite3.Connection) -> None:
        """Migrate vec_embeddings from old schema (no node_id, no distance_metric)
        to the canonical schema matching upstream cashew-brain v1.1.0.

        Old schema:  USING vec0(embedding float[384])
        New schema:  USING vec0(node_id TEXT primary key, embedding float[384] distance_metric=cosine)

        The old schema caused _retrieve_with_vec to return rowid values that never
        matched thought_nodes.id (SHA hashes), making vec search always return 0.
        """
        try:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='vec_embeddings'"
            )
            if cursor.fetchone() is None:
                return
            has_node_id = False
            try:
                conn.execute("SELECT node_id FROM vec_embeddings LIMIT 1")
                has_node_id = True
            except Exception:
                pass
            if not has_node_id:
                logger.info("Migrating vec_embeddings from old schema (dropping and recreating)")
                conn.execute("DROP TABLE vec_embeddings")
        except Exception:
            logger.info("sqlite-vec not available; skipping vec_embeddings migration")



    def _create_vec_embeddings(self, conn: sqlite3.Connection) -> None:
        try:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='vec_embeddings'"
            )
            if cursor.fetchone() is not None:
                return
            conn.enable_load_extension(True)
            try:
                import sqlite_vec
                sqlite_vec.load(conn)
            except (ImportError, AttributeError):
                conn.load_extension("vec0")
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS vec_embeddings
                USING vec0(node_id TEXT primary key, embedding float[384] distance_metric=cosine)
            """)
            logger.debug("vec_embeddings virtual table ready")
        except Exception:
            logger.info("sqlite-vec not available; semantic search will use fallback")

    def _enrich_results(self, node_ids: list[str]) -> list[dict]:
        """Fetch full node dicts from DB for upstream retrieval results.

        Upstream RetrievalResult carries core fields (id, content, type, domain),
        but Hermes-specific formatting needs permanent flag, tags, referent_time
        etc. Batch-query the DB to get these.
        """
        if not node_ids:
            return []
        import sqlite3
        conn = sqlite3.connect(str(self._db_path))
        try:
            placeholders = ",".join("?" * len(node_ids))
            cursor = conn.execute(
                f"SELECT * FROM thought_nodes WHERE id IN ({placeholders})", node_ids
            )
            rows = cursor.fetchall()
            cols = [col[0] for col in cursor.description]
            return [dict(zip(cols, row)) for row in rows]
        finally:
            conn.close()

    def _format_context(self, nodes: list[dict]) -> str:
        if not nodes:
            return ""
        lines = ["=== RELEVANT CONTEXT ==="]
        for node in nodes:
            domain = node.get("domain")
            node_type = node.get("node_type")
            content = node.get("content", "")
            permanent = node.get("permanent") == 1
            labels = []
            if domain:
                labels.append(f"domain: {domain}")
            if node_type:
                labels.append(f"type: {node_type}")
            if permanent:
                labels.append("permanent")
            if labels:
                prefix = f"[{' | '.join(labels)}]"
                lines.append(f"{prefix} {content}")
            else:
                lines.append(content)
        return "\n".join(lines)

    def _update_access_metrics(self, node_ids: list[str]) -> None:
        if not node_ids:
            return
        try:
            import sqlite3
            conn = sqlite3.connect(str(self._db_path))
            try:
                placeholders = ",".join("?" * len(node_ids))
                conn.execute(
                    f"""
                    UPDATE thought_nodes
                    SET access_count = access_count + 1,
                        last_accessed = CURRENT_TIMESTAMP
                    WHERE id IN ({placeholders})
                    """,
                    node_ids,
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            logger.warning("cashew access metrics update failed", exc_info=True)

    def _drain_once(self, turn: tuple[str, str]) -> None:
        """Persist one turn via Cashew's heuristic extractor (or LLM if configured).

        Lazy-imports core.session so the plugin module loads even when cashew-brain
        is not installed (matches Phase 1 Pattern 3 for agent.memory_provider).
        When self._model_fn is set (via llm_aux_role config), upstream receives
        the LLM callable and can perform LLM extraction, think cycles, and sleep
        synthesis. When None, Cashew's built-in heuristic extractor is used
        (04-RESEARCH.md §§1, 6.2 — no LLM round-trip).

        Retries up to 3 times on SQLITE_BUSY with exponential backoff before
        dropping the turn (SYNC-05)."""
        from core.session import end_session  # lazy import (see 04-RESEARCH.md §9 + test strategy §11)
        user, assistant, session_id = turn

        import sqlite3
        max_retries = 3
        for attempt in range(max_retries):
            try:
                end_session(
                    db_path=str(self._db_path),
                    session_id=session_id or self._session_id,
                    conversation_text=f"User: {user}\nAssistant: {assistant}",
                    model_fn=self._model_fn,
                )
                break  # success
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    wait = 0.5 * (2 ** attempt)
                    logger.info(
                        "cashew sync: database locked, retrying in %.1fs (attempt %d/%d)",
                        wait, attempt + 1, max_retries,
                    )
                    time.sleep(wait)
                else:
                    raise  # give up — let the outer except in _worker_loop handle it
        # Run think cycle periodically if LLM is wired
        if self._model_fn is not None and self._config and self._config.think_interval > 0:
            counter = self._load_think_counter() + 1
            if counter >= self._config.think_interval:
                counter = 0
                try:
                    from core.session import think_cycle
                    result = think_cycle(
                        db_path=str(self._db_path),
                        model_fn=self._model_fn,
                    )
                    if result.new_nodes:
                        logger.info(
                            "think cycle produced %d insight(s) on cluster: %s",
                            len(result.new_nodes),
                            result.cluster_topic or "unknown",
                        )
                except Exception:
                    logger.warning("think cycle failed", exc_info=True)
            self._save_think_counter(counter)

    def _load_think_counter(self) -> int:
        """Read persistent think counter from DB. Resets to 0 on any error."""
        try:
            import sqlite3
            conn = sqlite3.connect(str(self._db_path))
            try:
                row = conn.execute(
                    "SELECT value FROM hermes_provider_meta WHERE key='think_counter'"
                ).fetchone()
                return int(row[0]) if row else 0
            finally:
                conn.close()
        except Exception:
            return 0

    def _save_think_counter(self, value: int) -> None:
        """Write persistent think counter to DB."""
        try:
            import sqlite3
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "INSERT OR REPLACE INTO hermes_provider_meta (key, value) VALUES ('think_counter', ?)",
                    (str(value),),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def on_pre_compress(self, messages: list) -> str:
        """Extract forest-level conversation-arc insights before compression.

        Uses a dedicated LLM prompt (different from end_session's per-turn
        prompt) to identify topic shifts, framing changes, implicit decisions,
        unstated subjects, and recurring patterns that only become visible
        across multiple turns.

        Persists insight/observation nodes to the Cashew graph and returns
        a short summary string for the compressor.

        Silent-degrades to "" when no LLM is wired, insufficient exchanges,
        or any failure (never raises).
        """
        if self._model_fn is None or self._db_path is None:
            return ""

        import json as _json

        exchanges = self._extract_exchanges(messages)
        # Need at least 3 user+assistant exchanges for arc detection
        if len(exchanges) < 6:
            return ""

        # Cap at 20 most recent messages to bound prompt cost
        messages_text = "\n\n".join(exchanges[-20:])

        try:
            user_domain = self._config.user_domain if self._config else "user"
            ai_domain = self._config.ai_domain if self._config else "ai"

            prompt = PRE_COMPRESS_PROMPT_TEMPLATE.format(
                user_domain=user_domain,
                ai_domain=ai_domain,
                messages_text=messages_text,
            )

            response = self._model_fn(prompt)
            if not response or not response.strip():
                return ""

            # Parse JSON — handle markdown code fences (same pattern as end_session)
            cleaned = response.strip()
            if cleaned.startswith("```"):
                start = cleaned.find("[")
                if start == -1:
                    return ""
                end = cleaned.rfind("]")
                if end == -1:
                    return ""
                cleaned = cleaned[start:end + 1]

            items = _json.loads(cleaned)
            if not isinstance(items, list):
                return ""

            # Filter to items marked for retention
            items = [it for it in items if it.get("keep", True)]
            if not items:
                return ""

            # Persist to graph
            created = self._create_insight_nodes(items)
            if created == 0:
                return ""

            # Build summary string for compressor
            summaries = []
            for item in items[:3]:
                content = item.get("content", "")
                if content:
                    summaries.append(f"- {content[:200]}")
            if summaries:
                return "Cashew insight extraction:\n" + "\n".join(summaries)
            return ""

        except _json.JSONDecodeError:
            logger.warning("on_pre_compress: failed to parse LLM response", exc_info=True)
            return ""
        except Exception:
            logger.warning("on_pre_compress failed", exc_info=True)
            return ""

    def _extract_exchanges(self, messages: list) -> list[str]:
        """Extract user/assistant text exchanges from OpenAI-format messages.

        Handles multimodal content (list-of-parts format) by extracting only
        text parts. Filters out system and tool messages. Returns a list of
        "role: content" strings in conversation order.
        """
        exchanges: list[str] = []
        for msg in messages:
            role = msg.get("role", "")
            if role not in ("user", "assistant"):
                continue

            content = msg.get("content", "")
            if isinstance(content, list):
                # Multimodal: extract text parts only
                parts: list[str] = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text = part.get("text", "")
                        if text:
                            parts.append(text)
                content = " ".join(parts)

            if isinstance(content, str) and content.strip():
                exchanges.append(f"{role}: {content.strip()}")
        return exchanges

    def _create_insight_nodes(self, items: list[dict]) -> int:
        """Create insight/observation nodes in the Cashew graph.

        Uses upstream _create_node / _set_node_tags for persistence, then
        calls embed_nodes to generate embeddings. Returns node count.

        Silent-degrades: logs warning on failure, never raises.
        """
        from core.session import _create_node, _set_node_tags
        from core.embeddings import embed_nodes

        db_path = str(self._db_path)
        count = 0

        for item in items:
            content = item.get("content", "")
            node_type = item.get("type", "insight")
            domain = item.get("domain", "user")
            tags = item.get("tags", [])

            if not content or not content.strip():
                continue

            try:
                node_id = _create_node(
                    db_path=db_path,
                    content=content.strip(),
                    node_type=node_type,
                    session_id="pre_compress",
                    domain=domain,
                )
                if tags and isinstance(tags, list):
                    _set_node_tags(db_path, node_id, tags)
                count += 1
            except Exception:
                logger.warning("on_pre_compress: failed to create node", exc_info=True)
                continue

        if count > 0:
            try:
                embed_nodes(db_path)
            except Exception:
                logger.warning("on_pre_compress: embedding failed", exc_info=True)

        return count

    def on_session_end(self, messages: list) -> None:
        """Best-effort sleep cycle (ABC-06).

        Does NOT drain the sync queue — the background worker is non-daemon and
        keeps running across session boundaries. WAL mode handles concurrent DB
        writes between the sleep cycle and the worker. Data-loss protection is
        handled by dispose(), which posts a sentinel and bounded-joins the
        worker. This method is advisory; dispose() is authoritative.

        Runs the refactored sleep cycle if configured (sleep_cycles=true, model_fn
        wired).
        """
        if self._sync_queue is None:
            return  # not initialized or silent-degraded

        # Refactored sleep cycle (v0.8.0): runs in ~4s at 7K nodes.
        # Safe to call from lifecycle hooks — bounded by MAX_NODES_PER_CYCLE.
        if (
            self._config is not None
            and self._config.sleep_cycles
            and self._db_path is not None
        ):
            try:
                from .sleep_refactor import run_sleep_cycle
                run_sleep_cycle(
                    db_path=str(self._db_path),
                    limit=2000,
                    model_fn=self._model_fn,
                    background_dream=True,
                )
            except Exception:
                logger.warning("sleep cycle failed", exc_info=True)

    def shutdown(self) -> None:
        """Post sentinel, bounded-join worker, clear references (ABC-05 + SYNC-05).

        Order is load-bearing:
          1. If not initialized, return (Phase 2 safe-no-op carryover).
          2. Post _SHUTDOWN sentinel to the queue. put_nowait first; fallback to
             a 1s blocking put if the queue is full (worker is draining fast).
          3. Bounded-join the worker using sync_queue_timeout. WARNING on timeout.
          4. Clear _sync_queue, _sync_worker, _config, _db_path, _retriever.

        _hermes_home is intentionally NOT reset — is_available() must keep
        reflecting on-disk reality (Phase 2 Success #3).
        """
        if self._sync_queue is None:
            return  # safe no-op: initialize() was never called
        timeout = self._config.sync_queue_timeout if self._config is not None else 30.0
        # Post sentinel. put_nowait first; if somehow full, try a brief blocking put.
        try:
            self._sync_queue.put_nowait(_SHUTDOWN)
        except queue.Full:
            try:
                self._sync_queue.put(_SHUTDOWN, block=True, timeout=1.0)
            except queue.Full:
                logger.warning("cashew shutdown: could not post sentinel; worker may leak")
        # Bounded join. NEVER raise (silent-degrade Key Decision).
        if self._sync_worker is not None:
            self._sync_worker.join(timeout=timeout)
            if self._sync_worker.is_alive():
                logger.warning(
                    "cashew sync worker did not exit within %ss; abandoning",
                    timeout,
                )
        # Clear state. _hermes_home persists (see Phase 2 Plan 02-02 rationale).
        self._sync_queue = None
        self._sync_worker = None
        self._config = None
        self._db_path = None
        self._retriever = None
        self._warm_cache.clear()
        self._prefetch_pending = None
        self._last_assistant = ""
        logger.debug("cashew provider shutdown complete (Phase 4 — worker drained)")

    def prefetch(self, query: str, domain: str | None = None, tag: str | None = None,
                 exclude_tags: list[str] | None = None, **kwargs: Any) -> str:
        """Return recalled-context string from Cashew (RECALL-01).

        Checks the warm cache (populated by queue_prefetch) first. On a cache
        hit, returns the cached context immediately without hitting storage.
        On a cache miss, delegates to upstream cashew-brain's
        retrieve_recursive_bfs for full three-tier retrieval.

        Delegates to upstream cashew-brain's retrieve_recursive_bfs which handles
        the full three-tier retrieval (sqlite-vec semantic search → graph BFS →
        keyword fallback) with hybrid scoring. Hermes-specific fields (permanent
        flag, tags) are enriched from the DB before formatting.

        Falls back to SQL LIKE keyword search when upstream retrieval fails
        (e.g. sqlite-vec or sentence-transformers unavailable in test environment).

        Contract:
        - Half-state guard: if `_config is None`, return `""` without logging.
        - Empty result is valid (returns `""` without logging).
        - Failure path: `except Exception` logs ONE WARNING and returns `""`.
        """
        if self._config is None:
            return ""
        # Atomically swap in any background-prefetched results
        pending = self._prefetch_pending
        if pending is not None:
            self._prefetch_pending = None
            # Store under the raw query so the matching logic below can find it
            self._warm_cache[query] = pending
        # Warm cache fast path: check if a cached cue matches the query.
        if self._warm_cache:
            query_lower = query.lower()
            for cue, ctx in self._warm_cache.items():
                if not cue:
                    continue
                cue_lower = cue.lower()
                if cue_lower in query_lower or query_lower in cue_lower:
                    logger.info("prefetch warm cache HIT: cue=%r query=%r", cue, query)
                    self._warm_cache.clear()
                    return ctx
                cue_words = set(w for w in cue_lower.split() if len(w) > 3)
                query_words = set(w for w in query_lower.split() if len(w) > 3)
                if len(cue_words & query_words) >= 2:
                    logger.info("prefetch warm cache HIT: cue=%r query=%r (word overlap)", cue, query)
                    self._warm_cache.clear()
                    return ctx
            # No match — clear stale cache and fall through to cold retrieval.
            logger.info("prefetch warm cache MISS (%d cue(s) in cache) — falling through to cold retrieval", len(self._warm_cache))
            self._warm_cache.clear()
        max_nodes = self._config.recall_k
        try:
            from core.retrieval import retrieve_recursive_bfs
            results = retrieve_recursive_bfs(
                db_path=str(self._db_path),
                query=query,
                top_k=max_nodes,
                domain=domain,
                tags=[tag] if tag else None,
                exclude_tags=exclude_tags,
            )
            if results:
                node_ids = [r.node_id for r in results]
                self._update_access_metrics(node_ids)
                nodes = self._enrich_results(node_ids)
                return self._format_context(nodes)
        except Exception:
            logger.debug("upstream retrieval failed, falling back to keyword", exc_info=True)
        try:
            nodes = self._keyword_search(query, max_nodes, domain, tag, exclude_tags)
            if nodes:
                self._update_access_metrics([n["id"] for n in nodes])
                return self._format_context(nodes)
        except Exception:
            logger.warning("cashew recall failed for query=%r", query, exc_info=True)
        return ""

    def queue_prefetch(self, query: str, *, session_id: str = "") -> None:
        """Warm cashew memory for the next turn (ABC optional hook).

        Dispatches a background thread so this returns immediately and never
        blocks the user's turn. The thread runs vector search (and optionally
        LLM cue extraction) and populates _warm_cache when done.

        If the background thread hasn't finished before the next prefetch(),
        prefetch falls through to cold storage transparently. Results are
        stored in a staging slot (_prefetch_pending) and swapped atomically
        into _warm_cache at the start of the next prefetch to avoid
        concurrent access between thread and main loop.

        Contract:
        - Half-state guard: if _config is None, return silently.
        - Never blocks — returns in <1ms.
        - Never raises into Hermes (caught in background thread).
        """
        if self._config is None:
            return
        self._prefetch_pending = None  # clear any stale results
        if not query:
            logger.debug("queue_prefetch: empty query, no warmup")
            return

        # Capture the state the thread needs — these are stable after initialize()
        db_path = str(self._db_path)
        top_k = self._config.prefetch_k
        use_llm = self._model_fn is not None and self._config.prefetch_cues > 0

        def _warmup_worker() -> None:
            """Background thread: retrieve + optionally refine with LLM."""
            try:
                # If LLM is available, extract cues for better retrieval
                if use_llm:
                    try:
                        cues = self._extract_prefetch_cues(query)
                        logger.info(
                            "queue_prefetch: extracted %d LLM cue(s)",
                            len(cues),
                        )
                    except Exception:
                        logger.debug("queue_prefetch: LLM cue extraction failed, using raw query")
                        cues = [query] if query else []
                else:
                    cues = [query] if query else []

                if not cues:
                    return

                from core.retrieval import retrieve_recursive_bfs
                seen_ids: set[str] = set()
                all_nodes: list[dict] = []
                for cue in cues:
                    results = retrieve_recursive_bfs(
                        db_path=db_path, query=cue, top_k=top_k,
                    )
                    if results:
                        node_ids = [r.node_id for r in results]
                        nodes = self._enrich_results(node_ids)
                        for n in nodes:
                            nid = n.get("id", "")
                            if nid not in seen_ids:
                                seen_ids.add(nid)
                                all_nodes.append(n)

                if all_nodes:
                    ctx = self._format_context(all_nodes)
                    # Stage results for the next prefetch to pick up
                    self._prefetch_pending = ctx
                    logger.info(
                        "queue_prefetch: cached %d result(s) from %d cue(s) for next turn",
                        len(all_nodes), len(cues),
                    )
            except Exception:
                logger.debug("queue_prefetch background worker failed (non-fatal)", exc_info=True)

        t = threading.Thread(target=_warmup_worker, daemon=True,
                             name=f"cashew-prefetch-{self._session_id}")
        t.start()

    def _extract_prefetch_cues(self, query: str) -> list[str]:
        """Use the auxiliary LLM to extract concrete search cues from the turn.

        Transforms the conversational turn into 2-3 concrete noun phrases
        suitable for semantic search. Uses both the user message (query) and
        the buffered assistant response (_last_assistant) for context.

        Returns:
            List of search cue strings (may be empty).

        Raises:
            Exception: forwarded to caller for logging.
        """
        if not self._model_fn:
            return [query] if query else []
        assistant = self._last_assistant or ""
        n = max(1, self._config.prefetch_cues) if self._config else 3
        prompt = (
            "Extract up to {} concrete search queries from this conversation "
            "turn that would find relevant semantic memory for what is likely "
            "to come next. Each search query must be a short noun phrase (not "
            "a question).\n\n"
            "User: {}\n"
            "Assistant: {}\n\n"
            "Respond with one search query per line. No numbering, no prefixes."
        ).format(n, query, assistant)
        raw = self._model_fn(prompt)
        cues = [
            line.strip() for line in raw.strip().split("\n")
            if line.strip() and not line.strip().startswith(("```", "Here", "Sure"))
        ]
        return cues[:n] if cues else [query] if query else []

    def _keyword_search(
        self, query: str, max_nodes: int,
        domain: str | None = None, tag: str | None = None,
        exclude_tags: list[str] | None = None,
    ) -> list[dict]:
        import sqlite3
        conn = sqlite3.connect(str(self._db_path))
        try:
            where_clauses: list[str] = []
            params: list = []
            words = [w for w in query.split() if w]
            if words:
                where_clauses.append(
                    "(" + " AND ".join(["content LIKE ?"] * len(words)) + ")"
                )
                params.extend(f"%{w}%" for w in words)
            if domain:
                where_clauses.append("domain = ?")
                params.append(domain)
            if tag:
                where_clauses.append("tags LIKE ?")
                params.append(f"%{tag}%")
            if exclude_tags:
                for ex_tag in exclude_tags:
                    if ex_tag:
                        where_clauses.append("(tags IS NULL OR tags NOT LIKE ?)")
                        params.append(f"%{ex_tag}%")
            order_params: list = []
            if words:
                order_params.append(f"%{query}%")
            cursor = conn.execute(
                f"""
                SELECT * FROM thought_nodes
                WHERE {' AND '.join(where_clauses) if where_clauses else '1=1'}
                ORDER BY
                    {'(CASE WHEN content LIKE ? THEN 1 ELSE 0 END) DESC,' if order_params else ''}
                    referent_time DESC NULLS LAST,
                    timestamp DESC
                LIMIT ?
                """,
                (*params, *order_params, max_nodes),
            )
            rows = cursor.fetchall()
            cols = [col[0] for col in cursor.description]
            return [dict(zip(cols, row)) for row in rows]
        finally:
            conn.close()

    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Return the list of LLM tool schemas this provider exposes (RECALL-02 + SYNC-03).

        Phase 3 + Phase 4: two tools — cashew_query (recall) and cashew_extract
        (explicit sync). Schema structure follows OpenAI's parameters convention.

        The returned list is a fresh list literal each call, but the schema dicts
        themselves are module constants (not copies) — callers must not mutate.
        """
        return [CASHEW_QUERY_SCHEMA, CASHEW_EXTRACT_SCHEMA]

    def handle_tool_call(self, name: str, args: Dict[str, Any]) -> str:
        """Route an LLM tool call to the Cashew backend.

        Two tools are handled:
          - cashew_query (Phase 3): recall from the thought graph.
          - cashew_extract (Phase 4): explicit, synchronous extraction of
            one turn. Bypasses the sync queue — returns only after Cashew
            completes.

        Silent-degrade paths (per PROJECT.md Key Decision):
          - Unknown tool -> WARNING (no exc_info) + error envelope with
            tool='cashew_query' for historical compatibility.
          - Half-state (initialize never ran or silent-degraded) -> error
            envelope, no log (initialize already warned).
          - Any exception during happy path -> WARNING + exc_info=True +
            error envelope.

        Returns:
            JSON string — NEVER None, NEVER raises into Hermes.
        """
        if name == "cashew_query":
            if self._config is None:
                return build_error_envelope(
                    query=args.get("query"),
                    error_message="cashew recall failed",
                )
            try:
                query = args["query"]
                max_nodes = args.get("max_nodes", self._config.recall_k)
                domain = args.get("domain")
                tag = args.get("tag")
                exclude_tags = args.get("exclude_tags")
                try:
                    from core.retrieval import retrieve_recursive_bfs
                    results = retrieve_recursive_bfs(
                        db_path=str(self._db_path),
                        query=query,
                        top_k=max_nodes,
                        domain=domain,
                        tags=[tag] if tag else None,
                        exclude_tags=exclude_tags,
                    )
                except Exception:
                    results = None
                if results:
                    node_ids = [r.node_id for r in results]
                    nodes = self._enrich_results(node_ids)
                else:
                    nodes = self._keyword_search(query, max_nodes, domain, tag, exclude_tags)
                if nodes:
                    self._update_access_metrics([n["id"] for n in nodes])
                    context = self._format_context(nodes)
                    node_count = len(nodes)
                else:
                    context = ""
                    node_count = 0
                return build_success_envelope(
                    query=query,
                    context=context,
                    node_count=node_count,
                )
            except Exception:
                logger.warning(
                    "cashew tool call %r failed",
                    name,
                    exc_info=True,
                )
                return build_error_envelope(
                    query=args.get("query"),
                    error_message="cashew recall failed",
                )

        elif name == "cashew_extract":
            # Half-state guard (matches Phase 3 cashew_query + 04-RESEARCH.md §6.9).
            # No log — initialize() already warned when it set _db_path / _config to None.
            if self._db_path is None or self._config is None:
                return build_extract_error_envelope()
            try:
                user = args["user_content"]  # KeyError caught below — tool-call failure
                assistant = args["assistant_content"]
                # Lazy import (matches _drain_once in Plan 04-01 — keeps is_available
                # free of core.session side effects).
                from core.session import end_session
                result = end_session(
                    db_path=str(self._db_path),
                    session_id=self._session_id,
                    conversation_text=f"User: {user}\nAssistant: {assistant}",
                    model_fn=self._model_fn,
                )
                return build_extract_success_envelope(
                    new_nodes=len(result.new_nodes),
                    new_edges=len(result.new_edges),
                )
            except Exception:
                logger.warning(
                    "cashew tool call %r failed",
                    name,
                    exc_info=True,
                )
                return build_extract_error_envelope()

        else:
            # Unknown-tool branch (Phase 3 contract preserved; note: uses the QUERY
            # envelope because historically unknown-tool returned the cashew_query
            # error shape. This preserves backward compatibility with Phase 3's
            # test_handle_tool_call.py::test_unknown_tool_returns_error_envelope_and_logs_once
            # which asserts tool='cashew_query', error='unknown tool', query=None.
            # Rationale: unknown-tool routing predates the existence of multiple
            # tools; the envelope has served as a generic-error shape. Phase 4 does
            # not change this behavior — only ADDS a cashew_extract-specific error
            # envelope for the cashew_extract branch.)
            logger.warning("cashew unknown tool call: %r", name)
            return build_error_envelope(query=None, error_message="unknown tool")

    def system_prompt_block(self) -> str:
        """Return a ~10-line LLM-visible status string for the system prompt (UX-01).

        The returned string is included verbatim in Hermes's assembled system prompt
        so the LLM can reason about what memory is available.

        Format (~10 lines):
            [cashew] memory provider: available
            graph: <N> nodes, <M> edges
            recall depth: <recall_k>

        When unavailable or empty: clearly signals the LLM should not expect recall.
        Never raises. Returns a plain str, not a dict or JSON.
        """
        if self._config is None or self._hermes_home is None:
            return "[cashew] memory provider: not configured\n"

        try:
            recall_k = self._config.recall_k
        except AttributeError:
            recall_k = 5

        if self._db_path is None:
            return (
                f"[cashew] memory provider: available (db not initialized)\n"
                f"graph: uninitialized\n"
                f"recall depth: {recall_k}\n"
            )

        try:
            import sqlite3
            conn = sqlite3.connect(str(self._db_path))
            cursor = conn.execute(
                "SELECT COUNT(*), (SELECT COUNT(*) FROM derivation_edges) FROM thought_nodes"
            )
            row = cursor.fetchone()
            conn.close()
            node_count = row[0] if row else 0
            edge_count = row[1] if row else 0
            if node_count == 0:
                graph_state = "empty"
            else:
                graph_state = f"{node_count} nodes, {edge_count} edges"
        except Exception:
            graph_state = "unknown"

        user_domain = get_user_domain(self._config)
        ai_domain = get_ai_domain(self._config)

        return (
            f"[cashew] memory provider: available\n"
            f"graph: {graph_state}\n"
            f"recall depth: {recall_k}\n"
            f"user domain: {user_domain}\n"
            f"ai domain: {ai_domain}\n"
        )

    # All other ABC methods are inherited as no-ops from the ABC defaults (when Hermes is present).


def register(ctx) -> None:
    """Hermes discovery entry point — filesystem loader calls this.

    Two code paths:
    - Directory scanner (source="bundled"|"user" in plugins/memory/__init__.py):
      ctx is a _ProviderCollector with register_memory_provider.
    - Entry-point loader (source="entrypoint"): ctx is a PluginContext without
      register_memory_provider — memory providers are discovered by the
      directory scanner, not entry points.
    """
    register_fn = getattr(ctx, "register_memory_provider", None)
    if register_fn is not None:
        register_fn(CashewMemoryProvider())
