# i3-filter-stack
Filter windows and stack windows of a certain type together in i3.

AI-generated and unreviewed. But I use it.

## Alternatives and prior work
I found a tool called i3-stack which may do something similar but it was undocumented.


## Installation
pipx install i3-filter-stack

## Usage
Start a daemon which places windows with a class kitty in a stacked layout

`i3-filter-stack --class kitty --group class`

You might like to add this to a systemd serice.


## Caveats
Does not support many filtering options at the moment.
