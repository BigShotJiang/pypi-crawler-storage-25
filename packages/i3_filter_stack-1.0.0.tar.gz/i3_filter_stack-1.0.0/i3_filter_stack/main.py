import argparse
import uuid
import i3ipc


def main():
    parser = argparse.ArgumentParser(
        description="Stack i3 windows of a certain class together automatically"
    )
    parser.add_argument("--class", dest="window_class", metavar="CLASS",
                        required=True, help="Window class to match (e.g. kitty-claude)")
    parser.add_argument("--group", choices=["class"], default="class",
                        help="How to group windows (currently only 'class' is supported)")
    args = parser.parse_args()

    i3 = i3ipc.Connection()

    def on_new_window(i3, event):
        window = event.container
        wclass = window.window_class or ""
        if args.window_class.lower() not in wclass.lower():
            return

        tree = i3.get_tree()
        existing = [
            w for w in tree.leaves()
            if (w.window_class or "").lower() == wclass.lower()
            and w.id != window.id
        ]

        i3.command(f'[con_id={window.id}] floating disable')

        if not existing:
            print(f"First '{args.window_class}' window, nothing to stack with yet")
            return

        target = existing[0]
        mark = f"__fs_{uuid.uuid4().hex}"
        print(f"Stacking con_id={window.id} with con_id={target.id} via mark {mark}")

        i3.command(f'[con_id={target.id}] mark {mark}')
        i3.command(f'[con_id={window.id}] move container to mark {mark}')
        i3.command(f'[con_id={target.id}] unmark {mark}')
        i3.command(f'[con_id={target.id}] layout stacking')

    i3.on(i3ipc.Event.WINDOW_NEW, on_new_window)
    print(f"Watching for windows with class '{args.window_class}'...")
    i3.main()


if __name__ == "__main__":
    main()