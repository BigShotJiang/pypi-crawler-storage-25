"""Core functions for Wrapping Developer LLM in Python"""

import functools
from typing import Any, Callable, ParamSpec  # , TypeVar

import requests as req
from .consts import (
    ADLIB_API_KEY,
    ADLIB_CHATBOT_PUBLIC_KEY,
    ADLIB_CORE_URL,
    ADLIB_VALIDATE_URL,
)

_P = ParamSpec("_P")
# _T = TypeVar("_T")


class AdLib:
    def __init__(
        self,
        adlib_api_key: str = ADLIB_API_KEY,
        adlib_chatbot_api_key: str = ADLIB_CHATBOT_PUBLIC_KEY,
    ) -> None:
        self.api_key = adlib_api_key
        self.pub_key = adlib_chatbot_api_key
        self.payload = body = {
            "access_token": self.api_key,
            "chatbot_token": self.pub_key,
        }

        if not self.api_key or not self.pub_key:
            raise Exception("adlib_api_key and CHATBOT_PUBLIC_KEY required")

        response = req.post(ADLIB_VALIDATE_URL, json=body)
        data = response.json()
        if not data["success"]:
            raise ValueError(f"API Access Denied: {data['error']}")

        self.last_llm_output = ""
        self.last_adified = ""

    def _adify(self, llm_output: str) -> dict[str, Any]:
        """Return the full response from the adify service for llm_output"""
        self.payload["llm_output"] = self.last_llm_output = llm_output
        response = req.post(ADLIB_CORE_URL, json=self.payload)

        data = response.json()
        self.last_adified = data.get("adified", "")  # "" if error or not adified

        output: dict[str, Any] = {
            "success": True,
            "adified": self.last_adified if self.last_adified else self.last_llm_output,
        }

        if "error" in data:
            output["success"] = False
            output["error"] = data.get("error", "An Error Occured")

        return output

    def adify(self, llm_output: str | Callable[_P, str]) -> str | Callable[_P, str]:
        """Directly adify text or decorate a function.

        Usage:
            adlib.adify("input text")
            @adlib.adify
            def fn(...):
                return "text"
        """
        if callable(llm_output):
            func = llm_output

            @functools.wraps(func)
            def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> str:
                output = func(*args, **kwargs)
                return str(self.adify(output))  # Extra str 'cos of typing

            return wrapper

        data = self._adify(llm_output)
        return data["adified"]
