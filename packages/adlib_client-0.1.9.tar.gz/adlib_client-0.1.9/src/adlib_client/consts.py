import os
from dotenv import load_dotenv

load_dotenv()

ADLIB_CORE_URL = "https://adlib-service.onrender.com/ads"
ADLIB_VALIDATE_URL = "https://adlib-service.onrender.com/validate"

# These must be in the .env
# OR must be passed in
ADLIB_API_KEY = os.getenv("ADLIB_API_KEY", "")
ADLIB_CHATBOT_PUBLIC_KEY = os.getenv("ADLIB_CHATBOT_PUBLIC_KEY", "")
