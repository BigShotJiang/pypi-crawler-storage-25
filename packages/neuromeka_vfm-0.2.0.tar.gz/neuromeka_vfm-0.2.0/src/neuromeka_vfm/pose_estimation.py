import warnings
from typing import Any, Dict, List, Optional, Sequence
import numpy as np

from .pickle_client import PickleClient


class PoseEstimation:
    """
    Client for FoundationPose pickle RPC server.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        timeout_ms: Optional[int] = None,
        linger_ms: Optional[int] = None,
    ):
        import os

        host = host or os.environ.get("FPOSE_HOST", "localhost")
        port = port or int(os.environ.get("FPOSE_PORT", "5557"))
        self.client = PickleClient(host, port, timeout_ms=timeout_ms, linger_ms=linger_ms)

    def get_version(self):
        return self.client.send_data({"operation": "get_version"})

    def get_health(self):
        return self.client.send_data({"operation": "get_health"})

    def get_capabilities(self):
        resp = self.get_version()
        if isinstance(resp, dict) and resp.get("result") == "SUCCESS":
            data = resp.get("data") or {}
            if isinstance(data, dict):
                return {"result": "SUCCESS", "data": data.get("capabilities", {})}
        return resp

    @staticmethod
    def _append_mesh_payload(
        payload: dict,
        mesh_path: Optional[str] = None,
        mesh_vertices=None,
        mesh_faces=None,
        require_mesh: bool = False,
    ):
        if mesh_path is not None:
            payload["mesh_path"] = mesh_path
            return

        has_vertices = mesh_vertices is not None
        has_faces = mesh_faces is not None
        if has_vertices and has_faces:
            payload["mesh_vertices"] = mesh_vertices
            payload["mesh_faces"] = mesh_faces
            return

        if has_vertices != has_faces:
            raise ValueError("mesh_vertices and mesh_faces must be provided together.")

        if require_mesh:
            raise ValueError("Either mesh_path or both mesh_vertices and mesh_faces must be provided.")

    @staticmethod
    def _append_session_payload(
        payload: dict,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
    ):
        if session_id is not None:
            payload["session_id"] = str(session_id)
        if object_id is not None:
            payload["object_id"] = str(object_id)
        if mask_id is not None:
            payload["mask_id"] = str(mask_id)

    def create_session(
        self,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
        mesh_path: Optional[str] = None,
        mesh_vertices=None,
        mesh_faces=None,
        apply_scale: float = 1.0,
        force_apply_color: bool = False,
        apply_color: Sequence[float] = (160, 160, 160),
        est_refine_iter: int = 10,
        track_refine_iter: int = 3,
        min_n_views: int = 40,
        inplane_step: int = 60,
        symmetry_tfs=None,
    ):
        payload = {
            "operation": "create_session",
            "apply_scale": apply_scale,
            "force_apply_color": force_apply_color,
            "apply_color": list(apply_color),
            "est_refine_iter": est_refine_iter,
            "track_refine_iter": track_refine_iter,
            "min_n_views": min_n_views,
            "inplane_step": inplane_step,
        }
        self._append_session_payload(payload, session_id=session_id, object_id=object_id, mask_id=mask_id)
        self._append_mesh_payload(
            payload=payload,
            mesh_path=mesh_path,
            mesh_vertices=mesh_vertices,
            mesh_faces=mesh_faces,
            require_mesh=False,
        )
        if symmetry_tfs is not None:
            payload["symmetry_tfs"] = symmetry_tfs
        return self.client.send_data(payload)

    def list_sessions(self):
        return self.client.send_data({"operation": "list_sessions"})

    def delete_session(self, session_id: Optional[str] = None, object_id: Optional[str] = None):
        payload = {"operation": "delete_session"}
        self._append_session_payload(payload, session_id=session_id, object_id=object_id)
        return self.client.send_data(payload)

    def reset_session(self, session_id: Optional[str] = None, object_id: Optional[str] = None):
        payload = {"operation": "reset_session"}
        self._append_session_payload(payload, session_id=session_id, object_id=object_id)
        return self.client.send_data(payload)

    def init(
        self,
        mesh_path: Optional[str] = None,
        apply_scale: float = 1.0,
        force_apply_color: bool = False,
        apply_color: Sequence[float] = (160, 160, 160),
        est_refine_iter: int = 10,
        track_refine_iter: int = 3,
        min_n_views: int = 40,
        inplane_step: int = 60,
        mesh_vertices=None,
        mesh_faces=None,
        symmetry_tfs=None,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
    ):
        payload = {
            "operation": "init",
            "apply_scale": apply_scale,
            "force_apply_color": force_apply_color,
            "apply_color": list(apply_color),
            "est_refine_iter": est_refine_iter,
            "track_refine_iter": track_refine_iter,
            "min_n_views": min_n_views,
            "inplane_step": inplane_step,
        }
        self._append_session_payload(payload, session_id=session_id, object_id=object_id, mask_id=mask_id)
        self._append_mesh_payload(
            payload=payload,
            mesh_path=mesh_path,
            mesh_vertices=mesh_vertices,
            mesh_faces=mesh_faces,
            require_mesh=True,
        )
        if symmetry_tfs is not None:
            payload["symmetry_tfs"] = symmetry_tfs
        return self.client.send_data(payload)

    def register(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        mask: np.ndarray,
        K: np.ndarray,
        iteration: int = None,
        check_vram: bool = True,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
    ):
        payload = {
            "operation": "register",
            "rgb": rgb,
            "depth": depth,
            "mask": mask,
            "K": K,
            "check_vram": bool(check_vram),
        }
        self._append_session_payload(payload, session_id=session_id, object_id=object_id, mask_id=mask_id)
        if iteration is not None:
            payload["iteration"] = iteration
        return self.client.send_data(payload)

    def register_with_mesh(
        self,
        mesh_path: Optional[str] = None,
        mesh_vertices=None,
        mesh_faces=None,
        apply_scale: float = 1.0,
        force_apply_color: bool = False,
        apply_color: Sequence[float] = (160, 160, 160),
        est_refine_iter: int = 10,
        track_refine_iter: int = 3,
        min_n_views: int = 40,
        inplane_step: int = 60,
        symmetry_tfs=None,
        rgb: Optional[np.ndarray] = None,
        depth: Optional[np.ndarray] = None,
        mask: Optional[np.ndarray] = None,
        K: Optional[np.ndarray] = None,
        iteration: Optional[int] = None,
        check_vram: bool = True,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
    ):
        if rgb is None or depth is None or mask is None or K is None:
            raise ValueError("rgb, depth, mask, and K must be provided.")

        payload = {
            "operation": "register_with_mesh",
            "apply_scale": apply_scale,
            "force_apply_color": force_apply_color,
            "apply_color": list(apply_color),
            "est_refine_iter": est_refine_iter,
            "track_refine_iter": track_refine_iter,
            "min_n_views": min_n_views,
            "inplane_step": inplane_step,
            "rgb": rgb,
            "depth": depth,
            "mask": mask,
            "K": K,
            "check_vram": bool(check_vram),
        }
        self._append_session_payload(payload, session_id=session_id, object_id=object_id, mask_id=mask_id)
        self._append_mesh_payload(
            payload=payload,
            mesh_path=mesh_path,
            mesh_vertices=mesh_vertices,
            mesh_faces=mesh_faces,
            require_mesh=True,
        )
        if symmetry_tfs is not None:
            payload["symmetry_tfs"] = symmetry_tfs
        if iteration is not None:
            payload["iteration"] = iteration
        return self.client.send_data(payload)

    def track(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        iteration: int = None,
        bbox_xywh=None,
        mask=None,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
        mask_id: Optional[str] = None,
    ):
        payload = {
            "operation": "track",
            "rgb": rgb,
            "depth": depth,
            "K": K,
            "bbox_xywh": bbox_xywh,
        }
        self._append_session_payload(payload, session_id=session_id, object_id=object_id, mask_id=mask_id)
        if mask is not None:
            payload["mask"] = mask
        if iteration is not None:
            payload["iteration"] = iteration
        return self.client.send_data(payload)

    def track_many(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        objects: Sequence[Dict[str, Any]],
        iteration: Optional[int] = None,
    ):
        payload_objects: List[Dict[str, Any]] = []
        for obj in objects:
            item = dict(obj)
            if iteration is not None and "iteration" not in item:
                item["iteration"] = iteration
            payload_objects.append(item)
        return self.client.send_data(
            {
                "operation": "track_many",
                "rgb": rgb,
                "depth": depth,
                "K": K,
                "objects": payload_objects,
            }
        )

    def register_many(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        objects: Sequence[Dict[str, Any]],
        iteration: Optional[int] = None,
        check_vram: bool = True,
    ):
        results: Dict[str, Any] = {}
        for index, obj in enumerate(objects):
            item = dict(obj)
            session_id = item.get("session_id") or item.get("object_id") or f"object_{index}"
            object_id = item.get("object_id") or session_id
            key = str(object_id)
            mask = item.get("mask")
            if mask is None:
                results[key] = {
                    "success": False,
                    "session_id": session_id,
                    "object_id": object_id,
                    "error": "mask is required",
                }
                continue
            mesh_path = item.get("mesh_path")
            mesh_vertices = item.get("mesh_vertices")
            mesh_faces = item.get("mesh_faces")
            has_mesh = mesh_path is not None or (mesh_vertices is not None and mesh_faces is not None)
            try:
                if has_mesh:
                    resp = self.register_with_mesh(
                        mesh_path=mesh_path,
                        mesh_vertices=mesh_vertices,
                        mesh_faces=mesh_faces,
                        apply_scale=item.get("apply_scale", 1.0),
                        force_apply_color=item.get("force_apply_color", False),
                        apply_color=item.get("apply_color", (160, 160, 160)),
                        est_refine_iter=item.get("est_refine_iter", 10),
                        track_refine_iter=item.get("track_refine_iter", 3),
                        min_n_views=item.get("min_n_views", 40),
                        inplane_step=item.get("inplane_step", 60),
                        symmetry_tfs=item.get("symmetry_tfs"),
                        rgb=rgb,
                        depth=depth,
                        mask=mask,
                        K=K,
                        iteration=item.get("iteration", iteration),
                        check_vram=bool(item.get("check_vram", check_vram)),
                        session_id=session_id,
                        object_id=object_id,
                        mask_id=item.get("mask_id"),
                    )
                else:
                    resp = self.register(
                        rgb=rgb,
                        depth=depth,
                        mask=mask,
                        K=K,
                        iteration=item.get("iteration", iteration),
                        check_vram=bool(item.get("check_vram", check_vram)),
                        session_id=session_id,
                        object_id=object_id,
                        mask_id=item.get("mask_id"),
                    )
            except Exception as exc:
                results[key] = {
                    "success": False,
                    "session_id": session_id,
                    "object_id": object_id,
                    "error": str(exc),
                }
                continue
            success = isinstance(resp, dict) and resp.get("result") == "SUCCESS"
            data = resp.get("data", {}) if isinstance(resp, dict) else {}
            results[key] = {
                "success": bool(success),
                "session_id": session_id,
                "object_id": object_id,
                **(data if isinstance(data, dict) else {}),
            }
            if not success:
                results[key]["error"] = resp.get("message") if isinstance(resp, dict) else "register failed"
        return {
            "result": "SUCCESS",
            "data": {
                "results": results,
                "success_count": sum(1 for item in results.values() if item.get("success")),
                "object_count": len(objects),
            },
        }

    def reset_vram(self, free_vram: bool = True):
        return self.client.send_data({"operation": "reset_vram", "free_vram": bool(free_vram)})

    def reset(self, free_vram: bool = True):
        """Deprecated. Use reset_vram() instead."""
        warnings.warn("PoseEstimation.reset() is deprecated; use reset_vram().", DeprecationWarning, stacklevel=2)
        return self.reset_vram(free_vram=free_vram)

    def reset_object(
        self,
        mesh_path: Optional[str] = None,
        mesh_vertices=None,
        mesh_faces=None,
        model_pts=None,
        model_normals=None,
        symmetry_tfs=None,
        min_n_views: int = None,
        inplane_step: int = None,
        session_id: Optional[str] = None,
        object_id: Optional[str] = None,
    ):
        """Re-run server-side reset_object/make_rotation_grid with optional mesh/model overrides."""
        payload = {"operation": "reset_object"}
        self._append_session_payload(payload, session_id=session_id, object_id=object_id)
        if mesh_path is not None or mesh_vertices is not None or mesh_faces is not None:
            self._append_mesh_payload(
                payload=payload,
                mesh_path=mesh_path,
                mesh_vertices=mesh_vertices,
                mesh_faces=mesh_faces,
                require_mesh=False,
            )
        if model_pts is not None:
            payload["model_pts"] = model_pts
        if model_normals is not None:
            payload["model_normals"] = model_normals
        if symmetry_tfs is not None:
            payload["symmetry_tfs"] = symmetry_tfs
        if min_n_views is not None:
            payload["min_n_views"] = min_n_views
        if inplane_step is not None:
            payload["inplane_step"] = inplane_step
        return self.client.send_data(payload)

    def close(self):
        self.client.close()


class MultiObjectPoseEstimation:
    """Small convenience manager for session-scoped multi-object FoundationPose tracking."""

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        timeout_ms: Optional[int] = None,
        linger_ms: Optional[int] = None,
        client: Optional[PoseEstimation] = None,
    ):
        self.client = client or PoseEstimation(
            host=host,
            port=port,
            timeout_ms=timeout_ms,
            linger_ms=linger_ms,
        )
        self.objects: Dict[str, Dict[str, Any]] = {}
        self.latest: Dict[str, Dict[str, Any]] = {}

    def add_object(
        self,
        object_id: str,
        session_id: Optional[str] = None,
        mask_id: Optional[str] = None,
        mesh_path: Optional[str] = None,
        mesh_vertices=None,
        mesh_faces=None,
        **pose_config,
    ):
        if not object_id:
            raise ValueError("object_id is required.")
        session_id = session_id or object_id
        info = {
            "object_id": object_id,
            "session_id": session_id,
            "mask_id": mask_id,
            "mesh_path": mesh_path,
            "mesh_vertices": mesh_vertices,
            "mesh_faces": mesh_faces,
            **pose_config,
        }
        self.objects[object_id] = info
        return info

    def remove_object(self, object_id: str, delete_session: bool = True):
        info = self.objects.pop(object_id, None)
        self.latest.pop(object_id, None)
        if delete_session and info is not None:
            return self.client.delete_session(session_id=info.get("session_id"), object_id=object_id)
        return {"result": "SUCCESS", "data": {"object_id": object_id, "deleted": info is not None}}

    def register_many(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        masks_by_object_id: Dict[str, Any],
        iteration: Optional[int] = None,
        check_vram: bool = True,
    ):
        objects: List[Dict[str, Any]] = []
        for object_id, info in self.objects.items():
            if object_id not in masks_by_object_id:
                continue
            objects.append({**info, "mask": masks_by_object_id[object_id]})
        resp = self.client.register_many(
            rgb=rgb,
            depth=depth,
            K=K,
            objects=objects,
            iteration=iteration,
            check_vram=check_vram,
        )
        self._update_latest_from_register_many(resp)
        return resp

    def track_many(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        masks_by_object_id: Optional[Dict[str, Any]] = None,
        bboxes_by_object_id: Optional[Dict[str, Any]] = None,
        iteration: Optional[int] = None,
    ):
        masks_by_object_id = masks_by_object_id or {}
        bboxes_by_object_id = bboxes_by_object_id or {}
        objects: List[Dict[str, Any]] = []
        for object_id, info in self.objects.items():
            item = {
                "object_id": object_id,
                "session_id": info.get("session_id") or object_id,
                "mask_id": info.get("mask_id"),
            }
            if object_id in masks_by_object_id:
                item["mask"] = masks_by_object_id[object_id]
            if object_id in bboxes_by_object_id:
                item["bbox_xywh"] = bboxes_by_object_id[object_id]
            objects.append(item)
        resp = self.client.track_many(rgb=rgb, depth=depth, K=K, objects=objects, iteration=iteration)
        self._update_latest_from_track_many(resp)
        return resp

    def list_sessions(self):
        return self.client.list_sessions()

    def close(self):
        self.client.close()

    def _update_latest_from_register_many(self, resp):
        data = resp.get("data", {}) if isinstance(resp, dict) else {}
        results = data.get("results", {}) if isinstance(data, dict) else {}
        for object_id, result in results.items():
            if isinstance(result, dict):
                self.latest[str(object_id)] = dict(result)

    def _update_latest_from_track_many(self, resp):
        data = resp.get("data", {}) if isinstance(resp, dict) else {}
        poses = data.get("poses", {}) if isinstance(data, dict) else {}
        for object_id, result in poses.items():
            if isinstance(result, dict):
                self.latest[str(object_id)] = dict(result)


# Backward-compat alias
FoundationPoseClient = PoseEstimation
