from importlib import import_module

__all__ = [
    "PoseEstimation",
    "MultiObjectPoseEstimation",
    "FoundationPoseClient",
    "upload_mesh",
    "MeshGenerator",
    "write_box_stl",
    "Segmentation",
    "NrmkRealtimeSegmentation",
    "Sam3Segmentation",
    "NrmkSam3",
    "Dinov3Client",
    "NrmkDinov3Client",
    "NrmkDinov3",
    "Dinov3Detection",
    "Dinov3DetectionConfig",
    "Dinov3DetectionError",
    "Dinov3Sam3Detection",
    "Dinov3Sam3DetectionConfig",
    "Dinov3Sam3DetectionError",
    "NrmkDinov3Detection",
    "NrmkDinov3ImageSegmentation",
    "NrmkDinov3DetectionConfig",
    "NrmkDinov3Sam3Detection",
    "NrmkDinov3Sam3DetectionConfig",
    "SEGMENTATION_COMPRESSION_STRATEGIES",
]

_EXPORTS = {
    "PoseEstimation": (".pose_estimation", "PoseEstimation"),
    "MultiObjectPoseEstimation": (".pose_estimation", "MultiObjectPoseEstimation"),
    "FoundationPoseClient": (".pose_estimation", "FoundationPoseClient"),
    "upload_mesh": (".upload_mesh", "upload_mesh"),
    "MeshGenerator": (".generate_mesh", "MeshGenerator"),
    "write_box_stl": (".generate_mesh", "write_box_stl"),
    "Segmentation": (".segmentation", "Segmentation"),
    "NrmkRealtimeSegmentation": (".segmentation", "NrmkRealtimeSegmentation"),
    "Sam3Segmentation": (".sam3_segmentation", "Sam3Segmentation"),
    "NrmkSam3": (".sam3_segmentation", "NrmkSam3"),
    "Dinov3Client": (".dinov3_client", "Dinov3Client"),
    "NrmkDinov3Client": (".dinov3_client", "NrmkDinov3Client"),
    "NrmkDinov3": (".dinov3_client", "NrmkDinov3"),
    "Dinov3Detection": (".dinov3_detection", "Dinov3Detection"),
    "Dinov3DetectionConfig": (".dinov3_detection", "Dinov3DetectionConfig"),
    "Dinov3DetectionError": (".dinov3_detection", "Dinov3DetectionError"),
    "Dinov3Sam3Detection": (".dinov3_sam3_detection", "Dinov3Sam3Detection"),
    "Dinov3Sam3DetectionConfig": (
        ".dinov3_sam3_detection",
        "Dinov3Sam3DetectionConfig",
    ),
    "Dinov3Sam3DetectionError": (
        ".dinov3_sam3_detection",
        "Dinov3Sam3DetectionError",
    ),
    "NrmkDinov3Detection": (".dinov3_detection", "NrmkDinov3Detection"),
    "NrmkDinov3ImageSegmentation": (
        ".dinov3_detection",
        "NrmkDinov3ImageSegmentation",
    ),
    "NrmkDinov3DetectionConfig": (
        ".dinov3_detection",
        "NrmkDinov3DetectionConfig",
    ),
    "NrmkDinov3Sam3Detection": (
        ".dinov3_sam3_detection",
        "NrmkDinov3Sam3Detection",
    ),
    "NrmkDinov3Sam3DetectionConfig": (
        ".dinov3_sam3_detection",
        "NrmkDinov3Sam3DetectionConfig",
    ),
    "SEGMENTATION_COMPRESSION_STRATEGIES": (
        ".compression",
        "STRATEGIES",
    ),
}


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = _EXPORTS[name]
    module = import_module(module_name, __name__)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(list(globals().keys()) + __all__)
