from __future__ import annotations

import time
from typing import Any, Dict, Optional

import zmq

from .pickle_client import PickleClient


class Dinov3Client:
    """Client for the NRMK DINOv3 ZeroMQ pickle RPC server."""

    def __init__(
        self,
        hostname: str = "localhost",
        port: int = 5558,
        timeout_ms: int = 5000,
        *,
        host: Optional[str] = None,
        timeout: Optional[int] = None,
    ):
        if host is not None:
            hostname = host
        if timeout is not None:
            timeout_ms = timeout

        self.hostname = hostname
        self.host = hostname
        self.port = int(port)
        self.timeout_ms = int(timeout_ms)
        self.timeout = self.timeout_ms
        self.client = PickleClient(
            self.hostname,
            self.port,
            timeout_ms=self.timeout_ms,
            linger_ms=0,
        )

    def _send_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        start = time.time()
        try:
            response = self.client.send_data(request_data)
        except zmq.Again:
            self.client.reconnect()
            return {
                "status": "error",
                "result": "ERROR",
                "message": f"Client timeout after {self.timeout_ms}ms",
                "elapsed_seconds": time.time() - start,
            }

        if isinstance(response, dict):
            response.setdefault("elapsed_seconds", time.time() - start)
            return response

        return {
            "status": "error",
            "result": "ERROR",
            "message": "DINOv3 server returned a non-dictionary response.",
            "data": response,
            "elapsed_seconds": time.time() - start,
        }

    def register_and_detect(self, scene: Dict[str, Any], prompt: Dict[str, Any]) -> Dict[str, Any]:
        return self._send_request(
            {
                "endpoint": "register_and_detect",
                "scene": scene,
                "prompt": prompt,
            }
        )

    def register(
        self,
        prompt: Optional[Dict[str, Any]] = None,
        *,
        prompts: Optional[list] = None,
    ) -> Dict[str, Any]:
        if prompt is not None and prompts is not None:
            raise ValueError("Provide either 'prompt' or 'prompts', not both.")
        if prompt is None and prompts is None:
            raise ValueError("Either 'prompt' or 'prompts' is required.")

        request: Dict[str, Any] = {"endpoint": "register"}
        if prompts is not None:
            request["prompts"] = prompts
        else:
            request["prompt"] = prompt
        return self._send_request(request)

    def detect(
        self,
        label: Optional[Any] = None,
        scene: Optional[Dict[str, Any]] = None,
        *,
        labels: Optional[list] = None,
    ) -> Dict[str, Any]:
        if label is not None and labels is not None:
            raise ValueError("Provide either 'label' or 'labels', not both.")
        if label is None and labels is None:
            raise ValueError("Either 'label' or 'labels' is required.")

        request: Dict[str, Any] = {"endpoint": "detect", "scene": scene}
        if labels is not None:
            request["labels"] = labels
        else:
            request["label"] = label
        return self._send_request(request)

    def set_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(config, dict):
            raise ValueError("'config' must be a dictionary")
        return self._send_request({"endpoint": "set_config", "config": config})

    def get_config(self) -> Dict[str, Any]:
        return self._send_request({"endpoint": "get_config"})

    def get_capabilities(self) -> Dict[str, Any]:
        return self._send_request({"endpoint": "get_capabilities"})

    def get_health(self) -> Dict[str, Any]:
        return self._send_request({"endpoint": "get_health"})

    def get_version(self) -> Dict[str, Any]:
        return self._send_request({"endpoint": "get_version"})

    def close(self) -> None:
        self.client.close()


NrmkDinov3Client = Dinov3Client
NrmkDinov3 = Dinov3Client
