"""
Utility to generate simple parametric meshes (currently rectangular box) as binary STL.

Design goals
- Units: meters
- Origin: object center at (0, 0, 0)
- Axes: faces aligned to +/-X, +/-Y, +/-Z
- Output path can be controlled per call, per instance, or by env var.

Path behavior
- If `filename` is absolute: write exactly there.
- If `filename` is relative:
  - use `output_dir` argument when provided
  - otherwise use `$NRMK_MESH_DIR` (if set)
  - otherwise fallback to `/opt/meshes`

Usage (programmatic):
    from neuromeka_vfm.generate_mesh import write_box_stl, MeshGenerator

    # function style
    path = write_box_stl("custom_box.stl", width=0.054, depth=0.097, height=0.054)
    path = write_box_stl(
        "custom_box.stl",
        width=0.054,
        depth=0.097,
        height=0.054,
        output_dir="./mesh",
    )

    # class style
    mesh_gen = MeshGenerator(output_dir="./mesh")
    path = mesh_gen.write_box_stl("custom_box.stl", width=0.054, depth=0.097, height=0.054)

CLI:
    python -m neuromeka_vfm.generate_mesh box custom_box.stl 0.054 0.097 0.054
    python -m neuromeka_vfm.generate_mesh box custom_box.stl 0.054 0.097 0.054 --output-dir ./mesh
"""

import argparse
import os
import struct
import sys
from pathlib import Path
from typing import Iterable, List, Optional, Union

DEFAULT_MESH_DIR = Path(os.environ.get("NRMK_MESH_DIR", "/opt/meshes"))


def _ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _resolve_output_path(filename: Union[str, Path], output_dir: Optional[Union[str, Path]]) -> Path:
    out_path = Path(filename)
    if out_path.is_absolute():
        return out_path
    base_dir = Path(output_dir) if output_dir is not None else DEFAULT_MESH_DIR
    return base_dir / out_path


def _pack_triangle(normal: Iterable[float], v1: Iterable[float], v2: Iterable[float], v3: Iterable[float]) -> bytes:
    """Pack one triangle (normal + 3 vertices) into binary STL record."""
    return struct.pack(
        "<12fH",
        *normal,
        *v1,
        *v2,
        *v3,
        0,  # attribute byte count
    )


def _box_triangles(width: float, depth: float, height: float):
    """Generate normals and vertices for a box centered at origin."""
    hx, hy, hz = width / 2.0, depth / 2.0, height / 2.0
    # 8 vertices
    p = [
        (-hx, -hy, -hz),
        (hx, -hy, -hz),
        (hx, hy, -hz),
        (-hx, hy, -hz),
        (-hx, -hy, hz),
        (hx, -hy, hz),
        (hx, hy, hz),
        (-hx, hy, hz),
    ]
    # Each face: two triangles (ccw when looking from outside)
    faces = [
        ((-1, 0, 0), (0, 3, 7, 4)),  # -X
        ((1, 0, 0), (1, 2, 6, 5)),  # +X
        ((0, -1, 0), (0, 1, 5, 4)),  # -Y
        ((0, 1, 0), (3, 2, 6, 7)),  # +Y
        ((0, 0, -1), (0, 1, 2, 3)),  # -Z
        ((0, 0, 1), (4, 5, 6, 7)),  # +Z
    ]
    for normal, idx in faces:
        if len(idx) == 4:
            a, b, c, d = idx
            # two triangles: (a,b,c) and (a,c,d)
            yield normal, p[a], p[b], p[c]
            yield normal, p[a], p[c], p[d]
        else:
            raise ValueError("Face index must have 4 vertices.")


class MeshGenerator:
    """
    Small mesh generation helper class for client-side utility usage.

    Args:
        output_dir: base directory used when output filename is relative.
    """

    def __init__(self, output_dir: Union[str, Path] = DEFAULT_MESH_DIR):
        self.output_dir = Path(output_dir)

    def write_box_stl(self, filename: Union[str, Path], width: float, depth: float, height: float) -> Path:
        return write_box_stl(
            filename=filename,
            width=width,
            depth=depth,
            height=height,
            output_dir=self.output_dir,
        )


def write_box_stl(
    filename: Union[str, Path],
    width: float,
    depth: float,
    height: float,
    output_dir: Optional[Union[str, Path]] = None,
) -> Path:
    """
    Create a rectangular box STL.

    Args:
        filename: output file name. If relative, resolved with `output_dir` or
                  default mesh dir (`$NRMK_MESH_DIR` or `/opt/meshes`).
        width, depth, height: box dimensions in meters (must be > 0).
        output_dir: base directory for relative filename.

    Returns:
        Path to the written STL file.
    """
    if width <= 0 or depth <= 0 or height <= 0:
        raise ValueError("width, depth, height must be positive.")

    out_path = _resolve_output_path(filename, output_dir)
    _ensure_dir(out_path)

    triangles = list(_box_triangles(width, depth, height))
    header = b"rect_box_stl" + b"\0" * (80 - len("rect_box_stl"))
    with out_path.open("wb") as f:
        f.write(header)
        f.write(struct.pack("<I", len(triangles)))
        for tri in triangles:
            f.write(_pack_triangle(*tri))
    return out_path


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="neuromeka-generate-mesh",
        description="Generate simple parametric STL meshes",
    )
    subparsers = parser.add_subparsers(dest="shape", required=True)

    box_parser = subparsers.add_parser("box", help="Generate rectangular box STL")
    box_parser.add_argument("filename", help="Output STL file name/path")
    box_parser.add_argument("width", type=float, help="X size in meters")
    box_parser.add_argument("depth", type=float, help="Y size in meters")
    box_parser.add_argument("height", type=float, help="Z size in meters")
    box_parser.add_argument(
        "--output-dir",
        default=None,
        help="Base directory for relative output filename (default: $NRMK_MESH_DIR or /opt/meshes)",
    )
    return parser


def _cli(args: List[str]) -> int:
    parser = _build_parser()
    ns = parser.parse_args(args)
    try:
        if ns.shape == "box":
            path = write_box_stl(
                filename=ns.filename,
                width=ns.width,
                depth=ns.depth,
                height=ns.height,
                output_dir=ns.output_dir,
            )
        else:
            raise ValueError(f"Unsupported shape: {ns.shape}")
    except Exception as exc:  # noqa: BLE001
        print(f"Error: {exc}")
        return 1
    print(f"STL written to: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(_cli(sys.argv[1:]))
