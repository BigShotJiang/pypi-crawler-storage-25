from __future__ import annotations

import colorsys
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np


SUPPORTED_BACKBONES = (
    "dinov3_vits16",
    "dinov3_vits16plus",
    "dinov3_vitb16",
    "dinov3_vitl16",
    "dinov3_vitl16plus",
    "dinov3_vith16plus",
    "dinov3_vit7b16",
)


def normalize_backbone_name(backbone: str) -> str:
    if backbone in SUPPORTED_BACKBONES:
        return backbone
    candidate = f"dinov3_{backbone}"
    if candidate in SUPPORTED_BACKBONES:
        return candidate
    raise ValueError(f"Unsupported backbone '{backbone}'.")


def short_backbone_name(backbone: str) -> str:
    return normalize_backbone_name(backbone).removeprefix("dinov3_")


def ensure_rgb_uint8_image(image: np.ndarray) -> np.ndarray:
    array = np.asarray(image)
    if array.ndim != 3 or array.shape[2] != 3:
        raise ValueError("Expected an RGB image with shape (H, W, 3).")
    if array.dtype != np.uint8:
        array = np.clip(array, 0, 255).astype(np.uint8)
    return array


def ensure_rgba_uint8_image(image: np.ndarray) -> np.ndarray:
    array = np.asarray(image)
    if array.ndim != 3 or array.shape[2] not in {3, 4}:
        raise ValueError("Expected an RGB or RGBA image with shape (H, W, 3|4).")
    if array.dtype != np.uint8:
        array = np.clip(array, 0, 255).astype(np.uint8)
    if array.shape[2] == 4:
        return array

    alpha = np.full(array.shape[:2] + (1,), 255, dtype=np.uint8)
    return np.concatenate([array, alpha], axis=2)


def normalize_points(points: Iterable[Any]) -> List[Dict[str, int]]:
    normalized: List[Dict[str, int]] = []
    for point in points:
        if isinstance(point, dict):
            if "x" not in point or "y" not in point:
                raise ValueError("Prompt point dictionaries must contain 'x' and 'y'.")
            normalized.append({"x": int(point["x"]), "y": int(point["y"])})
            continue

        point_values = list(point)
        if len(point_values) != 2:
            raise ValueError("Prompt points must be (x, y) pairs.")
        normalized.append({"x": int(point_values[0]), "y": int(point_values[1])})
    return normalized


def infer_prompt_points_from_alpha(prompt_image: np.ndarray) -> List[Dict[str, int]]:
    rgba = ensure_rgba_uint8_image(prompt_image)
    height, width = rgba.shape[:2]
    if height <= 0 or width <= 0:
        raise ValueError("Prompt image has an invalid zero-sized dimension.")

    alpha_mask = rgba[..., 3] > 0
    if np.any(alpha_mask):
        rows, cols = np.where(alpha_mask)
        center_x = int((int(cols.min()) + int(cols.max()) + 1) // 2)
        center_y = int((int(rows.min()) + int(rows.max()) + 1) // 2)
        return [{"x": center_x, "y": center_y}]

    return [{"x": int(width // 2), "y": int(height // 2)}]


def erode_binary_mask(mask: np.ndarray, iterations: int) -> np.ndarray:
    current = np.asarray(mask).astype(bool)
    for _ in range(max(int(iterations), 0)):
        padded = np.pad(current, ((1, 1), (1, 1)), mode="constant", constant_values=False)
        current = (
            padded[:-2, :-2]
            & padded[:-2, 1:-1]
            & padded[:-2, 2:]
            & padded[1:-1, :-2]
            & padded[1:-1, 1:-1]
            & padded[1:-1, 2:]
            & padded[2:, :-2]
            & padded[2:, 1:-1]
            & padded[2:, 2:]
        )
    return current.astype(np.uint8)


def _connected_components_with_cv2(binary_mask: np.ndarray) -> Optional[Tuple[np.ndarray, List[Dict[str, int]]]]:
    try:
        import cv2
    except Exception:
        return None

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        np.asarray(binary_mask, dtype=np.uint8),
        connectivity=8,
    )
    components: List[Dict[str, int]] = []
    for raw_label in range(1, int(num_labels)):
        left = int(stats[raw_label, cv2.CC_STAT_LEFT])
        top = int(stats[raw_label, cv2.CC_STAT_TOP])
        width = int(stats[raw_label, cv2.CC_STAT_WIDTH])
        height = int(stats[raw_label, cv2.CC_STAT_HEIGHT])
        components.append(
            {
                "raw_label": int(raw_label),
                "area": int(stats[raw_label, cv2.CC_STAT_AREA]),
                "top": top,
                "left": left,
                "bottom": int(top + height - 1),
                "right": int(left + width - 1),
            }
        )
    return labels.astype(np.int32), components


def connected_components(binary_mask: np.ndarray) -> Tuple[np.ndarray, List[Dict[str, int]]]:
    cv2_result = _connected_components_with_cv2(binary_mask)
    if cv2_result is not None:
        return cv2_result

    binary = np.asarray(binary_mask).astype(bool)
    labels = np.zeros(binary.shape, dtype=np.int32)
    components: List[Dict[str, int]] = []
    next_label = 1
    height, width = binary.shape

    for start_y in range(height):
        for start_x in range(width):
            if not binary[start_y, start_x] or labels[start_y, start_x] != 0:
                continue

            stack = [(start_y, start_x)]
            labels[start_y, start_x] = next_label
            area = 0
            top = bottom = start_y
            left = right = start_x

            while stack:
                y, x = stack.pop()
                area += 1
                top = min(top, y)
                bottom = max(bottom, y)
                left = min(left, x)
                right = max(right, x)

                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        if dy == 0 and dx == 0:
                            continue
                        ny = y + dy
                        nx = x + dx
                        if ny < 0 or ny >= height or nx < 0 or nx >= width:
                            continue
                        if binary[ny, nx] and labels[ny, nx] == 0:
                            labels[ny, nx] = next_label
                            stack.append((ny, nx))

            components.append(
                {
                    "raw_label": next_label,
                    "area": int(area),
                    "top": int(top),
                    "left": int(left),
                    "bottom": int(bottom),
                    "right": int(right),
                }
            )
            next_label += 1

    return labels, components


def labeled_mask_to_bboxes(labeled_mask: np.ndarray) -> List[Dict[str, int]]:
    mask = np.asarray(labeled_mask)
    boxes: List[Dict[str, int]] = []
    for label in sorted(int(value) for value in np.unique(mask) if int(value) > 0):
        rows, cols = np.where(mask == label)
        if rows.size == 0:
            continue
        boxes.append(
            {
                "label": int(label),
                "top": int(rows.min()),
                "left": int(cols.min()),
                "bottom": int(rows.max()),
                "right": int(cols.max()),
            }
        )
    return boxes


def labeled_mask_to_object_coords(labeled_mask: np.ndarray) -> List[List[Tuple[int, int]]]:
    mask = np.asarray(labeled_mask)
    object_coords: List[List[Tuple[int, int]]] = []
    for label in sorted(int(value) for value in np.unique(mask) if int(value) > 0):
        rows, cols = np.where(mask == label)
        object_coords.append(list(zip(rows.tolist(), cols.tolist())))
    return object_coords


def postprocess_heatmap(
    scene_heatmap: np.ndarray,
    *,
    threshold: float = 0.7,
    final_erosion_count: int = 0,
    segment_min_size: int = 0,
    max_detections: Optional[int] = None,
) -> Dict[str, Any]:
    heatmap = np.asarray(scene_heatmap, dtype=np.float32)
    if heatmap.ndim != 2:
        raise ValueError("scene_heatmap must be a 2D array.")

    binary_mask = (heatmap >= float(threshold)).astype(np.uint8)
    if int(final_erosion_count) > 0:
        binary_mask = erode_binary_mask(binary_mask, int(final_erosion_count))

    raw_labels, raw_components = connected_components(binary_mask)
    components: List[Dict[str, Any]] = []
    for component in raw_components:
        if int(component["area"]) < int(segment_min_size):
            continue

        component_mask = raw_labels == int(component["raw_label"])
        component_scores = heatmap[component_mask]
        mean_score = float(component_scores.mean()) if component_scores.size else 0.0
        max_score = float(component_scores.max()) if component_scores.size else 0.0
        components.append(
            {
                "source_label": int(component["raw_label"]),
                "area": int(component["area"]),
                "top": int(component["top"]),
                "left": int(component["left"]),
                "bottom": int(component["bottom"]),
                "right": int(component["right"]),
                "mean_score": mean_score,
                "max_score": max_score,
            }
        )

    if max_detections is not None and int(max_detections) > 0:
        components = sorted(
            components,
            key=lambda item: (float(item["max_score"]), float(item["mean_score"]), int(item["area"])),
            reverse=True,
        )[: int(max_detections)]

    labeled_mask = np.zeros_like(raw_labels, dtype=np.int32)
    relabeled_components: List[Dict[str, Any]] = []
    for label, component in enumerate(components, start=1):
        component_mask = raw_labels == int(component["source_label"])
        labeled_mask[component_mask] = label
        relabeled = dict(component)
        relabeled["label"] = int(label)
        relabeled_components.append(relabeled)

    masks = {
        str(component["label"]): (labeled_mask == int(component["label"])).astype(np.uint8)[..., np.newaxis]
        for component in relabeled_components
    }

    return {
        "labeled_mask": labeled_mask,
        "masks": masks,
        "mask_ids": list(masks.keys()),
        "bboxes": labeled_mask_to_bboxes(labeled_mask),
        "object_coords": labeled_mask_to_object_coords(labeled_mask),
        "components": relabeled_components,
        "num_objects": len(relabeled_components),
        "threshold": float(threshold),
        "final_erosion_count": int(final_erosion_count),
        "segment_min_size": int(segment_min_size),
        "max_detections": None if max_detections is None else int(max_detections),
    }


def generate_heatmap_overlay(image: np.ndarray, heatmap: np.ndarray, alpha: float = 0.45) -> np.ndarray:
    import cv2

    image_rgb = ensure_rgb_uint8_image(image)
    heatmap_np = np.asarray(heatmap, dtype=np.float32)
    if heatmap_np.shape != image_rgb.shape[:2]:
        raise ValueError("Heatmap shape must match image height/width.")

    min_value = float(np.min(heatmap_np))
    max_value = float(np.max(heatmap_np))
    if max_value - min_value < 1e-8:
        normalized = np.zeros_like(heatmap_np, dtype=np.uint8)
    else:
        normalized = ((heatmap_np - min_value) / (max_value - min_value) * 255.0).astype(np.uint8)

    heatmap_bgr = cv2.applyColorMap(normalized, cv2.COLORMAP_JET)
    heatmap_rgb = cv2.cvtColor(heatmap_bgr, cv2.COLOR_BGR2RGB)
    return cv2.addWeighted(image_rgb, 1.0 - alpha, heatmap_rgb, alpha, 0.0)


def generate_mask_overlay(image: np.ndarray, labeled_mask: np.ndarray, alpha: float = 0.4) -> np.ndarray:
    import cv2

    image_rgb = ensure_rgb_uint8_image(image)
    mask = np.asarray(labeled_mask)
    if mask.shape != image_rgb.shape[:2]:
        raise ValueError("Mask shape must match image height/width.")

    unique_labels = [int(label) for label in np.unique(mask) if int(label) > 0]
    if not unique_labels:
        return image_rgb.copy()

    overlay = image_rgb.copy()
    label_count = len(unique_labels)
    for index, label in enumerate(unique_labels):
        hue = index / max(label_count, 1)
        color = tuple(int(channel * 255) for channel in colorsys.hsv_to_rgb(hue, 1.0, 1.0))
        overlay[mask == label] = color

    return cv2.addWeighted(image_rgb, 1.0 - alpha, overlay, alpha, 0.0)
