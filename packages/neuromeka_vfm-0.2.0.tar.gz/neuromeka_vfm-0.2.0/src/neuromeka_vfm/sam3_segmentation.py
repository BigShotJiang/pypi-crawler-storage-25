from typing import Any, Dict, Iterable, List, Optional, Set

import numpy as np

from .pickle_client import PickleClient


class Sam3Segmentation:
    """Client for the SAM3 docker server (ZeroMQ pickle RPC)."""

    def __init__(
        self,
        hostname: str = "localhost",
        port: int = 5559,
        timeout_ms: Optional[int] = None,
        validate_capabilities_on_init: bool = True,
    ):
        self.client = PickleClient(hostname, port, timeout_ms=timeout_ms, linger_ms=0)

        self.capabilities: Dict[str, Any] = {}
        self.supported_box_formats: Optional[Set[str]] = None
        self.supported_config_keys: Optional[Set[str]] = None

        self.last_obj_ids: List[str] = []
        self.current_frame_masks: Dict[str, np.ndarray] = {}
        self.last_boxes_xyxy: Optional[np.ndarray] = None
        self.last_scores: Optional[np.ndarray] = None
        self.tracking_object_ids: List[str] = []
        self.invisible_object_ids: List[str] = []
        self.first_frame_registered: bool = False
        self.last_frame_idx: Optional[int] = None
        self._tracking_active: bool = False
        self._tracked_obj_ids: List[str] = []

        if validate_capabilities_on_init:
            self.refresh_capabilities()
            self._validate_box_format("cxcywh_norm")

    @staticmethod
    def _is_success(response: Any) -> bool:
        if not isinstance(response, dict):
            return bool(response)
        for key in ("result", "success", "status"):
            flag = response.get(key)
            if flag is None:
                continue
            if isinstance(flag, str):
                return flag.lower() == "success"
            if isinstance(flag, bool):
                return flag
            return bool(flag)
        return bool(response)

    def _clear_local_state(self) -> None:
        self.last_obj_ids = []
        self.current_frame_masks = {}
        self.last_boxes_xyxy = None
        self.last_scores = None
        self.tracking_object_ids = []
        self.invisible_object_ids = []
        self.first_frame_registered = False
        self.last_frame_idx = None
        self._tracking_active = False
        self._tracked_obj_ids = []

    def _clear_tracking_state(self) -> None:
        self.tracking_object_ids = []
        self.invisible_object_ids = []
        self.current_frame_masks = {}
        self.last_obj_ids = []
        self.last_boxes_xyxy = None
        self.last_scores = None
        self.last_frame_idx = None
        self.first_frame_registered = False
        self._tracking_active = False
        self._tracked_obj_ids = []

    def _set_tracking_state_from_response(self, response: Any) -> None:
        if not isinstance(response, dict):
            return
        data = response.get("data")
        if not isinstance(data, dict):
            return
        obj_ids = self._extract_obj_ids(data.get("obj_ids"))
        self._tracked_obj_ids = obj_ids
        self._tracking_active = bool(obj_ids)

    def _update_capabilities_cache(self, response: Any) -> None:
        if not self._is_success(response):
            return
        if not isinstance(response, dict):
            return
        data = response.get("data", {})
        if not isinstance(data, dict):
            return

        self.capabilities = data
        box_formats = data.get("box_formats")
        config_keys = data.get("config_keys")

        if isinstance(box_formats, (list, tuple, set)):
            self.supported_box_formats = {str(x) for x in box_formats}
        else:
            self.supported_box_formats = None

        if isinstance(config_keys, (list, tuple, set)):
            self.supported_config_keys = {str(x) for x in config_keys}
        else:
            self.supported_config_keys = None

    @staticmethod
    def _mask_to_hw1(mask: Any) -> np.ndarray:
        arr = np.asarray(mask)
        arr = np.squeeze(arr)
        if arr.ndim != 2:
            raise ValueError(f"Mask must be 2D after squeeze. Got shape: {np.asarray(mask).shape}")
        if arr.dtype != np.uint8:
            arr = arr.astype(np.uint8)
        return arr[..., np.newaxis]

    @staticmethod
    def _split_masks(masks: Any) -> List[Any]:
        if masks is None:
            return []
        if isinstance(masks, np.ndarray):
            if masks.ndim == 2:
                return [masks]
            if masks.ndim == 3:
                return [masks[i] for i in range(masks.shape[0])]
            if masks.ndim == 4 and masks.shape[-1] == 1:
                return [masks[i] for i in range(masks.shape[0])]
            return [masks]
        if isinstance(masks, (list, tuple)):
            return list(masks)
        return [masks]

    @staticmethod
    def _normalize_obj_ids(obj_ids: Any, n_masks: int) -> List[str]:
        if obj_ids is None:
            return [f"obj_{i}" for i in range(n_masks)]
        if isinstance(obj_ids, np.ndarray):
            values = obj_ids.tolist()
        elif isinstance(obj_ids, (list, tuple, set)):
            values = list(obj_ids)
        else:
            values = [obj_ids]
        return [str(v) for v in values]

    @staticmethod
    def _extract_obj_ids(obj_ids: Any) -> List[str]:
        if obj_ids is None:
            return []
        if isinstance(obj_ids, np.ndarray):
            values = obj_ids.tolist()
        elif isinstance(obj_ids, (list, tuple, set)):
            values = list(obj_ids)
        else:
            values = [obj_ids]
        return [str(v) for v in values]

    def _update_last_prediction(self, response: Any) -> None:
        if not self._is_success(response):
            return
        if not isinstance(response, dict):
            return
        data = response.get("data", {})
        if not isinstance(data, dict):
            return

        if "frame_idx" in data:
            frame_idx = data.get("frame_idx")
            self.last_frame_idx = int(frame_idx) if frame_idx is not None else None

        masks = data.get("masks")
        mask_list = self._split_masks(masks)
        obj_ids = self._normalize_obj_ids(data.get("obj_ids"), len(mask_list))

        self.last_obj_ids = list(obj_ids)
        self.tracking_object_ids = list(obj_ids)

        boxes_xyxy = data.get("boxes_xyxy")
        self.last_boxes_xyxy = (
            np.asarray(boxes_xyxy, dtype=np.float32) if boxes_xyxy is not None else None
        )

        scores = data.get("scores")
        self.last_scores = np.asarray(scores, dtype=np.float32) if scores is not None else None

        if masks is not None:
            mask_dict: Dict[str, np.ndarray] = {}
            for i, obj_id in enumerate(self.last_obj_ids):
                if i >= len(mask_list):
                    break
                mask = self._mask_to_hw1(mask_list[i])
                if np.any(mask):
                    mask_dict[obj_id] = mask
            self.current_frame_masks = mask_dict
        elif "obj_ids" in data:
            self.current_frame_masks = {
                obj_id: mask
                for obj_id, mask in self.current_frame_masks.items()
                if obj_id in self.last_obj_ids
            }

        self.invisible_object_ids = [
            obj_id for obj_id in self.tracking_object_ids if obj_id not in self.current_frame_masks
        ]

    def _validate_box_format(self, box_format: str) -> None:
        if self.supported_box_formats is None:
            return
        if box_format not in self.supported_box_formats:
            raise ValueError(
                f"Unsupported box_format '{box_format}'. Supported: {sorted(self.supported_box_formats)}"
            )

    def _validate_config_keys(self, config: Dict[str, Any]) -> None:
        if self.supported_config_keys is None:
            return
        unknown = [k for k in config.keys() if k not in self.supported_config_keys]
        if unknown:
            raise ValueError(
                f"Unsupported config keys: {sorted(unknown)}. "
                f"Supported: {sorted(self.supported_config_keys)}"
            )

    def check(self) -> Dict[str, Any]:
        return self.client.send_data({"operation": "check"})

    def get_health(self) -> Dict[str, Any]:
        return self.client.send_data({"operation": "get_health"})

    def get_version(self) -> Dict[str, Any]:
        return self.client.send_data({"operation": "get_version"})

    def refresh_capabilities(self) -> Dict[str, Any]:
        response = self.client.send_data({"operation": "get_capabilities"})
        self._update_capabilities_cache(response)
        return response

    def get_capabilities(self) -> Dict[str, Any]:
        return self.refresh_capabilities()

    def get_config(self) -> Dict[str, Any]:
        return self.client.send_data({"operation": "get_config"})

    def set_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(config, dict):
            raise ValueError("'config' must be a dictionary")
        self._validate_config_keys(config)
        return self.client.send_data({"operation": "set_config", "config": config})

    def get_memory_report(self) -> Dict[str, Any]:
        return self.client.send_data({"operation": "get_memory_report"})

    @property
    def tracking_active(self) -> bool:
        return self._tracking_active

    @property
    def tracked_obj_ids(self) -> List[str]:
        return list(self._tracked_obj_ids)

    def reset(
        self,
        free_vram: bool = True,
        reset_tracking: bool = True,
        drop_tracking_predictor: bool = False,
    ) -> Dict[str, Any]:
        response = self.client.send_data(
            {
                "operation": "reset",
                "free_vram": free_vram,
                "reset_tracking": reset_tracking,
                "drop_tracking_predictor": drop_tracking_predictor,
            }
        )
        if reset_tracking and response.get("result") == "SUCCESS":
            self._clear_tracking_state()
        return response

    def reset_tracking(
        self,
        free_vram: bool = True,
        drop_tracking_predictor: bool = False,
    ) -> Dict[str, Any]:
        return self.reset(
            free_vram=free_vram,
            reset_tracking=True,
            drop_tracking_predictor=drop_tracking_predictor,
        )

    def stop_tracking(
        self,
        free_vram: bool = True,
        drop_tracking_predictor: bool = False,
    ) -> Dict[str, Any]:
        return self.reset_tracking(
            free_vram=free_vram,
            drop_tracking_predictor=drop_tracking_predictor,
        )

    def predict(
        self,
        frame: np.ndarray,
        prompt: Optional[str] = None,
        boxes: Optional[Iterable] = None,
        labels: Optional[Iterable[bool]] = None,
        box_format: str = "cxcywh_norm",
        confidence_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        request: Dict[str, Any] = {
            "operation": "predict",
            "frame": frame,
            "box_format": box_format,
        }
        if prompt is not None:
            request["prompt"] = prompt
        if boxes is not None:
            self._validate_box_format(box_format)
            request["boxes"] = boxes
        if labels is not None:
            request["labels"] = labels
        if confidence_threshold is not None:
            request["confidence_threshold"] = confidence_threshold

        response = self.client.send_data(request)
        self._update_last_prediction(response)
        return response

    def predict_text(
        self,
        frame: np.ndarray,
        prompt: str,
        confidence_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        request: Dict[str, Any] = {
            "operation": "predict_text",
            "frame": frame,
            "prompt": prompt,
        }
        if confidence_threshold is not None:
            request["confidence_threshold"] = confidence_threshold

        response = self.client.send_data(request)
        self._update_last_prediction(response)
        return response

    def predict_box(
        self,
        frame: np.ndarray,
        boxes: Iterable,
        labels: Optional[Iterable[bool]] = None,
        box_format: str = "cxcywh_norm",
        prompt: Optional[str] = None,
        confidence_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        request: Dict[str, Any] = {
            "operation": "predict_box",
            "frame": frame,
            "boxes": boxes,
            "box_format": box_format,
        }
        self._validate_box_format(box_format)

        if labels is not None:
            request["labels"] = labels
        if prompt is not None:
            request["prompt"] = prompt
        if confidence_threshold is not None:
            request["confidence_threshold"] = confidence_threshold

        response = self.client.send_data(request)
        self._update_last_prediction(response)
        return response

    def register_first_frame(
        self,
        frame: np.ndarray,
        boxes: Optional[Iterable] = None,
        phrases: Optional[Iterable[str]] = None,
        points_data: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if points_data is not None and boxes is not None:
            raise ValueError("Use either points_data or boxes/phrases for register_first_frame, not both.")
        if points_data is None and boxes is None:
            raise ValueError("Either points_data or boxes must be provided.")

        request: Dict[str, Any] = {"operation": "register_first_frame", "frame": frame}
        if points_data is not None:
            request["points_data"] = points_data
        else:
            request["boxes"] = boxes
            if phrases is not None:
                request["phrases"] = phrases

        response = self.client.send_data(request)
        self._update_last_prediction(response)
        if self._is_success(response):
            self.first_frame_registered = True
            self._set_tracking_state_from_response(response)
        return response

    def track(self, frame: np.ndarray) -> Dict[str, Any]:
        response = self.client.send_data({"operation": "track", "frame": frame})
        self._update_last_prediction(response)
        if self._is_success(response):
            self._set_tracking_state_from_response(response)
        return response

    def get_next(self, frame: np.ndarray) -> Dict[str, Any]:
        return self.track(frame)

    def remove_object(
        self,
        obj_id: str,
        strict: bool = False,
        need_output: bool = False,
    ) -> Dict[str, Any]:
        response = self.client.send_data(
            {
                "operation": "remove_object",
                "obj_id": obj_id,
                "strict": strict,
                "need_output": need_output,
            }
        )
        if self._is_success(response):
            data = response.get("data", {})
            self._tracked_obj_ids = self._extract_obj_ids(data.get("obj_ids"))
            self._tracking_active = bool(self._tracked_obj_ids)
            self.tracking_object_ids = list(self._tracked_obj_ids)
            self.last_obj_ids = list(self._tracked_obj_ids)
            self.current_frame_masks = {
                current_obj_id: mask
                for current_obj_id, mask in self.current_frame_masks.items()
                if current_obj_id in self._tracked_obj_ids
            }
            self.invisible_object_ids = [
                current_obj_id
                for current_obj_id in self.tracking_object_ids
                if current_obj_id not in self.current_frame_masks
            ]
        return response

    def close(self) -> None:
        try:
            self._clear_local_state()
        finally:
            self.client.close()


NrmkSam3 = Sam3Segmentation
