from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

from .dinov3_client import Dinov3Client
from .dinov3_utils import (
    connected_components,
    ensure_rgb_uint8_image,
    ensure_rgba_uint8_image,
    infer_prompt_points_from_alpha,
    labeled_mask_to_bboxes,
    labeled_mask_to_object_coords,
    normalize_points,
    postprocess_heatmap,
)
from .sam3_segmentation import Sam3Segmentation


DEFAULT_PROMPT_LABEL = "__image_prompt__"
DEFAULT_DINOV3_TIMEOUT_MS = 180000
DEFAULT_SAM3_TIMEOUT_MS = 120000


class Dinov3Sam3DetectionError(RuntimeError):
    """Raised when DINOv3 heatmap to SAM3 mask refinement fails."""


@dataclass
class Dinov3Sam3DetectionConfig:
    backbone: Optional[str] = None
    model_dtype: Optional[str] = None
    prompt_patch_multiplier: int = 25
    scene_patch_multiplier: int = 50
    threshold: float = 0.7
    final_erosion_count: int = 0
    segment_min_size: int = 0
    max_detections: Optional[int] = None
    run_sam3: bool = True
    point_selection_mode: str = "global_top_n"
    min_component_patch_count: int = 1
    sam3_top_n_points: int = 4
    sam3_negative_top_n_points: int = 0
    sam3_negative_score_min: float = 0.15
    sam3_negative_score_max: float = 0.45
    sam3_mask_consensus_mode: str = "area"
    sam3_area_tolerance_ratio: float = 0.01
    sam3_iou_threshold: float = 0.5
    sam3_keep_largest_component: bool = True
    sam3_hostname: Optional[str] = None
    sam3_port: int = 5559
    sam3_timeout_ms: int = DEFAULT_SAM3_TIMEOUT_MS
    sam3_reset_before: bool = True
    sam3_reset_after: bool = True


def _is_success(response: Any) -> bool:
    if not isinstance(response, dict):
        return bool(response)
    for key in ("result", "success", "status"):
        value = response.get(key)
        if value is None:
            continue
        if isinstance(value, str):
            return value.lower() == "success"
        if isinstance(value, bool):
            return value
        return bool(value)
    return bool(response)


def _coerce_config(config: Optional[Any]) -> Dinov3Sam3DetectionConfig:
    if config is None:
        return Dinov3Sam3DetectionConfig()
    if isinstance(config, Dinov3Sam3DetectionConfig):
        return config
    if isinstance(config, dict):
        return Dinov3Sam3DetectionConfig(**dict(config))

    values: Dict[str, Any] = {}
    for field_name in Dinov3Sam3DetectionConfig.__dataclass_fields__:
        if hasattr(config, field_name):
            values[field_name] = getattr(config, field_name)
    if values:
        return Dinov3Sam3DetectionConfig(**values)

    raise TypeError("config must be a Dinov3Sam3DetectionConfig, compatible object, dict, or None.")


def _format_error_response(message: str, *, raw_response: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {
        "status": "error",
        "result": "ERROR",
        "message": message,
        "raw_response": raw_response,
    }


def _build_scene_payload(scene: np.ndarray, patch_multiplier: int) -> Dict[str, Any]:
    return {
        "image": ensure_rgb_uint8_image(scene),
        "patch_multiplier": int(patch_multiplier),
    }


def _build_prompt_payload(
    prompt_image: np.ndarray,
    *,
    label: str = DEFAULT_PROMPT_LABEL,
    points: Optional[Iterable[Any]] = None,
    patch_multiplier: int = 25,
) -> Dict[str, Any]:
    image_rgba = ensure_rgba_uint8_image(prompt_image)
    prompt_points = normalize_points(points) if points is not None else infer_prompt_points_from_alpha(image_rgba)
    if not prompt_points:
        raise ValueError("At least one prompt point is required.")
    return {
        "label": str(label),
        "config": {"patch_multiplier": int(patch_multiplier)},
        "images": [
            {
                "image": image_rgba,
                "points": prompt_points,
                "config": {"patch_multiplier": int(patch_multiplier)},
            }
        ],
    }


def _recover_native_heatmap(processed_heatmap: Any, native_patch_grid_size: Any) -> np.ndarray:
    heatmap = np.asarray(processed_heatmap, dtype=np.float32)
    if heatmap.ndim != 2:
        raise Dinov3Sam3DetectionError(f"DINOv3 heatmap must be 2D. Got shape: {heatmap.shape}")
    grid_height = int(native_patch_grid_size[0])
    grid_width = int(native_patch_grid_size[1])
    if grid_height <= 0 or grid_width <= 0:
        raise Dinov3Sam3DetectionError(f"Invalid native patch grid size: {native_patch_grid_size}")
    if heatmap.shape == (grid_height, grid_width):
        return heatmap.astype(np.float32)

    source_height, source_width = heatmap.shape
    row_indices = np.clip(
        np.floor((np.arange(grid_height, dtype=np.float32) + 0.5) * source_height / grid_height).astype(np.int64),
        0,
        source_height - 1,
    )
    col_indices = np.clip(
        np.floor((np.arange(grid_width, dtype=np.float32) + 0.5) * source_width / grid_width).astype(np.int64),
        0,
        source_width - 1,
    )
    return heatmap[row_indices[:, None], col_indices[None, :]].astype(np.float32)


def _select_primary_component_label(labeled_mask: np.ndarray, scene_heatmap: np.ndarray) -> Optional[int]:
    labels = [int(label) for label in np.unique(labeled_mask) if int(label) > 0]
    if not labels:
        return None

    best_label: Optional[int] = None
    best_score: Optional[Tuple[float, float, int]] = None
    heatmap = np.asarray(scene_heatmap, dtype=np.float32)
    for label in labels:
        component_mask = labeled_mask == label
        component_scores = heatmap[component_mask]
        score_tuple = (
            float(component_scores.mean()) if component_scores.size else 0.0,
            float(component_scores.max()) if component_scores.size else 0.0,
            int(component_mask.sum()),
        )
        if best_score is None or score_tuple > best_score:
            best_score = score_tuple
            best_label = label
    return best_label


def _scene_point_from_patch(
    *,
    row: int,
    col: int,
    grid_height: int,
    grid_width: int,
    scene_height: int,
    scene_width: int,
) -> Tuple[int, int]:
    center_y = int(round((float(row) + 0.5) * float(scene_height) / float(grid_height) - 0.5))
    center_x = int(round((float(col) + 0.5) * float(scene_width) / float(grid_width) - 0.5))
    center_y = max(0, min(center_y, scene_height - 1))
    center_x = max(0, min(center_x, scene_width - 1))
    return center_x, center_y


def _extract_top_patch_points(
    *,
    native_heatmap: np.ndarray,
    selected_component_mask: np.ndarray,
    top_n: int,
    scene_shape: Tuple[int, int],
) -> List[Dict[str, Any]]:
    scene_height, scene_width = scene_shape
    grid_height, grid_width = native_heatmap.shape
    candidates: List[Dict[str, Any]] = []
    for row in range(grid_height):
        for col in range(grid_width):
            point_x, point_y = _scene_point_from_patch(
                row=row,
                col=col,
                grid_height=grid_height,
                grid_width=grid_width,
                scene_height=scene_height,
                scene_width=scene_width,
            )
            inside = bool(selected_component_mask[point_y, point_x])
            candidates.append(
                {
                    "row": int(row),
                    "col": int(col),
                    "point_xy": [int(point_x), int(point_y)],
                    "score": float(native_heatmap[row, col]),
                    "inside_selected_component": inside,
                    "point_label": 1,
                    "is_negative": False,
                }
            )
    candidates.sort(
        key=lambda item: (
            1 if item["inside_selected_component"] else 0,
            float(item["score"]),
        ),
        reverse=True,
    )
    return candidates[: max(0, int(top_n))]


def _extract_component_top_patch_groups(
    *,
    native_heatmap: np.ndarray,
    labeled_mask: np.ndarray,
    top_n_per_component: int,
    scene_shape: Tuple[int, int],
    min_component_patch_count: int,
) -> Tuple[List[List[Dict[str, Any]]], List[Dict[str, Any]]]:
    scene_height, scene_width = scene_shape
    grid_height, grid_width = native_heatmap.shape
    grouped_candidates: Dict[int, List[Dict[str, Any]]] = {}

    for row in range(grid_height):
        for col in range(grid_width):
            point_x, point_y = _scene_point_from_patch(
                row=row,
                col=col,
                grid_height=grid_height,
                grid_width=grid_width,
                scene_height=scene_height,
                scene_width=scene_width,
            )
            component_label = int(labeled_mask[point_y, point_x])
            if component_label <= 0:
                continue
            grouped_candidates.setdefault(component_label, []).append(
                {
                    "row": int(row),
                    "col": int(col),
                    "point_xy": [int(point_x), int(point_y)],
                    "score": float(native_heatmap[row, col]),
                    "component_label": int(component_label),
                    "point_label": 1,
                    "is_negative": False,
                }
            )

    selected_groups: List[List[Dict[str, Any]]] = []
    component_summaries: List[Dict[str, Any]] = []
    for component_label in sorted(grouped_candidates):
        candidates = grouped_candidates[component_label]
        candidates.sort(key=lambda item: float(item["score"]), reverse=True)
        patch_count = len(candidates)
        kept = patch_count >= int(min_component_patch_count)
        selected_points = candidates[: max(0, int(top_n_per_component))] if kept else []
        if selected_points:
            selected_groups.append(selected_points)
        component_summaries.append(
            {
                "component_label": int(component_label),
                "pixel_area": int(np.sum(labeled_mask == component_label)),
                "patch_count": int(patch_count),
                "selected_point_count": int(len(selected_points)),
                "max_patch_score": float(candidates[0]["score"]) if candidates else None,
                "kept": bool(kept),
                "top_points": selected_points,
            }
        )
    return selected_groups, component_summaries


def _extract_negative_patch_points(
    *,
    native_heatmap: np.ndarray,
    exclusion_mask: np.ndarray,
    top_n: int,
    scene_shape: Tuple[int, int],
    min_score: float,
    max_score: float,
) -> List[Dict[str, Any]]:
    if int(top_n) <= 0 or float(max_score) < float(min_score):
        return []

    scene_height, scene_width = scene_shape
    grid_height, grid_width = native_heatmap.shape
    candidates: List[Dict[str, Any]] = []
    for row in range(grid_height):
        for col in range(grid_width):
            point_x, point_y = _scene_point_from_patch(
                row=row,
                col=col,
                grid_height=grid_height,
                grid_width=grid_width,
                scene_height=scene_height,
                scene_width=scene_width,
            )
            if bool(exclusion_mask[point_y, point_x]):
                continue
            score = float(native_heatmap[row, col])
            if score < float(min_score) or score > float(max_score):
                continue
            candidates.append(
                {
                    "row": int(row),
                    "col": int(col),
                    "point_xy": [int(point_x), int(point_y)],
                    "score": score,
                    "inside_selected_component": False,
                    "point_label": 0,
                    "is_negative": True,
                }
            )
    candidates.sort(key=lambda item: float(item["score"]), reverse=True)
    return candidates[: int(top_n)]


def _points_to_sam3_points_data(point_groups: List[List[Dict[str, Any]]]) -> Dict[str, Dict[str, Any]]:
    points_data: Dict[str, Dict[str, Any]] = {}
    for component_index, points in enumerate(point_groups):
        for point_index, point in enumerate(points):
            point_x, point_y = [int(value) for value in point["point_xy"]]
            point_label = int(point.get("point_label", 1))
            points_data[f"component_{component_index}_point_{point_index}"] = {
                "input_point": [[point_x, point_y]],
                "input_label": [point_label],
            }
    return points_data


def _split_sam3_masks(masks: Any) -> List[np.ndarray]:
    if masks is None:
        return []
    if isinstance(masks, np.ndarray):
        if masks.ndim == 2:
            return [masks]
        if masks.ndim == 3:
            return [masks[index] for index in range(masks.shape[0])]
        if masks.ndim == 4 and masks.shape[-1] == 1:
            return [masks[index, ..., 0] for index in range(masks.shape[0])]
        return [masks]
    if isinstance(masks, (list, tuple)):
        return [np.asarray(mask) for mask in masks]
    return [np.asarray(masks)]


def _normalize_obj_ids(obj_ids: Any, n_masks: int) -> List[str]:
    if obj_ids is None:
        return [f"component_0_point_{index}" for index in range(n_masks)]
    if isinstance(obj_ids, np.ndarray):
        values = obj_ids.tolist()
    elif isinstance(obj_ids, (list, tuple, set)):
        values = list(obj_ids)
    else:
        values = [obj_ids]
    normalized = [str(value) for value in values]
    if len(normalized) < n_masks:
        normalized.extend(f"component_0_point_{index}" for index in range(len(normalized), n_masks))
    return normalized[:n_masks]


def _parse_component_index(obj_id: str) -> int:
    prefix = "component_"
    marker = "_point_"
    if not obj_id.startswith(prefix) or marker not in obj_id:
        return 0
    try:
        return int(obj_id[len(prefix) : obj_id.index(marker)])
    except Exception:
        return 0


def _keep_largest_component(mask: np.ndarray) -> Tuple[np.ndarray, int]:
    binary = (np.asarray(mask) > 0).astype(np.uint8)
    if not binary.any():
        return binary, 0
    labels, components = connected_components(binary)
    if not components:
        return binary, int(binary.sum())
    largest = max(components, key=lambda item: int(item["area"]))
    cleaned = (labels == int(largest["raw_label"])).astype(np.uint8)
    return cleaned, int(largest["area"])


def _aggregate_sam3_masks(
    masks: List[np.ndarray],
    *,
    consensus_mode: str,
    area_tolerance_ratio: float,
    iou_threshold: float,
    keep_largest_component: bool,
) -> Dict[str, Any]:
    binary_masks = [(np.asarray(mask).squeeze() > 0).astype(np.uint8) for mask in masks]
    binary_masks = [mask for mask in binary_masks if mask.ndim == 2]
    if not binary_masks:
        raise Dinov3Sam3DetectionError("SAM3 returned no valid 2D masks.")

    mask_areas = [int(mask.sum()) for mask in binary_masks]
    best_cluster: List[int] = []
    best_cluster_score: Optional[Tuple[int, float]] = None
    if consensus_mode == "area":
        for index, area in enumerate(mask_areas):
            tolerance = max(1.0, float(area_tolerance_ratio) * max(float(area), 1.0))
            cluster = [
                candidate
                for candidate, other_area in enumerate(mask_areas)
                if abs(other_area - area) <= tolerance
            ]
            mean_delta = float(np.mean([abs(mask_areas[candidate] - area) for candidate in cluster]))
            score = (len(cluster), -mean_delta)
            if best_cluster_score is None or score > best_cluster_score:
                best_cluster = cluster
                best_cluster_score = score
    elif consensus_mode == "iou":
        for index, mask in enumerate(binary_masks):
            cluster = []
            iou_distances = []
            for candidate, other_mask in enumerate(binary_masks):
                intersection = int(np.logical_and(mask > 0, other_mask > 0).sum())
                union = int(np.logical_or(mask > 0, other_mask > 0).sum())
                iou = float(intersection / union) if union > 0 else 0.0
                if iou >= float(iou_threshold):
                    cluster.append(candidate)
                    iou_distances.append(1.0 - iou)
            score = (len(cluster), -float(np.mean(iou_distances)) if iou_distances else 0.0)
            if best_cluster_score is None or score > best_cluster_score:
                best_cluster = cluster
                best_cluster_score = score
    else:
        raise Dinov3Sam3DetectionError(f"Unsupported SAM3 mask consensus mode: {consensus_mode}")

    accepted_indices = sorted(best_cluster)
    rejected_indices = [index for index in range(len(mask_areas)) if index not in accepted_indices]
    accepted_areas = [mask_areas[index] for index in accepted_indices]
    target_area = float(np.median(accepted_areas))
    representative_index = min(accepted_indices, key=lambda index: abs(mask_areas[index] - target_area))
    representative_mask = binary_masks[representative_index]
    cleaned_mask = representative_mask
    largest_component_area = int(representative_mask.sum())
    if keep_largest_component:
        cleaned_mask, largest_component_area = _keep_largest_component(representative_mask)

    return {
        "consensus_mode": str(consensus_mode),
        "final_mask": cleaned_mask.astype(np.uint8),
        "mask_areas": mask_areas,
        "accepted_indices": accepted_indices,
        "rejected_indices": rejected_indices,
        "representative_index": int(representative_index),
        "representative_area": int(mask_areas[representative_index]),
        "accepted_area_median": float(target_area),
        "keep_largest_component": bool(keep_largest_component),
        "largest_component_area": int(largest_component_area),
    }


def _aggregate_sam3_masks_by_component(
    masks: List[np.ndarray],
    obj_ids: List[str],
    *,
    consensus_mode: str,
    area_tolerance_ratio: float,
    iou_threshold: float,
    keep_largest_component: bool,
) -> Tuple[np.ndarray, List[Dict[str, Any]]]:
    if len(masks) != len(obj_ids):
        raise Dinov3Sam3DetectionError("SAM3 returned mismatched masks and object ids.")

    grouped_indices: Dict[int, List[int]] = {}
    for mask_index, obj_id in enumerate(obj_ids):
        grouped_indices.setdefault(_parse_component_index(str(obj_id)), []).append(mask_index)

    first_mask = np.asarray(masks[0]).squeeze()
    final_labeled_mask = np.zeros(first_mask.shape, dtype=np.int32)
    component_summaries: List[Dict[str, Any]] = []
    next_label = 1

    for component_index in sorted(grouped_indices):
        indices = grouped_indices[component_index]
        aggregation = _aggregate_sam3_masks(
            [masks[index] for index in indices],
            consensus_mode=consensus_mode,
            area_tolerance_ratio=area_tolerance_ratio,
            iou_threshold=iou_threshold,
            keep_largest_component=keep_largest_component,
        )
        final_labeled_mask[aggregation["final_mask"] > 0] = next_label
        component_summaries.append(
            {
                "component_index": int(component_index),
                "final_label": int(next_label),
                "consensus_mode": str(aggregation["consensus_mode"]),
                "keep_largest_component": bool(aggregation["keep_largest_component"]),
                "source_mask_indices": [int(index) for index in indices],
                "mask_areas": aggregation["mask_areas"],
                "accepted_indices_within_component": aggregation["accepted_indices"],
                "rejected_indices_within_component": aggregation["rejected_indices"],
                "representative_index_within_component": aggregation["representative_index"],
                "representative_area": aggregation["representative_area"],
                "accepted_area_median": aggregation["accepted_area_median"],
                "largest_component_area": aggregation["largest_component_area"],
            }
        )
        next_label += 1

    return final_labeled_mask, component_summaries


def refine_dinov3_result_with_sam3(
    scene: np.ndarray,
    dinov3_result: Dict[str, Any],
    *,
    config: Optional[Any] = None,
    sam3_client: Optional[Sam3Segmentation] = None,
    default_sam3_hostname: str = "localhost",
) -> Dict[str, Any]:
    workflow_config = _coerce_config(config)
    scene_rgb = ensure_rgb_uint8_image(scene)
    timing_ms: Dict[str, Any] = dict(dinov3_result.get("timing_ms") or {})
    if not timing_ms and isinstance(dinov3_result.get("metadata"), dict):
        timing_ms = dict(dinov3_result["metadata"].get("timing_ms") or {})
    scene_heatmap = np.asarray(dinov3_result.get("scene_heatmap"), dtype=np.float32)
    if scene_heatmap.ndim != 2:
        raise Dinov3Sam3DetectionError("DINOv3 result must contain a 2D scene_heatmap.")
    if tuple(scene_heatmap.shape) != tuple(scene_rgb.shape[:2]):
        raise Dinov3Sam3DetectionError(
            f"DINOv3 scene_heatmap shape {scene_heatmap.shape} does not match scene shape {scene_rgb.shape[:2]}."
        )

    dino_processed = postprocess_heatmap(
        scene_heatmap,
        threshold=workflow_config.threshold,
        final_erosion_count=workflow_config.final_erosion_count,
        segment_min_size=workflow_config.segment_min_size,
        max_detections=workflow_config.max_detections,
    )
    dino_labeled_mask = np.asarray(dino_processed["labeled_mask"], dtype=np.int32)
    dino_components = list(dino_processed.get("components") or [])

    base_result = dict(dinov3_result)
    base_result.update(
        {
            "dino_labeled_mask": dino_labeled_mask,
            "dino_components": dino_components,
            "dino_bboxes": dino_processed.get("bboxes", []),
            "dino_object_coords": dino_processed.get("object_coords", []),
            "timing_ms": timing_ms,
            "threshold": float(workflow_config.threshold),
            "final_erosion_count": int(workflow_config.final_erosion_count),
            "segment_min_size": int(workflow_config.segment_min_size),
        }
    )

    if not workflow_config.run_sam3:
        base_result.update(dino_processed)
        base_result["sam3"] = {
            "status": "disabled",
            "message": "SAM3 refinement is disabled.",
        }
        return base_result

    if not dino_components:
        base_result.update(
            {
                "masks": {},
                "mask_ids": [],
                "bboxes": [],
                "object_coords": [],
                "components": [],
                "num_objects": 0,
                "sam3": {
                    "status": "skipped_no_components_after_filtering",
                    "message": "No DINO component survived thresholding before SAM3 refinement.",
                    "threshold": float(workflow_config.threshold),
                    "final_erosion_count": int(workflow_config.final_erosion_count),
                    "segment_min_size": int(workflow_config.segment_min_size),
                },
            }
        )
        return base_result

    metadata = dinov3_result.get("metadata") or {}
    native_grid_size = metadata.get("native_patch_grid_size")
    if native_grid_size is None:
        raise Dinov3Sam3DetectionError("DINOv3 metadata does not contain native_patch_grid_size.")
    native_heatmap = _recover_native_heatmap(dinov3_result.get("heatmap"), native_grid_size)

    component_groups: List[List[Dict[str, Any]]] = []
    component_selection: List[Dict[str, Any]] = []
    top_patch_points: List[Dict[str, Any]] = []
    negative_patch_points: List[Dict[str, Any]] = []

    if workflow_config.point_selection_mode == "top_n_per_component":
        component_groups, component_selection = _extract_component_top_patch_groups(
            native_heatmap=native_heatmap,
            labeled_mask=dino_labeled_mask,
            top_n_per_component=workflow_config.sam3_top_n_points,
            scene_shape=scene_rgb.shape[:2],
            min_component_patch_count=workflow_config.min_component_patch_count,
        )
        for group_index, group in enumerate(component_groups):
            for point in group:
                point["sam3_component_index"] = int(group_index)
                top_patch_points.append(point)
    elif workflow_config.point_selection_mode == "global_top_n":
        primary_label = _select_primary_component_label(dino_labeled_mask, scene_heatmap)
        primary_component_mask = dino_labeled_mask == primary_label if primary_label is not None else dino_labeled_mask > 0
        top_patch_points = _extract_top_patch_points(
            native_heatmap=native_heatmap,
            selected_component_mask=primary_component_mask,
            top_n=workflow_config.sam3_top_n_points,
            scene_shape=scene_rgb.shape[:2],
        )
        if top_patch_points:
            component_groups = [top_patch_points]
            component_selection = [
                {
                    "component_label": int(primary_label) if primary_label is not None else None,
                    "pixel_area": int(np.sum(primary_component_mask)),
                    "patch_count": len(top_patch_points),
                    "selected_point_count": len(top_patch_points),
                    "kept": True,
                    "top_points": top_patch_points,
                }
            ]
    else:
        raise Dinov3Sam3DetectionError(f"Unsupported point selection mode: {workflow_config.point_selection_mode}")

    if not component_groups:
        base_result.update(
            {
                "masks": {},
                "mask_ids": [],
                "bboxes": [],
                "object_coords": [],
                "components": [],
                "num_objects": 0,
                "native_heatmap": native_heatmap,
                "sam3": {
                    "status": "skipped_no_patch_points",
                    "message": "No DINO patch points were selected for SAM3 refinement.",
                    "component_selection": component_selection,
                    "point_selection_mode": workflow_config.point_selection_mode,
                },
            }
        )
        return base_result

    negative_exclusion_mask = dino_labeled_mask > 0
    if workflow_config.point_selection_mode == "global_top_n":
        primary_label = _select_primary_component_label(dino_labeled_mask, scene_heatmap)
        if primary_label is not None:
            negative_exclusion_mask = dino_labeled_mask == primary_label
    negative_patch_points = _extract_negative_patch_points(
        native_heatmap=native_heatmap,
        exclusion_mask=negative_exclusion_mask,
        top_n=workflow_config.sam3_negative_top_n_points,
        scene_shape=scene_rgb.shape[:2],
        min_score=workflow_config.sam3_negative_score_min,
        max_score=workflow_config.sam3_negative_score_max,
    )
    sam3_prompt_point_groups = [group + list(negative_patch_points) for group in component_groups]
    points_data = _points_to_sam3_points_data(sam3_prompt_point_groups)
    if not points_data:
        raise Dinov3Sam3DetectionError("No SAM3 prompt points were generated from the DINOv3 heatmap.")

    owns_sam3_client = sam3_client is None
    if sam3_client is None:
        sam3_host = workflow_config.sam3_hostname or default_sam3_hostname
        sam3_client = Sam3Segmentation(
            hostname=str(sam3_host),
            port=int(workflow_config.sam3_port),
            timeout_ms=int(workflow_config.sam3_timeout_ms),
            validate_capabilities_on_init=False,
        )

    sam3_elapsed: Optional[float] = None
    sam3_total_started = time.time()
    try:
        if workflow_config.sam3_reset_before:
            sam3_client.reset()
        sam3_start = time.time()
        sam3_response = sam3_client.register_first_frame(scene_rgb, points_data=points_data)
        sam3_elapsed = time.time() - sam3_start
    finally:
        try:
            if workflow_config.sam3_reset_after:
                sam3_client.reset()
        finally:
            if owns_sam3_client:
                sam3_client.close()
    timing_ms["sam3_register_client_ms"] = (
        float(sam3_elapsed * 1000.0) if sam3_elapsed is not None else None
    )
    timing_ms["sam3_total_client_ms"] = float((time.time() - sam3_total_started) * 1000.0)

    if not _is_success(sam3_response):
        raise Dinov3Sam3DetectionError(
            f"SAM3 request failed: {sam3_response.get('message') or sam3_response.get('error') or 'unknown error'}"
        )
    sam3_data = sam3_response.get("data") or {}
    if sam3_data.get("timing_ms") is not None:
        timing_ms["sam3_server_timing_ms"] = sam3_data.get("timing_ms")
    raw_sam3_masks = sam3_data.get("masks")
    if isinstance(raw_sam3_masks, dict):
        sam3_obj_ids = [str(key) for key in raw_sam3_masks.keys()]
        sam3_masks = [np.asarray(raw_sam3_masks[key]) for key in raw_sam3_masks.keys()]
    else:
        sam3_masks = _split_sam3_masks(raw_sam3_masks)
        sam3_obj_ids = _normalize_obj_ids(sam3_data.get("obj_ids"), len(sam3_masks))
    if not sam3_masks:
        raise Dinov3Sam3DetectionError("SAM3 returned no masks.")

    final_labeled_mask, sam3_component_summaries = _aggregate_sam3_masks_by_component(
        sam3_masks,
        sam3_obj_ids,
        consensus_mode=workflow_config.sam3_mask_consensus_mode,
        area_tolerance_ratio=workflow_config.sam3_area_tolerance_ratio,
        iou_threshold=workflow_config.sam3_iou_threshold,
        keep_largest_component=bool(workflow_config.sam3_keep_largest_component),
    )
    final_processed = postprocess_heatmap(
        (final_labeled_mask > 0).astype(np.float32),
        threshold=0.5,
        final_erosion_count=0,
        segment_min_size=0,
        max_detections=None,
    )
    final_processed["labeled_mask"] = final_labeled_mask.astype(np.int32)
    final_processed["masks"] = {
        str(label): (final_labeled_mask == int(label)).astype(np.uint8)[..., np.newaxis]
        for label in sorted(int(value) for value in np.unique(final_labeled_mask) if int(value) > 0)
    }
    final_processed["mask_ids"] = list(final_processed["masks"].keys())
    final_processed["num_objects"] = len(final_processed["mask_ids"])
    final_processed["bboxes"] = labeled_mask_to_bboxes(final_labeled_mask)
    final_processed["object_coords"] = labeled_mask_to_object_coords(final_labeled_mask)
    final_components: List[Dict[str, Any]] = []
    for bbox in final_processed["bboxes"]:
        label = int(bbox["label"])
        component_mask = final_labeled_mask == label
        component_scores = scene_heatmap[component_mask]
        final_components.append(
            {
                "label": label,
                "area": int(component_mask.sum()),
                "top": int(bbox["top"]),
                "left": int(bbox["left"]),
                "bottom": int(bbox["bottom"]),
                "right": int(bbox["right"]),
                "mean_score": float(component_scores.mean()) if component_scores.size else 0.0,
                "max_score": float(component_scores.max()) if component_scores.size else 0.0,
                "source": "sam3_refinement",
            }
        )
    final_processed["components"] = final_components

    base_result.update(final_processed)
    base_result.update(
        {
            "native_heatmap": native_heatmap,
            "timing_ms": timing_ms,
            "sam3": {
                "status": "success",
                "point_selection_mode": workflow_config.point_selection_mode,
                "top_n_points": int(workflow_config.sam3_top_n_points),
                "negative_top_n_points": int(workflow_config.sam3_negative_top_n_points),
                "negative_score_range": [
                    float(workflow_config.sam3_negative_score_min),
                    float(workflow_config.sam3_negative_score_max),
                ],
                "mask_consensus_mode": workflow_config.sam3_mask_consensus_mode,
                "keep_largest_component": bool(workflow_config.sam3_keep_largest_component),
                "min_component_patch_count": int(workflow_config.min_component_patch_count),
                "component_selection": component_selection,
                "top_patch_points": top_patch_points,
                "negative_patch_points": negative_patch_points,
                "prompt_point_groups": sam3_prompt_point_groups,
                "points_data": points_data,
                "returned_obj_ids": sam3_obj_ids,
                "component_summaries": sam3_component_summaries,
                "iou_threshold": float(workflow_config.sam3_iou_threshold),
                "timing_ms": sam3_data.get("timing_ms"),
                "client_elapsed_seconds": sam3_elapsed,
                "raw_response": sam3_response,
            },
        }
    )
    return base_result


class Dinov3Sam3Detection:
    """High-level DINOv3 image prompt to SAM3-refined mask workflow.

    This class assumes nrmk_dinov3 and nrmk_sam3 servers are already running.
    It does not start Docker or import torch.
    """

    def __init__(
        self,
        hostname: str = "localhost",
        port: int = 5558,
        timeout_ms: int = DEFAULT_DINOV3_TIMEOUT_MS,
        *,
        dinov3_client: Optional[Dinov3Client] = None,
        sam3_client: Optional[Sam3Segmentation] = None,
    ):
        self.hostname = hostname
        self.host = hostname
        self.port = int(port)
        self.timeout_ms = int(timeout_ms)
        self.dinov3_client = dinov3_client or Dinov3Client(
            hostname=self.hostname,
            port=self.port,
            timeout_ms=self.timeout_ms,
        )
        self.sam3_client = sam3_client
        self._owns_dinov3_client = dinov3_client is None

    def get_config(self) -> Dict[str, Any]:
        return self.dinov3_client.get_config()

    def get_capabilities(self) -> Dict[str, Any]:
        return self.dinov3_client.get_capabilities()

    def get_version(self) -> Dict[str, Any]:
        return self.dinov3_client.get_version()

    def get_health(self) -> Dict[str, Any]:
        return self.dinov3_client.get_health()

    def set_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return self.dinov3_client.set_config(config)

    def _apply_dinov3_config(self, config: Dinov3Sam3DetectionConfig) -> Optional[Dict[str, Any]]:
        service_config: Dict[str, Any] = {}
        if config.backbone:
            service_config["backbone"] = config.backbone
        if config.model_dtype:
            service_config["model_dtype"] = config.model_dtype
        if not service_config:
            return None
        return self.set_config(service_config)

    def detect_image_prompt(
        self,
        scene: np.ndarray,
        prompt_image: np.ndarray,
        *,
        label: str = DEFAULT_PROMPT_LABEL,
        points: Optional[Iterable[Any]] = None,
        config: Optional[Any] = None,
        apply_config: bool = True,
    ) -> Dict[str, Any]:
        workflow_config = _coerce_config(config)
        start = time.time()
        if apply_config:
            config_response = self._apply_dinov3_config(workflow_config)
            if config_response is not None and not _is_success(config_response):
                return _format_error_response(
                    f"Failed to set DINOv3 config: {config_response.get('message', 'unknown error')}",
                    raw_response=config_response,
                )

        scene_rgb = ensure_rgb_uint8_image(scene)
        scene_payload = _build_scene_payload(scene_rgb, workflow_config.scene_patch_multiplier)
        prompt_payload = _build_prompt_payload(
            prompt_image,
            label=label,
            points=points,
            patch_multiplier=workflow_config.prompt_patch_multiplier,
        )
        response = self.dinov3_client.register_and_detect(scene_payload, prompt_payload)
        if not _is_success(response):
            return _format_error_response(
                f"Failed to run DINOv3 register_and_detect: {response.get('message', 'unknown error')}",
                raw_response=response,
            )

        data = response.get("data") or {}
        if "results" in data and isinstance(data["results"], dict):
            per_label = {}
            for result_label, result_data in data["results"].items():
                per_label[str(result_label)] = refine_dinov3_result_with_sam3(
                    scene_rgb,
                    result_data,
                    config=workflow_config,
                    sam3_client=self.sam3_client,
                    default_sam3_hostname=self.hostname,
                )
            result_data = {
                "labels": list(per_label.keys()),
                "per_label": per_label,
                "config": data.get("config"),
                "vram_usage": data.get("vram_usage"),
            }
        else:
            result_data = refine_dinov3_result_with_sam3(
                scene_rgb,
                data,
                config=workflow_config,
                sam3_client=self.sam3_client,
                default_sam3_hostname=self.hostname,
            )

        return {
            "status": "success",
            "result": "SUCCESS",
            "data": result_data,
            "raw_response": response,
            "elapsed_seconds": time.time() - start,
        }

    def close(self) -> None:
        if self._owns_dinov3_client:
            self.dinov3_client.close()


NrmkDinov3Sam3Detection = Dinov3Sam3Detection
NrmkDinov3Sam3DetectionConfig = Dinov3Sam3DetectionConfig
