"""
Example client for the SAM3 segmentation server.

Run:
    python -m neuromeka_vfm.examples.sam3_demo \
      --host localhost --port 5559 \
      --image /path/to/image.jpg \
      --mode text --prompt "bolt"

Tracking mode:
    python -m neuromeka_vfm.examples.sam3_demo \
      --host localhost --port 5559 \
      --image /path/to/frame0.jpg \
      --mode track --box 700 470 980 620 --phrase bolt \
      --next-image /path/to/frame1.jpg --next-image /path/to/frame2.jpg
"""

import argparse

import numpy as np
from PIL import Image

from neuromeka_vfm import Sam3Segmentation


def parse_args():
    parser = argparse.ArgumentParser(description="SAM3 segmentation demo")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=5559)
    parser.add_argument("--image", required=True, help="Path to RGB image")
    parser.add_argument(
        "--mode",
        choices=["text", "box", "text_box", "track"],
        default="text",
        help="Inference mode",
    )
    parser.add_argument("--prompt", default=None, help="Text prompt")
    parser.add_argument(
        "--box",
        action="append",
        nargs=4,
        type=float,
        metavar=("X1", "Y1", "X2", "Y2"),
        help="Bounding box. Repeat --box for multiple boxes.",
    )
    parser.add_argument(
        "--box-format",
        default="xyxy_abs",
        choices=[
            "cxcywh_norm",
            "xyxy_abs",
            "xywh_abs",
            "cxcywh_abs",
            "xyxy_norm",
            "xywh_norm",
        ],
    )
    parser.add_argument(
        "--label",
        action="append",
        type=int,
        choices=[0, 1],
        help="Box label. Repeat per box. 1=positive, 0=negative",
    )
    parser.add_argument("--confidence-threshold", type=float, default=None)
    parser.add_argument(
        "--phrase",
        action="append",
        default=None,
        help="Tracking object phrase. Repeat per --box (mode=track).",
    )
    parser.add_argument(
        "--next-image",
        action="append",
        default=None,
        help="Path to next frame image. Repeat to run tracking loop (mode=track).",
    )
    parser.add_argument(
        "--remove-object",
        default=None,
        help="Optional object id to remove after first tracking step (mode=track).",
    )
    parser.add_argument(
        "--save-npz",
        default=None,
        help="Optional output path to save masks/boxes/scores npz",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    image = Image.open(args.image).convert("RGB")
    frame = np.array(image)

    client = Sam3Segmentation(args.host, args.port)
    try:
        if args.mode == "text":
            if args.prompt is None:
                raise ValueError("--prompt is required for mode=text")
            response = client.predict_text(
                frame=frame,
                prompt=args.prompt,
                confidence_threshold=args.confidence_threshold,
            )
        elif args.mode == "box":
            if not args.box:
                raise ValueError("At least one --box is required for mode=box")
            labels = None if args.label is None else [bool(v) for v in args.label]
            response = client.predict_box(
                frame=frame,
                boxes=args.box,
                labels=labels,
                box_format=args.box_format,
                confidence_threshold=args.confidence_threshold,
            )
        elif args.mode == "text_box":
            if args.prompt is None:
                raise ValueError("--prompt is required for mode=text_box")
            if not args.box:
                raise ValueError("At least one --box is required for mode=text_box")
            labels = None if args.label is None else [bool(v) for v in args.label]
            response = client.predict(
                frame=frame,
                prompt=args.prompt,
                boxes=args.box,
                labels=labels,
                box_format=args.box_format,
                confidence_threshold=args.confidence_threshold,
            )
        else:
            if not args.box:
                raise ValueError("At least one --box is required for mode=track")
            if args.phrase is None:
                phrases = [f"obj_{i}" for i in range(len(args.box))]
            else:
                phrases = list(args.phrase)
            if len(phrases) != len(args.box):
                raise ValueError("--phrase count must match --box count in mode=track")

            response = client.register_first_frame(
                frame=frame,
                boxes=args.box,
                phrases=phrases,
            )
            if response.get("result") != "SUCCESS":
                print(response)
                return

            data = response["data"]
            print("Registered frame_idx:", data["frame_idx"])
            print("Tracked obj_ids:", data["obj_ids"])

            next_frames = []
            if args.next_image:
                for next_image_path in args.next_image:
                    next_image = Image.open(next_image_path).convert("RGB")
                    next_frames.append(np.array(next_image))
            else:
                next_frames.append(frame)

            for i, next_frame in enumerate(next_frames, start=1):
                next_response = client.get_next(next_frame)
                if next_response.get("result") != "SUCCESS":
                    print(next_response)
                    return
                next_data = next_response["data"]
                print(
                    f"[track step {i}] obj_count={len(next_data['obj_ids'])}, "
                    f"mask_shape={next_data['masks'].shape}"
                )
                if i == 1 and args.remove_object:
                    remove_response = client.remove_object(args.remove_object)
                    print("remove_object:", remove_response)
            client.stop_tracking(free_vram=True, drop_tracking_predictor=False)
            return

        if response.get("result") != "SUCCESS":
            print(response)
            return

        data = response["data"]
        num_objects = len(data["scores"])
        print(f"Detected objects: {num_objects}")
        print("Scores:", data["scores"])
        print("Boxes (xyxy):", data["boxes_xyxy"])

        if args.save_npz is not None:
            np.savez_compressed(
                args.save_npz,
                masks=data["masks"],
                boxes_xyxy=data["boxes_xyxy"],
                scores=data["scores"],
            )
            print(f"Saved: {args.save_npz}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
