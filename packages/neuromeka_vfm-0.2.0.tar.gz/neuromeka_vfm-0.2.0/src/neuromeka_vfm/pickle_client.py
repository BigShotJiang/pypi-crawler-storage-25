import pickle
import sys

import zmq


def _install_numpy_pickle_compat() -> None:
    try:
        import numpy.core as np_core
        import numpy.core.multiarray as np_multiarray
        import numpy.core.numeric as np_numeric

        sys.modules.setdefault("numpy.core", np_core)
        sys.modules.setdefault("numpy.core.multiarray", np_multiarray)
        sys.modules.setdefault("numpy.core.numeric", np_numeric)
        sys.modules.setdefault("numpy._core", np_core)
        sys.modules.setdefault("numpy._core.multiarray", np_multiarray)
        sys.modules.setdefault("numpy._core.numeric", np_numeric)
    except Exception:
        pass

    try:
        import numpy._core as np__core
        import numpy._core.multiarray as np__multiarray
        import numpy._core.numeric as np__numeric

        sys.modules.setdefault("numpy._core", np__core)
        sys.modules.setdefault("numpy._core.multiarray", np__multiarray)
        sys.modules.setdefault("numpy._core.numeric", np__numeric)
        sys.modules.setdefault("numpy.core", np__core)
        sys.modules.setdefault("numpy.core.multiarray", np__multiarray)
        sys.modules.setdefault("numpy.core.numeric", np__numeric)
    except Exception:
        pass


class PickleClient:
    """Minimal ZeroMQ pickle-based RPC client."""

    def __init__(self, hostname: str, port: int, timeout_ms=None, linger_ms=None):
        _install_numpy_pickle_compat()
        self.hostname = hostname
        self.port = port
        self.context = zmq.Context()
        self.timeout_ms = timeout_ms
        self.linger_ms = linger_ms
        self.socket = None
        self._connect()

    def _connect(self):
        self.socket = self.context.socket(zmq.REQ)
        if self.timeout_ms is not None:
            self.socket.setsockopt(zmq.RCVTIMEO, int(self.timeout_ms))
        if self.linger_ms is not None:
            self.socket.setsockopt(zmq.LINGER, int(self.linger_ms))
        self.socket.connect(f"tcp://{self.hostname}:{self.port}")

    def reconnect(self):
        if self.socket is not None and not self.socket.closed:
            self.socket.close()
        self._connect()

    def send_data(self, data):
        self.socket.send(pickle.dumps(data))
        response = pickle.loads(self.socket.recv())
        return response

    def close(self):
        if self.socket is not None and not self.socket.closed:
            self.socket.close()
        if not self.context.closed:
            self.context.term()
