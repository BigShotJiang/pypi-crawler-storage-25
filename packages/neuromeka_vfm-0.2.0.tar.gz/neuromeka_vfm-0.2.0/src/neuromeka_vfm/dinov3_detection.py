from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional

import numpy as np

from .dinov3_client import Dinov3Client
from .dinov3_utils import (
    ensure_rgb_uint8_image,
    ensure_rgba_uint8_image,
    infer_prompt_points_from_alpha,
    normalize_points,
    postprocess_heatmap,
)


DEFAULT_PROMPT_LABEL = "__image_prompt__"


class Dinov3DetectionError(RuntimeError):
    """Raised when a DINOv3 image-prompt detection request cannot complete."""


@dataclass
class Dinov3DetectionConfig:
    backbone: Optional[str] = None
    model_dtype: Optional[str] = None
    prompt_patch_multiplier: int = 25
    scene_patch_multiplier: int = 50
    threshold: float = 0.7
    final_erosion_count: int = 0
    segment_min_size: int = 0
    max_detections: Optional[int] = None
    run_sam3: bool = False
    point_selection_mode: str = "global_top_n"
    min_component_patch_count: int = 1
    sam3_top_n_points: int = 4
    sam3_negative_top_n_points: int = 0
    sam3_negative_score_min: float = 0.15
    sam3_negative_score_max: float = 0.45
    sam3_mask_consensus_mode: str = "area"
    sam3_area_tolerance_ratio: float = 0.01
    sam3_iou_threshold: float = 0.5
    sam3_keep_largest_component: bool = True
    sam3_hostname: Optional[str] = None
    sam3_port: int = 5559
    sam3_timeout_ms: int = 120000
    sam3_reset_before: bool = True
    sam3_reset_after: bool = True


def _is_success(response: Any) -> bool:
    if not isinstance(response, dict):
        return bool(response)
    for key in ("result", "success", "status"):
        value = response.get(key)
        if value is None:
            continue
        if isinstance(value, str):
            return value.lower() == "success"
        if isinstance(value, bool):
            return value
        return bool(value)
    return bool(response)


def _coerce_config(config: Optional[Any]) -> Dinov3DetectionConfig:
    if config is None:
        return Dinov3DetectionConfig()
    if isinstance(config, Dinov3DetectionConfig):
        return config
    if isinstance(config, dict):
        return Dinov3DetectionConfig(**dict(config))
    raise TypeError("config must be a Dinov3DetectionConfig, dict, or None.")


class Dinov3Detection:
    """High-level DINOv3 image-prompt detection client.

    The class assumes an nrmk_dinov3 ZeroMQ server is already running. It does not
    start Docker, load weights, or import torch.
    """

    def __init__(
        self,
        hostname: str = "localhost",
        port: int = 5558,
        timeout_ms: int = 180000,
        *,
        client: Optional[Dinov3Client] = None,
        validate_capabilities_on_init: bool = False,
    ):
        self.hostname = hostname
        self.host = hostname
        self.port = int(port)
        self.timeout_ms = int(timeout_ms)
        self.client = client or Dinov3Client(
            hostname=self.hostname,
            port=self.port,
            timeout_ms=self.timeout_ms,
        )
        self.capabilities: Dict[str, Any] = {}
        if validate_capabilities_on_init:
            self.refresh_capabilities()

    def refresh_capabilities(self) -> Dict[str, Any]:
        response = self.client.get_capabilities()
        if _is_success(response) and isinstance(response.get("data"), dict):
            self.capabilities = response["data"]
        return response

    def get_capabilities(self) -> Dict[str, Any]:
        return self.refresh_capabilities()

    def get_config(self) -> Dict[str, Any]:
        return self.client.get_config()

    def get_health(self) -> Dict[str, Any]:
        return self.client.get_health()

    def get_version(self) -> Dict[str, Any]:
        return self.client.get_version()

    def set_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return self.client.set_config(config)

    def _apply_config(self, config: Dinov3DetectionConfig) -> Optional[Dict[str, Any]]:
        service_config: Dict[str, Any] = {}
        if config.backbone:
            service_config["backbone"] = config.backbone
        if config.model_dtype:
            service_config["model_dtype"] = config.model_dtype
        if not service_config:
            return None
        current_response = self.get_config()
        if _is_success(current_response) and isinstance(current_response.get("data"), dict):
            current = current_response["data"]
            pending: Dict[str, Any] = {}
            requested_backbone = service_config.get("backbone")
            if requested_backbone:
                current_backbone = str(current.get("backbone") or "").strip()
                current_backbone_resolved = str(current.get("backbone_resolved") or "").strip()
                requested = str(requested_backbone).strip()
                if requested not in {current_backbone, current_backbone_resolved}:
                    if f"dinov3_{requested}" != current_backbone_resolved:
                        pending["backbone"] = requested_backbone
            requested_dtype = service_config.get("model_dtype")
            if requested_dtype and str(requested_dtype) != str(current.get("model_dtype")):
                pending["model_dtype"] = requested_dtype
            if not pending:
                return {
                    "status": "success",
                    "result": "SUCCESS",
                    "data": {"applied": [], "skipped": sorted(service_config)},
                }
            service_config = pending
        return self.set_config(service_config)

    @staticmethod
    def build_scene_payload(scene: np.ndarray, patch_multiplier: int) -> Dict[str, Any]:
        return {
            "image": ensure_rgb_uint8_image(scene),
            "patch_multiplier": int(patch_multiplier),
        }

    @staticmethod
    def build_prompt_payload(
        prompt_image: np.ndarray,
        *,
        label: str = DEFAULT_PROMPT_LABEL,
        points: Optional[Iterable[Any]] = None,
        patch_multiplier: int = 25,
    ) -> Dict[str, Any]:
        image_rgba = ensure_rgba_uint8_image(prompt_image)
        prompt_points = normalize_points(points) if points is not None else infer_prompt_points_from_alpha(image_rgba)
        if not prompt_points:
            raise ValueError("At least one prompt point is required.")

        return {
            "label": str(label),
            "config": {"patch_multiplier": int(patch_multiplier)},
            "images": [
                {
                    "image": image_rgba,
                    "points": prompt_points,
                    "config": {"patch_multiplier": int(patch_multiplier)},
                }
            ],
        }

    def _format_error_response(self, response: Dict[str, Any], action: str) -> Dict[str, Any]:
        return {
            "status": "error",
            "result": "ERROR",
            "message": f"Failed to {action}: {response.get('message', 'unknown error')}",
            "raw_response": response,
            "elapsed_seconds": response.get("elapsed_seconds"),
        }

    def _postprocess_single_result(
        self,
        data: Dict[str, Any],
        config: Dinov3DetectionConfig,
    ) -> Dict[str, Any]:
        scene_heatmap = np.asarray(data.get("scene_heatmap"), dtype=np.float32)
        heatmap = np.asarray(data.get("heatmap"), dtype=np.float32) if data.get("heatmap") is not None else None
        processed = postprocess_heatmap(
            scene_heatmap,
            threshold=config.threshold,
            final_erosion_count=config.final_erosion_count,
            segment_min_size=config.segment_min_size,
            max_detections=config.max_detections,
        )

        result = {
            "label": data.get("label"),
            "heatmap": heatmap,
            "scene_heatmap": scene_heatmap,
            "timing_ms": data.get("timing_ms") or (data.get("metadata") or {}).get("timing_ms") or {},
            "metadata": data.get("metadata", {}),
            "config": data.get("config"),
            "vram_usage": data.get("vram_usage"),
            "prompt": data.get("prompt"),
        }
        result.update(processed)
        return result

    def _postprocess_response_data(
        self,
        data: Dict[str, Any],
        config: Dinov3DetectionConfig,
    ) -> Dict[str, Any]:
        if "results" in data and isinstance(data["results"], dict):
            per_label = {
                str(label): self._postprocess_single_result(result, config)
                for label, result in data["results"].items()
            }
            return {
                "labels": list(per_label.keys()),
                "per_label": per_label,
                "config": data.get("config"),
                "vram_usage": data.get("vram_usage"),
            }
        return self._postprocess_single_result(data, config)

    def _postprocess_response_data_with_optional_sam3(
        self,
        scene: np.ndarray,
        data: Dict[str, Any],
        config: Dinov3DetectionConfig,
    ) -> Dict[str, Any]:
        if not bool(config.run_sam3):
            return self._postprocess_response_data(data, config)

        from .dinov3_sam3_detection import refine_dinov3_result_with_sam3

        if "results" in data and isinstance(data["results"], dict):
            per_label = {
                str(label): refine_dinov3_result_with_sam3(
                    scene,
                    result,
                    config=config,
                    default_sam3_hostname=config.sam3_hostname or self.hostname,
                )
                for label, result in data["results"].items()
            }
            return {
                "labels": list(per_label.keys()),
                "per_label": per_label,
                "config": data.get("config"),
                "vram_usage": data.get("vram_usage"),
            }

        return refine_dinov3_result_with_sam3(
            scene,
            data,
            config=config,
            default_sam3_hostname=config.sam3_hostname or self.hostname,
        )

    def register_image_prompt(
        self,
        prompt_image: np.ndarray,
        *,
        label: str = DEFAULT_PROMPT_LABEL,
        points: Optional[Iterable[Any]] = None,
        config: Optional[Any] = None,
        apply_config: bool = True,
    ) -> Dict[str, Any]:
        detection_config = _coerce_config(config)
        if apply_config:
            config_response = self._apply_config(detection_config)
            if config_response is not None and not _is_success(config_response):
                return self._format_error_response(config_response, "set DINOv3 config")

        prompt_payload = self.build_prompt_payload(
            prompt_image,
            label=label,
            points=points,
            patch_multiplier=detection_config.prompt_patch_multiplier,
        )
        return self.client.register(prompt=prompt_payload)

    def detect_registered(
        self,
        scene: np.ndarray,
        *,
        label: str = DEFAULT_PROMPT_LABEL,
        config: Optional[Any] = None,
        apply_config: bool = False,
    ) -> Dict[str, Any]:
        detection_config = _coerce_config(config)
        if apply_config:
            config_response = self._apply_config(detection_config)
            if config_response is not None and not _is_success(config_response):
                return self._format_error_response(config_response, "set DINOv3 config")

        scene_payload = self.build_scene_payload(
            scene,
            patch_multiplier=detection_config.scene_patch_multiplier,
        )
        response = self.client.detect(label=label, scene=scene_payload)
        if not _is_success(response):
            return self._format_error_response(response, "detect registered DINOv3 prompt")

        try:
            result_data = self._postprocess_response_data_with_optional_sam3(
                scene,
                response.get("data", {}),
                detection_config,
            )
        except Exception as exc:
            return {
                "status": "error",
                "result": "ERROR",
                "message": str(exc),
                "raw_response": response,
                "elapsed_seconds": response.get("elapsed_seconds"),
            }
        return {
            "status": "success",
            "result": "SUCCESS",
            "data": result_data,
            "raw_response": response,
            "elapsed_seconds": response.get("elapsed_seconds"),
        }

    def detect_image_prompt(
        self,
        scene: np.ndarray,
        prompt_image: np.ndarray,
        *,
        label: str = DEFAULT_PROMPT_LABEL,
        points: Optional[Iterable[Any]] = None,
        config: Optional[Any] = None,
        apply_config: bool = True,
    ) -> Dict[str, Any]:
        detection_config = _coerce_config(config)
        if apply_config:
            config_response = self._apply_config(detection_config)
            if config_response is not None and not _is_success(config_response):
                return self._format_error_response(config_response, "set DINOv3 config")

        scene_payload = self.build_scene_payload(
            scene,
            patch_multiplier=detection_config.scene_patch_multiplier,
        )
        prompt_payload = self.build_prompt_payload(
            prompt_image,
            label=label,
            points=points,
            patch_multiplier=detection_config.prompt_patch_multiplier,
        )
        response = self.client.register_and_detect(scene_payload, prompt_payload)
        if not _is_success(response):
            return self._format_error_response(response, "run DINOv3 register_and_detect")

        try:
            result_data = self._postprocess_response_data_with_optional_sam3(
                scene,
                response.get("data", {}),
                detection_config,
            )
        except Exception as exc:
            return {
                "status": "error",
                "result": "ERROR",
                "message": str(exc),
                "raw_response": response,
                "elapsed_seconds": response.get("elapsed_seconds"),
            }
        return {
            "status": "success",
            "result": "SUCCESS",
            "data": result_data,
            "raw_response": response,
            "elapsed_seconds": response.get("elapsed_seconds"),
        }

    def close(self) -> None:
        self.client.close()


NrmkDinov3Detection = Dinov3Detection
NrmkDinov3ImageSegmentation = Dinov3Detection
NrmkDinov3DetectionConfig = Dinov3DetectionConfig
