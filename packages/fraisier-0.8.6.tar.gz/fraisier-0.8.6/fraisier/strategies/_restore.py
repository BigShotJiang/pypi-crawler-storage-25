"""Staging strategy: full backup restore lifecycle, then migrate up."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from fraisier.dbops.confiture import migrate_down, migrate_up

from ._base import Strategy, StrategyResult

log = logging.getLogger(__name__)


@dataclass
class RestoreConfig:
    """Structured configuration for the restore_migrate strategy."""

    db_name: str
    backup_dir: Path
    backup_pattern: str = "*.dump"
    max_age_hours: float = 48.0
    target_owner: str | None = None
    create_template: bool = False
    template_name: str | None = None
    min_tables: int = 0
    backup_path: Path | None = None
    service_name: str | None = None


class RestoreMigrateStrategy(Strategy):
    """Staging: full backup restore lifecycle, then migrate up.

    Steps:
    1. Find latest backup matching pattern in backup_dir
    2. Validate backup age (< max_age_hours)
    3. Stop service (if service_name configured, prevents connection reconnect)
    4. Terminate all connections to target database
    5. DROP DATABASE IF EXISTS + CREATE DATABASE
    6. pg_restore --no-owner --no-acl
    7. REASSIGN OWNED to target_owner (if configured)
    8. CREATE DATABASE template (if create_template=true)
    9. confiture migrate up
    10. Validate table count >= min_tables (if configured)
    11. Start service (if service_name configured)

    Rollback: template-based (instant) or migrate_down.
    """

    def __init__(self, config: RestoreConfig, *, admin_url: str) -> None:
        from fraisier.dbops._validation import validate_pg_identifier

        validate_pg_identifier(config.db_name, "database name")
        if config.target_owner:
            validate_pg_identifier(config.target_owner, "target owner")
        if config.template_name:
            validate_pg_identifier(config.template_name, "template name")
        self._config = config
        self._admin_url = admin_url

    @property
    def _resolved_template_name(self) -> str:
        return self._config.template_name or f"template_{self._config.db_name}"

    def execute(
        self,
        confiture_config: Path,
        *,
        migrations_dir: Path = Path("db/migrations"),
        allow_irreversible: bool = False,
        pre_migrate_verify: bool = False,
        database_url: str | None = None,
        hooks_config: dict[str, Any] | None = None,
    ) -> StrategyResult:
        from fraisier.dbops.operations import (
            create_db,
            drop_db,
            start_service,
            stop_service,
            terminate_backends,
        )
        from fraisier.dbops.restore import (
            find_latest_backup,
            restore_backup,
            validate_backup_age,
            validate_table_count,
        )
        from fraisier.errors import DatabaseError

        cfg = self._config

        # Step 1: Resolve backup file
        if cfg.backup_path is not None:
            backup_file = cfg.backup_path
            log.info("Using explicit backup: %s", backup_file)
        else:
            backup_file = find_latest_backup(cfg.backup_dir, pattern=cfg.backup_pattern)
            if backup_file is None:
                raise DatabaseError(
                    f"No backup matching '{cfg.backup_pattern}' in {cfg.backup_dir}",
                )
            log.info("Found backup: %s", backup_file)

            # Step 2: Validate backup age (only when not explicit)
            if not validate_backup_age(backup_file, max_age_hours=cfg.max_age_hours):
                raise DatabaseError(
                    f"Backup {backup_file.name} is older than {cfg.max_age_hours}h",
                )

        # Step 3: Stop service to prevent connection reconnect race
        if cfg.service_name:
            code, _, stderr = stop_service(cfg.service_name)
            if code != 0:
                raise DatabaseError(
                    f"Failed to stop service {cfg.service_name}: {stderr.strip()}",
                )
            log.info("Stopped service %s", cfg.service_name)

        # Step 4: Terminate connections
        terminate_backends(cfg.db_name, connection_url=self._admin_url)
        log.info("Terminated connections to %s", cfg.db_name)

        # Step 5: Drop and recreate database
        code, _, stderr = drop_db(cfg.db_name, connection_url=self._admin_url)
        if code != 0:
            raise DatabaseError(
                f"Failed to drop database {cfg.db_name}: {stderr.strip()}",
            )
        code, _, stderr = create_db(cfg.db_name, connection_url=self._admin_url)
        if code != 0:  # pragma: no cover
            raise DatabaseError(
                f"Failed to create database {cfg.db_name}: {stderr.strip()}",
            )
        log.info("Recreated database %s", cfg.db_name)

        # Step 6 + 7: pg_restore (with optional ownership fix)
        restore_result = restore_backup(
            backup_path=str(backup_file),
            db_name=cfg.db_name,
            db_owner=cfg.target_owner,
            connection_url=self._admin_url,
        )
        if not restore_result.success:
            raise DatabaseError(
                f"pg_restore failed: {restore_result.error}",
            )
        log.info("Restored backup into %s", cfg.db_name)

        # Step 8: Create rollback template
        if cfg.create_template:
            template_name = self._resolved_template_name
            # Drop existing template if any, disconnect from source, create
            terminate_backends(template_name, connection_url=self._admin_url)
            drop_db(template_name, connection_url=self._admin_url)
            terminate_backends(cfg.db_name, connection_url=self._admin_url)
            code, _, stderr = create_db(
                template_name, template=cfg.db_name, connection_url=self._admin_url
            )
            if code != 0:  # pragma: no cover
                raise DatabaseError(
                    f"Failed to create template {template_name}: {stderr.strip()}",
                )
            log.info("Created rollback template %s", template_name)

        # Step 9: Migrate up
        result = migrate_up(
            confiture_config,
            migrations_dir=migrations_dir,
            database_url=database_url,
            hooks_config=hooks_config,
        )
        log.info("Applied %d migrations", result.steps_applied)

        # Step 10: Validate table count
        if cfg.min_tables > 0:
            ok, count = validate_table_count(
                cfg.db_name,
                min_threshold=cfg.min_tables,
                connection_url=self._admin_url,
            )
            if not ok:
                raise DatabaseError(
                    f"Table count validation failed: {count} < {cfg.min_tables}",
                )
            log.info("Table count validation passed: %d >= %d", count, cfg.min_tables)

        # Step 11: Start service
        if cfg.service_name:
            code, _, stderr = start_service(cfg.service_name)
            if code != 0:
                raise DatabaseError(
                    f"Failed to start service {cfg.service_name}: {stderr.strip()}",
                )
            log.info("Started service %s", cfg.service_name)

        return StrategyResult(success=True, migrations_applied=result.steps_applied)

    def rollback(
        self,
        confiture_config: Path,
        *,
        migrations_dir: Path = Path("db/migrations"),
        steps: int,
        database_url: str | None = None,
        hooks_config: dict[str, Any] | None = None,
    ) -> StrategyResult:
        if self._config.create_template:
            from fraisier.dbops.templates import reset_from_template

            template_name = self._resolved_template_name
            # Compute the prefix that makes prefix + db_name == template_name
            prefix = template_name.removesuffix(self._config.db_name)
            if prefix + self._config.db_name != template_name:
                # Custom template name doesn't follow prefix convention —
                # do drop + create manually.
                from fraisier.dbops.operations import (
                    create_db,
                    drop_db,
                    terminate_backends,
                )

                terminate_backends(self._config.db_name, connection_url=self._admin_url)
                code, _, stderr = drop_db(
                    self._config.db_name, connection_url=self._admin_url
                )
                if code != 0:  # pragma: no cover
                    return StrategyResult(
                        success=False,
                        errors=[
                            f"Failed to drop database for rollback: {stderr.strip()}"
                        ],
                    )
                terminate_backends(template_name, connection_url=self._admin_url)
                code, _, stderr = create_db(
                    self._config.db_name,
                    template=template_name,
                    connection_url=self._admin_url,
                )
                if code != 0:  # pragma: no cover
                    return StrategyResult(
                        success=False,
                        errors=[f"Template rollback failed: {stderr.strip()}"],
                    )
                return StrategyResult(success=True)

            tmpl_result = reset_from_template(
                self._config.db_name,
                prefix=prefix,
                connection_url=self._admin_url,
            )
            if not tmpl_result.success:  # pragma: no cover
                return StrategyResult(
                    success=False,
                    errors=[f"Template rollback failed: {tmpl_result.error}"],
                )
            return StrategyResult(success=True)

        result = migrate_down(
            confiture_config,
            migrations_dir=migrations_dir,
            steps=steps,
            database_url=database_url,
            hooks_config=hooks_config,
        )
        return StrategyResult(
            success=result.success,
            migrations_applied=result.steps_applied,
            errors=result.errors,
        )
