"""
HTTP-Client fuer die Open Food Facts API.
Basis-URL: https://world.openfoodfacts.org
Kein API-Key noetig — vollstaendig kostenlos und open-source.
"""

import httpx
from typing import Any

# Basis-URLs der Open Food Facts API
BASE_URL = "https://world.openfoodfacts.org"
SEARCH_URL = "https://world.openfoodfacts.org/cgi/search.pl"

# Standard-Headers fuer Open Food Facts (User-Agent empfohlen)
HEADERS = {
    "User-Agent": "openfoodfacts-mcp-server/0.1.0 (https://github.com/AiAgentKarl/openfoodfacts-mcp-server)"
}


async def get_product_by_barcode(barcode: str) -> dict[str, Any]:
    """Ruft Produktdaten anhand des Barcodes ab."""
    url = f"{BASE_URL}/api/v2/product/{barcode}.json"
    async with httpx.AsyncClient(headers=HEADERS, timeout=15.0) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.json()


async def search_products(
    query: str,
    page: int = 1,
    page_size: int = 10,
    fields: str = "code,product_name,brands,categories,nutrition_grades,ecoscore_grade,allergens_tags,image_front_url"
) -> dict[str, Any]:
    """Sucht Produkte anhand eines Suchbegriffs."""
    params = {
        "search_terms": query,
        "search_simple": 1,
        "action": "process",
        "json": 1,
        "page": page,
        "page_size": page_size,
        "fields": fields,
    }
    async with httpx.AsyncClient(headers=HEADERS, timeout=15.0) as client:
        response = await client.get(SEARCH_URL, params=params)
        response.raise_for_status()
        return response.json()


async def search_by_category(
    category: str,
    page: int = 1,
    page_size: int = 10
) -> dict[str, Any]:
    """Sucht Produkte anhand einer Kategorie."""
    url = f"{BASE_URL}/category/{category}.json"
    params = {"page": page, "page_size": page_size}
    async with httpx.AsyncClient(headers=HEADERS, timeout=15.0) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        return response.json()
