"""
OpenFoodFacts MCP Server — Haupteinstiegspunkt.
Gibt AI-Agents Zugriff auf 3M+ Lebensmittelprodukte weltweit.
Kein API-Key noetig — vollstaendig kostenlos und open-source.
"""

from fastmcp import FastMCP
from src.tools.food_tools import (
    lookup_product_by_barcode,
    search_food,
    get_nutrition_facts,
    check_allergens,
    get_eco_score,
    find_alternatives,
    get_product_additives,
    get_product_labels,
)

# FastMCP-Server initialisieren
mcp = FastMCP(
    "openfoodfacts-mcp-server",
    instructions=(
        "MCP Server fuer Open Food Facts — die groesste Open-Source-Lebensmitteldatenbank der Welt "
        "mit 3M+ Produkten aus 200+ Laendern. Verfuegbare Tools: "
        "lookup_product_by_barcode (Barcode-Suche), search_food (Textsuche), "
        "get_nutrition_facts (Naehrwertdetails + Nutri-Score), check_allergens (14 EU-Allergene), "
        "get_eco_score (Umweltbewertung + CO2), find_alternatives (bessere Produkte finden), "
        "get_product_additives (E-Nummern/Zusatzstoffe), get_product_labels (Bio/Vegan/Fairtrade/Halal). "
        "Kein API-Key noetig."
    )
)

# Alle Tools beim Server registrieren
mcp.tool()(lookup_product_by_barcode)
mcp.tool()(search_food)
mcp.tool()(get_nutrition_facts)
mcp.tool()(check_allergens)
mcp.tool()(get_eco_score)
mcp.tool()(find_alternatives)
mcp.tool()(get_product_additives)
mcp.tool()(get_product_labels)


def main():
    """Startet den MCP-Server ueber stdio-Transport."""
    mcp.run()


if __name__ == "__main__":
    main()
