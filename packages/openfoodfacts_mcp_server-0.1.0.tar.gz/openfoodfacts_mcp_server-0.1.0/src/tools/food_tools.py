"""
Tool-Funktionen fuer Open Food Facts.
Reine async-Funktionen — werden in server.py mit @mcp.tool() registriert.
"""

from src.clients.openfoodfacts_client import (
    get_product_by_barcode,
    search_products,
)


def _extract_nutriments(nutriments: dict) -> dict:
    """Extrahiert die wichtigsten Naehrwerte aus dem nutriments-Objekt."""
    keys = [
        ("energy-kcal_100g", "energie_kcal_pro_100g"),
        ("proteins_100g", "proteine_pro_100g"),
        ("carbohydrates_100g", "kohlenhydrate_pro_100g"),
        ("sugars_100g", "davon_zucker_pro_100g"),
        ("fat_100g", "fett_pro_100g"),
        ("saturated-fat_100g", "davon_gesaettigt_pro_100g"),
        ("fiber_100g", "ballaststoffe_pro_100g"),
        ("salt_100g", "salz_pro_100g"),
        ("sodium_100g", "natrium_pro_100g"),
    ]
    result = {}
    for api_key, label in keys:
        val = nutriments.get(api_key)
        if val is not None:
            result[label] = round(float(val), 2)
    return result


async def lookup_product_by_barcode(barcode: str) -> dict:
    """
    Ruft vollstaendige Produktinformationen anhand des Barcodes ab.
    Gibt Name, Marke, Naehrwerte, Allergene und Bewertungen zurueck.

    Args:
        barcode: EAN-Barcode des Produkts (z.B. 3017620422003 fuer Nutella)
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt mit Barcode '{barcode}' nicht gefunden.", "status": 0}

        product = data.get("product", {})
        nutriments = product.get("nutriments", {})

        return {
            "barcode": barcode,
            "name": product.get("product_name", ""),
            "generischer_name": product.get("generic_name", ""),
            "marke": product.get("brands", ""),
            "menge": product.get("quantity", ""),
            "kategorien": product.get("categories", ""),
            "laender": product.get("countries", ""),
            "zutaten": product.get("ingredients_text", ""),
            "allergene": product.get("allergens", ""),
            "spuren_von": product.get("traces", ""),
            "naehrwerte_pro_100g": _extract_nutriments(nutriments),
            "nutriscore": product.get("nutrition_grades", ""),
            "ecoscore": product.get("ecoscore_grade", ""),
            "nova_gruppe": product.get("nova_group", ""),
            "palmoel": product.get("ingredients_from_palm_oil_n", 0),
            "bild_url": product.get("image_front_url", ""),
            "openfoodfacts_url": f"https://world.openfoodfacts.org/product/{barcode}",
        }
    except Exception as e:
        return {"fehler": str(e)}


async def search_food(
    query: str,
    max_results: int = 10,
    page: int = 1
) -> dict:
    """
    Sucht Lebensmittelprodukte nach Name, Zutat oder Marke.
    Gibt eine Liste von passenden Produkten mit Grundinformationen zurueck.

    Args:
        query: Suchbegriff (z.B. "Schokolade", "vegan pasta", "Bio Joghurt")
        max_results: Anzahl der Ergebnisse (1-20, Standard: 10)
        page: Seite der Ergebnisse (Standard: 1)
    """
    try:
        max_results = max(1, min(20, max_results))
        data = await search_products(query, page=page, page_size=max_results)
        products = data.get("products", [])
        total = data.get("count", 0)

        results = []
        for p in products:
            results.append({
                "barcode": p.get("code", ""),
                "name": p.get("product_name", ""),
                "marke": p.get("brands", ""),
                "kategorien": p.get("categories", ""),
                "nutriscore": p.get("nutrition_grades", ""),
                "ecoscore": p.get("ecoscore_grade", ""),
                "allergene": ", ".join(p.get("allergens_tags", [])),
                "bild": p.get("image_front_url", ""),
            })

        return {
            "suchanfrage": query,
            "gesamt_treffer": total,
            "seite": page,
            "ergebnisse": results,
        }
    except Exception as e:
        return {"fehler": str(e)}


async def get_nutrition_facts(barcode: str) -> dict:
    """
    Ruft detaillierte Naehrwertinformationen fuer ein Produkt ab.
    Gibt Kalorien, Makros, Vitamine und Nutri-Score mit Bewertung zurueck.

    Args:
        barcode: EAN-Barcode des Produkts
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt '{barcode}' nicht gefunden."}

        product = data.get("product", {})
        nutriments = product.get("nutriments", {})
        nutriscore = product.get("nutrition_grades", "").upper()

        nutriscore_erklaerung = {
            "A": "Sehr gut — sehr nahrhafte Lebensmittel",
            "B": "Gut — nahrhafte Lebensmittel",
            "C": "Mittel — akzeptable Naehrwerte",
            "D": "Schlecht — wenig nahrhafte Lebensmittel",
            "E": "Sehr schlecht — sehr ungesunde Naehrwerte",
        }.get(nutriscore, "Nicht bewertet")

        return {
            "produkt": product.get("product_name", ""),
            "barcode": barcode,
            "portion": product.get("serving_size", "Nicht angegeben"),
            "naehrwerte_pro_100g": _extract_nutriments(nutriments),
            "nutriscore": nutriscore,
            "nutriscore_bedeutung": nutriscore_erklaerung,
            "nova_gruppe": product.get("nova_group", ""),
            "nova_erklaerung": {
                1: "Unverarbeitete oder minimal verarbeitete Lebensmittel",
                2: "Verarbeitete kulinarische Zutaten",
                3: "Verarbeitete Lebensmittel",
                4: "Ultra-verarbeitete Produkte",
            }.get(product.get("nova_group"), "Nicht klassifiziert"),
        }
    except Exception as e:
        return {"fehler": str(e)}


async def check_allergens(barcode: str) -> dict:
    """
    Prueft alle Allergene und Spurenbestandteile eines Produkts.
    Gibt eine strukturierte Liste der 14 EU-Hauptallergene zurueck.

    Args:
        barcode: EAN-Barcode des Produkts
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt '{barcode}' nicht gefunden."}

        product = data.get("product", {})

        eu_allergene = [
            "en:gluten", "en:crustaceans", "en:eggs", "en:fish",
            "en:peanuts", "en:soybeans", "en:milk", "en:nuts",
            "en:celery", "en:mustard", "en:sesame-seeds",
            "en:sulphur-dioxide-and-sulphites", "en:lupin", "en:molluscs"
        ]

        allergen_tags = product.get("allergens_tags", [])
        traces_tags = product.get("traces_tags", [])

        def tag_to_name(tag: str) -> str:
            return tag.replace("en:", "").replace("-", " ").title()

        enthaltene = [tag_to_name(t) for t in allergen_tags]
        spuren = [tag_to_name(t) for t in traces_tags]
        eu_gefunden = [tag_to_name(t) for t in allergen_tags if t in eu_allergene]

        return {
            "produkt": product.get("product_name", ""),
            "barcode": barcode,
            "zutaten_text": product.get("ingredients_text", "Nicht angegeben"),
            "allergene_enthalten": enthaltene,
            "spuren_von": spuren,
            "eu_hauptallergene_enthalten": eu_gefunden,
            "palmoel_zutaten": product.get("ingredients_from_palm_oil_n", 0),
            "hinweis": "Immer auch Originalverpackung pruefen — Rezeptureaenderungen moeglich.",
        }
    except Exception as e:
        return {"fehler": str(e)}


async def get_eco_score(barcode: str) -> dict:
    """
    Ruft den Eco-Score und Umweltinformationen eines Produkts ab.
    Gibt CO2-Fussabdruck, Verpackung, Herkunft und Umweltbewertung zurueck.

    Args:
        barcode: EAN-Barcode des Produkts
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt '{barcode}' nicht gefunden."}

        product = data.get("product", {})
        ecoscore = product.get("ecoscore_grade", "").upper()

        ecoscore_erklaerung = {
            "A": "Sehr geringe Umweltauswirkungen",
            "B": "Geringe Umweltauswirkungen",
            "C": "Mittlere Umweltauswirkungen",
            "D": "Hohe Umweltauswirkungen",
            "E": "Sehr hohe Umweltauswirkungen",
        }.get(ecoscore, "Nicht bewertet")

        ecoscore_data = product.get("ecoscore_data", {})
        adjustments = ecoscore_data.get("adjustments", {})
        packaging = adjustments.get("packaging", {})
        origins = adjustments.get("origins_of_ingredients", {})

        return {
            "produkt": product.get("product_name", ""),
            "barcode": barcode,
            "ecoscore": ecoscore,
            "ecoscore_bedeutung": ecoscore_erklaerung,
            "ecoscore_punkte": ecoscore_data.get("score", ""),
            "co2_gesamt_kg_pro_kg": ecoscore_data.get("co2_total", ""),
            "verpackung_punktabzug": packaging.get("score", ""),
            "herkunft_info": origins.get("value", ""),
            "laender_des_produkts": product.get("countries", ""),
            "labels": product.get("labels", ""),
            "bio_zertifiziert": "bio" in product.get("labels", "").lower() or
                                "organic" in product.get("labels", "").lower(),
        }
    except Exception as e:
        return {"fehler": str(e)}


async def find_alternatives(
    barcode: str,
    besser_nutriscore: bool = True,
    besser_ecoscore: bool = False,
    max_results: int = 5
) -> dict:
    """
    Findet gesundheitlich oder oekologisch bessere Alternativen zu einem Produkt.
    Sucht in derselben Produktkategorie nach besser bewerteten Optionen.

    Args:
        barcode: EAN-Barcode des Referenzprodukts
        besser_nutriscore: Nur Produkte mit besserem Nutri-Score zurueckgeben
        besser_ecoscore: Nur Produkte mit besserem Eco-Score zurueckgeben
        max_results: Maximale Anzahl der Alternativen (1-10)
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Referenzprodukt '{barcode}' nicht gefunden."}

        product = data.get("product", {})
        product_name = product.get("product_name", "")
        current_nutriscore = product.get("nutrition_grades", "e")
        current_ecoscore = product.get("ecoscore_grade", "e")

        search_term = product_name.split(" ")[0] if product_name else "food"
        search_results = await search_products(
            search_term, page_size=20,
            fields="code,product_name,brands,nutrition_grades,ecoscore_grade,allergens_tags,image_front_url"
        )

        nutriscore_order = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "": 6}
        current_ns_rank = nutriscore_order.get(current_nutriscore.lower(), 6)
        current_es_rank = nutriscore_order.get(current_ecoscore.lower(), 6)

        alternativen = []
        max_results = max(1, min(10, max_results))
        for p in search_results.get("products", []):
            if p.get("code") == barcode:
                continue
            ns = p.get("nutrition_grades", "")
            es = p.get("ecoscore_grade", "")
            ns_rank = nutriscore_order.get(ns.lower(), 6)
            es_rank = nutriscore_order.get(es.lower(), 6)

            if besser_nutriscore and ns_rank >= current_ns_rank:
                continue
            if besser_ecoscore and es_rank >= current_es_rank:
                continue

            alternativen.append({
                "barcode": p.get("code", ""),
                "name": p.get("product_name", ""),
                "marke": p.get("brands", ""),
                "nutriscore": ns.upper(),
                "ecoscore": es.upper(),
                "allergene": ", ".join(p.get("allergens_tags", [])),
                "bild": p.get("image_front_url", ""),
            })
            if len(alternativen) >= max_results:
                break

        return {
            "referenz_produkt": product_name,
            "referenz_barcode": barcode,
            "referenz_nutriscore": current_nutriscore.upper(),
            "referenz_ecoscore": current_ecoscore.upper(),
            "alternativen_gefunden": len(alternativen),
            "alternativen": alternativen,
            "hinweis": "Alternativen basieren auf aehnlichen Produkten in Open Food Facts.",
        }
    except Exception as e:
        return {"fehler": str(e)}


async def get_product_additives(barcode: str) -> dict:
    """
    Listet alle Zusatzstoffe (E-Nummern) eines Produkts auf.
    Gibt Risikoklasse und Beschreibung der Zusatzstoffe zurueck.

    Args:
        barcode: EAN-Barcode des Produkts
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt '{barcode}' nicht gefunden."}

        product = data.get("product", {})
        additives_tags = product.get("additives_tags", [])

        def tag_to_e_number(tag: str) -> str:
            return tag.replace("en:e", "E").replace("en:", "").upper()

        e_nummern = [tag_to_e_number(t) for t in additives_tags]

        return {
            "produkt": product.get("product_name", ""),
            "barcode": barcode,
            "anzahl_zusatzstoffe": len(e_nummern),
            "e_nummern": e_nummern,
            "nova_gruppe": product.get("nova_group", ""),
            "zutaten_text": product.get("ingredients_text", "Nicht angegeben"),
            "hinweis": "Fuer detaillierte E-Nummer-Infos: https://www.zusatzstoffe-online.de",
            "openfoodfacts_url": f"https://world.openfoodfacts.org/product/{barcode}",
        }
    except Exception as e:
        return {"fehler": str(e)}


async def get_product_labels(barcode: str) -> dict:
    """
    Gibt alle Zertifizierungen und Labels eines Produkts zurueck.
    Z.B. Bio, Fairtrade, Vegan, Vegetarisch, Halal, Koscher, Glutenfrei.

    Args:
        barcode: EAN-Barcode des Produkts
    """
    try:
        data = await get_product_by_barcode(barcode)
        if data.get("status") != 1:
            return {"fehler": f"Produkt '{barcode}' nicht gefunden."}

        product = data.get("product", {})
        labels_tags = product.get("labels_tags", [])
        labels_text = product.get("labels", "")

        def hat_label(keyword: str) -> bool:
            return any(keyword in t.lower() for t in labels_tags) or keyword in labels_text.lower()

        return {
            "produkt": product.get("product_name", ""),
            "barcode": barcode,
            "alle_labels": labels_text,
            "zertifizierungen": {
                "bio_eu": hat_label("organic") or hat_label("bio"),
                "fairtrade": hat_label("fairtrade"),
                "vegan": hat_label("vegan"),
                "vegetarisch": hat_label("vegetarian") or hat_label("vegetarisch"),
                "halal": hat_label("halal"),
                "koscher": hat_label("kosher") or hat_label("koscher"),
                "glutenfrei": hat_label("gluten-free") or hat_label("glutenfrei"),
                "laktosefrei": hat_label("lactose-free") or hat_label("laktosefrei"),
                "rainforest_alliance": hat_label("rainforest"),
                "palm_oil_free": hat_label("palm-oil-free"),
            },
            "herstellungsland": product.get("manufacturing_places", ""),
            "laender_des_produkts": product.get("countries", ""),
        }
    except Exception as e:
        return {"fehler": str(e)}
