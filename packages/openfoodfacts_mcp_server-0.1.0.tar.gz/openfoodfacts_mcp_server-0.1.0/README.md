# openfoodfacts-mcp-server

MCP Server for Open Food Facts — the world's largest open-source food product database with 3M+ products from 200+ countries. No API key required.

[![PyPI version](https://badge.fury.io/py/openfoodfacts-mcp-server.svg)](https://badge.fury.io/py/openfoodfacts-mcp-server)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- **Barcode Lookup** — Get full product info by EAN barcode
- **Product Search** — Search 3M+ products by name, ingredient, or brand
- **Nutrition Facts** — Detailed nutritional data + Nutri-Score (A–E)
- **Allergen Check** — All 14 EU major allergens + traces
- **Eco-Score** — Environmental impact, CO₂ footprint, packaging info
- **Find Alternatives** — Find healthier or more eco-friendly products
- **Additives / E-Numbers** — List all additives in a product
- **Labels & Certifications** — Organic, Vegan, Fairtrade, Halal, Kosher, Gluten-Free

## Installation

```bash
pip install openfoodfacts-mcp-server
```

## Usage

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "openfoodfacts": {
      "command": "openfoodfacts-mcp-server"
    }
  }
}
```

### Direct Run

```bash
openfoodfacts-mcp-server
```

## Tools

| Tool | Description |
|------|-------------|
| `lookup_product_by_barcode` | Full product info by EAN barcode |
| `search_food` | Search products by name, ingredient, or brand |
| `get_nutrition_facts` | Nutrition data + Nutri-Score explanation |
| `check_allergens` | All 14 EU allergens + traces |
| `get_eco_score` | Eco-Score + CO₂ + packaging info |
| `find_alternatives` | Better products by Nutri-Score or Eco-Score |
| `get_product_additives` | E-numbers / additives list |
| `get_product_labels` | Organic, Vegan, Fairtrade, Halal, Kosher, etc. |

## Example Queries

```
"What are the allergens in product 3017620422003?"
"Find vegan pasta products with a good Nutri-Score"
"What is the eco-score of this chocolate bar?"
"Find healthier alternatives to this snack"
"List all E-numbers in product 5449000214911"
```

## Data Source

All data comes from [Open Food Facts](https://world.openfoodfacts.org) — a free, open-source, collaborative food database. No API key required. Data is available under the Open Database License (ODbL).

## License

MIT © AiAgentKarl
