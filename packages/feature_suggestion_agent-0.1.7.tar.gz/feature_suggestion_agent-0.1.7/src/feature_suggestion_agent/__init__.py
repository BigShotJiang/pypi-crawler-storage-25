"""
Feature creation Agent Package

An intelligent agent for creating new features for machine learning tasks.
"""

from .agent import FeatureSuggestionAgent
from .models import (
    FeatureInput, 
    FeatureOutput, 
    FeaturesListModel
)

__version__ = "0.1.6"
__all__ = [
    "FeatureSuggestionAgent",
    "FeatureInput",
    "FeatureOutput",
    "FeaturesListModel"
]