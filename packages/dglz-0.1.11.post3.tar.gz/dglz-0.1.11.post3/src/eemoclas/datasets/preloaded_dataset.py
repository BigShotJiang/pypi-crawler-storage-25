"""Memory-efficient preloading for resampled EEG datasets.

Provides two operating modes transparently selected at runtime:

* **Full mode** -- all compressed samples fit in RAM.  Data stays resident
  for the entire training run (no eviction between epochs).
* **Streaming mode** -- a dynamic sliding-window queue preloads upcoming
  samples, evicts consumed ones, and adjusts the window size based on
  real-time system memory pressure.

The mode is **never** decided upfront.  Samples are loaded progressively;
only when 100 % are successfully cached does the preloader upgrade to
full mode, eliminating race conditions when multiple classifiers start
simultaneously.

Cross-platform memory detection:

* Linux  -- ``/proc/meminfo``
* Windows -- ``ctypes`` → ``GlobalMemoryStatusEx``
* macOS  -- ``sysctl``
"""

from __future__ import annotations

import logging
import platform
import subprocess
from typing import Any, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

logger = logging.getLogger("dglz.preload")


# =====================================================================
# Cross-platform memory detection
# =====================================================================


def _get_memory_info() -> tuple[int, int]:
    """Return ``(total_bytes, available_bytes)`` for the current system.

    Uses platform-native APIs.  Falls back to (8 GB, 4 GB) with a
    warning when the platform is unsupported or detection fails.
    """
    system = platform.system()
    try:
        if system == "Linux":
            return _linux_memory_info()
        if system == "Windows":
            return _windows_memory_info()
        if system == "Darwin":
            return _macos_memory_info()
    except Exception as exc:
        logger.warning("Memory detection failed on %s: %s", system, exc)

    logger.warning(
        "Unsupported platform '%s'; assuming 8 GB total / 4 GB available.",
        system,
    )
    return (8 * 1024**3, 4 * 1024**3)


def _linux_memory_info() -> tuple[int, int]:
    """Read ``/proc/meminfo`` for *MemTotal* and *MemAvailable*."""
    total = available = 0
    with open("/proc/meminfo") as fh:
        for line in fh:
            parts = line.split()
            if not parts:
                continue
            key, value = parts[0], parts[1]
            if key == "MemTotal:":
                total = int(value) * 1024
            elif key == "MemAvailable:":
                available = int(value) * 1024
            if total and available:
                break
    if not available:
        available = total // 2
    return total, available


def _windows_memory_info() -> tuple[int, int]:
    """Call ``GlobalMemoryStatusEx`` via *ctypes*."""
    import ctypes

    class _MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    stat = _MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(stat)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))  # type: ignore[attr-defined]
    return int(stat.ullTotalPhys), int(stat.ullAvailPhys)


def _macos_memory_info() -> tuple[int, int]:
    """Read ``hw.memsize`` and ``vm_stat`` on macOS."""
    import re

    total = int(
        subprocess.check_output(["sysctl", "-n", "hw.memsize"], stderr=subprocess.DEVNULL).strip()
    )
    vm_out = subprocess.check_output(["vm_stat"], stderr=subprocess.DEVNULL).decode()
    page_size = 4096
    free_pages = inactive_pages = 0
    for line in vm_out.splitlines():
        m = re.match(r"Pages free:\s+(\d+)", line)
        if m:
            free_pages = int(m.group(1))
        m = re.match(r"Pages inactive:\s+(\d+)", line)
        if m:
            inactive_pages = int(m.group(1))
    available = (free_pages + inactive_pages) * page_size
    return total, min(available, total)


# =====================================================================
# Tensor helpers
# =====================================================================

_COMPRESSION_DTYPES = {
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
}


def _compress_tensor(t: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
    """Compress a float tensor; non-float tensors pass through."""
    if t.is_floating_point() and t.dtype != dtype:
        return t.to(dtype)
    return t


def _decompress_tensor(t: torch.Tensor) -> torch.Tensor:
    """Cast a compressed tensor back to ``torch.float32``."""
    if t.is_floating_point() and t.dtype != torch.float32:
        return t.float()
    return t


def _tensor_bytes(t: torch.Tensor) -> int:
    """Number of bytes occupied by a tensor's storage."""
    return t.nelement() * t.element_size()


# =====================================================================
# CompressedPreloader
# =====================================================================


class CompressedPreloader:
    """Progressive in-memory cache with dynamic sliding-window eviction.

    Parameters
    ----------
    dataset:
        The underlying :class:`ResampledTensorDataset`.
    compression:
        ``"float16"`` | ``"bfloat16"`` | ``"none"``.
    system_reserve_ratio:
        Fraction of *total* RAM reserved for the OS (default 5 %).
    skip_meta:
        When *True* the ``meta`` dict is **not** cached (saves memory;
        ``meta`` is unused during the forward pass).
    val_indices:
        Optional validation-set indices.  Used for unified memory budget
        calculation when ``preload_val`` is enabled.
    """

    def __init__(
        self,
        dataset: Dataset,
        *,
        compression: str = "float16",
        system_reserve_ratio: float = 0.05,
        skip_meta: bool = True,
        val_indices: np.ndarray | list[int] | None = None,
    ) -> None:
        self._dataset = dataset
        self._skip_meta = skip_meta
        self._system_reserve_ratio = system_reserve_ratio

        if compression == "none":
            self._comp_dtype: Optional[torch.dtype] = None
        else:
            self._comp_dtype = _COMPRESSION_DTYPES.get(compression)
            if self._comp_dtype is None:
                raise ValueError(
                    f"Unknown compression '{compression}'. "
                    f"Choose from: {list(_COMPRESSION_DTYPES)} or 'none'."
                )

        self._val_indices = list(val_indices) if val_indices is not None else []

        # Cache state
        self._cache: dict[int, dict[str, Any]] = {}
        self._shared_token_meta: list[dict] | None = None
        self._full_mode: bool = False
        self._access_order: list[int] = []
        self._tail_ptr: int = 0  # next index in access_order to prefetch
        self._bytes_used: int = 0
        self._sample_bytes_est: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def prepare_epoch(self, access_order: list[int]) -> None:
        """Initialise the preloader for a new epoch.

        * On first call (or after :meth:`clear`): loads samples
          progressively until the memory budget is exhausted or all
          samples are cached.
        * In full mode (already 100 % cached): only updates the access
          order (new shuffle); no re-loading.
        """
        self._access_order = list(access_order)

        if self._full_mode:
            logger.debug("prepare_epoch: full mode – access order updated (%d samples)", len(self._access_order))
            return

        # First-time or streaming-mode setup
        self._cache.clear()
        self._tail_ptr = 0
        self._bytes_used = 0
        self._shared_token_meta = None
        self._full_mode = False

        n_total = len(self._access_order) + len(self._val_indices)

        # Estimate per-sample size by loading one sample
        if self._sample_bytes_est == 0:
            self._sample_bytes_est = self._estimate_sample_bytes()

        budget = self._compute_budget()
        n_cacheable = min(n_total, budget // max(1, self._sample_bytes_est))

        logger.info(
            "Preload: budget=%.1f MB, est. sample=%.1f KB, "
            "total samples=%d, cacheable=%d",
            budget / 1024**2,
            self._sample_bytes_est / 1024,
            n_total,
            n_cacheable,
        )

        # Preload up to cacheable samples
        to_load = min(n_cacheable, len(self._access_order))
        for i in range(to_load):
            self._prefetch_one(self._access_order[i])

        # Attempt to preload val samples if budget allows
        if self._val_indices:
            for vi in self._val_indices:
                if self._bytes_used + self._sample_bytes_est > budget:
                    break
                self._prefetch_one(vi)

        # Check if all samples loaded → upgrade to full mode
        self._check_full_mode()

        logger.info(
            "Preload: cached %d/%d train samples, %d/%d val samples, "
            "%.1f MB used, full_mode=%s",
            min(to_load, len(self._access_order)),
            len(self._access_order),
            sum(1 for v in self._val_indices if v in self._cache),
            len(self._val_indices),
            self._bytes_used / 1024**2,
            self._full_mode,
        )

    def get(self, ds_idx: int) -> dict | None:
        """Return a **decompressed** sample from cache, or *None*."""
        raw = self._cache.get(ds_idx)
        if raw is None:
            return None
        return self._decompress_sample(raw)

    def on_consumed(self, ds_idx: int) -> None:
        """Called after a training sample has been used for a forward pass.

        In streaming mode: evicts the consumed sample, reads real-time
        memory, and prefetches upcoming samples to fill freed space.
        In full mode: no-op.
        """
        if self._full_mode:
            return

        # Evict consumed sample
        self._evict(ds_idx)

        # Read real-time memory and decide how many to prefetch
        budget = self._compute_budget()
        headroom = budget - self._bytes_used

        # If memory is tight, evict oldest unconsumed samples
        while headroom < 0 and self._cache:
            # Find oldest cached sample that hasn't been consumed yet
            # (not the current one, which was already evicted)
            oldest = next(iter(self._cache))
            self._evict(oldest)
            headroom = budget - self._bytes_used

        # Prefetch as many upcoming samples as budget allows
        if headroom > 0 and self._sample_bytes_est > 0:
            n_prefetch = min(
                headroom // self._sample_bytes_est,
                len(self._access_order) - self._tail_ptr,
            )
            for _ in range(max(0, n_prefetch)):
                if self._tail_ptr >= len(self._access_order):
                    break
                self._prefetch_one(self._access_order[self._tail_ptr])

        self._check_full_mode()

    @property
    def full_mode(self) -> bool:
        return self._full_mode

    @property
    def n_cached(self) -> int:
        return len(self._cache)

    @property
    def bytes_used(self) -> int:
        return self._bytes_used

    def clear(self) -> None:
        """Release all cached data.  Called when switching k-fold folds."""
        self._cache.clear()
        self._shared_token_meta = None
        self._full_mode = False
        self._tail_ptr = 0
        self._bytes_used = 0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_budget(self) -> int:
        """Memory budget = MemAvailable - TotalRAM × reserve_ratio."""
        total, available = _get_memory_info()
        reserve = int(total * self._system_reserve_ratio)
        return max(0, available - reserve)

    def _estimate_sample_bytes(self) -> int:
        """Estimate compressed byte size of one sample by loading the first."""
        if len(self._dataset) == 0:
            return 0
        sample = self._dataset[0]
        total = 0
        for key, value in sample.items():
            if key == "token_meta":
                # Will be shared – counted once globally, not per-sample
                continue
            if key == "meta" and self._skip_meta:
                continue
            if isinstance(value, torch.Tensor):
                if value.is_floating_point() and self._comp_dtype is not None:
                    total += value.nelement() * self._comp_dtype.itemsize
                else:
                    total += _tensor_bytes(value)
            elif isinstance(value, str):
                total += len(value.encode("utf-8"))
            elif isinstance(value, (int, float)):
                total += 8
            elif isinstance(value, list):
                total += 64  # rough estimate for list-of-str/int
        return total

    def _prefetch_one(self, ds_idx: int) -> None:
        """Load a single sample, compress it, and cache it."""
        if ds_idx in self._cache:
            return
        sample = self._dataset[ds_idx]
        compressed: dict[str, Any] = {}

        # Share token_meta globally
        if self._shared_token_meta is None and "token_meta" in sample:
            self._shared_token_meta = sample["token_meta"]

        for key, value in sample.items():
            if key == "token_meta":
                continue  # shared, not per-sample
            if key == "meta" and self._skip_meta:
                continue
            if isinstance(value, torch.Tensor) and self._comp_dtype is not None:
                old_bytes = _tensor_bytes(value)
                compressed[key] = _compress_tensor(value, self._comp_dtype)
                new_bytes = _tensor_bytes(compressed[key])
                self._bytes_used += new_bytes
                # Account for Python dict/tensor object overhead (~128 bytes)
                self._bytes_used += 128
            elif isinstance(value, torch.Tensor):
                compressed[key] = value
                self._bytes_used += _tensor_bytes(value) + 128
            else:
                compressed[key] = value
                # Rough overhead for non-tensor values
                self._bytes_used += 64

        self._cache[ds_idx] = compressed
        if isinstance(self._access_order, list):
            # Update tail pointer if this index is in the access order
            while self._tail_ptr < len(self._access_order):
                if self._access_order[self._tail_ptr] in self._cache:
                    self._tail_ptr += 1
                else:
                    break

    def _evict(self, ds_idx: int) -> None:
        """Remove a cached sample and reclaim its memory."""
        compressed = self._cache.pop(ds_idx, None)
        if compressed is None:
            return
        for key, value in compressed.items():
            if isinstance(value, torch.Tensor):
                self._bytes_used -= _tensor_bytes(value) + 128
            else:
                self._bytes_used -= 64
        # Clamp to zero in case of estimation drift
        self._bytes_used = max(0, self._bytes_used)

    def _decompress_sample(self, compressed: dict) -> dict:
        """Cast compressed tensors back to float32 and attach shared metadata."""
        result: dict[str, Any] = {}
        for key, value in compressed.items():
            if isinstance(value, torch.Tensor):
                result[key] = _decompress_tensor(value)
            else:
                result[key] = value

        # Attach shared token_meta
        if self._shared_token_meta is not None:
            result["token_meta"] = self._shared_token_meta

        # If meta was skipped, provide a minimal placeholder
        if self._skip_meta and "meta" not in result:
            result["meta"] = {}

        return result

    def _check_full_mode(self) -> None:
        """Upgrade to full mode if all samples are cached."""
        if self._full_mode:
            return
        all_indices = set(self._access_order) | set(self._val_indices)
        if all_indices and all(idx in self._cache for idx in all_indices):
            self._full_mode = True
            logger.info(
                "Preload: all %d samples cached (%.1f MB) – upgraded to full mode.",
                len(all_indices),
                self._bytes_used / 1024**2,
            )


# =====================================================================
# PreloadingTrainLoader
# =====================================================================


class PreloadingTrainLoader:
    """Drop-in DataLoader replacement with per-epoch sliding-window preloading.

    The :class:`Trainer` does not need modification – ``for batch in
    loader`` works as expected.

    Each ``__iter__`` call (new epoch):

    1. Generates a freshly shuffled access order.
    2. Calls :meth:`CompressedPreloader.prepare_epoch` (first epoch
       loads data; subsequent epochs in full mode only update order).
    3. Yields batches, calling :meth:`on_consumed` after each sample.
    """

    def __init__(
        self,
        preloader: CompressedPreloader,
        dataset: Dataset,
        train_idx: np.ndarray | list[int],
        batch_size: int,
        collate_fn: Any,
        seed: int = 42,
    ) -> None:
        self._preloader = preloader
        self._dataset = dataset
        self._train_idx = np.asarray(train_idx)
        self._batch_size = batch_size
        self._collate_fn = collate_fn
        self._seed = seed
        self._epoch = 0

    def __iter__(self):
        # Generate shuffled order for this epoch
        rng = np.random.default_rng(self._seed + self._epoch)
        shuffled = self._train_idx[rng.permutation(len(self._train_idx))].tolist()
        self._epoch += 1

        # Prepare preloader with new access order
        self._preloader.prepare_epoch(shuffled)

        # Yield batches
        batch_samples: list[dict] = []
        for ds_idx in shuffled:
            sample = self._preloader.get(ds_idx)
            if sample is None:
                # Cache miss – load from disk
                sample = self._dataset[ds_idx]

            batch_samples.append(sample)
            self._preloader.on_consumed(ds_idx)

            if len(batch_samples) == self._batch_size:
                yield self._collate_fn(batch_samples)
                batch_samples = []

        # Remaining samples
        if batch_samples:
            yield self._collate_fn(batch_samples)

    def __len__(self) -> int:
        return (len(self._train_idx) + self._batch_size - 1) // self._batch_size


# =====================================================================
# PreloadedDataset (full-mode Dataset wrapper)
# =====================================================================


class PreloadedDataset(Dataset):
    """Simple Dataset wrapper for full-mode preloading.

    All samples are assumed to be in the preloader's cache.  Falls back
    to the original dataset for any cache misses.
    """

    def __init__(
        self,
        preloader: CompressedPreloader,
        original_dataset: Dataset,
        indices: np.ndarray | list[int] | None = None,
    ) -> None:
        self._preloader = preloader
        self._original = original_dataset
        self._indices = list(indices) if indices is not None else None

    def __len__(self) -> int:
        if self._indices is not None:
            return len(self._indices)
        return len(self._original)

    def __getitem__(self, idx: int) -> dict:
        ds_idx = self._indices[idx] if self._indices is not None else idx
        sample = self._preloader.get(ds_idx)
        if sample is not None:
            return sample
        return self._original[ds_idx]
