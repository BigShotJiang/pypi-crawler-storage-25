"""Tests for the preloaded dataset module.

Covers: progressive loading, full-mode upgrade, dynamic sliding window,
cross-platform memory detection, compression, format compatibility,
collate compatibility, and configuration integration.
"""

from __future__ import annotations

import os
import tempfile
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest
import torch

from eemoclas.datasets.collate import collate_emotion, collate_subject_state
from eemoclas.datasets.preloaded_dataset import (
    CompressedPreloader,
    PreloadedDataset,
    PreloadingTrainLoader,
    _decompress_tensor,
    _get_memory_info,
)
from eemoclas.datasets.resampled_dataset import ResampledTensorDataset


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def _create_sample_pt(path, x_shape=(30, 2500), y=0, subject_id="sub001", raw=False):
    """Create a minimal .pt sample file."""
    sample = {
        "x": torch.randn(*x_shape),
        "y": torch.LongTensor([y]),
        "subject_id": subject_id,
        "token_meta": [
            {"source_channel": "FP1", "band_name": "broadband", "low": 1.0, "high": 45.0}
        ] * x_shape[0],
        "meta": {"sampler": "test", "center_seconds": 1.0},
        "emotion_label": y,
        "segment_id": f"seg_{y}",
    }
    torch.save(sample, path)
    return sample


def _create_raw_sample_pt(path, x_shape=(30, 2500)):
    """Create a raw .pt sample file."""
    sample = {"x": torch.randn(*x_shape)}
    torch.save(sample, path)


def _create_manifest(tmp_dir, n_samples=5, with_raw=False):
    """Create a manifest.csv and .pt sample files."""
    samples_dir = os.path.join(tmp_dir, "samples")
    os.makedirs(samples_dir, exist_ok=True)

    rows = []
    for i in range(n_samples):
        sample_id = f"sample_{i:04d}"
        pt_path = os.path.join(samples_dir, f"{sample_id}.pt")
        _create_sample_pt(pt_path, subject_id=f"sub{i:03d}", y=i % 2)

        row = {
            "sample_id": sample_id,
            "sample_path": pt_path,
            "subject_id": f"sub{i:03d}",
            "group_label": i % 2,
        }

        if with_raw:
            raw_path = os.path.join(samples_dir, f"{sample_id}_raw.pt")
            _create_raw_sample_pt(raw_path)
            row["raw_sample_path"] = raw_path

        rows.append(row)

    manifest_path = os.path.join(tmp_dir, "manifest.csv")
    df = pd.DataFrame(rows)
    df.to_csv(manifest_path, index=False)
    return manifest_path


def _make_subject_state_sample(path, y=0, subject_id="sub001"):
    """Create a subject-state .pt sample (8 trials)."""
    sample = {
        "x": torch.randn(8, 30, 2500),
        "y": torch.LongTensor([y]),
        "subject_id": subject_id,
        "token_meta": [
            {"source_channel": "FP1", "band_name": "broadband", "low": 1.0, "high": 45.0}
        ] * 30,
        "meta": {"sampler": "test"},
        "trial_segment_ids": [f"seg_{i}" for i in range(8)],
        "trial_emotion_labels": torch.randint(0, 2, (8,)),
        "group_label": y,
    }
    torch.save(sample, path)


def _create_subject_state_manifest(tmp_dir, n_samples=3):
    """Create manifest with subject-state shaped samples."""
    samples_dir = os.path.join(tmp_dir, "samples")
    os.makedirs(samples_dir, exist_ok=True)

    rows = []
    for i in range(n_samples):
        sample_id = f"ss_{i:04d}"
        pt_path = os.path.join(samples_dir, f"{sample_id}.pt")
        _make_subject_state_sample(pt_path, y=i % 2, subject_id=f"sub{i:03d}")
        rows.append({
            "sample_id": sample_id,
            "sample_path": pt_path,
            "subject_id": f"sub{i:03d}",
            "group_label": i % 2,
        })

    manifest_path = os.path.join(tmp_dir, "manifest.csv")
    pd.DataFrame(rows).to_csv(manifest_path, index=False)
    return manifest_path


# ---------------------------------------------------------------------------
# Memory detection
# ---------------------------------------------------------------------------


class TestMemoryDetection:
    """Cross-platform memory detection."""

    def test_get_memory_info_returns_positive(self):
        total, available = _get_memory_info()
        assert total > 0
        assert available > 0
        assert available <= total

    def test_get_memory_info_linux_reads_proc(self):
        """On Linux, verify MemTotal is read from /proc/meminfo."""
        import platform
        if platform.system() != "Linux":
            pytest.skip("Linux-only test")
        total, available = _get_memory_info()
        assert total > 1 * 1024**3  # At least 1 GB

    def test_memory_info_fallback_on_exception(self):
        with patch("eemoclas.datasets.preloaded_dataset._linux_memory_info", side_effect=OSError("no")):
            with patch("eemoclas.datasets.preloaded_dataset.platform") as mock_plat:
                mock_plat.system.return_value = "Linux"
                total, available = _get_memory_info()
                assert total == 8 * 1024**3
                assert available == 4 * 1024**3


# ---------------------------------------------------------------------------
# Compression
# ---------------------------------------------------------------------------


class TestCompression:
    """Tensor compression / decompression."""

    def test_float16_compress(self):
        t = torch.randn(30, 2500)
        from eemoclas.datasets.preloaded_dataset import _compress_tensor
        compressed = _compress_tensor(t, torch.float16)
        assert compressed.dtype == torch.float16
        assert compressed.shape == t.shape

    def test_float16_decompress(self):
        t = torch.randn(30, 2500).half()
        result = _decompress_tensor(t)
        assert result.dtype == torch.float32

    def test_non_float_passthrough(self):
        t = torch.randint(0, 10, (5,))
        result = _decompress_tensor(t)
        assert result.dtype == t.dtype


# ---------------------------------------------------------------------------
# CompressedPreloader
# ---------------------------------------------------------------------------


class TestCompressedPreloader:
    """Core preloader functionality."""

    def test_full_mode_when_budget_sufficient(self, tmp_dir):
        """All samples load → full mode."""
        manifest = _create_manifest(tmp_dir, n_samples=3)
        dataset = ResampledTensorDataset(manifest)

        # Give a huge budget so everything fits
        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1, 2])

        assert preloader.full_mode is True
        assert preloader.n_cached == 3

    def test_streaming_mode_when_budget_insufficient(self, tmp_dir):
        """Budget too small → streaming mode."""
        manifest = _create_manifest(tmp_dir, n_samples=10)
        dataset = ResampledTensorDataset(manifest)

        # Tiny budget → only 1-2 samples fit
        preloader = CompressedPreloader(dataset, compression="float16")
        with patch.object(preloader, "_compute_budget", return_value=500):
            preloader.prepare_epoch(list(range(10)))

        assert preloader.full_mode is False
        assert preloader.n_cached < 10

    def test_get_returns_float32(self, tmp_dir):
        """Decompressed samples should be float32."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        sample = preloader.get(0)
        assert sample is not None
        assert sample["x"].dtype == torch.float32

    def test_get_returns_none_for_uncached(self, tmp_dir):
        """Uncached indices return None."""
        manifest = _create_manifest(tmp_dir, n_samples=5)
        dataset = ResampledTensorDataset(manifest)

        preloader = CompressedPreloader(dataset, compression="float16")
        with patch.object(preloader, "_compute_budget", return_value=500):
            preloader.prepare_epoch([0, 1, 2, 3, 4])

        # Find an uncached index
        for i in range(5):
            if preloader.get(i) is None:
                return  # success
        # If all cached, budget was big enough — skip
        pytest.skip("Budget was too large for this test")

    def test_output_format_matches_original(self, tmp_dir):
        """Preloaded sample has same keys as original dataset."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        original = dataset[0]
        cached = preloader.get(0)

        for key in original:
            assert key in cached, f"Missing key: {key}"

    def test_token_meta_shared(self, tmp_dir):
        """Only one copy of token_meta stored."""
        manifest = _create_manifest(tmp_dir, n_samples=3)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1, 2])

        # All cached samples should reference the same token_meta
        s0 = preloader.get(0)
        s1 = preloader.get(1)
        assert s0["token_meta"] is s1["token_meta"]  # same object

    def test_meta_skipped_when_configured(self, tmp_dir):
        """skip_meta=True: meta should be empty dict placeholder."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16", skip_meta=True)
            preloader.prepare_epoch([0, 1])

        sample = preloader.get(0)
        assert "meta" in sample
        assert sample["meta"] == {}  # placeholder

    def test_on_consumed_noop_in_full_mode(self, tmp_dir):
        """Full mode: on_consumed does not evict."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        assert preloader.full_mode
        preloader.on_consumed(0)
        assert preloader.n_cached == 2  # nothing evicted

    def test_on_consumed_evicts_and_prefetches(self, tmp_dir):
        """Streaming mode: on_consumed evicts consumed, prefetches next."""
        manifest = _create_manifest(tmp_dir, n_samples=5)
        dataset = ResampledTensorDataset(manifest)

        # Budget allows 3 samples
        preloader = CompressedPreloader(dataset, compression="float16")
        preloader._sample_bytes_est = 1000  # force estimate
        with patch.object(preloader, "_compute_budget", return_value=3500):
            preloader.prepare_epoch([0, 1, 2, 3, 4])

        n_before = preloader.n_cached
        assert n_before >= 2  # at least some cached

        # Consume first sample
        preloader.on_consumed(0)
        # Should have evicted 0 and potentially prefetched next
        assert 0 not in preloader._cache

    def test_clear_resets_state(self, tmp_dir):
        """clear() releases all cached data."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        preloader.clear()
        assert preloader.n_cached == 0
        assert preloader.bytes_used == 0
        assert preloader.full_mode is False

    def test_val_indices_included_in_full_check(self, tmp_dir):
        """Val indices included in full-mode upgrade check."""
        manifest = _create_manifest(tmp_dir, n_samples=3)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(
                dataset, compression="float16", val_indices=[0, 1]
            )
            preloader.prepare_epoch([2])

        # All train + val samples should be cached for full mode
        if preloader.full_mode:
            assert preloader.get(0) is not None
            assert preloader.get(1) is not None
            assert preloader.get(2) is not None

    def test_prepare_epoch_full_mode_no_reload(self, tmp_dir):
        """In full mode, subsequent prepare_epoch only updates order."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        assert preloader.full_mode
        bytes_before = preloader.bytes_used

        # Second epoch — should not re-load
        preloader.prepare_epoch([1, 0])  # reversed order
        assert preloader.bytes_used == bytes_before
        assert preloader.full_mode


# ---------------------------------------------------------------------------
# Dynamic window (mocked memory)
# ---------------------------------------------------------------------------


class TestDynamicWindow:
    """Dynamic window size adjustment based on real-time memory."""

    def test_window_shrinks_when_memory_drops(self, tmp_dir):
        """Window shrinks when available memory decreases."""
        manifest = _create_manifest(tmp_dir, n_samples=10)
        dataset = ResampledTensorDataset(manifest)
        preloader = CompressedPreloader(dataset, compression="float16")

        # First load one sample to get real estimate
        sample = dataset[0]
        real_sample_bytes = preloader._estimate_sample_bytes()

        # Budget allows only 4 samples (streaming mode)
        budget_initial = real_sample_bytes * 4 + 1000
        with patch.object(preloader, "_compute_budget", return_value=budget_initial):
            preloader.prepare_epoch(list(range(10)))

        n_initial = preloader.n_cached
        assert not preloader.full_mode  # streaming mode
        assert n_initial < 10

        # Simulate memory pressure: only 1 sample worth of budget
        tight_budget = real_sample_bytes + 500
        with patch.object(preloader, "_compute_budget", return_value=tight_budget):
            preloader.on_consumed(preloader._access_order[0])

        # Should have evicted extra samples to fit tight budget
        assert preloader.n_cached < n_initial

    def test_window_expands_when_memory_increases(self, tmp_dir):
        """Window expands when available memory increases."""
        manifest = _create_manifest(tmp_dir, n_samples=10)
        dataset = ResampledTensorDataset(manifest)
        preloader = CompressedPreloader(dataset, compression="float16")

        # Start with tiny budget
        preloader._sample_bytes_est = 1000
        with patch.object(preloader, "_compute_budget", return_value=1500):
            preloader.prepare_epoch(list(range(10)))

        n_initial = preloader.n_cached

        # Memory frees up
        with patch.object(preloader, "_compute_budget", return_value=10000):
            preloader.on_consumed(preloader._access_order[0])

        assert preloader.n_cached >= n_initial  # should have prefetched more


# ---------------------------------------------------------------------------
# PreloadingTrainLoader
# ---------------------------------------------------------------------------


class TestPreloadingTrainLoader:
    """DataLoader replacement with sliding-window preloading."""

    def test_yields_correct_batch_count(self, tmp_dir):
        """Number of batches matches __len__."""
        manifest = _create_manifest(tmp_dir, n_samples=7)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            loader = PreloadingTrainLoader(
                preloader, dataset, list(range(7)),
                batch_size=3, collate_fn=collate_emotion,
            )

        batches = list(loader)
        assert len(batches) == len(loader)  # ceil(7/3) = 3

    def test_batch_format_matches_collate(self, tmp_dir):
        """Batches have the same format as DataLoader-produced batches."""
        manifest = _create_manifest(tmp_dir, n_samples=4)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            loader = PreloadingTrainLoader(
                preloader, dataset, list(range(4)),
                batch_size=2, collate_fn=collate_emotion,
            )

        batch = next(iter(loader))
        assert "x" in batch
        assert "y" in batch
        assert batch["x"].shape[0] == 2
        assert batch["x"].dtype == torch.float32

    def test_different_shuffle_per_epoch(self, tmp_dir):
        """Each epoch gets a different shuffle order."""
        manifest = _create_manifest(tmp_dir, n_samples=5)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            loader = PreloadingTrainLoader(
                preloader, dataset, list(range(5)),
                batch_size=5, collate_fn=collate_fn_passthrough,
                seed=42,
            )

        # Collect indices from epoch 0
        epoch0_indices = []
        for batch in loader:
            epoch0_indices.extend(batch)

        # Collect from epoch 1
        epoch1_indices = []
        for batch in loader:
            epoch1_indices.extend(batch)

        # Should be different permutations (with high probability)
        assert sorted(epoch0_indices) == sorted(epoch1_indices) == [0, 1, 2, 3, 4]


def collate_fn_passthrough(samples):
    """Collate that returns raw sample indices for shuffle testing."""
    return [s.get("_idx", i) for i, s in enumerate(samples)]


# ---------------------------------------------------------------------------
# PreloadedDataset (full-mode wrapper)
# ---------------------------------------------------------------------------


class TestPreloadedDataset:
    """Full-mode Dataset wrapper."""

    def test_getitem_from_cache(self, tmp_dir):
        """Returns decompressed sample from cache."""
        manifest = _create_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        wrapped = PreloadedDataset(preloader, dataset, [0, 1])
        sample = wrapped[0]
        assert sample["x"].dtype == torch.float32

    def test_fallback_to_disk(self, tmp_dir):
        """Uncached samples load from original dataset."""
        manifest = _create_manifest(tmp_dir, n_samples=3)
        dataset = ResampledTensorDataset(manifest)

        # Empty preloader — no cache
        preloader = CompressedPreloader(dataset, compression="float16")

        wrapped = PreloadedDataset(preloader, dataset, [0, 1, 2])
        sample = wrapped[0]
        assert "x" in sample

    def test_len_matches_indices(self, tmp_dir):
        manifest = _create_manifest(tmp_dir, n_samples=5)
        dataset = ResampledTensorDataset(manifest)
        preloader = CompressedPreloader(dataset, compression="float16")
        wrapped = PreloadedDataset(preloader, dataset, [0, 2, 4])
        assert len(wrapped) == 3


# ---------------------------------------------------------------------------
# Collate compatibility
# ---------------------------------------------------------------------------


class TestCollateCompatibility:
    """Ensure preloaded samples work with existing collate functions."""

    def test_collate_emotion(self, tmp_dir):
        manifest = _create_manifest(tmp_dir, n_samples=4)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1, 2, 3])

        samples = [preloader.get(i) for i in range(4)]
        batch = collate_emotion(samples)
        assert batch["x"].shape == (4, 30, 2500)
        assert batch["y"].shape == (4, 1)

    def test_collate_subject_state(self, tmp_dir):
        manifest = _create_subject_state_manifest(tmp_dir, n_samples=2)
        dataset = ResampledTensorDataset(manifest)

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1])

        samples = [preloader.get(i) for i in range(2)]
        batch = collate_subject_state(samples)
        assert batch["x"].shape == (2, 8, 30, 2500)


# ---------------------------------------------------------------------------
# Config integration
# ---------------------------------------------------------------------------


class TestPreloadConfig:
    """PreloadConfig dataclass and YAML loading."""

    def test_default_values(self):
        from eemoclas.config.dataclasses import PreloadConfig
        cfg = PreloadConfig()
        assert cfg.enabled is True
        assert cfg.compression == "float16"
        assert cfg.system_reserve_ratio == 0.05
        assert cfg.preload_val is False
        assert cfg.skip_meta is True

    def test_training_config_has_preload(self):
        from eemoclas.config.dataclasses import TrainingConfig
        cfg = TrainingConfig()
        assert hasattr(cfg, "preload")
        assert cfg.preload.enabled is True

    def test_yaml_preload_section(self, tmp_dir):
        """YAML with preload section loads correctly."""
        from eemoclas.config.loader import load_config

        yaml_path = os.path.join(tmp_dir, "test_config.yaml")
        with open(yaml_path, "w") as f:
            f.write("""
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "test"
signal:
  fs: 250
  train_segment_points: 12500
  window_points: 2500
channels:
  mode: "by_name"
  selected: "all"
bands:
  definitions:
    broadband: {low: 1.0, high: 45.0}
data:
  index_dir: ""
  resample_output_dir: ""
  test_dir: ""
models:
  test_model:
    task:
      name: "normal_emotion"
      dataset_class: "NormalEmotionDataset"
      num_classes: 2
    model:
      architecture: "emotion_cnn_transformer"
    training:
      epochs: 2
      batch_size: 16
      preload:
        enabled: true
        compression: "float16"
        system_reserve_ratio: 0.1
        preload_val: true
        skip_meta: false
    augmentation:
      enabled: false
    splitting:
      method: "holdout"
    seeding:
      random_seed: 42
""")
        config = load_config(yaml_path)
        mc = config.get_model_config("test_model")
        assert mc.training.preload.enabled is True
        assert mc.training.preload.compression == "float16"
        assert mc.training.preload.system_reserve_ratio == 0.1
        assert mc.training.preload.preload_val is True
        assert mc.training.preload.skip_meta is False


# ---------------------------------------------------------------------------
# Dual-branch preload
# ---------------------------------------------------------------------------


class TestDualBranchPreload:
    """Preloading with load_raw=True (dual-branch models)."""

    def test_dual_branch_loads_raw(self, tmp_dir):
        manifest = _create_manifest(tmp_dir, n_samples=3, with_raw=True)
        dataset = ResampledTensorDataset(manifest, load_raw=True)

        sample = dataset[0]
        assert "x_raw" in sample

        with patch.object(CompressedPreloader, "_compute_budget", return_value=10 * 1024**3):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch([0, 1, 2])

        cached = preloader.get(0)
        assert "x_raw" in cached
        assert cached["x_raw"].dtype == torch.float32


# ---------------------------------------------------------------------------
# Race condition safety
# ---------------------------------------------------------------------------


class TestRaceConditionSafety:
    """Two preloaders started simultaneously shouldn't both claim full mode."""

    def test_two_preloaders_concurrent(self, tmp_dir):
        """Simulate two classifiers starting at once."""
        manifest = _create_manifest(tmp_dir, n_samples=10)
        dataset = ResampledTensorDataset(manifest)

        # Each preloader sees only half the available memory
        call_count = [0]
        budgets = [5 * 1024**3, 4 * 1024**3]  # decreasing budget

        def mock_budget(self):
            idx = min(call_count[0], len(budgets) - 1)
            call_count[0] += 1
            return budgets[idx]

        with patch.object(CompressedPreloader, "_compute_budget", mock_budget):
            preloader = CompressedPreloader(dataset, compression="float16")
            preloader.prepare_epoch(list(range(10)))

        # With limited budget, should be in streaming mode
        # (unless samples are tiny enough to all fit)
        if preloader.bytes_used < 4 * 1024**3:
            assert preloader.full_mode is True  # all fit despite small budget
        else:
            assert preloader.full_mode is False  # streaming mode
