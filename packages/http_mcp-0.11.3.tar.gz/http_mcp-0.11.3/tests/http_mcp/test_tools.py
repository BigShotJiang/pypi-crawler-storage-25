from http import HTTPStatus

from pydantic import BaseModel, Field
from starlette.testclient import TestClient

from http_mcp._json_rcp_types.errors import Error, ErrorCode
from http_mcp.exceptions import ServerError, ToolInvocationError
from http_mcp.server import MCPServer
from http_mcp.types import Arguments, NoArguments, Tool
from tests.fixtures.context import Context
from tests.fixtures.main import mount_mcp_server

# ---------------------------------------------------------------------------
# Models and helper tools from test_tools_methods.py
# ---------------------------------------------------------------------------


class TestTool1Arguments(BaseModel):
    question: str = Field(description="The question to answer")


class TestTool1Output(BaseModel):
    answer: str = Field(description="The answer to the question")


class TestTool2Arguments(BaseModel):
    user_id: str = Field(description="The user ID to get information about")


class TestTool2Output(BaseModel):
    user_id: str = Field(description="The user ID")
    email: str = Field(description="The email address of the user")


class TestToolWithoutArgumentsOutput(BaseModel):
    message: str = Field(description="The message to return")


async def tool_1(args: Arguments[TestTool1Arguments]) -> TestTool1Output:
    """Return a simple answer."""
    assert args.inputs.question == "What is the meaning of life?"
    context = args.get_state_key("context", Context)
    assert context.called_tools == []
    context.add_called_tool("tool_1")
    return TestTool1Output(answer=f"Hello, {args.inputs.question}!")


def tool_2(args: Arguments[TestTool2Arguments]) -> TestTool2Output:
    """Return a simple user information."""
    assert args.inputs.user_id == "123"
    context = args.get_state_key("context", Context)
    assert context.called_tools == ["tool_1"]
    context.add_called_tool("tool_2")
    return TestTool2Output(user_id=args.inputs.user_id, email=f"{args.inputs.user_id}@example.com")


def tool_without_arguments() -> TestToolWithoutArgumentsOutput:
    """Return a simple message."""
    return TestToolWithoutArgumentsOutput(message="Hello, world!")


async def tool_without_arguments_async() -> TestToolWithoutArgumentsOutput:
    """Return a simple message."""
    return TestToolWithoutArgumentsOutput(message="Hello, world!")


def tool_that_raises_error(
    _args: Arguments[TestTool1Arguments],
) -> TestTool1Output:
    """Return a simple answer."""
    raise ValueError


def tool_without_arguments_that_raises_error() -> TestToolWithoutArgumentsOutput:
    """Return a simple message."""
    raise ValueError


def tool_that_raises_invocation_result(
    _args: Arguments[TestTool1Arguments],
) -> TestTool1Output:
    """Return a simple answer."""
    raise ToolInvocationError("tool_that_returns_invocation_result", "Feedback here")


TOOLS = (
    Tool(
        func=tool_1,
        inputs=TestTool1Arguments,
        output=TestTool1Output,
    ),
    Tool(
        func=tool_2,
        inputs=TestTool2Arguments,
        output=TestTool2Output,
    ),
    Tool(
        func=tool_without_arguments,
        inputs=type(None),
        output=TestToolWithoutArgumentsOutput,
    ),
    Tool(
        func=tool_without_arguments_async,
        inputs=type(None),
        output=TestToolWithoutArgumentsOutput,
    ),
    Tool(
        func=tool_that_raises_invocation_result,
        inputs=TestTool1Arguments,
        output=TestTool1Output,
        return_error_message=True,
    ),
)


# ---------------------------------------------------------------------------
# Model from test_coverage_gaps.py
# ---------------------------------------------------------------------------


class SimpleOutput(BaseModel):
    value: str = Field(description="A value")


_TOOLS_LIST_CHUNK_SIZE = 100
_TOOLS_OVERFLOW_COUNT = 150
_TOOLS_SECOND_PAGE_COUNT = 50


# ---------------------------------------------------------------------------
# Tests from test_tools_methods.py
# ---------------------------------------------------------------------------


def test_list_tools() -> None:
    server = MCPServer(
        tools=TOOLS,
        name="test",
        version="1.0.0",
    )
    app = mount_mcp_server(server)
    client = TestClient(app)
    response = client.post(
        "/mcp",
        json={"jsonrpc": "2.0", "method": "tools/list", "id": 1, "params": {}},
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {
            "tools": [
                {
                    "name": "tool_1",
                    "title": "Tool 1",
                    "description": "Return a simple answer.",
                    "inputSchema": {
                        "properties": {
                            "question": {
                                "description": "The question to answer",
                                "title": "Question",
                                "type": "string",
                            },
                        },
                        "required": ["question"],
                        "title": "tool_1Arguments",
                        "type": "object",
                    },
                    "outputSchema": {
                        "properties": {
                            "answer": {
                                "description": "The answer to the question",
                                "title": "Answer",
                                "type": "string",
                            },
                        },
                        "required": ["answer"],
                        "title": "tool_1Output",
                        "type": "object",
                    },
                    "annotations": {
                        "title": "Tool 1",
                        "readOnlyHint": False,
                        "destructiveHint": False,
                        "idempotentHint": True,
                        "openWorldHint": True,
                    },
                    "meta": None,
                },
                {
                    "name": "tool_2",
                    "title": "Tool 2",
                    "description": "Return a simple user information.",
                    "inputSchema": {
                        "properties": {
                            "user_id": {
                                "description": "The user ID to get information about",
                                "title": "User Id",
                                "type": "string",
                            },
                        },
                        "required": ["user_id"],
                        "title": "tool_2Arguments",
                        "type": "object",
                    },
                    "outputSchema": {
                        "properties": {
                            "user_id": {
                                "description": "The user ID",
                                "title": "User Id",
                                "type": "string",
                            },
                            "email": {
                                "description": "The email address of the user",
                                "title": "Email",
                                "type": "string",
                            },
                        },
                        "required": ["user_id", "email"],
                        "title": "tool_2Output",
                        "type": "object",
                    },
                    "annotations": {
                        "title": "Tool 2",
                        "readOnlyHint": False,
                        "destructiveHint": False,
                        "idempotentHint": True,
                        "openWorldHint": True,
                    },
                    "meta": None,
                },
                {
                    "name": "tool_that_raises_invocation_result",
                    "title": "Tool That Raises Invocation Result",
                    "description": "Return a simple answer.",
                    "inputSchema": {
                        "properties": {
                            "question": {
                                "description": "The question to answer",
                                "title": "Question",
                                "type": "string",
                            },
                        },
                        "required": ["question"],
                        "title": "tool_that_raises_invocation_resultArguments",
                        "type": "object",
                    },
                    "outputSchema": {
                        "$defs": {
                            "TestTool1Output": {
                                "properties": {
                                    "answer": {
                                        "description": "The answer to the question",
                                        "title": "Answer",
                                        "type": "string",
                                    },
                                },
                                "required": ["answer"],
                                "title": "TestTool1Output",
                                "type": "object",
                            },
                            "ErrorMessage": {
                                "description": (
                                    "Returned feedback if the tool invocation was not successful."
                                ),
                                "properties": {
                                    "error_message": {
                                        "description": (
                                            "The error message if the tool invocation was not"
                                            " successful"
                                        ),
                                        "title": "Error Message",
                                        "type": "string",
                                    },
                                },
                                "required": ["error_message"],
                                "title": "ErrorMessage",
                                "type": "object",
                            },
                        },
                        "type": "object",
                        "oneOf": [
                            {"$ref": "#/$defs/TestTool1Output"},
                            {"$ref": "#/$defs/ErrorMessage"},
                        ],
                        "title": "tool_that_raises_invocation_resultOutput",
                    },
                    "annotations": {
                        "title": "Tool That Raises Invocation Result",
                        "readOnlyHint": False,
                        "destructiveHint": False,
                        "idempotentHint": True,
                        "openWorldHint": True,
                    },
                    "meta": None,
                },
                {
                    "name": "tool_without_arguments",
                    "title": "Tool Without Arguments",
                    "description": "Return a simple message.",
                    "inputSchema": {
                        "properties": {},
                        "title": "tool_without_argumentsArguments",
                        "type": "object",
                    },
                    "outputSchema": {
                        "properties": {
                            "message": {
                                "description": "The message to return",
                                "title": "Message",
                                "type": "string",
                            },
                        },
                        "required": ["message"],
                        "title": "tool_without_argumentsOutput",
                        "type": "object",
                    },
                    "annotations": {
                        "title": "Tool Without Arguments",
                        "readOnlyHint": False,
                        "destructiveHint": False,
                        "idempotentHint": True,
                        "openWorldHint": True,
                    },
                    "meta": None,
                },
                {
                    "name": "tool_without_arguments_async",
                    "title": "Tool Without Arguments Async",
                    "description": "Return a simple message.",
                    "inputSchema": {
                        "properties": {},
                        "title": "tool_without_arguments_asyncArguments",
                        "type": "object",
                    },
                    "outputSchema": {
                        "properties": {
                            "message": {
                                "description": "The message to return",
                                "title": "Message",
                                "type": "string",
                            },
                        },
                        "required": ["message"],
                        "title": "tool_without_arguments_asyncOutput",
                        "type": "object",
                    },
                    "annotations": {
                        "title": "Tool Without Arguments Async",
                        "readOnlyHint": False,
                        "destructiveHint": False,
                        "idempotentHint": True,
                        "openWorldHint": True,
                    },
                    "meta": None,
                },
            ],
        },
    }


def test_server_call_tools() -> None:
    server = MCPServer(
        tools=TOOLS,
        name="test",
        version="1.0.0",
    )
    app = mount_mcp_server(server)
    with TestClient(app) as client:
        response_1 = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 1,
                "params": {
                    "name": "tool_1",
                    "arguments": {"question": "What is the meaning of life?"},
                },
            },
        )
        assert response_1.status_code == HTTPStatus.OK
        response_json = response_1.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": '{"answer":"Hello, What is the meaning of life?!"}',
                    },
                ],
                "structuredContent": {"answer": "Hello, What is the meaning of life?!"},
                "isError": False,
            },
        }
        assert client.app_state["context"].called_tools == ["tool_1"]

        response_2 = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 1,
                "params": {
                    "name": "tool_2",
                    "arguments": {"user_id": "123"},
                },
            },
        )

        assert response_2.status_code == HTTPStatus.OK
        response_json = response_2.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": '{"user_id":"123","email":"123@example.com"}',
                    },
                ],
                "structuredContent": {"user_id": "123", "email": "123@example.com"},
                "isError": False,
            },
        }
        assert client.app_state["context"].called_tools == ["tool_1", "tool_2"]

        response_3 = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 3,
                "params": {
                    "name": "tool_without_arguments",
                    "arguments": {},
                },
            },
        )
        assert response_3.status_code == HTTPStatus.OK
        response_json = response_3.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 3,
            "result": {
                "content": [{"type": "text", "text": '{"message":"Hello, world!"}'}],
                "structuredContent": {"message": "Hello, world!"},
                "isError": False,
            },
        }
        assert client.app_state["context"].called_tools == [
            "tool_1",
            "tool_2",
        ]

        response_4 = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 4,
                "params": {"name": "tool_without_arguments_async", "arguments": {}},
            },
        )
        assert response_4.status_code == HTTPStatus.OK
        response_json = response_4.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 4,
            "result": {
                "content": [{"type": "text", "text": '{"message":"Hello, world!"}'}],
                "structuredContent": {"message": "Hello, world!"},
                "isError": False,
            },
        }
        assert client.app_state["context"].called_tools == [
            "tool_1",
            "tool_2",
        ]


def test_server_call_tool_with_invalid_arguments() -> None:
    server = MCPServer(
        tools=TOOLS,
        name="test",
        version="1.0.0",
    )
    app = mount_mcp_server(server)
    client = TestClient(app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/call",
            "id": 1,
            "params": {
                "name": "tool_1",
                "arguments": {"invalid_field": "What is the meaning of life?"},
            },
        },
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": ErrorCode.INVALID_PARAMS.value,
            "message": "Error validating arguments for tool tool_1: "
            '[{"field": "question", "message": "Field required"}]',
        },
    }


def test_server_call_tool_with_error() -> None:
    server = MCPServer(
        tools=(
            Tool(
                func=tool_that_raises_error,
                inputs=TestTool1Arguments,
                output=TestTool1Output,
            ),
            Tool(
                func=tool_without_arguments_that_raises_error,
                inputs=type(None),
                output=TestToolWithoutArgumentsOutput,
            ),
        ),
        name="test",
        version="1.0.0",
    )
    client = TestClient(server.app)

    for tool in (tool_that_raises_error, tool_without_arguments_that_raises_error):
        response = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 1,
                "params": {
                    "name": tool.__name__,
                    "arguments": {"question": "What is the meaning of life?"}
                    if tool.__name__ == tool_that_raises_error.__name__
                    else {},
                },
            },
        )
        assert response.status_code == HTTPStatus.OK
        response_json = response.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": f"Error calling tool {tool.__name__}: Unknown error",
                    },
                ],
                "isError": True,
            },
        }


def test_tool_not_found() -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/call",
            "id": 1,
            "params": {"name": "not_found", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": ErrorCode.RESOURCE_NOT_FOUND.value,
            "message": "Tool not_found not found",
        },
    }


# ---------------------------------------------------------------------------
# Tests from test_coverage_gaps.py (tool-related)
# ---------------------------------------------------------------------------


def test_tools_list_pagination_returns_next_cursor() -> None:
    tools = tuple(
        Tool(
            func=lambda: SimpleOutput(value="ok"),
            inputs=type(None),
            output=SimpleOutput,
        )
        for _ in range(_TOOLS_OVERFLOW_COUNT)
    )
    for i, tool in enumerate(tools):
        tool.func.__name__ = f"tool_{i}"
        tool.func.__doc__ = f"Tool {i}."

    server = MCPServer(name="test", version="1.0.0", tools=tools)
    client = TestClient(server.app)

    response = client.post(
        "/mcp",
        json={"jsonrpc": "2.0", "method": "tools/list", "id": 1, "params": {}},
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["result"]["nextCursor"] is not None
    assert len(data["result"]["tools"]) == _TOOLS_LIST_CHUNK_SIZE

    response2 = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": 2,
            "params": {"cursor": data["result"]["nextCursor"]},
        },
    )
    assert response2.status_code == HTTPStatus.OK
    data2 = response2.json()
    assert len(data2["result"]["tools"]) == _TOOLS_SECOND_PAGE_COUNT
    assert data2["result"].get("nextCursor") is None


def test_get_state_key_missing_key_raises_server_error() -> None:
    def tool_accessing_missing_key(args: Arguments[NoArguments]) -> SimpleOutput:
        """Access a missing state key."""
        args.get_state_key("nonexistent_key", object)
        return SimpleOutput(value="unreachable")

    server = MCPServer(
        name="test",
        version="1.0.0",
        tools=(
            Tool(
                func=tool_accessing_missing_key,
                inputs=NoArguments,
                output=SimpleOutput,
            ),
        ),
    )
    app = mount_mcp_server(server)
    with TestClient(app) as client:
        response = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "tools/call",
                "id": 1,
                "params": {"name": "tool_accessing_missing_key", "arguments": {}},
            },
        )
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert data["result"]["isError"] is True
        assert "nonexistent_key" in data["result"]["content"][0]["text"]


def test_tool_without_args_reraises_server_error() -> None:
    def tool_raising_server_error() -> SimpleOutput:
        """Raise a ServerError."""
        raise ServerError(
            Error(code=ErrorCode.INTERNAL_ERROR, description="Custom server error"),
        )

    server = MCPServer(
        name="test",
        version="1.0.0",
        tools=(
            Tool(func=tool_raising_server_error, inputs=type(None), output=SimpleOutput),
        ),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/call",
            "id": 1,
            "params": {"name": "tool_raising_server_error", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["result"]["isError"] is True
    assert "Custom server error" in data["result"]["content"][0]["text"]


def test_tool_with_args_reraises_server_error() -> None:
    def tool_raising_server_error(_args: Arguments[NoArguments]) -> SimpleOutput:
        """Raise a ServerError."""
        raise ServerError(
            Error(code=ErrorCode.INTERNAL_ERROR, description="Args server error"),
        )

    server = MCPServer(
        name="test",
        version="1.0.0",
        tools=(
            Tool(func=tool_raising_server_error, inputs=NoArguments, output=SimpleOutput),
        ),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/call",
            "id": 1,
            "params": {"name": "tool_raising_server_error", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["result"]["isError"] is True
    assert "Args server error" in data["result"]["content"][0]["text"]


def test_tool_returns_error_message_when_configured() -> None:
    def tool_raising_invocation_error(
        _args: Arguments[NoArguments],
    ) -> SimpleOutput:
        """Raise a ToolInvocationError."""
        raise ToolInvocationError("tool_raising_invocation_error", "Something failed")

    server = MCPServer(
        name="test",
        version="1.0.0",
        tools=(
            Tool(
                func=tool_raising_invocation_error,
                inputs=NoArguments,
                output=SimpleOutput,
                return_error_message=True,
            ),
        ),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "tools/call",
            "id": 1,
            "params": {"name": "tool_raising_invocation_error", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["result"]["isError"] is False
    content = data["result"]["structuredContent"]
    assert "Something failed" in content["error_message"]
