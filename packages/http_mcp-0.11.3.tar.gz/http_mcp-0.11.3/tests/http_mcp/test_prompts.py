from http import HTTPStatus

import pytest
from pydantic import BaseModel, Field
from starlette.testclient import TestClient

from http_mcp._json_rcp_types.errors import Error, ErrorCode
from http_mcp._mcp_types.content import TextContent
from http_mcp._mcp_types.prompts import PromptMessage
from http_mcp.exceptions import ServerError
from http_mcp.server import MCPServer
from http_mcp.types import Arguments, NoArguments, Prompt
from tests.fixtures.main import BasicAuthBackend, mount_mcp_server

# ---------------------------------------------------------------------------
# Models and helper prompts from test_prompts_methods.py
# ---------------------------------------------------------------------------


class TestArguments(BaseModel):
    argument_1: int = Field(description="The first argument")
    argument_2: str = Field(description="The second argument")
    argument_3: bool = Field(description="The third argument", default=True)
    argument_4: float = Field(description="The fourth argument", default=1.0)


def prompt_sync(arg: Arguments[TestArguments]) -> tuple[PromptMessage, ...]:
    """Test prompt sync."""
    return (PromptMessage(role="user", content=TextContent(text=arg.inputs.model_dump_json())),)


async def prompt_async(arg: Arguments[TestArguments]) -> tuple[PromptMessage, ...]:
    """Test prompt async."""
    return (PromptMessage(role="user", content=TextContent(text=arg.inputs.model_dump_json())),)


def prompt_that_raises_error(_arg: Arguments[TestArguments]) -> tuple[PromptMessage, ...]:
    """Test prompt that raises an error."""
    raise ValueError


def prompt_without_arguments() -> tuple[PromptMessage, ...]:
    """Test prompt without arguments."""
    return (PromptMessage(role="user", content=TextContent(text="No arguments here.")),)


async def prompt_without_arguments_async() -> tuple[PromptMessage, ...]:
    """Test prompt without arguments async."""
    return (PromptMessage(role="user", content=TextContent(text="No arguments here.")),)


def prompt_without_arguments_error() -> tuple[PromptMessage, ...]:
    """Test prompt without arguments error."""
    raise ValueError


PROMPT_SYNC = Prompt(
    func=prompt_sync,
    arguments_type=TestArguments,
)

PROMPT_ASYNC = Prompt(
    func=prompt_async,
    arguments_type=TestArguments,
)


PROMPT_ERROR = Prompt(
    func=prompt_that_raises_error,
    arguments_type=TestArguments,
)

PROMPT_WITHOUT_ARGUMENTS_SYNC = Prompt(
    func=prompt_without_arguments,
    arguments_type=type(None),
)

PROMPT_WITHOUT_ARGUMENTS_ASYNC = Prompt(
    func=prompt_without_arguments_async,
    arguments_type=type(None),
)

PROMPT_WITHOUT_ARGUMENTS_ERROR = Prompt(
    func=prompt_without_arguments_error,
    arguments_type=type(None),
)


HEADER_AUTHORIZATION = {"Authorization": "Bearer TEST_TOKEN"}


# ---------------------------------------------------------------------------
# Tests from test_prompts_methods.py
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "prompt",
    [
        PROMPT_SYNC,
        PROMPT_ASYNC,
        PROMPT_WITHOUT_ARGUMENTS_SYNC,
        PROMPT_WITHOUT_ARGUMENTS_ASYNC,
    ],
)
def test_prompt_list(prompt: Prompt) -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(prompt,),
    )
    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post("/mcp", json={"jsonrpc": "2.0", "method": "prompts/list", "id": 1})
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {
            "prompts": [
                {
                    "arguments": [
                        {
                            "description": "The first argument",
                            "name": "argument_1",
                            "required": True,
                        },
                        {
                            "description": "The second argument",
                            "name": "argument_2",
                            "required": True,
                        },
                        {
                            "description": "The third argument",
                            "name": "argument_3",
                            "required": False,
                        },
                        {
                            "description": "The fourth argument",
                            "name": "argument_4",
                            "required": False,
                        },
                    ]
                    if not issubclass(prompt.arguments_type, type(None))
                    else [],
                    "description": prompt.description,
                    "name": prompt.name,
                    "title": prompt.title,
                },
            ],
        },
    }


@pytest.mark.parametrize(
    "prompt",
    [
        PROMPT_SYNC,
        PROMPT_ASYNC,
        PROMPT_WITHOUT_ARGUMENTS_SYNC,
        PROMPT_WITHOUT_ARGUMENTS_ASYNC,
    ],
)
def test_prompt_get(prompt: Prompt) -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(prompt,),
    )
    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {
                "name": prompt.name,
                "arguments": {
                    "argument_1": 1,
                    "argument_2": "test",
                    "argument_3": False,
                    "argument_4": 2.0,
                }
                if not issubclass(prompt.arguments_type, type(None))
                else {},
            },
        },
    )

    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "id": 1,
        "jsonrpc": "2.0",
        "result": {
            "description": prompt.description,
            "messages": [
                {
                    "content": {
                        "text": (
                            '{"argument_1":1,"argument_2":"test","argument_3":false,"argument_4":2.0}'
                            if not issubclass(prompt.arguments_type, type(None))
                            else "No arguments here."
                        ),
                        "type": "text",
                    },
                    "role": "user",
                },
            ],
        },
    }


@pytest.mark.parametrize("prompt", [PROMPT_SYNC, PROMPT_ASYNC])
def test_prompts(
    prompt: Prompt,
) -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(prompt,),
    )

    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {
                "name": prompt.name,
                "arguments": {
                    "argument_1": 1,
                    "argument_2": "test",
                    "argument_3": False,
                    "argument_4": 2.0,
                },
            },
        },
    )

    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "id": 1,
        "jsonrpc": "2.0",
        "result": {
            "description": prompt.description,
            "messages": [
                {
                    "content": {
                        "text": (
                            '{"argument_1":1,"argument_2":"test","argument_3":false,"argument_4":2.0}'
                        ),
                        "type": "text",
                    },
                    "role": "user",
                },
            ],
        },
    }


@pytest.mark.parametrize("prompt", [PROMPT_SYNC, PROMPT_ASYNC])
def test_server_call_prompt_with_invalid_arguments(prompt: Prompt) -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(prompt,),
    )
    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {
                "name": prompt.name,
                "arguments": {"invalid_field": "What is the meaning of life?"},
            },
        },
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": ErrorCode.INVALID_PARAMS.value,
            "message": f"Error validating arguments for prompt {prompt.name}: "
            '[{"field": "argument_1", "message": "Field required"}, '
            '{"field": "argument_2", "message": "Field required"}]',
        },
    }


@pytest.mark.parametrize("prompt", [PROMPT_ERROR, PROMPT_WITHOUT_ARGUMENTS_ERROR])
def test_server_call_prompt_with_error(prompt: Prompt) -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(prompt,),
    )
    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {
                "name": prompt.name,
                "arguments": {
                    "argument_1": 1,
                    "argument_2": "test",
                    "argument_3": False,
                    "argument_4": 2.0,
                },
            },
        },
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {
            "description": f"Error getting prompt {prompt.name}: Unknown error",
            "messages": [],
        },
    }


def test_prompt_not_found() -> None:
    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(),
    )
    client = TestClient(server.app, headers={"Authorization": "Bearer TEST_TOKEN"})
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {
                "name": "not_found",
                "arguments": {},
            },
        },
    )
    assert response.status_code == HTTPStatus.OK
    response_json = response.json()
    assert response_json == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": ErrorCode.RESOURCE_NOT_FOUND.value,
            "message": "Prompt not_found not found",
        },
    }


# ---------------------------------------------------------------------------
# Tests from test_server_handling_prompt_scopes.py
# ---------------------------------------------------------------------------


def test_call_prompt_with_scope() -> None:
    def prompt_with_scope() -> tuple[PromptMessage, ...]:
        """Private prompt.

        Only accessible to authenticated users with the 'private' scope.
        """
        return (
            PromptMessage(
                role="user",
                content=TextContent(text="This is a private prompt."),
            ),
        )

    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(
            Prompt(
                func=prompt_with_scope,
                arguments_type=type(None),
                scopes=("private",),
            ),
        ),
    )
    app = mount_mcp_server(server, BasicAuthBackend(("private",)))
    with TestClient(app, headers={"Authorization": "Bearer TEST_TOKEN"}) as client:
        response = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "prompts/get",
                "id": 1,
                "params": {
                    "name": "prompt_with_scope",
                    "arguments": {},
                },
            },
        )
        assert response.status_code == HTTPStatus.OK
        response_json = response.json()
        assert response_json == {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "description": (
                    "Private prompt.\n"
                    "\n"
                    "Only accessible to authenticated users with the 'private' scope.\n"
                ),
                "messages": [
                    {
                        "role": "user",
                        "content": {
                            "text": "This is a private prompt.",
                            "type": "text",
                        },
                    },
                ],
            },
        }


def test_call_prompt_without_required_scope() -> None:
    def prompt_with_scope() -> tuple[PromptMessage, ...]:
        """Private prompt.

        Only accessible to authenticated users with the 'private' scope.
        """
        return (
            PromptMessage(
                role="user",
                content=TextContent(text="This is a private prompt."),
            ),
        )

    server = MCPServer(
        tools=(),
        name="test",
        version="1.0.0",
        prompts=(
            Prompt(
                func=prompt_with_scope,
                arguments_type=type(None),
                scopes=("private",),
            ),
        ),
    )
    app = mount_mcp_server(server, BasicAuthBackend(("non_sufficient_scope",)))
    with TestClient(app, headers={"Authorization": "Bearer TEST_TOKEN"}) as client:
        response = client.post(
            "/mcp",
            json={
                "jsonrpc": "2.0",
                "method": "prompts/get",
                "id": 1,
                "params": {
                    "name": "prompt_with_scope",
                    "arguments": {},
                },
            },
        )
        assert response.status_code == HTTPStatus.FORBIDDEN
        assert response.json() == {"error": "insufficient_scope"}


# ---------------------------------------------------------------------------
# Tests from test_coverage_gaps.py (prompt-related)
# ---------------------------------------------------------------------------


def test_prompt_without_args_reraises_server_error() -> None:
    def prompt_raising_server_error() -> tuple[PromptMessage, ...]:
        """Raise a ServerError."""
        raise ServerError(
            Error(code=ErrorCode.INTERNAL_ERROR, description="Prompt server error"),
        )

    server = MCPServer(
        name="test",
        version="1.0.0",
        prompts=(
            Prompt(func=prompt_raising_server_error, arguments_type=type(None)),
        ),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {"name": "prompt_raising_server_error", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["error"]["code"] == ErrorCode.INTERNAL_ERROR.value


def test_prompt_with_args_reraises_server_error() -> None:
    def prompt_raising_server_error(
        _args: Arguments[NoArguments],
    ) -> tuple[PromptMessage, ...]:
        """Raise a ServerError."""
        raise ServerError(
            Error(code=ErrorCode.INTERNAL_ERROR, description="Prompt args server error"),
        )

    server = MCPServer(
        name="test",
        version="1.0.0",
        prompts=(
            Prompt(func=prompt_raising_server_error, arguments_type=NoArguments),
        ),
    )
    client = TestClient(server.app)
    response = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "method": "prompts/get",
            "id": 1,
            "params": {"name": "prompt_raising_server_error", "arguments": {}},
        },
    )
    assert response.status_code == HTTPStatus.OK
    data = response.json()
    assert data["error"]["code"] == ErrorCode.INTERNAL_ERROR.value
