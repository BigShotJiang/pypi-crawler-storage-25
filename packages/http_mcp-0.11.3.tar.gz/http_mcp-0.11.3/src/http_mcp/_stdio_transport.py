import asyncio
import json
import logging
import sys
from typing import TYPE_CHECKING

from pydantic import ValidationError
from starlette.requests import Request

from http_mcp._json_rcp_types.errors import Error, ErrorCode
from http_mcp._json_rcp_types.messages import (
    JSONRPCError,
    JSONRPCMessage,
    JSONRPCRequest,
)
from http_mcp._transport_base import BaseTransport
from http_mcp.exceptions import InsufficientScopeError
from http_mcp.server_interface import ServerInterface
from http_mcp.types.utils import sanitize_validation_errors

if TYPE_CHECKING:
    from starlette.types import Scope


LOGGER = logging.getLogger(__name__)

MAXIMUM_MESSAGE_SIZE = 4 * 1024 * 1024  # 4MB, matching HTTP transport
_MAX_LOG_LENGTH = 500


class StdioTransport(BaseTransport):
    def __init__(self, server: ServerInterface) -> None:
        super().__init__(server)

    async def start(self, request_headers: dict[str, str] | None = None) -> None:
        """Start listening for messages on stdin."""
        loop = asyncio.get_running_loop()
        reader = asyncio.StreamReader(limit=MAXIMUM_MESSAGE_SIZE)
        protocol = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)

        writer_transport, writer_protocol = await loop.connect_write_pipe(
            asyncio.streams.FlowControlMixin,
            sys.stdout,
        )
        writer = asyncio.StreamWriter(writer_transport, writer_protocol, None, loop)

        while not reader.at_eof():
            try:
                line = await reader.readline()
            except ValueError:
                LOGGER.exception(
                    "STDIO message exceeded maximum size of %d bytes",
                    MAXIMUM_MESSAGE_SIZE,
                )
                error_response = JSONRPCError(
                    jsonrpc="2.0",
                    error=Error(
                        code=ErrorCode.INVALID_PARAMS,
                        description="Message too large",
                    ),
                )
                await self._write_response(
                    writer,
                    error_response.model_dump_json(by_alias=True, exclude_none=True),
                )
                break

            if not line:
                continue

            line = line.strip()
            if not line:
                continue

            LOGGER.debug("Received message: %s", line[:_MAX_LOG_LENGTH])
            json_message = {}
            try:
                json_message = json.loads(line)
                await self._handle_message(
                    JSONRPCRequest.model_validate(json_message),
                    writer,
                    request_headers,
                )
            except ValidationError as e:
                LOGGER.exception("STDIO request validation error")
                error_response = JSONRPCError(
                    jsonrpc="2.0",
                    error=Error(
                        code=ErrorCode.INVALID_PARAMS,
                        description=sanitize_validation_errors(e),
                    ),
                )
                await self._write_response(
                    writer,
                    error_response.model_dump_json(by_alias=True, exclude_none=True),
                )
            except json.JSONDecodeError:
                error_response = JSONRPCError(
                    jsonrpc="2.0",
                    error=Error(
                        code=ErrorCode.INVALID_PARAMS,
                        description="Parse error",
                    ),
                )
                await self._write_response(
                    writer,
                    error_response.model_dump_json(by_alias=True, exclude_none=True),
                )
                continue

    async def _write_response(
        self,
        writer: asyncio.StreamWriter,
        response: str,
    ) -> None:
        """Write a JSON-RPC response to stdout."""
        LOGGER.debug("Sending response: %s", response[:_MAX_LOG_LENGTH])
        writer.write(response.encode("utf-8"))
        writer.write(b"\n")
        await writer.drain()

    async def _handle_message(
        self,
        message: JSONRPCRequest,
        writer: asyncio.StreamWriter,
        request_headers: dict[str, str] | None = None,
    ) -> None:
        asgi_headers: list[tuple[bytes, bytes]] = (
            [(k.lower().encode(), v.encode()) for k, v in request_headers.items()]
            if request_headers
            else []
        )
        scope: Scope = {
            "type": "http",
            "method": "POST",
            "headers": asgi_headers,
            "path": "/",
            "client": ("127.0.0.1", 0),
            "server": ("127.0.0.1", 0),
            "root_path": "",
        }
        dummy_request = Request(scope)

        async def process(msg: JSONRPCRequest) -> JSONRPCMessage | JSONRPCError | None:
            if msg.method.startswith("notifications/"):
                return None

            try:
                return await self._process_request(msg, dummy_request)
            except InsufficientScopeError as e:
                required = " ".join(e.required_scopes) if e.required_scopes else "unknown"
                return JSONRPCError(
                    jsonrpc="2.0",
                    id=msg.id,
                    error=Error(
                        code=ErrorCode.RESOURCE_NOT_FOUND,
                        description=f"Insufficient scope; required: {required}",
                    ),
                )
            except Exception:
                LOGGER.exception("Unexpected error processing STDIO request")
                return JSONRPCError(
                    jsonrpc="2.0",
                    id=msg.id,
                    error=Error(
                        code=ErrorCode.INTERNAL_ERROR,
                        description="Internal server error",
                    ),
                )

        response = await process(message)
        if response:
            await self._write_response(
                writer,
                response.model_dump_json(by_alias=True, exclude_none=True),
            )
