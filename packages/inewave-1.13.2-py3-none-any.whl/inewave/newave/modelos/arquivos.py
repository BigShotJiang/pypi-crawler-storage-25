from cfinterface.components.section import Section
from cfinterface.components.line import Line
from cfinterface.components.literalfield import LiteralField
from typing import Any, IO, List, Optional
import pandas as pd  # type: ignore[import-untyped]  # no pandas-stubs package


class BlocoNomesArquivos(Section):
    """
    Bloco de informações do arquivo de
    entrada do NEWAVE `arquivos.dat`.
    """

    __slots__ = ["__linha"]

    FIM_BLOCO = " 9999"

    def __init__(
        self,
        previous: Optional[Any] = None,
        next: Optional[Any] = None,
        data: Optional[Any] = None,
    ) -> None:
        super().__init__(previous, next, data)
        self.__linha = Line([LiteralField(30, 0), LiteralField(40, 30)])

    def __eq__(self, o: object) -> bool:
        if not isinstance(o, BlocoNomesArquivos):
            return False
        bloco: BlocoNomesArquivos = o
        if not all(
            [
                isinstance(self.data, pd.DataFrame),
                isinstance(o.data, pd.DataFrame),
            ]
        ):
            return False
        else:
            return self.data.equals(bloco.data)

    # Override
    def read(self, file: IO[Any], *args: Any, **kwargs: Any) -> None:  # type: ignore[override]  # signature extends base class
        def converte_tabela_em_df() -> pd.DataFrame:
            df = pd.DataFrame(data={"legenda": legendas, "nome": nomes})
            return df

        legendas: List[str] = []
        nomes: List[str] = []
        while True:
            linha = file.readline()
            if len(linha) < 3:
                self.data = converte_tabela_em_df()
                break
            dados = self.__linha.read(linha)
            legendas.append(dados[0])
            nomes.append(dados[1])

    # Override
    def write(self, file: IO[Any], *args: Any, **kwargs: Any) -> None:  # type: ignore[override]  # signature extends base class
        if not isinstance(self.data, pd.DataFrame):
            raise ValueError("Dados do arquivos.dat não foram lidos")
        for _, linha in self.data.iterrows():
            file.write(self.__linha.write(linha.tolist()))
