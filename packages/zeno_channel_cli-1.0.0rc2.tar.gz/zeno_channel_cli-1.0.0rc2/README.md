# zeno-channel-cli

Terminal channel for [Zeno](https://github.com/nkootstra/zeno). Reads
lines from stdin into `IncomingMessage`s and renders the agent's
`OutgoingMessage`s to stdout. Doubles as a manual smoke-test harness
and as the simplest reference implementation of the `Channel` protocol.

## Install

```bash
uv add 'zeno-framework[cli]'
# or, without the AI package:
uv add zeno-channel-cli
```

## Minimal usage

```python
import asyncio

from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.cli import CliChannel
from zeno.testing import FakeProvider

app = ZenoApp(
    agent=Agent(name="root", instructions="You are Zeno, a helpful assistant."),
    channels=[CliChannel()],
    provider=FakeProvider(),  # swap for OpenAIProvider / ClaudeSDKProvider in production
)

asyncio.run(app.run())
```

Then run the script. Type a line, hit return, see the reply. `Ctrl-D`
or `Ctrl-C` exits cleanly. `user_id` defaults to `$USER` (or `"local"`
if unset) so a developer running the snippet above gets a sensible
tenant scope without configuration. Override explicitly in production:

```python
CliChannel(user_id="alice", prompt=">>> ")
```

## Behavior

- **Capabilities**: `supports_streaming=False`,
  `supports_threading=False`. The core `StreamBuffer` consolidates
  chunked replies into one `send()` at finalize-time, which the
  renderer emits as a single line.
- **Stdin**: read via `asyncio.to_thread(stream.readline)` so the CLI
  channel stays dependency-free (no `aioconsole`). At most one line
  read is in flight at a time, matching REPL semantics.
- **Inbound queue**: exposes `inbound_put(message)` so
  [`zeno-scheduler`](https://github.com/nkootstra/zeno/tree/main/packages/zeno-scheduler)
  can inject proactive messages without going through stdin.
- **Shutdown**: `stop()` is idempotent and closes the renderer; calling
  `send()` after `stop()` raises `ChannelError`.

## Testing

```bash
uv run pytest packages/zeno-channel-cli
```

Tests use `io.StringIO` for stdin/stdout — no terminal needed.

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
