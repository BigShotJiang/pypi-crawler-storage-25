print("""import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets,transforms
from torch.utils.data import DataLoader
import os

train_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ToTensor(),
])

test_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

train_dir = "./dataset/train"

test_dir="./dataset/test"
train_dataset = datasets.ImageFolder(train_dir,transform=train_transforms)

test_dataset = datasets.ImageFolder(test_dir,transform=test_transforms)

class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN,self).__init__()

        self.features = nn.Sequential(
            #Block 1 
            nn.Conv2d(3,32,kernel_size=3,padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),

            #Block 2 
            nn.Conv2d(32,64,kernel_size=3,padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),

            # Block 3
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2),

            # Block 4
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )

        self.pool = nn.AdaptiveAvgPool2d((1,1))

        self.classifier = nn.Sequential(
            nn.Linear(256,128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128,2)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print("Using device:", device)

test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

model = SimpleCNN().to(device)
model.load_state_dict(torch.load("best_model.pth"))
model.eval()

def test_model(model, loader):
    model.eval()
    correct = 0
    total = 0

    all_preds = []
    all_labels = []

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            _, predicted = torch.max(outputs, 1)

            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    accuracy = correct / total
    return accuracy, all_preds, all_labels

test_acc, preds, labels = test_model(model, test_loader)
print("Final Test Accuracy:", test_acc)

from sklearn.metrics import confusion_matrix, classification_report

cm = confusion_matrix(labels, preds)
print("Confusion Matrix:\\n", cm)

print("\\nClassification Report:\\n")
print(classification_report(labels, preds, target_names=train_dataset.classes))

from torchviz import make_dot
import torch

dummy_input = torch.randn(1, 3, 224, 224).to(device)
output = model(dummy_input)

graph = make_dot(output, params=dict(model.named_parameters()))
graph.render("cnn_architecture", format="png")

from torchinfo import summary

summary(model, input_size=(1, 3, 224, 224))""")
