print("""import numpy as np

def mp_neuron(x, w, theta):
    return 1 if np.dot(x, w) >= theta else 0

# XOR inputs
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])


print("XOR using MP Neuron")

for x in X:
    # Hidden layer
    h1 = mp_neuron(x, [1, -1], 1)   # A AND NOT B
    h2 = mp_neuron(x, [-1, 1], 1)   # NOT A AND B

    # Output layer
    out = mp_neuron([h1, h2], [1, 1], 1)

    print(x, "→", out)


import numpy as np
print("XNOR using MP Neuron")

for x in X:
    # Hidden layer
    h1 = mp_neuron(x, [1, 1], 2)     # A AND B
    h2 = mp_neuron(x, [-1, -1], 0)   # NOT A AND NOT B  

    # Output layer
    out = mp_neuron([h1, h2], [1, 1], 1)

    print(x, "→", out)
""")
