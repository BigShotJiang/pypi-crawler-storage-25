import os
import json
import glob

def main():
    directory = '/Users/rayyansiddiqui/coding/Python/packages/expkit/dlexps-main'
    notebooks = glob.glob(os.path.join(directory, '*.ipynb'))
    
    for nb_path in notebooks:
        basename = os.path.basename(nb_path)
        name, _ = os.path.splitext(basename)
        
        # Clean up the file name to avoid spaces or special characters in the python module name
        clean_name = name.replace(" ", "_").replace("(", "").replace(")", "")
        out_path = os.path.join(directory, f"{clean_name}.py")
        
        try:
            with open(nb_path, 'r', encoding='utf-8') as f:
                nb_data = json.load(f)
                
            code_blocks = []
            for cell in nb_data.get('cells', []):
                if cell.get('cell_type') == 'code':
                    source = ''.join(cell.get('source', []))
                    if source.strip():
                        code_blocks.append(source)
            
            full_code = '\n\n'.join(code_blocks)
            
            # Escape triple quotes and backslashes to safely embed in a raw string block
            escaped_code = full_code.replace('\\', '\\\\').replace('"""', '\\"\\"\\"')
            
            # Create a script that just prints the entire code block
            final_content = f'print("""{escaped_code}""")\n'
            
            with open(out_path, 'w', encoding='utf-8') as f:
                f.write(final_content)
                
            print(f"Converted {basename} to {clean_name}.py")
        except Exception as e:
            print(f"Error processing {basename}: {e}")

if __name__ == '__main__':
    main()
