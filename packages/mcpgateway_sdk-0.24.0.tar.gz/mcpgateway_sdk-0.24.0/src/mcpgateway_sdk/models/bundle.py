"""Bundle models."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class BundleTool(BaseModel):
    """A tool within a bundle, with optional overrides."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    tool_id: UUID
    override_name: str | None = None
    override_description: str | None = None
    enabled: bool = True
    display_order: int = 0
    has_override_embedding: bool = False

    original_name: str
    original_description: str
    server_id: UUID
    server_name: str
    display_name: str | None = None
    input_schema: dict[str, Any]

    effective_name: str
    effective_description: str

    created_at: datetime
    updated_at: datetime


class Bundle(BaseModel):
    """An MCP bundle grouping tools for an agent."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    description: str | None = None
    agent_id: UUID | None = None
    tool_count: int = 0
    created_at: datetime
    updated_at: datetime


class BundleWithKey(Bundle):
    """Bundle response including the opaque sharing key."""

    bundle_key: str


class BundleDetail(BundleWithKey):
    """Bundle response including tools list."""

    tools: list[BundleTool]


class ServerAssignment(BaseModel):
    """Response from assigning a server's tools to a bundle."""

    model_config = ConfigDict(extra="ignore")

    tools_added: int
    tools_existing: int
