"""Walk a directory tree, chunk files, embed, and store."""

import os
from pathlib import Path

from .chunker import chunk_text

TEXT_EXTENSIONS = {
    # Code
    ".py", ".pyw", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx",
    ".go", ".rs", ".java", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp",
    ".cs", ".rb", ".php", ".swift", ".kt", ".scala", ".r", ".lua",
    ".vim", ".ex", ".exs", ".erl", ".hs", ".ml", ".fs", ".fsx",
    # Shell / config
    ".sh", ".bash", ".zsh", ".fish", ".ps1", ".bat", ".cmd",
    ".toml", ".yaml", ".yml", ".json", ".jsonc", ".ini", ".cfg",
    ".env", ".conf", ".config",
    # Docs / markup
    ".md", ".mdx", ".rst", ".txt", ".adoc", ".tex",
    # Web
    ".html", ".htm", ".css", ".scss", ".sass", ".less", ".svelte", ".vue",
    # Data / query
    ".sql", ".graphql", ".gql", ".proto",
    # Misc
    ".xml", ".gitignore", ".dockerignore", ".editorconfig", ".lock",
}

SKIP_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", ".hypothesis",
    "dist", "build", ".idea", ".vscode", "target", "vendor",
    ".gradle", ".cargo", "coverage", ".coverage", "htmlcov",
}

MAX_FILE_SIZE = 512 * 1024  # 512 KB — skip huge generated files
BATCH_SIZE = 32


def _iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(
            d for d in dirnames
            if d not in SKIP_DIRS and not d.startswith(".")
        )
        for fname in filenames:
            p = Path(dirpath) / fname
            ext = p.suffix.lower()
            if ext in TEXT_EXTENSIONS or ext == ".pdf":
                yield p


def _read_text(path: Path) -> str | None:
    try:
        if path.stat().st_size > MAX_FILE_SIZE:
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None


def _read_pdf(path: Path) -> str | None:
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        pages = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(pages)
    except Exception:
        return None


def index_path(root: Path, store, embedder, progress=None, task_id=None) -> dict:
    """Index all files under root. Returns {indexed, skipped, failed, total}."""
    files = list(_iter_files(root))
    indexed = skipped = failed = 0

    batch_files: list[Path] = []
    batch_chunk_groups: list[list[dict]] = []
    batch_texts: list[str] = []

    def flush():
        nonlocal indexed
        if not batch_texts:
            return
        embeddings = embedder.embed(batch_texts)
        ei = 0
        for bf, bchunks in zip(batch_files, batch_chunk_groups):
            n = len(bchunks)
            stat = bf.stat()
            store.upsert_file(
                str(bf), stat.st_mtime, stat.st_size,
                bchunks, embeddings[ei:ei + n],
            )
            ei += n
            indexed += 1
        batch_files.clear()
        batch_chunk_groups.clear()
        batch_texts.clear()

    for fpath in files:
        if progress is not None and task_id is not None:
            progress.advance(task_id)
        try:
            stat = fpath.stat()
            if not store.file_needs_indexing(str(fpath), stat.st_mtime, stat.st_size):
                skipped += 1
                continue

            text = _read_pdf(fpath) if fpath.suffix.lower() == ".pdf" else _read_text(fpath)
            if not text or not text.strip():
                continue

            chunks = chunk_text(text)
            if not chunks:
                continue

            batch_files.append(fpath)
            batch_chunk_groups.append(chunks)
            batch_texts.extend(c["text"] for c in chunks)

            if len(batch_files) >= BATCH_SIZE:
                flush()

        except Exception:
            failed += 1

    flush()
    return {"indexed": indexed, "skipped": skipped, "failed": failed, "total": len(files)}
