"""recall — local semantic file search."""

import sys
from pathlib import Path

from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.text import Text

console = Console()

HELP = """\
[bold]recall[/bold] — local semantic search

  [cyan]recall index [PATH][/cyan]      Index a directory (default: current dir). Incremental.
  [cyan]recall "query"[/cyan]           Search the index by meaning.
  [cyan]recall status[/cyan]            Show index stats.
  [cyan]recall clear[/cyan]             Wipe the index.

Options for search:
  --top N, -n N           Return N results (default: 10)
  --json                  JSON output

Examples:
  recall index ~/IdeaProjects
  recall "script that uses COM to export iTunes playlists"
  recall "sqlite WAL mode" --top 5
"""


def _print_help():
    console.print(HELP)


def _do_index(path: str):
    from .embedder import Embedder
    from .indexer import index_path
    from .store import Store

    root = Path(path).resolve()
    if not root.is_dir():
        console.print(f"[red]Not a directory:[/red] {root}")
        sys.exit(1)

    console.print(f"[bold]Indexing[/bold] {root}")
    console.print("[dim]Loading embedding model (first run downloads ~130 MB)...[/dim]")

    store = Store()
    embedder = Embedder()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        transient=True,
    ) as progress:
        from .indexer import _iter_files
        files = list(_iter_files(root))
        task = progress.add_task("Scanning...", total=len(files))
        result = index_path(root, store, embedder, progress=progress, task_id=task)

    store.close()

    console.print(
        f"[green]Done.[/green] "
        f"[bold]{result['indexed']}[/bold] indexed  "
        f"[dim]{result['skipped']} skipped[/dim]  "
        f"[red]{result['failed']} failed[/red]  "
        f"[dim]({result['total']} total)[/dim]"
    )


def _do_status():
    from .store import Store
    store = Store()
    s = store.stats()
    store.close()
    console.print(
        f"[bold]{s['files']}[/bold] files, [bold]{s['chunks']}[/bold] chunks"
    )
    console.print(f"[dim]{s['db_path']}[/dim]")


def _do_clear():
    from .store import Store
    ans = console.input("[yellow]Wipe the entire index? [y/N][/yellow] ")
    if ans.strip().lower() != "y":
        console.print("Cancelled.")
        return
    store = Store()
    store.clear()
    store.close()
    console.print("[green]Index cleared.[/green]")


def _do_search(query: str, top: int, as_json: bool):
    from .embedder import Embedder
    from .store import Store

    store = Store()
    s = store.stats()
    if s["files"] == 0:
        console.print("[yellow]Index is empty. Run: recall index <path>[/yellow]")
        store.close()
        return

    embedder = Embedder()
    qemb = embedder.embed_one(query)
    results = store.search(qemb, top_k=top)
    store.close()

    if not results:
        console.print("[yellow]No results.[/yellow]")
        return

    if as_json:
        import json
        out = [
            {
                "path": r["path"],
                "start_line": r["start_line"],
                "end_line": r["end_line"],
                "distance": r["distance"],
                "snippet": r["text"][:300].strip(),
            }
            for r in results
        ]
        print(json.dumps(out, indent=2))
        return

    for i, r in enumerate(results, 1):
        path = Path(r["path"])
        # For normalized embeddings, vec0 L2 distance d satisfies: cos_sim = 1 - d²/2
        d = r["distance"]
        score = max(0.0, 1.0 - (d * d / 2))

        header = Text()
        header.append(f"{i}. ", style="dim")
        header.append(str(path), style="bold cyan")
        header.append(f"  :{r['start_line']}", style="dim")
        header.append(f"  {score:.0%}", style="green")
        console.print(header)

        from rich.markup import escape
        snippet = escape(r["text"][:280].strip().replace("\n", "  "))
        console.print(f"   [dim]{snippet}[/dim]")
        console.print()


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        _print_help()
        return

    cmd = args[0]

    if cmd == "index":
        path = args[1] if len(args) > 1 else "."
        _do_index(path)
        return

    if cmd == "status":
        _do_status()
        return

    if cmd == "clear":
        _do_clear()
        return

    # Everything else is a search query
    top = 10
    as_json = False
    query_parts = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--top", "-n") and i + 1 < len(args):
            try:
                top = int(args[i + 1])
                i += 2
                continue
            except ValueError:
                pass
        elif a.startswith("--top="):
            try:
                top = int(a.split("=", 1)[1])
                i += 1
                continue
            except ValueError:
                pass
        elif a == "--json":
            as_json = True
            i += 1
            continue
        query_parts.append(a)
        i += 1

    if not query_parts:
        _print_help()
        return

    _do_search(" ".join(query_parts), top, as_json)
