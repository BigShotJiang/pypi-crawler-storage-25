"""sqlite-vec vector store for file chunks and embeddings."""

import sqlite3
import time
from pathlib import Path

import numpy as np
import sqlite_vec

DB_PATH = Path.home() / ".recall" / "index.db"
EMBEDDING_DIM = 384


class Store:
    def __init__(self, db_path: Path = DB_PATH):
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._path = db_path
        self._conn = sqlite3.connect(db_path)
        self._conn.enable_load_extension(True)
        sqlite_vec.load(self._conn)
        self._conn.enable_load_extension(False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS files (
                id       INTEGER PRIMARY KEY,
                path     TEXT UNIQUE NOT NULL,
                mtime    REAL NOT NULL,
                size     INTEGER NOT NULL,
                indexed_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS chunks (
                id        INTEGER PRIMARY KEY,
                file_id   INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
                chunk_idx INTEGER NOT NULL,
                start_line INTEGER NOT NULL,
                end_line   INTEGER NOT NULL,
                text      TEXT NOT NULL
            );
        """)
        self._conn.execute(f"""
            CREATE VIRTUAL TABLE IF NOT EXISTS chunk_embeddings USING vec0(
                chunk_id  INTEGER PRIMARY KEY,
                embedding float[{EMBEDDING_DIM}]
            )
        """)
        self._conn.commit()

    def file_needs_indexing(self, path: str, mtime: float, size: int) -> bool:
        row = self._conn.execute(
            "SELECT mtime, size FROM files WHERE path = ?", (path,)
        ).fetchone()
        return row is None or row[0] != mtime or row[1] != size

    def _delete_file_by_id(self, file_id: int):
        chunk_ids = [
            r[0] for r in self._conn.execute(
                "SELECT id FROM chunks WHERE file_id = ?", (file_id,)
            )
        ]
        for cid in chunk_ids:
            self._conn.execute(
                "DELETE FROM chunk_embeddings WHERE chunk_id = ?", (cid,)
            )
        self._conn.execute("DELETE FROM chunks WHERE file_id = ?", (file_id,))
        self._conn.execute("DELETE FROM files WHERE id = ?", (file_id,))

    def upsert_file(
        self,
        path: str,
        mtime: float,
        size: int,
        chunks: list[dict],
        embeddings: np.ndarray,
    ):
        row = self._conn.execute(
            "SELECT id FROM files WHERE path = ?", (path,)
        ).fetchone()
        if row:
            self._delete_file_by_id(row[0])

        cur = self._conn.execute(
            "INSERT INTO files (path, mtime, size, indexed_at) VALUES (?, ?, ?, ?)",
            (path, mtime, size, time.time()),
        )
        file_id = cur.lastrowid

        for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
            cur2 = self._conn.execute(
                "INSERT INTO chunks (file_id, chunk_idx, start_line, end_line, text)"
                " VALUES (?, ?, ?, ?, ?)",
                (file_id, i, chunk["start_line"], chunk["end_line"], chunk["text"]),
            )
            chunk_id = cur2.lastrowid
            self._conn.execute(
                "INSERT INTO chunk_embeddings (chunk_id, embedding) VALUES (?, ?)",
                (chunk_id, emb.astype(np.float32).tobytes()),
            )
        self._conn.commit()

    def search(self, query_embedding: np.ndarray, top_k: int = 10) -> list[dict]:
        emb_bytes = query_embedding.astype(np.float32).tobytes()
        rows = self._conn.execute(
            """
            SELECT c.id, c.start_line, c.end_line, c.text, f.path, ce.distance
            FROM chunk_embeddings ce
            JOIN chunks c ON c.id = ce.chunk_id
            JOIN files f ON f.id = c.file_id
            WHERE ce.embedding MATCH ?
              AND k = ?
            ORDER BY ce.distance
            """,
            (emb_bytes, top_k),
        ).fetchall()
        return [
            {
                "chunk_id": r[0],
                "start_line": r[1],
                "end_line": r[2],
                "text": r[3],
                "path": r[4],
                "distance": r[5],
            }
            for r in rows
        ]

    def stats(self) -> dict:
        files = self._conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        chunks = self._conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        return {"files": files, "chunks": chunks, "db_path": str(self._path)}

    def clear(self):
        chunk_ids = [r[0] for r in self._conn.execute("SELECT id FROM chunks")]
        for cid in chunk_ids:
            self._conn.execute(
                "DELETE FROM chunk_embeddings WHERE chunk_id = ?", (cid,)
            )
        self._conn.execute("DELETE FROM chunks")
        self._conn.execute("DELETE FROM files")
        self._conn.commit()

    def close(self):
        self._conn.close()
