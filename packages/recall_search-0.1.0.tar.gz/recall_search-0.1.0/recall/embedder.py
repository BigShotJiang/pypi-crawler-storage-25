"""Embedding model wrapper — GPU if available, CPU fallback."""

import os
import warnings
import numpy as np

MODEL_NAME = "BAAI/bge-small-en-v1.5"
_INSTANCE = None


def _get_model():
    global _INSTANCE
    if _INSTANCE is None:
        import torch

        # Suppress noisy HuggingFace / transformers output
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

        import logging
        logging.getLogger("sentence_transformers").setLevel(logging.ERROR)
        logging.getLogger("transformers").setLevel(logging.ERROR)
        logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

        import io
        import contextlib
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from sentence_transformers import SentenceTransformer
            device = "cuda" if torch.cuda.is_available() else "cpu"
            with contextlib.redirect_stdout(io.StringIO()):
                _INSTANCE = SentenceTransformer(MODEL_NAME, device=device)
    return _INSTANCE


class Embedder:
    def __init__(self):
        self._model = _get_model()

    def embed(self, texts: list[str]) -> np.ndarray:
        return self._model.encode(
            texts,
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=64,
        )

    def embed_one(self, text: str) -> np.ndarray:
        return self.embed([text])[0]

    @property
    def dim(self) -> int:
        return 384
