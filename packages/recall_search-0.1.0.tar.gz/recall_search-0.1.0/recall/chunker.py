"""Split file text into overlapping line-based chunks."""

CHUNK_LINES = 40
OVERLAP_LINES = 8
MAX_CHUNK_CHARS = 4000


def chunk_text(text: str) -> list[dict]:
    """Return list of {start_line, end_line, text} dicts (1-indexed lines)."""
    lines = text.splitlines(keepends=True)
    if not lines:
        return []

    chunks = []
    i = 0
    while i < len(lines):
        end = min(i + CHUNK_LINES, len(lines))
        chunk = "".join(lines[i:end])
        if chunk.strip():
            chunks.append({
                "start_line": i + 1,
                "end_line": end,
                "text": chunk[:MAX_CHUNK_CHARS],
            })
        if end == len(lines):
            break
        i = end - OVERLAP_LINES
        if i < 0:
            i = 0

    return chunks
