import numpy as np
import pytest
from pathlib import Path

from recall.indexer import _iter_files, chunk_text, SKIP_DIRS, TEXT_EXTENSIONS
from recall.chunker import chunk_text


class FakeEmbedder:
    def embed(self, texts):
        return np.random.randn(len(texts), 384).astype(np.float32)

    def embed_one(self, text):
        return self.embed([text])[0]


class FakeStore:
    def __init__(self):
        self.indexed = {}
        self.calls = []

    def file_needs_indexing(self, path, mtime, size):
        return path not in self.indexed

    def upsert_file(self, path, mtime, size, chunks, embeddings):
        self.indexed[path] = {"mtime": mtime, "size": size, "chunks": chunks}
        self.calls.append(path)


def test_iter_files_basic(tmp_path):
    (tmp_path / "main.py").write_text("print('hello')")
    (tmp_path / "notes.md").write_text("# Notes")
    (tmp_path / "image.png").write_bytes(b"\x89PNG")
    files = list(_iter_files(tmp_path))
    paths = {f.name for f in files}
    assert "main.py" in paths
    assert "notes.md" in paths
    assert "image.png" not in paths


def test_iter_files_skips_skip_dirs(tmp_path):
    skip_dir = tmp_path / "node_modules"
    skip_dir.mkdir()
    (skip_dir / "index.js").write_text("module.exports = {}")
    (tmp_path / "app.py").write_text("pass")
    files = list(_iter_files(tmp_path))
    paths = {f.name for f in files}
    assert "index.js" not in paths
    assert "app.py" in paths


def test_iter_files_skips_hidden_dirs(tmp_path):
    hidden = tmp_path / ".hidden"
    hidden.mkdir()
    (hidden / "secret.py").write_text("x = 1")
    files = list(_iter_files(tmp_path))
    assert not any(f.name == "secret.py" for f in files)


def test_iter_files_recursive(tmp_path):
    sub = tmp_path / "src" / "utils"
    sub.mkdir(parents=True)
    (sub / "helper.py").write_text("def help(): pass")
    files = list(_iter_files(tmp_path))
    assert any(f.name == "helper.py" for f in files)


def test_index_path_basic(tmp_path):
    from recall.indexer import index_path

    (tmp_path / "code.py").write_text("def foo(): return 42\n" * 5)
    (tmp_path / "readme.md").write_text("# Project\nThis does stuff.")

    store = FakeStore()
    embedder = FakeEmbedder()
    result = index_path(tmp_path, store, embedder)

    assert result["indexed"] == 2
    assert result["skipped"] == 0
    assert result["failed"] == 0
    assert result["total"] == 2


def test_index_path_skips_unchanged(tmp_path):
    from recall.indexer import index_path

    f = tmp_path / "code.py"
    f.write_text("x = 1\n")

    class TrackingStore(FakeStore):
        def file_needs_indexing(self, path, mtime, size):
            return False  # Pretend everything is up to date

    store = TrackingStore()
    embedder = FakeEmbedder()
    result = index_path(tmp_path, store, embedder)

    assert result["skipped"] == 1
    assert result["indexed"] == 0


def test_index_path_empty_dir(tmp_path):
    from recall.indexer import index_path
    store = FakeStore()
    embedder = FakeEmbedder()
    result = index_path(tmp_path, store, embedder)
    assert result["total"] == 0
    assert result["indexed"] == 0
