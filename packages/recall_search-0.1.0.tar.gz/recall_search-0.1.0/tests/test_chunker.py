import pytest
from recall.chunker import chunk_text, CHUNK_LINES, OVERLAP_LINES


def test_empty_string():
    assert chunk_text("") == []


def test_whitespace_only():
    assert chunk_text("   \n  \n") == []


def test_single_chunk():
    text = "\n".join(f"line {i}" for i in range(10))
    chunks = chunk_text(text)
    assert len(chunks) == 1
    assert chunks[0]["start_line"] == 1
    assert chunks[0]["end_line"] == 10
    assert "line 0" in chunks[0]["text"]


def test_two_chunks():
    # CHUNK_LINES=40, OVERLAP=8 → second chunk starts at line 33
    lines = [f"line {i}" for i in range(50)]
    text = "\n".join(lines)
    chunks = chunk_text(text)
    assert len(chunks) == 2
    assert chunks[0]["start_line"] == 1
    assert chunks[0]["end_line"] == 40
    assert chunks[1]["start_line"] == 33  # 40 - 8 + 1
    assert chunks[1]["end_line"] == 50


def test_overlap_content():
    lines = [f"line {i}" for i in range(50)]
    text = "\n".join(lines)
    chunks = chunk_text(text)
    # Lines 33–40 should appear in both chunks
    assert "line 32" in chunks[0]["text"]  # 0-indexed line 32 = display line 33
    assert "line 32" in chunks[1]["text"]


def test_exact_chunk_size():
    text = "\n".join(f"x" for _ in range(CHUNK_LINES))
    chunks = chunk_text(text)
    assert len(chunks) == 1


def test_max_chars_truncated():
    long_line = "a" * 5000
    chunks = chunk_text(long_line)
    assert len(chunks) == 1
    assert len(chunks[0]["text"]) <= 4000


def test_line_numbers_are_1indexed():
    text = "first\nsecond\nthird"
    chunks = chunk_text(text)
    assert chunks[0]["start_line"] == 1


def test_many_chunks():
    lines = [f"line {i}" for i in range(200)]
    text = "\n".join(lines)
    chunks = chunk_text(text)
    assert len(chunks) > 4
    # Verify monotonically increasing start lines
    starts = [c["start_line"] for c in chunks]
    assert starts == sorted(starts)
    # Last chunk covers the end
    assert chunks[-1]["end_line"] == 200
