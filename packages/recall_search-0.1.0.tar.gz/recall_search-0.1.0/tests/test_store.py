import tempfile
import time
from pathlib import Path

import numpy as np
import pytest

from recall.store import Store, EMBEDDING_DIM


@pytest.fixture
def store(tmp_path):
    db = tmp_path / "test.db"
    s = Store(db_path=db)
    yield s
    s.close()


def _rand_emb(n=1) -> np.ndarray:
    v = np.random.randn(n, EMBEDDING_DIM).astype(np.float32)
    norms = np.linalg.norm(v, axis=1, keepdims=True)
    return v / norms


def test_empty_stats(store):
    s = store.stats()
    assert s["files"] == 0
    assert s["chunks"] == 0


def test_upsert_and_stats(store):
    chunks = [{"start_line": 1, "end_line": 10, "text": "hello world"}]
    embs = _rand_emb(1)
    store.upsert_file("fake/file.py", mtime=1.0, size=100, chunks=chunks, embeddings=embs)
    s = store.stats()
    assert s["files"] == 1
    assert s["chunks"] == 1


def test_file_needs_indexing_new(store):
    assert store.file_needs_indexing("nonexistent.py", 1.0, 100)


def test_file_needs_indexing_unchanged(store):
    chunks = [{"start_line": 1, "end_line": 5, "text": "x"}]
    embs = _rand_emb(1)
    store.upsert_file("a.py", 1.0, 50, chunks, embs)
    assert not store.file_needs_indexing("a.py", 1.0, 50)


def test_file_needs_indexing_changed_mtime(store):
    chunks = [{"start_line": 1, "end_line": 5, "text": "x"}]
    embs = _rand_emb(1)
    store.upsert_file("a.py", 1.0, 50, chunks, embs)
    assert store.file_needs_indexing("a.py", 2.0, 50)


def test_file_needs_indexing_changed_size(store):
    chunks = [{"start_line": 1, "end_line": 5, "text": "x"}]
    embs = _rand_emb(1)
    store.upsert_file("a.py", 1.0, 50, chunks, embs)
    assert store.file_needs_indexing("a.py", 1.0, 999)


def test_upsert_replaces_existing(store):
    chunks1 = [{"start_line": 1, "end_line": 5, "text": "old"}]
    chunks2 = [
        {"start_line": 1, "end_line": 5, "text": "new chunk 1"},
        {"start_line": 4, "end_line": 10, "text": "new chunk 2"},
    ]
    embs1 = _rand_emb(1)
    embs2 = _rand_emb(2)
    store.upsert_file("a.py", 1.0, 50, chunks1, embs1)
    store.upsert_file("a.py", 2.0, 60, chunks2, embs2)
    s = store.stats()
    assert s["files"] == 1
    assert s["chunks"] == 2


def test_search_returns_results(store):
    chunks = [{"start_line": 1, "end_line": 10, "text": "hello world python"}]
    embs = _rand_emb(1)
    store.upsert_file("test.py", 1.0, 100, chunks, embs)
    query = _rand_emb(1)[0]
    results = store.search(query, top_k=5)
    assert len(results) == 1
    assert results[0]["path"] == "test.py"
    assert "distance" in results[0]


def test_search_empty_index(store):
    query = _rand_emb(1)[0]
    results = store.search(query, top_k=5)
    assert results == []


def test_search_top_k(store):
    for i in range(10):
        chunks = [{"start_line": 1, "end_line": 5, "text": f"file {i} content"}]
        embs = _rand_emb(1)
        store.upsert_file(f"file{i}.py", float(i), i * 10, chunks, embs)
    query = _rand_emb(1)[0]
    results = store.search(query, top_k=3)
    assert len(results) == 3


def test_clear(store):
    chunks = [{"start_line": 1, "end_line": 5, "text": "data"}]
    embs = _rand_emb(1)
    store.upsert_file("a.py", 1.0, 100, chunks, embs)
    store.clear()
    s = store.stats()
    assert s["files"] == 0
    assert s["chunks"] == 0


def test_search_results_have_required_fields(store):
    chunks = [{"start_line": 1, "end_line": 10, "text": "sample code"}]
    embs = _rand_emb(1)
    store.upsert_file("sample.py", 1.0, 200, chunks, embs)
    query = _rand_emb(1)[0]
    results = store.search(query, top_k=1)
    assert len(results) == 1
    r = results[0]
    for field in ("path", "start_line", "end_line", "text", "distance", "chunk_id"):
        assert field in r, f"Missing field: {field}"
