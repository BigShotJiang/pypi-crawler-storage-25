"""Allow running the server as ``python -m smartsheet_mcp``."""

from __future__ import annotations

from .server import main

if __name__ == "__main__":
    main()
