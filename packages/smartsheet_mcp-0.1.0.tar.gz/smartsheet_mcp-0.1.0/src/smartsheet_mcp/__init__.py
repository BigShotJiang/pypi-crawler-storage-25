"""Smartsheet MCP server (read-only MVP)."""

__version__ = "0.1.0"
