from abc import ABC, abstractmethod
from typing import List

from .rules.procedure_rules import (ProcedureConnectionRequiredRule,
                                    ProcedureExamplesRule,
                                    ProcedureIsMutationRule, ProcedureRule)
from .rules.search_hint_order_rule import SearchHintOrderRule


class ProcedureRuleFactory(ABC):
    @abstractmethod
    def get_rules(self) -> List[ProcedureRule]:
        pass


class DefaultProcedureRuleFactory(ProcedureRuleFactory):
    def get_rules(self) -> List[ProcedureRule]:
        return [ProcedureExamplesRule(), ProcedureConnectionRequiredRule(), ProcedureIsMutationRule(), SearchHintOrderRule()]
