from astroid import FunctionDef
from astroid.exceptions import InferenceError, NameInferenceError
from pylint.lint import PyLinter

from kognitos.bdk.reflection import BookProcedureDescriptor

from .procedure_rules import ProcedureRule

PROCEDURE_QNAME = "kognitos.bdk.decorators.procedure_decorator.procedure"
SEARCH_HINT_QNAME = "kognitos.bdk.decorators.search_hint_decorator.search_hint"


def _get_decorator_index(node: FunctionDef, qname: str) -> int | None:
    """Return the first index of a decorator matching *qname*, or ``None``."""
    if not node.decorators:
        return None
    for idx, decorator in enumerate(node.decorators.nodes):
        try:
            func = next(decorator.func.infer()) if hasattr(decorator, "func") else next(decorator.infer())
            if func.qname() == qname:
                return idx
        except (NameInferenceError, InferenceError):
            continue
    return None


class SearchHintOrderRule(ProcedureRule):
    """Ensure ``@procedure`` appears above ``@search_hint`` in the decorator stack.

    Python applies decorators bottom-up (closest to the function definition
    first).  ``@search_hint`` must execute *before* ``@procedure`` so that the
    hints are already stored when ``@procedure`` reads them.  In source code
    this means ``@procedure`` must be listed *above* ``@search_hint``.
    """

    def check_rule(
        self,
        linter: PyLinter,
        book_procedure: BookProcedureDescriptor,
        node: FunctionDef,
    ) -> None:
        procedure_idx = _get_decorator_index(node, PROCEDURE_QNAME)
        if procedure_idx is None:
            return

        # Check every @search_hint on this function
        if not node.decorators:
            return

        for idx, decorator in enumerate(node.decorators.nodes):
            try:
                func = next(decorator.func.infer()) if hasattr(decorator, "func") else next(decorator.infer())
            except (NameInferenceError, InferenceError):
                continue

            if func.qname() != SEARCH_HINT_QNAME:
                continue

            # In the AST list, lower index == higher in source.
            # @procedure must be at a *lower* index than @search_hint.
            if idx < procedure_idx:
                linter.add_message(
                    "search-hint-before-procedure",
                    args=node.repr_name(),
                    node=decorator,
                )
