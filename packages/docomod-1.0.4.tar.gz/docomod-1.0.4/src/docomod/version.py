"""
Version information for docomod.
This is the single source of truth for version numbers.
"""

__version__ = "1.0.4"
