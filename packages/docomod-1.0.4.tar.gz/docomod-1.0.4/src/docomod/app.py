"""
docomod - Docx Comment Editor
"""

import sys
import os
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                               QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem,
                               QHeaderView, QLabel, QLineEdit, QTextEdit, QFileDialog,
                               QMessageBox, QSplitter, QGroupBox, QFormLayout, QComboBox)
from PySide6.QtCore import Qt
try:
    from docx import Document
    from docx.oxml.ns import qn
except ImportError:
    print("Please install python-docx: pip install python-docx")
    sys.exit(1)


TRANSLATIONS = {
    'zh': {
        'title': "docomod - Docx 批注编辑器",
        'open_file': "打开文件 (.docx)",
        'save_file': "保存文件",
        'table_headers': ["ID", "批注人", "缩写", "内容"],
        'edit_group': "编辑批注",
        'edit_group_batch': "批量编辑批注 (已选中 {} 条)",
        'label_author': "批注人:",
        'label_initials': "缩写:",
        'label_content': "内容:",
        'apply_changes': "应用修改",
        'msg_success_load': "文件加载成功！",
        'msg_error_load': "无法加载文件: {}",
        'msg_updated': "批注已在内存中更新，请记得保存文件！",
        'msg_batch_updated': "已更新 {} 条批注，请记得保存文件！",
        'msg_success_save': "文件已保存至: {}",
        'msg_error_save': "保存失败: {}",
        'dialog_open_title': "选择Word文件",
        'dialog_save_title': "保存文件",
        'msg_title_success': "成功",
        'msg_title_error': "错误",
        'msg_title_updated': "已更新",
        'batch_mode_hint': "批量模式: 内容不可编辑"
    },
    'en': {
        'title': "docomod - Docx Comment Editor",
        'open_file': "Open File (.docx)",
        'save_file': "Save File",
        'table_headers': ["ID", "Author", "Initials", "Content"],
        'edit_group': "Edit Comment",
        'edit_group_batch': "Batch Edit Comments ({} selected)",
        'label_author': "Author:",
        'label_initials': "Initials:",
        'label_content': "Content:",
        'apply_changes': "Apply Changes",
        'msg_success_load': "File loaded successfully!",
        'msg_error_load': "Cannot load file: {}",
        'msg_updated': "Comment updated in memory. Remember to save!",
        'msg_batch_updated': "{} comments updated. Remember to save!",
        'msg_success_save': "File saved to: {}",
        'msg_error_save': "Save failed: {}",
        'dialog_open_title': "Select Word File",
        'dialog_save_title': "Save File",
        'msg_title_success': "Success",
        'msg_title_error': "Error",
        'msg_title_updated': "Updated",
        'batch_mode_hint': "Batch mode: Content not editable"
    },
    'ja': {
        'title': "docomod - Docx コメントエディタ",
        'open_file': "ファイルを開く (.docx)",
        'save_file': "保存",
        'table_headers': ["ID", "作成者", "頭文字", "内容"],
        'edit_group': "コメントを編集",
        'edit_group_batch': "一括編集 ({} 件選択)",
        'label_author': "作成者:",
        'label_initials': "頭文字:",
        'label_content': "内容:",
        'apply_changes': "変更を適用",
        'msg_success_load': "ファイルの読み込みに成功しました！",
        'msg_error_load': "ファイルを読み込めません: {}",
        'msg_updated': "コメントが更新されました。保存を忘れないでください！",
        'msg_batch_updated': "{} 件のコメントを更新しました。保存を忘れないでください！",
        'msg_success_save': "ファイルが保存されました: {}",
        'msg_error_save': "保存に失敗しました: {}",
        'dialog_open_title': "Wordファイルを選択",
        'dialog_save_title': "ファイルを保存",
        'msg_title_success': "成功",
        'msg_title_error': "エラー",
        'msg_title_updated': "更新済み",
        'batch_mode_hint': "一括モード: 内容は編集できません"
    },
    'fr': {
        'title': "docomod - Éditeur de commentaires Docx",
        'open_file': "Ouvrir (.docx)",
        'save_file': "Enregistrer",
        'table_headers': ["ID", "Auteur", "Initiales", "Contenu"],
        'edit_group': "Modifier le commentaire",
        'edit_group_batch': "Modification en lot ({} sélectionnés)",
        'label_author': "Auteur:",
        'label_initials': "Initiales:",
        'label_content': "Contenu:",
        'apply_changes': "Appliquer",
        'msg_success_load': "Fichier chargé avec succès !",
        'msg_error_load': "Impossible de charger le fichier : {}",
        'msg_updated': "Commentaire mis à jour. N'oubliez pas d'enregistrer !",
        'msg_batch_updated': "{} commentaires mis à jour. N'oubliez pas d'enregistrer !",
        'msg_success_save': "Fichier enregistré sous : {}",
        'msg_error_save': "Échec de l'enregistrement : {}",
        'dialog_open_title': "Sélectionner un fichier Word",
        'dialog_save_title': "Enregistrer le fichier",
        'msg_title_success': "Succès",
        'msg_title_error': "Erreur",
        'msg_title_updated': "Mis à jour",
        'batch_mode_hint': "Mode lot: Contenu non modifiable"
    },
    'ru': {
        'title': "docomod - Редактор комментариев Docx",
        'open_file': "Открыть (.docx)",
        'save_file': "Сохранить",
        'table_headers': ["ID", "Автор", "Инициалы", "Содержание"],
        'edit_group': "Редактировать",
        'edit_group_batch': "Пакетное редактирование ({} выбрано)",
        'label_author': "Автор:",
        'label_initials': "Инициалы:",
        'label_content': "Содержание:",
        'apply_changes': "Применить",
        'msg_success_load': "Файл успешно загружен!",
        'msg_error_load': "Не удалось загрузить файл: {}",
        'msg_updated': "Комментарий обновлен. Не забудьте сохранить!",
        'msg_batch_updated': "{} комментариев обновлено. Не забудьте сохранить!",
        'msg_success_save': "Файл сохранен: {}",
        'msg_error_save': "Ошибка сохранения: {}",
        'dialog_open_title': "Выберите файл Word",
        'dialog_save_title': "Сохранить файл",
        'msg_title_success': "Успех",
        'msg_title_error': "Ошибка",
        'msg_title_updated': "Обновлено",
        'batch_mode_hint': "Пакетный режим: Содержание не редактируется"
    },
    'de': {
        'title': "docomod - Docx Kommentar-Editor",
        'open_file': "Öffnen (.docx)",
        'save_file': "Speichern",
        'table_headers': ["ID", "Autor", "Initialen", "Inhalt"],
        'edit_group': "Kommentar bearbeiten",
        'edit_group_batch': "Stapelbearbeitung ({} ausgewählt)",
        'label_author': "Autor:",
        'label_initials': "Initialen:",
        'label_content': "Inhalt:",
        'apply_changes': "Übernehmen",
        'msg_success_load': "Datei erfolgreich geladen!",
        'msg_error_load': "Datei konnte nicht geladen werden: {}",
        'msg_updated': "Kommentar aktualisiert. Bitte speichern!",
        'msg_batch_updated': "{} Kommentare aktualisiert. Bitte speichern!",
        'msg_success_save': "Datei gespeichert unter: {}",
        'msg_error_save': "Speichern fehlgeschlagen: {}",
        'dialog_open_title': "Word-Datei auswählen",
        'dialog_save_title': "Datei speichern",
        'msg_title_success': "Erfolg",
        'msg_title_error': "Fehler",
        'msg_title_updated': "Aktualisiert",
        'batch_mode_hint': "Stapelmodus: Inhalt nicht bearbeitbar"
    },
    'it': {
        'title': "docomod - Editor Commenti Docx",
        'open_file': "Apri (.docx)",
        'save_file': "Salva",
        'table_headers': ["ID", "Autore", "Iniziali", "Contenuto"],
        'edit_group': "Modifica commento",
        'edit_group_batch': "Modifica batch ({} selezionati)",
        'label_author': "Autore:",
        'label_initials': "Iniziali:",
        'label_content': "Contenuto:",
        'apply_changes': "Applica",
        'msg_success_load': "File caricato con successo!",
        'msg_error_load': "Impossibile caricare il file: {}",
        'msg_updated': "Commento aggiornato. Ricorda di salvare!",
        'msg_batch_updated': "{} commenti aggiornati. Ricorda di salvare!",
        'msg_success_save': "File salvato in: {}",
        'msg_error_save': "Salvataggio fallito: {}",
        'dialog_open_title': "Seleziona file Word",
        'dialog_save_title': "Salva file",
        'msg_title_success': "Successo",
        'msg_title_error': "Errore",
        'msg_title_updated': "Aggiornato",
        'batch_mode_hint': "Modalità batch: Contenuto non modificabile"
    },
    'es': {
        'title': "docomod - Editor de Comentarios Docx",
        'open_file': "Abrir (.docx)",
        'save_file': "Guardar",
        'table_headers': ["ID", "Autor", "Iniciales", "Contenido"],
        'edit_group': "Editar comentario",
        'edit_group_batch': "Edición por lotes ({} seleccionados)",
        'label_author': "Autor:",
        'label_initials': "Iniciales:",
        'label_content': "Contenido:",
        'apply_changes': "Aplicar",
        'msg_success_load': "¡Archivo cargado con éxito!",
        'msg_error_load': "No se puede cargar el archivo: {}",
        'msg_updated': "Comentario actualizado. ¡Recuerde guardar!",
        'msg_batch_updated': "{} comentarios actualizados. ¡Recuerde guardar!",
        'msg_success_save': "Archivo guardado en: {}",
        'msg_error_save': "Error al guardar: {}",
        'dialog_open_title': "Seleccionar archivo Word",
        'dialog_save_title': "Guardar archivo",
        'msg_title_success': "Éxito",
        'msg_title_error': "Error",
        'msg_title_updated': "Actualizado",
        'batch_mode_hint': "Modo por lotes: Contenido no editable"
    },
    'pt': {
        'title': "docomod - Editor de Comentários Docx",
        'open_file': "Abrir (.docx)",
        'save_file': "Salvar",
        'table_headers': ["ID", "Autor", "Iniciais", "Conteúdo"],
        'edit_group': "Editar comentário",
        'edit_group_batch': "Edição em lote ({} selecionados)",
        'label_author': "Autor:",
        'label_initials': "Iniciais:",
        'label_content': "Conteúdo:",
        'apply_changes': "Aplicar",
        'msg_success_load': "Arquivo carregado com sucesso!",
        'msg_error_load': "Não foi possível carregar o arquivo: {}",
        'msg_updated': "Comentário atualizado. Lembre-se de salvar!",
        'msg_batch_updated': "{} comentários atualizados. Lembre-se de salvar!",
        'msg_success_save': "Arquivo salvo em: {}",
        'msg_error_save': "Falha ao salvar: {}",
        'dialog_open_title': "Selecionar arquivo Word",
        'dialog_save_title': "Salvar arquivo",
        'msg_title_success': "Sucesso",
        'msg_title_error': "Erro",
        'msg_title_updated': "Atualizado",
        'batch_mode_hint': "Modo em lote: Conteúdo não editável"
    },
    'ko': {
        'title': "docomod - Docx 댓글 편집기",
        'open_file': "열기 (.docx)",
        'save_file': "저장",
        'table_headers': ["ID", "작성자", "이니셜", "내용"],
        'edit_group': "댓글 편집",
        'edit_group_batch': "일괄 편집 ({}개 선택됨)",
        'label_author': "작성자:",
        'label_initials': "이니셜:",
        'label_content': "내용:",
        'apply_changes': "변경 사항 적용",
        'msg_success_load': "파일이 성공적으로 로드되었습니다!",
        'msg_error_load': "파일을 로드할 수 없습니다: {}",
        'msg_updated': "댓글이 업데이트되었습니다. 저장하는 것을 잊지 마세요!",
        'msg_batch_updated': "{}개의 댓글이 업데이트되었습니다. 저장하는 것을 잊지 마세요!",
        'msg_success_save': "파일 저장 위치: {}",
        'msg_error_save': "저장 실패: {}",
        'dialog_open_title': "Word 파일 선택",
        'dialog_save_title': "파일 저장",
        'msg_title_success': "성공",
        'msg_title_error': "오류",
        'msg_title_updated': "업데이트됨",
        'batch_mode_hint': "일괄 모드: 내용 편집 불가"
    }
}


class docomodApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.current_lang = 'zh'
        self.resize(1000, 700)

        self.doc = None
        self.current_file_path = None
        self.comments_data = []
        self.batch_mode = False

        self.setup_ui()
        self.retranslate_ui()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        toolbar_layout = QHBoxLayout()

        self.combo_lang = QComboBox()
        self.combo_lang.addItems([
            "中文 (Chinese)", "English", "日本語 (Japanese)", "Français (French)",
            "Русский (Russian)", "Deutsch (German)", "Italiano (Italian)",
            "Español (Spanish)", "Português (Portuguese)", "한국어 (Korean)"
        ])
        self.combo_lang.currentIndexChanged.connect(self.change_language)
        toolbar_layout.addWidget(self.combo_lang)

        self.btn_open = QPushButton()
        self.btn_open.clicked.connect(self.open_file)
        self.btn_save = QPushButton()
        self.btn_save.clicked.connect(self.save_file)
        self.btn_save.setEnabled(False)

        toolbar_layout.addWidget(self.btn_open)
        toolbar_layout.addWidget(self.btn_save)
        toolbar_layout.addStretch()
        main_layout.addLayout(toolbar_layout)

        splitter = QSplitter(Qt.Vertical)
        main_layout.addWidget(splitter)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.table.itemSelectionChanged.connect(self.load_selected_comment)
        splitter.addWidget(self.table)

        self.edit_group = QGroupBox()
        edit_layout = QVBoxLayout(self.edit_group)

        self.form_layout = QFormLayout()
        self.edit_author = QLineEdit()
        self.edit_initials = QLineEdit()
        self.edit_content = QTextEdit()
        self.edit_content.setMaximumHeight(100)

        self.label_author = QLabel()
        self.label_initials = QLabel()
        self.label_content = QLabel()
        self.label_batch_hint = QLabel()
        self.label_batch_hint.setStyleSheet("color: gray; font-style: italic;")

        self.form_layout.addRow(self.label_author, self.edit_author)
        self.form_layout.addRow(self.label_initials, self.edit_initials)
        self.form_layout.addRow(self.label_content, self.edit_content)
        self.form_layout.addRow(self.label_batch_hint)

        edit_layout.addLayout(self.form_layout)

        btn_layout = QHBoxLayout()
        self.btn_apply = QPushButton()
        self.btn_apply.clicked.connect(self.apply_changes)
        self.btn_apply.setEnabled(False)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_apply)

        edit_layout.addLayout(btn_layout)

        edit_container = QWidget()
        edit_container_layout = QVBoxLayout(edit_container)
        edit_container_layout.addWidget(self.edit_group)
        edit_container_layout.setContentsMargins(0, 0, 0, 0)

        splitter.addWidget(edit_container)
        splitter.setSizes([400, 200])

    def change_language(self, index):
        lang_codes = ['zh', 'en', 'ja', 'fr', 'ru', 'de', 'it', 'es', 'pt', 'ko']
        if 0 <= index < len(lang_codes):
            self.current_lang = lang_codes[index]
            self.retranslate_ui()

    def retranslate_ui(self):
        texts = TRANSLATIONS[self.current_lang]

        if self.current_file_path:
            self.setWindowTitle(f"{texts['title']} - {os.path.basename(self.current_file_path)}")
        else:
            self.setWindowTitle(texts['title'])

        self.btn_open.setText(texts['open_file'])
        self.btn_save.setText(texts['save_file'])
        self.btn_apply.setText(texts['apply_changes'])

        self.table.setHorizontalHeaderLabels(texts['table_headers'])

        self.update_edit_group_title()

        self.label_author.setText(texts['label_author'])
        self.label_initials.setText(texts['label_initials'])
        self.label_content.setText(texts['label_content'])
        
        if self.batch_mode:
            self.label_batch_hint.setText(texts['batch_mode_hint'])
        else:
            self.label_batch_hint.setText("")

    def update_edit_group_title(self):
        texts = TRANSLATIONS[self.current_lang]
        selected_count = len(self.table.selectionModel().selectedRows())
        if selected_count > 1:
            self.edit_group.setTitle(texts['edit_group_batch'].format(selected_count))
        else:
            self.edit_group.setTitle(texts['edit_group'])

    def open_file(self):
        texts = TRANSLATIONS[self.current_lang]
        file_path, _ = QFileDialog.getOpenFileName(self, texts['dialog_open_title'], "", "Word Documents (*.docx)")
        if file_path:
            try:
                self.load_docx(file_path)
                self.current_file_path = file_path
                self.btn_save.setEnabled(True)
                self.setWindowTitle(f"{texts['title']} - {os.path.basename(file_path)}")
                QMessageBox.information(self, texts['msg_title_success'], texts['msg_success_load'])
            except Exception as e:
                QMessageBox.critical(self, texts['msg_title_error'], texts['msg_error_load'].format(str(e)))

    def load_docx(self, path):
        self.doc = Document(path)
        self.comments_data = []

        try:
            comments_part = self.doc.part.rels.part_with_reltype("http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments")
            comments_xml = comments_part.element
        except KeyError:
            self.refresh_table()
            return

        for comment in comments_xml.xpath('//w:comment'):
            c_id = comment.get(qn('w:id'))
            author = comment.get(qn('w:author')) or ""
            initials = comment.get(qn('w:initials')) or ""

            text_content = ""
            texts = comment.xpath('.//w:t')
            text_content = "".join([t.text for t in texts if t.text])

            self.comments_data.append({
                'id': c_id,
                'author': author,
                'initials': initials,
                'text': text_content,
                'element': comment
            })

        self.refresh_table()

    def refresh_table(self):
        self.table.setRowCount(0)
        self.table.setRowCount(len(self.comments_data))

        for row, data in enumerate(self.comments_data):
            self.table.setItem(row, 0, QTableWidgetItem(str(data['id'])))
            self.table.setItem(row, 1, QTableWidgetItem(data['author']))
            self.table.setItem(row, 2, QTableWidgetItem(data['initials']))
            self.table.setItem(row, 3, QTableWidgetItem(data['text']))

    def load_selected_comment(self):
        selected_rows = self.table.selectionModel().selectedRows()
        texts = TRANSLATIONS[self.current_lang]
        
        if not selected_rows:
            self.btn_apply.setEnabled(False)
            self.batch_mode = False
            self.edit_author.clear()
            self.edit_initials.clear()
            self.edit_content.clear()
            self.edit_content.setEnabled(True)
            self.label_batch_hint.setText("")
            self.update_edit_group_title()
            return

        if len(selected_rows) == 1:
            self.batch_mode = False
            row = selected_rows[0].row()
            data = self.comments_data[row]
            self.edit_author.setText(data['author'])
            self.edit_initials.setText(data['initials'])
            self.edit_content.setText(data['text'])
            self.edit_content.setEnabled(True)
            self.label_batch_hint.setText("")
        else:
            self.batch_mode = True
            first_row = selected_rows[0].row()
            first_data = self.comments_data[first_row]
            self.edit_author.setText(first_data['author'])
            self.edit_initials.setText(first_data['initials'])
            self.edit_content.setText("")
            self.edit_content.setEnabled(False)
            self.label_batch_hint.setText(texts['batch_mode_hint'])

        self.btn_apply.setEnabled(True)
        self.update_edit_group_title()

    def apply_changes(self):
        texts = TRANSLATIONS[self.current_lang]
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        new_author = self.edit_author.text()
        new_initials = self.edit_initials.text()

        if self.batch_mode:
            updated_count = 0
            for index in selected_rows:
                row = index.row()
                data = self.comments_data[row]
                comment_element = data['element']

                comment_element.set(qn('w:author'), new_author)
                comment_element.set(qn('w:initials'), new_initials)

                data['author'] = new_author
                data['initials'] = new_initials

                self.table.item(row, 1).setText(new_author)
                self.table.item(row, 2).setText(new_initials)
                updated_count += 1

            QMessageBox.information(self, texts['msg_title_updated'], texts['msg_batch_updated'].format(updated_count))
        else:
            row = selected_rows[0].row()
            data = self.comments_data[row]
            new_text = self.edit_content.toPlainText()

            comment_element = data['element']

            comment_element.set(qn('w:author'), new_author)
            comment_element.set(qn('w:initials'), new_initials)

            text_elements = comment_element.xpath('.//w:t')
            if text_elements:
                for i, t in enumerate(text_elements):
                    if i == 0:
                        t.text = new_text
                    else:
                        t.text = ""

            data['author'] = new_author
            data['initials'] = new_initials
            data['text'] = new_text

            self.table.item(row, 1).setText(new_author)
            self.table.item(row, 2).setText(new_initials)
            self.table.item(row, 3).setText(new_text)

            QMessageBox.information(self, texts['msg_title_updated'], texts['msg_updated'])

    def save_file(self):
        texts = TRANSLATIONS[self.current_lang]
        if not self.doc:
            return

        file_path, _ = QFileDialog.getSaveFileName(self, texts['dialog_save_title'], self.current_file_path, "Word Documents (*.docx)")
        if file_path:
            try:
                self.doc.save(file_path)
                QMessageBox.information(self, texts['msg_title_success'], texts['msg_success_save'].format(file_path))
            except Exception as e:
                QMessageBox.critical(self, texts['msg_title_error'], texts['msg_error_save'].format(str(e)))


def main():
    app = QApplication(sys.argv)
    window = docomodApp()
    window.show()
    sys.exit(app.exec())