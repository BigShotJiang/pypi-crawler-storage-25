"""
docomod - Advanced Docx Comment Editor

A lightweight, open-source solution for precise management of Docx comment metadata.
"""

from docomod.version import __version__
from docomod.app import docomodApp

__author__ = "EasyCam"
__license__ = "GPL-3.0"
__url__ = "https://github.com/easycam/docomod"

__all__ = ["docomodApp", "__version__"]
