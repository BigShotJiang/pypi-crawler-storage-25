"""Data loader implementations."""
