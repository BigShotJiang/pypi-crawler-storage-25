# Base module tests
