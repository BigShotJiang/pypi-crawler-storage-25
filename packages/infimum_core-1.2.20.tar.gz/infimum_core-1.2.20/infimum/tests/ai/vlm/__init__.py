"""Tests for VLM providers."""
