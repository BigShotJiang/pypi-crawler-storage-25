﻿// Copyright 2024-2026 Alişah Özcan
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0
// Developer: Alişah Özcan

#ifndef HEONGPU_DEFAULT_MODULUS_H
#define HEONGPU_DEFAULT_MODULUS_H

#include "gpuntt/common/common.cuh"
#include "gpuntt/common/nttparameters.cuh"
#include <unordered_map>
#include <vector>

namespace heongpu
{
    /*
    The default modulus for different poly_modulus_degree values was determined
    based on security estimates from the lattice-estimator tool, with parameters
    selected to align with the desired security level.
    lattice-estimator: https://github.com/malb/lattice-estimator
    Reference: https://eprint.iacr.org/2015/046
    */
    namespace defaultparams
    {

        const std::unordered_map<std::size_t, std::vector<Modulus64>>&
        get_128bit_sec_modulus();

        const std::unordered_map<std::size_t, std::vector<Modulus64>>&
        get_192bit_sec_modulus();

        const std::unordered_map<std::size_t, std::vector<Modulus64>>&
        get_256bit_sec_modulus();

    } // namespace defaultparams
} // namespace heongpu
#endif // HEONGPU_DEFAULT_MODULUS_H
