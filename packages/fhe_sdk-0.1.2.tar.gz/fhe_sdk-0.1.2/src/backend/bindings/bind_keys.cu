#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <heongpu/heongpu.hpp>

namespace py = pybind11;
using namespace heongpu;

using CKKSContext = HEContext<Scheme::CKKS>;
using CKKSSecretkey  = Secretkey<Scheme::CKKS>;
using CKKSPublickey  = Publickey<Scheme::CKKS>;
using CKKSRelinkey   = Relinkey<Scheme::CKKS>;
using CKKSGaloiskey  = Galoiskey<Scheme::CKKS>;
using CKKSKeygen     = HEKeyGenerator<Scheme::CKKS>;

void register_keys(py::module_& m)
{
    py::class_<CKKSSecretkey>(m, "CKKSSecretkey",
        "CKKS secret key. Construct with the context, then fill via "
        "CKKSKeyGenerator.generate_secret_key(sk).")
        .def(py::init([](CKKSContext& ctx) { return CKKSSecretkey(ctx); }),
             py::arg("context"),
             "Allocate an empty secret key bound to the given context.");

    py::class_<CKKSPublickey>(m, "CKKSPublickey",
        "CKKS public key. Construct with the context, then fill via "
        "CKKSKeyGenerator.generate_public_key(pk, sk).")
        .def(py::init([](CKKSContext& ctx) { return CKKSPublickey(ctx); }),
             py::arg("context"),
             "Allocate an empty public key bound to the given context.");

    py::class_<CKKSRelinkey>(m, "CKKSRelinkey",
        "CKKS relinearization key. Required after every multiply_inplace().\n"
        "Construct with the context, then fill via "
        "CKKSKeyGenerator.generate_relin_key(rk, sk).")
        .def(py::init([](CKKSContext& ctx) { return CKKSRelinkey(ctx); }),
             py::arg("context"),
             "Allocate an empty relin key bound to the given context.");

    py::class_<CKKSGaloiskey>(m, "CKKSGaloiskey",
        "CKKS Galois (rotation) key.\n"
        "Three construction modes:\n"
        "  CKKSGaloiskey(ctx)             — powers-of-2 shifts up to MAX_SHIFT\n"
        "  CKKSGaloiskey(ctx, max_shift)  — all shifts in (-2^max_shift, 2^max_shift)\n"
        "  CKKSGaloiskey(ctx, [s0,s1,...]) — exact list of required shifts\n"
        "Fill via CKKSKeyGenerator.generate_galois_key(gk, sk).")

        .def(py::init([](CKKSContext& ctx) { return CKKSGaloiskey(ctx); }),
             py::arg("context"),
             "Galois key covering powers-of-2 rotation shifts up to MAX_SHIFT.")

        .def(py::init([](CKKSContext& ctx, int max_shift) {
                 return CKKSGaloiskey(ctx, max_shift);
             }),
             py::arg("context"), py::arg("max_shift"),
             "Galois key covering all rotations in (-2^max_shift, 2^max_shift).")

        .def(py::init(
                 [](CKKSContext& ctx, const std::vector<int>& shifts) {
                     std::vector<int> s = shifts;
                     return CKKSGaloiskey(ctx, s);
                 }),
             py::arg("context"), py::arg("shifts"),
             "Galois key for exactly the rotation steps in the given list.\n"
             "Use for bootstrapping: pass bootstrapping_key_indexs() as the shift list.");

    py::class_<CKKSKeygen>(m, "CKKSKeyGenerator",
        "Key generator for CKKS. Fills pre-allocated key objects from a secret key.")

        .def(py::init([](CKKSContext& ctx) { return new CKKSKeygen(ctx); }),
             py::arg("context"),
             "Construct a key generator for an already-generated context.")

        .def("generate_secret_key",
             [](CKKSKeygen& self, CKKSSecretkey& sk) {
                 self.generate_secret_key(sk);
             },
             py::arg("sk"),
             "Fill sk with a freshly sampled ternary secret key.")

        .def("generate_public_key",
             [](CKKSKeygen& self, CKKSPublickey& pk, CKKSSecretkey& sk) {
                 self.generate_public_key(pk, sk);
             },
             py::arg("pk"), py::arg("sk"),
             "Fill pk with the public key derived from sk.")

        .def("generate_relin_key",
             [](CKKSKeygen& self, CKKSRelinkey& rk, CKKSSecretkey& sk) {
                 self.generate_relin_key(rk, sk);
             },
             py::arg("rk"), py::arg("sk"),
             "Fill rk with the relinearization key derived from sk.\n"
             "The keyswitching method (I or II) is set at context generate() time.")

        .def("generate_galois_key",
             [](CKKSKeygen& self, CKKSGaloiskey& gk, CKKSSecretkey& sk,
                bool store_on_host) {
                 ExecutionOptions opts;
                 if (store_on_host)
                     opts.set_storage_type(storage_type::HOST);
                 self.generate_galois_key(gk, sk, opts);
             },
             py::arg("gk"), py::arg("sk"), py::arg("store_on_host") = false,
             "Fill gk with rotation keys for all shifts registered in gk.\n"
             "The shift set is fixed at Galoiskey construction time.\n"
             "store_on_host=True keeps the keys in CPU RAM and streams each one\n"
             "to the GPU per rotation — far less VRAM, slower per rotation.\n"
             "Needed to fit bootstrapping key material on small GPUs.");
}
