RESOLUTION = 480  # ticks per quarter note
