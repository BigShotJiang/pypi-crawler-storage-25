# convert music21.stream.Score to libresvip.model.base.Project
import music21
import music21.stream.base
import libresvip
import libresvip.model.base
from music21_svs_formats import util
import more_itertools
from types_linq import Enumerable

from typing import List, Tuple, Dict


class UnsupportedMusic21ObjectError(ValueError):
    pass


def mTimeDistinct(stream: music21.stream.base.Stream):
    """
    Remove duplicate time signatures or tempos that have the same offset.
    """
    todelete: List[music21.base.Music21Object] = []
    for prev, curr in more_itertools.pairwise(stream):
        if prev.getOffsetBySite(stream) == curr.getOffsetBySite(stream):
            todelete.append(curr)
    for obj in todelete:
        stream.remove(obj)


def dumpNote(
    mNote: music21.note.Note, mPart: music21.stream.base.Stream, isSlur: bool = False
) -> libresvip.model.base.Note:
    """
    Convert music21.note.Note to libresvip.model.base.Note
    """
    lNote = libresvip.model.base.Note()
    lNote.start_pos = round(mNote.getOffsetBySite(mPart) * util.RESOLUTION)
    endTick = round(
        (mNote.getOffsetBySite(mPart) + mNote.duration.quarterLength) * util.RESOLUTION
    )
    lNote.length = endTick - lNote.start_pos
    lNote.key_number = mNote.pitch.midi
    if mNote.lyrics:
        mLyric = mNote.lyrics[0]
        if mLyric.syllabic == "single" or mLyric.syllabic == "begin":
            lNote.lyric = mLyric.text
        else:
            lNote.lyric = "-" + mLyric.text
    elif isSlur:
        lNote.lyric = "-"
    return lNote


def dumpTrack(mPart: music21.stream.base.Stream) -> libresvip.model.base.SingingTrack:
    """
    Convert music21.stream.base.Part to libresvip.model.base.SingingTrack
    """
    lTrack = libresvip.model.base.SingingTrack()
    if hasattr(mPart, "partName") and mPart.partName:
        lTrack.title = mPart.partName
    mPart = mPart.flatten().stripTies()
    slurNotes = (
        Enumerable(mPart.getElementsByClass(music21.spanner.Slur))
        .where(lambda x: len(x.getSpannedElements()) > 1)
        .select_many(lambda x: x.getSpannedElements()[1:])
        .to_set()
    )
    for mGeneralNote in mPart.notesAndRests:
        if isinstance(mGeneralNote, music21.note.Note):
            isSlur = mGeneralNote in slurNotes
            lTrack.note_list.append(dumpNote(mGeneralNote, mPart, isSlur))
        elif isinstance(mGeneralNote, music21.chord.Chord):
            raise UnsupportedMusic21ObjectError("Chord is not supported by libresvip.")

    # Convert vocaloid-style multisyllabic lyric to SynthV-style multisyllabic lyric
    # example: `walk` `-ing` -> `walking` `+`
    if len(lTrack.note_list) > 1:
        wordStart = lTrack.note_list[0]
        for lNote in lTrack.note_list:
            if lNote.lyric == "-":
                continue
            elif lNote.lyric.startswith("-"):
                lNote.lyric = "+"
                wordStart.lyric = wordStart.lyric + lNote.lyric[1:]
            else:
                wordStart = lNote
    return lTrack


def dumpProject(mObject: music21.base.Music21Object) -> libresvip.model.base.Project:
    """
    Convert music21.stream.Score to libresvip.model.base.Project
    """
    if isinstance(mObject, music21.stream.base.Stream):
        mStream = mObject
    else:
        mStream = music21.stream.Stream()
        mStream.insert(0, mObject)
    lProject = libresvip.model.base.Project()
    if hasattr(mStream, "parts"):  # mStream is a Score
        lProject.track_list = [dumpTrack(mPart) for mPart in mStream.parts]
    else:
        lProject.track_list = [dumpTrack(mStream)]
    flattenedScore = mStream.flatten()
    mTempos: music21.stream.Stream[music21.tempo.MetronomeMark] = music21.stream.Stream(
        flattenedScore.getElementsByClass(music21.tempo.MetronomeMark)
    )
    mTimeDistinct(mTempos)
    lProject.song_tempo_list = (
        Enumerable(mTempos)
        .select(
            lambda x: libresvip.model.base.SongTempo(
                Position=round(x.getOffsetBySite(flattenedScore) * util.RESOLUTION),
                BPM=x.number,
            )
        )
        .to_list()
    )
    if not lProject.song_tempo_list:
        lProject.song_tempo_list.append(
            libresvip.model.base.SongTempo(Position=0, BPM=120)
        )
    lProject.time_signature_list = (
        Enumerable(
            enumerate(
                flattenedScore.makeMeasures().getElementsByClass(music21.stream.Measure)
            )
        )
        .where(lambda x: x[1].timeSignature)
        .select(
            lambda x: libresvip.model.base.TimeSignature(
                bar_index=x[0],
                numerator=x[1].timeSignature.numerator,
                denominator=x[1].timeSignature.denominator,
            )
        )
        .to_list()
    )
    if not lProject.time_signature_list:
        lProject.time_signature_list.append(
            libresvip.model.base.TimeSignature(bar_index=0, numerator=4, denominator=4)
        )

    return lProject
