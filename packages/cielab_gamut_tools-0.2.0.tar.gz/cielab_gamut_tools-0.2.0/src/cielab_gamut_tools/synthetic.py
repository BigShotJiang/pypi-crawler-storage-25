"""
Synthetic reference gamut generation.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from pathlib import Path


# Standard illuminant white points (CIE xy chromaticity)
D65_WHITE = np.array([0.31272, 0.32903])
D50_WHITE = np.array([0.34567, 0.35850])
DCI_WHITE = np.array([0.314, 0.351])
D60_WHITE = np.array([0.32168, 0.33767])

# Standard gamut primaries (CIE xy chromaticity)
SRGB_PRIMARIES = np.array([
    [0.6400, 0.3300],  # Red
    [0.3000, 0.6000],  # Green
    [0.1500, 0.0600],  # Blue
])

def srgb_gamma(gs: NDArray[np.floating]) -> NDArray[np.floating]:
    """
    Apply the sRGB piecewise gamma (linearise encoded sRGB values).

    Matches the MATLAB reference ``sRGBgamma(v)`` exactly::

        d = 25*v/323          for v <= 0.04045
        d = ((200*v+11)/211)^2.4  for v >  0.04045

    Args:
        gs: sRGB-encoded values as a numpy array, range [0, 1].

    Returns:
        Linear values as a numpy array, same shape as *gs*.
    """
    val = 25.0 * gs / 323.0
    sel = gs > 0.04045
    val[sel] = np.power(((200.0 * gs[sel] + 11.0) / 211.0), 2.4)
    return val

BT2020_PRIMARIES = np.array([
    [0.708, 0.292],   # Red
    [0.170, 0.797],   # Green
    [0.131, 0.046],   # Blue
])

DCI_P3_PRIMARIES = np.array([
    [0.680, 0.320],   # Red
    [0.265, 0.690],   # Green
    [0.150, 0.060],   # Blue
])

# Adobe RGB (1998) primaries — worked example in IEC 62906-6-1 Table B.1
ADOBE_RGB_PRIMARIES = np.array([
    [0.640, 0.330],   # Red
    [0.210, 0.710],   # Green
    [0.150, 0.060],   # Blue
])


class SyntheticGamut:
    """
    A synthetic reference gamut defined by primaries, white point, and gamma.

    Synthetic gamuts are computed mathematically rather than from measurements,
    making them useful as reference standards for coverage calculations.
    """

    def __init__(
        self,
        primaries_xy: NDArray[np.floating],
        white_xy: NDArray[np.floating],
        gamma: float | Callable[[NDArray[np.floating]], NDArray[np.floating]] = 2.2,
        title: str | None = None,
    ) -> None:
        """
        Create a synthetic gamut from primaries and white point.

        Args:
            primaries_xy: CIE xy chromaticity of RGB primaries, shape (3, 2).
            white_xy: CIE xy chromaticity of white point, shape (2,).
            gamma: Display gamma.  Either a plain float (e.g. ``2.4``) whose
                reciprocal is used as the power-law exponent, or a callable
                that maps an ``NDArray[np.floating]`` of encoded values to
                linear values (e.g. :func:`srgb_gamma` for the sRGB piecewise
                transfer function).  Defaults to ``2.2``.
            title: Human-readable gamut name shown in plot titles.
        """
        self.primaries_xy = np.asarray(primaries_xy)
        self.white_xy = np.asarray(white_xy)
        self.gamma = gamma
        self.title = title

        self._gamut: "Gamut | None" = None

    @classmethod
    def srgb(cls) -> SyntheticGamut:
        """Create an sRGB reference gamut (D65, gamma 2.2)."""
        return cls(SRGB_PRIMARIES, D65_WHITE, gamma = srgb_gamma, title="sRGB")

    @classmethod
    def bt2020(cls) -> SyntheticGamut:
        """Create a BT.2020 reference gamut (D65, gamma 2.4)."""
        return cls(BT2020_PRIMARIES, D65_WHITE, gamma=2.4, title="BT.2020")

    @classmethod
    def dci_p3(cls) -> SyntheticGamut:
        """Create a DCI-P3 reference gamut (DCI white, gamma 2.6)."""
        return cls(DCI_P3_PRIMARIES, DCI_WHITE, gamma=2.6, title="DCI-P3")

    @classmethod
    def display_p3(cls) -> SyntheticGamut:
        """Create a Display P3 reference gamut (D65 white, sRGB gamma)."""
        return cls(DCI_P3_PRIMARIES, D65_WHITE, gamma = srgb_gamma, title="Display P3")

    @classmethod
    def adobe_rgb(cls) -> SyntheticGamut:
        """Create an Adobe RGB (1998) reference gamut (D65 white, gamma 2.2).

        Primaries and white point match the worked example in IEC 62906-6-1
        Table B.1, which provides a 602-point CGATS reference dataset for this
        gamut.
        """
        return cls(ADOBE_RGB_PRIMARIES, D65_WHITE, gamma=2.2, title="Adobe RGB (1998)")

    def _build_gamut(self) -> "Gamut":
        """Build the underlying Gamut object."""
        from cielab_gamut_tools.gamut import Gamut
        from cielab_gamut_tools.colorspace.adaptation import adapt_d65_to_d50
        from cielab_gamut_tools.colorspace.lab import xyz_to_lab
        from cielab_gamut_tools.geometry.tesselation import make_tesselation

        # Generate RGB cube tesselation
        triangles, rgb_surface = make_tesselation()

        # Convert RGB to XYZ using primaries and white point (source colorspace)
        xyz_surface = self._rgb_to_xyz(rgb_surface)

        # Chromatic adaptation to D50
        xyz_d50 = adapt_d65_to_d50(xyz_surface, source_white=self.white_xy)

        # Convert to CIELab
        lab = xyz_to_lab(xyz_d50)

        # Store source-space XYZ alongside Lab for export and future analyses
        return Gamut(lab, triangles, rgb=rgb_surface, xyz=xyz_surface, title=self.title)

    def _rgb_to_xyz(self, rgb: NDArray[np.floating]) -> NDArray[np.floating]:
        """
        Convert RGB values to XYZ using this gamut's primaries and white point.

        Args:
            rgb: Linear RGB values, shape (N, 3), range [0, 1].

        Returns:
            XYZ tristimulus values, shape (N, 3).
        """
        # Apply gamma to get linear RGB
        if callable(self.gamma):
            rgb_linear = self.gamma(rgb)
        else:
            rgb_linear = np.power(rgb, self.gamma)

        # Build RGB to XYZ matrix from primaries and white point
        M = _build_rgb_to_xyz_matrix(self.primaries_xy, self.white_xy)

        # Transform
        return rgb_linear @ M.T

    @property
    def gamut(self) -> "Gamut":
        """Get the underlying Gamut object, building it if needed."""
        if self._gamut is None:
            self._gamut = self._build_gamut()
        return self._gamut

    def volume(self) -> float:
        """Calculate the gamut volume."""
        return self.gamut.volume()

    def compute_rings(self, l_steps: int = 100, h_steps: int = 360):
        """Compute C*_RSS ring radii. See ``Gamut.compute_rings()``."""
        return self.gamut.compute_rings(l_steps, h_steps)

    def intersect(self, other: "Gamut | SyntheticGamut") -> "Gamut":
        """Compute intersection with another gamut."""
        return self.gamut.intersect(other)

    def plot_surface(self, **kwargs) -> "Figure":
        """Create a 3D surface plot."""
        return self.gamut.plot_surface(**kwargs)

    def to_cgats(self, path: "str | Path", **kwargs) -> None:
        """Write gamut data to a CGATS.17 file. See ``Gamut.to_cgats()``."""
        return self.gamut.to_cgats(path, **kwargs)

    def plot_rings(
        self,
        reference=None,
        reference2=None,
        **kwargs,
    ) -> "Figure":
        """Create a 2D gamut rings plot. All kwargs forwarded to ``plot_rings()``."""
        return self.gamut.plot_rings(reference=reference, reference2=reference2, **kwargs)


def _build_rgb_to_xyz_matrix(
    primaries_xy: NDArray[np.floating],
    white_xy: NDArray[np.floating],
) -> NDArray[np.floating]:
    """
    Build the 3x3 RGB to XYZ transformation matrix.

    Args:
        primaries_xy: CIE xy of primaries, shape (3, 2).
        white_xy: CIE xy of white point, shape (2,).

    Returns:
        3x3 transformation matrix.
    """
    from cielab_gamut_tools.colorspace.lab import xy_to_XYZ

    # Convert primaries from xy to XYZ (Y=1)
    primaries_XYZ = np.array([xy_to_XYZ(xy) for xy in primaries_xy])

    # Convert white point from xy to XYZ (Y=1)
    white_XYZ = xy_to_XYZ(white_xy)

    # Solve for scaling factors S such that S * primaries_XYZ = white_XYZ
    # This ensures RGB=[1,1,1] maps to the white point
    S = np.linalg.solve(primaries_XYZ.T, white_XYZ)

    # Build final matrix: each column is a scaled primary
    M = primaries_XYZ.T * S

    return M
