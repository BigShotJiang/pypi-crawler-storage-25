#!/usr/bin/env bash
# Publish cogmeta-talon to PyPI
#
# Usage: ./publish.sh           (builds + publishes current version)
#        ./publish.sh 0.7.40    (set version, build, publish)
set -e

cd "$(dirname "$0")"

VERSION="${1:-$(python3 -c 'from src.talon import __version__; print(__version__)')}"
WHL="cogmeta_talon-${VERSION}-py3-none-any.whl"

# ── Sync version in both files ────────────────────────────────────────────────
sed -i "s/^version = .*/version = \"$VERSION\"/" pyproject.toml
sed -i "s/^__version__ = .*/__version__ = \"$VERSION\"/" src/talon/__init__.py
echo "Version set to $VERSION"

# ── Build ─────────────────────────────────────────────────────────────────────
python3 -m build -w
echo "Built dist/$WHL"

# ── Upload to PyPI ─────────────────────────────────────────────────────────────
TWINE_USERNAME=__token__ TWINE_PASSWORD="$(cat /ai/projects/cogz/usp/k/pypi.md | tail -1 | tr -d '[:space:]')" \
    twine upload "dist/$WHL"

echo ""
echo "Published cogmeta-talon $VERSION to PyPI"
echo "  Install: pipx install cogmeta-talon==$VERSION"
echo "  Upgrade: pipx upgrade cogmeta-talon"
