"""Slim client env-var registry.

Mirror of the backend `talon.config.env` module's API surface, but trimmed to
the keys the client wheel actually reads. Today that's just `TALON_CLOUD_URL`.
Future additions land here as the audit migrates more client callsites off
ad-hoc `os.environ.get(...)`.

The point is twofold:

1. **One canonical default per key.** The wheel previously had nine separate
   `os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")` lines, each a
   chance for the default to drift. One source of truth here.
2. **API parity with the backend registry.** Same enum, same getter names so
   a backend-migrated function moved to the client (or vice versa) needs no
   import rewrite.
"""
from __future__ import annotations

import os
from enum import Enum


class EnvVar(str, Enum):
    """Canonical env-var keys read by the client wheel."""

    CLOUD_URL = "TALON_CLOUD_URL"
    API_BASE = "TALON_API_BASE"


_DEFAULTS: dict[EnvVar, str | None] = {
    EnvVar.CLOUD_URL: "https://api.cogmeta.ai",
    EnvVar.API_BASE: "https://api.cogmeta.ai",
}


def _raw(var: EnvVar) -> str | None:
    val = os.environ.get(var.value)
    if val is not None:
        return val
    return _DEFAULTS.get(var)


def get(var: EnvVar, default: str | None = None) -> str | None:
    val = _raw(var)
    return val if val is not None else default


def get_required(var: EnvVar) -> str:
    val = _raw(var)
    if val is None:
        raise RuntimeError(
            f"Required env var {var.value} is unset and has no canonical default"
        )
    return val
