"""Per-component rotating file loggers under ~/.talon/logs/.

Each component gets one logger writing to <component>.log with rotation
(5 MB × 5 backups = 25 MB cap per component, ~125 MB worst-case across all).

Normal mode  → INFO and above
Debug mode   → DEBUG and above

Loggers are cached per-component; multiple setup() calls are safe.
"""
from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

from .state import is_debug

LOG_DIR = Path.home() / ".talon" / "logs"
_MAX_BYTES = 5 * 1024 * 1024  # 5 MB
_BACKUP_COUNT = 5
_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FORMAT = "%Y-%m-%dT%H:%M:%S"

_CACHE: dict[str, logging.Logger] = {}


def _ensure_log_dir() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_DIR


def setup(component: str, *, also_stderr: bool = False) -> logging.Logger:
    """Get or create a rotating logger for `component`.

    component: short slug, becomes filename (cli|proxy|hooks|indexer|telemetry)
    also_stderr: when True, additionally mirror WARNING+ to stderr (used by
                 long-running daemons where the operator may be watching stderr)

    Falls back to a stderr-only logger if the log dir cannot be created
    (e.g. read-only home dir) — never raises.
    """
    if component in _CACHE:
        return _CACHE[component]

    logger = logging.getLogger(f"talon.{component}")
    logger.setLevel(logging.DEBUG if is_debug() else logging.INFO)
    logger.propagate = False

    # Clear any handlers a prior import set up (idempotent)
    logger.handlers.clear()

    formatter = logging.Formatter(_FORMAT, datefmt=_DATE_FORMAT)

    file_handler: Optional[logging.Handler] = None
    try:
        _ensure_log_dir()
        log_path = LOG_DIR / f"{component}.log"
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=_MAX_BYTES,
            backupCount=_BACKUP_COUNT,
            encoding="utf-8",
            delay=True,  # don't open the file until first write
        )
        file_handler.setLevel(logging.DEBUG if is_debug() else logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError:
        # Read-only home, permissions, etc. — fall through to stderr-only.
        also_stderr = True

    if also_stderr:
        stream = logging.StreamHandler(sys.stderr)
        stream.setLevel(logging.WARNING if not is_debug() else logging.DEBUG)
        stream.setFormatter(formatter)
        logger.addHandler(stream)

    _CACHE[component] = logger
    return logger


def reset_cache() -> None:
    """Clear the logger cache. Used by tests or after debug-mode toggles."""
    for logger in _CACHE.values():
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)
    _CACHE.clear()


def log_path(component: str) -> Path:
    """Path to the active log file for a component (may not yet exist)."""
    return LOG_DIR / f"{component}.log"


def all_log_paths() -> list[Path]:
    """All log files currently on disk (current + rotated backups)."""
    if not LOG_DIR.exists():
        return []
    return sorted(LOG_DIR.glob("*.log*"))
