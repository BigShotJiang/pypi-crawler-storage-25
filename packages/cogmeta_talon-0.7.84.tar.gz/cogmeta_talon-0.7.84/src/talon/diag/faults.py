"""Fault catalog — single source of truth for client-side error classification.

Every recognized failure mode has a stable code (e.g. AUTH-001), a one-line
user message, a remediation hint, and a severity. classify(exc, ctx) maps an
exception (with optional context) to a Fault, or returns None for unrecognized
errors (which fall through to the generic "Error: {e}" path).

Codes are stable — never renumber. New codes append. Deprecated codes stay in
the catalog with `deprecated=True` so old log lines remain interpretable.

Categories:
    AUTH-*      authentication / credentials
    NET-*       network / connectivity / TLS
    IDX-*       indexer / cloud upload
    MCP-*       MCP protocol / proxy
    UPG-*       upgrade / install / rollback
    STATUS-*    health-check semantics
    CFG-*       on-disk config corruption
    LLM-*       LLM-side signals (rate limit, no response)
"""
from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass(frozen=True)
class Fault:
    code: str
    message: str       # one-line, terse, user-facing
    remediation: str   # actionable next step
    severity: str = "error"  # info | warn | error | fatal
    deprecated: bool = False


FAULT_CATALOG: dict[str, Fault] = {
    # --- Authentication ---
    "AUTH-001": Fault("AUTH-001", "API key rejected by cloud (401)", "Run: talon auth login"),
    "AUTH-002": Fault("AUTH-002", "Not logged in", "Run: talon login"),
    "AUTH-003": Fault("AUTH-003", "Login timed out", "Try again or check browser"),
    "AUTH-004": Fault("AUTH-004", "API key expired (>7d)", "Run: talon auth sync"),

    # --- Network ---
    "NET-001": Fault("NET-001", "Cannot reach Talon cloud", "Check connectivity then: talon health"),
    "NET-002": Fault("NET-002", "Connection dropped mid-request", "Retrying; persistent? talon health"),
    "NET-003": Fault("NET-003", "MCP proxy lost connection — giving up after retries",
                     "Run: talon health; restart Claude Code", "fatal"),
    "NET-004": Fault("NET-004", "TLS certificate error",
                     "Check system clock; corp proxy; SSL_CERT_FILE env"),

    # --- Indexer ---
    "IDX-001": Fault("IDX-001", "Index quality degraded — many parse failures",
                     "Run: talon-index --debug to see per-file failures", "warn"),
    "IDX-002": Fault("IDX-002", "Upload to cloud index failed",
                     "Retry; if persistent, contact support"),
    "IDX-003": Fault("IDX-003", "No supported source files found in tree",
                     "cd to project root containing .py/.ts/.go/etc."),
    "IDX-004": Fault("IDX-004", "Index upload timed out (>60s)",
                     "Project may exceed current cloud capacity; contact support"),

    # --- MCP / proxy ---
    "MCP-001": Fault("MCP-001", "MCP tool call no response (>30s)",
                     "Run: talon health; restart Claude Code"),
    "MCP-002": Fault("MCP-002", "MCP protocol error (malformed JSON-RPC)",
                     "Run: talon diag tail proxy"),

    # --- Upgrade ---
    "UPG-001": Fault("UPG-001", "Upgrade install timed out",
                     "Run: pipx install --force cogmeta-talon"),
    "UPG-002": Fault("UPG-002", "Upgrade AND rollback both failed",
                     "Run: pipx install cogmeta-talon==<previous-version>", "fatal"),

    # --- Health / status ---
    "STATUS-001": Fault("STATUS-001", "Cloud reachable but health endpoint unhealthy",
                        "Cloud-side issue; check status.cogmeta.ai", "warn"),

    # --- Config corruption ---
    "CFG-001": Fault("CFG-001", ".mcp.json corrupted or unreadable",
                     "Run: talon init --force"),
    "CFG-002": Fault("CFG-002", "credentials.json corrupted",
                     "Run: talon login (will rewrite)"),

    # --- LLM-side ---
    "LLM-001": Fault("LLM-001", "Anthropic rate limit hit",
                     "Wait and retry; check Anthropic console", "warn"),
    "LLM-002": Fault("LLM-002", "No LLM response after tool use",
                     "Possible context overflow; try /compact in Claude Code", "warn"),
}


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------

def classify(exc: BaseException, ctx: Optional[dict[str, Any]] = None) -> Optional[Fault]:
    """Map exception + context to a Fault. Return None if unrecognized.

    ctx may include any of:
        op           — short label for the operation ("login", "index_upload", ...)
        http_status  — int HTTP status code (for httpx/urllib failures)
        url          — request URL (used to disambiguate index vs auth, etc.)
        elapsed_s    — operation duration in seconds (for timeout classification)
        retries      — number of retries already attempted
    """
    ctx = ctx or {}
    name = type(exc).__name__
    msg = str(exc)
    lower = msg.lower()
    op = (ctx.get("op") or "").lower()
    url = (ctx.get("url") or "").lower()
    status = ctx.get("http_status")

    # --- HTTP status-code driven ---
    if isinstance(status, int):
        if status == 401:
            return FAULT_CATALOG["AUTH-001"]
        if status == 504 and ("index-data" in url or "index" in op):
            return FAULT_CATALOG["IDX-004"]
        if status >= 500 and "health" in url:
            return FAULT_CATALOG["STATUS-001"]
        if status == 429 and "anthropic" in url:
            return FAULT_CATALOG["LLM-001"]
        if status >= 400 and ("index-data" in url or "index" in op):
            return FAULT_CATALOG["IDX-002"]

    # --- TLS / SSL ---
    if "ssl" in name.lower() or "certificate" in lower or "ssl:" in lower:
        return FAULT_CATALOG["NET-004"]

    # --- Connection failures (most common path) ---
    if name in {"ConnectionRefusedError", "ConnectionError", "ConnectError",
                "ConnectTimeout", "ReadTimeout", "TimeoutError"} \
            or "name or service not known" in lower \
            or "could not resolve" in lower \
            or "connection refused" in lower \
            or "connection timed out" in lower:
        return FAULT_CATALOG["NET-001"]

    if name in {"RemoteDisconnected", "ProtocolError", "ConnectionResetError"} \
            or "connection reset" in lower \
            or "remote end closed" in lower:
        return FAULT_CATALOG["NET-002"]

    # --- Auth — credentials missing/corrupt ---
    if "credentials.json" in lower or op in {"auth_load", "credentials_load"}:
        if "no such file" in lower or "filenotfound" in name.lower():
            return FAULT_CATALOG["AUTH-002"]
        if "json" in lower or "decode" in lower:
            return FAULT_CATALOG["CFG-002"]

    if op == "login" and ("timeout" in lower or "timed out" in lower):
        return FAULT_CATALOG["AUTH-003"]

    # --- Config corruption ---
    if ".mcp.json" in lower:
        return FAULT_CATALOG["CFG-001"]

    # --- Indexer-specific ---
    if op == "index" and "no supported" in lower:
        return FAULT_CATALOG["IDX-003"]

    # --- Upgrade-specific ---
    if op == "upgrade" and ("timeout" in lower or "timed out" in lower):
        return FAULT_CATALOG["UPG-001"]
    if op == "upgrade_rollback":
        return FAULT_CATALOG["UPG-002"]

    # --- Proxy SSE retries exhausted ---
    if op == "proxy_sse" and ctx.get("retries_exhausted"):
        return FAULT_CATALOG["NET-003"]

    return None


# ---------------------------------------------------------------------------
# Emission — log + user-print
# ---------------------------------------------------------------------------

@dataclass
class EmitResult:
    fault: Fault
    log_path: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)


def emit(
    fault: Fault,
    details: Optional[dict[str, Any]] = None,
    logger: Optional[logging.Logger] = None,
    *,
    show_user: bool = True,
    log_path: Optional[str] = None,
) -> EmitResult:
    """Log the fault to `logger` and (if show_user) print the user-facing block to stderr.

    Returns an EmitResult so callers can attach the fault to a higher-level response
    (e.g. an MCP tool result) without re-deriving it.
    """
    details = details or {}
    if logger is not None:
        log_method = {
            "info": logger.info,
            "warn": logger.warning,
            "error": logger.error,
            "fatal": logger.critical,
        }.get(fault.severity, logger.error)
        log_method("[%s] %s | details=%s", fault.code, fault.message, details)

    if show_user:
        marker = {"info": "i", "warn": "!", "error": "✗", "fatal": "✗"}.get(fault.severity, "✗")
        sys.stderr.write(f"{marker} {fault.code}  {fault.message}\n")
        sys.stderr.write(f"  → {fault.remediation}\n")
        if log_path:
            sys.stderr.write(f"  Details: {log_path}\n")
        sys.stderr.flush()

    return EmitResult(fault=fault, log_path=log_path, extra=details)
