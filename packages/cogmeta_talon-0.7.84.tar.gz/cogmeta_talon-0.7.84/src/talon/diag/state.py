"""Resolve client debug-mode from --debug flag, env var, or config.yaml.

Precedence (highest first):
    1. Explicit override via set_debug_override(bool) — used by --debug CLI flag
    2. TALON_DEBUG env var (truthy = "1", "true", "yes", "on")
    3. ~/.talon/config.yaml: debug.enabled: true
    4. Default: False

Cached per-process after first resolution. Call set_debug_override() to bust.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

_TRUTHY = {"1", "true", "yes", "on"}
_OVERRIDE: Optional[bool] = None
_CACHED: Optional[bool] = None


def set_debug_override(value: Optional[bool]) -> None:
    """Force debug mode on/off for the rest of this process. Pass None to clear."""
    global _OVERRIDE, _CACHED
    _OVERRIDE = value
    _CACHED = None


def is_debug() -> bool:
    """Resolve debug mode. Cached after first call (until set_debug_override clears)."""
    global _CACHED
    if _OVERRIDE is not None:
        return _OVERRIDE
    if _CACHED is not None:
        return _CACHED

    env_val = os.environ.get("TALON_DEBUG", "").strip().lower()
    if env_val in _TRUTHY:
        _CACHED = True
        return True

    cfg_path = Path.home() / ".talon" / "config.yaml"
    if cfg_path.exists():
        try:
            import yaml  # type: ignore[import-untyped]

            data = yaml.safe_load(cfg_path.read_text()) or {}
            if isinstance(data, dict):
                debug_block = data.get("debug")
                if isinstance(debug_block, dict) and debug_block.get("enabled") is True:
                    _CACHED = True
                    return True
        except Exception:
            pass  # config corrupt — treat as not-debug

    _CACHED = False
    return False
