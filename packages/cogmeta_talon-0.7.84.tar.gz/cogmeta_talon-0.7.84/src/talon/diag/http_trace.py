"""HTTP request tracing — wraps httpx and urllib calls so every call lands
in the diag log with method/url/status/duration, plus full body in debug mode.

Always logged (normal mode):
    POST https://api.cogmeta.ai/talon/auth → 401 (123ms, 234B)

Debug mode adds:
    request headers (post-redaction)
    request body    (post-redaction, JSON-aware)
    response body   (post-redaction, JSON-aware)

Use the wrappers instead of raw httpx/urllib calls in any code that should
participate in diagnostics. Callers can opt out by passing trace=False.
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .faults import classify, emit
from .redact import redact, redact_json_text
from .state import is_debug

_MAX_BODY_LOG_BYTES = 16 * 1024  # cap any single body log at 16 KB


def _truncate(text: str, limit: int = _MAX_BODY_LOG_BYTES) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"…<truncated {len(text) - limit} bytes>"


def _log_request(logger: logging.Logger, method: str, url: str,
                 headers: Optional[dict[str, Any]], body: Any) -> None:
    if not is_debug():
        return
    safe_headers = redact(dict(headers or {}))
    if isinstance(body, (bytes, bytearray)):
        body_text = body.decode("utf-8", errors="replace")
    elif body is None:
        body_text = ""
    elif isinstance(body, str):
        body_text = body
    else:
        try:
            body_text = json.dumps(body, separators=(",", ":"))
        except Exception:
            body_text = repr(body)
    logger.debug("HTTP REQ  %s %s headers=%s body=%s",
                 method, url, safe_headers,
                 _truncate(redact_json_text(body_text)) if body_text else "")


def _log_response(logger: logging.Logger, method: str, url: str,
                  status: int, elapsed_ms: int, body_text: str) -> None:
    size = len(body_text)
    if status >= 400:
        log_level = logger.warning
    else:
        log_level = logger.info
    log_level("HTTP RES  %s %s → %d (%dms, %dB)", method, url, status, elapsed_ms, size)
    if is_debug() and body_text:
        logger.debug("HTTP BODY %s %s\n%s", method, url, _truncate(redact_json_text(body_text)))


def trace_urllib(
    req: Request,
    *,
    logger: logging.Logger,
    op: str,
    timeout: Optional[float] = None,
    context: Any = None,
) -> tuple[int, bytes, dict[str, str]]:
    """Wrap urlopen() with diag logging + fault classification.

    Returns (status, body_bytes, headers_dict). Raises the original exception
    after emitting a Fault if one is classifiable.
    """
    method = req.get_method()
    url = req.get_full_url()
    body = req.data
    headers = dict(req.headers)
    _log_request(logger, method, url, headers, body)

    t0 = time.monotonic()
    try:
        with urlopen(req, timeout=timeout, context=context) as resp:
            elapsed_ms = int((time.monotonic() - t0) * 1000)
            raw = resp.read()
            status = resp.getcode() or 0
            resp_headers = {k: v for k, v in resp.headers.items()}
            text = raw.decode("utf-8", errors="replace") if raw else ""
            _log_response(logger, method, url, status, elapsed_ms, text)
            return status, raw, resp_headers
    except HTTPError as exc:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        body_text = ""
        try:
            body_text = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        _log_response(logger, method, url, exc.code, elapsed_ms, body_text)
        fault = classify(exc, {"op": op, "url": url, "http_status": exc.code,
                               "elapsed_s": elapsed_ms / 1000})
        if fault:
            emit(fault, {"url": url, "status": exc.code, "elapsed_ms": elapsed_ms},
                 logger=logger, show_user=False)
        raise
    except (URLError, OSError) as exc:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.warning("HTTP ERR  %s %s → %s (%dms)", method, url, type(exc).__name__, elapsed_ms)
        fault = classify(exc, {"op": op, "url": url, "elapsed_s": elapsed_ms / 1000})
        if fault:
            emit(fault, {"url": url, "elapsed_ms": elapsed_ms},
                 logger=logger, show_user=False)
        raise


def trace_httpx_response(
    response: Any,
    *,
    logger: logging.Logger,
    op: str,
    elapsed_ms: int,
) -> None:
    """Log an httpx Response after the fact. Call from a code path that
    already issued the request (we don't wrap httpx.Client because callers
    use it in many shapes — context managers, async, streaming, etc.)."""
    method = (getattr(response, "request", None) and response.request.method) or "?"
    url = str(response.url)
    body_text = ""
    try:
        body_text = response.text or ""
    except Exception:
        pass
    _log_response(logger, method, url, response.status_code, elapsed_ms, body_text)
    if response.status_code >= 400:
        fault = classify(
            Exception(f"HTTP {response.status_code}"),
            {"op": op, "url": url, "http_status": response.status_code,
             "elapsed_s": elapsed_ms / 1000},
        )
        if fault:
            emit(fault, {"url": url, "status": response.status_code, "elapsed_ms": elapsed_ms},
                 logger=logger, show_user=False)
