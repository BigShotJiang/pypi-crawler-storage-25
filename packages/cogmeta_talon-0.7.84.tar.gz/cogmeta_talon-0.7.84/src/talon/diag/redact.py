"""Strip secrets from log payloads before they hit disk or the network.

Conservative-by-default: anything that looks like a key, token, password, or
authorization header is replaced with "<redacted>". Length-preserving where
useful for debugging key prefixes (sk-* keeps the first 7 chars, then "...").

Usage:
    from talon.diag import redact
    safe = redact(text_or_dict)

Tested in tests/test_diag_redact.py — that suite is the contract; if you add
a code path that emits payloads, add a leak test there too.
"""
from __future__ import annotations

import json
import re
from typing import Any

# Patterns ordered by specificity — apply most-specific first.
_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Anthropic / OpenAI style API keys: keep prefix to aid debugging
    (re.compile(r"\b(sk-[A-Za-z0-9_-]{4})[A-Za-z0-9_-]{20,}\b"), r"\1<redacted>"),
    # AWS access key id
    (re.compile(r"\b(AKIA|ASIA)[A-Z0-9]{16}\b"), "<redacted-aws-key>"),
    # 06_security.md [MEDIUM] AWS secret access keys: 40 alphanumeric +/=
    # following an `aws_secret_access_key` / `aws_session_token` assignment.
    # Anchored on the assignment label so we don't false-positive on any
    # 40-char token in unrelated text. Case-insensitive label, optional
    # whitespace + colon/equals.
    (re.compile(
        r"(?i)(aws[_-]?secret[_-]?access[_-]?key\s*[:=]\s*)['\"]?([A-Za-z0-9/+=]{40})['\"]?"
    ), r"\1<redacted-aws-secret>"),
    (re.compile(
        r"(?i)(aws[_-]?session[_-]?token\s*[:=]\s*)['\"]?([A-Za-z0-9/+=]{40,})['\"]?"
    ), r"\1<redacted-aws-session-token>"),
    # Bearer tokens in Authorization headers
    (re.compile(r"(Bearer\s+)[A-Za-z0-9._\-]+", re.IGNORECASE), r"\1<redacted>"),
    # JWT (3 base64-url segments separated by dots, each >=10 chars)
    (re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"), "<redacted-jwt>"),
    # PEM blocks
    (re.compile(r"-----BEGIN [A-Z ]+PRIVATE KEY-----.*?-----END [A-Z ]+PRIVATE KEY-----", re.DOTALL),
     "<redacted-pem>"),
]

# JSON keys whose values get fully redacted regardless of content.
_SENSITIVE_KEYS = frozenset({
    "api_key",
    "access_token",
    "refresh_token",
    "password",
    "passwd",
    "secret",
    "client_secret",
    "authorization",
    "x-api-key",
    "renewal_key",
    "private_key",
    "session_token",
    # 06_security.md [MEDIUM] AWS secret access key handling — JSON dumps
    # frequently surface these as nested keys; redact whole values when
    # the key matches, not just when the regex catches the assignment.
    "aws_secret_access_key",
    "aws_session_token",
    "aws_access_key_id",
    "aws-secret-access-key",
    "aws-session-token",
    "aws-access-key-id",
})


def _redact_string(s: str) -> str:
    out = s
    for pat, repl in _PATTERNS:
        out = pat.sub(repl, out)
    return out


def _redact_obj(obj: Any) -> Any:
    """Recursive redaction for dicts/lists. Leaves non-string scalars alone."""
    if isinstance(obj, dict):
        return {
            k: ("<redacted>" if isinstance(k, str) and k.lower() in _SENSITIVE_KEYS
                else _redact_obj(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_redact_obj(x) for x in obj]
    if isinstance(obj, str):
        return _redact_string(obj)
    return obj


def redact(value: Any) -> Any:
    """Return a sanitized copy of value with secrets stripped.

    - str  → pattern-redacted string
    - dict → recursively redacted dict (sensitive keys → "<redacted>")
    - list → recursively redacted list
    - bytes → decoded as utf-8 (replace errors), then redacted, returned as str
    - other → returned unchanged
    """
    if isinstance(value, bytes):
        return _redact_string(value.decode("utf-8", errors="replace"))
    if isinstance(value, str):
        return _redact_string(value)
    if isinstance(value, (dict, list)):
        return _redact_obj(value)
    return value


def redact_json_text(raw: str) -> str:
    """Redact a JSON document by parsing then re-emitting. Falls back to
    string-level redaction if parsing fails."""
    try:
        parsed = json.loads(raw)
    except (ValueError, TypeError):
        return _redact_string(raw)
    return json.dumps(_redact_obj(parsed), separators=(",", ":"))
