"""Talon client diagnostics — unified logging, redaction, fault classification.

Public API:
    setup(component)       -> logging.Logger writing to ~/.talon/logs/<component>.log
    is_debug()             -> bool
    redact(text|dict)      -> sanitized copy with secrets stripped
    classify(exc, ctx)     -> Fault | None
    emit(fault, details, logger=None)  -> log + user-print
    LOG_DIR                -> Path to ~/.talon/logs/

Components used across the codebase:
    "cli"        — talon CLI (setup_cli)
    "proxy"      — proxy_wrapper SSE bridge
    "hooks"      — statusline + prompt_hook
    "indexer"    — talon-index runs
    "telemetry"  — telemetry network failures
"""
from __future__ import annotations

from .faults import FAULT_CATALOG, Fault, classify, emit
from .logger import LOG_DIR, setup
from .redact import redact
from .state import is_debug, set_debug_override

__all__ = [
    "FAULT_CATALOG",
    "Fault",
    "LOG_DIR",
    "classify",
    "emit",
    "is_debug",
    "redact",
    "set_debug_override",
    "setup",
]
