"""User-Agent helper for all outbound HTTPS to *.cogmeta.ai.

CloudFlare Bot Fight Mode (error 1010) blocks the default `Python-urllib/<ver>`
UA on api.cogmeta.ai. Every urllib/httpx call from the talon client wheel MUST
set this UA — see usp/exp/mvp/elite/fix/principles/architecture/cloudflare_alb_path.md.

The `talon-cli/<ver>` shape is also what:
  - the CF allow-list rule expects (skip Bot Fight + rate limits)
  - the server-side 426-Upgrade middleware parses for client-version detection

Three layers covered by one convention.
"""
from __future__ import annotations


def talon_ua() -> str:
    try:
        from importlib.metadata import version
        v = version("cogmeta-talon")
    except Exception:
        v = "0.0.0"
    return f"talon-cli/{v}"
