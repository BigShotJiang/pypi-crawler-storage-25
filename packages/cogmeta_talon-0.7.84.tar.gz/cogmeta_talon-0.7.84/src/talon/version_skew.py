"""R-CLIENT-MCP-VERSION-SKEW — client/cloud version compatibility check.

Surfaces version skew between the locally-installed `talon` client whl and
the cloud server it's talking to. Detects three classes of skew:

  - **safe**: same minor (0.2.x ↔ 0.2.y)
  - **warn**: client minor older than cloud or vice-versa (0.2 ↔ 0.3)
  - **error**: major mismatch (0.x ↔ 1.x) → contracts likely broken

The cloud `/talon/mcp/health` endpoint already reports its version; we
parse both and compute the skew level. Used by:
    talon health    — surfaces skew alongside reachability
    talon doctor    — fails the readiness check on `error` skew
    talon-proxy     — logs a one-time warning on session start
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

# Match plain semver: 0.2.1, 1.0.0-rc.2, etc. The pre-release suffix is
# stripped for comparison (we only care about major.minor.patch ordering).
_SEMVER_RE = re.compile(r"^(\d+)\.(\d+)(?:\.(\d+))?")


class SkewLevel(str, Enum):
    SAFE = "safe"
    WARN = "warn"
    ERROR = "error"
    UNKNOWN = "unknown"


@dataclass
class SkewReport:
    level: SkewLevel
    client: str
    cloud: str
    detail: str

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "client": self.client,
            "cloud": self.cloud,
            "detail": self.detail,
        }


def _parse(v: str) -> tuple[int, int, int] | None:
    """Return (major, minor, patch) or None if unparseable."""
    if not v:
        return None
    m = _SEMVER_RE.match(v.strip().lstrip("v"))
    if not m:
        return None
    major, minor, patch = m.group(1), m.group(2), m.group(3) or "0"
    try:
        return int(major), int(minor), int(patch)
    except ValueError:
        return None


def compare_versions(client: str, cloud: str) -> SkewReport:
    """Return a SkewReport describing the relationship between client + cloud.

    Both args are version strings like "0.2.1" or "v0.3.0-rc.2". Either may
    be empty; missing strings are treated as UNKNOWN.
    """
    c = _parse(client)
    s = _parse(cloud)

    if c is None or s is None:
        return SkewReport(
            level=SkewLevel.UNKNOWN,
            client=client or "(unset)",
            cloud=cloud or "(unset)",
            detail="one or both versions unparseable",
        )

    cm, cn, _cp = c
    sm, sn, _sp = s

    if cm != sm:
        return SkewReport(
            level=SkewLevel.ERROR,
            client=client,
            cloud=cloud,
            detail=f"major version mismatch (client={cm}.x, cloud={sm}.x) — contracts likely broken; upgrade with `talon upgrade`",
        )

    if cn == sn:
        return SkewReport(
            level=SkewLevel.SAFE,
            client=client,
            cloud=cloud,
            detail="same minor — no compatibility concern",
        )

    if cn < sn:
        return SkewReport(
            level=SkewLevel.WARN,
            client=client,
            cloud=cloud,
            detail=f"client behind cloud ({cm}.{cn} < {sm}.{sn}) — run `talon upgrade` to pick up new features",
        )

    return SkewReport(
        level=SkewLevel.WARN,
        client=client,
        cloud=cloud,
        detail=f"client ahead of cloud ({cm}.{cn} > {sm}.{sn}) — cloud may not yet support newer client features",
    )


def fetch_cloud_version(cloud_url: str, timeout: float = 5.0) -> str:
    """Fetch cloud version from /talon/mcp/health. Empty string on failure."""
    import json
    import ssl
    import urllib.request

    try:
        url = cloud_url.rstrip("/") + "/talon/mcp/health"
        from talon._ua import talon_ua
        req = urllib.request.Request(url, headers={"User-Agent": talon_ua()})
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            data = json.loads(resp.read())
            return str(data.get("version") or "")
    except Exception:
        return ""


def get_client_version() -> str:
    """Return the installed talon whl version, or empty on failure."""
    try:
        import talon
        return getattr(talon, "__version__", "") or ""
    except Exception:
        return ""
