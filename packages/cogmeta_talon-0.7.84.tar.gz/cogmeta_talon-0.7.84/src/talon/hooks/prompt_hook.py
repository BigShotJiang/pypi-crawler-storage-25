#!/usr/bin/env python3
"""talon-prompt-hook — UserPromptSubmit hook (single combined hook).

1. Renews Talon API key if near expiry and patches .mcp.json (synchronous, first)
2. Fires prompt telemetry to cloud API (fire-and-forget thread)
3. Refreshes alltime score, inbox, graph health, PyPI update check (background threads)
4. Injects a brief reminder to use talon MCP tools on first coding prompt of session
"""

import datetime
import json
import os
import sys
import threading
import time
from pathlib import Path

from talon._ua import talon_ua

_CREDS = Path.home() / ".talon" / "credentials.json"
_RENEWAL_STATE = Path.home() / ".talon" / "renewal_state.json"
_SESSION_FILE = Path.home() / ".talon" / "session_state.json"

# IP audit §6 (2026-05-01): renewal cadence is server-tuned via hook_config.
# The bland defaults below are first-connect / offline fallbacks — a competitor
# reading the wheel can no longer learn the production renewal window.
# Accessors (_renewal_ttl_hours / _renewal_threshold) defined later because
# they read _HOOK_CONFIG_PATH which is declared with the other interval cfg.
_RENEWAL_TTL_HOURS_DEFAULT = 6
_RENEWAL_THRESHOLD_DEFAULT = 0.80


# --- diag logging (best-effort, never raises) -------------------------------
# Hooks are intentionally silent on failure (they must not break Claude Code's
# prompt flow). We additionally append a one-line event to ~/.talon/logs/hooks.log
# so that what would otherwise be invisible misfires can be inspected via
# `talon diag tail hooks`. Falls back to a tiny direct-append if the diag
# module is unavailable for any reason.
_HOOKS_LOGGER = None
try:
    from talon.diag.logger import setup as _diag_setup  # noqa: E402
    _HOOKS_LOGGER = _diag_setup("hooks")
except Exception:
    _HOOKS_LOGGER = None


def _diag_log(event: str, **fields) -> None:
    if _HOOKS_LOGGER is not None:
        try:
            _HOOKS_LOGGER.warning("%s | %s", event, fields)
            return
        except Exception:
            pass
    try:
        log_dir = Path.home() / ".talon" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "hooks.log"
        if log_path.exists() and log_path.stat().st_size > 2 * 1024 * 1024:
            log_path.unlink()  # crude self-rotate when diag is unavailable
        line = json.dumps({"ts": time.time(), "event": event, **fields}) + "\n"
        with open(log_path, "a") as f:
            f.write(line)
    except Exception:
        pass


def _load_api_key() -> tuple[str, str]:
    try:
        creds = json.loads(_CREDS.read_text())
        return creds.get("api_key", ""), creds.get("cloud_url", "https://api.cogmeta.ai")
    except Exception:
        return "", "https://api.cogmeta.ai"


def _renew_api_key() -> None:
    """Silently renew API key once we cross the server-tuned renewal threshold.

    Both the TTL window and the renewal threshold are read from hook_config so
    the cloud can re-tune renewal cadence without a wheel ship. Defaults are
    intentionally bland and live alongside other offline fallbacks at module
    top.
    """
    if not _CREDS.exists():
        return
    try:
        creds = json.loads(_CREDS.read_text())
    except Exception:
        return

    saved_at = creds.get("saved_at", "")
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", "https://api.cogmeta.ai").rstrip("/")
    if not saved_at or not api_key:
        return

    try:
        saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
        now = datetime.datetime.now(datetime.timezone.utc)
        ttl_hours = _renewal_ttl_hours()
        threshold = _renewal_threshold()
        if (now - saved).total_seconds() / (ttl_hours * 3600) < threshold:
            return
    except Exception:
        return

    try:
        if _RENEWAL_STATE.exists():
            st = json.loads(_RENEWAL_STATE.read_text())
            backoff = min(60 * (2 ** st.get("attempt_count", 0)), 3600)
            if time.time() - st.get("last_attempt", 0) < backoff:
                return
    except Exception:
        pass

    try:
        import ssl
        import urllib.request
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            f"{cloud_url}/cloud/v1/users/me/api-key",
            method="POST",
            headers={"X-API-Key": api_key, "User-Agent": talon_ua()},
        )
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            data = json.loads(resp.read())
        new_key = data.get("api_key", "")
        _diag_log("api_key_renewed", success=bool(new_key))
        if new_key:
            ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            tmp = _CREDS.parent / f".credentials.tmp.{os.getpid()}"
            tmp.write_text(json.dumps({**creds, "api_key": new_key, "saved_at": ts}, indent=2))
            tmp.chmod(0o600)
            tmp.rename(_CREDS)
            _RENEWAL_STATE.write_text(json.dumps({"last_attempt": time.time(), "attempt_count": 0}))
            for p in (Path.home() / ".mcp.json", Path.cwd() / ".mcp.json"):
                try:
                    if not p.exists():
                        continue
                    txt = p.read_text()
                    if api_key not in txt:
                        continue
                    cfg = json.loads(txt)
                    patched = False
                    for sv in cfg.get("mcpServers", {}).values():
                        env = sv.get("env", {})
                        if env.get("TALON_API_KEY") == api_key:
                            env["TALON_API_KEY"] = new_key
                            patched = True
                    if patched:
                        tmp2 = p.parent / f".mcp.json.tmp.{os.getpid()}"
                        tmp2.write_text(json.dumps(cfg, indent=2) + "\n")
                        tmp2.rename(p)
                except Exception:
                    pass
        return
    except Exception as exc:
        _diag_log("api_key_renew_failed", error=type(exc).__name__, msg=str(exc)[:200])

    try:
        st = json.loads(_RENEWAL_STATE.read_text()) if _RENEWAL_STATE.exists() else {}
        _RENEWAL_STATE.write_text(json.dumps({
            "last_attempt": time.time(),
            "attempt_count": st.get("attempt_count", 0) + 1,
        }))
    except Exception:
        pass


def _fire_telemetry(prompt_text: str, session_id: str) -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        telemetry_url = os.environ.get("TALON_TELEMETRY_URL") or f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/prompt_event"
        # Ship the FULL classification record so the cloud can answer
        # "what fraction of prompts are misclassified?" by joining against
        # talon_trace_steps. Previously this payload only sent
        # session_id + prompt_length + timestamp; the cloud ingest then
        # hardcoded is_code=True / task_type='unknown' on insert, which made
        # the admin dashboard's coding-vs-non-coding chart meaningless.
        # No prompt text is sent — only the classifier's verdict + the
        # trigger keyword. Privacy-safe.
        cls = _classify_prompt(prompt_text)
        data = json.dumps({
            "session_id": session_id,
            "prompt_length": len(prompt_text),
            "timestamp": time.time(),
            "is_code": cls["is_code"],
            "task_type": cls["task_type"],
            "confidence": cls["confidence"],
            "matched_keyword": cls["matched_keyword"],
        }).encode()
        req = urllib.request.Request(
            telemetry_url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": talon_ua()},
            method="POST",
        )
        env_key = os.environ.get("TALON_API_KEY", "") or api_key
        if env_key:
            req.add_header("X-API-Key", env_key)
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        urllib.request.urlopen(req, timeout=3, context=ctx)
    except Exception as exc:
        _diag_log("telemetry_post_failed", error=type(exc).__name__, msg=str(exc)[:200])


def _fetch_alltime_score() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        alltime_path = Path.home() / ".talon" / "score_alltime.json"
        if alltime_path.exists():
            age = time.time() - json.loads(alltime_path.read_text()).get("updated_at", 0)
            if age < _interval_cfg("alltime_score_ttl_s"):
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/score/summary"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": talon_ua()})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        alltime_path.parent.mkdir(parents=True, exist_ok=True)
        alltime_path.write_text(json.dumps({
            "score": data.get("avg_score", 0.0),
            "sessions": data.get("total_sessions", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _fetch_latest_score() -> None:
    """Refresh ~/.talon/score.json from the cloud per-connection scorer.

    The client wheel no longer carries the session-scoring formula. The cloud
    SSE per-connection scorer is authoritative; this poll refreshes the local
    cache the statusline reads. Cadence is server-tunable via
    hook_config.score_latest_ttl_s.
    """
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        score_path = Path.home() / ".talon" / "score.json"
        if score_path.exists():
            age = time.time() - json.loads(score_path.read_text()).get("updated_at", 0)
            if age < _interval_cfg("score_latest_ttl_s"):
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/score/latest"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": talon_ua()})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        score_path.parent.mkdir(parents=True, exist_ok=True)
        score_path.write_text(json.dumps({
            "session": float(data.get("session", 0.0)),
            "last_prompt": float(data.get("last_prompt", 0.0)),
            "band": data.get("band", "no_data"),
            "savings_pct": float(data.get("est_reduction_pct", 0.0)),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _fetch_inbox() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        inbox_path = Path.home() / ".talon" / "inbox.json"
        if inbox_path.exists():
            age = time.time() - json.loads(inbox_path.read_text()).get("updated_at", 0)
            if age < _interval_cfg("inbox_ttl_s"):
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/support/unread"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": talon_ua()})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        inbox_path.parent.mkdir(parents=True, exist_ok=True)
        inbox_path.write_text(json.dumps({
            "unread": data.get("unread", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _refresh_graph_health() -> None:
    try:
        import ssl
        import urllib.request

        health_path = Path.home() / ".talon" / "graph_health.json"
        if health_path.exists():
            age = time.time() - json.loads(health_path.read_text()).get("checked_at", 0)
            if age < _interval_cfg("graph_health_ttl_s"):
                return

        api_key, cloud_url = _load_api_key()
        if not api_key:
            return

        project_id = os.environ.get("TALON_PROJECT_ID", "")
        if not project_id:
            try:
                mcp_cfg = json.loads((Path.cwd() / ".mcp.json").read_text())
                project_id = (
                    mcp_cfg.get("mcpServers", {})
                    .get("talon", {})
                    .get("env", {})
                    .get("TALON_PROJECT_ID", "")
                )
            except Exception:
                pass
        if not project_id:
            return

        url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/stats"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            url, headers={"X-API-Key": api_key, "User-Agent": talon_ua()}
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        stats = json.loads(resp.read())

        files = stats.get("files", 0)
        functions = stats.get("functions", 0)

        health_path.parent.mkdir(parents=True, exist_ok=True)
        health_path.write_text(json.dumps({
            "project_id": project_id,
            "state_pct": 100 if (functions > 0 and files > 0) else 0,
            "files": files,
            "functions": functions,
            "classes": stats.get("classes", 0),
            "action": "" if (functions > 0 and files > 0) else "run talon index",
            "checked_at": time.time(),
        }))
    except Exception as exc:
        _diag_log("graph_health_refresh_failed", error=type(exc).__name__, msg=str(exc)[:200])


def _check_for_update() -> None:
    try:
        import ssl
        import urllib.request
        from talon import __version__ as current

        update_path = Path.home() / ".talon" / "update.json"
        if update_path.exists():
            cached = json.loads(update_path.read_text())
            if time.time() - cached.get("checked_at", 0) < _interval_cfg("update_check_ttl_s"):
                return

        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            "https://pypi.org/pypi/cogmeta-talon/json",
            headers={"User-Agent": "talon-client/" + current, "Accept": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        data = json.loads(resp.read())
        latest = data.get("info", {}).get("version", current)

        update_path.parent.mkdir(parents=True, exist_ok=True)
        update_path.write_text(json.dumps({
            "current": current,
            "latest": latest,
            "available": latest != current,
            "checked_at": time.time(),
        }))
    except Exception as exc:
        _diag_log("update_check_failed", error=type(exc).__name__, msg=str(exc)[:200])


_HOOK_CONFIG_PATH = Path.home() / ".talon" / "hook_config.json"
_HOOK_CONFIG_TTL = 300

# Refresh-cadence literals for the background fetchers below are
# server-overridable via hook_config. Literals here are bland offline
# fallbacks.
_INTERVAL_DEFAULTS: dict[str, float] = {
    "alltime_score_ttl_s": 3600.0,
    "inbox_ttl_s": 300.0,
    "graph_health_ttl_s": 1800.0,
    "update_check_ttl_s": 3600.0,
    "score_latest_ttl_s": 300.0,
}


def _interval_cfg(key: str) -> float:
    try:
        if _HOOK_CONFIG_PATH.exists():
            data = json.loads(_HOOK_CONFIG_PATH.read_text())
            v = data.get(key)
            if v is not None:
                return float(v)
    except Exception:
        pass
    return _INTERVAL_DEFAULTS[key]


def _renewal_ttl_hours() -> float:
    try:
        if _HOOK_CONFIG_PATH.exists():
            v = json.loads(_HOOK_CONFIG_PATH.read_text()).get("api_key_renewal_ttl_hours")
            if v is not None:
                return float(v)
    except Exception:
        pass
    return float(_RENEWAL_TTL_HOURS_DEFAULT)


def _renewal_threshold() -> float:
    try:
        if _HOOK_CONFIG_PATH.exists():
            v = json.loads(_HOOK_CONFIG_PATH.read_text()).get("api_key_renewal_threshold")
            if v is not None:
                return float(v)
    except Exception:
        pass
    return float(_RENEWAL_THRESHOLD_DEFAULT)


_CODING_TASK_PATTERN = None


def _coding_task_pattern():
    """Lazy-init the coding-task keyword regex. Returned compiled object is
    used for both bool detection AND for reporting which keyword(s) matched.

    Keyword list extended 2026-05-01 (TREF1 classifier sweep): added
    `check / verify / record / return / propagate / wire / expose` to
    close the 9.2% false-negative gap on TREF1's 65-prompt corpus.
    Continuation prompts ("also check the cache backend", "same for
    mysql dialect — return thread_id") were the dominant miss pattern
    and these verbs catch them without inflating false positives on
    real prose (asymmetric impact: ~50× cheaper to over-fire than to
    miss). New TREF1 recall: 100% (was 90.8%).
    """
    global _CODING_TASK_PATTERN
    if _CODING_TASK_PATTERN is None:
        import re
        _CODING_TASK_PATTERN = re.compile(
            r"\b(fix|add|implement|refactor|migrate|update|change|create|write|debug|build|"
            r"edit|modify|remove|delete|rename|move|extract|test|deploy|install|configure|"
            r"import|export|parse|render|fetch|query|hook|route|endpoint|function|class|"
            r"method|module|file|script|bug|error|exception|fail|break|crash|regression|"
            r"performance|optimise|optimize|async|await|thread|process|pipeline|"
            r"check|verify|record|return|propagate|wire|expose|ensure|stored|"
            r"handle|append)\b",
            re.IGNORECASE,
        )
    return _CODING_TASK_PATTERN


def _is_coding_task(prompt: str) -> bool:
    return bool(_coding_task_pattern().search(prompt))


def _classify_prompt(prompt: str) -> dict:
    """Run the keyword classifier and return ALL the signals — bool result,
    matched-keyword count (proxy for confidence), and the first matched
    keyword (free-text label so misclass triage can group by trigger).

    Used by `_fire_telemetry` to ship the full classification record to the
    cloud, not just the prompt length. Closes the prompt-misclass-reporting
    gap surfaced 2026-05-01.
    """
    if not prompt:
        return {"is_code": False, "task_type": "empty", "confidence": 0.0, "matched_keyword": ""}
    pat = _coding_task_pattern()
    matches = pat.findall(prompt)
    if not matches:
        return {"is_code": False, "task_type": "non_coding", "confidence": 0.0, "matched_keyword": ""}
    # Confidence: 1 match = 0.5; 2 = 0.7; 3 = 0.85; 4+ = 0.95
    n = len(matches)
    confidence = min(0.95, 0.5 + 0.15 * (n - 1)) if n >= 1 else 0.0
    first = matches[0].lower() if matches else ""
    return {
        "is_code": True,
        "task_type": first,           # the trigger keyword — useful for triage
        "confidence": round(confidence, 2),
        "matched_keyword": first,
    }


def _fetch_hook_config() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        if _HOOK_CONFIG_PATH.exists():
            age = time.time() - json.loads(_HOOK_CONFIG_PATH.read_text()).get("_updated_at", 0)
            if age < _HOOK_CONFIG_TTL:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/users/me/hook-config"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": talon_ua()})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        data["_updated_at"] = time.time()
        _HOOK_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        _HOOK_CONFIG_PATH.write_text(json.dumps(data))
    except Exception:
        pass


def _read_hook_config() -> dict:
    try:
        if _HOOK_CONFIG_PATH.exists():
            return json.loads(_HOOK_CONFIG_PATH.read_text())
    except Exception:
        pass
    return {}


def _is_first_prompt(session_id: str) -> bool:
    try:
        _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _SESSION_FILE.exists():
            state = json.loads(_SESSION_FILE.read_text())
            if state.get("session_id") == session_id:
                return False
        _SESSION_FILE.write_text(json.dumps({"session_id": session_id}))
        return True
    except Exception:
        return False


def main() -> None:
    try:
        raw = sys.stdin.read()
        event = json.loads(raw) if raw.strip() else {}
    except Exception:
        event = {}

    # Key renewal first — synchronous, so fresh key is used by all threads below
    _renew_api_key()

    session_id = event.get("session_id", "")
    prompt_text = ""
    content = event.get("message", {}).get("content", "")
    if isinstance(content, str):
        prompt_text = content
    elif isinstance(content, list):
        for c in content:
            if isinstance(c, dict) and c.get("text"):
                prompt_text = c["text"]
                break

    telemetry_enabled = os.environ.get("TALON_TELEMETRY_ENABLED", "1") != "0"

    threads = []
    if telemetry_enabled:
        threads.append(threading.Thread(target=_fire_telemetry, args=(prompt_text, session_id), daemon=True))
    threads.append(threading.Thread(target=_fetch_alltime_score, daemon=True))
    threads.append(threading.Thread(target=_fetch_latest_score, daemon=True))
    threads.append(threading.Thread(target=_fetch_inbox, daemon=True))
    threads.append(threading.Thread(target=_check_for_update, daemon=True))
    threads.append(threading.Thread(target=_refresh_graph_health, daemon=True))
    threads.append(threading.Thread(target=_fetch_hook_config, daemon=True))
    for t in threads:
        t.start()

    result: dict = {"continue": True}
    every_prompt = (
        os.environ.get("TALON_L2_EVERY_PROMPT") == "1"
        or _read_hook_config().get("l2_every_prompt", 0) == 1
    )
    if _is_coding_task(prompt_text) and (every_prompt or _is_first_prompt(session_id)):
        # Server-fetched reminder text (canonical source); offline fallback
        # used when hook_config.json hasn't been populated yet. The fallback
        # is intentionally generic — the calibrated wording lives server-side
        # and is delivered via /cloud/v1/users/me/hook-config.
        cfg = _read_hook_config()
        result["systemMessage"] = cfg.get("coding_reminder") or (
            "[Talon] Use graph_ask_lite first for code context, "
            "then edit_batch for changes. Run /talon score to check session efficiency."
        )

    json.dump(result, sys.stdout)
    sys.stdout.flush()

    for t in threads:
        t.join(timeout=1)


if __name__ == "__main__":
    main()
