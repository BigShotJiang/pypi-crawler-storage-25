#!/usr/bin/env python3
"""talon-statusline.py — Claude Code status line with Talon session score.

Shows: CogMeta: last_prompt / session / alltime | -XX% ████▒▒ ↓X.XM | Nt X.XM

Score values are read from ~/.talon/score.json which is refreshed in the
background by prompt_hook._fetch_latest_score (canonical scorer is the cloud
SSE per-connection scorer; this file just renders).
"""

import json
import os
import re
import sys
import time
from pathlib import Path

GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[38;5;33m"
CYAN = "\033[36m"
NEON = "\033[38;5;213m"
DIM = "\033[2m"
RESET = "\033[0m"

# Used by _mcp_status_badge to detect "did this session see a Talon tool
# call". Scoring no longer happens client-side — see prompt_hook._fetch_latest_score.
TALON_TOOLS = frozenset({
    "mcp__talon__graph_ask_lite",
    "mcp__talon__graph_query",
    "mcp__talon__smart_read_batch",
    "mcp__talon__edit_batch",
})

BASELINES_PATH = Path(__file__).resolve().parent.parent / "data" / "vanilla_baselines.json"

_baselines_cache: dict | None = None

# Server-overridable tuning via hook_config; literals here are bland offline
# fallbacks. Authoritative values arrive from the cloud config refresh.
_HOOK_CONFIG_PATH = Path.home() / ".talon" / "hook_config.json"

_BAND_DEFAULTS: dict[str, float] = {
    "score_band_green": 0.85,
    "score_band_cyan": 0.65,
    "score_band_yellow": 0.40,
    "floor_per_turn": 30_000.0,
    "model_mult_opus": 4.0,
    "model_mult_haiku": 0.6,
    "model_mult_default": 1.0,
}


def _band_cfg() -> dict[str, float]:
    try:
        if _HOOK_CONFIG_PATH.exists():
            data = json.loads(_HOOK_CONFIG_PATH.read_text())
            return {k: float(data.get(k, v)) for k, v in _BAND_DEFAULTS.items()}
    except Exception:
        pass
    return dict(_BAND_DEFAULTS)


def _floor_per_turn() -> int:
    return int(_band_cfg()["floor_per_turn"])


# --- diag logging (best-effort, never raises) -------------------------------
# Statusline runs after every assistant message. Failures here would make the
# bar disappear silently. Append a one-line event to ~/.talon/logs/hooks.log
# so support can see what tried + failed without forcing the user into debug.
_HOOKS_LOGGER = None
try:
    from talon.diag.logger import setup as _diag_setup  # noqa: E402
    _HOOKS_LOGGER = _diag_setup("hooks")
except Exception:
    _HOOKS_LOGGER = None


def _diag_log(event: str, **fields) -> None:
    if _HOOKS_LOGGER is not None:
        try:
            _HOOKS_LOGGER.warning("%s | %s", event, fields)
            return
        except Exception:
            pass
    try:
        log_dir = Path.home() / ".talon" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "hooks.log"
        if log_path.exists() and log_path.stat().st_size > 2 * 1024 * 1024:
            log_path.unlink()
        line = json.dumps({"ts": time.time(), "event": event, **fields}) + "\n"
        with open(log_path, "a") as f:
            f.write(line)
    except Exception:
        pass


def _load_baselines() -> dict:
    global _baselines_cache
    if _baselines_cache is not None:
        return _baselines_cache
    try:
        if BASELINES_PATH.exists():
            _baselines_cache = json.loads(BASELINES_PATH.read_text())
            return _baselines_cache
    except Exception:
        pass
    _baselines_cache = {}
    return _baselines_cache


def _classify_task_type(first_message: str) -> str:
    text = first_message.lower()
    if re.search(r"\b(refactor|rename|restructure|reorganize|extract\s+method|move\s+to)\b", text):
        return "refactor"
    return "write"


def _project_vanilla_tmc(baselines: dict, n_files: int, task_type: str,
                         n_turns: int) -> tuple[int, str]:
    strata = baselines.get("strata", {})

    def _scale(s: dict, key: str) -> tuple[int, str]:
        median_tok = s["tokens"]["median"]
        median_turns = s["turns"]["median"]
        if median_turns <= 0 or n_turns <= 0:
            return int(median_tok), f"stratum:{key}"
        per_turn = max(median_tok / median_turns, _floor_per_turn())
        projected = per_turn * n_turns
        return int(projected), f"stratum:{key}"

    key = f"{task_type}_{n_files}f"
    if key in strata:
        return _scale(strata[key], key)

    candidates = [(k, v) for k, v in strata.items() if v["task_type"] == task_type]
    if candidates:
        best_k, best_v = min(candidates, key=lambda x: abs(x[1]["n_files"] - n_files))
        return _scale(best_v, best_k)

    return n_turns * 30_000, "fallback"


def _detect_model(transcript_path: str) -> str:
    try:
        with open(transcript_path) as _f:
            for line in _f:
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                if entry.get("type") == "assistant":
                    model = entry.get("message", {}).get("model", "")
                    if model and not model.startswith("<"):
                        return model
    except Exception:
        pass
    return ""


def _model_multiplier(model: str) -> float:
    m = model.lower()
    cfg = _band_cfg()
    if "opus" in m:
        return cfg["model_mult_opus"]
    if "haiku" in m:
        return cfg["model_mult_haiku"]
    return cfg["model_mult_default"]


def _fmt_tok(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1000:
        return f"{n // 1000}K"
    return str(n)


def _color_score(v: float) -> str:
    pct = int(v * 100)
    bands = _band_cfg()
    if v >= bands["score_band_green"]:
        return f"{GREEN}{pct}{RESET}"
    if v >= bands["score_band_cyan"]:
        return f"{CYAN}{pct}{RESET}"
    if v >= bands["score_band_yellow"]:
        return f"{YELLOW}{pct}{RESET}"
    return f"\033[31m{pct}{RESET}"


def _dual_bar(actual: int, projected: int, width: int = 8) -> str:
    if projected <= 0 or actual >= projected:
        return f"{BLUE}{'█' * width}{RESET}"
    ratio = actual / projected
    filled = int(ratio * width)
    gap = width - filled
    return f"{BLUE}{'█' * filled}{RESET}{DIM}{'▒' * gap}{RESET}"


def _parse_transcript(cc_data: dict) -> dict:
    transcript_path = cc_data.get("transcript_path", "")
    if not transcript_path or not os.path.exists(transcript_path):
        return {}

    total_input = 0
    cache_read = 0
    cache_creation = 0
    n_turns = 0
    tool_names: list[str] = []
    files_touched: set[str] = set()
    first_msg = ""
    model = ""

    try:
        with open(transcript_path) as _tf:
            for line in _tf:
                try:
                    entry = json.loads(line)
                except Exception:
                    continue

                if entry.get("type") == "user" and not first_msg:
                    content = entry.get("message", {}).get("content", "")
                    if isinstance(content, str):
                        first_msg = content
                    elif isinstance(content, list):
                        for c in content:
                            if isinstance(c, dict) and c.get("text"):
                                first_msg = c["text"]
                                break

                if entry.get("type") != "assistant":
                    continue

                n_turns += 1
                msg = entry.get("message", {})
                if not model:
                    model = msg.get("model", "")
                usage = msg.get("usage", {})
                if usage:
                    total_input += usage.get("input_tokens", 0)
                    cache_read += usage.get("cache_read_input_tokens", 0)
                    cache_creation += usage.get("cache_creation_input_tokens", 0)

                for item in msg.get("content", []):
                    if not isinstance(item, dict) or item.get("type") != "tool_use":
                        continue
                    name = item.get("name", "")
                    tool_names.append(name)
                    fp = item.get("input", {}).get("file_path", "")
                    if name in ("Read", "Edit", "Write") and fp:
                        files_touched.add(fp)
    except Exception:
        pass

    actual_tmc = total_input + cache_read + cache_creation
    return {
        "n_turns": n_turns, "actual_tmc": actual_tmc,
        "tool_names": tool_names, "files_touched": files_touched,
        "first_msg": first_msg, "model": model,
    }


def _talon_active_in_transcript(tool_names: list[str]) -> bool:
    return any(t in TALON_TOOLS for t in tool_names)


def _talon_mcp_configured() -> bool:
    for p in [Path.cwd() / ".mcp.json", Path.home() / ".claude.json", Path.home() / ".mcp.json"]:
        try:
            if p.exists():
                d = json.loads(p.read_text())
                if "talon" in d.get("mcpServers", {}):
                    return True
        except Exception:
            pass
    return False


def _cogmeta_score(data: dict) -> str:
    # Score values are server-computed and refreshed by
    # prompt_hook._fetch_latest_score. When score.json is missing or stale,
    # show "?" for prompt/session — there is no client-side scorer to fall
    # back to.
    last_prompt: float | None = None
    session: float | None = None
    got_mcp = False

    try:
        score_path = Path.home() / ".talon" / "score.json"
        if score_path.exists():
            d = json.loads(score_path.read_text())
            age = time.time() - d.get("updated_at", 0)
            if age < 7200:
                last_prompt = float(d.get("last_prompt", 0.0))
                session = float(d.get("session", 0.0))
                got_mcp = True
    except Exception:
        pass

    talon_active = got_mcp or _talon_active_in_transcript(data.get("tool_names", []))

    alltime = 0.0
    try:
        p = Path.home() / ".talon" / "score_alltime.json"
        if p.exists():
            alltime = json.loads(p.read_text()).get("score", 0.0)
    except Exception:
        pass

    mcp_configured = _talon_mcp_configured()
    has_creds = (Path.home() / ".talon" / "credentials.json").exists()

    label = f"{DIM}[Prompt, Session, All Time]{RESET}"

    if not mcp_configured:
        if not has_creds:
            return f"{DIM}CogMeta: /talon login{RESET}"
        return f"{DIM}CogMeta: /talon init{RESET}"

    if data.get("n_turns", 0) == 0:
        return f"CogMeta: {_color_score(0.0)} / {_color_score(0.0)} / {_color_score(alltime)} {label}"

    if not talon_active:
        return f"CogMeta: {_color_score(0.0)} / {_color_score(0.0)} / {_color_score(alltime)} {label}"

    if last_prompt is None or session is None:
        pending = f"{DIM}?{RESET}"
        return f"CogMeta: {pending} / {pending} / {_color_score(alltime)} {label}"

    return f"CogMeta: {_color_score(last_prompt)} / {_color_score(session)} / {_color_score(alltime)} {label}"


def _session_savings(data: dict, cc_data: dict) -> str:
    n_turns = data.get("n_turns", 0)
    actual_tmc = data.get("actual_tmc", 0)
    raw = f"{DIM}{n_turns}t {_fmt_tok(actual_tmc)}{RESET}"

    if n_turns == 0:
        return raw

    n_files = max(1, len(data.get("files_touched", set())))
    task_type = _classify_task_type(data.get("first_msg", ""))

    baselines = _load_baselines()
    if not baselines:
        return raw

    projected_tmc, _source = _project_vanilla_tmc(baselines, n_files, task_type, n_turns)

    transcript_path = cc_data.get("transcript_path", "")
    model = _detect_model(transcript_path) if transcript_path else data.get("model", "")
    multiplier = _model_multiplier(model)
    projected_tmc = int(projected_tmc * multiplier)

    saved = projected_tmc - actual_tmc
    if saved <= 0 or projected_tmc <= 0:
        return f"{DIM}{'█' * 8}{RESET} {raw}"

    save_pct = saved / projected_tmc * 100
    bar = _dual_bar(actual_tmc, projected_tmc)
    return f"{CYAN}-{save_pct:.0f}%{RESET} {bar} {CYAN}↓{_fmt_tok(saved)}{RESET} {raw}"


def _mcp_needs_restart(transcript_path: str) -> bool:
    """True if .mcp.json was written after the current CC session started."""
    try:
        if not transcript_path or not os.path.exists(transcript_path):
            return False
        session_start = os.path.getctime(transcript_path)
        for p in [Path.home() / ".mcp.json", Path(os.getcwd()) / ".mcp.json"]:
            if p.exists() and p.stat().st_mtime > session_start:
                return True
    except Exception:
        pass
    return False


def _mcp_project_name() -> str:
    """Return TALON_PROJECT_ID from .mcp.json if set, else empty string."""
    try:
        for p in [Path(os.getcwd()) / ".mcp.json", Path.home() / ".mcp.json"]:
            if p.exists():
                d = json.loads(p.read_text())
                pid = d.get("mcpServers", {}).get("talon", {}).get("env", {}).get("TALON_PROJECT_ID", "")
                if pid:
                    return pid
                # Fall back to dir name from project path arg if present (skip URLs)
                args = d.get("mcpServers", {}).get("talon", {}).get("args", [])
                for arg in args:
                    if arg.startswith("http"):
                        continue
                    if "/" in arg or arg.startswith("."):
                        return Path(arg).name
    except Exception:
        pass
    return Path(os.getcwd()).name


def _mcp_check_status() -> dict:
    """Read ~/.talon/mcp_status.json written by `talon check`. Returns {} if absent/stale."""
    try:
        p = Path.home() / ".talon" / "mcp_status.json"
        if not p.exists():
            return {}
        d = json.loads(p.read_text())
        # Accept status written within the last 2 hours
        if time.time() - d.get("checked_at", 0) > 7200:
            return {}
        return d
    except Exception as exc:
        _diag_log("mcp_status_read_failed", error=type(exc).__name__, msg=str(exc)[:200])
        return {}


def _mcp_status_badge(data: dict, transcript_path: str = "") -> str:
    """MCP connection badge — truth from talon check result, then tool-call fallback."""
    if not _talon_mcp_configured():
        return ""

    # Restart needed — .mcp.json written after this CC session started
    if _mcp_needs_restart(transcript_path):
        return f"\033[31mMCP: \u2717 restart CC{RESET}"

    tool_names = data.get("tool_names", [])
    talon_seen = any(t in TALON_TOOLS for t in tool_names)

    project = _mcp_project_name()
    label = f" {DIM}{project}{RESET}" if project else ""

    # Talon tool was called this session — definitely connected
    if talon_seen:
        return f"{GREEN}MCP: \u2713{label}{RESET}"

    # talon check wrote a verified status — use it as truth
    status = _mcp_check_status()
    if status.get("ok"):
        pid = status.get("project_id", "") or project
        plabel = f" {DIM}{pid}{RESET}" if pid else ""
        return f"{GREEN}MCP: \u2713{plabel}{RESET}"

    # No verified status yet and lots of non-talon coding work — likely disconnected
    n_turns = data.get("n_turns", 0)
    if n_turns >= 5 and len(tool_names) >= 5:
        return f"\033[31mMCP: \u2717 not connected{RESET}"

    return f"{DIM}MCP: …{label}{RESET}"


def _graph_health_badge() -> str:
    """Return 'Graph: X%' badge from cached graph_health.json (refreshed every 30 min by prompt hook)."""
    try:
        p = Path.home() / ".talon" / "graph_health.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        # Show stale data up to 2 hours old (hook refreshes at 30 min)
        if time.time() - d.get("checked_at", 0) > 7200:
            return ""
        state_pct = d.get("state_pct", 0)
        action = d.get("action", "")
        if state_pct >= 99:
            return f"{GREEN}Graph: {state_pct}%{RESET}"
        if state_pct > 0:
            return f"{YELLOW}Graph: {state_pct}% \u26a0 {action}{RESET}"
        return f"\033[31mGraph: {state_pct}% \u26a0 {action}{RESET}"
    except Exception as exc:
        _diag_log("graph_health_badge_failed", error=type(exc).__name__, msg=str(exc)[:200])
    return ""


def _upgrade_badge() -> str:
    """Return '⬆ X.Y.Z' badge if a newer version is available, else empty string."""
    try:
        p = Path.home() / ".talon" / "update.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        if not d.get("available", False):
            return ""
        # Ignore stale cache (older than 24 hours)
        if time.time() - d.get("checked_at", 0) > 86400:
            return ""
        latest = d.get("latest", "")
        if not latest:
            return ""
        # Re-check against actual installed version — cache may be stale post-upgrade
        try:
            from talon import __version__ as installed
            inst_t = tuple(int(x) for x in installed.split("."))
            late_t = tuple(int(x) for x in latest.split("."))
            if inst_t >= late_t:
                return ""
        except Exception:
            pass
        return f"\033[38;5;214m\u2b06 {latest}\033[0m"
    except Exception as exc:
        _diag_log("upgrade_badge_failed", error=type(exc).__name__, msg=str(exc)[:200])
    return ""


def _inbox_badge() -> str:
    """Return '✉ N' badge if there are unread support messages, else empty string."""
    try:
        p = Path.home() / ".talon" / "inbox.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        # Ignore stale cache (older than 2 hours)
        if time.time() - d.get("updated_at", 0) > 7200:
            return ""
        unread = d.get("unread", 0)
        if unread > 0:
            return f"\033[38;5;208m✉ {unread}\033[0m"
    except Exception:
        pass
    return ""


def _savings_badge_enabled() -> bool:
    """Check ~/.talon/config.yaml for statusline.show_savings (default True)."""
    try:
        import yaml
        cfg_path = Path.home() / ".talon" / "config.yaml"
        if cfg_path.exists():
            cfg = yaml.safe_load(cfg_path.read_text()) or {}
            return bool(cfg.get("statusline", {}).get("show_savings", True))
    except Exception:
        pass
    return True


def _savings_badge() -> str:
    """Return cache savings badge from ~/.talon/score.json if enabled in config."""
    if not _savings_badge_enabled():
        return ""
    try:
        score_path = Path.home() / ".talon" / "score.json"
        if not score_path.exists():
            return ""
        d = json.loads(score_path.read_text())
        age = time.time() - d.get("updated_at", 0)
        if age > 7200:
            return ""
        savings_pct = d.get("savings_pct", 0.0)
        savings_usd = d.get("savings_usd", 0.0)
        if savings_pct <= 0:
            return ""
        if savings_usd > 0:
            return f"{CYAN}-{savings_pct:.0f}% cache ${savings_usd:.3f} saved{RESET}"
        return f"{CYAN}-{savings_pct:.0f}% cache{RESET}"
    except Exception:
        pass
    return ""


def main() -> None:
    try:
        raw = sys.stdin.read()
        cc_data = json.loads(raw) if raw.strip() else {}
    except Exception:
        cc_data = {}

    data = _parse_transcript(cc_data)
    parts = []

    parts.append(_cogmeta_score(data))

    mcp = _mcp_status_badge(data, transcript_path=cc_data.get("transcript_path", ""))
    if mcp:
        parts.append(mcp)

    graph = _graph_health_badge()
    if graph:
        parts.append(graph)

    upgrade = _upgrade_badge()
    if upgrade:
        parts.append(upgrade)

    badge = _inbox_badge()
    if badge:
        parts.append(badge)

    savings = _savings_badge()
    if savings:
        parts.append(savings)

    n_turns = data.get("n_turns", 0)
    actual_tmc = data.get("actual_tmc", 0)
    if n_turns > 0:
        parts.append(f"{NEON}{n_turns}t {_fmt_tok(actual_tmc)}{RESET}")

    print(" | ".join(parts))


if __name__ == "__main__":
    main()
