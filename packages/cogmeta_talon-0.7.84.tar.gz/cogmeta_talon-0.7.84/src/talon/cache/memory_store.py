"""In-memory source cache for proxy_wrapper local-fast-path lookups.

Backs `_srb_local`, `_srb_lookup_symbol`, and `_inject_gal_bodies` with a
flat file-line array and a symbol index built from a lightweight regex
pass over the project source. The richer ranking and search algorithms
live server-side; this is the offline-fast-path only.

Class name `MemoryStore` is retained for backward-compat with existing
import sites; this is a plain local cache.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS: frozenset[str] = frozenset({".py", ".ts", ".tsx"})

_PY_SYMBOL_RE = re.compile(
    r"^(?P<indent>[ \t]*)(?:async\s+)?(?P<type>def|class)\s+(?P<name>\w+)",
    re.MULTILINE,
)
_TS_SYMBOL_RE = re.compile(
    r"^(?P<indent>[ \t]*)(?:export\s+)?(?:async\s+)?(?P<type>function|class)\s+(?P<name>\w+)",
    re.MULTILINE,
)
_SYMBOL_REGEX_MAP: dict[str, re.Pattern[str]] = {
    ".py": _PY_SYMBOL_RE,
    ".ts": _TS_SYMBOL_RE,
    ".tsx": _TS_SYMBOL_RE,
}

_SKIP_DIRS: frozenset[str] = frozenset({
    "node_modules", "__pycache__", ".git", "venv", ".venv", "dist", "build",
})


class MemoryStore:
    """Local file cache: file → lines plus a flat symbol index."""

    def __init__(self) -> None:
        self._lines: dict[str, list[str]] = {}
        self._index: dict[str, list[tuple[str, int]]] = {}
        self._file_symbols: dict[str, list[dict[str, Any]]] = {}

    @staticmethod
    def _discover_files(project_path: Path) -> list[str]:
        result: list[str] = []
        root = str(project_path)
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [
                d for d in dirnames
                if not d.startswith(".") and d not in _SKIP_DIRS
            ]
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                if ext in SUPPORTED_EXTENSIONS:
                    abs_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(abs_path, root).replace(os.sep, "/")
                    result.append(rel_path)
        return sorted(result)

    @staticmethod
    def _extract_symbols(file_path: str, lines: list[str]) -> list[dict[str, Any]]:
        ext = os.path.splitext(file_path)[1].lower()
        pattern = _SYMBOL_REGEX_MAP.get(ext)
        if pattern is None:
            return []
        content = "\n".join(lines)
        matches = list(pattern.finditer(content))
        symbols: list[dict[str, Any]] = []
        current_class: str | None = None
        class_indent: int = -1
        for i, m in enumerate(matches):
            line_start = content[: m.start()].count("\n") + 1
            indent = len(m.group("indent").replace("\t", "    "))
            sym_type_raw = m.group("type")
            if i + 1 < len(matches):
                next_start = content[: matches[i + 1].start()].count("\n") + 1
                line_end = max(next_start - 1, line_start)
            else:
                line_end = len(lines)
            class_name: str | None = None
            if sym_type_raw == "class":
                current_class = m.group("name")
                class_indent = indent
                sym_type = "class"
            elif sym_type_raw in ("def", "function"):
                if current_class is not None and indent > class_indent:
                    sym_type = "method"
                    class_name = current_class
                else:
                    sym_type = "function"
                    if indent <= class_indent:
                        current_class = None
                        class_indent = -1
            else:
                sym_type = "function"
            symbols.append({
                "name": m.group("name"),
                "line_start": line_start,
                "line_end": line_end,
                "type": sym_type,
                "class_name": class_name,
            })
        return symbols

    def _index_symbols(self, file_path: str, symbols: list[dict[str, Any]]) -> None:
        self._file_symbols[file_path] = symbols
        for sym in symbols:
            self._index.setdefault(sym["name"], []).append((file_path, sym["line_start"]))

    def _remove_from_index(self, file_path: str) -> None:
        dead: list[str] = []
        for name, locs in self._index.items():
            self._index[name] = [(fp, ln) for fp, ln in locs if fp != file_path]
            if not self._index[name]:
                dead.append(name)
        for k in dead:
            del self._index[k]
        self._file_symbols.pop(file_path, None)

    def build(self, project_path: Path, file_paths: list[str] | None = None) -> None:
        """Walk *project_path* and load all supported files into the cache."""
        if file_paths is None:
            file_paths = self._discover_files(project_path)
        for rel_path in file_paths:
            abs_path = project_path / rel_path
            try:
                content = abs_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            lines = content.splitlines()
            self._lines[rel_path] = lines
            self._index_symbols(rel_path, self._extract_symbols(rel_path, lines))

    def get_lines(self, file_path: str, start: int, end: int) -> list[str]:
        """1-indexed inclusive line slice; empty list on miss or out-of-range."""
        lines = self._lines.get(file_path)
        if lines is None:
            return []
        lo = max(start - 1, 0)
        hi = min(end, len(lines))
        return lines[lo:hi]

    def locate_symbol(self, name: str) -> list[tuple[str, int]]:
        """Exact-match symbol lookup → list of (file, line)."""
        return list(self._index.get(name, []))

    def locate_symbol_fuzzy(
        self, query: str, *, max_results: int = 20
    ) -> list[tuple[str, int, str]]:
        """Local fast-path: exact match only. Ranked fuzzy lives server-side;
        a miss here forwards to the cloud SRB on the next hop."""
        exact = self._index.get(query)
        if not exact:
            return []
        return [(fp, ln, "exact") for fp, ln in exact[:max_results]]

    def get_symbol_at(self, file_path: str, line: int) -> dict[str, Any] | None:
        """Symbol whose line-range contains *line*, or None."""
        for sym in self._file_symbols.get(file_path, []):
            if sym["line_start"] <= line <= sym["line_end"]:
                return dict(sym)
        return None

    def refresh_file(self, file_path: str, content: str) -> None:
        """Re-load a single file into the cache after edit_batch writes it."""
        self._remove_from_index(file_path)
        lines = content.splitlines()
        self._lines[file_path] = lines
        self._index_symbols(file_path, self._extract_symbols(file_path, lines))

    @property
    def file_count(self) -> int:
        return len(self._lines)

    @property
    def symbol_count(self) -> int:
        return sum(len(locs) for locs in self._index.values())
