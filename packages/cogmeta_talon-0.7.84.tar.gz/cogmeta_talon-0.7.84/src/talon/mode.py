"""Alpha S2 — `talon mode` config (default | strict | yolo).

Closes R-CLIENT-MODE-DEFAULT-VS-YOLO. Reads/writes `~/.talon/config.yaml`
under the `mode:` key. Hook scripts dispatch on the active mode value.

Three canonical modes:
    default   — moderate enforcement: nudges, blocks known anti-patterns,
                preserves legitimate workflows. THIS IS THE ALPHA DEFAULT
                and the only mode the customer-facing landing page
                recommends.
    strict    — opt-in zero-regression: blocks any tool call where the
                blast-radius hint flags risk. Slower but predictable.
    yolo      — opt-in for power users / benchmark runs: no client-side
                enforcement, all decisions go to the LLM. NEVER ship as
                default in any pre-set config; CI lint refuses promotion.

Resolution order (first match wins):
    1. `--talon-mode <m>` flag if the active CLI parses it (per-call override)
    2. `TALON_MODE` env var
    3. `~/.talon/config.yaml`  → `mode: <m>`
    4. canonical default → "default"

Public API:
    get_mode()              -> str — resolves the active mode
    set_mode(mode)          -> None — writes ~/.talon/config.yaml
    is_strict()             -> bool — convenience for hook scripts
    is_yolo()               -> bool — convenience for hook scripts
    VALID_MODES             -> tuple[str, ...]
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

VALID_MODES = ("default", "strict", "yolo")
_CONFIG_PATH = Path.home() / ".talon" / "config.yaml"
_DEFAULT_MODE = "default"

_CACHED: str | None = None


def _config_path() -> Path:
    """Override-able for tests."""
    override = os.environ.get("TALON_CONFIG_PATH")
    if override:
        return Path(override)
    return _CONFIG_PATH


def _read_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        import yaml  # type: ignore[import-untyped]
        data = yaml.safe_load(path.read_text()) or {}
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        logger.debug("config.yaml read failed: %s", exc)
        return {}


def _write_yaml(path: Path, data: dict) -> None:
    """Best-effort atomic-ish write of the config file."""
    import yaml  # type: ignore[import-untyped]
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(yaml.safe_dump(data, sort_keys=True))
    os.replace(tmp, path)


def get_mode() -> str:
    """Resolve the active mode. Cached until `clear_cache()` is called."""
    global _CACHED
    if _CACHED is not None:
        return _CACHED

    env_val = (os.environ.get("TALON_MODE") or "").strip().lower()
    if env_val in VALID_MODES:
        _CACHED = env_val
        return _CACHED

    data = _read_yaml(_config_path())
    cfg_val = str(data.get("mode") or "").strip().lower()
    if cfg_val in VALID_MODES:
        _CACHED = cfg_val
        return _CACHED

    _CACHED = _DEFAULT_MODE
    return _CACHED


def set_mode(mode: str) -> str:
    """Persist *mode* to ~/.talon/config.yaml. Returns the canonicalised mode.

    Raises ValueError on unknown modes — defensive against typos.
    """
    canonical = (mode or "").strip().lower()
    if canonical not in VALID_MODES:
        raise ValueError(
            f"unknown mode: {mode!r}; valid modes: {', '.join(VALID_MODES)}"
        )
    path = _config_path()
    data = _read_yaml(path)
    data["mode"] = canonical
    _write_yaml(path, data)
    clear_cache()
    return canonical


def clear_cache() -> None:
    """Drop the cached resolution. Used by tests + after set_mode."""
    global _CACHED
    _CACHED = None


def is_strict() -> bool:
    return get_mode() == "strict"


def is_yolo() -> bool:
    return get_mode() == "yolo"


def is_default() -> bool:
    return get_mode() == "default"


def explain_mode() -> str:
    """Multi-line description suitable for `talon mode` (no args) output."""
    current = get_mode()
    cfg_exists = _config_path().exists()
    env_set = bool(os.environ.get("TALON_MODE"))
    lines = [
        f"talon mode: {current}",
        "",
        "  default — moderate enforcement (recommended)",
        "  strict  — zero-regression edits; blocks risky writes",
        "  yolo    — no enforcement; benchmark / power-user only",
        "",
        f"  config:  {_config_path()}{'' if cfg_exists else ' (not yet written)'}",
        f"  env:     TALON_MODE = {os.environ.get('TALON_MODE') or '(unset)'}",
        "",
        "  set:     talon mode set <default|strict|yolo>",
    ]
    if env_set:
        lines.append("  note:    TALON_MODE is set in the environment and overrides config.yaml")
    return "\n".join(lines)
