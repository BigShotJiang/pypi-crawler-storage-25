"""Talon — Context intelligence for Agentic Development."""

__version__ = "0.7.83"
