"""talon-index — parse a project locally and upload the graph to cogmeta.ai cloud.

Walks the project directory, parses Python and TypeScript files using tree-sitter,
then POSTs the parsed graph data to the cloud API.

The graph (intent routing, callers, blast, flow) is stored and served server-side.
This binary only does the parsing — no database credentials needed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import ssl
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from talon.config.env import EnvVar, get_required as _env_get
from talon._ua import talon_ua

logger = logging.getLogger(__name__)

# Tree-sitter is heavyweight (~50ms + native lib). Defer the parser import to
# the functions that actually parse, so `talon-index --help` returns instantly
# and any non-parsing CLI dispatch path (e.g. early arg validation) doesn't
# pay the cost. Type annotations on functions reference ParseResult by name —
# `from __future__ import annotations` (line 10) makes those strings, so no
# import is required at module load to type-check.

_CREDS_PATH = Path.home() / ".talon" / "credentials.json"

SKIP_DIRS: set[str] = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", ".env",
    "dist", "build", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "egg-info", ".eggs", "legacy",
}


def _should_skip_dir(dirname: str) -> bool:
    return dirname in SKIP_DIRS or dirname.startswith(".")


def discover_files(project_path: str) -> list[str]:
    from talon.indexer.parser import SUPPORTED_EXTENSIONS  # deferred import — see top-of-file note
    files: list[str] = []
    project_path = os.path.abspath(project_path)
    for root, dirs, filenames in os.walk(project_path):
        dirs[:] = [d for d in dirs if not _should_skip_dir(d)]
        for filename in sorted(filenames):
            ext = os.path.splitext(filename)[1].lower()
            if ext in SUPPORTED_EXTENSIONS:
                full_path = os.path.join(root, filename)
                files.append(os.path.relpath(full_path, project_path))
    return sorted(files)


def _parse_one(
    full_path: str, rel_path: str, project_id: str,
) -> tuple[str, "ParseResult | None", BaseException | None]:  # type: ignore[name-defined]
    """Read + parse one file. Returns (rel_path, result_or_None, exc_or_None)."""
    from talon.indexer.parser import parse_file  # deferred — heavy tree-sitter import
    try:
        with open(full_path, "rb") as f:
            source = f.read()
    except (OSError, PermissionError) as e:
        logger.warning("Could not read %s: %s", rel_path, e)
        return rel_path, None, e
    try:
        result = parse_file(source, rel_path, project_id)
        result.file_node.hash = hashlib.sha256(source).hexdigest()
        stat = os.stat(full_path)
        result.file_node.last_modified = time.strftime(
            "%Y-%m-%dT%H:%M:%S", time.gmtime(stat.st_mtime)
        )
        return rel_path, result, None
    except Exception as exc:
        return rel_path, None, exc


def parse_project(project_path: str, project_id: str) -> list["ParseResult"]:  # type: ignore[name-defined]
    # 04_performance.md [HIGH] CLI indexer single-threaded parse — RESOLVED:
    # tree-sitter releases the GIL inside its native parser, so a thread pool
    # actually scales. Default = max(2, cpu_count() - 1) so the host stays
    # responsive but a 1k-file repo isn't a 50s sequential wait. Override via
    # TALON_INDEX_WORKERS for benchmarking.
    from talon.indexer.parser import ParseResult  # deferred — heavy tree-sitter import
    project_path = os.path.abspath(project_path)
    files = discover_files(project_path)
    if not files:
        return []
    try:
        _default = max(2, (os.cpu_count() or 4) - 1)
        max_workers = int(os.environ.get("TALON_INDEX_WORKERS", _default))
    except ValueError:
        max_workers = max(2, (os.cpu_count() or 4) - 1)

    results: list[ParseResult] = []
    parse_failures = 0
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [
            pool.submit(_parse_one, os.path.join(project_path, rel), rel, project_id)
            for rel in files
        ]
        for fut in as_completed(futures):
            rel_path, result, exc = fut.result()
            if exc is not None and result is None:
                if not isinstance(exc, (OSError, PermissionError)):
                    parse_failures += 1
                    logger.warning("Failed to parse %s: %s", rel_path, exc)
                continue
            if result is not None:
                results.append(result)

    # Emit IDX-001 if parse-failure rate is materially high. Threshold: 10%.
    if files and parse_failures / max(len(files), 1) > 0.10:
        try:
            from talon import diag as _diag
            fault = _diag.FAULT_CATALOG.get("IDX-001")
            if fault is not None:
                _diag.emit(
                    fault,
                    {"failed": parse_failures, "total": len(files),
                     "rate_pct": round(100 * parse_failures / len(files), 1)},
                    logger=logger,
                    show_user=True,
                    log_path=str(_diag.LOG_DIR / "indexer.log"),
                )
        except Exception:
            pass
    return results


def _serialize_results(results: list[ParseResult]) -> list[dict]:
    """Serialize ParseResult objects to JSON-safe dicts."""
    out = []
    for r in results:
        out.append({
            "file": r.file_node.model_dump(by_alias=True),
            "module": r.module_node.model_dump(by_alias=True),
            "classes": [c.model_dump(by_alias=True) for c in r.classes],
            "functions": [f.model_dump(by_alias=True) for f in r.functions],
            "imports": [i.model_dump(by_alias=True) for i in r.imports],
            "call_edges": list(r.call_edges),
            "method_chains": list(r.method_chains),
            "attr_type_map": r.attr_type_map,
        })
    return out


def _fetch_graph_stats(cloud_url: str, api_key: str, project_id: str, retries: int = 6, interval: float = 5.0) -> dict | None:
    """Poll GET /cloud/v1/projects/{project_id}/stats until files > 0 (or timeout)."""
    url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/stats"
    headers = {"X-API-Key": api_key}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={**headers, "User-Agent": talon_ua()})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            if data.get("files", 0) > 0:
                return data
        except Exception:
            pass
        if attempt < retries - 1:
            time.sleep(interval)
    return None


_UPLOAD_CHUNK_SIZE = 100   # files per request — ~7-10 MB per batch
_UPLOAD_WORKERS = 8        # parallel chunk uploads


_INGEST_POLL_INTERVAL_S = 1.0
_INGEST_POLL_MAX_WAIT_S = 180


def _register_local_project(
    cloud_url: str,
    api_key: str,
    project_id: str,
    *,
    timeout_s: int = 15,
) -> None:
    """Pre-register the project_id with the cloud before pushing chunks.

    Wave 4 ownership re-verify on the cloud refuses any chunk write whose
    (project_id, user_id) pair is not in talon_project_repos. For local
    indexes (no git URL), the standard add_project endpoint is unavailable.
    POST /cloud/v1/projects/register-local fills that gap.

    Idempotent on the server side, so re-running `talon index` is cheap.
    Failures here are surfaced to the user — a missing registration row will
    fail the upload with a less actionable error.
    """
    url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/register-local"
    payload = json.dumps({
        "project_id": project_id,
        "display_name": project_id,
    }).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "X-API-Key": api_key,
            "User-Agent": talon_ua(),
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        if resp.status not in (200, 201):
            raise RuntimeError(f"register-local returned HTTP {resp.status}")


def _poll_ingest_status(
    cloud_url: str,
    api_key: str,
    job_id: str,
    ssl_ctx: "ssl.SSLContext | None" = None,
) -> dict:
    """Poll /cloud/v1/projects/index-data/status/{job_id} until terminal.

    The v2 ingest path returns 202 + job_id; the actual Arango writes happen
    on a separate cogz-ingest worker process. This loop waits until the
    worker reports done/failed/unknown so the caller's "all data is in the
    graph by the time this returns" semantics match the legacy v1 sync path.

    `unknown` means the status hash TTL'd out — treat as completed.
    """
    deadline = time.time() + _INGEST_POLL_MAX_WAIT_S
    last: dict = {}
    while time.time() < deadline:
        url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/index-data/status/{job_id}"
        req = urllib.request.Request(
            url,
            headers={"X-API-Key": api_key, "User-Agent": talon_ua()},
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=10, context=ssl_ctx) as resp:
                last = json.loads(resp.read())
        except Exception:
            time.sleep(_INGEST_POLL_INTERVAL_S)
            continue
        state = last.get("state", "queued")
        if state in ("done", "unknown"):
            return last
        if state == "failed":
            raise RuntimeError(
                f"cloud ingest failed (job {job_id}): "
                f"{last.get('error', 'no error message')}"
            )
        time.sleep(_INGEST_POLL_INTERVAL_S)
    raise RuntimeError(
        f"cloud ingest stuck (job {job_id}, last_state={last.get('state','?')}, "
        f"after {_INGEST_POLL_MAX_WAIT_S}s)"
    )


def _upload_chunk(
    cloud_url: str,
    api_key: str,
    project_id: str,
    project_path: str,
    chunk: list[dict],
    ssl_ctx: "ssl.SSLContext | None" = None,
) -> dict:
    """POST one chunk via the v2 async-ingest path, then poll until done.

    Why v2: the v1 handler ran the bulk-upsert work on the cogz-api event
    loop, which serialised concurrent uploads through one worker and hit
    the ALB 60s upstream timeout for big repos. v2 returns 202 in <1s
    regardless of payload size; the work runs on a separate cogz-ingest
    process that XREADGROUP's from a Redis Stream.
    """
    payload = json.dumps({
        "project_id": project_id,
        "project_path": project_path,
        "files": chunk,
    }).encode()
    req = urllib.request.Request(
        f"{cloud_url.rstrip('/')}/cloud/v1/projects/index-data-v2",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "X-API-Key": api_key,
            "User-Agent": talon_ua(),
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120, context=ssl_ctx) as resp:
        body = json.loads(resp.read())
    job_id = body.get("job_id")
    if not job_id:
        raise RuntimeError(f"v2 response missing job_id: {body}")
    # Block until this chunk's ingest finishes. We poll per-chunk (not
    # pipelined across chunks) so the caller's "graph populated by the
    # time this returns" guarantee matches the legacy sync path.
    final = _poll_ingest_status(cloud_url, api_key, job_id, ssl_ctx=ssl_ctx)
    return {
        "files": int(final.get("files_indexed", len(chunk))),
        "job_id": job_id,
        "duration_ms": final.get("duration_ms"),
    }


def _upload(
    cloud_url: str,
    api_key: str,
    project_id: str,
    project_path: str,
    graph_data: list[dict],
) -> dict:
    """POST parsed graph data to the cloud API in parallel chunks."""
    ssl_ctx: ssl.SSLContext | None = None
    if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE

    chunks = [graph_data[i:i + _UPLOAD_CHUNK_SIZE] for i in range(0, len(graph_data), _UPLOAD_CHUNK_SIZE)]
    n = len(chunks)
    if n > 1:
        print(f"  Uploading {len(graph_data)} files in {n} batches ({_UPLOAD_WORKERS} parallel)...")

    total_files = 0
    last_result: dict = {}
    workers = min(_UPLOAD_WORKERS, n)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_upload_chunk, cloud_url, api_key, project_id, project_path, chunk, ssl_ctx): i
            for i, chunk in enumerate(chunks)
        }
        completed = 0
        for fut in as_completed(futures):
            result = fut.result()  # raises on HTTP error
            total_files += result.get("files", 0)
            last_result = result
            completed += 1
            if n > 1:
                print(f"  Batch {completed}/{n} done")

    last_result["files"] = total_files
    return last_result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Index a project into the cogmeta.ai cloud graph",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  talon-index                          # Index current directory
  talon-index /path/to/project
  talon-index . --project-id my-app
        """,
    )
    parser.add_argument("project_path", nargs="?", default=None,
                        help="Path to project root (default: current directory)")
    parser.add_argument("--project-id", help="Project identifier (default: directory name)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    # Hand the indexer logger to the diag rotating file handler. --verbose
    # forces debug mode for this run only (TALON_DEBUG / config persists in
    # other processes — this flag is one-shot).
    if args.verbose:
        try:
            from talon import diag as _diag
            _diag.set_debug_override(True)
        except Exception:
            pass
    try:
        from talon import diag as _diag
        _idx_logger = _diag.setup("indexer", also_stderr=True)
        # Route the module-level `logger` writes to the indexer log too.
        for handler in _idx_logger.handlers:
            logger.addHandler(handler)
        logger.setLevel(_idx_logger.level)
    except Exception:
        # Diag unavailable — preserve original behavior so indexing still works
        level = logging.DEBUG if args.verbose else logging.INFO
        logging.basicConfig(level=level,
                            format="%(asctime)s [%(levelname)s] %(message)s",
                            stream=sys.stderr)

    project_path = os.path.abspath(args.project_path or os.getcwd())
    project_id = args.project_id or os.path.basename(project_path)

    if not os.path.isdir(project_path):
        print(f"Error: {project_path} is not a directory", file=sys.stderr)
        sys.exit(1)

    # Fail-fast: check there are actually source files here before spending time indexing
    source_files = discover_files(project_path)
    if not source_files:
        from talon.indexer.parser import SUPPORTED_EXTENSIONS  # deferred — see top-of-file note
        supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        print(
            f"Error: no source files found in {project_path}\n"
            f"  Supported: {supported}\n"
            f"  Are you in the right directory? Try: cd <your-project> && talon index",
            file=sys.stderr,
        )
        sys.exit(1)
    print(f"Found {len(source_files)} source file(s) in {project_path}")

    # Load credentials
    if not _CREDS_PATH.exists():
        print("Not logged in. Run: /talon login", file=sys.stderr)
        sys.exit(1)

    try:
        creds = json.loads(_CREDS_PATH.read_text())
    except Exception as e:
        print(f"Error reading credentials: {e}", file=sys.stderr)
        sys.exit(1)

    # Try silent renewal before using the key
    try:
        from talon.mcp.setup_cli import _maybe_renew_api_key, _check_session_valid
        if not _check_session_valid():
            sys.exit(1)
        if _maybe_renew_api_key(creds):
            creds = json.loads(_CREDS_PATH.read_text())
    except Exception:
        pass

    api_key = creds.get("api_key", "")
    cloud_url = os.environ.get("TALON_INDEX_URL") or creds.get("cloud_url") or _env_get(EnvVar.CLOUD_URL)
    if not api_key:
        print("No API key found. Run: /talon login", file=sys.stderr)
        sys.exit(1)

    # Parse
    print(f"Parsing {project_path}...")
    start = time.monotonic()
    results = parse_project(project_path, project_id)
    parse_time = time.monotonic() - start

    if not results:
        print("No supported files found (.py, .ts, .tsx)", file=sys.stderr)
        sys.exit(1)

    print(f"  Parsed {len(results)} files in {parse_time:.2f}s")

    # Pre-register so the chunk POSTs pass Wave 4 ownership re-verify.
    # Cheap on the cloud (idempotent ON CONFLICT) so we always call it.
    try:
        _register_local_project(cloud_url, api_key, project_id)
    except Exception as exc:
        print(f"Warning: register-local failed ({exc}); upload may fail ownership check", file=sys.stderr)

    # Upload
    print(f"Uploading graph to {cloud_url}...")
    upload_start = time.monotonic()
    try:
        graph_data = _serialize_results(results)
        result = _upload(cloud_url, api_key, project_id, project_path, graph_data)
        upload_time = time.monotonic() - upload_start
    except Exception as e:
        # Try to classify into a Fault (IDX-002 / IDX-004 / NET-*) so the user
        # sees an actionable code instead of a raw exception string.
        try:
            from talon import diag as _diag
            ctx = {"op": "index_upload", "url": cloud_url}
            # Pull out HTTP status if the exception carries one (HTTPError etc.)
            if hasattr(e, "code") and isinstance(e.code, int):
                ctx["http_status"] = e.code
            fault = _diag.classify(e, ctx)
            log_path = str(_diag.LOG_DIR / "indexer.log")
            if fault is not None:
                _diag.emit(fault, {"exc_type": type(e).__name__, "msg": str(e)[:200]},
                           logger=logger, show_user=True, log_path=log_path)
            else:
                logger.exception("Upload failed (unclassified)")
                print(f"Upload failed: {e}", file=sys.stderr)
                print(f"  Details: {log_path}", file=sys.stderr)
        except Exception:
            print(f"Upload failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Count what the parser found
    parsed_functions = sum(len(r.functions) for r in results)
    parsed_classes = sum(len(r.classes) for r in results)

    print(f"\nIndexing complete for project '{project_id}'")
    print(f"  Files:     {len(results)}")
    print(f"  Functions: {parsed_functions}  (parsed)")
    print(f"  Classes:   {parsed_classes}  (parsed)")
    print(f"  Parse:     {parse_time:.2f}s")
    print(f"  Upload:    {upload_time:.2f}s")
    print(f"  Total:     {parse_time + upload_time:.2f}s")

    # Graph-side verification — poll ArangoDB directly, compare with parsed counts
    print("\nVerifying graph...")
    stats = _fetch_graph_stats(cloud_url, api_key, project_id)
    if stats and stats.get("functions", 0) > 0:
        g_files = stats["files"]
        g_funcs = stats["functions"]
        g_classes = stats.get("classes", 0)
        g_edges = stats.get("edges", 0)

        # Compare parsed vs stored
        func_match = abs(g_funcs - parsed_functions) / max(parsed_functions, 1) < 0.05  # within 5%
        class_match = abs(g_classes - parsed_classes) / max(parsed_classes, 1) < 0.05

        print(f"  ✓ Graph confirmed — {g_files} files · {g_funcs} functions · "
              f"{g_classes} classes · {g_edges} edges")
        if not func_match:
            print(f"  ⚠ Function count mismatch: parsed {parsed_functions}, graph has {g_funcs}")
        if not class_match:
            print(f"  ⚠ Class count mismatch: parsed {parsed_classes}, graph has {g_classes}")
        if stats.get("last_indexed_at"):
            print(f"  Indexed at: {stats['last_indexed_at']}")
    elif stats and stats.get("files", 0) > 0:
        print(f"  ✗ Files in graph ({stats['files']}) but 0 functions — graph write incomplete")
        print(f"    Expected: {parsed_functions} functions, {parsed_classes} classes")
        print(f"    Re-run: talon index")
        sys.exit(1)
    else:
        print("  ⚠ Graph verification timed out — background write still in progress")
        print(f"    Expected: {parsed_functions} functions from {len(results)} files")
        print("    Re-run 'talon index' if MCP tools report empty results after a minute")
    print()


if __name__ == "__main__":
    main()
