"""Tree-sitter AST parser for Python and TypeScript source files.

Extracts structural code entities (modules, classes, functions, imports, calls)
from source files using tree-sitter grammars. Returns ParseResult dataclasses
that are written to the code graph.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field

import tree_sitter_python as tspython
import tree_sitter_typescript as tstypescript
from tree_sitter import Language, Parser

from talon.indexer.schema import (
    ClassNode,
    FileNode,
    FunctionNode,
    ImportNode,
    ModuleNode,
    make_key,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tree-sitter Language Initialization
# ---------------------------------------------------------------------------

PY_LANGUAGE = Language(tspython.language())
TS_LANGUAGE = Language(tstypescript.language_typescript())
TSX_LANGUAGE = Language(tstypescript.language_tsx())

SUPPORTED_EXTENSIONS: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
}


# ---------------------------------------------------------------------------
# ParseResult
# ---------------------------------------------------------------------------


@dataclass
class ParseResult:
    """Result of parsing a single source file."""

    file_node: FileNode
    module_node: ModuleNode
    classes: list[ClassNode] = field(default_factory=list)
    functions: list[FunctionNode] = field(default_factory=list)
    imports: list[ImportNode] = field(default_factory=list)
    call_edges: list[tuple[str, str]] = field(default_factory=list)
    # Stage 6 fields
    method_chains: list[tuple[str, str, str]] = field(default_factory=list)
    # (caller_name, inner_call, chained_method)
    attr_type_map: dict[str, dict[str, str]] = field(default_factory=dict)
    # {class_name: {attr_name: type_name}} from __init__
    dispatch_maps: list[tuple[str, list[str]]] = field(default_factory=list)
    # (dict_var_name, [func_name, ...])
    error_paths: list[dict] = field(default_factory=list)
    # {function, exception_type, is_handled, line, handler_function}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _node_text(node) -> str:  # noqa: ANN001
    """Get the UTF-8 text of a tree-sitter node."""
    return node.text.decode("utf-8") if node.text else ""


def _file_path_to_module(file_path: str, language: str) -> str:
    """Convert a file path to a module name.

    Python:  src/talon/indexer/parser.py  -> src.talon.indexer.parser
    TypeScript: src/components/App.tsx   -> src/components/App
    """
    if language == "python":
        # Strip .py extension and replace path separators with dots
        name = file_path.replace(os.sep, "/")
        if name.endswith(".py"):
            name = name[:-3]
        # Remove __init__ suffix for packages
        if name.endswith("/__init__"):
            name = name[:-9]
        return name.replace("/", ".")
    else:
        # TypeScript: strip .ts/.tsx extension, keep path separators
        name = file_path.replace(os.sep, "/")
        for ext in (".tsx", ".ts"):
            if name.endswith(ext):
                name = name[: -len(ext)]
                break
        return name


def _get_language_for_ext(ext: str) -> Language | None:
    """Return the tree-sitter Language for a file extension."""
    mapping = {
        ".py": PY_LANGUAGE,
        ".ts": TS_LANGUAGE,
        ".tsx": TSX_LANGUAGE,
    }
    return mapping.get(ext)


# ---------------------------------------------------------------------------
# Python AST Extraction
# ---------------------------------------------------------------------------


def _extract_python_docstring(block_node) -> str:  # noqa: ANN001
    """Extract docstring from the first statement of a block."""
    for child in block_node.children:
        if child.type == "expression_statement":
            expr = child.children[0] if child.children else None
            if expr and expr.type == "string":
                text = _node_text(expr)
                # Strip triple quotes
                for q in ('"""', "'''"):
                    if text.startswith(q) and text.endswith(q):
                        return text[3:-3].strip()
                return text.strip("\"'").strip()
        elif child.type in ("pass_statement", "comment"):
            continue
        else:
            break
    return ""


def _extract_python_decorators(node) -> list[str]:  # noqa: ANN001
    """Extract decorator names from a decorated_definition or directly from children."""
    decorators = []
    for child in node.children:
        if child.type == "decorator":
            # Decorator text is like "@staticmethod" — strip the @
            text = _node_text(child).lstrip("@").strip()
            decorators.append(text)
    return decorators


def _extract_python_params(params_node) -> list[str]:  # noqa: ANN001
    """Extract parameter names from a parameters node."""
    params = []
    for child in params_node.children:
        if child.type == "identifier":
            params.append(_node_text(child))
        elif child.type == "typed_parameter":
            for sub in child.children:
                if sub.type == "identifier":
                    params.append(_node_text(sub))
                    break
        elif child.type == "default_parameter" or child.type == "typed_default_parameter":
            for sub in child.children:
                if sub.type == "identifier":
                    params.append(_node_text(sub))
                    break
        elif child.type == "list_splat_pattern" or child.type == "dictionary_splat_pattern":
            for sub in child.children:
                if sub.type == "identifier":
                    name = _node_text(sub)
                    prefix = "*" if child.type == "list_splat_pattern" else "**"
                    params.append(prefix + name)
                    break
    return params


def _extract_python_return_type(func_node) -> str | None:  # noqa: ANN001
    """Extract the return type annotation from a function definition."""
    # The return type comes after -> token
    found_arrow = False
    for child in func_node.children:
        if child.type == "->" or _node_text(child) == "->":
            found_arrow = True
            continue
        if found_arrow and child.type == "type":
            return _node_text(child)
    return None


def _extract_python_class_bases(class_node) -> list[str]:  # noqa: ANN001
    """Extract base class names from a class_definition."""
    bases = []
    for child in class_node.children:
        if child.type == "argument_list":
            for arg in child.children:
                if arg.type == "identifier":
                    bases.append(_node_text(arg))
                elif arg.type == "attribute":
                    bases.append(_node_text(arg))
    return bases


def _extract_python_raises(func_node) -> list[str]:  # noqa: ANN001
    """Extract exception types from raise statements in a function body."""
    raises: list[str] = []

    def _walk(node) -> None:  # noqa: ANN001
        if node.type == "raise_statement":
            for child in node.children:
                if child.type == "call":
                    # raise ValueError("...")
                    func = child.children[0] if child.children else None
                    if func and func.type == "identifier":
                        raises.append(_node_text(func))
                    elif func and func.type == "attribute":
                        raises.append(_node_text(func))
                elif child.type == "identifier":
                    # raise exc (re-raise a variable)
                    raises.append(_node_text(child))
        # Don't recurse into nested function/class definitions
        if node.type not in ("function_definition", "class_definition") or node is func_node:
            for child in node.children:
                _walk(child)

    _walk(func_node)
    return list(dict.fromkeys(raises))  # deduplicate preserving order


def _extract_python_catches(func_node) -> list[str]:  # noqa: ANN001
    """Extract exception types from except clauses in a function body.

    Handles: except ValueError, except (ValueError, KeyError),
    except ValueError as e, except (ValueError, KeyError) as e.
    """
    catches: list[str] = []

    def _collect_exc_identifiers(node) -> None:  # noqa: ANN001
        """Recursively collect exception type identifiers from a node."""
        if node.type == "identifier":
            catches.append(_node_text(node))
        elif node.type == "attribute":
            catches.append(_node_text(node))
        elif node.type in ("tuple", "parenthesized_expression"):
            for sub in node.children:
                _collect_exc_identifiers(sub)

    def _extract_exc_types(node) -> None:  # noqa: ANN001
        """Extract exception type identifiers from an except_clause."""
        # AST structure varies:
        #   except ValueError:           -> identifier child
        #   except ValueError as e:      -> as_pattern > identifier + as_pattern_target
        #   except (A, B):               -> tuple child
        #   except (A, B) as e:          -> as_pattern > tuple + as_pattern_target
        found_except = False
        for child in node.children:
            if child.type == "except" or _node_text(child) == "except":
                found_except = True
                continue
            if child.type in (":", "block"):
                break
            if not found_except:
                continue
            if child.type == "as_pattern":
                # Extract types from the pattern, skip the alias (as_pattern_target)
                for sub in child.children:
                    if sub.type == "as_pattern_target":
                        continue  # skip alias like 'e'
                    if sub.type == "as" or _node_text(sub) == "as":
                        continue
                    _collect_exc_identifiers(sub)
            else:
                _collect_exc_identifiers(child)

    def _walk(node) -> None:  # noqa: ANN001
        if node.type == "except_clause":
            _extract_exc_types(node)
        # Don't recurse into nested function/class definitions
        if node.type not in ("function_definition", "class_definition") or node is func_node:
            for child in node.children:
                _walk(child)

    _walk(func_node)
    return list(dict.fromkeys(catches))  # deduplicate preserving order


def _extract_init_type_map(class_node, class_name: str) -> dict[str, str]:  # noqa: ANN001
    """Extract attribute type assignments from __init__ method.

    Scans for patterns like ``self.x = Type()`` or ``self.x: Type = ...``
    and returns ``{attr_name: type_name}``.
    """
    type_map: dict[str, str] = {}

    # Find __init__ method in class body
    for child in class_node.children:
        if child.type == "block":
            for block_child in child.children:
                func_node = None
                if block_child.type == "function_definition":
                    func_node = block_child
                elif block_child.type == "decorated_definition":
                    for sub in block_child.children:
                        if sub.type == "function_definition":
                            func_node = sub
                            break
                if func_node is None:
                    continue
                # Check if this is __init__
                name = ""
                for fc in func_node.children:
                    if fc.type == "identifier" and not name:
                        name = _node_text(fc)
                        break
                if name != "__init__":
                    continue
                # Scan __init__ body for self.x = Type() assignments
                for fc in func_node.children:
                    if fc.type == "block":
                        _scan_init_body(fc, type_map)
    return type_map


def _scan_init_body(block_node, type_map: dict[str, str]) -> None:  # noqa: ANN001
    """Scan __init__ block for self.attr = Type() assignments."""
    for stmt in block_node.children:
        if stmt.type == "expression_statement":
            expr = stmt.children[0] if stmt.children else None
            if expr and expr.type == "assignment":
                _extract_self_assignment(expr, type_map)
        elif stmt.type == "type_alias_statement":
            pass  # skip type aliases


def _extract_self_assignment(assign_node, type_map: dict[str, str]) -> None:  # noqa: ANN001
    """Extract self.x = Type() from an assignment node."""
    lhs = None
    rhs = None
    found_eq = False
    for child in assign_node.children:
        if child.type == "=" or _node_text(child) == "=":
            found_eq = True
            continue
        if not found_eq:
            lhs = child
        else:
            rhs = child
            break
    if lhs is None or rhs is None:
        return
    # LHS must be self.attr
    if lhs.type == "attribute":
        attr_text = _node_text(lhs)
        if attr_text.startswith("self."):
            attr_name = attr_text[5:]
            # RHS must be a call to a Type constructor: Type() or module.Type()
            if rhs.type == "call":
                func = rhs.children[0] if rhs.children else None
                if func:
                    if func.type == "identifier":
                        type_name = _node_text(func)
                        # Skip lowercase names (likely functions, not types)
                        if type_name[0:1].isupper():
                            type_map[attr_name] = type_name
                    elif func.type == "attribute":
                        # e.g., module.Type()
                        parts = _node_text(func).rsplit(".", 1)
                        if len(parts) == 2 and parts[1][0:1].isupper():
                            type_map[attr_name] = parts[1]


def _extract_python_dispatch_maps(root_node) -> list[tuple[str, list[str]]]:  # noqa: ANN001
    """Extract dispatch map patterns from module-level dict assignments.

    Detects patterns like::

        HANDLERS = {"a": handler_a, "b": handler_b}

    Returns list of (dict_var_name, [func_name, ...]).
    """
    dispatch_maps: list[tuple[str, list[str]]] = []

    for node in root_node.children:
        if node.type == "expression_statement":
            expr = node.children[0] if node.children else None
            if expr and expr.type == "assignment":
                _try_extract_dispatch(expr, dispatch_maps)
    return dispatch_maps


def _try_extract_dispatch(assign_node, dispatch_maps: list[tuple[str, list[str]]]) -> None:  # noqa: ANN001
    """Try to extract a dispatch map from an assignment."""
    lhs = None
    rhs = None
    found_eq = False
    for child in assign_node.children:
        if child.type == "=" or _node_text(child) == "=":
            found_eq = True
            continue
        if not found_eq and lhs is None:
            lhs = child
        elif found_eq and rhs is None:
            rhs = child
    if lhs is None or rhs is None:
        return
    if lhs.type != "identifier":
        return
    var_name = _node_text(lhs)
    if rhs.type != "dictionary":
        return
    # Extract function reference values from dict pairs
    func_names: list[str] = []
    for child in rhs.children:
        if child.type == "pair":
            # pair has key and value children
            children = [c for c in child.children if c.type not in (":", ",")]
            if len(children) >= 2:
                value = children[-1]
                if value.type == "identifier":
                    func_names.append(_node_text(value))
    if func_names:
        dispatch_maps.append((var_name, func_names))


def _extract_error_paths(func_node, caller_name: str) -> list[dict]:  # noqa: ANN001
    """Extract error path info from a function: raises and try/except blocks.

    Returns list of dicts with keys:
    - function: caller function name
    - exception_type: the exception class
    - is_handled: True if inside a try/except that catches it
    - line: line number of the raise/except
    """
    error_paths: list[dict] = []
    # Track which exception types are caught in this function
    caught_types: set[str] = set()

    def _walk_for_catches(node) -> None:  # noqa: ANN001
        if node.type == "except_clause":
            for child in node.children:
                if child.type == "identifier":
                    caught_types.add(_node_text(child))
                elif child.type == "as_pattern":
                    for sub in child.children:
                        if sub.type == "identifier":
                            caught_types.add(_node_text(sub))
                            break
        if node.type not in ("function_definition", "class_definition") or node is func_node:
            for child in node.children:
                _walk_for_catches(child)

    def _walk_for_raises(node) -> None:  # noqa: ANN001
        if node.type == "raise_statement":
            exc_type = ""
            for child in node.children:
                if child.type == "call":
                    func = child.children[0] if child.children else None
                    if func and func.type == "identifier":
                        exc_type = _node_text(func)
                elif child.type == "identifier":
                    exc_type = _node_text(child)
            if exc_type:
                error_paths.append({
                    "function": caller_name,
                    "exception_type": exc_type,
                    "is_handled": exc_type in caught_types or "Exception" in caught_types,
                    "line": node.start_point[0] + 1,
                })
        if node.type not in ("function_definition", "class_definition") or node is func_node:
            for child in node.children:
                _walk_for_raises(child)

    _walk_for_catches(func_node)
    _walk_for_raises(func_node)
    return error_paths


def _detect_method_chains(func_body_node, caller_name: str) -> list[tuple[str, str, str]]:  # noqa: ANN001
    """Detect method chain calls like get_data().process().

    Returns list of (caller_name, inner_call, chained_method).
    """
    chains: list[tuple[str, str, str]] = []

    def _walk(node) -> None:  # noqa: ANN001
        if node.type == "call":
            func = node.children[0] if node.children else None
            if func and func.type == "attribute":
                # attribute node: object.method
                obj = func.children[0] if func.children else None
                method_id = None
                for child in func.children:
                    if child.type == "identifier":
                        method_id = child
                # Check if object is itself a call (method chain)
                if obj and obj.type == "call":
                    inner_func = obj.children[0] if obj.children else None
                    if inner_func and method_id:
                        inner_name = _node_text(inner_func)
                        chained_method = _node_text(method_id)
                        chains.append((caller_name, inner_name, chained_method))
        for child in node.children:
            _walk(child)

    _walk(func_body_node)
    return chains


def _collect_python_calls(node, calls: list[str]) -> None:  # noqa: ANN001
    """Recursively collect function call names from a subtree.

    Q+ blocker fix (b): when TALON_EXP_INDEXER_ATTR_CALL_EDGES=1, attribute
    calls like `obj.method()` ALSO emit the bare LHS `obj` so the call edge
    resolves to the underlying function vertex. Catches the django-11333
    shape where `clear_url_caches()` calls `get_resolver.cache_clear()` —
    without the bare-`get_resolver` edge, inbound caller queries miss the
    dependency entirely.
    """
    if node.type == "call":
        func_node = node.children[0] if node.children else None
        if func_node:
            if func_node.type == "identifier":
                calls.append(_node_text(func_node))
            elif func_node.type == "attribute":
                full = _node_text(func_node)
                calls.append(full)
                import os as _os_qp
                if _os_qp.environ.get("TALON_EXP_INDEXER_ATTR_CALL_EDGES", "").strip().lower() in ("1", "true", "yes", "on"):
                    for child in func_node.children:
                        if child.type == "identifier":
                            lhs = _node_text(child)
                            if lhs and "." not in lhs and lhs != full:
                                calls.append(lhs)
                            break
                        if child.type == ".":
                            break
    for child in node.children:
        _collect_python_calls(child, calls)


def _parse_python_function(
    func_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    class_name: str | None,
    decorators: list[str],
    is_method: bool,
) -> FunctionNode:
    """Parse a function_definition node into a FunctionNode."""
    name = ""
    params: list[str] = []
    return_type: str | None = None
    is_async = False
    docstring = ""

    for child in func_node.children:
        if child.type == "async" or _node_text(child) == "async":
            is_async = True
        elif child.type == "identifier" and not name:
            name = _node_text(child)
        elif child.type == "parameters":
            params = _extract_python_params(child)
        elif child.type == "block":
            docstring = _extract_python_docstring(child)

    return_type = _extract_python_return_type(func_node)

    is_static = "staticmethod" in decorators
    is_classmethod = "classmethod" in decorators

    # E9b: Extract exception types
    raises = _extract_python_raises(func_node)
    catches = _extract_python_catches(func_node)

    key = make_key(project_id, module_name, name)
    if class_name:
        key = make_key(project_id, module_name, class_name, name)

    return FunctionNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        class_name=class_name,
        params=params,
        return_type=return_type,
        is_async=is_async,
        is_method=is_method,
        is_static=is_static,
        is_classmethod=is_classmethod,
        decorators=decorators,
        docstring=docstring,
        line_start=func_node.start_point[0] + 1,
        line_end=func_node.end_point[0] + 1,
        raises=raises,
        catches=catches,
    )


def _parse_python_module_assignment(
    node,  # noqa: ANN001 - tree-sitter expression_statement node
    project_id: str,
    module_name: str,
) -> FunctionNode | None:
    """Parse a module-level assignment (NAME = EXPR) into a FunctionNode.

    H4: Enables scope to find module-level variables like state.py counters
    (total_count = [0]) and defaults.py config declarations (Option(...)).

    Only captures UPPER_CASE or snake_case names at module level (indent=0).
    Skips __dunder__ and single-char names.
    """
    expr = node.children[0] if node.children else None
    if not expr or expr.type != "assignment":
        return None

    # Extract LHS name
    lhs = None
    for child in expr.children:
        if child.type in ("identifier", "pattern_list"):
            lhs = child
            break
        if child.type == "=" or _node_text(child) == "=":
            break

    if lhs is None or lhs.type != "identifier":
        return None

    name = _node_text(lhs)

    # Filter: skip __dunder__, single-char, and common non-symbols
    if name.startswith("__") and name.endswith("__"):
        return None
    if len(name) <= 1:
        return None
    # Must be UPPER_CASE or snake_case with underscore (to reduce noise)
    if not (name.isupper() or "_" in name or name[0].isupper()):
        return None

    key = make_key(project_id, module_name, name)
    return FunctionNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        class_name=None,
        params=[],
        return_type=None,
        is_async=False,
        is_method=False,
        is_static=False,
        is_classmethod=False,
        is_assignment=True,
        decorators=[],
        docstring="",
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
    )


def _parse_python(
    tree,  # noqa: ANN001
    source: bytes,
    project_id: str,
    file_path: str,
    module_name: str,
) -> tuple[
    list[ClassNode], list[FunctionNode], list[ImportNode], list[tuple[str, str]],
    list[tuple[str, str, str]], dict[str, dict[str, str]],
    list[tuple[str, list[str]]], list[dict],
]:
    """Extract entities from a Python AST.

    Returns (classes, functions, imports, call_edges,
             method_chains, attr_type_map, dispatch_maps, error_paths).
    """
    classes: list[ClassNode] = []
    functions: list[FunctionNode] = []
    imports: list[ImportNode] = []
    call_edges: list[tuple[str, str]] = []
    method_chains: list[tuple[str, str, str]] = []
    attr_type_map: dict[str, dict[str, str]] = {}
    error_paths: list[dict] = []

    root = tree.root_node

    for node in root.children:
        if node.type == "class_definition":
            _parse_python_class(
                node, project_id, module_name, classes, functions,
                call_edges, decorators=[], method_chains=method_chains,
                attr_type_map=attr_type_map, error_paths=error_paths,
            )
        elif node.type == "decorated_definition":
            decorators = _extract_python_decorators(node)
            for child in node.children:
                if child.type == "class_definition":
                    _parse_python_class(
                        child, project_id, module_name, classes, functions,
                        call_edges, decorators, method_chains=method_chains,
                        attr_type_map=attr_type_map, error_paths=error_paths,
                    )
                elif child.type == "function_definition":
                    fn = _parse_python_function(child, project_id, module_name, None, decorators, is_method=False)
                    functions.append(fn)
                    _collect_function_calls_python(child, fn.name, call_edges, method_chains)
                    error_paths.extend(_extract_error_paths(child, fn.name))
        elif node.type == "function_definition":
            fn = _parse_python_function(node, project_id, module_name, None, [], is_method=False)
            functions.append(fn)
            _collect_function_calls_python(node, fn.name, call_edges, method_chains)
            error_paths.extend(_extract_error_paths(node, fn.name))
        elif node.type == "import_statement":
            imp = _parse_python_import(node, project_id, module_name)
            if imp:
                imports.append(imp)
        elif node.type == "import_from_statement":
            imp = _parse_python_import_from(node, project_id, module_name)
            if imp:
                imports.append(imp)
        elif node.type == "expression_statement":
            # H4: Parse module-level assignments (NAME = EXPR)
            assign_fn = _parse_python_module_assignment(node, project_id, module_name)
            if assign_fn:
                functions.append(assign_fn)

    # Extract dispatch maps from module-level dict assignments
    dispatch_maps = _extract_python_dispatch_maps(root)

    return (classes, functions, imports, call_edges,
            method_chains, attr_type_map, dispatch_maps, error_paths)


def _parse_python_class(
    class_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    classes: list[ClassNode],
    functions: list[FunctionNode],
    call_edges: list[tuple[str, str]],
    decorators: list[str],
    method_chains: list[tuple[str, str, str]] | None = None,
    attr_type_map: dict[str, dict[str, str]] | None = None,
    error_paths: list[dict] | None = None,
) -> None:
    """Parse a class_definition node, extracting the class and its methods."""
    name = ""
    bases: list[str] = []
    docstring = ""

    for child in class_node.children:
        if child.type == "identifier" and not name:
            name = _node_text(child)
        elif child.type == "argument_list":
            bases = _extract_python_class_bases(class_node)
        elif child.type == "block":
            docstring = _extract_python_docstring(child)
            # Parse methods inside the class block
            for block_child in child.children:
                if block_child.type == "function_definition":
                    fn = _parse_python_function(
                        block_child, project_id, module_name, name, [], is_method=True
                    )
                    functions.append(fn)
                    _collect_function_calls_python(block_child, f"{name}.{fn.name}", call_edges, method_chains)
                    if error_paths is not None:
                        error_paths.extend(_extract_error_paths(block_child, f"{name}.{fn.name}"))
                elif block_child.type == "decorated_definition":
                    method_decorators = _extract_python_decorators(block_child)
                    for sub in block_child.children:
                        if sub.type == "function_definition":
                            fn = _parse_python_function(
                                sub, project_id, module_name, name, method_decorators, is_method=True
                            )
                            functions.append(fn)
                            _collect_function_calls_python(sub, f"{name}.{fn.name}", call_edges, method_chains)
                            if error_paths is not None:
                                error_paths.extend(_extract_error_paths(sub, f"{name}.{fn.name}"))

    # Extract __init__ type map for attribute call resolution
    if name and attr_type_map is not None:
        init_types = _extract_init_type_map(class_node, name)
        if init_types:
            attr_type_map[name] = init_types

    key = make_key(project_id, module_name, name)
    cls = ClassNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        bases=bases,
        decorators=decorators,
        docstring=docstring,
        line_start=class_node.start_point[0] + 1,
        line_end=class_node.end_point[0] + 1,
    )
    classes.append(cls)


def _collect_function_calls_python(
    func_node,  # noqa: ANN001
    caller_name: str,
    call_edges: list[tuple[str, str]],
    method_chains: list[tuple[str, str, str]] | None = None,
) -> None:
    """Collect call edges from a function body.

    Normalizes callee names:
    - ``self.method()`` → ``ClassName.method`` (using caller's class context)
    - ``cls.method()`` → ``ClassName.method``
    """
    # Extract class name from caller_name (e.g., "Foo.main" -> "Foo")
    class_name = caller_name.rsplit(".", 1)[0] if "." in caller_name else None

    # Find the block child (the function body)
    for child in func_node.children:
        if child.type == "block":
            calls: list[str] = []
            _collect_python_calls(child, calls)
            for callee in calls:
                # Normalize self.xxx / cls.xxx -> ClassName.xxx
                if class_name and callee.startswith(("self.", "cls.")):
                    _, method = callee.split(".", 1)
                    callee = f"{class_name}.{method}"
                call_edges.append((caller_name, callee))
            # Detect method chains (e.g., get_data().process())
            if method_chains is not None:
                method_chains.extend(_detect_method_chains(child, caller_name))
            break


def _parse_python_import(
    node,  # noqa: ANN001
    project_id: str,
    module_name: str,
) -> ImportNode | None:
    """Parse an import_statement node (e.g., 'import json')."""
    names: list[str] = []
    for child in node.children:
        if child.type == "dotted_name":
            names.append(_node_text(child))
        elif child.type == "aliased_import":
            for sub in child.children:
                if sub.type == "dotted_name":
                    names.append(_node_text(sub))
                    break

    if not names:
        return None

    target = names[0]
    key = make_key(project_id, module_name, "import", target, str(node.start_point[0]))
    return ImportNode(
        **{"_key": key},
        project_id=project_id,
        source_module=module_name,
        target_module=target,
        imported_names=names,
        is_relative=False,
        line_number=node.start_point[0] + 1,
    )


def _parse_python_import_from(
    node,  # noqa: ANN001
    project_id: str,
    module_name: str,
) -> ImportNode | None:
    """Parse an import_from_statement node (e.g., 'from typing import Any')."""
    target = ""
    imported: list[str] = []
    is_relative = False

    # Check for relative import dots
    for child in node.children:
        if child.type == "relative_import":
            is_relative = True
            for sub in child.children:
                if sub.type == "dotted_name":
                    target = _node_text(sub)
                elif sub.type == "import_prefix":
                    # Just dots like "." or ".."
                    if not target:
                        target = _node_text(sub)

    # Non-relative import: find the module name after 'from'
    found_from = False
    found_import = False
    for child in node.children:
        if _node_text(child) == "from":
            found_from = True
            continue
        if _node_text(child) == "import":
            found_import = True
            continue
        if found_from and not found_import:
            if child.type == "dotted_name":
                target = _node_text(child)
                # Check if it starts with a dot (relative)
            elif child.type == "relative_import":
                is_relative = True
                for sub in child.children:
                    if sub.type == "dotted_name":
                        target = _node_text(sub)
        elif found_import:
            if child.type == "dotted_name":
                imported.append(_node_text(child))
            elif child.type == "aliased_import":
                for sub in child.children:
                    if sub.type == "dotted_name":
                        imported.append(_node_text(sub))
                        break

    if not target:
        return None

    key = make_key(project_id, module_name, "import_from", target, str(node.start_point[0]))
    return ImportNode(
        **{"_key": key},
        project_id=project_id,
        source_module=module_name,
        target_module=target,
        imported_names=imported,
        is_relative=is_relative,
        line_number=node.start_point[0] + 1,
    )


# ---------------------------------------------------------------------------
# TypeScript AST Extraction
# ---------------------------------------------------------------------------


def _extract_ts_params(params_node) -> list[str]:  # noqa: ANN001
    """Extract parameter names from a formal_parameters node."""
    params = []
    for child in params_node.children:
        if child.type == "required_parameter" or child.type == "optional_parameter":
            for sub in child.children:
                if sub.type == "identifier":
                    params.append(_node_text(sub))
                    break
                elif sub.type == "object_pattern" or sub.type == "array_pattern":
                    # Destructured parameter: collect all identifiers
                    params.append(_node_text(sub))
                    break
        elif child.type == "identifier":
            params.append(_node_text(child))
    return params


def _extract_ts_return_type(node) -> str | None:  # noqa: ANN001
    """Extract return type annotation from a TS function/method node."""
    for child in node.children:
        if child.type == "type_annotation":
            # Return everything after the colon
            for sub in child.children:
                if sub.type != ":":
                    return _node_text(sub)
    return None


def _collect_ts_calls(node, calls: list[str]) -> None:  # noqa: ANN001
    """Recursively collect function call names from a TypeScript subtree."""
    if node.type == "call_expression":
        func_node = node.children[0] if node.children else None
        if func_node:
            if func_node.type == "identifier":
                calls.append(_node_text(func_node))
            elif func_node.type == "member_expression":
                calls.append(_node_text(func_node))
    for child in node.children:
        _collect_ts_calls(child, calls)


def _parse_typescript(
    tree,  # noqa: ANN001
    source: bytes,
    project_id: str,
    file_path: str,
    module_name: str,
) -> tuple[list[ClassNode], list[FunctionNode], list[ImportNode], list[tuple[str, str]]]:
    """Extract entities from a TypeScript/TSX AST."""
    classes: list[ClassNode] = []
    functions: list[FunctionNode] = []
    imports: list[ImportNode] = []
    call_edges: list[tuple[str, str]] = []

    root = tree.root_node

    for node in root.children:
        if node.type == "import_statement":
            imp = _parse_ts_import(node, project_id, module_name)
            if imp:
                imports.append(imp)
        elif node.type == "class_declaration":
            _parse_ts_class(node, project_id, module_name, classes, functions, call_edges)
        elif node.type == "function_declaration":
            fn = _parse_ts_function_decl(node, project_id, module_name)
            functions.append(fn)
            _collect_ts_function_calls(node, fn.name, call_edges)
        elif node.type == "export_statement":
            _parse_ts_export(node, project_id, module_name, classes, functions, imports, call_edges)
        elif node.type == "lexical_declaration":
            _parse_ts_lexical_decl(node, project_id, module_name, functions, call_edges)

    return classes, functions, imports, call_edges


def _parse_ts_export(
    node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    classes: list[ClassNode],
    functions: list[FunctionNode],
    imports: list[ImportNode],
    call_edges: list[tuple[str, str]],
) -> None:
    """Parse an export_statement, dispatching to child types."""
    for child in node.children:
        if child.type == "class_declaration":
            _parse_ts_class(child, project_id, module_name, classes, functions, call_edges)
        elif child.type == "function_declaration":
            fn = _parse_ts_function_decl(child, project_id, module_name)
            functions.append(fn)
            _collect_ts_function_calls(child, fn.name, call_edges)
        elif child.type == "lexical_declaration":
            _parse_ts_lexical_decl(child, project_id, module_name, functions, call_edges)


def _parse_ts_class(
    class_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    classes: list[ClassNode],
    functions: list[FunctionNode],
    call_edges: list[tuple[str, str]],
) -> None:
    """Parse a class_declaration node."""
    name = ""
    bases: list[str] = []

    for child in class_node.children:
        if child.type == "type_identifier" and not name:
            name = _node_text(child)
        elif child.type == "class_heritage":
            for heritage_child in child.children:
                if heritage_child.type == "extends_clause":
                    for sub in heritage_child.children:
                        if sub.type == "identifier" or sub.type == "type_identifier":
                            bases.append(_node_text(sub))
                elif heritage_child.type == "implements_clause":
                    for sub in heritage_child.children:
                        if sub.type == "identifier" or sub.type == "type_identifier":
                            bases.append(_node_text(sub))
        elif child.type == "class_body":
            for body_child in child.children:
                if body_child.type == "method_definition":
                    fn = _parse_ts_method(body_child, project_id, module_name, name)
                    functions.append(fn)
                    _collect_ts_function_calls(body_child, f"{name}.{fn.name}", call_edges)

    key = make_key(project_id, module_name, name)
    cls = ClassNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        bases=bases,
        decorators=[],
        docstring="",
        line_start=class_node.start_point[0] + 1,
        line_end=class_node.end_point[0] + 1,
    )
    classes.append(cls)


def _parse_ts_method(
    method_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    class_name: str,
) -> FunctionNode:
    """Parse a method_definition node."""
    name = ""
    params: list[str] = []
    return_type: str | None = None
    is_async = False

    for child in method_node.children:
        if child.type == "async" or _node_text(child) == "async":
            is_async = True
        elif child.type == "property_identifier" and not name:
            name = _node_text(child)
        elif child.type == "formal_parameters":
            params = _extract_ts_params(child)
        elif child.type == "type_annotation" and return_type is None:
            return_type = _extract_ts_return_type(method_node)

    key = make_key(project_id, module_name, class_name, name)
    return FunctionNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        class_name=class_name,
        params=params,
        return_type=return_type,
        is_async=is_async,
        is_method=True,
        is_static=False,
        is_classmethod=False,
        decorators=[],
        docstring="",
        line_start=method_node.start_point[0] + 1,
        line_end=method_node.end_point[0] + 1,
    )


def _parse_ts_function_decl(
    func_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
) -> FunctionNode:
    """Parse a function_declaration node."""
    name = ""
    params: list[str] = []
    return_type: str | None = None
    is_async = False

    for child in func_node.children:
        if child.type == "async" or _node_text(child) == "async":
            is_async = True
        elif child.type == "identifier" and not name:
            name = _node_text(child)
        elif child.type == "formal_parameters":
            params = _extract_ts_params(child)
        elif child.type == "type_annotation" and return_type is None:
            return_type = _extract_ts_return_type(func_node)

    key = make_key(project_id, module_name, name)
    return FunctionNode(
        **{"_key": key},
        project_id=project_id,
        name=name,
        module=module_name,
        class_name=None,
        params=params,
        return_type=return_type,
        is_async=is_async,
        is_method=False,
        is_static=False,
        is_classmethod=False,
        decorators=[],
        docstring="",
        line_start=func_node.start_point[0] + 1,
        line_end=func_node.end_point[0] + 1,
    )


def _parse_ts_lexical_decl(
    lex_node,  # noqa: ANN001
    project_id: str,
    module_name: str,
    functions: list[FunctionNode],
    call_edges: list[tuple[str, str]],
) -> None:
    """Parse a lexical_declaration looking for arrow function assignments.

    Handles patterns like: const UserCard: React.FC<Props> = (args) => { ... }
    """
    for child in lex_node.children:
        if child.type == "variable_declarator":
            name = ""
            arrow_fn = None
            for sub in child.children:
                if sub.type == "identifier" and not name:
                    name = _node_text(sub)
                elif sub.type == "arrow_function":
                    arrow_fn = sub

            if name and arrow_fn:
                params: list[str] = []
                for sub in arrow_fn.children:
                    if sub.type == "formal_parameters":
                        params = _extract_ts_params(sub)
                        break
                    elif sub.type == "identifier":
                        # Single param arrow: x => ...
                        params = [_node_text(sub)]
                        break

                key = make_key(project_id, module_name, name)
                fn = FunctionNode(
                    **{"_key": key},
                    project_id=project_id,
                    name=name,
                    module=module_name,
                    class_name=None,
                    params=params,
                    return_type=None,
                    is_async=False,
                    is_method=False,
                    is_static=False,
                    is_classmethod=False,
                    decorators=[],
                    docstring="",
                    line_start=arrow_fn.start_point[0] + 1,
                    line_end=arrow_fn.end_point[0] + 1,
                )
                functions.append(fn)
                _collect_ts_function_calls(arrow_fn, name, call_edges)


def _collect_ts_function_calls(
    node,  # noqa: ANN001
    caller_name: str,
    call_edges: list[tuple[str, str]],
) -> None:
    """Collect call edges from a TS function/method body.

    Normalizes callee names:
    - ``this.method()`` → ``ClassName.method`` (using caller's class context)
    """
    # Extract class name from caller_name (e.g., "Foo.bar" -> "Foo")
    class_name = caller_name.rsplit(".", 1)[0] if "." in caller_name else None

    body = None
    for child in node.children:
        if child.type == "statement_block":
            body = child
            break
    if body is None:
        return
    calls: list[str] = []
    _collect_ts_calls(body, calls)
    for callee in calls:
        # Normalize this.xxx -> ClassName.xxx
        if class_name and callee.startswith("this."):
            _, method = callee.split(".", 1)
            callee = f"{class_name}.{method}"
        call_edges.append((caller_name, callee))


def _parse_ts_import(
    node,  # noqa: ANN001
    project_id: str,
    module_name: str,
) -> ImportNode | None:
    """Parse a TypeScript import_statement."""
    source_str = ""
    imported_names: list[str] = []

    for child in node.children:
        if child.type == "string":
            # Extract the string content (strip quotes)
            for sub in child.children:
                if sub.type == "string_fragment":
                    source_str = _node_text(sub)
                    break
            if not source_str:
                # Fallback: strip quotes from the full string
                source_str = _node_text(child).strip("\"'")
        elif child.type == "import_clause":
            for sub in child.children:
                if sub.type == "named_imports":
                    for imp in sub.children:
                        if imp.type == "import_specifier":
                            imported_names.append(_node_text(imp).strip())
                elif sub.type == "identifier":
                    imported_names.append(_node_text(sub))
                elif sub.type == "namespace_import":
                    imported_names.append(_node_text(sub))

    if not source_str:
        return None

    is_relative = source_str.startswith(".")
    key = make_key(project_id, module_name, "import", source_str, str(node.start_point[0]))

    return ImportNode(
        **{"_key": key},
        project_id=project_id,
        source_module=module_name,
        target_module=source_str,
        imported_names=imported_names,
        is_relative=is_relative,
        line_number=node.start_point[0] + 1,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_file(
    source: str | bytes,
    file_path: str,
    project_id: str,
    language: str | None = None,
) -> ParseResult:
    """Parse a source file and extract code entities.

    Args:
        source: File contents as string or bytes.
        file_path: Relative path to the file from project root.
        project_id: Project identifier for key generation.
        language: Language override. If None, detected from extension.

    Returns:
        ParseResult with all extracted entities.
    """
    if isinstance(source, str):
        source_bytes = source.encode("utf-8")
    else:
        source_bytes = source

    # Detect language from extension
    ext = os.path.splitext(file_path)[1].lower()
    if language is None:
        language = SUPPORTED_EXTENSIONS.get(ext)

    if language is None:
        logger.warning("Unsupported file extension: %s (file: %s)", ext, file_path)
        return _empty_result(file_path, project_id, source_bytes)

    ts_language = _get_language_for_ext(ext)
    if ts_language is None:
        logger.warning("No tree-sitter language for extension: %s", ext)
        return _empty_result(file_path, project_id, source_bytes)

    # Parse with tree-sitter
    parser = Parser(ts_language)
    try:
        tree = parser.parse(source_bytes)
    except Exception:
        logger.warning("Failed to parse file: %s", file_path, exc_info=True)
        return _empty_result(file_path, project_id, source_bytes)

    if tree.root_node.has_error:
        logger.warning("Parse errors in file: %s (continuing with partial results)", file_path)

    # Compute module name
    module_name = _file_path_to_module(file_path, language)

    # Create file and module nodes
    loc = source_bytes.count(b"\n") + (1 if source_bytes and not source_bytes.endswith(b"\n") else 0)
    file_key = make_key(project_id, file_path)
    file_node = FileNode(
        **{"_key": file_key},
        project_id=project_id,
        path=file_path,
        language=language,
        loc=loc,
    )

    module_key = make_key(project_id, module_name)
    module_node = ModuleNode(
        **{"_key": module_key},
        project_id=project_id,
        name=module_name,
        path=file_path,
        language=language,
        is_package=file_path.endswith("__init__.py"),
    )

    # Extract entities
    method_chains: list[tuple[str, str, str]] = []
    attr_type_map: dict[str, dict[str, str]] = {}
    dispatch_maps: list[tuple[str, list[str]]] = []
    error_paths: list[dict] = []

    if language == "python":
        (classes, functions, imports, call_edges,
         method_chains, attr_type_map, dispatch_maps, error_paths) = _parse_python(
            tree, source_bytes, project_id, file_path, module_name
        )
    else:
        classes, functions, imports, call_edges = _parse_typescript(
            tree, source_bytes, project_id, file_path, module_name
        )

    return ParseResult(
        file_node=file_node,
        module_node=module_node,
        classes=classes,
        functions=functions,
        imports=imports,
        call_edges=call_edges,
        method_chains=method_chains,
        attr_type_map=attr_type_map,
        dispatch_maps=dispatch_maps,
        error_paths=error_paths,
    )


def _empty_result(file_path: str, project_id: str, source_bytes: bytes) -> ParseResult:
    """Return an empty ParseResult for files that can't be parsed."""
    ext = os.path.splitext(file_path)[1].lower()
    language = SUPPORTED_EXTENSIONS.get(ext, "unknown")
    module_name = _file_path_to_module(file_path, language)
    loc = source_bytes.count(b"\n") + (1 if source_bytes and not source_bytes.endswith(b"\n") else 0)

    file_key = make_key(project_id, file_path)
    file_node = FileNode(
        **{"_key": file_key},
        project_id=project_id,
        path=file_path,
        language=language,
        loc=loc,
    )

    module_key = make_key(project_id, module_name)
    module_node = ModuleNode(
        **{"_key": module_key},
        project_id=project_id,
        name=module_name,
        path=file_path,
        language=language,
    )

    return ParseResult(file_node=file_node, module_node=module_node)
