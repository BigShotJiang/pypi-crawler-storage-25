# Talon

Context intelligence for Agentic Development — graph-based code context for AI coding agents.

## Supported Languages

| Language   | Extensions                     | Parser Features                                                      |
| ---------- | ------------------------------ | -------------------------------------------------------------------- |
| Python     | `.py`                          | Classes, decorators, raise/except, async                             |
| TypeScript | `.ts`, `.tsx`                  | Classes, interfaces, arrow functions, ES imports                     |
| JavaScript | `.js`, `.jsx`, `.mjs`, `.cjs`  | Arrow functions, ES imports/exports, method chains, error paths      |
| Go         | `.go`                          | Structs, receiver methods, interfaces, panic/recover                 |
| Java       | `.java`                        | Annotations, constructors, throws, inheritance, enums                |
| Rust       | `.rs`                          | Structs, traits, impl blocks, enums, panic!/? error paths            |
| C#         | `.cs`                          | Classes, interfaces, attributes, constructors, throw/catch           |
| Kotlin     | `.kt`, `.kts`                  | Data/sealed classes, companion objects, suspend functions             |
| Ruby       | `.rb`                          | Classes, modules, include/extend, singleton methods, rescue          |
| PHP        | `.php`                         | Classes, interfaces, traits, enums, namespace imports                |

All languages get full-depth parsing: classes/structs, functions/methods, imports, call edges, error flow edges, method chain resolution, and cross-module call edges.

## Install

```bash
pip install talon
```

## Quick start

```bash
# Authenticate with cogmeta.ai (opens browser, no copy/paste)
talon-setup auth login

# Generate .mcp.json for your project
talon-setup init --cloud
```

Then restart Claude Code — Talon is active.

## After your first run

Once you've dispatched a job, your trust dashboard surfaces every piece of data Cogmeta holds about you — self-serve, no support ticket required:

- **[app.cogmeta.ai/dispatch/trust.html](https://app.cogmeta.ai/dispatch/trust.html)** — PII findings in your recent jobs (heuristic scanner; you confirm each redaction).
- **[app.cogmeta.ai/dispatch/redaction.html](https://app.cogmeta.ai/dispatch/redaction.html)** — every redaction you've requested + the `executed_at` timestamp once the TombstoneSweeper actually erases the content.
- **[app.cogmeta.ai/dispatch/retention.html](https://app.cogmeta.ai/dispatch/retention.html)** — per-category TTL settings (jobs, conversations, messages). Data older than the TTL is auto-erased on the RetentionSweeper's hourly tick.
- **[app.cogmeta.ai/dispatch/jobs.html](https://app.cogmeta.ai/dispatch/jobs.html)** — your dispatched jobs + cost. Banners surface jobs that will expire within 3 days so you can export before they vanish.
- **[app.cogmeta.ai/audit-log.html](https://app.cogmeta.ai/audit-log.html)** — hash-chained audit trail (tamper-evident; verify locally with the chain's prev_hash links).

For machine-readable GDPR Art 15 export: `POST /cloud/v1/dispatch/user/data/export` returns the bundle inline. Schema is published at [app.cogmeta.ai/dispatch/export-bundle/v1.0/](https://app.cogmeta.ai/dispatch/export-bundle/v1.0/) — pin `schema_version` and DPO automation evolves additively.

