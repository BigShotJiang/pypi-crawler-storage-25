"""R-CLIENT-MCP-VERSION-SKEW tests."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from talon.version_skew import SkewLevel, compare_versions


def test_same_minor_is_safe():
    out = compare_versions("0.2.1", "0.2.5")
    assert out.level == SkewLevel.SAFE


def test_minor_drift_is_warn():
    out = compare_versions("0.2.1", "0.3.0")
    assert out.level == SkewLevel.WARN
    assert "behind" in out.detail


def test_client_ahead_is_warn():
    out = compare_versions("0.4.0", "0.2.1")
    assert out.level == SkewLevel.WARN
    assert "ahead" in out.detail


def test_major_mismatch_is_error():
    out = compare_versions("0.2.1", "1.0.0")
    assert out.level == SkewLevel.ERROR
    assert "upgrade" in out.detail.lower()


def test_v_prefix_handled():
    out = compare_versions("v0.2.1", "v0.2.5")
    assert out.level == SkewLevel.SAFE


def test_pre_release_suffix_ignored():
    out = compare_versions("0.2.1-rc.2", "0.2.5")
    assert out.level == SkewLevel.SAFE


def test_unparseable_returns_unknown():
    out = compare_versions("garbage", "0.2.1")
    assert out.level == SkewLevel.UNKNOWN


def test_empty_returns_unknown():
    out = compare_versions("", "0.2.1")
    assert out.level == SkewLevel.UNKNOWN
    out = compare_versions("0.2.1", "")
    assert out.level == SkewLevel.UNKNOWN


def test_to_dict_round_trip():
    d = compare_versions("0.2.1", "0.2.5").to_dict()
    assert d["level"] == "safe"
    assert d["client"] == "0.2.1"
    assert d["cloud"] == "0.2.5"
    assert "detail" in d


def test_skew_level_values_stable():
    """Telemetry depends on these exact strings."""
    assert SkewLevel.SAFE.value == "safe"
    assert SkewLevel.WARN.value == "warn"
    assert SkewLevel.ERROR.value == "error"
    assert SkewLevel.UNKNOWN.value == "unknown"
