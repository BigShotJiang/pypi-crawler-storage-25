"""Alpha S2 — talon mode (default | strict | yolo) tests.

Covers R-CLIENT-MODE-DEFAULT-VS-YOLO. Tests are pure (no real ~/.talon/
filesystem touched) via the TALON_CONFIG_PATH env override.
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

# Same prelude as other client tests (test_diag_faults.py etc.) — uv run
# would otherwise pick up a globally-installed older `talon` package.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import pytest

# yaml is bundled (PyYAML in client deps) — skip if missing on a slimmer install.
yaml = pytest.importorskip("yaml")


@pytest.fixture
def mode_module(tmp_path, monkeypatch):
    """Fresh module instance + isolated config path per test."""
    monkeypatch.setenv("TALON_CONFIG_PATH", str(tmp_path / "config.yaml"))
    monkeypatch.delenv("TALON_MODE", raising=False)
    from talon import mode
    importlib.reload(mode)
    yield mode


# ===========================================================================
# Resolution order
# ===========================================================================

def test_default_when_nothing_set(mode_module):
    assert mode_module.get_mode() == "default"


def test_env_var_wins(monkeypatch, mode_module):
    monkeypatch.setenv("TALON_MODE", "strict")
    mode_module.clear_cache()
    assert mode_module.get_mode() == "strict"


def test_config_yaml_picked_up(mode_module):
    mode_module.set_mode("strict")
    assert mode_module.get_mode() == "strict"


def test_env_overrides_config(monkeypatch, mode_module):
    mode_module.set_mode("strict")  # config says strict
    monkeypatch.setenv("TALON_MODE", "default")  # env says default
    mode_module.clear_cache()
    assert mode_module.get_mode() == "default"


def test_invalid_env_value_falls_through_to_default(monkeypatch, mode_module):
    monkeypatch.setenv("TALON_MODE", "blue")
    mode_module.clear_cache()
    assert mode_module.get_mode() == "default"


# ===========================================================================
# set_mode validation + persistence
# ===========================================================================

def test_set_mode_persists_to_yaml(tmp_path, monkeypatch, mode_module):
    monkeypatch.setenv("TALON_CONFIG_PATH", str(tmp_path / "config.yaml"))
    mode_module.set_mode("yolo")
    raw = (tmp_path / "config.yaml").read_text()
    parsed = yaml.safe_load(raw)
    assert parsed["mode"] == "yolo"


def test_set_mode_invalid_raises(mode_module):
    with pytest.raises(ValueError) as exc_info:
        mode_module.set_mode("super-yolo")
    msg = str(exc_info.value)
    assert "default" in msg
    assert "strict" in msg
    assert "yolo" in msg


def test_set_mode_canonicalises_case(mode_module):
    out = mode_module.set_mode("STRICT")
    assert out == "strict"
    assert mode_module.get_mode() == "strict"


def test_set_mode_preserves_other_config_keys(tmp_path, monkeypatch, mode_module):
    """Pre-existing keys in config.yaml MUST survive a set_mode call."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml.safe_dump({"debug": {"enabled": True}, "other": 42}))
    monkeypatch.setenv("TALON_CONFIG_PATH", str(cfg))
    importlib.reload(mode_module)
    mode_module.set_mode("strict")
    parsed = yaml.safe_load(cfg.read_text())
    assert parsed["mode"] == "strict"
    assert parsed["debug"]["enabled"] is True
    assert parsed["other"] == 42


def test_set_mode_corrupt_yaml_does_not_crash(tmp_path, monkeypatch, mode_module):
    """Corrupt config.yaml should be overwritten with a valid one + the new mode."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text("{ this is not valid yaml")
    monkeypatch.setenv("TALON_CONFIG_PATH", str(cfg))
    importlib.reload(mode_module)
    mode_module.set_mode("strict")
    parsed = yaml.safe_load(cfg.read_text())
    assert parsed["mode"] == "strict"


# ===========================================================================
# Convenience predicates
# ===========================================================================

def test_is_strict_true_when_strict(mode_module):
    mode_module.set_mode("strict")
    assert mode_module.is_strict() is True
    assert mode_module.is_yolo() is False
    assert mode_module.is_default() is False


def test_is_yolo_true_when_yolo(mode_module):
    mode_module.set_mode("yolo")
    assert mode_module.is_yolo() is True
    assert mode_module.is_strict() is False


def test_is_default_true_when_default(mode_module):
    assert mode_module.is_default() is True


# ===========================================================================
# explain_mode output
# ===========================================================================

def test_explain_mode_includes_current(mode_module):
    out = mode_module.explain_mode()
    assert "default" in out
    assert "strict" in out
    assert "yolo" in out
    assert "talon mode set" in out


def test_explain_mode_flags_env_override(monkeypatch, mode_module):
    monkeypatch.setenv("TALON_MODE", "yolo")
    mode_module.clear_cache()
    out = mode_module.explain_mode()
    assert "TALON_MODE" in out
    assert "yolo" in out


# ===========================================================================
# VALID_MODES contract
# ===========================================================================

def test_valid_modes_is_canonical_three(mode_module):
    """The three modes are part of the spec — refuse to silently grow."""
    assert set(mode_module.VALID_MODES) == {"default", "strict", "yolo"}
