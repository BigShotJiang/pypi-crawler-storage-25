"""CLI exit-code + parser contract tests.

11_test_coverage.md [LOW] "CLI commands lack coverage": 6 CLI entry points,
zero unit tests for exit codes / argparse / `--help` output / conflicting flags.
A hidden breaking change to output format would break automation scripts
silently.

This file tests `_build_parser` + the highest-leverage `_cmd_*` handlers
that don't require a live cloud connection: `_cmd_doctor` (returns 1 on
FAIL findings, 0 on clean), `_cmd_mode` (validates mode names), and
top-level argparse routing for the documented subcommands.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pytest

# Ensure backend isn't accidentally on sys.path stealing imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


# ===========================================================================
# Argparse: _build_parser surface
# ===========================================================================

def _parser() -> argparse.ArgumentParser:
    from talon.mcp.setup_cli import _build_parser
    return _build_parser()


def test_parser_has_documented_top_level_subcommands():
    """The doc / SKILL.md / talon help table all reference these subcommands.
    If a refactor drops one of them, automation breaks silently."""
    p = _parser()
    args = p.parse_args(["init", "--force"])
    assert args.command == "init"
    args = p.parse_args(["doctor"])
    assert args.command == "doctor"
    args = p.parse_args(["check"])
    assert args.command == "check"


def test_parser_no_command_does_not_crash():
    """Bare `talon` (no subcommand) must produce a parseable Namespace, not
    a SystemExit. main() then prints the help banner."""
    p = _parser()
    args = p.parse_args([])
    assert getattr(args, "command", None) in (None, "")


def test_parser_unknown_subcommand_exits_2():
    """argparse convention: unknown subcommand → SystemExit(2). Stable for
    shell-script error-handling that grep for non-zero exit codes."""
    p = _parser()
    with pytest.raises(SystemExit) as exc_info:
        p.parse_args(["totally-not-a-command"])
    assert exc_info.value.code == 2


def test_parser_help_exits_zero():
    """`talon --help` must exit 0 — POSIX convention. Anything else breaks
    `talon --help | less` etc."""
    p = _parser()
    with pytest.raises(SystemExit) as exc_info:
        p.parse_args(["--help"])
    assert exc_info.value.code == 0


# ===========================================================================
# _cmd_doctor — exit-code contract
# ===========================================================================

@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    """Redirect HOME so doctor reads test fixtures, not real ~/."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    import importlib

    from talon import doctor
    importlib.reload(doctor)
    return tmp_path


def test_cmd_doctor_returns_nonzero_on_failures(fake_home, capsys):
    """No credentials + no .mcp.json → at least one FAIL finding → exit 1."""
    from talon.mcp.setup_cli import _cmd_doctor
    args = argparse.Namespace(path=str(fake_home), json_output=False)
    rc = _cmd_doctor(args)
    assert rc == 1
    captured = capsys.readouterr()
    assert "TALON DOCTOR" in captured.out


def test_cmd_doctor_json_output_is_valid_json(fake_home, capsys):
    """`--json` is meant for scripting — output MUST be parseable JSON,
    not interleaved with progress text. A regression that sneaks a print()
    into the JSON path breaks `jq` consumers immediately."""
    from talon.mcp.setup_cli import _cmd_doctor
    args = argparse.Namespace(path=str(fake_home), json_output=True)
    _cmd_doctor(args)
    captured = capsys.readouterr()
    parsed = json.loads(captured.out)
    assert "findings" in parsed
    assert "ok_count" in parsed
    assert "fail_count" in parsed


def test_cmd_doctor_json_round_trip_matches_report(fake_home, capsys):
    """JSON output must match `report.to_dict()` exactly — no key drift."""
    from talon.doctor import run_doctor
    from talon.mcp.setup_cli import _cmd_doctor

    expected = run_doctor(Path(fake_home)).to_dict()
    args = argparse.Namespace(path=str(fake_home), json_output=True)
    _cmd_doctor(args)
    captured = capsys.readouterr()
    actual = json.loads(captured.out)
    assert set(actual) == set(expected)


# ===========================================================================
# _cmd_mode — input validation
# ===========================================================================

def test_cmd_mode_rejects_invalid_mode(fake_home, capsys):
    """Typo in mode name MUST reject with a non-zero exit code AND print
    valid options to stderr. Common automation patterns set mode in install
    scripts — a silent acceptance of a typo would leave the user in default
    mode while their script reported success."""
    from talon.mcp.setup_cli import _cmd_mode
    # Real signature uses `mode_action` (not `mode_command`).
    args = argparse.Namespace(mode_action="set", value="full-yolo-omega")
    rc = _cmd_mode(args)
    assert rc == 1
    captured = capsys.readouterr()
    # Error message must hit stderr — that's what the install scripts grep
    assert "error" in captured.err.lower()


def test_cmd_mode_set_valid_mode_returns_zero(fake_home, capsys):
    """`talon mode set strict` must succeed and persist the value."""
    from talon.mcp.setup_cli import _cmd_mode
    args = argparse.Namespace(mode_action="set", value="strict")
    rc = _cmd_mode(args)
    assert rc == 0


def test_cmd_mode_show_returns_zero_on_clean_install(fake_home, capsys):
    """`talon mode show` is a read — must always succeed even on first run
    (no config.yaml). Default mode is reported."""
    from talon.mcp.setup_cli import _cmd_mode
    args = argparse.Namespace(mode_action=None, value=None)  # action=None → "show"
    rc = _cmd_mode(args)
    assert rc == 0
    captured = capsys.readouterr()
    out_lower = captured.out.lower()
    assert any(label in out_lower for label in ("default", "strict", "yolo", "mode"))


# ===========================================================================
# Sanity: importing setup_cli must not start the setup chain
# ===========================================================================

def test_importing_setup_cli_is_pure():
    """Earlier the module-level `_install_skill` etc. fired at import time
    via main(); after the 04_performance.md fix they only fire inside
    `_ensure_cc_setup_once()` / `_FORCE_SETUP_COMMANDS`. Importing this
    module must have no observable side-effect on the user's filesystem."""
    import importlib
    import talon.mcp.setup_cli as cli
    importlib.reload(cli)
    assert hasattr(cli, "main")
    assert hasattr(cli, "_build_parser")
    # Force-setup commands list still exists — the cache helper exists too
    assert hasattr(cli, "_FORCE_SETUP_COMMANDS") or hasattr(cli, "_ensure_cc_setup_once")
