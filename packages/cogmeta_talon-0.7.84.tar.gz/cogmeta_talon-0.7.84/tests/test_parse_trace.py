"""Unit tests for parse_trace — thinking block capture and step classification."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from talon.telemetry.session_reporter import parse_trace


def _write_jsonl(events: list[dict]) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False)
    for ev in events:
        f.write(json.dumps(ev) + "\n")
    f.close()
    return Path(f.name)


def _assistant(content: list[dict], usage: dict | None = None, ts: str = "2026-01-01T00:00:00Z") -> dict:
    return {
        "type": "assistant",
        "timestamp": ts,
        "message": {
            "id": "msg_1",
            "model": "claude-sonnet-4-6",
            "stop_reason": "end_turn",
            "usage": usage or {"input_tokens": 100, "output_tokens": 50,
                               "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0},
            "content": content,
        },
    }


def _user_prompt(text: str) -> dict:
    return {
        "type": "user",
        "message": {
            "content": [{"type": "text", "text": text}],
        },
    }


# ---------------------------------------------------------------------------
# Thinking block capture
# ---------------------------------------------------------------------------

def test_thinking_block_captured():
    events = [
        _user_prompt("fix the bug"),
        _assistant([
            {"type": "thinking", "thinking": "Let me reason through this step by step."},
            {"type": "text", "text": "I'll fix it now."},
        ]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    names = [s["tool_name"] for s in result["steps"]]
    assert "__thinking__" in names, f"Expected __thinking__ in steps, got: {names}"
    assert "__text__" in names

    thinking_step = next(s for s in result["steps"] if s["tool_name"] == "__thinking__")
    assert "Let me reason through this step by step." in thinking_step["text_content"]


def test_thinking_block_truncated_at_5000():
    long_thinking = "x" * 6000
    events = [
        _assistant([{"type": "thinking", "thinking": long_thinking}]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    thinking_step = next((s for s in result["steps"] if s["tool_name"] == "__thinking__"), None)
    assert thinking_step is not None
    assert len(thinking_step["text_content"]) <= 5000


def test_multiple_thinking_blocks_concatenated():
    events = [
        _assistant([
            {"type": "thinking", "thinking": "First thought."},
            {"type": "thinking", "thinking": "Second thought."},
            {"type": "text", "text": "Answer."},
        ]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    thinking_step = next((s for s in result["steps"] if s["tool_name"] == "__thinking__"), None)
    assert thinking_step is not None
    assert "First thought." in thinking_step["text_content"]
    assert "Second thought." in thinking_step["text_content"]


def test_no_thinking_blocks_no_thinking_step():
    events = [
        _assistant([{"type": "text", "text": "Just a plain response."}]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    names = [s["tool_name"] for s in result["steps"]]
    assert "__thinking__" not in names
    assert "__text__" in names


def test_thinking_step_has_zero_tokens():
    """Thinking steps should not claim turn tokens (text step or first tool gets them)."""
    events = [
        _assistant([
            {"type": "thinking", "thinking": "Thinking..."},
            {"type": "text", "text": "Response."},
        ], usage={"input_tokens": 200, "output_tokens": 80,
                  "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0}),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    thinking_step = next(s for s in result["steps"] if s["tool_name"] == "__thinking__")
    assert thinking_step["input_tokens"] == 0
    assert thinking_step["output_tokens"] == 0


def test_thinking_step_ordering():
    """__thinking__ step must come before __text__ step in same turn."""
    events = [
        _assistant([
            {"type": "thinking", "thinking": "Reasoning."},
            {"type": "text", "text": "Answer."},
        ]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    names = [s["tool_name"] for s in result["steps"]]
    thinking_idx = names.index("__thinking__")
    text_idx = names.index("__text__")
    assert thinking_idx < text_idx


# ---------------------------------------------------------------------------
# Tool call steps
# ---------------------------------------------------------------------------

def test_tool_call_step():
    events = [
        _assistant([
            {"type": "thinking", "thinking": "I'll call graph_ask_lite."},
            {"type": "tool_use", "id": "tu_1", "name": "mcp__talon__graph_ask_lite",
             "input": {"task": "fix the bug", "expected_files": ["foo.py"]}},
        ]),
        {
            "type": "user",
            "message": {
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "result"}
                ]
            },
        },
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    names = [s["tool_name"] for s in result["steps"]]
    assert "mcp__talon__graph_ask_lite" in names
    assert "__thinking__" in names

    tool_step = next(s for s in result["steps"] if s["tool_name"] == "mcp__talon__graph_ask_lite")
    assert tool_step["tool_input"]["task"] == "fix the bug"
    assert tool_step["input_tokens"] == 100  # first tool in turn gets tokens


def test_thinking_not_counted_as_tool_call():
    events = [
        _assistant([
            {"type": "thinking", "thinking": "Reasoning."},
            {"type": "tool_use", "id": "tu_1", "name": "mcp__talon__edit_batch",
             "input": {"edits": []}},
        ]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    assert result["total_tool_calls"] == 1  # only edit_batch counts


# ---------------------------------------------------------------------------
# Empty / edge cases
# ---------------------------------------------------------------------------

def test_empty_thinking_block_skipped():
    events = [
        _assistant([
            {"type": "thinking", "thinking": "   "},
            {"type": "text", "text": "Response."},
        ]),
    ]
    path = _write_jsonl(events)
    result = parse_trace(path)

    names = [s["tool_name"] for s in result["steps"]]
    assert "__thinking__" not in names  # stripped empty → skipped


def test_parse_trace_empty_file():
    path = _write_jsonl([])
    result = parse_trace(path)
    assert result == {}
