"""R-CLIENT-HOOK-CONFLICT — doctor diagnostic tests."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import pytest

yaml = pytest.importorskip("yaml")


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    """Redirect HOME so the doctor reads test fixtures, not real ~/."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    # Force doctor module reload so its module-level path constants pick up new HOME
    import importlib

    from talon import doctor
    importlib.reload(doctor)
    return tmp_path


# ===========================================================================
# Individual checks
# ===========================================================================

def test_python_version_check_passes_on_modern_python(fake_home):
    from talon.doctor import check_python_version
    f = check_python_version()
    # Test runs on Python 3.12; should pass.
    assert f.level == "ok"
    assert f.code == "TALON-DOCTOR-PY-001"


def test_credentials_missing_is_fail(fake_home):
    from talon.doctor import check_credentials
    f = check_credentials()
    assert f.level == "fail"
    assert "talon login" in f.fix


def test_credentials_empty_api_key_is_fail(fake_home):
    creds_path = fake_home / ".talon" / "credentials.json"
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    creds_path.write_text(json.dumps({"email": "x@y.z", "api_key": ""}))
    from talon.doctor import check_credentials
    f = check_credentials()
    assert f.level == "fail"


def test_credentials_present_is_ok(fake_home):
    creds_path = fake_home / ".talon" / "credentials.json"
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    creds_path.write_text(json.dumps({"email": "alice@cogmeta.ai", "api_key": "cogz_api_x"}))
    from talon.doctor import check_credentials
    f = check_credentials()
    assert f.level == "ok"
    assert "alice@cogmeta.ai" in f.message


def test_config_yaml_absent_is_ok(fake_home):
    """No config.yaml → defaults apply → not a problem."""
    from talon.doctor import check_config_yaml
    f = check_config_yaml()
    assert f.level == "ok"


def test_config_yaml_corrupt_is_fail(fake_home):
    cfg = fake_home / ".talon" / "config.yaml"
    cfg.parent.mkdir(parents=True, exist_ok=True)
    cfg.write_text("{ this is not yaml")
    from talon.doctor import check_config_yaml
    f = check_config_yaml()
    assert f.level == "fail"


def test_mode_value_default_is_ok(fake_home):
    from talon.doctor import check_mode_value
    f = check_mode_value()
    assert f.level == "ok"
    assert "default" in f.message


# ===========================================================================
# Hook-duplicate detection
# ===========================================================================

def test_hook_duplicates_flagged(fake_home):
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True, exist_ok=True)
    settings.write_text(json.dumps({
        "hooks": {
            "UserPromptSubmit": [
                {"hooks": [{"command": "/path/to/talon-hook.sh"}]},
                {"hooks": [{"command": "/path/to/talon-hook.sh"}]},
            ],
        },
    }))
    from talon.doctor import check_claude_settings
    findings = check_claude_settings()
    levels = {f.code: f.level for f in findings}
    assert levels.get("TALON-DOCTOR-HOOK-DUP-001") == "warn"


def test_no_hook_duplicates_is_ok(fake_home):
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True, exist_ok=True)
    settings.write_text(json.dumps({
        "hooks": {
            "UserPromptSubmit": [
                {"hooks": [{"command": "/path/to/talon-hook.sh"}]},
                {"hooks": [{"command": "/path/to/different-hook.sh"}]},
            ],
        },
    }))
    from talon.doctor import check_claude_settings
    findings = check_claude_settings()
    dup_finding = next(f for f in findings if f.code == "TALON-DOCTOR-HOOK-DUP-001")
    assert dup_finding.level == "ok"


def test_claude_settings_corrupt_is_fail(fake_home):
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True, exist_ok=True)
    settings.write_text("not json {")
    from talon.doctor import check_claude_settings
    findings = check_claude_settings()
    assert any(f.level == "fail" for f in findings)


def test_claude_settings_missing_is_warn(fake_home):
    """No Claude Code installed yet → warn, not fail (talon still works)."""
    from talon.doctor import check_claude_settings
    findings = check_claude_settings()
    assert findings[0].level == "warn"


# ===========================================================================
# .mcp.json checks
# ===========================================================================

def test_mcp_json_missing_is_warn(tmp_path, fake_home):
    from talon.doctor import check_mcp_json
    findings = check_mcp_json(tmp_path)
    assert findings[0].level == "warn"
    assert "talon init" in findings[0].fix


def test_mcp_json_corrupt_is_fail(tmp_path, fake_home):
    (tmp_path / ".mcp.json").write_text("not json")
    from talon.doctor import check_mcp_json
    findings = check_mcp_json(tmp_path)
    assert any(f.level == "fail" for f in findings)


def test_mcp_json_no_servers_is_fail(tmp_path, fake_home):
    (tmp_path / ".mcp.json").write_text(json.dumps({"mcpServers": {}}))
    from talon.doctor import check_mcp_json
    findings = check_mcp_json(tmp_path)
    assert any(f.level == "fail" for f in findings)


def test_mcp_json_no_talon_entry_is_fail(tmp_path, fake_home):
    (tmp_path / ".mcp.json").write_text(json.dumps({
        "mcpServers": {"linear": {"command": "uvx", "args": ["mcp-linear"]}},
    }))
    from talon.doctor import check_mcp_json
    findings = check_mcp_json(tmp_path)
    assert any(f.level == "fail" for f in findings)


def test_mcp_json_with_talon_and_others_is_ok(tmp_path, fake_home):
    (tmp_path / ".mcp.json").write_text(json.dumps({
        "mcpServers": {
            "talon": {"command": "talon-proxy-wrapper", "args": []},
            "linear": {"command": "uvx", "args": []},
        },
    }))
    from talon.doctor import check_mcp_json
    findings = check_mcp_json(tmp_path)
    levels = {f.code: f.level for f in findings}
    # The talon-registered + others-preserved findings should both be "ok".
    assert levels.get("TALON-DOCTOR-MCP-001") == "ok"
    assert levels.get("TALON-DOCTOR-MCP-005") == "ok"


# ===========================================================================
# Driver
# ===========================================================================

def test_run_doctor_aggregates_findings(fake_home, tmp_path):
    """Smoke test: full driver returns a DoctorReport without raising."""
    from talon.doctor import run_doctor
    report = run_doctor(tmp_path)
    assert len(report.findings) > 0


def test_format_report_renders_lines(fake_home, tmp_path):
    from talon.doctor import format_report, run_doctor
    txt = format_report(run_doctor(tmp_path))
    assert "TALON DOCTOR" in txt
    assert "ok ·" in txt
    assert "warn ·" in txt or "fail ·" in txt or "0 warn" in txt


def test_doctor_report_to_dict_round_trip(fake_home, tmp_path):
    from talon.doctor import run_doctor
    d = run_doctor(tmp_path).to_dict()
    assert "ok_count" in d
    assert "warn_count" in d
    assert "fail_count" in d
    assert "findings" in d
    assert isinstance(d["findings"], list)
