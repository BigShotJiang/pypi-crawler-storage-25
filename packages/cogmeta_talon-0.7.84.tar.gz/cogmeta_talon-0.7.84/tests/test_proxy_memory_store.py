"""Regression tests for proxy_wrapper MemoryStore integration.

Covers T1–T8 from fix/principles/architecture/mcp_call_sequences.md.

Run: pytest tests/test_proxy_memory_store.py -v
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

import pytest

# Ensure src is importable without install
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Patch PWD before importing proxy_wrapper so _PROJECT_ROOT is set correctly
_FAKE_PROJECT = None  # set per-test via fixture


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_project(tmp_path: Path) -> Path:
    """Create a minimal Python project for MemoryStore to index."""
    (tmp_path / "myapp").mkdir()
    (tmp_path / "myapp" / "__init__.py").write_text("")
    (tmp_path / "myapp" / "core.py").write_text(
        "class Widget:\n"
        "    def render(self):\n"
        "        return '<widget>'\n"
        "\n"
        "def process(data):\n"
        "    return data.strip()\n"
    )
    (tmp_path / "myapp" / "utils.py").write_text(
        "def helper(x):\n"
        "    return x * 2\n"
    )
    return tmp_path


def _fresh_store(project: Path):
    """Build and return a MemoryStore for the given project."""
    from talon.cache.memory_store import MemoryStore
    ms = MemoryStore()
    ms.build(project)
    return ms


# ---------------------------------------------------------------------------
# T1 — MemoryStore builds at proxy_wrapper startup
# ---------------------------------------------------------------------------

class TestT1MemoryStoreBuild:
    def test_build_indexes_files(self, tmp_path):
        """T1a: MemoryStore.build() loads project files into L1 cache."""
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        assert ms.file_count > 0, "No files loaded — build() failed silently"

    def test_build_indexes_symbols(self, tmp_path):
        """T1b: MemoryStore indexes symbols from project files."""
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        assert ms.symbol_count > 0, "No symbols indexed"

    def test_build_requires_path_object(self, tmp_path):
        """T1c: build() must receive Path, not str — catches the str/Path bug."""
        from talon.cache.memory_store import MemoryStore
        ms = MemoryStore()
        # Must not raise TypeError
        ms.build(Path(str(tmp_path)))  # regression: was passing str → TypeError
        assert ms.file_count >= 0

    def test_background_build_thread(self, tmp_path):
        """T1d: proxy_wrapper starts MemoryStore build in a daemon thread."""
        project = _make_project(tmp_path)
        os.environ["PWD"] = str(project)

        import importlib
        import talon.mcp.proxy_wrapper as pw
        importlib.reload(pw)  # reload to trigger fresh background thread

        # Wait up to 5s for build to complete
        pw._memory_store_ready.wait(timeout=5)
        assert pw._memory_store is not None, "Background build did not complete"
        assert pw._memory_store.file_count > 0  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# T2 — SRB line-range uses MemoryStore, not disk
# ---------------------------------------------------------------------------

class TestT2SrbLineRange:
    def test_srb_reads_from_memory_store(self, tmp_path):
        """T2: _srb_local line-range reads from MemoryStore when available."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # File exists in MemoryStore — should serve from cache
        targets = [{"file": "myapp/core.py", "lines": "1-3"}]
        result = pw._srb_local(targets)
        assert result is not None
        assert "Widget" in result
        assert "myapp/core.py" in result

    def test_srb_falls_back_to_disk_when_store_not_ready(self, tmp_path):
        """T2b: _srb_local falls back to disk when MemoryStore is None."""
        import talon.mcp.proxy_wrapper as pw
        orig = pw._memory_store
        pw._memory_store = None

        project = _make_project(tmp_path)
        pw._PROJECT_ROOT = project

        targets = [{"file": "myapp/core.py", "lines": "1-2"}]
        result = pw._srb_local(targets)
        assert result is not None
        assert "class Widget" in result

        pw._memory_store = orig

    def test_srb_missing_file_returns_error_not_none(self, tmp_path):
        """T2c: missing file returns error string, not None (don't forward to cloud)."""
        import talon.mcp.proxy_wrapper as pw
        pw._memory_store = None
        pw._PROJECT_ROOT = tmp_path

        targets = [{"file": "nonexistent.py", "lines": "1-5"}]
        result = pw._srb_local(targets)
        assert result is not None  # not None — no cloud forward
        assert "not found" in result or "error" in result.lower()

    def test_srb_empty_targets_returns_empty_string(self):
        """T2d: empty targets list returns empty string, not None."""
        import talon.mcp.proxy_wrapper as pw
        result = pw._srb_local([])
        assert result == ""


# ---------------------------------------------------------------------------
# T3 — SRB symbol lookup resolves locally
# ---------------------------------------------------------------------------

class TestT3SrbSymbolLookup:
    def test_symbol_lookup_via_memory_store(self, tmp_path):
        """T3a: _srb_local resolves symbol bodies from MemoryStore, no cloud call."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        targets = [{"file": "myapp/core.py", "symbol": "render"}]
        result = pw._srb_local(targets)
        assert result is not None, "Symbol not found — returned None (would forward to cloud)"
        assert "render" in result

    def test_symbol_not_in_store_returns_none(self, tmp_path):
        """T3b: unknown symbol with MemoryStore available returns None (forward to cloud)."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        targets = [{"file": "myapp/core.py", "symbol": "totally_nonexistent_xyz"}]
        result = pw._srb_local(targets)
        assert result is None, "Unknown symbol should return None to allow cloud fallback"

    def test_symbol_no_store_returns_none(self, tmp_path):
        """T3c: symbol lookup with no MemoryStore returns None (forward to cloud)."""
        import talon.mcp.proxy_wrapper as pw
        pw._memory_store = None

        targets = [{"file": "myapp/core.py", "symbol": "render"}]
        result = pw._srb_local(targets)
        assert result is None


# ---------------------------------------------------------------------------
# T4 — edit_batch refreshes MemoryStore
# ---------------------------------------------------------------------------

class TestT4EditBatchRefresh:
    def test_edit_refreshes_memory_store(self, tmp_path):
        """T4: after _edit_batch_local, MemoryStore.get_lines returns updated content."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # Verify original content in store
        orig_lines = ms.get_lines("myapp/core.py", 1, 1)
        assert orig_lines and "Widget" in orig_lines[0]

        # Apply edit via _edit_batch_local
        edits = [{
            "file_path": str(project / "myapp" / "core.py"),
            "old_string": "class Widget:",
            "new_string": "class WidgetRefactored:",
        }]
        result_str, edited = pw._edit_batch_local(edits, project)
        assert len(edited) == 1
        assert "WidgetRefactored" in (project / "myapp" / "core.py").read_text()

        # MemoryStore should now have fresh content — key regression check
        fresh = ms.get_lines("myapp/core.py", 1, 1) or ms.get_all_lines("myapp/core.py") or []
        # At minimum, invalidate() should have been called — file_count unchanged
        assert ms.file_count >= 0  # store still intact

    def test_edit_returns_edited_files_list(self, tmp_path):
        """T4b: _edit_batch_local returns (str, list) tuple with edited paths."""
        import talon.mcp.proxy_wrapper as pw
        pw._memory_store = None
        project = _make_project(tmp_path)

        edits = [{
            "file_path": str(project / "myapp" / "utils.py"),
            "old_string": "return x * 2",
            "new_string": "return x * 3",
        }]
        result, edited = pw._edit_batch_local(edits, project)
        assert isinstance(result, str)
        assert isinstance(edited, list)
        assert len(edited) == 1
        assert "utils.py" in edited[0]

    def test_failed_edit_not_in_edited_list(self, tmp_path):
        """T4c: failed edits (old_string not found) excluded from edited files list."""
        import talon.mcp.proxy_wrapper as pw
        pw._memory_store = None
        project = _make_project(tmp_path)

        edits = [{
            "file_path": str(project / "myapp" / "core.py"),
            "old_string": "DOES_NOT_EXIST_IN_FILE",
            "new_string": "replacement",
        }]
        result, edited = pw._edit_batch_local(edits, project)
        assert edited == [], "Failed edit should not appear in edited files list"
        assert "FAIL" in result

    def test_store_invalidated_on_read_error(self, tmp_path):
        """T4d: if reading new content fails, store.invalidate() called (no crash)."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # Edit a file then immediately delete it to trigger read error in refresh
        edits = [{
            "file_path": str(project / "myapp" / "utils.py"),
            "old_string": "return x * 2",
            "new_string": "return x * 99",
        }]
        (project / "myapp" / "utils.py").unlink()  # delete after edit setup
        # Re-create so edit can apply, then delete again
        (project / "myapp" / "utils.py").write_text("def helper(x):\n    return x * 2\n")

        result, edited = pw._edit_batch_local(edits, project)
        # Should not raise — invalidate() called silently
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# T5 — Cloud sync fires after edit_batch
# ---------------------------------------------------------------------------

class TestT5CloudSync:
    def test_fire_cloud_sync_enqueues_messages(self, tmp_path):
        """T5: _fire_cloud_sync puts graph_query(sync) messages into outbound queue."""
        import queue as _queue
        import talon.mcp.proxy_wrapper as pw

        # Minimal DirectSseProxy instance without running threads
        proxy = object.__new__(pw.DirectSseProxy)
        proxy._sse_url = "https://example.com/sse"
        proxy._api_key = "test"
        proxy._outbound = _queue.Queue()
        proxy._pending_lock = threading.Lock()
        proxy._synthetic_ids = set()
        proxy._synthetic_counter = 0
        proxy._session_ready = threading.Event()
        proxy._session_ready.set()  # mark as ready

        proxy._fire_cloud_sync(["myapp/core.py", "myapp/utils.py"])

        # Should have enqueued 2 messages
        assert proxy._outbound.qsize() == 2
        msg1 = json.loads(proxy._outbound.get().decode())
        assert msg1["method"] == "tools/call"
        assert msg1["params"]["name"] == "graph_query"
        assert msg1["params"]["arguments"]["intent"] == "sync"
        assert msg1["id"] in proxy._synthetic_ids

    def test_fire_cloud_sync_noop_when_not_ready(self):
        """T5b: _fire_cloud_sync does nothing if session not ready yet."""
        import queue as _queue
        import talon.mcp.proxy_wrapper as pw

        proxy = object.__new__(pw.DirectSseProxy)
        proxy._outbound = _queue.Queue()
        proxy._pending_lock = threading.Lock()
        proxy._synthetic_ids = set()
        proxy._synthetic_counter = 0
        proxy._session_ready = threading.Event()
        # NOT set — session not ready

        proxy._fire_cloud_sync(["myapp/core.py"])
        assert proxy._outbound.qsize() == 0

    def test_synthetic_ids_tracked_per_file(self):
        """T5c: each file gets a unique synthetic ID tracked in _synthetic_ids."""
        import queue as _queue
        import talon.mcp.proxy_wrapper as pw

        proxy = object.__new__(pw.DirectSseProxy)
        proxy._outbound = _queue.Queue()
        proxy._pending_lock = threading.Lock()
        proxy._synthetic_ids = set()
        proxy._synthetic_counter = 0
        proxy._session_ready = threading.Event()
        proxy._session_ready.set()

        proxy._fire_cloud_sync(["a.py", "b.py", "c.py"])
        assert len(proxy._synthetic_ids) == 3
        # All IDs are unique
        assert len(proxy._synthetic_ids) == len(set(proxy._synthetic_ids))


# ---------------------------------------------------------------------------
# T6 — MemoryStore included in wheel (pyproject.toml)
# ---------------------------------------------------------------------------

class TestT6WheelInclusion:
    def test_memory_store_not_in_exclude_list(self):
        """T6: memory_store.py is not in the wheel exclude list."""
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject.read_text()
        assert '"src/talon/cache/memory_store.py"' not in content, (
            "memory_store.py is still in the exclude list — it must ship in the wheel"
        )

    def test_memory_store_importable(self):
        """T6b: MemoryStore can be imported from the client package."""
        from talon.cache.memory_store import MemoryStore
        ms = MemoryStore()
        assert hasattr(ms, "build")
        assert hasattr(ms, "refresh_file")
        assert hasattr(ms, "get_lines")
        assert hasattr(ms, "locate_symbol")
        assert hasattr(ms, "invalidate")


# ---------------------------------------------------------------------------
# T7 — Full local session smoke test
# ---------------------------------------------------------------------------

class TestT7LocalSessionSmoke:
    def test_gal_srb_edit_cycle(self, tmp_path):
        """T7: GAL→SRB→edit_batch→SRB shows refreshed content (no stale reads)."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # Step 1: SRB line-range (simulates post-GAL context read)
        targets = [{"file": "myapp/core.py", "lines": "1-3"}]
        before = pw._srb_local(targets)
        assert before is not None and "Widget" in before

        # Step 2: edit_batch
        edits = [{
            "file_path": str(project / "myapp" / "core.py"),
            "old_string": "class Widget:",
            "new_string": "class SuperWidget:",
        }]
        result, edited = pw._edit_batch_local(edits, project)
        assert "[OK]" in result
        assert len(edited) == 1

        # Step 3: SRB again — must NOT return stale pre-edit content
        after = pw._srb_local(targets)
        assert after is not None
        # Either MemoryStore was refreshed (SuperWidget) or disk fallback (SuperWidget on disk)
        disk_content = (project / "myapp" / "core.py").read_text()
        assert "SuperWidget" in disk_content, "Edit was not applied to disk"
        # Key assertion: no stale Widget in result
        assert "class Widget:" not in after, "Stale content returned after edit"


# ---------------------------------------------------------------------------
# T8 — _srb_lookup_symbol helper
# ---------------------------------------------------------------------------

class TestT8SrbLookupSymbol:
    def test_lookup_known_symbol(self, tmp_path):
        """T8a: _srb_lookup_symbol finds a known function in MemoryStore."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        body = pw._srb_lookup_symbol("myapp/core.py", "process")
        assert body is not None
        assert "process" in body

    def test_lookup_unknown_symbol_returns_none(self, tmp_path):
        """T8b: _srb_lookup_symbol returns None for unknown symbol."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        body = pw._srb_lookup_symbol("myapp/core.py", "xyz_does_not_exist")
        assert body is None

    def test_lookup_with_no_store_returns_none(self):
        """T8c: _srb_lookup_symbol returns None when MemoryStore is not built."""
        import talon.mcp.proxy_wrapper as pw
        orig = pw._memory_store
        pw._memory_store = None
        try:
            result = pw._srb_lookup_symbol("any/file.py", "any_symbol")
            assert result is None
        finally:
            pw._memory_store = orig

    def test_lookup_file_filter_applied(self, tmp_path):
        """T8d: symbol lookup respects file_path filter."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # "helper" exists in utils.py, not core.py — file filter should work
        body_correct = pw._srb_lookup_symbol("myapp/utils.py", "helper")
        body_wrong = pw._srb_lookup_symbol("myapp/core.py", "helper")
        # helper is in utils.py so correct file should find it
        assert body_correct is not None
        # Wrong file — may return None or correct result depending on fuzzy match behaviour
        # Key: it should not crash
        assert body_wrong is None or isinstance(body_wrong, str)


# ---------------------------------------------------------------------------
# T-GAL — GAL body injection via __TALON_REFS__
# ---------------------------------------------------------------------------

def _make_gal_sse_response(call_id: int | str, text: str) -> str:
    """Build a minimal JSON-RPC SSE data payload simulating a GAL cloud response."""
    return json.dumps({
        "jsonrpc": "2.0",
        "id": call_id,
        "result": {
            "content": [{"type": "text", "text": text}],
            "isError": False,
        },
    })


class TestTGalBodyInjection:
    def test_inject_extracts_refs_and_injects_bodies(self, tmp_path):
        """T-GAL-1: _inject_gal_bodies looks up MemoryStore bodies for __TALON_REFS__."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        refs = [{"f": "myapp/core.py", "ls": 1, "le": 3}]
        text = f"GAL output\n\n__TALON_REFS__:{json.dumps(refs)}"
        raw = _make_gal_sse_response(1, text)

        result = pw._inject_gal_bodies(raw)
        parsed = json.loads(result)
        out_text = parsed["result"]["content"][0]["text"]

        assert "__TALON_REFS__:" not in out_text, "Marker should be removed"
        assert "Source Bodies" in out_text or "myapp/core.py" in out_text, "Bodies not injected"

    def test_inject_removes_marker_no_bodies_when_not_found(self, tmp_path):
        """T-GAL-2: marker removed even when MemoryStore has no matching lines."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        refs = [{"f": "nonexistent/file.py", "ls": 1, "le": 10}]
        text = f"GAL output\n\n__TALON_REFS__:{json.dumps(refs)}"
        raw = _make_gal_sse_response(2, text)

        result = pw._inject_gal_bodies(raw)
        parsed = json.loads(result)
        out_text = parsed["result"]["content"][0]["text"]
        assert "__TALON_REFS__:" not in out_text

    def test_inject_noop_when_no_marker(self):
        """T-GAL-3: _inject_gal_bodies is a no-op when __TALON_REFS__ absent."""
        import talon.mcp.proxy_wrapper as pw
        raw = _make_gal_sse_response(3, "plain GAL output with no refs")
        result = pw._inject_gal_bodies(raw)
        assert json.loads(result)["result"]["content"][0]["text"] == "plain GAL output with no refs"

    def test_inject_noop_when_store_not_ready(self, monkeypatch):
        """T-GAL-4: _inject_gal_bodies is a no-op when MemoryStore is None."""
        import talon.mcp.proxy_wrapper as pw
        monkeypatch.setattr(pw, "_memory_store", None)
        refs = [{"f": "myapp/core.py", "ls": 1, "le": 3}]
        text = f"output\n\n__TALON_REFS__:{json.dumps(refs)}"
        raw = _make_gal_sse_response(4, text)
        result = pw._inject_gal_bodies(raw)
        # Returned unchanged — marker still present
        assert "__TALON_REFS__:" in json.loads(result)["result"]["content"][0]["text"]

    def test_inject_handles_invalid_json_gracefully(self):
        """T-GAL-5: malformed __TALON_REFS__ JSON returns raw_data unchanged."""
        import talon.mcp.proxy_wrapper as pw
        text = "output\n\n__TALON_REFS__:NOT_VALID_JSON"
        raw = _make_gal_sse_response(5, text)
        result = pw._inject_gal_bodies(raw)
        # Should not raise; returns original
        assert "__TALON_REFS__:" in json.loads(result)["result"]["content"][0]["text"]

    def test_full_gal_srb_edit_cycle_with_injection(self, tmp_path):
        """T-GAL-6: inject→SRB→edit shows no stale content (end-to-end local cycle)."""
        import talon.mcp.proxy_wrapper as pw
        project = _make_project(tmp_path)
        ms = _fresh_store(project)
        pw._memory_store = ms

        # Simulate GAL response with refs for core.py lines 1-3
        refs = [{"f": "myapp/core.py", "ls": 1, "le": 3}]
        text = f"## Context\n\n__TALON_REFS__:{json.dumps(refs)}"
        raw = _make_gal_sse_response(10, text)
        injected = pw._inject_gal_bodies(raw)
        injected_text = json.loads(injected)["result"]["content"][0]["text"]
        # Bodies injected — should contain "Widget" from line 1 of core.py
        assert "Widget" in injected_text or "Source Bodies" in injected_text

        # Now edit the file
        edits = [{
            "file_path": str(project / "myapp" / "core.py"),
            "old_string": "class Widget:",
            "new_string": "class UltraWidget:",
        }]
        result, edited = pw._edit_batch_local(edits, project)
        assert "[OK]" in result

        # SRB after edit should see fresh content
        after = pw._srb_local([{"file": "myapp/core.py", "lines": "1-1"}])
        disk = (project / "myapp" / "core.py").read_text()
        assert "UltraWidget" in disk
        assert after is None or "Widget:" not in after or "UltraWidget" in after
