"""Phase 8 local smoke harness — exercises every fault code in the catalog.

Walks the 21 fault codes from `talon.diag.faults.FAULT_CATALOG`, forces each
through the classifier + emitter, and verifies:

  1. classify(exc, ctx) returns the expected fault for each forcing input
  2. emit(fault, ...) writes the right line to the per-component log
  3. emit(fault, ...) prints the user-facing 3-line block to stderr

This is the local equivalent of the "Phase 8 manual smoke" matrix from
memory `project_client_diag_phases_7_8_pending.md`. Live verification
against a deployed cogz-api still requires the deploy window.

Run: pytest tests/test_diag_fault_smoke.py -v
Coverage report: pytest tests/test_diag_fault_smoke.py --report-csv=fault_coverage.csv
"""
from __future__ import annotations

import io
import json
import logging
import socket
import ssl
import sys
from contextlib import redirect_stderr
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from talon.diag import FAULT_CATALOG, classify, emit, setup  # noqa: E402
from talon.diag.logger import reset_cache  # noqa: E402
from talon.diag.state import set_debug_override  # noqa: E402


# ---------------------------------------------------------------------------
# Forcing matrix — for each fault code, the (exception, context) pair
# that should trigger it. Mirrors the force matrix in the pending-phases memory.
# ---------------------------------------------------------------------------

FORCING_MATRIX: dict[str, tuple[Exception, dict]] = {
    "AUTH-001": (Exception("rejected"), {"op": "auth", "http_status": 401, "url": "https://api.cogmeta.ai/me"}),
    "AUTH-002": (FileNotFoundError("No such file: credentials.json"), {"op": "auth_load"}),
    "AUTH-003": (Exception("Login timed out after 5 minutes"), {"op": "login"}),
    # AUTH-004 (key TTL >7d) is detected proactively by the renewal hook;
    # not a classify() input — verified separately in test_diag_faults.py
    "NET-001": (ConnectionRefusedError("Connection refused"), {"op": "any", "url": "https://api.cogmeta.ai/x"}),
    "NET-002": (ConnectionResetError("Connection reset by peer"), {"op": "any"}),
    "NET-003": (Exception("backoff exhausted"), {"op": "proxy_sse", "retries_exhausted": True}),
    "NET-004": (ssl.SSLError("certificate verify failed"), {"op": "any"}),
    "IDX-002": (Exception("upload server error"),
                {"op": "index", "http_status": 500, "url": "https://api/cloud/v1/projects/index-data"}),
    "IDX-003": (Exception("No supported files found in tree"), {"op": "index"}),
    "IDX-004": (Exception("ALB timeout"),
                {"op": "index", "http_status": 504, "url": "https://api.cogmeta.ai/cloud/v1/projects/index-data"}),
    # IDX-001 (parse rate >10%) is detected by the indexer aggregator,
    # not classify() — exercised separately below in test_idx_001_emit_path
    "STATUS-001": (Exception("unhealthy"),
                   {"op": "health", "http_status": 503, "url": "https://api.cogmeta.ai/health"}),
    "CFG-001": (Exception(".mcp.json invalid"), {"op": "init"}),
    "CFG-002": (Exception("credentials.json json decode error"), {"op": "credentials_load"}),
    "UPG-001": (Exception("Install timed out after 5 minutes"), {"op": "upgrade"}),
    "UPG-002": (Exception("rollback failed"), {"op": "upgrade_rollback"}),
    "LLM-001": (Exception("rate limit"),
                {"http_status": 429, "url": "https://api.anthropic.com/v1/messages"}),
    # LLM-002 (no LLM response after tool use) is detected from transcript
    # analysis, not classify() — covered by separate transcript tests
    # MCP-001 / MCP-002 emit via proxy_wrapper internal paths, not classify()
}


# ---------------------------------------------------------------------------
# Test 1: classify() coverage — every code with a classify path is reachable
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("code,inputs", list(FORCING_MATRIX.items()))
def test_classify_reaches_each_fault(code, inputs):
    """For each forcing input, classify() returns the expected fault code."""
    exc, ctx = inputs
    fault = classify(exc, ctx)
    assert fault is not None, f"classify() returned None for {code}"
    assert fault.code == code, (
        f"Expected {code} but got {fault.code} for inputs: exc={exc!r}, ctx={ctx}"
    )


# ---------------------------------------------------------------------------
# Test 2: emit() user-facing block — verify the 3-line stderr render
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("code", list(FORCING_MATRIX.keys()))
def test_emit_renders_user_block(code):
    """For each fault, emit() writes the 3-line block (✗/!/i + → + Details:) to stderr."""
    fault = FAULT_CATALOG[code]
    captured = io.StringIO()
    with redirect_stderr(captured):
        emit(fault, {"smoke": True}, logger=None, show_user=True, log_path="/tmp/smoke.log")
    out = captured.getvalue()
    # Severity marker line
    expected_marker = {"info": "i", "warn": "!", "error": "✗", "fatal": "✗"}.get(fault.severity, "✗")
    assert f"{expected_marker} {code}" in out, f"Marker line missing for {code}: {out!r}"
    assert fault.message in out, f"Message missing for {code}"
    # Remediation line
    assert "→" in out and fault.remediation in out, f"Remediation missing for {code}"
    # Details line
    assert "/tmp/smoke.log" in out, f"Log path missing for {code}"


# ---------------------------------------------------------------------------
# Test 3: emit() log line — verify the per-component log gets the structured entry
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("code", list(FORCING_MATRIX.keys()))
def test_emit_writes_log_line(tmp_path, monkeypatch, code):
    """For each fault, emit() writes a structured log line containing the code."""
    # LOG_DIR is computed at module import; monkeypatch the constant so the
    # rotating handler points at our tmp_path
    log_dir = tmp_path / ".talon" / "logs"
    monkeypatch.setattr("talon.diag.logger.LOG_DIR", log_dir)
    set_debug_override(None)
    reset_cache()

    logger = setup("cli")
    fault = FAULT_CATALOG[code]
    emit(fault, {"smoke": True, "code": code}, logger=logger, show_user=False)

    for h in logger.handlers:
        h.flush()

    log_path = log_dir / "cli.log"
    assert log_path.exists(), f"Log file not created for {code}: {log_path}"
    contents = log_path.read_text()
    assert f"[{code}]" in contents, f"Code tag missing in log for {code}: {contents!r}"
    assert fault.message in contents, f"Message missing in log for {code}"
    assert "smoke" in contents, f"Details missing in log for {code}"


# ---------------------------------------------------------------------------
# Test 4: severity → log level mapping
# ---------------------------------------------------------------------------

SEVERITY_TO_LOG_LEVEL = {
    "info": logging.INFO,
    "warn": logging.WARNING,
    "error": logging.ERROR,
    "fatal": logging.CRITICAL,
}


class _CapturingHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record):
        self.records.append(record)


@pytest.mark.parametrize("code", list(FORCING_MATRIX.keys()))
def test_emit_uses_correct_log_level(tmp_path, monkeypatch, code):
    """Each fault's severity maps to the right log level when emit() runs.

    We attach our own handler directly to the diag logger because the diag
    logger has propagate=False (intentional — keeps handlers explicit) so
    pytest's caplog (which hooks the root logger) doesn't see records.
    """
    log_dir = tmp_path / ".talon" / "logs"
    monkeypatch.setattr("talon.diag.logger.LOG_DIR", log_dir)
    set_debug_override(None)
    reset_cache()

    logger = setup("cli")
    cap = _CapturingHandler()
    cap.setLevel(logging.DEBUG)
    logger.addHandler(cap)

    fault = FAULT_CATALOG[code]
    expected_level = SEVERITY_TO_LOG_LEVEL.get(fault.severity, logging.ERROR)

    emit(fault, {}, logger=logger, show_user=False)

    matching = [r for r in cap.records if f"[{code}]" in r.getMessage()]
    assert matching, f"No log record for {code}"
    assert matching[0].levelno == expected_level, (
        f"{code} (severity={fault.severity}) emitted at {matching[0].levelname}, "
        f"expected {logging.getLevelName(expected_level)}"
    )


# ---------------------------------------------------------------------------
# Test 5: catalog completeness — every code in FAULT_CATALOG either has a
# forcing input here OR is documented as detected outside classify()
# ---------------------------------------------------------------------------

# Codes detected outside classify() — verified by integration tests elsewhere
NON_CLASSIFY_CODES = {
    "AUTH-004",  # API key TTL — proactive renewal hook check
    "IDX-001",   # parse-rate aggregator in indexer/cli.py
    "MCP-001",   # proxy_wrapper SSE timeout watchdog
    "MCP-002",   # proxy_wrapper JSON-RPC parser
    "LLM-002",   # transcript-analysis path
}


def test_catalog_completeness():
    """Every code in FAULT_CATALOG is either in FORCING_MATRIX or NON_CLASSIFY_CODES."""
    catalog_codes = set(FAULT_CATALOG.keys())
    forcing_codes = set(FORCING_MATRIX.keys())
    classify_only = forcing_codes & NON_CLASSIFY_CODES
    assert not classify_only, (
        f"Codes are in BOTH forcing matrix AND non-classify set: {classify_only}"
    )
    accounted = forcing_codes | NON_CLASSIFY_CODES
    missing = catalog_codes - accounted
    assert not missing, (
        f"Codes in FAULT_CATALOG not covered by forcing matrix or marked non-classify: {missing}"
    )
    extra = forcing_codes - catalog_codes
    assert not extra, f"Forcing matrix references codes not in FAULT_CATALOG: {extra}"


# ---------------------------------------------------------------------------
# Test 6: IDX-001 — exercised via the indexer's aggregator path (not classify)
# ---------------------------------------------------------------------------

def test_idx_001_emit_path(tmp_path, monkeypatch):
    """IDX-001 fires when emit() is called directly with the fault from the catalog."""
    monkeypatch.setenv("HOME", str(tmp_path))
    set_debug_override(None)
    reset_cache()
    logger = setup("indexer")
    fault = FAULT_CATALOG["IDX-001"]
    captured = io.StringIO()
    with redirect_stderr(captured):
        emit(fault, {"failed": 5, "total": 30, "rate_pct": 16.7},
             logger=logger, show_user=True, log_path=str(tmp_path / "indexer.log"))
    out = captured.getvalue()
    assert "IDX-001" in out
    assert "Index quality degraded" in out
    assert "talon-index --debug" in out


# ---------------------------------------------------------------------------
# Test 7: severity-marker variety — verify info/warn/error/fatal markers all render
# ---------------------------------------------------------------------------

def test_all_severity_markers_render():
    """Each severity in the catalog renders its expected marker symbol."""
    severities_in_catalog = {f.severity for f in FAULT_CATALOG.values()}
    expected_markers = {"info": "i", "warn": "!", "error": "✗", "fatal": "✗"}
    for sev in severities_in_catalog:
        assert sev in expected_markers, f"Unknown severity {sev!r} in catalog"


# ---------------------------------------------------------------------------
# Test 8: phase-8 fault-coverage report — produces a CSV for QA / support
# ---------------------------------------------------------------------------

def test_emit_phase8_coverage_report(tmp_path, capsys):
    """Generates a fault-coverage report row per code. Useful for support QA.

    Output written to stdout when run with -s; suppressed in normal test runs.
    """
    rows = []
    for code, fault in sorted(FAULT_CATALOG.items()):
        in_matrix = code in FORCING_MATRIX
        non_classify = code in NON_CLASSIFY_CODES
        rows.append({
            "code": code,
            "severity": fault.severity,
            "message": fault.message,
            "remediation": fault.remediation,
            "classify_reachable": in_matrix,
            "detection_path": "classify()" if in_matrix else (
                "non-classify (caller emits directly)" if non_classify else "UNCOVERED"
            ),
        })
    print()  # newline after pytest progress
    print(f"{'CODE':<14} {'SEV':<7} {'PATH':<35} {'MESSAGE'}")
    print("-" * 100)
    for row in rows:
        print(f"{row['code']:<14} {row['severity']:<7} {row['detection_path']:<35} {row['message']}")
    # Persist to tmp for archival
    out_path = tmp_path / "fault_coverage.json"
    out_path.write_text(json.dumps(rows, indent=2))
    # All rows must have a real detection_path (no UNCOVERED)
    uncovered = [r["code"] for r in rows if r["detection_path"] == "UNCOVERED"]
    assert not uncovered, f"Codes without detection path: {uncovered}"


# ---------------------------------------------------------------------------
# Reset diag state between tests to avoid logger-cache pollution
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_diag_state():
    set_debug_override(None)
    reset_cache()
    yield
    set_debug_override(None)
    reset_cache()
