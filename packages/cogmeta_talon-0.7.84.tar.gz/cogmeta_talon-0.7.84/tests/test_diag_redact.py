"""Redaction contract tests — these are the leak-prevention guarantees.

If any of these fail, secrets are escaping into log files. Treat as a
release-blocking regression.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from talon.diag.redact import redact, redact_json_text  # noqa: E402


def test_anthropic_style_key_redacted():
    secret = "sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz1234567890"
    out = redact(f"using key {secret} for request")
    assert secret not in out
    assert "sk-ant-" in out  # prefix preserved for debugging
    assert "<redacted>" in out


def test_aws_access_key_redacted():
    text = "key AKIAIOSFODNN7EXAMPLE used"
    out = redact(text)
    assert "AKIAIOSFODNN7EXAMPLE" not in out
    assert "<redacted-aws-key>" in out


def test_bearer_token_redacted():
    text = "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.AbCdEfGhIjKlMnOp.SiGnAtUrEsTuFf12345"
    out = redact(text)
    assert "AbCdEf" not in out
    assert "Bearer <redacted>" in out or "<redacted-jwt>" in out


def test_credentials_json_round_trip():
    """Simulate full credentials.json contents being passed to redact()."""
    creds = {
        "api_key": "sk-ant-api03-Secret_Production_KeyPRODUCTION1234567890XXX",
        "access_token": "eyJhbGciOiJIUzI1NiJ9.AbCdEfGhIjKl.MnOpQrStUvWx",
        "refresh_token": "rt-abc-12345-SECRET",
        "email": "user@example.com",
        "cloud_url": "https://api.cogmeta.ai",
    }
    out = redact(creds)
    raw = json.dumps(out)
    # Sensitive values stripped
    assert "sk-ant-api03-Secret" not in raw
    assert "rt-abc-12345-SECRET" not in raw
    assert "eyJhbGciOiJIUzI1NiJ9" not in raw
    # Non-sensitive values preserved
    assert "user@example.com" in raw
    assert "api.cogmeta.ai" in raw


def test_nested_dict_redaction():
    payload = {
        "request": {
            "headers": {"Authorization": "Bearer SECRET-TOKEN-HERE"},
            "body": {"api_key": "sk-leak", "user": "alice"},
        }
    }
    out = redact(payload)
    flat = json.dumps(out)
    assert "SECRET-TOKEN-HERE" not in flat
    assert "sk-leak" not in flat
    assert "alice" in flat  # non-sensitive preserved


def test_list_of_dicts_redaction():
    items = [{"api_key": "sk-1"}, {"api_key": "sk-2"}, {"name": "ok"}]
    out = redact(items)
    flat = json.dumps(out)
    assert "sk-1" not in flat
    assert "sk-2" not in flat
    assert "ok" in flat


def test_pem_block_redacted():
    pem = (
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIIEpAIBAAKCAQEA1x... lots of base64 ...\n"
        "-----END RSA PRIVATE KEY-----"
    )
    out = redact(f"key follows: {pem} done")
    assert "MIIEpAIBAAKCAQEA1x" not in out
    assert "<redacted-pem>" in out


def test_redact_json_text_parses_when_valid():
    raw = '{"api_key":"sk-leakable","x":1}'
    out = redact_json_text(raw)
    assert "sk-leakable" not in out
    assert '"x":1' in out


def test_redact_json_text_falls_back_when_invalid():
    raw = "not json sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz1234567890 trailing"
    out = redact_json_text(raw)
    assert "AbCdEfGhIjKlMnOpQrStUvWxYz1234567890" not in out


def test_bytes_input_decoded_and_redacted():
    raw = b"key sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz1234567890 in bytes"
    out = redact(raw)
    assert isinstance(out, str)
    assert "AbCdEfGhIjKlMnOpQrStUvWxYz1234567890" not in out


def test_non_string_scalars_passthrough():
    assert redact(42) == 42
    assert redact(None) is None
    assert redact(True) is True


def test_case_insensitive_sensitive_keys():
    payload = {"Api_Key": "sk-leak", "AUTHORIZATION": "Bearer T", "Password": "hunter2"}
    out = redact(payload)
    flat = json.dumps(out)
    assert "sk-leak" not in flat
    assert "hunter2" not in flat


def test_renewal_key_redacted():
    payload = {"renewal_key": "renew-secret-123", "last_renewed": 12345}
    out = redact(payload)
    assert out["renewal_key"] == "<redacted>"
    assert out["last_renewed"] == 12345


def test_repeated_secrets_all_redacted():
    """If a secret appears twice in the same string, redact both."""
    sk = "sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz1234567890"
    text = f"first {sk} and again {sk} done"
    out = redact(text)
    assert sk not in out
    assert out.count("<redacted>") == 2


# ---------------------------------------------------------------------------
# 06_security.md [MEDIUM] AWS secret-key + session-token coverage.
# ---------------------------------------------------------------------------

def test_aws_secret_access_key_redacted_via_assignment():
    """`aws_secret_access_key=<40-char>` must be scrubbed regardless of
    underscore/hyphen / case style."""
    secret = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    for line in [
        f"aws_secret_access_key={secret}",
        f"AWS_SECRET_ACCESS_KEY: {secret}",
        f"aws-secret-access-key={secret}",
        f'AWS_Secret_Access_Key = "{secret}"',
    ]:
        out = redact(line)
        assert secret not in out, f"secret leaked from {line!r} → {out!r}"
        assert "<redacted-aws-secret>" in out


def test_aws_session_token_redacted_via_assignment():
    """Session tokens are >=40 chars and base64-ish — match the assignment label."""
    token = "AQoDYXdzEPT//////////wEXAMPLEFAKETOKENaddress="
    out = redact(f"aws_session_token={token}")
    assert token not in out
    assert "<redacted-aws-session-token>" in out


def test_aws_secret_redacted_in_json_dict():
    """JSON dump with `aws_secret_access_key` as a key must redact the value
    even though no `=` / `:` assignment delimiter sits in the string itself
    — covered by `_SENSITIVE_KEYS` membership."""
    payload = {"aws_secret_access_key": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
               "aws_access_key_id": "AKIAIOSFODNN7EXAMPLE",
               "aws_session_token": "AQoDYXdzEPT//////////wEXAMPLEFAKETOKENaddress",
               "harmless": "ok"}
    out = redact(payload)
    assert out["aws_secret_access_key"] == "<redacted>"
    assert out["aws_access_key_id"] == "<redacted>"
    assert out["aws_session_token"] == "<redacted>"
    assert out["harmless"] == "ok"


def test_aws_secret_no_false_positive_on_random_40_chars():
    """A random 40-char alphanumeric string in unrelated text should NOT be
    redacted — the regex anchors on the assignment label (`aws_secret_…=`).
    Otherwise we'd false-positive on hashes, base64 fragments, etc."""
    text = "the file hash is xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx done"
    out = redact(text)
    assert out == text  # unchanged


def test_aws_redact_handles_quoted_value():
    """Quotes around the value (common in JSON / yaml dumps) must not
    prevent matching."""
    secret = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    out = redact(f'aws_secret_access_key="{secret}"')
    assert secret not in out
