use std::path::Path;

use linguafranca::chat_completions_openai::convert::stream::{
    ChatCompletionsToOpenResponsesStream, OpenResponsesToChatCompletionsStream,
};
use linguafranca::chat_completions_openai::request::ChatCompletionsOpenAiRequest;
use linguafranca::chat_completions_openai::response::ChatCompletionsOpenAiResponse;
use linguafranca::chat_completions_openai::stream::ChatCompletionsStreamChunk;
use linguafranca::open_responses::request::OpenResponsesRequest;
use linguafranca::open_responses::response::OpenResponsesResponse;
use linguafranca::open_responses::stream::OpenResponsesStreamEvent;
use linguafranca::stream::StreamTransform;
use rstest::rstest;

mod common;

#[derive(Clone, Copy)]
enum Direction {
    ChatCompletionsToOpenResponses,
    OpenResponsesToChatCompletions,
}

fn run(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!(
        "tests/fixtures/chat_completions_openai/request/{case}"
    ));

    match direction {
        Direction::ChatCompletionsToOpenResponses => {
            let label = format!("{case} Chat Completions -> Open Responses");
            common::run_into_open_responses_case::<
                ChatCompletionsOpenAiRequest,
                OpenResponsesRequest,
            >(
                case,
                &dir,
                "chat_completions.json",
                "open_responses.json",
                "chat_completions_to_open_responses",
                label.as_str(),
            );
        }
        Direction::OpenResponsesToChatCompletions => {
            let label = format!("{case} Open Responses -> Chat Completions");
            common::run_from_open_responses_case::<
                ChatCompletionsOpenAiRequest,
                OpenResponsesRequest,
            >(
                case,
                &dir,
                "chat_completions.json",
                "open_responses.json",
                "open_responses_to_chat_completions",
                label.as_str(),
            );
        }
    }
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::multi_turn("multi_turn")]
#[case::with_tools("with_tools")]
#[case::with_image("with_image")]
#[case::with_image_url("with_image_url")]
#[case::system_and_developer_roles("system_and_developer_roles")]
#[case::tool_conversation_order("tool_conversation_order")]
#[case::reasoning_and_text_config("reasoning_and_text_config")]
fn chat_completions_to_open_responses_bidirectional(#[case] case: &str) {
    run(case, Direction::ChatCompletionsToOpenResponses);
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::multi_turn("multi_turn")]
#[case::with_tools("with_tools")]
#[case::with_image("with_image")]
#[case::with_image_url("with_image_url")]
#[case::system_and_developer_roles("system_and_developer_roles")]
#[case::tool_conversation_order("tool_conversation_order")]
#[case::reasoning_and_text_config("reasoning_and_text_config")]
fn open_responses_to_chat_completions_bidirectional(#[case] case: &str) {
    run(case, Direction::OpenResponsesToChatCompletions);
}

#[rstest]
#[case::dropped_fields_chat_completions("dropped_fields_chat_completions")]
#[case::lossy_parameter_normalization("lossy_parameter_normalization")]
#[case::reasoning_effort_mapping("reasoning_effort_mapping")]
#[case::reasoning_content_items("reasoning_content_items")]
fn chat_completions_to_open_responses_only(#[case] case: &str) {
    run(case, Direction::ChatCompletionsToOpenResponses);
}

#[rstest]
#[case::include_logprobs_clamping("include_logprobs_clamping")]
#[case::tool_choice_missing_name("tool_choice_missing_name")]
#[case::item_reference_ordering("item_reference_ordering")]
#[case::stream_usage_defaults("stream_usage_defaults")]
#[case::dropped_fields_open_responses("dropped_fields_open_responses")]
#[case::reasoning_summary_dropped("reasoning_summary_dropped")]
#[case::max_output_tokens_mapping("max_output_tokens_mapping")]
#[case::simple_text_input_string("simple_text_input_string")]
#[case::reasoning_items_input("reasoning_items_input")]
fn open_responses_to_chat_completions_only(#[case] case: &str) {
    run(case, Direction::OpenResponsesToChatCompletions);
}

fn run_response(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!(
        "tests/fixtures/chat_completions_openai/response/{case}"
    ));

    match direction {
        Direction::ChatCompletionsToOpenResponses => {
            let label = format!("{case} Chat Completions Response -> Open Responses");
            common::run_into_open_responses_case::<
                ChatCompletionsOpenAiResponse,
                OpenResponsesResponse,
            >(
                case,
                &dir,
                "chat_completions.json",
                "open_responses.json",
                "chat_completions_to_open_responses",
                label.as_str(),
            );
        }
        Direction::OpenResponsesToChatCompletions => {
            let label = format!("{case} Open Responses -> Chat Completions Response");
            common::run_from_open_responses_case::<
                ChatCompletionsOpenAiResponse,
                OpenResponsesResponse,
            >(
                case,
                &dir,
                "chat_completions.json",
                "open_responses.json",
                "open_responses_to_chat_completions",
                label.as_str(),
            );
        }
    }
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::tool_calls_and_reasoning("tool_calls_and_reasoning")]
#[case::with_refusal("with_refusal")]
#[case::with_annotations("with_annotations")]
#[case::max_tokens("max_tokens")]
#[case::failed_status("failed_status")]
#[case::usage_with_details("usage_with_details")]
fn resp_chat_completions_to_open_responses_bidirectional(#[case] case: &str) {
    run_response(case, Direction::ChatCompletionsToOpenResponses);
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::tool_calls_and_reasoning("tool_calls_and_reasoning")]
#[case::with_refusal("with_refusal")]
#[case::with_annotations("with_annotations")]
#[case::max_tokens("max_tokens")]
#[case::failed_status("failed_status")]
#[case::usage_with_details("usage_with_details")]
fn resp_open_responses_to_chat_completions_bidirectional(#[case] case: &str) {
    run_response(case, Direction::OpenResponsesToChatCompletions);
}

#[rstest]
#[case::multiple_choices_first_only("multiple_choices_first_only")]
#[case::choice_logprobs_dropped("choice_logprobs_dropped")]
#[case::annotations_without_content_dropped("annotations_without_content_dropped")]
#[case::audio_dropped("audio_dropped")]
#[case::custom_tool_call_downgraded("custom_tool_call_downgraded")]
#[case::service_tier_scale_mapped_to_priority("service_tier_scale_mapped_to_priority")]
#[case::unknown_service_tier_dropped("unknown_service_tier_dropped")]
#[case::non_assistant_role_warned("non_assistant_role_warned")]
fn resp_chat_completions_to_open_responses_only(#[case] case: &str) {
    run_response(case, Direction::ChatCompletionsToOpenResponses);
}

#[rstest]
#[case::dropped_fields_open_responses("dropped_fields_open_responses")]
#[case::non_terminal_status_finish_reason_omitted("non_terminal_status_finish_reason_omitted")]
#[case::function_call_output_dropped("function_call_output_dropped")]
#[case::non_assistant_output_message_dropped("non_assistant_output_message_dropped")]
#[case::output_text_logprobs_dropped("output_text_logprobs_dropped")]
#[case::input_type_content_parts_dropped("input_type_content_parts_dropped")]
#[case::reasoning_summary_and_content_joined("reasoning_summary_and_content_joined")]
#[case::content_and_refusal_joining("content_and_refusal_joining")]
fn resp_open_responses_to_chat_completions_only(#[case] case: &str) {
    run_response(case, Direction::OpenResponsesToChatCompletions);
}

fn run_stream(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!(
        "tests/fixtures/chat_completions_openai/stream/{case}"
    ));

    match direction {
        Direction::ChatCompletionsToOpenResponses => {
            let input: Vec<ChatCompletionsStreamChunk> =
                common::load_fixture(&dir.join("chat_completions_events.json"), case);
            let mut stream = ChatCompletionsToOpenResponsesStream::new();
            let mut actual_events = Vec::new();
            for (i, event) in input.into_iter().enumerate() {
                actual_events.extend(stream.transform(event).expect(
                    format!("{case} stream CC->OR transform failed at input event #{i}").as_str(),
                ));
            }
            actual_events.extend(
                stream
                    .flush()
                    .expect(format!("{case} stream CC->OR flush failed").as_str()),
            );
            let warnings = stream.take_warnings();

            let expected: Vec<OpenResponsesStreamEvent> =
                common::load_fixture(&dir.join("open_responses_events.json"), case);
            let label = format!("{case} stream Chat Completions -> Open Responses");
            let actual_json = serde_json::to_value(&actual_events).expect(
                format!("{case} stream CC->OR failed to serialize actual events to JSON").as_str(),
            );
            let expected_json = serde_json::to_value(&expected).expect(
                format!("{case} stream CC->OR failed to serialize expected events to JSON")
                    .as_str(),
            );
            common::assert_json_eq(&actual_json, &expected_json, label.as_str());
            common::check_warnings(&dir, "chat_completions_to_open_responses", warnings, case);
        }
        Direction::OpenResponsesToChatCompletions => {
            let input: Vec<OpenResponsesStreamEvent> =
                common::load_fixture(&dir.join("open_responses_events.json"), case);
            let mut stream = OpenResponsesToChatCompletionsStream::new();
            let mut actual_events = Vec::new();
            for (i, event) in input.into_iter().enumerate() {
                actual_events.extend(stream.transform(event).expect(
                    format!("{case} stream OR->CC transform failed at input event #{i}").as_str(),
                ));
            }
            actual_events.extend(
                stream
                    .flush()
                    .expect(format!("{case} stream OR->CC flush failed").as_str()),
            );
            let warnings = stream.take_warnings();

            let expected: Vec<ChatCompletionsStreamChunk> =
                common::load_fixture(&dir.join("chat_completions_events.json"), case);
            let label = format!("{case} stream Open Responses -> Chat Completions");
            let actual_json = serde_json::to_value(&actual_events).expect(
                format!("{case} stream OR->CC failed to serialize actual events to JSON").as_str(),
            );
            let expected_json = serde_json::to_value(&expected).expect(
                format!("{case} stream OR->CC failed to serialize expected events to JSON")
                    .as_str(),
            );
            common::assert_json_eq(&actual_json, &expected_json, label.as_str());
            common::check_warnings(&dir, "open_responses_to_chat_completions", warnings, case);
        }
    }
}

#[rstest]
#[case::max_tokens("max_tokens_from_cc")]
#[case::multi_output_or("multi_output_or_from_cc")]
#[case::multi_tool_use("multi_tool_use_from_cc")]
#[case::response_incomplete_or("response_incomplete_or_from_cc")]
#[case::simple_text("simple_text_from_cc")]
#[case::simple_text_or("simple_text_or_from_cc")]
#[case::thinking_and_tool_use("thinking_and_tool_use_from_cc")]
#[case::tool_use_only("tool_use_only_from_cc")]
#[case::with_annotations_or("with_annotations_or_from_cc")]
#[case::with_citations("with_citations_from_cc")]
#[case::with_function_call_or("with_function_call_or_from_cc")]
#[case::with_reasoning_no_summary_or("with_reasoning_no_summary_or_from_cc")]
#[case::with_reasoning_or("with_reasoning_or_from_cc")]
#[case::with_redacted_thinking("with_redacted_thinking_from_cc")]
#[case::with_thinking("with_thinking_from_cc")]
#[case::with_tool_use("with_tool_use_from_cc")]
fn stream_chat_completions_to_open_responses(#[case] case: &str) {
    run_stream(case, Direction::ChatCompletionsToOpenResponses);
}

#[rstest]
#[case::max_tokens("max_tokens_from_or")]
#[case::multi_output_or("multi_output_or_from_or")]
#[case::multi_tool_use("multi_tool_use_from_or")]
#[case::response_incomplete_or("response_incomplete_or_from_or")]
#[case::simple_text("simple_text_from_or")]
#[case::simple_text_or("simple_text_or_from_or")]
#[case::thinking_and_tool_use("thinking_and_tool_use_from_or")]
#[case::tool_use_only("tool_use_only_from_or")]
#[case::with_function_call_or("with_function_call_or_from_or")]
#[case::with_reasoning_no_summary_or("with_reasoning_no_summary_or_from_or")]
#[case::with_reasoning_or("with_reasoning_or_from_or")]
#[case::with_redacted_thinking("with_redacted_thinking_from_or")]
#[case::with_thinking("with_thinking_from_or")]
#[case::with_tool_use("with_tool_use_from_or")]
fn stream_open_responses_to_chat_completions(#[case] case: &str) {
    run_stream(case, Direction::OpenResponsesToChatCompletions);
}
