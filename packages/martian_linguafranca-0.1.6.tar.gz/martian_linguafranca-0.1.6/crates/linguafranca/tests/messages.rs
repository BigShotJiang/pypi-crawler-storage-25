use std::path::Path;

use linguafranca::anthropic::convert::stream::{
    AnthropicMessagesToOpenResponsesStream, OpenResponsesToAnthropicMessagesStream,
};
use linguafranca::anthropic::request::AnthropicRequest;
use linguafranca::anthropic::response::AnthropicResponse;
use linguafranca::anthropic::stream::AnthropicStreamEvent;
use linguafranca::open_responses::request::OpenResponsesRequest;
use linguafranca::open_responses::response::OpenResponsesResponse;
use linguafranca::open_responses::stream::OpenResponsesStreamEvent;
use linguafranca::stream::StreamTransform;
use rstest::rstest;

mod common;

enum Direction {
    AnthropicMessagesToOpenResponses,
    OpenResponsesToAnthropicMessages,
}

fn run(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join(format!("tests/fixtures/anthropic_messages/request/{case}"));

    match direction {
        Direction::AnthropicMessagesToOpenResponses => {
            let label = format!("{case} Anthropic Messages -> Open Responses");
            common::run_into_open_responses_case::<AnthropicRequest, OpenResponsesRequest>(
                case,
                &dir,
                "messages.json",
                "open_responses.json",
                "messages_to_open_responses",
                label.as_str(),
            );
        }
        Direction::OpenResponsesToAnthropicMessages => {
            let label = format!("{case} Open Responses -> Anthropic Messages");
            common::run_from_open_responses_case::<AnthropicRequest, OpenResponsesRequest>(
                case,
                &dir,
                "messages.json",
                "open_responses.json",
                "open_responses_to_messages",
                label.as_str(),
            );
        }
    }
}

// ── Bidirectional ──

#[rstest]
#[case::simple_text("simple_text")]
#[case::with_system("with_system")]
#[case::system_blocks("system_blocks")]
#[case::multi_turn("multi_turn")]
#[case::with_tools("with_tools")]
#[case::tool_use_conversation("tool_use_conversation")]
#[case::with_image("with_image")]
#[case::with_image_url("with_image_url")]
#[case::with_json_schema("with_json_schema")]
fn anthropic_messages_to_open_responses(#[case] case: &str) {
    run(case, Direction::AnthropicMessagesToOpenResponses);
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::with_system("with_system")]
#[case::system_blocks("system_blocks")]
#[case::multi_turn("multi_turn")]
#[case::with_tools("with_tools")]
#[case::tool_use_conversation("tool_use_conversation")]
#[case::with_image("with_image")]
#[case::with_image_url("with_image_url")]
#[case::with_json_schema("with_json_schema")]
fn open_responses_to_anthropic_messages(#[case] case: &str) {
    run(case, Direction::OpenResponsesToAnthropicMessages);
}

// ── Anthropic Messages → Open Responses only ──

#[rstest]
#[case::dropped_fields_messages("dropped_fields_messages")]
#[case::with_reasoning_messages("with_reasoning_messages")]
#[case::reasoning_items_messages("reasoning_items_messages")]
fn anthropic_messages_to_open_responses_only(#[case] case: &str) {
    run(case, Direction::AnthropicMessagesToOpenResponses);
}

// ── Open Responses → Anthropic Messages only ──

#[rstest]
#[case::dropped_fields_open_responses("dropped_fields_open_responses")]
#[case::with_reasoning_open_responses("with_reasoning_open_responses")]
#[case::default_max_tokens("default_max_tokens")]
#[case::simple_text_string_open_responses("simple_text_string_open_responses")]
#[case::reasoning_items_open_responses("reasoning_items_open_responses")]
fn open_responses_to_anthropic_messages_only(#[case] case: &str) {
    run(case, Direction::OpenResponsesToAnthropicMessages);
}

// ════════════════════════════════════════════════════════════════════
// Response conversion
// ════════════════════════════════════════════════════════════════════

fn run_response(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join(format!("tests/fixtures/anthropic_messages/response/{case}"));

    match direction {
        Direction::AnthropicMessagesToOpenResponses => {
            let label = format!("{case} Anthropic Messages -> Open Responses");
            common::run_into_open_responses_case::<AnthropicResponse, OpenResponsesResponse>(
                case,
                &dir,
                "messages.json",
                "open_responses.json",
                "messages_to_open_responses",
                label.as_str(),
            );
        }
        Direction::OpenResponsesToAnthropicMessages => {
            let label = format!("{case} Open Responses -> Anthropic Messages");
            common::run_from_open_responses_case::<AnthropicResponse, OpenResponsesResponse>(
                case,
                &dir,
                "messages.json",
                "open_responses.json",
                "open_responses_to_messages",
                label.as_str(),
            );
        }
    }
}

// ── Bidirectional (response) ──

#[rstest]
#[case::simple_text("simple_text")]
#[case::with_tool_use("with_tool_use")]
#[case::with_thinking("with_thinking")]
#[case::max_tokens("max_tokens")]
#[case::redacted_thinking("redacted_thinking")]
#[case::multi_tool_use("multi_tool_use")]
fn resp_anthropic_messages_to_open_responses(#[case] case: &str) {
    run_response(case, Direction::AnthropicMessagesToOpenResponses);
}

#[rstest]
#[case::simple_text("simple_text")]
#[case::with_tool_use("with_tool_use")]
#[case::with_thinking("with_thinking")]
#[case::max_tokens("max_tokens")]
#[case::redacted_thinking("redacted_thinking")]
#[case::multi_tool_use("multi_tool_use")]
fn resp_open_responses_to_anthropic_messages(#[case] case: &str) {
    run_response(case, Direction::OpenResponsesToAnthropicMessages);
}

// ── Anthropic Messages → Open Responses only (response) ──

#[rstest]
#[case::with_citations("with_citations")]
#[case::dropped_fields_messages("dropped_fields_messages")]
#[case::web_search_messages("web_search_messages")]
fn resp_anthropic_messages_to_open_responses_only(#[case] case: &str) {
    run_response(case, Direction::AnthropicMessagesToOpenResponses);
}

// ── Open Responses → Anthropic Messages only (response) ──

#[rstest]
#[case::dropped_fields_open_responses("dropped_fields_open_responses")]
#[case::with_refusal("with_refusal")]
#[case::function_call_output_open_responses("function_call_output_open_responses")]
#[case::with_citations_open_responses("with_citations_open_responses")]
fn resp_open_responses_to_anthropic_messages_only(#[case] case: &str) {
    run_response(case, Direction::OpenResponsesToAnthropicMessages);
}

// ════════════════════════════════════════════════════════════════════
// Stream conversion
// ════════════════════════════════════════════════════════════════════

fn run_stream(case: &str, direction: Direction) {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join(format!("tests/fixtures/anthropic_messages/stream/{case}"));

    match direction {
        Direction::AnthropicMessagesToOpenResponses => {
            let input: Vec<AnthropicStreamEvent> =
                common::load_fixture(&dir.join("messages_events.json"), case);
            let mut stream = AnthropicMessagesToOpenResponsesStream::new();
            let mut actual_events = Vec::new();
            for event in input {
                actual_events.extend(stream.transform(event).unwrap());
            }
            actual_events.extend(stream.flush().unwrap());
            let warnings = stream.take_warnings();

            let expected: serde_json::Value =
                common::load_fixture(&dir.join("open_responses_events.json"), case);
            let label = format!("{case} stream Anthropic Messages -> Open Responses");
            common::assert_json_eq(
                &serde_json::to_value(&actual_events).unwrap(),
                &expected,
                label.as_str(),
            );
            common::check_warnings(&dir, "messages_to_open_responses", warnings, case);
        }
        Direction::OpenResponsesToAnthropicMessages => {
            let input: Vec<OpenResponsesStreamEvent> =
                common::load_fixture(&dir.join("open_responses_events.json"), case);
            let mut stream = OpenResponsesToAnthropicMessagesStream::new();
            let mut actual_events = Vec::new();
            for event in input {
                actual_events.extend(stream.transform(event).unwrap());
            }
            actual_events.extend(stream.flush().unwrap());
            let warnings = stream.take_warnings();

            let expected: serde_json::Value =
                common::load_fixture(&dir.join("messages_events.json"), case);
            let label = format!("{case} stream Open Responses -> Anthropic Messages");
            common::assert_json_eq(
                &serde_json::to_value(&actual_events).unwrap(),
                &expected,
                label.as_str(),
            );
            common::check_warnings(&dir, "open_responses_to_messages", warnings, case);
        }
    }
}

// ── Anthropic Messages → Open Responses stream ──

#[rstest]
#[case::simple_text("simple_text")]
#[case::tool_use_only("tool_use_only")]
#[case::with_thinking("with_thinking")]
#[case::max_tokens("max_tokens")]
#[case::thinking_and_tool_use("thinking_and_tool_use")]
#[case::with_tool_use("with_tool_use")]
#[case::multi_tool_use("multi_tool_use")]
#[case::stop_sequence("stop_sequence")]
#[case::web_search_messages("web_search_messages")]
#[case::with_error_messages("with_error_messages")]
fn stream_anthropic_messages_to_open_responses(#[case] case: &str) {
    run_stream(case, Direction::AnthropicMessagesToOpenResponses);
}

// ── Open Responses → Anthropic Messages stream ──

#[rstest]
#[case::simple_text_open_responses("simple_text_open_responses")]
#[case::with_function_call_open_responses("with_function_call_open_responses")]
#[case::with_reasoning_open_responses("with_reasoning_open_responses")]
#[case::response_incomplete_open_responses("response_incomplete_open_responses")]
#[case::multi_output_open_responses("multi_output_open_responses")]
#[case::with_reasoning_no_summary_open_responses("with_reasoning_no_summary_open_responses")]
#[case::with_refusal_open_responses("with_refusal_open_responses")]
#[case::with_annotations_open_responses("with_annotations_open_responses")]
fn stream_open_responses_to_anthropic_messages(#[case] case: &str) {
    run_stream(case, Direction::OpenResponsesToAnthropicMessages);
}
