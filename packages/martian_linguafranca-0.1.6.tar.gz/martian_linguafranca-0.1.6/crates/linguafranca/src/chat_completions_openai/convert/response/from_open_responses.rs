use crate::chat_completions_openai::convert::mapping::open_responses_status_to_chat_completions_finish_reason;
use crate::chat_completions_openai::response::{
    ChatCompletionsAssistantMessage, ChatCompletionsChoice, ChatCompletionsOpenAiResponse,
};
use crate::chat_completions_openai::types::*;
use crate::convert::ctx::ConversionCtx;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::types::*;
use crate::traits::FromOpenResponses;

type Ctx = ConversionCtx<()>;

impl FromOpenResponses for ChatCompletionsOpenAiResponse {
    type Source = OpenResponsesResponse;

    fn from_open_responses(
        source: OpenResponsesResponse,
    ) -> Result<ConversionResult<Self>, ConversionError> {
        let mut ctx = Ctx::new();

        let finish_reason = convert_open_responses_status_to_chat_completions_finish_reason(
            source.status,
            &source.output,
            &mut ctx,
        );
        let message = convert_open_responses_output_to_assistant_message(source.output, &mut ctx);

        let usage = source.usage.map(Into::into);

        let mut result = ConversionResult::with_warnings(
            ChatCompletionsOpenAiResponse {
                id: source.id,
                object: "chat.completion".into(),
                created: source.created_at,
                model: source.model,
                choices: vec![ChatCompletionsChoice {
                    index: 0,
                    message,
                    finish_reason,
                    logprobs: None,
                }],
                usage,
                system_fingerprint: None,
                service_tier: source.service_tier.map(convert_open_responses_service_tier),
            },
            ctx.into_warnings(),
        );

        if source.object != "response" {
            result.warn(
                "object",
                format!("unexpected value '{}', expected 'response'", source.object),
            );
        }

        result.warn_unsupported(
            "Chat Completions",
            &[
                ("completed_at", source.completed_at.is_some()),
                ("incomplete_details", source.incomplete_details.is_some()),
                (
                    "previous_response_id",
                    source.previous_response_id.is_some(),
                ),
                ("instructions", source.instructions.is_some()),
                ("error", source.error.is_some()),
                ("tools", source.tools.is_some()),
                ("tool_choice", source.tool_choice.is_some()),
                ("truncation", source.truncation.is_some()),
                ("parallel_tool_calls", source.parallel_tool_calls.is_some()),
                ("text", source.text.is_some()),
                ("top_p", source.top_p.is_some()),
                ("presence_penalty", source.presence_penalty.is_some()),
                ("frequency_penalty", source.frequency_penalty.is_some()),
                ("top_logprobs", source.top_logprobs.is_some()),
                ("temperature", source.temperature.is_some()),
                ("reasoning", source.reasoning.is_some()),
                ("max_output_tokens", source.max_output_tokens.is_some()),
                ("max_tool_calls", source.max_tool_calls.is_some()),
                ("store", source.store.is_some()),
                ("background", source.background.is_some()),
                ("metadata", source.metadata.is_some()),
                ("safety_identifier", source.safety_identifier.is_some()),
                ("prompt_cache_key", source.prompt_cache_key.is_some()),
            ],
        );

        Ok(result)
    }
}

fn convert_open_responses_output_to_assistant_message(
    output: Vec<OutputItem>,
    ctx: &mut Ctx,
) -> ChatCompletionsAssistantMessage {
    let mut content_fragments = Vec::new();
    let mut refusal_fragments = Vec::new();
    let mut reasoning_fragments = Vec::new();
    let mut tool_calls = Vec::new();
    let mut annotations = Vec::new();

    for (i, item) in output.into_iter().enumerate() {
        ctx.push(format!("output[{i}]"));
        match item {
            OutputItem::Message { role, content, .. } => {
                if role != MessageRole::Assistant {
                    ctx.warn(
                        "role",
                        "non-assistant output message role is not valid in Chat Completions response, dropped",
                    );
                    ctx.pop();
                    continue;
                }
                for (j, part) in content.into_iter().enumerate() {
                    ctx.push(format!("content[{j}]"));
                    match part {
                        ContentPart::OutputText {
                            text,
                            annotations: part_annotations,
                            logprobs,
                        } => {
                            if !logprobs.is_empty() {
                                ctx.warn(
                                    "logprobs",
                                    "output_text.logprobs is not supported in Chat Completions response, dropped",
                                );
                            }
                            if !text.is_empty() {
                                content_fragments.push(text);
                            }
                            annotations.extend(
                                part_annotations
                                    .into_iter()
                                    .map(convert_open_responses_annotation_to_chat_completions),
                            );
                        }
                        ContentPart::Refusal { refusal } => {
                            if !refusal.is_empty() {
                                refusal_fragments.push(refusal);
                            }
                        }
                        ContentPart::InputText { text }
                        | ContentPart::Text { text }
                        | ContentPart::SummaryText { text }
                        | ContentPart::ReasoningText { text } => {
                            if !text.is_empty() {
                                content_fragments.push(text);
                            }
                        }
                        ContentPart::InputImage { .. } | ContentPart::InputFile { .. } => {
                            ctx.warn("content_part", "input-type content in output, dropped");
                        }
                    }
                    ctx.pop();
                }
            }
            OutputItem::FunctionCall {
                call_id,
                name,
                arguments,
                ..
            } => {
                tool_calls.push(ChatCompletionsToolCall::Function {
                    id: call_id,
                    function: ChatCompletionsFunctionCallData { name, arguments },
                });
            }
            OutputItem::Reasoning {
                summary, content, ..
            } => {
                for part in summary {
                    if let Some(text) = extract_reasoning_text(part) {
                        reasoning_fragments.push(text);
                    }
                }
                if let Some(content) = content {
                    for part in content {
                        if let Some(text) = extract_reasoning_text(part) {
                            reasoning_fragments.push(text);
                        }
                    }
                }
            }
            OutputItem::FunctionCallOutput { .. } => {
                ctx.warn(
                    "function_call_output",
                    "not valid in Chat Completions response output, dropped",
                );
            }
            OutputItem::WebSearchCall { .. } => {
                ctx.warn(
                    "web_search_call",
                    "not supported in Chat Completions response, dropped",
                );
            }
        }
        ctx.pop();
    }

    let content = (!content_fragments.is_empty()).then(|| content_fragments.join("\n"));
    let refusal = (!refusal_fragments.is_empty()).then(|| refusal_fragments.join("\n"));
    let reasoning_content =
        (!reasoning_fragments.is_empty()).then(|| reasoning_fragments.join("\n"));

    ChatCompletionsAssistantMessage {
        role: "assistant".into(),
        content,
        tool_calls: (!tool_calls.is_empty()).then_some(tool_calls),
        refusal,
        reasoning_content,
        annotations,
        audio: None,
    }
}

fn extract_reasoning_text(part: ContentPart) -> Option<String> {
    match part {
        ContentPart::SummaryText { text }
        | ContentPart::ReasoningText { text }
        | ContentPart::Text { text }
        | ContentPart::OutputText { text, .. }
        | ContentPart::InputText { text } => (!text.is_empty()).then_some(text),
        ContentPart::Refusal { refusal } => (!refusal.is_empty()).then_some(refusal),
        ContentPart::InputImage { .. } | ContentPart::InputFile { .. } => None,
    }
}

fn convert_open_responses_status_to_chat_completions_finish_reason(
    status: ResponseStatus,
    output: &[OutputItem],
    ctx: &mut Ctx,
) -> Option<ChatCompletionsFinishReason> {
    match status {
        ResponseStatus::Completed | ResponseStatus::Incomplete | ResponseStatus::Failed => {
            open_responses_status_to_chat_completions_finish_reason(status, output)
        }
        ResponseStatus::InProgress | ResponseStatus::Queued => {
            ctx.warn(
                "status",
                "non-terminal Open Responses status in non-streaming response; finish_reason omitted",
            );
            None
        }
    }
}

fn convert_open_responses_annotation_to_chat_completions(
    ann: Annotation,
) -> ChatCompletionsAnnotation {
    match ann {
        Annotation::UrlCitation {
            url,
            title,
            start_index,
            end_index,
        } => ChatCompletionsAnnotation::UrlCitation {
            url_citation: ChatCompletionsUrlCitation {
                url,
                title,
                start_index,
                end_index,
            },
        },
    }
}

fn convert_open_responses_service_tier(tier: ServiceTier) -> String {
    match tier {
        ServiceTier::Auto => "auto".into(),
        ServiceTier::Default => "default".into(),
        ServiceTier::Flex => "flex".into(),
        ServiceTier::Priority => "priority".into(),
    }
}
