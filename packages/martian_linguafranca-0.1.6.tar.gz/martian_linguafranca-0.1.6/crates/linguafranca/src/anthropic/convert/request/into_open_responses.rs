use crate::anthropic::convert::ctx::ConversionCtx;
use crate::anthropic::convert::helpers::*;
use crate::anthropic::request::AnthropicRequest;
use crate::anthropic::types::*;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::convert::open_responses_input_accum::OpenResponsesInputAccum;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::request::{OpenResponsesInput, OpenResponsesRequest};
use crate::open_responses::types::*;
use crate::traits::IntoOpenResponses;

impl IntoOpenResponses for AnthropicRequest {
    type Target = OpenResponsesRequest;

    fn into_open_responses(
        self,
    ) -> Result<ConversionResult<OpenResponsesRequest>, ConversionError> {
        let mut ctx = ConversionCtx::new();
        let mut accum = OpenResponsesInputAccum::new();
        if let Some(system) = self.system {
            accum.push_item(
                MessageRole::System,
                InputItem::Message {
                    role: MessageRole::System,
                    content: InputContent::Text(extract_system_text(system)),
                    id: None,
                    status: None,
                },
            );
        }
        convert_anthropic_messages(&mut accum, self.messages, &mut ctx);

        let mut result = ConversionResult::with_warnings(
            OpenResponsesRequest {
                model: self.model,
                input: OpenResponsesInput::Items(accum.into_items()),
                max_output_tokens: Some(self.max_tokens),
                temperature: self.temperature,
                top_p: self.top_p,
                stream: self.stream,
                tools: self.tools.map(|tools| {
                    tools
                        .into_iter()
                        .filter_map(|t| {
                            convert_anthropic_messages_tool_to_open_responses(t, &mut ctx)
                        })
                        .collect()
                }),
                tool_choice: self
                    .tool_choice
                    .map(convert_anthropic_messages_tool_choice_to_open_responses),
                reasoning: self.thinking.and_then(|t| {
                    convert_anthropic_messages_thinking_to_open_responses_reasoning(t, &ctx)
                }),
                service_tier: self
                    .service_tier
                    .and_then(|tier| ServiceTier::lossy_try_from(tier, &mut ctx, "service_tier")),
                text: convert_anthropic_output_config_to_open_responses_text(
                    self.output_config,
                    &mut ctx,
                ),
                ..Default::default()
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Open Responses",
            &[
                ("top_k", self.top_k.is_some()),
                ("stop_sequences", self.stop_sequences.is_some()),
                ("cache_control", self.cache_control.is_some()),
                ("container", self.container.is_some()),
                ("inference_geo", self.inference_geo.is_some()),
            ],
        );
        if self.metadata.is_some() {
            result.warn("metadata", "Anthropic metadata structure differs, dropped");
        }

        Ok(result)
    }
}

fn extract_system_text(system: AnthropicSystem) -> String {
    match system {
        AnthropicSystem::Text(t) => t,
        AnthropicSystem::Blocks(blocks) => blocks
            .into_iter()
            .map(|b| b.text)
            .collect::<Vec<_>>()
            .join("\n"),
    }
}

fn convert_anthropic_messages(
    accum: &mut OpenResponsesInputAccum,
    messages: Vec<AnthropicMessage>,
    ctx: &mut ConversionCtx,
) {
    for (i, msg) in messages.into_iter().enumerate() {
        ctx.push(format!("messages[{i}]"));

        let blocks = match msg.content {
            AnthropicMessageContent::Text(t) => {
                vec![AnthropicInputContentBlock::Text {
                    text: t,
                    cache_control: None,
                    citations: None,
                }]
            }
            AnthropicMessageContent::Blocks(b) => b,
        };

        let role = match msg.role {
            AnthropicRole::User => MessageRole::User,
            AnthropicRole::Assistant => MessageRole::Assistant,
        };

        convert_blocks(accum, blocks, role, ctx);
        ctx.pop();
    }
}

fn convert_blocks(
    accum: &mut OpenResponsesInputAccum,
    blocks: Vec<AnthropicInputContentBlock>,
    role: MessageRole,
    ctx: &mut ConversionCtx,
) {
    for block in blocks {
        match block {
            AnthropicInputContentBlock::Text { text, .. } => {
                accum.push_part(InputContentPart::Text { text });
            }
            AnthropicInputContentBlock::Image { source, .. } => {
                accum.push_part(InputContentPart::Image {
                    image_url: Some(image_source_to_url(source)),
                    detail: None,
                });
            }
            AnthropicInputContentBlock::Document { source, title, .. } => {
                accum.push_part(document_source_to_open_responses_file(source, title));
            }
            AnthropicInputContentBlock::SearchResult { content, title, .. } => {
                accum.push_part(search_result_to_text(title, content));
            }
            AnthropicInputContentBlock::ToolResult {
                tool_use_id,
                content,
                ..
            } => {
                let output = tool_result_content_to_output(content);
                accum.push_item(
                    role,
                    InputItem::FunctionCallOutput {
                        call_id: tool_use_id,
                        output,
                        id: None,
                        status: None,
                    },
                );
            }
            AnthropicInputContentBlock::ToolUse {
                id, name, input, ..
            } => {
                let arguments = serde_json::to_string(&input).unwrap_or_else(|_| {
                    ctx.warn(
                        "tool_use.input",
                        "failed to serialize tool input, replaced with empty string",
                    );
                    String::new()
                });
                accum.push_item(
                    role,
                    InputItem::FunctionCall {
                        call_id: id,
                        name,
                        arguments,
                        id: None,
                        status: None,
                    },
                );
            }
            // Signature is stored in encrypted_content to preserve it for
            // round-trips. On the way back (OR→AM), we distinguish from
            // RedactedThinking by checking whether summary is non-empty.
            AnthropicInputContentBlock::Thinking {
                thinking,
                signature,
            } => {
                accum.push_item(
                    role,
                    InputItem::Reasoning {
                        summary: vec![SummaryContent {
                            kind: SummaryContentType::SummaryText,
                            text: thinking,
                        }],
                        id: None,
                        encrypted_content: Some(signature),
                    },
                );
            }
            AnthropicInputContentBlock::RedactedThinking { data } => {
                accum.push_item(
                    role,
                    InputItem::Reasoning {
                        summary: Vec::new(),
                        id: None,
                        encrypted_content: Some(data),
                    },
                );
            }
        }
    }

    accum.flush_parts(role);
}

fn tool_result_content_to_output(
    content: Option<AnthropicToolResultContent>,
) -> FunctionCallOutputValue {
    match content {
        None => FunctionCallOutputValue::Text(String::new()),
        Some(AnthropicToolResultContent::Text(t)) => FunctionCallOutputValue::Text(t),
        Some(AnthropicToolResultContent::Blocks(blocks)) => {
            let parts: Vec<InputContentPart> = blocks
                .into_iter()
                .map(|b| match b {
                    AnthropicToolResultBlock::Text { text } => InputContentPart::Text { text },
                    AnthropicToolResultBlock::Image { source } => InputContentPart::Image {
                        image_url: Some(image_source_to_url(source)),
                        detail: None,
                    },
                    AnthropicToolResultBlock::Document { source, title, .. } => {
                        document_source_to_open_responses_file(source, title)
                    }
                    AnthropicToolResultBlock::SearchResult { content, title, .. } => {
                        search_result_to_text(title, content)
                    }
                })
                .collect();
            FunctionCallOutputValue::Parts(parts)
        }
    }
}

fn convert_anthropic_messages_tool_to_open_responses(
    tool: AnthropicToolUnion,
    ctx: &mut ConversionCtx,
) -> Option<Tool> {
    match tool {
        AnthropicToolUnion::Known(am) => Some(Tool::Function {
            name: am.name,
            description: am.description,
            parameters: Some(am.input_schema),
            strict: am.strict,
        }),
        AnthropicToolUnion::Other(value) => {
            let type_str = value.get("type").and_then(|v| v.as_str()).unwrap_or("");
            if type_str.starts_with("web_search") {
                let user_location = value
                    .get("user_location")
                    .and_then(|loc| loc.as_object())
                    .map(|obj| UserLocation {
                        kind: obj
                            .get("type")
                            .and_then(|v| v.as_str())
                            .unwrap_or("approximate")
                            .to_string(),
                        city: obj.get("city").and_then(|v| v.as_str()).map(String::from),
                        country: obj
                            .get("country")
                            .and_then(|v| v.as_str())
                            .map(String::from),
                        region: obj.get("region").and_then(|v| v.as_str()).map(String::from),
                        timezone: obj
                            .get("timezone")
                            .and_then(|v| v.as_str())
                            .map(String::from),
                    });
                let allowed_domains = value
                    .get("allowed_domains")
                    .and_then(|v| v.as_array())
                    .map(|arr| {
                        arr.iter()
                            .filter_map(|v| v.as_str().map(String::from))
                            .collect::<Vec<_>>()
                    })
                    .unwrap_or_default();

                if value
                    .get("blocked_domains")
                    .and_then(|v| v.as_array())
                    .is_some_and(|a| !a.is_empty())
                {
                    ctx.warn(
                        "blocked_domains",
                        "not supported in Open Responses, dropped",
                    );
                }
                if value.get("allowed_callers").is_some() {
                    ctx.warn(
                        "allowed_callers",
                        "not supported in Open Responses, dropped",
                    );
                }
                if value.get("cache_control").is_some() {
                    ctx.warn("cache_control", "not supported in Open Responses, dropped");
                }
                if value.get("max_uses").is_some() {
                    ctx.warn("max_uses", "not supported in Open Responses, dropped");
                }

                let filters = if allowed_domains.is_empty() {
                    None
                } else {
                    Some(WebSearchFilters { allowed_domains })
                };

                Some(Tool::WebSearch {
                    search_context_size: None,
                    user_location,
                    filters,
                })
            } else {
                None
            }
        }
    }
}

fn convert_anthropic_messages_tool_choice_to_open_responses(tc: AnthropicToolChoice) -> ToolChoice {
    match tc {
        AnthropicToolChoice::Auto { .. } => ToolChoice::Mode(ToolChoiceMode::Auto),
        AnthropicToolChoice::Any { .. } => ToolChoice::Mode(ToolChoiceMode::Required),
        AnthropicToolChoice::None => ToolChoice::Mode(ToolChoiceMode::None),
        AnthropicToolChoice::Tool { name, .. } => {
            ToolChoice::Specific(SpecificToolChoice::Function { name: Some(name) })
        }
    }
}

fn convert_anthropic_messages_thinking_to_open_responses_reasoning(
    thinking: AnthropicThinkingConfig,
    ctx: &ConversionCtx,
) -> Option<ReasoningConfig> {
    match thinking {
        AnthropicThinkingConfig::Enabled { budget_tokens } => {
            let effort = ctx.config.budget_to_effort(budget_tokens);
            Some(ReasoningConfig {
                effort: Some(effort),
                summary: None,
            })
        }
        AnthropicThinkingConfig::Adaptive => Some(ReasoningConfig {
            effort: Some(ReasoningEffort::Medium),
            summary: None,
        }),
        AnthropicThinkingConfig::Disabled => None,
    }
}

fn convert_anthropic_output_config_to_open_responses_text(
    config: Option<AnthropicOutputConfig>,
    ctx: &mut ConversionCtx,
) -> Option<TextConfig> {
    let config = config?;

    if config.effort.is_some() {
        ctx.warn(
            "output_config.effort",
            "not supported in Open Responses, dropped",
        );
    }

    let format =
        config.format.map(
            |AnthropicOutputFormat::JsonSchema { schema }| TextFormat::JsonSchema {
                name: "json_schema".to_string(),
                description: None,
                schema: Some(schema),
                strict: None,
            },
        );

    format.as_ref()?;

    Some(TextConfig {
        format,
        verbosity: None,
    })
}
