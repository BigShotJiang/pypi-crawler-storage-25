use super::accum::OpenResponsesToAnthropicMessagesAccum;
use crate::anthropic::convert::helpers::*;
use crate::anthropic::response::AnthropicResponse;
use crate::anthropic::stream::*;
use crate::anthropic::types::*;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::error::{ConversionError, ConversionWarning};
use crate::open_responses::stream::OpenResponsesStreamEvent;
use crate::open_responses::types::*;
use crate::stream::StreamTransform;

/// Converts Open Responses stream events to Anthropic Messages stream events, one at a time.
pub struct OpenResponsesToAnthropicMessagesStream {
    accum: OpenResponsesToAnthropicMessagesAccum,
}

impl Default for OpenResponsesToAnthropicMessagesStream {
    fn default() -> Self {
        Self::new()
    }
}

impl OpenResponsesToAnthropicMessagesStream {
    pub fn new() -> Self {
        Self {
            accum: OpenResponsesToAnthropicMessagesAccum::new(),
        }
    }
}

impl StreamTransform for OpenResponsesToAnthropicMessagesStream {
    type Input = OpenResponsesStreamEvent;
    type Output = AnthropicStreamEvent;

    fn transform(
        &mut self,
        input: OpenResponsesStreamEvent,
    ) -> Result<Vec<AnthropicStreamEvent>, ConversionError> {
        let accum = &mut self.accum;
        match input {
            OpenResponsesStreamEvent::ResponseCreated { response, .. } => {
                Ok(handle_response_created(accum, response))
            }
            OpenResponsesStreamEvent::ContentPartAdded { part, .. } => {
                Ok(handle_content_part_added(accum, part))
            }
            OpenResponsesStreamEvent::OutputTextDelta { delta, .. } => {
                Ok(vec![AnthropicStreamEvent::ContentBlockDelta {
                    index: accum.block_index.saturating_sub(1),
                    delta: AnthropicStreamDelta::TextDelta { text: delta },
                }])
            }
            OpenResponsesStreamEvent::OutputTextDone { .. } => {
                let index = accum.block_index.saturating_sub(1);
                Ok(vec![AnthropicStreamEvent::ContentBlockStop { index }])
            }
            OpenResponsesStreamEvent::OutputItemAdded { item, .. } => {
                Ok(handle_output_item_added(accum, item))
            }
            OpenResponsesStreamEvent::FunctionCallArgumentsDelta { delta, .. } => {
                Ok(vec![AnthropicStreamEvent::ContentBlockDelta {
                    index: accum.block_index.saturating_sub(1),
                    delta: AnthropicStreamDelta::InputJsonDelta {
                        partial_json: delta,
                    },
                }])
            }
            OpenResponsesStreamEvent::FunctionCallArgumentsDone { .. } => {
                let index = accum.block_index.saturating_sub(1);
                Ok(vec![AnthropicStreamEvent::ContentBlockStop { index }])
            }
            OpenResponsesStreamEvent::ReasoningSummaryTextDelta { delta, .. } => {
                Ok(vec![AnthropicStreamEvent::ContentBlockDelta {
                    index: accum.block_index.saturating_sub(1),
                    delta: AnthropicStreamDelta::ThinkingDelta { thinking: delta },
                }])
            }
            OpenResponsesStreamEvent::ReasoningDelta { delta, .. } => {
                Ok(vec![AnthropicStreamEvent::ContentBlockDelta {
                    index: accum.block_index.saturating_sub(1),
                    delta: AnthropicStreamDelta::ThinkingDelta { thinking: delta },
                }])
            }
            OpenResponsesStreamEvent::OutputItemDone { item, .. } => {
                Ok(handle_output_item_done(accum, item))
            }
            OpenResponsesStreamEvent::RefusalDelta { delta, .. } => {
                Ok(vec![AnthropicStreamEvent::ContentBlockDelta {
                    index: accum.block_index.saturating_sub(1),
                    delta: AnthropicStreamDelta::TextDelta { text: delta },
                }])
            }
            OpenResponsesStreamEvent::RefusalDone { .. } => {
                let index = accum.block_index.saturating_sub(1);
                Ok(vec![AnthropicStreamEvent::ContentBlockStop { index }])
            }
            OpenResponsesStreamEvent::ResponseCompleted { response, .. }
            | OpenResponsesStreamEvent::ResponseFailed { response, .. }
            | OpenResponsesStreamEvent::ResponseIncomplete { response, .. } => {
                Ok(handle_response_terminal(response))
            }
            OpenResponsesStreamEvent::OutputTextAnnotationAdded { annotation, .. } => {
                if annotation.is_some() {
                    accum.ctx.warn(
                        "annotation",
                        "not supported in Anthropic Messages streaming, dropped",
                    );
                }
                Ok(vec![])
            }
            OpenResponsesStreamEvent::WebSearchCallInProgress { .. }
            | OpenResponsesStreamEvent::WebSearchCallSearching { .. }
            | OpenResponsesStreamEvent::WebSearchCallCompleted { .. } => Ok(vec![]),
            // Events with no Anthropic Messages equivalent
            OpenResponsesStreamEvent::ResponseInProgress { .. }
            | OpenResponsesStreamEvent::ResponseQueued { .. }
            | OpenResponsesStreamEvent::ContentPartDone { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryPartAdded { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryPartDone { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryTextDone { .. }
            | OpenResponsesStreamEvent::ReasoningDone { .. } => Ok(vec![]),
        }
    }

    fn flush(&mut self) -> Result<Vec<AnthropicStreamEvent>, ConversionError> {
        Ok(vec![])
    }

    fn take_warnings(&mut self) -> Vec<ConversionWarning> {
        self.accum.ctx.take_warnings()
    }
}

fn handle_response_created(
    accum: &mut OpenResponsesToAnthropicMessagesAccum,
    response: crate::open_responses::response::OpenResponsesResponse,
) -> Vec<AnthropicStreamEvent> {
    let usage = response.usage.map(AnthropicUsage::from).unwrap_or_default();
    let service_tier = response.service_tier.and_then(|tier| {
        AnthropicServiceTier::lossy_try_from(tier, &mut accum.ctx, "service_tier")
    });
    vec![AnthropicStreamEvent::MessageStart {
        message: AnthropicResponse {
            id: response.id,
            kind: "message".into(),
            role: AnthropicRole::Assistant,
            model: response.model,
            content: vec![],
            stop_reason: None,
            stop_sequence: None,
            usage,
            container: None,
            service_tier,
        },
    }]
}

fn handle_content_part_added(
    accum: &mut OpenResponsesToAnthropicMessagesAccum,
    part: ContentPart,
) -> Vec<AnthropicStreamEvent> {
    match part {
        ContentPart::OutputText { .. } | ContentPart::Refusal { .. } => {
            let index = accum.next_block_index();
            vec![AnthropicStreamEvent::ContentBlockStart {
                index,
                content_block: AnthropicOutputContentBlock::Known(
                    AnthropicKnownOutputContentBlock::Text {
                        text: String::new(),
                        citations: vec![],
                    },
                ),
            }]
        }
        _ => vec![],
    }
}

fn handle_output_item_added(
    accum: &mut OpenResponsesToAnthropicMessagesAccum,
    item: OutputItem,
) -> Vec<AnthropicStreamEvent> {
    match item {
        OutputItem::FunctionCall { call_id, name, .. } => {
            let index = accum.next_block_index();
            vec![AnthropicStreamEvent::ContentBlockStart {
                index,
                content_block: AnthropicOutputContentBlock::Known(
                    AnthropicKnownOutputContentBlock::ToolUse {
                        id: call_id,
                        name,
                        input: serde_json::json!({}),
                    },
                ),
            }]
        }
        OutputItem::Reasoning {
            summary,
            encrypted_content,
            ..
        } => {
            if summary.is_empty() && encrypted_content.is_some() {
                // RedactedThinking — defer to OutputItemDone which carries the
                // authoritative encrypted_content. The OR API may re-encrypt
                // across Added/Done/Completed events, so we use the Done value.
                let index = accum.next_block_index();
                accum.thinking_block_open = true;
                accum.thinking_block_index = index;
                vec![]
            } else {
                // Thinking — will receive ThinkingDelta events, defer ContentBlockStop
                let index = accum.next_block_index();
                accum.thinking_block_open = true;
                accum.thinking_block_index = index;
                vec![AnthropicStreamEvent::ContentBlockStart {
                    index,
                    content_block: AnthropicOutputContentBlock::Known(
                        AnthropicKnownOutputContentBlock::Thinking {
                            thinking: String::new(),
                            signature: String::new(),
                        },
                    ),
                }]
            }
        }
        // Message items don't map to Anthropic Messages content block starts
        OutputItem::Message { .. } | OutputItem::FunctionCallOutput { .. } => vec![],
        OutputItem::WebSearchCall { id, .. } => {
            let index = accum.next_block_index();
            accum.pending_web_search_block_index = Some(index);
            vec![AnthropicStreamEvent::ContentBlockStart {
                index,
                content_block: AnthropicOutputContentBlock::Known(
                    AnthropicKnownOutputContentBlock::ServerToolUse {
                        id,
                        name: "web_search".into(),
                        input: serde_json::json!({}),
                        caller: None,
                    },
                ),
            }]
        }
    }
}

fn handle_output_item_done(
    accum: &mut OpenResponsesToAnthropicMessagesAccum,
    item: OutputItem,
) -> Vec<AnthropicStreamEvent> {
    match item {
        OutputItem::Reasoning {
            summary,
            encrypted_content,
            ..
        } if accum.thinking_block_open => {
            accum.thinking_block_open = false;
            let index = accum.thinking_block_index;
            let is_redacted = summary.is_empty();

            if is_redacted {
                // Redacted thinking: emit the full block now using Done's encrypted_content
                let data = encrypted_content.unwrap_or_default();
                vec![
                    AnthropicStreamEvent::ContentBlockStart {
                        index,
                        content_block: AnthropicOutputContentBlock::Known(
                            AnthropicKnownOutputContentBlock::RedactedThinking { data },
                        ),
                    },
                    AnthropicStreamEvent::ContentBlockStop { index },
                ]
            } else {
                let mut events = Vec::new();
                if let Some(signature) = encrypted_content.filter(|s| !s.is_empty()) {
                    events.push(AnthropicStreamEvent::ContentBlockDelta {
                        index,
                        delta: AnthropicStreamDelta::SignatureDelta { signature },
                    });
                }
                events.push(AnthropicStreamEvent::ContentBlockStop { index });
                events
            }
        }
        OutputItem::WebSearchCall { id, action, .. }
            if accum.pending_web_search_block_index.is_some() =>
        {
            let server_tool_use_index = accum.pending_web_search_block_index.take().unwrap();
            let result_index = accum.next_block_index();
            let mut events = Vec::new();

            let (query, content) = match action {
                Some(WebSearchAction::Search { query, sources, .. }) => {
                    let q = query.unwrap_or_default();
                    let content: Vec<AnthropicWebSearchToolResultItem> = sources
                        .into_iter()
                        .map(|s| AnthropicWebSearchToolResultItem::WebSearchResult {
                            url: s.url,
                            title: String::new(),
                            encrypted_content: String::new(),
                            page_age: None,
                        })
                        .collect();
                    (q, content)
                }
                _ => (String::new(), vec![]),
            };

            let query_json = serde_json::json!({ "query": query }).to_string();
            events.push(AnthropicStreamEvent::ContentBlockDelta {
                index: server_tool_use_index,
                delta: AnthropicStreamDelta::InputJsonDelta {
                    partial_json: query_json,
                },
            });
            events.push(AnthropicStreamEvent::ContentBlockStop {
                index: server_tool_use_index,
            });
            events.push(AnthropicStreamEvent::ContentBlockStart {
                index: result_index,
                content_block: AnthropicOutputContentBlock::Known(
                    AnthropicKnownOutputContentBlock::WebSearchToolResult {
                        tool_use_id: id,
                        content,
                    },
                ),
            });
            events.push(AnthropicStreamEvent::ContentBlockStop {
                index: result_index,
            });
            events
        }
        _ => vec![],
    }
}

fn handle_response_terminal(
    response: crate::open_responses::response::OpenResponsesResponse,
) -> Vec<AnthropicStreamEvent> {
    if let Some(error) = response.error {
        return vec![AnthropicStreamEvent::Error {
            error: AnthropicStreamError {
                kind: error.code,
                message: error.message,
            },
        }];
    }

    let stop_reason = convert_open_responses_status_to_anthropic_messages_stop_reason(
        response.status,
        &response.output,
        response.incomplete_details.as_ref(),
    );
    let usage = response.usage.map(AnthropicUsage::from);
    vec![
        AnthropicStreamEvent::MessageDelta {
            delta: AnthropicMessageDelta {
                stop_reason,
                stop_sequence: None,
            },
            usage,
        },
        AnthropicStreamEvent::MessageStop,
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::open_responses::response::OpenResponsesResponse;
    use crate::stream::StreamTransform;

    fn make_response_created() -> OpenResponsesStreamEvent {
        OpenResponsesStreamEvent::ResponseCreated {
            sequence_number: 0,
            response: OpenResponsesResponse {
                id: "resp_1".into(),
                object: "response".into(),
                model: "gpt-5".into(),
                status: ResponseStatus::InProgress,
                ..Default::default()
            },
        }
    }

    #[test]
    fn response_created_emits_message_start() {
        let mut stream = OpenResponsesToAnthropicMessagesStream::new();
        let events = stream.transform(make_response_created()).unwrap();
        assert_eq!(events.len(), 1);
        assert!(matches!(
            &events[0],
            AnthropicStreamEvent::MessageStart { .. }
        ));
    }

    #[test]
    fn text_delta_passes_through() {
        let mut stream = OpenResponsesToAnthropicMessagesStream::new();
        stream.transform(make_response_created()).unwrap();
        stream
            .transform(OpenResponsesStreamEvent::ContentPartAdded {
                sequence_number: 1,
                item_id: "msg_0".into(),
                output_index: 0,
                content_index: 0,
                part: ContentPart::OutputText {
                    text: String::new(),
                    annotations: vec![],
                    logprobs: vec![],
                },
            })
            .unwrap();
        let events = stream
            .transform(OpenResponsesStreamEvent::OutputTextDelta {
                sequence_number: 2,
                item_id: "msg_0".into(),
                output_index: 0,
                content_index: 0,
                delta: "hello".into(),
                logprobs: vec![],
                obfuscation: None,
            })
            .unwrap();
        assert_eq!(events.len(), 1);
        match &events[0] {
            AnthropicStreamEvent::ContentBlockDelta {
                delta: AnthropicStreamDelta::TextDelta { text },
                ..
            } => assert_eq!(text, "hello"),
            other => panic!("expected TextDelta, got {other:?}"),
        }
    }

    #[test]
    fn response_completed_emits_message_delta_and_stop() {
        let mut stream = OpenResponsesToAnthropicMessagesStream::new();
        stream.transform(make_response_created()).unwrap();
        let events = stream
            .transform(OpenResponsesStreamEvent::ResponseCompleted {
                sequence_number: 10,
                response: OpenResponsesResponse {
                    id: "resp_1".into(),
                    object: "response".into(),
                    model: "gpt-5".into(),
                    status: ResponseStatus::Completed,
                    ..Default::default()
                },
            })
            .unwrap();
        assert_eq!(events.len(), 2);
        assert!(matches!(
            &events[0],
            AnthropicStreamEvent::MessageDelta { .. }
        ));
        assert!(matches!(&events[1], AnthropicStreamEvent::MessageStop));
    }
}
