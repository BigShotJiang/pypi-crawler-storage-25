"""Runtime paths and environment (server + detector invocation)."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def _is_frozen() -> bool:
    return getattr(sys, "frozen", False) and hasattr(sys, "executable")


def server_exe_dir() -> Path:
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path.cwd()


def _env_str(*names: str, default: str = "") -> str:
    for n in names:
        v = os.environ.get(n, "").strip()
        if v:
            return v
    return default


def _env_int(*names: str, default: int) -> int:
    for n in names:
        v = os.environ.get(n, "").strip()
        if v:
            return int(v)
    return default


def data_dir() -> Path:
    raw = _env_str("FLICKER_DETECTOR_WEB_DATA", "FLASH_DETECTOR_WEB_DATA")
    if raw:
        return Path(raw).expanduser().resolve()
    return server_exe_dir() / "flicker_detector_web_data"


def uploads_dir() -> Path:
    return data_dir() / "uploads"


def sqlite_path() -> Path:
    return data_dir() / "web.sqlite"


def trust_proxy() -> bool:
    v = _env_str("FLICKER_DETECTOR_TRUST_PROXY", "FLASH_DETECTOR_TRUST_PROXY")
    return v.lower() in ("1", "true", "yes")


def default_bind_host() -> str:
    return _env_str("FLICKER_DETECTOR_BIND", "FLASH_DETECTOR_BIND") or "127.0.0.1"


def default_port() -> int:
    return _env_int("FLICKER_DETECTOR_PORT", "FLASH_DETECTOR_PORT", default=8765)


def max_upload_mb() -> int:
    return _env_int("FLICKER_DETECTOR_MAX_UPLOAD_MB", "FLASH_DETECTOR_MAX_UPLOAD_MB", default=2048)


def max_concurrent_jobs() -> int:
    return _env_int("FLICKER_DETECTOR_MAX_CONCURRENT_JOBS", "FLASH_DETECTOR_MAX_CONCURRENT_JOBS", default=1)


def detector_timeout_sec() -> int:
    return _env_int("FLICKER_DETECTOR_JOB_TIMEOUT_SEC", "FLASH_DETECTOR_JOB_TIMEOUT_SEC", default=7200)


def detector_job_extra_argv(
    *,
    threshold_override: float | None = None,
) -> list[str]:
    """Extra flags after base `gpu-flicker-detector` argv for each Web upload job (omit envs to keep CLI defaults).

    Per-job ``threshold_override`` wins over ``FLICKER_DETECTOR_THRESHOLD`` / ``FLASH_DETECTOR_JOB_THRESHOLD``.
    """
    out: list[str] = []
    if threshold_override is not None:
        out += ["--threshold", str(threshold_override)]
    else:
        thr = _env_str("FLICKER_DETECTOR_THRESHOLD", "FLASH_DETECTOR_JOB_THRESHOLD")
        if thr:
            out += ["--threshold", thr]
    weights = _env_str("FLICKER_DETECTOR_LAYER_LOSS_WEIGHTS", "FLASH_DETECTOR_LAYER_LOSS_WEIGHTS")
    if weights:
        out += ["--layer-loss-weights", weights]
    return out


def _repo_root() -> Path | None:
    """flicker-detector-gpu repo root (pyproject at repo root or ``src/pypi/pyproject.toml``)."""
    p = Path(__file__).resolve()
    for parent in p.parents:
        for pp in (parent / "pyproject.toml", parent / "src" / "pypi" / "pyproject.toml"):
            if pp.is_file():
                try:
                    txt = pp.read_text(encoding="utf-8", errors="replace")
                    if "flicker-detector-gpu" in txt:
                        return parent
                except OSError:
                    continue
    return None


def _has_docker_compose_file(d: Path) -> bool:
    return (d / "docker-compose.yml").is_file() or (d / "compose.yaml").is_file()


def compose_project_dir() -> Path | None:
    """Directory containing docker-compose.yml (``flash_detector_web/deploy``, repo root, cwd, …)."""
    raw = _env_str("FLICKER_DETECTOR_COMPOSE_DIR")
    candidates: list[Path] = []
    if raw:
        candidates.append(Path(raw).expanduser().resolve())
    pkg_root = Path(__file__).resolve().parent.parent
    deploy = pkg_root / "deploy"
    if _has_docker_compose_file(deploy):
        candidates.append(deploy)
    rr = _repo_root()
    if rr is not None:
        candidates.append(rr)
    candidates.append(server_exe_dir())
    if not _is_frozen():
        candidates.append(Path.cwd())

    seen: set[Path] = set()
    for base in candidates:
        try:
            resolved = base.resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        if _has_docker_compose_file(resolved):
            return resolved
    return None


def resolve_detector_argv() -> list[str]:
    """Argv prefix to run the detector CLI (same flags as gpu-flicker-detector)."""
    raw_json = _env_str("FLICKER_DETECTOR_ARGV_JSON")
    if raw_json:
        arr = json.loads(raw_json)
        if not isinstance(arr, list) or not arr:
            raise RuntimeError("FLICKER_DETECTOR_ARGV_JSON must be a non-empty JSON array of strings")
        return [str(x) for x in arr]

    exe = _env_str("FLICKER_DETECTOR_EXE", "IMAGE_FLASH_DETECTOR_EXE")
    if exe:
        p = Path(exe).expanduser().resolve()
        if not p.is_file():
            raise RuntimeError(f"FLICKER_DETECTOR_EXE is not a file: {p}")
        return [str(p)]

    return [sys.executable, "-m", "flicker_detector_gpu.cli"]


def resolve_detector_exe() -> Path | None:
    """First token of detector argv (for backward-compatible health fields)."""
    try:
        argv = resolve_detector_argv()
    except RuntimeError:
        return None
    if not argv:
        return None
    return Path(argv[0]) if Path(argv[0]).exists() else None


def static_dist_dir() -> Path | None:
    """Built SPA (index.html). PyInstaller bundles under _MEIPASS/static."""
    if _is_frozen():
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            p = Path(meipass) / "static"
            if (p / "index.html").is_file():
                return p
        p2 = server_exe_dir() / "static"
        if (p2 / "index.html").is_file():
            return p2
        return None
    pkg_root = Path(__file__).resolve().parent.parent
    src_root = pkg_root.parent
    dev = src_root / "flicker_detector_webui" / "dist"
    if (dev / "index.html").is_file():
        return dev
    return None
