"""Parser multi-outils pour les appels MCP et custom dans les réponses LLM."""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Tuple


def parse_mcp_tool_calls(text: str) -> List[Tuple[str, str, Dict[str, Any]]]:
    """Extrait TOUS les appels d'outils MCP du texte LLM.

    Retourne une liste de (server_name, tool_name, arguments).
    """
    pattern = re.compile(r"<TOOL_MCP:([^:]+):([^>]+)>(.*?)</TOOL_MCP>", re.DOTALL)
    calls: List[Tuple[str, str, Dict[str, Any]]] = []
    for match in pattern.finditer(text):
        server_name = match.group(1).strip()
        tool_name = match.group(2).strip()
        args_text = match.group(3).strip()
        try:
            arguments = json.loads(args_text) if args_text else {}
        except json.JSONDecodeError:
            arguments = {}
        calls.append((server_name, tool_name, arguments))
    return calls


def parse_custom_tool_calls(text: str) -> List[Tuple[str, Dict[str, Any]]]:
    """Extrait TOUS les appels d'outils custom du texte LLM.

    Retourne une liste de (tool_name, arguments).
    """
    pattern = re.compile(r"<TOOL_CUSTOM:([^>]+)>(.*?)</TOOL_CUSTOM>", re.DOTALL)
    calls: List[Tuple[str, Dict[str, Any]]] = []
    for match in pattern.finditer(text):
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        try:
            arguments = json.loads(args_text) if args_text else {}
        except json.JSONDecodeError:
            arguments = {}
        calls.append((tool_name, arguments))
    return calls


def strip_tool_calls(text: str) -> str:
    """Retire les balises d'appel d'outil du texte pour obtenir la partie narrative."""
    # Supprime les balises MCP
    text = re.sub(r"<TOOL_MCP:[^:]+:[^>]+>.*?</TOOL_MCP>", "", text, flags=re.DOTALL)
    # Supprime les balises custom
    text = re.sub(r"<TOOL_CUSTOM:[^>]+>.*?</TOOL_CUSTOM>", "", text, flags=re.DOTALL)
    return text.strip()


def has_tool_calls(text: str) -> bool:
    """Vérifie si le texte contient au moins un appel d'outil (MCP ou custom)."""
    return bool(
        re.search(r"<TOOL_MCP:[^:]+:[^>]+>", text)
        or re.search(r"<TOOL_CUSTOM:[^>]+>", text)
    )
