"""Gestion du workspace San-o1 Intelligence."""

import json
import re
from datetime import datetime
from pathlib import Path

# Répertoire racine du workspace.
# En V1, le workspace est le dossier depuis lequel la CLI est lancée.
ROOT = Path.cwd()

# Arborescence attendue
DIRS = [
    "soi",
    "agents",
    "teams",
    "prompts",
    "workspace/inbox",
    "workspace/active_projects",
    "workspace/archive",
    "workspace/notes",
    "workspace/sandbox",
    "workspace/sandbox/inbox",
    "workspace/sandbox/output",
    "workspace/sandbox/tmp",
    "workspace/conversations",
    "workspace/heartbeat",
    "workspace/cron",
    "workspace/multi_agent",
    "workspace/multi_agent/handovers",
    "workspace/multi_agent/runs",
    "workspace/multi_agent/sessions",
    "tools",
    "tools/custom",
    "memory",
    "memory/advanced",
    "memory/advanced/user",
    "memory/advanced/signals",
    "memory/advanced/adaptation",
    "memory/advanced/context",
    "memory/advanced/graph",
    "memory/advanced/reviews",
    "config",
    "scripts",
    "docs",
]

# Fichiers de configuration par défaut
DEFAULT_CONFIGS = {
    "config/workspace.config.json": {
        "name": "San-o1 Intelligence",
        "version": "0.1.0",
        "default_agent": "assistant",
        "created_at": None,
        "last_updated": None,
        "features": {
            "prompt_first": True,
            "sandbox_mode": True,
            "proactive_mode": True,
            "self_tooling": True,
            "multi_agent": True,
            "openrouter_team_runtime": True,
            "advanced_memory": True,
            "openrouter_tui": True,
            "onboarding": True,
            "heartbeat": True,
            "cron": True,
            "memory_system": True,
            "task_system": True,
            "logging": True,
        },
        "sandbox": {
            "enabled": True,
            "root": "workspace/sandbox",
            "entrypoint_files": ["AGENTS.md", "CLAUDE.md", "README.md"],
            "default_agent": "assistant",
        },
        "multi_agent": {
            "enabled": True,
            "default_team": "core",
            "handoff_root": "workspace/multi_agent/handovers",
            "runs_root": "workspace/multi_agent/runs",
        },
        "advanced_memory": {
            "enabled": True,
            "root": "memory/advanced",
            "user_model": "memory/advanced/user/user_model.md",
            "adaptive_brief": "memory/advanced/adaptation/adaptive_brief.md",
            "link_style": "wikilinks",
        },
        "heartbeat": {
            "enabled": True,
            "events": "workspace/heartbeat/events.jsonl",
            "last": "workspace/heartbeat/last.json",
        },
        "cron": {
            "enabled": True,
            "jobs": "workspace/cron/jobs.json",
            "runs": "workspace/cron/runs.jsonl",
        },
    },
    "config/agents.config.json": {
        "agents": [],
        "default_agent": "assistant",
    },
    "config/tools.config.json": {
        "tools": [
            {
                "name": "filesystem",
                "type": "internal",
                "description": "Lecture et écriture de fichiers Markdown/JSON/YAML dans le workspace local.",
                "enabled": True,
            },
            {
                "name": "prompt_builder",
                "type": "internal",
                "description": "Assemblage d'un prompt complet à partir des fichiers d'un agent.",
                "enabled": True,
            },
            {
                "name": "sandbox_brief",
                "type": "internal",
                "description": "Génération d'un brief pour agents locaux comme Codex ou Claude Code, sans API.",
                "enabled": True,
            },
            {
                "name": "proactive_check",
                "type": "internal",
                "description": "Analyse locale du workspace pour proposer la prochaine action.",
                "enabled": True,
            },
            {
                "name": "self_tooling",
                "type": "internal",
                "description": "Création d'outils custom locaux en brouillon dans tools/custom/.",
                "enabled": True,
            },
            {
                "name": "n8n",
                "type": "future",
                "description": "Automatisation de workflows via webhooks.",
                "enabled": False,
            },
            {
                "name": "qdrant",
                "type": "future",
                "description": "Mémoire vectorielle locale ou distante.",
                "enabled": False,
            },
        ],
        "version": "0.1.0",
    },
    "config/custom_tools.config.json": {
        "tools": [],
        "policy": "draft_requires_user_approval",
    },
    "config/teams.config.json": {
        "teams": [],
        "default_team": "core",
    },
    "config/llm.config.json": {
        "default_mode": "free",
        "model_policy": "auto_prudent",
        "free_model": "openrouter/free",
        "paid_model": "openrouter/auto",
        "team_model": "x-ai/grok-4.20-multi-agent",
        "team_reasoning_effort": "medium",
        "confirm_paid_first_call": True,
        "history_limit": 20,
        "temperature": 0.7,
        "max_tokens": 1200,
        "team_max_tokens": 2400,
        "stream": True,
    },
    "config/heartbeat.config.json": {
        "enabled": True,
        "default_agent": "assistant",
        "mode": "local",
        "use_llm_if_available": False,
        "max_events": 20,
    },
    "config/cron.config.json": {
        "enabled": True,
        "default_agent": "assistant",
        "mode": "local",
        "use_llm_if_available": False,
        "max_due_jobs": 10,
    },
}

DEFAULT_TEXT_FILES = {
    "AGENTS.md": """# Instructions pour agents IA locaux

Ce workspace est une sandbox locale pour San-o1 Intelligence.

## Rôle
Tu peux travailler ici comme un agent local de type Codex ou Claude Code, sans passer par une API IA.

## Démarrage
1. Lis `README.md`.
2. Lis `docs/sandbox_mode.md`.
3. Lis `docs/proactive_mode.md`.
4. Lis `docs/self_tooling.md`.
5. Lis `docs/multi_agent.md`.
6. Lis les fichiers de l'agent cible, par défaut `agents/assistant/`.
7. Utilise `python3 scripts/run_agent.py sandbox-brief assistant` si tu veux un brief complet.
8. Lance `python3 scripts/run_agent.py proactive-check assistant` au début d'une session pour proposer la prochaine action.

## Règles de sécurité
- Ne lis pas `.env`.
- Ne révèle jamais de secret.
- Ne supprime rien sans confirmation explicite.
- Demande confirmation avant toute action sensible, destructive, coûteuse ou externe.
- Reste local-first : aucune API n'est obligatoire.

## Zones de travail
- `workspace/sandbox/inbox/` : entrées fournies à l'agent.
- `workspace/sandbox/tmp/` : brouillons temporaires.
- `workspace/sandbox/output/` : sorties générées.
- `workspace/notes/` : notes durables.
- `workspace/active_projects/` : projets en cours.

## Mémoire et tâches
- Ajoute les faits durables dans `agents/<agent>/memory.md`.
- Mets à jour les tâches dans `agents/<agent>/tasks.md`.
- Journalise les actions importantes dans `agents/<agent>/logs.md`.

## Proactivité
- Au début d'une session, observe mémoire, tâches, logs et inbox.
- Propose une prochaine action claire.
- Exécute seulement les actions locales, simples et réversibles.
- Demande confirmation pour les actions sensibles, destructives, coûteuses ou externes.

## Standard prompt engineering
- Structure les prompts importants avec rôle, contexte, entrées, méthode, garde-fous, format de sortie, critères de qualité et vérification.
- Pour une tâche complexe, utilise une chaîne courte : comprendre, lire le contexte, agir, vérifier, synthétiser.
- Pour une décision ambiguë, compare quelques options selon impact, effort, risque et réversibilité.
- Appuie-toi sur les fichiers et données disponibles ; signale clairement ce qui manque.
- Raisonne de façon structurée en interne, puis expose une justification courte et vérifiable.

## Création d'outils
- Tu peux créer des outils locaux avec `create-tool`.
- Les outils auto-créés vont dans `tools/custom/<outil>/`.
- Tout nouvel outil commence au statut `draft`.
- Un outil `draft` doit être relu et approuvé par l'utilisateur avant usage sensible.

## Multi-agent
- Les équipes sont dans `teams/<team>/`.
- Les handoffs sont dans `workspace/multi_agent/handovers/`.
- Le coordinateur répartit le travail et évite les doublons.
- Chaque agent garde son propre dossier, sa mémoire, ses tâches et ses logs.
- Utilise `team-brief` pour générer un contexte d'équipe.

## Commandes utiles
```bash
python3 scripts/run_agent.py show-agent assistant
python3 scripts/run_agent.py proactive-check assistant --output workspace/sandbox/output/PROACTIVE_REPORT.md
python3 scripts/run_agent.py build-prompt assistant --output workspace/sandbox/output/prompt_assistant.txt
python3 scripts/run_agent.py create-team core --agents assistant --objective "Coordonner le workspace SOI"
python3 scripts/run_agent.py team-brief core --output workspace/multi_agent/sessions/core_brief.md
python3 scripts/run_agent.py handoff assistant dev "Implémenter une tâche" --team core
python3 scripts/run_agent.py add-memory assistant "Mémoire à conserver"
python3 scripts/run_agent.py add-task assistant "Nouvelle tâche" --status TODO
python3 scripts/run_agent.py create-tool nom-outil --purpose "Objectif de l'outil"
python3 scripts/run_agent.py list-tools
python3 scripts/run_agent.py log assistant --action "Action" --summary "Résumé"
```
""",
    "CLAUDE.md": """# Claude Code — San-o1 Intelligence

Ce dépôt est un workspace sandbox local-first. Tu peux l'utiliser sans API IA.

Commence par lire `AGENTS.md`, puis `README.md`, puis l'agent cible dans `agents/`.

Par défaut, travaille avec `agents/assistant/`.

Règles :
- Ne lis pas `.env`.
- Ne fais pas d'action destructive sans confirmation.
- Mets à jour mémoire, tâches et logs quand c'est pertinent.
- Utilise `workspace/sandbox/` pour les brouillons et sorties temporaires.
- Lance `python3 scripts/run_agent.py proactive-check assistant` pour proposer une prochaine action.
- Crée les nouveaux outils uniquement en brouillon avec `create-tool`.
- Utilise `teams/` et `handoff` pour coordonner plusieurs agents.
""",
    ".env.example": """# San-o1 Intelligence — Variables d'environnement (futures extensions)

# APIs LLM optionnelles
# OPENAI_API_KEY=sk-...
# ANTHROPIC_API_KEY=sk-ant-...

# Mémoire vectorielle future
# QDRANT_URL=http://localhost:6333
# QDRANT_API_KEY=...

# Automatisations et intégrations futures
# N8N_WEBHOOK_URL=...
# GITHUB_TOKEN=ghp_...
""",
    ".gitignore": """# Environnement local
.env
.venv/
venv/
__pycache__/
*.pyc

# Sorties générées
prompt_*.txt
*.log

# Fichiers système
.DS_Store
""",
    "memory/long_term_memory.md": """# Mémoire long terme

## Projets importants

## Décisions stratégiques

## Connaissances clés

## Relations et contacts
""",
    "memory/short_term_memory.md": """# Mémoire court terme

## Sessions récentes

## Contexte immédiat

## Points en cours de discussion
""",
    "memory/user_profile.md": """# Profil utilisateur — l'utilisateur

## Préférences générales
- Langue : Français
- Style de réponse : simple, structuré, concis
- Tutoiement attendu

## Domaines d'intérêt
- Projets IA
- Automatisation
- Développement
- Musique
- Biscuiterie / R&D

## À ne pas oublier
- Préfère les réponses simples et structurées
""",
    "memory/decisions.md": """# Décisions importantes

## Format
- Date :
- Contexte :
- Décision :
- Conséquences :

---
""",
    "memory/advanced/index.md": """# Mémoire avancée SOI

## Cartes principales
- [[memory_protocol]]
- [[user/user_profile]]
- [[user/user_model]]
- [[user/preferences]]
- [[user/communication_style]]
- [[user/behavior_patterns]]
- [[user/goals]]
- [[adaptation/adaptive_brief]]
- [[adaptation/adaptation_rules]]
- [[signals/observations]]
- [[graph/links]]

## Principe
Cette mémoire est un graphe Markdown local. Chaque note peut pointer vers une autre avec des wikilinks.
""",
    "memory/advanced/memory_protocol.md": """# Protocole de mémoire avancée

## Règles
- Lire avant d'écrire.
- Ne jamais sauvegarder de secret sans confirmation.
- Dater chaque entrée.
- Ajouter des liens `[[...]]` quand une information touche une préférence, un projet, une décision ou une règle d'adaptation.
- Mettre à jour le modèle utilisateur quand plusieurs signaux convergent.
""",
    "memory/advanced/user/user_profile.md": """# Profil utilisateur avancé — l'utilisateur

Liens : [[preferences]], [[communication_style]], [[behavior_patterns]], [[goals]], [[user_model]]

## Identité connue
- l'utilisateur utilise San-o1 Intelligence comme workspace IA local-first.
- Langue préférée : français.
- Relation attendue avec l'assistant : tutoiement.
""",
    "memory/advanced/user/preferences.md": "# Préférences utilisateur\n\nLiens : [[user_profile]], [[adaptive_brief]]\n",
    "memory/advanced/user/communication_style.md": "# Style de communication\n\nLiens : [[user_profile]], [[adaptive_brief]]\n",
    "memory/advanced/user/behavior_patterns.md": "# Patterns comportementaux\n\nLiens : [[user_profile]], [[user_model]]\n",
    "memory/advanced/user/goals.md": "# Objectifs utilisateur\n\nLiens : [[user_profile]], [[projects]]\n",
    "memory/advanced/user/constraints.md": "# Contraintes utilisateur\n\nLiens : [[user_profile]], [[risks]]\n",
    "memory/advanced/user/user_model.md": "# Modèle utilisateur adaptatif\n\nGénéré par `memory-user-model`.\n",
    "memory/advanced/signals/observations.md": "# Observations\n\nLiens : [[user_model]], [[feedback]]\n",
    "memory/advanced/signals/session_signals.md": "# Signaux de session\n\nLiens : [[observations]], [[adaptive_brief]]\n",
    "memory/advanced/adaptation/adaptation_rules.md": """# Règles d'adaptation

Liens : [[adaptive_brief]], [[preferences]], [[communication_style]]

## Règles par défaut
- Répondre en français sauf demande contraire.
- Tutoyer l'utilisateur.
- Favoriser les réponses simples, structurées et actionnables.
- Proposer une prochaine action claire.
- Éviter de surcharger l'utilisateur avec trop d'options.
- Demander confirmation avant action sensible.
""",
    "memory/advanced/adaptation/adaptive_brief.md": "# Brief adaptatif\n\nGénéré par `memory-brief`.\n",
    "memory/advanced/adaptation/feedback.md": "# Feedback utilisateur\n\nLiens : [[adaptive_brief]], [[user_model]]\n",
    "memory/advanced/context/projects.md": "# Projets liés à l'utilisateur\n\nLiens : [[goals]], [[decisions]]\n",
    "memory/advanced/context/decisions.md": "# Décisions contextualisées\n\nLiens : [[projects]], [[user_model]]\n",
    "memory/advanced/context/risks.md": "# Risques et précautions\n\nLiens : [[constraints]], [[adaptation_rules]]\n",
    "memory/advanced/graph/links.md": "# Liens mémoire\n\nFormat : `source --relation--> cible`\n",
    "memory/advanced/graph/tags.md": "# Tags mémoire\n\n- #preference\n- #communication\n- #pattern\n- #goal\n- #decision\n- #project\n- #risk\n",
    "memory/advanced/reviews/memory_review.md": "# Revue mémoire\n\nHistorique des consolidations et points à vérifier.\n",
    "prompts/agent_builder.md": """# Prompt : Agent Builder

Tu es un architecte d'agents IA pour San-o1 Intelligence.

## Mission
Transformer une intention utilisateur en agent persistant : identité claire, mission stable, règles cohérentes, mémoire utile, outils autorisés et critères de succès.

## Techniques mobilisées
- Meta-prompting : concevoir le prompt système comme une architecture de comportement.
- Prompt chaining : intention -> responsabilités -> limites -> fichiers -> validation.
- Self-consistency : vérifier cohérence entre rôle, permissions, outils, mémoire et tâches.
- Graph prompting : relier les mémoires et décisions aux notes utiles.

## Entrées attendues
- Nom ou identifiant
- Rôle
- Mission principale
- Domaines d'aide
- Ton, style et langue
- Limites, permissions et actions interdites
- Mémoire initiale si disponible

## Méthode
1. Clarifier l'objectif réel de l'agent.
2. Déduire responsabilités, limites et outils.
3. Repérer les informations manquantes qui changeraient fortement la conception.
4. Proposer des valeurs par défaut sobres.
5. Vérifier la cohérence entre mission, règles, outils et mémoire.
6. Demander confirmation avant toute création de fichiers.

## Sortie attendue
- Résumé de l'agent
- Hypothèses retenues
- Fichiers à créer ou modifier
- Contenu Markdown proposé
- Questions bloquantes uniquement si nécessaires

## Critères de qualité
- Rôle clair
- Règles actionnables
- Permissions explicites
- Mémoire factuelle
- Structure simple à maintenir
""",
    "prompts/task_planner.md": """# Prompt : Task Planner

Tu es un planificateur de tâches IA pour San-o1 Intelligence.

## Mission
Découper un objectif en tâches concrètes, priorisées et suivables dans `PRIORITY`, `TODO`, `DOING`, `DONE` et `BLOCKED`.

## Techniques mobilisées
- Prompt chaining : objectif -> résultat terminé -> contraintes -> tâches -> statut -> prochaine action.
- Directional stimulus : privilégier livrables visibles, dépendances et blocages exacts.
- Self-consistency : vérifier que chaque tâche mène au résultat visé et n'est pas un doublon.

## Méthode
1. Reformuler le résultat visé.
2. Identifier contraintes, dépendances et inconnues.
3. Découper en livrables visibles.
4. Mettre en `PRIORITY` seulement ce qui doit être fait maintenant.
5. Placer en `BLOCKED` uniquement ce qui dépend d'une information ou décision absente.
6. Terminer par la prochaine action la plus simple.

## Sortie attendue
- Résultat visé
- Tâches par statut
- Dépendances
- Blocages
- Prochaine action

## Critères de qualité
- Chaque tâche est compréhensible seule.
- Chaque tâche produit un livrable ou une décision.
- Les blocages indiquent exactement ce qui manque.
""",
    "prompts/memory_extractor.md": """# Prompt : Memory Extractor

Tu es un extracteur de mémoire IA pour San-o1 Intelligence.

## Mission
Extraire uniquement les informations utiles à conserver dans la mémoire locale.

## Techniques mobilisées
- Grounding : conserver seulement ce qui est présent ou explicitement confirmé.
- Self-consistency : vérifier doublons, contradictions et utilité future.
- Graph prompting : proposer des wikilinks pertinents.
- Reflexion sécurité : contrôler secret, donnée sensible et consentement.

## Catégories
- preference
- communication
- pattern
- goal
- constraint
- project
- decision
- risk
- feedback

## Méthode
1. Repérer les signaux utiles dans plusieurs sessions.
2. Écarter le bruit et les doublons.
3. Classer avec une confiance `high`, `medium` ou `low`.
4. Proposer une phrase factuelle et concise.
5. Proposer les wikilinks ou fichiers cibles.
6. Signaler les données sensibles à confirmer avant sauvegarde.

## Garde-fous
- Ne pas inventer.
- Ne pas sauvegarder de secret.
- Ne pas transformer une hypothèse en préférence stable.
""",
    "prompts/project_manager.md": """# Prompt : Project Manager

Tu es un chef de projet IA local-first.

## Mission
Clarifier l'état d'un projet, identifier les risques et proposer la prochaine action qui débloque le plus de valeur.

## Techniques mobilisées
- Grounding local : baser le diagnostic sur notes, tâches, décisions et fichiers.
- Prompt chaining : diagnostic -> options -> décision -> plan -> mise à jour SOI.
- Tree of thoughts léger : comparer quelques chemins quand la priorité n'est pas évidente.
- Self-consistency : vérifier objectif, contraintes, énergie, coût et risques.

## Méthode
1. Résumer le projet en une phrase orientée résultat.
2. Comparer l'objectif avec l'état actuel.
3. Identifier écarts, risques, décisions manquantes et dépendances.
4. Classer les actions par impact, effort et urgence.
5. Comparer les options selon impact, effort, risque et réversibilité si nécessaire.
6. Proposer une seule priorité immédiate.

## Sortie attendue
- État actuel
- Priorité
- Risques
- Décisions à prendre
- Plan court
- Mises à jour SOI suggérées
""",
    "prompts/code_assistant.md": """# Prompt : Code Assistant

Tu es un assistant développeur IA senior.

## Mission
Comprendre le problème, modifier le code de façon ciblée, vérifier le résultat et expliquer clairement ce qui a changé.

## Techniques mobilisées
- ReAct local : inspecter les fichiers, agir, vérifier, ajuster.
- Grounding codebase : déduire les choix depuis le code existant.
- Prompt chaining : contexte -> hypothèse -> patch -> test -> synthèse.
- Self-consistency : vérifier que correctif, tests et comportement attendu restent cohérents.

## Méthode
1. Inspecter les fichiers pertinents.
2. Réutiliser les patterns locaux.
3. Comparer les causes plausibles si le bug est ambigu.
4. Faire le plus petit changement utile.
5. Ajouter ou adapter les tests si le risque le justifie.
6. Lancer une vérification locale.
7. Résumer fichiers modifiés, logique et limites.

## Garde-fous
- Ne pas réécrire largement sans nécessité.
- Ne pas écraser des changements non liés.
- Ne pas masquer un échec de test.
""",
    "prompts/sandbox_handoff.md": """# Prompt : Sandbox Handoff

Tu es un agent IA local qui travaille dans le workspace San-o1 Intelligence.

## Mission
Utiliser le dossier local comme une sandbox de travail, sans API obligatoire, en préservant sécurité, traçabilité et lisibilité.

## Techniques mobilisées
- ReAct local : observer, décider, agir, vérifier.
- Grounding local : citer les fichiers lus ou utilisés.
- Prompt chaining : démarrage -> analyse -> action -> vérification -> synthèse.
- Self-consistency : vérifier que l'action respecte AGENTS, règles agent et demande utilisateur.

## À lire avant d'agir
- `AGENTS.md`
- `README.md`
- `docs/sandbox_mode.md`
- `docs/proactive_mode.md`
- `docs/advanced_memory.md`
- `memory/advanced/adaptation/adaptive_brief.md`
- `agents/<agent>/agent.md`
- `agents/<agent>/system_prompt.md`
- `agents/<agent>/memory.md`
- `agents/<agent>/tasks.md`
- `agents/<agent>/rules.md`

## Démarrage recommandé
1. Identifier l'agent cible, par défaut `assistant`.
2. Lancer `python3 scripts/run_agent.py proactive-check <agent>`.
3. Repérer tâches, inbox, outils brouillons et risques.
4. Choisir une action locale, simple et réversible si elle répond à la demande.
5. Vérifier le résultat avec une commande locale quand c'est possible.

## Règles
- Ne lis pas `.env`.
- Ne révèle jamais de secret.
- Ne supprime rien sans confirmation.
- Ne lance pas d'action externe, coûteuse ou sensible sans confirmation.
- Mets à jour mémoire, tâches et logs quand c'est pertinent.
- Utilise `workspace/sandbox/tmp/` pour les brouillons.
- Utilise `workspace/sandbox/output/` pour les résultats.

## Sortie attendue
- Résumé de ce qui a été compris
- Fichiers lus
- Fichiers modifiés
- Commandes lancées
- Prochaine action recommandée

## Critères de qualité
- Les hypothèses sont visibles.
- Les actions faites sont séparées des recommandations.
- Un autre agent peut reprendre sans deviner.
""",
    "prompts/multi_agent_coordinator.md": """# Prompt : Multi-Agent Coordinator

Tu es le coordinateur d'une équipe d'agents San-o1 Intelligence.

## Mission
Répartir un objectif entre plusieurs agents persistants, éviter les doublons, clarifier les responsabilités et consolider les décisions.

## Techniques mobilisées
- Graph prompting : agents, responsabilités, dépendances et handoffs.
- Prompt chaining : objectif -> agents -> lots -> dépendances -> handoffs -> consolidation.
- Tree of thoughts léger : comparer plusieurs répartitions si le découpage est ambigu.
- Self-consistency : vérifier qu'un fichier ou une responsabilité n'est pas attribué deux fois sans raison.

## À lire
- `teams/<team>/team.md`
- `teams/<team>/roles.md`
- `teams/<team>/coordination.md`
- `agents/<agent>/tasks.md`
- `workspace/multi_agent/handovers/`

## Méthode
1. Reformuler l'objectif commun.
2. Lister les agents et leur responsabilité naturelle.
3. Découper le travail en lots indépendants.
4. Attribuer une seule responsabilité principale par agent.
5. Identifier dépendances et risques de doublon.
6. Définir livrable, fichier cible et limite par agent.
7. Écrire les handoffs nécessaires.

## Règles
- Un agent reçoit une tâche claire à la fois.
- Chaque handoff important est écrit avec la commande `handoff`.
- Chaque agent maintient sa propre mémoire, ses tâches et ses logs.
- Les décisions communes vont dans `memory/decisions.md`.
- Demander confirmation avant action sensible.
- Ne pas créer d'agent supplémentaire si une clarification de rôle suffit.

## Sortie attendue
- Répartition des rôles
- Tâches par agent
- Risques ou blocages
- Prochaine action coordonnée

## Critères de qualité
- Chaque agent comprend son périmètre sans lire tout l'historique.
- Les handoffs contiennent contexte, livrable, contrainte et fichier cible.
""",
    "prompts/advanced_memory_analyzer.md": """# Prompt : Advanced Memory Analyzer

Tu analyses une conversation pour enrichir la mémoire avancée San-o1 Intelligence.

## Mission
Extraire les signaux durables concernant l'utilisateur, ses préférences, ses patterns, ses objectifs et les règles d'adaptation utiles.

## Techniques mobilisées
- Grounding : extraire seulement ce qui est exprimé, répété ou confirmé.
- Self-consistency : comparer avec la mémoire existante pour repérer doublons et contradictions.
- Graph prompting : relier chaque mémoire aux notes pertinentes avec des wikilinks.
- Reflexion : vérifier sensibilité, consentement et confiance avant capture.

## Catégories
- preference
- communication
- pattern
- goal
- constraint
- feedback
- project
- decision
- risk

## Méthode
1. Repérer les signaux explicitement exprimés, répétés ou confirmés.
2. Séparer préférences stables, besoins de session et indices faibles.
3. Détecter les doublons, contradictions et données sensibles.
4. Proposer une confiance `high`, `medium` ou `low`.
5. Relier chaque signal aux notes `memory/advanced/` pertinentes.
6. Proposer les commandes `memory-capture` utiles.

## Règles
- Ne pas inventer.
- Ne pas sauvegarder de secret.
- Ne pas enregistrer une donnée sensible sans consentement explicite.
- Relier chaque mémoire à une note avec des wikilinks.
- Distinguer un signal faible d'une préférence stable.
- Ne pas transformer une information personnelle en diagnostic.

## Sortie attendue
- Signaux durables proposés
- Signaux faibles à surveiller
- Données à ne pas sauvegarder
- Commandes `memory-capture` proposées
""",
    "docs/onboarding.md": """# Onboarding public

`onboard` crée un assistant SOI générique, utilisable par une autre personne sans hériter des mémoires personnelles de l'assistant.

## Commandes

```bash
python3 scripts/run_agent.py onboard
python3 scripts/run_agent.py onboard --non-interactive --name assistant --accept-defaults
```

## Principes

- L'assistant généré ne suppose aucun nom utilisateur.
- l'assistant reste l'assistant personnel existant.
- L'onboarding reste local-first et ne demande aucune clé API.
""",
    "docs/heartbeat.md": """# Heartbeat local

Le heartbeat SOI réveille l'assistant sur la base d'un état local : tâches, inbox et événements système.

## Commandes

```bash
python3 scripts/run_agent.py heartbeat status
python3 scripts/run_agent.py system-event --text "Nouvel événement" --mode next-heartbeat
python3 scripts/run_agent.py heartbeat run --agent assistant
```

## Stockage

- `config/heartbeat.config.json`
- `workspace/heartbeat/events.jsonl`
- `workspace/heartbeat/last.json`
""",
    "docs/cron.md": """# Cron local

Le cron SOI planifie des messages agent dans des fichiers locaux.

## Commandes

```bash
python3 scripts/run_agent.py cron add --name daily-check --every 1d --message "Prépare un point de situation." --agent assistant
python3 scripts/run_agent.py cron list
python3 scripts/run_agent.py cron due
```

## Stockage

- `config/cron.config.json`
- `workspace/cron/jobs.json`
- `workspace/cron/runs.jsonl`
""",
    "docs/architecture.md": """# Architecture de San-o1 Intelligence

San-o1 Intelligence est un workspace local-first et prompt-first.

## Structure

```text
soi/          -> modules Python
agents/       -> agents persistants
prompts/      -> prompts reutilisables
workspace/    -> espace de travail local
memory/       -> memoire globale
config/       -> configuration JSON
scripts/      -> entrees CLI
docs/         -> documentation
```

## Flux

1. La CLI lit ou modifie des fichiers Markdown/JSON.
2. Le prompt builder assemble le contexte d'un agent.
3. L'utilisateur copie le prompt dans Claude, Codex, ChatGPT ou un LLM local.
4. Les décisions, tâches et mémoires sont réinjectées dans le workspace.
""",
    "docs/prompt_system.md": """# Système de prompts

Le prompt complet est assemblé depuis les fichiers d'un agent et la mémoire globale.

## Sources principales
- `agents/<agent>/agent.md`
- `agents/<agent>/system_prompt.md`
- `agents/<agent>/goals.md`
- `agents/<agent>/rules.md`
- `agents/<agent>/tools.md`
- `agents/<agent>/tasks.md`
- `agents/<agent>/logs.md`
- `memory/*.md`

## Principe
Le système reste utilisable sans API IA : le prompt généré peut être copié-collé dans l'outil de ton choix.

## Standard de prompt SOI
Un bon prompt San-o1 Intelligence précise :
- Rôle
- Contexte
- Entrées
- Mission
- Méthode
- Format de sortie
- Garde-fous
- Critères de qualité
- Vérification

## Techniques avancées intégrées
- Instruction claire et séparateurs.
- Few-shot structurel pour les formats importants.
- Prompt chaining pour les tâches complexes.
- Raisonnement structuré privé avec synthèse courte.
- Self-consistency pour vérifier faits, contraintes et sécurité.
- Tree of thoughts léger pour comparer des options.
- RAG / grounding local sur les fichiers fournis.
- ReAct local : observer, agir, vérifier.
- Reflexion finale : factualité, sécurité, actionnabilité.
- Graph prompting pour mémoires, tâches, décisions et handoffs.

## Anti-patterns
- Donner seulement une personnalité sans méthode de travail.
- Multiplier les règles vagues.
- Oublier les limites sensibles.
- Demander une sortie sans format exploitable.
- Mélanger faits, hypothèses et décisions.
""",
    "docs/memory_system.md": """# Système de mémoire

## Mémoire agent
Chaque agent possède `agents/<agent>/memory.md` pour son contexte spécifique.

## Mémoire globale
Le dossier `memory/` stocke le profil utilisateur, les décisions et le contexte partagé.

## Bonnes pratiques
- Ajouter uniquement les informations utiles à long terme
- Distinguer mémoire court terme et long terme
- Journaliser les décisions importantes
""",
    "docs/roadmap.md": """# Roadmap San-o1 Intelligence

## V1 — Prompt-first local
- [x] Architecture fichiers
- [x] Agent l'assistant
- [x] CLI Python
- [x] Mémoire Markdown
- [x] Tâches Markdown
- [x] Génération de prompt complet

## V2 — Intégrations
- [ ] n8n
- [ ] Qdrant
- [ ] API REST
- [ ] LLM local

## V3 — Interface
- [ ] Dashboard web
- [ ] Gestion visuelle des agents
- [ ] Historique de sessions

## V4 — Agents avancés
- [ ] Agents spécialisés
- [ ] Permissions par outil
- [ ] Mémoire automatique depuis conversations
""",
    "docs/sandbox_mode.md": """# Mode sandbox local

Le mode sandbox permet à un agent local comme Codex ou Claude Code d'utiliser San-o1 Intelligence sans API.

## Principe

L'agent n'appelle pas un serveur IA depuis SOI. Il lit et modifie directement les fichiers du workspace :
- agents
- mémoire
- tâches
- logs
- notes
- prompts

## Démarrer une session

```bash
python3 scripts/run_agent.py sandbox-brief assistant --output workspace/sandbox/output/SANDBOX_BRIEF.md
```

Ensuite, ouvre ce dossier avec ton agent local et demande-lui de lire :
- `AGENTS.md`
- `README.md`
- `workspace/sandbox/output/SANDBOX_BRIEF.md`
- `agents/assistant/system_prompt.md`
- `agents/assistant/memory.md`
- `agents/assistant/tasks.md`

## Zones

```text
workspace/sandbox/inbox/   -> fichiers donnés à l'agent
workspace/sandbox/tmp/     -> brouillons
workspace/sandbox/output/  -> résultats générés
```

## Règles

- Pas d'API obligatoire.
- Pas de secret dans le prompt.
- Pas de suppression sans confirmation.
- Journaliser les décisions importantes.
- Mettre à jour la mémoire quand un fait durable apparaît.

## Boucle de prompt recommandée
1. Observer les fichiers utiles et séparer faits, hypothèses et inconnues.
2. Découper la demande en sous-actions simples si elle est complexe.
3. Comparer les chemins possibles quand le choix n'est pas évident.
4. Agir uniquement si l'action est locale, simple, réversible et alignée avec la demande.
5. Vérifier avec une commande locale quand c'est possible.
""",
    "docs/proactive_mode.md": """# Mode proactif

Le mode proactif permet à un agent local de commencer une session en observant le workspace, puis en proposant une prochaine action.

## Commande

```bash
python3 scripts/run_agent.py proactive-check assistant --output workspace/sandbox/output/PROACTIVE_REPORT.md
```

## Ce que l'agent observe

- `agents/<agent>/tasks.md`
- `workspace/sandbox/inbox/`
- `workspace/inbox/`
- `tools/custom/`

## Règle d'action

L'agent peut agir seul uniquement si l'action est locale, simple et réversible.
Il doit demander confirmation si l'action est sensible, destructive, coûteuse, externe ou liée à des secrets.
""",
    "docs/self_tooling.md": """# Création d'outils par les agents

Un agent peut créer ses propres outils locaux sans API.

## Commande

```bash
python3 scripts/run_agent.py create-tool extract-notes --purpose "Extraire les points importants depuis une note Markdown"
```

## Emplacement

Les outils sont créés dans :

```text
tools/custom/<nom-outil>/
```

Chaque outil contient :
- `tool.json`
- `README.md`
- `run.py` si l'outil est en Python

## Statuts

- `draft` : créé par l'agent, à relire.
- `approved` : validé par l'utilisateur.

## Validation

```bash
python3 scripts/run_agent.py approve-tool extract-notes
```

## Sécurité

Un outil brouillon ne doit pas être utilisé pour une action sensible sans validation.
""",
    "docs/multi_agent.md": """# Multi-agent local

Le multi-agent de San-o1 Intelligence reste local-first et fichier-first.

## Principe

Une équipe est un dossier Markdown dans `teams/<team>/`.
Chaque agent garde son propre dossier dans `agents/<agent>/`.
Les passages de relais sont écrits dans `workspace/multi_agent/handovers/`.

## Commandes

```bash
python3 scripts/run_agent.py create-team core --agents assistant --objective "Coordonner le workspace SOI"
python3 scripts/run_agent.py team-brief core --output workspace/multi_agent/sessions/core_brief.md
python3 scripts/run_agent.py handoff assistant dev "Implémenter une tâche" --team core
python3 scripts/run_agent.py list-teams
python3 scripts/run_agent.py show-team core
```

## Règles

- Le coordinateur clarifie l'objectif global.
- Chaque agent reçoit une tâche précise.
- Les handoffs doivent être traçables.
- Les décisions durables sont journalisées.
- Les actions sensibles demandent confirmation.
""",
    "docs/advanced_memory.md": """# Mémoire avancée adaptative

La mémoire avancée de San-o1 Intelligence est un graphe Markdown local.

## Commandes

```bash
python3 scripts/run_agent.py memory-capture "l'utilisateur préfère des réponses simples." --kind preference
python3 scripts/run_agent.py memory-user-model --output workspace/sandbox/output/USER_MODEL.md
python3 scripts/run_agent.py memory-brief assistant --output workspace/sandbox/output/ADAPTIVE_BRIEF.md
python3 scripts/run_agent.py memory-link user/preferences adaptation/adaptive_brief --relation influences
```

## Règles
- Ne jamais sauvegarder un secret sans confirmation.
- Dater chaque entrée.
- Utiliser des wikilinks `[[...]]`.
- Corriger le modèle si l'utilisateur donne un feedback contraire.
""",
    "workspace/sandbox/README.md": """# Sandbox San-o1 Intelligence

Ce dossier sert de zone de travail pour agents locaux comme Codex ou Claude Code.

## Dossiers

- `inbox/` : place ici les demandes, fichiers ou notes à traiter.
- `tmp/` : brouillons temporaires.
- `output/` : résultats générés par l'agent.

## Utilisation

```bash
python3 scripts/run_agent.py sandbox-brief assistant --output workspace/sandbox/output/SANDBOX_BRIEF.md
```

Puis demande à ton agent local de lire `AGENTS.md` et ce brief.
""",
    "workspace/sandbox/inbox/.gitkeep": "",
    "workspace/sandbox/output/.gitkeep": "",
    "workspace/sandbox/tmp/.gitkeep": "",
    "workspace/conversations/.gitkeep": "",
    "workspace/multi_agent/README.md": """# Multi-agent San-o1 Intelligence

Ce dossier stocke les traces de coordination entre agents.

## Dossiers

- `handovers/` : passages de relais entre agents.
- `sessions/` : briefs et synthèses d'équipe.
""",
    "workspace/multi_agent/handovers/.gitkeep": "",
    "workspace/multi_agent/sessions/.gitkeep": "",
    "teams/README.md": """# Équipes multi-agent

Chaque dossier dans `teams/` décrit une équipe d'agents.

Une équipe contient :
- `team.md`
- `roles.md`
- `coordination.md`
- `handoffs.md`
""",
    "tools/README.md": """# Outils San-o1 Intelligence

Ce dossier contient les outils locaux du workspace.

## Custom tools

Les outils créés par les agents sont placés dans `tools/custom/`.

Par défaut, un outil auto-créé commence en statut `draft`.
Il doit être relu et approuvé avant usage sensible.
""",
    "tools/custom/.gitkeep": "",
}


def normalize_agent_name(name: str) -> str:
    """Convertit un nom d'agent en identifiant de dossier stable."""
    normalized = name.strip().lower()
    normalized = re.sub(r"\s+", "-", normalized)
    normalized = re.sub(r"[^a-z0-9_-]", "", normalized)
    if not normalized:
        raise ValueError("Le nom de l'agent ne peut pas être vide.")
    return normalized


def ensure_dirs():
    """Crée tous les répertoires nécessaires."""
    for d in DIRS:
        (ROOT / d).mkdir(parents=True, exist_ok=True)


def merge_missing(current: dict, default: dict) -> bool:
    """Ajoute récursivement les clés manquantes d'une config par défaut."""
    changed = False
    for key, value in default.items():
        if key not in current:
            current[key] = value
            changed = True
        elif isinstance(current[key], dict) and isinstance(value, dict):
            changed = merge_missing(current[key], value) or changed
    return changed


def write_default_configs():
    """Écrit les fichiers de configuration par défaut."""
    now = datetime.now().isoformat()
    for path, data in DEFAULT_CONFIGS.items():
        file_path = ROOT / path
        if not file_path.exists():
            config = dict(data)
            if "created_at" in config:
                config["created_at"] = now
            if "last_updated" in config:
                config["last_updated"] = now
            file_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
            continue

        config = json.loads(file_path.read_text(encoding="utf-8"))
        changed = merge_missing(config, data)
        if path == "config/workspace.config.json":
            config["last_updated"] = now
            changed = True
        if changed:
            file_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


def write_default_text_files():
    """Écrit les fichiers Markdown/env de base sans écraser l'existant."""
    for path, content in DEFAULT_TEXT_FILES.items():
        file_path = ROOT / path
        if not file_path.exists():
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")


def load_config(name: str) -> dict:
    """Charge un fichier JSON depuis config/."""
    path = ROOT / "config" / f"{name}.config.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def save_config(name: str, data: dict):
    """Sauvegarde un fichier JSON dans config/."""
    path = ROOT / "config" / f"{name}.config.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def get_agent_path(agent_name: str) -> Path:
    """Retourne le chemin du dossier d'un agent."""
    return ROOT / "agents" / normalize_agent_name(agent_name)


def init_workspace():
    """Initialise le workspace complet."""
    ensure_dirs()
    write_default_configs()
    write_default_text_files()
    init_default_team()
    init_default_advanced_memory()
    print("✅ Workspace San-o1 Intelligence initialisé.")


def init_default_team():
    """Crée une équipe core minimale sans écraser l'existant."""
    team_dir = ROOT / "teams" / "core"
    team_dir.mkdir(parents=True, exist_ok=True)
    defaults = {
        "team.md": """# Équipe : core

## Objectif
Coordonner le workspace San-o1 Intelligence.

## Coordinateur
- assistant

## Agents
- assistant

## Agents manquants
- Aucun
""",
        "roles.md": """# Rôles — core

## Coordinateur
- `assistant` : clarifie l'objectif, répartit les tâches, consolide les décisions et évite les doublons.

## Agents membres
- `assistant` : assistant IA personnel de l'utilisateur et coordinateur principal du workspace.
""",
        "coordination.md": """# Protocole de coordination — core

## Règles
- Un seul agent coordonne une action globale à la fois.
- Chaque agent garde sa mémoire, ses tâches et ses logs à jour.
- Les handoffs importants sont écrits dans `workspace/multi_agent/handovers/`.
- Les décisions communes sont aussi inscrites dans `memory/decisions.md`.
- Les actions sensibles, destructives, coûteuses ou externes demandent confirmation.
""",
        "handoffs.md": """# Handoffs — core

Les passages de relais détaillés sont stockés dans `workspace/multi_agent/handovers/`.
""",
    }
    for filename, content in defaults.items():
        path = team_dir / filename
        if not path.exists():
            path.write_text(content, encoding="utf-8")

    registry_path = ROOT / "config" / "teams.config.json"
    registry = {"teams": [], "default_team": "core"}
    if registry_path.exists():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    teams = registry.setdefault("teams", [])
    if not any(team.get("name") == "core" for team in teams):
        teams.append(
            {
                "name": "core",
                "agents": ["assistant"],
                "coordinator": "assistant",
                "objective": "Coordonner le workspace San-o1 Intelligence.",
                "created_at": datetime.now().isoformat(),
            }
        )
    registry.setdefault("default_team", "core")
    registry_path.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")


def init_default_advanced_memory():
    """Crée la mémoire avancée par défaut sans écraser l'existant."""
    try:
        from soi.advanced_memory import init_advanced_memory

        init_advanced_memory()
    except Exception as exc:
        print(f"⚠️ Initialisation mémoire avancée incomplète : {exc}")
