"""Onboarding public pour créer un assistant SOI générique."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from soi.agent import create_agent
from soi.workspace import ROOT, load_config, normalize_agent_name, save_config


DEFAULT_NAME = "assistant"
DEFAULT_ROLE = "assistant IA local-first"
DEFAULT_OBJECTIVE = (
    "Aider l'utilisateur à organiser ses idées, gérer ses tâches, conserver le "
    "contexte utile et transformer ses demandes en actions locales, simples et "
    "traçables."
)
DEFAULT_TONE = "clair, chaleureux et fiable"
DEFAULT_STYLE = "structuré, concis et actionnable"
DEFAULT_LANGUAGE = "Français"
DEFAULT_DOMAINS = (
    "- Organisation personnelle\n"
    "- Projets techniques\n"
    "- Écriture et réflexion\n"
    "- Automatisation locale\n"
    "- Gestion de tâches et de mémoire"
)
DEFAULT_LIMITS = (
    "- Ne pas inventer d'informations\n"
    "- Demander confirmation avant action sensible, destructive, coûteuse ou externe\n"
    "- Ne jamais lire ni révéler de secret\n"
    "- Rester local-first par défaut"
)
DEFAULT_RULES = (
    "- Utiliser un vocabulaire générique et ne supposer aucun nom utilisateur\n"
    "- Proposer une prochaine action claire sans surcharger l'utilisateur\n"
    "- Maintenir les tâches, mémoires et logs quand c'est utile\n"
    "- Préférer les actions réversibles et vérifiables"
)
DEFAULT_MEMORY = (
    "Cet assistant est conçu comme un assistant SOI public et réutilisable, "
    "non lié à un utilisateur personnel précis."
)


@dataclass(frozen=True)
class OnboardingOptions:
    name: str = DEFAULT_NAME
    role: str = DEFAULT_ROLE
    objective: str = DEFAULT_OBJECTIVE
    tone: str = DEFAULT_TONE
    style: str = DEFAULT_STYLE
    language: str = DEFAULT_LANGUAGE
    domains: str = DEFAULT_DOMAINS
    limits: str = DEFAULT_LIMITS
    rules: str = DEFAULT_RULES
    initial_memory: str = DEFAULT_MEMORY
    workspace: str = str(ROOT)
    default_agent: bool = False


def _ask(prompt: str, default: str) -> str:
    value = input(f"{prompt} [{default}] : ").strip()
    return value or default


def _interactive_options() -> OnboardingOptions:
    print("Onboarding SOI - assistant générique")
    print("Appuie sur Entrée pour garder une valeur par défaut.\n")
    name = _ask("Identifiant de l'assistant", DEFAULT_NAME)
    role = _ask("Rôle", DEFAULT_ROLE)
    objective = _ask("Objectif principal", DEFAULT_OBJECTIVE)
    tone = _ask("Ton", DEFAULT_TONE)
    style = _ask("Style", DEFAULT_STYLE)
    language = _ask("Langue", DEFAULT_LANGUAGE)
    workspace = _ask("Workspace cible", str(ROOT))
    make_default = _ask("Définir comme agent par défaut ? oui/non", "non").lower() in {"o", "oui", "y", "yes"}
    return OnboardingOptions(
        name=name,
        role=role,
        objective=objective,
        tone=tone,
        style=style,
        language=language,
        workspace=workspace,
        default_agent=make_default,
    )


def _set_default_agent(slug: str) -> None:
    agents_config = load_config("agents")
    agents_config.setdefault("agents", [])
    if slug not in agents_config["agents"]:
        agents_config["agents"].append(slug)
    agents_config["agents"] = sorted(set(agents_config["agents"]))
    agents_config["default_agent"] = slug
    save_config("agents", agents_config)

    workspace_config = load_config("workspace")
    workspace_config["default_agent"] = slug
    workspace_config.setdefault("sandbox", {})["default_agent"] = slug
    save_config("workspace", workspace_config)


def onboard(
    *,
    name: Optional[str] = None,
    role: Optional[str] = None,
    objective: Optional[str] = None,
    tone: Optional[str] = None,
    style: Optional[str] = None,
    language: Optional[str] = None,
    non_interactive: bool = False,
    accept_defaults: bool = False,
    default_agent: bool = False,
    workspace: Optional[str] = None,
) -> str:
    """Crée ou configure un assistant générique utilisable par tout le monde."""
    if non_interactive:
        if not accept_defaults and not name:
            print("❌ Utilise --accept-defaults ou fournis --name en mode non interactif.")
            return ""
        options = OnboardingOptions(
            name=name or DEFAULT_NAME,
            role=role or DEFAULT_ROLE,
            objective=objective or DEFAULT_OBJECTIVE,
            tone=tone or DEFAULT_TONE,
            style=style or DEFAULT_STYLE,
            language=language or DEFAULT_LANGUAGE,
            workspace=workspace or str(ROOT),
            default_agent=default_agent,
        )
    else:
        options = _interactive_options()
        if name:
            options = OnboardingOptions(**{**options.__dict__, "name": name})

    slug = create_agent(
        name=options.name,
        role=options.role,
        objective=options.objective,
        tone=options.tone,
        style=options.style,
        language=options.language,
        domains=options.domains,
        limits=options.limits,
        rules=options.rules,
        initial_memory=options.initial_memory,
    )

    if options.default_agent:
        _set_default_agent(slug)

    normalized = normalize_agent_name(slug)
    agent_dir = ROOT / "agents" / normalized
    requested_workspace = Path(options.workspace).expanduser()
    print("\n✅ Onboarding terminé.")
    print(f"Assistant : {normalized}")
    print(f"Dossier : {agent_dir.relative_to(ROOT)}")
    print(f"Workspace actif : {ROOT}")
    if requested_workspace.resolve() != ROOT.resolve():
        print("Note : cette V1 crée l'assistant dans le workspace SOI courant.")
    print("\nCommandes utiles :")
    print(f"  python3 scripts/run_agent.py show-agent {normalized}")
    print(f"  python3 scripts/run_agent.py build-prompt {normalized} --output workspace/sandbox/output/prompt_{normalized}.txt")
    print(f"  python3 scripts/run_agent.py heartbeat run --agent {normalized}")
    print(f"  python3 scripts/run_agent.py cron add --name daily-check --every 1d --message \"Prépare un point de situation.\" --agent {normalized}")
    return normalized
