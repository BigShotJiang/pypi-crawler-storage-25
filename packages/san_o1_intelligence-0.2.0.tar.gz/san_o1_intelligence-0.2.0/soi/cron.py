"""Scheduler cron local et fichier-first pour SOI."""

from __future__ import annotations

from datetime import datetime, timedelta
import json
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set

from soi.openrouter_client import OpenRouterClient
from soi.workspace import ROOT, load_config, normalize_agent_name, save_config


JOBS_PATH = ROOT / "workspace" / "cron" / "jobs.json"
RUNS_PATH = ROOT / "workspace" / "cron" / "runs.jsonl"
DEFAULT_CONFIG = {
    "enabled": True,
    "default_agent": "assistant",
    "mode": "local",
    "use_llm_if_available": False,
    "max_due_jobs": 10,
}


def _now() -> datetime:
    return datetime.now().replace(microsecond=0)


def _now_iso() -> str:
    return _now().isoformat()


def _parse_datetime(value: str) -> datetime:
    clean = value.strip()
    if clean.startswith("+"):
        return _now() + _parse_duration(clean[1:])
    try:
        return datetime.fromisoformat(clean)
    except ValueError as exc:
        raise ValueError("Date invalide. Utilise ISO, par exemple 2026-05-01T22:00:00, ou +10m.") from exc


def _parse_duration(value: str) -> timedelta:
    match = re.fullmatch(r"\s*(\d+)\s*([smhdw])\s*", value)
    if not match:
        raise ValueError("Durée invalide. Exemples valides : 30s, 10m, 2h, 1d, 1w.")
    amount = int(match.group(1))
    unit = match.group(2)
    if unit == "s":
        return timedelta(seconds=amount)
    if unit == "m":
        return timedelta(minutes=amount)
    if unit == "h":
        return timedelta(hours=amount)
    if unit == "d":
        return timedelta(days=amount)
    return timedelta(weeks=amount)


def _ensure_storage() -> None:
    JOBS_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not JOBS_PATH.exists():
        JOBS_PATH.write_text("[]\n", encoding="utf-8")
    if not RUNS_PATH.exists():
        RUNS_PATH.write_text("", encoding="utf-8")


def _load_config() -> Dict[str, object]:
    config = load_config("cron")
    changed = False
    for key, value in DEFAULT_CONFIG.items():
        if key not in config:
            config[key] = value
            changed = True
    if changed:
        save_config("cron", config)
    return config


def _load_jobs() -> List[Dict[str, object]]:
    _ensure_storage()
    try:
        data = json.loads(JOBS_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        data = []
    return data if isinstance(data, list) else []


def _save_jobs(jobs: List[Dict[str, object]]) -> None:
    _ensure_storage()
    JOBS_PATH.write_text(json.dumps(jobs, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _append_run(run: Dict[str, object]) -> None:
    _ensure_storage()
    with RUNS_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(run, ensure_ascii=False) + "\n")


def _read_runs(job_id: Optional[str] = None) -> List[Dict[str, object]]:
    _ensure_storage()
    runs: List[Dict[str, object]] = []
    for line in RUNS_PATH.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and (job_id is None or value.get("job_id") == job_id):
            runs.append(value)
    return runs


def _job_id(name: str) -> str:
    return normalize_agent_name(name)


def _find_job(jobs: List[Dict[str, object]], job_id: str) -> Optional[Dict[str, object]]:
    for job in jobs:
        if str(job.get("id")) == job_id:
            return job
    return None


def _parse_cron_field(field: str, minimum: int, maximum: int) -> Set[int]:
    values: Set[int] = set()
    for part in field.split(","):
        part = part.strip()
        if not part:
            continue
        if part == "*":
            values.update(range(minimum, maximum + 1))
            continue
        if part.startswith("*/"):
            step = int(part[2:])
            values.update(range(minimum, maximum + 1, step))
            continue
        if "-" in part:
            start_text, end_text = part.split("-", 1)
            values.update(range(int(start_text), int(end_text) + 1))
            continue
        values.add(int(part))
    invalid = [value for value in values if value < minimum or value > maximum]
    if invalid:
        raise ValueError(f"Champ cron invalide : {field}")
    return values


def _cron_matches(moment: datetime, expression: str) -> bool:
    fields = expression.split()
    if len(fields) != 5:
        raise ValueError("La V1 supporte les expressions cron 5 champs.")
    minute, hour, day, month, weekday = fields
    # Python: Monday=0. Cron commonly accepts Sunday=0. We map Sunday to 0 and shift Python.
    cron_weekday = (moment.weekday() + 1) % 7
    return (
        moment.minute in _parse_cron_field(minute, 0, 59)
        and moment.hour in _parse_cron_field(hour, 0, 23)
        and moment.day in _parse_cron_field(day, 1, 31)
        and moment.month in _parse_cron_field(month, 1, 12)
        and cron_weekday in _parse_cron_field(weekday, 0, 7)
    )


def _next_for_cron(expression: str, after: Optional[datetime] = None) -> datetime:
    cursor = (after or _now()).replace(second=0, microsecond=0) + timedelta(minutes=1)
    limit = cursor + timedelta(days=366)
    while cursor <= limit:
        if _cron_matches(cursor, expression):
            return cursor
        cursor += timedelta(minutes=1)
    raise ValueError("Impossible de trouver une prochaine exécution cron dans les 366 jours.")


def _compute_next_run(job: Dict[str, object], after: Optional[datetime] = None) -> Optional[str]:
    schedule_type = str(job.get("schedule_type", ""))
    value = str(job.get("schedule_value", ""))
    base = after or _now()
    if schedule_type == "at":
        target = _parse_datetime(value)
        return target.isoformat() if target >= base else None
    if schedule_type == "every":
        last_run_at = str(job.get("last_run_at") or "")
        if last_run_at:
            try:
                base = datetime.fromisoformat(last_run_at)
            except ValueError:
                base = after or _now()
        return (base + _parse_duration(value)).isoformat()
    if schedule_type == "cron":
        return _next_for_cron(value, after=base).isoformat()
    return None


def _select_schedule(every: Optional[str], at: Optional[str], cron_expr: Optional[str]) -> Dict[str, str]:
    selected = [(name, value) for name, value in [("every", every), ("at", at), ("cron", cron_expr)] if value]
    if len(selected) != 1:
        raise ValueError("Fournis exactement un mode de planification : --every, --at ou --cron.")
    schedule_type, value = selected[0]
    probe = {"schedule_type": schedule_type, "schedule_value": value}
    next_run = _compute_next_run(probe)
    if next_run is None:
        raise ValueError("La planification est déjà expirée ou invalide.")
    return {"schedule_type": schedule_type, "schedule_value": value, "next_run_at": next_run}


def cron_add(
    *,
    name: str,
    message: str,
    agent: Optional[str] = None,
    every: Optional[str] = None,
    at: Optional[str] = None,
    cron_expr: Optional[str] = None,
    disabled: bool = False,
) -> str:
    config = _load_config()
    jobs = _load_jobs()
    job_id = _job_id(name)
    schedule = _select_schedule(every, at, cron_expr)
    existing = _find_job(jobs, job_id)
    job = {
        "id": job_id,
        "name": name.strip(),
        "agent": normalize_agent_name(agent or str(config.get("default_agent") or "assistant")),
        "message": message.strip(),
        "enabled": not disabled,
        "created_at": _now_iso(),
        "updated_at": _now_iso(),
        "last_run_at": None,
        "last_status": None,
        "run_count": 0,
        **schedule,
    }
    if existing:
        jobs[jobs.index(existing)] = {**existing, **job, "created_at": existing.get("created_at", job["created_at"])}
        print(f"🔄 Cron mis à jour : {job_id}")
    else:
        jobs.append(job)
        print(f"✅ Cron ajouté : {job_id}")
    _save_jobs(jobs)
    print(f"Prochaine exécution : {job['next_run_at']}")
    return job_id


def cron_list() -> List[Dict[str, object]]:
    jobs = _load_jobs()
    if not jobs:
        print("Aucun cron configuré.")
        return []
    print("# Cron SOI")
    for job in jobs:
        status = "enabled" if job.get("enabled", True) else "disabled"
        print(f"- {job.get('id')} [{status}] agent={job.get('agent')} next={job.get('next_run_at')} message={job.get('message')}")
    return jobs


def cron_show(job_id: str) -> Optional[Dict[str, object]]:
    job_id = _job_id(job_id)
    job = _find_job(_load_jobs(), job_id)
    if not job:
        print(f"❌ Cron introuvable : {job_id}")
        return None
    print(json.dumps(job, indent=2, ensure_ascii=False))
    return job


def cron_set_enabled(job_id: str, enabled: bool) -> None:
    job_id = _job_id(job_id)
    jobs = _load_jobs()
    job = _find_job(jobs, job_id)
    if not job:
        print(f"❌ Cron introuvable : {job_id}")
        return
    job["enabled"] = enabled
    job["updated_at"] = _now_iso()
    _save_jobs(jobs)
    print("✅ Cron activé." if enabled else "⏸️ Cron désactivé.")


def cron_rm(job_id: str) -> None:
    job_id = _job_id(job_id)
    jobs = _load_jobs()
    kept = [job for job in jobs if str(job.get("id")) != job_id]
    if len(kept) == len(jobs):
        print(f"❌ Cron introuvable : {job_id}")
        return
    _save_jobs(kept)
    print(f"🗑️ Cron supprimé : {job_id}")


def _local_job_report(job: Dict[str, object]) -> str:
    return (
        f"Run cron local pour `{job.get('id')}`.\n"
        f"Agent cible : {job.get('agent')}.\n"
        f"Message : {job.get('message')}.\n"
        "Aucune action externe, destructive, coûteuse ou liée à des secrets n'a été lancée."
    )


def _execute_job(job: Dict[str, object]) -> Dict[str, object]:
    config = _load_config()
    started_at = _now_iso()
    status = "success"
    error = ""
    output = _local_job_report(job)
    if bool(config.get("use_llm_if_available", False)) and OpenRouterClient().has_api_key:
        try:
            from soi.chat_runtime import AgentChatRuntime

            runtime = AgentChatRuntime(agent_name=str(job.get("agent")), mode="free")
            try:
                reply = runtime.ask(str(job.get("message")), allow_paid=False)
                output = reply.content
            finally:
                runtime.close()
        except Exception as exc:
            status = "error"
            error = str(exc)
            output = f"{output}\n\nErreur locale pendant l'appel LLM : {error}"
    return {
        "timestamp": _now_iso(),
        "started_at": started_at,
        "job_id": job.get("id"),
        "agent": job.get("agent"),
        "status": status,
        "message": job.get("message"),
        "output": output,
        "error": error,
    }


def cron_run(job_id: str) -> Optional[Dict[str, object]]:
    job_id = _job_id(job_id)
    jobs = _load_jobs()
    job = _find_job(jobs, job_id)
    if not job:
        print(f"❌ Cron introuvable : {job_id}")
        return None
    run = _execute_job(job)
    _append_run(run)
    job["last_run_at"] = run["timestamp"]
    job["last_status"] = run["status"]
    job["run_count"] = int(job.get("run_count", 0)) + 1
    job["updated_at"] = _now_iso()
    job["next_run_at"] = _compute_next_run(job, after=_now())
    _save_jobs(jobs)
    print(run["output"])
    return run


def _due_jobs(jobs: Iterable[Dict[str, object]]) -> List[Dict[str, object]]:
    current = _now()
    due: List[Dict[str, object]] = []
    for job in jobs:
        if not job.get("enabled", True):
            continue
        next_run_at = job.get("next_run_at")
        if not next_run_at:
            continue
        try:
            next_run = datetime.fromisoformat(str(next_run_at))
        except ValueError:
            continue
        if next_run <= current:
            due.append(job)
    return due


def cron_due() -> List[Dict[str, object]]:
    config = _load_config()
    if not bool(config.get("enabled", True)):
        print("Scheduler cron désactivé.")
        return []
    max_due = int(config.get("max_due_jobs", 10))
    runs: List[Dict[str, object]] = []
    for job in _due_jobs(_load_jobs())[:max_due]:
        run = cron_run(str(job.get("id")))
        if run:
            runs.append(run)
    if not runs:
        print("Aucun cron arrivé à échéance.")
    return runs


def cron_runs(job_id: Optional[str] = None) -> List[Dict[str, object]]:
    normalized = _job_id(job_id) if job_id else None
    runs = _read_runs(normalized)
    if not runs:
        print("Aucun run enregistré.")
        return []
    print("# Runs cron SOI")
    for run in runs[-20:]:
        print(f"- {run.get('timestamp')} {run.get('job_id')} [{run.get('status')}]")
    return runs
