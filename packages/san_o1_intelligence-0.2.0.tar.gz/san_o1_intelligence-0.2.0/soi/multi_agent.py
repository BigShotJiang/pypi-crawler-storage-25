"""Coordination multi-agent locale."""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from soi.logger import log
from soi.tasks import add_task
from soi.workspace import ROOT, get_agent_path, normalize_agent_name

TEAMS_ROOT = ROOT / "teams"
HANDOFF_ROOT = ROOT / "workspace" / "multi_agent" / "handovers"
REGISTRY_PATH = ROOT / "config" / "teams.config.json"


def _team_slug(name: str) -> str:
    return normalize_agent_name(name)


def _parse_agents(agents: str) -> List[str]:
    raw_items = agents.replace("\n", ",").split(",")
    return [normalize_agent_name(item) for item in raw_items if item.strip()]


def _load_registry() -> dict:
    if REGISTRY_PATH.exists():
        return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    return {"teams": [], "default_team": "core"}


def _save_registry(registry: dict):
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_PATH.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")


def _upsert_team(entry: dict):
    registry = _load_registry()
    teams = registry.setdefault("teams", [])
    teams[:] = [team for team in teams if team.get("name") != entry["name"]]
    teams.append(entry)
    teams.sort(key=lambda item: item.get("name", ""))
    registry.setdefault("default_team", entry["name"])
    _save_registry(registry)


def _read(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return f"<!-- {path.relative_to(ROOT)} non trouvé -->"


def create_team(
    name: str,
    agents: str,
    objective: str = "Coordonner plusieurs agents persistants.",
    coordinator: str = "assistant",
) -> str:
    """Crée une équipe multi-agent locale."""
    slug = _team_slug(name)
    agent_ids = _parse_agents(agents)
    coordinator_id = normalize_agent_name(coordinator)
    if coordinator_id not in agent_ids:
        agent_ids.insert(0, coordinator_id)

    team_dir = TEAMS_ROOT / slug
    team_dir.mkdir(parents=True, exist_ok=True)
    HANDOFF_ROOT.mkdir(parents=True, exist_ok=True)

    missing_agents = [agent for agent in agent_ids if not get_agent_path(agent).exists()]
    now = datetime.now().isoformat()

    team_md = f"""# Équipe : {slug}

## Objectif
{objective}

## Coordinateur
- {coordinator_id}

## Agents
{chr(10).join(f"- {agent}" for agent in agent_ids)}

## Agents manquants
{chr(10).join(f"- {agent}" for agent in missing_agents) if missing_agents else "- Aucun"}

## Créée le
{now}
"""

    roles_md = f"""# Rôles — {slug}

## Coordinateur
- `{coordinator_id}` : clarifie l'objectif, répartit les tâches, consolide les décisions et évite les doublons.

## Agents membres
{chr(10).join(f"- `{agent}` : rôle défini dans `agents/{agent}/agent.md`." for agent in agent_ids)}
"""

    coordination_md = f"""# Protocole de coordination — {slug}

## Règles
- Un seul agent coordonne une action globale à la fois.
- Chaque agent garde sa mémoire, ses tâches et ses logs à jour.
- Les handoffs importants sont écrits dans `workspace/multi_agent/handovers/`.
- Les décisions communes sont aussi inscrites dans `memory/decisions.md`.
- Les actions sensibles, destructives, coûteuses ou externes demandent confirmation.

## Cycle conseillé
1. Le coordinateur lit les tâches et le contexte.
2. Il découpe le travail par agent.
3. Chaque agent reçoit une tâche claire.
4. Les résultats sont consolidés dans le brief d'équipe.
5. Les décisions et mémoires importantes sont enregistrées.
"""

    handoffs_md = f"""# Handoffs — {slug}

Les passages de relais détaillés sont stockés dans `workspace/multi_agent/handovers/`.
"""

    files = {
        "team.md": team_md,
        "roles.md": roles_md,
        "coordination.md": coordination_md,
        "handoffs.md": handoffs_md,
    }
    for filename, content in files.items():
        path = team_dir / filename
        path.write_text(content, encoding="utf-8")

    _upsert_team(
        {
            "name": slug,
            "agents": agent_ids,
            "coordinator": coordinator_id,
            "objective": objective,
            "created_at": now,
        }
    )

    print(f"🤝 Équipe multi-agent '{slug}' prête.")
    if missing_agents:
        print(f"⚠️ Agents manquants : {', '.join(missing_agents)}")
    return slug


def list_teams():
    """Liste les équipes multi-agent."""
    registry = _load_registry()
    teams = registry.get("teams", [])
    if not teams:
        print("Aucune équipe multi-agent trouvée.")
        return
    print("🤝 Équipes disponibles :")
    for team in teams:
        agents = ", ".join(team.get("agents", []))
        print(f"  - {team['name']} [{agents}]")


def show_team(name: str):
    """Affiche le résumé d'une équipe."""
    slug = _team_slug(name)
    team_dir = TEAMS_ROOT / slug
    if not team_dir.exists():
        print(f"❌ Équipe '{slug}' introuvable.")
        return

    print(f"\n🤝 Équipe : {slug}")
    print("-" * 40)
    for filename in ["team.md", "roles.md", "coordination.md", "handoffs.md"]:
        path = team_dir / filename
        if path.exists():
            content = path.read_text(encoding="utf-8").strip()
            preview = content[:800]
            suffix = "..." if len(content) > 800 else ""
            print(f"\n📄 {filename}\n{preview}{suffix}")


def team_brief(name: str, output_file: Optional[str] = None) -> str:
    """Construit un brief multi-agent pour une équipe."""
    slug = _team_slug(name)
    team_dir = TEAMS_ROOT / slug
    if not team_dir.exists():
        message = f"❌ Équipe '{slug}' introuvable."
        print(message)
        return message

    registry = _load_registry()
    team_entry = next((team for team in registry.get("teams", []) if team.get("name") == slug), {})
    agents = team_entry.get("agents", [])

    agent_sections = []
    for agent in agents:
        agent_dir = get_agent_path(agent)
        agent_sections.append(
            f"""## Agent `{agent}`

### Identité
{_read(agent_dir / "agent.md")}

### Objectifs
{_read(agent_dir / "goals.md")}

### Tâches
{_read(agent_dir / "tasks.md")}
"""
        )

    brief = f"""# Brief multi-agent — {slug}

## Équipe
{_read(team_dir / "team.md")}

## Rôles
{_read(team_dir / "roles.md")}

## Coordination
{_read(team_dir / "coordination.md")}

## Agents
{chr(10).join(agent_sections)}

## Instructions finales
- Le coordinateur répartit le travail et évite les doublons.
- Chaque agent travaille dans son propre dossier `agents/<agent>/`.
- Chaque passage de relais important doit être enregistré avec `handoff`.
- Les décisions durables doivent être journalisées.
- Les actions sensibles demandent confirmation.
- Découpe le travail en lots indépendants avec un livrable, un fichier cible et une limite claire par agent.
- Vérifie qu'aucun fichier ou responsabilité critique n'est attribué deux fois sans raison.
- Termine par la prochaine action coordonnée et les dépendances restantes.
"""

    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(brief, encoding="utf-8")
        print(f"💾 Brief multi-agent sauvegardé dans : {output_file}")

    print(brief)
    return brief


def handoff(
    from_agent: str,
    to_agent: str,
    task: str,
    context: str = "",
    team: str = "core",
) -> str:
    """Crée un passage de relais entre deux agents."""
    source = normalize_agent_name(from_agent)
    target = normalize_agent_name(to_agent)
    team_slug = _team_slug(team)
    HANDOFF_ROOT.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_task = normalize_agent_name(task[:48])
    handoff_path = HANDOFF_ROOT / f"{timestamp}_{source}_to_{target}_{safe_task}.md"

    content = f"""# Handoff : {source} -> {target}

## Équipe
{team_slug}

## Date
{datetime.now().isoformat()}

## Tâche
{task}

## Contexte
{context or "Aucun contexte complémentaire."}

## Attendu de l'agent receveur
- Lire ce handoff.
- Ajouter ou mettre à jour sa tâche.
- Exécuter uniquement les actions sûres.
- Journaliser la suite donnée.
"""
    handoff_path.write_text(content, encoding="utf-8")

    team_handoffs = TEAMS_ROOT / team_slug / "handoffs.md"
    if team_handoffs.exists():
        current = team_handoffs.read_text(encoding="utf-8").rstrip()
        team_handoffs.write_text(
            f"{current}\n\n- {datetime.now().strftime('%Y-%m-%d %H:%M')} : `{source}` -> `{target}` : {task} (`{handoff_path.relative_to(ROOT)}`)\n",
            encoding="utf-8",
        )

    if get_agent_path(target).exists():
        add_task(target, task, status="TODO")
    if get_agent_path(source).exists():
        log(source, action="Handoff multi-agent", decision=f"Passage de relais vers {target}", file_modified=str(handoff_path.relative_to(ROOT)), summary=task)
    if get_agent_path(target).exists():
        log(target, action="Réception handoff multi-agent", decision=f"Recevoir une tâche depuis {source}", file_modified=str(handoff_path.relative_to(ROOT)), summary=task)

    print(f"🔁 Handoff créé : {handoff_path.relative_to(ROOT)}")
    return str(handoff_path)
