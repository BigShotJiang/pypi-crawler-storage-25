"""Journalisation des actions et décisions."""

from datetime import datetime

from soi.workspace import ROOT, get_agent_path, normalize_agent_name


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _append_decision(agent_name: str, decision: str, summary: str):
    """Ajoute les décisions importantes au fichier global de décisions."""
    decisions_path = ROOT / "memory" / "decisions.md"
    decisions_path.parent.mkdir(parents=True, exist_ok=True)
    if not decisions_path.exists():
        decisions_path.write_text("# Décisions importantes\n\n", encoding="utf-8")

    entry = f"""## {_now()}

- **Agent** : {agent_name}
- **Décision** : {decision}
- **Contexte** : {summary}

---
"""
    current = decisions_path.read_text(encoding="utf-8").rstrip()
    decisions_path.write_text(f"{current}\n\n{entry}", encoding="utf-8")


def log(
    agent_name: str,
    action: str = "",
    decision: str = "",
    file_modified: str = "",
    summary: str = "",
):
    """Ajoute une entrée dans le journal de l'agent."""
    slug = normalize_agent_name(agent_name)
    logs_path = get_agent_path(slug) / "logs.md"

    if not logs_path.parent.exists():
        print(f"❌ Agent '{slug}' introuvable.")
        return

    if not logs_path.exists():
        logs_path.write_text(f"# Journal de l’agent — {slug}\n\n---\n", encoding="utf-8")

    entry = f"""## {_now()}

- **Action** : {action or "Non précisée"}
- **Décision** : {decision or "Aucune"}
- **Fichier modifié** : {file_modified or "Non précisé"}
- **Résumé** : {summary or "Non précisé"}

---
"""

    current = logs_path.read_text(encoding="utf-8").rstrip()
    logs_path.write_text(f"{current}\n\n{entry}", encoding="utf-8")

    if decision.strip():
        _append_decision(slug, decision.strip(), summary.strip() or action.strip())

    print(f"📝 Entrée ajoutée au journal de '{slug}'.")
