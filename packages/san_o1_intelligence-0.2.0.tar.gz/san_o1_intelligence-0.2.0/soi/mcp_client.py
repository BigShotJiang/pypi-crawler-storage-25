"""Client MCP minimal compatible Python 3.9 — JSON-RPC over stdio."""

from __future__ import annotations

import functools
import json
import os
import re
import subprocess
import threading
import time
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Callable, Dict, List, Optional, Tuple, TypeVar

from soi.workspace import ROOT

DEFAULT_MCP_PROTOCOL_VERSION = "2024-11-05"
DEFAULT_TIMEOUT = 30.0


class MCPError(Exception):
    """Erreur liée au protocole MCP."""


class MCPServerTimeout(MCPError):
    """Timeout lors d'un appel MCP."""


class MCPTransientError(MCPError):
    """Erreur transitoire (retryable) : timeout, connexion perdue, etc."""


class MCPPermanentError(MCPError):
    """Erreur permanente (non retryable) : outil inexistant, paramètres invalides."""


def classify_mcp_error(exc: Exception) -> MCPError:
    """Classifie une exception MCP en transitoire ou permanente."""
    msg = str(exc).lower()
    transient_signals = [
        "timeout",
        "connexion",
        "broken pipe",
        "interrompue",
        "fermée",
        "temporarily",
        "unavailable",
    ]
    if isinstance(exc, MCPServerTimeout):
        return MCPTransientError(str(exc))
    if any(sig in msg for sig in transient_signals):
        return MCPTransientError(str(exc))
    return MCPPermanentError(str(exc))


F = TypeVar("F", bound=Callable[..., Any])


def retry_mcp(max_retries: int = 3, backoff: Tuple[float, ...] = (1.0, 2.0, 4.0)) -> Callable[[F], F]:
    """Décorateur de retry avec backoff exponentiel pour les appels MCP."""

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error: Optional[Exception] = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as exc:
                    classified = classify_mcp_error(exc)
                    if isinstance(classified, MCPPermanentError):
                        raise classified from exc
                    last_error = classified
                    if attempt < max_retries:
                        sleep_time = backoff[min(attempt, len(backoff) - 1)]
                        time.sleep(sleep_time)
            raise last_error or MCPError("Échec après retries")

        return wrapper  # type: ignore[return-value]

    return decorator


class MCPServerStdio:
    """Connexion stdio à un serveur MCP via JSON-RPC."""

    def __init__(
        self,
        name: str,
        command: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.name = name
        self.command = command
        self.args = args or []
        self.env = env
        self.timeout = timeout
        self.process: Optional[subprocess.Popen] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._pending: Dict[str, Queue] = {}
        self._lock = threading.Lock()
        self._running = False
        self._request_counter = 0

    def connect(self) -> bool:
        """Lance le serveur, initialise la session MCP. Retourne True si OK."""
        env = dict(os.environ)
        if self.env:
            env.update(self.env)

        try:
            self.process = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
            )
        except FileNotFoundError as exc:
            raise MCPError(f"Commande introuvable : {self.command}") from exc
        except Exception as exc:
            raise MCPError(f"Échec du lancement du serveur MCP {self.name}: {exc}") from exc

        self._running = True
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader_thread.start()

        # Handshake MCP
        try:
            result = self._call(
                "initialize",
                {
                    "protocolVersion": DEFAULT_MCP_PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": "san-o1-intelligence", "version": "0.1.0"},
                },
            )
            # Ignorer le résultat d'initialize pour l'instant ; juste valider la réponse
            _ = result
            self._send_notification("notifications/initialized")
        except Exception as exc:
            self.disconnect()
            raise MCPError(f"Handshake MCP échoué pour {self.name}: {exc}") from exc

        return True

    def disconnect(self) -> None:
        """Arrête proprement le serveur."""
        self._running = False
        if self.process:
            for pipe in (self.process.stdin, self.process.stdout, self.process.stderr):
                if pipe:
                    try:
                        pipe.close()
                    except Exception:
                        pass
            if self.process.poll() is None:
                try:
                    self.process.terminate()
                    self.process.wait(timeout=2.0)
                except Exception:
                    pass
                try:
                    self.process.kill()
                except Exception:
                    pass
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self.process = None
        with self._lock:
            for q in self._pending.values():
                q.put(None)
            self._pending.clear()

    def _send_raw(self, line: str) -> None:
        if not self.process or self.process.stdin is None:
            raise MCPError(f"Serveur MCP {self.name} non connecté.")
        try:
            self.process.stdin.write(line + "\n")
            self.process.stdin.flush()
        except BrokenPipeError as exc:
            raise MCPError(f"Connexion MCP {self.name} interrompue.") from exc

    def _reader_loop(self) -> None:
        """Lit stdout ligne par ligne et distribue les réponses."""
        while self._running and self.process and self.process.stdout:
            try:
                line = self.process.stdout.readline()
            except Exception:
                break
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            msg_id = msg.get("id")
            if msg_id is not None:
                with self._lock:
                    q = self._pending.get(str(msg_id))
                if q is not None:
                    q.put(msg)
            # Les notifications sans id sont ignorées silencieusement

    def _next_id(self) -> str:
        with self._lock:
            self._request_counter += 1
            return f"{self.name}_{self._request_counter}"

    def _call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Envoie une requête JSON-RPC et attend le résultat."""
        req_id = self._next_id()
        q: Queue = Queue(maxsize=1)
        with self._lock:
            self._pending[req_id] = q

        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params or {},
        }
        self._send_raw(json.dumps(payload))

        try:
            msg = q.get(timeout=self.timeout)
        except Empty:
            with self._lock:
                self._pending.pop(req_id, None)
            raise MCPServerTimeout(f"Timeout ({self.timeout}s) sur {method} pour {self.name}")

        with self._lock:
            self._pending.pop(req_id, None)

        if msg is None:
            raise MCPError(f"Connexion fermée pendant l'appel {method} sur {self.name}")

        if "error" in msg:
            error = msg["error"]
            raise MCPError(f"Erreur MCP {self.name}: {error}")

        return msg.get("result")

    def _send_notification(self, method: str, params: Optional[Dict[str, Any]] = None) -> None:
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
        }
        self._send_raw(json.dumps(payload))

    def list_tools(self) -> List[Dict[str, Any]]:
        """Liste les outils exposés par le serveur MCP."""
        result = self._call("tools/list", {})
        if not isinstance(result, dict):
            return []
        tools = result.get("tools")
        if not isinstance(tools, list):
            return []
        return tools

    @retry_mcp(max_retries=3, backoff=(1.0, 2.0, 4.0))
    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        """Appelle un outil MCP par son nom (avec retry automatique sur erreurs transitoires)."""
        result = self._call("tools/call", {"name": name, "arguments": arguments or {}})
        return result


class MCPClientManager:
    """Gère plusieurs connexions MCP et agrège les outils."""

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or (ROOT / "config" / "mcp.config.json")
        self.servers: Dict[str, MCPServerStdio] = {}
        self._tool_to_server: Dict[str, str] = {}
        self._tools_cache: List[Dict[str, Any]] = []

    def load_and_connect(self) -> Tuple[int, int]:
        """Charge la config, connecte les serveurs activés.
        Retourne (nb_connectés, nb_échecs).
        """
        self.disconnect_all()
        self.servers.clear()
        self._tool_to_server.clear()
        self._tools_cache.clear()

        if not self.config_path.exists():
            return 0, 0

        try:
            config = json.loads(self.config_path.read_text(encoding="utf-8"))
        except Exception:
            return 0, 0

        servers = config.get("servers", [])
        connected = 0
        failed = 0

        for entry in servers:
            if not entry.get("enabled", False):
                continue
            name = str(entry.get("name", ""))
            transport = str(entry.get("transport", "stdio"))
            if not name or transport != "stdio":
                continue
            command = str(entry.get("command", ""))
            args = entry.get("args", [])
            env = entry.get("env")
            timeout = float(entry.get("timeout", DEFAULT_TIMEOUT))

            if not command:
                failed += 1
                continue

            server = MCPServerStdio(
                name=name,
                command=command,
                args=args if isinstance(args, list) else [],
                env=env if isinstance(env, dict) else None,
                timeout=timeout,
            )
            try:
                server.connect()
                self.servers[name] = server
                connected += 1
            except MCPError:
                failed += 1
                continue

        self._refresh_tools_cache()
        return connected, failed

    def disconnect_all(self) -> None:
        for server in list(self.servers.values()):
            server.disconnect()
        self.servers.clear()
        self._tool_to_server.clear()
        self._tools_cache.clear()

    def _refresh_tools_cache(self) -> None:
        self._tools_cache = []
        self._tool_to_server.clear()
        for server in self.servers.values():
            try:
                tools = server.list_tools()
            except MCPError:
                continue
            for tool in tools:
                if not isinstance(tool, dict):
                    continue
                tname = str(tool.get("name", ""))
                if not tname:
                    continue
                self._tools_cache.append(tool)
                self._tool_to_server[tname] = server.name

    def list_tools(self) -> List[Dict[str, Any]]:
        """Retourne tous les outils MCP disponibles."""
        return list(self._tools_cache)

    def find_server_for_tool(self, tool_name: str) -> Optional[str]:
        return self._tool_to_server.get(tool_name)

    def call_tool(self, server_name: str, tool_name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        server = self.servers.get(server_name)
        if not server:
            raise MCPError(f"Serveur MCP '{server_name}' non connecté.")
        return server.call_tool(tool_name, arguments)

    def tools_text_for_prompt(self) -> str:
        """Génère un bloc texte décrivant les outils MCP pour le prompt système."""
        tools = self.list_tools()
        if not tools:
            return ""
        lines = ["## Outils MCP disponibles"]
        for tool in tools:
            name = str(tool.get("name", "?"))
            description = str(tool.get("description", "Pas de description."))
            schema = tool.get("inputSchema", {})
            lines.append(f"- {name}: {description}")
            if isinstance(schema, dict) and schema.get("properties"):
                lines.append(f"  Paramètres: {json.dumps(schema.get('properties'), ensure_ascii=False)}")
        lines.append("")
        lines.append(
            "Pour appeler un outil MCP, réponds exactement avec :"
        )
        lines.append("<TOOL_MCP:server:tool>{\"param\": \"valeur\"}</TOOL_MCP>")
        lines.append("Remplace 'server' par le nom du serveur, 'tool' par le nom de l'outil.")
        return "\n".join(lines)

    def status_lines(self) -> List[str]:
        """Retourne des lignes de statut pour le TUI / CLI."""
        lines: List[str] = []
        if not self.servers:
            lines.append("Aucun serveur MCP connecté.")
            return lines
        lines.append("Serveurs MCP connectés :")
        for name, server in self.servers.items():
            try:
                tools = server.list_tools()
                tool_names = [str(t.get("name", "?")) for t in tools if isinstance(t, dict)]
                lines.append(f"  - {name}: {len(tool_names)} outil(s) — {', '.join(tool_names)}")
            except MCPError as exc:
                lines.append(f"  - {name}: erreur — {exc}")
        return lines


def parse_mcp_tool_call(text: str) -> Optional[Tuple[str, str, Dict[str, Any]]]:
    """Extrait un appel d'outil MCP du texte LLM.
    Retourne (server_name, tool_name, arguments) ou None.
    """
    # Cherche <TOOL_MCP:server:tool>{...}</TOOL_MCP>
    pattern = re.compile(
        r"<TOOL_MCP:([^:]+):([^>]+)>(.*?)</TOOL_MCP>", re.DOTALL
    )
    match = pattern.search(text)
    if not match:
        return None
    server_name = match.group(1).strip()
    tool_name = match.group(2).strip()
    args_text = match.group(3).strip()
    try:
        arguments = json.loads(args_text) if args_text else {}
    except json.JSONDecodeError:
        arguments = {}
    return server_name, tool_name, arguments
