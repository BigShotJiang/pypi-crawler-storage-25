"""San-o1 Intelligence — Workspace IA local-first pour agents persistants."""

__version__ = "0.1.0"
__package_name__ = "san-o1-intelligence"
