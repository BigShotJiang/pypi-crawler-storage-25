"""Runtime d'équipe SOI avec orchestration OpenRouter optionnelle."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Dict, List, Mapping, Optional

from soi.conversation import read_text_if_exists
from soi.multi_agent import _team_slug, team_brief
from soi.openrouter_client import OpenRouterClient, OpenRouterError, load_llm_config, team_model
from soi.workspace import ROOT, normalize_agent_name

RUNS_ROOT = ROOT / "workspace" / "multi_agent" / "runs"


@dataclass(frozen=True)
class TeamRunResult:
    """Résultat persistant d'un run d'équipe."""

    team: str
    objective: str
    mode: str
    model: str
    content: str
    markdown_path: Path
    json_path: Path
    usage: Dict[str, object]
    error: str = ""
    local_only: bool = False


def _now_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _read_workspace(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return f"<!-- {path.name} non trouve -->"


def _load_team_registry(root: Path = ROOT) -> Dict[str, object]:
    path = root / "config" / "teams.config.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {"teams": [], "default_team": "core"}


def _team_entry(team: str, root: Path = ROOT) -> Dict[str, object]:
    slug = _team_slug(team)
    registry = _load_team_registry(root=root)
    for entry in registry.get("teams", []):
        if entry.get("name") == slug:
            return dict(entry)
    return {}


def _agent_context(agent: str, root: Path = ROOT) -> str:
    slug = normalize_agent_name(agent)
    agent_dir = root / "agents" / slug
    return f"""## Agent `{slug}`

### Identite
{read_text_if_exists(agent_dir / "agent.md") or "Agent introuvable."}

### Objectifs
{read_text_if_exists(agent_dir / "goals.md") or "Aucun objectif trouve."}

### Taches
{read_text_if_exists(agent_dir / "tasks.md") or "Aucune tache trouvee."}

### Memoire utile
{read_text_if_exists(agent_dir / "memory.md") or "Aucune memoire trouvee."}
"""


def build_team_messages(team: str, objective: str, root: Path = ROOT) -> List[Dict[str, str]]:
    """Construit le prompt d'orchestration envoyé à OpenRouter."""
    slug = _team_slug(team)
    team_dir = root / "teams" / slug
    entry = _team_entry(slug, root=root)
    agents = [str(agent) for agent in entry.get("agents", [])]
    if not agents and team_dir.exists():
        agents = [slug]

    agent_sections = "\n\n".join(_agent_context(agent, root=root) for agent in agents)
    team_context = f"""# Contexte equipe SOI

## Equipe
{_read_workspace(team_dir / "team.md")}

## Roles
{_read_workspace(team_dir / "roles.md")}

## Coordination
{_read_workspace(team_dir / "coordination.md")}

## Agents disponibles
{agent_sections or "Aucun agent declare."}

## Brief adaptatif global
{read_text_if_exists(root / "memory" / "advanced" / "adaptation" / "adaptive_brief.md")}
"""
    system = """Tu es le coordinateur d'un run multi-agent San-o1 Intelligence.

Tu dois simuler une equipe d'agents persistants a partir du contexte local fourni.
Tu peux proposer des handoffs, des taches et des fichiers a modifier, mais tu ne dois
jamais pretendre avoir modifie le workspace. Les actions externes, couteuses,
destructives ou liees a des secrets demandent confirmation.

Format obligatoire en Markdown :
1. Synthese
2. Plan par agent
3. Handoffs proposes
4. Risques / confirmations necessaires
5. Verification locale recommandee
6. Prochaine action
"""
    user = f"""Objectif du run d'equipe :
{objective}

{team_context}

Produis un plan d'execution concret, sobre, traceable et compatible local-first."""
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def _local_plan(team: str, objective: str, root: Path = ROOT) -> str:
    slug = _team_slug(team)
    entry = _team_entry(slug, root=root)
    agents = [str(agent) for agent in entry.get("agents", [])] or ["assistant"]
    coordinator = str(entry.get("coordinator") or agents[0])
    handoff_lines = "\n".join(
        f"- `{coordinator}` -> `{agent}` : clarifier et traiter la partie de l'objectif qui correspond a son role."
        for agent in agents
        if agent != coordinator
    )
    if not handoff_lines:
        handoff_lines = "- Aucun handoff requis : le coordinateur peut traiter seul ou creer un agent specialise."

    return f"""# Run d'equipe local — {slug}

## Synthese
Objectif : {objective}

Ce run est en mode local, sans appel OpenRouter. Il prepare la coordination et les traces a creer.

## Plan par agent
{chr(10).join(f"- `{agent}` : relire son contexte, proposer son livrable, noter les limites et verifier localement." for agent in agents)}

## Handoffs proposes
{handoff_lines}

## Risques / confirmations necessaires
- Appel OpenRouter : confirmation necessaire via `--execute`, car cela peut consommer du credit.
- Secrets : ne jamais lire ni afficher `.env`.
- Actions destructives : confirmation explicite requise.

## Verification locale recommandee
- Generer un brief avec `python3 scripts/run_agent.py team-brief {slug}`.
- Creer les handoffs utiles avec `python3 scripts/run_agent.py handoff ... --team {slug}`.

## Prochaine action
Lancer `team-run {slug} "...objectif..." --execute` si l'utilisateur veut une orchestration IA OpenRouter."""


def _write_run(
    team: str,
    objective: str,
    mode: str,
    model: str,
    content: str,
    usage: Optional[Mapping[str, object]] = None,
    error: str = "",
    local_only: bool = False,
    root: Path = ROOT,
) -> TeamRunResult:
    slug = _team_slug(team)
    run_id = _now_id()
    run_dir = root / "workspace" / "multi_agent" / "runs"
    run_dir.mkdir(parents=True, exist_ok=True)
    markdown_path = run_dir / f"{run_id}_{slug}.md"
    json_path = run_dir / f"{run_id}_{slug}.json"
    header = f"""# Run multi-agent — {slug}

Date : {datetime.now().isoformat(timespec="seconds")}
Mode : `{mode}`
Modele : `{model or 'local'}`
Objectif : {objective}

---

"""
    markdown_path.write_text(header + content.strip() + "\n", encoding="utf-8")
    data = {
        "team": slug,
        "objective": objective,
        "mode": mode,
        "model": model,
        "usage": dict(usage or {}),
        "error": error,
        "local_only": local_only,
        "markdown_path": str(markdown_path.relative_to(root)),
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return TeamRunResult(
        team=slug,
        objective=objective,
        mode=mode,
        model=model,
        content=content,
        markdown_path=markdown_path,
        json_path=json_path,
        usage=dict(usage or {}),
        error=error,
        local_only=local_only,
    )


def run_team_objective(
    team: str,
    objective: str,
    execute: bool = False,
    model: Optional[str] = None,
    reasoning_effort: Optional[str] = None,
    root: Path = ROOT,
    client: Optional[OpenRouterClient] = None,
) -> TeamRunResult:
    """Prépare ou exécute un run d'équipe.

    `execute=False` reste strictement local et gratuit. `execute=True` appelle
    OpenRouter avec le modèle d'équipe configuré.
    """
    slug = _team_slug(team)
    team_dir = root / "teams" / slug
    if not team_dir.exists():
        raise ValueError(f"Equipe '{slug}' introuvable.")

    config = load_llm_config(root=root)
    selected_model = model or team_model(config)
    selected_reasoning = reasoning_effort or str(config.get("team_reasoning_effort", "medium"))

    if not execute:
        content = _local_plan(slug, objective, root=root)
        return _write_run(slug, objective, "local-plan", selected_model, content, local_only=True, root=root)

    active_client = client or OpenRouterClient(config=config)
    messages = build_team_messages(slug, objective, root=root)
    try:
        response = active_client.chat(
            messages,
            mode="paid",
            model=selected_model,
            max_tokens=int(config.get("team_max_tokens", 2400)),
            reasoning_effort=selected_reasoning,
            session_id=f"team_{slug}_{_now_id()}",
        )
        return _write_run(
            slug,
            objective,
            "openrouter",
            response.model or selected_model,
            response.content,
            usage=response.usage,
            root=root,
        )
    except OpenRouterError as exc:
        content = (
            "Le run OpenRouter n'a pas pu aboutir.\n\n"
            f"Erreur : {exc}\n\n"
            "Aucun secret n'a ete affiche. Verifie la cle OPENROUTER_API_KEY, le credit ou relance sans `--execute`."
        )
        return _write_run(
            slug,
            objective,
            "openrouter-error",
            selected_model,
            content,
            error=str(exc),
            local_only=True,
            root=root,
        )


def save_team_brief_for_run(team: str, output_file: Optional[str] = None) -> str:
    """Petit wrapper public pour garder une API lisible côté CLI."""
    return team_brief(team, output_file=output_file)
