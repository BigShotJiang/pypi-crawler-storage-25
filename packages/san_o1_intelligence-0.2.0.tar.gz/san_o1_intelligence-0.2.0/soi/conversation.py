"""Historique persistant des conversations SOI."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from soi.workspace import ROOT, normalize_agent_name
from soi.mcp_client import MCPClientManager
from soi.tooling import custom_tools_text_for_prompt


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _new_session_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def conversations_root(root: Path = ROOT) -> Path:
    return root / "workspace" / "conversations"


@dataclass(frozen=True)
class ConversationRecord:
    role: str
    content: str
    mode: str = "local"
    model: str = ""
    usage: Optional[Dict[str, object]] = None
    timestamp: str = ""
    session_id: str = ""

    def to_json(self) -> Dict[str, object]:
        return {
            "timestamp": self.timestamp or _now_iso(),
            "session_id": self.session_id,
            "role": self.role,
            "content": self.content,
            "mode": self.mode,
            "model": self.model,
            "usage": self.usage or {},
        }


class ConversationStore:
    """Stocke une session JSONL dans `workspace/conversations/<agent>/`."""

    def __init__(self, agent_name: str = "assistant", session_id: Optional[str] = None, root: Path = ROOT):
        self.root = root
        self.agent_name = normalize_agent_name(agent_name)
        self.session_id = session_id or _new_session_id()
        self.agent_dir = conversations_root(root) / self.agent_name
        self.agent_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.agent_dir / f"{self.session_id}.jsonl"

    def append(
        self,
        role: str,
        content: str,
        mode: str = "local",
        model: str = "",
        usage: Optional[Dict[str, object]] = None,
    ) -> None:
        record = ConversationRecord(
            role=role,
            content=content,
            mode=mode,
            model=model,
            usage=usage or {},
            timestamp=_now_iso(),
            session_id=self.session_id,
        )
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record.to_json(), ensure_ascii=False) + "\n")

    def records(self) -> List[Dict[str, object]]:
        if not self.path.exists():
            return []
        return _read_jsonl(self.path)

    def export_markdown(self) -> Path:
        out_path = self.path.with_suffix(".md")
        lines = [
            f"# Conversation SOI — {self.agent_name}",
            "",
            f"Session : `{self.session_id}`",
            "",
        ]
        for record in self.records():
            role = str(record.get("role", "unknown")).upper()
            mode = str(record.get("mode", "local"))
            model = str(record.get("model", ""))
            suffix = f" — {mode}"
            if model:
                suffix += f" / {model}"
            lines.extend([f"## {role}{suffix}", "", str(record.get("content", "")).strip(), ""])
        out_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
        return out_path


def _read_jsonl(path: Path) -> List[Dict[str, object]]:
    records: List[Dict[str, object]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            records.append(data)
    return records


def recent_messages(agent_name: str = "assistant", limit: int = 20, root: Path = ROOT) -> List[Dict[str, str]]:
    """Charge les derniers messages utilisateur/assistant de toutes les sessions."""
    agent_dir = conversations_root(root) / normalize_agent_name(agent_name)
    if not agent_dir.exists() or limit <= 0:
        return []

    records: List[Dict[str, object]] = []
    paths = sorted(agent_dir.glob("*.jsonl"), key=lambda path: path.stat().st_mtime)
    for path in paths:
        records.extend(_read_jsonl(path))

    messages: List[Dict[str, str]] = []
    for record in records:
        role = str(record.get("role", ""))
        content = str(record.get("content", "")).strip()
        if role in {"user", "assistant"} and content:
            messages.append({"role": role, "content": content})
    return messages[-limit:]


def read_text_if_exists(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return ""


def build_system_context(
    agent_name: str = "assistant",
    root: Path = ROOT,
    mcp_manager: Optional[MCPClientManager] = None,
    agent_mode_enabled: bool = True,
) -> str:
    """Assemble un contexte système compact pour le chat OpenRouter."""
    slug = normalize_agent_name(agent_name)
    agent_dir = root / "agents" / slug
    sections = [
        "# Identité et règles de l'agent",
        read_text_if_exists(agent_dir / "system_prompt.md"),
        "# Mémoire de l'agent",
        read_text_if_exists(agent_dir / "memory.md"),
        "# Tâches en cours",
        read_text_if_exists(agent_dir / "tasks.md"),
        "# Outils disponibles",
        read_text_if_exists(agent_dir / "tools.md"),
        "# Brief adaptatif",
        read_text_if_exists(root / "memory" / "advanced" / "adaptation" / "adaptive_brief.md"),
    ]
    if mcp_manager is not None:
        mcp_text = mcp_manager.tools_text_for_prompt()
        if mcp_text:
            sections.append(mcp_text)
    custom_text = custom_tools_text_for_prompt()
    if custom_text:
        sections.append(custom_text)
    agent_mode_line = "Mode Agent : ACTIVÉ. Tu dois exécuter les actions concrètes via les outils MCP et custom quand c'est utile et autorisé." if agent_mode_enabled else "Mode Agent : DÉSACTIVÉ. Reste conversationnel, ne pas invoquer d'outils sans demande explicite."
    context = "\n\n".join(section for section in sections if section)
    return f"""{context}

# Instructions de chat OpenRouter
- Tu es l'agent `{slug}` dans San-o1 Intelligence.
- {agent_mode_line}
- Réponds en français, tutoie l'utilisateur, reste clair, structuré et actionnable.

## Boucle agentique avancée
Tu es en mode boucle agentique. Tu peux invoquer plusieurs outils successivement.
Structure ta réflexion en :
1. **OBSERVATION** — que sais-je maintenant ?
2. **ORIENTATION** — vers quel objectif ?
3. **DÉCISION** — quel outil maintenant ?
4. **ACTION** — appeler l'outil
5. **VÉRIFICATION** — le résultat correspond-il à l'attente ?
6. **SYNTHÈSE ou RÉPLANIFICATION**

- Chaque résultat d'outil te sera renvoyé comme message.
- Tu peux alors décider d'un nouvel outil ou synthétiser.
- Si un outil échoue, diagnose et essaie une alternative.
- Numérote tes étapes : Étape 1/5, Étape 2/5...
- Après chaque action, évalue si l'objectif est atteint.
- Si un résultat est inattendu, réévalue ta planification.
- Si tu es bloqué après 3 tentatives, arrête et demande de l'aide.

## Gestion des erreurs
- Si un outil retourne une erreur, analyse le type d'erreur.
- Erreur transitoire (timeout) : le système a déjà réessayé, ne réessaie pas toi-même.
- Erreur paramètres : corrige tes arguments et réessaie.
- Erreur outil inexistant : choisis un outil alternatif.
- Jamais de boucle infinie : si 3 échecs consécutifs, arrête et rapporte.

## Auto-amélioration
- Tu peux créer de nouveaux outils dans tools/custom/.
- Tu peux proposer des modifications au code dans soi/ (confirmation requise en safe_agent).
- Après une modification importante, suggère une mise à jour de la mémoire.

## Syntaxe des outils
- Pour les outils MCP : `<TOOL_MCP:server:outil>{{"param": "valeur"}}</TOOL_MCP>`
- Pour les outils custom : `<TOOL_CUSTOM:nom>{{"param": "valeur"}}</TOOL_CUSTOM>`
- **Si tu dois exécuter une action locale** (écrire un fichier, créer un répertoire, lancer une commande, lire un fichier), **utilise les outils**. N'écris jamais que tu l'as fait sans appel outil ou preuve locale.
- N'appelle un outil que si l'action concrète est utile. Pour une simple réponse, réponds directement.
- Si une action touche un secret, un coût, une suppression ou une action externe, demande confirmation.
- Le TUI conserve l'historique localement, mais tu ne dois jamais demander ni afficher une clé API.
- Le serveur MCP `desktop-commander` te donne un accès direct au filesystem : `write_file`, `read_file`, `create_directory`, `list_directory`, `move_file`, etc.
- Le serveur MCP `filesystem` te donne un accès natif au filesystem du workspace.
- Le serveur MCP `playwright` te permet d'automatiser un navigateur.
"""


def build_chat_messages(
    agent_name: str,
    user_content: str,
    history_limit: int = 20,
    root: Path = ROOT,
    mcp_manager: Optional[MCPClientManager] = None,
    agent_mode_enabled: bool = True,
) -> List[Dict[str, str]]:
    """Construit les messages pour OpenRouter avec contexte local + historique récent."""
    messages = [{"role": "system", "content": build_system_context(agent_name, root=root, mcp_manager=mcp_manager, agent_mode_enabled=agent_mode_enabled)}]
    messages.extend(recent_messages(agent_name, limit=history_limit, root=root))
    messages.append({"role": "user", "content": user_content})
    return messages


def list_inbox_files(root: Path = ROOT) -> List[str]:
    """Liste les fichiers d'inbox visibles dans le TUI."""
    inboxes = [root / "workspace" / "sandbox" / "inbox", root / "workspace" / "inbox"]
    files: List[str] = []
    for inbox in inboxes:
        if inbox.exists():
            for path in sorted(inbox.iterdir()):
                if path.is_file() and path.name != ".gitkeep":
                    files.append(str(path.relative_to(root)))
    return files


def summarize_tasks(agent_name: str = "assistant", root: Path = ROOT) -> Dict[str, int]:
    """Compte les tâches par statut pour le panneau TUI."""
    tasks_path = root / "agents" / normalize_agent_name(agent_name) / "tasks.md"
    statuses = {"PRIORITY": 0, "TODO": 0, "DOING": 0, "DONE": 0, "BLOCKED": 0}
    if not tasks_path.exists():
        return statuses
    current = ""
    for line in tasks_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("## "):
            current = stripped.replace("## ", "", 1)
        elif current in statuses and stripped.startswith("- ["):
            statuses[current] += 1
    return statuses
