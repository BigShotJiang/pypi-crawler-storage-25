"""Auto-modification sécurisée du code core de San-o1 Intelligence."""

from __future__ import annotations

import ast
import importlib.util
import json
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from soi.workspace import ROOT


@dataclass
class ModifyResult:
    """Résultat d'une tentative de modification."""

    success: bool
    snapshot_id: str = ""
    message: str = ""
    validation_errors: List[str] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.validation_errors is None:
            self.validation_errors = []


class SelfModifier:
    """Permet à l'agent de modifier son propre code avec garde-fous."""

    def __init__(self, root: Path = ROOT):
        self.root = root
        self.core_dir = root / "soi"
        self.snapshot_dir = root / ".soi_snapshots"
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)

    def snapshot_before_change(self, description: str = "auto-snapshot") -> str:
        """Crée un snapshot git du workspace avant modification."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_id = f"soi-snapshot-{timestamp}"

        # Vérifier que git est disponible
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return ""

        try:
            # Stash les changements non commités
            subprocess.run(
                ["git", "stash", "push", "-m", snapshot_id],
                cwd=self.root,
                capture_output=True,
                check=False,
            )
            # Créer un tag pour le rollback
            subprocess.run(
                ["git", "tag", "-f", snapshot_id],
                cwd=self.root,
                capture_output=True,
                check=False,
            )
        except Exception:
            pass

        # Écrire aussi un fichier de métadonnées
        meta = {
            "id": snapshot_id,
            "timestamp": timestamp,
            "description": description,
        }
        (self.snapshot_dir / f"{snapshot_id}.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return snapshot_id

    def modify_file(self, path: str, new_content: str) -> ModifyResult:
        """Modifie un fichier avec validation et snapshot préalable."""
        target = self.root / path
        if not target.exists():
            return ModifyResult(success=False, message=f"Fichier introuvable : {path}")

        # Vérifier que c'est bien dans le workspace
        try:
            resolved = target.resolve()
            root_resolved = self.root.resolve()
            if not str(resolved).startswith(str(root_resolved)):
                return ModifyResult(success=False, message="Chemin hors du workspace interdit.")
        except Exception as exc:
            return ModifyResult(success=False, message=f"Erreur de résolution de chemin : {exc}")

        # Snapshot avant changement
        snapshot_id = self.snapshot_before_change(f"modify:{path}")

        # Validation syntaxique pour les fichiers Python
        if target.suffix == ".py":
            validation = self.validate_python(new_content)
            if validation.validation_errors:
                return ModifyResult(
                    success=False,
                    snapshot_id=snapshot_id,
                    message="Validation échouée, modification annulée.",
                    validation_errors=validation.validation_errors,
                )

        # Écrire le fichier
        try:
            old_content = target.read_text(encoding="utf-8")
            target.write_text(new_content, encoding="utf-8")

            # Validation par compilation
            if target.suffix == ".py":
                compile_result = self._py_compile_check(target)
                if not compile_result.success:
                    # Rollback auto
                    target.write_text(old_content, encoding="utf-8")
                    return ModifyResult(
                        success=False,
                        snapshot_id=snapshot_id,
                        message="Compilation échouée, rollback automatique effectué.",
                        validation_errors=compile_result.validation_errors,
                    )
        except Exception as exc:
            return ModifyResult(success=False, snapshot_id=snapshot_id, message=f"Erreur d'écriture : {exc}")

        return ModifyResult(
            success=True,
            snapshot_id=snapshot_id,
            message=f"Fichier {path} modifié avec succès.",
        )

    def validate_python(self, content: str) -> ModifyResult:
        """Valide la syntaxe Python avec ast.parse."""
        errors: List[str] = []
        try:
            ast.parse(content)
        except SyntaxError as exc:
            errors.append(f"SyntaxError ligne {exc.lineno}: {exc.msg}")
        except Exception as exc:
            errors.append(f"Erreur de parsing AST: {exc}")

        # Vérifier les imports basiques (sans exécution)
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        mod = alias.name.split(".")[0]
                        if not self._is_stdlib_or_local(mod):
                            errors.append(f"Import potentiellement manquant : {mod}")
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        mod = node.module.split(".")[0]
                        if not self._is_stdlib_or_local(mod):
                            errors.append(f"Import potentiellement manquant : {mod}")
        except Exception:
            pass

        return ModifyResult(
            success=len(errors) == 0,
            message="Validation syntaxique OK" if not errors else "Erreurs de syntaxe détectées.",
            validation_errors=errors,
        )

    def _py_compile_check(self, path: Path) -> ModifyResult:
        """Vérifie qu'un fichier Python compile avec python -m py_compile."""
        try:
            result = subprocess.run(
                ["python3", "-m", "py_compile", str(path)],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                stderr = result.stderr.strip()
                return ModifyResult(
                    success=False,
                    message="py_compile a échoué.",
                    validation_errors=[stderr] if stderr else ["Erreur de compilation inconnue."],
                )
            return ModifyResult(success=True, message="Compilation OK.")
        except Exception as exc:
            return ModifyResult(success=False, message=f"Erreur py_compile: {exc}", validation_errors=[str(exc)])

    @staticmethod
    def _is_stdlib_or_local(module: str) -> bool:
        """Vérifie si un module est stdlib, local (soi.*) ou déjà installé."""
        if module.startswith("soi."):
            return True
        # Liste simplifiée des modules stdlib courants
        stdlib_modules = {
            "abc", "argparse", "ast", "asyncio", "base64", "collections", "contextlib",
            "copy", "csv", "dataclasses", "datetime", "enum", "fnmatch", "functools",
            "hashlib", "html", "http", "importlib", "inspect", "io", "itertools",
            "json", "logging", "math", "operator", "os", "pathlib", "pickle", "queue",
            "random", "re", "shutil", "signal", "socket", "sqlite3", "statistics",
            "string", "subprocess", "sys", "tempfile", "textwrap", "threading", "time",
            "traceback", "typing", "urllib", "uuid", "warnings", "xml", "zipfile",
            "__future__", "httpx",
        }
        if module in stdlib_modules:
            return True
        # Essayer de trouver le module
        try:
            spec = importlib.util.find_spec(module)
            return spec is not None
        except Exception:
            return False

    def rollback(self, snapshot_id: str) -> bool:
        """Restaure le workspace à un snapshot git."""
        if not snapshot_id:
            return False
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return False
        try:
            subprocess.run(
                ["git", "reset", "--hard", snapshot_id],
                cwd=self.root,
                capture_output=True,
                check=False,
            )
            subprocess.run(
                ["git", "stash", "pop"],
                cwd=self.root,
                capture_output=True,
                check=False,
            )
            return True
        except Exception:
            return False

    def is_core_file(self, path: str) -> bool:
        """Vérifie si un chemin cible le répertoire core soi/."""
        if not path:
            return False
        try:
            resolved = (self.root / path).resolve()
            return str(resolved).startswith(str(self.core_dir.resolve()))
        except Exception:
            return False
