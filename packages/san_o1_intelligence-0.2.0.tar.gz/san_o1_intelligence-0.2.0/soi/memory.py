"""Gestion de la mémoire des agents."""

from soi.workspace import get_agent_path, normalize_agent_name

VALID_SECTIONS = [
    "Mémoire long terme",
    "Mémoire court terme",
    "Préférences utilisateur",
    "Projets actifs",
    "Informations importantes",
    "À ne pas oublier",
]


def _insert_bullet(text: str, section: str, bullet: str) -> str:
    """Insère une bullet sous une section Markdown, en créant la section si besoin."""
    lines = text.splitlines()
    header = f"## {section}"

    if header not in [line.strip() for line in lines]:
        if lines and lines[-1].strip() != "":
            lines.append("")
        lines.extend([header, ""])

    header_index = next(i for i, line in enumerate(lines) if line.strip() == header)
    insert_at = header_index + 1
    while insert_at < len(lines) and lines[insert_at].strip() == "":
        insert_at += 1

    lines.insert(insert_at, bullet)
    next_index = insert_at + 1
    if next_index < len(lines) and lines[next_index].strip() and not lines[next_index].strip().startswith("- "):
        lines.insert(next_index, "")
    elif next_index == len(lines):
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def add_memory(agent_name: str, content: str, section: str = "Mémoire long terme"):
    """Ajoute une entrée mémoire à un agent."""
    slug = normalize_agent_name(agent_name)
    if not content.strip():
        print("❌ La mémoire à ajouter ne peut pas être vide.")
        return

    if section not in VALID_SECTIONS:
        print(f"⚠️ Section '{section}' inconnue. Utilisation de 'Mémoire long terme'.")
        section = "Mémoire long terme"

    memory_path = get_agent_path(slug) / "memory.md"
    if not memory_path.exists():
        print(f"❌ Fichier mémoire introuvable pour l'agent '{slug}'.")
        return

    text = memory_path.read_text(encoding="utf-8")
    updated = _insert_bullet(text, section, f"- {content.strip()}")
    memory_path.write_text(updated, encoding="utf-8")
    print(f"🧠 Mémoire ajoutée à '{slug}' dans la section '{section}'.")


def get_memory(agent_name: str) -> str:
    """Retourne le contenu mémoire d'un agent."""
    memory_path = get_agent_path(agent_name) / "memory.md"
    if memory_path.exists():
        return memory_path.read_text(encoding="utf-8")
    return ""
