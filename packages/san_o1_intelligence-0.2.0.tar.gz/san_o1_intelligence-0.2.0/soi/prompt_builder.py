"""Génération du prompt complet d'un agent."""

from typing import Optional

from soi.workspace import ROOT, get_agent_path, normalize_agent_name


def read_agent_file(agent_name: str, filename: str) -> str:
    """Lit un fichier d'agent s'il existe."""
    path = get_agent_path(agent_name) / filename
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return f"<!-- agents/{normalize_agent_name(agent_name)}/{filename} non trouvé -->"


def read_memory_file(filename: str) -> str:
    """Lit un fichier du dossier memory/ s'il existe."""
    path = ROOT / "memory" / filename
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return f"<!-- memory/{filename} non trouvé -->"


def read_workspace_file(path: str) -> str:
    """Lit un fichier du workspace s'il existe."""
    file_path = ROOT / path
    if file_path.exists():
        return file_path.read_text(encoding="utf-8").strip()
    return f"<!-- {path} non trouvé -->"


def private_memory_notice(label: str) -> str:
    """Message utilisé quand un prompt générique ne doit pas charger l'état local privé."""
    return (
        f"<!-- Contenu local privé non inclus dans le prompt générique : {label}. "
        "Ce contenu sera créé ou enrichi dans le workspace cible via onboard et les commandes mémoire. -->"
    )


def build_prompt(agent_name: str, output_file: Optional[str] = None) -> str:
    """Construit le prompt complet d'un agent."""
    slug = normalize_agent_name(agent_name)
    agent_dir = get_agent_path(slug)
    if not agent_dir.exists():
        message = f"❌ Agent '{slug}' introuvable."
        print(message)
        return message
    generic_prompt = slug == "assistant"

    long_term_memory = private_memory_notice("Mémoire long terme") if generic_prompt else read_memory_file("long_term_memory.md")
    short_term_memory = private_memory_notice("Mémoire court terme") if generic_prompt else read_memory_file("short_term_memory.md")
    user_profile = private_memory_notice("Profil utilisateur") if generic_prompt else read_memory_file("user_profile.md")
    decisions = private_memory_notice("Décisions") if generic_prompt else read_memory_file("decisions.md")
    user_model = private_memory_notice("Modèle utilisateur adaptatif") if generic_prompt else read_workspace_file("memory/advanced/user/user_model.md")
    adaptive_brief = private_memory_notice("Brief adaptatif") if generic_prompt else read_workspace_file("memory/advanced/adaptation/adaptive_brief.md")

    prompt = f"""==================================================
PROMPT COMPLET — AGENT : {slug.upper()}
San-o1 Intelligence
==================================================

# 1. IDENTITÉ

{read_agent_file(slug, "agent.md")}

---

# 2. SYSTEM PROMPT

{read_agent_file(slug, "system_prompt.md")}

---

# 3. OBJECTIFS

{read_agent_file(slug, "goals.md")}

---

# 4. RÈGLES

{read_agent_file(slug, "rules.md")}

---

# 5. MÉMOIRE DE L'AGENT

{read_agent_file(slug, "memory.md")}

---

# 6. MÉMOIRE GLOBALE

## Mémoire long terme
{long_term_memory}

## Mémoire court terme
{short_term_memory}

## Profil utilisateur
{user_profile}

## Décisions importantes
{decisions}

## Mémoire avancée — Profil utilisateur adaptatif
{user_model}

## Mémoire avancée — Brief adaptatif
{adaptive_brief}

---

# 7. OUTILS DISPONIBLES

{read_agent_file(slug, "tools.md")}

---

# 8. TÂCHES EN COURS

{read_agent_file(slug, "tasks.md")}

---

# 9. JOURNAL RÉCENT

{read_agent_file(slug, "logs.md")}

---

# 10. CONTEXTE MULTI-AGENT

## Registre des équipes
{read_workspace_file("config/teams.config.json")}

## Équipe core
{read_workspace_file("teams/core/team.md")}

## Rôles core
{read_workspace_file("teams/core/roles.md")}

## Coordination core
{read_workspace_file("teams/core/coordination.md")}

---

# 11. INSTRUCTIONS FINALES

- Tu es l'agent `{slug}` dans San-o1 Intelligence.
- Réponds en français sauf demande contraire.
- Ne fabrique pas d'information manquante : signale ce qui est inconnu.
- Distingue les faits, les hypothèses et les recommandations quand le contexte est ambigu.
- Utilise le contexte local comme source principale : fichiers lus, mémoire, tâches, logs et décisions.
- Pour une demande complexe, applique une chaîne courte : comprendre, récupérer le contexte, décider, agir, vérifier, synthétiser.
- Raisonne de façon structurée en interne, puis expose une justification courte et vérifiable.
- Si plusieurs chemins sont plausibles, compare brièvement impact, effort, risque et réversibilité avant de choisir.
- Vérifie l'auto-cohérence de ta réponse avec les faits, contraintes, règles de sécurité et demande exacte.
- Propose une prochaine action claire et réaliste.
- Garde les réponses simples, structurées, utiles et proportionnées.
- Lorsque c'est pertinent, indique quels fichiers du workspace devraient être mis à jour.
- En multi-agent, utilise `teams/`, `team-brief` et `handoff` pour coordonner le travail.
- Demande confirmation avant toute action sensible, destructive, coûteuse ou liée à des secrets.
- Signale les risques techniques, financiers ou de sécurité.
- Vérifie localement le résultat quand une commande simple permet de le faire.
- Termine les interventions importantes par une relecture qualité : factualité, sécurité, actionnabilité, traçabilité.
- Qualité attendue : rôle clair, contexte respecté, action concrète, garde-fous visibles, sortie exploitable et vérification explicite.

==================================================
"""

    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(prompt, encoding="utf-8")
        print(f"💾 Prompt sauvegardé dans : {output_file}")

    print(prompt)
    return prompt
