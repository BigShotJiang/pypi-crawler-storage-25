"""Création et gestion d'outils locaux auto-créés."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from soi.workspace import ROOT, normalize_agent_name

TOOLS_ROOT = ROOT / "tools" / "custom"
REGISTRY_PATH = ROOT / "config" / "custom_tools.config.json"


def _load_registry() -> dict:
    if REGISTRY_PATH.exists():
        return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    return {"tools": [], "policy": "draft_requires_user_approval"}


def _save_registry(registry: dict):
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_PATH.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")


def _upsert_tool(entry: dict):
    registry = _load_registry()
    tools = registry.setdefault("tools", [])
    tools[:] = [tool for tool in tools if tool.get("name") != entry["name"]]
    tools.append(entry)
    tools.sort(key=lambda item: item.get("name", ""))
    _save_registry(registry)


def _python_template(tool_name: str, purpose: str) -> str:
    tool_literal = repr(tool_name)
    purpose_literal = repr(purpose)
    return f'''#!/usr/bin/env python3
"""Outil local brouillon : {tool_name}."""

TOOL_NAME = {tool_literal}
PURPOSE = {purpose_literal}


def main():
    """Point d'entrée de l'outil."""
    print(f"Outil brouillon : {{TOOL_NAME}}")
    print(f"Objectif : {{PURPOSE}}")
    print("À implémenter avant usage réel.")


if __name__ == "__main__":
    main()
'''


def create_tool(
    name: str,
    purpose: str,
    agent_name: str = "assistant",
    language: str = "python",
) -> str:
    """Crée un outil local en brouillon."""
    slug = normalize_agent_name(name)
    if language not in {"python", "markdown"}:
        print("❌ Langage invalide. Choisissez : python, markdown")
        return slug
    if not purpose.strip():
        print("❌ L'objectif de l'outil ne peut pas être vide.")
        return slug

    tool_dir = TOOLS_ROOT / slug
    tool_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.now().isoformat()
    manifest = {
        "name": slug,
        "display_name": name.strip(),
        "purpose": purpose.strip(),
        "created_by": normalize_agent_name(agent_name),
        "created_at": now,
        "status": "draft",
        "language": language,
        "entrypoint": "run.py" if language == "python" else "README.md",
        "requires_user_approval": True,
        "safety_notes": [
            "Un outil brouillon ne doit pas être lancé sur des données sensibles sans revue.",
            "Toute action destructive, externe ou coûteuse doit être confirmée par l'utilisateur.",
        ],
    }

    (tool_dir / "tool.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (tool_dir / "README.md").write_text(
        f"""# Outil : {name.strip()}

Statut : draft

## Objectif

{purpose.strip()}

## Usage prévu

Cet outil a été créé par un agent local comme brouillon.
Il doit être relu et approuvé avant usage réel.

## Sécurité

- Ne pas utiliser sur des secrets sans revue.
- Ne pas effectuer d'action destructive sans confirmation.
- Documenter toute dépendance ajoutée.
""",
        encoding="utf-8",
    )

    if language == "python":
        run_path = tool_dir / "run.py"
        run_path.write_text(_python_template(slug, purpose.strip()), encoding="utf-8")
        run_path.chmod(0o755)

    _upsert_tool(manifest)
    print(f"🛠️ Outil brouillon créé : tools/custom/{slug}")
    print("Statut : draft. Validation utilisateur requise avant usage sensible.")
    return slug


def create_tool_as_agent(
    name: str,
    purpose: str,
    agent_name: str = "assistant",
    language: str = "python",
    code: Optional[str] = None,
) -> str:
    """Crée un outil local et l'approuve immédiatement (mode agent)."""
    slug = create_tool(name, purpose, agent_name=agent_name, language=language)
    manifest_path = TOOLS_ROOT / slug / "tool.json"
    if not manifest_path.exists():
        return slug

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["status"] = "approved"
    manifest["approved_at"] = datetime.now().isoformat()
    manifest["requires_user_approval"] = False
    manifest["auto_approved_by_agent"] = normalize_agent_name(agent_name)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    if code and language == "python":
        run_path = TOOLS_ROOT / slug / "run.py"
        run_path.write_text(code, encoding="utf-8")
        run_path.chmod(0o755)

    _upsert_tool(manifest)
    print(f"✅ Outil créé et approuvé en mode agent : tools/custom/{slug}")
    return slug


def approve_tool(name: str):
    """Marque un outil comme approuvé localement."""
    slug = normalize_agent_name(name)
    manifest_path = TOOLS_ROOT / slug / "tool.json"
    if not manifest_path.exists():
        print(f"❌ Outil '{slug}' introuvable.")
        return

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["status"] = "approved"
    manifest["approved_at"] = datetime.now().isoformat()
    manifest["requires_user_approval"] = False
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    _upsert_tool(manifest)
    print(f"✅ Outil '{slug}' approuvé.")


def list_tools(status: Optional[str] = None):
    """Liste les outils locaux custom."""
    registry = _load_registry()
    tools = registry.get("tools", [])
    if status:
        tools = [tool for tool in tools if tool.get("status") == status]

    if not tools:
        print("Aucun outil custom trouvé.")
        return

    print("🧰 Outils custom :")
    for tool in tools:
        print(f"  - {tool['name']} [{tool.get('status', 'unknown')}] — {tool.get('purpose', '')}")


def custom_tools_text_for_prompt() -> str:
    """Génère un bloc texte décrivant les outils custom approuvés pour le prompt système."""
    registry = _load_registry()
    tools = [t for t in registry.get("tools", []) if t.get("status") == "approved"]
    if not tools:
        return ""

    lines = ["## Outils custom disponibles"]
    for tool in tools:
        name = str(tool.get("name", "?"))
        purpose = str(tool.get("purpose", "Pas de description."))
        entrypoint = str(tool.get("entrypoint", "run.py"))
        lines.append(f"- {name}: {purpose}")
        lines.append(f"  Entrypoint: tools/custom/{name}/{entrypoint}")
        # Essayer de lire tool.json pour les paramètres
        tool_json_path = TOOLS_ROOT / name / "tool.json"
        if tool_json_path.exists():
            try:
                manifest = json.loads(tool_json_path.read_text(encoding="utf-8"))
                params = manifest.get("parameters")
                if isinstance(params, dict) and params.get("properties"):
                    lines.append(f"  Paramètres: {json.dumps(params.get('properties'), ensure_ascii=False)}")
            except Exception:
                pass
        lines.append(f"  Invocation: <TOOL_CUSTOM:{name}>{{\"param\": \"valeur\"}}</TOOL_CUSTOM>")

    lines.append("")
    lines.append("Pour appeler un outil custom, réponds exactement avec :")
    lines.append("<TOOL_CUSTOM:nom>{\"param\": \"valeur\"}</TOOL_CUSTOM>")
    return "\n".join(lines)


def execute_custom_tool(name: str, arguments: Optional[Dict[str, Any]] = None) -> str:
    """Exécute un outil custom approuvé et retourne le résultat."""
    registry = _load_registry()
    tool = next((t for t in registry.get("tools", []) if t.get("name") == name), None)
    if not tool:
        raise RuntimeError(f"Outil custom '{name}' introuvable dans le registre.")
    if tool.get("status") != "approved":
        raise RuntimeError(f"Outil custom '{name}' n'est pas approuvé (status={tool.get('status')}).")

    entrypoint = str(tool.get("entrypoint", "run.py"))
    tool_dir = TOOLS_ROOT / name
    script_path = tool_dir / entrypoint
    if not script_path.exists():
        raise RuntimeError(f"Entrypoint introuvable : {script_path}")

    import subprocess
    args = arguments or {}
    env = dict(os.environ)
    env["SOI_TOOL_ARGS"] = json.dumps(args, ensure_ascii=False)
    env["SOI_TOOL_NAME"] = name

    result = subprocess.run(
        [str(script_path)],
        cwd=str(tool_dir),
        capture_output=True,
        text=True,
        timeout=60,
        env=env,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        stderr = result.stderr.strip()
        raise RuntimeError(f"Outil {name} a échoué (code {result.returncode}): {stderr or output}")
    return output
