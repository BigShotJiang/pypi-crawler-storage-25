"""Mode sandbox pour agents IA locaux sans API."""

from typing import Optional

from soi.workspace import ROOT, get_agent_path, normalize_agent_name


def sandbox_brief(agent_name: str = "assistant", output_file: Optional[str] = None) -> str:
    """Construit un brief pour ouvrir SOI avec Codex, Claude Code ou un agent local."""
    slug = normalize_agent_name(agent_name)
    agent_dir = get_agent_path(slug)
    if not agent_dir.exists():
        message = f"❌ Agent '{slug}' introuvable."
        print(message)
        return message

    brief = f"""# Brief sandbox — San-o1 Intelligence

Tu es un agent IA local qui travaille dans le workspace San-o1 Intelligence.

## Agent cible
- Agent : `{slug}`
- Dossier agent : `agents/{slug}/`
- Workspace racine : `{ROOT}`

## Principe essentiel
Tu n'as pas besoin d'API IA pour utiliser ce workspace.
Tu dois lire et modifier directement les fichiers locaux Markdown/JSON comme une sandbox de travail.

## Boucle de travail avancée
1. Observe le contexte local utile : fichiers agent, mémoire, tâches, logs, inbox et docs.
2. Clarifie l'intention réelle et les contraintes visibles.
3. Découpe les demandes complexes en sous-actions courtes et vérifiables.
4. Si plusieurs chemins existent, compare impact, effort, risque et réversibilité.
5. Agis uniquement si l'action est locale, simple, réversible et alignée avec la demande.
6. Vérifie le résultat avec une commande locale quand c'est possible.
7. Termine par une synthèse courte : faits, modifications, vérification, prochaine action.

## Démarrage obligatoire
1. Lis `AGENTS.md`.
2. Lis `README.md`.
3. Lis `docs/multi_agent.md`.
4. Lis `docs/advanced_memory.md`.
5. Lis `memory/advanced/index.md`.
6. Lis `memory/advanced/adaptation/adaptive_brief.md`.
7. Lis `teams/core/team.md`.
8. Lis `agents/{slug}/agent.md`.
9. Lis `agents/{slug}/system_prompt.md`.
10. Lis `agents/{slug}/memory.md`.
11. Lis `agents/{slug}/tasks.md`.
12. Lis `agents/{slug}/rules.md`.
13. Lance `python3 scripts/run_agent.py proactive-check {slug}` pour choisir la prochaine action.

## Commandes utiles
```bash
python3 scripts/run_agent.py show-agent {slug}
python3 scripts/run_agent.py proactive-check {slug} --output workspace/sandbox/output/PROACTIVE_REPORT.md
python3 scripts/run_agent.py build-prompt {slug} --output workspace/sandbox/output/prompt_{slug}.txt
python3 scripts/run_agent.py memory-capture "l'utilisateur préfère ..." --kind preference --links user/preferences,adaptation/adaptive_brief
python3 scripts/run_agent.py memory-user-model --output workspace/sandbox/output/USER_MODEL.md
python3 scripts/run_agent.py memory-brief {slug} --output workspace/sandbox/output/ADAPTIVE_BRIEF.md
python3 scripts/run_agent.py team-brief core --output workspace/multi_agent/sessions/core_brief.md
python3 scripts/run_agent.py handoff {slug} autre-agent "Tâche à transmettre" --team core
python3 scripts/run_agent.py add-memory {slug} "Mémoire à conserver"
python3 scripts/run_agent.py add-task {slug} "Nouvelle tâche" --status TODO
python3 scripts/run_agent.py create-tool nom-outil --purpose "Objectif de l'outil"
python3 scripts/run_agent.py list-tools
python3 scripts/run_agent.py log {slug} --action "Action" --decision "Décision" --summary "Résumé"
```

## Zones de travail
- Entrées utilisateur : `workspace/sandbox/inbox/`
- Brouillons temporaires : `workspace/sandbox/tmp/`
- Sorties générées : `workspace/sandbox/output/`
- Notes : `workspace/notes/`
- Projets actifs : `workspace/active_projects/`

## Règles sandbox
- Reste local-first : pas d'appel API obligatoire.
- Ne lis pas `.env` et ne révèle jamais de secret.
- Ne supprime rien sans confirmation explicite.
- Demande confirmation avant action sensible, destructive, coûteuse ou liée à des accès externes.
- Mets à jour `agents/{slug}/memory.md` quand un fait durable apparaît.
- Mets à jour `agents/{slug}/tasks.md` quand le statut du travail change.
- Ajoute une entrée dans `agents/{slug}/logs.md` à la fin d'une intervention importante.
- Tu peux créer des outils locaux dans `tools/custom/`, mais ils commencent toujours en `draft`.
- Demande validation avant d'utiliser un outil brouillon pour une action sensible.
- Utilise `teams/` et `workspace/multi_agent/handovers/` pour coordonner plusieurs agents.
- Utilise `memory/advanced/` pour analyser l'utilisateur et adapter le style.
- Relie les mémoires importantes avec des wikilinks `[[...]]`.

## Résultat attendu
Travaille comme dans un dépôt local classique, puis termine avec :
- ce que tu as lu,
- ce que tu as modifié,
- les commandes lancées,
- les fichiers à relire,
- la prochaine action recommandée,
- les risques ou confirmations restantes.
"""

    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(brief, encoding="utf-8")
        print(f"💾 Brief sandbox sauvegardé dans : {output_file}")

    print(brief)
    return brief
