"""Client OpenRouter et configuration LLM de San-o1 Intelligence."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Mapping, Optional

import httpx

from soi.workspace import ROOT

OPENROUTER_CHAT_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODELS_URL = "https://openrouter.ai/models"
OPENROUTER_KEYS_URL = "https://openrouter.ai/settings/keys"

DEFAULT_LLM_CONFIG: Dict[str, object] = {
    "default_mode": "free",
    "model_policy": "auto_prudent",
    "free_model": "openrouter/free",
    "paid_model": "openrouter/auto",
    "team_model": "x-ai/grok-4.20-multi-agent",
    "team_reasoning_effort": "medium",
    "confirm_paid_first_call": True,
    "history_limit": 20,
    "temperature": 0.7,
    "max_tokens": 1200,
    "team_max_tokens": 2400,
    "stream": True,
}


class OpenRouterError(RuntimeError):
    """Erreur OpenRouter lisible sans fuite de secret."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class ChatResponse:
    """Réponse non-streamée ou synthèse finale d'une réponse streamée."""

    content: str
    model: str
    usage: Dict[str, object]


@dataclass(frozen=True)
class StreamEvent:
    """Événement de streaming OpenRouter."""

    content: str = ""
    model: str = ""
    usage: Optional[Dict[str, object]] = None
    done: bool = False


def _config_path(root: Path = ROOT) -> Path:
    return root / "config" / "llm.config.json"


def load_llm_config(root: Path = ROOT, create: bool = True) -> Dict[str, object]:
    """Charge la config LLM, en ajoutant les valeurs manquantes."""
    path = _config_path(root)
    if not path.exists():
        if not create:
            return dict(DEFAULT_LLM_CONFIG)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(DEFAULT_LLM_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
        return dict(DEFAULT_LLM_CONFIG)

    loaded = json.loads(path.read_text(encoding="utf-8"))
    changed = False
    for key, value in DEFAULT_LLM_CONFIG.items():
        if key not in loaded:
            loaded[key] = value
            changed = True
    if changed and create:
        path.write_text(json.dumps(loaded, indent=2, ensure_ascii=False), encoding="utf-8")
    return loaded


def _strip_env_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1].strip()
    return value


def _dotenv_value(key: str, root: Path = ROOT) -> Optional[str]:
    """Lit uniquement une clé précise depuis `.env`, sans exposer les autres secrets."""
    path = root / ".env"
    if not path.exists() or not path.is_file():
        return None

    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            stripped = stripped.removeprefix("export ").strip()
        name, separator, value = stripped.partition("=")
        if separator and name.strip() == key:
            return _strip_env_quotes(value)
    return None


def get_openrouter_api_key(
    env: Optional[Mapping[str, str]] = None,
    root: Path = ROOT,
) -> Optional[str]:
    """Retourne la clé depuis l'environnement, puis `.env` si nécessaire."""
    source = env if env is not None else os.environ
    value = source.get("OPENROUTER_API_KEY", "").strip()
    if value:
        return value
    return _dotenv_value("OPENROUTER_API_KEY", root=root)


def model_for_mode(config: Mapping[str, object], mode: str) -> str:
    """Résout le modèle OpenRouter pour `free` ou `paid`."""
    normalized = mode.strip().lower()
    if normalized == "free":
        return str(config.get("free_model") or DEFAULT_LLM_CONFIG["free_model"])
    if normalized == "paid":
        return str(config.get("paid_model") or DEFAULT_LLM_CONFIG["paid_model"])
    raise ValueError("Mode invalide. Utilise 'free' ou 'paid'.")


def team_model(config: Mapping[str, object]) -> str:
    """Retourne le modèle OpenRouter dédié aux runs multi-agent."""
    return str(config.get("team_model") or DEFAULT_LLM_CONFIG["team_model"])


def config_default_mode(config: Mapping[str, object]) -> str:
    """Retourne le mode par défaut, corrigé si nécessaire."""
    mode = str(config.get("default_mode") or DEFAULT_LLM_CONFIG["default_mode"]).strip().lower()
    return mode if mode in {"free", "paid"} else "free"


def _parse_error_payload(data: object) -> str:
    if isinstance(data, dict):
        error = data.get("error", data)
        if isinstance(error, dict):
            message = error.get("message") or error.get("code") or error
            return str(message)
        return str(error)
    return str(data)


def parse_openrouter_error(response: httpx.Response) -> OpenRouterError:
    """Transforme une réponse d'erreur HTTP en message actionnable."""
    try:
        detail = _parse_error_payload(response.json())
    except Exception:
        detail = response.text.strip() or response.reason_phrase
    message = f"OpenRouter HTTP {response.status_code}: {detail}"
    return OpenRouterError(message, status_code=response.status_code)


class OpenRouterClient:
    """Petit client OpenRouter compatible avec le format chat completions."""

    def __init__(
        self,
        config: Optional[Mapping[str, object]] = None,
        api_key: Optional[str] = None,
        timeout: float = 90.0,
        transport: Optional[httpx.BaseTransport] = None,
    ):
        self.config = dict(config or load_llm_config())
        self.api_key = api_key if api_key is not None else get_openrouter_api_key()
        self.timeout = timeout
        self.transport = transport

    @property
    def has_api_key(self) -> bool:
        return bool(self.api_key)

    def _headers(self) -> Dict[str, str]:
        if not self.api_key:
            raise OpenRouterError(
                "OPENROUTER_API_KEY est absent. Le TUI reste en mode local sans appel API."
            )
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://local.san-o1-intelligence",
            "X-Title": "San-o1 Intelligence",
        }

    def _payload(
        self,
        messages: List[Dict[str, str]],
        mode: str,
        stream: bool,
        session_id: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        reasoning_effort: Optional[str] = None,
    ) -> Dict[str, object]:
        payload: Dict[str, object] = {
            "model": model or model_for_mode(self.config, mode),
            "messages": messages,
            "temperature": float(self.config.get("temperature", 0.7)),
            "max_tokens": int(max_tokens or self.config.get("max_tokens", 1200)),
            "stream": stream,
        }
        if reasoning_effort:
            payload["reasoning"] = {"effort": reasoning_effort}
        if stream:
            payload["stream_options"] = {"include_usage": True}
        if session_id:
            payload["session_id"] = session_id[:256]
        return payload

    def chat(
        self,
        messages: List[Dict[str, str]],
        mode: str = "free",
        session_id: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        reasoning_effort: Optional[str] = None,
    ) -> ChatResponse:
        """Appelle OpenRouter en mode non-streamé."""
        payload = self._payload(
            messages,
            mode=mode,
            stream=False,
            session_id=session_id,
            model=model,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
        )
        with httpx.Client(timeout=self.timeout, transport=self.transport) as client:
            response = client.post(OPENROUTER_CHAT_URL, headers=self._headers(), json=payload)
        if response.status_code >= 400:
            raise parse_openrouter_error(response)

        data = response.json()
        choices = data.get("choices") or []
        message = choices[0].get("message", {}) if choices else {}
        return ChatResponse(
            content=str(message.get("content") or ""),
            model=str(data.get("model") or payload["model"]),
            usage=dict(data.get("usage") or {}),
        )

    def stream_chat(
        self,
        messages: List[Dict[str, str]],
        mode: str = "free",
        session_id: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        reasoning_effort: Optional[str] = None,
    ) -> Iterator[StreamEvent]:
        """Stream une réponse OpenRouter en événements texte."""
        payload = self._payload(
            messages,
            mode=mode,
            stream=True,
            session_id=session_id,
            model=model,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
        )
        selected_model = str(payload["model"])
        usage: Dict[str, object] = {}

        with httpx.Client(timeout=self.timeout, transport=self.transport) as client:
            with client.stream("POST", OPENROUTER_CHAT_URL, headers=self._headers(), json=payload) as response:
                if response.status_code >= 400:
                    raise parse_openrouter_error(response)

                for line in response.iter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    data_line = line.removeprefix("data: ").strip()
                    if data_line == "[DONE]":
                        yield StreamEvent(model=selected_model, usage=usage, done=True)
                        return

                    try:
                        event = json.loads(data_line)
                    except json.JSONDecodeError:
                        continue
                    selected_model = str(event.get("model") or selected_model)
                    if event.get("usage"):
                        usage = dict(event["usage"])
                    for choice in event.get("choices") or []:
                        delta = choice.get("delta") or {}
                        content = delta.get("content")
                        if content:
                            yield StreamEvent(content=str(content), model=selected_model, usage=usage)

        yield StreamEvent(model=selected_model, usage=usage, done=True)


def models_status_lines(
    root: Path = ROOT,
    env: Optional[Mapping[str, str]] = None,
) -> List[str]:
    """Produit un statut modèle sans révéler la clé API."""
    config = load_llm_config(root=root)
    key_status = "détectée" if get_openrouter_api_key(env, root=root) else "absente"
    default_mode = config_default_mode(config)
    free_model = model_for_mode(config, "free")
    paid_model = model_for_mode(config, "paid")
    configured_team_model = team_model(config)
    return [
        "San-o1 Intelligence — OpenRouter",
        f"Clé OPENROUTER_API_KEY : {key_status}",
        f"Mode par défaut : {default_mode}",
        f"Politique modèle : {config.get('model_policy', 'auto_prudent')}",
        f"Mode gratuit : {free_model}",
        f"Mode payant : {paid_model}",
        f"Modèle équipe : {configured_team_model}",
        f"Raisonnement équipe : {config.get('team_reasoning_effort', 'medium')}",
        f"Confirmation premier appel payant : {bool(config.get('confirm_paid_first_call', True))}",
        f"Historique conversation : {int(config.get('history_limit', 20))} messages",
        f"Modèles OpenRouter : {OPENROUTER_MODELS_URL}",
        f"Créer une clé : {OPENROUTER_KEYS_URL}",
    ]


def print_models_status(root: Path = ROOT) -> None:
    """Affiche le statut OpenRouter pour la CLI."""
    for line in models_status_lines(root=root):
        print(line)


def collect_stream_text(events: Iterable[StreamEvent]) -> ChatResponse:
    """Utilitaire de tests et fallback : agrège un stream en réponse."""
    chunks: List[str] = []
    model = ""
    usage: Dict[str, object] = {}
    for event in events:
        if event.content:
            chunks.append(event.content)
        if event.model:
            model = event.model
        if event.usage:
            usage = dict(event.usage)
    return ChatResponse(content="".join(chunks), model=model, usage=usage)
