"""Gestion des tâches des agents."""

from typing import List, Optional

from soi.workspace import get_agent_path, normalize_agent_name

VALID_STATUSES = ["PRIORITY", "TODO", "DOING", "DONE", "BLOCKED"]


def _ensure_sections(text: str) -> str:
    lines = text.splitlines()
    existing = {line.strip() for line in lines if line.strip().startswith("## ")}
    for status in VALID_STATUSES:
        header = f"## {status}"
        if header not in existing:
            if lines and lines[-1].strip() != "":
                lines.append("")
            lines.extend([header, ""])
    return "\n".join(lines).rstrip() + "\n"


def _insert_under_status(text: str, status: str, task_line: str) -> str:
    text = _ensure_sections(text)
    lines = text.splitlines()
    header = f"## {status}"
    header_index = next(i for i, line in enumerate(lines) if line.strip() == header)

    insert_at = header_index + 1
    while insert_at < len(lines) and lines[insert_at].strip() == "":
        insert_at += 1

    lines.insert(insert_at, task_line)
    next_index = insert_at + 1
    if next_index < len(lines) and lines[next_index].strip() and not lines[next_index].strip().startswith("- ["):
        lines.insert(next_index, "")
    elif next_index == len(lines):
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _find_task(lines: List[str], title: str) -> Optional[int]:
    title_lower = title.lower()
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("- [") and title_lower in stripped.lower():
            return index
    return None


def _task_exists(text: str, title: str) -> bool:
    return _find_task(text.splitlines(), title) is not None


def add_task(agent_name: str, title: str, status: str = "TODO"):
    """Ajoute une tâche à un agent."""
    slug = normalize_agent_name(agent_name)
    if status not in VALID_STATUSES:
        print(f"❌ Statut invalide. Choisissez parmi : {', '.join(VALID_STATUSES)}")
        return
    if not title.strip():
        print("❌ Le titre de la tâche ne peut pas être vide.")
        return

    tasks_path = get_agent_path(slug) / "tasks.md"
    if not tasks_path.exists():
        print(f"❌ Fichier de tâches introuvable pour l'agent '{slug}'.")
        return

    text = tasks_path.read_text(encoding="utf-8")
    if _task_exists(text, title):
        print(f"⚠️ Tâche déjà présente pour '{slug}' : {title}")
        return

    checkbox = "[x]" if status == "DONE" else "[ ]"
    updated = _insert_under_status(text, status, f"- {checkbox} {title.strip()}")
    tasks_path.write_text(updated, encoding="utf-8")
    print(f"✅ Tâche ajoutée à '{slug}' ({status}) : {title}")


def complete_task(agent_name: str, title: str):
    """Marque une tâche comme terminée en la déplaçant vers DONE."""
    update_task_status(agent_name, title, "DONE")


def update_task_status(agent_name: str, title: str, new_status: str):
    """Change le statut d'une tâche en la déplaçant de section."""
    slug = normalize_agent_name(agent_name)
    if new_status not in VALID_STATUSES:
        print(f"❌ Statut invalide. Choisissez parmi : {', '.join(VALID_STATUSES)}")
        return

    tasks_path = get_agent_path(slug) / "tasks.md"
    if not tasks_path.exists():
        print(f"❌ Fichier de tâches introuvable pour l'agent '{slug}'.")
        return

    text = _ensure_sections(tasks_path.read_text(encoding="utf-8"))
    lines = text.splitlines()
    task_index = _find_task(lines, title)
    if task_index is None:
        print(f"⚠️ Tâche '{title}' non trouvée pour '{slug}'.")
        return

    removed_line = lines.pop(task_index)
    task_text = removed_line.split("]", 1)[-1].strip()
    while task_index < len(lines) and lines[task_index].strip() == "":
        lines.pop(task_index)

    checkbox = "[x]" if new_status == "DONE" else "[ ]"
    without_task = "\n".join(lines).rstrip() + "\n"
    updated = _insert_under_status(without_task, new_status, f"- {checkbox} {task_text}")
    tasks_path.write_text(updated, encoding="utf-8")
    print(f"🔄 Tâche '{task_text}' déplacée vers {new_status}.")
