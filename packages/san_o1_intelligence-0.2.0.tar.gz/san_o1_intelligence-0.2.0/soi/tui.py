"""TUI Textual pour le chat persistant San-o1 Intelligence."""

from __future__ import annotations

import asyncio
import contextlib
import io
import json
import re
import subprocess
import sys
from typing import Optional, Tuple

from rich.markdown import Markdown
from rich.panel import Panel
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, RichLog, Static

from soi.agent_runtime import AgentExecutionRuntime, AgentRuntimeResult
from soi.conversation import (
    ConversationStore,
    build_chat_messages,
    list_inbox_files,
    read_text_if_exists,
    summarize_tasks,
)
from soi.openrouter_client import (
    ChatResponse,
    OpenRouterClient,
    OpenRouterError,
    config_default_mode,
    get_openrouter_api_key,
    load_llm_config,
    model_for_mode,
)
from soi.mcp_client import MCPClientManager, MCPError, parse_mcp_tool_call
from soi.proactive import proactive_check
from soi.workspace import ROOT, normalize_agent_name


LOGO = r"""
   _____                  ___  __
  / ___/____ _____       / _ \/ /
  \__ \/ __ `/ __ \_____/ // / / 
 ___/ / /_/ / / / /____/ // / /__
/____/\__,_/_/ /_/     \___/____/
"""

HELP_TEXT = """# Commandes TUI

- `/help` : afficher cette aide
- `/mode` : afficher le mode actif
- `/mode free` : passer au routeur gratuit `openrouter/free`
- `/mode paid` : passer au routeur payant `openrouter/auto`
- `/confirm` : confirmer le premier appel payant en attente
- `/model-policy` : afficher la politique modèle auto_prudent
- `/tasks` : afficher les tâches de l'agent
- `/memory` : afficher mémoire agent + brief adaptatif
- `/inbox` : lister les fichiers inbox
- `/proactive` : lancer le check proactif local
- `/search <query>` : recherche web via DuckDuckGo + synthèse OpenRouter
- `/mcp` ou `/mcp-list` : afficher les serveurs MCP et leurs outils
- `/mcp-reload` : recharger la connexion aux serveurs MCP
- `/agent-mode` : afficher le mode agent
- `/agent-mode on` : activer le mode agent (exécution MCP)
- `/agent-mode off` : désactiver le mode agent (conversationnel uniquement)
- `/save` : exporter la session courante en Markdown
- `/clear` : nettoyer l'affichage du chat
- `/quit` : quitter le TUI
"""


class SOIChatApp(App):
    """Application TUI Textual."""

    TITLE = "San-o1 Intelligence"
    SUB_TITLE = "l'assistant TUI OpenRouter"
    BINDINGS = [
        ("ctrl+c", "quit", "Quitter"),
        ("ctrl+s", "save", "Sauver"),
        ("ctrl+l", "clear_chat", "Nettoyer"),
    ]
    CSS = """
    Screen {
        background: #080b10;
        color: #d8e2ef;
    }

    #layout {
        height: 1fr;
    }

    #left {
        width: 1fr;
        min-width: 56;
    }

    #logo {
        height: 8;
        color: #7dd3fc;
        content-align: center middle;
        border: tall #1f2937;
    }

    #chat {
        height: 1fr;
        border: tall #334155;
        padding: 0 1;
        background: #0b1220;
    }

    #live {
        min-height: 3;
        max-height: 8;
        border: tall #1f2937;
        padding: 0 1;
        background: #101827;
    }

    #prompt {
        height: 3;
        border: tall #38bdf8;
        background: #020617;
    }

    #side {
        width: 38;
        border: tall #475569;
        padding: 1;
        background: #111827;
    }
    """

    def __init__(self, agent_name: str = "assistant", mode: Optional[str] = None):
        super().__init__()
        self.agent_name = normalize_agent_name(agent_name)
        self.config = load_llm_config()
        self.mode = (mode or config_default_mode(self.config)).lower()
        if self.mode not in {"free", "paid"}:
            self.mode = "free"
        self.runtime = AgentExecutionRuntime(agent_name=self.agent_name, mode=self.mode, config=self.config)
        self.store = self.runtime.store
        self.client = self.runtime.client
        self.mcp_manager = self.runtime.mcp_manager
        self.paid_confirmed = False
        self.pending_paid_message: Optional[str] = None
        self.pending_mcp_call: Optional[Tuple[str, str, dict]] = None
        self.agent_mode_enabled = True
        self.busy = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="layout"):
            with Vertical(id="left"):
                yield Static(LOGO, id="logo")
                yield RichLog(id="chat", markup=True, wrap=True, highlight=True)
                yield Static("", id="live")
                yield Input(placeholder="Message pour l'assistant, ou /help", id="prompt")
            yield Static(id="side")
        yield Footer()

    def on_mount(self) -> None:
        self._chat().write("[bold cyan]San-o1 Intelligence[/] prêt.")
        self._chat().write("Tape `/help` pour les commandes. Les conversations sont stockées en JSONL local.")
        if not self.client.has_api_key:
            self._chat().write("[yellow]OPENROUTER_API_KEY absent : mode local lecture seule, sans appel API.[/]")
        self._connect_mcp()
        self._refresh_sidebar()
        self.query_one("#prompt", Input).focus()

    def action_save(self) -> None:
        self._save_session()

    def action_clear_chat(self) -> None:
        self._clear_chat()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        value = event.value.strip()
        event.input.value = ""
        if not value:
            return
        if value.startswith("/"):
            self._handle_command(value)
            return
        self._handle_user_message(value)

    def _chat(self) -> RichLog:
        return self.query_one("#chat", RichLog)

    def _live(self) -> Static:
        return self.query_one("#live", Static)

    def _write_markdown(self, text: str) -> None:
        self._chat().write(Markdown(text))

    def _write_panel(self, title: str, body: str) -> None:
        self._chat().write(Panel(body.strip() or "Rien à afficher.", title=title, border_style="cyan"))

    def _refresh_sidebar(self) -> None:
        tasks = summarize_tasks(self.agent_name)
        inbox_count = len(list_inbox_files())
        key_status = "detectee" if get_openrouter_api_key() else "absente"
        current_model = model_for_mode(self.config, self.mode)
        mcp_lines = self.mcp_manager.status_lines()
        mcp_block = "\n".join(mcp_lines)
        agent_mode_status = "ON" if self.agent_mode_enabled else "OFF"
        policy = self.runtime.model_policy
        decision = self.runtime.last_model_decision
        decision_reason = decision.reason if decision else "aucune"
        pending = self.runtime.pending_action.kind if self.runtime.pending_action else "aucune"
        body = f"""[bold cyan]l'assistant[/]

Agent      : {self.agent_name}
Mode       : {self.mode}
Modele     : {current_model}
Politique  : {policy}
Decision   : {decision_reason}
Cle API    : {key_status}
Session    : {self.store.session_id}
Agent Mode : {agent_mode_status}
Attente    : {pending}

[bold]Taches[/]
PRIORITY   : {tasks["PRIORITY"]}
DOING      : {tasks["DOING"]}
TODO       : {tasks["TODO"]}
BLOCKED    : {tasks["BLOCKED"]}
DONE       : {tasks["DONE"]}

Inbox      : {inbox_count}

[bold]MCP[/]
{mcp_block}

[bold]Raccourcis[/]
Ctrl+S     : save
Ctrl+L     : clear
Ctrl+C     : quit
"""
        self.query_one("#side", Static).update(body)

    def _handle_command(self, command: str) -> None:
        parts = command.split(maxsplit=1)
        name = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if name == "/help":
            self._write_markdown(HELP_TEXT)
        elif name == "/mode":
            self._set_mode(arg)
        elif name == "/confirm":
            self._confirm_paid_call()
        elif name == "/model-policy":
            self._show_model_policy()
        elif name == "/tasks":
            self._show_tasks()
        elif name == "/memory":
            self._show_memory()
        elif name == "/inbox":
            self._show_inbox()
        elif name == "/proactive":
            self._show_proactive()
        elif name == "/search":
            self._run_web_search(arg)
        elif name in ("/mcp", "/mcp-list"):
            self._show_mcp()
        elif name == "/mcp-reload":
            self._reload_mcp()
        elif name == "/save":
            self._save_session()
        elif name == "/clear":
            self._clear_chat()
        elif name == "/agent-mode":
            self._toggle_agent_mode(arg)
        elif name == "/quit":
            self.exit()
        else:
            self._chat().write(f"[red]Commande inconnue : {command}[/]")

    def _toggle_agent_mode(self, arg: str) -> None:
        if arg.lower() in ("on", "true", "1"):
            self.agent_mode_enabled = True
            self.runtime.autonomy_mode = "safe_agent"
            self._chat().write("[green]Mode Agent activé. l'assistant va exécuter les actions via MCP.[/]")
        elif arg.lower() in ("off", "false", "0"):
            self.agent_mode_enabled = False
            self.runtime.autonomy_mode = "conversation"
            self._chat().write("[yellow]Mode Agent désactivé. l'assistant reste conversationnel.[/]")
        else:
            status = "activé" if self.agent_mode_enabled else "désactivé"
            self._chat().write(f"Mode Agent : [bold]{status}[/]. Utilise `/agent-mode on` ou `/agent-mode off`.")
        self._refresh_sidebar()

    def _set_mode(self, arg: str) -> None:
        if not arg:
            self._chat().write(f"Mode actif : [bold]{self.mode}[/] -> {model_for_mode(self.config, self.mode)}")
            return
        if arg not in {"free", "paid"}:
            self._chat().write("[red]Mode invalide. Utilise `/mode free` ou `/mode paid`.[/]")
            return
        self.mode = arg
        self.runtime.mode = arg
        if self.mode == "free":
            self.pending_paid_message = None
        self._chat().write(f"Mode actif : [bold]{self.mode}[/] -> {model_for_mode(self.config, self.mode)}")
        self._refresh_sidebar()

    def _confirm_paid_call(self) -> None:
        if self.runtime.pending_action:
            pending_kind = self.runtime.pending_action.kind
            if pending_kind == "paid":
                self.paid_confirmed = True
            self._chat().write(f"[green]Confirmation reçue : {pending_kind}[/]")
            self.busy = True
            self._live().update("[cyan]l'assistant agit...[/]")
            asyncio.create_task(self._confirm_runtime_action())
            return
        if self.pending_mcp_call:
            server_name, tool_name, arguments = self.pending_mcp_call
            self.pending_mcp_call = None
            self._chat().write(f"[green]Exécution MCP confirmée : {server_name}/{tool_name}[/]")
            asyncio.create_task(self._run_mcp_and_continue(server_name, tool_name, arguments, confirmed=True))
            return
        if not self.pending_paid_message:
            self._chat().write("Aucune action en attente.")
            return
        message = self.pending_paid_message
        self.pending_paid_message = None
        self.paid_confirmed = True
        self._send_user_message(message, echo=False)

    def _show_model_policy(self) -> None:
        self._write_panel("Politique modele", self.runtime.policy_status())

    def _show_tasks(self) -> None:
        path = ROOT / "agents" / self.agent_name / "tasks.md"
        self._write_panel("Taches", read_text_if_exists(path))

    def _show_memory(self) -> None:
        memory = read_text_if_exists(ROOT / "agents" / self.agent_name / "memory.md")
        brief = read_text_if_exists(ROOT / "memory" / "advanced" / "adaptation" / "adaptive_brief.md")
        self._write_panel("Memoire", f"{memory}\n\n---\n\n{brief}")

    def _show_inbox(self) -> None:
        files = list_inbox_files()
        body = "\n".join(f"- {file}" for file in files) if files else "Inbox vide."
        self._write_panel("Inbox", body)

    def _show_proactive(self) -> None:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            proactive_check(self.agent_name)
        self._write_panel("Proactive", buffer.getvalue())

    def _connect_mcp(self) -> None:
        try:
            connected, failed = self.mcp_manager.load_and_connect()
            if connected or failed:
                self._chat().write(f"[dim]MCP : {connected} serveur(s) connecté(s), {failed} échec(s).[/]")
        except Exception as exc:
            self._chat().write(f"[yellow]MCP : erreur de connexion — {exc}[/]")

    def _show_mcp(self) -> None:
        lines = self.mcp_manager.status_lines()
        self._write_panel("MCP", "\n".join(lines))

    def _reload_mcp(self) -> None:
        self._chat().write("[dim]Reconnexion MCP...[/]")
        self._connect_mcp()
        self._refresh_sidebar()

    def _save_session(self) -> None:
        path = self.store.export_markdown()
        self._chat().write(f"Session exportee : [green]{path.relative_to(ROOT)}[/]")

    def _clear_chat(self) -> None:
        self._chat().clear()
        self._live().update("")
        self._chat().write("Affichage nettoye. L'historique JSONL local est conserve.")

    def _handle_user_message(self, content: str) -> None:
        if self.busy:
            self._chat().write("[yellow]l'assistant repond deja. Attends la fin du stream.[/]")
            return
        self._send_user_message(content)

    def _send_user_message(self, content: str, echo: bool = True) -> None:
        if echo:
            self._chat().write(f"[bold green]l'utilisateur[/] : {content}")

        self.busy = True
        self._live().update("[cyan]l'assistant observe et decide...[/]")
        asyncio.create_task(self._ask_runtime(content))

    async def _ask_runtime(self, content: str) -> None:
        result = await asyncio.to_thread(
            self.runtime.ask,
            content,
            allow_paid=self.paid_confirmed,
            history_limit=int(self.config.get("history_limit", 20)),
        )
        self._finish_agent_result(result)

    async def _confirm_runtime_action(self) -> None:
        result = await asyncio.to_thread(
            self.runtime.confirm_pending,
            allow_paid=self.paid_confirmed,
            history_limit=int(self.config.get("history_limit", 20)),
        )
        self._finish_agent_result(result)

    def _finish_agent_result(self, result: AgentRuntimeResult) -> None:
        self.busy = False
        self._live().update("")
        label = "confirmation requise" if result.confirmation_required else result.model or result.mode
        self._chat().write(f"[bold cyan]l'assistant[/] ([dim]{label}[/]) :")
        self._write_markdown(result.content or "_Réponse vide._")
        if result.model_reason:
            self._chat().write(f"[dim]Decision modele : {result.model_reason}[/]")
        if result.tool_executed:
            self._chat().write(f"[dim]Outil exécuté : {result.tool_executed}[/]")
        if result.usage:
            self._chat().write(f"[dim]Usage : {result.usage}[/]")
        if not result.confirmation_required and result.mode == "paid":
            self.paid_confirmed = False
        self._refresh_sidebar()

    async def _ask_openrouter(self, messages: list[dict[str, str]]) -> None:
        await asyncio.to_thread(self._stream_openrouter, messages)

    def _stream_openrouter(self, messages: list[dict[str, str]]) -> None:
        chunks: list[str] = []
        model = model_for_mode(self.config, self.mode)
        usage = {}
        try:
            for event in self.client.stream_chat(messages, mode=self.mode, session_id=self.store.session_id):
                if event.content:
                    chunks.append(event.content)
                    self.call_from_thread(self._set_live_text, "".join(chunks))
                if event.model:
                    model = event.model
                if event.usage:
                    usage = event.usage
            response = ChatResponse(content="".join(chunks), model=model, usage=usage)
            self.call_from_thread(self._finish_response, response)
        except OpenRouterError as exc:
            self.call_from_thread(self._finish_error, str(exc))
        except Exception as exc:
            self.call_from_thread(self._finish_error, f"Erreur locale pendant l'appel OpenRouter : {exc}")

    def _finish_response(self, response: ChatResponse) -> None:
        self.busy = False
        self._live().update("")

        # Détection appel MCP
        mcp_call = parse_mcp_tool_call(response.content)
        if mcp_call and getattr(self, "_tool_depth", 0) < 2:
            self._tool_depth = getattr(self, "_tool_depth", 0) + 1
            server_name, tool_name, arguments = mcp_call
            self.store.append("assistant", response.content, mode=self.mode, model=response.model, usage=response.usage)
            self._chat().write(f"[bold cyan]l'assistant[/] ([dim]{response.model}[/]) :")
            if not self.agent_mode_enabled:
                self._chat().write("[yellow]Mode Agent désactivé — appel MCP affiché sans exécution.[/]")
                self._tool_depth = 0
                self._write_markdown(response.content or "_Réponse vide._")
                self._refresh_sidebar()
                return
            self._chat().write(f"[italic dim]Appel MCP : {server_name}/{tool_name}...[/]")
            asyncio.create_task(self._run_mcp_and_continue(server_name, tool_name, arguments))
            return

        tool_match = re.search(r"<TOOL:web-search:([^>]+)>", response.content)
        if tool_match and getattr(self, "_tool_depth", 0) < 2:
            self._tool_depth = getattr(self, "_tool_depth", 0) + 1
            query = tool_match.group(1).strip()
            self.store.append("assistant", response.content, mode=self.mode, model=response.model, usage=response.usage)
            self._chat().write(f"[bold cyan]l'assistant[/] ([dim]{response.model}[/]) :")
            self._chat().write(f"[italic dim]Recherche web demandée : {query}...[/]")
            asyncio.create_task(self._run_tool_and_continue("web-search", query))
            return

        self._tool_depth = 0
        self.store.append("assistant", response.content, mode=self.mode, model=response.model, usage=response.usage)
        self._chat().write(f"[bold cyan]l'assistant[/] ([dim]{response.model}[/]) :")
        self._write_markdown(response.content or "_Réponse vide._")
        if response.usage:
            self._chat().write(f"[dim]Usage : {response.usage}[/]")
        self._refresh_sidebar()

    def _finish_error(self, message: str) -> None:
        self.busy = False
        self._live().update("")
        self.store.append("assistant", message, mode=self.mode, model=model_for_mode(self.config, self.mode), usage={})
        self._chat().write(f"[red]{message}[/]")
        self._refresh_sidebar()

    def _set_live_text(self, text: str) -> None:
        self._live().update(text)

    def _run_web_search(self, query: str) -> None:
        if not query:
            self._chat().write("[red]Usage : /search <requête>[/]")
            return
        self._chat().write(f"[cyan]Recherche web : {query}...[/]")
        asyncio.create_task(self._run_tool_and_continue("web-search", query, echo=False))

    def _exec_web_search(self, query: str) -> str:
        cmd = [
            sys.executable or "python3",
            str(ROOT / "tools" / "custom" / "web-search" / "run.py"),
            query,
            "--mode",
            self.mode,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        except Exception as exc:
            return f"Erreur lors de l'exécution de la recherche : {exc}"
        if result.returncode != 0:
            return f"Erreur de recherche web (code {result.returncode}) :\n{result.stderr}"
        return result.stdout

    async def _run_tool_and_continue(self, tool_name: str, query: str, echo: bool = True) -> None:
        if tool_name == "web-search":
            result = await asyncio.to_thread(self._exec_web_search, query)
            if echo:
                self._chat().write(f"[dim]Résultats bruts récupérés ({len(result)} caractères).[/]")
            tool_message = (
                f"Résultats de recherche web pour : {query}\n\n"
                f"{result}\n\n"
                "Merci de synthétiser ces résultats pour l'utilisateur."
            )
            # Construire les messages SANS duper le tool_message dans l'historique
            messages = build_chat_messages(
                self.agent_name,
                tool_message,
                history_limit=int(self.config.get("history_limit", 20)),
                mcp_manager=self.mcp_manager,
            )
            self.store.append("user", tool_message, mode="tool", model="web-search", usage={})
            self.busy = True
            self._live().update("[cyan]l'assistant synthétise...[/]")
            try:
                await self._ask_openrouter(messages)
            except Exception as exc:
                self.busy = False
                self._live().update("")
                self._chat().write(f"[red]Erreur pendant la synthèse : {exc}[/]")
                self._refresh_sidebar()

    def _exec_mcp_tool(self, server_name: str, tool_name: str, arguments: dict) -> str:
        try:
            result = self.mcp_manager.call_tool(server_name, tool_name, arguments)
            return json.dumps(result, ensure_ascii=False, indent=2)
        except MCPError as exc:
            return f"Erreur MCP : {exc}"
        except Exception as exc:
            return f"Erreur inattendue MCP : {exc}"

    async def _run_mcp_and_continue(self, server_name: str, tool_name: str, arguments: dict, confirmed: bool = False) -> None:
        risky_tools = {"write_file", "edit_block", "move_file", "start_process", "force_terminate", "kill_process"}
        if tool_name in risky_tools and not confirmed:
            self.pending_mcp_call = (server_name, tool_name, arguments)
            self._chat().write(
                f"[yellow]⚠️ Action MCP à risque détectée : {server_name}/{tool_name}[/]\n"
                f"Arguments : {json.dumps(arguments, ensure_ascii=False, indent=2)}\n"
                "Tape `/confirm` pour exécuter, ou ignore pour annuler."
            )
            self._refresh_sidebar()
            return

        result = await asyncio.to_thread(self._exec_mcp_tool, server_name, tool_name, arguments)
        self._chat().write(f"[dim]Résultat MCP brut ({len(result)} caractères).[/]")
        tool_message = (
            f"Résultat de l'outil MCP {server_name}/{tool_name} :\n\n"
            f"{result}\n\n"
            "Merci de synthétiser ce résultat pour l'utilisateur."
        )
        messages = build_chat_messages(
            self.agent_name,
            tool_message,
            history_limit=int(self.config.get("history_limit", 20)),
            mcp_manager=self.mcp_manager,
            agent_mode_enabled=self.agent_mode_enabled,
        )
        self.store.append("user", tool_message, mode="tool", model=f"mcp-{server_name}", usage={})
        self.busy = True
        self._live().update("[cyan]l'assistant synthétise...[/]")
        try:
            await self._ask_openrouter(messages)
        except Exception as exc:
            self.busy = False
            self._live().update("")
            self._chat().write(f"[red]Erreur pendant la synthèse MCP : {exc}[/]")
            self._refresh_sidebar()

    def on_unmount(self) -> None:
        self.mcp_manager.disconnect_all()


def run_chat_tui(agent_name: str = "assistant", mode: Optional[str] = None) -> None:
    """Point d'entrée CLI."""
    app = SOIChatApp(agent_name=agent_name, mode=mode)
    app.run()
