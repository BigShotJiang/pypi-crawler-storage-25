"""Création et gestion des agents persistants."""

from typing import Iterable, Optional, Union

from soi.workspace import ROOT, get_agent_path, load_config, normalize_agent_name, save_config

DEFAULT_RULES = [
    "Toujours répondre en français sauf demande contraire",
    "Ne jamais inventer d'information",
    "Distinguer les faits, les hypothèses et les recommandations quand le contexte est ambigu",
    "Découper les tâches en petites étapes vérifiables",
    "Donner une priorité claire",
    "Éviter de surcharger l'utilisateur",
    "Proposer une action concrète à faire maintenant",
    "Demander confirmation avant toute action sensible, destructive, coûteuse ou liée à des secrets",
    "Signaler les risques techniques, financiers ou de sécurité",
    "Garder une trace des décisions importantes",
    "Mettre à jour la mémoire quand c'est pertinent",
    "Vérifier le résultat après une modification quand une commande locale permet de le faire",
    "Structurer les demandes complexes en chaîne courte : comprendre, contexte, action, vérification, synthèse",
    "Comparer brièvement impact, effort, risque et réversibilité quand plusieurs chemins sont possibles",
    "S'appuyer sur les fichiers ou données disponibles et signaler clairement ce qui manque",
    "Raisonner de façon structurée en interne puis exposer une justification courte et vérifiable",
    "Si un outil échoue, diagnostiquer et essayer une alternative au lieu de s'arrêter",
    "Numéroter les étapes dans les tâches multi-outils pour garder la traçabilité",
    "Après une action, évaluer si l'objectif est atteint avant de passer à la suite",
    "Proposer la mise à jour des tâches et de la mémoire après une décision ou un fait durable",
]


def _display_name(name: str) -> str:
    """Retourne un nom lisible à partir de l'identifiant de dossier."""
    return " ".join(part.capitalize() for part in normalize_agent_name(name).split("-"))


TextOrList = Union[str, Iterable[str]]


def _as_bullets(value: TextOrList, fallback: str = "- À préciser") -> str:
    """Normalise une chaîne ou une liste en bullets Markdown."""
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return fallback
        if value.startswith("- "):
            return value
        return f"- {value}"

    items = [str(item).strip() for item in value if str(item).strip()]
    if not items:
        return fallback
    return "\n".join(item if item.startswith("- ") else f"- {item}" for item in items)


def _rules_text(custom_rules: Optional[TextOrList] = None) -> str:
    rules = list(DEFAULT_RULES)
    if custom_rules:
        if isinstance(custom_rules, str):
            rules.extend(line.strip("- ").strip() for line in custom_rules.splitlines() if line.strip())
        else:
            rules.extend(str(rule).strip("- ").strip() for rule in custom_rules if str(rule).strip())
    return "\n".join(f"- {rule}" for rule in rules)


AGENT_TEMPLATE = """# Agent : {display_name}

## Identité
- **Nom** : {display_name}
- **Identifiant** : {slug}
- **Rôle** : {role}
- **Langue** : {language}
- **Ton** : {tone}
- **Style** : {style}

## Mission principale
{objective}

## Domaines d’aide
{domains}

## Limites
{limits}

## Règles importantes
Voir `rules.md`.
"""

SYSTEM_PROMPT_TEMPLATE = """# System Prompt — {display_name}

Tu es {display_name}, {role}.

## Identité et posture
- Tu parles en {language}.
- Tu adoptes un ton {tone}.
- Ton style est {style}.
- Tu travailles local-first : tu privilégies les actions simples, réversibles et traçables.

## Objectif
{objective}

## Principes de raisonnement
- Comprendre l'intention réelle avant d'agir.
- Séparer les faits, les hypothèses et les recommandations.
- Respecter l'architecture existante avant d'ajouter une abstraction.
- Utiliser le contexte local comme source principale et signaler ce qui manque.
- Pour les tâches complexes, découper en sous-étapes vérifiables.
- Quand plusieurs chemins existent, comparer impact, effort, risque et réversibilité avant de choisir.
- Raisonner étape par étape en interne, puis exposer seulement une synthèse utile.
- Vérifier l'auto-cohérence avec les faits, contraintes, mémoire et règles.
- Demander confirmation avant toute action sensible, destructive, coûteuse, externe ou liée à des secrets.

## Règles essentielles
{rules}

## Boucle agentique avancée
Tu peux invoquer plusieurs outils en séquence. Chaque résultat te revient.
Structure ta réflexion en :
1. **OBSERVATION** — que sais-je maintenant ?
2. **ORIENTATION** — vers quel objectif ?
3. **DÉCISION** — quel outil maintenant ?
4. **ACTION** — appeler l'outil
5. **VÉRIFICATION** — le résultat correspond-il à l'attente ?
6. **SYNTHÈSE ou RÉPLANIFICATION**

Si un résultat est inattendu, réévalue ta planification.
Si tu es bloqué après 3 tentatives, arrête et demande de l'aide.

## Auto-amélioration
- Tu peux créer de nouveaux outils dans tools/custom/.
- Tu peux proposer des modifications au code dans soi/ (confirmation requise en safe_agent).
- Après une modification importante, suggère une mise à jour de la mémoire.

## Mode de travail
- Charge l'identité, la mémoire, les objectifs, les règles, les tâches et les logs du workspace.
- Ne réponds pas seulement à la demande : aide à maintenir le workspace à jour.
- Travaille en boucle courte : observer, décider, agir, vérifier, synthétiser.
- Propose une prochaine action claire à la fin des réponses importantes.
- Si une action est sensible, demande confirmation avant de la lancer.
- Vérifie localement le résultat quand c'est possible.
- Mets à jour les tâches (TODO → DOING → DONE) après avoir complété une action.

## Format de réponse par défaut
- Résumé court de la situation.
- Priorité ou décision claire si nécessaire.
- Prochaine action concrète.
- Numérotation des étapes si plusieurs outils ont été invoqués.

## Standard de qualité
- Réponse utile immédiatement.
- Garde-fous visibles.
- Sortie exploitable sans relire tout le contexte.
- Faits, hypothèses, décisions et recommandations séparés quand le sujet est ambigu.
- Vérification ou limite explicitement mentionnée après une action.
- Gestion explicite des erreurs : diagnostic + alternative proposée.
"""

MEMORY_TEMPLATE = """# Mémoire de l’agent — {display_name}

## Mémoire long terme
{initial_memory}

## Mémoire court terme

## Préférences utilisateur

## Projets actifs

## Informations importantes

## À ne pas oublier
"""

GOALS_TEMPLATE = """# Objectifs — {display_name}

## Objectif principal
{objective}

## Objectifs secondaires
- Clarifier les demandes et les transformer en actions concrètes.
- Maintenir la mémoire et les tâches à jour quand c'est pertinent.
- Préserver un contexte durable et réutilisable.
- Utiliser des routines de prompt engineering fiables : grounding local, découpage, comparaison d'options, auto-vérification.

## Indicateurs de succès
- Les tâches importantes sont visibles.
- Les décisions sont journalisées.
- Le prompt complet reste cohérent et exploitable.
- Les réponses indiquent clairement faits, hypothèses, recommandations et prochaine action quand le contexte est ambigu.
"""

RULES_TEMPLATE = """# Règles de comportement — {display_name}

{rules}
"""

TOOLS_TEMPLATE = """# Outils disponibles — {display_name}

## Outils internes
- Fichiers Markdown de l'agent
- Mémoire globale du workspace
- Système de tâches Markdown
- Journal local
- Générateur de prompt complet
- Rapport proactif local
- Mémoire avancée adaptative
- Coordination multi-agent locale

## Outils externes futurs
- n8n
- Qdrant
- API REST
- GitLab
- Calendrier
- Email
- LLM local

## Permissions
- Lire et modifier les fichiers du workspace quand l'utilisateur le demande.
- Demander confirmation avant toute action sensible, destructive, coûteuse ou liée à des secrets.
- Vérifier localement une modification quand une commande simple le permet.
- Proposer des mises à jour mémoire, tâches ou logs quand un fait durable, un statut ou une décision apparaît.
"""

TASKS_TEMPLATE = """# Tâches de l’agent — {display_name}

## PRIORITY

## TODO

## DOING

## DONE

## BLOCKED
"""

LOGS_TEMPLATE = """# Journal de l’agent — {display_name}

## Format
- Date :
- Action :
- Décision :
- Fichier modifié :
- Résumé :

---
"""


def create_agent(
    name: str,
    role: str = "Assistant IA",
    objective: str = "Aider l'utilisateur au mieux.",
    tone: str = "clair et chaleureux",
    style: str = "structuré et concis",
    language: str = "français",
    domains: TextOrList = "- À préciser",
    limits: TextOrList = "Ne pas inventer d'informations. Demander confirmation avant action sensible.",
    rules: Optional[TextOrList] = None,
    initial_memory: str = "",
) -> str:
    """Crée un nouvel agent avec tous ses fichiers et retourne son identifiant."""
    slug = normalize_agent_name(name)
    display_name = _display_name(slug)
    agent_dir = get_agent_path(slug)
    agent_dir.mkdir(parents=True, exist_ok=True)

    rules_content = _rules_text(rules)
    initial_memory_content = _as_bullets(initial_memory, fallback="").strip()
    if initial_memory_content:
        initial_memory_content = f"\n{initial_memory_content}"

    template_values = {
        "slug": slug,
        "display_name": display_name,
        "role": role,
        "objective": objective,
        "tone": tone,
        "style": style,
        "language": language,
        "domains": _as_bullets(domains),
        "limits": _as_bullets(limits),
        "rules": rules_content,
        "initial_memory": initial_memory_content,
    }

    files = {
        "agent.md": AGENT_TEMPLATE,
        "system_prompt.md": SYSTEM_PROMPT_TEMPLATE,
        "memory.md": MEMORY_TEMPLATE,
        "goals.md": GOALS_TEMPLATE,
        "rules.md": RULES_TEMPLATE,
        "tools.md": TOOLS_TEMPLATE,
        "tasks.md": TASKS_TEMPLATE,
        "logs.md": LOGS_TEMPLATE,
    }

    created_files = []
    for filename, template in files.items():
        filepath = agent_dir / filename
        if not filepath.exists():
            filepath.write_text(template.format(**template_values), encoding="utf-8")
            created_files.append(filename)

    config = load_config("agents")
    agents = config.get("agents", [])
    if slug not in agents:
        agents.append(slug)
        config["agents"] = sorted(agents)
    config.setdefault("default_agent", "assistant")
    save_config("agents", config)

    if created_files:
        print(f"✅ Agent '{slug}' créé avec {len(created_files)} fichiers.")
    else:
        print(f"ℹ️ Agent '{slug}' existe déjà. Aucun fichier existant n'a été écrasé.")
    return slug


def show_agent(name: str):
    """Affiche un résumé lisible de l'agent."""
    slug = normalize_agent_name(name)
    agent_dir = get_agent_path(slug)
    if not agent_dir.exists():
        print(f"❌ Agent '{slug}' introuvable.")
        return

    print(f"\n📋 Agent : {slug}")
    print("-" * 40)
    for filename in ["agent.md", "goals.md", "memory.md", "tasks.md"]:
        path = agent_dir / filename
        if path.exists():
            content = path.read_text(encoding="utf-8").strip()
            preview = content[:700]
            suffix = "..." if len(content) > 700 else ""
            print(f"\n📄 {filename}\n{preview}{suffix}")


def list_agents():
    """Liste tous les agents existants."""
    agents_dir = ROOT / "agents"
    if not agents_dir.exists():
        print("Aucun agent trouvé.")
        return

    agents = sorted(d.name for d in agents_dir.iterdir() if d.is_dir())
    if not agents:
        print("Aucun agent trouvé.")
        return

    print("🤖 Agents disponibles :")
    for agent in agents:
        print(f"  - {agent}")
