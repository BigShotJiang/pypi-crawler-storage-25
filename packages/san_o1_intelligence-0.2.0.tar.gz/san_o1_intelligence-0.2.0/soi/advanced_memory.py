"""Mémoire avancée Markdown liée et adaptative."""

from datetime import datetime
import re
from pathlib import Path
from typing import Iterable, Optional

from soi.workspace import ROOT, normalize_agent_name

ADVANCED_ROOT = ROOT / "memory" / "advanced"

MEMORY_TARGETS = {
    "preference": "user/preferences.md",
    "communication": "user/communication_style.md",
    "pattern": "user/behavior_patterns.md",
    "goal": "user/goals.md",
    "constraint": "user/constraints.md",
    "observation": "signals/observations.md",
    "feedback": "adaptation/feedback.md",
    "rule": "adaptation/adaptation_rules.md",
    "project": "context/projects.md",
    "decision": "context/decisions.md",
    "risk": "context/risks.md",
}

SENSITIVE_PATTERNS = [
    r"\bpassword\b",
    r"\bmot de passe\b",
    r"\bapi[_ -]?key\b",
    r"\bsecret\b",
    r"\btoken\b",
    r"\biban\b",
    r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b",
]


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _is_sensitive(content: str) -> bool:
    lowered = content.lower()
    return any(re.search(pattern, lowered) for pattern in SENSITIVE_PATTERNS)


def _ensure_file(path: Path, title: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(f"# {title}\n\n", encoding="utf-8")


def _append(path: Path, title: str, content: str):
    _ensure_file(path, title)
    current = path.read_text(encoding="utf-8").rstrip()
    path.write_text(f"{current}\n\n{content}\n", encoding="utf-8")


def _wiki_links(links: str) -> str:
    items = [item.strip() for item in links.split(",") if item.strip()]
    if not items:
        return "[[index]]"
    return ", ".join(item if item.startswith("[[") else f"[[{item}]]" for item in items)


def _read(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return ""


def _recent_bullets(path: Path, limit: int = 8) -> list[str]:
    text = _read(path)
    bullets = [line.strip() for line in text.splitlines() if line.strip().startswith("- **Contenu**")]
    return bullets[-limit:]


def init_advanced_memory():
    """Crée la structure de mémoire avancée."""
    files = {
        "index.md": """# Mémoire avancée SOI

## Cartes principales
- [[memory_protocol]]
- [[user/user_profile]]
- [[user/user_model]]
- [[user/preferences]]
- [[user/communication_style]]
- [[user/behavior_patterns]]
- [[user/goals]]
- [[adaptation/adaptive_brief]]
- [[adaptation/adaptation_rules]]
- [[signals/observations]]
- [[graph/links]]

## Principe
Cette mémoire est un graphe Markdown local. Chaque note peut pointer vers une autre avec des wikilinks.
""",
        "memory_protocol.md": """# Protocole de mémoire avancée

## Règles
- Lire avant d'écrire.
- Ne jamais sauvegarder de secret sans confirmation.
- Dater chaque entrée.
- Ajouter des liens `[[...]]` quand une information touche une préférence, un projet, une décision ou une règle d'adaptation.
- Mettre à jour le modèle utilisateur quand plusieurs signaux convergent.

## Types
- preference
- communication
- pattern
- goal
- constraint
- observation
- feedback
- rule
- project
- decision
- risk
""",
        "user/user_profile.md": """# Profil utilisateur avancé — l'utilisateur

Liens : [[preferences]], [[communication_style]], [[behavior_patterns]], [[goals]], [[user_model]]

## Identité connue
- l'utilisateur utilise San-o1 Intelligence comme workspace IA local-first.
- Langue préférée : français.
- Relation attendue avec l'assistant : tutoiement.

## À enrichir
- Préférences stables
- Style de décision
- Niveau de détail souhaité
- Projets prioritaires
""",
        "user/preferences.md": "# Préférences utilisateur\n\nLiens : [[user_profile]], [[adaptive_brief]]\n",
        "user/communication_style.md": "# Style de communication\n\nLiens : [[user_profile]], [[adaptive_brief]]\n",
        "user/behavior_patterns.md": "# Patterns comportementaux\n\nLiens : [[user_profile]], [[user_model]]\n",
        "user/goals.md": "# Objectifs utilisateur\n\nLiens : [[user_profile]], [[projects]]\n",
        "user/constraints.md": "# Contraintes utilisateur\n\nLiens : [[user_profile]], [[risks]]\n",
        "user/user_model.md": "# Modèle utilisateur adaptatif\n\nGénéré par `memory-user-model`.\n",
        "signals/observations.md": "# Observations\n\nLiens : [[user_model]], [[feedback]]\n",
        "signals/session_signals.md": "# Signaux de session\n\nLiens : [[observations]], [[adaptive_brief]]\n",
        "adaptation/adaptation_rules.md": """# Règles d'adaptation

Liens : [[adaptive_brief]], [[preferences]], [[communication_style]]

## Règles par défaut
- Répondre en français sauf demande contraire.
- Tutoyer l'utilisateur.
- Favoriser les réponses simples, structurées et actionnables.
- Proposer une prochaine action claire.
- Éviter de surcharger l'utilisateur avec trop d'options.
- Demander confirmation avant action sensible.
- Pour les tâches complexes, utiliser une chaîne courte : comprendre, lire le contexte, agir, vérifier, synthétiser.
- Comparer impact, effort, risque et réversibilité quand plusieurs chemins sont possibles.
- Appuyer les réponses sur les fichiers et données disponibles, puis signaler ce qui manque.
- Exposer une justification courte et vérifiable plutôt qu'un raisonnement long.
""",
        "adaptation/adaptive_brief.md": "# Brief adaptatif\n\nGénéré par `memory-brief`.\n",
        "adaptation/feedback.md": "# Feedback utilisateur\n\nLiens : [[adaptive_brief]], [[user_model]]\n",
        "context/projects.md": "# Projets liés à l'utilisateur\n\nLiens : [[goals]], [[decisions]]\n",
        "context/decisions.md": "# Décisions contextualisées\n\nLiens : [[projects]], [[user_model]]\n",
        "context/risks.md": "# Risques et précautions\n\nLiens : [[constraints]], [[adaptation_rules]]\n",
        "graph/links.md": "# Liens mémoire\n\nFormat : `source --relation--> cible`\n",
        "graph/tags.md": "# Tags mémoire\n\n- #preference\n- #communication\n- #pattern\n- #goal\n- #decision\n- #project\n- #risk\n",
        "reviews/memory_review.md": "# Revue mémoire\n\nHistorique des consolidations et points à vérifier.\n",
    }
    for relative_path, content in files.items():
        path = ADVANCED_ROOT / relative_path
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
    print("🧠 Mémoire avancée initialisée dans memory/advanced/.")


def capture_memory(
    content: str,
    kind: str = "observation",
    source: str = "conversation",
    confidence: str = "medium",
    links: str = "user/user_profile,adaptation/adaptive_brief",
    agent_name: str = "assistant",
) -> Optional[str]:
    """Capture une mémoire avancée dans le bon fichier Markdown."""
    init_advanced_memory()
    if kind not in MEMORY_TARGETS:
        print(f"❌ Type mémoire invalide. Types : {', '.join(MEMORY_TARGETS)}")
        return None
    if not content.strip():
        print("❌ Le contenu mémoire ne peut pas être vide.")
        return None
    if _is_sensitive(content):
        print("⚠️ Mémoire potentiellement sensible détectée. Demande confirmation avant sauvegarde.")
        return None

    target = ADVANCED_ROOT / MEMORY_TARGETS[kind]
    agent = normalize_agent_name(agent_name)
    entry = f"""## {_now()} — {kind}

- **Agent** : [[agents/{agent}]]
- **Source** : {source}
- **Confiance** : {confidence}
- **Liens** : {_wiki_links(links)}
- **Contenu** : {content.strip()}
"""
    _append(target, target.stem.replace("_", " ").capitalize(), entry)
    _append(
        ADVANCED_ROOT / "graph" / "links.md",
        "Liens mémoire",
        f"- [{_today()}] [[{MEMORY_TARGETS[kind].replace('.md', '')}]] --type:{kind}--> {_wiki_links(links)}",
    )
    print(f"🧠 Mémoire avancée ajoutée : {MEMORY_TARGETS[kind]}")
    return str(target)


def link_memory(source: str, target: str, relation: str = "related"):
    """Ajoute un lien explicite dans le graphe mémoire."""
    init_advanced_memory()
    entry = f"- [{_today()}] [[{source}]] --{relation}--> [[{target}]]"
    _append(ADVANCED_ROOT / "graph" / "links.md", "Liens mémoire", entry)
    print(f"🔗 Lien mémoire ajouté : {source} --{relation}--> {target}")


def build_user_model(output_file: Optional[str] = None) -> str:
    """Construit un modèle utilisateur adaptatif transparent depuis les notes Markdown."""
    init_advanced_memory()
    preferences = _recent_bullets(ADVANCED_ROOT / "user" / "preferences.md")
    communication = _recent_bullets(ADVANCED_ROOT / "user" / "communication_style.md")
    patterns = _recent_bullets(ADVANCED_ROOT / "user" / "behavior_patterns.md")
    goals = _recent_bullets(ADVANCED_ROOT / "user" / "goals.md")
    constraints = _recent_bullets(ADVANCED_ROOT / "user" / "constraints.md")
    feedback = _recent_bullets(ADVANCED_ROOT / "adaptation" / "feedback.md")

    def section(title: str, items: Iterable[str], fallback: str) -> str:
        values = list(items)
        if not values:
            return f"## {title}\n- {fallback}\n"
        return f"## {title}\n" + "\n".join(values) + "\n"

    model = f"""# Modèle utilisateur adaptatif

Dernière génération : {_now()}

Liens : [[user_profile]], [[preferences]], [[communication_style]], [[behavior_patterns]], [[adaptive_brief]]

{section("Préférences stables", preferences, "Utiliser les préférences par défaut connues.")}
{section("Style de communication", communication, "Français, tutoiement, simple, structuré, actionnable.")}
{section("Patterns observés", patterns, "Aucun pattern durable supplémentaire détecté.")}
{section("Objectifs actifs", goals, "Continuer à faire évoluer San-o1 Intelligence.")}
{section("Contraintes et précautions", constraints, "Demander confirmation pour les actions sensibles.")}
{section("Feedback récent", feedback, "Aucun feedback explicite supplémentaire.")}
## Hypothèse d'adaptation actuelle
- l'utilisateur préfère un assistant proactif, mais qui reste clair, concret, local-first et qui ne surcharge pas.
- L'agent doit proposer une prochaine action utile et maintenir les fichiers mémoire/tâches/logs à jour.
- En cas d'incertitude ou de risque, l'agent doit expliquer brièvement et demander confirmation.
"""

    target = ADVANCED_ROOT / "user" / "user_model.md"
    target.write_text(model, encoding="utf-8")
    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(model, encoding="utf-8")
        print(f"💾 Modèle utilisateur sauvegardé dans : {output_file}")
    print(model)
    return model


def build_adaptive_brief(agent_name: str = "assistant", output_file: Optional[str] = None) -> str:
    """Construit un brief d'adaptation chargé par les agents."""
    init_advanced_memory()
    user_model = _read(ADVANCED_ROOT / "user" / "user_model.md")
    rules = _read(ADVANCED_ROOT / "adaptation" / "adaptation_rules.md")
    profile = _read(ADVANCED_ROOT / "user" / "user_profile.md")
    agent = normalize_agent_name(agent_name)
    brief = f"""# Brief adaptatif — {agent}

Dernière génération : {_now()}

## Profil utilisateur
{profile}

## Modèle utilisateur
{user_model}

## Règles d'adaptation
{rules}

## Instructions d'adaptation pour l'agent
- Charge ce brief avant de répondre à une demande importante.
- Adapte le niveau de détail à la préférence de l'utilisateur : simple, structuré, actionnable.
- Si l'utilisateur demande une évolution du système, implémente-la localement quand c'est sûr.
- Mets à jour la mémoire avancée quand une préférence, un pattern ou un feedback durable apparaît.
- Utilise des wikilinks pour relier les nouvelles mémoires.
- Pour les tâches complexes, applique une boucle courte : contexte, options, action, vérification, synthèse.
- Termine les interventions importantes par une vérification de factualité, sécurité et prochaine action.
"""
    target = ADVANCED_ROOT / "adaptation" / "adaptive_brief.md"
    target.write_text(brief, encoding="utf-8")
    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(brief, encoding="utf-8")
        print(f"💾 Brief adaptatif sauvegardé dans : {output_file}")
    print(brief)
    return brief
