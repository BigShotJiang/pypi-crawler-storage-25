"""Politique de sélection des modèles SOI."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Mapping, Optional

from soi.openrouter_client import model_for_mode


COMPLEXITY_PATTERNS = [
    r"\bimpl[ée]mente\b",
    r"\brefactor",
    r"\bcorrige\b",
    r"\bdebug\b",
    r"\barchitecture\b",
    r"\bmigration\b",
    r"\bplanifie\b",
    r"\bautomatis",
    r"\boutil\b",
    r"\bMCP\b",
    r"\bfichier\b",
    r"\btest",
    r"\btelegram\b",
    r"\bTUI\b",
    r"\bprojet\b",
]

PREMIUM_PATTERNS = [
    r"\bpremium\b",
    r"\bpayant\b",
    r"\bpaid\b",
    r"\bmeilleur mod[èe]le\b",
    r"\bhaute qualit[ée]\b",
    r"\bcomplexe\b",
]


@dataclass(frozen=True)
class ModelDecision:
    """Décision de routage modèle."""

    mode: str
    model: str
    reason: str
    requires_confirmation: bool = False


def configured_model_policy(config: Mapping[str, object]) -> str:
    policy = str(config.get("model_policy") or "auto_prudent").strip().lower()
    return policy if policy in {"manual", "auto_prudent"} else "auto_prudent"


def looks_complex(content: str) -> bool:
    """Heuristique locale, volontairement prudente et lisible."""
    text = content.strip()
    lowered = text.lower()
    if len(text) > 900:
        return True
    if len(re.findall(r"\n|;|,", text)) >= 8:
        return True
    return any(re.search(pattern, lowered, flags=re.IGNORECASE) for pattern in COMPLEXITY_PATTERNS)


def asks_for_premium(content: str) -> bool:
    lowered = content.lower()
    return any(re.search(pattern, lowered, flags=re.IGNORECASE) for pattern in PREMIUM_PATTERNS)


def adaptive_max_tokens(config: Mapping[str, object], iteration: int = 1, is_synthesis: bool = False) -> int:
    """Retourne max_tokens adaptatif selon l'itération de la boucle agentique."""
    if is_synthesis:
        return int(config.get("max_tokens_synthesis", 1500))
    if iteration <= 3:
        return int(config.get("max_tokens_complex", 4000))
    return int(config.get("max_tokens", 2000))


def adaptive_temperature(config: Mapping[str, object], task_type: str = "default") -> float:
    """Retourne la température adaptée au type de tâche."""
    if task_type in {"code", "analysis", "reasoning", "debug"}:
        return float(config.get("temperature_reasoning", 0.3))
    if task_type in {"creative", "brainstorm", "explore"}:
        return float(config.get("temperature_creative", 0.8))
    return float(config.get("temperature", 0.5))


def choose_model(
    config: Mapping[str, object],
    content: str,
    *,
    requested_mode: Optional[str] = None,
    autonomy_mode: str = "safe_agent",
    free_failed: bool = False,
) -> ModelDecision:
    """Choisit free/paid sans lancer d'appel réseau.

    En `auto_prudent`, le paid est seulement proposé et doit être confirmé par
    le runtime appelant avant tout coût.
    """
    mode = (requested_mode or str(config.get("default_mode") or "free")).strip().lower()
    if mode not in {"free", "paid"}:
        mode = "free"

    policy = configured_model_policy(config)
    if mode == "paid":
        return ModelDecision(
            mode="paid",
            model=model_for_mode(config, "paid"),
            reason="mode paid demandé explicitement",
            requires_confirmation=True,
        )

    if free_failed:
        return ModelDecision(
            mode="paid",
            model=model_for_mode(config, "paid"),
            reason="échec du modèle gratuit, escalade proposée",
            requires_confirmation=True,
        )

    if policy != "auto_prudent":
        return ModelDecision(
            mode=mode,
            model=model_for_mode(config, mode),
            reason="politique manuelle",
            requires_confirmation=False,
        )

    if asks_for_premium(content):
        return ModelDecision(
            mode="paid",
            model=model_for_mode(config, "paid"),
            reason="demande explicite de capacité premium",
            requires_confirmation=True,
        )

    if autonomy_mode in {"agent", "safe_agent"} and looks_complex(content):
        return ModelDecision(
            mode="paid",
            model=model_for_mode(config, "paid"),
            reason="tâche agentique ou complexe détectée",
            requires_confirmation=True,
        )

    return ModelDecision(
        mode="free",
        model=model_for_mode(config, "free"),
        reason="tâche simple, gratuit par défaut",
        requires_confirmation=False,
    )
