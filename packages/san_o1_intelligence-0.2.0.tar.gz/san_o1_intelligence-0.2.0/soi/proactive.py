"""Analyse proactive locale du workspace."""

from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from soi.workspace import ROOT, get_agent_path, normalize_agent_name

STATUSES = ["PRIORITY", "TODO", "DOING", "DONE", "BLOCKED"]


def _parse_tasks(tasks_path: Path) -> Dict[str, List[str]]:
    tasks = {status: [] for status in STATUSES}
    if not tasks_path.exists():
        return tasks

    current_status = None
    for line in tasks_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("## "):
            candidate = stripped.replace("## ", "", 1).strip()
            current_status = candidate if candidate in tasks else None
            continue
        if current_status and stripped.startswith("- ["):
            tasks[current_status].append(stripped)
    return tasks


def _list_files(path: Path) -> List[str]:
    if not path.exists():
        return []
    return sorted(str(file.relative_to(ROOT)) for file in path.iterdir() if file.is_file() and file.name != ".gitkeep")


def _list_draft_tools() -> List[str]:
    tools_dir = ROOT / "tools" / "custom"
    if not tools_dir.exists():
        return []
    drafts = []
    for tool_dir in sorted(path for path in tools_dir.iterdir() if path.is_dir()):
        manifest = tool_dir / "tool.json"
        if manifest.exists() and '"status": "draft"' in manifest.read_text(encoding="utf-8"):
            drafts.append(str(tool_dir.relative_to(ROOT)))
    return drafts


def _next_action(tasks: Dict[str, List[str]], inbox_files: List[str], draft_tools: List[str]) -> str:
    for status in ["PRIORITY", "DOING", "TODO", "BLOCKED"]:
        if tasks[status]:
            task = tasks[status][0].replace("- [ ]", "").replace("- [x]", "").strip()
            if status == "BLOCKED":
                return f"Clarifier le blocage : {task}"
            return f"Traiter la tâche {status} : {task}"
    if inbox_files:
        return f"Analyser l'entrée sandbox : {inbox_files[0]}"
    if draft_tools:
        return f"Revoir et valider l'outil brouillon : {draft_tools[0]}"
    return "Aucune action urgente détectée. Proposer une amélioration du workspace ou attendre une nouvelle demande."


def proactive_check(agent_name: str = "assistant", output_file: Optional[str] = None) -> str:
    """Produit un rapport proactif local pour un agent."""
    slug = normalize_agent_name(agent_name)
    agent_dir = get_agent_path(slug)
    if not agent_dir.exists():
        message = f"❌ Agent '{slug}' introuvable."
        print(message)
        return message

    tasks = _parse_tasks(agent_dir / "tasks.md")
    sandbox_inbox = _list_files(ROOT / "workspace" / "sandbox" / "inbox")
    workspace_inbox = _list_files(ROOT / "workspace" / "inbox")
    draft_tools = _list_draft_tools()
    next_action = _next_action(tasks, sandbox_inbox + workspace_inbox, draft_tools)

    report = f"""# Rapport proactif — {slug}

Date : {datetime.now().strftime("%Y-%m-%d %H:%M")}

## Signaux détectés

- Tâches PRIORITY : {len(tasks["PRIORITY"])}
- Tâches DOING : {len(tasks["DOING"])}
- Tâches TODO : {len(tasks["TODO"])}
- Tâches BLOCKED : {len(tasks["BLOCKED"])}
- Fichiers dans `workspace/sandbox/inbox/` : {len(sandbox_inbox)}
- Fichiers dans `workspace/inbox/` : {len(workspace_inbox)}
- Outils brouillons à revoir : {len(draft_tools)}

## Prochaine action recommandée

{next_action}

## Commandes utiles

```bash
python3 scripts/run_agent.py show-agent {slug}
python3 scripts/run_agent.py build-prompt {slug} --output workspace/sandbox/output/prompt_{slug}.txt
python3 scripts/run_agent.py sandbox-brief {slug} --output workspace/sandbox/output/SANDBOX_BRIEF.md
```

## Règle de proactivité

Si l'action est simple, locale et réversible, l'agent peut la faire puis journaliser.
Si l'action est sensible, destructive, coûteuse, externe ou liée à des secrets, l'agent doit demander confirmation.
"""

    if output_file:
        out_path = ROOT / output_file
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(report, encoding="utf-8")
        print(f"💾 Rapport proactif sauvegardé dans : {output_file}")

    print(report)
    return report
