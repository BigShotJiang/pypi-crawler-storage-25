"""Heartbeat local pour SOI."""

from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
from typing import Dict, List, Optional

from soi.conversation import list_inbox_files, summarize_tasks
from soi.openrouter_client import OpenRouterClient
from soi.workspace import ROOT, load_config, normalize_agent_name, save_config


EVENTS_PATH = ROOT / "workspace" / "heartbeat" / "events.jsonl"
LAST_PATH = ROOT / "workspace" / "heartbeat" / "last.json"
DEFAULT_CONFIG = {
    "enabled": True,
    "default_agent": "assistant",
    "mode": "local",
    "use_llm_if_available": False,
    "max_events": 20,
}


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure_storage() -> None:
    EVENTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not EVENTS_PATH.exists():
        EVENTS_PATH.write_text("", encoding="utf-8")


def _load_config() -> Dict[str, object]:
    config = load_config("heartbeat")
    changed = False
    for key, value in DEFAULT_CONFIG.items():
        if key not in config:
            config[key] = value
            changed = True
    if changed:
        save_config("heartbeat", config)
    return config


def _append_jsonl(path: Path, data: Dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(data, ensure_ascii=False) + "\n")


def _read_jsonl(path: Path, limit: int = 20) -> List[Dict[str, object]]:
    if not path.exists():
        return []
    records: List[Dict[str, object]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            records.append(value)
    return records[-limit:]


def _agent_exists(agent_name: str) -> bool:
    return (ROOT / "agents" / normalize_agent_name(agent_name)).exists()


def _local_recommendation(agent_name: str, events: List[Dict[str, object]]) -> str:
    tasks = summarize_tasks(agent_name, root=ROOT)
    inbox_files = list_inbox_files(root=ROOT)
    if tasks.get("PRIORITY", 0):
        return "Traiter la première tâche PRIORITY de l'agent."
    if tasks.get("DOING", 0):
        return "Reprendre la tâche DOING en cours."
    if inbox_files:
        return f"Analyser l'entrée inbox : {inbox_files[0]}"
    if events:
        return f"Examiner le dernier événement système : {events[-1].get('text', '')}"
    return "Aucune action urgente détectée. Attendre une demande ou proposer une amélioration locale."


def _build_report(agent_name: str, events: List[Dict[str, object]]) -> str:
    tasks = summarize_tasks(agent_name, root=ROOT)
    inbox_files = list_inbox_files(root=ROOT)
    recommendation = _local_recommendation(agent_name, events)
    event_lines = "\n".join(
        f"- {event.get('timestamp', '?')} : {event.get('text', '')}" for event in events[-5:]
    ) or "- Aucun événement récent"
    inbox_lines = "\n".join(f"- {path}" for path in inbox_files[:10]) or "- Aucun fichier inbox"
    return f"""# Heartbeat SOI — {agent_name}

Date : {_now_iso()}

## État local

- Tâches PRIORITY : {tasks.get("PRIORITY", 0)}
- Tâches DOING : {tasks.get("DOING", 0)}
- Tâches TODO : {tasks.get("TODO", 0)}
- Tâches BLOCKED : {tasks.get("BLOCKED", 0)}
- Fichiers inbox : {len(inbox_files)}
- Événements récents : {len(events)}

## Inbox

{inbox_lines}

## Événements récents

{event_lines}

## Recommandation

{recommendation}

## Garde-fous

Aucune action destructive, externe, coûteuse ou liée à des secrets n'a été lancée.
"""


def heartbeat_status() -> str:
    """Affiche l'état du heartbeat."""
    config = _load_config()
    enabled = bool(config.get("enabled", True))
    last = {}
    if LAST_PATH.exists():
        try:
            last = json.loads(LAST_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            last = {}
    events = _read_jsonl(EVENTS_PATH, limit=1000)
    report = f"""# Statut heartbeat SOI

- Activé : {enabled}
- Mode : {config.get("mode", "local")}
- Agent par défaut : {config.get("default_agent", "assistant")}
- Appel LLM si disponible : {bool(config.get("use_llm_if_available", False))}
- Événements enregistrés : {len(events)}
- Dernier heartbeat : {last.get("timestamp", "jamais")}
"""
    print(report)
    return report


def heartbeat_enable(enabled: bool = True) -> None:
    config = _load_config()
    config["enabled"] = bool(enabled)
    save_config("heartbeat", config)
    print("✅ Heartbeat activé." if enabled else "⏸️ Heartbeat désactivé.")


def heartbeat_last() -> str:
    if not LAST_PATH.exists():
        message = "Aucun heartbeat enregistré."
        print(message)
        return message
    text = LAST_PATH.read_text(encoding="utf-8")
    print(text)
    return text


def system_event(text: str, mode: str = "next-heartbeat") -> Dict[str, object]:
    """Enregistre un événement système et déclenche éventuellement un heartbeat."""
    if mode not in {"now", "next-heartbeat"}:
        raise ValueError("Mode invalide. Utilise 'now' ou 'next-heartbeat'.")
    _ensure_storage()
    event = {"timestamp": _now_iso(), "text": text.strip(), "mode": mode}
    _append_jsonl(EVENTS_PATH, event)
    print(f"✅ Événement enregistré ({mode}).")
    if mode == "now":
        heartbeat_run()
    return event


def heartbeat_run(agent_name: Optional[str] = None) -> str:
    """Exécute un heartbeat local."""
    config = _load_config()
    if not bool(config.get("enabled", True)):
        message = "Heartbeat désactivé."
        print(message)
        return message

    slug = normalize_agent_name(agent_name or str(config.get("default_agent") or "assistant"))
    if not _agent_exists(slug):
        slug = "assistant" if _agent_exists("assistant") else slug

    max_events = int(config.get("max_events", 20))
    events = _read_jsonl(EVENTS_PATH, limit=max_events)
    report = _build_report(slug, events)

    if bool(config.get("use_llm_if_available", False)) and OpenRouterClient().has_api_key:
        try:
            from soi.chat_runtime import AgentChatRuntime

            runtime = AgentChatRuntime(agent_name=slug, mode="free")
            try:
                reply = runtime.ask(
                    "Heartbeat local SOI. Lis ce rapport et propose uniquement une prochaine action sûre :\n\n"
                    + report,
                    allow_paid=False,
                )
                report = reply.content
            finally:
                runtime.close()
        except Exception as exc:
            report = f"{report}\n\nNote : appel LLM ignoré après erreur locale : {exc}\n"

    result = {
        "timestamp": _now_iso(),
        "agent": slug,
        "mode": "local",
        "event_count": len(events),
        "report": report,
    }
    LAST_PATH.parent.mkdir(parents=True, exist_ok=True)
    LAST_PATH.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(report)
    return report
