"""Runtime de chat headless pour San-o1 Intelligence.

Compatibilité légère autour du runtime agentique commun. Les connecteurs
historiques peuvent continuer à appeler `AgentChatRuntime.ask`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Mapping, Optional

from soi.agent_runtime import AgentExecutionRuntime, AgentRuntimeResult, PendingAction
from soi.mcp_client import MCPClientManager
from soi.openrouter_client import OpenRouterClient, config_default_mode, load_llm_config
from soi.workspace import ROOT, normalize_agent_name


@dataclass(frozen=True)
class AgentReply:
    """Réponse prête à être envoyée par un connecteur externe."""

    content: str
    mode: str
    model: str
    session_id: str
    usage: Dict[str, object]
    local_only: bool = False
    error: bool = False
    confirmation_required: bool = False
    confirmation_kind: str = ""
    pending_action: Optional[PendingAction] = None
    tool_executed: str = ""
    verification: str = ""
    model_reason: str = ""
    autonomy_mode: str = "safe_agent"

    @classmethod
    def from_result(cls, result: AgentRuntimeResult) -> "AgentReply":
        return cls(
            content=result.content,
            mode=result.mode,
            model=result.model,
            session_id=result.session_id,
            usage=result.usage,
            local_only=result.local_only,
            error=result.error,
            confirmation_required=result.confirmation_required,
            confirmation_kind=result.confirmation_kind,
            pending_action=result.pending_action,
            tool_executed=result.tool_executed,
            verification=result.verification,
            model_reason=result.model_reason,
            autonomy_mode=result.autonomy_mode,
        )


class AgentChatRuntime:
    """Boucle de chat synchrone réutilisable hors TUI."""

    def __init__(
        self,
        agent_name: str = "assistant",
        mode: Optional[str] = None,
        session_id: Optional[str] = None,
        root: Path = ROOT,
        config: Optional[Mapping[str, object]] = None,
        client: Optional[OpenRouterClient] = None,
        mcp_manager: Optional[MCPClientManager] = None,
        autonomy_mode: str = "safe_agent",
        pending_action: Optional[PendingAction] = None,
    ):
        self.root = root
        self.agent_name = normalize_agent_name(agent_name)
        self.config = dict(config or load_llm_config(root=root))
        self.mode = self._normalize_mode(mode or config_default_mode(self.config))
        self.runtime = AgentExecutionRuntime(
            agent_name=self.agent_name,
            mode=self.mode,
            session_id=session_id,
            root=root,
            config=self.config,
            client=client,
            mcp_manager=mcp_manager,
            autonomy_mode=autonomy_mode,
            pending_action=pending_action,
        )
        self.store = self.runtime.store
        self.client = self.runtime.client
        self.mcp_manager = self.runtime.mcp_manager

    @staticmethod
    def _normalize_mode(mode: str) -> str:
        normalized = mode.strip().lower()
        return normalized if normalized in {"free", "paid"} else "free"

    @property
    def pending_action(self) -> Optional[PendingAction]:
        return self.runtime.pending_action

    def close(self) -> None:
        self.runtime.close()

    def ask(
        self,
        content: str,
        *,
        allow_paid: bool = False,
        history_limit: Optional[int] = None,
    ) -> AgentReply:
        result = self.runtime.ask(content, allow_paid=allow_paid, history_limit=history_limit)
        return AgentReply.from_result(result)

    def confirm_pending(
        self,
        *,
        allow_paid: bool = False,
        history_limit: Optional[int] = None,
    ) -> AgentReply:
        result = self.runtime.confirm_pending(allow_paid=allow_paid, history_limit=history_limit)
        return AgentReply.from_result(result)
