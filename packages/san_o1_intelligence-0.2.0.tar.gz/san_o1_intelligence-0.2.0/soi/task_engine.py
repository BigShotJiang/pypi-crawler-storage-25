"""Moteur d'exécution et de gestion des tâches Markdown de l'agent."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from soi.workspace import ROOT, normalize_agent_name


STATUS_ORDER = ["PRIORITY", "TODO", "DOING", "DONE", "BLOCKED"]


@dataclass
class Task:
    """Représentation d'une tâche dans tasks.md."""

    id: str
    title: str
    status: str
    agent_name: str = ""
    notes: str = ""
    line_number: int = 0


@dataclass
class TaskBoard:
    """Tableau de tâches parsé depuis tasks.md."""

    tasks: Dict[str, List[Task]] = field(default_factory=lambda: {s: [] for s in STATUS_ORDER})
    raw_lines: List[str] = field(default_factory=list)
    task_line_map: Dict[str, int] = field(default_factory=dict)


class TaskEngine:
    """Lit, exécute et met à jour les tâches d'un agent."""

    def __init__(self, root: Path = ROOT):
        self.root = root

    def tasks_path(self, agent_name: str) -> Path:
        return self.root / "agents" / normalize_agent_name(agent_name) / "tasks.md"

    def load_tasks(self, agent_name: str) -> TaskBoard:
        """Parse le fichier tasks.md en TaskBoard."""
        path = self.tasks_path(agent_name)
        board = TaskBoard()
        if not path.exists():
            return board

        lines = path.read_text(encoding="utf-8").splitlines()
        board.raw_lines = list(lines)
        current_status = ""
        task_counter = 0

        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("## "):
                current_status = stripped.replace("## ", "", 1).strip().upper()
                continue
            if current_status in STATUS_ORDER and stripped.startswith("- ["):
                task_counter += 1
                task_id = f"{normalize_agent_name(agent_name)}-{task_counter}"
                # Extraire le titre : "- [ ] Titre" ou "- [x] Titre"
                match = re.match(r"- \[(.?)\]\s+(.*)", stripped)
                if match:
                    title = match.group(2).strip()
                else:
                    title = stripped
                task = Task(
                    id=task_id,
                    title=title,
                    status=current_status,
                    agent_name=agent_name,
                    line_number=i,
                )
                board.tasks[current_status].append(task)
                board.task_line_map[task_id] = i

        return board

    def get_next_action(self, agent_name: str) -> Optional[Task]:
        """Retourne la prochaine tâche à exécuter (PRIORITY puis TODO)."""
        board = self.load_tasks(agent_name)
        for status in ("PRIORITY", "TODO"):
            if board.tasks[status]:
                return board.tasks[status][0]
        return None

    def update_status(self, agent_name: str, task_id: str, new_status: str) -> bool:
        """Met à jour le statut d'une tâche dans tasks.md."""
        new_status = new_status.upper()
        if new_status not in STATUS_ORDER:
            return False

        board = self.load_tasks(agent_name)
        if task_id not in board.task_line_map:
            return False

        line_idx = board.task_line_map[task_id]
        old_line = board.raw_lines[line_idx]
        # Mettre à jour la case à cocher selon le statut
        if new_status == "DONE":
            new_line = re.sub(r"- \[(.?)\]", "- [x]", old_line, count=1)
        else:
            new_line = re.sub(r"- \[(.?)\]", "- [ ]", old_line, count=1)

        if new_line == old_line:
            # Pas de case trouvée, ajouter une
            new_line = f"- [ ] {old_line.lstrip('- ').strip()}"

        board.raw_lines[line_idx] = new_line

        # Déplacer la tâche vers la bonne section si nécessaire
        # Pour l'instant, on met juste à jour la ligne en place
        # (déplacement entre sections serait plus complexe)

        path = self.tasks_path(agent_name)
        path.write_text("\n".join(board.raw_lines) + "\n", encoding="utf-8")
        return True

    def add_task(self, agent_name: str, title: str, status: str = "TODO") -> bool:
        """Ajoute une nouvelle tâche dans la section correspondante."""
        status = status.upper()
        if status not in STATUS_ORDER:
            return False

        path = self.tasks_path(agent_name)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            # Créer le fichier avec les sections
            lines = [f"# Tâches de l'agent — {agent_name}", ""]
            for s in STATUS_ORDER:
                lines.append(f"## {s}")
                lines.append("")
            path.write_text("\n".join(lines), encoding="utf-8")

        lines = path.read_text(encoding="utf-8").splitlines()
        # Trouver la section
        section_idx = None
        for i, line in enumerate(lines):
            if line.strip() == f"## {status}":
                section_idx = i
                break

        if section_idx is None:
            return False

        # Insérer la tâche après la section
        insert_idx = section_idx + 1
        while insert_idx < len(lines) and lines[insert_idx].strip().startswith("- ["):
            insert_idx += 1

        lines.insert(insert_idx, f"- [ ] {title}")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True

    def mark_blocked(self, agent_name: str, task_id: str, reason: str) -> bool:
        """Marque une tâche comme bloquée avec une raison."""
        board = self.load_tasks(agent_name)
        if task_id not in board.task_line_map:
            return False

        line_idx = board.task_line_map[task_id]
        old_line = board.raw_lines[line_idx]
        new_line = f"{old_line.rstrip()} _(bloqué: {reason})_"
        board.raw_lines[line_idx] = new_line

        path = self.tasks_path(agent_name)
        path.write_text("\n".join(board.raw_lines) + "\n", encoding="utf-8")
        return True

    def tasks_summary(self, agent_name: str) -> Dict[str, int]:
        """Retourne un résumé du nombre de tâches par statut."""
        board = self.load_tasks(agent_name)
        return {status: len(board.tasks[status]) for status in STATUS_ORDER}

    def tasks_text_for_prompt(self, agent_name: str) -> str:
        """Génère un texte compact des tâches pour le prompt système."""
        board = self.load_tasks(agent_name)
        lines = ["## Tâches actives"]
        has_tasks = False
        for status in STATUS_ORDER:
            tasks = board.tasks[status]
            if tasks:
                has_tasks = True
                lines.append(f"### {status}")
                for task in tasks:
                    prefix = "[x]" if status == "DONE" else "[ ]"
                    lines.append(f"- {prefix} {task.title}")
        if not has_tasks:
            lines.append("_Aucune tâche active._")
        next_task = self.get_next_action(agent_name)
        if next_task:
            lines.append("")
            lines.append(f"**Prochaine action suggérée** : {next_task.title}")
        return "\n".join(lines)
