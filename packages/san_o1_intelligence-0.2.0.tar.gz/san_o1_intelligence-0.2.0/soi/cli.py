"""Interface en ligne de commande de San-o1 Intelligence."""

import argparse
import sys

from soi.workspace import ROOT, init_workspace
from soi.agent import create_agent, show_agent, list_agents
from soi.memory import add_memory
from soi.tasks import add_task, complete_task, update_task_status
from soi.prompt_builder import build_prompt
from soi.logger import log
from soi.sandbox import sandbox_brief
from soi.proactive import proactive_check
from soi.tooling import approve_tool, create_tool, create_tool_as_agent, list_tools as list_custom_tools
from soi.multi_agent import create_team, handoff, list_teams, show_team, team_brief
from soi.team_runtime import run_team_objective
from soi.advanced_memory import build_adaptive_brief, build_user_model, capture_memory, init_advanced_memory, link_memory
from soi.mcp_client import MCPClientManager, MCPError
from soi.openrouter_client import config_default_mode, load_llm_config, print_models_status
from soi.onboarding import onboard
from soi.heartbeat import heartbeat_enable, heartbeat_last, heartbeat_run, heartbeat_status, system_event
from soi.cron import cron_add, cron_due, cron_list, cron_rm, cron_run, cron_runs, cron_set_enabled, cron_show


def main():
    parser = argparse.ArgumentParser(
        prog="soi",
        description="San-o1 Intelligence — Workspace IA local-first",
    )
    subparsers = parser.add_subparsers(dest="command", help="Commandes disponibles")

    # init
    subparsers.add_parser("init", help="Initialise le workspace")

    # onboard
    onboard_parser = subparsers.add_parser("onboard", help="Crée/configure un assistant générique SOI")
    onboard_parser.add_argument("--name", default=None, help="Identifiant de l'assistant")
    onboard_parser.add_argument("--role", default=None, help="Rôle de l'assistant")
    onboard_parser.add_argument("--objective", default=None, help="Objectif principal")
    onboard_parser.add_argument("--tone", default=None, help="Ton")
    onboard_parser.add_argument("--style", default=None, help="Style")
    onboard_parser.add_argument("--language", default=None, help="Langue")
    onboard_parser.add_argument("--workspace", default=None, help="Workspace cible à afficher/valider")
    onboard_parser.add_argument("--non-interactive", action="store_true", help="Désactive les questions interactives")
    onboard_parser.add_argument("--accept-defaults", action="store_true", help="Accepte les valeurs par défaut")
    onboard_parser.add_argument("--default-agent", action="store_true", help="Définit cet assistant comme agent par défaut")

    # create-agent
    create_parser = subparsers.add_parser("create-agent", help="Crée un nouvel agent")
    create_parser.add_argument("name", help="Nom de l'agent")
    create_parser.add_argument("--role", default="Assistant IA", help="Rôle de l'agent")
    create_parser.add_argument("--objective", default="Aider l'utilisateur au mieux.", help="Objectif principal")
    create_parser.add_argument("--tone", default="Clair et chaleureux", help="Ton de communication")
    create_parser.add_argument("--style", default="Structuré et concis", help="Style de communication")
    create_parser.add_argument("--language", default="Français", help="Langue")
    create_parser.add_argument("--domains", default="- À préciser", help="Domaines d'aide, en texte ou bullets Markdown")
    create_parser.add_argument("--limits", default="Ne pas inventer d'informations. Demander confirmation avant action sensible.", help="Limites de l'agent")
    create_parser.add_argument("--rules", default="", help="Règles spécifiques à ajouter aux règles par défaut")
    create_parser.add_argument("--initial-memory", default="", help="Mémoire initiale à placer dans memory.md")

    # build-prompt
    build_parser = subparsers.add_parser("build-prompt", help="Génère le prompt complet d'un agent")
    build_parser.add_argument("name", help="Nom de l'agent")
    build_parser.add_argument("--output", default=None, help="Fichier de sortie (optionnel)")

    # sandbox-brief
    sandbox_parser = subparsers.add_parser("sandbox-brief", help="Génère le brief pour Codex/Claude Code sans API")
    sandbox_parser.add_argument("name", nargs="?", default="assistant", help="Nom de l'agent")
    sandbox_parser.add_argument("--output", default=None, help="Fichier de sortie (optionnel)")

    # proactive-check
    proactive_parser = subparsers.add_parser("proactive-check", help="Analyse le workspace et propose la prochaine action")
    proactive_parser.add_argument("name", nargs="?", default="assistant", help="Nom de l'agent")
    proactive_parser.add_argument("--output", default=None, help="Fichier de sortie (optionnel)")

    # heartbeat
    heartbeat_parser = subparsers.add_parser("heartbeat", help="Contrôle le heartbeat local")
    heartbeat_subparsers = heartbeat_parser.add_subparsers(dest="heartbeat_command", help="Commandes heartbeat")
    heartbeat_subparsers.add_parser("status", help="Affiche le statut du heartbeat")
    heartbeat_subparsers.add_parser("enable", help="Active le heartbeat")
    heartbeat_subparsers.add_parser("disable", help="Désactive le heartbeat")
    heartbeat_subparsers.add_parser("last", help="Affiche le dernier heartbeat")
    heartbeat_run_parser = heartbeat_subparsers.add_parser("run", help="Exécute un heartbeat maintenant")
    heartbeat_run_parser.add_argument("--agent", default=None, help="Agent cible")

    # system-event
    event_parser = subparsers.add_parser("system-event", help="Enregistre un événement système")
    event_parser.add_argument("--text", required=True, help="Texte de l'événement")
    event_parser.add_argument("--mode", choices=["now", "next-heartbeat"], default="next-heartbeat", help="Mode de réveil")

    # cron
    cron_parser = subparsers.add_parser("cron", help="Gère les tâches planifiées locales")
    cron_subparsers = cron_parser.add_subparsers(dest="cron_command", help="Commandes cron")
    cron_add_parser = cron_subparsers.add_parser("add", help="Ajoute ou met à jour un cron")
    cron_add_parser.add_argument("--name", required=True, help="Nom du cron")
    cron_add_parser.add_argument("--message", required=True, help="Message envoyé à l'agent")
    cron_add_parser.add_argument("--agent", default=None, help="Agent cible")
    cron_add_parser.add_argument("--every", default=None, help="Intervalle, ex. 10m, 1h, 1d")
    cron_add_parser.add_argument("--at", default=None, help="Date ISO ou +durée")
    cron_add_parser.add_argument("--cron", dest="cron_expr", default=None, help="Expression cron 5 champs")
    cron_add_parser.add_argument("--disabled", action="store_true", help="Crée le cron désactivé")
    cron_subparsers.add_parser("list", help="Liste les crons")
    cron_show_parser = cron_subparsers.add_parser("show", help="Affiche un cron")
    cron_show_parser.add_argument("id", help="Identifiant ou nom du cron")
    cron_enable_parser = cron_subparsers.add_parser("enable", help="Active un cron")
    cron_enable_parser.add_argument("id", help="Identifiant ou nom du cron")
    cron_disable_parser = cron_subparsers.add_parser("disable", help="Désactive un cron")
    cron_disable_parser.add_argument("id", help="Identifiant ou nom du cron")
    cron_rm_parser = cron_subparsers.add_parser("rm", help="Supprime un cron")
    cron_rm_parser.add_argument("id", help="Identifiant ou nom du cron")
    cron_run_parser = cron_subparsers.add_parser("run", help="Exécute un cron maintenant")
    cron_run_parser.add_argument("id", help="Identifiant ou nom du cron")
    cron_subparsers.add_parser("due", help="Exécute les crons arrivés à échéance")
    cron_runs_parser = cron_subparsers.add_parser("runs", help="Affiche l'historique des runs")
    cron_runs_parser.add_argument("id", nargs="?", default=None, help="Identifiant ou nom du cron")

    # chat
    chat_parser = subparsers.add_parser("chat", help="Lance le TUI OpenRouter persistant")
    chat_parser.add_argument("--agent", default="assistant", help="Agent cible")
    chat_parser.add_argument("--mode", choices=["free", "paid"], default=None, help="Mode OpenRouter")

    # models
    subparsers.add_parser("models", help="Affiche la configuration OpenRouter sans révéler de secret")

    # create-tool
    tool_parser = subparsers.add_parser("create-tool", help="Crée un outil local custom en brouillon")
    tool_parser.add_argument("name", help="Nom de l'outil")
    tool_parser.add_argument("--purpose", required=True, help="Objectif de l'outil")
    tool_parser.add_argument("--agent", default="assistant", help="Agent créateur")
    tool_parser.add_argument("--language", default="python", choices=["python", "markdown"], help="Type d'outil")

    # create-tool-as-agent
    tool_agent_parser = subparsers.add_parser("create-tool-as-agent", help="Crée et approuve un outil local custom (mode agent)")
    tool_agent_parser.add_argument("name", help="Nom de l'outil")
    tool_agent_parser.add_argument("--purpose", required=True, help="Objectif de l'outil")
    tool_agent_parser.add_argument("--agent", default="assistant", help="Agent créateur")
    tool_agent_parser.add_argument("--language", default="python", choices=["python", "markdown"], help="Type d'outil")
    tool_agent_parser.add_argument("--code", default=None, help="Code Python à écrire dans run.py (optionnel)")

    # approve-tool
    approve_parser = subparsers.add_parser("approve-tool", help="Marque un outil custom comme approuvé")
    approve_parser.add_argument("name", help="Nom de l'outil")

    # list-tools
    tools_parser = subparsers.add_parser("list-tools", help="Liste les outils custom")
    tools_parser.add_argument("--status", default=None, choices=["draft", "approved"], help="Filtre par statut")

    # mcp-list
    mcp_list_parser = subparsers.add_parser("mcp-list", help="Liste les serveurs MCP et leurs outils")

    # mcp-test
    mcp_test_parser = subparsers.add_parser("mcp-test", help="Teste la connexion à un serveur MCP")
    mcp_test_parser.add_argument("name", help="Nom du serveur MCP à tester")

    # create-team
    team_parser = subparsers.add_parser("create-team", help="Crée une équipe multi-agent")
    team_parser.add_argument("name", help="Nom de l'équipe")
    team_parser.add_argument("--agents", default="assistant", help="Agents séparés par des virgules")
    team_parser.add_argument("--objective", default="Coordonner plusieurs agents persistants.", help="Objectif de l'équipe")
    team_parser.add_argument("--coordinator", default="assistant", help="Agent coordinateur")

    # list-teams
    subparsers.add_parser("list-teams", help="Liste les équipes multi-agent")

    # show-team
    show_team_parser = subparsers.add_parser("show-team", help="Affiche une équipe multi-agent")
    show_team_parser.add_argument("name", help="Nom de l'équipe")

    # team-brief
    brief_parser = subparsers.add_parser("team-brief", help="Génère le brief complet d'une équipe")
    brief_parser.add_argument("name", help="Nom de l'équipe")
    brief_parser.add_argument("--output", default=None, help="Fichier de sortie (optionnel)")

    # team-run
    run_parser = subparsers.add_parser("team-run", help="Prépare ou exécute un run d'équipe avec OpenRouter")
    run_parser.add_argument("name", help="Nom de l'équipe")
    run_parser.add_argument("objective", help="Objectif concret du run")
    run_parser.add_argument("--execute", action="store_true", help="Appelle OpenRouter au lieu d'un plan local")
    run_parser.add_argument("--model", default=None, help="Modèle OpenRouter à utiliser")
    run_parser.add_argument(
        "--reasoning-effort",
        default=None,
        choices=["low", "medium", "high", "xhigh"],
        help="Effort de raisonnement OpenRouter pour le run",
    )

    # handoff
    handoff_parser = subparsers.add_parser("handoff", help="Crée un passage de relais entre deux agents")
    handoff_parser.add_argument("from_agent", help="Agent source")
    handoff_parser.add_argument("to_agent", help="Agent cible")
    handoff_parser.add_argument("task", help="Tâche à transmettre")
    handoff_parser.add_argument("--context", default="", help="Contexte du passage de relais")
    handoff_parser.add_argument("--team", default="core", help="Équipe concernée")

    # add-memory
    mem_parser = subparsers.add_parser("add-memory", help="Ajoute une mémoire à un agent")
    mem_parser.add_argument("name", help="Nom de l'agent")
    mem_parser.add_argument("content", help="Contenu de la mémoire")
    mem_parser.add_argument("--section", default="Mémoire long terme", help="Section cible")

    # memory-init
    subparsers.add_parser("memory-init", help="Initialise la mémoire avancée Markdown liée")

    # memory-capture
    capture_parser = subparsers.add_parser("memory-capture", help="Capture une mémoire avancée liée")
    capture_parser.add_argument("content", help="Contenu à mémoriser")
    capture_parser.add_argument("--kind", default="observation", choices=[
        "preference",
        "communication",
        "pattern",
        "goal",
        "constraint",
        "observation",
        "feedback",
        "rule",
        "project",
        "decision",
        "risk",
    ], help="Type de mémoire")
    capture_parser.add_argument("--source", default="conversation", help="Source de l'information")
    capture_parser.add_argument("--confidence", default="medium", help="Niveau de confiance")
    capture_parser.add_argument("--links", default="user/user_profile,adaptation/adaptive_brief", help="Wikilinks séparés par virgules")
    capture_parser.add_argument("--agent", default="assistant", help="Agent qui capture")

    # memory-link
    link_parser = subparsers.add_parser("memory-link", help="Ajoute un lien explicite au graphe mémoire")
    link_parser.add_argument("source", help="Note source")
    link_parser.add_argument("target", help="Note cible")
    link_parser.add_argument("--relation", default="related", help="Relation")

    # memory-user-model
    user_model_parser = subparsers.add_parser("memory-user-model", help="Génère le modèle utilisateur adaptatif")
    user_model_parser.add_argument("--output", default=None, help="Fichier de sortie optionnel")

    # memory-brief
    memory_brief_parser = subparsers.add_parser("memory-brief", help="Génère le brief adaptatif d'un agent")
    memory_brief_parser.add_argument("name", nargs="?", default="assistant", help="Nom de l'agent")
    memory_brief_parser.add_argument("--output", default=None, help="Fichier de sortie optionnel")

    # add-task
    task_parser = subparsers.add_parser("add-task", help="Ajoute une tâche à un agent")
    task_parser.add_argument("name", help="Nom de l'agent")
    task_parser.add_argument("title", help="Titre de la tâche")
    task_parser.add_argument("--status", default="TODO", choices=["PRIORITY", "TODO", "DOING", "DONE", "BLOCKED"], help="Statut initial")

    # complete-task
    done_parser = subparsers.add_parser("complete-task", help="Marque une tâche comme terminée")
    done_parser.add_argument("name", help="Nom de l'agent")
    done_parser.add_argument("title", help="Titre de la tâche")

    # update-task
    upd_parser = subparsers.add_parser("update-task", help="Change le statut d'une tâche")
    upd_parser.add_argument("name", help="Nom de l'agent")
    upd_parser.add_argument("title", help="Titre de la tâche")
    upd_parser.add_argument("status", choices=["PRIORITY", "TODO", "DOING", "DONE", "BLOCKED"], help="Nouveau statut")

    # show-agent
    show_parser = subparsers.add_parser("show-agent", help="Affiche le résumé d'un agent")
    show_parser.add_argument("name", help="Nom de l'agent")

    # list-agents
    subparsers.add_parser("list-agents", help="Liste tous les agents")

    # log
    log_parser = subparsers.add_parser("log", help="Ajoute une entrée au journal")
    log_parser.add_argument("name", help="Nom de l'agent")
    log_parser.add_argument("--action", default="", help="Action réalisée")
    log_parser.add_argument("--decision", default="", help="Décision prise")
    log_parser.add_argument("--file", default="", dest="file_modified", help="Fichier modifié")
    log_parser.add_argument("--summary", default="", help="Résumé")

    args = parser.parse_args()

    if args.command == "init":
        init_workspace()
        # Crée l'assistant par défaut
        create_agent(
            name="assistant",
            role="Assistant IA personnel de l'utilisateur",
            objective="Aider l'utilisateur à créer des projets IA, automatiser des workflows, organiser les idées, coder, écrire, composer de la musique et gérer des projets techniques.",
            tone="Clair, chaleureux, structuré et fiable",
            style="Structuré, concis, avec une touche personnelle",
            language="Français",
            domains="- Projets IA\n- Automatisation de workflows\n- Organisation d'idées\n- Développement\n- Écriture\n- Composition musicale\n- Gestion de projets techniques",
            limits="Ne pas inventer d'informations. Demander confirmation avant action sensible. Signaler les risques.",
            rules="- Tutoie l'utilisateur\n- Aide l'utilisateur à garder ses projets IA organisés\n- Ne surcharge pas l'utilisateur avec trop d'options à la fois",
            initial_memory="l'utilisateur préfère les réponses simples, structurées et directement actionnables.",
        )
        print("🤖 Agent par défaut 'l'assistant' prêt.")

    elif args.command == "onboard":
        onboard(
            name=args.name,
            role=args.role,
            objective=args.objective,
            tone=args.tone,
            style=args.style,
            language=args.language,
            workspace=args.workspace,
            non_interactive=args.non_interactive,
            accept_defaults=args.accept_defaults,
            default_agent=args.default_agent,
        )

    elif args.command == "create-agent":
        create_agent(
            name=args.name,
            role=args.role,
            objective=args.objective,
            tone=args.tone,
            style=args.style,
            language=args.language,
            domains=args.domains,
            limits=args.limits,
            rules=args.rules,
            initial_memory=args.initial_memory,
        )

    elif args.command == "build-prompt":
        build_prompt(args.name, output_file=args.output)

    elif args.command == "sandbox-brief":
        sandbox_brief(args.name, output_file=args.output)

    elif args.command == "proactive-check":
        proactive_check(args.name, output_file=args.output)

    elif args.command == "heartbeat":
        if args.heartbeat_command == "status" or args.heartbeat_command is None:
            heartbeat_status()
        elif args.heartbeat_command == "enable":
            heartbeat_enable(True)
        elif args.heartbeat_command == "disable":
            heartbeat_enable(False)
        elif args.heartbeat_command == "last":
            heartbeat_last()
        elif args.heartbeat_command == "run":
            heartbeat_run(agent_name=args.agent)

    elif args.command == "system-event":
        system_event(args.text, mode=args.mode)

    elif args.command == "cron":
        if args.cron_command == "add":
            cron_add(
                name=args.name,
                message=args.message,
                agent=args.agent,
                every=args.every,
                at=args.at,
                cron_expr=args.cron_expr,
                disabled=args.disabled,
            )
        elif args.cron_command == "list" or args.cron_command is None:
            cron_list()
        elif args.cron_command == "show":
            cron_show(args.id)
        elif args.cron_command == "enable":
            cron_set_enabled(args.id, True)
        elif args.cron_command == "disable":
            cron_set_enabled(args.id, False)
        elif args.cron_command == "rm":
            cron_rm(args.id)
        elif args.cron_command == "run":
            cron_run(args.id)
        elif args.cron_command == "due":
            cron_due()
        elif args.cron_command == "runs":
            cron_runs(args.id)

    elif args.command == "chat":
        try:
            from soi.tui import run_chat_tui
        except ImportError as exc:
            print("❌ Le TUI avancé nécessite la dépendance `textual`.")
            print("Installe-la avec : python3 -m pip install -e .")
            print(f"Détail import : {exc}")
            sys.exit(1)
        config = load_llm_config()
        run_chat_tui(agent_name=args.agent, mode=args.mode or config_default_mode(config))

    elif args.command == "models":
        print_models_status()

    elif args.command == "create-tool":
        create_tool(
            name=args.name,
            purpose=args.purpose,
            agent_name=args.agent,
            language=args.language,
        )

    elif args.command == "create-tool-as-agent":
        create_tool_as_agent(
            name=args.name,
            purpose=args.purpose,
            agent_name=args.agent,
            language=args.language,
            code=args.code,
        )

    elif args.command == "approve-tool":
        approve_tool(args.name)

    elif args.command == "list-tools":
        list_custom_tools(status=args.status)

    elif args.command == "mcp-list":
        manager = MCPClientManager()
        try:
            connected, failed = manager.load_and_connect()
            print(f"Serveurs MCP connectés : {connected}, échecs : {failed}")
            for line in manager.status_lines():
                print(line)
        except MCPError as exc:
            print(f"❌ Erreur MCP : {exc}")
        finally:
            manager.disconnect_all()

    elif args.command == "mcp-test":
        manager = MCPClientManager()
        try:
            manager.load_and_connect()
            server = manager.servers.get(args.name)
            if not server:
                print(f"❌ Serveur MCP '{args.name}' non trouvé ou non activé.")
                sys.exit(1)
            tools = server.list_tools()
            print(f"✅ Serveur '{args.name}' connecté — {len(tools)} outil(s) :")
            for tool in tools:
                tname = tool.get("name", "?")
                tdesc = tool.get("description", "Pas de description.")
                print(f"  - {tname}: {tdesc}")
        except MCPError as exc:
            print(f"❌ Erreur MCP : {exc}")
            sys.exit(1)
        finally:
            manager.disconnect_all()

    elif args.command == "create-team":
        create_team(
            name=args.name,
            agents=args.agents,
            objective=args.objective,
            coordinator=args.coordinator,
        )

    elif args.command == "list-teams":
        list_teams()

    elif args.command == "show-team":
        show_team(args.name)

    elif args.command == "team-brief":
        team_brief(args.name, output_file=args.output)

    elif args.command == "team-run":
        result = run_team_objective(
            team=args.name,
            objective=args.objective,
            execute=args.execute,
            model=args.model,
            reasoning_effort=args.reasoning_effort,
        )
        print(result.content)
        print(f"\n💾 Run sauvegardé : {result.markdown_path.relative_to(ROOT)}")
        if result.error:
            print(f"⚠️ Erreur OpenRouter : {result.error}")

    elif args.command == "handoff":
        handoff(
            from_agent=args.from_agent,
            to_agent=args.to_agent,
            task=args.task,
            context=args.context,
            team=args.team,
        )

    elif args.command == "add-memory":
        add_memory(args.name, args.content, section=args.section)

    elif args.command == "memory-init":
        init_advanced_memory()

    elif args.command == "memory-capture":
        capture_memory(
            content=args.content,
            kind=args.kind,
            source=args.source,
            confidence=args.confidence,
            links=args.links,
            agent_name=args.agent,
        )

    elif args.command == "memory-link":
        link_memory(args.source, args.target, relation=args.relation)

    elif args.command == "memory-user-model":
        build_user_model(output_file=args.output)

    elif args.command == "memory-brief":
        build_adaptive_brief(args.name, output_file=args.output)

    elif args.command == "add-task":
        add_task(args.name, args.title, status=args.status)

    elif args.command == "complete-task":
        complete_task(args.name, args.title)

    elif args.command == "update-task":
        update_task_status(args.name, args.title, args.status)

    elif args.command == "show-agent":
        show_agent(args.name)

    elif args.command == "list-agents":
        list_agents()

    elif args.command == "log":
        log(
            agent_name=args.name,
            action=args.action,
            decision=args.decision,
            file_modified=args.file_modified,
            summary=args.summary,
        )

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
