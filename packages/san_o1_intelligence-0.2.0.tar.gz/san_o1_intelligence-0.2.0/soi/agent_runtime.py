"""Runtime agentique commun pour le TUI, Telegram et futurs connecteurs."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Dict, List, Mapping, Optional

from soi.conversation import ConversationStore, build_chat_messages
from soi.mcp_client import MCPClientManager, MCPError, MCPPermanentError, MCPTransientError, parse_mcp_tool_call
from soi.model_policy import ModelDecision, adaptive_max_tokens, choose_model, configured_model_policy
from soi.openrouter_client import ChatResponse, OpenRouterClient, OpenRouterError, config_default_mode, load_llm_config
from soi.tool_parser import has_tool_calls, parse_custom_tool_calls, parse_mcp_tool_calls
from soi.tooling import _load_registry, execute_custom_tool
from soi.workspace import ROOT, normalize_agent_name


RISKY_MCP_TOOLS = {
    "write_file",
    "edit_block",
    "move_file",
    "delete_file",
    "remove_file",
    "start_process",
    "force_terminate",
    "kill_process",
}

CORE_MODIFY_TOOLS = {"write_file", "edit_block"}


@dataclass
class PendingAction:
    """Action en attente d'une confirmation utilisateur."""

    kind: str
    content: str = ""
    mode: str = "free"
    model: str = ""
    reason: str = ""
    server_name: str = ""
    tool_name: str = ""
    arguments: Optional[Dict[str, object]] = None

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> "PendingAction":
        arguments = data.get("arguments")
        return cls(
            kind=str(data.get("kind") or ""),
            content=str(data.get("content") or ""),
            mode=str(data.get("mode") or "free"),
            model=str(data.get("model") or ""),
            reason=str(data.get("reason") or ""),
            server_name=str(data.get("server_name") or ""),
            tool_name=str(data.get("tool_name") or ""),
            arguments=arguments if isinstance(arguments, dict) else {},
        )


@dataclass
class AgentRuntimeResult:
    """Réponse uniforme prête pour TUI ou connecteur externe."""

    content: str
    mode: str
    model: str
    session_id: str
    usage: Dict[str, object]
    local_only: bool = False
    error: bool = False
    confirmation_required: bool = False
    confirmation_kind: str = ""
    confirmation_token: str = ""
    pending_action: Optional[PendingAction] = None
    tool_executed: str = ""
    verification: str = ""
    model_reason: str = ""
    autonomy_mode: str = "safe_agent"
    loop_iterations: int = 0


class AgentExecutionRuntime:
    """Boucle observe -> décide -> agit -> vérifie -> synthétise."""

    def __init__(
        self,
        agent_name: str = "assistant",
        mode: Optional[str] = None,
        session_id: Optional[str] = None,
        root: Path = ROOT,
        config: Optional[Mapping[str, object]] = None,
        client: Optional[OpenRouterClient] = None,
        mcp_manager: Optional[MCPClientManager] = None,
        autonomy_mode: str = "safe_agent",
        pending_action: Optional[PendingAction] = None,
    ):
        self.root = root
        self.agent_name = normalize_agent_name(agent_name)
        self.config = dict(config or load_llm_config(root=root))
        self.mode = self._normalize_mode(mode or config_default_mode(self.config))
        self.store = ConversationStore(self.agent_name, session_id=session_id, root=root)
        self.client = client or OpenRouterClient(config=self.config)
        self.mcp_manager = mcp_manager or MCPClientManager()
        self.autonomy_mode = self._normalize_autonomy(autonomy_mode)
        self.pending_action = pending_action
        self.last_model_decision: Optional[ModelDecision] = None
        self._mcp_connected = False
        self._loop_iterations_used = 0
        self._loop_tokens_used = 0

    @staticmethod
    def _normalize_mode(mode: str) -> str:
        normalized = mode.strip().lower()
        return normalized if normalized in {"free", "paid"} else "free"

    @staticmethod
    def _normalize_autonomy(mode: str) -> str:
        normalized = mode.strip().lower()
        return normalized if normalized in {"conversation", "agent", "safe_agent"} else "safe_agent"

    @property
    def model_policy(self) -> str:
        return configured_model_policy(self.config)

    def policy_status(self) -> str:
        decision = self.last_model_decision
        reason = decision.reason if decision else "aucune décision encore prise"
        mode = decision.mode if decision else self.mode
        model = decision.model if decision else ""
        pending = self.pending_action.kind if self.pending_action else "aucune"
        return (
            f"Politique modèle : {self.model_policy}\n"
            f"Mode courant : {mode}\n"
            f"Modèle courant : {model or 'non résolu'}\n"
            f"Raison : {reason}\n"
            f"Autonomie : {self.autonomy_mode}\n"
            f"Action en attente : {pending}"
        )

    def ensure_mcp(self) -> None:
        if not self._mcp_connected:
            try:
                self.mcp_manager.load_and_connect()
                self._mcp_connected = True
            except Exception:
                self._mcp_connected = False

    def close(self) -> None:
        self.mcp_manager.disconnect_all()
        self._mcp_connected = False

    def ask(
        self,
        content: str,
        *,
        allow_paid: bool = False,
        history_limit: Optional[int] = None,
    ) -> AgentRuntimeResult:
        clean_content = content.strip()
        if not clean_content:
            return self._local_reply("Message vide.", mode=self.mode, model="", error=True)

        decision = choose_model(
            self.config,
            clean_content,
            requested_mode=self.mode,
            autonomy_mode=self.autonomy_mode,
        )
        self.last_model_decision = decision
        self.store.append("user", clean_content, mode=decision.mode, model=decision.model)

        if not self.client.has_api_key:
            return self._local_reply(
                "OPENROUTER_API_KEY est absent. Je peux enregistrer la conversation et lire le contexte local, mais pas appeler OpenRouter.",
                mode="local",
                model="",
                error=True,
            )

        if decision.mode == "paid" and decision.requires_confirmation and not allow_paid:
            return self._require_paid_confirmation(clean_content, decision)

        return self._agent_loop(
            clean_content,
            decision=decision,
            history_limit=history_limit,
            allow_paid=allow_paid,
        )

    def confirm_pending(
        self,
        *,
        allow_paid: bool = False,
        history_limit: Optional[int] = None,
    ) -> AgentRuntimeResult:
        pending = self.pending_action
        if pending is None:
            return self._local_reply("Aucune action en attente.", mode=self.mode, model="", error=True)

        self.pending_action = None
        if pending.kind == "paid":
            if not allow_paid:
                self.pending_action = pending
                return self._local_reply(
                    "Confirmation payante refusée par la configuration du canal.",
                    mode="local",
                    model=pending.model,
                    error=True,
                )
            decision = ModelDecision(
                mode="paid",
                model=pending.model,
                reason=pending.reason or "confirmation utilisateur",
                requires_confirmation=False,
            )
            self.last_model_decision = decision
            return self._agent_loop(
                pending.content,
                decision=decision,
                history_limit=history_limit,
                allow_paid=True,
            )

        if pending.kind == "mcp":
            return self._run_mcp_single(
                pending.server_name,
                pending.tool_name,
                pending.arguments or {},
                mode=pending.mode,
                model=pending.model,
                history_limit=history_limit,
            )

        return self._local_reply("Action en attente inconnue.", mode="local", model="", error=True)

    def _require_paid_confirmation(self, content: str, decision: ModelDecision) -> AgentRuntimeResult:
        pending = PendingAction(
            kind="paid",
            content=content,
            mode=decision.mode,
            model=decision.model,
            reason=decision.reason,
        )
        self.pending_action = pending
        message = (
            "Cette demande mérite le modèle payant selon la politique auto_prudent.\n\n"
            f"Raison : {decision.reason}\n"
            f"Modèle proposé : {decision.model}\n\n"
            "Confirme pour lancer l'appel payant, ou repasse en mode free pour rester gratuit."
        )
        self.store.append("assistant", message, mode="local", model=decision.model, usage={})
        return AgentRuntimeResult(
            content=message,
            mode="local",
            model=decision.model,
            session_id=self.store.session_id,
            usage={},
            local_only=True,
            confirmation_required=True,
            confirmation_kind="paid",
            confirmation_token="confirm",
            pending_action=pending,
            model_reason=decision.reason,
            autonomy_mode=self.autonomy_mode,
        )

    def _agent_loop(
        self,
        initial_content: str,
        *,
        decision: ModelDecision,
        history_limit: Optional[int],
        allow_paid: bool,
    ) -> AgentRuntimeResult:
        """Boucle agentique multi-tours : observe -> décide -> agit -> vérifie -> synthétise."""
        max_iterations = int(self.config.get("agent_loop_max_iterations", 10))
        token_budget = int(self.config.get("agent_loop_token_budget", 12000))

        iteration = 0
        current_content = initial_content
        total_usage: Dict[str, object] = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

        while iteration < max_iterations:
            iteration += 1
            self._loop_iterations_used = iteration

            # Vérifier budget tokens
            if self._loop_tokens_used >= token_budget:
                return self._max_iterations_reached(
                    iteration, total_usage, reason="budget tokens épuisé"
                )

            # Construire messages
            self.ensure_mcp()
            limit = int(history_limit if history_limit is not None else self.config.get("history_limit", 30))
            agent_mode_enabled = self.autonomy_mode in {"agent", "safe_agent"}
            messages = build_chat_messages(
                self.agent_name,
                current_content,
                history_limit=limit,
                root=self.root,
                mcp_manager=self.mcp_manager,
                agent_mode_enabled=agent_mode_enabled,
            )

            max_tokens = adaptive_max_tokens(self.config, iteration=iteration)

            # Appeler LLM
            try:
                response = self.client.chat(
                    messages,
                    mode=decision.mode,
                    model=decision.model,
                    session_id=self.store.session_id,
                    max_tokens=max_tokens,
                )
            except OpenRouterError as exc:
                if decision.mode == "free":
                    paid = choose_model(
                        self.config,
                        initial_content,
                        requested_mode="free",
                        autonomy_mode=self.autonomy_mode,
                        free_failed=True,
                    )
                    self.last_model_decision = paid
                    return self._require_paid_confirmation(initial_content, paid)
                return self._local_reply(str(exc), mode=decision.mode, model=decision.model, error=True)
            except Exception as exc:
                return self._local_reply(
                    f"Erreur locale pendant l'appel OpenRouter : {exc}",
                    mode=decision.mode,
                    model=decision.model,
                    error=True,
                )

            # Accumuler usage
            for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
                total_usage[key] = total_usage.get(key, 0) + response.usage.get(key, 0)
            self._loop_tokens_used = total_usage.get("total_tokens", 0)

            # Mode conversation ou pas de tool calls → réponse finale
            if self.autonomy_mode == "conversation" or not has_tool_calls(response.content):
                self.store.append("assistant", response.content, mode=decision.mode, model=response.model, usage=response.usage)
                return AgentRuntimeResult(
                    content=response.content,
                    mode=decision.mode,
                    model=response.model,
                    session_id=self.store.session_id,
                    usage=dict(total_usage),
                    model_reason=decision.reason,
                    autonomy_mode=self.autonomy_mode,
                    loop_iterations=iteration,
                )

            # Parser les tool calls
            mcp_calls = parse_mcp_tool_calls(response.content)
            custom_calls = parse_custom_tool_calls(response.content)

            # Enregistrer la réponse de l'assistant
            self.store.append("assistant", response.content, mode=decision.mode, model=response.model, usage=response.usage)

            # Exécuter les outils
            observations: List[Dict[str, object]] = []

            for server_name, tool_name, arguments in mcp_calls:
                if self._needs_confirmation(server_name, tool_name, arguments):
                    pending = PendingAction(
                        kind="mcp",
                        mode=decision.mode,
                        model=response.model,
                        reason=f"outil MCP risqué : {server_name}/{tool_name}",
                        server_name=server_name,
                        tool_name=tool_name,
                        arguments=arguments,
                    )
                    self.pending_action = pending
                    message = (
                        f"Action locale à confirmer : {server_name}/{tool_name}\n\n"
                        f"Arguments :\n{json.dumps(arguments, ensure_ascii=False, indent=2)}\n\n"
                        "Confirme pour exécuter, ou ignore pour annuler."
                    )
                    self.store.append("assistant", message, mode="local", model=response.model, usage={})
                    return AgentRuntimeResult(
                        content=message,
                        mode="local",
                        model=response.model,
                        session_id=self.store.session_id,
                        usage=dict(total_usage),
                        local_only=True,
                        confirmation_required=True,
                        confirmation_kind="mcp",
                        confirmation_token="confirm",
                        pending_action=pending,
                        model_reason=decision.reason,
                        autonomy_mode=self.autonomy_mode,
                        loop_iterations=iteration,
                    )

                result_text = self._execute_mcp_tool(server_name, tool_name, arguments)
                is_error = result_text.startswith("ERREUR")
                observations.append({
                    "type": "mcp",
                    "server": server_name,
                    "tool": tool_name,
                    "status": "error" if is_error else "success",
                    "result": result_text,
                    "retryable": "TRANSIENTE" in result_text,
                })

            for tool_name, arguments in custom_calls:
                if self.autonomy_mode == "safe_agent" and self._is_draft_tool(tool_name):
                    pending = PendingAction(
                        kind="mcp",
                        mode=decision.mode,
                        model=response.model,
                        reason=f"outil custom brouillon : {tool_name}",
                        server_name="custom",
                        tool_name=tool_name,
                        arguments=arguments,
                    )
                    self.pending_action = pending
                    message = (
                        f"Outil custom brouillon à confirmer : {tool_name}\n\n"
                        f"Arguments :\n{json.dumps(arguments, ensure_ascii=False, indent=2)}\n\n"
                        "Confirme pour exécuter, ou ignore pour annuler."
                    )
                    self.store.append("assistant", message, mode="local", model=response.model, usage={})
                    return AgentRuntimeResult(
                        content=message,
                        mode="local",
                        model=response.model,
                        session_id=self.store.session_id,
                        usage=dict(total_usage),
                        local_only=True,
                        confirmation_required=True,
                        confirmation_kind="mcp",
                        confirmation_token="confirm",
                        pending_action=pending,
                        model_reason=decision.reason,
                        autonomy_mode=self.autonomy_mode,
                        loop_iterations=iteration,
                    )

                try:
                    result = execute_custom_tool(tool_name, arguments)
                    observations.append({
                        "type": "custom",
                        "tool": tool_name,
                        "status": "success",
                        "result": result,
                    })
                except Exception as exc:
                    observations.append({
                        "type": "custom",
                        "tool": tool_name,
                        "status": "error",
                        "result": f"ERREUR: {exc}",
                    })

            # Construire observation et continuer la boucle
            observation = self._build_observation_message(iteration, max_iterations, observations)
            self.store.append("user", observation, mode="tool", model="agent-loop", usage={})
            current_content = observation

        # Max iterations atteint
        return self._max_iterations_reached(iteration, total_usage)

    def _execute_mcp_tool(self, server_name: str, tool_name: str, arguments: Dict[str, object]) -> str:
        """Exécute un outil MCP avec gestion d'erreur structurée."""
        self.ensure_mcp()
        try:
            raw = self.mcp_manager.call_tool(server_name, tool_name, arguments)
            return json.dumps(raw, ensure_ascii=False, indent=2)
        except MCPTransientError as exc:
            return f"ERREUR TRANSIENTE (retry épuisé): {exc}"
        except MCPPermanentError as exc:
            return f"ERREUR PERMANENTE: {exc}"
        except MCPError as exc:
            return f"ERREUR MCP: {exc}"
        except Exception as exc:
            return f"ERREUR INATTENDUE: {exc}"

    def _build_observation_message(
        self,
        iteration: int,
        max_iterations: int,
        observations: List[Dict[str, object]],
    ) -> str:
        """Construit le message d'observation structuré pour le LLM."""
        lines = [
            f"=== Résultats des outils — Itération {iteration}/{max_iterations} ===",
            "",
        ]
        for obs in observations:
            obs_type = obs.get("type")
            if obs_type == "mcp":
                lines.append(f"[{obs['server']}/{obs['tool']}]")
            else:
                lines.append(f"[custom/{obs['tool']}]")

            status = obs.get("status")
            result = str(obs.get("result", ""))
            if status == "success":
                lines.append("  ✅ Succès")
                # Tronquer les résultats très longs
                if len(result) > 2000:
                    result = result[:2000] + f"\n... [tronqué, {len(result)} caractères au total]"
                lines.append(f"  Résultat: {result}")
            else:
                lines.append("  ❌ Erreur")
                retryable = obs.get("retryable", False)
                lines.append(f"  Type: {'Transitoire (retry épuisé)' if retryable else 'Permanente'}")
                lines.append(f"  Détail: {result}")
                lines.append("  Suggestion: corrige les arguments ou choisis un outil alternatif.")
            lines.append("")

        lines.append("=== Fin des résultats ===")
        lines.append("")
        lines.append("Tu peux maintenant :")
        lines.append("- Invoquer d'autres outils si nécessaire")
        lines.append("- Synthétiser pour l'utilisateur")
        lines.append("- Réévaluer ta planification si un résultat est inattendu")
        return "\n".join(lines)

    def _needs_confirmation(
        self,
        server_name: str,
        tool_name: str,
        arguments: Optional[Dict[str, object]] = None,
    ) -> bool:
        """Détermine si un appel MCP nécessite confirmation utilisateur."""
        if self.autonomy_mode != "safe_agent":
            return False
        if tool_name in RISKY_MCP_TOOLS:
            return True
        if tool_name in CORE_MODIFY_TOOLS and arguments:
            path = str(arguments.get("path") or arguments.get("file_path") or "")
            if self._is_core_path(path):
                return True
        return False

    def _is_core_path(self, path: str) -> bool:
        """Vérifie si un chemin cible le répertoire core soi/."""
        if not path:
            return False
        try:
            resolved = (self.root / path).resolve()
            core_dir = (self.root / "soi").resolve()
            return str(resolved).startswith(str(core_dir))
        except Exception:
            return False

    @staticmethod
    def _is_draft_tool(tool_name: str) -> bool:
        """Vérifie si un outil custom est au statut brouillon."""
        registry = _load_registry()
        tool = next((t for t in registry.get("tools", []) if t.get("name") == tool_name), None)
        return tool is not None and tool.get("status") != "approved"

    def _max_iterations_reached(
        self,
        iteration: int,
        usage: Dict[str, object],
        reason: str = "max itérations atteint",
    ) -> AgentRuntimeResult:
        message = (
            f"⚠️ Limite atteinte : {reason} ({iteration} itérations).\n\n"
            "Résumé de ce qui a été fait :\n"
            "- L'agent a exécuté plusieurs outils en boucle.\n"
            "- La limite de sécurité a été atteinte.\n\n"
            "Prochaine étape suggérée : confirme pour continuer, ou reformule la demande en plus petites étapes."
        )
        self.store.append("assistant", message, mode="local", model="", usage={})
        return AgentRuntimeResult(
            content=message,
            mode="local",
            model="",
            session_id=self.store.session_id,
            usage=dict(usage),
            local_only=True,
            model_reason=reason,
            autonomy_mode=self.autonomy_mode,
            loop_iterations=iteration,
        )

    def _run_mcp_single(
        self,
        server_name: str,
        tool_name: str,
        arguments: Dict[str, object],
        *,
        mode: str,
        model: str,
        history_limit: Optional[int],
    ) -> AgentRuntimeResult:
        """Exécute un seul outil MCP (utilisé par confirm_pending)."""
        self.ensure_mcp()
        result_text = self._execute_mcp_tool(server_name, tool_name, arguments)

        tool_message = (
            f"Résultat de l'outil MCP {server_name}/{tool_name} :\n\n"
            f"{result_text}\n\n"
            "Synthétise pour l'utilisateur ce qui a été fait, cite la preuve locale disponible, "
            "et indique la vérification ou la limite restante."
        )
        self.store.append("user", tool_message, mode="tool", model=f"mcp-{server_name}", usage={})
        if not self.client.has_api_key:
            return self._local_reply(result_text, mode="tool", model=f"mcp-{server_name}")

        limit = int(history_limit if history_limit is not None else self.config.get("history_limit", 30))
        messages = build_chat_messages(
            self.agent_name,
            tool_message,
            history_limit=limit,
            root=self.root,
            mcp_manager=self.mcp_manager,
            agent_mode_enabled=self.autonomy_mode in {"agent", "safe_agent"},
        )
        try:
            response = self.client.chat(messages, mode=mode, model=model, session_id=self.store.session_id)
        except OpenRouterError as exc:
            return self._local_reply(str(exc), mode=mode, model=model, error=True)
        except Exception as exc:
            return self._local_reply(f"Erreur locale pendant l'appel OpenRouter : {exc}", mode=mode, model=model, error=True)

        self.store.append("assistant", response.content, mode=mode, model=response.model, usage=response.usage)
        return AgentRuntimeResult(
            content=response.content,
            mode=mode,
            model=response.model,
            session_id=self.store.session_id,
            usage=response.usage,
            tool_executed=f"{server_name}/{tool_name}",
            verification="résultat MCP réinjecté dans la synthèse",
            autonomy_mode=self.autonomy_mode,
        )

    def _local_reply(self, content: str, *, mode: str, model: str, error: bool = False) -> AgentRuntimeResult:
        self.store.append("assistant", content, mode=mode, model=model, usage={})
        return AgentRuntimeResult(
            content=content,
            mode=mode,
            model=model,
            session_id=self.store.session_id,
            usage={},
            local_only=True,
            error=error,
            autonomy_mode=self.autonomy_mode,
        )
