"""Tests unitaires pour le client MCP minimal de SOI."""

import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

# Ajoute le projet au PYTHONPATH
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from soi.mcp_client import (
    MCPClientManager,
    MCPError,
    MCPServerStdio,
    parse_mcp_tool_call,
)


FAKE_SERVER = PROJECT_ROOT / "tests" / "fake_mcp_server.py"


class TestParseMcpToolCall(unittest.TestCase):
    def test_no_call(self):
        self.assertIsNone(parse_mcp_tool_call("Rien du tout"))

    def test_simple_call(self):
        text = 'bla <TOOL_MCP:fs:read>{"path": "/tmp"}</TOOL_MCP> fin'
        result = parse_mcp_tool_call(text)
        self.assertIsNotNone(result)
        self.assertEqual(result[0], "fs")
        self.assertEqual(result[1], "read")
        self.assertEqual(result[2], {"path": "/tmp"})

    def test_multiline_call(self):
        text = """<TOOL_MCP:math:add>{
  "a": 1,
  "b": 2
}</TOOL_MCP>"""
        result = parse_mcp_tool_call(text)
        self.assertIsNotNone(result)
        self.assertEqual(result[2], {"a": 1, "b": 2})


class TestMCPServerStdio(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not FAKE_SERVER.exists():
            raise unittest.SkipTest("Serveur factice introuvable")

    def test_connect_and_list_tools(self):
        server = MCPServerStdio("fake", sys.executable or "python3", [str(FAKE_SERVER)])
        try:
            self.assertTrue(server.connect())
            tools = server.list_tools()
            self.assertEqual(len(tools), 1)
            self.assertEqual(tools[0]["name"], "echo")
        finally:
            server.disconnect()

    def test_call_tool(self):
        server = MCPServerStdio("fake", sys.executable or "python3", [str(FAKE_SERVER)])
        try:
            server.connect()
            result = server.call_tool("echo", {"message": "hello"})
            self.assertIn("content", result)
        finally:
            server.disconnect()

    def test_disconnect_idempotent(self):
        server = MCPServerStdio("fake", sys.executable or "python3", [str(FAKE_SERVER)])
        server.disconnect()  # Ne doit pas planter si jamais connecté


class TestMCPClientManager(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.config_path = Path(self.tmpdir.name) / "mcp.config.json"

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_empty_config(self):
        self.config_path.write_text(json.dumps({"servers": []}), encoding="utf-8")
        mgr = MCPClientManager(config_path=self.config_path)
        connected, failed = mgr.load_and_connect()
        self.assertEqual(connected, 0)
        self.assertEqual(failed, 0)
        mgr.disconnect_all()

    def test_disabled_server(self):
        cfg = {
            "servers": [
                {
                    "name": "fake",
                    "enabled": False,
                    "transport": "stdio",
                    "command": "python3",
                    "args": [str(FAKE_SERVER)],
                }
            ]
        }
        self.config_path.write_text(json.dumps(cfg), encoding="utf-8")
        mgr = MCPClientManager(config_path=self.config_path)
        connected, failed = mgr.load_and_connect()
        self.assertEqual(connected, 0)
        self.assertEqual(failed, 0)
        mgr.disconnect_all()

    def test_tools_text_empty(self):
        mgr = MCPClientManager(config_path=self.config_path)
        text = mgr.tools_text_for_prompt()
        self.assertEqual(text, "")


if __name__ == "__main__":
    unittest.main()
