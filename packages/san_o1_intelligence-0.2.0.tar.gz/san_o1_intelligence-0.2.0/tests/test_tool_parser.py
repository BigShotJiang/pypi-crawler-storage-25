"""Tests du parser multi-outils."""

from soi.tool_parser import has_tool_calls, parse_custom_tool_calls, parse_mcp_tool_calls, strip_tool_calls


def test_parse_single_mcp_call():
    text = '<TOOL_MCP:desktop-commander:read_file>{"path": "/tmp/test.txt"}</TOOL_MCP>'
    calls = parse_mcp_tool_calls(text)
    assert len(calls) == 1
    assert calls[0] == ("desktop-commander", "read_file", {"path": "/tmp/test.txt"})


def test_parse_multiple_mcp_calls():
    text = (
        'Premier appel : <TOOL_MCP:fs:read_file>{"path": "/a.txt"}</TOOL_MCP>\n'
        'Deuxième appel : <TOOL_MCP:fs:write_file>{"path": "/b.txt", "content": "hello"}</TOOL_MCP>'
    )
    calls = parse_mcp_tool_calls(text)
    assert len(calls) == 2
    assert calls[0] == ("fs", "read_file", {"path": "/a.txt"})
    assert calls[1] == ("fs", "write_file", {"path": "/b.txt", "content": "hello"})


def test_parse_no_mcp_call():
    assert parse_mcp_tool_calls("Juste du texte") == []


def test_parse_mcp_invalid_json():
    text = '<TOOL_MCP:fs:read_file>{invalid json}</TOOL_MCP>'
    calls = parse_mcp_tool_calls(text)
    assert len(calls) == 1
    assert calls[0][2] == {}  # fallback to empty dict


def test_parse_single_custom_call():
    text = '<TOOL_CUSTOM:web-search>{"query": "python"}</TOOL_CUSTOM>'
    calls = parse_custom_tool_calls(text)
    assert len(calls) == 1
    assert calls[0] == ("web-search", {"query": "python"})


def test_parse_multiple_custom_calls():
    text = (
        '<TOOL_CUSTOM:web-search>{"query": "a"}</TOOL_CUSTOM>\n'
        '<TOOL_CUSTOM:daily-journal>{}</TOOL_CUSTOM>'
    )
    calls = parse_custom_tool_calls(text)
    assert len(calls) == 2


def test_has_tool_calls_mcp():
    assert has_tool_calls("<TOOL_MCP:x:y>{}</TOOL_MCP>") is True


def test_has_tool_calls_custom():
    assert has_tool_calls("<TOOL_CUSTOM:x>{}</TOOL_CUSTOM>") is True


def test_has_tool_calls_none():
    assert has_tool_calls("Pas d'outil ici") is False


def test_strip_tool_calls():
    text = 'Voici <TOOL_MCP:fs:read_file>{}</TOOL_MCP> et <TOOL_CUSTOM:x>{}</TOOL_CUSTOM> fin'
    stripped = strip_tool_calls(text)
    assert "TOOL_MCP" not in stripped
    assert "TOOL_CUSTOM" not in stripped
    assert "Voici" in stripped
    assert "fin" in stripped
