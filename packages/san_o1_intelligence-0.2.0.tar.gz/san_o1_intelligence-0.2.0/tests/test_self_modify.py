"""Tests de l'auto-modification sécurisée."""

from pathlib import Path

from soi.self_modify import SelfModifier


def test_is_core_file(tmp_path: Path):
    modifier = SelfModifier(root=tmp_path)
    (tmp_path / "soi").mkdir()
    (tmp_path / "soi" / "agent.py").write_text("pass")
    assert modifier.is_core_file("soi/agent.py") is True
    assert modifier.is_core_file("tools/custom/x/run.py") is False


def test_validate_python_ok():
    modifier = SelfModifier()
    result = modifier.validate_python("x = 1\nprint(x)")
    assert result.success is True
    assert result.validation_errors == []


def test_validate_python_syntax_error():
    modifier = SelfModifier()
    result = modifier.validate_python("def foo(\n")
    assert result.success is False
    assert any("SyntaxError" in e for e in result.validation_errors)


def test_modify_and_rollback(tmp_path: Path):
    modifier = SelfModifier(root=tmp_path)
    (tmp_path / "soi").mkdir()
    target = tmp_path / "soi" / "test_module.py"
    target.write_text("x = 1\n")

    result = modifier.modify_file("soi/test_module.py", "x = 2\n")
    assert result.success is True
    assert "modifié avec succès" in result.message
    assert target.read_text() == "x = 2\n"


def test_modify_invalid_syntax_rollback(tmp_path: Path):
    modifier = SelfModifier(root=tmp_path)
    (tmp_path / "soi").mkdir()
    target = tmp_path / "soi" / "test_module.py"
    target.write_text("x = 1\n")

    result = modifier.modify_file("soi/test_module.py", "def foo(\n")
    assert result.success is False
    assert "rollback" in result.message.lower() or "Validation" in result.message
    # Le fichier original doit être restauré
    assert target.read_text() == "x = 1\n"


def test_modify_outside_workspace(tmp_path: Path):
    modifier = SelfModifier(root=tmp_path)
    result = modifier.modify_file("/etc/passwd", "hack")
    assert result.success is False
    assert "hors du workspace" in result.message or "introuvable" in result.message
