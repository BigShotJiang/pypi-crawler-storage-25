"""Tests du retry MCP avec backoff."""

import time
from unittest.mock import MagicMock

from soi.mcp_client import (
    MCPError,
    MCPPermanentError,
    MCPTransientError,
    classify_mcp_error,
    retry_mcp,
)


def test_classify_timeout():
    err = classify_mcp_error(MCPError("Timeout (30s) sur read_file"))
    assert isinstance(err, MCPTransientError)


def test_classify_broken_pipe():
    err = classify_mcp_error(MCPError("Connexion MCP interrompue"))
    assert isinstance(err, MCPTransientError)


def test_classify_tool_not_found():
    err = classify_mcp_error(MCPError("Erreur MCP desktop-commander: outil inexistant"))
    assert isinstance(err, MCPPermanentError)


def test_retry_mcp_success_first():
    call_count = 0

    @retry_mcp(max_retries=2, backoff=(0.01, 0.02))
    def stable():
        nonlocal call_count
        call_count += 1
        return "ok"

    assert stable() == "ok"
    assert call_count == 1


def test_retry_mcp_eventual_success():
    call_count = 0

    @retry_mcp(max_retries=3, backoff=(0.01, 0.02, 0.04))
    def flaky():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise MCPTransientError("timeout")
        return "ok"

    assert flaky() == "ok"
    assert call_count == 3


def test_retry_mcp_exhausted():
    call_count = 0

    @retry_mcp(max_retries=2, backoff=(0.01, 0.02))
    def always_fail():
        nonlocal call_count
        call_count += 1
        raise MCPTransientError("timeout")

    try:
        always_fail()
        assert False, "Should have raised"
    except MCPError:
        pass
    assert call_count == 3  # initial + 2 retries


def test_retry_mcp_permanent_no_retry():
    call_count = 0

    @retry_mcp(max_retries=3, backoff=(0.01, 0.02, 0.04))
    def permanent_fail():
        nonlocal call_count
        call_count += 1
        raise MCPPermanentError("outil inexistant")

    try:
        permanent_fail()
        assert False, "Should have raised"
    except MCPPermanentError:
        pass
    assert call_count == 1  # no retries for permanent errors
