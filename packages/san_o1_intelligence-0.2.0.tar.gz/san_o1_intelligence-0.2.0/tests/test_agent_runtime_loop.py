"""Tests de la boucle agentique multi-tours."""

from unittest.mock import MagicMock, patch

from soi.agent_runtime import AgentExecutionRuntime, AgentRuntimeResult, PendingAction
from soi.model_policy import ModelDecision


def test_agent_loop_no_tool_calls():
    """Scénario : le LLM répond directement sans outil."""
    runtime = AgentExecutionRuntime(agent_name="test", autonomy_mode="agent")
    runtime.client = MagicMock()
    runtime.client.has_api_key = True
    runtime.client.chat.return_value = MagicMock(
        content="Réponse simple sans outil.",
        model="test-model",
        usage={"total_tokens": 10},
    )

    with patch("soi.agent_runtime.build_chat_messages", return_value=[]):
        result = runtime._agent_loop(
            "Hello",
            decision=ModelDecision(mode="free", model="test", reason="test"),
            history_limit=10,
            allow_paid=False,
        )

    assert isinstance(result, AgentRuntimeResult)
    assert result.content == "Réponse simple sans outil."
    assert result.loop_iterations == 1


def test_agent_loop_single_mcp_call():
    """Scénario : le LLM appelle un outil MCP, puis synthétise."""
    runtime = AgentExecutionRuntime(agent_name="test", autonomy_mode="agent")
    runtime.client = MagicMock()
    runtime.client.has_api_key = True

    # Premier appel : l'agent décide d'appeler un outil
    response1 = MagicMock(
        content='<TOOL_MCP:fs:read_file>{"path": "/tmp/test.txt"}</TOOL_MCP>',
        model="test-model",
        usage={"total_tokens": 20},
    )
    # Deuxième appel : synthèse après résultat
    response2 = MagicMock(
        content="Contenu du fichier : hello world",
        model="test-model",
        usage={"total_tokens": 15},
    )
    runtime.client.chat.side_effect = [response1, response2]

    runtime.mcp_manager = MagicMock()
    runtime.mcp_manager.call_tool.return_value = {"content": "hello world"}

    with patch("soi.agent_runtime.build_chat_messages", return_value=[]):
        result = runtime._agent_loop(
            "Lis le fichier",
            decision=ModelDecision(mode="free", model="test", reason="test"),
            history_limit=10,
            allow_paid=False,
        )

    assert isinstance(result, AgentRuntimeResult)
    assert "hello world" in result.content
    assert result.loop_iterations == 2


def test_agent_loop_max_iterations():
    """Scénario : l'agent atteint la limite d'itérations."""
    runtime = AgentExecutionRuntime(agent_name="test", autonomy_mode="agent")
    runtime.config["agent_loop_max_iterations"] = 2
    runtime.client = MagicMock()
    runtime.client.has_api_key = True

    # Toujours un appel d'outil
    response = MagicMock(
        content='<TOOL_MCP:fs:read_file>{"path": "/tmp/test.txt"}</TOOL_MCP>',
        model="test-model",
        usage={"total_tokens": 10},
    )
    runtime.client.chat.return_value = response

    runtime.mcp_manager = MagicMock()
    runtime.mcp_manager.call_tool.return_value = {"content": "x"}

    with patch("soi.agent_runtime.build_chat_messages", return_value=[]):
        result = runtime._agent_loop(
            "Boucle infinie simulée",
            decision=ModelDecision(mode="free", model="test", reason="test"),
            history_limit=10,
            allow_paid=False,
        )

    assert isinstance(result, AgentRuntimeResult)
    assert "Limite atteinte" in result.content
    assert result.loop_iterations == 2


def test_safe_agent_blocks_risky_tool():
    """Scénario : safe_agent bloque un outil risqué."""
    runtime = AgentExecutionRuntime(agent_name="test", autonomy_mode="safe_agent")
    runtime.client = MagicMock()
    runtime.client.has_api_key = True
    runtime.client.chat.return_value = MagicMock(
        content='<TOOL_MCP:fs:write_file>{"path": "/tmp/x", "content": "x"}</TOOL_MCP>',
        model="test-model",
        usage={"total_tokens": 10},
    )

    with patch("soi.agent_runtime.build_chat_messages", return_value=[]):
        result = runtime._agent_loop(
            "Écris un fichier",
            decision=ModelDecision(mode="free", model="test", reason="test"),
            history_limit=10,
            allow_paid=False,
        )

    assert isinstance(result, AgentRuntimeResult)
    assert result.confirmation_required is True
    assert result.pending_action is not None
    assert result.pending_action.tool_name == "write_file"


def test_is_core_path():
    """Vérifie que les chemins core sont bien détectés."""
    runtime = AgentExecutionRuntime(agent_name="test")
    assert runtime._is_core_path("soi/agent.py") is True
    assert runtime._is_core_path("tools/custom/x/run.py") is False
    assert runtime._is_core_path("") is False
