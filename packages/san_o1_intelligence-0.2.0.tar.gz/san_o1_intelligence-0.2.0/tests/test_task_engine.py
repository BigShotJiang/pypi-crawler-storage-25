"""Tests du moteur de tâches."""

from pathlib import Path

from soi.task_engine import TaskEngine


def test_load_empty_tasks(tmp_path: Path):
    engine = TaskEngine(root=tmp_path)
    board = engine.load_tasks("test-agent")
    assert board.tasks["TODO"] == []
    assert board.tasks["DONE"] == []


def test_add_and_load_task(tmp_path: Path):
    engine = TaskEngine(root=tmp_path)
    ok = engine.add_task("test-agent", "Faire les courses", status="TODO")
    assert ok is True

    board = engine.load_tasks("test-agent")
    assert len(board.tasks["TODO"]) == 1
    assert board.tasks["TODO"][0].title == "Faire les courses"


def test_update_status(tmp_path: Path):
    engine = TaskEngine(root=tmp_path)
    engine.add_task("test-agent", "Coder", status="TODO")
    board = engine.load_tasks("test-agent")
    task_id = board.tasks["TODO"][0].id

    ok = engine.update_status("test-agent", task_id, "DOING")
    assert ok is True


def test_get_next_action(tmp_path: Path):
    engine = TaskEngine(root=tmp_path)
    engine.add_task("test-agent", "Prioritaire", status="PRIORITY")
    engine.add_task("test-agent", "Normal", status="TODO")

    next_task = engine.get_next_action("test-agent")
    assert next_task is not None
    assert next_task.title == "Prioritaire"


def test_tasks_summary(tmp_path: Path):
    engine = TaskEngine(root=tmp_path)
    engine.add_task("test-agent", "A", status="TODO")
    engine.add_task("test-agent", "B", status="TODO")
    engine.add_task("test-agent", "C", status="DONE")

    summary = engine.tasks_summary("test-agent")
    assert summary["TODO"] == 2
    assert summary["DONE"] == 1
    assert summary["PRIORITY"] == 0
