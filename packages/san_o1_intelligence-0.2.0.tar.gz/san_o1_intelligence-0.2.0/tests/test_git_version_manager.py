import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "tools" / "custom" / "git-version-manager" / "run.py"


def load_module():
    spec = importlib.util.spec_from_file_location("git_version_manager", MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=root,
        text=True,
        capture_output=True,
        check=True,
    )


class GitVersionManagerTests(unittest.TestCase):
    def test_snapshot_commits_allowed_files_and_leaves_env_untracked(self):
        module = load_module()
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            git(repo, "init")
            git(repo, "config", "user.email", "test@example.local")
            git(repo, "config", "user.name", "SOI Test")

            (repo / "note.md").write_text("hello\n", encoding="utf-8")
            (repo / ".env").write_text("TOKEN=secret\n", encoding="utf-8")

            did_commit = module.commit_snapshot(
                root=repo,
                message="test snapshot",
                prefix="auto",
                extra_excludes=[],
                include_sensitive=False,
                dry_run=False,
            )

            self.assertTrue(did_commit)
            committed = git(repo, "show", "--name-only", "--pretty=format:", "HEAD").stdout.splitlines()
            self.assertEqual(committed, ["note.md"])
            status = git(repo, "status", "--porcelain=v1", "--untracked-files=all").stdout
            self.assertIn("?? .env", status)
            self.assertNotIn("note.md", status)

    def test_dry_run_does_not_create_commit(self):
        module = load_module()
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            git(repo, "init")
            git(repo, "config", "user.email", "test@example.local")
            git(repo, "config", "user.name", "SOI Test")
            (repo / "note.md").write_text("hello\n", encoding="utf-8")

            did_commit = module.commit_snapshot(
                root=repo,
                message=None,
                prefix="auto",
                extra_excludes=[],
                include_sensitive=False,
                dry_run=True,
            )

            self.assertFalse(did_commit)
            log = subprocess.run(["git", "log", "--oneline"], cwd=repo, text=True, capture_output=True)
            self.assertNotEqual(log.returncode, 0)


if __name__ == "__main__":
    unittest.main()
