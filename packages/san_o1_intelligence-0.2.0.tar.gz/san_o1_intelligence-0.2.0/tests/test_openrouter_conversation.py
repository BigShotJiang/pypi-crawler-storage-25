import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

import httpx

from soi.conversation import ConversationStore, build_chat_messages, recent_messages, summarize_tasks
from soi.agent_runtime import AgentExecutionRuntime, PendingAction
from soi.chat_runtime import AgentChatRuntime
from soi.model_policy import choose_model
from soi.openrouter_client import (
    OpenRouterClient,
    collect_stream_text,
    get_openrouter_api_key,
    load_llm_config,
    model_for_mode,
    models_status_lines,
    parse_openrouter_error,
    print_models_status,
    team_model,
)
from soi.team_runtime import build_team_messages, run_team_objective


class OpenRouterConfigTests(unittest.TestCase):
    def test_load_llm_config_creates_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = load_llm_config(root=root)

            self.assertEqual(config["default_mode"], "free")
            self.assertEqual(config["free_model"], "openrouter/free")
            self.assertEqual(config["paid_model"], "openrouter/auto")
            self.assertEqual(config["team_model"], "x-ai/grok-4.20-multi-agent")
            self.assertTrue((root / "config" / "llm.config.json").exists())

    def test_model_for_mode(self):
        config = {"free_model": "openrouter/free", "paid_model": "openrouter/auto"}

        self.assertEqual(model_for_mode(config, "free"), "openrouter/free")
        self.assertEqual(model_for_mode(config, "paid"), "openrouter/auto")
        self.assertEqual(team_model({"team_model": "x-ai/grok-4.20-multi-agent"}), "x-ai/grok-4.20-multi-agent")
        with self.assertRaises(ValueError):
            model_for_mode(config, "scan")

    def test_auto_prudent_uses_free_for_simple_prompt(self):
        config = {
            "model_policy": "auto_prudent",
            "free_model": "openrouter/free",
            "paid_model": "openrouter/auto",
        }

        decision = choose_model(config, "Salut, resume ma journee simplement.")

        self.assertEqual(decision.mode, "free")
        self.assertFalse(decision.requires_confirmation)

    def test_auto_prudent_escalates_complex_agentic_prompt(self):
        config = {
            "model_policy": "auto_prudent",
            "free_model": "openrouter/free",
            "paid_model": "openrouter/auto",
        }

        decision = choose_model(config, "Implémente le mode agent dans Telegram et ajoute les tests.")

        self.assertEqual(decision.mode, "paid")
        self.assertTrue(decision.requires_confirmation)

    def test_models_status_never_prints_secret(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            secret = "test-openrouter-key"
            lines = models_status_lines(root=root, env={"OPENROUTER_API_KEY": secret})
            buffer = io.StringIO()

            with redirect_stdout(buffer):
                print_models_status(root=root)

            self.assertNotIn(secret, "\n".join(lines))
            self.assertNotIn(secret, buffer.getvalue())

    def test_get_key_from_dotenv_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            key_name = "OPENROUTER" + "_API_KEY"
            (root / ".env").write_text(
                f"# config file\n{key_name}=\"test-openrouter-dotenv-key\"\nOTHER_VALUE=hidden\n",
                encoding="utf-8",
            )

            self.assertEqual(
                get_openrouter_api_key(env={}, root=root),
                "test-openrouter-dotenv-key",
            )
            self.assertEqual(
                get_openrouter_api_key(env={"OPENROUTER_API_KEY": "test-openrouter-env-key"}, root=root),
                "test-openrouter-env-key",
            )

    def test_parse_error_message(self):
        response = httpx.Response(
            402,
            json={"error": {"message": "Payment required"}},
            request=httpx.Request("POST", "https://openrouter.ai/api/v1/chat/completions"),
        )

        error = parse_openrouter_error(response)

        self.assertEqual(error.status_code, 402)
        self.assertIn("Payment required", str(error))

    def test_stream_parser_collects_chunks_and_model(self):
        def handler(request):
            body = (
                'data: {"model":"openrouter/free","choices":[{"delta":{"content":"Bon"}}]}\n\n'
                'data: {"model":"openrouter/free","choices":[{"delta":{"content":"jour"}}],"usage":{"total_tokens":4}}\n\n'
                "data: [DONE]\n\n"
            )
            return httpx.Response(200, content=body.encode("utf-8"))

        client = OpenRouterClient(
            config={"free_model": "openrouter/free", "paid_model": "openrouter/auto"},
            api_key="test-key",
            transport=httpx.MockTransport(handler),
        )

        response = collect_stream_text(client.stream_chat([{"role": "user", "content": "Salut"}], mode="free"))

        self.assertEqual(response.content, "Bonjour")
        self.assertEqual(response.model, "openrouter/free")
        self.assertEqual(response.usage["total_tokens"], 4)

    def test_chat_payload_accepts_team_model_and_reasoning(self):
        captured = {}

        def handler(request):
            captured["payload"] = json.loads(request.content.decode("utf-8"))
            return httpx.Response(
                200,
                json={
                    "model": "x-ai/grok-4.20-multi-agent",
                    "choices": [{"message": {"content": "Plan pret"}}],
                    "usage": {"total_tokens": 7},
                },
            )

        client = OpenRouterClient(
            config={"free_model": "openrouter/free", "paid_model": "openrouter/auto"},
            api_key="test-key",
            transport=httpx.MockTransport(handler),
        )

        response = client.chat(
            [{"role": "user", "content": "Planifie"}],
            mode="paid",
            model="x-ai/grok-4.20-multi-agent",
            reasoning_effort="high",
            max_tokens=222,
        )

        self.assertEqual(response.content, "Plan pret")
        self.assertEqual(captured["payload"]["model"], "x-ai/grok-4.20-multi-agent")
        self.assertEqual(captured["payload"]["reasoning"], {"effort": "high"})
        self.assertEqual(captured["payload"]["max_tokens"], 222)


class ConversationStoreTests(unittest.TestCase):
    def _make_root(self) -> tempfile.TemporaryDirectory:
        return tempfile.TemporaryDirectory()

    def test_jsonl_persistence_and_recent_messages(self):
        with self._make_root() as tmp:
            root = Path(tmp)
            store = ConversationStore("assistant", session_id="test-session", root=root)

            store.append("user", "Salut", mode="free", model="openrouter/free")
            store.append("assistant", "Bonjour l'utilisateur", mode="free", model="openrouter/free", usage={"total_tokens": 3})

            records = store.records()
            recent = recent_messages("assistant", limit=2, root=root)
            export = store.export_markdown()

            self.assertEqual(len(records), 2)
            self.assertEqual(recent[0]["role"], "user")
            self.assertEqual(recent[1]["content"], "Bonjour l'utilisateur")
            self.assertTrue(export.exists())
            self.assertIn("Bonjour l'utilisateur", export.read_text(encoding="utf-8"))

    def test_build_chat_messages_uses_local_context(self):
        with self._make_root() as tmp:
            root = Path(tmp)
            agent = root / "agents" / "assistant"
            agent.mkdir(parents=True)
            (agent / "system_prompt.md").write_text("Tu es Assistant.", encoding="utf-8")
            (agent / "memory.md").write_text("l'utilisateur aime les réponses courtes.", encoding="utf-8")
            (agent / "tasks.md").write_text("# Taches\n\n## TODO\n- [ ] Tester", encoding="utf-8")
            brief = root / "memory" / "advanced" / "adaptation"
            brief.mkdir(parents=True)
            (brief / "adaptive_brief.md").write_text("Répondre en français.", encoding="utf-8")

            messages = build_chat_messages("assistant", "Coucou", root=root)

            self.assertEqual(messages[0]["role"], "system")
            self.assertIn("Tu es Assistant.", messages[0]["content"])
            self.assertEqual(messages[-1], {"role": "user", "content": "Coucou"})

    def test_summarize_tasks_counts_statuses(self):
        with self._make_root() as tmp:
            root = Path(tmp)
            tasks = root / "agents" / "assistant"
            tasks.mkdir(parents=True)
            (tasks / "tasks.md").write_text(
                "# Taches\n\n## PRIORITY\n- [ ] A\n\n## DONE\n- [x] B\n- [x] C\n",
                encoding="utf-8",
            )

            summary = summarize_tasks("assistant", root=root)

            self.assertEqual(summary["PRIORITY"], 1)
            self.assertEqual(summary["DONE"], 2)


class AgentChatRuntimeTests(unittest.TestCase):
    def _make_chat_root(self) -> tempfile.TemporaryDirectory:
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        agent = root / "agents" / "assistant"
        agent.mkdir(parents=True)
        (agent / "system_prompt.md").write_text("Tu es Assistant.", encoding="utf-8")
        (agent / "memory.md").write_text("", encoding="utf-8")
        (agent / "tasks.md").write_text("# Taches\n", encoding="utf-8")
        brief = root / "memory" / "advanced" / "adaptation"
        brief.mkdir(parents=True)
        (brief / "adaptive_brief.md").write_text("Réponds en français.", encoding="utf-8")
        return tmp

    def test_runtime_without_api_key_persists_local_error(self):
        with self._make_chat_root() as tmp:
            root = Path(tmp)
            client = OpenRouterClient(
                config={"free_model": "openrouter/free", "paid_model": "openrouter/auto"},
                api_key="",
            )
            runtime = AgentChatRuntime(
                root=root,
                config={"default_mode": "free", "free_model": "openrouter/free", "paid_model": "openrouter/auto"},
                client=client,
                session_id="telegram_test",
            )

            reply = runtime.ask("Salut")

            self.assertTrue(reply.error)
            self.assertTrue(reply.local_only)
            records = runtime.store.records()
            self.assertEqual(records[0]["role"], "user")
            self.assertEqual(records[1]["role"], "assistant")
            self.assertIn("OPENROUTER_API_KEY", records[1]["content"])

    def test_runtime_uses_openrouter_client_and_persists_response(self):
        def handler(request):
            return httpx.Response(
                200,
                json={
                    "model": "openrouter/free",
                    "choices": [{"message": {"content": "Bonjour l'utilisateur"}}],
                    "usage": {"total_tokens": 5},
                },
            )

        with self._make_chat_root() as tmp:
            root = Path(tmp)
            config = {
                "default_mode": "free",
                "free_model": "openrouter/free",
                "paid_model": "openrouter/auto",
                "history_limit": 20,
            }
            client = OpenRouterClient(
                config=config,
                api_key="test-key",
                transport=httpx.MockTransport(handler),
            )
            runtime = AgentChatRuntime(root=root, config=config, client=client, session_id="telegram_test")

            reply = runtime.ask("Salut")

            self.assertEqual(reply.content, "Bonjour l'utilisateur")
            self.assertEqual(reply.usage["total_tokens"], 5)
            records = runtime.store.records()
            self.assertEqual(records[-1]["content"], "Bonjour l'utilisateur")

    def test_runtime_blocks_paid_until_confirmation(self):
        with self._make_chat_root() as tmp:
            root = Path(tmp)
            config = {
                "default_mode": "free",
                "model_policy": "auto_prudent",
                "free_model": "openrouter/free",
                "paid_model": "openrouter/auto",
                "history_limit": 20,
            }
            client = OpenRouterClient(config=config, api_key="test-key", transport=httpx.MockTransport(lambda request: httpx.Response(500)))
            runtime = AgentExecutionRuntime(root=root, config=config, client=client, session_id="agent_test")

            reply = runtime.ask("Implémente une migration complexe et ajoute les tests.", allow_paid=False)

            self.assertTrue(reply.confirmation_required)
            self.assertEqual(reply.confirmation_kind, "paid")
            self.assertIsNotNone(reply.pending_action)
            self.assertIn("modèle payant", reply.content)

    def test_runtime_escalates_to_paid_when_free_fails(self):
        def handler(request):
            return httpx.Response(
                429,
                json={"error": {"message": "Free model unavailable"}},
                request=request,
            )

        with self._make_chat_root() as tmp:
            root = Path(tmp)
            config = {
                "default_mode": "free",
                "model_policy": "manual",
                "free_model": "openrouter/free",
                "paid_model": "openrouter/auto",
                "history_limit": 20,
            }
            client = OpenRouterClient(config=config, api_key="test-key", transport=httpx.MockTransport(handler))
            runtime = AgentExecutionRuntime(root=root, config=config, client=client, session_id="agent_test")

            reply = runtime.ask("Salut", allow_paid=False)

            self.assertTrue(reply.confirmation_required)
            self.assertEqual(reply.confirmation_kind, "paid")
            self.assertIn("échec du modèle gratuit", reply.model_reason)

    def test_runtime_holds_risky_mcp_tool_for_confirmation(self):
        def handler(request):
            return httpx.Response(
                200,
                json={
                    "model": "openrouter/free",
                    "choices": [
                        {
                            "message": {
                                "content": '<TOOL_MCP:desktop-commander:write_file>{"path":"/tmp/demo.txt","content":"ok"}</TOOL_MCP>'
                            }
                        }
                    ],
                    "usage": {"total_tokens": 5},
                },
            )

        with self._make_chat_root() as tmp:
            root = Path(tmp)
            config = {
                "default_mode": "free",
                "model_policy": "manual",
                "free_model": "openrouter/free",
                "paid_model": "openrouter/auto",
                "history_limit": 20,
            }
            client = OpenRouterClient(config=config, api_key="test-key", transport=httpx.MockTransport(handler))
            runtime = AgentExecutionRuntime(root=root, config=config, client=client, session_id="agent_test")

            reply = runtime.ask("Prépare l'action locale.", allow_paid=False)

            self.assertTrue(reply.confirmation_required)
            self.assertEqual(reply.confirmation_kind, "mcp")
            self.assertEqual(reply.pending_action.tool_name, "write_file")

    def test_pending_action_serializes_for_telegram_confirmation(self):
        action = PendingAction(
            kind="paid",
            content="Implémente le mode agent",
            mode="paid",
            model="openrouter/auto",
            reason="tâche complexe",
        )

        restored = PendingAction.from_dict(action.to_dict())

        self.assertEqual(restored.kind, "paid")
        self.assertEqual(restored.content, "Implémente le mode agent")
        self.assertEqual(restored.model, "openrouter/auto")


class TeamRuntimeTests(unittest.TestCase):
    def _make_team_root(self) -> tempfile.TemporaryDirectory:
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        (root / "config").mkdir(parents=True)
        (root / "config" / "teams.config.json").write_text(
            json.dumps(
                {
                    "teams": [
                        {
                            "name": "core",
                            "agents": ["assistant", "dev"],
                            "coordinator": "assistant",
                            "objective": "Coordonner SOI",
                        }
                    ],
                    "default_team": "core",
                }
            ),
            encoding="utf-8",
        )
        team = root / "teams" / "core"
        team.mkdir(parents=True)
        (team / "team.md").write_text("# Equipe core", encoding="utf-8")
        (team / "roles.md").write_text("# Roles", encoding="utf-8")
        (team / "coordination.md").write_text("# Coordination", encoding="utf-8")
        for agent in ["assistant", "dev"]:
            agent_dir = root / "agents" / agent
            agent_dir.mkdir(parents=True)
            (agent_dir / "agent.md").write_text(f"# Agent {agent}", encoding="utf-8")
            (agent_dir / "goals.md").write_text("Objectif", encoding="utf-8")
            (agent_dir / "tasks.md").write_text("# Taches", encoding="utf-8")
            (agent_dir / "memory.md").write_text("Memoire", encoding="utf-8")
        brief = root / "memory" / "advanced" / "adaptation"
        brief.mkdir(parents=True)
        (brief / "adaptive_brief.md").write_text("Francais, actionnable.", encoding="utf-8")
        return tmp

    def test_build_team_messages_uses_team_and_agent_context(self):
        with self._make_team_root() as tmp:
            root = Path(tmp)
            messages = build_team_messages("core", "Construire un plan", root=root)

            self.assertEqual(messages[0]["role"], "system")
            self.assertIn("Construire un plan", messages[1]["content"])
            self.assertIn("Agent `assistant`", messages[1]["content"])
            self.assertIn("Agent `dev`", messages[1]["content"])

    def test_team_run_local_writes_markdown_and_json(self):
        with self._make_team_root() as tmp:
            root = Path(tmp)
            result = run_team_objective("core", "Construire un plan", execute=False, root=root)

            self.assertTrue(result.local_only)
            self.assertTrue(result.markdown_path.exists())
            self.assertTrue(result.json_path.exists())
            self.assertIn("Run d'equipe local", result.markdown_path.read_text(encoding="utf-8"))

    def test_team_run_execute_uses_openrouter_client(self):
        def handler(request):
            payload = json.loads(request.content.decode("utf-8"))
            self.assertEqual(payload["model"], "x-ai/grok-4.20-multi-agent")
            self.assertEqual(payload["reasoning"], {"effort": "medium"})
            return httpx.Response(
                200,
                json={
                    "model": "x-ai/grok-4.20-multi-agent",
                    "choices": [{"message": {"content": "## Synthese\nPret"}}],
                    "usage": {"total_tokens": 10},
                },
            )

        with self._make_team_root() as tmp:
            root = Path(tmp)
            client = OpenRouterClient(api_key="test-key", transport=httpx.MockTransport(handler))
            result = run_team_objective("core", "Construire un plan", execute=True, root=root, client=client)

            self.assertFalse(result.local_only)
            self.assertEqual(result.usage["total_tokens"], 10)
            self.assertIn("Synthese", result.content)


if __name__ == "__main__":
    unittest.main()
