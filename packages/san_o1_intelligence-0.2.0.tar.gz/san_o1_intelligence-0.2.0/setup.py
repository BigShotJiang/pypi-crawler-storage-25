"""Compatibility shim for older editable installs.

Project metadata lives in pyproject.toml.
"""

from setuptools import setup


setup()
