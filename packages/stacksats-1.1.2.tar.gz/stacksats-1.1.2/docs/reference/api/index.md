---
title: API Reference
description: Generated API documentation for core StackSats modules.
---

# API Reference

Start with [Public API](../public-api.md) if you want the supported `1.x` imports, CLI boundary, and artifact contracts.

This section is generated from source code docstrings and signatures.
Treat it as internal reference material unless a symbol is re-exported from top-level `stacksats`.

Implementation code also lives in domain subpackages (for example `stacksats.data`, `stacksats.features`, `stacksats.model_development`, `stacksats.runner`, `stacksats.strategy_time_series`, `stacksats.export_weights`, `stacksats.execution`, `stacksats.viz`). Package roots such as `stacksats.runner`, `stacksats.model_development`, `stacksats.export_weights`, `stacksats.api`, and `stacksats.eda` are now façade modules that re-export focused implementation files underneath them. If you imported former top-level modules by path, see [Python package layout (internal imports)](../../migration.md#python-package-layout-internal-imports) in the Migration Guide.

## Core modules

- [eda](eda.md)
- [strategy_types](strategy-types.md)
- [runner](runner.md)
- [api module](api-module.md)

## Notes

- API reference documents callable surface area.
- Conceptual behavior and tradeoffs are documented in the [Concepts](../../model.md) section.
- Stability boundary:
  - Treat top-level `stacksats` exports, documented artifact payloads, and the documented CLI subset as the stable public API.
  - Generated module pages in this section are internal reference and may change between releases even when they remain documented.
  - See [Stability Policy](../../stability.md) for the canonical support and deprecation rules.
