"""Strategy-focused unit tests."""
