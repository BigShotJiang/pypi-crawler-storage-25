# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Synchronous Validation Executor with decoupled workflow steps.

This module provides the SyncValidationExecutor class that performs real-time
validation by extracting metadata from both source and target systems and
comparing them immediately.

The validation workflow is decoupled into three distinct steps using the
public workflow API module:
1. Query Generation - Uses data_validation_api.generate_schema_query / generate_metrics_query
2. Query Execution - Uses data_validation_api.execute_query with extractor's result processors
3. Validation - Uses data_validation_api.validate_schema / validate_metrics
"""

import logging

import pandas as pd

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.executer.base_validation_executor import (
    BaseValidationExecutor,
    validation_handler,
)
from snowflake.snowflake_data_validation.public import (
    data_validation_api,
)
from snowflake.snowflake_data_validation.public.model import QueryExecutionResult
from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.utils.constants import (
    CHUNK_ID_COLUMN_KEY,
    DEFAULT_TOLERANCE,
    ObjectType,
    Platform,
    Result,
    ValidationLevel,
)
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext
from snowflake.snowflake_data_validation.utils.telemetry import (
    report_telemetry,
)
from snowflake.snowflake_data_validation.validation.row_data_validator import (
    SOURCE_SUFFIX,
    TARGET_SUFFIX,
    RowDataValidator,
)


LOGGER = logging.getLogger(__name__)


class SyncValidationExecutor(BaseValidationExecutor):
    """Executor for synchronous validation operations.

    This executor performs real-time validation by extracting metadata from both
    source and target systems and comparing them immediately. Used for run-validation
    and run-validation-ipc commands.

    The validation workflow is decoupled into three distinct steps:
    1. Query Generation - Generate SQL queries for source and target platforms
    2. Query Execution - Execute generated queries and return results
    3. Validation - Compare results and produce validation output

    This separation enables better testability, reusability, and potential
    parallelization of source and target operations.
    """

    @validation_handler("Schema validation failed.")
    @log
    @report_telemetry(params_list=["source_table_context", "target_table_context"])
    def execute_schema_validation(
        self,
        source_table_context: TableContext,
        target_table_context: TableContext,
        column_mappings: dict[str, str],
    ) -> bool:
        """Execute schema validation using the public workflow API.

        This method orchestrates the three workflow steps using the public API:
        1. Generate queries using data_validation_api.generate_schema_query
        2. Execute queries using data_validation_api.execute_query
        3. Validate using data_validation_api.validate_schema

        Args:
            source_table_context: Source table context for validation.
            target_table_context: Target table context for validation.
            column_mappings: Mapping of source to target column names.

        Returns:
            bool: True if validation passes, False otherwise.

        """
        LOGGER.info(
            "Starting schema validation for table: %s",
            source_table_context.fully_qualified_name,
        )

        source_query = data_validation_api.generate_schema_query(source_table_context)
        target_query = data_validation_api.generate_schema_query(target_table_context)

        self._emit_extraction_message(source_table_context)
        source_result = data_validation_api.execute_query(
            table_context=source_table_context,
            connector=self.source_extractor.connector,
            generated_query=source_query,
            result_processor=self.source_extractor.process_schema_query_result,
        )

        # Teradata view validation does not need view materialization.
        if (
            source_table_context.object_type == ObjectType.VIEW
            and self.context.source_platform == Platform.TERADATA
        ):
            source_result = data_validation_api.normalize_table_metadata(
                platform=self.context.source_platform,
                metadata=source_result,
            )

        self._emit_extraction_message(target_table_context)
        target_result = data_validation_api.execute_query(
            table_context=target_table_context,
            connector=self.target_extractor.connector,
            generated_query=target_query,
            result_processor=self.target_extractor.process_schema_query_result,
        )

        if (
            source_table_context.object_type == ObjectType.VIEW
            and self.context.source_platform == Platform.TERADATA
        ):
            validation_result = data_validation_api.validate_schema_simple(
                source_query_result=source_result,
                target_query_result=target_result,
                table_context=source_table_context,
                column_mappings=column_mappings,
                datatypes_mappings=self.context.datatypes_mappings,
            )
        else:
            validation_result = data_validation_api.validate_schema(
                source_query_result=source_result,
                target_query_result=target_result,
                table_context=source_table_context,
                column_mappings=column_mappings,
                datatypes_mappings=self.context.datatypes_mappings,
            )

        self._emit_validation_result_message(
            validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
            is_valid=validation_result.is_valid,
            fully_qualified_name=source_table_context.fully_qualified_name,
        )

        return validation_result.is_valid

    @validation_handler("Metrics validation failed.")
    @log
    @report_telemetry(params_list=["source_table_context", "target_table_context"])
    def execute_metrics_validation(
        self,
        source_table_context: TableContext,
        target_table_context: TableContext,
        column_mappings: dict[str, str],
    ) -> bool:
        """Execute metrics validation using the public workflow API.

        This method orchestrates the three workflow steps using the public API:
        1. Generate queries using data_validation_api.generate_metrics_query
        2. Execute queries using data_validation_api.execute_query
        3. Validate using data_validation_api.validate_metrics

        Args:
            source_table_context: Source table context for validation.
            target_table_context: Target table context for validation.
            column_mappings: Mapping of source to target column names.

        Returns:
            bool: True if validation passes, False otherwise.

        """
        LOGGER.info(
            "Starting metrics validation for table: %s",
            source_table_context.fully_qualified_name,
        )

        source_query = data_validation_api.generate_metrics_query(
            table_context=source_table_context,
        )
        target_query = data_validation_api.generate_metrics_query(
            table_context=target_table_context,
        )

        self._emit_extraction_message(source_table_context, validation_type="Metrics")
        source_result = data_validation_api.execute_query(
            table_context=source_table_context,
            connector=self.source_extractor.connector,
            generated_query=source_query,
            result_processor=lambda result, _: self.source_extractor.process_metrics_query_result(
                result
            ),
        )

        self._emit_extraction_message(target_table_context, validation_type="Metrics")
        target_result = data_validation_api.execute_query(
            table_context=target_table_context,
            connector=self.target_extractor.connector,
            generated_query=target_query,
            result_processor=lambda result, _: self.target_extractor.process_metrics_query_result(
                result
            ),
        )

        tolerance = self._get_tolerance_from_config()

        validation_result = data_validation_api.validate_metrics(
            source_query_result=source_result,
            target_query_result=target_result,
            table_context=source_table_context,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        self._emit_validation_result_message(
            validation_type=ValidationLevel.METRICS_VALIDATION.value,
            is_valid=validation_result.is_valid,
            fully_qualified_name=source_table_context.fully_qualified_name,
        )

        return validation_result.is_valid

    @validation_handler("Row validation failed.")
    @log
    @report_telemetry(params_list=["source_table_context", "target_table_context"])
    def execute_row_validation(
        self, source_table_context: TableContext, target_table_context: TableContext
    ) -> bool:
        """Execute row validation.

        Note: Row validation has a more complex workflow and is not yet
        fully decoupled into separate query generation, execution, and
        validation steps. This will be addressed in a future refactoring.

        Args:
            source_table_context: Source table context for validation.
            target_table_context: Target table context for validation.

        Returns:
            bool: True if validation passes, False otherwise.

        """
        LOGGER.info(
            "Starting row validation for table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        if source_table_context.index_column_collection == []:
            LOGGER.error(
                "Row validation requires index columns to be defined. "
                "Table %s (%s) has no index columns configured. "
                "Please set 'index_column_list' in your configuration file. "
                "Skipping row validation.",
                source_table_context.fully_qualified_name,
                source_table_context.platform.value,
            )
            self.context.output_handler.handle_message(
                header="Row validation skipped.",
                message=(
                    f"Row validation requires index columns to be defined. "
                    f"{source_table_context.fully_qualified_name} ({source_table_context.platform.value}). "
                    "Please set 'index_column_list' in your configuration file. "
                    "Skipping row validation."
                ),
                level=OutputMessageLevel.ERROR,
            )
            return True

        self._create_table_chunks_md5(
            source_table_context=source_table_context,
            target_table_context=target_table_context,
        )

        self._compute_md5(
            source_table_context=source_table_context,
            target_table_context=target_table_context,
        )

        source_extract_query = data_validation_api.generate_extract_chunks_md5_query(
            source_table_context
        )
        target_extract_query = data_validation_api.generate_extract_chunks_md5_query(
            target_table_context
        )

        LOGGER.debug(
            "Starting extracted chunks MD5 for table %s",
            source_table_context.fully_qualified_name,
        )

        source_chunks_result = data_validation_api.execute_query(
            table_context=source_table_context,
            connector=self.source_extractor.connector,
            generated_query=source_extract_query,
        )

        if source_chunks_result.dataframe.empty:
            LOGGER.error(
                "No MD5 chunks found for table %s. Skipping row validation.",
                source_table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header="Row validation failed.",
                message=(
                    f"No MD5 chunks found for table {source_table_context.fully_qualified_name}. "
                    "Skipping row validation."
                ),
                level=OutputMessageLevel.ERROR,
            )
            return True

        LOGGER.debug(
            "Successfully extracted chunks MD5 for table %s",
            source_table_context.fully_qualified_name,
        )

        LOGGER.debug(
            "Starting extracted chunks MD5 for table %s",
            target_table_context.fully_qualified_name,
        )
        target_chunks_result = data_validation_api.execute_query(
            table_context=target_table_context,
            connector=self.target_extractor.connector,
            generated_query=target_extract_query,
        )

        if target_chunks_result.dataframe.empty:
            LOGGER.error(
                "No MD5 chunks found for table %s. Skipping row validation.",
                target_table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header="Row validation failed.",
                message=(
                    f"No MD5 chunks found for table {target_table_context.fully_qualified_name}. "
                    "Skipping row validation."
                ),
                level=OutputMessageLevel.ERROR,
            )
            return True

        LOGGER.debug(
            "Successfully extracted chunks MD5 for table %s",
            target_table_context.fully_qualified_name,
        )

        LOGGER.info(
            "Starting chunks MD5 comparison between table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        self.context.output_handler.handle_message(
            message=(
                f"Starting MD5 comparison between table "
                f"{source_table_context.fully_qualified_name} and table "
                f"{target_table_context.fully_qualified_name}"
            ),
            level=OutputMessageLevel.INFO,
        )

        comparison_result = data_validation_api.compare_md5_chunks(
            source_chunks_result=source_chunks_result,
            target_chunks_result=target_chunks_result,
            table_context=source_table_context,
        )

        LOGGER.info(
            "Completing chunks MD5 comparison between table %s and table %s.",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        if comparison_result.is_valid:
            LOGGER.info(
                "No differences found in MD5 comparison between table %s and table %s.",
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header="Row validation passed.",
                message=(
                    f"No differences found in MD5 comparison between table "
                    f"{source_table_context.fully_qualified_name} and table "
                    f"{target_table_context.fully_qualified_name}"
                ),
                level=OutputMessageLevel.SUCCESS,
            )

            # Register row validation execution status as SUCCESS
            self._register_row_validation_execution_status(
                source_table_context=source_table_context,
                status=Result.SUCCESS,
            )

            return True
        else:
            LOGGER.info(
                "Differences found in MD5 comparison between table %s and table %s:\n%s",
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
                comparison_result.results_dataframe,
            )

        self._validate_md5_rows_chunk(
            compared_df=comparison_result.results_dataframe,
            source_table_context=source_table_context,
            target_table_context=target_table_context,
        )

        self.context.output_handler.handle_message(
            header="Row validation failed.",
            level=OutputMessageLevel.FAILURE,
        )

        self._register_row_validation_execution_status(
            source_table_context=source_table_context,
            status=Result.FAILURE,
        )

        return True

    @log
    def _create_table_chunks_md5(
        self, source_table_context: TableContext, target_table_context: TableContext
    ) -> None:
        # Generate DDL statements using public API
        source_create_statement = (
            data_validation_api.generate_create_md5_table_statement(
                source_table_context
            )
        )
        target_create_statement = (
            data_validation_api.generate_create_md5_table_statement(
                target_table_context
            )
        )

        # Execute source table creation using public API
        LOGGER.debug(
            "Creating table to store the md5 chunks for table %s",
            source_table_context.fully_qualified_name,
        )
        data_validation_api.execute_statement(
            table_context=source_table_context,
            connector=self.source_extractor.connector,
            generated_query=source_create_statement,
        )
        LOGGER.debug(
            "Table to store the md5 chunks created for table %s",
            source_table_context.fully_qualified_name,
        )

        # Execute target table creation using public API
        LOGGER.debug(
            "Creating table to store the md5 chunks for table %s",
            target_table_context.fully_qualified_name,
        )
        data_validation_api.execute_statement(
            table_context=target_table_context,
            connector=self.target_extractor.connector,
            generated_query=target_create_statement,
        )
        LOGGER.debug(
            "Table to store the md5 chunks created for table %s",
            target_table_context.fully_qualified_name,
        )

    @log
    def _compute_md5(
        self, source_table_context: TableContext, target_table_context: TableContext
    ) -> None:
        self.context.output_handler.handle_message(
            message=(
                f"Computing MD5 for table {source_table_context.fully_qualified_name} "
                f"and table {target_table_context.fully_qualified_name}"
            ),
            level=OutputMessageLevel.INFO,
        )

        source_md5_queries = data_validation_api.generate_compute_md5_queries(
            table_context=source_table_context,
            other_table_name=target_table_context.table_name,
        )
        target_md5_queries = data_validation_api.generate_compute_md5_queries(
            table_context=target_table_context,
            other_table_name=source_table_context.table_name,
        )

        LOGGER.info(
            "Computing MD5 for table %s (%d queries)",
            source_table_context.fully_qualified_name,
            len(source_md5_queries),
        )
        for query in source_md5_queries:
            data_validation_api.execute_statement(
                table_context=source_table_context,
                connector=self.source_extractor.connector,
                generated_query=query,
            )
        LOGGER.info(
            "Successfully computed MD5 for table %s",
            source_table_context.fully_qualified_name,
        )

        LOGGER.info(
            "Computing MD5 for table %s (%d queries)",
            target_table_context.fully_qualified_name,
            len(target_md5_queries),
        )
        for query in target_md5_queries:
            data_validation_api.execute_statement(
                table_context=target_table_context,
                connector=self.target_extractor.connector,
                generated_query=query,
            )
        LOGGER.info(
            "Successfully computed MD5 for table %s",
            target_table_context.fully_qualified_name,
        )

        self.context.output_handler.handle_message(
            message=(
                f"Successfully computed MD5 for table "
                f"{source_table_context.fully_qualified_name} and table "
                f"{target_table_context.fully_qualified_name}"
            ),
            level=OutputMessageLevel.INFO,
        )

    @log
    def _validate_md5_rows_chunk(
        self,
        compared_df: pd.DataFrame,
        source_table_context: TableContext,
        target_table_context: TableContext,
    ) -> None:
        source_index_column_collection = [
            column.name for column in source_table_context.index_column_collection
        ]
        target_index_column_collection = [
            column.name for column in target_table_context.index_column_collection
        ]

        rows_compared_df = pd.DataFrame()
        for _, row in compared_df.iterrows():

            current_chunk_id = row[CHUNK_ID_COLUMN_KEY]

            LOGGER.info(
                "Starting MD5 row validation for chunk %s in table %s and table %s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )

            source_rows_query = (
                data_validation_api.generate_extract_md5_rows_chunk_query(
                    chunk_id=current_chunk_id,
                    table_context=source_table_context,
                )
            )
            target_rows_query = (
                data_validation_api.generate_extract_md5_rows_chunk_query(
                    chunk_id=current_chunk_id,
                    table_context=target_table_context,
                )
            )

            LOGGER.debug(
                "Extracting MD5 rows for chunk %s in table %s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
            )
            source_rows_result = data_validation_api.execute_query(
                table_context=source_table_context,
                connector=self.source_extractor.connector,
                generated_query=source_rows_query,
            )
            LOGGER.debug(
                "Successfully extracted MD5 rows for chunk %s in table %s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
            )

            LOGGER.debug(
                "Extracting MD5 rows for chunk %s in table %s",
                current_chunk_id,
                target_table_context.fully_qualified_name,
            )
            target_rows_result = data_validation_api.execute_query(
                table_context=target_table_context,
                connector=self.target_extractor.connector,
                generated_query=target_rows_query,
            )
            LOGGER.debug(
                "Successfully extracted MD5 rows for chunk %s in table %s",
                current_chunk_id,
                target_table_context.fully_qualified_name,
            )

            LOGGER.info(
                "Starting MD5 rows for chunk %s comparison between table %s and table %s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )

            self.context.output_handler.handle_message(
                message=(
                    f"Starting MD5 rows for chunk {current_chunk_id} comparison between table "
                    f"{source_table_context.fully_qualified_name} and table "
                    f"{target_table_context.fully_qualified_name}"
                ),
                level=OutputMessageLevel.INFO,
            )

            source_md5_rows_chunk_str = (
                source_rows_result.dataframe.convert_dtypes().rename(
                    columns=lambda x: x.upper() + SOURCE_SUFFIX
                )
            )
            target_md5_rows_chunk_str = (
                target_rows_result.dataframe.convert_dtypes().rename(
                    columns=lambda x: x.upper() + TARGET_SUFFIX
                )
            )

            source_index_column_suffix_collection = [
                str.upper(column_name) + SOURCE_SUFFIX
                for column_name in source_index_column_collection
            ]

            target_index_column_suffix_collection = [
                str.upper(column_name) + TARGET_SUFFIX
                for column_name in target_index_column_collection
            ]

            source_transformed_result = QueryExecutionResult(
                dataframe=source_md5_rows_chunk_str
            )
            target_transformed_result = QueryExecutionResult(
                dataframe=target_md5_rows_chunk_str
            )

            rows_comparison_result = data_validation_api.compare_md5_rows_chunk(
                source_rows_result=source_transformed_result,
                target_rows_result=target_transformed_result,
                source_index_column_suffix_collection=source_index_column_suffix_collection,
                target_index_column_suffix_collection=target_index_column_suffix_collection,
                table_context=source_table_context,
            )

            LOGGER.info(
                "Successfully completed MD5 rows for chunk %s comparison between table %s and table %s."
                "Differences found: \n%s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
                rows_comparison_result.results_dataframe,
            )

            rows_compared_df = pd.concat(
                [rows_compared_df, rows_comparison_result.results_dataframe]
            )

            if (
                len(rows_comparison_result.results_dataframe)
                >= source_table_context.max_failed_rows_number
            ):
                LOGGER.warning(
                    "Maximum failed rows threshold (%d) reached during row validation "
                    "for tables %s and %s. Stopping further validation.",
                    source_table_context.max_failed_rows_number,
                    source_table_context.fully_qualified_name,
                    target_table_context.fully_qualified_name,
                )
                self.context.output_handler.handle_message(
                    header="Row validation stopped: maximum failed rows reached.",
                    message=(
                        f"Row validation between "
                        f"{source_table_context.fully_qualified_name} and "
                        f"{target_table_context.fully_qualified_name} was stopped because "
                        f"the number of failed rows ({len(rows_comparison_result.results_dataframe)}) "
                        f"reached the configured threshold "
                        f"({source_table_context.max_failed_rows_number})."
                    ),
                    level=OutputMessageLevel.FAILURE,
                )
                break

            LOGGER.info(
                "Successfully completed MD5 row validation for chunk %s in table %s and table %s",
                current_chunk_id,
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )

        self.context.output_handler.handle_message(
            message=(
                f"Completing MD5 comparison between table "
                f"{source_table_context.fully_qualified_name} and table "
                f"{target_table_context.fully_qualified_name}"
            ),
            level=OutputMessageLevel.INFO,
        )

        LOGGER.info(
            "Generating row validation report for table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        source_index_column_collection = [
            column.name for column in source_table_context.index_column_collection
        ]
        target_index_column_collection = [
            column.name for column in target_table_context.index_column_collection
        ]

        data_validator = RowDataValidator()
        data_validator.generate_row_validation_report(
            compared_df=rows_compared_df,
            fully_qualified_name=source_table_context.fully_qualified_name,
            target_fully_qualified_name=target_table_context.fully_qualified_name,
            source_index_column_collection=source_index_column_collection,
            target_index_column_collection=target_index_column_collection,
            source_index_column_suffix_collection=source_index_column_suffix_collection,
            target_index_column_suffix_collection=target_index_column_suffix_collection,
            object_id=source_table_context.id,
            context=self.context,
            db_manager=self.db_manager,
            object_type=source_table_context.object_type,
        )

        LOGGER.info(
            "Successfully generated row validation report for table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        LOGGER.info(
            "Generating row validation queries for table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

        data_validator.generate_row_validation_queries(
            compared_df=rows_compared_df,
            fully_qualified_name=source_table_context.fully_qualified_name,
            target_fully_qualified_name=target_table_context.fully_qualified_name,
            source_index_column_collection=source_index_column_collection,
            target_index_column_collection=target_index_column_collection,
            object_id=source_table_context.id,
            context=self.context,
        )

        LOGGER.info(
            "Successfully generated row validation queries for table %s and table %s",
            source_table_context.fully_qualified_name,
            target_table_context.fully_qualified_name,
        )

    def _register_row_validation_execution_status(
        self,
        source_table_context: TableContext,
        status: Result,
    ) -> None:
        """Register the row validation execution status in the database.

        Args:
            source_table_context: The source table context containing object information.
            status: The execution status (SUCCESS/FAILURE).

        """
        execution_status_df = pd.DataFrame(
            [
                {
                    "TABLE_NAME": source_table_context.fully_qualified_name,
                    "OBJECT_TYPE": source_table_context.object_type.value,
                    "OBJECT_ID": source_table_context.id,
                    "STATUS": status.value,
                }
            ]
        )

        self.db_manager.upload_row_validation_execution_status(execution_status_df)

        LOGGER.info(
            "Registered row validation execution status for table %s: %s",
            source_table_context.fully_qualified_name,
            status.value,
        )

    def _emit_extraction_message(
        self,
        table_context: TableContext,
        validation_type: str = "schema",
    ) -> None:
        """Emit an output message for query extraction.

        Args:
            table_context: The table context for the query.
            validation_type: Type of validation (schema, Metrics, etc.).

        """
        message = (
            f"Extracting {validation_type} validations for: "
            f"{table_context.fully_qualified_name} on {table_context.platform.value}"
        )
        self.context.output_handler.handle_message(
            message=message,
            level=OutputMessageLevel.INFO,
        )

    def _emit_validation_result_message(
        self,
        validation_type: str,
        is_valid: bool,
        fully_qualified_name: str,
    ) -> None:
        """Emit an output message for validation result.

        Args:
            validation_type: Type of validation (Schema, Metrics, etc.).
            is_valid: Whether the validation passed.
            fully_qualified_name: The table name for logging.

        """
        validation_status = "passed" if is_valid else "failed"
        LOGGER.info(
            "%s validation %s for table: %s",
            validation_type,
            validation_status,
            fully_qualified_name,
        )
        self.context.output_handler.handle_message(
            header=f"{validation_type} validation {validation_status}.",
            message="",
            level=(
                OutputMessageLevel.SUCCESS if is_valid else OutputMessageLevel.FAILURE
            ),
        )

    def _get_tolerance_from_config(self) -> float:
        """Get tolerance value from configuration.

        Returns:
            float: The tolerance value from config or DEFAULT_TOLERANCE.

        """
        tolerance = DEFAULT_TOLERANCE
        if (
            self.context.configuration.comparison_configuration
            and "tolerance" in self.context.configuration.comparison_configuration
        ):
            tolerance = float(
                self.context.configuration.comparison_configuration["tolerance"]
            )
            LOGGER.debug("Using tolerance from configuration: %f", tolerance)
        else:
            LOGGER.debug("Using default tolerance: %f", tolerance)
        return tolerance

    def _get_schema_validation_message(
        self, table_configuration: TableConfiguration
    ) -> str:
        """Get sync validation message for schema validation."""
        return (
            f"Validating schema for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_metrics_validation_message(
        self, table_configuration: TableConfiguration
    ) -> str:
        """Get sync validation message for metrics validation."""
        return (
            f"Validating metrics for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_row_validation_message(
        self, table_configuration: TableConfiguration
    ) -> str:
        """Get sync validation message for row validation."""
        return (
            f"Validating rows for {table_configuration.fully_qualified_name} "
            f"and {table_configuration.target_fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )
