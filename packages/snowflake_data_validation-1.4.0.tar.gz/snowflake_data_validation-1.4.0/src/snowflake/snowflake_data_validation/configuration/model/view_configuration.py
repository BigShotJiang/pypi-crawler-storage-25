from pydantic import model_validator
from typing_extensions import Self

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.utils.constants import (
    ObjectType,
    Platform,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_database import (
    HelperDatabase,
)


class ViewConfiguration(TableConfiguration):
    """View configuration model.

    Args:
        pydantic.BaseModel (pydantic.BaseModel): pydantic BaseModel

    """

    object_type: ObjectType = ObjectType.VIEW

    @model_validator(mode="after")
    def load(self) -> Self:
        self._assign_id()
        self._assign_guid()
        self._load_source_decomposed_fully_qualified_name()
        self._load_target_fully_qualified_name()
        self._set_has_where_clause()
        self._set_has_target_where_clause()
        self._normalize_where_clause()
        self._check_target_where_clause()
        self._set_column_mappings()
        self._normalize_column_selection_list()
        self._set_is_temporary_table()
        self._set_internal_identifiers()
        return self

    def _set_internal_identifiers(
        self,
        source_platform: Platform = None,
        target_platform: Platform = Platform.SNOWFLAKE,
    ) -> None:
        self.internal_fully_qualified_name = self.fully_qualified_name
        self.internal_target_fully_qualified_name = self.target_fully_qualified_name
        self.internal_source_table = self.source_table
        self.internal_target_name = self.target_name

        # Skip internal identifiers generation for Teradata views, because temporary table is not necessary.
        if source_platform == Platform.TERADATA:
            return

        # Apply quoting if original identifier was non-regular
        source_needs_quotes = HelperDatabase.is_delimited_identifier(self.source_table)
        target_needs_quotes = HelperDatabase.is_delimited_identifier(self.target_name)

        source_temp_name = (
            HelperDatabase.normalize_identifier(self.source_table)
            if source_needs_quotes
            else self.source_table
        )

        target_temp_name = target_temp_name = (
            HelperDatabase.normalize_identifier(self.target_name)
            if target_needs_quotes
            else self.target_name
        )

        source_temp_name = HelperDatabase.generate_temporary_table_identifier(
            table_name=source_temp_name,
            id=self.id,
            guid=self.guid,
            platform=source_platform,
        )

        target_temp_name = HelperDatabase.generate_temporary_table_identifier(
            table_name=target_temp_name,
            id=self.id,
            guid=self.guid,
            platform=target_platform,
        )

        self.internal_source_table = HelperDatabase.quote_identifier(
            source_temp_name, source_needs_quotes
        )
        self.internal_target_name = HelperDatabase.quote_identifier(
            target_temp_name, target_needs_quotes
        )

        self.internal_fully_qualified_name = (
            f"{self.source_database}.{self.source_schema}.{self.internal_source_table}"
        )

        self.internal_target_fully_qualified_name = (
            f"{self.target_database}.{self.target_schema}.{self.internal_target_name}"
        )
