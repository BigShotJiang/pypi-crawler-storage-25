from snowflake.snowflake_data_validation.query.query_generator_base import (
    QueryGeneratorBase,
)
from snowflake.snowflake_data_validation.result_set.extractor.result_set_cte_generator import (
    generate_cte_query,
    generate_outer_query,
)
from snowflake.snowflake_data_validation.utils.constants import Platform
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext


class QueryGeneratorResultSet(QueryGeneratorBase):
    """ResultSet-specific implementation of query generator."""

    def __init__(self):
        """Initialize the ResultSet query generator."""
        super().__init__(platform=Platform.RESULT_SET)

    def cte_query_generator(
        self,
        metrics_templates,
        col_name: str,
        col_type: str,
        fully_qualified_name: str,
        where_clause: str,
        has_where_clause: bool,
        sql_generator,
        exclude_metrics: bool,
        apply_metric_column_modifier: bool,
    ) -> tuple[str, str, list[str]] | tuple[None, None, None]:
        """Generate a CTE query for a specific column using Snowflake CTE generator.

        Args:
            metrics_templates: DataFrame containing metrics templates.
            col_name (str): Column name.
            col_type (str): Column data type.
            fully_qualified_name (str): Fully qualified table name.
            where_clause (str): WHERE clause.
            has_where_clause (bool): Whether WHERE clause is present.
            sql_generator: SQL template generator instance.
            exclude_metrics (bool): If True, excludes certain metrics from the CTE query.
            apply_metric_column_modifier (bool): Whether to apply metric column modifier.

        Returns:
            Tuple containing CTE query, CTE name, and metrics list, or (None, None, None) if no query generated.

        """
        return generate_cte_query(
            metrics_templates=metrics_templates,
            col_name=col_name,
            col_type=col_type,
            fully_qualified_name=fully_qualified_name,
            where_clause=where_clause,
            has_where_clause=has_where_clause,
            sql_generator=sql_generator,
            exclude_metrics=exclude_metrics,
            apply_metric_column_modifier=apply_metric_column_modifier,
        )

    def outer_query_generator(self, cte_names, metrics) -> str:
        """Generate an outer query combining CTEs using Snowflake outer query generator.

        Args:
            cte_names: List of CTE names.
            metrics: List of metrics for each CTE.

        Returns:
            str: Generated outer query.

        """
        return generate_outer_query(cte_names, metrics)

    def generate_extract_md5_rows_chunk_query(
        self, chunk_id: str, table_context: TableContext
    ) -> str:
        """Generate the SQL query to extract the MD5 rows for a specific chunk.

        Args:
            chunk_id: The unique identifier for the chunk.
            table_context: Configuration object containing table properties.

        Returns:
            SQL query string to extract the MD5 rows for the specified chunk.

        """
        pass

    def _generate_compute_md5_chunk_query(
        self, table_context: TableContext, chunk_id: str, fetch: int, offset: int
    ) -> str | list[str]:
        """Generate the SQL query to compute MD5 for a chunk of a table.

        Args:
            table_context: Configuration object containing table properties.
            chunk_id: The ID of the chunk to compute MD5 for.
            fetch: The maximum number of rows to process in this chunk.
            offset: The starting row number for this chunk.

        Returns:
            SQL query string or a list of SQL query strings.

        """
        pass

    def generate_statement_table_chunks_md5(self, table_context: TableContext) -> str:
        """Generate the DDL statement to create a table for storing MD5 checksums.

        Args:
            table_context: Configuration object containing table properties.

        Returns:
            SQL query string to create a table for storing MD5 checksums.

        """
        pass

    def generate_extract_chunks_md5_query(self, table_context: TableContext) -> str:
        """Generate the SQL query to extract MD5 for all chunks of a table.

        Args:
            table_context: Configuration object containing table properties.

        Returns:
            SQL query string to extract MD5 for all chunks of a table.

        """
        pass
