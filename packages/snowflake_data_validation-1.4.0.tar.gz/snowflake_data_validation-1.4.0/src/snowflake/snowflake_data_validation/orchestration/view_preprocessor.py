from snowflake.snowflake_data_validation.configuration.model.view_configuration import (
    ViewConfiguration,
)
from snowflake.snowflake_data_validation.extractor.metadata_extractor_base import (
    MetadataExtractorBase,
)
from snowflake.snowflake_data_validation.public import (
    data_validation_api,
)
from snowflake.snowflake_data_validation.script_writer.script_writer_base import (
    ScriptWriterBase,
)
from snowflake.snowflake_data_validation.utils.constants import Origin
from snowflake.snowflake_data_validation.utils.context import Context


class ViewPreProcessor:
    """
    Preprocessor for handling view-based data validation operations.

    This class is responsible for creating temporary tables from views for both source and
    target platforms during data validation. It provides methods to generate temporary tables
    from views, ensuring that data validation can be performed on consistent and isolated
    datasets derived from views. The preprocessor uses the public workflow API for query
    generation and execution, separating these concerns for better testability and reusability.

    For async mode (when extractor is ScriptWriterBase), it also writes the materialization
    queries to script files for later reference.
    """

    def materialize_source_view(
        self,
        view_configuration: ViewConfiguration,
        source_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> None:
        """Generate and execute source view materialization.

        For async mode (ScriptWriterBase), also writes the query to a script file.

        Args:
            view_configuration: Configuration object containing view details and settings.
            source_extractor: Extractor or script writer for the source platform.
            context: Context object containing platform and execution details.

        """
        source_query = data_validation_api.generate_view_materialization_query(
            fully_qualified_view_name=view_configuration.fully_qualified_name,
            fully_qualified_temporary_table_name=view_configuration.internal_fully_qualified_name,
            platform=context.source_platform,
            sql_generator=context.sql_generator,
        )

        # Execute the materialization (create temporary table)
        data_validation_api.execute_view_materialization(
            connector=source_extractor.connector,
            generated_query=source_query,
            fully_qualified_view_name=view_configuration.fully_qualified_name,
            platform=context.source_platform,
        )

        # For async mode, also write the query to a script file
        if isinstance(source_extractor, ScriptWriterBase):
            data_validation_api.write_view_materialization_query_to_script(
                generated_query=source_query,
                output_directory=source_extractor.report_path,
                origin=Origin.SOURCE.value,
                platform=context.source_platform.value,
                timestamp=context.run_start_time,
            )

    def materialize_target_view(
        self,
        view_configuration: ViewConfiguration,
        target_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> None:
        """Generate and execute target view materialization.

        For async mode (ScriptWriterBase), also writes the query to a script file.

        Args:
            view_configuration: Configuration object containing view details and settings.
            target_extractor: Extractor or script writer for the target platform.
            context: Context object containing platform and execution details.

        """
        target_query = data_validation_api.generate_view_materialization_query(
            fully_qualified_view_name=view_configuration.target_fully_qualified_name,
            fully_qualified_temporary_table_name=view_configuration.internal_target_fully_qualified_name,
            platform=context.target_platform,
            sql_generator=context.sql_generator,
        )

        # Execute the materialization (create temporary table)
        data_validation_api.execute_view_materialization(
            connector=target_extractor.connector,
            generated_query=target_query,
            fully_qualified_view_name=view_configuration.target_fully_qualified_name,
            platform=context.target_platform,
        )

        # For async mode, also write the query to a script file
        if isinstance(target_extractor, ScriptWriterBase):
            data_validation_api.write_view_materialization_query_to_script(
                generated_query=target_query,
                output_directory=target_extractor.report_path,
                origin=Origin.TARGET.value,
                platform=context.target_platform.value,
                timestamp=context.run_start_time,
            )
