# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data container for HTML report metadata."""

from dataclasses import dataclass
from datetime import datetime

from snowflake.snowflake_data_validation.utils.context import Context


@dataclass
class ReportMetadata:
    """Data container for report header information.

    Attributes:
        date: Formatted date string for the report.
        source_platform: Name of the source platform.
        source_connection: Source connection identifier.
        target_platform: Name of the target platform.
        target_connection: Target connection identifier.
        execution_id: Unique execution identifier.

    """

    date: str
    source_platform: str
    source_connection: str
    target_platform: str
    target_connection: str
    execution_id: str

    @classmethod
    def from_context(cls, context: Context) -> "ReportMetadata":
        """Create ReportMetadata from a Context object.

        Args:
            context: The validation context containing run information.

        Returns:
            ReportMetadata: A new instance populated from the context.

        """
        formatted_date = datetime.strptime(
            context.run_start_time, "%Y%m%dT%H%M%S"
        ).strftime("%Y-%m-%d %H:%M:%S")

        # Handle cases where connections may be None (e.g., async validation from files)
        source_connection_id = (
            context.configuration.source_connection.get_connection_identifier()
            if context.configuration.source_connection
            else "N/A (from files)"
        )
        target_connection_id = (
            context.configuration.target_connection.get_connection_identifier()
            if context.configuration.target_connection
            else "N/A (from files)"
        )

        return cls(
            date=formatted_date,
            source_platform=context.source_platform.value,
            source_connection=source_connection_id,
            target_platform=context.target_platform.value,
            target_connection=target_connection_id,
            execution_id=context.run_id,
        )
