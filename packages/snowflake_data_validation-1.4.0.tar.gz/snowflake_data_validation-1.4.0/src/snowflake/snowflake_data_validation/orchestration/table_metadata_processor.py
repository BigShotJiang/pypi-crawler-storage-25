# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

import pandas as pd

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.extractor.metadata_extractor_base import (
    MetadataExtractorBase,
)
from snowflake.snowflake_data_validation.public import data_validation_api
from snowflake.snowflake_data_validation.script_writer.script_writer_base import (
    ScriptWriterBase,
)
from snowflake.snowflake_data_validation.utils.constants import Platform
from snowflake.snowflake_data_validation.utils.context import Context
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.model.table_column_metadata import (
    TableColumnMetadata,
)


LOGGER = logging.getLogger(__name__)


class TableMetadataProcessor:
    """Handles table metadata extraction and processing operations.

    This class uses the public data_validation_api for all metadata processing,
    delegating query generation, execution, and metadata transformation to the API.
    """

    @log
    def generate_table_column_metadata(
        self,
        table_configuration: TableConfiguration,
        source_extractor: MetadataExtractorBase | ScriptWriterBase,
        target_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> tuple[TableColumnMetadata, TableColumnMetadata]:
        """Generate source and target table column metadata.

        This method handles the extraction of table column metadata from the source database
        and mapping it to the target. If the target is Snowflake, it will also extract
        case-sensitive column information to ensure proper column name matching between
        SQL Server and Snowflake.

        Args:
            table_configuration: Table configuration containing all necessary metadata
            source_extractor: Source extractor for metadata extraction
            target_extractor: Target extractor for metadata extraction
            context: Validation context

        Returns:
            Tuple[TableColumnMetadata, TableColumnMetadata]: Source and target metadata

        """
        LOGGER.info(
            "Loading table column metadata model for: %s",
            table_configuration.fully_qualified_name,
        )

        source_table_column_metadata, table_column_metadata_from_source_df = (
            self._extract_and_generate_source_metadata(
                table_configuration=table_configuration,
                source_extractor=source_extractor,
                context=context,
            )
        )

        LOGGER.debug("Successfully generated source table column metadata model")

        target_table_column_metadata = self._extract_and_generate_target_metadata(
            table_configuration=table_configuration,
            table_column_metadata_from_source_df=table_column_metadata_from_source_df,
            target_extractor=target_extractor,
            context=context,
        )

        LOGGER.debug("Successfully generated target table column metadata model")

        LOGGER.info(
            "Successfully loaded table column metadata model for: %s",
            table_configuration.fully_qualified_name,
        )

        return source_table_column_metadata, target_table_column_metadata

    @log
    def generate_source_table_column_metadata(
        self,
        table_configuration: TableConfiguration,
        source_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> TableColumnMetadata:
        """Generate source-only table column metadata.

        This method is used for source-only validation where only source metadata
        is needed without any target comparison.

        Args:
            table_configuration: Table configuration containing all necessary metadata
            source_extractor: Source extractor for metadata extraction
            context: Validation context

        Returns:
            TableColumnMetadata: Source table column metadata

        """
        LOGGER.info(
            "Loading source-only table column metadata for: %s",
            table_configuration.fully_qualified_name,
        )

        source_table_column_metadata, _ = self._extract_and_generate_source_metadata(
            table_configuration=table_configuration,
            source_extractor=source_extractor,
            context=context,
        )

        LOGGER.info(
            "Successfully loaded source-only table column metadata for: %s",
            table_configuration.fully_qualified_name,
        )

        return source_table_column_metadata

    def _extract_and_generate_source_metadata(
        self,
        table_configuration: TableConfiguration,
        source_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> tuple[TableColumnMetadata, pd.DataFrame]:
        """Extract and generate source table column metadata.

        Uses public API functions for query generation, execution, and processing.

        Args:
            table_configuration: Table configuration containing all necessary metadata
            source_extractor: Source extractor for metadata extraction
            context: Validation context

        Returns:
            tuple[TableColumnMetadata, pd.DataFrame]: A tuple containing:
                - TableColumnMetadata: Source table column metadata model
                - pd.DataFrame: Raw source table column metadata DataFrame,
                  used for generating target metadata with proper column mappings

        """
        column_metadata_query = data_validation_api.generate_column_metadata_query(
            table_configuration=table_configuration,
            platform=context.source_platform,
            sql_generator=context.sql_generator,
        )

        column_metadata_result = (
            data_validation_api.execute_query_from_table_configuration(
                table_configuration=table_configuration,
                platform=context.source_platform,
                connector=source_extractor.connector,
                generated_query=column_metadata_query,
            )
        )

        column_metadata_result = data_validation_api.normalize_table_column_metadata(
            platform=context.source_platform,
            database=table_configuration.source_database,
            schema=table_configuration.source_schema,
            table=table_configuration.source_table,
            object_type=table_configuration.object_type,
            metadata=column_metadata_result,
        )

        row_count_query = data_validation_api.generate_row_count_query(
            fully_qualified_name=table_configuration.fully_qualified_name,
            where_clause=table_configuration.where_clause,
            has_where_clause=table_configuration.has_where_clause,
            object_id=table_configuration.id,
            platform=context.source_platform,
            sql_generator=context.sql_generator,
        )

        row_count_result = data_validation_api.execute_query_from_table_configuration(
            table_configuration=table_configuration,
            platform=context.source_platform,
            connector=source_extractor.connector,
            generated_query=row_count_query,
        )

        source_row_count = data_validation_api.extract_row_count(row_count_result)

        LOGGER.debug(
            "Successfully loaded table row count for table: %s in platform: %s",
            table_configuration.fully_qualified_name,
            context.source_platform,
        )

        source_table_column_metadata = (
            data_validation_api.process_table_column_metadata(
                query_result=column_metadata_result,
                row_count=source_row_count,
                datatypes_mappings=context.datatypes_mappings,
                column_selection_list=table_configuration.column_selection_list,
            )
        )

        return source_table_column_metadata, column_metadata_result.dataframe

    def _extract_and_generate_target_metadata(
        self,
        table_configuration: TableConfiguration,
        table_column_metadata_from_source_df: pd.DataFrame,
        target_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> TableColumnMetadata:
        """Extract and generate target table column metadata.

        Uses public API functions for query generation, execution, and processing.

        Args:
            table_configuration: Table configuration containing all necessary metadata
            table_column_metadata_from_source_df: Source table column metadata DataFrame,
                used to derive target column names with proper mappings applied
            target_extractor: Target extractor for metadata extraction
            context: Validation context

        Returns:
            TableColumnMetadata: Target table column metadata

        """
        row_count_query = data_validation_api.generate_row_count_query(
            fully_qualified_name=table_configuration.target_fully_qualified_name,
            where_clause=table_configuration.target_where_clause,
            has_where_clause=table_configuration.has_target_where_clause,
            object_id=table_configuration.id,
            platform=context.target_platform,
            sql_generator=context.sql_generator,
        )

        row_count_result = data_validation_api.execute_query_from_table_configuration(
            table_configuration=table_configuration,
            platform=context.target_platform,
            connector=target_extractor.connector,
            generated_query=row_count_query,
        )

        target_row_count = data_validation_api.extract_row_count(row_count_result)

        case_sensitive_columns_df = self._extract_case_sensitive_columns(
            table_configuration=table_configuration,
            target_extractor=target_extractor,
            context=context,
        )

        LOGGER.debug(
            "Successfully loaded table row count for table: %s in platform: %s",
            table_configuration.internal_target_fully_qualified_name,
            context.target_platform,
        )

        target_table_column_metadata = data_validation_api.process_target_table_column_metadata_from_source_table(
            table_column_metadata_from_source_df=table_column_metadata_from_source_df,
            table_configuration=table_configuration,
            datatypes_mappings=context.datatypes_mappings,
            row_count=target_row_count,
            case_sensitive_columns_df=case_sensitive_columns_df,
        )

        return target_table_column_metadata

    def _extract_case_sensitive_columns(
        self,
        table_configuration: TableConfiguration,
        target_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> pd.DataFrame:
        """Extract case-sensitive column names from Snowflake target.

        Uses public API to generate and execute the case-sensitive columns query.

        Args:
            table_configuration: Table configuration containing target table info
            target_extractor: Target extractor for query execution
            context: Validation context

        Returns:
            pd.DataFrame: DataFrame with case-sensitive column names, or empty DataFrame

        """
        if context.target_platform != Platform.SNOWFLAKE:
            return pd.DataFrame()

        try:
            case_sensitive_query = (
                data_validation_api.generate_case_sensitive_columns_query(
                    sql_generator=context.sql_generator,
                    target_database_name=table_configuration.target_database,
                    target_schema_name=table_configuration.target_schema,
                    target_table_name=table_configuration.internal_target_name,
                    platform=context.target_platform,
                )
            )

            case_sensitive_result = (
                data_validation_api.execute_query_from_table_configuration(
                    table_configuration=table_configuration,
                    platform=context.target_platform,
                    connector=target_extractor.connector,
                    generated_query=case_sensitive_query,
                )
            )

            LOGGER.info("Found case-sensitive columns information for Snowflake target")
            return case_sensitive_result.dataframe

        except Exception as e:
            LOGGER.warning(
                "Could not extract case-sensitive column information: %s", str(e)
            )
            return pd.DataFrame()
