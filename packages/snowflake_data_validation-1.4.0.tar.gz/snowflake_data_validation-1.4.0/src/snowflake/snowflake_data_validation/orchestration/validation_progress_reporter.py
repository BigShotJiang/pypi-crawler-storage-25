# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os

from collections.abc import Callable

import pandas as pd

from snowflake.snowflake_data_validation.orchestration.html_report import (
    HtmlReportBuilder,
    ReportMetadata,
)
from snowflake.snowflake_data_validation.utils.constants import (
    EXECUTION_SUMMARY_REPORT_NAME,
    RESULTS_SUMMARY_REPORT_NAME,
)
from snowflake.snowflake_data_validation.utils.context import Context
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.progress_reporter import (
    ProgressMetadata,
    report_progress,
)
from snowflake.snowflake_data_validation.validation.results_summary_report import (
    ResultsSummaryReport,
)
from snowflake.snowflake_data_validation.validation.row_validation_report_buffer import (
    RowValidationReportBuffer,
)
from snowflake.snowflake_data_validation.validation.validation_database_manager import (
    ValidationDatabaseManager,
)
from snowflake.snowflake_data_validation.validation.validation_report_buffer import (
    ValidationReportBuffer,
)


LOGGER = logging.getLogger(__name__)

# Status emoji mappings
STATUS_EMOJI_MAP = {
    "SUCCESS": "✅ SUCCESS",
    "FAILURE": "❌ FAILURE",
    "WARNING": "⚠️ WARNING",
}


def _apply_status_emoji(df: pd.DataFrame, column: str = "STATUS") -> pd.DataFrame:
    """Apply emoji formatting to status values in a DataFrame.

    Args:
        df: DataFrame containing status values.
        column: Column name containing status values (default: "STATUS").

    Returns:
        pd.DataFrame: DataFrame with emoji-formatted status values.

    """
    if column in df.columns:
        df = df.copy()
        df[column] = df[column].replace(STATUS_EMOJI_MAP)
    return df


class ValidationProgressReporter:
    """Handles progress reporting and validation report management.

    Accepts an optional custom progress callback at construction time. When
    provided, ``report_progress_for_table`` delegates to the custom callback
    instead of the default stdout/pipe-based ``report_progress()`` mechanism.

    Args:
        progress_callback: Optional callback invoked for each table.
            Signature: (table_name: str, columns: list[str], context: Context | None) -> None

    """

    def __init__(
        self,
        progress_callback: (
            Callable[[str, list[str], Context | None], None] | None
        ) = None,
    ):
        """Initialize the reporter with an optional custom progress callback."""
        self._progress_callback = progress_callback

    @log
    def report_progress_for_table(
        self,
        table_name: str,
        column_selection_list: list[str],
        context: Context | None = None,
    ) -> None:
        """Report progress for a specific table.

        If a custom progress callback was provided at construction, it is
        called instead of the default reporting logic.

        Args:
            table_name: Name of the table being processed
            column_selection_list: List of columns being validated
            context: Validation context for run_id and run_start_time (optional)

        """
        if self._progress_callback is not None:
            try:
                self._progress_callback(table_name, column_selection_list, context)
            except Exception as e:
                LOGGER.warning(
                    "Error in custom progress callback for table %s: %s. "
                    "This is non-critical and validation will continue.",
                    table_name,
                    str(e),
                )
            return

        # Default behaviour: report via stdout/pipe (CLI IPC mode)
        # Only report progress if console output is not enabled
        if (
            context
            and hasattr(context, "output_handler")
            and not context.output_handler.console_output_enabled
        ):
            LOGGER.debug(
                "Reporting progress for table: %s with %d columns",
                table_name,
                len(column_selection_list),
            )
            progress_metadata = ProgressMetadata(
                table=table_name,
                columns=column_selection_list,
                run_id=context.run_id,
                run_start_time=context.run_start_time,
            )
            try:
                report_progress(progress_metadata)
            except OSError as e:
                if (
                    isinstance(e, BrokenPipeError) or e.errno == 32
                ):  # 32 is the error code for BrokenPipeError
                    LOGGER.warning(
                        "BrokenPipeError: Failed to report progress for table: %s. "
                        "This typically occurs when the parent process has closed the pipe. "
                        "This is non-critical and validation will continue.",
                        table_name,
                    )
                else:
                    LOGGER.warning(
                        "OSError reporting progress for table %s: %s. "
                        "This is non-critical and validation will continue.",
                        table_name,
                        str(e),
                    )
            except Exception as e:
                LOGGER.warning(
                    "Error reporting progress for table %s: %s. "
                    "This is non-critical and validation will continue.",
                    table_name,
                    str(e),
                )

    @log
    def flush_validation_reports(
        self, context: Context, db_manager: ValidationDatabaseManager
    ) -> None:
        """Flush all buffered validation data to the SQLite database.

        This method is called after all tables have been processed to write
        all accumulated validation results to the database.

        Args:
            context: Validation context containing report path and timing info
            db_manager: The ValidationDatabaseManager instance to use.

        """
        buffer = ValidationReportBuffer()

        if buffer.has_data():
            db_path = buffer.flush_to_database(context, db_manager)
            LOGGER.info(
                "Successfully flushed validation report buffer to database: %s", db_path
            )
        else:
            LOGGER.info("No validation data to flush - buffer is empty")

    @log
    def log_row_validation_summary(self, context: Context) -> None:
        """Log summary of row validation data written to the database.

        Since row validation data is written directly to the database as each
        table's validation completes, this method just logs the summary.

        Args:
            context: Validation context containing report path and timing info

        """
        buffer = RowValidationReportBuffer()

        if buffer.has_data():
            total_rows = buffer.get_total_rows_written()
            LOGGER.info(
                "Row validation complete: %d total rows written to database",
                total_rows,
            )
        else:
            LOGGER.info("No row validation data was written to the database")

    @log
    def generate_execution_summary_report(
        self, context: Context, db_manager: ValidationDatabaseManager
    ) -> None:
        """Generate execution summary report after validation is complete.

        This method compiles and logs a summary of the entire validation
        execution, including key metrics and outcomes.

        """
        if not db_manager.is_initialized():
            LOGGER.warning(
                "Skipping execution summary report - database not initialized"
            )
            return

        LOGGER.info("Generating execution summary report.")

        execution_summary_report_df = (
            db_manager.get_execution_summary_report_dataframe()
        )

        csv_filename = f"{context.run_start_time}_{EXECUTION_SUMMARY_REPORT_NAME}"
        csv_path = os.path.join(context.report_path, csv_filename)

        os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)

        execution_summary_report_df.to_csv(csv_path, index=False, encoding="utf-8")
        LOGGER.info(
            "Successfully wrote %d rows to execution summary report CSV: %s",
            len(execution_summary_report_df),
            csv_path,
        )

        LOGGER.info("Execution summary report generated.")

    @log
    def generate_results_summary_report(
        self, context: Context, results_summary: ResultsSummaryReport
    ) -> None:
        """Generate results summary report after validation is complete.

        This method compiles and logs a summary of the validation results,
        including key metrics and outcomes.

        Args:
            context: Validation context containing report path and timing info
            results_summary: The ResultsSummaryReport instance containing summary data

        """
        LOGGER.info("Generating results summary report.")

        schema_results_summary_df = _apply_status_emoji(
            results_summary.schema_results_summary
        )
        metrics_results_summary_df = _apply_status_emoji(
            results_summary.metrics_results_summary
        )
        row_results_summary_df = _apply_status_emoji(
            results_summary.row_results_summary
        )

        report_filename = f"{context.run_start_time}_{RESULTS_SUMMARY_REPORT_NAME}"
        report_path = os.path.join(context.report_path, report_filename)

        metadata = ReportMetadata.from_context(context)

        HtmlReportBuilder().add_header(
            "Validation Results Summary Report"
        ).add_metadata(metadata).add_summary_table(results_summary.summary).add_section(
            "SCHEMA VALIDATION SUMMARY",
            results_summary.schema_validation_summary,
            schema_results_summary_df,
        ).add_section(
            "METRICS VALIDATION SUMMARY",
            results_summary.metrics_validation_summary,
            metrics_results_summary_df,
        ).add_section(
            "ROW VALIDATION SUMMARY",
            results_summary.row_validation_summary,
            row_results_summary_df,
        ).add_scripts().add_footer().write_to_file(
            report_path
        )

        LOGGER.info("Results summary report generated.")
