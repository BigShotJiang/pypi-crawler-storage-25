# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Validator for comparing ResultSet objects."""

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.public.model.result_set import ResultSet
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_DATATYPES_MAPPING_NAME_FORMAT,
    Platform,
)
from snowflake.snowflake_data_validation.validation.dataframe_validator_base import (
    DataFrameValidatorBase,
)


class ResultSetValidator(DataFrameValidatorBase):
    """Validator class for comparing two ResultSet objects or DataFrames.

    This validator extends DataFrameValidatorBase and adds support for:
    - Converting ResultSet objects to Polars DataFrames with type casting
    - Loading datatype mappings for type translation

    Example:
        >>> validator = ResultSetValidator()
        >>> result = validator.metrics_level_validation(
        ...     first_result_set=result_set_1,
        ...     second_result_set=result_set_2,
        ...     column_mappings={},
        ...     tolerance=0.001,
        ... )

    """

    def __init__(
        self,
        custom_templates_directory: str | None = None,
    ):
        """Initialize the ResultSetValidator.

        Args:
            custom_templates_directory: Optional path to a directory containing
                custom template files. If not provided, uses the default templates.

        """
        super().__init__(
            platform=Platform.RESULT_SET,
            custom_templates_directory=custom_templates_directory,
        )

        # Load datatype mappings for ResultSet validation
        datatypes_file_path = (
            self.templates_directory_path
            / COLUMN_DATATYPES_MAPPING_NAME_FORMAT.format(
                source_platform=Platform.SNOWFLAKE.value,
                target_platform=Platform.RESULT_SET.value,
            )
        )
        self.datatypes_mappings = self._load_datatypes(
            datatypes_file_path=datatypes_file_path
        )

    def to_polars_dataframe(self, result_set: ResultSet) -> pl.DataFrame:
        """Convert a ResultSet object to a Polars DataFrame.

        Args:
            result_set: The ResultSet object to convert.

        Returns:
            A Polars DataFrame representing the data in the ResultSet,
            with columns cast to appropriate types based on the datatype mappings.

        """
        df = pl.DataFrame(data=result_set.rows)

        target_schema = self._translate_snowflake_schema_to_polars(
            column_types=result_set.column_types
        )

        cast_expressions = []
        for col_name, target_type in target_schema.items():
            if col_name not in df.columns:
                continue

            current_type = df[col_name].dtype
            cast_expr = self._build_cast_expression(
                col_name=col_name,
                current_type=current_type,
                target_type=target_type,
            )
            cast_expressions.append(cast_expr)

        if cast_expressions:
            df = df.with_columns(cast_expressions)

        return df

    def metrics_level_validation(
        self,
        first_result_set: ResultSet | pl.DataFrame,
        second_result_set: ResultSet | pl.DataFrame,
        column_mappings: dict[str, str],
        tolerance: float,
        object_name: str = "ResultSet Metrics Comparison",
    ) -> pd.DataFrame:
        """Compare two result sets at the metrics level.

        Args:
            first_result_set: The first result set or DataFrame to compare.
            second_result_set: The second result set or DataFrame to compare.
            column_mappings: Dictionary mapping columns between the result sets.
            tolerance: The tolerance level for metric comparisons.
            object_name: Name for the validation object (used in reporting).

        Returns:
            A pandas DataFrame containing the validation results.

        """
        if isinstance(first_result_set, ResultSet):
            first_df = self.to_polars_dataframe(result_set=first_result_set)
        else:
            first_df = first_result_set

        if isinstance(second_result_set, ResultSet):
            second_df = self.to_polars_dataframe(result_set=second_result_set)
        else:
            second_df = second_result_set

        return self._metrics_level_validation_internal(
            first_df=first_df,
            second_df=second_df,
            column_mappings=column_mappings,
            tolerance=tolerance,
            object_name=object_name,
        )

    def cell_level_validation(
        self,
        first_result_set: ResultSet | pl.DataFrame,
        second_result_set: ResultSet | pl.DataFrame,
        object_name: str = "ResultSet Cell Comparison",
    ) -> pd.DataFrame:
        """Validate the cell values between two result sets.

        Args:
            first_result_set: The first result set or DataFrame to compare.
            second_result_set: The second result set or DataFrame to compare.
            object_name: Name for the validation object (used in reporting).

        Returns:
            A pandas DataFrame containing the validation results for each cell,
            including whether the values match and any discrepancies found.

        """
        if isinstance(first_result_set, ResultSet):
            first_df = self.to_polars_dataframe(result_set=first_result_set)
        else:
            first_df = first_result_set

        if isinstance(second_result_set, ResultSet):
            second_df = self.to_polars_dataframe(result_set=second_result_set)
        else:
            second_df = second_result_set

        return self._cell_level_validation_internal(
            first_df=first_df,
            second_df=second_df,
            object_name=object_name,
        )
