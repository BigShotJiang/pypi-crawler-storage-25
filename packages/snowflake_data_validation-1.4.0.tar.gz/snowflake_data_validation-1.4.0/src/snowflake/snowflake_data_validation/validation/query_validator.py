# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Validator for comparing query results."""

import logging

import polars as pl

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.public.model.generated_query import (
    GeneratedQuery,
)
from snowflake.snowflake_data_validation.public.model.validation_result import (
    ValidationResult,
)
from snowflake.snowflake_data_validation.utils.constants import Platform
from snowflake.snowflake_data_validation.validation.dataframe_validator_base import (
    DataFrameValidatorBase,
)


LOGGER = logging.getLogger(__name__)


class QueryValidator(DataFrameValidatorBase):
    """Validator class for comparing query results as DataFrames.

    This validator extends DataFrameValidatorBase and adds support for:
    - Executing queries and converting results to Polars DataFrames
    - Optimized direct read using ConnectorX when available

    Example:
        >>> validator = QueryValidator()
        >>> df = validator.to_polars_dataframe(query=my_query, connector=my_connector)
        >>> result = validator.metrics_level_validation(
        ...     first_dataframe=df1,
        ...     second_dataframe=df2,
        ...     column_mappings={},
        ...     tolerance=0.001,
        ... )

    """

    def __init__(
        self,
        custom_templates_directory: str | None = None,
    ):
        """Initialize the QueryValidator.

        Args:
            custom_templates_directory: Optional directory path for custom
                metric query templates.

        """
        super().__init__(
            platform=Platform.QUERY,
            custom_templates_directory=custom_templates_directory,
        )

    def to_polars_dataframe(
        self,
        query: GeneratedQuery,
        connector: ConnectorBase,
    ) -> pl.DataFrame:
        """Execute a query and convert the result to a Polars DataFrame.

        If the connector has a direct read URI configured (via enable_direct_read=True
        during connection), this method will attempt to use Polars' optimized database
        reading with ConnectorX for improved performance. Falls back to the standard
        method if direct read is not available or fails.

        Args:
            query: The query to be executed, encapsulated in a GeneratedQuery object.
            connector: An instance of a connector that can execute the query.

        Returns:
            A Polars DataFrame containing the results of the executed query.

        """
        if connector._direct_read_uri:
            try:
                LOGGER.debug(
                    "Using direct read with ConnectorX for optimized performance"
                )
                return pl.read_database_uri(
                    query=query.query_string,
                    uri=connector._direct_read_uri,
                    engine="connectorx",
                )
            except Exception as e:
                LOGGER.warning(
                    "Direct read failed, falling back to standard method: %s", str(e)
                )

        result = connector.execute_query(query=query.query_string)

        # Handle connectors that return (column_names, rows) tuple format
        if isinstance(result, tuple) and len(result) == 2:
            column_names, rows = result
            # Convert rows to lists only if needed (e.g., pyodbc.Row objects)
            # Skip conversion for native tuples/lists to avoid overhead
            if rows and not isinstance(rows[0], list | tuple):
                rows = [list(row) for row in rows]
            return pl.DataFrame(data=rows, schema=column_names, orient="row")

        # Standard format: list of tuples/rows
        return pl.DataFrame(data=result)

    def metrics_level_validation(
        self,
        first_dataframe: pl.DataFrame,
        second_dataframe: pl.DataFrame,
        column_mappings: dict[str, str] | None = None,
        tolerance: float = 0.001,
    ) -> ValidationResult:
        """Compare two DataFrames at the metrics level.

        Args:
            first_dataframe: The first DataFrame to compare.
            second_dataframe: The second DataFrame to compare.
            column_mappings: Optional dictionary mapping columns between DataFrames.
            tolerance: The tolerance level for metric comparisons.

        Returns:
            ValidationResult containing whether the DataFrames are equivalent
            and any differences found.

        """
        if column_mappings is None:
            column_mappings = {}

        differences_data = self._metrics_level_validation_internal(
            first_df=first_dataframe,
            second_df=second_dataframe,
            column_mappings=column_mappings,
            tolerance=tolerance,
            object_name="QueryValidation Metrics Comparison",
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    def cell_level_validation(
        self,
        first_dataframe: pl.DataFrame,
        second_dataframe: pl.DataFrame,
    ) -> ValidationResult:
        """Compare two DataFrames at the cell level.

        Args:
            first_dataframe: The first DataFrame to compare.
            second_dataframe: The second DataFrame to compare.

        Returns:
            ValidationResult containing whether the DataFrames are equivalent
            and any differences found.

        """
        differences_data = self._cell_level_validation_internal(
            first_df=first_dataframe,
            second_df=second_dataframe,
            object_name="QueryValidation Cell Comparison",
        )

        validation_result = ValidationResult(
            is_valid=True,
            results_dataframe=differences_data,
        )

        return validation_result
