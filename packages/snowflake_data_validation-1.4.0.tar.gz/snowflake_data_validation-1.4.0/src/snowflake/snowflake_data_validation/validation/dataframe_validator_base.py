# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Base class for DataFrame validators."""

from pathlib import Path

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.public.model.query_generator_factory import (
    QueryGeneratorFactory,
)
from snowflake.snowflake_data_validation.utils.constants import (
    DEFAULT_OBJECT_ID,
    ObjectType,
    Origin,
    Platform,
)
from snowflake.snowflake_data_validation.utils.helper import Helper
from snowflake.snowflake_data_validation.utils.helpers.helper_misc import (
    get_current_timestamp,
)
from snowflake.snowflake_data_validation.utils.model.column_metadata import (
    ColumnMetadata,
)
from snowflake.snowflake_data_validation.utils.model.table_context import (
    create_table_context,
)
from snowflake.snowflake_data_validation.validation.cell_data_validator import (
    CellDataValidator,
)
from snowflake.snowflake_data_validation.validation.metrics_data_validator import (
    MetricsDataValidator,
)


# Base path for templates (relative to this module)
_TEMPLATES_BASE_PATH = Path(__file__).parent.parent


def _get_default_templates_dir(platform: Platform) -> Path:
    """Get the default templates directory for the specified platform.

    Args:
        platform: The platform to get templates for.

    Returns:
        Path to the platform's templates directory.

    """
    return _TEMPLATES_BASE_PATH / platform.value / "extractor" / "templates"


class DataFrameValidatorBase:
    """Base class for DataFrame validators.

    This class provides common functionality for validating DataFrames, including
    metrics-level and cell-level validation. Subclasses implement their specific
    data loading mechanisms (e.g., from ResultSet objects or query execution).

    Attributes:
        platform: The platform type (RESULT_SET or QUERY).
        templates_directory_path: Path to the templates directory.
        datatypes_mappings: Dictionary mapping database types to Polars types.

    """

    def __init__(
        self,
        platform: Platform,
        custom_templates_directory: str | None = None,
    ):
        """Initialize the DataFrame validator.

        Args:
            platform: The platform for which templates should be loaded
                (RESULT_SET or QUERY). This affects which default templates
                are used and the file naming pattern.
            custom_templates_directory: Optional path to a directory containing
                custom template files. If not provided, uses the default templates
                for the specified platform.

        """
        self.platform = platform
        self._use_custom_templates = custom_templates_directory is not None

        if custom_templates_directory is None:
            # Use default internal templates for the specified platform
            self.templates_directory_path = _get_default_templates_dir(platform)
        else:
            # Use custom templates with platform-specific naming
            self.templates_directory_path = Path(custom_templates_directory)

        self._templates_platform = platform

        # Initialize datatypes_mappings - subclasses may override this
        self.datatypes_mappings: dict[str, pl.DataType] = {}

    def _load_datatypes(self, datatypes_file_path: Path) -> dict[str, pl.DataType]:
        """Load datatype mappings from a YAML file.

        Args:
            datatypes_file_path: Path to the YAML file containing datatype mappings.

        Returns:
            Dictionary mapping database type names to Polars data types.

        """
        temp_datatypes_mappings: dict[str, str] = (
            Helper.load_datatypes_mapping_templates_from_yaml(
                yaml_path=datatypes_file_path
            )
        )
        datatypes_mappings: dict[str, pl.DataType] = {
            key: getattr(pl, value) for key, value in temp_datatypes_mappings.items()
        }
        return datatypes_mappings

    def _calculate_column_metrics(
        self,
        polar_df: pl.DataFrame,
        column_mappings: dict[str, str],
    ) -> pd.DataFrame:
        """Calculate column metrics for a DataFrame.

        Args:
            polar_df: The Polars DataFrame to calculate metrics for.
            column_mappings: Dictionary mapping source column names to target names.

        Returns:
            A pandas DataFrame containing the calculated metrics.

        """
        column_metadata_list = []
        for column in polar_df.columns:
            column_name = column_mappings.get(column, column)
            metadata = ColumnMetadata(
                name=column_name,
                data_type=str(polar_df.schema[column]).upper(),
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            )
            column_metadata_list.append(metadata)

        # Use the validator's platform templates for DataFrame metrics calculation
        templates_path = str(self.templates_directory_path)
        # Use platform-specific name for error messages (e.g., "ResultSet", "Query")
        platform_name = self.platform.value.replace("_", " ").title().replace(" ", "")
        table_context = create_table_context(
            columns=column_metadata_list,
            database_name="dataframe_database",
            fully_qualified_name=platform_name,
            id=1,
            internal_fully_qualified_name=platform_name,
            internal_table_name=platform_name,
            object_type=ObjectType.RESULT_SET,
            origin=Origin.SOURCE,
            platform=self.platform,
            queries_templates_directory_path=templates_path,
            row_count=len(polar_df),
            run_id=1,
            run_start_time=get_current_timestamp(include_microseconds=True),
            schema_name="dataframe_schema",
            table_name="dataframe_table",
            templates_directory_path=templates_path,
        )

        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_metrics_query(
            table_context=table_context,
        )

        metrics_df = polar_df.sql(query=query_string).to_pandas()
        return metrics_df

    def _metrics_level_validation_internal(
        self,
        first_df: pl.DataFrame,
        second_df: pl.DataFrame,
        column_mappings: dict[str, str],
        tolerance: float,
        object_name: str,
    ) -> pd.DataFrame:
        """Implement metrics-level validation internally.

        Args:
            first_df: The first DataFrame to compare.
            second_df: The second DataFrame to compare.
            column_mappings: Dictionary mapping columns between DataFrames.
            tolerance: The tolerance level for metric comparisons.
            object_name: Name for the validation object (used in reporting).

        Returns:
            A pandas DataFrame containing the validation results.

        """
        first_metrics_df = self._calculate_column_metrics(
            polar_df=first_df,
            column_mappings={},  # No mapping needed for source metrics calculation
        )

        second_metrics_df = self._calculate_column_metrics(
            polar_df=second_df,
            column_mappings=column_mappings,
        )

        metrics_validator = MetricsDataValidator()
        validation_results = metrics_validator.validate_column_metadata(
            object_name=object_name,
            object_id=DEFAULT_OBJECT_ID,
            object_type=ObjectType.RESULT_SET,
            source_df=first_metrics_df,
            target_df=second_metrics_df,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        return validation_results

    def _cell_level_validation_internal(
        self,
        first_df: pl.DataFrame,
        second_df: pl.DataFrame,
        object_name: str,
        index_columns: list[str] | None = None,
        target_index_columns: list[str] | None = None,
    ) -> pd.DataFrame:
        """Implement cell-level validation internally.

        Args:
            first_df: The first DataFrame to compare.
            second_df: The second DataFrame to compare.
            object_name: Name for the validation object (used in reporting).
            index_columns: Source-side key column names for row matching.
                When ``None``, rows are matched positionally.
            target_index_columns: Target-side key column names.
                Defaults to *index_columns* when ``None``.

        Returns:
            A pandas DataFrame containing the validation results.

        """
        cell_validator = CellDataValidator()
        validation_results = cell_validator.validate_cell_comparison(
            object_name=object_name,
            source_df=first_df,
            target_df=second_df,
            index_columns=index_columns,
            target_index_columns=target_index_columns,
        )

        return validation_results

    def _build_cast_expression(
        self,
        col_name: str,
        current_type: pl.DataType,
        target_type: pl.DataType,
    ) -> pl.Expr:
        """Build a Polars expression to cast a column to a target type.

        Handles special cases for temporal types (Datetime, Date, Time) and Boolean
        when the source is a string, using appropriate parsing methods instead of
        direct casting.

        Args:
            col_name: The name of the column to cast.
            current_type: The current Polars data type of the column.
            target_type: The target Polars data type to cast to.

        Returns:
            A Polars expression that casts the column to the target type.

        """
        col_expr = pl.col(col_name)

        if target_type == pl.Datetime:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_datetime(strict=False)
            else:
                col_expr = col_expr.cast(pl.Datetime, strict=False)
        elif target_type == pl.Date:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_date(strict=False)
            else:
                col_expr = col_expr.cast(pl.Date, strict=False)
        elif target_type == pl.Time:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_time(strict=False)
            else:
                col_expr = col_expr.cast(pl.Time, strict=False)
        elif target_type == pl.Boolean:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_lowercase().is_in(["true", "1", "yes"])
            else:
                col_expr = col_expr.cast(pl.Boolean, strict=False)
        else:
            col_expr = col_expr.cast(target_type, strict=False)

        return col_expr.alias(col_name)

    def _translate_snowflake_schema_to_polars(
        self, column_types: dict[str, str]
    ) -> dict[str, pl.DataType]:
        """Translate database column types to Polars data types.

        Args:
            column_types: Dictionary mapping column names to database type names.

        Returns:
            Dictionary mapping column names to Polars data types.

        """
        translated_schema = {}
        for column_name, column_type in column_types.items():
            normalized_type = column_type.upper()
            if normalized_type in self.datatypes_mappings:
                translated_schema[column_name] = self.datatypes_mappings[
                    normalized_type
                ]
            else:
                # Default to string type if the data type is unrecognized
                translated_schema[column_name] = pl.Utf8

        return translated_schema
