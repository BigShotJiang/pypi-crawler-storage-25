# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Abstract base class for validation database connections."""

from abc import ABC, abstractmethod

import pandas as pd


class ValidationDatabaseConnectionBase(ABC):
    """Abstract base class for validation database connections.

    This interface defines the contract for database connections used to store
    validation reports. Implementations can support different database backends
    such as SQLite, Snowflake, or other databases.
    """

    @abstractmethod
    def __init__(self, context) -> None:
        """Initialize the database connection with the execution context.

        Args:
            context: The execution context containing configuration and runtime info.

        """
        pass

    @abstractmethod
    def initialize(self) -> str:
        """Initialize the database connection and create required tables.

        Returns:
            str: Connection identifier (e.g., file path for SQLite, table path for Snowflake).

        """
        pass

    @abstractmethod
    def upload_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload validation report data to the database.

        Args:
            dataframe: DataFrame containing validation report data.

        Returns:
            int: Number of rows inserted.

        """
        pass

    @abstractmethod
    def upload_row_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation report data to the database.

        Args:
            dataframe: DataFrame containing row validation report data.

        Returns:
            int: Number of rows inserted.

        """
        pass

    @abstractmethod
    def upload_row_validation_execution_status(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation execution status data to the database.

        Args:
            dataframe: DataFrame containing row validation execution status data.

        Returns:
            int: Number of rows inserted.

        """
        pass

    @abstractmethod
    def get_connection_identifier(self) -> str | None:
        """Get the connection identifier.

        Returns:
            str | None: The connection identifier, or None if not initialized.

        """
        pass

    @abstractmethod
    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute a SQL query and return the results as a DataFrame.

        Args:
            query: The SQL query to execute.

        Returns:
            pd.DataFrame: Query results as a DataFrame.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        pass

    @abstractmethod
    def close(self) -> None:
        """Close the database connection and clean up resources."""
        pass

    @abstractmethod
    def cleanup(self) -> None:
        """Clean up the database file after reports have been generated.

        This method should remove the temporary database file from the filesystem.
        """
        pass

    @abstractmethod
    def get_execution_summary_report_query(self) -> str:
        """Get the SQL query for generating execution summary report.

        Returns:
            str: SQL query string for execution summary report.

        """
        pass

    @abstractmethod
    def get_validation_summary_query(self) -> str:
        """Get the SQL query for generating validation summary.

        Returns:
            str: SQL query string for validation summary.

        """
        pass

    @abstractmethod
    def get_schema_validation_summary_query(self) -> str:
        """Get the SQL query for generating schema validation summary.

        Returns:
            str: SQL query string for schema validation summary.

        """
        pass

    @abstractmethod
    def get_metrics_validation_summary_query(self) -> str:
        """Get the SQL query for generating metrics validation summary.

        Returns:
            str: SQL query string for metrics validation summary.

        """
        pass

    @abstractmethod
    def get_row_validation_summary_query(self) -> str:
        """Get the SQL query for generating row validation summary.

        Returns:
            str: SQL query string for row validation summary.

        """
        pass

    @abstractmethod
    def get_schema_validation_results_summary_query(self) -> str:
        """Get the SQL query for generating schema validation results summary.

        Returns:
            str: SQL query string for schema validation results summary.

        """
        pass

    @abstractmethod
    def get_metrics_validation_results_summary_query(self) -> str:
        """Get the SQL query for generating metrics validation results summary.

        Returns:
            str: SQL query string for metrics validation results summary.

        """
        pass

    @abstractmethod
    def get_row_validation_results_summary_query(self) -> str:
        """Get the SQL query for generating row validation results summary.

        Returns:
            str: SQL query string for row validation results summary.

        """
        pass
