# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""SQLite implementation of the validation database connection."""

import logging
import os
import sqlite3

from collections.abc import Generator
from contextlib import contextmanager

import pandas as pd

from snowflake.snowflake_data_validation.utils.constants import (
    METRICS_VALIDATION_STATUS,
    ROW_VALIDATION_EXECUTION_STATUS_TABLE,
    ROW_VALIDATION_REPORT_TABLE,
    ROW_VALIDATION_STATUS,
    SCHEMA_VALIDATION_STATUS,
    VALIDATION_DATABASE_NAME,
    VALIDATION_REPORT_TABLE,
    Result,
)
from snowflake.snowflake_data_validation.validation.validation_database.validation_database_connection_base import (
    ValidationDatabaseConnectionBase,
)


LOGGER = logging.getLogger(__name__)


class SQLiteValidationConnection(ValidationDatabaseConnectionBase):
    """SQLite implementation of the validation database connection.

    This implementation stores validation reports in a local SQLite database file.
    """

    def __init__(self, context):
        """Initialize the SQLite connection with the execution context.

        Args:
            context: The execution context containing report path and run start time.

        """
        self._context = context
        self._db_path: str | None = None
        LOGGER.debug("SQLiteValidationConnection initialized with context")

    def initialize(self) -> str:
        """Initialize the SQLite database with the required tables.

        Returns:
            str: The path to the database file.

        """
        self._db_path = self._get_database_path()
        LOGGER.info("Initializing SQLite validation database: %s", self._db_path)

        with self._get_connection() as conn:
            self._create_validation_report_table(conn)
            self._create_row_validation_report_table(conn)
            self._create_row_validation_execution_status_table(conn)

        LOGGER.info("SQLite validation database initialized successfully")
        return self._db_path

    def _get_database_path(self) -> str:
        """Get the full path for the validation database file.

        Returns:
            str: The full path to the validation database file.

        """
        return os.path.join(
            self._context.report_path,
            f"{self._context.run_start_time}_{VALIDATION_DATABASE_NAME}",
        )

    @contextmanager
    def _get_connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Get a database connection as a context manager.

        Yields:
            sqlite3.Connection: A database connection.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        if self._db_path is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")

        conn = sqlite3.connect(self._db_path)
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _create_validation_report_table(self, conn: sqlite3.Connection) -> None:
        """Create the validation report table if it doesn't exist.

        Args:
            conn: SQLite database connection.

        """
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {VALIDATION_REPORT_TABLE} (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            EXECUTION_ID TEXT,
            VALIDATION_TYPE TEXT,
            OBJECT_NAME TEXT,
            OBJECT_TYPE TEXT,
            OBJECT_ID INTEGER,
            COLUMN_VALIDATED TEXT,
            EVALUATION_CRITERIA TEXT,
            SOURCE_VALUE TEXT,
            SNOWFLAKE_VALUE TEXT,
            STATUS TEXT,
            COMMENTS TEXT
        )
        """
        conn.execute(create_table_sql)
        LOGGER.debug("Validation report table created/verified")

    def _create_row_validation_report_table(self, conn: sqlite3.Connection) -> None:
        """Create the row validation report table if it doesn't exist.

        Args:
            conn: SQLite database connection.

        """
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {ROW_VALIDATION_REPORT_TABLE} (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            EXECUTION_ID TEXT,
            OBJECT_NAME TEXT,
            OBJECT_TYPE TEXT,
            OBJECT_ID INTEGER,
            RESULT TEXT
        )
        """
        conn.execute(create_table_sql)
        LOGGER.debug("Row validation report table created/verified")

    def _create_row_validation_execution_status_table(
        self, conn: sqlite3.Connection
    ) -> None:
        """Create the row validation execution status table if it doesn't exist.

        Args:
            conn: SQLite database connection.

        """
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {ROW_VALIDATION_EXECUTION_STATUS_TABLE} (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            EXECUTION_ID TEXT,
            OBJECT_NAME TEXT,
            OBJECT_TYPE TEXT,
            OBJECT_ID INTEGER,
            STATUS TEXT
        )
        """
        conn.execute(create_table_sql)
        LOGGER.debug("Row validation execution status table created/verified")

    def upload_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload validation report data to the SQLite database.

        Args:
            dataframe: DataFrame containing validation report data.

        Returns:
            int: Number of rows inserted.

        """
        if dataframe.empty:
            LOGGER.debug("No validation data to write")
            return 0

        df_to_insert = self._prepare_validation_dataframe(dataframe)

        with self._get_connection() as conn:
            df_to_insert.to_sql(
                VALIDATION_REPORT_TABLE,
                conn,
                if_exists="append",
                index=False,
            )

        rows_inserted = len(df_to_insert)
        LOGGER.info(
            "Successfully wrote %d rows to validation report table", rows_inserted
        )
        return rows_inserted

    def _prepare_validation_dataframe(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """Prepare validation DataFrame for insertion.

        Args:
            dataframe: Raw DataFrame from validation buffer.

        Returns:
            pd.DataFrame: DataFrame ready for database insertion.

        """
        column_mapping = {"TABLE": "OBJECT_NAME"}

        df_to_insert = dataframe.rename(columns=column_mapping)
        # Add EXECUTION_ID column from context as the first column
        df_to_insert.insert(0, "EXECUTION_ID", self._context.run_id)
        return df_to_insert

    def upload_row_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation report data to the SQLite database.

        Args:
            dataframe: DataFrame containing row validation report data.

        Returns:
            int: Number of rows inserted.

        """
        if dataframe.empty:
            LOGGER.debug("No row validation data to write")
            return 0

        df_to_insert = self._prepare_row_validation_dataframe(dataframe)

        with self._get_connection() as conn:
            df_to_insert.to_sql(
                ROW_VALIDATION_REPORT_TABLE,
                conn,
                if_exists="append",
                index=False,
            )

        rows_inserted = len(df_to_insert)
        LOGGER.info(
            "Successfully wrote %d rows to row validation report table", rows_inserted
        )
        return rows_inserted

    def _prepare_row_validation_dataframe(
        self, dataframe: pd.DataFrame
    ) -> pd.DataFrame:
        """Prepare row validation DataFrame for insertion.

        Args:
            dataframe: Raw DataFrame from row validation buffer.

        Returns:
            pd.DataFrame: DataFrame ready for database insertion.

        """
        column_mapping = {
            "TABLE_NAME": "OBJECT_NAME",
        }

        df_to_insert = dataframe.rename(columns=column_mapping)
        # Add EXECUTION_ID column from context
        df_to_insert["EXECUTION_ID"] = self._context.run_id

        final_columns = [
            "EXECUTION_ID",
            "OBJECT_NAME",
            "OBJECT_TYPE",
            "OBJECT_ID",
            "RESULT",
        ]
        return df_to_insert[
            [col for col in final_columns if col in df_to_insert.columns]
        ]

    def upload_row_validation_execution_status(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation execution status data to the SQLite database.

        Args:
            dataframe: DataFrame containing row validation execution status data.

        Returns:
            int: Number of rows inserted.

        """
        if dataframe.empty:
            LOGGER.debug("No row validation execution status data to write")
            return 0

        df_to_insert = self._prepare_row_validation_execution_status_dataframe(
            dataframe
        )

        with self._get_connection() as conn:
            df_to_insert.to_sql(
                ROW_VALIDATION_EXECUTION_STATUS_TABLE,
                conn,
                if_exists="append",
                index=False,
            )

        rows_inserted = len(df_to_insert)
        LOGGER.info(
            "Successfully wrote %d rows to row validation execution status table",
            rows_inserted,
        )
        return rows_inserted

    def _prepare_row_validation_execution_status_dataframe(
        self, dataframe: pd.DataFrame
    ) -> pd.DataFrame:
        """Prepare row validation execution status DataFrame for insertion.

        Args:
            dataframe: Raw DataFrame from row validation execution status.

        Returns:
            pd.DataFrame: DataFrame ready for database insertion.

        """
        column_mapping = {
            "TABLE_NAME": "OBJECT_NAME",
        }

        df_to_insert = dataframe.rename(columns=column_mapping)
        # Add EXECUTION_ID column from context
        df_to_insert["EXECUTION_ID"] = self._context.run_id

        final_columns = [
            "EXECUTION_ID",
            "OBJECT_NAME",
            "OBJECT_TYPE",
            "OBJECT_ID",
            "STATUS",
        ]
        return df_to_insert[
            [col for col in final_columns if col in df_to_insert.columns]
        ]

    def get_connection_identifier(self) -> str | None:
        """Get the database file path.

        Returns:
            str | None: The database path, or None if not initialized.

        """
        return self._db_path

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute a SQL query and return the results as a DataFrame.

        Args:
            query: The SQL query to execute.

        Returns:
            pd.DataFrame: Query results as a DataFrame.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        if self._db_path is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")

        with self._get_connection() as conn:
            result = pd.read_sql_query(query, conn)

        LOGGER.debug("Executed query, returned %d rows", len(result))
        return result

    def close(self) -> None:
        """Close the SQLite connection and clean up resources."""
        self._db_path = None
        LOGGER.debug("SQLiteValidationConnection closed")

    def cleanup(self) -> None:
        """Remove the SQLite database file from the filesystem.

        This method should be called after all reports have been generated
        to clean up the temporary database file.
        """
        if self._db_path is not None and os.path.exists(self._db_path):
            try:
                os.remove(self._db_path)
                LOGGER.info("SQLite database file removed: %s", self._db_path)
            except OSError as e:
                LOGGER.warning(
                    "Failed to remove SQLite database file %s: %s", self._db_path, e
                )
        self._db_path = None

    def get_execution_summary_report_query(self) -> str:
        query_template = f"""
WITH SCHEMA_VALIDATION_SUMMARY AS (
    SELECT
        EXECUTION_ID,
        OBJECT_NAME,
        OBJECT_TYPE,
        OBJECT_ID,
        IIF(FAILURE_COUNT = 0, '{Result.SUCCESS.value}', '{Result.FAILURE.value}') AS {SCHEMA_VALIDATION_STATUS}
    FROM (
        SELECT
            EXECUTION_ID,
            OBJECT_NAME,
            OBJECT_TYPE,
            OBJECT_ID,
            SUM(IIF(STATUS = '{Result.FAILURE.value}', 1, 0)) AS FAILURE_COUNT
        FROM {VALIDATION_REPORT_TABLE}
        WHERE STATUS IN ('{Result.SUCCESS.value}', '{Result.FAILURE.value}')
            AND VALIDATION_TYPE = 'SCHEMA VALIDATION'
        GROUP BY EXECUTION_ID, OBJECT_NAME, OBJECT_TYPE, OBJECT_ID
    )
),

METRICS_VALIDATION_SUMMARY AS (
    SELECT
        EXECUTION_ID,
        OBJECT_NAME,
        OBJECT_TYPE,
        OBJECT_ID,
        IIF(FAILURE_COUNT = 0, '{Result.SUCCESS.value}', '{Result.FAILURE.value}') AS {METRICS_VALIDATION_STATUS}
    FROM (
        SELECT
            EXECUTION_ID,
            OBJECT_NAME,
            OBJECT_TYPE,
            OBJECT_ID,
            SUM(IIF(STATUS = '{Result.FAILURE.value}', 1, 0)) AS FAILURE_COUNT
        FROM {VALIDATION_REPORT_TABLE}
        WHERE STATUS IN ('{Result.SUCCESS.value}', '{Result.FAILURE.value}')
            AND VALIDATION_TYPE = 'METRICS VALIDATION'
        GROUP BY EXECUTION_ID, OBJECT_NAME, OBJECT_TYPE, OBJECT_ID
    )
),

ROW_VALIDATION_SUMMARY AS (
    SELECT
        EXECUTION_ID,
        OBJECT_NAME,
        OBJECT_TYPE,
        OBJECT_ID,
        STATUS AS {ROW_VALIDATION_STATUS}
    FROM {ROW_VALIDATION_EXECUTION_STATUS_TABLE}
    GROUP BY EXECUTION_ID, OBJECT_NAME, OBJECT_TYPE, OBJECT_ID, STATUS
)

SELECT
    SVS.EXECUTION_ID,
    SVS.OBJECT_NAME,
    SVS.OBJECT_TYPE,
    SVS.OBJECT_ID,
    COALESCE(SVS.{SCHEMA_VALIDATION_STATUS}, 'N/A') AS {SCHEMA_VALIDATION_STATUS},
    COALESCE(MVS.{METRICS_VALIDATION_STATUS}, 'N/A') AS {METRICS_VALIDATION_STATUS},
    COALESCE(RVS.{ROW_VALIDATION_STATUS}, 'N/A') AS {ROW_VALIDATION_STATUS}
FROM SCHEMA_VALIDATION_SUMMARY AS SVS
LEFT JOIN METRICS_VALIDATION_SUMMARY AS MVS
    ON SVS.OBJECT_NAME = MVS.OBJECT_NAME
    AND SVS.OBJECT_TYPE = MVS.OBJECT_TYPE
    AND SVS.OBJECT_ID = MVS.OBJECT_ID
LEFT JOIN ROW_VALIDATION_SUMMARY AS RVS
    ON SVS.OBJECT_NAME = RVS.OBJECT_NAME
    AND SVS.OBJECT_TYPE = RVS.OBJECT_TYPE
    AND SVS.OBJECT_ID = RVS.OBJECT_ID
ORDER BY SVS.OBJECT_NAME, SVS.OBJECT_TYPE;
"""
        return query_template

    def get_validation_summary_query(self) -> str:
        query_template = f"""
WITH SUMMARY_OBJECT_EXECUTION AS (
    SELECT OBJECT_NAME, OBJECT_TYPE FROM {VALIDATION_REPORT_TABLE}
    UNION
    SELECT OBJECT_NAME, OBJECT_TYPE FROM {ROW_VALIDATION_REPORT_TABLE}
)
SELECT
    UPPER(OBJECT_TYPE) AS 'OBJECT TYPE',
    COUNT(OBJECT_TYPE) AS 'NUMBER OF OBJECTS VALIDATED'
FROM SUMMARY_OBJECT_EXECUTION
GROUP BY OBJECT_TYPE
UNION ALL
SELECT
    'TOTAL',
    COUNT(OBJECT_TYPE) AS 'NUMBER OF OBJECTS VALIDATED'
FROM SUMMARY_OBJECT_EXECUTION;
"""
        return query_template

    def get_schema_validation_summary_query(self) -> str:
        query_template = f"""
    WITH SCHEMA_VALIDATION_SUMMARY AS (
        SELECT
        OBJECT_NAME,
        OBJECT_TYPE,
        IIF(
            SUM(IIF(STATUS = '{Result.FAILURE.value}', 1, 0)) = 0,
            '{Result.SUCCESS.value}',
            '{Result.FAILURE.value}'
        ) AS {SCHEMA_VALIDATION_STATUS}
        FROM {VALIDATION_REPORT_TABLE}
        WHERE STATUS IN ('{Result.SUCCESS.value}', '{Result.FAILURE.value}')
        AND VALIDATION_TYPE = 'SCHEMA VALIDATION'
        GROUP BY OBJECT_NAME, OBJECT_TYPE
    )
    SELECT
        UPPER(OBJECT_TYPE) AS "OBJECT TYPE",
        COUNT(*) FILTER (
        WHERE {SCHEMA_VALIDATION_STATUS} = '{Result.SUCCESS.value}'
        ) AS {Result.SUCCESS.value},
        COUNT(*) FILTER (
        WHERE {SCHEMA_VALIDATION_STATUS} = '{Result.FAILURE.value}'
        ) AS {Result.FAILURE.value}
    FROM SCHEMA_VALIDATION_SUMMARY GROUP BY OBJECT_TYPE
    UNION ALL
    SELECT
        'TOTAL',
        COUNT(*) FILTER (
        WHERE {SCHEMA_VALIDATION_STATUS} = '{Result.SUCCESS.value}'
        ) AS {Result.SUCCESS.value},
        COUNT(*) FILTER (
        WHERE {SCHEMA_VALIDATION_STATUS} = '{Result.FAILURE.value}'
        ) AS {Result.FAILURE.value}
    FROM SCHEMA_VALIDATION_SUMMARY;
    """
        return query_template

    def get_metrics_validation_summary_query(self) -> str:
        query_template = f"""
    WITH METRICS_VALIDATION_SUMMARY AS (
        SELECT
        OBJECT_NAME,
        OBJECT_TYPE,
        IIF(
            SUM(IIF(STATUS = '{Result.FAILURE.value}', 1, 0)) = 0,
            '{Result.SUCCESS.value}',
            '{Result.FAILURE.value}'
        ) AS {METRICS_VALIDATION_STATUS}
        FROM {VALIDATION_REPORT_TABLE}
        WHERE STATUS IN ('{Result.SUCCESS.value}', '{Result.FAILURE.value}')
        AND VALIDATION_TYPE = 'METRICS VALIDATION'
        GROUP BY OBJECT_NAME, OBJECT_TYPE
    )
    SELECT
        UPPER(OBJECT_TYPE) AS "OBJECT TYPE",
        COUNT(*) FILTER (
        WHERE {METRICS_VALIDATION_STATUS} = '{Result.SUCCESS.value}'
        ) AS {Result.SUCCESS.value},
        COUNT(*) FILTER (
        WHERE {METRICS_VALIDATION_STATUS} = '{Result.FAILURE.value}'
        ) AS {Result.FAILURE.value}
    FROM METRICS_VALIDATION_SUMMARY GROUP BY OBJECT_TYPE
    UNION ALL
    SELECT
        'TOTAL',
        COUNT(*) FILTER (
        WHERE {METRICS_VALIDATION_STATUS} = '{Result.SUCCESS.value}'
        ) AS {Result.SUCCESS.value},
        COUNT(*) FILTER (
        WHERE {METRICS_VALIDATION_STATUS} = '{Result.FAILURE.value}'
        ) AS {Result.FAILURE.value}
    FROM METRICS_VALIDATION_SUMMARY;
    """

        return query_template

    def get_row_validation_summary_query(self) -> str:
        query_template = f"""
WITH ROW_VALIDATION_SUMMARY AS (
    SELECT
        OBJECT_NAME,
        OBJECT_TYPE,
        STATUS AS {ROW_VALIDATION_STATUS}
    FROM {ROW_VALIDATION_EXECUTION_STATUS_TABLE}
    GROUP BY OBJECT_NAME, OBJECT_TYPE, STATUS
)
SELECT
    UPPER(OBJECT_TYPE) AS "OBJECT TYPE",
    COUNT(*) FILTER (WHERE {ROW_VALIDATION_STATUS} = '{Result.SUCCESS.value}') AS {Result.SUCCESS.value},
    COUNT(*) FILTER (WHERE {ROW_VALIDATION_STATUS} = '{Result.FAILURE.value}') AS {Result.FAILURE.value}
FROM ROW_VALIDATION_SUMMARY GROUP BY OBJECT_TYPE
UNION ALL
SELECT
    'TOTAL',
    COUNT(*) FILTER (WHERE {ROW_VALIDATION_STATUS} = '{Result.SUCCESS.value}') AS {Result.SUCCESS.value},
    COUNT(*) FILTER (WHERE {ROW_VALIDATION_STATUS} = '{Result.FAILURE.value}') AS {Result.FAILURE.value}
FROM ROW_VALIDATION_SUMMARY;
"""
        return query_template

    def get_schema_validation_results_summary_query(self) -> str:
        query_template = f"""
WITH VALIDATION_STATUS_COUNT_SUMMARY AS (SELECT
    OBJECT_NAME,
    OBJECT_ID,
    UPPER(OBJECT_TYPE) AS OBJECT_TYPE,
    COUNT(*) FILTER (WHERE STATUS = 'SUCCESS') AS SUCCESS,
    COUNT(*) FILTER (WHERE STATUS = 'WARNING') AS WARNING,
    COUNT(*) FILTER (WHERE STATUS = 'FAILURE') AS FAILURE
FROM {VALIDATION_REPORT_TABLE}
WHERE VALIDATION_TYPE = 'SCHEMA VALIDATION'
GROUP BY OBJECT_TYPE, OBJECT_NAME, OBJECT_ID ORDER BY OBJECT_TYPE, OBJECT_ID)
SELECT
    OBJECT_NAME AS NAME,
    OBJECT_ID AS ID,
    OBJECT_TYPE AS TYPE,
    SUCCESS,
    WARNING,
    FAILURE,
    IIF(FAILURE > 0, 'FAILURE', 'SUCCESS') AS STATUS
FROM VALIDATION_STATUS_COUNT_SUMMARY
"""
        return query_template

    def get_metrics_validation_results_summary_query(self) -> str:
        query_template = f"""
WITH VALIDATION_STATUS_COUNT_SUMMARY AS (SELECT
    OBJECT_NAME,
    OBJECT_ID,
    UPPER(OBJECT_TYPE) AS OBJECT_TYPE,
    COUNT(*) FILTER (WHERE STATUS = 'SUCCESS') AS SUCCESS,
    COUNT(*) FILTER (WHERE STATUS = 'WARNING') AS WARNING,
    COUNT(*) FILTER (WHERE STATUS = 'FAILURE') AS FAILURE
FROM {VALIDATION_REPORT_TABLE}
WHERE VALIDATION_TYPE = 'METRICS VALIDATION'
GROUP BY OBJECT_TYPE, OBJECT_NAME, OBJECT_ID
ORDER BY OBJECT_TYPE, OBJECT_ID)
SELECT
    OBJECT_NAME AS NAME,
    OBJECT_ID AS ID,
    OBJECT_TYPE AS TYPE,
    SUCCESS,
    WARNING,
    FAILURE,
    IIF(FAILURE > 0, 'FAILURE', 'SUCCESS') AS STATUS
FROM VALIDATION_STATUS_COUNT_SUMMARY
"""
        return query_template

    def get_row_validation_results_summary_query(self) -> str:
        query_template = f"""
SELECT
    RVES.OBJECT_NAME AS NAME,
    RVES.OBJECT_ID AS ID,
    UPPER(RVES.OBJECT_TYPE) AS TYPE,
    COUNT(*) FILTER (WHERE RVR.RESULT = 'FAILURE') AS FAILURE,
    COUNT(*) FILTER (WHERE RVR.RESULT = 'NOT_FOUND_SOURCE') AS 'NOT FOUND IN SOURCE',
    COUNT(*) FILTER (WHERE RVR.RESULT = 'NOT_FOUND_TARGET') AS 'NOT FOUND IN TARGET',
    RVES.STATUS
FROM {ROW_VALIDATION_EXECUTION_STATUS_TABLE} AS RVES
LEFT JOIN
{ROW_VALIDATION_REPORT_TABLE} RVR
ON RVES.EXECUTION_ID AND RVR.EXECUTION_ID
AND RVES.OBJECT_NAME = RVR.OBJECT_NAME
AND RVES.OBJECT_ID = RVR.OBJECT_ID
GROUP BY RVES.OBJECT_NAME, RVES.OBJECT_ID, RVES.OBJECT_TYPE, RVES.STATUS
ORDER BY RVES.OBJECT_ID;
"""
        return query_template
