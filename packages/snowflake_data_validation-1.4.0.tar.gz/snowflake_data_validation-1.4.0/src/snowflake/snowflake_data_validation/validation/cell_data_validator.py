import logging

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.utils.constants import (
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_ROW_KEY,
    DIFF_COL_SOURCE_VALUE_KEY,
    DIFF_COL_TARGET_VALUE_KEY,
)
from snowflake.snowflake_data_validation.validation.data_validator_base import (
    DataValidatorBase,
)


ROW_INDEX_CONST = "__row_idx__"

LOGGER = logging.getLogger(__name__)

RESULT_COLUMNS = [
    DIFF_COL_ROW_KEY,
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_SOURCE_VALUE_KEY,
    DIFF_COL_TARGET_VALUE_KEY,
]


class CellDataValidator(DataValidatorBase):
    """Validator for performing cell-level comparisons between source and target DataFrames."""

    def validate_cell_comparison(
        self,
        object_name: str,
        source_df: pl.DataFrame,
        target_df: pl.DataFrame,
        positional: bool = True,
        index_columns: list[str] | None = None,
        target_index_columns: list[str] | None = None,
    ) -> pd.DataFrame:
        """
        Compare source and target DataFrames at the cell level and return differences.

        Uses Polars' unpivot (melt) operation for fully vectorized comparison,
        avoiding Python loops for better performance on large DataFrames.

        When *index_columns* is provided, rows are matched by the values of those
        key columns (like row-by-row validation) instead of by positional order.
        This tolerates different row counts and detects rows present in only one side.

        Args:
            object_name: The name of the object being validated.
            source_df: The source DataFrame.
            target_df: The target DataFrame.
            positional: If True, compare columns by position instead of by name.
                Ignored when *index_columns* is set.
            index_columns: Source-side key column names for row matching.
                When ``None`` or empty (default), falls back to positional
                matching.  Keys are expected to be unique per row; duplicate
                keys will produce a Cartesian product in the join.
            target_index_columns: Target-side key column names.
                Defaults to *index_columns* when ``None``.

        Returns:
            pd.DataFrame: A DataFrame with differences, including column name, row
            identifier, source value, and target value.

        """
        source_df = self._strip_string_columns(source_df)
        target_df = self._strip_string_columns(target_df)

        if index_columns:
            return self._compare_with_key_matching(
                object_name,
                source_df,
                target_df,
                index_columns,
                target_index_columns or index_columns,
            )

        return self._compare_positional(object_name, source_df, target_df, positional)

    # ------------------------------------------------------------------
    # Positional matching (original behaviour)
    # ------------------------------------------------------------------

    def _compare_positional(
        self,
        object_name: str,
        source_df: pl.DataFrame,
        target_df: pl.DataFrame,
        positional: bool,
    ) -> pd.DataFrame:
        if source_df.shape != target_df.shape:
            LOGGER.error(
                "Dataframe dimensions mismatch. Skipping cell-level comparison for: %s",
                object_name,
            )
            raise Exception("Dataframe dimensions mismatch.")

        if positional:
            target_df = target_df.rename(
                dict(zip(target_df.columns, source_df.columns, strict=True))
            )

        source_with_idx = source_df.with_row_index(ROW_INDEX_CONST)
        target_with_idx = target_df.with_row_index(ROW_INDEX_CONST)

        source_melted = source_with_idx.unpivot(
            index=ROW_INDEX_CONST,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_SOURCE_VALUE_KEY,
        )
        target_melted = target_with_idx.unpivot(
            index=ROW_INDEX_CONST,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_TARGET_VALUE_KEY,
        )

        diff_df = (
            source_melted.join(
                target_melted,
                on=[ROW_INDEX_CONST, DIFF_COL_COLUMN_KEY],
            )
            .filter(
                pl.col(DIFF_COL_SOURCE_VALUE_KEY).ne_missing(
                    pl.col(DIFF_COL_TARGET_VALUE_KEY)
                )
            )
            .rename({ROW_INDEX_CONST: DIFF_COL_ROW_KEY})
            .select(RESULT_COLUMNS)
        )

        if diff_df.is_empty():
            LOGGER.info("No cell-level differences found for: %s", object_name)
            return pd.DataFrame(columns=RESULT_COLUMNS)

        return diff_df.to_pandas()

    # ------------------------------------------------------------------
    # Key-based matching (same strategy as row-by-row)
    # ------------------------------------------------------------------

    def _compare_with_key_matching(
        self,
        object_name: str,
        source_df: pl.DataFrame,
        target_df: pl.DataFrame,
        index_columns: list[str],
        target_index_columns: list[str],
    ) -> pd.DataFrame:
        if target_index_columns != index_columns:
            target_df = target_df.rename(
                dict(zip(target_index_columns, index_columns, strict=True))
            )

        src_key_set = set(index_columns)
        value_columns = [c for c in source_df.columns if c not in src_key_set]
        target_value_columns = [c for c in target_df.columns if c not in src_key_set]

        if len(value_columns) != len(target_value_columns):
            LOGGER.error(
                "Value-column count mismatch (%d vs %d) for: %s",
                len(value_columns),
                len(target_value_columns),
                object_name,
            )
            raise Exception("Value-column count mismatch.")

        if target_value_columns != value_columns:
            target_df = target_df.rename(
                dict(zip(target_value_columns, value_columns, strict=True))
            )

        if source_df.select(index_columns).is_duplicated().any():
            LOGGER.warning(
                "Duplicate key values detected in source for %s. "
                "This may cause a Cartesian product in the join.",
                object_name,
            )
        if target_df.select(index_columns).is_duplicated().any():
            LOGGER.warning(
                "Duplicate key values detected in target for %s. "
                "This may cause a Cartesian product in the join.",
                object_name,
            )

        source_melted = source_df.unpivot(
            index=index_columns,
            on=value_columns,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_SOURCE_VALUE_KEY,
        )
        target_melted = target_df.unpivot(
            index=index_columns,
            on=value_columns,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_TARGET_VALUE_KEY,
        )

        join_on = [*index_columns, DIFF_COL_COLUMN_KEY]
        diff_df = source_melted.join(
            target_melted, on=join_on, how="full", coalesce=True
        ).filter(
            pl.col(DIFF_COL_SOURCE_VALUE_KEY).ne_missing(
                pl.col(DIFF_COL_TARGET_VALUE_KEY)
            )
        )

        if diff_df.is_empty():
            LOGGER.info("No cell-level differences found for: %s", object_name)
            return pd.DataFrame(columns=RESULT_COLUMNS)

        row_id_expr = pl.concat_str(
            [
                pl.format("{}={}", pl.lit(c), pl.col(c).cast(pl.Utf8).fill_null("NULL"))
                for c in index_columns
            ],
            separator=" | ",
        ).alias(DIFF_COL_ROW_KEY)

        diff_df = diff_df.select(
            [
                row_id_expr,
                pl.col(DIFF_COL_COLUMN_KEY),
                pl.col(DIFF_COL_SOURCE_VALUE_KEY),
                pl.col(DIFF_COL_TARGET_VALUE_KEY),
            ]
        )

        return diff_df.to_pandas()

    @staticmethod
    def _strip_string_columns(df: pl.DataFrame) -> pl.DataFrame:
        """Strip leading/trailing whitespace from all string columns.

        Fixed-width CHAR types from sources like Teradata are right-padded
        with spaces, while Snowflake trims them.  Stripping before comparison
        avoids false positives caused solely by trailing whitespace.

        Also normalizes ``Object``-typed columns (common when pandas ingests
        VARCHAR from ODBC/native drivers) by casting to Utf8 then stripping.
        """
        str_like = (
            pl.Utf8,
            pl.String,
        )
        exprs = []
        for c in df.columns:
            dt = df[c].dtype
            if dt in str_like:
                exprs.append(pl.col(c).str.strip_chars().alias(c))
            elif dt == pl.Object:
                exprs.append(
                    pl.col(c)
                    .map_elements(
                        lambda v: (
                            str(v).strip()
                            if v is not None and not (isinstance(v, float) and v != v)
                            else v
                        ),
                        return_dtype=pl.Utf8,
                    )
                    .alias(c)
                )
        if not exprs:
            return df
        return df.with_columns(exprs)
