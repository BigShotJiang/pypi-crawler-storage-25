import logging

import pandas as pd

from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_DATATYPE,
    COLUMN_VALIDATED,
    COLUMN_VALIDATED_KEY,
    COMMENTS_KEY,
    EVALUATION_CRITERIA_KEY,
    NOT_EXIST_TARGET,
    SNOWFLAKE_VALUE_KEY,
    SOURCE_VALUE_KEY,
    STATUS_KEY,
    TABLE_KEY,
    VALIDATION_TYPE_KEY,
    ObjectType,
    Result,
    ValidationLevel,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_misc import HelperMisc
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.validation.data_validator_base import (
    RESULT_COMMENTS,
    DataValidatorBase,
)


LOGGER = logging.getLogger(__name__)


class SchemaDataValidator(DataValidatorBase):
    """
    Validator for schema-level data validation between source and target platforms.

    This class extends DataValidatorBase to provide specific validation functionality
    for comparing database schemas, table structures, column definitions, and other
    metadata between source and target data sources.
    """

    @log
    def validate_table_metadata(
        self,
        object_name: str,
        object_type: ObjectType,
        object_id: int,
        target_df: pd.DataFrame,
        source_df: pd.DataFrame,
        column_mappings: dict[str, str],
        datatypes_mappings: dict[str, str],
    ) -> pd.DataFrame:
        """
        Validate the metadata of two tables by normalizing and comparing their dataframes.

        Args:
            object_name (str): The name of the object (e.g., table) being validated.
            object_type (ObjectType): The type of object (TABLE or VIEW).
            object_id (int): The object ID from the table/view configuration.
            target_df (pd.DataFrame): The dataframe representing the target table's metadata.
            source_df (pd.DataFrame): The dataframe representing the source table's metadata.
            column_mappings (dict[str, str]): A dictionary mapping source column names to target column names.
            datatypes_mappings (dict[str, str]): Mapping of source datatypes to target datatypes (required).

        Returns:
            pd.DataFrame: A DataFrame containing the validation differences.

        """
        LOGGER.info("Starting table metadata validation for: %s", object_name)

        LOGGER.debug("Normalizing target and source DataFrames")
        normalized_target = self.normalize_dataframe(target_df)
        normalized_source = self.normalize_dataframe(source_df)

        differences_data = pd.DataFrame(
            columns=[
                VALIDATION_TYPE_KEY,
                TABLE_KEY,
                COLUMN_VALIDATED_KEY,
                EVALUATION_CRITERIA_KEY,
                SOURCE_VALUE_KEY,
                SNOWFLAKE_VALUE_KEY,
                STATUS_KEY,
                COMMENTS_KEY,
            ]
        )

        # Handle case where target DataFrame is empty (no metadata found)
        if normalized_target.empty or COLUMN_VALIDATED not in normalized_target.columns:
            LOGGER.warning(
                "Target table schema metadata is empty or missing COLUMN_VALIDATED column for table: %s",
                object_name,
            )
            uppercase_target_validated_set = set()
        else:
            uppercase_target_validated_set = HelperMisc.create_uppercase_set(
                normalized_target[COLUMN_VALIDATED].values
            )

        for _, source_row in normalized_source.iterrows():
            source_validated_value = source_row[COLUMN_VALIDATED]

            # Handle missing columns in target, try both lower and upper for case sensitivity
            source_validated_value = column_mappings.get(
                source_validated_value.lower(),
                column_mappings.get(
                    source_validated_value.upper(), source_validated_value
                ),
            )
            # Match MetricsDataValidator: target set is uppercase; compare case-insensitively
            # (e.g. Teradata metadata lowercase vs Snowflake uppercase unquoted identifiers).
            if (
                str(source_validated_value).upper()
                not in uppercase_target_validated_set
            ):
                LOGGER.debug(
                    "Column %s not found in target table", source_validated_value
                )
                new_row = self.create_validation_row(
                    validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
                    table_name=object_name,
                    column_validated=source_validated_value,
                    evaluation_criteria=COLUMN_VALIDATED,
                    source_value=source_validated_value,
                    snowflake_value=NOT_EXIST_TARGET,
                    status=Result.FAILURE.value,
                    comments=f"{RESULT_COMMENTS[Result.FAILURE]}: The column does not exist in the target table.",
                )
                differences_data = self.add_validation_row_to_data(
                    differences_data, new_row
                )
                continue

            # Validate existing columns
            if (
                normalized_target.empty
                or COLUMN_VALIDATED not in normalized_target.columns
            ):
                continue

            target_row = normalized_target[
                normalized_target[COLUMN_VALIDATED].str.upper()
                == str(source_validated_value).upper()
            ]
            column_has_differences = False

            for column in normalized_source.columns:
                # Skip irrelevant columns
                if column in {COLUMN_VALIDATED, TABLE_KEY}:
                    continue

                source_value = source_row[column]
                target_value = target_row[column].values[0]

                validation_row, field_success = self.validate_column_field(
                    column,
                    source_value,
                    target_value,
                    datatypes_mappings,
                    object_name,
                    source_validated_value,
                )

                if not validation_row.empty:
                    differences_data = self.add_validation_row_to_data(
                        differences_data, validation_row
                    )

                if not field_success:
                    column_has_differences = True

            # Record overall column success if no field differences found
            if not column_has_differences:
                success_row = self.create_validation_row(
                    validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
                    table_name=object_name,
                    column_validated=source_validated_value,
                    evaluation_criteria=COLUMN_VALIDATED,
                    source_value=source_validated_value,
                    snowflake_value=source_validated_value,
                    status=Result.SUCCESS.value,
                    comments=(
                        f"{RESULT_COMMENTS[Result.SUCCESS]}: Column exists in "
                        "target table and all metadata matches"
                    ),
                )
                differences_data = self.add_validation_row_to_data(
                    differences_data, success_row
                )

        # Determine if there are actual failures (excluding WARNING status)
        failure_rows = differences_data[
            differences_data[STATUS_KEY] == Result.FAILURE.value
        ]
        has_failures = len(failure_rows) > 0

        # Process and output validation results
        self.process_validation_results(
            validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
            differences_data=differences_data,
            object_name=object_name,
            object_type=object_type,
            object_id=object_id,
            header="Schema validation results:",
            has_differences=has_failures,
        )

        return differences_data

    @log
    def validate_table_metadata_basic(
        self,
        object_name: str,
        object_type: ObjectType,
        object_id: int,
        target_df: pd.DataFrame,
        source_df: pd.DataFrame,
        column_mappings: dict[str, str],
        datatypes_mappings: dict[str, str],
    ) -> pd.DataFrame:
        """
        Validate table metadata focusing only on column existence and datatype matching.

        This is a simplified version of validate_table_metadata that skips validation of
        precision, scale, and character length. Use this when you only need to verify
        that columns exist and their datatypes are compatible.

        Args:
            object_name (str): The name of the object (e.g., table) being validated.
            object_type (ObjectType): The type of object (TABLE or VIEW).
            object_id (int): The object ID from the table/view configuration.
            target_df (pd.DataFrame): The dataframe representing the target table's metadata.
            source_df (pd.DataFrame): The dataframe representing the source table's metadata.
            column_mappings (dict[str, str]): A dictionary mapping source column names to target column names.
            datatypes_mappings (dict[str, str]): Mapping of source datatypes to target datatypes (required).

        Returns:
            pd.DataFrame: A DataFrame containing the validation differences.

        """
        LOGGER.info("Starting basic table metadata validation for: %s", object_name)

        LOGGER.debug("Normalizing target and source DataFrames")
        normalized_target = self.normalize_dataframe(target_df)
        normalized_source = self.normalize_dataframe(source_df)

        differences_data = pd.DataFrame(
            columns=[
                VALIDATION_TYPE_KEY,
                TABLE_KEY,
                COLUMN_VALIDATED_KEY,
                EVALUATION_CRITERIA_KEY,
                SOURCE_VALUE_KEY,
                SNOWFLAKE_VALUE_KEY,
                STATUS_KEY,
                COMMENTS_KEY,
            ]
        )

        # Handle case where target DataFrame is empty (no metadata found)
        if normalized_target.empty or COLUMN_VALIDATED not in normalized_target.columns:
            LOGGER.warning(
                "Target table schema metadata is empty or missing COLUMN_VALIDATED column for table: %s",
                object_name,
            )
            uppercase_target_validated_set = set()
        else:
            uppercase_target_validated_set = HelperMisc.create_uppercase_set(
                normalized_target[COLUMN_VALIDATED].values
            )

        for _, source_row in normalized_source.iterrows():
            source_validated_value = source_row[COLUMN_VALIDATED]

            # Handle column name mapping (try both lower and upper for case sensitivity)
            mapped_column_name = column_mappings.get(
                source_validated_value.lower(),
                column_mappings.get(
                    source_validated_value.upper(), source_validated_value
                ),
            )

            # Check if column exists in target (case-insensitive comparison)
            if str(mapped_column_name).upper() not in uppercase_target_validated_set:
                LOGGER.debug("Column %s not found in target table", mapped_column_name)
                new_row = self.create_validation_row(
                    validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
                    table_name=object_name,
                    column_validated=mapped_column_name,
                    evaluation_criteria=COLUMN_VALIDATED,
                    source_value=mapped_column_name,
                    snowflake_value=NOT_EXIST_TARGET,
                    status=Result.FAILURE.value,
                    comments=f"{RESULT_COMMENTS[Result.FAILURE]}: The column does not exist in the target table.",
                )
                differences_data = self.add_validation_row_to_data(
                    differences_data, new_row
                )
                continue

            # Skip datatype validation if target is empty
            if (
                normalized_target.empty
                or COLUMN_VALIDATED not in normalized_target.columns
            ):
                continue

            # Get the target row for datatype comparison
            target_row = normalized_target[
                normalized_target[COLUMN_VALIDATED].str.upper()
                == str(mapped_column_name).upper()
            ]

            # Validate datatype only
            if COLUMN_DATATYPE in normalized_source.columns:
                source_datatype = source_row[COLUMN_DATATYPE]
                target_datatype = target_row[COLUMN_DATATYPE].values[0]

                validation_row, field_success = self.validate_datatype_field(
                    source_datatype,
                    target_datatype,
                    datatypes_mappings,
                    object_name,
                    mapped_column_name,
                    COLUMN_DATATYPE,
                )

                if not validation_row.empty:
                    differences_data = self.add_validation_row_to_data(
                        differences_data, validation_row
                    )

                # Record overall column success if datatype matched
                if field_success:
                    success_row = self.create_validation_row(
                        validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
                        table_name=object_name,
                        column_validated=mapped_column_name,
                        evaluation_criteria=COLUMN_VALIDATED,
                        source_value=mapped_column_name,
                        snowflake_value=mapped_column_name,
                        status=Result.SUCCESS.value,
                        comments=(
                            f"{RESULT_COMMENTS[Result.SUCCESS]}: Column exists in "
                            "target table and datatype matches"
                        ),
                    )
                    differences_data = self.add_validation_row_to_data(
                        differences_data, success_row
                    )
            else:
                # No datatype column, just record column existence success
                success_row = self.create_validation_row(
                    validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
                    table_name=object_name,
                    column_validated=mapped_column_name,
                    evaluation_criteria=COLUMN_VALIDATED,
                    source_value=mapped_column_name,
                    snowflake_value=mapped_column_name,
                    status=Result.SUCCESS.value,
                    comments=(
                        f"{RESULT_COMMENTS[Result.SUCCESS]}: Column exists in target table"
                    ),
                )
                differences_data = self.add_validation_row_to_data(
                    differences_data, success_row
                )

        # Determine if there are actual failures
        failure_rows = differences_data[
            differences_data[STATUS_KEY] == Result.FAILURE.value
        ]
        has_failures = len(failure_rows) > 0

        # Process and output validation results
        self.process_validation_results(
            validation_type=ValidationLevel.SCHEMA_VALIDATION.value,
            differences_data=differences_data,
            object_name=object_name,
            object_type=object_type,
            object_id=object_id,
            header="Basic schema validation results:",
            has_differences=has_failures,
        )

        return differences_data
