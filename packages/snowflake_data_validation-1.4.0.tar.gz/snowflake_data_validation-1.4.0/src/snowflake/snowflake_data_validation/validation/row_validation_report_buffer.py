# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
import threading

import pandas as pd

from snowflake.snowflake_data_validation.utils.constants import (
    OBJECT_ID_KEY,
    ROW_VALIDATION_REPORT_CSV_NAME,
)
from snowflake.snowflake_data_validation.utils.thread_safe_singleton import (
    ThreadSafeSingleton,
)
from snowflake.snowflake_data_validation.validation.validation_database_manager import (
    ValidationDatabaseManager,
)


LOGGER = logging.getLogger(__name__)


class RowValidationReportBuffer(metaclass=ThreadSafeSingleton):
    """Thread-safe singleton class for writing row validation report data to database.

    This class writes row validation results directly to the database as each table's
    validation completes. It uses a lock to ensure thread-safe database writes when
    multiple validation threads complete simultaneously.

    Similar to ValidationReportBuffer but specifically designed for row-level validation
    results which may contain detailed information about individual row differences
    between source and target databases.
    """

    def __init__(self):
        """Initialize the buffer with a thread-safe lock.

        Note: This method may be called multiple times due to the metaclass implementation,
        but initialization is protected to ensure it only happens once.
        """
        if not hasattr(self, "_initialized"):
            self._write_lock = threading.Lock()
            self._total_rows_written = 0
            self._initialized = True
            LOGGER.debug("RowValidationReportBuffer singleton initialized")

    def add_data(
        self,
        dataframe: pd.DataFrame,
        context,
        db_manager: ValidationDatabaseManager,
    ) -> None:
        """Write a DataFrame directly to the database and CSV file.

        This method writes the row validation data immediately to the database
        and a CSV file when called, ensuring data is persisted as soon as each
        table's validation completes.

        Args:
            dataframe (pd.DataFrame): The row validation data to write
            context: The execution context containing configuration and runtime info.
            db_manager: The ValidationDatabaseManager instance to use.

        """
        if dataframe.empty:
            LOGGER.debug("Empty DataFrame provided, skipping database write")
            return

        # Ensure database is initialized
        db_manager.initialize_database(context)

        df_copy = dataframe.copy()

        # Use lock to ensure thread-safe writes
        with self._write_lock:
            # Write to database
            rows_inserted = db_manager.upload_row_validation_report(df_copy)
            self._total_rows_written += rows_inserted
            LOGGER.info(
                "Wrote %d rows to row validation report database (total: %d)",
                rows_inserted,
                self._total_rows_written,
            )

            # Write to CSV file
            self._write_to_csv(df_copy, context)

    def _write_to_csv(self, dataframe: pd.DataFrame, context) -> str:
        """Write the row validation report DataFrame to a local CSV file.

        Args:
            dataframe: The DataFrame containing row validation results.
            context: The execution context containing report path and run start time.

        Returns:
            str: The path to the written CSV file.

        """
        # Extract table name from the DataFrame (use first row's TABLE_NAME)
        table_name = "unknown_table"
        if "TABLE_NAME" in dataframe.columns and not dataframe.empty:
            table_name = str(dataframe["TABLE_NAME"].iloc[0])

        csv_filename = f"{context.run_start_time}_{ROW_VALIDATION_REPORT_CSV_NAME.format(table_name=table_name)}"
        csv_path = os.path.join(context.report_path, csv_filename)

        # Ensure directory exists
        os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)

        # Add EXECUTION_ID column from context as the first column
        dataframe_with_id = dataframe.copy()
        dataframe_with_id.insert(0, "EXECUTION_ID", context.run_id)

        # Sort by OBJECT_ID before writing to CSV
        sorted_dataframe = dataframe_with_id.sort_values(
            by=OBJECT_ID_KEY, ascending=True
        )
        sorted_dataframe.to_csv(csv_path, index=False, encoding="utf-8")
        LOGGER.info(
            "Successfully wrote %d rows to row validation report CSV: %s",
            len(dataframe),
            csv_path,
        )

        return csv_path

    def get_total_rows_written(self) -> int:
        """Get the total number of rows written to the database.

        Returns:
            int: Total number of rows written across all tables.

        """
        return self._total_rows_written

    def clear(self) -> None:
        """Reset the buffer state.

        This method resets the row count, typically used for cleanup
        or when starting a fresh validation run.
        """
        with self._write_lock:
            self._total_rows_written = 0
        LOGGER.info("Row validation report buffer cleared")

    def has_data(self) -> bool:
        """Check if any data has been written to the database.

        Returns:
            bool: True if rows have been written, False otherwise

        """
        return self._total_rows_written > 0
