# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Factory for creating SQL Server connectors from connection configurations."""

from typing import Literal, get_args

from snowflake.snowflake_data_validation.configuration.model.connection_types import (
    Connection,
)
from snowflake.snowflake_data_validation.connector.connector_base import (
    ConnectorBase,
)
from snowflake.snowflake_data_validation.connector.connector_factory_base import (
    ConnectorFactoryBase,
)
from snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server import (
    ConnectorSqlServer,
)
from snowflake.snowflake_data_validation.utils.constants import Platform


# SQL Server connection mode type
SqlServerMode = Literal[
    "sql_auth", "windows_auth", "service_principal", "managed_identity", "credentials"
]

# Valid modes for SQL Server (used for validation)
VALID_SQLSERVER_MODES = set(get_args(SqlServerMode))


class SqlServerConnectorFactory(ConnectorFactoryBase):
    """Factory for creating SQL Server connectors from connection configurations.

    Supports multiple authentication modes via the 'mode' field:
    1. sql_auth (or 'credentials'): Uses username and password
    2. windows_auth: Uses trusted connection (integrated security)
    3. service_principal: Uses Azure Entra ID with client credentials
    4. managed_identity: Uses Azure Managed Identity
    """

    @staticmethod
    def create_connector(connection_config: Connection) -> ConnectorBase:
        """Create a SQL Server connector from connection configuration.

        Args:
            connection_config: Connection configuration object

        Returns:
            ConnectorBase: Configured SQL Server connector

        Raises:
            typer.BadParameter: If configuration is invalid or unsupported
            ConnectionError: If connection fails

        """
        # Validate mode is one of the supported SQL Server modes
        mode = getattr(connection_config, "mode", "sql_auth")
        if mode not in VALID_SQLSERVER_MODES:
            from typer import BadParameter

            raise BadParameter(
                f"Invalid mode '{mode}' for SQL Server. "
                f"Supported modes: {', '.join(sorted(VALID_SQLSERVER_MODES))}"
            )

        return SqlServerConnectorFactory._create_credentials_connector(
            connection_config
        )

    @staticmethod
    def _get_effective_mode(connection_config: Connection) -> SqlServerMode:
        """Get the effective authentication mode from connection config.

        Handles backward compatibility with 'credentials' mode.

        Args:
            connection_config: Connection configuration object

        Returns:
            SqlServerMode: The resolved authentication mode

        """
        mode = getattr(connection_config, "mode", "sql_auth")

        # Backward compatibility: 'credentials' is treated as 'sql_auth'
        if mode == "credentials":
            return "sql_auth"

        return mode

    @staticmethod
    def _create_credentials_connector(
        connection_config: Connection,
    ) -> ConnectorSqlServer:
        """Create SQL Server connector using various authentication modes."""
        # Get effective authentication mode
        mode = SqlServerConnectorFactory._get_effective_mode(connection_config)

        # Validate required parameters based on mode
        if mode == "sql_auth":
            required_params = ["host", "database", "username", "password"]
        elif mode == "windows_auth":
            required_params = ["host", "database"]
        elif mode == "service_principal":
            required_params = [
                "host",
                "database",
                "client_id",
                "client_secret",
                "tenant_id",
            ]
        elif mode == "managed_identity":
            # client_id is optional for managed identity (only needed for user-assigned)
            required_params = ["host", "database"]
        else:
            required_params = ["host", "database"]

        SqlServerConnectorFactory._validate_required_parameters(
            connection_config, required_params, Platform.SQLSERVER.value
        )

        def create_connector():
            connector = ConnectorSqlServer()
            connector.connect(
                host=connection_config.host,
                database=connection_config.database,
                user=getattr(connection_config, "username", None),
                password=getattr(connection_config, "password", None),
                port=getattr(connection_config, "port", 1433),
                mode=mode,
                client_id=getattr(connection_config, "client_id", None),
                client_secret=getattr(connection_config, "client_secret", None),
                tenant_id=getattr(connection_config, "tenant_id", None),
                trust_server_certificate=getattr(
                    connection_config, "trust_server_certificate", None
                ),
                encrypt=getattr(connection_config, "encrypt", None),
                odbc_driver=getattr(connection_config, "odbc_driver", None),
            )
            return connector

        return SqlServerConnectorFactory._handle_connection_exceptions(
            Platform.SQLSERVER.value, create_connector
        )
