from pathlib import Path

import pandas as pd

from ruamel.yaml import YAML

from snowflake.snowflake_data_validation.utils.constants import (
    METRICS_VALIDATION_STATUS,
    OBJECT_NAME_KEY,
    OBJECT_TYPE_KEY,
    ROW_VALIDATION_STATUS,
    SCHEMA_VALIDATION_STATUS,
    ObjectType,
    Result,
    ValidationScope,
)


def sync_configuration_file(
    configuration_file_path: str, execution_summary_report_file_path: str
) -> None:
    """
    Sync the configuration file with the execution summary report.

    Args:
        configuration_file_path (str): The path to the configuration file to be updated.
        execution_summary_report_file_path (str): The path to the execution summary report CSV file.

    """
    config_path = Path(configuration_file_path)
    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration file not found: {configuration_file_path}"
        )

    execution_summary_report_path = Path(execution_summary_report_file_path)
    if not execution_summary_report_path.exists():
        raise FileNotFoundError(
            f"Execution summary report file not found: {execution_summary_report_file_path}"
        )

    execution_summary_report_df = pd.read_csv(execution_summary_report_path)
    objects_to_remove_df = execution_summary_report_df.query(
        f"{SCHEMA_VALIDATION_STATUS} == '{Result.SUCCESS.value}' and "
        f"{METRICS_VALIDATION_STATUS} == '{Result.SUCCESS.value}' and "
        f"{ROW_VALIDATION_STATUS} == '{Result.SUCCESS.value}'"
    )

    if objects_to_remove_df.empty:
        return

    yaml = YAML()
    yaml.preserve_quotes = True
    with open(config_path, encoding="utf-8") as config_file:
        config_data = yaml.load(config_file)

    original_tables_count = len(config_data.get(ValidationScope.TABLES.value, []))
    original_views_count = len(config_data.get(ValidationScope.VIEWS.value, []))

    if ValidationScope.TABLES.value in config_data and isinstance(
        config_data[ValidationScope.TABLES.value], list
    ):
        tables_to_remove_df = objects_to_remove_df[
            objects_to_remove_df[OBJECT_TYPE_KEY] == ObjectType.TABLE.value
        ]
        table_names_to_remove = tables_to_remove_df[OBJECT_NAME_KEY].values.tolist()
        config_data[ValidationScope.TABLES.value] = [
            v
            for v in config_data[ValidationScope.TABLES.value]
            if v.get("fully_qualified_name") not in table_names_to_remove
        ]

        if not config_data[ValidationScope.TABLES.value]:
            config_data.pop(ValidationScope.TABLES.value)

    if ValidationScope.VIEWS.value in config_data and isinstance(
        config_data[ValidationScope.VIEWS.value], list
    ):
        views_to_remove_df = objects_to_remove_df[
            objects_to_remove_df[OBJECT_TYPE_KEY] == ObjectType.VIEW.value
        ]
        view_names_to_remove = views_to_remove_df[OBJECT_NAME_KEY].values.tolist()
        config_data[ValidationScope.VIEWS.value] = [
            v
            for v in config_data[ValidationScope.VIEWS.value]
            if v.get("fully_qualified_name") not in view_names_to_remove
        ]

        if not config_data[ValidationScope.VIEWS.value]:
            config_data.pop(ValidationScope.VIEWS.value)

    new_tables_count = len(config_data.get(ValidationScope.TABLES.value, []))
    new_views_count = len(config_data.get(ValidationScope.VIEWS.value, []))

    if (
        original_tables_count == new_tables_count
        and original_views_count == new_views_count
    ):
        return

    with open(config_path, "w", encoding="utf-8") as config_file:
        yaml.dump(config_data, config_file)
