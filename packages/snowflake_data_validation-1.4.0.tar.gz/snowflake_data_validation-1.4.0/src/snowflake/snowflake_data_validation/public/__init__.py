# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Workflow module for decoupled validation steps.

This module provides a library API for performing data validation in a
decoupled manner, where each step (query generation, execution, validation)
can be called independently.

Submodules:
    - model: API result types (GeneratedQuery, QueryExecutionResult, ValidationResult, etc.)
    - enums: Core enums (Platform, Origin, ObjectType, ExecutionMode)
    - configuration: Configuration classes (TableConfiguration, ViewConfiguration, etc.)
    - context: Runtime context classes (Context, TableContext)
    - metadata: Metadata models (TableColumnMetadata, ColumnMetadata)
    - connectors: Database connector abstractions (ConnectorBase)
    - generators: SQL generation utilities (SQLQueriesTemplateGenerator)

Example usage:
    from snowflake.snowflake_data_validation.public import generate_schema_query
    from snowflake.snowflake_data_validation.public.enums import Platform
    from snowflake.snowflake_data_validation.public.configuration import TableConfiguration
    from snowflake.snowflake_data_validation.public.model import GeneratedQuery

"""
# =============================================================================
# API FUNCTIONS (for workflow steps)
# =============================================================================
from snowflake.snowflake_data_validation.public.data_validation_api import (
    build_validation_file_path,
    compare_md5_chunks,
    compare_md5_rows_chunk,
    execute_query,
    execute_query_from_table_configuration,
    execute_statement,
    execute_view_materialization,
    extract_row_count,
    generate_case_sensitive_columns_query,
    generate_cell_validation_data_query,
    generate_column_metadata_query,
    generate_compute_md5_queries,
    generate_create_md5_table_statement,
    generate_extract_chunks_md5_query,
    generate_extract_md5_rows_chunk_query,
    generate_metrics_query,
    generate_row_count_query,
    generate_schema_query,
    generate_snapshot,
    generate_view_materialization_query,
    get_configuration_file,
    load_validation_result_from_file,
    load_validation_results,
    process_table_column_metadata,
    process_target_table_column_metadata_from_source_table,
    query_cell_level_validation,
    query_metrics_level_validation,
    query_to_dataframe,
    result_set_cell_level_validation,
    result_set_metrics_level_validation,
    result_set_to_dataframe,
    run_async_generation,
    run_async_validation,
    run_source_validation,
    run_validation,
    validate_cell,
    validate_cell_snapshot_result_set,
    validate_metrics,
    validate_metrics_snapshot_result_set,
    validate_metrics_snapshot_table,
    validate_schema,
    validate_schema_snapshot_table,
    validate_schema_snapshot_result_set,
    write_metrics_query_to_script,
    write_schema_query_to_script,
    write_view_materialization_query_to_script,
)

# =============================================================================
# API RESULT TYPES (DTOs)
# =============================================================================
from snowflake.snowflake_data_validation.public.model import (
    DataValidationExceptionError,
    GeneratedQuery,
    QueryExecutionResult,
    ValidationResult,
    ResultSet,
)

# =============================================================================
# CORE ENUMS
# =============================================================================
from snowflake.snowflake_data_validation.public.enums import (
    ExecutionMode,
    ObjectType,
    Origin,
    Platform,
    ValidationLevel,
)

# =============================================================================
# CONFIGURATION CLASSES
# =============================================================================
from snowflake.snowflake_data_validation.public.configuration import (
    TableConfiguration,
    ViewConfiguration,
)

# =============================================================================
# CONTEXT CLASSES
# =============================================================================
from snowflake.snowflake_data_validation.public.context import (
    Context,
    TableContext,
)

# =============================================================================
# METADATA MODELS
# =============================================================================
from snowflake.snowflake_data_validation.public.metadata import (
    ColumnMetadata,
    TableColumnMetadata,
)

# =============================================================================
# CONNECTORS
# =============================================================================
from snowflake.snowflake_data_validation.public.connectors import (
    ConnectorBase,
    ConnectorRedshift,
    ConnectorSnowflake,
    ConnectorSqlServer,
    ConnectorTeradata,
)

# =============================================================================
# CONNECTOR FACTORIES
# =============================================================================
from snowflake.snowflake_data_validation.public.connectors import (
    ConnectorFactory,
    ConnectorFactoryBase,
    RedshiftConnectorFactory,
    SnowflakeConnectorFactory,
    SqlServerConnectorFactory,
    TeradataConnectorFactory,
)

# =============================================================================
# SQL GENERATORS
# =============================================================================
from snowflake.snowflake_data_validation.public.generators import (
    SQLQueriesTemplateGenerator,
)

# =============================================================================
# TEMPLATES LOADER
# =============================================================================
from snowflake.snowflake_data_validation.utils.model.templates_loader_manager import (
    TemplatesLoaderManager,
)

__all__ = [
    # API Functions
    "build_validation_file_path",
    "compare_md5_chunks",
    "compare_md5_rows_chunk",
    "execute_query",
    "execute_query_from_table_configuration",
    "execute_statement",
    "execute_view_materialization",
    "extract_row_count",
    "generate_case_sensitive_columns_query",
    "generate_cell_validation_data_query",
    "generate_column_metadata_query",
    "generate_compute_md5_queries",
    "generate_create_md5_table_statement",
    "generate_extract_chunks_md5_query",
    "generate_extract_md5_rows_chunk_query",
    "generate_metrics_query",
    "generate_row_count_query",
    "generate_schema_query",
    "generate_snapshot",
    "generate_view_materialization_query",
    "get_configuration_file",
    "load_validation_result_from_file",
    "load_validation_results",
    "process_table_column_metadata",
    "process_target_table_column_metadata_from_source_table",
    "query_cell_level_validation",
    "query_metrics_level_validation",
    "query_to_dataframe",
    "result_set_cell_level_validation",
    "result_set_metrics_level_validation",
    "result_set_to_dataframe",
    "run_async_generation",
    "run_async_validation",
    "run_source_validation",
    "run_validation",
    "validate_cell",
    "validate_cell_snapshot_result_set",
    "validate_metrics",
    "validate_metrics_snapshot_result_set",
    "validate_metrics_snapshot_table",
    "validate_schema",
    "validate_schema_snapshot_table",
    "validate_schema_snapshot_result_set",
    "write_metrics_query_to_script",
    "write_schema_query_to_script",
    "write_view_materialization_query_to_script",
    "DataValidationExceptionError",
    "GeneratedQuery",
    "QueryExecutionResult",
    "ValidationResult",
    "ExecutionMode",
    "ObjectType",
    "Origin",
    "Platform",
    "ConfigurationModel",
    "TableConfiguration",
    "ValidationConfiguration",
    "ViewConfiguration",
    "Context",
    "TableContext",
    "ColumnMetadata",
    "TableColumnMetadata",
    "ResultSet",
    "ConnectorBase",
    "ConnectorRedshift",
    "ConnectorSnowflake",
    "ConnectorSqlServer",
    "ConnectorTeradata",
    "ConnectorFactory",
    "ConnectorFactoryBase",
    "RedshiftConnectorFactory",
    "SnowflakeConnectorFactory",
    "SqlServerConnectorFactory",
    "TeradataConnectorFactory",
    "SQLQueriesTemplateGenerator",
    "TemplatesLoaderManager",
    "ValidationLevel",
]
