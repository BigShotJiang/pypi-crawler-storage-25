# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass


@dataclass(frozen=True)
class ResultSet:
    """Data structure representing a result set from a not materialized query execution.

    This structure is designed to encapsulate the essential components of a query result,
    including column names, row data, and column types.

    Attributes:
        rows: A list of dictionaries, where each dictionary represents a row of data with
              column names as keys and corresponding cell values as values.
        column_types: A dictionary mapping column names to their respective data types.

    """

    rows: list[dict[str, any]]
    column_types: dict[str, str]
