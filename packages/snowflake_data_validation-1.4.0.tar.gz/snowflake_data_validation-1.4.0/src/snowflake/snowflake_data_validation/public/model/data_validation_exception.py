# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Custom exception for data validation errors."""


class DataValidationExceptionError(Exception):
    """Custom exception for data validation errors.

    This exception provides structured error information for validation failures,
    including context about the platform, operation, and object involved.

    Attributes:
        platform: The database platform where the error occurred.
        object_name: The name of the object being validated.
        object_id: The ID of the object being validated.

    """

    def __init__(
        self,
        message: str,
        platform: str,
        object_name: str,
        object_id: int,
    ):
        """
        Initialize a DataValidationExceptionError instance.

        Args:
            message (str): The error message describing the validation exception.
            platform (str): The platform where the validation error occurred (e.g., 'Snowflake', 'BigQuery').
            object_name (str): The name of the object that failed validation.
            object_id (int): The unique identifier of the object that failed validation.

        """
        super().__init__(message)
        self.platform = platform
        self.object_name = object_name
        self.object_id = object_id

    def __str__(self):
        """Return a string representation of the exception with structured error information."""
        error_source = f"[{self.platform}]"
        error_object = f"{self.object_name} (ID: {self.object_id})"
        return (
            f"{error_source} failed for object: {error_object}. Error: {self.args[0]}"
        )
