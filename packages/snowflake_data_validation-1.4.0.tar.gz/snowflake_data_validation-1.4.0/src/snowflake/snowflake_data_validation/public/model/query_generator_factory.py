from snowflake.snowflake_data_validation.query.query.query_generator_query import (
    QueryGeneratorQuery,
)
from snowflake.snowflake_data_validation.query.query_generator_base import (
    QueryGeneratorBase,
)
from snowflake.snowflake_data_validation.redshift.query.query_generator_redshift import (
    QueryGeneratorRedshift,
)
from snowflake.snowflake_data_validation.result_set.query.query_generator_result_set import (
    QueryGeneratorResultSet,
)
from snowflake.snowflake_data_validation.snowflake.query.query_generator_snowflake import (
    QueryGeneratorSnowflake,
)
from snowflake.snowflake_data_validation.sqlserver.query.query_generator_sqlserver import (
    QueryGeneratorSqlServer,
)
from snowflake.snowflake_data_validation.teradata.query.query_generator_teradata import (
    QueryGeneratorTeradata,
)
from snowflake.snowflake_data_validation.utils.constants import Platform


class QueryGeneratorFactory:
    """Factory for creating platform-specific query generators."""

    @staticmethod
    def create(platform: Platform) -> QueryGeneratorBase:
        """Create a query generator for the specified platform.

        Args:
            platform: The database platform to create a generator for.

        Returns:
            QueryGeneratorBase: An instance of the platform-specific generator.

        Raises:
            ValueError: If the platform is not supported.

        """
        generators: dict[Platform, type[QueryGeneratorBase]] = {
            Platform.SNOWFLAKE: QueryGeneratorSnowflake,
            Platform.REDSHIFT: QueryGeneratorRedshift,
            Platform.SQLSERVER: QueryGeneratorSqlServer,
            Platform.TERADATA: QueryGeneratorTeradata,
            Platform.RESULT_SET: QueryGeneratorResultSet,
            Platform.QUERY: QueryGeneratorQuery,
        }

        generator_class = generators.get(platform)
        if generator_class is None:
            raise ValueError(f"Unsupported platform: {platform}")

        return generator_class()
