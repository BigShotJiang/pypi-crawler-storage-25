# Data Validation API Overview

The `data_validation_api.py` module provides a comprehensive set of functions for validating data between source and target database platforms during migrations. The API follows a **step-by-step workflow** pattern and supports multiple database platforms.

## Supported Platforms

The API supports multiple platforms via the `Platform` enum:

- **Snowflake** (source and target)
- **SQL Server** (source)
- **Redshift** (source)
- **Teradata** (source)
- **Result Set** (in-memory comparison)

---

## API Structure

The API is organized into **sequential steps** that mirror the validation workflow:

### Step 0: Metadata Generation

Functions to prepare metadata queries before validation.

| Function | Purpose |
|----------|---------|
| `generate_view_materialization_query()` | Creates DDL to materialize a view as a temporary table (CREATE TABLE AS SELECT) |
| `generate_column_metadata_query()` | Generates query to extract column info (names, types, nullability, PKs) |
| `generate_row_count_query()` | Generates query to count rows, with optional WHERE clause |
| `generate_case_sensitive_columns_query()` | Retrieves case-sensitive column names from Snowflake |

### Step 1: Query Generation

Functions to generate validation queries without execution.

| Function | Purpose |
|----------|---------|
| `execute_view_materialization()` | Executes DDL to create temporary table from view |
| `generate_schema_query()` | Generates schema metadata extraction query |
| `generate_metrics_query()` | Generates column-level metrics query (min, max, count, distinct, etc.) |

### Step 1.2: Row Validation Query Generation

MD5-based row validation uses chunked comparison for efficiency.

| Function | Purpose |
|----------|---------|
| `generate_create_md5_table_statement()` | Creates DDL for MD5 chunks storage table |
| `generate_compute_md5_queries()` | Generates INSERT queries to compute MD5 checksums per chunk |
| `generate_extract_chunks_md5_query()` | Extracts computed MD5 checksums from chunks table |
| `generate_extract_md5_rows_chunk_query()` | Extracts individual row MD5s for a specific chunk |

### Step 2: Query Execution

Functions to execute generated queries and retrieve results.

| Function | Purpose |
|----------|---------|
| `execute_query_from_table_configuration()` | Executes query using `TableConfiguration` context |
| `execute_query()` | Executes query using `TableContext` |
| `execute_statement()` | Executes DDL/DML without returning results |

### Step 3: Validation

| Function | Purpose | Key Parameters |
|----------|---------|----------------|
| `validate_schema()` | Compares schema metadata (column names, types, constraints) | `datatypes_mappings: dict[str, str]` (required) |
| `validate_metrics()` | Compares column-level metrics with configurable tolerance | `tolerance: float` (default 0.001) |


### Step 3.1: Row Validation - Chunk Comparison

| Function | Purpose |
|----------|---------|
| `compare_md5_chunks()` | Compares MD5 checksums of data chunks |
| `compare_md5_rows_chunk()` | Compares individual row MD5s within a specific chunk |
| `extract_diff_chunk_ids()` | Extracts list of chunk IDs that have differences |

### Step 3.2: Row Validation - Cell Comparison

| Function | Purpose |
|----------|---------|
| `validate_cell()` | Compares individual cell values between source and target DataFrames, returning specific cells that differ |

The cell validation provides a lightweight alternative to MD5-based row validation. It uses Polars for efficient vectorized comparison and returns detailed information about each differing cell including column name, row index, source value, and target value.

### Step 3.2.1: Result Set Comparison

| Function | Purpose |
|----------|---------|
| `result_set_to_dataframe()` | Converts a `ResultSet` object to a Polars DataFrame |
| `result_set_cell_level_validation()` | Compares two `ResultSet` objects at the cell level and determines if they are equivalent |
| `result_set_metrics_level_validation()` | Compares two `ResultSet` objects at the metrics level (min, max, count, etc.) |

These functions compare result sets for equivalence. Cell-level validation checks individual cell values while metrics-level validation compares aggregate statistics.

### Step 3.2.2: Query Comparison

| Function | Purpose |
|----------|---------|
| `query_to_dataframe()` | Executes a query and converts the result to a Polars DataFrame |
| `query_cell_level_validation()` | Compares two Polars DataFrames at the cell level |
| `query_metrics_level_validation()` | Compares two Polars DataFrames at the metrics level with configurable tolerance |

These functions provide direct DataFrame comparison capabilities without requiring `ResultSet` objects. They are useful for comparing query results from different sources.

### Step 3.3: Snapshot Validation

Functions to validate snapshots by comparing saved schema/metrics files from two tables.

| Function | Purpose |
|----------|---------|
| `validate_schema_snapshot_table()` | Validates schema snapshots by loading and comparing metadata from two directories (local or Snowflake stage) |
| `validate_metrics_snapshot_table()` | Validates metrics snapshots by loading and comparing metrics data from two directories (local or Snowflake stage) |

Both snapshot validation functions support:
- Local directories or Snowflake stages as input
- Column name mappings between source and target
- Datatype mappings for cross-platform comparisons

### Step 3.3.1: Result Set Snapshot Validation

Functions to validate snapshots specifically for result set comparisons.

| Function | Purpose |
|----------|---------|
| `validate_schema_snapshot_result_set()` | Validates schema snapshots for result sets by comparing metadata from two directories |
| `validate_metrics_snapshot_result_set()` | Validates metrics snapshots for result sets with configurable tolerance |
| `validate_cell_snapshot_result_set()` | Validates cell snapshots for result sets by performing cell-level comparison |

These result set snapshot validation functions support:
- Local directories or Snowflake stages as input
- Column name mappings between source and target (schema and metrics)
- Datatype mappings for schema comparisons
- Configurable tolerance for metrics comparisons

---

## Snapshot Generation

| Function | Purpose |
|----------|---------|
| `generate_snapshot()` | Generates validation snapshots to a local directory or Snowflake stage |


---

## Utility Functions

| Function | Purpose |
|----------|---------|
| `extract_row_count()` | Extracts row count from query result |
| `extract_diff_chunk_ids()` | Extracts chunk IDs with differences from validation result |
| `process_table_column_metadata()` | Converts raw DataFrame to structured `TableColumnMetadata` |
| `process_target_table_column_metadata_from_source_table()` | Transforms source metadata to expected target structure (handles column/datatype mappings) |

---

## Configuration Functions

| Function | Purpose |
|----------|---------|
| `get_configuration_file()` | Exports configuration template files (YAML and optionally Jinja2 query templates) to a specified directory |

### get_configuration_file

Exports the YAML configuration templates and optionally the Jinja2 query templates for a specific platform to a directory. These templates can be customized for validation.

**Parameters:**
- `templates_directory: str` - Directory path where templates will be written (must exist and be writable)
- `include_query_templates: bool` - If True, includes Jinja2 (.j2) query template files
- `platform: Platform` - The source platform (SNOWFLAKE, SQLSERVER, TERADATA, REDSHIFT, RESULT_SET)

**Example:**
```python
from snowflake.snowflake_data_validation.public import (
    get_configuration_file,
    Platform,
)

get_configuration_file(
    templates_directory="/path/to/templates",
    include_query_templates=True,
    platform=Platform.SQLSERVER,
)
```

---

## Orchestration Functions

High-level functions to run complete validation workflows.

| Function | Purpose | Parameters |
|----------|---------|------------|
| `run_validation()` | Run synchronous data validation based on a configuration file | `platform: Platform`, `data_validation_config_file: str` |
| `run_async_generation()` | Generate validation scripts for later execution | `platform: Platform`, `data_validation_config_file: str` |
| `run_async_validation()` | Run asynchronous data validation | `platform: Platform`, `data_validation_config_file: str` |
| `run_source_validation()` | Execute validation queries on source only and save results as Parquet files | `platform: Platform`, `data_validation_config_file: str` |

---

## Async Mode Support

The API supports **asynchronous execution** where queries are written to files for later execution.

### Script Writing Functions

| Function | Purpose |
|----------|---------|
| `write_view_materialization_query_to_script()` | Writes view materialization query to `.sql` file |
| `write_schema_query_to_script()` | Writes schema validation query to file |
| `write_metrics_query_to_script()` | Writes metrics validation query to file |

### File Loading Functions

| Function | Purpose |
|----------|---------|
| `load_validation_result_from_file()` | Loads validation data from CSV/Parquet file |
| `load_validation_results()` | Loads both source and target validation files |
| `build_validation_file_path()` | Constructs file path for validation data |

---

## Key Data Models

- **`GeneratedQuery`** - Wraps a generated SQL query string
- **`QueryExecutionResult`** - Contains a pandas or Polars DataFrame with query results
- **`ValidationResult`** - Contains `is_valid` flag and `results_dataframe`
- **`TableContext`** - Table metadata including platform, FQN, and configuration
- **`TableConfiguration`** - Configuration for table validation (mappings, selections)
- **`TableColumnMetadata`** - Structured column metadata information
- **`TemplatesLoaderManager`** - Manages loading of datatype and metrics templates

---

## Additional Classes Available

### Connectors

| Class | Purpose |
|-------|---------|
| `ConnectorSnowflake` | Snowflake database connector |
| `ConnectorSqlServer` | SQL Server database connector |
| `ConnectorRedshift` | Redshift database connector |
| `ConnectorTeradata` | Teradata database connector |

### Enums

| Enum | Values |
|------|--------|
| `Platform` | SNOWFLAKE, SQLSERVER, REDSHIFT, TERADATA, RESULT_SET |
| `Origin` | SOURCE, TARGET |
| `ObjectType` | TABLE, VIEW, RESULT_SET |
| `ExecutionMode` | SYNC, ASYNC |

---

## Error Handling

All functions raise `DataValidationExceptionError` on failure, which includes:

- Error message
- Platform name
- Object name (table/view FQN)
- Object ID
