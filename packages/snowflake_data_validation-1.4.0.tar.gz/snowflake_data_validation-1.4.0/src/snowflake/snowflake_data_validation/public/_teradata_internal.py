# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Teradata-specific internal helper functions for the public API.

This module contains private utility functions that support the public API
for Teradata-specific operations, including normalization of HELP COLUMN results.

WARNING: Functions in this module are internal implementation details and
may change without notice. Do not import from this module directly.
"""

from __future__ import annotations

import pandas as pd

from snowflake.snowflake_data_validation.utils.constants import (
    CALCULATED_COLUMN_SIZE_IN_BYTES_KEY,
    CHARACTER_LENGTH_KEY,
    COLUMN_NAME_KEY,
    DATA_TYPE_KEY,
    DATABASE_NAME_KEY,
    IS_PRIMARY_KEY_KEY,
    NULLABLE_KEY,
    PRECISION_KEY,
    SCALE_KEY,
    SCHEMA_NAME_KEY,
    TABLE_NAME_KEY,
)


TERADATA_TYPE_CODE_MAPPING = {
    "A1": "ARRAY",
    "AN": "MULTI-DIMENSIONAL ARRAY",
    "AT": "TIME",
    "BF": "BYTE",
    "BO": "BLOB",
    "BV": "VARBYTE",
    "CF": "CHAR",
    "CO": "CLOB",
    "CV": "VARCHAR",
    "D": "DECIMAL",
    "DA": "DATE",
    "DH": "INTERVAL DAY TO HOUR",
    "DM": "INTERVAL DAY TO MINUTE",
    "DS": "INTERVAL DAY TO SECOND",
    "DY": "INTERVAL DAY",
    "F": "FLOAT",
    "HM": "INTERVAL HOUR TO MINUTE",
    "HS": "INTERVAL HOUR TO SECOND",
    "HR": "INTERVAL HOUR",
    "I": "INTEGER",
    "I1": "BYTEINT",
    "I2": "SMALLINT",
    "I8": "BIGINT",
    "JN": "JSON",
    "MI": "INTERVAL MINUTE",
    "MO": "INTERVAL MONTH",
    "MS": "INTERVAL MINUTE TO SECOND",
    "N": "NUMBER",
    "PD": "PERIOD(DATE)",
    "PM": "PERIOD(TIMESTAMP WITH TIME ZONE)",
    "PS": "PERIOD(TIMESTAMP)",
    "PT": "PERIOD(TIME)",
    "PZ": "PERIOD(TIME WITH TIME ZONE)",
    "SC": "INTERVAL SECOND",
    "SZ": "TIMESTAMP WITH TIME ZONE",
    "TS": "TIMESTAMP",
    "TZ": "TIME WITH TIME ZONE",
    "XM": "XML",
    "YM": "INTERVAL YEAR TO MONTH",
    "YR": "INTERVAL YEAR",
}

TERADATA_STRING_DATA_TYPES = {
    "CHAR",
    "VARCHAR",
    "CLOB",
    "BYTE",
    "VARBYTE",
    "INTERVAL DAY TO HOUR",
    "INTERVAL DAY TO MINUTE",
    "INTERVAL DAY TO SECOND",
    "INTERVAL DAY",
    "INTERVAL HOUR TO MINUTE",
    "INTERVAL HOUR TO SECOND",
    "INTERVAL HOUR",
    "INTERVAL MINUTE",
    "INTERVAL MINUTE TO SECOND",
    "INTERVAL SECOND",
    "INTERVAL YEAR TO MONTH",
    "INTERVAL YEAR",
    "INTERVAL MONTH",
    "PERIOD(DATE)",
    "PERIOD(TIME)",
    "PERIOD(TIME WITH TIME ZONE)",
    "PERIOD(TIMESTAMP)",
    "PERIOD(TIMESTAMP WITH TIME ZONE)",
}

TERADATA_NUMERIC_DATA_TYPES = {
    "DECIMAL",
    "NUMBER",
    "INTEGER",
    "BYTEINT",
    "SMALLINT",
    "BIGINT",
}

TERADATA_HELP_COLUMN_NAME = "COLUMN NAME"
TERADATA_HELP_COLUMN_TYPE = "TYPE"
TERADATA_HELP_COLUMN_NULLABLE = "NULLABLE"
TERADATA_HELP_COLUMN_MAX_LENGTH = "MAX LENGTH"
TERADATA_HELP_COLUMN_DECIMAL_TOTAL = "DECIMAL TOTAL DIGITS"
TERADATA_HELP_COLUMN_DECIMAL_FRAC = "DECIMAL FRACTIONAL DIGITS"

COLUMN_VALIDATED_KEY = "COLUMN_VALIDATED"
TERADATA_HELP_COLUMN_PRIMARY = "PRIMARY?"


def teradata_normalize_table_column_metadata(
    database: str,
    table: str,
    metadata_df: pd.DataFrame,
) -> pd.DataFrame:
    """Normalize Teradata HELP COLUMN result into a standardized column metadata DataFrame.

    This function transforms the output of Teradata's HELP COLUMN command into a
    standardized DataFrame format used by the data validation framework.
    Uses vectorized pandas operations for better performance.

    Args:
        database: The database name containing the table.
        table: The table name.
        metadata_df: DataFrame containing HELP COLUMN results with columns:
            - Column Name: Name of the column
            - Type: 2-character Teradata type code (e.g., 'CV', 'I', 'D')
            - Nullable: Nullable indicator (Y/N/?/1/-)
            - Max Length: Maximum length for character types
            - Decimal Total Digits: Precision for numeric types
            - Decimal Fractional Digits: Scale for numeric types

    Returns:
        pd.DataFrame: Normalized DataFrame with columns:
            DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, DATA_TYPE,
            CHARACTER_LENGTH, PRECISION, SCALE, NULLABLE, IS_PRIMARY_KEY,
            CALCULATED_COLUMN_SIZE_IN_BYTES

    """
    output_columns = [
        DATABASE_NAME_KEY,
        SCHEMA_NAME_KEY,
        TABLE_NAME_KEY,
        COLUMN_NAME_KEY,
        DATA_TYPE_KEY,
        CHARACTER_LENGTH_KEY,
        PRECISION_KEY,
        SCALE_KEY,
        NULLABLE_KEY,
        IS_PRIMARY_KEY_KEY,
        CALCULATED_COLUMN_SIZE_IN_BYTES_KEY,
    ]

    if metadata_df.empty:
        return pd.DataFrame(columns=output_columns)

    result_df = pd.DataFrame()

    result_df[COLUMN_NAME_KEY] = (
        metadata_df[TERADATA_HELP_COLUMN_NAME].fillna("").astype(str).str.strip()
    )

    type_codes = (
        metadata_df[TERADATA_HELP_COLUMN_TYPE].fillna("").astype(str).str.strip()
    )
    result_df[DATA_TYPE_KEY] = type_codes.map(TERADATA_TYPE_CODE_MAPPING).fillna(
        type_codes
    )

    is_string = result_df[DATA_TYPE_KEY].isin(TERADATA_STRING_DATA_TYPES)
    is_numeric = result_df[DATA_TYPE_KEY].isin(TERADATA_NUMERIC_DATA_TYPES)

    max_length = pd.to_numeric(
        metadata_df[TERADATA_HELP_COLUMN_MAX_LENGTH], errors="coerce"
    ).fillna(0)
    result_df[CHARACTER_LENGTH_KEY] = "0"
    result_df.loc[is_string, CHARACTER_LENGTH_KEY] = (
        max_length[is_string].astype(int).astype(str)
    )

    decimal_total = pd.to_numeric(
        metadata_df[TERADATA_HELP_COLUMN_DECIMAL_TOTAL], errors="coerce"
    ).fillna(-128)
    decimal_frac = pd.to_numeric(
        metadata_df[TERADATA_HELP_COLUMN_DECIMAL_FRAC], errors="coerce"
    ).fillna(-128)

    result_df[PRECISION_KEY] = "-1"
    valid_precision = is_numeric & (decimal_total != -128)
    result_df.loc[valid_precision, PRECISION_KEY] = (
        decimal_total[valid_precision].astype(int).astype(str)
    )

    result_df[SCALE_KEY] = "-1"
    valid_scale = is_numeric & (decimal_frac != -128)
    result_df.loc[valid_scale, SCALE_KEY] = (
        decimal_frac[valid_scale].astype(int).astype(str)
    )

    nullable_values = (
        metadata_df[TERADATA_HELP_COLUMN_NULLABLE]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
    )
    result_df[NULLABLE_KEY] = nullable_values == "Y"

    primary_values = (
        metadata_df[TERADATA_HELP_COLUMN_PRIMARY]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
    )
    result_df[IS_PRIMARY_KEY_KEY] = primary_values == "Y"

    result_df[CALCULATED_COLUMN_SIZE_IN_BYTES_KEY] = "0"
    result_df.loc[is_string, CALCULATED_COLUMN_SIZE_IN_BYTES_KEY] = (
        max_length[is_string].astype(int).astype(str)
    )

    result_df[DATABASE_NAME_KEY] = database
    result_df[SCHEMA_NAME_KEY] = database
    result_df[TABLE_NAME_KEY] = table

    return result_df[output_columns]


def teradata_normalize_table_metadata(
    metadata_df: pd.DataFrame,
) -> pd.DataFrame:
    """Normalize Teradata HELP COLUMN result into minimal table metadata format.

    This function transforms the output of Teradata's HELP COLUMN command into a
    minimal DataFrame format used for simple schema validation.
    Uses vectorized pandas operations for better performance.

    Args:
        metadata_df: DataFrame containing HELP COLUMN results.

    Returns:
        pd.DataFrame: Normalized DataFrame with columns:
            COLUMN_VALIDATED, DATA_TYPE

    """
    output_columns = [COLUMN_VALIDATED_KEY, DATA_TYPE_KEY]

    if metadata_df.empty:
        return pd.DataFrame(columns=output_columns)

    result_df = pd.DataFrame()

    result_df[COLUMN_VALIDATED_KEY] = (
        metadata_df[TERADATA_HELP_COLUMN_NAME].fillna("").astype(str).str.strip()
    )

    type_codes = (
        metadata_df[TERADATA_HELP_COLUMN_TYPE].fillna("").astype(str).str.strip()
    )
    result_df[DATA_TYPE_KEY] = type_codes.map(TERADATA_TYPE_CODE_MAPPING).fillna(
        type_codes
    )

    return result_df[output_columns]
