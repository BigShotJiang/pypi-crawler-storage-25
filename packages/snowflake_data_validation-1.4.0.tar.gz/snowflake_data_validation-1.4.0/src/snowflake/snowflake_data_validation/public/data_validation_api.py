# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import json
import os
import tempfile

from collections.abc import Callable
from pathlib import Path

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.configuration.configuration_loader import (
    ConfigurationLoader,
)
from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.extractor.sql_queries_template_generator import (
    SQLQueriesTemplateGenerator,
)
from snowflake.snowflake_data_validation.public._internal import (
    build_script_file_path as _build_script_file_path,
)
from snowflake.snowflake_data_validation.public._internal import (
    execute_query_internal as _execute_query_internal,
)
from snowflake.snowflake_data_validation.public._internal import (
    get_target_cols,
    is_snowflake_stage,
    load_snapshot_dataframe,
    upload_to_stage,
)
from snowflake.snowflake_data_validation.public._internal import (
    write_query_to_script as _write_query_to_script,
)
from snowflake.snowflake_data_validation.public._teradata_internal import (
    teradata_normalize_table_column_metadata,
    teradata_normalize_table_metadata,
)
from snowflake.snowflake_data_validation.public.model import (
    DataValidationExceptionError,
    GeneratedQuery,
    QueryExecutionResult,
    ResultSet,
    ValidationResult,
)
from snowflake.snowflake_data_validation.public.model.query_generator_factory import (
    QueryGeneratorFactory,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)
from snowflake.snowflake_data_validation.utils.arguments_manager_factory import (
    ArgumentsManagerFactory,
    create_validation_environment_from_config,
)
from snowflake.snowflake_data_validation.utils.console_output_handler import (
    ConsoleOutputHandler,
)
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_DATATYPE,
    COLUMN_NAME_KEY,
    COLUMN_VALIDATED,
    DATABASE_NAME_KEY,
    DEFAULT_OBJECT_ID,
    DEFAULT_TOLERANCE,
    IS_DATA_TYPE_SUPPORTED_KEY,
    ROW_COUNT_KEY,
    SCHEMA_NAME_KEY,
    SNAPSHOT_CELL_VALIDATION_FILE_NAME_FORMAT,
    SNAPSHOT_METADATA_EXECUTION_MODE_KEY,
    SNAPSHOT_METADATA_FILE_NAME_FORMAT,
    SNAPSHOT_METADATA_FULLY_QUALIFIED_NAME_KEY,
    SNAPSHOT_METADATA_PLATFORM_KEY,
    SNAPSHOT_METADATA_TIMESTAMP_KEY,
    SNAPSHOT_METADATA_VALIDATION_LEVELS_KEY,
    SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT,
    SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT,
    SNAPSHOT_SUPPORTED_VALIDATION_LEVELS,
    TABLE_NAME_KEY,
    ExecutionMode,
    ObjectType,
    Platform,
    SnapshotMode,
    ValidationLevel,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_database import (
    HelperDatabase,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_misc import (
    get_current_timestamp,
)
from snowflake.snowflake_data_validation.utils.model.table_column_metadata import (
    TableColumnMetadata,
)
from snowflake.snowflake_data_validation.utils.model.table_context import (
    TableContext,
)
from snowflake.snowflake_data_validation.validation.cell_data_validator import (
    CellDataValidator,
)
from snowflake.snowflake_data_validation.validation.metrics_data_validator import (
    MetricsDataValidator,
)
from snowflake.snowflake_data_validation.validation.query_validator import (
    QueryValidator,
)
from snowflake.snowflake_data_validation.validation.result_set_validator import (
    ResultSetValidator,
)
from snowflake.snowflake_data_validation.validation.row_data_validator import (
    RowDataValidator,
)
from snowflake.snowflake_data_validation.validation.schema_data_validator import (
    SchemaDataValidator,
)


# =============================================================================
# STEP 0: METADATA GENERATION FUNCTIONS
# =============================================================================


def generate_view_materialization_query(
    fully_qualified_view_name: str,
    fully_qualified_temporary_table_name: str,
    platform: Platform,
    sql_generator: SQLQueriesTemplateGenerator,
) -> GeneratedQuery:
    """Generate a query to materialize a view as a temporary table.

    This function creates the SQL query needed to create a temporary table
    from a view (CREATE TABLE AS SELECT). This is useful for view validation
    where the view data needs to be materialized before validation operations.

    Args:
        fully_qualified_view_name: The fully qualified name of the view to materialize
            (e.g., "database.schema.view_name").
        fully_qualified_temporary_table_name: The fully qualified name of the
            temporary table to create (e.g., "database.schema.temp_table_name").
        platform: The database platform (SNOWFLAKE, SQLSERVER, etc.).
        sql_generator: The SQLQueriesTemplateGenerator instance to use for query generation.

    Returns:
        GeneratedQuery: The generated DDL statement to create the temporary table.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(platform=platform)
        query_string = query_generator.generate_temporary_table_from_view_query(
            fully_qualified_temporary_table_name=fully_qualified_temporary_table_name,
            fully_qualified_view_name=fully_qualified_view_name,
            platform=platform,
            sql_generator=sql_generator,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=fully_qualified_view_name,
            object_id="",
        ) from e


def generate_column_metadata_query(
    table_configuration: TableConfiguration,
    sql_generator: SQLQueriesTemplateGenerator,
    platform: Platform,
) -> GeneratedQuery:
    """Generate a query to extract column metadata from a table.

    This function creates the SQL query needed to extract detailed column
    information including names, data types, nullability, and primary key
    status. The query generator is automatically selected based on the platform.

    Args:
        table_configuration: The table configuration containing table metadata.
        sql_generator: The SQLQueriesTemplateGenerator instance to use for query generation.
        platform: The database platform for which to generate the query.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(platform=platform)
        query_string = query_generator.generate_table_column_metadata_query(
            table_configuration=table_configuration,
            sql_generator=sql_generator,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=table_configuration.fully_qualified_name,
            object_id=table_configuration.id,
        ) from e


def generate_row_count_query(
    fully_qualified_name: str,
    where_clause: str,
    has_where_clause: bool,
    object_id: int,
    platform: Platform,
    sql_generator: SQLQueriesTemplateGenerator,
) -> GeneratedQuery:
    """Generate a query to extract the row count from a table.

    This function creates the SQL query needed to count the rows in a table,
    optionally filtered by a WHERE clause if specified in the table context.

    Args:
        fully_qualified_name: The fully qualified name of the table to count rows from.
        where_clause: The WHERE clause to apply for filtering rows (if any).
        has_where_clause: Flag indicating whether a WHERE clause should be included.
        object_id: The unique identifier of the table (used for error context).
        platform: The database platform for which to generate the query.
        sql_generator: The SQLQueriesTemplateGenerator instance to use for query generation.

    Returns:
        GeneratedQuery: The generated row count query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(platform=platform)
        query_string = query_generator.generate_table_row_count_query(
            fully_qualified_name=fully_qualified_name,
            where_clause=where_clause,
            has_where_clause=has_where_clause,
            platform=platform,
            sql_generator=sql_generator,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=fully_qualified_name,
            object_id=object_id,
        ) from e


def generate_case_sensitive_columns_query(
    sql_generator: SQLQueriesTemplateGenerator,
    target_database_name: str,
    target_schema_name: str,
    target_table_name: str,
    platform: Platform,
) -> GeneratedQuery:
    """Generate a query to extract case-sensitive column names from Snowflake.

    This function creates the SQL query needed to retrieve the list of
    case-sensitive column names from Snowflake. This is used to determine
    which columns should be treated as case-sensitive during metadata
    transformation.

    Args:
        sql_generator: The SQLQueriesTemplateGenerator instance to use for query generation.
        target_database_name: The name of the target database.
        target_schema_name: The name of the target schema.
        target_table_name: The name of the target table.
        platform: The database platform for which to generate the query.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        database_name = HelperDatabase.normalize_identifier(
            identifier=target_database_name
        )

        schema_name = HelperDatabase.normalize_identifier(identifier=target_schema_name)

        table_name = HelperDatabase.normalize_identifier(identifier=target_table_name)

        query_string = sql_generator.get_case_sensitive_columns(
            database_name=database_name,
            schema_name=schema_name,
            table_name=table_name,
            platform=platform.value,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="CaseSensitiveColumns",
            object_id="",
        ) from e


# =============================================================================
# STEP 1: QUERY GENERATION FUNCTIONS
# =============================================================================


def execute_view_materialization(
    connector: ConnectorBase,
    generated_query: GeneratedQuery,
    fully_qualified_view_name: str,
    platform: Platform,
) -> None:
    """Execute a view materialization query.

    This function executes a DDL statement to create a temporary table
    from a view. Use this after generating the query with
    generate_view_materialization_query().

    Args:
        connector: The database connector to use for execution.
        generated_query: The query to execute (from generate_view_materialization_query).
        fully_qualified_view_name: The view name for error context.
        platform: The platform for error context.

    Raises:
        DataValidationExceptionError: If execution fails.

    """
    try:
        connector.execute_statement(generated_query.query_string)
    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=fully_qualified_view_name,
            object_id="",
        ) from e


def generate_schema_query(table_context: TableContext) -> GeneratedQuery:
    """Generate a schema validation query without executing it.

    This function creates the SQL query needed to extract schema metadata
    from a table. The query generator is automatically selected based on
    the platform specified in the table_context.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_schema_query(table_context)
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_metrics_query(
    table_context: TableContext,
) -> GeneratedQuery:
    """Generate a metrics validation query without executing it.

    This function creates the SQL query needed to extract column-level
    metrics (min, max, count, distinct, etc.) from a table. The query
    generator is automatically selected based on the platform.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_metrics_query(
            table_context=table_context,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_cell_validation_data_query(
    table_context: TableContext,
    order_by_columns: list[str] | None = None,
) -> GeneratedQuery:
    """Generate SELECT for L3 cell validation using the same normalization as L3 MD5.

    Each column is wrapped with the platform's datatype normalization templates
    (TO_CHAR/TRIM for numerics and dates, TRIM for strings) so cell-by-cell
    comparison matches row-hash validation semantics.

    Args:
        table_context: Source or target table context with ``columns`` populated
            from L1 schema metadata (and ``where_clause`` / FQN as needed).
        order_by_columns: Optional index columns for deterministic row ordering.

    Returns:
        GeneratedQuery: SQL string ready for execution on that platform.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_cell_validation_data_query(
            table_context,
            order_by_columns=order_by_columns,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# STEP 1.2: ROW VALIDATION QUERY GENERATION FUNCTIONS
# =============================================================================


def generate_create_md5_table_statement(
    table_context: TableContext,
) -> GeneratedQuery:
    """Generate DDL statement to create MD5 chunks storage table.

    This function creates the DDL statement needed to create a temporary
    table for storing MD5 checksums during row validation. The query
    generator is automatically selected based on the platform.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.

    Returns:
        GeneratedQuery: The generated DDL statement.

    Raises:
        DataValidationExceptionError: If statement generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        statement = query_generator.generate_statement_table_chunks_md5(table_context)
        return GeneratedQuery(query_string=statement)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_compute_md5_queries(
    table_context: TableContext,
    other_table_name: str,
) -> list[GeneratedQuery]:
    """Generate queries to compute MD5 checksums for each chunk.

    This function creates the SQL queries needed to compute MD5 checksums
    for row validation. Returns a list because each chunk requires a
    separate INSERT query. The query generator is automatically selected
    based on the platform.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.
        other_table_name: The name of the corresponding table on the
            other platform (used for chunk ID generation).

    Returns:
        list[GeneratedQuery]: List of generated queries, one per chunk.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        queries = query_generator.generate_compute_md5_query(
            table_context=table_context,
            other_table_name=other_table_name,
        )

        if isinstance(queries, str):
            return [GeneratedQuery(query_string=queries)]

        return [GeneratedQuery(query_string=q) for q in queries]

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_extract_chunks_md5_query(
    table_context: TableContext,
) -> GeneratedQuery:
    """Generate query to extract MD5 checksums for all chunks.

    This function creates the SQL query needed to extract the computed
    MD5 checksums from the chunks storage table. The query generator
    is automatically selected based on the platform.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_extract_chunks_md5_query(table_context)
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_extract_md5_rows_chunk_query(
    chunk_id: str,
    table_context: TableContext,
) -> GeneratedQuery:
    """Generate query to extract MD5 rows for a specific chunk.

    This function creates the SQL query needed to extract the individual
    MD5 row hashes for a specific chunk that was identified as having
    differences. The query generator is automatically selected based
    on the platform.

    Args:
        chunk_id: The unique identifier for the chunk to extract.
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.

    Returns:
        GeneratedQuery: The generated query string.

    Raises:
        DataValidationExceptionError: If query generation fails.

    """
    try:
        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_extract_md5_rows_chunk_query(
            chunk_id=chunk_id,
            table_context=table_context,
        )
        return GeneratedQuery(query_string=query_string)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# STEP 2: QUERY EXECUTION FUNCTIONS
# =============================================================================


def execute_query_from_table_configuration(
    table_configuration: TableConfiguration,
    platform: Platform,
    connector: ConnectorBase,
    generated_query: GeneratedQuery,
    result_processor: Callable[[list, bool], pd.DataFrame] | None = None,
) -> QueryExecutionResult:
    """Execute a pre-generated query using table configuration for context.

    Args:
        table_configuration: The table configuration containing table metadata.
        platform: The platform for query execution and error context.
        connector: The database connector to use for execution.
        generated_query: The query to execute (from generation step).
        result_processor: Optional function to convert raw results to DataFrame.
            If not provided, a platform-appropriate processor is used automatically.

    Returns:
        QueryExecutionResult: The execution result containing the DataFrame.

    Raises:
        DataValidationExceptionError: If query execution fails.

    """
    return _execute_query_internal(
        connector=connector,
        generated_query=generated_query,
        platform=platform,
        is_case_sensitive=table_configuration.is_case_sensitive,
        object_name=table_configuration.fully_qualified_name,
        object_id=table_configuration.id,
        result_processor=result_processor,
    )


def execute_query(
    table_context: TableContext,
    connector: ConnectorBase,
    generated_query: GeneratedQuery,
    result_processor: Callable[[list, bool], pd.DataFrame] | None = None,
) -> QueryExecutionResult:
    """Execute a pre-generated query and return the result.

    Args:
        table_context: The table context containing table metadata.
            The platform is inferred from table_context.platform.
        connector: The database connector to use for execution.
        generated_query: The query to execute (from generation step).
        result_processor: Optional function to convert raw results to DataFrame.
            If not provided, a platform-appropriate processor is used automatically.

    Returns:
        QueryExecutionResult: The execution result containing the DataFrame.

    Raises:
        DataValidationExceptionError: If query execution fails.

    """
    return _execute_query_internal(
        connector=connector,
        generated_query=generated_query,
        platform=table_context.platform,
        is_case_sensitive=table_context.is_case_sensitive,
        object_name=table_context.fully_qualified_name,
        object_id=table_context.id,
        result_processor=result_processor,
    )


def execute_statement(
    table_context: TableContext,
    connector: ConnectorBase,
    generated_query: GeneratedQuery,
) -> None:
    """Execute a statement or query without returning results.

    This function executes DDL statements (CREATE, DROP, etc.) or
    DML statements (INSERT, UPDATE, DELETE) that don't return data.
    Use this for operations like creating MD5 tables or computing
    MD5 checksums during row validation.

    Args:
        table_context: The table context containing table metadata.
            Used for error context if execution fails.
        connector: The database connector to use for execution.
        generated_query: The statement/query to execute.

    Raises:
        DataValidationExceptionError: If execution fails.

    """
    try:
        connector.execute_statement(generated_query.query_string)
    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# STEP 3: VALIDATION FUNCTIONS
# =============================================================================


def validate_schema_simple(
    source_query_result: QueryExecutionResult,
    target_query_result: QueryExecutionResult,
    table_context: TableContext,
    column_mappings: dict[str, str],
    datatypes_mappings: dict[str, str],
) -> ValidationResult:
    """Validate schema by comparing source and target DataFrames.

    This function compares schema metadata from source and target platforms
    and produces a validation result.

    Args:
        source_query_result: QueryExecutionResult with source schema metadata.
        target_query_result: QueryExecutionResult with target schema metadata.
        table_context: TableContext for the table being validated.
        column_mappings: Mapping of source to target column names.
        datatypes_mappings: Mapping of source datatypes to target datatypes (required).

    Returns:
        ValidationResult: The validation result.

    Raises:
        DataValidationExceptionError: If validation fails.

    """
    try:
        validator = SchemaDataValidator()

        differences_data: pd.DataFrame = validator.validate_table_metadata_basic(
            object_name=table_context.fully_qualified_name,
            object_type=table_context.object_type,
            object_id=table_context.id,
            target_df=target_query_result.dataframe,
            source_df=source_query_result.dataframe,
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

        return ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def validate_schema(
    source_query_result: QueryExecutionResult,
    target_query_result: QueryExecutionResult,
    table_context: TableContext,
    column_mappings: dict[str, str],
    datatypes_mappings: dict[str, str],
) -> ValidationResult:
    """Validate schema by comparing source and target DataFrames.

    This function compares schema metadata from source and target platforms
    and produces a validation result.

    Args:
        source_query_result: QueryExecutionResult with source schema metadata.
        target_query_result: QueryExecutionResult with target schema metadata.
        table_context: TableContext for the table being validated.
        column_mappings: Mapping of source to target column names.
        datatypes_mappings: Mapping of source datatypes to target datatypes (required).

    Returns:
        ValidationResult: The validation result.

    Raises:
        DataValidationExceptionError: If validation fails.

    """
    try:
        validator = SchemaDataValidator()

        differences_data: pd.DataFrame = validator.validate_table_metadata(
            object_name=table_context.fully_qualified_name,
            object_type=table_context.object_type,
            object_id=table_context.id,
            target_df=target_query_result.dataframe,
            source_df=source_query_result.dataframe,
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

        return ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def validate_metrics(
    source_query_result: QueryExecutionResult,
    target_query_result: QueryExecutionResult,
    table_context: TableContext,
    column_mappings: dict[str, str],
    tolerance: float = DEFAULT_TOLERANCE,
) -> ValidationResult:
    """Validate metrics by comparing source and target DataFrames.

    This function compares column-level metrics from source and target
    platforms and produces a validation result.

    Args:
        source_query_result: QueryExecutionResult with source metrics metadata.
        target_query_result: QueryExecutionResult with target metrics metadata.
        table_context: TableContext for the source table.
        column_mappings: Mapping of source to target column names.
        tolerance: Tolerance for numeric comparisons (default 0.001).

    Returns:
        ValidationResult: The validation result.

    Raises:
        DataValidationExceptionError: If validation fails.

    """
    try:
        validator = MetricsDataValidator()

        results_dataframe: pd.DataFrame = validator.validate_column_metadata(
            object_name=table_context.fully_qualified_name,
            object_type=table_context.object_type,
            object_id=table_context.id,
            target_df=target_query_result.dataframe,
            source_df=source_query_result.dataframe,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        return ValidationResult(
            is_valid=results_dataframe.empty,
            results_dataframe=results_dataframe,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# STEP 3.1: ROW VALIDATION - CHUNK COMPARISON
# =============================================================================


def compare_md5_chunks(
    source_chunks_result: QueryExecutionResult,
    target_chunks_result: QueryExecutionResult,
    table_context: TableContext,
) -> ValidationResult:
    """Compare MD5 chunks between source and target.

    This function compares the MD5 checksums of data chunks from source
    and target platforms. It identifies chunks that have different MD5
    values, indicating potential data differences.

    Args:
        source_chunks_result: QueryExecutionResult containing source MD5 chunks.
        target_chunks_result: QueryExecutionResult containing target MD5 chunks.
        table_context: TableContext for error context.

    Returns:
        ValidationResult: Contains is_valid (True if no differences) and
            results_dataframe with chunks that have different MD5 values.

    Raises:
        DataValidationExceptionError: If comparison fails.

    """
    try:
        validator = RowDataValidator()
        results_dataframe = validator.get_diff_md5_chunks(
            source_md5_df=source_chunks_result.dataframe,
            target_md5_df=target_chunks_result.dataframe,
        )

        return ValidationResult(
            is_valid=results_dataframe.empty,
            results_dataframe=results_dataframe,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def compare_md5_rows_chunk(
    source_rows_result: QueryExecutionResult,
    target_rows_result: QueryExecutionResult,
    source_index_column_suffix_collection: list[str],
    target_index_column_suffix_collection: list[str],
    table_context: TableContext,
) -> ValidationResult:
    """Compare MD5 rows within a specific chunk between source and target.

    This function compares individual row MD5 hashes within a chunk that
    was identified as having differences. It identifies specific rows
    that differ between source and target.

    Args:
        source_rows_result: QueryExecutionResult containing source MD5 rows
            for the chunk.
        target_rows_result: QueryExecutionResult containing target MD5 rows
            for the chunk.
        source_index_column_suffix_collection: List of source index column
            names with suffix (e.g., ["ID_SOURCE", "NAME_SOURCE"]).
        target_index_column_suffix_collection: List of target index column
            names with suffix (e.g., ["ID_TARGET", "NAME_TARGET"]).
        table_context: TableContext for error context.

    Returns:
        ValidationResult: Contains is_valid (True if no differences) and
            results_dataframe with rows that have different MD5 values.

    Raises:
        DataValidationExceptionError: If comparison fails.

    """
    try:
        validator = RowDataValidator()
        results_dataframe = validator.get_diff_md5_rows_chunk(
            source_md5_rows_chunk=source_rows_result.dataframe,
            target_md5_rows_chunk=target_rows_result.dataframe,
            source_index_column_suffix_collection=source_index_column_suffix_collection,
            target_index_column_suffix_collection=target_index_column_suffix_collection,
        )

        return ValidationResult(
            is_valid=results_dataframe.empty,
            results_dataframe=results_dataframe,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# STEP 3.2: ROW VALIDATION - CELL COMPARISON
# =============================================================================
def validate_cell(
    source_query_result: QueryExecutionResult,
    target_query_result: QueryExecutionResult,
    table_context: TableContext,
    index_columns: list[str] | None = None,
    target_index_columns: list[str] | None = None,
) -> ValidationResult:
    """Validate individual cell values between source and target.

    This function compares individual cell values for specific rows and
    columns that were identified as having differences. It produces a
    validation result indicating which specific cells differ.

    When *index_columns* is provided, rows are matched by their key
    column values (the same strategy used by row-by-row validation)
    instead of by positional order.

    Args:
        source_query_result: QueryExecutionResult containing source row data.
        target_query_result: QueryExecutionResult containing target row data.
        table_context: TableContext for error context.
        index_columns: Source-side key column names for row matching.
            When ``None``, rows are matched positionally.
        target_index_columns: Target-side key column names.
            Defaults to *index_columns* when ``None``.

    Returns:
        ValidationResult: Contains is_valid (True if no differences) and
            results_dataframe with specific cells that have different values.

    Raises:
        DataValidationExceptionError: If validation fails.

    """
    try:
        validator = CellDataValidator()
        results_dataframe = validator.validate_cell_comparison(
            object_name=table_context.fully_qualified_name,
            source_df=source_query_result.dataframe,
            target_df=target_query_result.dataframe,
            index_columns=index_columns,
            target_index_columns=target_index_columns,
        )

        return ValidationResult(
            is_valid=results_dataframe.empty,
            results_dataframe=results_dataframe,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=table_context.platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


# =============================================================================
# SNAPSHOT GENERATION AND VALIDATION
# =============================================================================
def generate_snapshot(
    table_context: TableContext | ResultSet,
    validation_levels: set[ValidationLevel],
    output_directory: str,
    snowflake_stage_connector: ConnectorSnowflake,
    connector: ConnectorBase | None = None,
) -> list[str]:
    """Generate validation snapshots for a table at specified validation levels.

    Args:
        table_context: The context of the table for which to generate snapshots.
        validation_levels: The set of validation levels to include in the snapshot.
        output_directory: The local directory or Snowflake stage path where
            snapshots will be stored.
        snowflake_stage_connector: The Snowflake stage connector to use if
            output_directory is a stage.
        connector: The database connector to use for executing queries. Optional
            when table_context is ResultSet, required when table_context is
            TableContext.

    Returns:
        list[str]: A list of file paths to the generated snapshot files
            (local paths or stage paths).

    """
    try:
        if validation_levels is None or len(validation_levels) == 0:
            raise ValueError(
                "At least one validation level must be specified for snapshot generation."
            )

        if not validation_levels.issubset(SNAPSHOT_SUPPORTED_VALIDATION_LEVELS):
            raise ValueError(
                "Snapshot generation is only supported for schema and metrics validation levels. "
            )

        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot generation."
            )

        is_stage = is_snowflake_stage(output_directory)
        is_table = isinstance(table_context, TableContext)
        platform = table_context.platform if is_table else Platform.RESULT_SET
        if is_stage:
            if is_table:
                stage_files = generate_stage_snapshot_table(
                    table_context=table_context,
                    connector=connector,
                    validation_levels=validation_levels,
                    stage=output_directory,
                    execution_mode=SnapshotMode.STAGE,
                    snowflake_stage_connector=snowflake_stage_connector,
                    platform=platform,
                )
            else:
                stage_files = generate_stage_snapshot_result_set(
                    result_set=table_context,
                    validation_levels=validation_levels,
                    stage=output_directory,
                    execution_mode=SnapshotMode.STAGE,
                    snowflake_stage_connector=snowflake_stage_connector,
                    platform=platform,
                )
            return stage_files
        else:
            if is_table:
                local_files = generate_local_snapshot_table(
                    table_context=table_context,
                    connector=connector,
                    validation_levels=validation_levels,
                    execution_mode=SnapshotMode.LOCAL,
                    output_directory=output_directory,
                    platform=platform,
                )
            else:
                local_files = generate_local_snapshot_result_set(
                    result_set=table_context,
                    validation_levels=validation_levels,
                    execution_mode=SnapshotMode.LOCAL,
                    output_directory=output_directory,
                    platform=platform,
                )
            return local_files

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=table_context.fully_qualified_name,
            object_id=table_context.id,
        ) from e


def generate_local_snapshot_table(
    table_context: TableContext,
    connector: ConnectorBase,
    validation_levels: set[ValidationLevel],
    execution_mode: SnapshotMode,
    output_directory: str,
    platform: Platform,
) -> list[str]:
    """
    Generate validation snapshots and save them to a local directory.

    Args:
        table_context: The context of the table for which to generate snapshots.
        connector: The database connector to use for executing queries.
        validation_levels: The set of validation levels to include in the snapshot.
        execution_mode: The mode of snapshot generation (used for metadata).
        output_directory: The local directory where snapshots will be stored.
        platform: The platform.

    Returns:
        list[str]: A list of file paths to the generated snapshot files in the local directory.

    """
    output_files = []
    output_directory_path = Path(output_directory)

    if not output_directory_path.is_dir():
        raise ValueError(
            f"Output directory path '{output_directory}' is not a directory."
        )

    if ValidationLevel.SCHEMA_VALIDATION in validation_levels:
        schema_snapshot_file = generate_schema_validation_snapshot_table(
            table_context=table_context,
            connector=connector,
            output_directory_path=output_directory_path,
        )
        output_files.append(schema_snapshot_file)

    if ValidationLevel.METRICS_VALIDATION in validation_levels:
        metrics_snapshot_file = generate_metrics_validation_snapshot_table(
            table_context=table_context,
            connector=connector,
            output_directory_path=output_directory_path,
        )
        output_files.append(metrics_snapshot_file)

    if ValidationLevel.CELL_VALIDATION in validation_levels:
        raise ValueError(
            "Cell validation snapshots for table are not supported for generation."
        )

    metadata_output_path = generate_snapshot_metadata_table(
        table_context=table_context,
        validation_levels=validation_levels,
        execution_mode=execution_mode,
        output_directory_path=output_directory_path,
        platform=platform,
    )
    output_files.append(metadata_output_path)

    return output_files


def generate_stage_snapshot_table(
    table_context: TableContext,
    connector: ConnectorBase,
    validation_levels: set[ValidationLevel],
    stage: str,
    execution_mode: SnapshotMode,
    snowflake_stage_connector: ConnectorSnowflake,
    platform: Platform,
) -> list[str]:
    """
    Generate validation snapshots and upload them to a Snowflake stage.

    Args:
        table_context: The context of the table for which to generate snapshots.
        connector: The database connector to use for executing queries.
        validation_levels: The set of validation levels to include in the snapshot.
        stage: The Snowflake stage path where snapshots will be uploaded.
        execution_mode: The mode of snapshot generation (used for metadata).
        snowflake_stage_connector: The Snowflake stage connector to use for uploading files.
        platform: The platform.

    Returns:
        list[str]: A list of stage paths to the uploaded snapshot files.

    """
    output_files = []
    with tempfile.TemporaryDirectory() as temporary_output_directory:
        local_files = generate_local_snapshot_table(
            table_context=table_context,
            connector=connector,
            validation_levels=validation_levels,
            execution_mode=execution_mode,
            output_directory=temporary_output_directory,
            platform=platform,
        )

        normalized_stage = HelperDatabase.normalize_snowflake_stage(stage)
        for local_file in local_files:
            output_file = upload_to_stage(
                connector=snowflake_stage_connector,
                local_file=local_file,
                stage=normalized_stage,
            )
            output_files.append(output_file)

    return output_files


def generate_schema_validation_snapshot_table(
    table_context: TableContext,
    connector: ConnectorBase,
    output_directory_path: Path,
) -> str:
    """
    Generate schema validation snapshot for a given table context.

    Args:
        table_context: The context of the table for which to generate the snapshot.
        connector: The database connector to use for executing queries.
        output_directory_path: The directory where the snapshot file will be saved.

    Returns:
        str: The path to the generated schema snapshot file.

    """
    schema_validation_query = generate_schema_query(table_context=table_context)
    schema_validation_query_result = execute_query(
        table_context=table_context,
        connector=connector,
        generated_query=schema_validation_query,
    )
    schema_snapshot_path = output_directory_path / SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
        normalized_fully_qualified_name=table_context.normalized_fully_qualified_name
    )
    schema_validation_query_result.dataframe.to_parquet(schema_snapshot_path)
    return str(schema_snapshot_path)


def generate_metrics_validation_snapshot_table(
    table_context: TableContext,
    connector: ConnectorBase,
    output_directory_path: Path,
) -> str:
    """
    Generate metrics validation snapshot for a given table context.

    Args:
        table_context: The context of the table for which to generate the snapshot.
        connector: The database connector to use for executing queries.
        output_directory_path: The directory where the snapshot file will be saved.

    Returns:
        str: The path to the generated metrics snapshot file.

    """
    metrics_validation_query = generate_metrics_query(table_context=table_context)
    metrics_validation_query_result = execute_query(
        table_context=table_context,
        connector=connector,
        generated_query=metrics_validation_query,
    )
    metrics_snapshot_path = output_directory_path / SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
        normalized_fully_qualified_name=table_context.normalized_fully_qualified_name
    )
    metrics_validation_query_result.dataframe.to_parquet(metrics_snapshot_path)
    return str(metrics_snapshot_path)


def generate_snapshot_metadata_table(
    table_context: TableContext,
    validation_levels: set[ValidationLevel],
    execution_mode: SnapshotMode,
    output_directory_path: Path,
    platform: Platform,
) -> str:
    """
    Generate snapshot metadata for a given table context.

    Args:
        table_context: The context of the table for which to generate metadata.
        validation_levels: The set of validation levels included in the snapshot.
        execution_mode: The mode of snapshot generation (used for metadata).
        output_directory_path: The directory where the metadata file will be saved.
        platform: The platform.

    Returns:
        str: The path to the generated metadata file.

    """
    timestamp = get_current_timestamp()
    snapshot_metadata = {
        SNAPSHOT_METADATA_TIMESTAMP_KEY: timestamp,
        SNAPSHOT_METADATA_FULLY_QUALIFIED_NAME_KEY: table_context.fully_qualified_name,
        SNAPSHOT_METADATA_PLATFORM_KEY: platform.value,
        SNAPSHOT_METADATA_VALIDATION_LEVELS_KEY: [
            level.value for level in validation_levels
        ],
        SNAPSHOT_METADATA_EXECUTION_MODE_KEY: execution_mode.value,
    }

    metadata_snapshot_path = output_directory_path / SNAPSHOT_METADATA_FILE_NAME_FORMAT.format(
        normalized_fully_qualified_name=table_context.normalized_fully_qualified_name
    )
    with open(metadata_snapshot_path, "w") as f:
        json.dump(snapshot_metadata, f, indent=4)

    return str(metadata_snapshot_path)


def validate_schema_snapshot_table(
    first_directory: str,
    first_table_fully_qualified_name: str,
    second_directory: str,
    second_table_fully_qualified_name: str,
    snowflake_stage_connector: ConnectorSnowflake,
    column_mappings: dict[str, str] | None = None,
    datatypes_mappings: dict[str, str] | None = None,
) -> ValidationResult:
    """
    Validate schema snapshots for two tables by loading their metadata from files and comparing them.

    Args:
        first_directory: The directory (local or Snowflake stage) containing the first table's snapshot
        first_table_fully_qualified_name: The fully qualified name of the first table (used for file naming).
        second_directory: The directory (local or Snowflake stage) containing the second table's snapshot
        second_table_fully_qualified_name: The fully qualified name of the second table (used
            for file naming).
        snowflake_stage_connector: The Snowflake stage connector to use for loading files if directories are
            stages.
        column_mappings: Optional dictionary for mapping column names between source and target.
        datatypes_mappings: Optional dictionary for mapping data types between source and target.

    Returns:
        ValidationResult: The result of the schema validation, including whether it is valid and any differences found.

    Raises:
        DataValidationExceptionError: If there is an error loading the snapshot files or during validation.

    """
    try:
        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot validation."
            )

        if column_mappings is None:
            column_mappings = {}

        if datatypes_mappings is None:
            datatypes_mappings = {}

        normalized_first_table_fully_qualified_name = (
            HelperDatabase.normalize_fully_qualified_name(
                fully_qualified_name=first_table_fully_qualified_name
            )
        )
        file_name = SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=normalized_first_table_fully_qualified_name
        )

        first_dataframe = load_snapshot_dataframe(
            directory=first_directory,
            file_name=file_name,
            validation_level=ValidationLevel.SCHEMA_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
        )

        normalized_second_table_fully_qualified_name = (
            HelperDatabase.normalize_fully_qualified_name(
                fully_qualified_name=second_table_fully_qualified_name
            )
        )

        file_name = SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=normalized_second_table_fully_qualified_name
        )

        second_dataframe = load_snapshot_dataframe(
            directory=second_directory,
            file_name=file_name,
            validation_level=ValidationLevel.SCHEMA_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
        )

        validator = SchemaDataValidator()
        differences_data: pd.DataFrame = validator.validate_table_metadata(
            object_name=first_table_fully_qualified_name,
            object_type=ObjectType.TABLE,
            object_id=DEFAULT_OBJECT_ID,
            source_df=first_dataframe,
            target_df=second_dataframe,
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to validate metrics snapshot: {str(e)}",
            platform=Platform.SNOWFLAKE.value,
            object_name=first_table_fully_qualified_name,
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def validate_metrics_snapshot_table(
    first_directory: str,
    first_table_fully_qualified_name: str,
    second_directory: str,
    second_table_fully_qualified_name: str,
    snowflake_stage_connector: ConnectorSnowflake,
    column_mappings: dict[str, str] | None = None,
    tolerance: float = DEFAULT_TOLERANCE,
) -> ValidationResult:
    """
    Validate metrics snapshots for two tables by loading their metadata from files and comparing them.

    Args:
        first_directory: The directory (local or Snowflake stage) containing the first table's snapshot
        first_table_fully_qualified_name: The fully qualified name of the first table (used for file naming).
        second_directory: The directory (local or Snowflake stage) containing the second table's snapshot
        second_table_fully_qualified_name: The fully qualified name of the second table (used
            for file naming).
        snowflake_stage_connector: The Snowflake stage connector to use for loading files if directories are
            stages.
        column_mappings: Optional dictionary for mapping column names between source and target.
        tolerance: The tolerance level for comparing metric values (default is 0.001).

    Returns:
        ValidationResult: The result of the metrics validation, including whether it is valid and any differences found.

    Raises:
        DataValidationExceptionError: If there is an error loading the snapshot files or during validation.

    """
    try:
        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot validation."
            )

        if column_mappings is None:
            column_mappings = {}

        normalized_first_table_fully_qualified_name = (
            HelperDatabase.normalize_fully_qualified_name(
                fully_qualified_name=first_table_fully_qualified_name
            )
        )
        file_name = SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=normalized_first_table_fully_qualified_name
        )

        first_dataframe = load_snapshot_dataframe(
            directory=first_directory,
            file_name=file_name,
            validation_level=ValidationLevel.METRICS_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
        )

        normalized_second_table_fully_qualified_name = (
            HelperDatabase.normalize_fully_qualified_name(
                fully_qualified_name=second_table_fully_qualified_name
            )
        )

        file_name = SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=normalized_second_table_fully_qualified_name
        )

        second_dataframe = load_snapshot_dataframe(
            directory=second_directory,
            file_name=file_name,
            validation_level=ValidationLevel.METRICS_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
        )

        validator = MetricsDataValidator()
        differences_data: pd.DataFrame = validator.validate_column_metadata(
            object_name=first_table_fully_qualified_name,
            object_type=ObjectType.TABLE,
            object_id=DEFAULT_OBJECT_ID,
            source_df=first_dataframe,
            target_df=second_dataframe,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to validate metrics snapshot: {str(e)}",
            platform=Platform.SNOWFLAKE.value,
            object_name=first_table_fully_qualified_name,
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def generate_local_snapshot_result_set(
    result_set: ResultSet,
    validation_levels: set[ValidationLevel],
    execution_mode: SnapshotMode,
    output_directory: str,
    platform: Platform,
) -> list[str]:
    """
    Generate validation snapshots for a ResultSet and save them to a local directory.

    Args:
        result_set: The ResultSet for which to generate snapshots.
        validation_levels: The set of validation levels to include in the snapshot.
        execution_mode: The mode of snapshot generation (used for metadata).
        output_directory: The local directory where snapshots will be stored.
        platform: The database platform (used for metadata).

    Returns:
        list[str]: A list of file paths to the generated snapshot files in the local directory.

    """
    output_files = []
    output_directory_path = Path(output_directory)

    if not output_directory_path.is_dir():
        raise ValueError(
            f"Output directory path '{output_directory}' is not a directory."
        )

    if ValidationLevel.SCHEMA_VALIDATION in validation_levels:
        schema_snapshot_file = generate_schema_validation_snapshot_result_set(
            result_set=result_set,
            output_directory_path=output_directory_path,
        )
        output_files.append(schema_snapshot_file)

    if ValidationLevel.METRICS_VALIDATION in validation_levels:
        metrics_snapshot_file = generate_metrics_validation_snapshot_result_set(
            result_set=result_set,
            output_directory_path=output_directory_path,
        )
        output_files.append(metrics_snapshot_file)

    if ValidationLevel.CELL_VALIDATION in validation_levels:
        cell_snapshot_file = generate_cell_validation_snapshot_result_set(
            result_set=result_set,
            output_directory_path=output_directory_path,
        )
        output_files.append(cell_snapshot_file)

    metadata_output_path = generate_snapshot_metadata_result_set(
        validation_levels=validation_levels,
        execution_mode=execution_mode,
        output_directory_path=output_directory_path,
        platform=platform,
    )
    output_files.append(metadata_output_path)

    return output_files


def generate_schema_validation_snapshot_result_set(
    result_set: ResultSet,
    output_directory_path: Path,
) -> str:
    """Generate a schema validation snapshot for a ResultSet and save it to a local directory.

    Args:
        result_set: The ResultSet for which to generate the schema snapshot.
        output_directory_path: The local directory where the snapshot will be stored.

    Returns:
        str: The file path to the generated schema snapshot file in the local directory.

    """
    schema_dataframe = pd.DataFrame(
        data=result_set.column_types.items(),
        columns=[COLUMN_VALIDATED, COLUMN_DATATYPE],
    )
    schema_snapshot_path = (
        output_directory_path
        / SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )
    )
    schema_dataframe.to_parquet(schema_snapshot_path)
    return str(schema_snapshot_path)


def generate_metrics_validation_snapshot_result_set(
    result_set: ResultSet,
    output_directory_path: Path,
) -> str:
    """Generate a metrics validation snapshot for a ResultSet and save it to a local directory.

    Args:
        result_set: The ResultSet for which to generate the metrics snapshot.
        output_directory_path: The local directory where the snapshot will be stored.

    Returns:
        str: The file path to the generated metrics snapshot file in the local directory.

    """
    result_set_validator = ResultSetValidator()
    result_set_dataframe = result_set_validator.to_polars_dataframe(
        result_set=result_set
    )
    metrics_dataframe = result_set_validator._calculate_column_metrics(
        polar_df=result_set_dataframe,
        column_mappings={},  # No mapping needed for source metrics calculation
    )

    metrics_snapshot_path = (
        output_directory_path
        / SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )
    )
    metrics_dataframe.to_parquet(metrics_snapshot_path)
    return str(metrics_snapshot_path)


def generate_cell_validation_snapshot_result_set(
    result_set: ResultSet,
    output_directory_path: Path,
) -> str:
    """Generate a cell validation snapshot for a ResultSet and save it to a local directory.

    Args:
        result_set: The ResultSet for which to generate the cell snapshot.
        output_directory_path: The local directory where the snapshot will be stored.

    Returns:
        str: The file path to the generated cell snapshot file in the local directory.

    """
    result_set_validator = ResultSetValidator()
    cell_dataframe = result_set_validator.to_polars_dataframe(result_set=result_set)
    cell_snapshot_path = (
        output_directory_path
        / SNAPSHOT_CELL_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )
    )
    cell_dataframe.write_parquet(cell_snapshot_path)
    return str(cell_snapshot_path)


def generate_snapshot_metadata_result_set(
    validation_levels: set[ValidationLevel],
    execution_mode: SnapshotMode,
    output_directory_path: Path,
    platform: Platform,
) -> str:
    """Generate snapshot metadata for a ResultSet and save it to a local directory.

    Args:
        validation_levels: The set of validation levels included in the snapshot.
        execution_mode: The mode of snapshot generation (used for metadata).
        output_directory_path: The local directory where the metadata file will be stored.
        platform: The platform.

    Returns:
        str: The file path to the generated metadata snapshot file in the local directory.

    """
    timestamp = get_current_timestamp()
    snapshot_metadata = {
        SNAPSHOT_METADATA_TIMESTAMP_KEY: timestamp,
        SNAPSHOT_METADATA_FULLY_QUALIFIED_NAME_KEY: Platform.RESULT_SET.value,
        SNAPSHOT_METADATA_PLATFORM_KEY: platform.value,
        SNAPSHOT_METADATA_VALIDATION_LEVELS_KEY: [
            level.value for level in validation_levels
        ],
        SNAPSHOT_METADATA_EXECUTION_MODE_KEY: execution_mode.value,
    }

    metadata_snapshot_path = (
        output_directory_path
        / SNAPSHOT_METADATA_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )
    )
    with open(metadata_snapshot_path, "w") as f:
        json.dump(snapshot_metadata, f, indent=4)

    return str(metadata_snapshot_path)


def generate_stage_snapshot_result_set(
    result_set: ResultSet,
    validation_levels: set[ValidationLevel],
    stage: str,
    execution_mode: SnapshotMode,
    snowflake_stage_connector: ConnectorSnowflake,
    platform: Platform,
) -> list[str]:
    """Generate validation snapshots for a ResultSet and save them to a Snowflake stage.

    Args:
        result_set: The ResultSet for which to generate snapshots.
        validation_levels: The set of validation levels to include in the snapshot.
        stage: The Snowflake stage path where snapshots will be uploaded.
        execution_mode: The mode of snapshot generation (used for metadata).
        output_directory: The Snowflake stage path where snapshots will be stored (e.g., "@my_stage/snapshots/").
        snowflake_stage_connector: The Snowflake stage connector to use for uploading files.
        platform: The database platform.

    Returns:
        list[str]: A list of stage file paths to the generated snapshot files in the Snowflake stage.

    """
    output_files = []
    with tempfile.TemporaryDirectory() as temporary_output_directory:
        local_files = generate_local_snapshot_result_set(
            result_set=result_set,
            validation_levels=validation_levels,
            execution_mode=execution_mode,
            output_directory=temporary_output_directory,
            platform=platform,
        )

        normalized_stage = HelperDatabase.normalize_snowflake_stage(stage)
        for local_file in local_files:
            output_file = upload_to_stage(
                connector=snowflake_stage_connector,
                local_file=local_file,
                stage=normalized_stage,
            )
            output_files.append(output_file)

    return output_files


def validate_schema_snapshot_result_set(
    first_directory: str,
    second_directory: str,
    datatypes_mappings: dict[str, str],
    snowflake_stage_connector: ConnectorSnowflake,
    column_mappings: dict[str, str] | None = None,
) -> ValidationResult:
    """Validate schema snapshot tables for result sets.

    This function loads the schema snapshot tables for two result sets from the specified directories,
    converts them to Polars DataFrames, and performs schema level validation using the provided column and
    data type mappings.

    Args:
        first_directory: The directory path containing the first result set's schema snapshot table.
        second_directory: The directory path containing the second result set's schema snapshot table.
        snowflake_stage_connector: The Snowflake stage connector to use for loading the snapshot tables.
        column_mappings: Optional dictionary for mapping column names between the two result sets.
        datatypes_mappings: Dictionary for mapping data types between the two result sets.

    Returns:
        ValidationResult: The result of the schema validation, including whether it is valid and any differences found.

    """
    try:
        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot validation."
            )

        if column_mappings is None:
            column_mappings = {}

        file_name = SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        first_dataframe = load_snapshot_dataframe(
            directory=first_directory,
            file_name=file_name,
            validation_level=ValidationLevel.SCHEMA_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            is_result_set=True,
        )

        file_name = SNAPSHOT_SCHEMA_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        second_dataframe = load_snapshot_dataframe(
            directory=second_directory,
            file_name=file_name,
            validation_level=ValidationLevel.SCHEMA_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            is_result_set=True,
        )

        validator = SchemaDataValidator()
        differences_data: pd.DataFrame = validator.validate_table_metadata_basic(
            object_name=Platform.RESULT_SET.value,
            object_type=ObjectType.TABLE,
            object_id=DEFAULT_OBJECT_ID,
            source_df=first_dataframe,
            target_df=second_dataframe,
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.RESULT_SET.value,
            object_name="validate schema snapshot",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def validate_metrics_snapshot_result_set(
    first_directory: str,
    second_directory: str,
    snowflake_stage_connector: ConnectorSnowflake,
    column_mappings: dict[str, str] | None = None,
    tolerance: float = DEFAULT_TOLERANCE,
) -> ValidationResult:
    """Validate metrics snapshot tables for result sets.

    This function loads the metrics snapshot tables for two result sets from the specified directories,
    converts them to Polars DataFrames, and performs metrics level validation using the provided column mappings and tolerance.

    Args:
        first_directory: The directory path containing the first result set's metrics snapshot table.
        second_directory: The directory path containing the second result set's metrics snapshot table.
        snowflake_stage_connector: The Snowflake stage connector to use for loading the snapshot tables.
        column_mappings: Optional dictionary for mapping column names between the two result sets.
        tolerance: The tolerance level for comparing metric values (default is 0.001).

    """
    try:
        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot validation."
            )

        if column_mappings is None:
            column_mappings = {}

        file_name = SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        first_dataframe = load_snapshot_dataframe(
            directory=first_directory,
            file_name=file_name,
            validation_level=ValidationLevel.METRICS_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            is_result_set=True,
        )

        file_name = SNAPSHOT_METRICS_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        second_dataframe = load_snapshot_dataframe(
            directory=second_directory,
            file_name=file_name,
            validation_level=ValidationLevel.METRICS_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            is_result_set=True,
        )

        validator = MetricsDataValidator()
        differences_data: pd.DataFrame = validator.validate_column_metadata(
            object_name=Platform.RESULT_SET.value,
            object_type=ObjectType.TABLE,
            object_id=DEFAULT_OBJECT_ID,
            source_df=first_dataframe,
            target_df=second_dataframe,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to validate metrics snapshot: {str(e)}",
            platform=Platform.RESULT_SET.value,
            object_name=Platform.RESULT_SET.value,
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def validate_cell_snapshot_result_set(
    first_directory: str,
    second_directory: str,
    snowflake_stage_connector: ConnectorSnowflake,
) -> ValidationResult:
    """Validate cell snapshot tables for result sets.

    This function loads the cell snapshot tables for two result sets from the specified
    local directories, converts them to Polars DataFrames, and performs cell level validation.

    Note: Cell validation from Snowflake stages is not supported. Both directories must be
    local file system paths.

    Args:
        first_directory: The local directory path containing the first result set's cell snapshot.
        second_directory: The local directory path containing the second result set's cell snapshot.
        snowflake_stage_connector: The Snowflake stage connector to use for loading snapshots.

    Returns:
        ValidationResult: Contains is_valid and results_dataframe with cell differences.

    Raises:
        ValueError: If either directory is a Snowflake stage path.

    """
    try:
        if is_snowflake_stage(first_directory) or is_snowflake_stage(second_directory):
            raise ValueError(
                "Cell validation from Snowflake stages is not supported for result sets. "
                "Please use local directories for cell validation."
            )

        file_name = SNAPSHOT_CELL_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        first_dataframe = load_snapshot_dataframe(
            directory=first_directory,
            file_name=file_name,
            validation_level=ValidationLevel.CELL_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            load_as_polars_df=True,
        )

        file_name = SNAPSHOT_CELL_VALIDATION_FILE_NAME_FORMAT.format(
            normalized_fully_qualified_name=Platform.RESULT_SET.value
        )

        second_dataframe = load_snapshot_dataframe(
            directory=second_directory,
            file_name=file_name,
            validation_level=ValidationLevel.CELL_VALIDATION,
            snowflake_stage_connector=snowflake_stage_connector,
            load_as_polars_df=True,
        )

        result_set_validator = ResultSetValidator()
        differences_data: pd.DataFrame = result_set_validator.cell_level_validation(
            first_result_set=first_dataframe,
            second_result_set=second_dataframe,
            object_name=Platform.RESULT_SET.value,
        )

        validation_result = ValidationResult(
            is_valid=True,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to validate cell snapshot: {str(e)}",
            platform=Platform.RESULT_SET.value,
            object_name=Platform.RESULT_SET.value,
            object_id=DEFAULT_OBJECT_ID,
        ) from e


# =============================================================================
# QUERY COMPARISON VALIDATION
# =============================================================================
def query_to_dataframe(
    query: GeneratedQuery,
    connector: ConnectorBase,
    platform: Platform,
) -> pl.DataFrame:
    """
    Convert a GeneratedQuery to a Polars DataFrame.

    Args:
        query (GeneratedQuery): The query to be executed.
        connector (ConnectorBase): The connector to use for executing the query.
        platform (Platform): The platform for which the query is being executed.

    Returns:
        pl.DataFrame: The resulting Polars DataFrame.

    Raises:
        DataValidationExceptionError: If there is an error during query execution.

    """
    try:
        query_validator = QueryValidator()
        dataframe = query_validator.to_polars_dataframe(
            query=query,
            connector=connector,
        )

        return dataframe

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="Query to dataframe",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def query_metrics_level_validation(
    first_dataframe: pl.DataFrame,
    second_dataframe: pl.DataFrame,
    column_mappings: dict[str, str] | None = None,
    tolerance: float = DEFAULT_TOLERANCE,
    custom_templates_directory: str | None = None,
) -> ValidationResult:
    """
    Compare two DataFrames at the metrics level and determine if they are equivalent.

    Args:
        first_dataframe (pl.DataFrame): The first DataFrame to compare.
        second_dataframe (pl.DataFrame): The second DataFrame to compare.
        column_mappings (dict[str, str] | None): Optional dictionary mapping columns between the DataFrames.
        tolerance (float): The tolerance level for comparison.
        custom_templates_directory (str | None): Optional directory path for custom metric query templates.

    Returns:
        ValidationResult: The result of the comparison, including whether the DataFrames are equivalent and any differences found.

    Raises:
        DataValidationExceptionError: If there is an error during validation.

    """
    try:
        if column_mappings is None:
            column_mappings = {}

        validator = QueryValidator(
            custom_templates_directory=custom_templates_directory
        )
        differences_data = validator.metrics_level_validation(
            first_dataframe=first_dataframe,
            second_dataframe=second_dataframe,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        return differences_data
    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.QUERY.value,
            object_name="Query comparison validation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def query_cell_level_validation(
    first_dataframe: pl.DataFrame,
    second_dataframe: pl.DataFrame,
    custom_templates_directory: str | None = None,
) -> ValidationResult:
    """
    Compare two DataFrames at the cell level and determine if they are equivalent.

    Args:
        first_dataframe (pl.DataFrame): The first DataFrame to compare.
        second_dataframe (pl.DataFrame): The second DataFrame to compare.
        custom_templates_directory (str | None): Optional directory path for custom metric query templates.

    Returns:
        ValidationResult: The result of the comparison, including whether the DataFrames are equivalent and any differences found.

    Raises:
        DataValidationExceptionError: If there is an error during validation.

    """
    try:
        validator = QueryValidator(
            custom_templates_directory=custom_templates_directory
        )
        differences_data = validator.cell_level_validation(
            first_dataframe=first_dataframe,
            second_dataframe=second_dataframe,
        )

        return differences_data

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.QUERY.value,
            object_name="Query comparison validation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


# =============================================================================
# RESULT SET COMPARISON VALIDATION
# =============================================================================
def result_set_to_dataframe(
    result_set: ResultSet,
    snowflake_stage_connector: ConnectorSnowflake,
    custom_templates_directory: str | None = None,
) -> pl.DataFrame:
    """
    Convert a ResultSet to a Polars DataFrame.

    Args:
        result_set (ResultSet): The result set to be converted.
        snowflake_stage_connector (ConnectorSnowflake): The Snowflake stage connector to use for the conversion.
        custom_templates_directory (str | None): Optional directory path for custom metric query templates.

    Returns:
        pl.DataFrame: The resulting Polars DataFrame.

    Raises:
        DataValidationExceptionError: If there is an error during the conversion.

    """
    try:
        if not isinstance(snowflake_stage_connector, ConnectorSnowflake):
            raise ValueError(
                "A Snowflake stage connector must be provided for stage snapshot generation."
            )

        validator = ResultSetValidator(
            custom_templates_directory=custom_templates_directory
        )
        dataframe = validator.to_polars_dataframe(
            result_set=result_set,
        )

        return dataframe

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.RESULT_SET.value,
            object_name="Result set to dataframe conversion",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def result_set_metrics_level_validation(
    first_result_set: ResultSet,
    second_result_set: ResultSet,
    column_mappings: dict[str, str] | None = None,
    tolerance: float = DEFAULT_TOLERANCE,
    custom_templates_directory: str | None = None,
) -> ValidationResult:
    """Compare two result sets at the metrics level and determine if they are equivalent.

    Args:
        first_result_set: The first ResultSet to compare.
        second_result_set: The second ResultSet to compare.
        column_mappings: Optional dictionary for mapping column names between the two result sets.
        tolerance: The tolerance level for comparing metric values (default is 0.001).
        custom_templates_directory: Optional directory path for custom metric query templates.

    Returns:
        ValidationResult: The result of the comparison, including whether the result sets are equivalent and any differences found.

    Exceptions:
        DataValidationExceptionError: If there is an error during validation, such as mismatched column counts or other issues.

    """
    try:
        if column_mappings is None:
            column_mappings = {}

        if len(first_result_set.column_types) != len(second_result_set.column_types):
            raise ValueError("The two result sets have different number of columns.")

        validator = ResultSetValidator(
            custom_templates_directory=custom_templates_directory
        )
        differences_data: pd.DataFrame = validator.metrics_level_validation(
            first_result_set=first_result_set,
            second_result_set=second_result_set,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        validation_result = ValidationResult(
            is_valid=not differences_data.empty,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.RESULT_SET.value,
            object_name="result set metrics level comparison",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def result_set_cell_level_validation(
    first_result_set: ResultSet,
    second_result_set: ResultSet,
    custom_templates_directory: str | None = None,
) -> ValidationResult:
    """
    Compare two result sets and determine if they are equivalent.

    This function compares the dataframes of two result sets, checking for
    equivalence in terms of data values, ignoring order and duplicates.
    It returns a ValidationResult indicating whether the result sets are
    considered equivalent and includes any differences found.

    Args:
        first_result_set: The first ResultSet to compare.
        second_result_set: The second ResultSet to compare.
        custom_templates_directory: Optional directory path for custom query templates used in validation.

    Returns:
        ValidationResult: The result of the comparison, including whether the result sets are equivalent and any differences found.

    """
    try:
        validator = ResultSetValidator(
            custom_templates_directory=custom_templates_directory
        )
        differences_data: pd.DataFrame = validator.cell_level_validation(
            first_result_set=first_result_set,
            second_result_set=second_result_set,
        )

        validation_result = ValidationResult(
            is_valid=True,
            results_dataframe=differences_data,
        )

        return validation_result

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=Platform.RESULT_SET.value,
            object_name="Result set cell level comparison",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


# =============================================================================
# UTILS FUNCTIONS
# =============================================================================


def extract_row_count(query_result: QueryExecutionResult) -> int:
    """Extract row count from a row count query result.

    This function extracts the row count value from the result of
    executing a row count query generated by generate_row_count_query.

    Args:
        query_result: The result from execute_query containing row count.

    Returns:
        int: The row count value, or 0 if not found.

    """
    df = query_result.dataframe
    if df.empty:
        return 0

    if ROW_COUNT_KEY in df.columns:
        return int(df.iloc[0][ROW_COUNT_KEY])

    first_row = df.iloc[0]
    for value in first_row:
        try:
            return int(value)
        except (ValueError, TypeError):
            continue

    return 0


def process_table_column_metadata(
    query_result: QueryExecutionResult,
    row_count: int,
    datatypes_mappings: dict[str, str],
    column_selection_list: list[str],
) -> TableColumnMetadata:
    """Process column metadata query results into a structured format.

    This function converts the raw DataFrame from execute_query into a
    structured TableColumnMetadata with column information.

    Args:
        query_result: The result from execute_query containing column metadata.
        row_count: The row count of the table, used for context in the metadata result.
        datatypes_mappings: A mapping of data types to determine if they are supported.
        column_selection_list: The list of columns that were selected for validation.

    Returns:
        TableColumnMetadata: Structured column metadata information.

    """
    table_column_metadata_from_source_df = query_result.dataframe
    table_column_metadata_from_source_df[IS_DATA_TYPE_SUPPORTED_KEY] = (
        table_column_metadata_from_source_df[COLUMN_DATATYPE].apply(
            lambda datatype_key: datatype_key in datatypes_mappings
        )
    )

    table_column_metadata_from_source_df[ROW_COUNT_KEY] = row_count

    table_column_metadata_model = TableColumnMetadata(
        table_column_metadata_df=table_column_metadata_from_source_df,
        column_selection_list=column_selection_list,
    )

    return table_column_metadata_model


def process_target_table_column_metadata_from_source_table(
    table_column_metadata_from_source_df: pd.DataFrame,
    table_configuration: TableConfiguration,
    datatypes_mappings: dict[str, str],
    row_count: int,
    case_sensitive_columns_df: pd.DataFrame,
) -> TableColumnMetadata:
    """Transform source column metadata to expected target metadata.

    This function takes source metadata and transforms it to represent the
    expected target table structure. It handles:
    - Updating database, schema, and table names
    - Mapping column names (source -> target)
    - Mapping data types (source type -> target type)

    Args:
        table_column_metadata_from_source_df: DataFrame with source column metadata.
        table_configuration: The table configuration containing target info and mappings.
        datatypes_mappings: A mapping of source data types to target data types.
        row_count: The row count of the target table, used for context in the metadata result.
        case_sensitive_columns_df: DataFrame containing case-sensitive column names from Snowflake.

    Returns:
        TableColumnMetadata: The transformed column metadata representing the expected target structure.

    """
    try:
        local_df: pd.DataFrame = table_column_metadata_from_source_df.copy()
        local_df[DATABASE_NAME_KEY] = table_configuration.target_database
        local_df[SCHEMA_NAME_KEY] = table_configuration.target_schema
        local_df[TABLE_NAME_KEY] = table_configuration.internal_target_name
        local_df[IS_DATA_TYPE_SUPPORTED_KEY] = local_df[COLUMN_DATATYPE].apply(
            lambda datatype_key: datatype_key in datatypes_mappings
        )
        local_df[COLUMN_DATATYPE] = local_df.apply(
            lambda row: datatypes_mappings[row[COLUMN_DATATYPE]],
            axis=1,
        )

        # Create case-sensitive dictionary if available, otherwise use empty dict
        case_sensitive_dict = {}
        if (
            case_sensitive_columns_df is not None
            and not case_sensitive_columns_df.empty
        ):
            # Handle both uppercase and lowercase column names
            column_name_key = "COLUMN_NAME"

            case_sensitive_dict = dict(
                zip(
                    case_sensitive_columns_df[column_name_key].str.upper(),
                    case_sensitive_columns_df[column_name_key],
                    strict=False,
                )
            )
        # Apply column name mappings with unified logic
        local_df[COLUMN_NAME_KEY] = get_target_cols(
            table_configuration, case_sensitive_dict, local_df[COLUMN_NAME_KEY]
        )
        local_df[ROW_COUNT_KEY] = row_count

        column_selection_list = None
        if table_configuration.column_selection_list:
            column_selection_list = table_configuration.column_selection_list.copy()
            # Apply column mappings to convert source column names to target column names
            column_selection_list = get_target_cols(
                table_configuration, case_sensitive_dict, column_selection_list
            )
        table_column_metadata_model: TableColumnMetadata = TableColumnMetadata(
            local_df, column_selection_list=column_selection_list
        )
        return table_column_metadata_model

    except Exception as e:
        raise ValueError("Failed to generate target table column metadata model") from e


def normalize_table_column_metadata(
    platform: Platform,
    database: str,
    schema: str,
    table: str,
    object_type: ObjectType,
    metadata: QueryExecutionResult,
) -> QueryExecutionResult:
    """Normalize table column metadata from HELP COLUMN result for simple metrics validation.

    Args:
        platform: The source platform.
        database: The database name.
        schema: The schema name.
        table: The table name.
        object_type: The type of the database object (e.g., TABLE, VIEW).
        metadata: The query execution result containing metadata DataFrame.

    Returns:
        QueryExecutionResult: Normalized query execution result.

    """
    if platform == Platform.TERADATA and object_type == ObjectType.VIEW:
        df = teradata_normalize_table_column_metadata(
            database=schema, table=table, metadata_df=metadata.dataframe
        )
        metadata = QueryExecutionResult(dataframe=df)

    return metadata


def normalize_table_metadata(
    platform: Platform,
    metadata: QueryExecutionResult,
) -> QueryExecutionResult:
    """Normalize table metadata from HELP COLUMN result for simple schema validation.

    Args:
        platform: The source platform.
        metadata: The query execution result containing metadata DataFrame.

    Returns:
        QueryExecutionResult: Normalized query execution result.

    """
    if platform == Platform.TERADATA:
        df = teradata_normalize_table_metadata(
            metadata_df=metadata.dataframe,
        )
        metadata = QueryExecutionResult(dataframe=df)

    return metadata


# =============================================================================
# ASYNC MODE: SCRIPT WRITING FUNCTIONS
# =============================================================================


def write_view_materialization_query_to_script(
    generated_query: GeneratedQuery,
    output_directory: str,
    origin: str,
    platform: str,
    timestamp: str,
    filename_template: str = "{origin}_{platform}_create_temporary_table_from_view_{timestamp}.sql",
) -> str:
    """Write a view materialization query to a script file.

    This is a convenience function for writing view materialization queries
    (CREATE TABLE AS SELECT from view) to script files in async mode.

    Args:
        generated_query: The generated view materialization query.
        output_directory: The directory to write the script file.
        origin: The origin identifier (e.g., "source", "target").
        platform: The platform name (e.g., "snowflake", "sqlserver").
        timestamp: The timestamp string for the run.
        filename_template: Template for the output filename.
            Defaults to "{origin}_{platform}_create_temporary_table_from_view_{timestamp}.sql".

    Returns:
        str: The full path to the written script file.

    Raises:
        DataValidationExceptionError: If writing fails.

    """
    file_path = _build_script_file_path(
        base_directory=output_directory,
        filename_template=filename_template,
        origin=origin,
        platform=platform,
        timestamp=timestamp,
    )

    _write_query_to_script(generated_query, file_path)
    return file_path


def write_schema_query_to_script(
    table_context: TableContext,
    generated_query: GeneratedQuery,
    output_directory: str,
    timestamp: str,
    filename_template: str = "{origin}_{platform}_table_metadata_{timestamp}.sql",
) -> str:
    """Generate and write a schema validation query to a script file.

    This is a convenience function that combines query generation and
    script writing for schema validation in async mode.

    Args:
        table_context: The table context containing table metadata.
        generated_query: The generated schema validation query.
        output_directory: The directory to write the script file.
        timestamp: The timestamp string for the run.
        filename_template: Template for the output filename.
            Defaults to "{origin}_{platform}_table_metadata_{timestamp}.sql".

    Returns:
        str: The full path to the written script file.

    Raises:
        DataValidationExceptionError: If generation or writing fails.

    """
    file_path = _build_script_file_path(
        base_directory=output_directory,
        filename_template=filename_template,
        origin=table_context.origin.value,
        platform=table_context.platform.value,
        timestamp=timestamp,
    )

    _write_query_to_script(generated_query, file_path)
    return file_path


def write_metrics_query_to_script(
    table_context: TableContext,
    generated_query: GeneratedQuery,
    output_directory: str,
    timestamp: str,
    filename_template: str = "{origin}_{platform}_column_metadata_{timestamp}.sql",
) -> str:
    """Generate and write a metrics validation query to a script file.

    This is a convenience function that combines query generation and
    script writing for metrics validation in async mode.

    Args:
        table_context: The table context containing table metadata.
        generated_query: The generated metrics validation query.
        output_directory: The directory to write the script file.
        timestamp: The timestamp string for the run.
        filename_template: Template for the output filename.
            Defaults to "{origin}_{platform}_column_metadata_{timestamp}.sql".

    Returns:
        str: The full path to the written script file.

    Raises:
        DataValidationExceptionError: If generation or writing fails.

    """
    file_path = _build_script_file_path(
        base_directory=output_directory,
        filename_template=filename_template,
        origin=table_context.origin.value,
        platform=table_context.platform.value,
        timestamp=timestamp,
    )

    _write_query_to_script(generated_query, file_path)
    return file_path


# =============================================================================
# ASYNC MODE: FILE LOADING FUNCTIONS
# =============================================================================


def load_validation_result_from_file(
    file_path: str,
) -> QueryExecutionResult:
    """Load validation data from a file into a QueryExecutionResult.

    This function reads validation data from a CSV or Parquet file and
    returns it as a QueryExecutionResult. Used in async execution mode
    to load pre-computed validation data for comparison.

    Args:
        file_path: The path to the validation data file (.csv or .parquet).

    Returns:
        QueryExecutionResult: The loaded data wrapped in a result object.

    Raises:
        DataValidationExceptionError: If file loading fails or format is unsupported.

    """
    import os

    try:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Validation file not found: {file_path}")

        if file_path.endswith(".csv"):
            dataframe = pd.read_csv(file_path)
        elif file_path.endswith(".parquet"):
            dataframe = pd.read_parquet(file_path)
        else:
            raise ValueError(
                f"Unsupported file format. Expected .csv or .parquet: {file_path}"
            )

        return QueryExecutionResult(dataframe=dataframe)

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to load validation file: {str(e)}",
            platform="",
            object_name=file_path,
            object_id="",
        ) from e


def load_validation_results(
    source_file_path: str,
    target_file_path: str,
) -> tuple[QueryExecutionResult, QueryExecutionResult]:
    """Load validation data from source and target files.

    This is a convenience function that loads both source and target
    validation data files in a single call. Used in async execution mode
    for validation comparison.

    Args:
        source_file_path: Path to the source validation data file.
        target_file_path: Path to the target validation data file.

    Returns:
        tuple[QueryExecutionResult, QueryExecutionResult]: A tuple containing
            (source_result, target_result).

    Raises:
        DataValidationExceptionError: If either file fails to load.

    """
    source_result = load_validation_result_from_file(source_file_path)
    target_result = load_validation_result_from_file(target_file_path)
    return source_result, target_result


def build_validation_file_path(
    base_directory: str,
    validation_type: str,
    table_context: TableContext,
    custom_filename: str | None = None,
) -> str:
    """Build the file path for a validation data file.

    This function constructs the full file path for loading validation
    data files, using either a custom filename or the default naming
    convention based on the table's fully qualified name.

    Args:
        base_directory: The base directory containing validation files.
        validation_type: The type of validation (e.g., "schema", "metrics").
        table_context: The table context containing table metadata.
        custom_filename: Optional custom filename. If not provided,
            uses "{fully_qualified_name}.csv".

    Returns:
        str: The full file path.

    """
    import os

    if custom_filename:
        filename = custom_filename
    else:
        filename = f"{table_context.fully_qualified_name}.csv"

    return os.path.join(base_directory, validation_type, filename)


# =============================================================================
# CLI COMMANDS
# =============================================================================


def get_configuration_file(
    templates_directory: str,
    include_query_templates: bool,
    platform: Platform,
) -> None:
    """Export configuration template files to a specified directory.

    This function dumps the YAML configuration templates and optionally
    the Jinja2 query templates for a specific platform to the specified
    directory. These templates can be customized and used for validation.

    Args:
        templates_directory: The directory path where templates will be written.
            Must exist and be writable.
        include_query_templates: If True, includes Jinja2 (.j2) query template
            files in addition to YAML configuration templates.
        platform: The source platform for which to export templates
            (e.g., Platform.SNOWFLAKE, Platform.SQLSERVER).

    Raises:
        DataValidationExceptionError: If the directory doesn't exist, is not
            writable, or if template export fails.

    Example:
        >>> from snowflake.snowflake_data_validation.public import (
        ...     get_configuration_file,
        ...     Platform,
        ... )
        >>> get_configuration_file(
        ...     templates_directory="/path/to/templates",
        ...     include_query_templates=True,
        ...     platform=Platform.SQLSERVER,
        ... )

    """
    try:
        templates_directory_path = Path(templates_directory)
        if not templates_directory_path.is_dir():
            raise ValueError(
                f"Templates directory '{templates_directory}' does not exist or is not a valid directory."
            )

        if os.access(templates_directory, os.W_OK) is False:
            raise PermissionError(
                f"Templates directory '{templates_directory}' is not writable. Please check permissions."
            )

        args_manager = ArgumentsManagerFactory.create(platform)
        args_manager.dump_and_write_yaml_templates(
            source=platform.value,
            templates_directory=templates_directory,
            query_templates=include_query_templates,
        )

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="get configuration file",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def run_validation(
    platform: Platform,
    data_validation_config_file: str,
) -> None:
    """
    Run data validation process based on a configuration file.

    Args:
        platform: The source platform for which to run validation
            (e.g., Platform.SNOWFLAKE, Platform.SQLSERVER).
        data_validation_config_file: The path to the data validation configuration file.

    Raises:
        DataValidationExceptionError: If the configuration file is invalid or
            if validation fails.

    """
    try:
        data_validation_config_file_path = Path(data_validation_config_file)
        if not data_validation_config_file_path.is_file():
            raise ValueError(
                f"Data validation configuration file '{data_validation_config_file}' does not exist or is not a valid file."
            )

        config_loader = ConfigurationLoader(file_path=data_validation_config_file_path)
        config_model = config_loader.get_configuration_model()

        validation_env = create_validation_environment_from_config(
            config_model=config_model,
            data_validation_config_file=data_validation_config_file,
            execution_mode=ExecutionMode.SYNC_VALIDATION,
            output_handler=ConsoleOutputHandler(enable_console_output=False),
        )

        # Lazy import to avoid circular dependency
        from snowflake.snowflake_data_validation.comparison_orchestrator import (
            ComparisonOrchestrator,
        )

        orchestrator = ComparisonOrchestrator.from_validation_environment(
            validation_env=validation_env  # type: ignore
        )

        orchestrator.run_sync_comparison()

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="run validation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def run_async_generation(
    platform: Platform,
    data_validation_config_file: str,
) -> None:
    """
    Run asynchronous generation of validation data based on a configuration file.

    Args:
        platform: The source platform for which to run async generation
            (e.g., Platform.SNOWFLAKE, Platform.SQLSERVER).
        data_validation_config_file: The path to the data validation configuration file.

    Raises:
        DataValidationExceptionError: If the configuration file is invalid or
            if async generation fails.

    """
    try:
        data_validation_config_file_path = Path(data_validation_config_file)
        config_loader = ConfigurationLoader(file_path=data_validation_config_file_path)
        config_model = config_loader.get_configuration_model()

        validation_env = create_validation_environment_from_config(
            config_model=config_model,
            data_validation_config_file=data_validation_config_file,
            execution_mode=ExecutionMode.ASYNC_GENERATION,
            output_handler=ConsoleOutputHandler(enable_console_output=False),
        )

        # Lazy import to avoid circular dependency
        from snowflake.snowflake_data_validation.comparison_orchestrator import (
            ComparisonOrchestrator,
        )

        orchestrator = ComparisonOrchestrator.from_validation_environment(
            validation_env=validation_env  # type: ignore
        )

        orchestrator.run_async_generation()

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="run async generation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def run_async_validation(
    platform: Platform,
    data_validation_config_file: str,
) -> None:
    """
    Run asynchronous validation process based on a configuration file.

    Args:
        platform: The source platform for which to run async validation
            (e.g., Platform.SNOWFLAKE, Platform.SQLSERVER).
        data_validation_config_file: The path to the data validation configuration file.

    Raises:
        DataValidationExceptionError: If the configuration file is invalid or
            if async validation fails.

    """
    try:
        data_validation_config_file_path = Path(data_validation_config_file)
        config_loader = ConfigurationLoader(file_path=data_validation_config_file_path)
        config_model = config_loader.get_configuration_model()

        validation_env = create_validation_environment_from_config(
            config_model=config_model,
            data_validation_config_file=data_validation_config_file,
            execution_mode=ExecutionMode.ASYNC_VALIDATION,
            output_handler=ConsoleOutputHandler(enable_console_output=False),
        )

        # Lazy import to avoid circular dependency
        from snowflake.snowflake_data_validation.comparison_orchestrator import (
            ComparisonOrchestrator,
        )

        orchestrator = ComparisonOrchestrator.from_validation_environment(
            validation_env=validation_env  # type: ignore
        )

        orchestrator.run_async_comparison()

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="run async validation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e


def run_source_validation(
    platform: Platform,
    data_validation_config_file: str,
) -> None:
    """
    Run source validation process based on a configuration file.

    Args:
        platform: The source platform for which to run source validation
            (e.g., Platform.SNOWFLAKE, Platform.SQLSERVER).
        data_validation_config_file: The path to the data validation configuration file.

    Raises:
        DataValidationExceptionError: If the configuration file is invalid or
            if source validation fails.

    """
    try:
        data_validation_config_file_path = Path(data_validation_config_file)
        config_loader = ConfigurationLoader(file_path=data_validation_config_file_path)
        config_model = config_loader.get_configuration_model()

        validation_env = create_validation_environment_from_config(
            config_model=config_model,
            data_validation_config_file=data_validation_config_file,
            execution_mode=ExecutionMode.SOURCE_VALIDATION,
            output_handler=ConsoleOutputHandler(enable_console_output=False),
        )

        # Lazy import to avoid circular dependency
        from snowflake.snowflake_data_validation.comparison_orchestrator import (
            ComparisonOrchestrator,
        )

        orchestrator = ComparisonOrchestrator.from_validation_environment(
            validation_env=validation_env  # type: ignore
        )

        orchestrator.run_source_validation()

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name="run source validation",
            object_id=DEFAULT_OBJECT_ID,
        ) from e
