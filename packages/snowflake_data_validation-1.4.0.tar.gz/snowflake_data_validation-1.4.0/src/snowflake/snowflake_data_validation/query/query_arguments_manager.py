# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

from snowflake.snowflake_data_validation.configuration.model.configuration_model import (
    ConfigurationModel,
)
from snowflake.snowflake_data_validation.utils.arguments_manager_base import (
    ArgumentsManagerBase,
    ValidationEnvironmentObject,
)
from snowflake.snowflake_data_validation.utils.console_output_handler import (
    ConsoleOutputHandler,
)
from snowflake.snowflake_data_validation.utils.constants import (
    ExecutionMode,
    Platform,
)


class QueryArgumentsManager(ArgumentsManagerBase):
    """Arguments manager for Query validation.

    This manager is primarily used for exporting Query templates.
    Query validation does not use database connections, so the
    create_validation_environment_from_config method is not supported.

    Note: Query validation uses the same underlying templates as Result Set
    validation since both operate on DataFrames. The datatype mapping templates
    are excluded as they are not applicable to query validation.
    """

    def __init__(self):
        """Initialize the Query arguments manager."""
        super().__init__(Platform.QUERY, Platform.QUERY)

    @property
    def is_snowflake_to_snowflake(self) -> bool:
        """Check if this is a Snowflake-to-Snowflake validation scenario.

        Returns:
            bool: False - Query validation is not Snowflake-to-Snowflake

        """
        return False

    def create_validation_environment_from_config(
        self,
        config_model: ConfigurationModel,
        data_validation_config_file: str,
        execution_mode: ExecutionMode,
        output_handler: ConsoleOutputHandler | None = None,
    ) -> ValidationEnvironmentObject:
        """Not supported for Query validation.

        Query validation does not use database connections and therefore
        does not support creating a validation environment from configuration.

        Raises:
            NotImplementedError: Always raised as this operation is not supported.

        """
        raise NotImplementedError(
            "Query validation does not support creating validation environments "
            "from configuration. Use query_cell_level_validation or "
            "query_metrics_level_validation API functions instead."
        )

    def get_source_templates_path(self) -> str:
        """Get Query templates path.

        Returns the path to the query templates directory.
        """
        current_dir = os.path.dirname(__file__)
        return os.path.join(current_dir, "extractor", "templates")

    def get_target_templates_path(self) -> str:
        """Get Query target templates path (same as source)."""
        return self.get_source_templates_path()
