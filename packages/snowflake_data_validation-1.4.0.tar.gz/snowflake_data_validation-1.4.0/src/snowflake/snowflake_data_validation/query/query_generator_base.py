# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.extractor.sql_queries_template_generator import (
    SQLQueriesTemplateGenerator,
)
from snowflake.snowflake_data_validation.utils.constants import NEWLINE, Platform
from snowflake.snowflake_data_validation.utils.helpers.helper_database import (
    HelperDatabase,
)
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext


class QueryGeneratorBase(ABC):
    """Abstract base class for query generation.

    This class defines the interface for generating database queries that are
    used by both MetadataExtractorBase and ScriptWriterBase implementations.
    """

    def __init__(self, platform: Platform):
        """Initialize the query generator with a platform.

        Args:
            platform (Platform): The platform enum value.

        """
        self.platform = platform

    def generate_schema_query(self, table_context: TableContext) -> str:
        """Generate the SQL query to extract metadata for a specific table.

        This template method provides the common workflow for generating schema queries.
        Platform-specific implementations can override hook methods for customization.

        Args:
            table_context (TableContext): Configuration object containing table properties.

        Returns:
            str: SQL query string to extract metadata for the specified table.

        """
        normalized_database = HelperDatabase.normalize_identifier(
            identifier=table_context.database_name
        )

        normalized_schema = HelperDatabase.normalize_identifier(
            identifier=table_context.schema_name
        )

        normalized_table_name = HelperDatabase.normalize_identifier(
            identifier=table_context.internal_table_name
        )

        query = table_context.sql_generator.generate_table_metadata_sql(
            platform=self.platform.value,
            table_name=normalized_table_name,
            schema_name=normalized_schema,
            database_name=normalized_database,
            fully_qualified_name=table_context.fully_qualified_name,
            where_clause=table_context.where_clause,
            has_where_clause=table_context.has_where_clause,
            column_selection_list=table_context.columns_to_validate,
            is_temporary_table=table_context.is_temporary_table,
        )

        return query

    def generate_metrics_query(self, table_context: TableContext) -> str:
        """Generate the SQL query to extract metadata for specific columns in a table.

        This template method provides the common workflow for generating CTE-based metrics queries.
        Platform-specific implementations must implement the abstract CTE generation methods.

        Args:
            table_context (TableContext): Configuration object containing table properties.

        Returns:
            str: SQL query string to extract column metadata for the specified columns.

        """
        cte_queries = []
        cte_names = []
        metrics = []

        for col in table_context.columns_to_validate:
            col_type = col.data_type

            # Apply Snowflake-specific TEXT -> VARCHAR transformation
            if self.platform == Platform.SNOWFLAKE and col_type == "TEXT":
                col_type = "VARCHAR"

            cte_query, cte_name, metric_list = self.cte_query_generator(
                metrics_templates=table_context.templates_loader_manager.metrics_templates,
                col_name=col.name,
                col_type=col_type,
                fully_qualified_name=table_context.fully_qualified_name,
                where_clause=table_context.where_clause,
                has_where_clause=table_context.has_where_clause,
                sql_generator=table_context.sql_generator,
                exclude_metrics=table_context.exclude_metrics,
                apply_metric_column_modifier=table_context.apply_metric_column_modifier,
            )
            if cte_query is None:
                continue
            cte_queries.append(cte_query)
            cte_names.append(cte_name)
            metrics.append(metric_list)

        if not cte_queries:
            error_message = (
                f"Metrics templates are missing for the column data types in "
                f"{table_context.fully_qualified_name}."
            )
            raise Exception(error_message)

        outer_query = self.outer_query_generator(cte_names, metrics)
        final_query = "WITH " + ", ".join(cte_queries) + NEWLINE + outer_query
        return final_query

    def generate_cell_validation_data_query(
        self,
        table_context: TableContext,
        order_by_columns: list[str] | None = None,
    ) -> str:
        """SELECT table data for cell comparison without SQL-side normalization.

        Platforms that share MD5 datatype templates (Teradata, Snowflake) override
        this to emit TRIM/TO_CHAR-normalized expressions matching row validation.
        """
        cols = table_context.join_column_names_with_commas()
        select_list = cols if cols else "*"
        query = f"SELECT {select_list} FROM {table_context.fully_qualified_name}"
        if table_context.has_where_clause:
            query += f" WHERE {table_context.where_clause}"
        if order_by_columns:
            ob = ", ".join(f'"{c}"' for c in order_by_columns)
            query += f" ORDER BY {ob}"
        return query

    def generate_compute_md5_query(
        self, table_context: TableContext, other_table_name: str
    ) -> str | list[str]:
        """Generate the SQL query to compute MD5 for a chunk of a table.

        Args:
            table_context (TableContext): Configuration object containing table properties.
            other_table_name (str): The name of the other table to compute MD5 for.

        Returns:
            Union[str, list[str]]: SQL query string or a list of SQL query strings to extract MD5 checksum information.

        """
        queries = []
        chunk_collection = table_context.get_chunk_collection()

        for chunk in chunk_collection:

            chunk_id = table_context.get_chunk_id(other_table_name=other_table_name)
            chunk_queries = self._generate_compute_md5_chunk_query(
                table_context=table_context,
                chunk_id=chunk_id,
                fetch=chunk.fetch,
                offset=chunk.offset,
            )
            if isinstance(chunk_queries, str):
                queries.append(chunk_queries)
            else:
                queries.extend(chunk_queries)

        return queries

    def generate_table_row_count_query(
        self,
        fully_qualified_name: str,
        where_clause: str,
        has_where_clause: bool,
        platform: Platform,
        sql_generator: SQLQueriesTemplateGenerator,
    ) -> str:
        """Generate the SQL query to extract the row count for a table.

        Args:
            fully_qualified_name (str): The fully qualified name of the table.
            where_clause (str): The WHERE clause to filter the rows.
            has_where_clause (bool): Flag indicating if the WHERE clause is present.
            platform (Platform): The platform for which the query is being generated.
            sql_generator (SQLQueriesTemplateGenerator): The SQL template generator instance.

        Returns:
            str: SQL query string to extract the row count for the specified table.

        """
        query = sql_generator.generate_table_row_count_query(
            fully_qualified_name=fully_qualified_name,
            where_clause=where_clause,
            has_where_clause=has_where_clause,
            platform=platform.value,
        )

        return query

    def generate_temporary_table_from_view_query(
        self,
        fully_qualified_temporary_table_name: str,
        fully_qualified_view_name: str,
        platform: Platform,
        sql_generator: SQLQueriesTemplateGenerator,
    ) -> str:
        """Generate the SQL query to create a temporary table from a view.

        Args:
            fully_qualified_temporary_table_name (str): The fully qualified name of the temporary table.
            fully_qualified_view_name (str): The fully qualified name of the view.
            platform (Platform): The platform for which the query is being generated.
            sql_generator (SQLQueriesTemplateGenerator): The SQL template generator instance.

        Returns:
            str: SQL query string to create a temporary table from the specified view.

        """
        query = sql_generator.generate_temporary_table_from_view_query(
            fully_qualified_temporary_table_name=fully_qualified_temporary_table_name,
            fully_qualified_view_name=fully_qualified_view_name,
            platform=platform.value,
        )

        return query

    @abstractmethod
    def _generate_compute_md5_chunk_query(
        self, table_context: TableContext, chunk_id: str, fetch: int, offset: int
    ) -> str | list[str]:
        """Generate the SQL query to compute MD5 for a chunk of a table.

        Args:
            table_context (TableContext): Configuration object containing table properties.
            chunk_id (str): The ID of the chunk to compute MD5 for.
            fetch (int): The maximum number of rows to process in this chunk.
            offset (int): The starting row number for this chunk.

        Returns:
            Union[str, list[str]]: SQL query string or a list of SQL query strings to extract MD5 checksum information.

        """
        pass

    def generate_table_column_metadata_query(
        self,
        table_configuration: TableConfiguration,
        sql_generator: SQLQueriesTemplateGenerator,
    ) -> str:
        """Generate the SQL query to extract column information metadata for a given table.

        This template method provides the common workflow for generating table column metadata queries.

        Args:
            table_configuration (TableConfiguration): Configuration object containing table properties.
            sql_generator (SQLQueriesTemplateGenerator): The SQL template generator instance.

        Returns:
            str: SQL query string to extract column information metadata.

        """
        local_database = HelperDatabase.normalize_identifier(
            identifier=table_configuration.source_database
        )
        local_schema = HelperDatabase.normalize_identifier(
            identifier=table_configuration.source_schema
        )
        local_name = HelperDatabase.normalize_identifier(
            identifier=table_configuration.internal_source_table
        )

        query = sql_generator.extract_table_column_metadata(
            database_name=local_database,
            schema_name=local_schema,
            table_name=local_name,
            platform=self.platform.value,
            is_temporary_table=table_configuration.is_temporary_table,
        )

        return query

    @abstractmethod
    def generate_statement_table_chunks_md5(self, table_context: TableContext) -> str:
        """Generate the DDL statement to create a table for storing MD5 checksums of data chunks.

        Args:
            table_context (TableContext): Configuration object containing table properties.

        Returns:
            str: SQL query string to create a table for storing MD5 checksums of data chunks.

        """
        pass

    @abstractmethod
    def generate_extract_chunks_md5_query(self, table_context: TableContext) -> str:
        """Generate the SQL query to extract MD5 for all chunks of a table.

        Args:
            table_context (TableContext): Configuration object containing table properties.

        Returns:
            str: SQL query string to extract MD5 for all chunks of a table.

        """
        pass

    @abstractmethod
    def generate_extract_md5_rows_chunk_query(
        self, chunk_id: str, table_context: TableContext
    ) -> str:
        """Generate the SQL query to extract the MD5 rows for a specific chunk of a table.

        Args:
            chunk_id (str): The unique identifier for the chunk.
            table_context (TableContext): Configuration object containing table properties.

        Returns:
            str: SQL query string to extract the MD5 rows for the specified chunk.

        """
        pass

    @abstractmethod
    def cte_query_generator(
        self,
        metrics_templates,
        col_name: str,
        col_type: str,
        fully_qualified_name: str,
        where_clause: str,
        has_where_clause: bool,
        sql_generator,
        exclude_metrics: bool,
        apply_metric_column_modifier: bool,
    ) -> tuple[str, str, list[str]] | tuple[None, None, None]:
        """Generate a CTE query for a specific column.

        This method delegates to the platform-specific CTE generator.

        Args:
            metrics_templates: DataFrame containing metrics templates.
            col_name (str): Column name.
            col_type (str): Column data type.
            fully_qualified_name (str): Fully qualified table name.
            where_clause (str): WHERE clause.
            has_where_clause (bool): Whether WHERE clause is present.
            sql_generator: SQL template generator instance.
            exclude_metrics (bool): If True, excludes certain metrics from the CTE query.
            apply_metric_column_modifier (bool): Whether to apply metric column modifier.

        Returns:
            Tuple containing CTE query, CTE name, and metrics list, or (None, None, None) if no query generated.

        """
        pass

    @abstractmethod
    def outer_query_generator(self, cte_names, metrics) -> str:
        """Generate an outer query combining CTEs.

        This method delegates to the platform-specific outer query generator.

        Args:
            cte_names: List of CTE names.
            metrics: List of metrics for each CTE.

        Returns:
            str: Generated outer query.

        """
        pass
