import pandas as pd
import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    result_set_cell_level_validation,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.public.model.result_set import ResultSet
from snowflake.snowflake_data_validation.utils.constants import (
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_ROW_KEY,
    DIFF_COL_SOURCE_VALUE_KEY,
    DIFF_COL_TARGET_VALUE_KEY,
)


def test_result_set_cell_level_validation_with_matching_data():
    result_set_data = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_result_set_cell_level_validation_with_unmatching_data():
    result_set_data_1 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 25, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 50, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )
    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 2

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "QTY"
    assert result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY] == "10.0"
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "25.0"

    assert result.results_dataframe.iloc[1][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[1][DIFF_COL_COLUMN_KEY] == "QTY"
    assert result.results_dataframe.iloc[1][DIFF_COL_SOURCE_VALUE_KEY] == "20.0"
    assert result.results_dataframe.iloc[1][DIFF_COL_TARGET_VALUE_KEY] == "50.0"


def test_result_set_cell_level_validation_with_null_data_matching():
    result_set_data = [
        {"ID": 1, "QTY": None, "NAME": "Device A", "UPDATED_AT": None},
        {"ID": None, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_result_set_cell_level_validation_with_null_data_mismatching():
    result_set_data_1 = [
        {"ID": 1, "QTY": None, "NAME": "Device A", "UPDATED_AT": None},
        {"ID": None, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "ID"
    assert pd.isna(result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "2"

    assert result.results_dataframe.iloc[1][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[1][DIFF_COL_COLUMN_KEY] == "QTY"
    assert pd.isna(result.results_dataframe.iloc[1][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[1][DIFF_COL_TARGET_VALUE_KEY] == "10"

    assert result.results_dataframe.iloc[2][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[2][DIFF_COL_COLUMN_KEY] == "UPDATED_AT"
    assert pd.isna(result.results_dataframe.iloc[2][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[2][DIFF_COL_TARGET_VALUE_KEY] == "2026-01-01"


def test_result_set_cell_level_validation_with_null_data_mismatching():
    result_set_data_1 = [
        {"ID": 1, "QTY": None, "NAME": "Device A", "UPDATED_AT": None},
        {"ID": None, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "ID"
    assert pd.isna(result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "2.0"

    assert result.results_dataframe.iloc[1][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[1][DIFF_COL_COLUMN_KEY] == "QTY"
    assert pd.isna(result.results_dataframe.iloc[1][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[1][DIFF_COL_TARGET_VALUE_KEY] == "10.0"

    assert result.results_dataframe.iloc[2][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[2][DIFF_COL_COLUMN_KEY] == "UPDATED_AT"
    assert pd.isna(result.results_dataframe.iloc[2][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[2][DIFF_COL_TARGET_VALUE_KEY] == "2026-01-01"


def test_result_set_cell_level_validation_with_different_row_counts():
    result_set_data_1 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
        {"ID": 3, "QTY": 30, "NAME": "Device C", "UPDATED_AT": "2026-01-03"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    with pytest.raises(DataValidationExceptionError) as exc_info:
        result_set_cell_level_validation(
            result_set_1,
            result_set_2,
        )

    assert (
        str(exc_info.value)
        == "[result_set] failed for object: Result set cell level comparison (ID: 1). Error: Dataframe dimensions mismatch."
    )


def test_result_set_cell_level_validation_with_different_column_counts():
    result_set_data_1 = [
        {"ID": 1, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_1_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_2_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_1_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_2_column_types
    )

    with pytest.raises(DataValidationExceptionError) as exc_info:
        result_set_cell_level_validation(
            result_set_1,
            result_set_2,
        )

    assert (
        str(exc_info.value)
        == "[result_set] failed for object: Result set cell level comparison (ID: 1). Error: Dataframe dimensions mismatch."
    )


def test_result_set_cell_level_validation_with_empty_result_sets():
    result_set_data = [{}]

    result_set_column_types = {}

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_cell_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True
