# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd
import pytest
import polars as pl

from snowflake.snowflake_data_validation.validation.cell_data_validator import (
    CellDataValidator,
)
from snowflake.snowflake_data_validation.utils.constants import (
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_ROW_KEY,
)


def test_validate_cell_comparison_identical_dataframes():
    """Test that identical DataFrames return an empty result."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    target_df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})

    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert result.empty


def test_validate_cell_comparison_detects_differences():
    """Test that CellDataValidator detects cell-level differences."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    target_df = pl.DataFrame({"A": [1, 99, 3], "B": ["x", "y", "changed"]})

    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert len(result) == 2

    columns_with_diff = result[DIFF_COL_COLUMN_KEY].tolist()
    assert "A" in columns_with_diff
    assert "B" in columns_with_diff

    row_indices = result[DIFF_COL_ROW_KEY].tolist()
    assert 1 in row_indices
    assert 2 in row_indices


def test_validate_cell_comparison_shape_mismatch():
    """Test that mismatched DataFrame shapes raise an exception."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    target_df = pl.DataFrame({"A": [1, 2], "B": ["x", "y"]})

    with pytest.raises(Exception, match="Dataframe dimensions mismatch"):
        validator.validate_cell_comparison(
            object_name="test_table",
            source_df=source_df,
            target_df=target_df,
        )


def test_validate_cell_comparison_large_dataframe():
    """Test that CellDataValidator handles larger DataFrames correctly."""
    validator = CellDataValidator()

    num_rows = 1000
    source_df = pl.DataFrame(
        {
            "col_a": list(range(num_rows)),
            "col_b": [f"value_{i}" for i in range(num_rows)],
            "col_c": [i * 1.5 for i in range(num_rows)],
            "col_d": [i % 2 == 0 for i in range(num_rows)],
        }
    )

    target_data = {
        "col_a": list(range(num_rows)),
        "col_b": [f"value_{i}" for i in range(num_rows)],
        "col_c": [i * 1.5 for i in range(num_rows)],
        "col_d": [i % 2 == 0 for i in range(num_rows)],
    }
    target_data["col_a"][10] = 9999
    target_data["col_a"][500] = 8888
    target_data["col_b"][250] = "modified"
    target_data["col_c"][750] = 0.0
    target_df = pl.DataFrame(target_data)

    result = validator.validate_cell_comparison(
        object_name="large_test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert len(result) == 4

    row_indices = set(result[DIFF_COL_ROW_KEY].tolist())
    assert row_indices == {10, 250, 500, 750}

    columns_with_diff = set(result[DIFF_COL_COLUMN_KEY].tolist())
    assert columns_with_diff == {"col_a", "col_b", "col_c"}


def test_validate_cell_comparison_default_positional_with_different_column_names():
    """Test default positional comparison returns empty when values match but column names differ."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    target_df = pl.DataFrame({"X": [1, 2, 3], "Y": ["x", "y", "z"]})

    # Default is positional=True, so different column names don't matter
    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert result.empty


def test_validate_cell_comparison_default_positional_detects_differences():
    """Test default positional comparison detects differences by position."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2], "B": ["x", "y"]})
    target_df = pl.DataFrame({"X": [1, 99], "Y": ["x", "changed"]})

    # Default is positional=True
    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert len(result) == 2

    columns_with_diff = result[DIFF_COL_COLUMN_KEY].tolist()
    assert "A" in columns_with_diff
    assert "B" in columns_with_diff

    row_indices = result[DIFF_COL_ROW_KEY].tolist()
    assert 1 in row_indices


def test_validate_cell_comparison_positional_preserves_source_column_names():
    """Test that positional comparison uses source column names in the result."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"source_col": [1, 2]})
    target_df = pl.DataFrame({"target_col": [1, 99]})

    # Default is positional=True
    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert len(result) == 1
    assert result[DIFF_COL_COLUMN_KEY].tolist()[0] == "source_col"


def test_validate_cell_comparison_positional_with_reordered_columns():
    """Test positional comparison finds differences when columns are reordered."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2], "B": [10, 20]})
    target_df = pl.DataFrame({"B": [10, 20], "A": [1, 2]})

    # Default is positional=True, so reordered columns cause differences
    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
    )

    assert len(result) == 4


def test_validate_cell_comparison_name_based_with_reordered_columns():
    """Test name-based comparison matches by column name regardless of order."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2], "B": [10, 20]})
    target_df = pl.DataFrame({"B": [10, 20], "A": [1, 2]})

    # Explicitly set positional=False for name-based comparison
    result = validator.validate_cell_comparison(
        object_name="test_table",
        source_df=source_df,
        target_df=target_df,
        positional=False,
    )

    assert result.empty


# ======================================================================
# Key-based row matching tests
# ======================================================================


def test_key_matching_identical_data_returns_empty():
    """Key-based matching with identical data produces no diffs."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})
    target_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert result.empty


def test_key_matching_detects_cell_differences():
    """Key-based matching detects value differences in non-key columns."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})
    target_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "CHANGED", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) == 1
    assert result[DIFF_COL_COLUMN_KEY].tolist() == ["VAL"]
    assert "ID=2" in result[DIFF_COL_ROW_KEY].tolist()[0]


def test_key_matching_rows_missing_from_target():
    """Rows present in source but absent in target appear as diffs."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})
    target_df = pl.DataFrame({"ID": [1, 3], "VAL": ["a", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) >= 1
    row_ids = result[DIFF_COL_ROW_KEY].tolist()
    assert any("ID=2" in r for r in row_ids)


def test_key_matching_rows_missing_from_source():
    """Rows present in target but absent in source appear as diffs."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 3], "VAL": ["a", "c"]})
    target_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) >= 1
    row_ids = result[DIFF_COL_ROW_KEY].tolist()
    assert any("ID=2" in r for r in row_ids)


def test_key_matching_different_target_index_columns():
    """target_index_columns allows matching when key column names differ."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"SRC_ID": [1, 2], "VAL": ["a", "b"]})
    target_df = pl.DataFrame({"TGT_ID": [1, 2], "VAL": ["a", "CHANGED"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["SRC_ID"],
        target_index_columns=["TGT_ID"],
    )

    assert len(result) == 1
    assert result[DIFF_COL_COLUMN_KEY].tolist() == ["VAL"]
    assert "SRC_ID=2" in result[DIFF_COL_ROW_KEY].tolist()[0]


def test_key_matching_different_row_counts_no_exception():
    """Different row counts do not raise when index_columns is set."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})
    target_df = pl.DataFrame({"ID": [1, 3], "VAL": ["a", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert isinstance(result, pd.DataFrame)
    assert set(result.columns) == {"ROW", "COLUMN", "SOURCE_VALUE", "TARGET_VALUE"}
    assert len(result) >= 1
    assert any("ID=2" in r for r in result[DIFF_COL_ROW_KEY].tolist())


def test_key_matching_falls_back_to_positional_when_none():
    """When index_columns is None, positional matching is used (existing behaviour)."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"A": [1, 2], "B": ["x", "y"]})
    target_df = pl.DataFrame({"A": [1, 2], "B": ["x", "y"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=None,
    )

    assert result.empty


def test_key_matching_composite_key():
    """Key-based matching works with multiple index columns."""
    validator = CellDataValidator()

    source_df = pl.DataFrame(
        {"K1": [1, 1, 2], "K2": ["a", "b", "a"], "VAL": ["x", "y", "z"]}
    )
    target_df = pl.DataFrame(
        {"K1": [1, 1, 2], "K2": ["a", "b", "a"], "VAL": ["x", "CHANGED", "z"]}
    )

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["K1", "K2"],
    )

    assert len(result) == 1
    row_id = result[DIFF_COL_ROW_KEY].tolist()[0]
    assert "K1=1" in row_id
    assert "K2=b" in row_id


def test_key_matching_reordered_rows():
    """Key-based matching correctly pairs rows regardless of order."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [3, 1, 2], "VAL": ["c", "a", "b"]})
    target_df = pl.DataFrame({"ID": [1, 2, 3], "VAL": ["a", "b", "c"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert result.empty


def test_key_matching_empty_source():
    """Empty source with non-empty target reports all target rows as diffs."""
    validator = CellDataValidator()

    source_df = pl.DataFrame(
        {"ID": pl.Series([], dtype=pl.Int64), "VAL": pl.Series([], dtype=pl.Utf8)}
    )
    target_df = pl.DataFrame({"ID": [1, 2], "VAL": ["a", "b"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) == 2
    assert result["SOURCE_VALUE"].isna().all()


def test_key_matching_empty_target():
    """Empty target with non-empty source reports all source rows as diffs."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2], "VAL": ["a", "b"]})
    target_df = pl.DataFrame(
        {"ID": pl.Series([], dtype=pl.Int64), "VAL": pl.Series([], dtype=pl.Utf8)}
    )

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) == 2
    assert result["TARGET_VALUE"].isna().all()


def test_key_matching_both_empty():
    """Two empty DataFrames produce no diffs with key matching."""
    validator = CellDataValidator()

    source_df = pl.DataFrame(
        {"ID": pl.Series([], dtype=pl.Int64), "VAL": pl.Series([], dtype=pl.Utf8)}
    )
    target_df = pl.DataFrame(
        {"ID": pl.Series([], dtype=pl.Int64), "VAL": pl.Series([], dtype=pl.Utf8)}
    )

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert result.empty


def test_key_matching_value_columns_already_aligned():
    """No rename needed when source and target value column names already match."""
    validator = CellDataValidator()

    source_df = pl.DataFrame({"ID": [1, 2], "NAME": ["a", "b"]})
    target_df = pl.DataFrame({"ID": [1, 2], "NAME": ["a", "CHANGED"]})

    result = validator.validate_cell_comparison(
        object_name="t",
        source_df=source_df,
        target_df=target_df,
        index_columns=["ID"],
    )

    assert len(result) == 1
    assert result[DIFF_COL_COLUMN_KEY].tolist() == ["NAME"]
