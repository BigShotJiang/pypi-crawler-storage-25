# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for Snowflake CLI functions and commands."""

import logging
import pytest
from unittest.mock import Mock, patch, MagicMock, ANY
from pathlib import Path

import typer
from typer.testing import CliRunner

from snowflake.snowflake_data_validation.snowflake.snowflake_cli import (
    snowflake_app,
)
from snowflake.snowflake_data_validation.utils.constants import (
    ExecutionMode,
    COLUMN_METRICS_TEMPLATE_NAME_FORMAT,
    COLUMN_DATATYPES_NORMALIZATION_TEMPLATES_NAME_FORMAT,
    Platform,
)


class TestSnowflakeCLI:
    """Test cases for SQL Server CLI commands."""

    def setup_method(self):
        """Set up test fixtures."""
        self.runner = CliRunner()

    @patch("snowflake.snowflake_data_validation.snowflake.snowflake_cli.Path")
    def test_snowflake_get_configuration_files(self, mock_path):
        """Test snowflake_get_configuration_files command to list available configuration files."""
        # Mock the config directory
        mock_config_dir = MagicMock()
        mock_path.return_value = mock_config_dir

        # Set up mock files with different extensions
        mock_files = [
            MagicMock(suffix=".yaml", name="snowflake_column_metrics_templates.yaml"),
        ]

        # Configure mock file behaviors
        for mock_file in mock_files:
            # Set is_file() behavior based on filename
            if mock_file.name == "subdirectory":
                mock_file.is_file.return_value = False
            else:
                mock_file.is_file.return_value = True

            # Make sure str(mock_file) returns the filename
            mock_file.__str__.return_value = mock_file.name

        # Configure directory mock
        mock_config_dir.exists.return_value = True
        mock_config_dir.glob.return_value = mock_files

        # Run the command
        result = self.runner.invoke(
            snowflake_app,
            ["get-configuration-files", "-td", current_dir := Path(__file__).parent],
        )

        # Assert command executed successfully
        assert result.exit_code == 0
        # delete the generated files from the test directory
        remove_files = [
            current_dir.joinpath(
                COLUMN_METRICS_TEMPLATE_NAME_FORMAT.format(
                    platform=Platform.SNOWFLAKE.value
                )
            ),
            current_dir.joinpath(
                COLUMN_DATATYPES_NORMALIZATION_TEMPLATES_NAME_FORMAT.format(
                    platform=Platform.SNOWFLAKE.value
                )
            ),
        ]
        for file in remove_files:
            if file.exists():
                file.unlink()

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.ComparisonOrchestrator"
    )
    def test_run_validation_ipc_with_credentials(
        self,
        mock_orchestrator_class,
        mock_args_manager_class,
        caplog,
    ):
        """Test IPC validation with credential-based connections."""
        caplog.set_level(logging.INFO)

        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager

        mock_validation_env = MagicMock()
        mock_args_manager.setup_validation_environment.return_value = (
            mock_validation_env
        )

        mock_orchestrator = MagicMock()
        mock_orchestrator.run_sync_comparison = MagicMock()
        mock_orchestrator_class.from_validation_environment.return_value = (
            mock_orchestrator
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow-account",
                "source_account",
                "--snow_username",
                "source_user",
                "--snow_database",
                "source_db",
                "--snow_schema",
                "source_schema",
                "--snow_warehouse",
                "source_wh",
                "--snow_password",
                "source_pass",
                "--target-snow-account",
                "target_account",
                "--target-snow_username",
                "target_user",
                "--target-snow_database",
                "target_db",
                "--target-snow_schema",
                "target_schema",
                "--target-snow_warehouse",
                "target_wh",
                "--target-snow_password",
                "target_pass",
            ],
        )

        assert result.exit_code == 0
        assert "Validation completed successfully!" in result.output
        mock_args_manager.setup_validation_environment.assert_called_once()
        mock_orchestrator.run_sync_comparison.assert_called_once()

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeNamedConnection"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.ComparisonOrchestrator"
    )
    def test_run_validation_ipc_source_named_connection(
        self,
        mock_orchestrator_class,
        mock_named_connection,
        mock_args_manager_class,
        caplog,
    ):
        """Test IPC validation with source named connection."""
        caplog.set_level(logging.INFO)

        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager

        mock_named_conn_instance = MagicMock()
        mock_named_connection.return_value = mock_named_conn_instance

        mock_target_connector = MagicMock()
        mock_args_manager.setup_target_connection.return_value = mock_target_connector

        mock_validation_env = MagicMock()
        mock_args_manager.setup_validation_environment.return_value = (
            mock_validation_env
        )

        mock_orchestrator = MagicMock()
        mock_orchestrator.run_sync_comparison = MagicMock()
        mock_orchestrator_class.from_validation_environment.return_value = (
            mock_orchestrator
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow_connection_name",
                "my_source_connection",
            ],
        )

        assert result.exit_code == 0
        assert "Validation completed successfully!" in result.output
        # Source named connection should be created
        mock_named_connection.assert_called_once()
        # Source credential setup should NOT be called
        mock_args_manager.setup_source_connection.assert_not_called()
        mock_orchestrator.run_sync_comparison.assert_called_once()

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeNamedConnection"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.ComparisonOrchestrator"
    )
    def test_run_validation_ipc_target_named_connection(
        self,
        mock_orchestrator_class,
        mock_named_connection,
        mock_args_manager_class,
        caplog,
    ):
        """Test IPC validation with target named connection."""
        caplog.set_level(logging.INFO)

        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager

        mock_source_connector = MagicMock()
        mock_args_manager.setup_source_connection.return_value = mock_source_connector

        mock_named_conn_instance = MagicMock()
        mock_named_connection.return_value = mock_named_conn_instance

        mock_validation_env = MagicMock()
        mock_args_manager.setup_validation_environment.return_value = (
            mock_validation_env
        )

        mock_orchestrator = MagicMock()
        mock_orchestrator.run_sync_comparison = MagicMock()
        mock_orchestrator_class.from_validation_environment.return_value = (
            mock_orchestrator
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow-account",
                "source_account",
                "--snow_username",
                "source_user",
                "--snow_database",
                "source_db",
                "--snow_schema",
                "source_schema",
                "--snow_warehouse",
                "source_wh",
                "--snow_password",
                "source_pass",
                "--target-connection-name",
                "my_target_connection",
            ],
        )

        assert result.exit_code == 0
        assert "Validation completed successfully!" in result.output
        # Target named connection should be created
        mock_named_connection.assert_called_once()
        mock_orchestrator.run_sync_comparison.assert_called_once()

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeNamedConnection"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.ComparisonOrchestrator"
    )
    def test_run_validation_ipc_both_named_connections(
        self,
        mock_orchestrator_class,
        mock_named_connection,
        mock_args_manager_class,
        caplog,
    ):
        """Test IPC validation with both source and target named connections."""
        caplog.set_level(logging.INFO)

        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager

        mock_named_conn_instance = MagicMock()
        mock_named_connection.return_value = mock_named_conn_instance

        mock_validation_env = MagicMock()
        mock_args_manager.setup_validation_environment.return_value = (
            mock_validation_env
        )

        mock_orchestrator = MagicMock()
        mock_orchestrator.run_sync_comparison = MagicMock()
        mock_orchestrator_class.from_validation_environment.return_value = (
            mock_orchestrator
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow_connection_name",
                "my_source_connection",
                "--target-connection-name",
                "my_target_connection",
            ],
        )

        assert result.exit_code == 0
        assert "Validation completed successfully!" in result.output
        # Both source and target named connections should be created
        assert mock_named_connection.call_count == 2
        mock_orchestrator.run_sync_comparison.assert_called_once()

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.ComparisonOrchestrator"
    )
    def test_run_validation_ipc_default_target_connection(
        self,
        mock_orchestrator_class,
        mock_args_manager_class,
        caplog,
    ):
        """Test IPC validation with default target connection (no target params)."""
        caplog.set_level(logging.INFO)

        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager

        mock_source_connector = MagicMock()
        mock_target_connector = MagicMock()
        mock_args_manager.setup_source_connection.return_value = mock_source_connector
        mock_args_manager.setup_target_connection.return_value = mock_target_connector

        mock_validation_env = MagicMock()
        mock_args_manager.setup_validation_environment.return_value = (
            mock_validation_env
        )

        mock_orchestrator = MagicMock()
        mock_orchestrator.run_sync_comparison = MagicMock()
        mock_orchestrator_class.from_validation_environment.return_value = (
            mock_orchestrator
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow-account",
                "source_account",
                "--snow_username",
                "source_user",
                "--snow_database",
                "source_db",
                "--snow_schema",
                "source_schema",
                "--snow_warehouse",
                "source_wh",
                "--snow_password",
                "source_pass",
            ],
        )

        assert result.exit_code == 0
        assert "Validation completed successfully!" in result.output
        # Target connection should be set up with default mode
        mock_args_manager.setup_target_connection.assert_called_once_with(
            target_conn_mode="default"
        )
        mock_orchestrator.run_sync_comparison.assert_called_once()

    def test_run_validation_ipc_help(self):
        """Test run-validation-ipc command help."""
        result = self.runner.invoke(snowflake_app, ["run-validation-ipc", "--help"])
        assert result.exit_code == 0
        assert "Run Snowflake data validation with IPC" in result.output
        assert "--snow_connection_name" in result.output
        assert "--target-connection-name" in result.output
        assert "--snow-account" in result.output
        assert "--target-snow-account" in result.output

    @patch(
        "snowflake.snowflake_data_validation.snowflake.snowflake_cli.SnowflakeArgumentsManager"
    )
    def test_run_validation_ipc_connection_error(self, mock_args_manager_class):
        """Test IPC validation with connection error."""
        mock_args_manager = MagicMock()
        mock_args_manager_class.return_value = mock_args_manager
        mock_args_manager.setup_validation_environment.side_effect = ConnectionError(
            "Database connection failed"
        )

        result = self.runner.invoke(
            snowflake_app,
            [
                "run-validation-ipc",
                "--snow-account",
                "source_account",
                "--snow_username",
                "source_user",
                "--snow_database",
                "source_db",
                "--snow_schema",
                "source_schema",
                "--snow_warehouse",
                "source_wh",
                "--snow_password",
                "source_pass",
            ],
        )

        assert result.exit_code == 1
        assert "Connection error: Database connection failed" in result.output
