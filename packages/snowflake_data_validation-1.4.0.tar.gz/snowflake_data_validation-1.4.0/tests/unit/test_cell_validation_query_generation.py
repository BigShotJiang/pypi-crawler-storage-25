"""Tests for L3 cell validation SELECT generation (MD5-aligned normalization)."""

from pathlib import Path

import snowflake.snowflake_data_validation as sdv_pkg

from snowflake.snowflake_data_validation.extractor.sql_queries_template_generator import (
    SQLQueriesTemplateGenerator,
)
from snowflake.snowflake_data_validation.public.data_validation_api import (
    generate_cell_validation_data_query,
)
from snowflake.snowflake_data_validation.utils.constants import (
    ObjectType,
    Origin,
    Platform,
)
from snowflake.snowflake_data_validation.utils.model.column_metadata import (
    ColumnMetadata,
)
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext
from snowflake.snowflake_data_validation.utils.model.templates_loader_manager import (
    TemplatesLoaderManager,
)


def _teradata_templates_path() -> str:
    return str(Path(sdv_pkg.__file__).parent / "teradata" / "extractor" / "templates")


def _snowflake_templates_path() -> str:
    return str(Path(sdv_pkg.__file__).parent / "snowflake" / "extractor" / "templates")


def _col(name: str, data_type: str, nullable: bool = True) -> ColumnMetadata:
    return ColumnMetadata(
        name=name,
        data_type=data_type,
        nullable=nullable,
        is_primary_key=False,
        calculated_column_size_in_bytes=0,
        properties={},
    )


def _make_context(
    platform: Platform,
    templates_dir: str,
    columns: list[ColumnMetadata],
    fqn: str = "db.schema.t",
) -> TableContext:
    sql_generator = SQLQueriesTemplateGenerator(
        jinja_templates_folder_path=templates_dir,
    )
    tlm = TemplatesLoaderManager(
        templates_directory_path=Path(templates_dir),
        platform=platform,
    )
    return TableContext(
        apply_metric_column_modifier=True,
        chunk_number=1,
        column_mappings={},
        column_selection_list=[],
        columns=columns,
        database_name="db",
        exclude_metrics=False,
        fully_qualified_name=fqn,
        has_where_clause=False,
        id=1,
        internal_fully_qualified_name=fqn,
        internal_table_name="t",
        is_case_sensitive=False,
        is_exclusion_mode=False,
        is_temporary_table=False,
        max_failed_rows_number=100,
        object_type=ObjectType.TABLE,
        origin=Origin.SOURCE,
        platform=platform,
        row_count=10,
        run_id="r",
        run_start_time="",
        schema_name="schema",
        sql_generator=sql_generator,
        table_name="t",
        templates_loader_manager=tlm,
        user_index_column_collection=[],
        where_clause="",
    )


def test_teradata_cell_query_wraps_decimal_with_to_char() -> None:
    """Teradata cell SELECT uses TO_CHAR/TRIM/COALESCE like MD5 normalization."""
    ctx = _make_context(
        Platform.TERADATA,
        _teradata_templates_path(),
        [_col("P", "DECIMAL")],
        fqn="tpcds.item",
    )
    gq = generate_cell_validation_data_query(ctx, order_by_columns=["I_ITEM_SK"])
    sql = gq.query_string.upper()
    assert "TO_CHAR" in sql
    assert "TRIM" in sql
    assert "COALESCE" in sql
    assert '"P"' in gq.query_string
    assert "ORDER BY" in sql.upper()
    assert '"I_ITEM_SK"' in gq.query_string


def test_snowflake_cell_query_maps_text_to_varchar_template() -> None:
    """Snowflake TEXT columns use the VARCHAR normalization template."""
    ctx = _make_context(
        Platform.SNOWFLAKE,
        _snowflake_templates_path(),
        [_col("X", "TEXT")],
        fqn="DB.SCHEMA.ITEM",
    )
    gq = generate_cell_validation_data_query(ctx, order_by_columns=None)
    sql = gq.query_string
    assert "TRIM" in sql
    assert '"X"' in sql


def test_snowflake_cell_query_uses_subquery_for_order_by() -> None:
    """Snowflake ORDER BY wraps in subquery so sort uses original column types."""
    ctx = _make_context(
        Platform.SNOWFLAKE,
        _snowflake_templates_path(),
        [_col("ID", "NUMBER"), _col("NAME", "TEXT")],
        fqn="DB.SCHEMA.T",
    )
    gq = generate_cell_validation_data_query(ctx, order_by_columns=["ID"])
    sql = gq.query_string
    assert "__ordered" in sql
    assert "ORDER BY" in sql.upper()


def test_teradata_cell_query_order_by_at_top_level() -> None:
    """Teradata ORDER BY stays at top level (subqueries disallow ORDER BY)."""
    ctx = _make_context(
        Platform.TERADATA,
        _teradata_templates_path(),
        [_col("ID", "INTEGER")],
        fqn="db.t",
    )
    gq = generate_cell_validation_data_query(ctx, order_by_columns=["ID"])
    sql = gq.query_string
    assert "__ordered" not in sql
    assert "ORDER BY" in sql.upper()
