# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import pandas as pd

from snowflake.snowflake_data_validation.orchestration.html_report.html_report_builder import (
    HtmlReportBuilder,
    CSS_STYLES,
    DATATABLES_SCRIPT,
)
from snowflake.snowflake_data_validation.orchestration.html_report.report_metadata import (
    ReportMetadata,
)


@pytest.fixture
def sample_metadata():
    """Create sample ReportMetadata for testing."""
    return ReportMetadata(
        date="2026-02-09 12:00:00",
        source_platform="SQL Server",
        source_connection="source_db_server",
        target_platform="Snowflake",
        target_connection="target_snowflake_account",
        execution_id="test-run-123",
    )


@pytest.fixture
def sample_summary_df():
    """Create a sample summary DataFrame."""
    return pd.DataFrame(
        {
            "Status": ["SUCCESS", "FAILURE"],
            "Count": [10, 2],
        }
    )


@pytest.fixture
def sample_details_df():
    """Create a sample details DataFrame."""
    return pd.DataFrame(
        {
            "Table": ["table1", "table2", "table3"],
            "Column": ["col1", "col2", "col3"],
            "Status": ["SUCCESS", "FAILURE", "SUCCESS"],
            "Message": ["OK", "Mismatch", "OK"],
        }
    )


def test_add_header():
    """Test that add_header generates correct HTML structure."""
    builder = HtmlReportBuilder()
    builder.add_header("My Test Report")
    html = builder.build()

    assert "<!DOCTYPE html>" in html
    assert "<title>My Test Report</title>" in html
    assert "<h1>My Test Report</h1>" in html
    assert CSS_STYLES in html


def test_add_metadata(sample_metadata):
    """Test that add_metadata includes all metadata fields."""
    builder = HtmlReportBuilder()
    builder.add_metadata(sample_metadata)
    html = builder.build()

    assert "Date: 2026-02-09 12:00:00" in html
    assert "Source platform: SQL Server" in html
    assert "Source connection identifier: source_db_server" in html
    assert "Target platform: Snowflake" in html
    assert "Target connection identifier: target_snowflake_account" in html
    assert "Execution ID: test-run-123" in html


def test_add_summary_table(sample_summary_df):
    """Test that add_summary_table renders DataFrame correctly."""
    builder = HtmlReportBuilder()
    builder.add_summary_table(sample_summary_df)
    html = builder.build()

    assert "SUCCESS" in html
    assert "FAILURE" in html
    assert "simple-table" in html


def test_add_section(sample_summary_df, sample_details_df):
    """Test that add_section includes title and both tables."""
    builder = HtmlReportBuilder()
    builder.add_section("SCHEMA VALIDATION", sample_summary_df, sample_details_df)
    html = builder.build()

    assert "<h2>SCHEMA VALIDATION</h2>" in html
    assert "simple-table" in html
    assert "display" in html
    assert "table1" in html


def test_add_scripts():
    """Test that add_scripts includes jQuery and DataTables."""
    builder = HtmlReportBuilder()
    builder.add_scripts()
    html = builder.build()

    assert "jquery-3.7.1.min.js" in html
    assert "jquery.dataTables.min.js" in html
    assert DATATABLES_SCRIPT in html


def test_add_footer():
    """Test that add_footer closes HTML tags."""
    builder = HtmlReportBuilder()
    builder.add_footer()
    html = builder.build()

    assert "</body>" in html
    assert "</html>" in html


def test_build_concatenates_sections(sample_metadata, sample_summary_df):
    """Test that build concatenates all sections in order."""
    builder = HtmlReportBuilder()
    builder.add_header("Test Report")
    builder.add_metadata(sample_metadata)
    builder.add_summary_table(sample_summary_df)
    builder.add_footer()

    html = builder.build()

    assert "<!DOCTYPE html>" in html
    assert "Test Report" in html
    assert "Date: 2026-02-09" in html
    assert "</html>" in html


def test_write_to_file(tmp_path):
    """Test that write_to_file creates the HTML file."""
    builder = HtmlReportBuilder()
    builder.add_header("Test Report")
    builder.add_footer()

    file_path = tmp_path / "test_report.html"
    builder.write_to_file(str(file_path))

    assert file_path.exists()

    with open(file_path, encoding="utf-8") as f:
        content = f.read()

    assert content == builder.build()


def test_method_chaining(sample_metadata, sample_summary_df, sample_details_df):
    """Test that method chaining produces complete HTML report."""
    builder = HtmlReportBuilder()
    html = (
        builder.add_header("Validation Report")
        .add_metadata(sample_metadata)
        .add_section("Schema Validation", sample_summary_df, sample_details_df)
        .add_scripts()
        .add_footer()
        .build()
    )

    assert "<!DOCTYPE html>" in html
    assert "<title>Validation Report</title>" in html
    assert "Date: 2026-02-09" in html
    assert "<h2>Schema Validation</h2>" in html
    assert "DataTable" in html
    assert "</html>" in html
