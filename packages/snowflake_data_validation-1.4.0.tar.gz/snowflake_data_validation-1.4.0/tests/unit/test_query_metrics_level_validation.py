import polars as pl
import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    query_metrics_level_validation,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_VALIDATED_KEY,
    EVALUATION_CRITERIA_KEY,
    STATUS_KEY,
    Result,
)


def test_query_metrics_validation_with_matching_data():
    dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_mismatched_data():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [50, 30],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True

    failed_rows = result.results_dataframe[
        result.results_dataframe[STATUS_KEY] == Result.FAILURE.value
    ]
    assert (failed_rows[COLUMN_VALIDATED_KEY] == "QTY").all()
    assert (
        failed_rows[EVALUATION_CRITERIA_KEY].isin(["AVG", "SUM", "MAX", "MIN"])
    ).all()


def test_query_metrics_validation_with_column_mappings():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QUANTITY": [10, 20],
            "TITLE": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
        column_mappings={"QTY": "QUANTITY", "NAME": "TITLE"},
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_special_characters_in_column_names():
    dataframe = pl.DataFrame(
        {
            "ID@": [1, 2],
            "(QTY)": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_various_data_types():
    dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QUANTITY": [10.5, 20.75],
            "NAME": ["Device A", "Device B"],
            "IS_ACTIVE": [True, False],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_null_data():
    dataframe = pl.DataFrame(
        {
            "ID": [1, None],
            "QTY": [None, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": [None, "2026-01-02"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_tolerance_on_numeric_columns():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3, 4],
            "QTY": [3.14159, 67.3451042454, 3.0114899, 28.12670001],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3, 4],
            "QTY": [4.14159, 68.3451042454, 4.0114899, 29.12670001],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
        tolerance=10.0,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_different_row_counts():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "QTY": [10, 20, 30],
            "NAME": ["Device A", "Device B", "Device C"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02", "2026-01-03"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    failed_rows = result.results_dataframe[
        result.results_dataframe[STATUS_KEY] == Result.FAILURE.value
    ]
    assert (
        failed_rows[COLUMN_VALIDATED_KEY].isin(["ID", "QTY", "NAME", "UPDATED_AT"])
    ).all()


def test_query_metrics_validation_with_single_row():
    dataframe = pl.DataFrame(
        {
            "ID": [1],
            "QTY": [10],
            "NAME": ["Device A"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_single_column():
    dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_float_precision():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "PRICE": [10.123456789, 20.987654321],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "PRICE": [10.123456790, 20.987654322],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
        tolerance=0.0001,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_large_dataset():
    large_data = {
        "ID": list(range(1000)),
        "VALUE": [float(i) for i in range(1000)],
    }
    dataframe = pl.DataFrame(large_data)

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_negative_values():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [-10, -20, -30],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [-10, -20, -30],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_zero_values():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [0, 0, 0],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [0, 0, 0],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_string_only_columns():
    dataframe = pl.DataFrame(
        {
            "NAME": ["Alice", "Bob", "Charlie"],
            "CITY": ["NYC", "LA", "Chicago"],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_query_metrics_validation_with_mixed_null_patterns():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [10, None, 30],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "VALUE": [10, None, 30],
        }
    )

    result = query_metrics_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()
