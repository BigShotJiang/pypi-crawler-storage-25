from unittest.mock import MagicMock

import polars as pl
import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    result_set_to_dataframe,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.public.model.result_set import ResultSet
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)


def test_result_set_to_dataframe_with_valid_data():
    result_set_data = [
        {"ID": 1, "NAME": "Device A", "QTY": 10},
        {"ID": 2, "NAME": "Device B", "QTY": 20},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
        "QTY": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert "ID" in result.columns
    assert "NAME" in result.columns
    assert "QTY" in result.columns


def test_result_set_to_dataframe_with_empty_result_set():
    result_set_data = []
    result_set_column_types = {}

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 0


def test_result_set_to_dataframe_with_null_values():
    result_set_data = [
        {"ID": 1, "NAME": "Device A", "QTY": None},
        {"ID": None, "NAME": "Device B", "QTY": 20},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
        "QTY": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert result["QTY"][0] is None
    assert result["ID"][1] is None


def test_result_set_to_dataframe_with_invalid_snowflake_connector():
    result_set_data = [
        {"ID": 1, "NAME": "Device A"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    invalid_snowflake_connector = "not_a_connector"

    with pytest.raises(DataValidationExceptionError) as exc_info:
        result_set_to_dataframe(
            result_set=result_set,
            snowflake_stage_connector=invalid_snowflake_connector,
        )

    assert "Snowflake stage connector must be provided" in str(exc_info.value)


def test_result_set_to_dataframe_with_various_data_types():
    result_set_data = [
        {
            "INT_COL": 42,
            "FLOAT_COL": 3.14,
            "STRING_COL": "hello",
            "BOOL_COL": True,
            "DATE_COL": "2026-01-01",
        },
    ]

    result_set_column_types = {
        "INT_COL": "INTEGER",
        "FLOAT_COL": "FLOAT",
        "STRING_COL": "VARCHAR",
        "BOOL_COL": "BOOLEAN",
        "DATE_COL": "DATE",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1
    assert result["INT_COL"][0] == 42
    assert result["FLOAT_COL"][0] == 3.14
    assert result["STRING_COL"][0] == "hello"
    assert result["BOOL_COL"][0] == True


def test_result_set_to_dataframe_with_single_row():
    result_set_data = [
        {"ID": 1, "NAME": "Single Device"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1
    assert result["ID"][0] == 1
    assert result["NAME"][0] == "Single Device"


def test_result_set_to_dataframe_with_single_column():
    result_set_data = [
        {"ID": 1},
        {"ID": 2},
        {"ID": 3},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 3
    assert len(result.columns) == 1
    assert result["ID"][0] == 1
    assert result["ID"][2] == 3


def test_result_set_to_dataframe_with_large_dataset():
    result_set_data = [{"ID": i, "VALUE": f"value_{i}"} for i in range(1000)]

    result_set_column_types = {
        "ID": "NUMBER",
        "VALUE": "VARCHAR",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1000
    assert result["ID"][0] == 0
    assert result["ID"][999] == 999


def test_result_set_to_dataframe_with_datetime_types():
    result_set_data = [
        {
            "ID": 1,
            "CREATED_AT": "2026-01-01 10:30:00",
            "UPDATED_AT": "2026-01-02 14:45:00",
        },
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "CREATED_AT": "DATETIME",
        "UPDATED_AT": "DATETIME",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1
    assert "CREATED_AT" in result.columns
    assert "UPDATED_AT" in result.columns


def test_result_set_to_dataframe_with_special_characters_in_column_names():
    result_set_data = [
        {"ID@": 1, "(QTY)": 10, "NAME#": "Device A"},
        {"ID@": 2, "(QTY)": 20, "NAME#": "Device B"},
    ]

    result_set_column_types = {
        "ID@": "NUMBER",
        "(QTY)": "NUMBER",
        "NAME#": "VARCHAR",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert "ID@" in result.columns
    assert "(QTY)" in result.columns
    assert "NAME#" in result.columns


def test_result_set_to_dataframe_with_negative_values():
    result_set_data = [
        {"ID": 1, "VALUE": -100},
        {"ID": 2, "VALUE": -200},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "VALUE": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert result["VALUE"][0] == -100
    assert result["VALUE"][1] == -200


def test_result_set_to_dataframe_with_float_precision():
    result_set_data = [
        {"ID": 1, "PRICE": 10.123456789},
        {"ID": 2, "PRICE": 20.987654321},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "PRICE": "FLOAT",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert abs(result["PRICE"][0] - 10.123456789) < 0.0000001
    assert abs(result["PRICE"][1] - 20.987654321) < 0.0000001


def test_result_set_to_dataframe_with_all_null_column():
    result_set_data = [
        {"ID": 1, "VALUE": None},
        {"ID": 2, "VALUE": None},
        {"ID": 3, "VALUE": None},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "VALUE": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 3
    assert result["VALUE"][0] is None
    assert result["VALUE"][1] is None
    assert result["VALUE"][2] is None


def test_result_set_to_dataframe_with_string_only_columns():
    result_set_data = [
        {"NAME": "Alice", "CITY": "NYC"},
        {"NAME": "Bob", "CITY": "LA"},
    ]

    result_set_column_types = {
        "NAME": "VARCHAR",
        "CITY": "VARCHAR",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert result["NAME"][0] == "Alice"
    assert result["CITY"][1] == "LA"


def test_result_set_to_dataframe_preserves_column_order():
    result_set_data = [
        {"A": 1, "B": 2, "C": 3, "D": 4},
    ]

    result_set_column_types = {
        "A": "NUMBER",
        "B": "NUMBER",
        "C": "NUMBER",
        "D": "NUMBER",
    }

    result_set = ResultSet(rows=result_set_data, column_types=result_set_column_types)
    mock_snowflake_connector = MagicMock(spec=ConnectorSnowflake)

    result = result_set_to_dataframe(
        result_set=result_set,
        snowflake_stage_connector=mock_snowflake_connector,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result.columns) == 4
