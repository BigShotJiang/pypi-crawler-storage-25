# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.orchestration.table_metadata_processor import (
    TableMetadataProcessor,
)
from snowflake.snowflake_data_validation.public.model import (
    QueryExecutionResult,
)
from snowflake.snowflake_data_validation.utils.constants import (
    CALCULATED_COLUMN_SIZE_IN_BYTES_KEY,
    CHARACTER_LENGTH_KEY,
    COLUMN_DATATYPE,
    COLUMN_NAME_KEY,
    DATABASE_NAME_KEY,
    IS_PRIMARY_KEY_KEY,
    NULLABLE_KEY,
    PRECISION_KEY,
    ROW_COUNT_KEY,
    SCALE_KEY,
    SCHEMA_NAME_KEY,
    TABLE_NAME_KEY,
    Platform,
)
from snowflake.snowflake_data_validation.utils.model.table_column_metadata import (
    TableColumnMetadata,
)


class TestTableMetadataProcessor:
    """Test class for TableMetadataProcessor."""

    def setup_method(self):
        self.processor = TableMetadataProcessor()

        self.mock_context = MagicMock()
        self.mock_context.source_platform = Platform.REDSHIFT
        self.mock_context.target_platform = Platform.SNOWFLAKE
        self.mock_context.output_handler = MagicMock()

        self.processor.context = self.mock_context

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_calls_api_with_correct_params(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata calls the public API with correct parameters."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["test_column"],
                COLUMN_DATATYPE: ["VARCHAR"],
                NULLABLE_KEY: [True],
                IS_PRIMARY_KEY_KEY: [False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [50],
                DATABASE_NAME_KEY: ["source_db"],
                SCHEMA_NAME_KEY: ["source_schema"],
                TABLE_NAME_KEY: ["source_table"],
                CHARACTER_LENGTH_KEY: [None],
                PRECISION_KEY: [None],
                SCALE_KEY: [None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=[],
            column_mappings={},
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [100]}))
        )
        mock_api.extract_row_count.return_value = 100
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )

        expected_result = MagicMock(spec=TableColumnMetadata)
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            expected_result
        )

        self.mock_context.datatypes_mappings = {
            "VARCHAR": "STRING",
            "INTEGER": "NUMBER",
        }

        result = self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        mock_api.process_target_table_column_metadata_from_source_table.assert_called_once()
        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        assert call_kwargs.kwargs["table_configuration"] == table_config
        assert call_kwargs.kwargs["datatypes_mappings"] == {
            "VARCHAR": "STRING",
            "INTEGER": "NUMBER",
        }
        assert call_kwargs.kwargs["row_count"] == 100
        assert result == expected_result

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_passes_source_df_to_api(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata passes the source DataFrame to the API."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["custom_column"],
                COLUMN_DATATYPE: ["INTEGER"],
                NULLABLE_KEY: [True],
                IS_PRIMARY_KEY_KEY: [False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [50],
                DATABASE_NAME_KEY: ["source_db"],
                SCHEMA_NAME_KEY: ["source_schema"],
                TABLE_NAME_KEY: ["source_table"],
                CHARACTER_LENGTH_KEY: [None],
                PRECISION_KEY: [None],
                SCALE_KEY: [None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=[],
            column_mappings={},
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [100]}))
        )
        mock_api.extract_row_count.return_value = 100
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "VARCHAR": "STRING",
            "INTEGER": "NUMBER",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        pd.testing.assert_frame_equal(
            call_kwargs.kwargs["table_column_metadata_from_source_df"], source_df
        )

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_passes_column_selection_list(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata passes column_selection_list via table_configuration."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["id", "name", "email"],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR", "VARCHAR"],
                NULLABLE_KEY: [False, True, True],
                IS_PRIMARY_KEY_KEY: [True, False, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 50, 100],
                DATABASE_NAME_KEY: ["source_db", "source_db", "source_db"],
                SCHEMA_NAME_KEY: ["source_schema", "source_schema", "source_schema"],
                TABLE_NAME_KEY: ["source_table", "source_table", "source_table"],
                CHARACTER_LENGTH_KEY: [None, None, None],
                PRECISION_KEY: [None, None, None],
                SCALE_KEY: [None, None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=["id", "name"],
            column_mappings={},
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [500]}))
        )
        mock_api.extract_row_count.return_value = 500
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        assert call_kwargs.kwargs["table_configuration"].column_selection_list == [
            "id",
            "name",
        ]

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_passes_empty_column_selection_list(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata handles empty column_selection_list."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["id", "name", "email", "age"],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR", "VARCHAR", "INTEGER"],
                NULLABLE_KEY: [False, True, True, False],
                IS_PRIMARY_KEY_KEY: [True, False, False, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 50, 100, 4],
                DATABASE_NAME_KEY: ["source_db", "source_db", "source_db", "source_db"],
                SCHEMA_NAME_KEY: [
                    "source_schema",
                    "source_schema",
                    "source_schema",
                    "source_schema",
                ],
                TABLE_NAME_KEY: [
                    "source_table",
                    "source_table",
                    "source_table",
                    "source_table",
                ],
                CHARACTER_LENGTH_KEY: [None, None, None, None],
                PRECISION_KEY: [None, None, None, None],
                SCALE_KEY: [None, None, None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=[],
            column_mappings={},
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [500]}))
        )
        mock_api.extract_row_count.return_value = 500
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        assert call_kwargs.kwargs["table_configuration"].column_selection_list == []

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_passes_column_mappings(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata passes column_mappings via table_configuration."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["id", "full_name"],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR"],
                NULLABLE_KEY: [False, True],
                IS_PRIMARY_KEY_KEY: [True, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 100],
                DATABASE_NAME_KEY: ["source_db", "source_db"],
                SCHEMA_NAME_KEY: ["source_schema", "source_schema"],
                TABLE_NAME_KEY: ["source_table", "source_table"],
                CHARACTER_LENGTH_KEY: [None, None],
                PRECISION_KEY: [None, None],
                SCALE_KEY: [None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=["full_name"],
            column_mappings={"FULL_NAME": "name"},
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [500]}))
        )
        mock_api.extract_row_count.return_value = 500
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        # TableConfiguration normalizes mapping values to uppercase when is_case_sensitive=False
        assert call_kwargs.kwargs["table_configuration"].column_mappings == {
            "FULL_NAME": "NAME"
        }

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    @pytest.mark.parametrize(
        "is_case_sensitive, column_selection_list, input_column_mappings, expected_column_mappings",
        [
            (
                False,
                ["id", "beautifool c*lumn", "$pecial column", "test column"],
                {
                    "BEAUTIFOOL C*LUMN": "beautifool_c_lumn",
                    "$PECIAL COLUMN": "_pecial_column",
                },
                # TableConfiguration normalizes values to uppercase when is_case_sensitive=False
                {
                    "BEAUTIFOOL C*LUMN": "BEAUTIFOOL_C_LUMN",
                    "$PECIAL COLUMN": "_PECIAL_COLUMN",
                },
            ),
            (
                True,
                ["id", "beautifool c*lumn", "$pecial column", "test column"],
                {
                    "beautifool c*lumn": "beautifool_c_lumn",
                    "$pecial column": "_pecial_column",
                },
                # When case sensitive, values are preserved as-is
                {
                    "beautifool c*lumn": "beautifool_c_lumn",
                    "$pecial column": "_pecial_column",
                },
            ),
        ],
    )
    def test_extract_and_generate_target_metadata_passes_special_characters_in_mappings(
        self,
        mock_api,
        is_case_sensitive,
        column_selection_list,
        input_column_mappings,
        expected_column_mappings,
    ):
        """Test that _extract_and_generate_target_metadata passes special character mappings correctly."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: [
                    "id",
                    "beautifool c*lumn",
                    "$pecial column",
                    "test column",
                ],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR", "VARCHAR", "INTEGER"],
                NULLABLE_KEY: [False, True, True, False],
                IS_PRIMARY_KEY_KEY: [True, False, False, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 100, 50, 4],
                DATABASE_NAME_KEY: ["source_db", "source_db", "source_db", "source_db"],
                SCHEMA_NAME_KEY: [
                    "source_schema",
                    "source_schema",
                    "source_schema",
                    "source_schema",
                ],
                TABLE_NAME_KEY: [
                    "source_table",
                    "source_table",
                    "source_table",
                    "source_table",
                ],
                CHARACTER_LENGTH_KEY: [None, None, None, None],
                PRECISION_KEY: [None, None, None, None],
                SCALE_KEY: [None, None, None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=column_selection_list,
            column_mappings=input_column_mappings,
            is_case_sensitive=is_case_sensitive,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [600]}))
        )
        mock_api.extract_row_count.return_value = 600
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        assert (
            call_kwargs.kwargs["table_configuration"].column_mappings
            == expected_column_mappings
        )
        assert (
            call_kwargs.kwargs["table_configuration"].is_case_sensitive
            == is_case_sensitive
        )

    @patch(
        "snowflake.snowflake_data_validation.orchestration.table_metadata_processor.data_validation_api"
    )
    def test_extract_and_generate_target_metadata_passes_brackets_in_mappings(
        self, mock_api
    ):
        """Test that _extract_and_generate_target_metadata passes bracket character mappings correctly."""
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: [
                    "id",
                    "[beautifool c*lumn]",
                    "[$pecial column]",
                    "test column",
                ],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR", "VARCHAR", "INTEGER"],
                NULLABLE_KEY: [False, True, True, False],
                IS_PRIMARY_KEY_KEY: [True, False, False, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 100, 50, 4],
                DATABASE_NAME_KEY: ["source_db", "source_db", "source_db", "source_db"],
                SCHEMA_NAME_KEY: [
                    "source_schema",
                    "source_schema",
                    "source_schema",
                    "source_schema",
                ],
                TABLE_NAME_KEY: [
                    "source_table",
                    "source_table",
                    "source_table",
                    "source_table",
                ],
                CHARACTER_LENGTH_KEY: [None, None, None, None],
                PRECISION_KEY: [None, None, None, None],
                SCALE_KEY: [None, None, None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=[
                "id",
                "[beautifool c*lumn]",
                "[$pecial column]",
                "test column",
            ],
            column_mappings={
                "[BEAUTIFOOL C*LUMN]": "[beautifool_c_lumn]",
                "[$PECIAL COLUMN]": "[_pecial_column]",
            },
            is_case_sensitive=False,
        )

        mock_target_extractor = MagicMock()
        mock_target_extractor.connector = MagicMock()

        mock_api.generate_row_count_query.return_value = MagicMock(
            query_string="SELECT COUNT(*)"
        )
        mock_api.execute_query_from_table_configuration.return_value = (
            QueryExecutionResult(dataframe=pd.DataFrame({ROW_COUNT_KEY: [600]}))
        )
        mock_api.extract_row_count.return_value = 600
        mock_api.generate_case_sensitive_columns_query.return_value = MagicMock(
            query_string="SELECT columns"
        )
        mock_api.process_target_table_column_metadata_from_source_table.return_value = (
            MagicMock()
        )

        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        call_kwargs = (
            mock_api.process_target_table_column_metadata_from_source_table.call_args
        )
        # TableConfiguration normalizes mapping values to uppercase when is_case_sensitive=False
        assert call_kwargs.kwargs["table_configuration"].column_mappings == {
            "[BEAUTIFOOL C*LUMN]": "[BEAUTIFOOL_C_LUMN]",
            "[$PECIAL COLUMN]": "[_PECIAL_COLUMN]",
        }

    def test_extract_and_generate_target_metadata_uses_passed_source_dataframe(self):
        """Test that _extract_and_generate_target_metadata uses the passed source DataFrame.

        This test verifies that the target metadata generation uses the source DataFrame
        passed as parameter, rather than re-extracting from the target database.
        This is critical because target column metadata should be derived from source
        columns (with mappings applied), not from the target database directly.
        """
        # Create source DataFrame with specific columns
        source_df = pd.DataFrame(
            {
                COLUMN_NAME_KEY: ["source_col_a", "source_col_b"],
                COLUMN_DATATYPE: ["INTEGER", "VARCHAR"],
                NULLABLE_KEY: [False, True],
                IS_PRIMARY_KEY_KEY: [True, False],
                CALCULATED_COLUMN_SIZE_IN_BYTES_KEY: [8, 100],
                DATABASE_NAME_KEY: ["source_db", "source_db"],
                SCHEMA_NAME_KEY: ["source_schema", "source_schema"],
                TABLE_NAME_KEY: ["source_table", "source_table"],
                CHARACTER_LENGTH_KEY: [None, None],
                PRECISION_KEY: [None, None],
                SCALE_KEY: [None, None],
            }
        )

        table_config = TableConfiguration(
            fully_qualified_name="source_db.source_schema.source_table",
            target_database="target_db",
            target_schema="target_schema",
            target_name="target_table",
            use_column_selection_as_exclude_list=False,
            column_selection_list=[],
            column_mappings={},
            is_case_sensitive=False,
        )

        # Mock target extractor
        mock_target_extractor = MagicMock()
        mock_target_extractor.platform = Platform.SNOWFLAKE
        mock_target_extractor.extract_table_row_count.return_value = pd.DataFrame(
            {ROW_COUNT_KEY: [100]}
        )
        mock_target_extractor.extract_case_sensitive_columns.return_value = (
            pd.DataFrame()
        )

        # Set up context with datatypes mappings
        self.mock_context.datatypes_mappings = {
            "INTEGER": "NUMBER",
            "VARCHAR": "STRING",
        }

        # Call _extract_and_generate_target_metadata with the source DataFrame
        result = self.processor._extract_and_generate_target_metadata(
            table_configuration=table_config,
            table_column_metadata_from_source_df=source_df,
            target_extractor=mock_target_extractor,
            context=self.mock_context,
        )

        # Verify that the result contains columns from the SOURCE DataFrame
        # (not re-extracted from target)
        assert len(result.columns) == 2
        assert result.columns[0].name == "SOURCE_COL_A"
        assert result.columns[1].name == "SOURCE_COL_B"

        # Verify that _extract_table_column_metadata_from_source was NOT called
        # on the target_extractor (it should use the passed DataFrame)
        assert (
            not hasattr(mock_target_extractor, "extract_table_column_metadata")
            or not mock_target_extractor.extract_table_column_metadata.called
        )
