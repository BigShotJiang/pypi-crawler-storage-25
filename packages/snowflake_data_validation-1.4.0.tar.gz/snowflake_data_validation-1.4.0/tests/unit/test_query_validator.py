# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest.mock import MagicMock

import polars as pl

from snowflake.snowflake_data_validation.public.model.generated_query import (
    GeneratedQuery,
)
from snowflake.snowflake_data_validation.validation.query_validator import (
    QueryValidator,
)


class MockRow:
    """Mock class to simulate pyodbc.Row objects that are iterable but not list/tuple."""

    def __init__(self, values):
        self._values = values

    def __iter__(self):
        return iter(self._values)

    def __len__(self):
        return len(self._values)


def test_to_polars_dataframe_with_tuple_rows():
    """Test that tuple rows are handled correctly without conversion overhead."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    column_names = ["id", "name"]
    rows = [(1, "Alice"), (2, "Bob")]
    mock_connector.execute_query.return_value = (column_names, rows)

    query = GeneratedQuery(query_string="SELECT id, name FROM users")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert result.columns == ["id", "name"]
    assert len(result) == 2
    assert result["id"].to_list() == [1, 2]
    assert result["name"].to_list() == ["Alice", "Bob"]


def test_to_polars_dataframe_with_list_rows():
    """Test that list rows are handled correctly without conversion overhead."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    column_names = ["id", "value"]
    rows = [[1, 100], [2, 200]]
    mock_connector.execute_query.return_value = (column_names, rows)

    query = GeneratedQuery(query_string="SELECT id, value FROM data")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert result.columns == ["id", "value"]
    assert len(result) == 2
    assert result["id"].to_list() == [1, 2]
    assert result["value"].to_list() == [100, 200]


def test_to_polars_dataframe_with_row_like_objects():
    """Test that Row-like objects (e.g., pyodbc.Row) are converted to lists."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    column_names = ["id", "name", "active"]
    rows = [
        MockRow([1, "Alice", True]),
        MockRow([2, "Bob", False]),
    ]
    mock_connector.execute_query.return_value = (column_names, rows)

    query = GeneratedQuery(query_string="SELECT id, name, active FROM users")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert result.columns == ["id", "name", "active"]
    assert len(result) == 2
    assert result["id"].to_list() == [1, 2]
    assert result["name"].to_list() == ["Alice", "Bob"]
    assert result["active"].to_list() == [True, False]


def test_to_polars_dataframe_with_empty_rows():
    """Test that empty result sets are handled correctly."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    column_names = ["id", "name"]
    rows = []
    mock_connector.execute_query.return_value = (column_names, rows)

    query = GeneratedQuery(query_string="SELECT id, name FROM empty_table")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert result.columns == ["id", "name"]
    assert len(result) == 0


def test_to_polars_dataframe_with_dict_result():
    """Test that standard dict format (non-tuple result) is handled correctly."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    mock_connector.execute_query.return_value = [
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"},
    ]

    query = GeneratedQuery(query_string="SELECT id, name FROM users")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert result["id"].to_list() == [1, 2]
    assert result["name"].to_list() == ["Alice", "Bob"]


def test_to_polars_dataframe_with_null_values():
    """Test that NULL values in Row-like objects are handled correctly."""
    validator = QueryValidator()
    mock_connector = MagicMock()

    column_names = ["id", "optional_field"]
    rows = [
        MockRow([1, None]),
        MockRow([2, "value"]),
    ]
    mock_connector.execute_query.return_value = (column_names, rows)

    query = GeneratedQuery(query_string="SELECT id, optional_field FROM data")
    result = validator.to_polars_dataframe(query=query, connector=mock_connector)

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert result["id"].to_list() == [1, 2]
    assert result["optional_field"].to_list() == [None, "value"]
