from unittest.mock import MagicMock

import polars as pl
import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    query_to_dataframe,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.public.model.generated_query import (
    GeneratedQuery,
)
from snowflake.snowflake_data_validation.utils.constants import Platform


def test_query_to_dataframe_with_valid_data():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = [
        {"ID": 1, "NAME": "Device A", "QTY": 10},
        {"ID": 2, "NAME": "Device B", "QTY": 20},
    ]

    query = GeneratedQuery(query_string="SELECT * FROM test_table")

    result = query_to_dataframe(
        query=query,
        connector=mock_connector,
        platform=Platform.SNOWFLAKE,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert "ID" in result.columns
    assert "NAME" in result.columns
    assert "QTY" in result.columns

    mock_connector.execute_query.assert_called_once_with(
        query="SELECT * FROM test_table"
    )


def test_query_to_dataframe_with_empty_result():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = []

    query = GeneratedQuery(query_string="SELECT * FROM empty_table")

    result = query_to_dataframe(
        query=query,
        connector=mock_connector,
        platform=Platform.SNOWFLAKE,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 0


def test_query_to_dataframe_with_null_values():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = [
        {"ID": 1, "NAME": "Device A", "QTY": None},
        {"ID": None, "NAME": "Device B", "QTY": 20},
    ]

    query = GeneratedQuery(query_string="SELECT * FROM test_table")

    result = query_to_dataframe(
        query=query,
        connector=mock_connector,
        platform=Platform.SNOWFLAKE,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 2
    assert result["QTY"][0] is None
    assert result["ID"][1] is None


def test_query_to_dataframe_with_different_platforms():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = [
        {"ID": 1, "NAME": "Device A"},
    ]

    query = GeneratedQuery(query_string="SELECT * FROM test_table")

    for platform in [
        Platform.SNOWFLAKE,
        Platform.SQLSERVER,
        Platform.TERADATA,
        Platform.REDSHIFT,
    ]:
        result = query_to_dataframe(
            query=query,
            connector=mock_connector,
            platform=platform,
        )

        assert isinstance(result, pl.DataFrame)
        assert len(result) == 1


def test_query_to_dataframe_with_various_data_types():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = [
        {
            "INT_COL": 42,
            "FLOAT_COL": 3.14,
            "STRING_COL": "hello",
            "BOOL_COL": True,
            "DATE_COL": "2026-01-01",
        },
    ]

    query = GeneratedQuery(query_string="SELECT * FROM test_table")

    result = query_to_dataframe(
        query=query,
        connector=mock_connector,
        platform=Platform.SNOWFLAKE,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1
    assert result["INT_COL"][0] == 42
    assert result["FLOAT_COL"][0] == 3.14
    assert result["STRING_COL"][0] == "hello"
    assert result["BOOL_COL"][0] == True
    assert result["DATE_COL"][0] == "2026-01-01"


def test_query_to_dataframe_with_query_execution_error():
    mock_connector = MagicMock()
    mock_connector.execute_query.side_effect = Exception("Query execution failed")

    query = GeneratedQuery(query_string="SELECT * FROM invalid_table")

    with pytest.raises(DataValidationExceptionError) as exc_info:
        query_to_dataframe(
            query=query,
            connector=mock_connector,
            platform=Platform.SNOWFLAKE,
        )

    assert "Query execution failed" in str(exc_info.value)


def test_query_to_dataframe_with_single_row():
    mock_connector = MagicMock()
    mock_connector.execute_query.return_value = [
        {"ID": 1, "NAME": "Single Device"},
    ]

    query = GeneratedQuery(query_string="SELECT * FROM test_table LIMIT 1")

    result = query_to_dataframe(
        query=query,
        connector=mock_connector,
        platform=Platform.SNOWFLAKE,
    )

    assert isinstance(result, pl.DataFrame)
    assert len(result) == 1
    assert result["ID"][0] == 1
    assert result["NAME"][0] == "Single Device"
