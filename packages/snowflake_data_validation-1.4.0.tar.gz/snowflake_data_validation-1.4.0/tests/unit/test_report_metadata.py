# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest.mock import MagicMock

from snowflake.snowflake_data_validation.orchestration.html_report.report_metadata import (
    ReportMetadata,
)


def test_report_metadata_creation():
    """Test that ReportMetadata can be created with all fields."""
    metadata = ReportMetadata(
        date="2026-02-09 12:00:00",
        source_platform="SQL Server",
        source_connection="source_server",
        target_platform="Snowflake",
        target_connection="target_account",
        execution_id="run-123",
    )

    assert metadata.date == "2026-02-09 12:00:00"
    assert metadata.source_platform == "SQL Server"
    assert metadata.source_connection == "source_server"
    assert metadata.target_platform == "Snowflake"
    assert metadata.target_connection == "target_account"
    assert metadata.execution_id == "run-123"


def test_from_context():
    """Test that from_context creates ReportMetadata from Context."""
    # Create mock context
    mock_context = MagicMock()
    mock_context.run_start_time = "20260209T120000"
    mock_context.run_id = "test-run-456"
    mock_context.source_platform.value = "SQL Server"
    mock_context.target_platform.value = "Snowflake"
    mock_context.configuration.source_connection.get_connection_identifier.return_value = (
        "source_db"
    )
    mock_context.configuration.target_connection.get_connection_identifier.return_value = (
        "target_db"
    )

    metadata = ReportMetadata.from_context(mock_context)

    assert metadata.date == "2026-02-09 12:00:00"
    assert metadata.source_platform == "SQL Server"
    assert metadata.source_connection == "source_db"
    assert metadata.target_platform == "Snowflake"
    assert metadata.target_connection == "target_db"
    assert metadata.execution_id == "test-run-456"


def test_from_context_formats_date():
    """Test that from_context formats the date correctly."""
    mock_context = MagicMock()
    mock_context.run_start_time = "20251231T235959"
    mock_context.run_id = "run-id"
    mock_context.source_platform.value = "SQL Server"
    mock_context.target_platform.value = "Snowflake"
    mock_context.configuration.source_connection.get_connection_identifier.return_value = (
        "src"
    )
    mock_context.configuration.target_connection.get_connection_identifier.return_value = (
        "tgt"
    )

    metadata = ReportMetadata.from_context(mock_context)

    assert metadata.date == "2025-12-31 23:59:59"
