# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for _escape_odbc_value in ConnectorSqlServer."""

import pytest

from snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server import (
    SQLSERVER_CONNECTION_STRING,
    _escape_odbc_value,
)


class TestEscapeOdbcValue:
    """Tests for _escape_odbc_value ODBC connection string escaping."""

    def test_plain_password(self):
        assert _escape_odbc_value("SimplePass1!") == "{SimplePass1!}"

    def test_semicolon(self):
        assert _escape_odbc_value("Semi;Colon123@") == "{Semi;Colon123@}"

    def test_opening_brace_at_start(self):
        assert _escape_odbc_value("{StartBrace1!") == "{{StartBrace1!}"

    def test_closing_brace_doubled(self):
        assert _escape_odbc_value("Pass}word1!") == "{Pass}}word1!}"

    def test_both_braces(self):
        assert _escape_odbc_value("a{b}c") == "{a{b}}c}"

    def test_semicolon_and_braces(self):
        assert _escape_odbc_value("Semi;{Colon}123@") == "{Semi;{Colon}}123@}"

    def test_multiple_semicolons(self):
        assert _escape_odbc_value("a;b;c;d") == "{a;b;c;d}"

    def test_multiple_closing_braces(self):
        assert _escape_odbc_value("a}}b") == "{a}}}}b}"

    def test_empty_string(self):
        assert _escape_odbc_value("") == "{}"

    @pytest.mark.parametrize(
        "char",
        ["=", " ", "\\", "'", '"', "%", "&", "@", "#", "]", "["],
    )
    def test_non_special_chars_safe(self, char):
        pwd = f"Pass{char}word1!"
        result = _escape_odbc_value(pwd)
        assert result == "{" + pwd + "}"


class TestEscapedPasswordInConnectionString:
    """Verify escaped passwords produce valid ODBC connection strings."""

    PARAMS = dict(
        driver="ODBC Driver 18 for SQL Server",
        server="127.0.0.1",
        port=1433,
        database="testdb",
        user="sa",
        trust_server_certificate="yes",
        encrypt="yes",
    )

    def test_semicolon_not_split(self):
        safe = _escape_odbc_value("Semi;Colon123@")
        conn_str = SQLSERVER_CONNECTION_STRING.format(password=safe, **self.PARAMS)
        assert "PWD={Semi;Colon123@};" in conn_str
        assert "Encrypt=yes" in conn_str

    def test_brace_at_start_not_misinterpreted(self):
        safe = _escape_odbc_value("{StartBrace1!")
        conn_str = SQLSERVER_CONNECTION_STRING.format(password=safe, **self.PARAMS)
        assert "PWD={{StartBrace1!};" in conn_str

    def test_plain_password_in_connection_string(self):
        safe = _escape_odbc_value("NormalPass1!")
        conn_str = SQLSERVER_CONNECTION_STRING.format(password=safe, **self.PARAMS)
        assert "PWD={NormalPass1!};" in conn_str
        assert "UID=sa;" in conn_str
