# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for get_configuration_file function."""

import tempfile
from unittest.mock import Mock, patch

import pytest

from snowflake.snowflake_data_validation.public import (
    DataValidationExceptionError,
    get_configuration_file,
    Platform,
)


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_get_configuration_file_without_query_templates(mock_factory):
    """Test exporting configuration files without query templates."""
    mock_args_manager = Mock()
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        get_configuration_file(
            templates_directory=temp_dir,
            include_query_templates=False,
            platform=Platform.SNOWFLAKE,
        )

    mock_factory.create.assert_called_once_with(Platform.SNOWFLAKE)
    mock_args_manager.dump_and_write_yaml_templates.assert_called_once_with(
        source=Platform.SNOWFLAKE.value,
        templates_directory=temp_dir,
        query_templates=False,
    )


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_get_configuration_file_with_query_templates(mock_factory):
    """Test exporting configuration files with query templates."""
    mock_args_manager = Mock()
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        get_configuration_file(
            templates_directory=temp_dir,
            include_query_templates=True,
            platform=Platform.SQLSERVER,
        )

    mock_factory.create.assert_called_once_with(Platform.SQLSERVER)
    mock_args_manager.dump_and_write_yaml_templates.assert_called_once_with(
        source=Platform.SQLSERVER.value,
        templates_directory=temp_dir,
        query_templates=True,
    )


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_get_configuration_file_teradata_platform(mock_factory):
    """Test exporting configuration files for Teradata platform."""
    mock_args_manager = Mock()
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        get_configuration_file(
            templates_directory=temp_dir,
            include_query_templates=False,
            platform=Platform.TERADATA,
        )

    mock_factory.create.assert_called_once_with(Platform.TERADATA)
    mock_args_manager.dump_and_write_yaml_templates.assert_called_once_with(
        source=Platform.TERADATA.value,
        templates_directory=temp_dir,
        query_templates=False,
    )


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_get_configuration_file_redshift_platform(mock_factory):
    """Test exporting configuration files for Redshift platform."""
    mock_args_manager = Mock()
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        get_configuration_file(
            templates_directory=temp_dir,
            include_query_templates=True,
            platform=Platform.REDSHIFT,
        )

    mock_factory.create.assert_called_once_with(Platform.REDSHIFT)
    mock_args_manager.dump_and_write_yaml_templates.assert_called_once_with(
        source=Platform.REDSHIFT.value,
        templates_directory=temp_dir,
        query_templates=True,
    )


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_get_configuration_file_result_set_platform(mock_factory):
    """Test exporting configuration files for Result Set platform."""
    mock_args_manager = Mock()
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        get_configuration_file(
            templates_directory=temp_dir,
            include_query_templates=True,
            platform=Platform.RESULT_SET,
        )

    mock_factory.create.assert_called_once_with(Platform.RESULT_SET)
    mock_args_manager.dump_and_write_yaml_templates.assert_called_once_with(
        source=Platform.RESULT_SET.value,
        templates_directory=temp_dir,
        query_templates=True,
    )


def test_raises_error_when_directory_does_not_exist():
    """Test that error is raised when templates directory doesn't exist."""
    non_existent_directory = "/non/existent/directory/path"

    with pytest.raises(DataValidationExceptionError) as exc_info:
        get_configuration_file(
            templates_directory=non_existent_directory,
            include_query_templates=False,
            platform=Platform.SNOWFLAKE,
        )

    assert "does not exist" in str(exc_info.value)


@patch("snowflake.snowflake_data_validation.public.data_validation_api.os.access")
def test_raises_error_when_directory_not_writable(mock_access):
    """Test that error is raised when templates directory is not writable."""
    mock_access.return_value = False

    with tempfile.TemporaryDirectory() as temp_dir:
        with pytest.raises(DataValidationExceptionError) as exc_info:
            get_configuration_file(
                templates_directory=temp_dir,
                include_query_templates=False,
                platform=Platform.SNOWFLAKE,
            )

    assert "not writable" in str(exc_info.value)


@patch(
    "snowflake.snowflake_data_validation.public.data_validation_api.ArgumentsManagerFactory"
)
def test_raises_error_when_dump_templates_fails(mock_factory):
    """Test that error is raised when dump_and_write_yaml_templates fails."""
    mock_args_manager = Mock()
    mock_args_manager.dump_and_write_yaml_templates.side_effect = Exception(
        "Template dump failed"
    )
    mock_factory.create.return_value = mock_args_manager

    with tempfile.TemporaryDirectory() as temp_dir:
        with pytest.raises(DataValidationExceptionError) as exc_info:
            get_configuration_file(
                templates_directory=temp_dir,
                include_query_templates=False,
                platform=Platform.SNOWFLAKE,
            )

    assert "Template dump failed" in str(exc_info.value)
