# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from ruamel.yaml import YAML

from snowflake.snowflake_data_validation.utils.configuration_file_synchronizer import (
    sync_configuration_file,
)
from snowflake.snowflake_data_validation.utils.constants import (
    METRICS_VALIDATION_STATUS,
    ROW_VALIDATION_STATUS,
    SCHEMA_VALIDATION_STATUS,
    Result,
)


SAMPLE_CONFIG = """\
source_platform: SQL server
target_platform: Snowflake
target_database: test_db

tables:
  - fully_qualified_name: db.schema.table1
  - fully_qualified_name: db.schema.table2
"""

SAMPLE_CONFIG_WITH_VIEWS = """\
source_platform: SQL server
target_platform: Snowflake
target_database: test_db

tables:
  - fully_qualified_name: db.schema.table1
  - fully_qualified_name: db.schema.table2

views:
  - fully_qualified_name: db.schema.view1
  - fully_qualified_name: db.schema.view2
"""

SAMPLE_EXECUTION_SUMMARY_NO_SUCCESS = f"""\
OBJECT_TYPE,OBJECT_NAME,{SCHEMA_VALIDATION_STATUS},{METRICS_VALIDATION_STATUS},{ROW_VALIDATION_STATUS}
table,db.schema.table1,{Result.FAILURE.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
table,db.schema.table2,{Result.SUCCESS.value},{Result.FAILURE.value},{Result.SUCCESS.value}
"""

SAMPLE_EXECUTION_SUMMARY_ONE_TABLE_SUCCESS = f"""\
OBJECT_TYPE,OBJECT_NAME,{SCHEMA_VALIDATION_STATUS},{METRICS_VALIDATION_STATUS},{ROW_VALIDATION_STATUS}
table,db.schema.table1,{Result.SUCCESS.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
table,db.schema.table2,{Result.SUCCESS.value},{Result.FAILURE.value},{Result.SUCCESS.value}
"""

SAMPLE_EXECUTION_SUMMARY_ALL_TABLES_SUCCESS = f"""\
OBJECT_TYPE,OBJECT_NAME,{SCHEMA_VALIDATION_STATUS},{METRICS_VALIDATION_STATUS},{ROW_VALIDATION_STATUS}
table,db.schema.table1,{Result.SUCCESS.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
table,db.schema.table2,{Result.SUCCESS.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
"""

SAMPLE_EXECUTION_SUMMARY_MIXED_SUCCESS = f"""\
OBJECT_TYPE,OBJECT_NAME,{SCHEMA_VALIDATION_STATUS},{METRICS_VALIDATION_STATUS},{ROW_VALIDATION_STATUS}
table,db.schema.table1,{Result.SUCCESS.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
table,db.schema.table2,{Result.SUCCESS.value},{Result.FAILURE.value},{Result.SUCCESS.value}
view,db.schema.view1,{Result.SUCCESS.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
view,db.schema.view2,{Result.FAILURE.value},{Result.SUCCESS.value},{Result.SUCCESS.value}
"""


@pytest.fixture
def temp_config_file(tmp_path):
    """Create a temporary configuration file for testing."""
    config_file = tmp_path / "test_config.yaml"
    config_file.write_text(SAMPLE_CONFIG)
    return str(config_file)


@pytest.fixture
def temp_execution_summary_no_success(tmp_path):
    """Create a temporary execution summary CSV with no full success statuses."""
    summary_file = tmp_path / "execution_summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_NO_SUCCESS)
    return str(summary_file)


def test_config_file_not_found(tmp_path):
    """Test that FileNotFoundError is raised for non-existent config file."""
    summary_file = tmp_path / "execution_summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_NO_SUCCESS)

    with pytest.raises(FileNotFoundError) as exc_info:
        sync_configuration_file("/non/existent/path.yaml", str(summary_file))

    assert "Configuration file not found" in str(exc_info.value)


def test_execution_summary_file_not_found(temp_config_file):
    """Test that FileNotFoundError is raised for non-existent execution summary file."""
    with pytest.raises(FileNotFoundError) as exc_info:
        sync_configuration_file(temp_config_file, "/non/existent/summary.csv")

    assert "Execution summary report file not found" in str(exc_info.value)


def test_no_objects_removed_when_no_full_success(tmp_path):
    """Test that config remains unchanged when no objects have full success."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text(SAMPLE_CONFIG)
    summary_file = tmp_path / "summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_NO_SUCCESS)

    sync_configuration_file(str(config_file), str(summary_file))

    yaml = YAML()
    with open(config_file, encoding="utf-8") as f:
        result = yaml.load(f)

    assert len(result["tables"]) == 2


def test_one_table_removed_on_success(tmp_path):
    """Test that a table is removed when it has full success status."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text(SAMPLE_CONFIG)
    summary_file = tmp_path / "summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_ONE_TABLE_SUCCESS)

    sync_configuration_file(str(config_file), str(summary_file))

    yaml = YAML()
    with open(config_file, encoding="utf-8") as f:
        result = yaml.load(f)

    assert len(result["tables"]) == 1
    assert result["tables"][0]["fully_qualified_name"] == "db.schema.table2"


def test_tables_section_removed_when_all_succeed(tmp_path):
    """Test that tables section is removed when all tables have full success."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text(SAMPLE_CONFIG)
    summary_file = tmp_path / "summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_ALL_TABLES_SUCCESS)

    sync_configuration_file(str(config_file), str(summary_file))

    yaml = YAML()
    with open(config_file, encoding="utf-8") as f:
        result = yaml.load(f)

    assert "tables" not in result


def test_mixed_tables_and_views_success(tmp_path):
    """Test sync with mixed tables and views where some succeed."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text(SAMPLE_CONFIG_WITH_VIEWS)
    summary_file = tmp_path / "summary.csv"
    summary_file.write_text(SAMPLE_EXECUTION_SUMMARY_MIXED_SUCCESS)

    sync_configuration_file(str(config_file), str(summary_file))

    yaml = YAML()
    with open(config_file, encoding="utf-8") as f:
        result = yaml.load(f)

    # table1 succeeded, table2 failed -> only table2 remains
    assert len(result["tables"]) == 1
    assert result["tables"][0]["fully_qualified_name"] == "db.schema.table2"
    # view1 succeeded, view2 failed -> only view2 remains
    assert len(result["views"]) == 1
    assert result["views"][0]["fully_qualified_name"] == "db.schema.view2"
