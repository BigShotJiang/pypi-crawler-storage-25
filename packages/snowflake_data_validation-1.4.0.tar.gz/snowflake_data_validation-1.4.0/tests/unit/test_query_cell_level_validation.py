import pandas as pd
import polars as pl
import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    query_cell_level_validation,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.utils.constants import (
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_ROW_KEY,
    DIFF_COL_SOURCE_VALUE_KEY,
    DIFF_COL_TARGET_VALUE_KEY,
)


def test_query_cell_level_validation_with_matching_data():
    dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=dataframe,
        second_dataframe=dataframe,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_query_cell_level_validation_with_unmatching_data():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [25, 50],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 2

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "QTY"
    assert result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY] == "10"
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "25"

    assert result.results_dataframe.iloc[1][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[1][DIFF_COL_COLUMN_KEY] == "QTY"
    assert result.results_dataframe.iloc[1][DIFF_COL_SOURCE_VALUE_KEY] == "20"
    assert result.results_dataframe.iloc[1][DIFF_COL_TARGET_VALUE_KEY] == "50"


def test_query_cell_level_validation_with_null_data_matching():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, None],
            "QTY": [None, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": [None, "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, None],
            "QTY": [None, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": [None, "2026-01-02"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_query_cell_level_validation_with_null_data_mismatching():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, None],
            "QTY": [None, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": [None, "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 3

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "ID"
    assert pd.isna(result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "2"

    assert result.results_dataframe.iloc[1][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[1][DIFF_COL_COLUMN_KEY] == "QTY"
    assert pd.isna(result.results_dataframe.iloc[1][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[1][DIFF_COL_TARGET_VALUE_KEY] == "10"

    assert result.results_dataframe.iloc[2][DIFF_COL_ROW_KEY] == 0
    assert result.results_dataframe.iloc[2][DIFF_COL_COLUMN_KEY] == "UPDATED_AT"
    assert pd.isna(result.results_dataframe.iloc[2][DIFF_COL_SOURCE_VALUE_KEY])
    assert result.results_dataframe.iloc[2][DIFF_COL_TARGET_VALUE_KEY] == "2026-01-01"


def test_query_cell_level_validation_with_different_row_counts():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2, 3],
            "QTY": [10, 20, 30],
            "NAME": ["Device A", "Device B", "Device C"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02", "2026-01-03"],
        }
    )

    with pytest.raises(DataValidationExceptionError) as exc_info:
        query_cell_level_validation(
            first_dataframe=first_dataframe,
            second_dataframe=second_dataframe,
        )

    assert "Dataframe dimensions mismatch" in str(exc_info.value)


def test_query_cell_level_validation_with_different_column_counts():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    with pytest.raises(DataValidationExceptionError) as exc_info:
        query_cell_level_validation(
            first_dataframe=first_dataframe,
            second_dataframe=second_dataframe,
        )

    assert "Dataframe dimensions mismatch" in str(exc_info.value)


def test_query_cell_level_validation_with_empty_dataframes():
    first_dataframe = pl.DataFrame()
    second_dataframe = pl.DataFrame()

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_query_cell_level_validation_with_multiple_column_differences():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "QTY": [10, 20],
            "NAME": ["Device A", "Device B"],
            "UPDATED_AT": ["2026-01-01", "2026-01-02"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [3, 4],
            "QTY": [30, 40],
            "NAME": ["Device C", "Device D"],
            "UPDATED_AT": ["2026-01-03", "2026-01-04"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 8


def test_query_cell_level_validation_with_float_data():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "PRICE": [10.5, 20.5],
            "NAME": ["Device A", "Device B"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "PRICE": [10.5, 25.5],
            "NAME": ["Device A", "Device B"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 1

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "PRICE"
    assert result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY] == "20.5"
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "25.5"


def test_query_cell_level_validation_with_boolean_data():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "IS_ACTIVE": [True, False],
            "NAME": ["Device A", "Device B"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1, 2],
            "IS_ACTIVE": [True, True],
            "NAME": ["Device A", "Device B"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 1

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 1
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "IS_ACTIVE"


def test_query_cell_level_validation_with_single_row():
    first_dataframe = pl.DataFrame(
        {
            "ID": [1],
            "QTY": [10],
            "NAME": ["Device A"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": [1],
            "QTY": [10],
            "NAME": ["Device A"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert result.results_dataframe.empty == True


def test_query_cell_level_validation_with_single_column():
    first_dataframe = pl.DataFrame(
        {
            "ID": ["a", "b", "c"],
        }
    )

    second_dataframe = pl.DataFrame(
        {
            "ID": ["a", "b", "d"],
        }
    )

    result = query_cell_level_validation(
        first_dataframe=first_dataframe,
        second_dataframe=second_dataframe,
    )

    assert result.is_valid == True
    assert len(result.results_dataframe) == 1

    assert result.results_dataframe.iloc[0][DIFF_COL_ROW_KEY] == 2
    assert result.results_dataframe.iloc[0][DIFF_COL_COLUMN_KEY] == "ID"
    assert result.results_dataframe.iloc[0][DIFF_COL_SOURCE_VALUE_KEY] == "c"
    assert result.results_dataframe.iloc[0][DIFF_COL_TARGET_VALUE_KEY] == "d"
