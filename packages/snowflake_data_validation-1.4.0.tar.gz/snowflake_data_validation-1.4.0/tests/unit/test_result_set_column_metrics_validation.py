import pytest

from snowflake.snowflake_data_validation.public.data_validation_api import (
    result_set_metrics_level_validation,
)
from snowflake.snowflake_data_validation.public.model.data_validation_exception import (
    DataValidationExceptionError,
)
from snowflake.snowflake_data_validation.public.model.result_set import ResultSet
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_VALIDATED,
    COLUMN_VALIDATED_KEY,
    EVALUATION_CRITERIA_KEY,
    STATUS_KEY,
    Result,
)


def test_result_set_metrics_validation_with_matching_data():
    result_set_data = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_mismatched_data():
    result_set_data_1 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 50, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 30, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True

    failed_rows = result.results_dataframe[
        result.results_dataframe[STATUS_KEY] == Result.FAILURE.value
    ]
    assert (failed_rows[COLUMN_VALIDATED_KEY] == "QTY").all()
    assert (
        failed_rows[EVALUATION_CRITERIA_KEY].isin(["AVG", "SUM", "MAX", "MIN"])
    ).all()


def test_result_set_metrics_validation_with_column_mappings():
    result_set_data_1 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QUANTITY": 10, "TITLE": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QUANTITY": 20, "TITLE": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_1_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_2_column_types = {
        "ID": "NUMBER",
        "QUANTITY": "NUMBER",
        "TITLE": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_1_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_2_column_types
    )

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
        column_mappings={"QTY": "QUANTITY", "NAME": "TITLE"},
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_special_characters_in_column_names():
    result_set_data = [
        {"ID@": 1, "(QTY)": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID@": 2, "(QTY)": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "ID@": "NUMBER",
        "(QTY)": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_various_data_types():
    result_set_data = [
        {
            "ID": 1,
            "QUANTITY": 10.5,
            "NAME": "Device A",
            "CREATED_AT": "2026-01-01 10:30:00",
            "IS_ACTIVE": True,
            "START_TIME": "10:30:00",
            "SHIP_DATE": "2026-01-15",
        },
        {
            "ID": 2,
            "QUANTITY": 20.75,
            "NAME": "Device B",
            "CREATED_AT": "2026-01-02 14:45:00",
            "IS_ACTIVE": False,
            "START_TIME": "14:45:00",
            "SHIP_DATE": "2026-01-16",
        },
    ]

    result_set_column_types = {
        "ID": "INT",  # INT -> pl.Int64
        "QUANTITY": "FLOAT",  # FLOAT -> pl.Float64
        "NAME": "STRING",  # STRING -> pl.Utf8
        "CREATED_AT": "DATETIME",  # DATETIME -> pl.Datetime
        "IS_ACTIVE": "BOOLEAN",  # BOOLEAN -> pl.Boolean
        "START_TIME": "TIME",  # TIME -> pl.Time
        "SHIP_DATE": "DATE",  # DATE -> pl.Date
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_null_data():
    result_set_data = [
        {"id": 1, "QTY": None, "NAME": "Device A", "UPDATED_AT": None},
        {"id": None, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_column_types = {
        "id": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_tolerance_on_numeric_columns():
    result_set_data_1 = [
        {
            "ID": 1,
            "QTY": 3.14159,
        },
        {
            "ID": 2,
            "QTY": 67.3451042454,
        },
        {
            "ID": 3,
            "QTY": 3.0114899,
        },
        {
            "ID": 4,
            "QTY": 28.12670001,
        },
    ]

    result_set_data_2 = [
        {
            "ID": 1,
            "QTY": 4.14159,
        },
        {
            "ID": 2,
            "QTY": 68.3451042454,
        },
        {
            "ID": 3,
            "QTY": 4.0114899,
        },
        {
            "ID": 4,
            "QTY": 29.12670001,
        },
    ]

    result_set_column_types = {
        "ID": "INTEGER",
        "QTY": "FLOAT",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_metrics_level_validation(
        result_set_1, result_set_2, tolerance=10.0
    )

    assert result.is_valid == True
    assert (result.results_dataframe[STATUS_KEY] == Result.SUCCESS.value).all()


def test_result_set_metrics_validation_with_different_row_counts():
    result_set_data_1 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
        {"ID": 3, "QTY": 30, "NAME": "Device C", "UPDATED_AT": "2026-01-03"},
    ]

    result_set_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_column_types
    )

    result = result_set_metrics_level_validation(
        result_set_1,
        result_set_2,
    )

    assert result.is_valid == True
    failed_rows = result.results_dataframe[
        result.results_dataframe[STATUS_KEY] == Result.FAILURE.value
    ]
    assert (
        failed_rows[COLUMN_VALIDATED_KEY].isin(["ID", "QTY", "NAME", "UPDATED_AT"])
    ).all()


def test_result_set_metrics_validation_with_different_column_counts():
    result_set_data_1 = [
        {"ID": 1, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_data_2 = [
        {"ID": 1, "QTY": 10, "NAME": "Device A", "UPDATED_AT": "2026-01-01"},
        {"ID": 2, "QTY": 20, "NAME": "Device B", "UPDATED_AT": "2026-01-02"},
    ]

    result_set_1_column_types = {
        "ID": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_2_column_types = {
        "ID": "NUMBER",
        "QTY": "NUMBER",
        "NAME": "VARCHAR",
        "UPDATED_AT": "DATE",
    }

    result_set_1 = ResultSet(
        rows=result_set_data_1, column_types=result_set_1_column_types
    )

    result_set_2 = ResultSet(
        rows=result_set_data_2, column_types=result_set_2_column_types
    )

    with pytest.raises(DataValidationExceptionError) as exc_info:
        result_set_metrics_level_validation(
            result_set_1,
            result_set_2,
        )

    assert (
        str(exc_info.value)
        == "[result_set] failed for object: result set metrics level comparison (ID: 1). Error: The two result sets have different number of columns."
    )


def test_result_set_metrics_validation_with_empty_result_sets():
    result_set_data = [{}]

    result_set_column_types = {}

    result_set_1 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    result_set_2 = ResultSet(rows=result_set_data, column_types=result_set_column_types)

    with pytest.raises(DataValidationExceptionError) as exc_info:
        result_set_metrics_level_validation(
            result_set_1,
            result_set_2,
        )

    assert (
        str(exc_info.value)
        == "[result_set] failed for object: result set metrics level comparison (ID: 1). Error: Metrics templates are missing for the column data types in ResultSet."
    )
