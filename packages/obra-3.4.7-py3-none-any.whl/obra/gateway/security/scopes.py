"""Gateway scope taxonomy and enforcement helpers."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from enum import StrEnum
from typing import Callable

from fastapi import HTTPException, Request, status

from obra.gateway.security.client_ip import extract_client_ip_from_request

logger = logging.getLogger("obra.gateway.security.events")


class GatewayScope(StrEnum):
    """Minimal gateway authorization scopes."""

    READ = "read"
    OPERATE = "operate"
    ADMIN = "admin"


SCOPE_HIERARCHY: dict[str, frozenset[str]] = {
    GatewayScope.ADMIN.value: frozenset(
        {
            GatewayScope.READ.value,
            GatewayScope.OPERATE.value,
            GatewayScope.ADMIN.value,
        }
    ),
    GatewayScope.OPERATE.value: frozenset(
        {
            GatewayScope.READ.value,
            GatewayScope.OPERATE.value,
        }
    ),
    GatewayScope.READ.value: frozenset({GatewayScope.READ.value}),
}


def resolve_scopes(scope_names: list[str]) -> frozenset[str]:
    """Expand configured scope names through the scope hierarchy."""

    resolved: set[str] = set()
    for raw_scope in scope_names:
        normalized = str(raw_scope or "").strip().lower()
        if normalized not in SCOPE_HIERARCHY:
            raise ValueError(f"Unsupported gateway scope: {raw_scope}")
        resolved.update(SCOPE_HIERARCHY[normalized])
    return frozenset(resolved)


def insufficient_scope_detail(scope: GatewayScope) -> dict[str, str]:
    """Return the canonical insufficient-scope error envelope."""

    return {
        "error_code": "insufficient_scope",
        "message": f"Required scope: {scope.value}",
        "hint": f"Request a token with '{scope.value}' scope",
    }


def has_scope(request: Request, scope: GatewayScope) -> bool:
    """Return True when request state includes the required scope."""

    configured_scopes = getattr(request.state, "gateway_scopes", frozenset())
    if not isinstance(configured_scopes, frozenset):
        configured_scopes = frozenset(configured_scopes or [])
    return scope.value in configured_scopes


def require_scope(scope: GatewayScope) -> Callable:
    """Build a FastAPI dependency that enforces the required gateway scope."""

    async def _dependency(request: Request) -> None:
        if has_scope(request, scope):
            return
        _log_scope_violation(request, scope)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=insufficient_scope_detail(scope),
        )

    return _dependency


def _log_scope_violation(request: Request, scope: GatewayScope) -> None:
    trusted_proxy_cidrs = list(getattr(request.app.state, "trusted_proxy_cidrs", []))
    payload = {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "event_type": "scope_violation",
        "client_ip": extract_client_ip_from_request(request, trusted_proxy_cidrs),
        "token_label": str(getattr(request.state, "gateway_token_label", "")),
        "scopes": sorted(str(item) for item in getattr(request.state, "gateway_scopes", frozenset())),
        "required_scope": scope.value,
        "method": request.method,
        "path": request.url.path,
        "outcome": "denied",
    }
    logger.warning(json.dumps(payload, sort_keys=True))
