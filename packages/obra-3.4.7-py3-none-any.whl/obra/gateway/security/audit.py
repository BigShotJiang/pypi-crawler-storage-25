"""Gateway security posture audit helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from obra.gateway.automation.profile import (
    GATEWAY_PROFILE_PRIVATE_TAILNET,
    GATEWAY_PROFILE_STANDARD,
    resolve_gateway_automation_profile,
)
from obra.gateway.server import _is_loopback_host, _is_private_or_tailscale_host

_SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2}
_MIN_RECOMMENDED_TOKEN_LENGTH = 24
_INFO_SESSION_TIMEOUT_THRESHOLD_S = 14_400
_INFO_MAX_SESSIONS_THRESHOLD = 10


@dataclass(frozen=True)
class AuditFinding:
    """One gateway security posture finding."""

    severity: str
    code: str
    message: str
    hint: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


def run_security_audit(config: dict[str, Any]) -> list[AuditFinding]:
    """Evaluate effective gateway posture using the runtime gateway contract."""

    findings: list[AuditFinding] = []
    profile = resolve_gateway_automation_profile(config)
    host = str(config["host"]).strip()
    auth_token = str(config.get("auth_token") or "").strip()
    auth_tokens = list(config.get("auth_tokens") or [])
    allow_public_bind = bool(config.get("allow_public_bind", False))
    tls_acknowledged = bool(config.get("public_bind_tls_terminated", False))
    cors_origins = [str(origin) for origin in config.get("cors_origins", [])]
    enable_cors = bool(config.get("enable_cors", False))
    enable_app_rate_limit = bool(config.get("enable_app_rate_limit", True))
    session_timeout_s = int(config.get("session_timeout_s", 7200))
    max_sessions = int(config.get("max_sessions", 5))

    if profile.private_only and not _is_loopback_host(host):
        findings.append(
            AuditFinding(
                severity="critical",
                code="private_profile_non_loopback_bind",
                message="private_automation profile may only bind to loopback addresses.",
                hint="Bind to 127.0.0.1 or localhost and use SSH tunnels/private overlays.",
                metadata={"host": host, "profile": profile.name},
            )
        )
    elif profile.name == GATEWAY_PROFILE_PRIVATE_TAILNET and not _is_private_or_tailscale_host(
        host
    ):
        findings.append(
            AuditFinding(
                severity="critical",
                code="tailnet_profile_public_bind",
                message=(
                    "private_tailnet profile requires a loopback, RFC1918 private, "
                    "or Tailscale address."
                ),
                hint="Use a private LAN or Tailscale address instead of a public bind.",
                metadata={"host": host, "profile": profile.name},
            )
        )
    elif (
        profile.name == GATEWAY_PROFILE_STANDARD
        and not _is_loopback_host(host)
        and not allow_public_bind
    ):
        findings.append(
            AuditFinding(
                severity="critical",
                code="public_bind_not_acknowledged",
                message="Non-loopback standard-profile binds require allow_public_bind=true.",
                hint=(
                    "Enable gateway.allow_public_bind only behind TLS-terminating edge "
                    "infrastructure."
                ),
                metadata={"host": host, "profile": profile.name},
            )
        )
    elif (
        profile.name == GATEWAY_PROFILE_STANDARD
        and not _is_loopback_host(host)
        and allow_public_bind
        and not tls_acknowledged
    ):
        findings.append(
            AuditFinding(
                severity="critical",
                code="public_bind_missing_tls_ack",
                message="Public bind is enabled without TLS termination acknowledgement.",
                hint=(
                    "Set gateway.public_bind_tls_terminated=true only when a trusted reverse "
                    "proxy or WAF terminates TLS."
                ),
                metadata={"host": host, "profile": profile.name},
            )
        )

    if profile.require_explicit_auth_token and not auth_token and not auth_tokens:
        findings.append(
            AuditFinding(
                severity="critical",
                code="missing_explicit_auth_token",
                message="This gateway profile requires an explicit auth token or auth_tokens entry.",
                hint="Set gateway.auth_token or gateway.auth_tokens before exposing the gateway.",
                metadata={"profile": profile.name},
            )
        )
    elif profile.name == GATEWAY_PROFILE_STANDARD and not auth_token and not auth_tokens:
        findings.append(
            AuditFinding(
                severity="warning",
                code="standard_profile_auto_generated_token",
                message="Standard profile will auto-generate a gateway token at startup.",
                hint="Set gateway.auth_token or gateway.auth_tokens to keep a stable operator token.",
                metadata={"profile": profile.name},
            )
        )

    _append_token_strength_findings(findings, auth_token, auth_tokens)

    if enable_cors and "*" in cors_origins:
        findings.append(
            AuditFinding(
                severity="warning",
                code="wildcard_cors_origin",
                message="Gateway CORS origins include '*'.",
                hint="Restrict gateway.cors_origins to the specific operator origins that need access.",
                metadata={"cors_origins": cors_origins},
            )
        )

    if not enable_app_rate_limit:
        findings.append(
            AuditFinding(
                severity="warning",
                code="app_rate_limit_disabled",
                message="Gateway application rate limiting is disabled.",
                hint="Enable gateway.enable_app_rate_limit before remote exposure.",
            )
        )

    if session_timeout_s > _INFO_SESSION_TIMEOUT_THRESHOLD_S:
        findings.append(
            AuditFinding(
                severity="info",
                code="high_session_timeout",
                message=(
                    f"Gateway session timeout is {session_timeout_s}s, above the "
                    f"{_INFO_SESSION_TIMEOUT_THRESHOLD_S}s review threshold."
                ),
            )
        )

    if max_sessions > _INFO_MAX_SESSIONS_THRESHOLD:
        findings.append(
            AuditFinding(
                severity="info",
                code="high_max_sessions",
                message=(
                    f"Gateway max_sessions is {max_sessions}, above the "
                    f"{_INFO_MAX_SESSIONS_THRESHOLD} session review threshold."
                ),
            )
        )

    return sorted(
        findings,
        key=lambda finding: (_SEVERITY_ORDER.get(finding.severity, 99), finding.code),
    )


def _append_token_strength_findings(
    findings: list[AuditFinding],
    auth_token: str,
    auth_tokens: list[dict[str, Any]],
) -> None:
    if auth_token and len(auth_token) < _MIN_RECOMMENDED_TOKEN_LENGTH:
        findings.append(
            AuditFinding(
                severity="warning",
                code="weak_primary_auth_token",
                message=(
                    f"Primary gateway auth_token is shorter than {_MIN_RECOMMENDED_TOKEN_LENGTH} "
                    "characters."
                ),
                hint="Use a longer random bearer token for remote access.",
                metadata={"token_label": "primary"},
            )
        )

    for entry in auth_tokens:
        token = str(entry.get("token") or "")
        if token and len(token) < _MIN_RECOMMENDED_TOKEN_LENGTH:
            findings.append(
                AuditFinding(
                    severity="warning",
                    code="weak_registry_auth_token",
                    message=(
                        "One registry auth token is shorter than "
                        f"{_MIN_RECOMMENDED_TOKEN_LENGTH} characters."
                    ),
                    hint="Use longer random values for gateway.auth_tokens entries.",
                    metadata={
                        "token_label": str(entry.get("label") or "registry-token"),
                        "scopes": list(entry.get("scopes") or []),
                    },
                )
            )
