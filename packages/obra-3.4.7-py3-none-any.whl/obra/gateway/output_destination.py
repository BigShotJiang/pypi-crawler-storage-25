"""Output-destination request schema and validation helpers."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from obra.gateway.webhook.model import validate_callback_url
from obra.security.url_validator import validate_outbound_url


class OutputDestination(BaseModel):
    """Destination that receives workflow-run outputs on terminal completion."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["webhook", "http_push"]
    url: str = Field(..., min_length=1)
    headers: dict[str, str] = Field(default_factory=dict)
    secret: str | None = None

    @field_validator("url")
    @classmethod
    def _validate_url(cls, value: str) -> str:
        validate_callback_url(value, allow_private_networks=True)
        # Block link-local / metadata endpoints even with private networks
        # allowed.  Cloud metadata (169.254.169.254) is never a valid output
        # destination.
        validate_outbound_url(value, allow_loopback=True, allow_private=True)
        return value

    @field_validator("headers", mode="before")
    @classmethod
    def _normalize_headers(cls, value: Any) -> dict[str, str]:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise ValueError("headers must be a mapping of strings")
        normalized: dict[str, str] = {}
        for key, item in value.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError("headers must use non-empty string keys")
            if not isinstance(item, str):
                raise ValueError("headers must use string values")
            normalized[key.strip()] = item
        return normalized

    @field_validator("secret", mode="before")
    @classmethod
    def _normalize_secret(cls, value: Any) -> str | None:
        if value is None:
            return None
        if not isinstance(value, str):
            raise ValueError("secret must be a string")
        normalized = value.strip()
        return normalized or None
