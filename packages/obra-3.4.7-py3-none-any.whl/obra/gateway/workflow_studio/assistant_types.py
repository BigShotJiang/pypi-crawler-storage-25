"""Shared assistant response types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class AssistantLlmResponse:
    """Normalized assistant generation result."""

    message: str
    outcome: str = "advice"
    action_records: list[dict[str, Any]] | None = None
    suggested_actions: list[str] | None = None
