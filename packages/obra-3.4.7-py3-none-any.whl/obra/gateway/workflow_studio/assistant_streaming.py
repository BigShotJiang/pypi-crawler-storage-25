"""Streamed assistant response generator (SSE)."""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, AsyncIterator

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.workflow_studio.assistant_llm import call_assistant_llm
from obra.gateway.workflow_studio.assistant_repository import (
    AssistantRepository,
    AssistantThread,
    AssistantTurn,
)
from obra.gateway.workflow_studio.assistant_stub_responses import match_stub_response

if TYPE_CHECKING:
    from obra.gateway.workflow_studio.assistant_session_logger import AssistantSessionLogger


def _sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


async def stream_assistant_response(
    thread: AssistantThread,
    user_turn: AssistantTurn,
    resolved_context: dict[str, Any],
    repository: AssistantRepository,
    *,
    system_prompt: str | None = None,
    app_state: Any | None = None,
    session_logger: AssistantSessionLogger | None = None,
    assistant_turn_context: dict[str, Any] | None = None,
) -> AsyncIterator[str]:
    """Yield SSE events for a streamed assistant response."""
    turn_id = user_turn.turn_id
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    auto_review_min_stage_count = int(pipeline_config.get("self_review_auto_min_stage_count", 5))

    try:
        # Emit session_info as the very first event
        if thread.session_id is not None:
            yield _sse("session_info", {"session_id": thread.session_id})

        yield _sse("status", {"phase": "resolving_context", "turn_id": turn_id})

        strategy = "contextual"
        if isinstance(resolved_context.get("strategies"), list) and resolved_context["strategies"]:
            strategy = resolved_context["strategies"][0]

        # Emit context manifest for transparency
        manifest = resolved_context.get("context_manifest")
        if manifest is not None:
            manifest_dict = manifest.to_dict() if hasattr(manifest, "to_dict") else manifest
            yield _sse("context_manifest", manifest_dict)

        yield _sse("status", {"phase": "generating", "turn_id": turn_id, "strategy": strategy})

        model_id = resolved_context.get("model_id")

        # Stub fallback: return deterministic responses without calling the LLM.
        # Enabled by OBRA_GATEWAY_ASSISTANT_STUB_FALLBACK=true (browser-rig default).
        stub = match_stub_response(user_turn.message, resolved_context)
        if stub is not None:
            full_message = stub.message
            llm_outcome = stub.outcome
            llm_action_records = stub.action_records
            llm_suggested_actions = stub.suggested_actions
        else:
            # Log LLM request
            t0 = time.perf_counter()
            if session_logger is not None:
                session_logger.log_event(
                    "asst.llm_request",
                    turn_id=turn_id,
                    model_id=model_id,
                    safety_mode=thread.safety_mode,
                    user_message_length=len(user_turn.message),
                    system_prompt_length=len(system_prompt or ""),
                )

            llm_response = await call_assistant_llm(
                system_prompt or "You are the Studio Assistant for Obra Workflow Studio.",
                user_turn.message,
                app_state=app_state,
                resolved_context=resolved_context,
                model_id=model_id,
            )
            full_message = llm_response.message
            llm_outcome = llm_response.outcome
            llm_action_records = llm_response.action_records
            llm_suggested_actions = llm_response.suggested_actions
            if not full_message.strip():
                raise RuntimeError("assistant returned empty content")

        # Log LLM/stub response
        if stub is None:
            duration_ms = int((time.perf_counter() - t0) * 1000)
            if session_logger is not None:
                session_logger.log_event(
                    "asst.llm_response",
                    turn_id=turn_id,
                    response_length=len(full_message),
                    outcome=llm_outcome,
                    action_count=len(llm_action_records or []),
                    duration_ms=duration_ms,
                )
        elif session_logger is not None:
            session_logger.log_event(
                "asst.stub_response",
                turn_id=turn_id,
                response_length=len(full_message),
                outcome=llm_outcome,
                action_count=len(llm_action_records or []),
            )

        chunk_size = 40
        for i in range(0, len(full_message), chunk_size):
            chunk = full_message[i : i + chunk_size]
            yield _sse("token", {"text": chunk})
            await asyncio.sleep(0)

        assistant_turn = repository.append_turn(
            thread.thread_id,
            role="assistant",
            message=full_message,
            context=assistant_turn_context,
            outcome=llm_outcome,
            action_records=llm_action_records,
            metadata={"suggested_actions": llm_suggested_actions} if llm_suggested_actions else None,
        )

        captured_scaffold_definition: dict[str, Any] | None = None
        for record in llm_action_records or []:
            if str(record.get("action_id") or "") != "execute_draft_workflow_from_thread":
                continue
            action_inputs = record.get("action_inputs")
            action_inputs = action_inputs if isinstance(action_inputs, dict) else {}
            scaffold_definition = action_inputs.get("scaffold_definition")
            if not isinstance(scaffold_definition, dict):
                continue
            captured_scaffold_definition = scaffold_definition
            current_context = repository.get_construction_context(thread.thread_id) or {}
            turn_ids = current_context.get("persisted_assistant_turn_ids")
            if not isinstance(turn_ids, list):
                turn_ids = current_context.get("construction_turn_ids")
            persisted_turn_ids = (
                [str(item) for item in turn_ids] if isinstance(turn_ids, list) else []
            )
            if assistant_turn.turn_id not in persisted_turn_ids:
                persisted_turn_ids.append(assistant_turn.turn_id)
            refinement_count = int(current_context.get("refinement_count") or 0)
            if isinstance(current_context.get("scaffold_draft"), dict):
                refinement_count += 1
            repository.update_construction_context(
                thread.thread_id,
                {
                    "scaffold_draft": scaffold_definition,
                    "persisted_assistant_turn_ids": persisted_turn_ids,
                    "refinement_count": refinement_count,
                },
            )
            break

        if isinstance(captured_scaffold_definition, dict):
            stages = captured_scaffold_definition.get("stages")
            if isinstance(stages, list) and len(stages) >= auto_review_min_stage_count:
                yield _sse(
                    "pipeline_auto_triggered",
                    {
                        "pipeline_id": "pipeline_self_review",
                        "workflow_context": captured_scaffold_definition,
                        "thread_id": thread.thread_id,
                        "turn_id": assistant_turn.turn_id,
                        "trigger_source": "system_auto",
                    },
                )

        # Log turn completed
        if session_logger is not None:
            session_logger.log_event(
                "asst.turn_completed",
                turn_id=assistant_turn.turn_id,
                role="assistant",
                message=full_message,
                outcome=llm_outcome,
                action_records=llm_action_records,
            )

        yield _sse(
            "done",
            {
                "turn": asdict(assistant_turn),
                "session_id": thread.session_id,
            },
        )

    except Exception as exc:
        # Log turn error
        if session_logger is not None:
            session_logger.log_event(
                "asst.turn_error",
                turn_id=turn_id,
                error_type=type(exc).__name__,
                error_detail=str(exc),
            )

        yield _sse(
            "error",
            {
                "error": "generation_failed",
                "detail": str(exc),
                "turn_id": turn_id,
            },
        )
