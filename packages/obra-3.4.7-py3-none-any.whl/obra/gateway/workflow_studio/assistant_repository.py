"""Durable assistant thread and turn repository."""

from __future__ import annotations

import json
import threading
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from fastapi import Request

from obra.config.loaders import get_gateway_assistant_config
from obra.utils.obra_home import get_runtime_dir

_UNSET = object()

AssistantTurnRole = Literal["user", "assistant", "system"]
AssistantTurnOutcome = Literal[
    "advice",
    "proposal",
    "applied",
    "partial",
    "conflict",
    "rejected",
    "reverted",
]


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _coerce_dict(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    return value if isinstance(value, dict) else None


def _coerce_records(value: Any) -> list[dict[str, Any]] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None
    return [item for item in value if isinstance(item, dict)]


@dataclass
class AssistantThread:
    """A named conversation thread in the assistant."""

    thread_id: str
    project_id: str
    name: str
    created_at: str
    updated_at: str
    archived: bool = False
    archived_at: str | None = None
    deleted: bool = False
    deleted_at: str | None = None
    safety_mode: str = "guided"
    turn_count: int = 0
    model_id: str | None = None
    session_id: str | None = None
    workflow_id: str | None = None
    current_route: str | None = None
    summary: str | None = None
    carried_forward_from_thread_id: str | None = None
    carry_forward_summary: str | None = None
    last_context: dict[str, Any] | None = None
    construction_context: dict[str, Any] | None = None


@dataclass
class AssistantTurn:
    """A single turn within a thread."""

    turn_id: str
    thread_id: str
    role: AssistantTurnRole
    message: str
    context: dict[str, Any] | None = None
    outcome: AssistantTurnOutcome | None = None
    action_records: list[dict[str, Any]] | None = None
    created_at: str = ""
    event_type: str | None = None
    event_title: str | None = None
    metadata: dict[str, Any] | None = None


@dataclass
class AssistantAuditPointer:
    """Persisted thread-history pointer for an executed action."""

    audit_id: str
    thread_id: str
    turn_id: str
    action_id: str | None
    checkpoint_id: str | None
    workflow_id: str | None
    record: dict[str, Any]


class AssistantRepository:
    """Durable local assistant thread and turn storage."""

    def __init__(
        self,
        *,
        storage_path: Path | None = None,
        retention_policy: dict[str, Any] | None = None,
    ) -> None:
        self._lock = threading.RLock()
        self._storage_path = storage_path or (get_runtime_dir() / "assistant" / "threads.json")
        self._retention_policy = dict(retention_policy or {})
        self._threads: dict[str, AssistantThread] = {}
        self._turns: dict[str, list[AssistantTurn]] = {}
        self._storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._load()

    @classmethod
    def from_request(cls, request: Request) -> AssistantRepository:
        """Extract or lazily create the repository from app state."""
        repo = getattr(request.app.state, "assistant_repository", None)
        if repo is not None:
            return repo

        assistant_config = get_gateway_assistant_config()
        gateway_config = getattr(request.app.state, "gateway_config", {}) or {}
        configured_path = gateway_config.get("assistant_storage_path")
        if configured_path:
            storage_path = Path(str(configured_path)).expanduser()
        else:
            relative_path = assistant_config["persistence_storage_path"]
            storage_path = get_runtime_dir() / relative_path

        repo = cls(
            storage_path=storage_path,
            retention_policy=assistant_config.get("retention"),
        )
        request.app.state.assistant_repository = repo
        return repo

    def _load(self) -> None:
        with self._lock:
            if not self._storage_path.exists():
                self._save_locked()
                return
            payload = json.loads(self._storage_path.read_text(encoding="utf-8") or "{}")
            raw_threads = payload.get("threads", {})
            raw_turns = payload.get("turns", {})
            if isinstance(raw_threads, dict):
                for thread_id, raw_thread in raw_threads.items():
                    if not isinstance(raw_thread, dict):
                        continue
                    self._threads[thread_id] = AssistantThread(
                        thread_id=str(raw_thread.get("thread_id") or thread_id),
                        project_id=str(raw_thread.get("project_id") or ""),
                        name=str(raw_thread.get("name") or "Untitled thread"),
                        created_at=str(raw_thread.get("created_at") or ""),
                        updated_at=str(
                            raw_thread.get("updated_at") or raw_thread.get("created_at") or ""
                        ),
                        archived=bool(raw_thread.get("archived", False)),
                        archived_at=raw_thread.get("archived_at"),
                        deleted=bool(raw_thread.get("deleted", False)),
                        deleted_at=raw_thread.get("deleted_at"),
                        safety_mode=str(raw_thread.get("safety_mode") or "guided"),
                        turn_count=int(raw_thread.get("turn_count") or 0),
                        model_id=raw_thread.get("model_id"),
                        session_id=raw_thread.get("session_id"),
                        workflow_id=raw_thread.get("workflow_id"),
                        current_route=raw_thread.get("current_route"),
                        summary=raw_thread.get("summary"),
                        carried_forward_from_thread_id=raw_thread.get(
                            "carried_forward_from_thread_id"
                        ),
                        carry_forward_summary=raw_thread.get("carry_forward_summary"),
                        last_context=_coerce_dict(raw_thread.get("last_context")),
                        construction_context=_coerce_dict(raw_thread.get("construction_context")),
                    )
            if isinstance(raw_turns, dict):
                for thread_id, entries in raw_turns.items():
                    if not isinstance(entries, list):
                        continue
                    turns: list[AssistantTurn] = []
                    for raw_turn in entries:
                        if not isinstance(raw_turn, dict):
                            continue
                        turns.append(
                            AssistantTurn(
                                turn_id=str(raw_turn.get("turn_id") or uuid4()),
                                thread_id=str(raw_turn.get("thread_id") or thread_id),
                                role=str(raw_turn.get("role") or "assistant"),  # type: ignore[arg-type]
                                message=str(raw_turn.get("message") or ""),
                                context=_coerce_dict(raw_turn.get("context")),
                                outcome=raw_turn.get("outcome"),  # type: ignore[arg-type]
                                action_records=_coerce_records(raw_turn.get("action_records")),
                                created_at=str(raw_turn.get("created_at") or ""),
                                event_type=raw_turn.get("event_type"),
                                event_title=raw_turn.get("event_title"),
                                metadata=_coerce_dict(raw_turn.get("metadata")),
                            )
                        )
                    self._turns[thread_id] = turns

    def _save_locked(self) -> None:
        payload = {
            "threads": {
                thread_id: asdict(thread)
                for thread_id, thread in sorted(self._threads.items(), key=lambda item: item[0])
            },
            "turns": {
                thread_id: [asdict(turn) for turn in turns]
                for thread_id, turns in sorted(self._turns.items(), key=lambda item: item[0])
            },
        }
        self._storage_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def _save(self) -> None:
        with self._lock:
            self._save_locked()

    def _touch_thread(self, thread: AssistantThread, *, when: str | None = None) -> None:
        thread.updated_at = when or _utc_now()

    def _recount_thread(self, thread_id: str) -> None:
        thread = self._threads.get(thread_id)
        if thread is None:
            return
        thread.turn_count = len(self._turns.get(thread_id, []))

    def _apply_retention_locked(self, project_id: str) -> None:
        max_active_threads = int(self._retention_policy.get("max_active_threads") or 0)
        archive_after_days = int(self._retention_policy.get("archive_after_days") or 0)
        delete_after_days = int(self._retention_policy.get("delete_after_days") or 0)
        now = datetime.now(tz=timezone.utc)

        active_threads = sorted(
            [
                thread
                for thread in self._threads.values()
                if thread.project_id == project_id and not thread.deleted and not thread.archived
            ],
            key=lambda thread: thread.updated_at,
            reverse=True,
        )
        if max_active_threads > 0:
            for thread in active_threads[max_active_threads:]:
                if thread.archived:
                    continue
                thread.archived = True
                thread.archived_at = thread.archived_at or _utc_now()
                thread.summary = thread.summary or self.build_thread_summary(thread.thread_id)
                self._touch_thread(thread)

        if archive_after_days > 0:
            cutoff = now - timedelta(days=archive_after_days)
            for thread in active_threads:
                updated_at = _parse_ts(thread.updated_at)
                if updated_at is None or updated_at > cutoff or thread.archived:
                    continue
                thread.archived = True
                thread.archived_at = thread.archived_at or _utc_now()
                thread.summary = thread.summary or self.build_thread_summary(thread.thread_id)
                self._touch_thread(thread)

        if delete_after_days > 0:
            delete_cutoff = now - timedelta(days=delete_after_days)
            for thread in self._threads.values():
                if thread.project_id != project_id or thread.deleted:
                    continue
                archived_at = _parse_ts(thread.archived_at or thread.updated_at)
                if not thread.archived or archived_at is None or archived_at > delete_cutoff:
                    continue
                thread.deleted = True
                thread.deleted_at = thread.deleted_at or _utc_now()
                self._touch_thread(thread)

    def create_thread(
        self,
        project_id: str,
        name: str,
        safety_mode: str = "guided",
        thread_id: str | None = None,
        *,
        workflow_id: str | None = None,
        current_route: str | None = None,
        summary: str | None = None,
        carried_forward_from_thread_id: str | None = None,
        carry_forward_summary: str | None = None,
        last_context: dict[str, Any] | None = None,
        construction_context: dict[str, Any] | None = None,
    ) -> AssistantThread:
        """Create a new conversation thread."""
        with self._lock:
            now = _utc_now()
            thread = AssistantThread(
                thread_id=thread_id or str(uuid4()),
                project_id=project_id,
                name=name,
                created_at=now,
                updated_at=now,
                safety_mode=safety_mode,
                workflow_id=workflow_id,
                current_route=current_route,
                summary=summary,
                carried_forward_from_thread_id=carried_forward_from_thread_id,
                carry_forward_summary=carry_forward_summary,
                last_context=last_context,
                construction_context=construction_context,
            )
            self._threads[thread.thread_id] = thread
            self._turns.setdefault(thread.thread_id, [])
            self._apply_retention_locked(project_id)
            self._save_locked()
            return thread

    def create_carry_forward_thread(
        self,
        *,
        project_id: str,
        name: str,
        source_thread_id: str,
        safety_mode: str = "guided",
        workflow_id: str | None = None,
        current_route: str | None = None,
    ) -> AssistantThread:
        """Create a new thread that explicitly carries forward one prior summary."""
        with self._lock:
            source = self.get_thread(source_thread_id)
            carry_forward_summary = self.build_thread_summary(source_thread_id)
            thread = self.create_thread(
                project_id=project_id,
                name=name,
                safety_mode=safety_mode,
                workflow_id=workflow_id or (source.workflow_id if source else None),
                current_route=current_route or (source.current_route if source else None),
                carried_forward_from_thread_id=source_thread_id,
                carry_forward_summary=carry_forward_summary,
                summary=carry_forward_summary,
                last_context=deepcopy(source.last_context) if source and source.last_context else None,
            )
            if source is not None and isinstance(source.construction_context, dict):
                self.update_thread(
                    thread.thread_id,
                    construction_context=deepcopy(source.construction_context),
                )
            self.append_turn(
                thread.thread_id,
                role="system",
                message=(
                    "Started a new thread with explicit carry-forward memory from an older thread.\n\n"
                    f"{carry_forward_summary}"
                ),
                context=None,
                event_type="carry_forward",
                event_title="Carry-forward memory imported",
                metadata={"source_thread_id": source_thread_id},
            )
            return thread

    def list_threads(
        self,
        project_id: str,
        archived: bool = False,
        *,
        search_query: str | None = None,
        include_deleted: bool = False,
    ) -> list[AssistantThread]:
        """List threads for a project."""
        with self._lock:
            self._apply_retention_locked(project_id)
            query = str(search_query or "").strip().lower()
            threads = [
                thread
                for thread in self._threads.values()
                if thread.project_id == project_id
                and thread.archived == archived
                and (include_deleted or not thread.deleted)
            ]
            if query:
                threads = [
                    thread
                    for thread in threads
                    if query in thread.name.lower()
                    or query in str(thread.summary or "").lower()
                    or query in str(thread.current_route or "").lower()
                    or query in str(thread.workflow_id or "").lower()
                ]
            return sorted(threads, key=lambda thread: thread.updated_at, reverse=True)

    def get_thread(
        self, thread_id: str, *, include_deleted: bool = False
    ) -> AssistantThread | None:
        """Return a thread by ID, or None if not found."""
        with self._lock:
            thread = self._threads.get(thread_id)
            if thread is None:
                return None
            if thread.deleted and not include_deleted:
                return None
            return thread

    def update_thread(
        self,
        thread_id: str,
        name: str | None = None,
        archived: bool | None = None,
        safety_mode: str | None = None,
        model_id: str | None | object = _UNSET,
        session_id: str | None | object = _UNSET,
        workflow_id: str | None | object = _UNSET,
        current_route: str | None | object = _UNSET,
        summary: str | None | object = _UNSET,
        last_context: dict[str, Any] | None | object = _UNSET,
        construction_context: dict[str, Any] | None | object = _UNSET,
        deleted: bool | None = None,
    ) -> AssistantThread | None:
        """Update mutable thread fields. Returns None if not found."""
        with self._lock:
            thread = self._threads.get(thread_id)
            if thread is None:
                return None
            if name is not None:
                thread.name = name
            if archived is not None:
                thread.archived = archived
                thread.archived_at = _utc_now() if archived else None
                if archived and not thread.summary:
                    thread.summary = self.build_thread_summary(thread_id)
            if deleted is not None:
                thread.deleted = deleted
                thread.deleted_at = _utc_now() if deleted else None
            if safety_mode is not None:
                thread.safety_mode = safety_mode
            if model_id is not _UNSET:
                thread.model_id = model_id
            if session_id is not _UNSET:
                thread.session_id = session_id
            if workflow_id is not _UNSET:
                thread.workflow_id = workflow_id
            if current_route is not _UNSET:
                thread.current_route = current_route
            if summary is not _UNSET:
                thread.summary = summary
            if last_context is not _UNSET:
                thread.last_context = last_context
            if construction_context is not _UNSET:
                thread.construction_context = construction_context
            self._touch_thread(thread)
            self._apply_retention_locked(thread.project_id)
            self._save_locked()
            return thread

    def update_construction_context(
        self,
        thread_id: str,
        context: dict[str, Any],
    ) -> None:
        """Persist construction context for a thread."""
        self.update_thread(thread_id, construction_context=context)

    def get_construction_context(self, thread_id: str) -> dict[str, Any] | None:
        """Return the persisted construction context for a thread, if any."""
        thread = self.get_thread(thread_id)
        if thread is None:
            return None
        value = thread.construction_context
        return dict(value) if isinstance(value, dict) else None

    def restore_thread(self, thread_id: str) -> AssistantThread | None:
        """Restore an archived thread."""
        return self.update_thread(thread_id, archived=False)

    def soft_delete_thread(self, thread_id: str) -> AssistantThread | None:
        """Soft-delete a thread."""
        thread = self.update_thread(thread_id, deleted=True)
        if thread is not None:
            thread.archived = False
            self._save()
        return thread

    def list_turns(self, thread_id: str) -> list[AssistantTurn]:
        """Return all turns for a thread."""
        with self._lock:
            return list(self._turns.get(thread_id, []))

    def get_turn(self, thread_id: str, turn_id: str) -> AssistantTurn | None:
        """Return one turn by id."""
        with self._lock:
            for turn in self._turns.get(thread_id, []):
                if turn.turn_id == turn_id:
                    return turn
            return None

    def update_turn(
        self,
        thread_id: str,
        turn_id: str,
        *,
        message: str | None = None,
        outcome: str | None = None,
        action_records: list[dict[str, Any]] | None = None,
        context: dict[str, Any] | None | object = _UNSET,
        metadata: dict[str, Any] | None | object = _UNSET,
    ) -> AssistantTurn | None:
        """Update mutable fields on an existing turn."""
        with self._lock:
            turn = self.get_turn(thread_id, turn_id)
            if turn is None:
                return None
            if message is not None:
                turn.message = message
            if outcome is not None:
                turn.outcome = outcome  # type: ignore[assignment]
            if action_records is not None:
                turn.action_records = action_records
            if context is not _UNSET:
                turn.context = context
            if metadata is not _UNSET:
                turn.metadata = metadata
            thread = self._threads.get(thread_id)
            if thread is not None:
                self._touch_thread(thread)
                thread.summary = thread.summary or self.build_thread_summary(thread_id)
            self._save_locked()
            return turn

    def append_turn(
        self,
        thread_id: str,
        role: str,
        message: str,
        context: dict[str, Any] | None = None,
        outcome: str | None = None,
        action_records: list[dict[str, Any]] | None = None,
        *,
        event_type: str | None = None,
        event_title: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AssistantTurn:
        """Append a turn to a thread and increment turn_count."""
        with self._lock:
            now = _utc_now()
            turn = AssistantTurn(
                turn_id=str(uuid4()),
                thread_id=thread_id,
                role=role,  # type: ignore[arg-type]
                message=message,
                context=context,
                outcome=outcome,  # type: ignore[arg-type]
                action_records=action_records,
                created_at=now,
                event_type=event_type,
                event_title=event_title,
                metadata=metadata,
            )
            self._turns.setdefault(thread_id, []).append(turn)
            thread = self._threads.get(thread_id)
            if thread is not None:
                self._recount_thread(thread_id)
                self._touch_thread(thread, when=now)
                thread.summary = self.build_thread_summary(thread_id)
            self._save_locked()
            return turn

    def build_thread_summary(self, thread_id: str) -> str:
        """Build a deterministic summary of a thread from stored turns."""
        turns = self._turns.get(thread_id, [])
        if not turns:
            return "Empty assistant thread."
        thread = self._threads.get(thread_id)

        user_turns = [turn for turn in turns if turn.role == "user"]
        assistant_turns = [turn for turn in turns if turn.role == "assistant"]
        system_turns = [turn for turn in turns if turn.role == "system"]
        latest_outcome = next(
            (turn.outcome for turn in reversed(assistant_turns) if turn.outcome), None
        )

        lines = [
            f"Turns: {len(turns)} total, {len(user_turns)} user, {len(assistant_turns)} assistant, {len(system_turns)} system.",
        ]
        if user_turns:
            lines.append(f"Started with: {user_turns[0].message[:180]}")
            lines.append(f"Most recent request: {user_turns[-1].message[:180]}")
        if latest_outcome:
            lines.append(f"Most recent assistant outcome: {latest_outcome}.")
        system_titles = [turn.event_title for turn in system_turns if turn.event_title]
        if system_titles:
            lines.append(f"System history: {', '.join(system_titles[-3:])}.")
        last_context = thread.last_context if thread is not None and isinstance(thread.last_context, dict) else {}
        readiness = (
            last_context.get("workflow_readiness")
            if isinstance(last_context.get("workflow_readiness"), dict)
            else None
        )
        if readiness is not None:
            phase = str(readiness.get("phase") or "").strip()
            completeness = readiness.get("overall_completeness")
            can_run = "yes" if bool(readiness.get("can_run")) else "no"
            has_seed = "yes" if bool(readiness.get("has_seed")) else "no"
            phase_line = f"Workflow phase: {phase or 'unknown'}"
            if isinstance(completeness, (int, float)):
                phase_line += f", completeness {float(completeness):.0%}"
            phase_line += f", can_run {can_run}, has_seed {has_seed}."
            lines.append(phase_line)
            suggested_next_action = str(readiness.get("suggested_next_action") or "").strip()
            if suggested_next_action:
                lines.append(f"Suggested next action: {suggested_next_action}")
        workflow_seed_summary = (
            last_context.get("workflow_seed_summary")
            if isinstance(last_context.get("workflow_seed_summary"), dict)
            else None
        )
        if workflow_seed_summary is not None:
            seed_intent = str(workflow_seed_summary.get("intent") or "").strip()
            if seed_intent:
                lines.append(f"Seed intent: {seed_intent}")
        construction_snapshot = (
            last_context.get("construction_context")
            if isinstance(last_context.get("construction_context"), dict)
            else None
        )
        if construction_snapshot is not None:
            refinement_count = int(construction_snapshot.get("refinement_count") or 0)
            has_scaffold_draft = bool(construction_snapshot.get("has_scaffold_draft"))
            lines.append(
                "Construction context: "
                f"has_scaffold_draft={str(has_scaffold_draft).lower()}, "
                f"refinement_count={refinement_count}."
            )
        return "\n".join(lines)

    def find_action_audit(self, audit_id: str) -> AssistantAuditPointer | None:
        """Find a persisted action record by audit identifier."""
        with self._lock:
            for thread_id, turns in self._turns.items():
                for turn in turns:
                    for record in turn.action_records or []:
                        if str(record.get("audit_id") or "") != audit_id:
                            continue
                        correlation = record.get("correlation")
                        correlation_dict = correlation if isinstance(correlation, dict) else {}
                        return AssistantAuditPointer(
                            audit_id=audit_id,
                            thread_id=thread_id,
                            turn_id=turn.turn_id,
                            action_id=str(
                                record.get("action_id") or record.get("action_type") or ""
                            )
                            or None,
                            checkpoint_id=(
                                str(correlation_dict.get("checkpoint_id") or "").strip() or None
                            ),
                            workflow_id=str(record.get("workflow_id") or "").strip() or None,
                            record=record,
                        )
            return None

    def list_persisted_audits(self, thread_id: str) -> list[dict[str, Any]]:
        """Return persisted action records carrying audit ids for a thread."""
        with self._lock:
            records: list[dict[str, Any]] = []
            for turn in self._turns.get(thread_id, []):
                for record in turn.action_records or []:
                    audit_id = str(record.get("audit_id") or "").strip()
                    if not audit_id:
                        continue
                    records.append(
                        {
                            "audit_id": audit_id,
                            "thread_id": thread_id,
                            "turn_id": turn.turn_id,
                            "action_id": record.get("action_id"),
                            "outcome": record.get("status"),
                            "timestamp": turn.created_at,
                            "correlation": record.get("correlation") or {},
                        }
                    )
            return sorted(records, key=lambda item: str(item.get("timestamp") or ""))
