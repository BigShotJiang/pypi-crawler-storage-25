"""Profile owners for the gateway's private automation contract."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

GATEWAY_PROFILE_STANDARD = "standard"
GATEWAY_PROFILE_PRIVATE_AUTOMATION = "private_automation"
GATEWAY_PROFILE_PRIVATE_TAILNET = "private_tailnet"
OBRA_GATEWAY_PROFILE_ENV = "OBRA_GATEWAY_PROFILE"
OBRA_GATEWAY_AUTH_TOKEN_ENV = "OBRA_GATEWAY_AUTH_TOKEN"

_PROFILE_ALIASES = {
    "standard": GATEWAY_PROFILE_STANDARD,
    "private_automation": GATEWAY_PROFILE_PRIVATE_AUTOMATION,
    "private-automation": GATEWAY_PROFILE_PRIVATE_AUTOMATION,
    "automation": GATEWAY_PROFILE_PRIVATE_AUTOMATION,
    "private_tailnet": GATEWAY_PROFILE_PRIVATE_TAILNET,
    "private-tailnet": GATEWAY_PROFILE_PRIVATE_TAILNET,
    "tailnet": GATEWAY_PROFILE_PRIVATE_TAILNET,
}


@dataclass(frozen=True)
class GatewayAutomationProfile:
    """Resolved gateway profile contract."""

    name: str
    private_only: bool
    require_explicit_auth_token: bool
    startup_guidance: str


def normalize_gateway_profile_name(value: Any) -> str:
    """Normalize profile identifiers from config or CLI input."""
    normalized = str(value or GATEWAY_PROFILE_STANDARD).strip().lower()
    if normalized in _PROFILE_ALIASES:
        return _PROFILE_ALIASES[normalized]
    raise ValueError(
        "Unsupported gateway profile. Use 'standard', 'private-automation', or 'private-tailnet'."
    )


def resolve_gateway_automation_profile(
    config: dict[str, Any] | None,
) -> GatewayAutomationProfile:
    """Resolve the active gateway profile with env override support."""
    configured = ""
    if isinstance(config, dict):
        configured = str(config.get("profile") or "").strip()
    profile_name = normalize_gateway_profile_name(
        os.getenv(OBRA_GATEWAY_PROFILE_ENV, configured or GATEWAY_PROFILE_STANDARD)
    )
    if profile_name == GATEWAY_PROFILE_PRIVATE_AUTOMATION:
        return GatewayAutomationProfile(
            name=profile_name,
            private_only=True,
            require_explicit_auth_token=True,
            startup_guidance=(
                "Private automation profile: keep the gateway bound to loopback and "
                "reach it remotely through SSH tunnels or private overlays."
            ),
        )
    if profile_name == GATEWAY_PROFILE_PRIVATE_TAILNET:
        return GatewayAutomationProfile(
            name=profile_name,
            private_only=False,
            require_explicit_auth_token=True,
            startup_guidance=(
                "Tailnet profile: gateway accepts connections from private/Tailscale "
                "addresses. Requires explicit auth token. Use 'obra gateway "
                "security-audit' before exposing."
            ),
        )
    return GatewayAutomationProfile(
        name=GATEWAY_PROFILE_STANDARD,
        private_only=False,
        require_explicit_auth_token=False,
        startup_guidance="Standard gateway profile.",
    )
