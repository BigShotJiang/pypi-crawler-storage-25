"""Output-delivery service for workflow-run terminal payload pushes."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import httpx

from obra.gateway.webhook.signing import sign_payload

logger = logging.getLogger(__name__)


class OutputDeliveryService:
    """Deliver terminal workflow outputs to a configured HTTP destination."""

    def __init__(
        self,
        *,
        timeout_s: float,
        retry_backoff_schedule_s: tuple[float, ...],
    ) -> None:
        self.timeout_s = timeout_s
        self.retry_backoff_schedule_s = retry_backoff_schedule_s

    async def deliver(
        self,
        run_id: str,
        artifacts: dict[str, Any],
        destination: dict[str, Any],
    ) -> int | None:
        """Push a successful run payload to the configured destination."""
        payload = {
            "run_id": run_id,
            "workflow_run_id": run_id,
            "status": "completed",
            **dict(artifacts),
        }
        return await self._deliver_payload(run_id, payload, destination)

    async def deliver_failure(
        self,
        run_id: str,
        error_detail: str,
        destination: dict[str, Any],
    ) -> int | None:
        """Push a failed run payload to the configured destination."""
        payload = {
            "run_id": run_id,
            "workflow_run_id": run_id,
            "status": "failed",
            "error": error_detail,
        }
        return await self._deliver_payload(run_id, payload, destination)

    async def _deliver_payload(
        self,
        run_id: str,
        payload: dict[str, Any],
        destination: dict[str, Any],
    ) -> int | None:
        last_status_code: int | None = None
        retryable = False

        for attempt in range(len(self.retry_backoff_schedule_s) + 1):
            try:
                last_status_code = await self._post_payload(run_id, payload, destination)
            except Exception:
                retryable = True
                last_status_code = None
                logger.info(
                    "Output delivery failed run_id=%s destination=%s",
                    run_id,
                    destination.get("url"),
                    exc_info=True,
                )
            else:
                retryable = last_status_code >= 500 if last_status_code is not None else False
                if not retryable:
                    return last_status_code

            if attempt >= len(self.retry_backoff_schedule_s):
                break
            await asyncio.sleep(self.retry_backoff_schedule_s[attempt])

        if retryable:
            logger.warning(
                "Output delivery exhausted retries run_id=%s destination=%s status_code=%s",
                run_id,
                destination.get("url"),
                last_status_code,
            )
        return last_status_code

    async def _post_payload(
        self,
        run_id: str,
        payload: dict[str, Any],
        destination: dict[str, Any],
    ) -> int:
        payload_bytes = json.dumps(payload).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "X-Obra-Run-ID": run_id,
            "X-Obra-Delivery-Status": str(payload.get("status") or ""),
        }
        destination_headers = destination.get("headers")
        if isinstance(destination_headers, dict):
            headers = {
                **{str(key): str(value) for key, value in destination_headers.items()},
                **headers,
            }
        secret = destination.get("secret")
        if isinstance(secret, str) and secret:
            headers["X-Obra-Signature"] = sign_payload(payload_bytes, secret)

        async with httpx.AsyncClient(timeout=self.timeout_s) as client:
            response = await client.post(
                str(destination["url"]),
                content=payload_bytes,
                headers=headers,
            )
        return int(response.status_code)
