"""Assistant handlers for canonical workflow-run actions."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext

_VALID_DOMAIN_IDS = frozenset({"business", "software"})


def execute_launch_run(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Launch a workflow run through the canonical session substrate."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    working_dir = str(inputs.get("working_dir") or "").strip() or (
        str(ctx.project_root) if ctx.project_root is not None else None
    )
    if working_dir is None:
        return {"outcome": "invalid", "detail": "Working directory unavailable"}
    result = ctx.run_action_service.launch(
        objective=str(inputs.get("objective") or "").strip(),
        project_id=str(inputs.get("project_id") or "").strip(),
        working_dir=working_dir,
        workflow_id=str(inputs.get("workflow_id") or workflow_id or "").strip(),
        revision_id=str(inputs.get("revision_id") or "").strip() or None,
        domain_id=(
            str(inputs.get("domain_id") or "").strip()
            if str(inputs.get("domain_id") or "").strip() in _VALID_DOMAIN_IDS
            else None
        ),
        repository=ctx.repository,
    )
    workflow_run = result.get("workflow_run", {})
    return {
        "outcome": "applied",
        "workflow_run": workflow_run,
        "run_id": workflow_run.get("workflow_run_id") or workflow_run.get("run_id"),
    }


def execute_approve_operator_review(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Approve an operator-blocked run."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    run_id = str(inputs.get("run_id") or "").strip()
    result = ctx.run_action_service.approve_operator_review(run_id)
    return {
        "outcome": "applied",
        "run_id": run_id,
        "run_action": result,
    }


def execute_resolve_escalation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Resolve a pending run escalation."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    run_id = str(inputs.get("run_id") or "").strip()
    escalation_id = str(inputs.get("escalation_id") or "").strip()
    choice = str(inputs.get("choice") or "").strip()
    result = ctx.run_action_service.resolve_escalation(
        run_id,
        escalation_id,
        choice=choice,
        was_timeout=bool(inputs.get("was_timeout", False)),
    )
    return {
        "outcome": "applied",
        "run_id": run_id,
        "escalation_id": escalation_id,
        "run_action": result,
    }
