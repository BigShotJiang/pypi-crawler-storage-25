"""Bearer token authentication for the gateway server."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from fastapi import Depends, HTTPException, Request, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from obra.gateway.automation.profile import (
    OBRA_GATEWAY_AUTH_TOKEN_ENV,
    GatewayAutomationProfile,
)
from obra.gateway.security.client_ip import (
    extract_client_ip_from_request,
    extract_client_ip_from_websocket,
)
from obra.gateway.security.scopes import GatewayScope, resolve_scopes

_bearer_scheme = HTTPBearer(auto_error=False)
logger = logging.getLogger("obra.gateway.security.events")

_ADMIN_SCOPE_SET = resolve_scopes([GatewayScope.ADMIN.value])


@dataclass(frozen=True)
class GatewayPrincipal:
    """Resolved gateway authentication principal."""

    owner_key: str
    scopes: frozenset[str]
    token_label: str
    auth_mode: str


def _owner_key(prefix: str, raw_value: str) -> str:
    digest = hashlib.sha256(raw_value.encode("utf-8")).hexdigest()
    return f"{prefix}:{digest}"


def get_request_owner_key(request: Request) -> str:
    """Return the owner key derived during gateway authentication."""
    owner_key = getattr(request.state, "gateway_owner_key", None)
    if isinstance(owner_key, str) and owner_key:
        return owner_key
    raise RuntimeError("Gateway owner key missing from authenticated request")


def verify_token(credentials: HTTPAuthorizationCredentials, expected_token: str) -> bool:
    """Verify bearer token using constant-time comparison.

    Args:
        credentials: The HTTP authorization credentials.
        expected_token: The expected token to compare against.

    Returns:
        True if token matches, False otherwise.
    """
    return hmac.compare_digest(credentials.credentials, expected_token)


def _extract_request_credentials(request: Request) -> HTTPAuthorizationCredentials | None:
    auth_header = request.headers.get("Authorization", "")
    scheme, _, credentials = auth_header.partition(" ")
    if not credentials.strip():
        return None
    return HTTPAuthorizationCredentials(
        scheme=(scheme or "Bearer").strip(),
        credentials=credentials.strip(),
    )


def _resolve_bearer_principal(
    raw_token: str,
    *,
    primary_token: str,
    token_registry: list[dict[str, Any]] | None = None,
) -> GatewayPrincipal | None:
    for entry in token_registry or []:
        configured_token = str(entry.get("token") or "")
        if configured_token and hmac.compare_digest(raw_token, configured_token):
            return GatewayPrincipal(
                owner_key=_owner_key("bearer", raw_token),
                scopes=resolve_scopes(list(entry.get("scopes") or [])),
                token_label=str(entry.get("label") or "registry-token"),
                auth_mode="bearer",
            )

    if primary_token and hmac.compare_digest(raw_token, primary_token):
        return GatewayPrincipal(
            owner_key=_owner_key("bearer", raw_token),
            scopes=_ADMIN_SCOPE_SET,
            token_label="primary",
            auth_mode="bearer",
        )
    return None


def _store_principal(target: Request | WebSocket, principal: GatewayPrincipal) -> GatewayPrincipal:
    state = getattr(target, "state", None)
    if state is not None:
        state.gateway_owner_key = principal.owner_key
        state.gateway_scopes = principal.scopes
        state.gateway_token_label = principal.token_label
        state.gateway_auth_mode = principal.auth_mode
    scope = getattr(target, "scope", None)
    if isinstance(scope, dict):
        scope["gateway_owner_key"] = principal.owner_key
        scope["gateway_scopes"] = principal.scopes
        scope["gateway_token_label"] = principal.token_label
        scope["gateway_auth_mode"] = principal.auth_mode
    return principal


def _emit_auth_event(
    *,
    event_type: str,
    outcome: str,
    client_ip: str,
    token_label: str | None,
    scopes: frozenset[str] | None,
    method: str,
    path: str,
    auth_mode: str,
) -> None:
    payload = {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "event_type": event_type,
        "client_ip": client_ip,
        "token_label": token_label,
        "scopes": sorted(scopes or []),
        "method": method,
        "path": path,
        "auth_mode": auth_mode,
        "outcome": outcome,
    }
    if outcome == "success":
        logger.info(json.dumps(payload, sort_keys=True))
    else:
        logger.warning(json.dumps(payload, sort_keys=True))


async def _authenticate_request(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None,
    *,
    token: str,
    token_registry: list[dict[str, Any]] | None = None,
) -> GatewayPrincipal:
    from obra.gateway.studio_browser import (
        is_studio_browser_authenticated_request,
        studio_session_cookie_name,
    )

    browser_rig_faults_enabled = bool(
        getattr(request.app.state, "workflow_studio_browser_faults_enabled", False)
    )
    rig_fault_state = getattr(request.app.state, "workflow_studio_browser_fault_state", None)
    if (
        browser_rig_faults_enabled
        and isinstance(rig_fault_state, dict)
        and request.url.path.startswith("/api/")
    ):
        http_delay_ms = max(0, int(rig_fault_state.get("http_delay_ms", 0) or 0))
        if http_delay_ms > 0:
            await asyncio.sleep(http_delay_ms / 1000)

        unauthorized_remaining = max(
            0,
            int(rig_fault_state.get("unauthorized_requests_remaining", 0) or 0),
        )
        unauthorized_path_prefix = str(
            rig_fault_state.get("unauthorized_path_prefix", "") or ""
        ).strip()
        matches_unauthorized_path = not unauthorized_path_prefix or request.url.path.startswith(
            unauthorized_path_prefix
        )
        if unauthorized_remaining > 0 and matches_unauthorized_path:
            rig_fault_state["unauthorized_requests_remaining"] = unauthorized_remaining - 1
            _log_request_failure(request, auth_mode="bearer")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication failed",
            )

    if credentials is not None:
        principal = _resolve_bearer_principal(
            credentials.credentials,
            primary_token=token,
            token_registry=token_registry,
        )
        if principal is not None:
            _store_principal(request, principal)
            _log_request_success(request, principal)
            return principal

    if is_studio_browser_authenticated_request(request):
        session_id = str(
            request.cookies.get(studio_session_cookie_name(request.app), "")
        ).strip()
        principal = GatewayPrincipal(
            owner_key=_owner_key("studio", session_id or "browser-session"),
            scopes=_ADMIN_SCOPE_SET,
            token_label="studio-browser",
            auth_mode="studio-browser",
        )
        _store_principal(request, principal)
        _log_request_success(request, principal)
        return principal

    _log_request_failure(request, auth_mode="bearer")
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing authentication token",
    )


async def authenticate_request(
    request: Request,
    *,
    token: str,
    token_registry: list[dict[str, Any]] | None = None,
) -> GatewayPrincipal:
    """Authenticate an HTTP request and populate request.state principal fields."""

    return await _authenticate_request(
        request,
        _extract_request_credentials(request),
        token=token,
        token_registry=token_registry,
    )


def authenticate_websocket_credentials(
    ws: WebSocket,
    raw_message: str,
    *,
    token: str,
    token_registry: list[dict[str, Any]] | None = None,
) -> GatewayPrincipal:
    """Authenticate a WebSocket auth frame and populate websocket principal fields."""

    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError as exc:
        _log_websocket_failure(
            ws,
            detail="Invalid authentication frame",
            auth_mode="bearer",
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication frame",
        ) from exc

    if not isinstance(payload, dict) or payload.get("type") != "auth" or "token" not in payload:
        _log_websocket_failure(
            ws,
            detail="Authentication required",
            auth_mode="bearer",
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    principal = _resolve_bearer_principal(
        str(payload.get("token") or ""),
        primary_token=token,
        token_registry=token_registry,
    )
    if principal is None:
        _log_websocket_failure(
            ws,
            detail="Authentication failed",
            auth_mode="bearer",
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed",
        )
    _store_principal(ws, principal)
    _log_websocket_success(ws, principal)
    return principal


def build_studio_websocket_principal(ws: WebSocket) -> GatewayPrincipal:
    """Build the first-party packaged Studio principal for a WebSocket session."""

    from obra.gateway.studio_browser import studio_session_cookie_name

    session_id = str(ws.cookies.get(studio_session_cookie_name(ws.app), "")).strip()
    principal = GatewayPrincipal(
        owner_key=_owner_key("studio", session_id or "browser-session"),
        scopes=_ADMIN_SCOPE_SET,
        token_label="studio-browser",
        auth_mode="studio-browser",
    )
    _store_principal(ws, principal)
    _log_websocket_success(ws, principal)
    return principal


def _log_request_success(request: Request, principal: GatewayPrincipal) -> None:
    trusted_proxy_cidrs = list(getattr(request.app.state, "trusted_proxy_cidrs", []))
    _emit_auth_event(
        event_type="auth_success",
        outcome="success",
        client_ip=extract_client_ip_from_request(request, trusted_proxy_cidrs),
        token_label=principal.token_label,
        scopes=principal.scopes,
        method=request.method,
        path=request.url.path,
        auth_mode=principal.auth_mode,
    )


def _log_request_failure(request: Request, *, auth_mode: str) -> None:
    trusted_proxy_cidrs = list(getattr(request.app.state, "trusted_proxy_cidrs", []))
    _emit_auth_event(
        event_type="auth_failure",
        outcome="failure",
        client_ip=extract_client_ip_from_request(request, trusted_proxy_cidrs),
        token_label=None,
        scopes=None,
        method=request.method,
        path=request.url.path,
        auth_mode=auth_mode,
    )


def _log_websocket_success(ws: WebSocket, principal: GatewayPrincipal) -> None:
    trusted_proxy_cidrs = list(getattr(ws.app.state, "trusted_proxy_cidrs", []))
    _emit_auth_event(
        event_type="auth_success",
        outcome="success",
        client_ip=extract_client_ip_from_websocket(ws, trusted_proxy_cidrs),
        token_label=principal.token_label,
        scopes=principal.scopes,
        method="WEBSOCKET",
        path=ws.url.path,
        auth_mode=principal.auth_mode,
    )


def _log_websocket_failure(
    ws: WebSocket,
    *,
    detail: str,
    auth_mode: str,
) -> None:
    del detail
    trusted_proxy_cidrs = list(getattr(ws.app.state, "trusted_proxy_cidrs", []))
    _emit_auth_event(
        event_type="auth_failure",
        outcome="failure",
        client_ip=extract_client_ip_from_websocket(ws, trusted_proxy_cidrs),
        token_label=None,
        scopes=None,
        method="WEBSOCKET",
        path=ws.url.path,
        auth_mode=auth_mode,
    )


def get_auth_dependency(token: str, token_registry: list[dict[str, Any]] | None = None) -> Callable:
    """Create a FastAPI dependency that validates bearer token auth.

    Args:
        token: The expected bearer token.
        token_registry: Optional additional bearer tokens with per-token scope metadata.

    Returns:
        A FastAPI Depends callable that raises 401 on invalid/missing tokens.
    """

    async def _verify(
        request: Request,
        credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    ) -> HTTPAuthorizationCredentials:
        principal = await _authenticate_request(
            request,
            credentials,
            token=token,
            token_registry=token_registry,
        )
        if principal.auth_mode == "studio-browser":
            return HTTPAuthorizationCredentials(scheme="Cookie", credentials="")
        if credentials is not None:
            return credentials
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing authentication token",
        )

    return _verify


def generate_token() -> str:
    """Generate a cryptographically secure URL-safe token.

    Returns:
        A 32-byte URL-safe token string.
    """
    return secrets.token_urlsafe(32)


def resolve_gateway_auth_token(
    config: dict[str, object],
    *,
    profile: GatewayAutomationProfile,
) -> tuple[str, str]:
    """Resolve auth token according to the active gateway profile."""
    env_token = os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV, "").strip()
    if env_token:
        return env_token, "env"

    configured_token = str(config.get("auth_token") or "").strip()
    if configured_token:
        return configured_token, "config"

    if profile.require_explicit_auth_token:
        raise ValueError(
            "Private automation profile requires an explicit gateway bearer token. "
            "Set OBRA_GATEWAY_AUTH_TOKEN or gateway.auth_token before startup."
        )

    return generate_token(), "generated"
