"""Google Gemini CLI provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any

from obra.config.cli_resolution import resolve_cli_path
from obra.config.loaders import get_gateway_onboarding_config


def detect_gemini_cli() -> dict[str, Any]:
    """Detect whether the Gemini CLI binary is installed.

    Returns dict with ``installed``, and either ``path``/``version``
    or ``install_url``/``install_command``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
            "install_command": "npm install -g @google/gemini-cli",
        }

    try:
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        version = result.stdout.strip() if result.returncode == 0 else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        version = "unknown"

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def _check_credential_file() -> dict[str, Any] | None:
    """Fast-path auth check via the on-disk OAuth credential file.

    Gemini CLI stores OAuth credentials at ``~/.gemini/oauth_creds.json``.
    Reading this file is nearly instant, whereas spawning the full CLI
    (a Node.js app) takes 3-5 seconds for startup alone — long enough to
    hit the subprocess timeout on resource-constrained environments like
    WSL2, causing persistent false-negative "needs setup" banners.

    Returns an auth-status dict on a conclusive result, or ``None`` when
    the file is missing / unparseable so the caller should fall back to
    the subprocess probe.
    """
    creds_path = Path.home() / ".gemini" / "oauth_creds.json"
    try:
        raw = creds_path.read_text(encoding="utf-8")
    except OSError:
        return None  # File missing or unreadable — fall through.

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None

    if not isinstance(data, dict) or not data.get("access_token"):
        return {"authenticated": False, "auth_issue": "not_authenticated"}

    # If a refresh_token is present the CLI can silently renew, so the
    # user is effectively authenticated regardless of access_token expiry.
    if data.get("refresh_token"):
        return {"authenticated": True, "auth_issue": None}

    # No refresh_token — check whether the access_token has expired.
    expiry_date = data.get("expiry_date")
    if expiry_date is not None:
        try:
            expiry_val = float(expiry_date)
            # Gemini CLI (Node.js) stores expiry in epoch milliseconds.
            expiry_s = expiry_val / 1000 if expiry_val > 1e12 else expiry_val
            if expiry_s < time.time():
                return {"authenticated": False, "auth_issue": "expired"}
        except (TypeError, ValueError):
            pass  # Treat unparseable expiry as non-expired.

    return {"authenticated": True, "auth_issue": None}


def check_google_auth() -> dict[str, Any]:
    """Check whether Gemini CLI is authenticated with Google.

    Function named ``check_google_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``google``.

    **Primary strategy**: read the on-disk OAuth credential file directly.
    This avoids spawning the Gemini CLI (a Node.js process with 3-5 s
    startup overhead) which frequently times out in gateway contexts.

    **Fallback**: ``gemini --list-sessions`` (not ``gemini auth status``
    which does not exist — the CLI would interpret it as a chat prompt).

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    # Fast path — credential file check (microseconds, no subprocess).
    file_result = _check_credential_file()
    if file_result is not None:
        return file_result

    # Slow path — subprocess fallback for non-standard credential storage
    # (e.g. macOS Keychain, custom XDG paths).
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "--list-sessions"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            combined = result.stdout.lower() + result.stderr.lower()
            if "expired" in combined:
                return {"authenticated": False, "auth_issue": "expired"}
            return {"authenticated": True, "auth_issue": None}
        combined = result.stdout.lower() + result.stderr.lower()
        if "expired" in combined:
            return {"authenticated": False, "auth_issue": "expired"}
        return {"authenticated": False, "auth_issue": "not_authenticated"}
    except subprocess.TimeoutExpired:
        return {"authenticated": False, "auth_issue": "connection_failed"}
    except OSError:
        return {"authenticated": False, "auth_issue": "not_installed"}


def authenticate_gemini_cli() -> dict[str, Any]:
    """Return manual auth instructions for Gemini CLI.

    Gemini CLI has no dedicated ``auth login`` command — authentication
    is triggered on first interactive use via Google OAuth in the
    browser.  Spawning the CLI programmatically would burn API quota
    without reliably surfacing the OAuth flow to the user.
    """
    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"triggered": False, "error": "Gemini CLI is not installed"}

    return {
        "triggered": False,
        "manual_action_required": True,
        "instructions": (
            "Run 'gemini' in your terminal to authenticate with Google. "
            "The CLI will open a browser window for OAuth sign-in on first use."
        ),
    }
