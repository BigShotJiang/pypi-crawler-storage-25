"""Claude Code provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import json
import subprocess
import threading
from typing import Any

from obra.config.cli_resolution import resolve_cli_path
from obra.config.loaders import get_gateway_onboarding_config
from obra.execution.os_compat import build_popen_kwargs, is_interactive_context
from obra.gateway.providers._auth_process import (
    register_auth_process,
    terminate_auth_process,
    unregister_auth_process,
)

# Module-level state for the background auth subprocess.
_auth_process: subprocess.Popen | None = None
_auth_lock = threading.Lock()


def _clear_completed_auth_process() -> None:
    global _auth_process
    if _auth_process is not None and _auth_process.poll() is not None:
        unregister_auth_process(_auth_process)
        _auth_process = None


def detect_claude_code() -> dict[str, Any]:
    """Detect whether the Claude Code native binary is installed.

    Returns dict with ``installed``, and either ``path``/``version``
    or ``install_url``/``install_command``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://claude.com/download",
            "install_command": "curl -fsSL https://claude.com/install.sh | sh",
        }

    # Try to get the version.
    try:
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        version = result.stdout.strip() if result.returncode == 0 else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        version = "unknown"

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def check_claude_code_auth() -> dict[str, Any]:
    """Check whether Claude Code is authenticated.

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    _clear_completed_auth_process()
    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "auth", "status"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            # claude auth status returns JSON with a loggedIn boolean.
            try:
                data = json.loads(result.stdout)
                if data.get("loggedIn") is False:
                    return {"authenticated": False, "auth_issue": "not_authenticated"}
                if data.get("loggedIn"):
                    return {"authenticated": True, "auth_issue": None}
            except (json.JSONDecodeError, AttributeError):
                pass
            # Non-JSON output: check for explicit failure signals.
            output = result.stdout.lower() + result.stderr.lower()
            if "expired" in output:
                return {"authenticated": False, "auth_issue": "expired"}
            # Exit code 0 means auth is valid — don't require specific
            # keywords since output wording varies by version.
            return {"authenticated": True, "auth_issue": None}
        # Non-zero exit: check stderr/stdout for clues.
        combined = result.stdout.lower() + result.stderr.lower()
        if "expired" in combined:
            return {"authenticated": False, "auth_issue": "expired"}
        return {"authenticated": False, "auth_issue": "not_authenticated"}
    except subprocess.TimeoutExpired:
        return {"authenticated": False, "auth_issue": "connection_failed"}
    except OSError:
        return {"authenticated": False, "auth_issue": "not_installed"}


def authenticate_claude_code() -> dict[str, Any]:
    """Trigger Claude Code OAuth login flow.

    Spawns ``claude auth login`` in the background. The auth-status
    endpoint detects completion by re-checking ``check_claude_code_auth()``.
    """
    global _auth_process

    config = get_gateway_onboarding_config()
    auth_timeout = config["auth_timeout_s"]

    if not is_interactive_context():
        return {
            "triggered": False,
            "error": "Claude Code login requires an interactive terminal.",
            "needs_tty": True,
        }

    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {"triggered": False, "error": "Claude Code is not installed"}

    with _auth_lock:
        _clear_completed_auth_process()
        # Kill any existing auth process.
        if _auth_process is not None:
            terminate_auth_process(_auth_process)
            _auth_process = None

        try:
            _auth_process = subprocess.Popen(
                [binary_path, "auth", "login"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                **build_popen_kwargs(),
            )
            register_auth_process(_auth_process, "claude-auth-login")
        except OSError as e:
            return {"triggered": False, "error": str(e)}

    # Start a timer to kill the process if auth times out.
    def _timeout_killer():
        global _auth_process
        with _auth_lock:
            if _auth_process is not None:
                terminate_auth_process(_auth_process)
                _auth_process = None

    timer = threading.Timer(auth_timeout, _timeout_killer)
    timer.daemon = True
    timer.start()

    return {"triggered": True}
