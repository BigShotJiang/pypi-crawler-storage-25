"""Shared auth-process lifecycle helpers for gateway onboarding providers."""

from __future__ import annotations

import contextlib
import subprocess

from obra.core.process_registry import ProcessRegistry

_AUTH_PROCESS_REGISTRY = ProcessRegistry()


def register_auth_process(process: subprocess.Popen[bytes] | subprocess.Popen[str], command: str) -> None:
    """Register a launched auth subprocess for cleanup and crash recovery."""
    _AUTH_PROCESS_REGISTRY.register(process.pid, command)


def unregister_auth_process(
    process: subprocess.Popen[bytes] | subprocess.Popen[str] | None,
) -> None:
    """Unregister a subprocess when it exits or is no longer owned."""
    if process is None:
        return
    _AUTH_PROCESS_REGISTRY.unregister(process.pid)


def terminate_auth_process(
    process: subprocess.Popen[bytes] | subprocess.Popen[str] | None,
) -> None:
    """Best-effort kill of an auth subprocess with registry cleanup."""
    if process is None:
        return
    with contextlib.suppress(OSError):
        process.kill()
    with contextlib.suppress(Exception):
        process.wait(timeout=0.5)
    unregister_auth_process(process)
