"""Automation-facing routes layered over the canonical gateway owners."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict, Field, field_validator

from obra.gateway.automation.workspaces import validate_payload_filename
from obra.gateway.automation.control_surface import GatewayAutomationControlSurface
from obra.gateway.security.scopes import GatewayScope, require_scope

router = APIRouter(prefix="/api/automation", tags=["automation"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


class AutomationRunStartRequest(BaseModel):
    """Automation-facing request body for workflow runs."""

    model_config = ConfigDict(extra="forbid")

    objective: str = Field(..., min_length=1, max_length=10_000)
    project_id: str = Field(..., min_length=1, max_length=256)
    working_dir: str | None = Field(default=None, max_length=4096)
    workflow_id: str | None = Field(default=None, max_length=256)
    revision_id: str | None = Field(default=None, max_length=256)
    domain_id: str | None = Field(default=None, max_length=256)
    input_manifest: list[str] | None = None
    input_payload: dict[str, str] | None = None

    @field_validator("working_dir", "workflow_id", "revision_id", "domain_id", mode="before")
    @classmethod
    def _normalize_optional_strings(cls, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value

    @field_validator("input_payload")
    @classmethod
    def _validate_input_payload(cls, value: dict[str, str] | None) -> dict[str, str] | None:
        for filename in (value or {}):
            validate_payload_filename(filename)
        return value


class AutomationDerivationStartRequest(BaseModel):
    """Automation-facing request body for workflow derivations."""

    model_config = ConfigDict(extra="forbid")

    mission: str = Field(..., min_length=1, max_length=10_000)
    project_id: str = Field(..., min_length=1, max_length=256)
    working_dir: str | None = Field(default=None, max_length=4096)
    domain_id: str | None = Field(default=None, max_length=256)
    input_spec_refs: list[dict[str, Any]] = Field(default_factory=list)
    output_spec_refs: list[dict[str, Any]] = Field(default_factory=list)
    rule_pack_refs: list[dict[str, Any]] = Field(default_factory=list)
    quality_pack_refs: list[dict[str, Any]] = Field(default_factory=list)
    baseline_workflow_ref: dict[str, Any] | None = None
    example_case_refs: list[dict[str, Any]] = Field(default_factory=list)
    exception_case_refs: list[dict[str, Any]] = Field(default_factory=list)
    policy_precedence_overrides: dict[str, Any] = Field(default_factory=dict)
    operator_constraints: dict[str, Any] = Field(default_factory=dict)

    @field_validator("working_dir", "domain_id", mode="before")
    @classmethod
    def _normalize_optional_strings(cls, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value


class AutomationActionRequest(BaseModel):
    """Automation-facing operator action request."""

    model_config = ConfigDict(extra="forbid")

    action: str = Field(..., min_length=1, max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)


@router.post("/runs", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def launch_automation_run(
    body: AutomationRunStartRequest,
    request: Request,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    if not isinstance(idempotency_key, str) or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.launch_run(
            objective=body.objective,
            project_id=body.project_id,
            working_dir=body.working_dir,
            workflow_id=body.workflow_id,
            revision_id=body.revision_id,
            domain_id=body.domain_id,
            input_manifest=body.input_manifest,
            input_payload=body.input_payload,
            idempotency_key=idempotency_key,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc


@router.get("/runs/{run_id}", dependencies=_READ_SCOPE)
async def get_automation_run(run_id: str, request: Request) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.get_resource("workflow_run", run_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation run not found"
        ) from exc


@router.get("/runs/{run_id}/events", dependencies=_READ_SCOPE)
async def watch_automation_run(
    run_id: str,
    request: Request,
    filter: str | None = Query(default=None),
    after_sequence: int | None = Query(default=None, ge=0),
) -> Any:
    surface = GatewayAutomationControlSurface.from_request(request)
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    try:
        return surface.watch_resource(
            "workflow_run",
            run_id,
            filter_names=filter_names,
            after_sequence=after_sequence,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation run not found"
        ) from exc


@router.post("/runs/{run_id}/cancel", dependencies=_OPERATE_SCOPE)
async def cancel_automation_run(
    run_id: str,
    request: Request,
    client_request_id: str | None = Header(default=None, alias="X-Obra-Client-Request-Id"),
) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.cancel_resource(
            "workflow_run",
            run_id,
            client_request_id=client_request_id,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation run not found"
        ) from exc


@router.post("/runs/{run_id}/actions", dependencies=_OPERATE_SCOPE)
async def act_on_automation_run(
    run_id: str,
    body: AutomationActionRequest,
    request: Request,
    client_request_id: str | None = Header(default=None, alias="X-Obra-Client-Request-Id"),
) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.dispatch_action(
            "workflow_run",
            run_id,
            action=body.action,
            payload=body.payload,
            client_request_id=client_request_id,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation run not found"
        ) from exc


@router.post("/derivations", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def launch_automation_derivation(
    body: AutomationDerivationStartRequest,
    request: Request,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    if not isinstance(idempotency_key, str) or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        payload = body.model_dump(exclude={"project_id", "working_dir"})
        return surface.launch_derivation(
            request_payload=payload,
            project_id=body.project_id,
            working_dir=body.working_dir,
            idempotency_key=idempotency_key,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc


@router.get("/derivations/{derivation_id}", dependencies=_READ_SCOPE)
async def get_automation_derivation(
    derivation_id: str,
    request: Request,
) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.get_resource("workflow_derivation", derivation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation derivation not found"
        ) from exc


@router.get("/derivations/{derivation_id}/events", dependencies=_READ_SCOPE)
async def watch_automation_derivation(
    derivation_id: str,
    request: Request,
    filter: str | None = Query(default=None),
    after_sequence: int | None = Query(default=None, ge=0),
) -> Any:
    surface = GatewayAutomationControlSurface.from_request(request)
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    try:
        return surface.watch_resource(
            "workflow_derivation",
            derivation_id,
            filter_names=filter_names,
            after_sequence=after_sequence,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation derivation not found"
        ) from exc


@router.post("/derivations/{derivation_id}/cancel", dependencies=_OPERATE_SCOPE)
async def cancel_automation_derivation(
    derivation_id: str,
    request: Request,
) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.cancel_resource("workflow_derivation", derivation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation derivation not found"
        ) from exc


@router.post("/derivations/{derivation_id}/actions", dependencies=_OPERATE_SCOPE)
async def act_on_automation_derivation(
    derivation_id: str,
    body: AutomationActionRequest,
    request: Request,
) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    try:
        return surface.dispatch_action(
            "workflow_derivation",
            derivation_id,
            action=body.action,
            payload=body.payload,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Automation derivation not found"
        ) from exc


@router.get("/bootstrap-template", dependencies=_READ_SCOPE)
async def get_automation_bootstrap_template(request: Request) -> dict[str, Any]:
    surface = GatewayAutomationControlSurface.from_request(request)
    return {"template": surface.build_bootstrap_template()}
