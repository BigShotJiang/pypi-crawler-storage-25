"""Workflow Studio project routes."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, ConfigDict, Field

from obra.api import APIClient
from obra.exceptions import APIError
from obra.gateway.automation.workspaces import provision_project_directory
from obra.gateway.errors import GatewayAPIError
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.workflow_studio.local_project_store import LocalProjectStore

router = APIRouter(prefix="/api/projects", tags=["workflow-studio"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


class CreateProjectRequest(BaseModel):
    """Request body for creating a project."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=1, max_length=256)
    working_dir: str | None = Field(default=None, min_length=1, max_length=4096)
    description: str = Field(default="", max_length=4096)
    domain_id: str | None = Field(default=None, max_length=128)


class UpdateProjectRequest(BaseModel):
    """Request body for updating a project."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, max_length=256)
    working_dir: str | None = Field(default=None, max_length=4096)
    domain_id: str | None = Field(default=None, max_length=128)


@router.get("/", dependencies=_READ_SCOPE)
async def list_projects(request: Request) -> dict[str, Any]:
    """List projects plus the user's default selection."""
    include_deleted = request.query_params.get("all", "false") == "true"
    store = _get_local_project_store(request)
    if store is not None:
        cached_projects = await asyncio.to_thread(
            store.list_projects,
            include_deleted=include_deleted,
        )
        if cached_projects or await asyncio.to_thread(store.is_hydrated):
            default_project_id = await asyncio.to_thread(store.get_default_project_id)
            return {
                "projects": cached_projects,
                "default_project_id": default_project_id,
            }

    payload = await _fetch_and_cache_projects(request)
    return {
        "projects": _filter_projects(
            payload["projects"],
            include_deleted=include_deleted,
        ),
        "default_project_id": payload["default_project_id"],
    }


@router.post("/", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def create_project(body: CreateProjectRequest, request: Request) -> dict[str, Any]:
    """Create a project."""
    client = _get_api_client(request)
    working_dir = body.working_dir
    if working_dir is None:
        allowed_base = Path(str(request.app.state.gateway_config["allowed_working_dir_base"]))
        provisioned = await asyncio.to_thread(
            provision_project_directory,
            base_dir=allowed_base.expanduser(),
            project_name=body.name,
            allowed_base=allowed_base.expanduser(),
        )
        working_dir = str(provisioned)
    try:
        project = await asyncio.to_thread(
            client.create_project,
            name=body.name,
            working_dir=working_dir,
            description=body.description,
            domain_id=body.domain_id,
        )
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_create_failed",
            default_message="Failed to create project",
        ) from exc
    store = _get_local_project_store(request)
    if store is not None:
        await asyncio.to_thread(store.upsert_project, project)
    return {"project": project}


@router.get("/{project_id}", dependencies=_READ_SCOPE)
async def get_project(project_id: str, request: Request) -> dict[str, Any]:
    """Get a project by id."""
    store = _get_local_project_store(request)
    if store is not None:
        cached_project = await asyncio.to_thread(store.get_project, project_id)
        if cached_project is not None:
            return {"project": cached_project}

    client = _get_api_client(request)
    try:
        project = await asyncio.to_thread(client.get_project, project_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_not_found",
            default_message=f"Failed to load project {project_id}",
        ) from exc
    if store is not None:
        await asyncio.to_thread(store.upsert_project, project)
    return {"project": project}


@router.post("/{project_id}", dependencies=_OPERATE_SCOPE)
async def update_project(
    project_id: str,
    body: UpdateProjectRequest,
    request: Request,
) -> dict[str, Any]:
    """Update one project."""
    if body.name is None and body.working_dir is None and body.domain_id is None:
        raise GatewayAPIError(
            error_code="missing_field",
            message="No updates provided",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    client = _get_api_client(request)
    try:
        project = await asyncio.to_thread(
            client.update_project,
            project_id,
            name=body.name,
            working_dir=body.working_dir,
            domain_id=body.domain_id,
        )
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_update_failed",
            default_message=f"Failed to update project {project_id}",
        ) from exc
    store = _get_local_project_store(request)
    if store is not None:
        await asyncio.to_thread(store.upsert_project, project)
    return {"project": project}


@router.post("/{project_id}/select", dependencies=_OPERATE_SCOPE)
async def select_project(project_id: str, request: Request) -> dict[str, Any]:
    """Select the default project for the current user."""
    client = _get_api_client(request)
    try:
        payload = await asyncio.to_thread(client.select_project, project_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_select_failed",
            default_message=f"Failed to select project {project_id}",
        ) from exc
    store = _get_local_project_store(request)
    if store is not None:
        await asyncio.to_thread(store.set_default_project_id, project_id)
    return payload


def _get_api_client(request: Request) -> APIClient:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        return client_factory()
    return APIClient.from_config()


def _get_local_project_store(request: Request) -> LocalProjectStore | None:
    store = getattr(request.app.state, "local_project_store", None)
    return store if isinstance(store, LocalProjectStore) else None


async def _fetch_and_cache_projects(request: Request) -> dict[str, Any]:
    client = _get_api_client(request)
    try:
        payload = await asyncio.to_thread(
            client.list_projects_with_selection,
            include_deleted=True,
        )
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_list_failed",
            default_message="Failed to list projects",
        ) from exc

    projects = payload.get("projects")
    normalized_projects = [project for project in projects if isinstance(project, dict)] if isinstance(projects, list) else []
    default_project_id = payload.get("default_project_id")
    store = _get_local_project_store(request)
    if store is not None:
        await asyncio.to_thread(
            store.replace_projects,
            normalized_projects,
            default_project_id=(
                str(default_project_id).strip() or None
                if default_project_id is not None
                else None
            ),
        )
    return {
        "projects": normalized_projects,
        "default_project_id": default_project_id,
    }


def _filter_projects(
    projects: list[dict[str, Any]],
    *,
    include_deleted: bool,
) -> list[dict[str, Any]]:
    if include_deleted:
        return projects
    return [project for project in projects if not _is_deleted(project)]


def _is_deleted(project: dict[str, Any]) -> bool:
    return bool(project.get("is_deleted") or project.get("deleted_at"))
