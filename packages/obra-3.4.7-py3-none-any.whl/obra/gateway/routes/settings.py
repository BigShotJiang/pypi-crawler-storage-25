"""Gateway routes for catalog-driven Workflow Studio settings management."""

from __future__ import annotations

import asyncio
from dataclasses import asdict
from http import HTTPStatus
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from obra.config.catalog import build_catalog, resolve_choices
from obra.config.loaders import load_layered_config
from obra.config.loaders._dict_utils import _delete_nested_value, _get_nested_value, _set_nested_value
from obra.config.loaders._loading import load_config, save_config

router = APIRouter(prefix="/api/settings", tags=["settings"])


class SettingsPatchRequest(BaseModel):
    """PATCH request payload for curated settings updates."""

    settings: dict[str, Any] = Field(default_factory=dict)


def _is_sensitive_field(entry: Any) -> bool:
    return bool(getattr(entry, "sensitive", False))


def _secret_field_state(config: dict[str, Any], path: str) -> dict[str, bool]:
    value = _get_nested_value(config, path)
    return {"configured": bool(isinstance(value, str) and value.strip())}


def _build_settings_payload() -> dict[str, Any]:
    """Build the full editable settings payload from the catalog.

    Iterates all catalog fields where ``readonly is False`` and
    ``value_type != 'object'`` (leaf nodes only), resolving current values
    from the layered config.
    """
    catalog = build_catalog()
    config, origins, warnings = load_layered_config(include_defaults=True)
    curated_config: dict[str, Any] = {}
    curated_origins: dict[str, str] = {}
    secret_fields: dict[str, dict[str, bool]] = {}
    for path, entry in catalog["fields"].items():
        if entry.readonly or entry.value_type == "object":
            continue
        value = _get_nested_value(config, path)
        if _is_sensitive_field(entry):
            secret_fields[path] = _secret_field_state(config, path)
        elif value is not None:
            _set_nested_value(curated_config, path, value)
        if path in origins:
            curated_origins[path] = origins[path]
    return {
        "config": curated_config,
        "origins": curated_origins,
        "secret_fields": secret_fields,
        "warnings": warnings,
    }


def _normalize_from_catalog(path: str, entry: Any, value: Any, full_config: dict | None = None) -> Any:
    """Validate and normalize *value* based on catalog entry metadata.

    Supports value_type: string, integer, boolean, enum.
    """
    vtype = entry.value_type

    if vtype == "string":
        if not isinstance(value, str):
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be a string.",
            )
        normalized = value.strip()
        if not normalized:
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must not be empty.",
            )
        if entry.choices:
            allowed = set(entry.choices)
            if normalized not in allowed:
                choices_str = ", ".join(sorted(allowed))
                raise HTTPException(
                    status_code=HTTPStatus.BAD_REQUEST,
                    detail=f"{path} must be one of: {choices_str}.",
                )
        return normalized

    if vtype == "integer":
        if isinstance(value, bool) or not isinstance(value, int):
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be an integer.",
            )
        if entry.min_value is not None and value < entry.min_value:
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be >= {entry.min_value}.",
            )
        if entry.max_value is not None and value > entry.max_value:
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be <= {entry.max_value}.",
            )
        return value

    if vtype == "boolean":
        if not isinstance(value, bool):
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be a boolean.",
            )
        return value

    if vtype == "enum":
        if not isinstance(value, str):
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} must be a string.",
            )
        normalized = value.strip()
        resolved = resolve_choices(entry, full_config)
        if resolved is not None:
            if normalized not in resolved:
                choices_str = ", ".join(sorted(resolved))
                raise HTTPException(
                    status_code=HTTPStatus.BAD_REQUEST,
                    detail=f"{path} must be one of: {choices_str}.",
                )
        return normalized

    raise HTTPException(
        status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        detail=f"Unsupported value_type '{vtype}' for {path}.",
    )


def _reject_locked_origin(path: str, origin: str | None) -> None:
    if origin in {"env", "project", "session"}:
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail=f"{path} is controlled by the {origin} layer and cannot be edited here.",
        )


def _normalize_secret_patch(path: str, value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail=f"{path} requires an object with an explicit secret mutation op.",
        )
    op = str(value.get("op") or "").strip()
    if op not in {"preserve", "replace", "clear"}:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail=f"{path}.op must be one of: preserve, replace, clear.",
        )
    if op == "replace":
        raw = value.get("value")
        if not isinstance(raw, str) or not raw.strip():
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path}.value must be a non-empty string when op=replace.",
            )
        return {"op": op, "value": raw.strip()}
    return {"op": op}


@router.get("/catalog")
async def get_settings_catalog() -> dict[str, Any]:
    """Return the full settings catalog with sections and field metadata."""

    catalog = await asyncio.to_thread(build_catalog)
    full_config, _origins, _warnings = await asyncio.to_thread(
        load_layered_config, include_defaults=True
    )

    sections = [
        {"id": s.id, "label": s.label, "description": s.description, "order": s.order}
        for s in catalog["sections"]
    ]

    fields: dict[str, Any] = {}
    for path, entry in catalog["fields"].items():
        serialized = asdict(entry)
        if entry.choices_resolver is not None:
            serialized["resolved_choices"] = resolve_choices(entry, full_config)
        fields[path] = serialized

    return {"sections": sections, "fields": fields}


@router.get("")
async def get_settings() -> dict[str, Any]:
    """Return the editable settings subset with layer origins and warnings."""

    return await asyncio.to_thread(_build_settings_payload)


@router.patch("")
async def patch_settings(payload: SettingsPatchRequest) -> dict[str, Any]:
    """Persist curated settings to the user config layer."""

    if not payload.settings:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="At least one setting is required.",
        )

    catalog = await asyncio.to_thread(build_catalog)
    catalog_fields = catalog["fields"]

    current_payload = await asyncio.to_thread(_build_settings_payload)
    current_origins = current_payload["origins"]
    updated_user_config = await asyncio.to_thread(load_config)

    full_config, _origins, _warnings = await asyncio.to_thread(
        load_layered_config, include_defaults=True
    )

    for path, value in payload.settings.items():
        entry = catalog_fields.get(path)
        if entry is None or entry.readonly or entry.value_type == "object":
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f"{path} is not editable from Workflow Studio settings.",
            )
        _reject_locked_origin(path, current_origins.get(path))
        if _is_sensitive_field(entry):
            mutation = _normalize_secret_patch(path, value)
            op = mutation["op"]
            if op == "replace":
                normalized_value = str(mutation["value"])
                _set_nested_value(updated_user_config, path, normalized_value)
                _set_nested_value(full_config, path, normalized_value)
            elif op == "clear":
                _delete_nested_value(updated_user_config, path)
                _delete_nested_value(full_config, path)
            continue
        normalized_value = _normalize_from_catalog(path, entry, value, full_config)
        _set_nested_value(updated_user_config, path, normalized_value)
        _set_nested_value(full_config, path, normalized_value)

    await asyncio.to_thread(save_config, updated_user_config)
    return await asyncio.to_thread(_build_settings_payload)
