"""ExecutionItemEmitter — execution-item progress events.

Owns all item lifecycle (started/completed/heartbeat), file tracking,
telemetry counters, and file-list rendering.  Receives EmitterContext and
PlanTreeEmitter at construction.

Cross-domain interface:
    item_started  → plan_tree.mark_item_started(item_id, title)
    item_completed → plan_tree.mark_item_completed(item_id, status)

Shared state read from EmitterContext:
    _llm           (LLMStateManager; written by MiscEmitter/ReviewEmitter, read by item_heartbeat)
    _is_tty        (read by item_heartbeat for inline heartbeat routing)

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

from typing import TYPE_CHECKING

from obra.core.interrupts import interrupt_requested as _interrupt_requested_direct
from obra.display.charset import glyphs
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext
    from obra.display.observability._plan_tree import PlanTreeEmitter


def _interrupt_requested() -> bool:
    """Look up interrupt_requested via the observability package namespace.

    This indirection allows tests to patch obra.display.observability.interrupt_requested
    and have the patch take effect in item_started.
    """
    import sys

    obs = sys.modules.get("obra.display.observability")
    if obs is not None:
        fn = getattr(obs, "interrupt_requested", None)
        if fn is not None:
            return fn()
    return _interrupt_requested_direct()


class ExecutionItemEmitter:
    """Emits all execution-item progress events.

    Owns file tracking counters and telemetry counters.  Cross-domain plan
    status mutations go through PlanTreeEmitter.mark_item_started /
    mark_item_completed.  All shared infrastructure (print, spinner,
    utilities) is accessed via self._ctx.
    """

    def __init__(self, ctx: "EmitterContext", plan_tree: "PlanTreeEmitter") -> None:
        self._ctx = ctx
        self._plan_tree = plan_tree

        # Execution tracking state
        self._files_created: int = 0
        self._files_modified: int = 0
        self._heartbeat_count: int = 0
        self._counters: dict[str, int] = {}

    # ------------------------------------------------------------------ #
    # Telemetry counters                                                  #
    # ------------------------------------------------------------------ #

    def increment(self, counter_name: str) -> None:
        """Increment a named telemetry counter.

        Generic counter mechanism for Rule 10 compliance. Used by parallel
        refinement paths to track event counts without requiring per-event
        dedicated methods.

        Args:
            counter_name: Identifier for the counter (e.g. "refinement_parallel_examine").
        """
        self._counters[counter_name] = self._counters.get(counter_name, 0) + 1

    def get_counter(self, counter_name: str) -> int:
        """Return current value of a named telemetry counter."""
        return self._counters.get(counter_name, 0)

    # ------------------------------------------------------------------ #
    # File tracking                                                       #
    # ------------------------------------------------------------------ #

    def track_file_created(self) -> None:
        """Increment the file created counter."""
        self._files_created += 1

    def track_file_modified(self) -> None:
        """Increment the file modified counter."""
        self._files_modified += 1

    def get_file_summary(self) -> str:
        """Get a summary of file activity for the current session."""
        if self._files_created == 0 and self._files_modified == 0:
            return ""
        from obra.messages.progress import build_file_summary

        return build_file_summary(self._files_created, self._files_modified)

    # ------------------------------------------------------------------ #
    # Item lifecycle                                                      #
    # ------------------------------------------------------------------ #

    def item_started(self, item: dict) -> None:
        """Emit event when processing a plan item starts.

        Args:
            item: Plan item being processed
        """
        if _interrupt_requested():
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: suppressed item_started after interrupt request",
                    style="dim",
                )
            return

        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        item_title = item.get("title", "")
        normalized_title = str(item_title).strip()
        if normalized_id and normalized_id != "?":
            self._plan_tree.mark_item_started(normalized_id, normalized_title)

        self._ctx.start_spinner(reason="item")

        # Level 0 (QUIET): Show minimal "Executing TX..."
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            progress = self._plan_tree.get_progress_summary()
            progress_prefix = ""
            if progress["total_tasks"] > 0:
                display_index = progress["current_index"] + 1
                progress_prefix = f"[Attempt {display_index}/{progress['total_tasks']}] "
            self._ctx._print(f"{progress_prefix}Executing {item_id}...", end="")
            if progress["total_tasks"] > 0:
                self._plan_tree.advance_task_index()
            return

        # Level 1 (PROGRESS): Show item with title
        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._ctx._timestamp()
            item_title = item.get("title", "")
            if item_title:
                self._ctx._print(
                    f"{timestamp}Executing {item_id}: {item_title}...",
                    style="cyan",
                )
            else:
                self._ctx._print(f"{timestamp}Executing {item_id}...", style="cyan")
            if self._plan_tree.get_progress_summary()["total_tasks"] > 0:
                self._plan_tree.advance_task_index()
            self._plan_tree.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._ctx._timestamp()
        item_title = item.get("title", "untitled")
        self._ctx._print(f"{timestamp}Item {item_id}: {item_title}", style="cyan")

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            # Truncate verbose item output
            item_str = str(item)
            max_chars = 300
            display_item = item_str if len(item_str) <= max_chars else item_str[:max_chars] + "..."
            self._ctx._print(f"[DEBUG] Full item: {display_item}", style="dim")
        self._plan_tree.render_task_tracker()

    def item_completed(self, item: dict, result: dict | None = None) -> None:
        """Emit event when processing a plan item completes.

        Args:
            item: Plan item that was processed
            result: Optional result data from processing
        """
        if self._ctx._spinner:
            self._ctx._spinner.clear_status_line()
        self._ctx.stop_spinner(reason="item")
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        result_payload = result if isinstance(result, dict) else {}
        raw_status = str(result_payload.get("status", "")).strip()
        status = self._plan_tree._normalize_status(raw_status)
        if not raw_status:
            status = "completed"
        elif status == "pending":
            # Unknown terminal status should not render as completed.
            status = "failed"
        is_success = status in {"completed", "skipped"}

        if normalized_id and normalized_id != "?":
            self._plan_tree.mark_item_completed(normalized_id, status)

        # Level 0 (QUIET): Complete the line with " done"
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            self._ctx._print(" done" if is_success else " failed")
            return

        # Level 1 (PROGRESS): Show completion with timestamp
        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._ctx._timestamp()
            if is_success:
                self._ctx._print(f"{timestamp}{item_id} complete", style="green")
            else:
                self._ctx._print(f"{timestamp}{item_id} failed", style="red")
            self._plan_tree.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._ctx._timestamp()
        if is_success:
            self._ctx._print(f"{timestamp}Item {item_id} complete", style="green")
        else:
            self._ctx._print(f"{timestamp}Item {item_id} failed", style="red")

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._ctx._print(f"[DEBUG] Result: {display_result}", style="dim")
        self._plan_tree.render_task_tracker()

    def item_heartbeat(
        self,
        item_id: str,
        elapsed_s: int,
        file_count: int,
        liveness_indicators: dict | None = None,
    ) -> None:
        """Emit heartbeat during long-running item execution.

        Args:
            item_id: ID of the item being executed
            elapsed_s: Seconds elapsed since execution started
            file_count: Number of files changed so far
            liveness_indicators: Optional dict with liveness status (DETAIL level only)
                                 Expected keys: log, cpu, files, db, proc (bool values)
        """
        self._heartbeat_count += 1
        # Note: Footer hint removed from heartbeat - was too noisy
        # Footer now shows only at start and completion

        # QUIET (0): No heartbeat output
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            return

        elapsed_str = self._ctx._format_elapsed(elapsed_s)
        timestamp = self._ctx._timestamp()

        # PROGRESS (1): Show heartbeat with elapsed time and file count
        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            file_summary = self.get_file_summary()
            llm_indicator = ""
            llm_state = self._ctx._llm.get_state()
            if llm_state == "waiting":
                llm_indicator = " [waiting for LLM]"
            elif llm_state == "streaming":
                llm_indicator = " [LLM streaming...]"
            elif llm_state == "processing":
                llm_indicator = " [processing]"
            prefix = "" if self._ctx._is_tty else timestamp
            task_label = self._plan_tree._current_task_label(item_id)
            message = f"{prefix}Executing {task_label}... ({elapsed_str})"
            if file_summary:
                message = f"{message} | {file_summary}"
            if llm_indicator:
                message = f"{message}{llm_indicator}"
            if self._ctx._should_inline_heartbeat():
                suffix = None
                if file_summary:
                    suffix = file_summary
                elif llm_indicator:
                    suffix = llm_indicator.strip()
                task_label = self._plan_tree._current_task_label(item_id)
                self._ctx._update_spinner_status(
                    f"execute — implementing {task_label}",
                    elapsed_s=elapsed_s,
                    suffix=suffix,
                )
                return
            if llm_indicator and self._ctx._is_tty:
                message = message.replace(llm_indicator, f"[dim]{llm_indicator}[/dim]")
            self._ctx._print(message, style="cyan")
            return

        # DETAIL (2+): Show heartbeat with liveness indicators
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            task_label = self._plan_tree._current_task_label(item_id)
            file_str = f", {file_count} files" if file_count > 0 else ""
            llm_indicator = ""
            llm_state = self._ctx._llm.get_state()
            if llm_state == "waiting":
                llm_indicator = " [waiting for LLM]"
            elif llm_state == "streaming":
                llm_indicator = " [LLM streaming...]"
            elif llm_state == "processing":
                llm_indicator = " [processing]"
            base_msg = f"Executing {task_label}... ({elapsed_str}{file_str})"

            # Inline heartbeat on TTY — update spinner in-place, no new line
            if self._ctx._should_inline_heartbeat():
                suffix = None
                if file_count > 0:
                    suffix = f"{file_count} files"
                elif llm_indicator:
                    suffix = llm_indicator.strip()
                self._ctx._update_spinner_status(
                    f"execute — implementing {task_label}",
                    elapsed_s=elapsed_s,
                    suffix=suffix,
                )
                return

            # Non-TTY: print with timestamp, LLM state, and liveness indicators
            printed_msg = f"{timestamp}{base_msg}{llm_indicator}"
            if liveness_indicators:
                indicators = []
                for key in ["log", "cpu", "files", "db", "proc"]:
                    value = liveness_indicators.get(key, False)
                    indicators.append(f"{key}={'Y' if value else 'N'}")
                liveness_str = " [liveness: " + " ".join(indicators) + "]"
                self._ctx._print(printed_msg + liveness_str, style="cyan")
            else:
                self._ctx._print(printed_msg, style="cyan")
            if self._plan_tree.get_progress_summary()["current_id"]:
                self._plan_tree.render_task_tracker()

    # ------------------------------------------------------------------ #
    # Spike heartbeat                                                     #
    # ------------------------------------------------------------------ #

    def spike_heartbeat(
        self,
        elapsed_s: int,
        file_count: int,
        attempt_label: str = "spike",
    ) -> None:
        """Emit heartbeat during spike execution with spike-aware labels.

        Args:
            elapsed_s: Seconds elapsed since spike started
            file_count: Number of files changed in the spike workspace
            attempt_label: Label for the spike attempt (e.g. "spike", "spike 1/3")
        """
        # QUIET (0): No heartbeat output
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            return

        elapsed_str = self._ctx._format_elapsed(elapsed_s)
        timestamp = self._ctx._timestamp()

        # PROGRESS (1): Show spike heartbeat
        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            file_summary = self.get_file_summary()
            if self._ctx._should_inline_heartbeat():
                suffix = file_summary or None
                self._ctx._update_spinner_status(
                    f"{attempt_label} — exploring and implementing",
                    elapsed_s=elapsed_s,
                    suffix=suffix,
                )
                return
            prefix = "" if self._ctx._is_tty else timestamp
            message = f"{prefix}{attempt_label}: implementing... ({elapsed_str})"
            if file_summary:
                message = f"{message} | {file_summary}"
            self._ctx._print(message, style="cyan")
            return

        # DETAIL (2+): Show spike heartbeat with file count
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            file_str = f", {file_count} files" if file_count > 0 else ""
            if self._ctx._should_inline_heartbeat():
                suffix = f"{file_count} files" if file_count > 0 else None
                self._ctx._update_spinner_status(
                    f"{attempt_label} — exploring and implementing",
                    elapsed_s=elapsed_s,
                    suffix=suffix,
                )
                return
            self._ctx._print(
                f"{timestamp}{attempt_label}: implementing... ({elapsed_str}{file_str})",
                style="cyan",
            )

    # ------------------------------------------------------------------ #
    # File events                                                         #
    # ------------------------------------------------------------------ #

    def file_event(
        self,
        filepath: str,
        event_type: str,
        line_count: int | None = None,
    ) -> None:
        """Emit file change event.

        Args:
            filepath: Path to the file that changed (relative to working dir)
            event_type: Type of event - "new" or "modified"
            line_count: Number of lines in the file (DETAIL level only)
        """
        # FIX-FILE-TRACKING-001: Filter out build artifacts from file tracking
        # These are generated files that shouldn't inflate file activity counts
        excluded_patterns = (
            "build/",
            "dist/",
            "__pycache__/",
            ".coverage",
            ".pytest_cache/",
            ".tox/",
            ".egg-info/",
            "node_modules/",
            ".pyc",
            ".pyo",
            ".pyz",
            ".pkg",
            ".toc",
            ".zip",
        )
        if any(pattern in filepath for pattern in excluded_patterns):
            return  # Skip build artifacts

        if event_type == "new":
            self.track_file_created()
        elif event_type == "modified":
            self.track_file_modified()

        # QUIET (0): No file events
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            return

        # PROGRESS (1): Show file event with type indicator
        timestamp = self._ctx._timestamp()
        symbol = "+" if event_type == "new" else "~"

        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            self._ctx._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")
            return

        # DETAIL (2+): Show file event with line count
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            if line_count is not None:
                self._ctx._print(
                    f"{timestamp}  {symbol} {filepath} ({event_type}, {line_count} lines)",
                    style="dim",
                )
            else:
                self._ctx._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")

    def render_file_list(self, recent_files: list[str], max_display: int = 5) -> None:
        """Render a recent file list at DETAIL verbosity and above.

        Args:
            recent_files: Recent file paths to display
            max_display: Max entries to show before truncating
        """
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return

        if not recent_files:
            return

        if len(recent_files) > max_display:
            display_limit = max(max_display - 1, 0)
            visible_files = recent_files[:display_limit]
            remaining = len(recent_files) - display_limit
            file_list = ", ".join(visible_files)
            if file_list:
                file_list = f"{file_list}, ... and {remaining} more"
            else:
                file_list = f"... and {remaining} more"
        else:
            file_list = ", ".join(recent_files[:max_display])
            if not file_list:
                return

        self._ctx._print(f"    {glyphs.tree_last} Recent: {file_list}", style="dim")
