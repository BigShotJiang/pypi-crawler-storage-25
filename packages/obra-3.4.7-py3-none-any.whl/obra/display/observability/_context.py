"""EmitterContext — shared infrastructure for all domain emitters.

EmitterContext owns:
- Rich console + TTY detection
- Spinner lifecycle management
- Pipeline renderer
- Display-limit caches and utility methods
- Cross-domain shared state (_llm via LLMStateManager, _current_stage_context,
  _plan_mode, _derive_step_start_time, _derive_current_step_name,
  _active_stage_name, _active_phase_name, _review_ctx via ReviewContextManager)
- Dashboard config caches

Design decision D1: spinner management is infrastructure, not a domain concern,
so it lives here rather than on any single domain emitter.
"""

import logging
import sys
import threading
from datetime import datetime

from rich.console import Console

from obra.display.pipeline import PipelineRenderer
from obra.display.spinner import StatusSpinner as _StatusSpinner_direct
from obra.display.spinner import set_active_spinner
from obra.display.spinner_status import SpinnerStatus


def _get_spinner_config(key: str):
    """Look up get_spinner_config via the observability package namespace.

    This indirection allows tests to patch obra.display.observability.get_spinner_config
    and have the patch take effect here.
    """
    obs = sys.modules.get("obra.display.observability")
    if obs is not None:
        fn = getattr(obs, "get_spinner_config", None)
        if fn is not None:
            return fn(key)
    from obra.config.loaders import get_spinner_config

    return get_spinner_config(key)


def _get_display_limit(key: str):
    """Look up get_display_limit via the observability package namespace."""
    obs = sys.modules.get("obra.display.observability")
    if obs is not None:
        fn = getattr(obs, "get_display_limit", None)
        if fn is not None:
            return fn(key)
    from obra.config.loaders import get_display_limit

    return get_display_limit(key)


def _get_status_spinner_class():
    """Look up StatusSpinner via the observability package namespace.

    This allows tests to patch obra.display.observability.StatusSpinner and have
    the patch take effect during ProgressEmitter construction.
    """
    obs = sys.modules.get("obra.display.observability")
    if obs is not None:
        cls = getattr(obs, "StatusSpinner", None)
        if cls is not None:
            return cls
    return _StatusSpinner_direct


logger = logging.getLogger(__name__)

# Re-exported here so EmitterContext methods can use them without importing _emitter
_STAGE_USER_LABELS: dict[str, str] = {
    "intent_generation": "intent_generation — elaborating your request",
    "assumptions": "assumptions — resolving missing details",
    "analogues": "analogues — scanning similar solutions",
    "brief": "brief — consolidating intent into a planning brief",
    "derive": "derive — detailing the execution plan",
    "revise": "revise — refining the plan",
    "intent_alignment": "intent_alignment — checking intent coverage",
    "review": "review — running review agents",
    "execute": "execute — implementing plan items",
    "validator": "validator — validating review output",
}

_PHASE_STATUS_LINES: dict[str, str] = {
    "USERPLAN_GENERATION": "plan — generating the user plan",
    "DERIVATION": "derive — detailing the execution plan",
    "REFINEMENT": "revise — refining the plan",
    "REVIEW": "review — preparing review agents",
    "EXECUTION": "execute — implementing plan items",
}

_PHASE_DISPLAY_NAMES: dict[str, str] = {
    "USERPLAN_GENERATION": "User Plan",
    "USERPLAN": "User Plan",
    "DERIVATION": "Derivation",
    "REFINEMENT": "Refinement",
    "STORY0": "Env Setup",
    "EXECUTION": "Execution",
    "REVIEW": "Review",
    "COMPLETED": "Completed",
}

_ALLOWED_LLM_STATES: frozenset[str] = frozenset({"idle", "waiting", "streaming", "processing"})


def get_user_facing_phase_label(phase: str | None) -> str:
    """Return a user-facing phase label for raw internal phase identifiers."""
    normalized = str(phase or "").strip().replace("-", "_").upper()
    if not normalized:
        return "Unknown"
    return _PHASE_DISPLAY_NAMES.get(normalized, normalized.replace("_", " ").title())


class ReviewContextManager:
    """Thread-safe manager for active review context fields."""

    def __init__(self) -> None:
        self._item_id: str | None = None
        self._cycle_id: str | None = None
        self._lock = threading.Lock()

    def set_context(self, item_id: str | None = None, cycle_id: str | None = None) -> None:
        """Update review context with skip-None semantics.

        Only updates fields where the passed value is not None.
        This preserves the existing partial-update pattern.
        """
        with self._lock:
            if item_id is not None:
                self._item_id = item_id
            if cycle_id is not None:
                self._cycle_id = cycle_id

    def set_item_id(self, item_id: str | None) -> None:
        with self._lock:
            self._item_id = item_id

    def set_cycle_id(self, cycle_id: str | None) -> None:
        with self._lock:
            self._cycle_id = cycle_id

    def clear(self) -> None:
        with self._lock:
            self._item_id = None
            self._cycle_id = None

    def get_item_id(self) -> str | None:
        with self._lock:
            return self._item_id

    def get_cycle_id(self) -> str | None:
        with self._lock:
            return self._cycle_id


class LLMStateManager:
    """Thread-safe manager for LLM state and call timing."""

    def __init__(self, allowed_states: frozenset[str]) -> None:
        self._state: str = "idle"
        self._call_start_time: float | None = None
        self._allowed_states = allowed_states
        self._lock = threading.Lock()

    def set_state(self, state: str) -> None:
        if state not in self._allowed_states:
            msg = f"Invalid LLM state: {state}"
            raise ValueError(msg)
        with self._lock:
            self._state = state

    def get_state(self) -> str:
        with self._lock:
            return self._state

    def set_call_start_time(self, t: float | None) -> None:
        with self._lock:
            self._call_start_time = t

    def get_call_start_time(self) -> float | None:
        with self._lock:
            return self._call_start_time


class EmitterContext:
    """Shared infrastructure context for domain emitters.

    Owns spinner management, print routing, utility methods, pipeline renderer,
    display-limit caches, and cross-domain shared state variables.

    All domain emitters receive an EmitterContext at construction and use
    self._ctx for shared operations.
    """

    def __init__(
        self,
        config: object,  # ObservabilityConfig — imported lazily to avoid circularity
        console: Console,
        is_tty: bool,
    ) -> None:

        self.config = config
        self.console = console
        self._is_tty = is_tty

        # --- Spinner lifecycle (D1: infrastructure, not domain) ---
        # Uses _get_spinner_config() which looks up via sys.modules so tests can patch
        # obra.display.observability.get_spinner_config and have patches take effect.
        self._spinner: _StatusSpinner_direct | None = None
        if self._is_tty and _get_spinner_config("enabled"):
            StatusSpinner = _get_status_spinner_class()
            self._spinner = StatusSpinner(
                console,
                phrase_rotation_interval_s=float(_get_spinner_config("phrase_rotation_interval_s")),
                phrase_rotation_min_s=float(_get_spinner_config("phrase_rotation_min_s")),
                phrase_rotation_max_s=float(_get_spinner_config("phrase_rotation_max_s")),
                accent_enabled=bool(_get_spinner_config("accent_enabled")),
                accent_highlight_color=str(_get_spinner_config("accent_highlight_color")),
                accent_highlight_width=int(_get_spinner_config("accent_highlight_width")),
                accent_highlight_gradient=bool(_get_spinner_config("accent_highlight_gradient")),
                accent_sweep_target_s=float(_get_spinner_config("accent_sweep_target_s")),
                accent_step_min_ms=int(_get_spinner_config("accent_step_min_ms")),
                accent_step_max_ms=int(_get_spinner_config("accent_step_max_ms")),
                accent_pause_min_s=float(_get_spinner_config("accent_pause_min_s")),
                accent_pause_max_s=float(_get_spinner_config("accent_pause_max_s")),
                refresh_rate_hz=int(_get_spinner_config("refresh_rate_hz")),
            )
            set_active_spinner(self._spinner)
        # FIX-SPINNER-HANG-001: Named-reasons set replaces fragile reference counter.
        self._spinner_active_reasons: set[str] = set()
        self._spinner_lock = threading.Lock()
        self._spinner_rotation_paused: bool = False
        self._stage_spinner_active: set[str] = set()

        # --- Pipeline renderer ---
        self._pipeline: PipelineRenderer = PipelineRenderer(console)
        self._pipeline_enabled: bool = True
        self._last_pipeline_stage: str | None = None

        # --- Display limit caches (CHORE-MAGIC-VALUES-002) ---
        self._title_max_chars: int = _get_display_limit("title_max_chars")
        self._description_max_chars: int = _get_display_limit("description_max_chars")
        self._note_max_chars: int = _get_display_limit("note_max_chars")
        self._seconds_before_minutes: int = _get_display_limit("seconds_before_minutes")

        # --- Dashboard config caches (read-only after init) ---
        self._dashboard_enabled: bool = bool(config.dashboard_enabled)
        self._footer_hint_enabled: bool = bool(config.footer_hint_enabled)
        self._task_tracker_enabled: bool = bool(config.task_tracker_enabled)
        self._task_tracker_max_next: int = max(0, int(config.task_tracker_max_next))

        # --- Cross-domain shared state (managed) ---
        # LLM state: written by MiscEmitter / LifecycleEmitter; read by ExecutionItemEmitter & LifecycleEmitter
        self._llm = LLMStateManager(_ALLOWED_LLM_STATES)

        # Written by DerivationEmitter & LifecycleEmitter; read by LifecycleEmitter stage_heartbeat
        self._current_stage_context: dict | None = None

        # Written by PlanTreeEmitter & DerivationEmitter; read by PlanTreeEmitter & LifecycleEmitter
        self._plan_mode: str | None = None

        # Written by DerivationEmitter; read by LifecycleEmitter stage_heartbeat
        self._derive_step_start_time: float | None = None
        self._derive_current_step_name: str | None = None

        # Written by LifecycleEmitter; read by _restore_spinner_status_line (utility)
        self._active_stage_name: str | None = None
        self._active_phase_name: str | None = None

        # Review context: written by ReviewEmitter; reset by LifecycleEmitter on EXECUTION phase start
        self._review_ctx = ReviewContextManager()

    # ------------------------------------------------------------------ #
    # Print routing                                                         #
    # ------------------------------------------------------------------ #

    def _print(self, message: str, style: str | None = None, end: str = "\n") -> None:
        """Print message with or without Rich formatting based on TTY detection.

        When the status spinner is active, routes through print_above().
        """
        if self._spinner and self._spinner.is_active and end == "\n":
            self._spinner.print_above(message, style=style)
            return
        if self._is_tty:
            self.console.print(message, style=style, end=end)
        else:
            self.console.print(message, end=end, markup=False)

    # ------------------------------------------------------------------ #
    # Spinner lifecycle                                                     #
    # ------------------------------------------------------------------ #

    def start_spinner(self, phrase: str | None = None, *, reason: str = "") -> None:
        """Start the status spinner for long operations.

        The legacy ``phrase`` parameter is ignored. Spinner text now comes only
        from explicit stage/phase status updates.
        """
        from obra.display.observability._emitter import VerbosityLevel

        del phrase
        if not self._spinner or self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        with self._spinner_lock:
            was_empty = len(self._spinner_active_reasons) == 0
            self._spinner_active_reasons.add(reason)
            if not was_empty:
                return
        self._spinner_rotation_paused = False
        self._spinner.start()
        self._restore_spinner_status_line()

    def stop_spinner(self, *, reason: str = "") -> None:
        """Remove a reason tag and stop the spinner if no reasons remain."""
        if not self._spinner:
            return
        with self._spinner_lock:
            self._spinner_active_reasons.discard(reason)
            if self._spinner_active_reasons:
                if self._spinner_rotation_paused:
                    self._spinner.set_rotation_paused(False)
                    self._spinner_rotation_paused = False
                return
        if self._spinner_rotation_paused:
            self._spinner.set_rotation_paused(False)
            self._spinner_rotation_paused = False
        self._spinner.stop()

    def halt_spinner(self) -> None:
        """Immediately stop the status spinner, regardless of active reasons."""
        try:
            with self._spinner_lock:
                if self._spinner_active_reasons:
                    logger.debug(
                        "halt_spinner: force-clearing active reasons: %s",
                        self._spinner_active_reasons,
                    )
                self._spinner_active_reasons.clear()
                self._stage_spinner_active.clear()
            self._spinner_rotation_paused = False
            if self._spinner and self._spinner.is_active:
                self._spinner.stop()
        except Exception:
            pass

    def _start_stage_spinner(self, stage: str) -> None:
        """Start spinner for a stage if not already tracked."""
        if stage in self._stage_spinner_active:
            return
        self._stage_spinner_active.add(stage)
        self.start_spinner(reason=f"stage:{stage}")

    def _stop_stage_spinner(self, stage: str) -> None:
        """Stop spinner for a stage if it was previously started."""
        if stage not in self._stage_spinner_active:
            return
        self._stage_spinner_active.remove(stage)
        self.stop_spinner(reason=f"stage:{stage}")

    def _should_inline_heartbeat(self) -> bool:
        from obra.display.observability._emitter import VerbosityLevel

        return (
            self._is_tty
            and self._spinner is not None
            and self._spinner.is_active
            and self.config.verbosity >= VerbosityLevel.PROGRESS
        )

    def use_inline_heartbeat(self) -> bool:
        """Return True if heartbeat should update the active spinner in-place."""
        return self._should_inline_heartbeat()

    # ------------------------------------------------------------------ #
    # Utility methods                                                       #
    # ------------------------------------------------------------------ #

    def _truncate_title(self, title: str) -> str:
        """Truncate title to configured max length with ellipsis."""
        limit = self._title_max_chars
        return title[:limit] + "..." if len(title) > limit else title

    def _truncate_description(self, text: str) -> str:
        """Truncate description/objective to configured max length with ellipsis."""
        limit = self._description_max_chars
        return text[:limit] + "..." if len(text) > limit else text

    def _truncate_note(self, text: str) -> str:
        """Truncate status note to configured max length with ellipsis."""
        limit = self._note_max_chars
        return text[:limit] + "..." if len(text) > limit else text

    def _get_stage_label(self, stage: str) -> str:
        base_stage = stage.split("_pass_", maxsplit=1)[0]
        return _STAGE_USER_LABELS.get(base_stage, base_stage.replace("_", " ").title())

    def _get_phase_status_line(self, phase: str | None) -> str | None:
        if not phase:
            return None
        return _PHASE_STATUS_LINES.get(str(phase).upper())

    def _get_stage_status_line(self, stage: str | None) -> str | None:
        if not stage:
            return None
        base_stage = str(stage).split("_pass_")[0]
        return _STAGE_USER_LABELS.get(base_stage)

    def _restore_spinner_status_line(self) -> None:
        """Restore spinner status to current stage/phase context, or clear when unknown."""
        if not self._spinner or not self._spinner.is_active:
            return

        status_line = self._get_stage_status_line(self._active_stage_name)
        if not status_line:
            status_line = self._get_phase_status_line(self._active_phase_name)

        if status_line:
            self._spinner.update_status_line(status_line, style="cyan")
        else:
            self._spinner.clear_status_line()

    def _spinner_interrupt_hint(self) -> str | None:
        """Return the canonical inline interrupt hint for active TTY spinner sessions."""
        if not self._is_tty or not self._spinner or not self._spinner.is_active:
            return None
        return "Ctrl+C to interrupt"

    def _update_spinner_status(
        self,
        label: str,
        *,
        elapsed_s: int | None = None,
        suffix: str | None = None,
        style: str | None = "cyan",
    ) -> None:
        """Update the active spinner with structured action-first status text."""
        if not self._spinner or not self._spinner.is_active:
            return
        self._spinner.update_status(
            SpinnerStatus(
                label=label,
                elapsed_s=elapsed_s,
                interrupt_hint=self._spinner_interrupt_hint(),
                suffix=suffix,
            ),
            style=style,
        )

    def _timestamp(self) -> str:
        """Get current timestamp in [HH:MM:SS] format."""
        if self.config.timestamps:
            return f"[{datetime.now().strftime('%H:%M:%S')}] "
        return ""

    def _format_status_line(self, status: str, message: str) -> str:
        """Format a status-first line with an optional timestamp."""
        timestamp = self._timestamp().strip()
        if timestamp:
            return f"{status} {timestamp} {message}"
        return f"{status} {message}"

    def _format_elapsed(self, elapsed_s: int) -> str:
        minutes = max(0, int(elapsed_s)) // 60
        seconds = max(0, int(elapsed_s)) % 60
        return f"{minutes}m {seconds:02d}s"

    def _dashboard_feature_enabled(self, enabled: bool) -> bool:
        """Return True if a dashboard UI element should render."""
        from obra.display.observability._emitter import VerbosityLevel

        return (
            self._dashboard_enabled and enabled and self.config.verbosity >= VerbosityLevel.PROGRESS
        )
