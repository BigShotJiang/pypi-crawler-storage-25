"""Custom build backend that enforces package isolation.

This module wraps setuptools.build_meta and adds a mandatory check
that prevents building wheels containing imports from src/.

CLAUDE.md Rule 21: The obra/ package must be 100% self-contained.
Any 'from src.' or 'import src.' statements will cause the build to fail.

This check is DETERMINISTIC and UN-BYPASSABLE:
- Runs on every `python -m build` invocation
- Cannot be skipped or worked around
- Fails fast with clear error message

See: ISSUE-SAAS-042, ADR for package isolation
"""

import ast
import base64
import hashlib
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

# Re-export everything from setuptools.build_meta for PEP 517 compliance
from setuptools.build_meta import *  # type: ignore[import-untyped]  # noqa: F403
from setuptools.build_meta import (
    build_wheel as _original_build_wheel,  # type: ignore[import-untyped]
)

INTERNAL_WHEEL_EXCLUDES = (
    "obra/benchmarks/",
    "obra/cli/local.py",
    "obra/cli/simulate.py",
    "obra/cli/simulation/",
    "obra/cli/simulation_contracts.py",
    "obra/cli/simulation_preflight.py",
)


def _find_src_imports(file_path: Path) -> list[str]:
    """Find all imports from src in a Python file.

    Returns list of violation descriptions. Empty list means clean.

    NOTE: Unlike the test file, this does NOT allow try/except exceptions.
    Per CLAUDE.md Rule 21: "NEVER add try/except fallbacks for graceful degradation"
    """
    try:
        content = file_path.read_text(encoding="utf-8")
        tree = ast.parse(content)
    except (SyntaxError, UnicodeDecodeError):
        return []

    violations = []

    for node in ast.walk(tree):
        # Check: import src or import src.foo
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "src" or alias.name.startswith("src."):
                    violations.append(f"Line {node.lineno}: import {alias.name}")

        # Check: from src import foo or from src.bar import baz
        elif isinstance(node, ast.ImportFrom):
            if node.module and (node.module == "src" or node.module.startswith("src.")):
                names = ", ".join(a.name for a in node.names)
                violations.append(f"Line {node.lineno}: from {node.module} import {names}")

    return violations


def _check_package_isolation() -> dict[str, list[str]]:
    """Check all obra package files for src imports.

    Returns dict mapping file paths to their violations.
    Empty dict means all clean.
    """
    # Find the obra package root (parent of this file)
    obra_root = Path(__file__).parent

    all_violations = {}

    for py_file in obra_root.rglob("*.py"):
        # Skip test files (not distributed)
        if "/tests/" in str(py_file) or py_file.name.startswith("test_"):
            continue

        # Skip build artifacts (CHORE-BUILD-ARTIFACT-SURFACE-001)
        if "/build/" in str(py_file) or "/dist/" in str(py_file):
            continue

        # Skip this file itself
        if py_file.name == "_build_backend.py":
            continue

        violations = _find_src_imports(py_file)
        if violations:
            # Use relative path for cleaner output
            rel_path = py_file.relative_to(obra_root)
            all_violations[str(rel_path)] = violations

    return all_violations


def _print_violation_report(violations: dict[str, list[str]]) -> None:
    """Print a clear, actionable violation report."""
    print("\n" + "=" * 70, file=sys.stderr)
    print("BUILD FAILED: Package isolation check detected src/ imports", file=sys.stderr)
    print("=" * 70, file=sys.stderr)
    print(file=sys.stderr)
    print(
        "The obra package must be 100% self-contained (CLAUDE.md Rule 21).",
        file=sys.stderr,
    )
    print("The following files contain imports from src/:", file=sys.stderr)
    print(file=sys.stderr)

    for file_path, file_violations in sorted(violations.items()):
        print(f"  {file_path}:", file=sys.stderr)
        for v in file_violations:
            print(f"    - {v}", file=sys.stderr)

    print(file=sys.stderr)
    print("Fix options:", file=sys.stderr)
    print("  1. Move the required code INTO obra/ (preferred)", file=sys.stderr)
    print("  2. Duplicate the minimal required code", file=sys.stderr)
    print("  3. Remove the import if not needed", file=sys.stderr)
    print(file=sys.stderr)
    print("DO NOT use try/except fallbacks - they mask the problem.", file=sys.stderr)
    print("=" * 70 + "\n", file=sys.stderr)


def _is_excluded_wheel_member(member_name: str) -> bool:
    """Return whether a wheel member should be stripped from public builds."""
    normalized = member_name.replace("\\", "/")
    return any(
        normalized == excluded or normalized.startswith(excluded)
        for excluded in INTERNAL_WHEEL_EXCLUDES
    )


def _hash_wheel_payload(payload: bytes) -> str:
    """Return a wheel RECORD-compliant sha256 hash for payload bytes."""
    digest = hashlib.sha256(payload).digest()
    return "sha256=" + base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def _rewrite_public_wheel(wheel_path: Path) -> None:
    """Strip internal-only modules from the public wheel."""
    with tempfile.NamedTemporaryFile(
        prefix=wheel_path.stem + "-public-",
        suffix=".whl",
        delete=False,
        dir=wheel_path.parent,
    ) as tmp_file:
        temp_wheel = Path(tmp_file.name)

    try:
        with (
            zipfile.ZipFile(wheel_path) as source_zip,
            zipfile.ZipFile(
                temp_wheel,
                "w",
                compression=zipfile.ZIP_DEFLATED,
            ) as target_zip,
        ):
            record_path: str | None = None
            written_payloads: list[tuple[str, bytes]] = []

            for info in source_zip.infolist():
                member_name = info.filename
                if _is_excluded_wheel_member(member_name):
                    continue
                if member_name.endswith(".dist-info/RECORD"):
                    record_path = member_name
                    continue

                payload = source_zip.read(member_name)
                target_zip.writestr(info, payload)
                written_payloads.append((member_name, payload))

            if record_path is None:
                raise RuntimeError("Wheel missing .dist-info/RECORD; cannot rewrite public wheel")

            record_rows: list[list[str]] = []
            for member_name, payload in written_payloads:
                record_rows.append([member_name, _hash_wheel_payload(payload), str(len(payload))])

            record_rows.append([record_path, "", ""])
            record_buffer = []
            for row in record_rows:
                record_buffer.append(",".join(row))
            record_payload = ("\n".join(record_buffer) + "\n").encode("utf-8")
            target_zip.writestr(record_path, record_payload)

        os.replace(temp_wheel, wheel_path)
    finally:
        if temp_wheel.exists():
            temp_wheel.unlink()


def _sync_workflow_studio_assets() -> None:
    """Copy built Workflow Studio assets into the packaged runtime surface."""
    obra_root = Path(__file__).parent
    repo_root = obra_root.parent
    source_dist = repo_root / "clients" / "workflow-studio-web" / "dist"
    target_dist = obra_root / "studio_web" / "dist"

    if not (source_dist / "index.html").exists():
        raise RuntimeError(
            "Workflow Studio browser assets are missing. Run "
            "`cd clients/workflow-studio-web && npm run build`, then retry the wheel build."
        )

    if target_dist.exists():
        shutil.rmtree(target_dist)
    target_dist.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_dist, target_dist)


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    """Build wheel after validating package isolation.

    This is the main entry point called by `python -m build --wheel`.
    The isolation check runs BEFORE any wheel building occurs.
    """
    violations = _check_package_isolation()

    if violations:
        _print_violation_report(violations)
        # Exit with error - do not proceed to build
        sys.exit(1)

    _sync_workflow_studio_assets()

    # All clean - proceed with normal build
    wheel_name = _original_build_wheel(wheel_directory, config_settings, metadata_directory)
    wheel_path = Path(wheel_directory) / wheel_name
    _rewrite_public_wheel(wheel_path)
    return wheel_name


def build_sdist(_sdist_directory, _config_settings=None):
    """Block sdist builds entirely.

    Per IP protection policy, we only distribute wheels (compiled bytecode),
    never source distributions. This prevents source code from being
    published to PyPI.
    """
    print("\n" + "=" * 70, file=sys.stderr)
    print("BUILD FAILED: Source distributions (sdist) are not allowed", file=sys.stderr)
    print("=" * 70, file=sys.stderr)
    print(file=sys.stderr)
    print("The obra package is proprietary and must be distributed as", file=sys.stderr)
    print("wheel-only to protect source code.", file=sys.stderr)
    print(file=sys.stderr)
    print("Use: python -m build --wheel", file=sys.stderr)
    print("Not:  python -m build  (builds both sdist and wheel)", file=sys.stderr)
    print("=" * 70 + "\n", file=sys.stderr)
    sys.exit(1)
