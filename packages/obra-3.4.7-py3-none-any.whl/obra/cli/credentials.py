"""Connector credential management commands."""

from __future__ import annotations

import json
from typing import Annotated, Any

import typer

from obra.connectors.credentials import CredentialStore

credentials_app = typer.Typer(help="Manage local connector credentials")


def _emit(payload: dict[str, Any] | list[dict[str, Any]], *, json_output: bool) -> None:
    if json_output:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
        return
    if isinstance(payload, list):
        for item in payload:
            typer.echo(f"{item.get('name')}: {item.get('type')} ({item.get('status')})")
        return
    for key, value in payload.items():
        typer.echo(f"{key}: {value}")


@credentials_app.command("add")
def add_credential(
    name: str,
    credential_type: Annotated[str, typer.Option("--type", help="api_key, bearer, or oauth2")],
    api_key: str | None = typer.Option(None, "--api-key"),
    access_token: str | None = typer.Option(None, "--access-token"),
    refresh_token: str | None = typer.Option(None, "--refresh-token"),
    token_url: str | None = typer.Option(None, "--token-url"),
    client_id: str | None = typer.Option(None, "--client-id"),
    client_secret: str | None = typer.Option(None, "--client-secret"),
    expires_at: float | None = typer.Option(None, "--expires-at"),
    header_name: str = typer.Option("Authorization", "--header-name"),
    prefix: str = typer.Option("", "--prefix"),
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Add or update one local connector credential."""
    payload: dict[str, Any] = {"type": credential_type}
    if credential_type == "api_key":
        payload.update({"api_key": api_key or "", "header_name": header_name, "prefix": prefix})
    elif credential_type == "bearer":
        payload.update({"access_token": access_token or ""})
    elif credential_type == "oauth2":
        payload.update(
            {
                "access_token": access_token or "",
                "refresh_token": refresh_token or "",
                "token_url": token_url or "",
                "client_id": client_id or "",
                "client_secret": client_secret or "",
                "expires_at": expires_at,
            }
        )
    else:
        raise typer.BadParameter("Credential type must be one of: api_key, bearer, oauth2")

    store = CredentialStore()
    store.put(name, payload)
    _emit({"name": name, "type": credential_type, "status": "stored"}, json_output=json_output)


@credentials_app.command("list")
def list_credentials(
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """List configured local connector credentials."""
    payload = CredentialStore().list_credentials()
    _emit(payload, json_output=json_output)


@credentials_app.command("remove")
def remove_credential(
    name: str,
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Remove one configured local connector credential."""
    removed = CredentialStore().remove(name)
    _emit({"name": name, "removed": removed}, json_output=json_output)


@credentials_app.command("refresh")
def refresh_credential(
    name: str,
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Refresh one renewable local connector credential."""
    credential = CredentialStore().refresh(name)
    _emit(
        {"name": name, "type": getattr(credential, "credential_type", "unknown"), "status": "refreshed"},
        json_output=json_output,
    )


@credentials_app.command("doctor")
def doctor_credentials(
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Inspect local connector credential store health."""
    payload = CredentialStore().doctor()
    _emit(payload, json_output=json_output)
