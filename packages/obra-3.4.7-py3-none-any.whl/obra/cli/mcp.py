"""CLI commands for the Obra MCP server.

Provides the `obra mcp serve` command to start the MCP server with
stdio or streamable-http transports.
"""

from __future__ import annotations

import os

import typer

mcp_app = typer.Typer(
    name="mcp",
    help="Obra MCP server for AI client integration.",
    no_args_is_help=True,
)


@mcp_app.command("serve")
def serve(
    transport: str = typer.Option(
        "stdio",
        "--transport",
        "-t",
        help="Transport mode: 'stdio' (local) or 'http' (streamable-http).",
    ),
    port: int = typer.Option(
        3100,
        "--port",
        "-p",
        help="Port for streamable-http transport (only used when --transport http).",
    ),
    gateway_url: str | None = typer.Option(
        None,
        "--gateway-url",
        help="Obra gateway base URL. Falls back to config mcp.gateway_base_url.",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="Bearer token for gateway auth. Falls back to OBRA_GATEWAY_AUTH_TOKEN / config.",
    ),
) -> None:
    """Start the Obra MCP server for AI client integration.

    The MCP server exposes Obra's software development orchestration as
    standardized MCP tools and resources. Compatible with OpenClaw, Claude
    Desktop, Cursor, and any MCP client.

    Examples:
        obra mcp serve                           # stdio (default)
        obra mcp serve --transport http          # streamable-http on port 3100
        obra mcp serve -t http -p 8080           # custom port
        obra mcp serve --gateway-url http://remote:18790  # remote gateway
    """
    from obra.config.loaders import load_config

    config = load_config()

    # Apply CLI overrides
    if "mcp" not in config:
        config["mcp"] = {}
    if gateway_url:
        config["mcp"]["gateway_base_url"] = gateway_url
    if token:
        if "gateway" not in config:
            config["gateway"] = {}
        config["gateway"]["auth_token"] = token
    elif os.environ.get("OBRA_GATEWAY_AUTH_TOKEN"):
        if "gateway" not in config:
            config["gateway"] = {}
        config["gateway"]["auth_token"] = os.environ["OBRA_GATEWAY_AUTH_TOKEN"]

    from obra.mcp.mcp_server import ObraMCPServer

    server = ObraMCPServer(config)

    if transport == "http":
        server.start_http(port)
    else:
        server.start_stdio()
