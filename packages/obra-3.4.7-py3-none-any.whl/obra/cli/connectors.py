"""Connector SDK CLI commands."""

from __future__ import annotations

import importlib
import json
from pathlib import Path
from typing import Any

import typer

from obra.api.protocol import PipelineStageRequest, StageRunnerContext
from obra.connectors.decorators import get_registered_operation
from obra.hybrid.stage_runner_loader import _import_runner_factory
from obra.workflow.runner_catalog import RunnerCatalogEntry
from obra.workflow.runner_catalog_sources import (
    _entry_points_for_group,
    load_shared_extension_runner_catalog_entries,
)

connectors_app = typer.Typer(help="Scaffold, inspect, and test connector packages")


def _emit(payload: dict[str, Any] | list[dict[str, Any]], *, json_output: bool) -> None:
    if json_output:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
        return
    if isinstance(payload, list):
        for item in payload:
            typer.echo(item.get("id") or item.get("path") or json.dumps(item))
        return
    typer.echo(json.dumps(payload, indent=2, sort_keys=True))


def _connector_entries() -> list[RunnerCatalogEntry]:
    entries = load_shared_extension_runner_catalog_entries()
    return [
        entry
        for entry in entries
        if "connector" in entry.tags
        or str(entry.source.package or "").startswith("obra-connector-")
    ]


def _find_entry(operation_id: str) -> RunnerCatalogEntry:
    for entry in _connector_entries():
        if entry.id == operation_id:
            return entry
    raise typer.BadParameter(f"Connector operation '{operation_id}' was not found")


def _definition_from_entry(entry: RunnerCatalogEntry) -> Any:
    provider_root = (entry.source.module or entry.activation.factory or "").split(".", 1)[0]
    if not provider_root and entry.source.package:
        provider_root = str(entry.source.package).replace("-", "_")
    return get_registered_operation(provider_root, entry.id, entry.version)


def _scaffold_files(connector_name: str) -> dict[str, str]:
    slug = connector_name.strip().lower().replace("_", "-")
    module_name = slug.replace("-", "_")
    package_dir = f"obra-connector-{slug}"
    package_name = f"obra_connector_{module_name}"
    return {
        "package_dir": package_dir,
        "pyproject": f"{package_dir}/pyproject.toml",
        "package_init": f"{package_dir}/{package_name}/__init__.py",
        "operations_init": f"{package_dir}/{package_name}/operations/__init__.py",
        "operation_file": f"{package_dir}/{package_name}/operations/example_operation.py",
        "connector_yaml": f"{package_dir}/connector.yaml",
        "test_file": f"{package_dir}/tests/test_example_operation.py",
    }


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


@connectors_app.command("list")
def list_connectors(
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """List installed connector operations."""
    payload = [
        {
            "id": entry.id,
            "version": entry.version,
            "display_name": entry.display_name,
            "package": entry.source.package,
            "module": entry.source.module,
            "factory": entry.activation.factory,
            "tags": list(entry.tags),
        }
        for entry in _connector_entries()
    ]
    _emit({"connectors": payload}, json_output=json_output)


@connectors_app.command("describe")
def describe_connector(
    operation_id: str,
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Describe one installed connector operation."""
    entry = _find_entry(operation_id)
    definition = _definition_from_entry(entry)
    payload = {
        "id": entry.id,
        "version": entry.version,
        "connector": entry.source.package,
        "display_name": entry.display_name,
        "input_schema": definition.input_schema,
        "output_schema": definition.output_schema,
        "auth_type": definition.auth_type,
        "async_mode": definition.async_mode,
        "summary": definition.summary,
        "description": definition.description,
    }
    _emit(payload, json_output=json_output)


@connectors_app.command("test")
def test_connector(
    operation_id: str,
    input: str = typer.Option("{}", "--input", help="JSON object payload"),
    credentials: str = typer.Option("", "--credentials", help="Local credential reference"),
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Execute one connector operation in isolation."""
    entry = _find_entry(operation_id)
    input_payload = json.loads(input)
    if not isinstance(input_payload, dict):
        raise typer.BadParameter("--input must parse to a JSON object")
    factory = _import_runner_factory(entry.activation.factory or "")
    request = PipelineStageRequest(
        stage_name=entry.id,
        trigger="manual_test",
        input_type="connector_test",
        runner_kind=entry.kind.value,
        runner_id=entry.id,
        runner_version=entry.version,
        stage_execution_id=f"test:{entry.id}",
        context=StageRunnerContext(
            stage_name=entry.id,
            stage_execution_id=f"test:{entry.id}",
            trigger="manual_test",
            input_type="connector_test",
            payload=input_payload,
            credentials_ref=credentials,
            timeout_s=600,
        ),
        timeout_s=600,
        content=input_payload,
    )
    runner = factory(request)
    result = runner.execute(request).to_dict()
    _emit(result, json_output=json_output)


@connectors_app.command("validate")
def validate_connectors(
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Validate installed connector entry points and catalog entries."""
    errors: list[dict[str, Any]] = []
    validated: list[dict[str, Any]] = []
    for entry_point in _entry_points_for_group("obra.runners"):
        try:
            provider = entry_point.load()
            raw_entries = provider() if callable(provider) else provider
            entries = raw_entries if isinstance(raw_entries, list) else [raw_entries]
            for raw_entry in entries:
                normalized = RunnerCatalogEntry.from_mapping(raw_entry)
                validated.append(
                    {
                        "entry_point": entry_point.name,
                        "id": normalized.id,
                        "version": normalized.version,
                    }
                )
        except Exception as exc:
            errors.append(
                {
                    "error": "ENTRY_POINT_LOAD_FAILED",
                    "entry_point": entry_point.name,
                    "actual": f"{type(exc).__name__}: {exc}",
                }
            )
    payload = {"ok": not errors, "validated": validated, "errors": errors}
    _emit(payload, json_output=json_output)
    if errors:
        raise typer.Exit(1)


@connectors_app.command("scaffold")
def scaffold_connector(
    connector_name: str,
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Generate a new connector package scaffold in the current directory."""
    files = _scaffold_files(connector_name)
    slug = connector_name.strip().lower().replace("_", "-")
    module_name = slug.replace("-", "_")
    package_name = f"obra_connector_{module_name}"
    factory_path = f"{package_name}:build_stage_runner"
    _write(
        Path(files["pyproject"]),
        "\n".join(
            [
                "[build-system]",
                'requires = ["setuptools>=68.0", "wheel"]',
                'build-backend = "setuptools.build_meta"',
                "",
                "[project]",
                f'name = "obra-connector-{slug}"',
                'version = "0.1.0"',
                f'description = "Connector package for {slug}"',
                'requires-python = ">=3.12"',
                'dependencies = ["obra>=3.2.36"]',
                "",
                '[project.entry-points."obra.runners"]',
                f'"{slug}" = "{package_name}:get_runner_catalog_entries"',
                "",
                "[tool.setuptools]",
                f'package-dir = {{"{package_name}" = "{package_name}"}}',
                f'packages = ["{package_name}", "{package_name}.operations"]',
                "",
            ]
        ),
    )
    _write(
        Path(files["package_init"]),
        "\n".join(
            [
                '"""Connector package scaffold."""',
                "",
                "from __future__ import annotations",
                "",
                "from obra.connectors._bridge import build_provider_catalog_entries, build_stage_runner as _build_stage_runner",
                "",
                f'PROVIDER_ROOT = "{package_name}"',
                "",
                "",
                "def _import_operations() -> None:",
                f"    import {package_name}.operations  # noqa: F401",
                "",
                "",
                "def get_runner_catalog_entries() -> list[dict[str, object]]:",
                "    _import_operations()",
                "    return build_provider_catalog_entries(",
                "        provider_root=PROVIDER_ROOT,",
                f'        package_name="obra-connector-{slug}",',
                f'        factory_path="{factory_path}",',
                "    )",
                "",
                "",
                "def build_stage_runner(request):",
                "    _import_operations()",
                "    return _build_stage_runner(request, provider_root=PROVIDER_ROOT)",
                "",
            ]
        ),
    )
    _write(Path(files["operations_init"]), "from . import example_operation  # noqa: F401\n")
    _write(
        Path(files["operation_file"]),
        "\n".join(
            [
                '"""Example connector operation."""',
                "",
                "from obra.connectors import operation",
                "",
                "",
                '@operation(id="example.operation", version="1.0.0", input_schema={"type": "object"}, output_schema={"type": "object"})',
                "def example_operation(inputs: dict) -> dict:",
                '    return {"echo": inputs}',
                "",
            ]
        ),
    )
    _write(
        Path(files["connector_yaml"]),
        "\n".join(
            [
                f"name: obra-connector-{slug}",
                f"description: Connector scaffold for {slug}",
                "author: Unpossible Creations, Inc.",
                "license: Proprietary",
                "",
            ]
        ),
    )
    _write(
        Path(files["test_file"]),
        "\n".join(
            [
                "from importlib import import_module",
                "",
                "",
                "def test_scaffold_package_imports() -> None:",
                f'    module = import_module("{package_name}")',
                "    assert callable(module.get_runner_catalog_entries)",
                "",
            ]
        ),
    )
    manifest = {
        "connector_name": connector_name,
        "package_dir": files["package_dir"],
        "files": [
            {"path": path, "purpose": key.replace("_", " ")}
            for key, path in files.items()
        ],
    }
    _emit(manifest, json_output=json_output)
