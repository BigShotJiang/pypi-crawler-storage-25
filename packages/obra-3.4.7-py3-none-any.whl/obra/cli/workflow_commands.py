"""Portable workflow package CLI commands."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import requests
import typer

from obra.cli.studio_runtime import (
    _gateway_base_url,
    load_studio_gateway_state,
    recover_studio_gateway_state,
)
from obra.config.loaders import get_gateway_config
from obra.display import handle_encoding_errors, print_error, print_success
from obra.workflow.package import sanitize_package_filename_component

logger = logging.getLogger(__name__)

workflow_app = typer.Typer(help="Export and import portable workflow packages")


def _resolve_gateway_connection() -> tuple[str, str]:
    gateway_config = get_gateway_config()
    host = str(gateway_config["host"])
    port = int(gateway_config["port"])
    token = ""

    state = load_studio_gateway_state()
    if state is not None and state.host == host and state.port == port:
        recovered = recover_studio_gateway_state(state)
        if recovered is not None:
            token = str(recovered.token or "").strip()

    if not token:
        token = str(gateway_config.get("auth_token") or "").strip()

    if not token:
        raise RuntimeError(
            "Gateway authentication token is unavailable. Start `obra studio` or set "
            "OBRA_GATEWAY_AUTH_TOKEN / gateway.auth_token first."
        )

    return _gateway_base_url(host, port), token


def _request_gateway_json(
    method: str,
    path: str,
    *,
    params: dict[str, str],
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    base_url, token = _resolve_gateway_connection()
    response = requests.request(
        method,
        f"{base_url}{path}",
        params=params,
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )
    if response.ok:
        return dict(response.json())

    detail = ""
    try:
        body = response.json()
        if isinstance(body, dict):
            detail = str(body.get("detail") or body)
        else:
            detail = str(body)
    except Exception:
        detail = response.text.strip()
    detail_suffix = f": {detail}" if detail else ""
    raise RuntimeError(
        f"Gateway request failed ({response.status_code} {response.reason}){detail_suffix}"
    )


@workflow_app.command("export")
@handle_encoding_errors
def export_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID to export"),
    project_id: str = typer.Option(..., "--project-id", help="Project ID owning the workflow"),
    working_dir: str | None = typer.Option(
        None,
        "--working-dir",
        help="Explicit working directory override for project-scoped knowledge lookup",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Destination path for the exported .obra file",
    ),
) -> None:
    """Export one workflow as a portable .obra package."""
    try:
        payload = _request_gateway_json(
            "GET",
            f"/api/workflows/{workflow_id}/export-package",
            params={
                "project_id": project_id,
                **({"working_dir": working_dir} if working_dir else {}),
            },
        )
        manifest = payload.get("manifest")
        manifest = manifest if isinstance(manifest, dict) else {}
        default_name = sanitize_package_filename_component(
            str(manifest.get("title") or workflow_id),
            fallback=workflow_id,
        )
        output_path = Path(output) if output is not None else Path(f"{default_name}.obra")
        output_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        print_success(f"Workflow package exported to {output_path}")
    except Exception as exc:
        logger.exception("Workflow export failed")
        print_error(str(exc))
        raise typer.Exit(code=1) from exc


@workflow_app.command("import")
@handle_encoding_errors
def import_workflow(
    file_path: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the .obra package file",
    ),
    project_id: str = typer.Option(..., "--project-id", help="Project ID receiving the workflow"),
    working_dir: str | None = typer.Option(
        None,
        "--working-dir",
        help="Explicit working directory override for project-scoped knowledge import",
    ),
) -> None:
    """Import one portable .obra package as a new workflow."""
    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Workflow package JSON must be an object")
        result = _request_gateway_json(
            "POST",
            "/api/workflows/import-package",
            params={
                "project_id": project_id,
                **({"working_dir": working_dir} if working_dir else {}),
            },
            payload=payload,
        )
        workflow_id = str(result.get("workflow_id") or "").strip()
        stage_count = int(result.get("stage_count") or 0)
        print_success(
            f"Imported workflow {workflow_id} ({stage_count} stages)"
            if workflow_id
            else f"Imported workflow package ({stage_count} stages)"
        )
    except Exception as exc:
        logger.exception("Workflow import failed")
        print_error(str(exc))
        raise typer.Exit(code=1) from exc
