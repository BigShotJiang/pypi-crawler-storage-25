"""Launch-context helpers for the shared CLI run/derive flow."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from http import HTTPStatus
from pathlib import Path
from typing import Any

import typer

from obra.cli.run_support.derive_inputs import (
    _resolve_and_validate_project_id,
    _validate_project_id_against_server,
)
from obra.cli.run_support.planning_context import (
    _extract_plan_context,
    _find_plan_yaml,
    _load_plan_context_from_file,
    _print_plan_lookup_error,
)
from obra.display import console, print_error, print_info, print_warning
from obra.display.errors import display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError
from obra.models.story0_state import session_story0_state_path
from obra.session.working_dir import (
    resolve_working_dir_selection as _resolve_working_dir_selection,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ContinueFromResolution:
    """Resolved inputs for `--continue-from` session handoff."""

    objective: str | None
    objective_display: str
    plan_context: dict[str, Any] | None
    session_data: dict[str, Any] | None
    skip_completed_items: list[str] = field(default_factory=list)
    intent_id: str | None = None
    skip_intent: bool = False


@dataclass(frozen=True)
class ResolvedLaunchContext:
    """Resolved project, working-directory, and resume-target state."""

    project_id: str
    work_dir: Path
    session_id: str | None
    session_data: dict[str, Any] | None
    session_project_id: str | None
    resume_target: str | None


@dataclass(frozen=True)
class PlanLaunchContext:
    """Resolved plan import and UserPlan state for a launch."""

    plan_context: dict[str, Any] | None
    effective_plan_id: str | None
    userplan_id: str | None


def resolve_continue_from(
    *,
    continue_from: str | None,
    objective: str | None,
    working_dir: Path | None,
    skip_intent_requested: bool,
) -> ContinueFromResolution:
    """Resolve `--continue-from` inputs into explicit continuation state."""
    if not continue_from:
        return ContinueFromResolution(
            objective=None,
            objective_display="<unknown>",
            plan_context=None,
            session_data=None,
            skip_completed_items=[],
            skip_intent=False,
        )

    try:
        from obra.api import APIClient
        from obra.session.continue_from import build_continue_context

        client = APIClient.from_config()
        continue_ctx = build_continue_context(
            client=client,
            session_id=continue_from,
            objective=objective,
            working_dir=working_dir,
            plan_context_extractor=_extract_plan_context,
        )

        objective_override = (
            objective.strip() if isinstance(objective, str) and objective.strip() else None
        )
        resolved_objective = objective_override or continue_ctx.resolved_objective or "<unknown>"

        console.print()
        print_info(f"Continuing from session {continue_from[:8]}...")
        console.print(
            f"  Progress: {len(continue_ctx.skip_completed_items)}/"
            f"{continue_ctx.total_plan_items} tasks already completed"
        )
        console.print(f"  Objective: {resolved_objective}")
        console.print()

        if continue_ctx.plan_context is not None:
            print_info("  Plan context: preserved from source session")

        skip_intent = skip_intent_requested
        if not skip_intent_requested:
            skip_intent = True
            if continue_ctx.active_intent:
                print_info(f"  Intent: preserving active intent {continue_ctx.active_intent.id}")
            else:
                print_warning("  Intent: no active intent found; continuing without intent context")

        return ContinueFromResolution(
            objective=continue_ctx.resolved_objective,
            objective_display=resolved_objective,
            plan_context=continue_ctx.plan_context,
            session_data=continue_ctx.source_session,
            skip_completed_items=continue_ctx.skip_completed_items,
            intent_id=continue_ctx.active_intent_id,
            skip_intent=skip_intent,
        )
    except APIError as exc:
        if exc.status_code == HTTPStatus.NOT_FOUND.value:
            print_error(f"Session not found: {continue_from}")
            console.print("\nCheck the session ID with: obra status")
        else:
            print_error(f"Failed to fetch session: {exc}")
        raise typer.Exit(1) from exc
    except typer.Exit:
        raise
    except Exception as exc:
        print_error(f"Failed to prepare continue-from: {exc}")
        raise typer.Exit(1) from exc


def resolve_launch_context(
    *,
    client: Any,
    working_dir: Path | None,
    project_id: str | None,
    resume_session: str | None,
    continue_from: str | None,
    continue_from_session: dict[str, Any] | None,
    resume_from: str | None,
    rerun_setup: bool,
    isolated: bool = False,
) -> ResolvedLaunchContext:
    """Resolve session ownership, project identity, working dir, and resume target."""
    session_id = resume_session or continue_from
    session_project_id: str | None = None
    session_data: dict[str, Any] | None = None
    project_explicit = False
    if session_id:
        session_data = continue_from_session if continue_from else None
        if session_data is None:
            try:
                session_data = client.get_session(session_id)
            except APIError as exc:
                if exc.status_code == HTTPStatus.NOT_FOUND.value:
                    print_error(f"Session not found: {session_id}")
                    console.print("\nCheck the session ID with: obra status")
                else:
                    print_error(f"Failed to fetch session: {exc}")
                raise typer.Exit(1) from exc
        if isinstance(session_data, dict):
            canonical_session_id = str(session_data.get("session_id") or "").strip()
            if canonical_session_id:
                session_id = canonical_session_id
        session_project_id = session_data.get("project_id") if session_data else None

    if session_project_id:
        if project_id and str(project_id) != str(session_project_id):
            print_warning(
                f"Ignoring --project {project_id}; session {session_id[:8]} "
                f"belongs to project {session_project_id}"
            )
        resolved_project_id = _validate_project_id_against_server(
            client, str(session_project_id), f"from session {session_id[:8]}"
        )
        project_explicit = True
    else:
        resolved_project_id, project_explicit = _resolve_and_validate_project_id(
            client, project_id, isolated=isolated, working_dir=working_dir
        )

    selection = _resolve_working_dir_selection(
        client=client,
        working_dir=working_dir,
        project_id=resolved_project_id,
        resume_session=resume_session,
        continue_from=continue_from,
        project_explicit=project_explicit,
    )
    work_dir = selection.path

    if not work_dir.exists():
        print_error(f"Working directory does not exist: {work_dir}")
        raise typer.Exit(1)

    if selection.conflict and selection.prompt_used:
        print_info(f"Working directory selected: {work_dir}")

    if selection.stored_missing and selection.project_id:
        try:
            client.update_project(
                project_id=selection.project_id,
                working_dir=str(work_dir),
            )
            print_info(f"Saved working directory to project {selection.project_id}")
        except Exception as exc:
            logger.warning(
                "Failed to persist working directory for project %s: %s",
                selection.project_id,
                exc,
            )

    normalized_resume_from = "story-0" if rerun_setup else resume_from
    resume_target: str | None = None
    if normalized_resume_from:
        normalized = normalized_resume_from.lower()
        if normalized in ("environment", "story-0", "env-setup"):
            normalized_resume_from = "story-0"
            resume_target = "story0"
        elif normalized in ("plan", "derivation"):
            normalized_resume_from = "derivation"
            resume_target = "derivation"
        else:
            normalized_resume_from = "execution"
            resume_target = "execution"

        state_path: Path | None = None
        if session_id:
            try:
                state_path = session_story0_state_path(work_dir, session_id)
            except ValueError:
                state_path = None
        if normalized_resume_from in ("story-0", "derivation") and state_path and state_path.exists():
            try:
                state_path.unlink()
                if normalized_resume_from == "story-0":
                    print_info("Removed environment setup state; re-running.")
                else:
                    print_info("Cleared environment setup state; skipping validation on resume.")
            except OSError as exc:
                logger.warning("Failed to remove environment setup state: %s", exc)

    return ResolvedLaunchContext(
        project_id=resolved_project_id,
        work_dir=work_dir,
        session_id=session_id,
        session_data=session_data,
        session_project_id=session_project_id,
        resume_target=resume_target,
    )


def resolve_plan_launch_context(
    *,
    client: Any,
    work_dir: Path,
    project_id: str,
    objective: str | None,
    plan_id: str | None,
    plan_file: Path | None,
    continue_from_plan_context: dict[str, Any] | None,
    from_step: int | None,
    cascade: bool,
    verbose: int,
) -> PlanLaunchContext:
    """Resolve plan import, lookup, and UserPlan persistence for a launch."""
    plan_context: dict[str, Any] | None = None
    effective_plan_id = plan_id

    if plan_file:
        console.print()
        console.print(f"[dim]Uploading plan file: {plan_file}[/dim]")
        try:
            import yaml

            if not plan_file.exists():
                print_error(f"Plan file not found: {plan_file}")
                logger.error("Plan file does not exist: %s", plan_file)
                raise typer.Exit(1)

            if not os.access(plan_file, os.R_OK):
                print_error(f"Plan file is not readable: {plan_file}")
                logger.error("Insufficient permissions to read plan file: %s", plan_file)
                raise typer.Exit(1)

            try:
                with plan_file.open(encoding="utf-8") as handle:
                    plan_data = yaml.safe_load(handle)
            except yaml.YAMLError as exc:
                print_error(f"Invalid YAML syntax in plan file: {exc}")
                logger.error(
                    "YAML parsing error in %s: %s",
                    plan_file,
                    exc,
                    exc_info=True,
                )
                raise typer.Exit(1) from exc
            except UnicodeDecodeError as exc:
                print_error(f"Plan file encoding error (expected UTF-8): {exc}")
                logger.error(
                    "Encoding error reading plan file %s: %s",
                    plan_file,
                    exc,
                    exc_info=True,
                )
                raise typer.Exit(1) from exc

            if plan_data is None:
                print_error(f"Plan file is empty: {plan_file}")
                logger.error("Plan file %s contains no data", plan_file)
                raise typer.Exit(1)

            if not isinstance(plan_data, dict):
                print_error(
                    f"Plan file must contain a YAML dictionary, got {type(plan_data).__name__}"
                )
                logger.error(
                    "Plan file %s validation failed: expected dict, got %s",
                    plan_file,
                    type(plan_data).__name__,
                )
                raise typer.Exit(1)

            plan_name = plan_data.get("work_id", plan_file.stem)
            plan_context = _extract_plan_context(plan_data, str(plan_file))
            upload_response = client.upload_plan(plan_name, plan_data)
            effective_plan_id = upload_response.get("plan_id")
            console.print(f"[dim]Plan uploaded: {effective_plan_id}[/dim]")
        except APIError as exc:
            display_obra_error(exc, console)
            logger.error("API error uploading plan file: %s", exc, exc_info=True)
            raise typer.Exit(1) from exc
        except ConfigurationError as exc:
            display_obra_error(exc, console)
            logger.error("Configuration error uploading plan file: %s", exc, exc_info=True)
            raise typer.Exit(1) from exc
        except ObraError as exc:
            display_obra_error(exc, console)
            logger.error("Obra error uploading plan file: %s", exc, exc_info=True)
            raise typer.Exit(1) from exc
        except OSError as exc:
            print_error(f"Failed to read plan file: {exc}")
            logger.error(
                "File I/O error reading plan file %s: %s",
                plan_file,
                exc,
                exc_info=True,
            )
            raise typer.Exit(1) from exc
        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Unexpected error uploading plan file: {exc}")
            logger.exception("Unexpected error uploading plan file %s", plan_file)
            raise typer.Exit(1) from exc

    if effective_plan_id and not plan_file:
        plan_path = _find_plan_yaml(effective_plan_id, work_dir)
        if not plan_path:
            _print_plan_lookup_error(effective_plan_id, work_dir)
            raise typer.Exit(1)
        plan_context = _load_plan_context_from_file(plan_path)

    if plan_context is None and continue_from_plan_context is not None:
        plan_context = continue_from_plan_context

    userplan_id: str | None = None
    if plan_context is not None:
        plan_file_path_str: str | None = None
        if plan_file:
            plan_file_path_str = str(plan_file)
        elif effective_plan_id:
            found_path = _find_plan_yaml(effective_plan_id, work_dir)
            if found_path:
                plan_file_path_str = str(found_path)

        try:
            from obra.execution.intake import (
                UserPlanFromStepError,
                create_and_persist_userplan,
            )

            result = create_and_persist_userplan(
                plan_context=plan_context,
                project_id=project_id,
                plan_file_path=plan_file_path_str,
                from_step=from_step,
                cascade=cascade,
                verbose=verbose,
            )
            userplan_id = result.userplan_id
            console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
            if verbose > 0:
                from obra.execution.userplan_cache import get_userplan_cache_path

                cache_path = get_userplan_cache_path(result.userplan.project_id, userplan_id)
                print_info(f"UserPlan cached at {cache_path}")

            if from_step is not None:
                total_steps = len(result.userplan.steps)
                console.print(
                    f"[dim]Re-deriving from step {from_step}: "
                    f"steps {from_step}-{total_steps} will be updated[/dim]"
                )
                if cascade and from_step < total_steps:
                    sibling_step_indices = list(range(from_step + 1, total_steps + 1))
                    console.print(
                        f"[dim]Cascade: Marked sibling steps {sibling_step_indices} as STALE[/dim]"
                    )
        except UserPlanFromStepError as exc:
            print_error(str(exc))
            console.print(f"\nUserPlan has {exc.total_steps} step(s).")
            console.print(f"Valid range: 1 to {exc.total_steps}")
            raise typer.Exit(2) from exc
        except Exception as exc:
            logger.warning(
                "Failed to create UserPlan from plan file: %s",
                exc,
                exc_info=True,
            )
            console.print(f"[dim]Note: UserPlan creation skipped ({exc})[/dim]")
    elif objective is not None:
        try:
            from obra.execution.userplan_construction import create_userplan_from_objective_text
            from obra.execution.userplan_persistence import persist_userplan_via_api

            userplan = create_userplan_from_objective_text(
                objective=objective,
                project_id=project_id,
            )
            userplan_id = userplan.id

            from obra.api import APIClient as UserPlanAPIClient

            userplan_client = UserPlanAPIClient.from_config()
            persist_userplan_via_api(
                userplan,
                client=userplan_client,
            )
            console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
            logger.info("Created UserPlan %s from objective", userplan_id)
        except typer.Exit:
            raise
        except Exception as exc:
            require_persistence = False
            try:
                from obra.config.loaders import load_layered_config

                cfg, _, _ = load_layered_config(include_defaults=True)
                require_persistence = (
                    cfg.get("features", {}).get("userplan", {}).get("require_persistence", False)
                )
            except Exception:
                pass

            if require_persistence:
                logger.exception(
                    "Failed to create UserPlan (persistence required): %s",
                    exc,
                )
                console.print(
                    f"[red]Error: UserPlan creation failed ({exc})[/red]\n"
                    "[dim]Set features.userplan.require_persistence: false for standalone mode[/dim]"
                )
                raise typer.Exit(1) from exc
            logger.warning(
                "Failed to create UserPlan from objective: %s",
                exc,
                exc_info=True,
            )
            console.print(f"[dim]Note: UserPlan creation skipped ({exc})[/dim]")

    return PlanLaunchContext(
        plan_context=plan_context,
        effective_plan_id=effective_plan_id,
        userplan_id=userplan_id,
    )
