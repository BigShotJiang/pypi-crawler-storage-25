"""Derive-input preparation helpers for CLI run/derive flows."""

from __future__ import annotations

import logging
import os
from http import HTTPStatus
from pathlib import Path
from typing import Any, cast

import typer

from obra.display import console, glyphs, print_error
from obra.exceptions import APIError, ConfigurationError
from obra.messages import get_message
from obra.review.config import ALLOWED_AGENTS, ReviewConfig, ReviewConfigCLIInputs

logger = logging.getLogger(__name__)

# Common tech stack keywords that indicate specificity
_TECH_KEYWORDS = frozenset(
    [
        "python",
        "javascript",
        "typescript",
        "go",
        "rust",
        "java",
        "ruby",
        "php",
        "swift",
        "kotlin",
        "c#",
        "csharp",
        "c++",
        "scala",
        "elixir",
        "fastapi",
        "django",
        "flask",
        "express",
        "nextjs",
        "next.js",
        "react",
        "vue",
        "angular",
        "svelte",
        "rails",
        "spring",
        "gin",
        "echo",
        "actix",
        "nestjs",
        "nuxt",
        "remix",
        "astro",
        "laravel",
        "symfony",
        "postgresql",
        "postgres",
        "mysql",
        "mongodb",
        "redis",
        "sqlite",
        "dynamodb",
        "firestore",
        "supabase",
        "prisma",
        "sqlalchemy",
        "typeorm",
        "docker",
        "kubernetes",
        "k8s",
        "aws",
        "gcp",
        "azure",
        "vercel",
        "heroku",
        "terraform",
        "cloudflare",
    ]
)

_MIN_WORD_COUNT = 10
_TRIVIAL_WORD_COUNT = 5


def _parse_review_agents_csv(review_agents: str | None) -> list[str] | None:
    """Parse a comma-separated agent list from CLI input."""
    if review_agents is None:
        return None
    agents = [part.strip() for part in review_agents.split(",") if part.strip()]
    return agents or None


def _load_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning config from project config layer if present."""
    from obra.config.planning import get_project_planning_config

    return cast(dict[str, Any], get_project_planning_config(project_path))


def _validate_project_id_against_server(
    client: Any,
    project_id: str,
    source: str,
) -> str:
    """Validate a project_id exists on the server."""
    try:
        project = client.get_project(project_id)
        is_deleted = project.get("is_deleted")
        if isinstance(is_deleted, bool) and is_deleted:
            print_error(f"Project '{project_id}' ({source}) has been deleted")
            console.print("\nUse 'obra projects list' to see available projects.")
            console.print("Use 'obra projects select <id>' to choose a different default.")
            raise typer.Exit(1)
        return str(project.get("project_id", project_id))
    except APIError as exc:
        if exc.status_code == HTTPStatus.NOT_FOUND.value:
            print_error(f"Project '{project_id}' ({source}) not found on server")
            console.print("\nThe project ID does not exist on the server.")
            console.print("Use 'obra projects list' to see available projects.")
            console.print("Use 'obra projects create' to create a new project.")
        else:
            print_error(f"Failed to validate project '{project_id}': {exc}")
        raise typer.Exit(1) from exc


def _find_project_by_working_dir(client: Any, working_dir: Path) -> str | None:
    """Return the project_id of an existing project whose working_dir matches, or None."""
    normalized_target = os.path.normcase(os.path.normpath(str(working_dir)))
    try:
        projects = client.list_projects()
    except Exception:
        logger.debug("Failed to list projects for working_dir lookup", exc_info=True)
        return None
    for project in projects:
        stored = project.get("working_directory") or project.get("working_dir")
        if not stored:
            continue
        if os.path.normcase(os.path.normpath(stored)) == normalized_target:
            pid = project.get("project_id")
            if pid and not project.get("is_deleted"):
                return str(pid)
    return None


def _find_or_create_project_for_dir(client: Any, working_dir: Path) -> str:
    """Find an existing project for the directory, or create one.

    Used when ``--isolated --dir <path>`` is given without ``--project``,
    e.g. by the benchmark harness running against freshly-cloned repos.
    Reuses an existing project if one already points at the same path,
    preventing unbounded project accumulation on repeated runs.
    """
    existing = _find_project_by_working_dir(client, working_dir)
    if existing:
        logger.info("Reusing project %s for isolated dir %s", existing, working_dir)
        return existing

    dir_name = working_dir.name or "isolated"
    project_name = f"isolated-{dir_name}"
    try:
        result = client.create_project(
            name=project_name,
            working_dir=str(working_dir),
            reuse_existing_for_working_dir=True,
        )
        project_id = str(result.get("project_id", ""))
        if not project_id:
            print_error("Failed to create ad-hoc project: empty project_id in response")
            raise typer.Exit(1)
        logger.info(
            "Created ad-hoc project %s for isolated dir %s",
            project_id,
            working_dir,
        )
        return project_id
    except APIError as exc:
        if exc.status_code == HTTPStatus.CONFLICT.value:
            existing = _find_project_by_working_dir(client, working_dir)
            if existing:
                logger.info(
                    "Recovered conflicting isolated project %s for dir %s",
                    existing,
                    working_dir,
                )
                return existing
        print_error(f"Failed to create ad-hoc project for --dir {working_dir}: {exc}")
        raise typer.Exit(1) from exc


def _resolve_and_validate_project_id(
    client: Any,
    cli_project_id: str | None,
    *,
    isolated: bool = False,
    working_dir: Path | None = None,
) -> tuple[str, bool]:
    """Resolve and validate project_id from CLI flag, local config, or server default.

    Returns:
        Tuple of (project_id, project_explicit) where project_explicit is True
        when the project was provided via --project CLI flag.
    """
    from obra.config import get_default_project_override

    if cli_project_id:
        project_id = _validate_project_id_against_server(
            client, cli_project_id, "from --project flag"
        )
        return project_id, True

    local_override = get_default_project_override()
    if local_override:
        project_id = _validate_project_id_against_server(
            client, local_override, "from local config"
        )
        return project_id, False

    if isolated:
        if working_dir is not None:
            return _find_or_create_project_for_dir(client, working_dir), True
        print_error(
            "No project specified in isolated mode. "
            "Use --project <id> or --dir <path> to run in isolated mode."
        )
        raise typer.Exit(1)

    try:
        result = client.list_projects_with_selection()
        default_id = result.get("default_project_id")
        if default_id:
            logger.debug("Using server's selected default project: %s", default_id)
            return str(default_id), False
    except Exception:
        logger.debug("Failed to fetch server default project", exc_info=True)

    print_error("No project selected")
    console.print(f"\n{get_message('guidance.requirement.select_project')}")
    console.print("Options:")
    console.print("  1. obra projects select <id>  - Select an existing project as default")
    console.print("  2. obra projects create       - Create a new project")
    console.print("  3. obra run --project <id> - Specify project for this run only")
    console.print("\nUse 'obra projects list' to see available projects.")
    raise typer.Exit(1)


def _build_review_config_from_cli(
    *,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    project_path: Path | None = None,
) -> ReviewConfig:
    """Build ReviewConfig from CLI flags and project config defaults."""
    explicit_agents = _parse_review_agents_csv(review_agents)
    add_agents = [
        name
        for name, enabled in (
            ("security", with_security),
            ("testing", with_testing),
            ("docs", with_docs),
            ("code_quality", with_code_quality),
        )
        if enabled
    ]
    remove_agents = [
        name
        for name, enabled in (
            ("security", no_security),
            ("testing", no_testing),
            ("docs", no_docs),
            ("code_quality", no_code_quality),
        )
        if enabled
    ]

    fail_threshold: str | None = None
    if fail_on_p2:
        fail_threshold = "p2"
    elif fail_on_p1:
        fail_threshold = "p1"

    try:
        cli_inputs = ReviewConfigCLIInputs(
            explicit_agents=explicit_agents,
            add_agents=add_agents,
            remove_agents=remove_agents,
            full_review=full_review,
            skip_review=skip_review,
            output_format=review_format,
            quiet=review_quiet,
            summary_only=review_summary_only,
            fail_threshold=fail_threshold,
            timeout_seconds=review_timeout,
        )
        return ReviewConfig.from_cli_and_config(
            project_path=project_path,
            cli_inputs=cli_inputs,
        )
    except ConfigurationError:
        raise
    except ValueError as exc:
        raise ConfigurationError(str(exc), "Update review CLI flags or review config.") from exc


def _detect_input_quality_issues(objective: str) -> list[str]:
    """Detect common input quality problems in user objectives."""
    issues = []
    words = objective.split()
    word_count = len(words)
    objective_lower = objective.lower()

    if word_count < _MIN_WORD_COUNT:
        if word_count <= _TRIVIAL_WORD_COUNT:
            issues.append(f"Very short objective ({word_count} words) - may be too vague")
        else:
            issues.append(f"Short objective ({word_count} words) - consider adding more detail")

    has_tech = any(tech in objective_lower for tech in _TECH_KEYWORDS)
    if not has_tech and word_count >= _TRIVIAL_WORD_COUNT:
        issues.append("No tech stack detected - specify language/framework/database")

    vague_patterns = [
        ("build a website", "What kind? E-commerce, blog, SaaS? What features?"),
        ("add authentication", "What type? JWT, OAuth2, session-based?"),
        ("add auth", "What type? JWT, OAuth2, session-based?"),
        ("fix the bug", "Which bug? What's the symptom? What file?"),
        ("fix bug", "Which bug? What's the symptom? What file?"),
        ("make it faster", "Which part? API? Page load? Database?"),
        ("improve performance", "Which part? API? Page load? Database?"),
        ("add tests", "What tests? Unit, integration, E2E? For which components?"),
        ("refactor", "What specifically? Which files/modules? What's the goal?"),
    ]

    for pattern, suggestion in vague_patterns:
        if pattern in objective_lower:
            issues.append(f"Vague pattern '{pattern}' - {suggestion}")
            break

    return issues


def _show_input_quality_warning(issues: list[str]) -> None:
    """Display input quality warning with actionable guidance."""
    console.print()
    console.print(f"[yellow]{glyphs.warning}  Input Quality Check:[/yellow]")
    for issue in issues:
        console.print(f"  [dim]•[/dim] {issue}")
    console.print()
    console.print(f"[dim]{glyphs.hint} For better results: [/dim][cyan]obra briefing quick[/cyan]")
    console.print()
