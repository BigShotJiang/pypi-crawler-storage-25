"""Runtime execution-loop helpers for CLI run/derive flows."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SessionRunOutcome:
    """Captured result of running a hybrid CLI session."""

    orchestrator: Any
    result: Any
    session_id: str | None


def resolve_domain_override(
    *,
    domain: str | None,
    continue_from_session: dict[str, Any] | None,
    session_project_id: str | None,
    session_data: dict[str, Any] | None,
    continue_from_plan_context: dict[str, Any] | None,
) -> str | None:
    """Resolve the effective domain override for the hybrid runtime."""
    resolved_domain_override = domain
    if resolved_domain_override is None and continue_from_session is not None:
        session_domain = continue_from_session.get("domain")
        if isinstance(session_domain, str) and session_domain.strip():
            resolved_domain_override = session_domain.strip()
    if resolved_domain_override is None and session_project_id:
        session_domain = session_data.get("domain") if isinstance(session_data, dict) else None
        if isinstance(session_domain, str) and session_domain.strip():
            resolved_domain_override = session_domain.strip()
    if resolved_domain_override is None and isinstance(continue_from_plan_context, dict):
        plan_domain = continue_from_plan_context.get(
            "domain_id",
            continue_from_plan_context.get("domain"),
        )
        if isinstance(plan_domain, str) and plan_domain.strip():
            resolved_domain_override = plan_domain.strip()
    return resolved_domain_override


def run_session(
    cli: Any,
    *,
    work_dir: Path,
    session_data: dict[str, Any] | None,
    session_project_id: str | None,
    continue_from_session: dict[str, Any] | None,
    continue_from_plan_context: dict[str, Any] | None,
    progress_emitter: Any,
    verbose: int,
    stream: bool,
    domain: str | None,
    effective_provider: str | None,
    effective_model: str | None,
    effective_reasoning: str | None,
    review_config: Any,
    bypass_modes: list[str],
    defaults_json: bool,
    spike_first_override: bool | None,
    obs_config: Any,
    skip_git_check: bool,
    auto_init_git: bool,
    plan_mode: str | None,
    story0_override_config: dict[str, Any] | None,
    session_display: Any,
    plan_context: dict[str, Any] | None,
    resume_session: str | None,
    resume_target: str | None,
    objective: str | None,
    initial_intent_id: str | None,
    plan_only: bool,
    project_id: str | None,
    effective_plan_id: str | None,
    skip_completed_items: list[str],
    userplan_id: str | None,
    from_step: int | None,
    work_type: str | None,
    parallel_requested: bool,
    parallel_max_workers: int | None,
) -> SessionRunOutcome:
    """Create the orchestrator, run derive/resume, and return the session outcome."""
    from obra.execution.intake import materialize_workflow_derivation_request
    from obra.hybrid import HybridOrchestrator

    resolved_domain_override = resolve_domain_override(
        domain=domain,
        continue_from_session=continue_from_session,
        session_project_id=session_project_id,
        session_data=session_data,
        continue_from_plan_context=continue_from_plan_context,
    )

    progress_json_value = False
    orchestrator = None
    session_id: str | None = None

    def on_progress(action: str, payload: dict) -> None:
        cli._refresh_local_session_heartbeat(orchestrator, action, payload)
        cli._route_progress_event(
            progress_emitter,
            cli.console,
            verbose,
            action,
            payload,
            progress_json=progress_json_value,
        )

    def on_stream(event_type: str, chunk: str) -> None:
        if event_type == "llm_streaming":
            progress_emitter.llm_streaming(chunk)

    on_escalation = cli._build_escalation_callback()

    orchestrator = HybridOrchestrator.from_config(
        working_dir=work_dir,
        on_progress=on_progress,
        on_escalation=on_escalation,
        on_stream=on_stream if stream else None,
        domain=resolved_domain_override,
        impl_provider=effective_provider,
        impl_model=effective_model,
        reasoning_level=effective_reasoning,
        review_config=review_config,
        bypass_modes=bypass_modes,
        defaults_json=defaults_json,
        spike_first_override=spike_first_override,
        observability_config=obs_config,
        progress_emitter=progress_emitter,
        skip_git_check=skip_git_check if skip_git_check else None,
        auto_init_git=auto_init_git if auto_init_git else None,
        planning_mode=plan_mode,
        config_override=story0_override_config,
        session_display=session_display,
    )
    orchestrator._runtime_state.intent_id = initial_intent_id
    orchestrator._runtime_state.parallel_execution_requested = parallel_requested
    orchestrator._runtime_state.parallel_max_workers = parallel_max_workers
    cli._install_imported_plan_handler(orchestrator, plan_context)

    cli._interrupt_manager.orchestrator = orchestrator
    cli._interrupt_manager.session_id = resume_session or "<pending>"
    try:
        with cli.defer_interrupts():
            if resume_session:
                result = orchestrator.resume(
                    resume_session,
                    resume_target=resume_target,
                )
            else:
                assert objective is not None, "objective required for derive"
                resolved_domain_id = domain
                if not resolved_domain_id:
                    resolved_domain = getattr(orchestrator, "_domain", None)
                    resolved_domain_id = getattr(resolved_domain, "name", None)
                workflow_derivation_request = materialize_workflow_derivation_request(
                    objective=objective,
                    domain_id=resolved_domain_id,
                    plan_context=plan_context,
                    allow_plan_context_domain=False,
                )
                result = orchestrator.derive(
                    objective,
                    plan_id=effective_plan_id,
                    plan_only=plan_only,
                    project_id=project_id,
                    bypass_modes=bypass_modes,
                    skip_completed_items=skip_completed_items,
                    userplan_id=userplan_id,
                    from_step=from_step,
                    work_type=work_type,
                    workflow_derivation_request=workflow_derivation_request,
                )
            session_id = orchestrator.session_id
            if session_id:
                progress_emitter.set_session_id(session_id)
                cli._interrupt_manager.session_id = session_id
                cli.rename_session_logging(session_id)
    finally:
        cli.clear_interrupt_request()

    return SessionRunOutcome(
        orchestrator=orchestrator,
        result=result,
        session_id=session_id,
    )
