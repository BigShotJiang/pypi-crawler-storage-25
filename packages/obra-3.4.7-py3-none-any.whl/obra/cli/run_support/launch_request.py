"""Typed launch-request validation for CLI run/derive session flow."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class LaunchRequest:
    """Normalized launch inputs used by the shared CLI session flow."""

    objective: str | None
    working_dir: Path | None = None
    project_id: str | None = None
    resume_session: str | None = None
    continue_from: str | None = None
    resume_from: str | None = None
    rerun_setup: bool = False
    plan_id: str | None = None
    plan_file: Path | None = None
    from_step: int | None = None
    intent_id: str | None = None

    @property
    def session_id(self) -> str | None:
        """Return the requested existing session, if any."""
        return self.resume_session or self.continue_from


def validate_launch_request(cli: Any, request: LaunchRequest) -> None:
    """Validate mutually exclusive and required launch flags."""
    if request.plan_id and request.plan_file:
        cli.print_error("Cannot specify both --plan-id and --plan-file")
        cli.console.print("\nUse one or the other:")
        cli.console.print("  --plan-id: Reference an already uploaded plan")
        cli.console.print("  --plan-file: Upload and use a plan in one step")
        raise cli.typer.Exit(2)

    if request.resume_session and request.continue_from:
        cli.print_error("Cannot specify both --resume and --continue-from")
        cli.console.print("\nUse one or the other:")
        cli.console.print("  --resume: Resume an active session")
        cli.console.print(
            "  --continue-from: Continue from failed/escalated session (creates new session)"
        )
        raise cli.typer.Exit(2)

    if (request.resume_from is not None or request.rerun_setup) and not request.resume_session:
        cli.print_error("--from and --rerun-setup require --resume")
        cli.console.print("\nUsage:")
        cli.console.print("  obra run --resume <session_id> --from story-0")
        cli.console.print("  obra run --resume <session_id> --rerun-setup")
        raise cli.typer.Exit(2)

    if not request.objective and not request.resume_session and not request.continue_from:
        cli.print_error("Must specify objective, --resume, or --continue-from")
        cli.console.print("\nUsage:")
        cli.console.print('  obra run "Your objective here"')
        cli.console.print("  obra run --resume <session_id>")
        cli.console.print("  obra run --continue-from <session_id>")
        raise cli.typer.Exit(1)

    if request.objective and request.resume_session:
        cli.print_error("Cannot specify both objective and --resume")
        cli.console.print("\nUse one or the other:")
        cli.console.print('  obra run "Your objective here"  # Start new session')
        cli.console.print("  obra run --resume <session_id>  # Resume existing session")
        raise cli.typer.Exit(1)

    if request.from_step is not None and not request.plan_file and not request.plan_id:
        cli.print_error("--from-step requires --plan-file or --plan-id")
        cli.console.print("\n--from-step re-derives from step N onwards in an existing UserPlan.")
        cli.console.print("Provide the plan source:")
        cli.console.print("  --plan-file path/to/plan.yaml")
        cli.console.print("  --plan-id <existing-plan-id>")
        raise cli.typer.Exit(2)
