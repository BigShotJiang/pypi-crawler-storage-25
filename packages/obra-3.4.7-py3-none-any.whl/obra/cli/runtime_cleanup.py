"""Universal runtime cleanup support for the Obra CLI."""

from __future__ import annotations

import contextlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import psutil

from obra.cli.studio_runtime import (
    StudioGatewayState,
    find_obra_gateway_listener_process,
    load_studio_gateway_state,
    stop_studio_gateway,
    stop_untracked_studio_gateway,
)
from obra.config.loaders import (
    get_cli_cleanup_runtime_log_config,
    get_gateway_config,
    get_projects_default_directory,
)
from obra.core.process_registry import PID_START_TIME_TOLERANCE_S, ProcessRegistry
from obra.display import console, print_info, print_success, print_warning
from obra.gateway.workflow_studio.local_project_store import LocalProjectStore
from obra.observability.production_logger import rotate_production_log_if_needed
from obra.utils.obra_home import get_runtime_dir

_RUN_DIR = Path.home() / ".obra" / "run"


@dataclass(frozen=True)
class SessionState:
    """Tracked session heartbeat state."""

    file_path: Path
    session_id: str
    short_id: str
    pid: int
    working_dir: Path | None
    live: bool


@dataclass(frozen=True)
class ProcessState:
    """Tracked ProcessGuard PID-file state."""

    file_path: Path
    name: str
    pid: int
    live: bool


@dataclass(frozen=True)
class GatewayState:
    """Tracked or discovered Workflow Studio gateway state."""

    tracked: bool
    host: str
    port: int
    pid: int | None
    state: StudioGatewayState | None
    live: bool


@dataclass
class ProjectCleanupResult:
    """Per-project cleanup summary."""

    root: Path
    sources: list[str]
    prompt_files_removed: int = 0
    prompt_indices_removed: int = 0
    llm_output_files_removed: int = 0
    dirs_removed: int = 0
    skipped: bool = False
    skip_reason: str | None = None


@dataclass
class CleanupReport:
    """Structured universal cleanup result."""

    all_projects: bool
    force: bool
    blocked_reasons: list[str] = field(default_factory=list)
    stopped_gateways: list[str] = field(default_factory=list)
    terminated_roots: list[str] = field(default_factory=list)
    recovered_pid_ledger_processes: list[str] = field(default_factory=list)
    pruned_pid_ledger_entries: list[str] = field(default_factory=list)
    removed_heartbeat_files: list[Path] = field(default_factory=list)
    removed_pid_files: list[Path] = field(default_factory=list)
    removed_tmp_paths: list[Path] = field(default_factory=list)
    removed_lock_files: list[Path] = field(default_factory=list)
    preserved_lock_files: list[str] = field(default_factory=list)
    rotated_logs: list[str] = field(default_factory=list)
    cleaned_projects: list[ProjectCleanupResult] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        return bool(self.blocked_reasons)

    @property
    def any_cleaned(self) -> bool:
        return any(
            (
                self.stopped_gateways,
                self.terminated_roots,
                self.recovered_pid_ledger_processes,
                self.pruned_pid_ledger_entries,
                self.removed_heartbeat_files,
                self.removed_pid_files,
                self.removed_tmp_paths,
                self.removed_lock_files,
                self.rotated_logs,
                [
                    project
                    for project in self.cleaned_projects
                    if (
                        project.prompt_files_removed
                        or project.prompt_indices_removed
                        or project.llm_output_files_removed
                        or project.dirs_removed
                    )
                ],
            )
        )


@dataclass
class _RootProcess:
    """Owned root process metadata used for termination/reporting."""

    pid: int
    labels: set[str] = field(default_factory=set)
    heartbeat_files: set[Path] = field(default_factory=set)
    pid_files: set[Path] = field(default_factory=set)


@dataclass
class _DiscoveredProjectRoot:
    """Project root candidate with merged discovery sources."""

    path: Path
    sources: set[str] = field(default_factory=set)
    active_session_ids: set[str] = field(default_factory=set)


def run_universal_cleanup(
    *,
    clean_all: bool,
    force: bool,
    runtime_dir: Path | None = None,
    run_dir: Path | None = None,
    current_working_dir: Path | None = None,
    project_store: LocalProjectStore | None = None,
    gateway_config: dict[str, Any] | None = None,
) -> CleanupReport:
    """Run universal runtime cleanup and return a structured report."""
    runtime_root = (runtime_dir or get_runtime_dir()).resolve(strict=False)
    run_root = (run_dir or _RUN_DIR).resolve(strict=False)
    cwd = (current_working_dir or Path.cwd()).resolve(strict=False)
    report = CleanupReport(all_projects=clean_all, force=force)

    sessions = _collect_session_states(run_root)
    processes = _collect_process_states(run_root)
    gateway = _collect_gateway_state(gateway_config or get_gateway_config())
    roots = _build_owned_roots(sessions, processes)

    _remove_stale_state(sessions, processes, report)
    _cleanup_pid_ledger(report)
    _handle_gateway_cleanup(gateway, report, force=force)
    _handle_root_process_cleanup(roots, report, force=force)

    active_sessions = [session for session in _collect_session_states(run_root) if session.live]
    active_roots_remain = _live_root_descriptions(
        _build_owned_roots(active_sessions, _collect_process_states(run_root))
    )
    gateway_after = _collect_gateway_state(gateway_config or get_gateway_config())
    if gateway_after is not None and gateway_after.live and not force:
        label = (
            f"Workflow Studio gateway on {gateway_after.host}:{gateway_after.port}"
            if gateway_after.pid is None
            else f"Workflow Studio gateway PID {gateway_after.pid} on {gateway_after.host}:{gateway_after.port}"
        )
        _append_unique(report.blocked_reasons, label)

    live_session_ids = {session.session_id for session in active_sessions}
    _cleanup_runtime_locks(runtime_root, live_session_ids=live_session_ids, report=report)

    active_work_remains = bool(active_roots_remain or (gateway_after is not None and gateway_after.live))
    if active_work_remains and not force:
        for reason in active_roots_remain:
            _append_unique(report.blocked_reasons, reason)
    else:
        _cleanup_runtime_tmp(runtime_root, report=report)

    if clean_all:
        project_roots = _discover_project_roots(
            active_sessions=active_sessions,
            current_working_dir=cwd,
            project_store=project_store,
        )
        _cleanup_project_roots(
            project_roots,
            force=force,
            report=report,
        )
        if active_work_remains and not force:
            _append_unique(
                report.blocked_reasons,
                "Runtime log rotation skipped until live Obra-owned work stops.",
            )
        else:
            _cleanup_runtime_logs(runtime_root, report=report)

    return report


def render_cleanup_report(report: CleanupReport) -> None:
    """Render a human-readable cleanup summary."""
    console.print()
    console.print("[bold]Obra Cleanup Summary[/bold]")

    if report.blocked_reasons:
        print_warning("Live Obra-owned work blocked part of the cleanup. Re-run with --force for a full reset.")
        for reason in report.blocked_reasons:
            console.print(f"  [yellow]Blocked:[/yellow] {reason}")

    if report.stopped_gateways:
        for entry in report.stopped_gateways:
            console.print(f"  [green]Gateway:[/green] {entry}")

    if report.terminated_roots:
        for entry in report.terminated_roots:
            console.print(f"  [green]Process:[/green] {entry}")
    if report.recovered_pid_ledger_processes:
        for entry in report.recovered_pid_ledger_processes:
            console.print(f"  [green]PID ledger process:[/green] {entry}")
    if report.pruned_pid_ledger_entries:
        for entry in report.pruned_pid_ledger_entries:
            console.print(f"  [green]PID ledger entry:[/green] {entry}")

    if report.removed_heartbeat_files:
        console.print(f"  [green]Heartbeat files removed:[/green] {len(report.removed_heartbeat_files)}")
    if report.removed_pid_files:
        console.print(f"  [green]PID files removed:[/green] {len(report.removed_pid_files)}")
    if report.removed_tmp_paths:
        console.print(f"  [green]Runtime tmp paths removed:[/green] {len(report.removed_tmp_paths)}")
    if report.removed_lock_files:
        console.print(f"  [green]Runtime lock files removed:[/green] {len(report.removed_lock_files)}")
    if report.preserved_lock_files:
        console.print(f"  [yellow]Runtime lock files preserved:[/yellow] {len(report.preserved_lock_files)}")
        for entry in report.preserved_lock_files:
            console.print(f"    [dim]{entry}[/dim]")
    if report.rotated_logs:
        for entry in report.rotated_logs:
            console.print(f"  [green]Log:[/green] {entry}")

    for project in report.cleaned_projects:
        if project.skipped:
            console.print(f"  [yellow]Project skipped:[/yellow] {project.root} ({project.skip_reason})")
            continue
        total_removed = (
            project.prompt_files_removed
            + project.prompt_indices_removed
            + project.llm_output_files_removed
        )
        if total_removed or project.dirs_removed:
            sources = ", ".join(sorted(project.sources))
            console.print(
                "  [green]Project cleaned:[/green] "
                f"{project.root} "
                f"(sources: {sources}; prompts={project.prompt_files_removed}, "
                f"prompt_indices={project.prompt_indices_removed}, "
                f"llm_output={project.llm_output_files_removed}, "
                f"dirs={project.dirs_removed})"
            )

    if not report.any_cleaned and not report.blocked and not report.preserved_lock_files:
        print_info("Nothing needed cleanup.")
    elif not report.blocked:
        print_success("Obra cleanup completed.")

    console.print()


def _build_owned_roots(
    sessions: list[SessionState],
    processes: list[ProcessState],
) -> dict[int, _RootProcess]:
    roots: dict[int, _RootProcess] = {}
    for session in sessions:
        if not session.live:
            continue
        root = roots.setdefault(session.pid, _RootProcess(pid=session.pid))
        root.labels.add(f"session {session.short_id}")
        root.heartbeat_files.add(session.file_path)
    for process in processes:
        if not process.live or process.pid <= 0:
            continue
        root = roots.setdefault(process.pid, _RootProcess(pid=process.pid))
        root.labels.add(f"process {process.name}")
        root.pid_files.add(process.file_path)
    return roots


def _collect_session_states(run_dir: Path) -> list[SessionState]:
    results: list[SessionState] = []
    if not run_dir.exists():
        return results

    for file_path in sorted(run_dir.glob("session-*.json")):
        try:
            payload = json.loads(file_path.read_text(encoding="utf-8"))
            session_id = str(payload["session_id"])
            short_id = str(payload["short_id"])
            pid = int(payload["pid"])
            working_dir = _path_from_optional_string(payload.get("working_dir"))
            live = _pid_is_live(pid)
            results.append(
                SessionState(
                    file_path=file_path,
                    session_id=session_id,
                    short_id=short_id,
                    pid=pid,
                    working_dir=working_dir,
                    live=live,
                )
            )
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            results.append(
                SessionState(
                    file_path=file_path,
                    session_id="unknown",
                    short_id=file_path.stem,
                    pid=-1,
                    working_dir=None,
                    live=False,
                )
            )
    return results


def _collect_process_states(run_dir: Path) -> list[ProcessState]:
    from obra.utils.process_guard import find_stale_processes

    states: list[ProcessState] = []
    for name, pid, live in find_stale_processes(run_dir):
        states.append(
            ProcessState(
                file_path=run_dir / f"{name}.pid",
                name=name,
                pid=pid,
                live=live and pid > 0 and _pid_is_live(pid),
            )
        )
    return states


def _collect_gateway_state(gateway_config: dict[str, Any]) -> GatewayState | None:
    state = load_studio_gateway_state()
    if state is not None:
        pid = state.pid if state.pid and _pid_is_live(state.pid) else state.pid
        live = bool(pid and _pid_is_live(pid))
        return GatewayState(
            tracked=True,
            host=state.host,
            port=state.port,
            pid=pid,
            state=state,
            live=live,
        )

    host = str(gateway_config["host"])
    port = int(gateway_config["port"])
    process = find_obra_gateway_listener_process(host, port)
    if process is None:
        return None
    return GatewayState(
        tracked=False,
        host=host,
        port=port,
        pid=process.pid,
        state=None,
        live=True,
    )


def _remove_stale_state(
    sessions: list[SessionState],
    processes: list[ProcessState],
    report: CleanupReport,
) -> None:
    for session in sessions:
        if session.live:
            continue
        if _remove_path(session.file_path):
            report.removed_heartbeat_files.append(session.file_path)

    for process in processes:
        if process.live:
            continue
        if _remove_path(process.file_path):
            report.removed_pid_files.append(process.file_path)


def _cleanup_pid_ledger(report: CleanupReport) -> None:
    orphaned_entries = ProcessRegistry.find_orphaned_pids()
    if not orphaned_entries:
        return

    entries_to_prune: list[dict[str, Any]] = []
    for entry in sorted(orphaned_entries, key=lambda item: int(item.get("pid", -1))):
        reason = str(entry.get("reason") or "")
        command = str(entry.get("command") or "tracked subprocess")
        pid = int(entry["pid"])

        if reason == "process_missing":
            report.pruned_pid_ledger_entries.append(
                f"Pruned stale entry for PID {pid} ({command}): process missing"
            )
            entries_to_prune.append(entry)
            continue

        if reason != "parent_exited":
            report.pruned_pid_ledger_entries.append(
                f"Pruned stale entry for PID {pid} ({command}): unknown orphan reason {reason or 'missing'}"
            )
            entries_to_prune.append(entry)
            continue

        termination_result = _terminate_process_tree(
            pid,
            expected_start_time=entry.get("start_time"),
        )
        if termination_result == "terminated":
            report.recovered_pid_ledger_processes.append(
                f"Recovered orphaned tracked subprocess PID {pid} ({command}) after parent exit"
            )
            entries_to_prune.append(entry)
            continue

        if termination_result == "identity_mismatch":
            report.pruned_pid_ledger_entries.append(
                f"Pruned stale entry for PID {pid} ({command}): start_time mismatch"
            )
            entries_to_prune.append(entry)
            continue

        if termination_result == "missing":
            report.pruned_pid_ledger_entries.append(
                f"Pruned stale entry for PID {pid} ({command}): process missing"
            )
            entries_to_prune.append(entry)
            continue

        _append_unique(
            report.blocked_reasons,
            f"PID ledger orphan PID {pid} ({command}) could not be terminated",
        )

    if entries_to_prune:
        ProcessRegistry.prune_pid_ledger_entries(entries_to_prune)


def _handle_gateway_cleanup(
    gateway: GatewayState | None,
    report: CleanupReport,
    *,
    force: bool,
) -> None:
    if gateway is None:
        return

    if gateway.tracked:
        if gateway.live and not force:
            _append_unique(
                report.blocked_reasons,
                f"Workflow Studio gateway PID {gateway.pid} on {gateway.host}:{gateway.port}",
            )
            return
        result = stop_studio_gateway(state=gateway.state)
        if result.get("reason") == "unowned_gateway" and force:
            untracked = stop_untracked_studio_gateway(host=gateway.host, port=gateway.port)
            if untracked.get("stopped"):
                report.stopped_gateways.append(
                    f"Stopped untracked gateway PID {untracked.get('pid')} on {gateway.host}:{gateway.port}"
                )
            return
        if result.get("reason") in {"stopped", "stopped_untracked"}:
            report.stopped_gateways.append(
                f"Stopped gateway PID {result.get('pid')} on {gateway.host}:{gateway.port}"
            )
        elif result.get("reason") == "stale_state_cleared":
            report.stopped_gateways.append(
                f"Cleared stale Studio gateway state for {gateway.host}:{gateway.port}"
            )
        return

    if not force:
        _append_unique(
            report.blocked_reasons,
            f"Workflow Studio gateway PID {gateway.pid} on {gateway.host}:{gateway.port}",
        )
        return

    result = stop_untracked_studio_gateway(host=gateway.host, port=gateway.port)
    if result.get("stopped"):
        report.stopped_gateways.append(
            f"Stopped untracked gateway PID {result.get('pid')} on {gateway.host}:{gateway.port}"
        )


def _handle_root_process_cleanup(
    roots: dict[int, _RootProcess],
    report: CleanupReport,
    *,
    force: bool,
) -> None:
    for pid, root in sorted(roots.items()):
        description = f"PID {pid} ({', '.join(sorted(root.labels))})"
        if not force:
            _append_unique(report.blocked_reasons, description)
            continue
        if _terminate_process_tree(pid) != "terminated":
            _append_unique(report.blocked_reasons, description)
            continue
        report.terminated_roots.append(f"Terminated {description}")
        for file_path in sorted(root.heartbeat_files):
            if _remove_path(file_path):
                report.removed_heartbeat_files.append(file_path)
        for file_path in sorted(root.pid_files):
            if _remove_path(file_path):
                report.removed_pid_files.append(file_path)


def _cleanup_runtime_tmp(runtime_dir: Path, *, report: CleanupReport) -> None:
    tmp_dir = runtime_dir / "tmp"
    if not tmp_dir.exists():
        return
    for path in sorted(tmp_dir.iterdir()):
        if _remove_tree(path):
            report.removed_tmp_paths.append(path)


def _cleanup_runtime_locks(
    runtime_dir: Path,
    *,
    live_session_ids: set[str],
    report: CleanupReport,
) -> None:
    locks_dir = runtime_dir / "locks"
    if not locks_dir.exists():
        return

    for path in sorted(locks_dir.iterdir()):
        if path.is_dir():
            report.preserved_lock_files.append(f"{path}: unknown lock directory preserved")
            continue
        metadata = _parse_obra_lock_file(path)
        if metadata is None:
            report.preserved_lock_files.append(f"{path}: unknown lock format preserved")
            continue
        stale = True
        reasons: list[str] = []
        pid = metadata.get("pid")
        session_id = metadata.get("session_id")
        if isinstance(pid, int):
            if _pid_is_live(pid):
                stale = False
                reasons.append(f"pid {pid} is still running")
            else:
                reasons.append(f"pid {pid} is stale")
        if isinstance(session_id, str):
            if session_id in live_session_ids:
                stale = False
                reasons.append(f"session {session_id} is still running")
            else:
                reasons.append(f"session {session_id} is stale")
        if stale and _remove_path(path):
            report.removed_lock_files.append(path)
        else:
            report.preserved_lock_files.append(f"{path}: {', '.join(reasons) or 'live lock preserved'}")


def _cleanup_project_roots(
    project_roots: list[_DiscoveredProjectRoot],
    *,
    force: bool,
    report: CleanupReport,
) -> None:
    for project in project_roots:
        result = ProjectCleanupResult(root=project.path, sources=sorted(project.sources))
        if project.active_session_ids and not force:
            result.skipped = True
            result.skip_reason = (
                "live Obra session(s) still using this project: "
                + ", ".join(sorted(project.active_session_ids))
            )
            report.cleaned_projects.append(result)
            continue

        prompt_root = project.path / ".obra" / "prompts"
        llm_output_root = project.path / ".obra" / "llm_output"

        if prompt_root.exists():
            for prompt_file in sorted(prompt_root.rglob(".obra-prompt-*.txt")):
                if _remove_path(prompt_file):
                    result.prompt_files_removed += 1
            index_path = prompt_root / ".prompt-index.json"
            if _remove_path(index_path):
                result.prompt_indices_removed += 1
            result.dirs_removed += _remove_empty_dirs(prompt_root)

        if llm_output_root.exists():
            for child in sorted(llm_output_root.iterdir()):
                removed_files, removed_dirs = _remove_tree_counted(child)
                result.llm_output_files_removed += removed_files
                result.dirs_removed += removed_dirs
            result.dirs_removed += _remove_empty_dirs(llm_output_root)

        report.cleaned_projects.append(result)


def _cleanup_runtime_logs(runtime_dir: Path, *, report: CleanupReport) -> None:
    logs_dir = runtime_dir / "logs"
    if not logs_dir.exists():
        return

    if rotate_production_log_if_needed(log_dir=logs_dir):
        report.rotated_logs.append(str(logs_dir / "production.jsonl"))

    cleanup_log_config = get_cli_cleanup_runtime_log_config()
    max_bytes = int(cleanup_log_config["runtime_log_max_size_bytes"])
    backup_count = int(cleanup_log_config["runtime_log_backup_count"])

    hybrid_log = logs_dir / "hybrid.jsonl"
    if _rotate_file_if_needed(hybrid_log, max_bytes=max_bytes, backup_count=backup_count):
        report.rotated_logs.append(str(hybrid_log))

    sessions_dir = logs_dir / "sessions"
    if sessions_dir.exists():
        for log_path in sorted(sessions_dir.glob("*.log")):
            if _rotate_file_if_needed(log_path, max_bytes=max_bytes, backup_count=backup_count):
                report.rotated_logs.append(str(log_path))


def _discover_project_roots(
    *,
    active_sessions: list[SessionState],
    current_working_dir: Path,
    project_store: LocalProjectStore | None = None,
) -> list[_DiscoveredProjectRoot]:
    roots: dict[str, _DiscoveredProjectRoot] = {}
    store = project_store or LocalProjectStore()

    if store.is_hydrated():
        for project in store.list_projects():
            working_dir = _path_from_optional_string(project.get("working_directory"))
            if working_dir is None:
                continue
            _record_project_root(roots, working_dir, source="local_project_store")

    for session in active_sessions:
        if session.working_dir is None:
            continue
        _record_project_root(
            roots,
            session.working_dir,
            source="active_session",
            session_id=session.session_id,
        )

    if _is_obra_project_root(current_working_dir):
        _record_project_root(roots, current_working_dir, source="cwd")

    default_dir = get_projects_default_directory()
    if default_dir.exists():
        candidates = [default_dir]
        with contextlib.suppress(OSError):
            candidates.extend(sorted(default_dir.iterdir()))
        for candidate in candidates:
            if candidate.is_dir() and _is_obra_project_root(candidate):
                _record_project_root(roots, candidate, source="projects.default_directory")

    return sorted(roots.values(), key=lambda entry: str(entry.path))


def _record_project_root(
    roots: dict[str, _DiscoveredProjectRoot],
    path: Path,
    *,
    source: str,
    session_id: str | None = None,
) -> None:
    resolved = path.resolve(strict=False)
    key = os.path.normcase(os.path.normpath(str(resolved)))
    root = roots.setdefault(key, _DiscoveredProjectRoot(path=resolved))
    root.sources.add(source)
    if session_id:
        root.active_session_ids.add(session_id)


def _live_root_descriptions(roots: dict[int, _RootProcess]) -> list[str]:
    return [
        f"PID {root.pid} ({', '.join(sorted(root.labels))})"
        for root in sorted(roots.values(), key=lambda entry: entry.pid)
    ]


def _parse_obra_lock_file(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    owner = str(payload.get("owner") or "").strip().lower()
    version = payload.get("version")
    if owner != "obra" or version != 1:
        return None
    if not isinstance(payload.get("pid"), int) and not isinstance(payload.get("session_id"), str):
        return None
    return payload


def _pid_is_live(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        process = psutil.Process(pid)
        if not process.is_running():
            return False
        with contextlib.suppress(psutil.Error):
            if process.status() == psutil.STATUS_ZOMBIE:
                return False
        return True
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return False


def _terminate_process_tree(
    pid: int,
    *,
    timeout_s: float = 5.0,
    expected_start_time: float | None = None,
) -> str:
    if pid <= 0 or pid == os.getpid():
        return "invalid"
    try:
        process = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return "missing"
    except psutil.AccessDenied:
        return "access_denied"

    if expected_start_time is not None and not ProcessRegistry.pid_matches_start_time(
        pid,
        expected_start_time,
        tolerance_s=PID_START_TIME_TOLERANCE_S,
    ):
        return "identity_mismatch"

    children: list[psutil.Process] = []
    with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
        children = process.children(recursive=True)

    all_processes = [*children, process]
    for child in all_processes:
        with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
            child.terminate()

    _gone, alive = psutil.wait_procs(all_processes, timeout=timeout_s)
    for child in alive:
        with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
            child.kill()
    psutil.wait_procs(alive, timeout=timeout_s)
    return "terminated" if not _pid_is_live(pid) else "failed"


def _rotate_file_if_needed(path: Path, *, max_bytes: int, backup_count: int) -> bool:
    if not path.exists():
        return False
    try:
        if path.stat().st_size < max_bytes:
            return False
    except OSError:
        return False

    for index in range(backup_count - 1, 0, -1):
        src = path.parent / f"{path.name}.{index}"
        dst = path.parent / f"{path.name}.{index + 1}"
        if src.exists():
            with contextlib.suppress(OSError):
                src.replace(dst)

    backup_path = path.parent / f"{path.name}.1"
    try:
        path.replace(backup_path)
        path.write_text("", encoding="utf-8")
    except OSError:
        return False
    return True


def _append_unique(items: list[str], value: str) -> None:
    if value not in items:
        items.append(value)


def _is_obra_project_root(path: Path) -> bool:
    try:
        return (path / ".obra").is_dir()
    except OSError:
        return False


def _path_from_optional_string(value: object) -> Path | None:
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value).expanduser().resolve(strict=False)


def _remove_path(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        path.unlink()
        return True
    except OSError:
        return False


def _remove_tree(path: Path) -> bool:
    if not path.exists():
        return False
    if path.is_dir():
        try:
            for child in path.iterdir():
                _remove_tree(child)
            path.rmdir()
            return True
        except OSError:
            return False
    return _remove_path(path)


def _remove_tree_counted(path: Path) -> tuple[int, int]:
    files_removed = 0
    dirs_removed = 0
    if not path.exists():
        return files_removed, dirs_removed
    if path.is_dir():
        for child in sorted(path.iterdir()):
            child_files, child_dirs = _remove_tree_counted(child)
            files_removed += child_files
            dirs_removed += child_dirs
        try:
            path.rmdir()
            dirs_removed += 1
        except OSError:
            pass
        return files_removed, dirs_removed

    if _remove_path(path):
        files_removed += 1
    return files_removed, dirs_removed


def _remove_empty_dirs(root: Path) -> int:
    removed = 0
    if not root.exists():
        return removed
    for directory in sorted((path for path in root.rglob("*") if path.is_dir()), reverse=True):
        with contextlib.suppress(OSError):
            if not any(directory.iterdir()):
                directory.rmdir()
                removed += 1
    with contextlib.suppress(OSError):
        if root.exists() and not any(root.iterdir()):
            root.rmdir()
            removed += 1
    return removed


__all__ = [
    "CleanupReport",
    "ProjectCleanupResult",
    "render_cleanup_report",
    "run_universal_cleanup",
]
