"""Setup command implementation extracted from obra.cli._main."""

from __future__ import annotations

import logging

import typer
from rich.markup import escape

from obra import __version__
from obra.cli.feedback import offer_bug_report
from obra.config.loaders import get_cli_retry_config
from obra.display import console, glyphs, print_error, print_success, print_warning
from obra.display.errors import display_error, display_obra_error
from obra.display.prompting import prompt_input
from obra.exceptions import ConfigurationError, ObraError
from obra.messages import get_message

logger = logging.getLogger(__name__)


def _list_provider_status() -> list[tuple[str, str, bool, str]]:
    """Return provider info tuples for all known LLM providers.

    Each tuple contains:
        - provider_key: the internal provider key (e.g. "anthropic")
        - provider_name: human-readable name from LLM_PROVIDERS
        - installed: whether the CLI is found on the system
        - cli_command: the CLI command string (e.g. "claude")
    """
    from obra.config import LLM_PROVIDERS, check_provider_status

    result: list[tuple[str, str, bool, str]] = []
    for provider_key in LLM_PROVIDERS:
        status = check_provider_status(provider_key)
        provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)
        result.append((provider_key, provider_name, status.installed, status.cli_command))
    return result


def _run_setup_check() -> int:
    """Run the --check flow: terms, auth, and provider status.

    Returns exit code: 0 if all checks pass, 1 otherwise.
    """
    import typer

    from obra.config import (
        TERMS_VERSION,
        is_terms_accepted,
        needs_reacceptance,
    )
    from obra.messages import get_message

    console.print()
    console.print("[bold]Setup Status Check[/bold]", style="cyan")
    console.print()

    # Check terms acceptance
    if is_terms_accepted():
        print_success(f"Terms accepted: version {TERMS_VERSION}")
    elif needs_reacceptance():
        from obra.config import get_terms_acceptance

        old_acceptance = get_terms_acceptance()
        old_version = (
            old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
        )
        print_warning(f"Terms version mismatch: {old_version} → {TERMS_VERSION}")
        console.print(get_message("recovery.auth.terms"))
        raise typer.Exit(1)
    else:
        print_warning("Terms not accepted")
        console.print(get_message("recovery.auth.terms"))
        raise typer.Exit(1)

    # Check authentication
    from obra.auth import get_current_auth

    auth = get_current_auth()
    if auth:
        print_success(f"Authenticated: {auth.email}")
    else:
        print_warning("Not authenticated")
        console.print(get_message("recovery.auth.setup"))
        raise typer.Exit(1)

    # Check environment (provider CLIs)
    console.print()
    console.print("[bold]Environment:[/bold]")

    provider_count = 0
    for _key, provider_name, installed, cli_command in _list_provider_status():
        if installed:
            console.print(
                f"  [green]{glyphs.success}[/green] {provider_name} ({cli_command})"
            )
            provider_count += 1
        else:
            console.print(
                f"  [red]{glyphs.failure}[/red] {provider_name} ({cli_command}) - not found"
            )

    console.print()
    if provider_count > 0:
        print_success("Setup complete - all checks passed")
        raise typer.Exit(0)
    print_warning("No provider CLIs installed")
    console.print("Install Claude Code: curl -fsSL https://claude.ai/install.sh | bash")
    raise typer.Exit(1)


def _run_terms_and_auth(no_browser: bool, timeout: int) -> bool:
    """Run terms acceptance + OAuth authentication + server registration.

    Returns True on success. Raises typer.Exit on failure or cancellation.
    """
    import time

    import typer

    from obra import __version__
    from obra.api import APIClient
    from obra.auth import save_auth
    from obra.config import (
        PRIVACY_VERSION,
        TERMS_VERSION,
        needs_reacceptance,
        save_terms_acceptance,
    )
    from obra.config.loaders import get_cli_retry_config
    from obra.legal import get_terms_summary
    from obra.messages import get_message

    # Check if re-acceptance is needed
    if needs_reacceptance():
        from obra.config import get_terms_acceptance

        old_acceptance = get_terms_acceptance()
        old_version = old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
        console.print(
            f"[yellow]Terms have been updated: v{old_version} → v{TERMS_VERSION}[/yellow]"
        )
        console.print()
        console.print("You must review and accept the updated terms to continue.")
        console.print()

    # Display terms summary
    terms_text = get_terms_summary()

    # Display terms in a box
    console.print(
        "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print(terms_text.strip())
    console.print(
        "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print()

    # Prompt for acceptance
    console.print("To accept these terms, type exactly: [bold]I ACCEPT[/bold]")
    console.print("To decline, type anything else or press Ctrl+C")
    console.print()

    # Get user input
    try:
        from obra.display.prompting import prompt_input

        user_input = prompt_input("> ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print()
        console.print("[yellow]Setup cancelled by user[/yellow]")
        raise typer.Exit(2) from None

    # Check acceptance (case-insensitive)
    if user_input.upper() != "I ACCEPT":
        console.print()
        console.print("[yellow]Terms not accepted. Setup cancelled.[/yellow]")
        console.print()
        console.print(get_message("guidance.requirement.accept_terms"))
        raise typer.Exit(2)

    console.print()
    print_success(f"Terms v{TERMS_VERSION} accepted")
    console.print()

    # Save local acceptance
    save_terms_acceptance()

    # Authenticate via OAuth
    if no_browser:
        console.print("Printing authentication URL (no browser)...")
    else:
        console.print("Opening browser for authentication...")
    console.print()

    try:
        from obra.auth import login_with_device_code

        if no_browser:
            auth_result = login_with_device_code(
                timeout=timeout,
                auto_open_browser=False,
            )
        else:
            auth_result = login_with_device_code(
                timeout=timeout,
                auto_open_browser=True,
            )
        save_auth(auth_result)

        console.print()
        print_success(f"Logged in as: {auth_result.email}")
        if auth_result.display_name:
            console.print(f"Name: {auth_result.display_name}")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Authentication failed: {e}")
        logger.error(f"OAuth flow failed during setup: {e}", exc_info=True)
        raise typer.Exit(1) from e

    # Register terms acceptance with server (MANDATORY)
    client = APIClient.from_config()
    retry_config = get_cli_retry_config()
    max_retries = retry_config["max_attempts"]
    retry_delay = retry_config["initial_delay_s"]
    backoff_multiplier = retry_config["backoff_multiplier"]

    for attempt in range(1, max_retries + 1):
        try:
            client.log_terms_acceptance(
                terms_version=TERMS_VERSION,
                privacy_version=PRIVACY_VERSION,
                client_version=__version__,
            )
            print_success("Terms acceptance registered with server")
            console.print()
            break  # Success - exit retry loop
        except typer.Exit:
            raise
        except Exception as e:
            logger.warning(f"Terms registration attempt {attempt}/{max_retries} failed: {e}")
            if attempt < max_retries:
                console.print(
                    f"[yellow]Server registration failed, retrying ({attempt}/{max_retries})...[/yellow]"
                )
                time.sleep(retry_delay)
                retry_delay *= backoff_multiplier  # Exponential backoff
            else:
                # All retries exhausted - this is fatal
                logger.exception(f"Terms registration failed after {max_retries} attempts")
                print_error("Failed to register terms acceptance with server")
                console.print()
                console.print(
                    "[red]Server-side registration is required for legal compliance.[/red]"
                )
                console.print("Please check your internet connection and try again.")
                console.print()
                console.print(
                    "If the problem persists, please report the issue at: https://github.com/Unpossible-Creations/Obra/issues"
                )
                raise typer.Exit(1) from e

    return True


_PROVIDER_INSTALL_OPTIONS = [
    {
        "name": "Claude Code",
        "description": "Anthropic Claude",
        "commands": [
            ("curl -fsSL https://claude.ai/install.sh | bash", "curl"),
            ("brew install --cask claude-code", "brew"),
        ],
    },
    {
        "name": "OpenAI Codex",
        "description": "OpenAI GPT models",
        "commands": [
            ("npm install -g @openai/codex", "npm"),
        ],
    },
    {
        "name": "Gemini CLI",
        "description": "Google Gemini models",
        "commands": [
            ("npm install -g @google/gemini-cli", "npm"),
        ],
    },
]


def _tool_available(tool: str) -> bool:
    """Check if a CLI tool is available on PATH."""
    import shutil

    return shutil.which(tool) is not None


def _offer_provider_install() -> None:
    """Offer to install a provider CLI when none are found.

    Shows a numbered menu of providers. For each, checks if the required
    installer tool (curl, brew, npm) is available and either runs the install
    command or prints it for manual execution.
    """
    import subprocess

    print_warning("No provider CLIs installed")
    console.print()
    console.print("Obra requires at least one LLM provider CLI.")
    console.print()
    console.print("[bold]Choose a provider to install:[/bold]")
    console.print()

    for idx, opt in enumerate(_PROVIDER_INSTALL_OPTIONS, 1):
        console.print(f"  {idx}. {opt['name']} — {opt['description']}")

    console.print(f"  {len(_PROVIDER_INSTALL_OPTIONS) + 1}. Skip (install manually later)")
    console.print()

    try:
        choice_str = prompt_input("Enter choice [1]: ", console=console).strip()
    except (EOFError, KeyboardInterrupt):
        console.print()
        console.print("[yellow]Skipped provider install.[/yellow]")
        console.print("Run 'obra setup' again after installing a provider CLI.")
        return

    if not choice_str:
        choice = 1
    else:
        try:
            choice = int(choice_str)
        except ValueError:
            console.print("[yellow]Invalid choice. Skipping provider install.[/yellow]")
            return

    if choice < 1 or choice > len(_PROVIDER_INSTALL_OPTIONS):
        console.print("[dim]Skipping provider install.[/dim]")
        console.print("Run 'obra setup' again after installing a provider CLI.")
        return

    selected = _PROVIDER_INSTALL_OPTIONS[choice - 1]

    # If provider only has a manual URL (no auto-install), show it
    if selected.get("manual_url"):
        console.print()
        console.print(f"Install {selected['name']} from: {selected['manual_url']}")
        console.print("Run 'obra setup --check' after installing to verify.")
        return

    # Find a command whose required tool is available
    install_cmd = None
    for cmd, required_tool in selected["commands"]:
        if required_tool is None or _tool_available(required_tool):
            install_cmd = cmd
            break

    if install_cmd is None:
        # No suitable installer found — show all commands for manual install
        console.print()
        console.print(f"[yellow]Could not find a supported installer for {selected['name']}.[/yellow]")
        console.print("Install manually with one of:")
        for cmd, required_tool in selected["commands"]:
            console.print(f"  {cmd}  [dim](requires {required_tool})[/dim]")
        console.print()
        console.print("Run 'obra setup --check' after installing to verify.")
        return

    # Confirm before running
    console.print()
    console.print(f"[bold]Install {selected['name']}:[/bold]")
    console.print(f"  {install_cmd}")
    console.print()

    try:
        confirm = prompt_input("Run this command now? [Y/n]: ", console=console).strip().lower()
    except (EOFError, KeyboardInterrupt):
        console.print()
        console.print("[yellow]Skipped.[/yellow]")
        return

    if confirm and confirm not in ("y", "yes", ""):
        console.print("[dim]Skipped. Run the command above manually, then 'obra setup --check'.[/dim]")
        return

    console.print()
    console.print(f"[cyan]Running: {install_cmd}[/cyan]")
    console.print()

    try:
        result = subprocess.run(
            install_cmd,
            shell=True,
            check=False,
        )
        if result.returncode == 0:
            print_success(f"{selected['name']} installed successfully!")
            console.print()
            # Re-check provider status
            recheck_count = 0
            for _key, _name, installed, _cmd in _list_provider_status():
                if installed:
                    recheck_count += 1
            if recheck_count > 0:
                print_success(f"{recheck_count} provider CLI(s) now available.")
            else:
                console.print("[yellow]Provider CLI not detected yet. You may need to restart your shell.[/yellow]")
                console.print("Run 'obra setup --check' to verify.")
        else:
            print_warning(f"Install command exited with code {result.returncode}")
            console.print("You can retry manually:")
            console.print(f"  {install_cmd}")
            console.print("Then run 'obra setup --check' to verify.")
    except Exception as exc:
        print_warning(f"Install failed: {exc}")
        console.print("Install manually:")
        console.print(f"  {install_cmd}")
        console.print("Then run 'obra setup --check' to verify.")


def _run_environment_validation() -> None:
    """Validate environment: check provider CLIs and working directory."""
    from pathlib import Path

    console.print("[bold]Validating environment...[/bold]")
    console.print()

    provider_count = 0
    for _key, provider_name, installed, cli_command in _list_provider_status():
        if installed:
            console.print(
                f"  [green]{glyphs.success}[/green] {provider_name} CLI: {cli_command}"
            )
            provider_count += 1
        else:
            console.print(f"  [dim]o[/dim] {provider_name} CLI: Not installed")

    console.print()

    # Check working directory
    obra_projects = Path.home() / "obra-projects"
    if obra_projects.exists():
        console.print(
            f"  [green]{glyphs.success}[/green] Working directory: {obra_projects}"
        )
    else:
        console.print(
            f"  [yellow]o[/yellow] Working directory: {obra_projects} (will be created)"
        )

    console.print()

    if provider_count == 0:
        _offer_provider_install()


def _run_provider_selection() -> str:
    """Run the provider selection flow: display, prompt, apply config.

    Returns the selected provider name (display name).
    Raises typer.Exit on cancellation.
    """
    import typer

    from obra.config import (
        DEFAULT_PROVIDER,
        LLM_PROVIDERS,
        load_config,
        save_config,
    )

    console.print("[bold]Select LLM Provider[/bold]")
    console.print("Choose your preferred provider. Recommended settings will be applied.")
    console.print("(You can customize later with 'obra config')")
    console.print()

    # Show available providers with status
    available_providers = []
    for idx, provider_key in enumerate(["anthropic", "openai", "google"], 1):
        if provider_key not in LLM_PROVIDERS:
            continue
        _key, provider_name, installed, _cli_command = next(
            (k, n, i, c) for k, n, i, c in _list_provider_status() if k == provider_key
        )
        if installed:
            console.print(f"  {idx}. {provider_name} [green](installed)[/green]")
        else:
            console.print(f"  {idx}. {provider_name} [dim](not installed)[/dim]")
        available_providers.append(provider_key)

    console.print()

    # Get provider selection
    try:
        from obra.display.prompting import prompt_input

        selection = prompt_input("Enter provider number [1/2/3]: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print()
        console.print("[yellow]Setup cancelled by user[/yellow]")
        raise typer.Exit(2) from None

    # Parse selection
    provider_map = {"1": "anthropic", "2": "openai", "3": "google"}
    selected_provider = provider_map.get(selection, DEFAULT_PROVIDER)

    # Apply default persona features + provider config
    from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config
    from obra.config.llm import apply_provider_config

    config = load_config()
    apply_default_persona_to_config(config)
    config, _notifications = apply_provider_config(config, selected_provider)
    save_config(config)
    console.print()
    provider_display = LLM_PROVIDERS.get(selected_provider, {}).get("name", selected_provider)
    print_success(f"LLM configuration set to {provider_display}")
    console.print()

    return provider_display


def _render_workflow_studio_setup_hint() -> None:
    from obra.cli.studio import _voice_install_hint

    console.print("[bold]Workflow Studio[/bold]")
    console.print("    Launch with `obra studio`.")
    console.print(f"    Optional voice dictation: `{escape(_voice_install_hint())}`")
    console.print("    Diagnose launch issues with `obra studio doctor`.")
    console.print()


def setup(
    check: bool = typer.Option(
        False,
        "--check",
        help="Check setup status without prompting",
    ),
    skip_validation: bool = typer.Option(
        False,
        "--skip-validation",
        help="Skip environment validation after authentication",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
    device_code: bool = typer.Option(  # noqa: ARG001 - kept for backward compat
        False,
        "--device-code",
        hidden=True,
        help="(Deprecated) Device code flow is now the default.",
    ),
) -> None:
    """First-time setup with terms acceptance, authentication, and provider selection.

    Complete onboarding flow:
    1. Display and accept Beta Software Agreement
    2. Authenticate via browser OAuth
    3. Register acceptance with server
    4. Validate environment configuration
    5. Select LLM provider (recommended settings auto-applied)

    Examples:
        $ obra setup
        $ obra setup --check
        $ obra setup --no-browser
        $ obra setup --timeout 600

    Exit Codes:
        0: Setup complete (or --check passed)
        1: Setup incomplete or failed
        2: User declined terms
    """
    try:
        # S1.T6: Implement --check flag
        if check:
            _run_setup_check()
            return

        # Regular setup flow (not --check mode)
        console.print()
        console.print("[bold]Obra Setup[/bold]", style="cyan")
        console.print()

        # Terms acceptance + OAuth authentication + server registration
        _run_terms_and_auth(no_browser=no_browser, timeout=timeout)

        # Environment validation (unless skipped)
        if not skip_validation:
            _run_environment_validation()

        # Provider selection
        _run_provider_selection()
        _render_workflow_studio_setup_hint()

        # S1.T5: Display setup completion with copy-paste prompt
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold green]Setup complete![/bold green]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]  AUTHENTICATION[/bold]")
        console.print()
        console.print("    You authenticate directly with your LLM provider.")
        console.print("    Your provider credentials stay local and are never sent to Obra servers.")
        console.print()
        console.print("    Make sure you have authenticated with your provider:")
        console.print("      [cyan]$ claude login[/cyan]     (Anthropic)")
        console.print("      [cyan]$ codex --login[/cyan]    (OpenAI)")
        console.print("      [cyan]$ gemini[/cyan]           (Google — authenticates on first run)")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]  USING OBRA WITH YOUR AI ASSISTANT[/bold]")
        console.print()
        console.print("    Copy this prompt to your AI assistant (Claude Code, Codex, Gemini):")
        console.print()
        console.print(
            "    [cyan]┌─────────────────────────────────────────────────────────────────┐[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  I want to use Obra. Start with `obra briefing quick`, then  [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  use `obra models`, `obra help domains`, and `obra help run` [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  before invoking `obra run` for my objective.                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]└─────────────────────────────────────────────────────────────────┘[/cyan]"
        )
        console.print()
        console.print("    Your AI will then follow the current discovery path and prepare")
        console.print("    higher-quality input before invoking Obra.")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print()
        console.print("  1. Give your AI the prompt above, then describe what you want to build")
        console.print()
        console.print("  2. Or inspect the LLM/operator path directly:")
        console.print("     [cyan]$ obra briefing quick[/cyan]")
        console.print("     [cyan]$ obra models[/cyan]")
        console.print("     [cyan]$ obra help domains[/cyan]")
        console.print("     [cyan]$ obra help run[/cyan]")
        console.print()
        console.print("  3. Or start directly (if you know what you're doing):")
        console.print('     [cyan]$ obra run "Add user authentication" --stream[/cyan]')
        console.print()
        console.print("  4. Check session status anytime:")
        console.print("     [cyan]$ obra status[/cyan]")
        console.print()
        console.print("  5. Explore configuration:")
        console.print("     [cyan]$ obra config[/cyan]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()

    except typer.Exit:
        # Re-raise typer.Exit without catching it as an error
        raise
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in setup command: {e}", exc_info=True)
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in setup command: {e}", exc_info=True)
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in setup command: {e}")
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
