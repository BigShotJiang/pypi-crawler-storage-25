"""Detect stale editable installs by comparing pyproject.toml content hash.

When Obra is installed with ``pip install -e .``, changes to pyproject.toml
(new dependencies, entry points, package additions) require a reinstall to
take effect.  This module warns developers when pyproject.toml has changed
since the last install.

This check is zero-cost for wheel installs: it exits immediately when the
PEP 610 ``direct_url.json`` editable marker is absent.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
import sys

logger = logging.getLogger(__name__)

_CACHE_DIR = Path.home() / ".obra"
_CACHE_FILE = _CACHE_DIR / ".editable_install_check"


def check_editable_install_freshness() -> None:
    """Refresh or warn if pyproject.toml changed since the last editable install.

    Safe to call on every CLI invocation — returns immediately for wheel
    installs and suppresses all exceptions so it never blocks the CLI.
    """
    try:
        _check()
    except Exception:
        pass


def _check() -> None:
    from importlib import metadata

    try:
        dist = metadata.distribution("obra")
    except metadata.PackageNotFoundError:
        return

    # Only applies to editable installs (PEP 610 direct_url.json)
    dist_path = Path(str(dist._path))
    direct_url_file = dist_path / "direct_url.json"
    if not direct_url_file.is_file():
        return
    try:
        direct_url = json.loads(direct_url_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return
    if not direct_url.get("dir_info", {}).get("editable", False):
        return

    # Find pyproject.toml from the editable URL
    url = direct_url.get("url", "")
    if not url.startswith("file://"):
        return
    pkg_dir = Path(url.removeprefix("file://"))
    pyproject = pkg_dir / "pyproject.toml"
    if not pyproject.is_file():
        # Try parent (URL may point to obra/ subdir)
        pyproject = pkg_dir.parent / "pyproject.toml"
        # Also check obra/pyproject.toml specifically
        if not pyproject.is_file():
            pyproject = pkg_dir / "pyproject.toml"
    if not pyproject.is_file():
        return

    # Hash pyproject.toml content
    current_hash = hashlib.sha256(pyproject.read_bytes()).hexdigest()[:16]
    cache_key = _cache_key(dist_path, pyproject)

    # Get RECORD mtime as a proxy for "last install time"
    record_file = dist_path / "RECORD"
    if not record_file.is_file():
        return
    record_mtime = str(record_file.stat().st_mtime)

    # Load cached state
    cache = _load_cache()
    cached = cache.get(cache_key, {})
    cached_hash = str(cached.get("pyproject_hash", ""))
    cached_record_mtime = str(cached.get("record_mtime", ""))

    if cached_record_mtime != record_mtime:
        # A new install happened (RECORD changed) — record the current
        # pyproject hash silently.  This covers the fresh-install case
        # and the case where someone just ran pip install -e .
        _save_cache(cache_key, current_hash, record_mtime)
        return

    if cached_hash == current_hash:
        # pyproject.toml unchanged since last install — all good.
        return

    if _auto_refresh_if_enabled(pkg_dir, cache_key, current_hash, record_file):
        return

    # pyproject.toml changed but no reinstall happened and auto-refresh
    # is disabled or failed.
    _warn(pyproject)


def _warn(pyproject: Path) -> None:
    """Print a one-line warning to stderr."""
    from obra.install_guidance import recommended_upgrade_command

    command = recommended_upgrade_command()
    try:
        from obra.display import print_warning

        print_warning(
            "pyproject.toml has changed since last install — "
            f"run `{command}` to pick up new packages/dependencies."
        )
    except Exception:
        import sys

        print(
            "WARNING: pyproject.toml has changed since last install — "
            f"run `{command}` to pick up new packages/dependencies.",
            file=sys.stderr,
        )


def _auto_refresh_if_enabled(
    pkg_dir: Path,
    cache_key: str,
    current_hash: str,
    record_file: Path,
) -> bool:
    """Reinstall a stale editable checkout when startup auto-update is enabled."""
    from rich.console import Console

    from obra.config import get_auto_update
    from obra.install_guidance import editable_reinstall_command_parts
    from obra.version_check import _run_upgrade_with_retries, _stop_stale_gateway_before_reexec

    if not get_auto_update():
        return False

    command = editable_reinstall_command_parts(str(pkg_dir))
    if not command:
        return False

    Console(stderr=True).print("[bold cyan]Refreshing editable Obra install...[/bold cyan]")
    success = _run_upgrade_with_retries({"method": "editable", "command": command})
    if not success:
        return False

    new_record_mtime = str(record_file.stat().st_mtime) if record_file.is_file() else ""
    _save_cache(cache_key, current_hash, new_record_mtime)
    _stop_stale_gateway_before_reexec()
    os.execvp(sys.argv[0], sys.argv)
    return True  # pragma: no cover


def _cache_key(dist_path: Path, pyproject: Path) -> str:
    """Return a stable cache key for one editable install surface."""
    return f"{dist_path.resolve()}::{pyproject.resolve()}"


def _load_cache() -> dict[str, dict[str, str]]:
    try:
        if _CACHE_FILE.is_file():
            payload = json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                return {}

            # Legacy format stored a single flat entry. Discard it so each
            # editable install can maintain independent freshness state.
            if "pyproject_hash" in payload or "record_mtime" in payload:
                return {}

            cache: dict[str, dict[str, str]] = {}
            for key, value in payload.items():
                if not isinstance(key, str) or not isinstance(value, dict):
                    continue
                pyproject_hash = value.get("pyproject_hash")
                record_mtime = value.get("record_mtime")
                if not isinstance(pyproject_hash, str) or not isinstance(record_mtime, str):
                    continue
                cache[key] = {
                    "pyproject_hash": pyproject_hash,
                    "record_mtime": record_mtime,
                }
            return cache
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_cache(cache_key: str, pyproject_hash: str, record_mtime: str) -> None:
    try:
        cache = _load_cache()
        cache[cache_key] = {
            "pyproject_hash": pyproject_hash,
            "record_mtime": record_mtime,
        }
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(
            json.dumps(cache, indent=2, sort_keys=True),
            encoding="utf-8",
        )
    except OSError:
        pass
