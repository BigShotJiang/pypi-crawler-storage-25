"""Domain module interface for Obra multi-domain architecture.

This module defines the protocol that all domain modules must implement.
Domains provide specialized configurations for different use cases
(e.g., software development, business workflows).

Architecture:
    - DomainModule: Protocol for domain implementations
    - FileFilterConfig: Configuration for file filtering
    - INTERFACE_VERSION: Version string for compatibility checks

Related:
    - docs/decisions/ADR-059-domain-abstraction-architecture.md
    - docs/guides/domains/domain-overview.md
"""

from dataclasses import dataclass
from typing import Any, Protocol

from obra.domains.lifecycle import (
    DomainDerivationDefaults,
    DomainLifecyclePolicy,
)

INTERFACE_VERSION = "v2"


@dataclass
class FileFilterConfig:
    """Configuration for file filtering in a domain.

    Attributes:
        excluded_files: Specific filenames to exclude (e.g., 'conftest.py')
        excluded_patterns: Glob patterns for exclusion (e.g., '**/migrations/*.py')
        binary_extensions: File extensions to treat as binary (e.g., '.pyc')
        ignore_dirs: Directory names to skip (e.g., 'node_modules')
        ignore_dir_suffixes: Directory suffixes to skip (e.g., '.egg-info')
    """

    excluded_files: frozenset[str]
    excluded_patterns: list[str]
    binary_extensions: frozenset[str]
    ignore_dirs: frozenset[str]
    ignore_dir_suffixes: tuple[str, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FileFilterConfig":
        """Create FileFilterConfig from dictionary.

        Args:
            data: Dictionary with filter configuration

        Returns:
            FileFilterConfig instance
        """
        return cls(
            excluded_files=frozenset(data.get("excluded_files", [])),
            excluded_patterns=list(data.get("excluded_patterns", [])),
            binary_extensions=frozenset(data.get("binary_extensions", [])),
            ignore_dirs=frozenset(data.get("ignore_dirs", [])),
            ignore_dir_suffixes=tuple(data.get("ignore_dir_suffixes", [])),
        )


@dataclass
class QualityDimension:
    """Configures a quality assessment dimension for a domain."""

    id: str
    display_name: str
    description: str
    default_enabled: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QualityDimension":
        """Create QualityDimension from dictionary."""
        return cls(
            id=str(data["id"]),
            display_name=str(data["display_name"]),
            description=str(data["description"]),
            default_enabled=bool(data["default_enabled"]),
        )


@dataclass
class ContextSource:
    """Optional context source descriptor for domain-specific enrichment."""

    id: str
    display_name: str
    description: str
    source_type: str
    default_enabled: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ContextSource":
        """Create ContextSource from dictionary."""
        source_type = str(data["source_type"])
        if source_type not in {"file", "command", "api"}:
            msg = "ContextSource.source_type must be one of 'file', 'command', or 'api'"
            raise ValueError(msg)
        return cls(
            id=str(data["id"]),
            display_name=str(data["display_name"]),
            description=str(data["description"]),
            source_type=source_type,
            default_enabled=bool(data["default_enabled"]),
        )


class DomainModule(Protocol):
    """Interface that all domain modules must implement.

    Domains provide specialized configurations for different orchestration
    use cases. Each domain defines work types, quality prompts, and file
    filtering rules appropriate for its context.

    Example:
        >>> from obra.domains import load_domain
        >>> domain = load_domain("software")
        >>> print(domain.name)
        software
        >>> work_types = domain.get_work_type_patterns()
        >>> print(len(work_types['work_types']))
        10
    """

    @property
    def name(self) -> str:
        """Domain name (e.g., 'software', 'business')."""
        ...

    @property
    def display_name(self) -> str:
        """Human-readable domain name.

        Expected default: title-cased variant of ``name``.
        """
        ...

    @property
    def description(self) -> str:
        """Short domain description used in UI and logs.

        Expected default: one-line summary of domain purpose.
        """
        ...

    @property
    def example_objectives(self) -> list[str]:
        """Representative objective examples for this domain.

        Expected default: at least one valid objective string.
        """
        ...

    @property
    def requires_git(self) -> bool:
        """Whether this domain requires a git repository.

        Expected default: ``True`` for code-centric domains.
        """
        ...

    @property
    def default_sandbox_policy(self) -> str:
        """Default sandbox policy string for this domain.

        Expected default: ``WORKSPACE_WRITE``.
        """
        ...

    @property
    def closeout_key(self) -> str:
        """Key used to resolve closeout templates.

        Expected default: same value as ``name``.
        """
        ...

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for this domain.

        Returns:
            Dictionary with 'work_types' list, 'detection_settings', and 'fallback'
        """
        ...

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for this domain.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        ...

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality dimensions for this domain.

        Each dimension ``id`` must correspond to a key in
        :meth:`get_quality_prompts`.
        """
        ...

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns.

        Returns:
            FileFilterConfig with exclusion rules
        """
        ...

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        ...

    def get_stage_quality_loop_defaults(
        self,
        archetype: str | None = None,
    ) -> dict[str, Any] | None:
        """Return a canonical quality_loop payload for one stage archetype.

        The returned payload must match the canonical shape validated by
        ``collect_stage_quality_loop_issues`` in ``obra.workflow.quality_loop``.
        Implementations may return ``None`` when no default applies.
        """
        ...

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for this domain.

        Returns:
            Markdown-formatted sizing guidance
        """
        ...

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return structured workflow-lifecycle defaults for this domain."""
        ...

    def get_derivation_defaults(self) -> DomainDerivationDefaults:
        """Return structured derivation defaults for workflow synthesis."""
        ...

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Return optional catalog-backed runner declarations for this domain.

        This hook is optional at runtime. Domain loaders should treat a missing
        method as equivalent to returning an empty list.
        """
        ...

    # Optional protocol hook: implementations may omit this and default to an
    # empty list conceptually. Call sites should use getattr(..., None) checks.
    def get_context_sources(self) -> list[ContextSource]:
        """Return optional context sources for domain-aware enrichment."""
        ...
