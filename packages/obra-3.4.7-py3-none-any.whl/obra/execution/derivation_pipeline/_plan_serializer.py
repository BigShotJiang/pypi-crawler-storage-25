"""Plan serialization and per-epic derivation helpers for the pipeline facade."""

from __future__ import annotations

import json
import logging
import re
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_serialize_max_concurrent,
    get_derivation_step3_tier,
)
from obra.exceptions import ObraError
from obra.hybrid.pipeline_factories import build_derive_pipeline
from obra.prompts.derive.derivation import (
    build_step3_per_epic_prompt,
    build_step3_per_epic_prompt_strict,
)

from ._epic_orchestrator import EpicDerivationOrchestrator
from ._plan_assembler import PlanAssembler

logger = logging.getLogger(__name__)

VALID_PHASES = ["explore", "plan", "implement", "commit"]
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}


def _engine_attr(name: str, default: Any) -> Any:
    """Resolve an attribute from the derivation engine module, if loaded."""
    module = sys.modules.get("obra.execution.derivation")
    if module is None:
        return default
    return getattr(module, name, default)


class PlanSerializer:
    """Own per-epic derivation and plan-item serialization helpers."""

    def __init__(
        self,
        *,
        parse_flat_response: Callable,
        working_dir: Path,
        reasoning_level: str,
        validator: Any,
        epic_limits: Callable[[], tuple[int, int]],
    ) -> None:
        self._parse_flat_response = parse_flat_response
        self._working_dir = working_dir
        self._reasoning_level = reasoning_level
        self._validator = validator
        self._epic_limits = epic_limits
        self._plan_assembler = PlanAssembler()
        self._orchestrator = EpicDerivationOrchestrator(
            epic_limits=epic_limits,
            validator=validator,
            working_dir=working_dir,
            plan_assembler=self._plan_assembler,
        )

    @staticmethod
    def build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        """Build minimal plan items for partial plan snapshots.

        Delegates to PlanAssembler.
        """
        return PlanAssembler.build_partial_plan_items(epic_id, epic_title, stories, tasks)

    @staticmethod
    def merge_epic_details(epics_prose: str, all_epic_details: list[str]) -> str:
        """Merge epic-only prose with per-epic story/task details.

        Delegates to PlanAssembler.
        """
        return PlanAssembler.merge_epic_details(epics_prose, all_epic_details)

    def serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Serialize each epic's stories/tasks to JSON in parallel, then merge."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        max_workers = get_derivation_serialize_max_concurrent()
        epic_count = len(parsed_epics)

        if progress_callback:
            progress_callback(
                "epic_serialization_batch_started",
                {
                    "epic_count": epic_count,
                    "max_concurrent": max_workers,
                },
            )

        def serialize_one(
            args: tuple[int, dict[str, Any], str],
        ) -> tuple[int, dict[str, Any], list[dict[str, Any]], int]:
            i, epic, epic_prose = args
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            epic_item: dict[str, Any] = {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "description": epic.get("description", ""),
                "acceptance_criteria": [],
                "dependencies": [],
                "parent_id": None,
                "depth": 0,
                "work_phase": "implement",
                "suggested_agent": None,
            }

            prompt = build_step3_per_epic_prompt(epic_prose, epic_id)
            epic_items = self._parse_flat_response(prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": "success",
                            "outcome": "completed",
                            "is_retry": False,
                        },
                    )
                tokens_est = len(prompt) // 4 + len(json.dumps(epic_items)) // 4
                return (i, epic_item, epic_items, tokens_est)

            story_count, task_count = self._validator.count_epic_story_task_ids(epic_prose, epic_id)
            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "initial",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "retry",
                        "is_retry": False,
                    },
                )

            logger.warning(
                "Epic %s Step 3 initial attempt failed, retrying with strict prompt (expected %d stories, %d tasks)",
                epic_id,
                story_count,
                task_count,
            )
            strict_prompt = build_step3_per_epic_prompt_strict(
                epic_prose,
                epic_id,
                expected_story_count=story_count,
                expected_task_count=task_count,
            )
            epic_items = self._parse_flat_response(strict_prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "strict_retry",
                            "status": "success",
                            "outcome": "completed",
                            "is_retry": True,
                        },
                    )
                tokens_est = (len(prompt) + len(strict_prompt)) // 4 + len(
                    json.dumps(epic_items)
                ) // 4
                return (i, epic_item, epic_items, tokens_est)

            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "strict_retry",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "failed",
                        "is_retry": True,
                    },
                )

            preview = re.sub(r"\s+", " ", epic_prose).strip()[:240]
            artifact_path = self._validator.write_epic_failure_artifact(
                Path(self._working_dir),
                epic_id=epic_id,
                story_count=story_count,
                task_count=task_count,
                reason_codes=["step3_template_fallback"],
                retry_metadata={
                    "initial_status": "template_fallback",
                    "retry_status": "template_fallback",
                    "attempt_stage": "strict_retry",
                },
                output_preview=preview,
            )
            msg = (
                f"No stories/tasks parsed for {epic_id} during per-epic serialization "
                f"(expected {story_count} stories, {task_count} tasks). "
                f"Both standard and strict retry failed."
            )
            if artifact_path:
                msg += f" Artifact: {artifact_path}"
            raise ValueError(msg)

        work = [
            (i, epic, prose)
            for i, (epic, prose) in enumerate(zip(parsed_epics, all_epic_details, strict=False))
        ]
        results: list[tuple[int, dict[str, Any], list[dict[str, Any]], int]] = []
        errors: list[tuple[int, str, Exception]] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(serialize_one, w): w for w in work}
            for future in as_completed(futures):
                i, epic, _ = futures[future]
                epic_id = epic.get("id", f"E{i + 1}")
                epic_title = epic.get("title", "Untitled")
                try:
                    result = future.result()
                    results.append(result)
                    if progress_callback:
                        progress_callback(
                            "epic_serialization_completed",
                            {
                                "epic_index": i + 1,
                                "epic_count": epic_count,
                                "epic_id": epic_id,
                                "epic_title": epic_title,
                                "items_serialized": len(result[2]) + 1,
                            },
                        )
                    logger.debug(
                        "Epic %s serialized: %d items, ~%d tokens",
                        epic_id,
                        len(result[2]) + 1,
                        result[3],
                    )
                except Exception as exc:
                    logger.warning("Epic %s serialization failed: %s", epic_id, exc)
                    errors.append((i, epic_id, exc))

        if errors:
            details = "; ".join(f"{epic_id}: {err}" for _, epic_id, err in errors[:3])
            raise ObraError(
                f"{len(errors)}/{epic_count} epics failed serialization. "
                f"Aborting to avoid incomplete plan. {details}"
            )

        results.sort(key=lambda x: x[0])
        all_plan_items: list[dict[str, Any]] = []
        total_tokens = 0
        for _, epic_item, epic_items, tokens in results:
            all_plan_items.append(epic_item)
            all_plan_items.extend(epic_items)
            total_tokens += tokens

        return all_plan_items, total_tokens

    def derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        """Derive stories + tasks per-epic with cumulative global context.

        Delegates to EpicDerivationOrchestrator.
        """
        return self._orchestrator.derive_per_epic(
            objective=objective,
            epics_prose=epics_prose,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
        )

    def parse_flat_response_via_pipeline(
        self,
        prompt: str,
        provider: str,
    ) -> list[dict[str, Any]]:
        """Parse flat derivation response using TemplateEditPipeline."""
        pipeline = build_derive_pipeline(
            working_dir=self._working_dir,
            action_name="derivation_flat",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items as an array. Each item must have:\n"
                '- id: string (e.g., "E1", "E1.S1", "E1.S1.T1")\n'
                "- title: string (concise action description)\n"
                '- item_type: "epic", "story", or "task"\n'
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on"
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            if len(plan_items) == 0:
                return (False, "plan_items must not be empty")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "title", "item_type", "description"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        step3_tier = get_derivation_step3_tier()
        resolve_tier = _engine_attr("resolve_tier_config", resolve_tier_config)
        tier_config = resolve_tier(step3_tier, role="orchestrator")
        llm_config = {
            "provider": tier_config["provider"],
            "model": tier_config["model"],
            "reasoning_level": tier_config.get("reasoning_level", self._reasoning_level),
            "auth": tier_config.get("auth_method", "oauth"),
        }

        logger.debug(
            "Step 3 serialization using tier=%s, provider=%s, model=%s",
            step3_tier,
            llm_config["provider"],
            llm_config["model"],
        )

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=lambda: {"plan_items": []},
            llm_config=llm_config,
            allow_unchanged=False,
        )

        if metadata.get("status") in ("template_fallback", "template_error", "validation_failed"):
            logger.warning(
                "Flat derivation parsing failed after %d attempts (status=%s), using fallback",
                metadata.get("attempts", 0),
                metadata.get("status"),
            )
            return []

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return []
        return self.normalize_flat_plan_items(plan_items)

    def normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize flat plan items to ensure required fields and correct values."""
        normalized: list[dict[str, Any]] = []
        stories_by_id: dict[str, dict[str, Any]] = {}

        for item in items:
            if not isinstance(item, dict):
                continue

            item_id = item.get("id", "")
            item_type = item.get("item_type", "task")
            title = item.get("title", "Untitled")
            description = item.get("description", "") or title

            acceptance = item.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                acceptance = [acceptance] if acceptance else []

            deps = item.get("dependencies", [])
            if not isinstance(deps, list):
                deps = [deps] if deps else []

            if item_type == "epic":
                depth = 0
            elif item_type == "story":
                depth = 1
            else:
                depth = 2

            parent_id = item.get("parent_id")
            if item_type == "epic":
                parent_id = None
            elif item_type == "story" and not parent_id:
                parent_id = "E1"
            elif item_type == "task" and not parent_id:
                if "." in item_id:
                    parent_id = item_id.rsplit(".", 1)[0]
                elif stories_by_id:
                    parent_id = next(iter(stories_by_id.keys()), "S1")
                else:
                    parent_id = "S1"

            raw_phase = item.get("work_phase", "implement")
            work_phase = raw_phase if raw_phase in VALID_PHASES else "implement"
            raw_agent = item.get("suggested_agent")
            suggested_agent = raw_agent if raw_agent is not None else PHASE_TO_AGENT.get(work_phase)

            normalized_item = {
                "id": item_id or f"T{len(normalized) + 1}",
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": acceptance,
                "dependencies": deps,
                "parent_id": parent_id,
                "depth": depth,
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }

            normalized.append(normalized_item)
            if item_type == "story":
                stories_by_id[normalized_item["id"]] = normalized_item

        return normalized

    def parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        """Parse hierarchical derivation response using TemplateEditPipeline."""
        pipeline = build_derive_pipeline(
            working_dir=self._working_dir,
            action_name="derivation_hierarchical",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items with full hierarchy. Each item needs:\n"
                '- id: string (e.g., "T1", "E1", "E1.S1", "E1.S1.T1")\n'
                '- item_type: "epic", "story", "task", "subtask", or "milestone"\n'
                "- title: string (concise action description)\n"
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on\n"
                '- work_phase: "explore", "plan", "implement", or "commit" (default: implement)'
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "item_type", "title"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=lambda: {"plan_items": None},
            llm_config={
                "provider": provider,
                "model": None,
                "reasoning_level": self._reasoning_level,
                "auth": "oauth",
            },
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Hierarchical derivation parsing failed after %d attempts, using diagnostic fallback",
                metadata.get("attempts", 0),
            )
            return self._validator.create_diagnostic_fallback(
                "Pipeline parse failed",
                "Template edit parsing failed after retries",
                "",
            )

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return self._validator.create_diagnostic_fallback(
                "Invalid plan_items type",
                f"Expected list, got {type(plan_items).__name__}",
                "",
            )

        return self._validator.normalize_hierarchical_plan_items(plan_items)
