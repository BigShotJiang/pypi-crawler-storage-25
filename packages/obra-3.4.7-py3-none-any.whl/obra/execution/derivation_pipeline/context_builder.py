"""Context-building helpers for the derivation engine."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from obra.config.loaders import get_derivation_preview_config

logger = logging.getLogger(__name__)

_preview_config = get_derivation_preview_config()
README_PREVIEW_LIMIT = _preview_config["readme_limit"]


class DerivationContextBuilder:
    """Owns local-project context gathering for derivation prompts."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    @staticmethod
    def render_constraints(constraints: dict[str, Any] | str | None) -> str:
        if constraints is None:
            return ""
        if isinstance(constraints, dict):
            constraints_markdown = constraints.get("constraints_markdown")
            if isinstance(constraints_markdown, str) and constraints_markdown.strip():
                return constraints_markdown
            return json.dumps(constraints)
        if isinstance(constraints, str):
            return constraints
        return json.dumps(constraints)

    def gather_context(self, project_context: dict[str, Any]) -> dict[str, Any]:
        """Gather local context for derivation."""
        context = dict(project_context)

        try:
            structure = self.summarize_structure()
            context["file_structure"] = structure
        except Exception as exc:
            logger.warning("Failed to gather file structure: %s", exc)

        readme_path = Path(self._owner._working_dir) / "README.md"
        if readme_path.exists():
            try:
                content = readme_path.read_text(encoding="utf-8")
                context["readme"] = content[:README_PREVIEW_LIMIT] + (
                    "..." if len(content) > README_PREVIEW_LIMIT else ""
                )
            except Exception:
                pass

        return context

    def summarize_structure(self) -> list[str]:
        """Summarize project file structure."""
        important_files: list[str] = []
        important_patterns = [
            # Source files (all major ecosystems)
            "*.py",
            "*.js",
            "*.ts",
            "*.tsx",
            "*.jsx",
            "*.rs",
            "*.go",
            "*.java",
            "*.kt",
            "*.cs",
            "*.cpp",
            "*.c",
            "*.h",
            "*.hpp",
            "*.swift",
            "*.rb",
            "*.php",
            "*.dart",
            "*.scala",
            # Manifests and config
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "Cargo.toml",
            "go.mod",
            "pom.xml",
            "build.gradle",
            "CMakeLists.txt",
            "*.csproj",
            "Package.swift",
            "composer.json",
            "pubspec.yaml",
            "Gemfile",
            # Documentation and build
            "README.md",
            "Makefile",
            "Dockerfile",
        ]

        max_files = 50
        skip_dirs = {
            ".git",
            "node_modules",
            "__pycache__",
            ".venv",
            "venv",
            "dist",
            "build",
            "target",
            ".gradle",
            "obj",
            "_build",
        }

        for pattern in important_patterns:
            for path in Path(self._owner._working_dir).rglob(pattern):
                if any(skip_dir in path.parts for skip_dir in skip_dirs):
                    continue

                try:
                    rel_path = path.relative_to(self._owner._working_dir)
                    important_files.append(str(rel_path))
                except ValueError:
                    continue

                if len(important_files) >= max_files:
                    break

            if len(important_files) >= max_files:
                break

        return sorted(important_files)[:max_files]

    @staticmethod
    def build_context_section(context: dict[str, Any]) -> str:
        """Format project context for prompt injection."""
        context_parts: list[str] = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        return "\n".join(context_parts) if context_parts else "No project context available."
