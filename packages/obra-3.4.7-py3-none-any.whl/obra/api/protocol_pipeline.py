"""Pipeline stage protocol types shared across client and server.

This module is part of the protocol*.py family and is kept byte-for-byte
in sync between:
- functions/src/orchestration/protocol_pipeline.py
- obra/api/protocol_pipeline.py

Contains PipelineStage* dataclasses and their helper functions, extracted
from protocol.py to reduce cognitive load for LLM-led development.
"""

from dataclasses import dataclass, field
from typing import Any

from obra.workflow.stage_artifacts import (
    collect_artifact_contract_issues,
    normalize_stage_output_artifacts,
    normalize_workflow_accumulation_artifact,
)

from .protocol_core import _coerce_lifecycle_payload, _coerce_optional_dict


@dataclass
class StageRoutingSignal:
    """Advisory routing recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRoutingSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class StageLoopSignal:
    """Advisory loop-control recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    current_iteration: int = 0
    max_iterations: int = 0
    loop_verdict: str = ""
    loop_state: str = ""
    retry_with: dict[str, Any] = field(default_factory=dict)
    pending_manual: "PendingManualPayload | None" = None
    resume: "LoopResumePayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "current_iteration": self.current_iteration,
            "max_iterations": self.max_iterations,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "retry_with": self.retry_with,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageLoopSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            current_iteration=int(data.get("current_iteration", 0) or 0),
            max_iterations=int(data.get("max_iterations", 0) or 0),
            loop_verdict=str(data.get("loop_verdict", "") or ""),
            loop_state=str(data.get("loop_state", "") or ""),
            retry_with=(
                data.get("retry_with", {}) if isinstance(data.get("retry_with"), dict) else {}
            ),
            pending_manual=PendingManualPayload.from_dict(data.get("pending_manual")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class LoopResumePayload:
    """Explicit loop-resume metadata carried across request, result, and state payloads."""

    checkpoint: str = ""
    strategy: str = ""
    token: str = ""
    token_field: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "checkpoint": self.checkpoint,
            "strategy": self.strategy,
            "token": self.token,
            "token_field": self.token_field,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "LoopResumePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            checkpoint=str(data.get("checkpoint", "") or ""),
            strategy=str(data.get("strategy", "") or ""),
            token=str(data.get("token", "") or ""),
            token_field=str(data.get("token_field", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
            workflow_lifecycle=_coerce_lifecycle_payload(data.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class PendingManualPayload:
    """Explicit metadata for a stage paused in pending-manual loop state."""

    reason: str = ""
    required_action: str = ""
    blocking: bool = True
    resume: LoopResumePayload | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "reason": self.reason,
            "required_action": self.required_action,
            "blocking": self.blocking,
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "PendingManualPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            reason=str(data.get("reason", "") or ""),
            required_action=str(data.get("required_action", "") or ""),
            blocking=bool(True if data.get("blocking") is None else data.get("blocking")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
            workflow_lifecycle=_coerce_lifecycle_payload(data.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class WaitPayload:
    """Explicit WAIT action payload contract for polling and resume flows."""

    status: str = ""
    reason: str = ""
    confidence: float | None = None
    polling: dict[str, Any] = field(default_factory=dict)
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] = field(default_factory=dict)
    accepted_revision_ref: dict[str, Any] = field(default_factory=dict)
    expected_baseline_ref: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        payload: dict[str, Any] = {
            "status": self.status,
            "reason": self.reason,
            "polling": self.polling,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }
        if self.confidence is not None:
            payload["confidence"] = self.confidence
        if self.pending_manual is not None:
            payload["pending_manual"] = self.pending_manual.to_dict()
        if self.resume is not None:
            payload["resume"] = self.resume.to_dict()
        if self.derivation_id is not None:
            payload["derivation_id"] = self.derivation_id
        if self.operator_review_checkpoint_state:
            payload["operator_review_checkpoint_state"] = self.operator_review_checkpoint_state
        if self.accepted_revision_ref:
            payload["accepted_revision_ref"] = self.accepted_revision_ref
        if self.expected_baseline_ref:
            payload["expected_baseline_ref"] = self.expected_baseline_ref
        if self.correlation:
            payload["correlation"] = self.correlation
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "WaitPayload":
        """Create from ServerAction payload."""
        return cls(
            status=str(payload.get("status") or ""),
            reason=str(payload.get("reason") or ""),
            confidence=(
                float(payload["confidence"]) if payload.get("confidence") is not None else None
            ),
            polling=_coerce_optional_dict(payload.get("polling")),
            pending_manual=PendingManualPayload.from_dict(payload.get("pending_manual")),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            workflow_lifecycle=_coerce_lifecycle_payload(payload.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(payload.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                payload.get("legacy_phase_normalization")
            ),
            derivation_id=(
                str(payload.get("derivation_id"))
                if payload.get("derivation_id") is not None
                else None
            ),
            operator_review_checkpoint_state=_coerce_optional_dict(
                payload.get("operator_review_checkpoint_state")
            ),
            accepted_revision_ref=_coerce_optional_dict(payload.get("accepted_revision_ref")),
            expected_baseline_ref=_coerce_optional_dict(payload.get("expected_baseline_ref")),
            correlation=_coerce_optional_dict(payload.get("correlation")),
            metadata=_coerce_optional_dict(payload.get("metadata")),
        )


@dataclass
class ArtifactReferencePayload:
    """Wire-safe canonical artifact reference."""

    target_artifact_type: str = ""
    target_artifact_id: str = ""
    target_version_selector: str = "latest"
    relationship_type: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "target_artifact_type": self.target_artifact_type,
            "target_artifact_id": self.target_artifact_id,
            "target_version_selector": self.target_version_selector,
            "relationship_type": self.relationship_type,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ArtifactReferencePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            target_artifact_type=str(data.get("target_artifact_type", "") or ""),
            target_artifact_id=str(data.get("target_artifact_id", "") or ""),
            target_version_selector=str(data.get("target_version_selector", "latest") or "latest"),
            relationship_type=str(data.get("relationship_type", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class ResolvedStageAssetBindingPayload:
    """Wire-safe resolved stage-template binding metadata."""

    binding_role: str = ""
    binding_scope: str = ""
    stage_id: str = ""
    artifact_ref: ArtifactReferencePayload | None = None
    content_format: str = ""
    adoption_state: str = ""
    materialized_path: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "binding_role": self.binding_role,
            "binding_scope": self.binding_scope,
            "stage_id": self.stage_id,
            "artifact_ref": (
                self.artifact_ref.to_dict() if self.artifact_ref is not None else None
            ),
            "content_format": self.content_format,
            "adoption_state": self.adoption_state,
            "materialized_path": self.materialized_path,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ResolvedStageAssetBindingPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            binding_role=str(data.get("binding_role", "") or ""),
            binding_scope=str(data.get("binding_scope", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            artifact_ref=ArtifactReferencePayload.from_dict(data.get("artifact_ref")),
            content_format=str(data.get("content_format", "") or ""),
            adoption_state=str(data.get("adoption_state", "") or ""),
            materialized_path=str(data.get("materialized_path", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class ProducedArtifactPayload:
    """Wire-safe produced artifact metadata used by stage runners."""

    artifact_type: str = ""
    artifact_id: str = ""
    version: str = ""
    compatibility_version: str = ""
    created_at: str = ""
    producer_kind: str = ""
    producer_id: str = ""
    operation_kind: str = ""
    workflow_execution_id: str = ""
    attempt_id: str = ""
    stage_id: str = ""
    stage_name: str = ""
    path: str = ""
    file_targets: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "artifact_type": self.artifact_type,
            "artifact_id": self.artifact_id,
            "version": self.version,
            "compatibility_version": self.compatibility_version,
            "created_at": self.created_at,
            "producer_kind": self.producer_kind,
            "producer_id": self.producer_id,
            "operation_kind": self.operation_kind,
            "workflow_execution_id": self.workflow_execution_id,
            "attempt_id": self.attempt_id,
            "stage_id": self.stage_id,
            "stage_name": self.stage_name,
            "path": self.path,
            "file_targets": self.file_targets,
            "files_changed": self.files_changed,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ProducedArtifactPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            artifact_type=str(data.get("artifact_type", "") or ""),
            artifact_id=str(data.get("artifact_id", "") or ""),
            version=str(data.get("version", "") or ""),
            compatibility_version=str(data.get("compatibility_version", "") or ""),
            created_at=str(data.get("created_at", "") or ""),
            producer_kind=str(data.get("producer_kind", "") or ""),
            producer_id=str(data.get("producer_id", "") or ""),
            operation_kind=str(data.get("operation_kind", "") or ""),
            workflow_execution_id=str(data.get("workflow_execution_id", "") or ""),
            attempt_id=str(data.get("attempt_id", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            stage_name=str(data.get("stage_name", "") or ""),
            path=str(data.get("path", "") or ""),
            file_targets=(
                [str(item) for item in data.get("file_targets", []) if str(item).strip()]
                if isinstance(data.get("file_targets"), list)
                else []
            ),
            files_changed=(
                [str(item) for item in data.get("files_changed", []) if str(item).strip()]
                if isinstance(data.get("files_changed"), list)
                else []
            ),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


# Request pipeline types (StageRunnerContext, PipelineStageRequest, and helpers)
# are now in protocol_pipeline_request.py. Lazy re-exports below preserve
# backward compatibility for existing import paths.

_RESULT_SYMBOLS = {
    "PipelineStageResult",
    "_hydrate_result_signals",
    "_validate_and_normalize_result_artifacts",
    "_reconcile_result_fields",
    "_reconcile_result_runner_metadata",
    "_sync_result_findings_and_issues",
    "_resolve_result_verdict_state",
    "_enrich_result_metadata",
    "_parse_result_signal_fields",
    "_parse_result_runner_fields",
}

_REQUEST_SYMBOLS = {
    "StageRunnerContext",
    "PipelineStageRequest",
    "_build_runner_context_core_fields",
    "_build_runner_context_loop_and_runtime_fields",
    "_hydrate_stage_request_fields",
    "_resolve_stage_artifact_fallbacks",
    "_normalize_stage_request_artifacts",
    "_sync_request_identity_fields",
    "_sync_bidirectional_list_fields",
    "_inject_artifacts_into_content",
    "_sync_loop_state",
    "_sync_stage_request_context",
    "_parse_payload_artifact_refs",
    "_build_stage_request_identity_fields",
    "_build_stage_request_iteration_fields",
    "_resolve_stage_request_content",
    "_BIDI_LIST_FIELDS",
    "_BIDI_OPTIONAL_FIELDS",
}


def __getattr__(name: str):
    """Lazy re-export request/result pipeline symbols (PEP 562, ADR-045)."""
    if name in _REQUEST_SYMBOLS:
        from . import protocol_pipeline_request as _req_mod

        value = getattr(_req_mod, name)
        globals()[name] = value
        return value
    if name in _RESULT_SYMBOLS:
        from . import protocol_pipeline_result as _res_mod

        value = getattr(_res_mod, name)
        globals()[name] = value
        return value
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


@dataclass
class RunnerDiagnosticPayload:
    """Structured runner resolution or installability diagnostic."""

    code: str
    message: str
    runner_id: str = ""
    requested_selector: str = ""
    requested_version: str = ""
    source_layer: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "RunnerDiagnosticPayload | None":
        """Create from dictionary payload."""
        if not isinstance(data, dict):
            return None
        return cls(
            code=str(data.get("code", "") or ""),
            message=str(data.get("message", "") or ""),
            runner_id=str(data.get("runner_id", "") or ""),
            requested_selector=str(data.get("requested_selector", "") or ""),
            requested_version=str(data.get("requested_version", "") or ""),
            source_layer=str(data.get("source_layer", "") or ""),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary payload."""
        return {
            "code": self.code,
            "message": self.message,
            "runner_id": self.runner_id,
            "requested_selector": self.requested_selector,
            "requested_version": self.requested_version,
            "source_layer": self.source_layer,
        }


# Result pipeline types (PipelineStageResult and helpers) are now in
# protocol_pipeline_result.py. Lazy re-exports above preserve backward
# compatibility.


def _parse_artifact_refs(
    refs: list[ArtifactReferencePayload] | list[dict[str, Any]] | None,
) -> list[ArtifactReferencePayload]:
    """Normalize artifact reference payloads from dicts or dataclasses."""
    normalized: list[ArtifactReferencePayload] = []
    for item in refs or []:
        if isinstance(item, ArtifactReferencePayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact_ref = ArtifactReferencePayload.from_dict(item)
            if artifact_ref is not None:
                normalized.append(artifact_ref)
    return normalized


def _parse_resolved_stage_asset_bindings(
    bindings: list[ResolvedStageAssetBindingPayload] | list[dict[str, Any]] | None,
) -> list[ResolvedStageAssetBindingPayload]:
    """Normalize resolved stage bindings from dict or dataclass form."""
    normalized: list[ResolvedStageAssetBindingPayload] = []
    for item in bindings or []:
        if isinstance(item, ResolvedStageAssetBindingPayload):
            normalized.append(item)
            continue
        if isinstance(item, dict):
            binding = ResolvedStageAssetBindingPayload.from_dict(item)
            if binding is not None:
                normalized.append(binding)
    return normalized


def _parse_produced_artifacts(
    artifacts: list[ProducedArtifactPayload] | list[dict[str, Any]] | None,
) -> list[ProducedArtifactPayload]:
    """Normalize produced artifact payloads from dicts or dataclasses."""
    normalized: list[ProducedArtifactPayload] = []
    for item in artifacts or []:
        if isinstance(item, ProducedArtifactPayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact = ProducedArtifactPayload.from_dict(item)
            if artifact is not None:
                normalized.append(artifact)
    return normalized


def _raise_artifact_contract_issues(issues: list[dict[str, Any]]) -> None:
    """Raise a deterministic validation error for typed artifact contract issues."""
    if not issues:
        return
    first_issue = issues[0]
    field_name = str(first_issue.get("field") or "artifact_contract")
    message = str(first_issue.get("message") or "Invalid stage artifact payload.")
    raise ValueError(f"{field_name}: {message}")
