"""API client for Obra Firebase Cloud Functions with retry logic and error handling.

Provides HTTP client wrapper for communicating with Cloud Functions endpoints,
implementing retry logic, timeout handling, and optional compression.

The client composes resource sub-clients (SessionClient, UserPlanClient) that
share a common HTTPCore transport layer.

Sub-client access:
    New code may use the resource sub-clients directly::

        client.sessions.get_session(session_id)
        client.userplans.create_userplan(...)

    The corresponding methods on ``APIClient`` itself (e.g.
    ``client.get_session()``, ``client.create_userplan()``) remain part of the
    supported public API and simply forward to the sub-clients.
"""

import json
import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import urlencode

import requests  # type: ignore[import-untyped]
from pydantic import BaseModel

from obra.api._http_core import HTTPCore
from obra.api._session_client import SessionClient
from obra.api._userplan_client import UserPlanClient
from obra.config import AUTH_STATE_PATH, FIREBASE_API_KEY
from obra.config.loaders import (
    get_api_base_url,
    get_api_client_config,
    load_auth_state,
)
from obra.constants import (
    API_DEFAULT_TIMEOUT_S,
    API_EVENTS_DEFAULT_LIMIT,
    API_LIMIT_MAX,
    API_PLANS_DEFAULT_LIMIT,
    API_TOKEN_REFRESH_THRESHOLD_MINUTES,
    API_USER_FEEDBACK_DEFAULT_LIMIT,
)
from obra.exceptions import (
    APIError,
    ConfigurationError,
    ErrorContext,
)
from obra.messages import get_message

logger = logging.getLogger(__name__)

# Attributes transparently delegated to the underlying HTTPCore transport.
# Reads and writes on an APIClient instance are forwarded via __getattr__ /
# __setattr__ so callers can use e.g. ``client.auth_token`` without knowing
# about the composition boundary.
_DELEGATED_HTTP_ATTRS: frozenset[str] = frozenset(
    {
        "base_url",
        "auth_token",
        "refresh_token",
        "firebase_api_key",
        "timeout",
        "enable_compression",
        "auto_refresh",
        "token_expires_at",
        "trace_id",
        "trace_span_id",
    }
)


class APIClient:
    """HTTP client for Obra Cloud Functions API.

    Implements:
    - Automatic retry with exponential backoff
    - Timeout handling
    - Auth token management
    - Optional gzip compression for large payloads
    - Standardized error handling

    Composes resource sub-clients for organized API access:
    - client.sessions: SessionClient for session lifecycle operations
    - client.userplans: UserPlanClient for UserPlan CRUD operations

    All methods are also available directly on APIClient for backward
    compatibility (e.g., client.get_session() forwards to client.sessions.get_session()).

    Example:
        client = APIClient(
            base_url="https://us-central1-obra-205b0.cloudfunctions.net",
            auth_token="your-firebase-token"
        )
        # Direct access (backward compatible)
        response = client.get_status(session_id="sess-123")
        # Sub-client access (new preferred path)
        response = client.sessions.get_status(session_id="sess-123")
    """

    DEFAULT_TIMEOUT = API_DEFAULT_TIMEOUT_S  # seconds
    TOKEN_REFRESH_THRESHOLD = timedelta(
        minutes=API_TOKEN_REFRESH_THRESHOLD_MINUTES
    )  # Refresh if <5 minutes until expiration

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        refresh_token: str | None = None,
        firebase_api_key: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
        enable_compression: bool = True,
        auto_refresh: bool = True,
        pool_retries: bool = True,
    ) -> None:
        """Initialize APIClient.

        Args:
            base_url: Base URL for Cloud Functions (e.g., https://us-central1-obra-205b0.cloudfunctions.net)
            auth_token: Firebase ID token for authentication
            refresh_token: Firebase refresh token for token renewal
            firebase_api_key: Firebase Web API key (required for token refresh)
            timeout: Request timeout in seconds (default: 30)
            enable_compression: Enable gzip compression for requests >5KB
            auto_refresh: Automatically refresh token when close to expiration
            pool_retries: Enable connection pool retries for transient connect errors

        Raises:
            ConfigurationError: If base_url is invalid
        """
        # Create shared HTTP transport
        self._http = HTTPCore(
            base_url=base_url,
            auth_token=auth_token,
            refresh_token=refresh_token,
            firebase_api_key=firebase_api_key,
            timeout=timeout,
            enable_compression=enable_compression,
            auto_refresh=auto_refresh,
            pool_retries=pool_retries,
        )

        # Compose resource sub-clients
        self.sessions = SessionClient(self._http)
        self.userplans = UserPlanClient(self._http)

    # =========================================================================
    # Attribute delegation to HTTPCore
    # =========================================================================

    @property
    def session(self) -> requests.Session:
        """Access the underlying requests.Session (read-only)."""
        return self._http.session

    def __getattr__(self, name: str) -> Any:
        """Delegate reads of HTTP-transport attributes to ``self._http``."""
        if name in _DELEGATED_HTTP_ATTRS:
            return getattr(self._http, name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        """Delegate writes of HTTP-transport attributes to ``self._http``."""
        if name in _DELEGATED_HTTP_ATTRS and "_http" in self.__dict__:
            setattr(self._http, name, value)
        else:
            object.__setattr__(self, name, value)

    def _build_fallback_error_context(
        self,
        *,
        method: str,
        endpoint: str,
        request_id: str | None,
        payload: dict[str, Any] | None,
    ) -> ErrorContext | None:
        """Build minimal error context when server context is missing."""
        return self._http._build_fallback_error_context(
            method=method, endpoint=endpoint, request_id=request_id, payload=payload
        )

    def set_trace_context(self, trace_id: str, span_id: str | None = None) -> None:
        """Set trace context headers for end-to-end observability."""
        self._http.set_trace_context(trace_id, span_id)

    def _build_trace_header(self) -> str | None:
        """Build X-Cloud-Trace-Context header value."""
        return self._http._build_trace_header()

    def refresh_auth_token(self) -> bool:
        """Refresh authentication token using Firebase refresh token."""
        return self._http.refresh_auth_token()

    def _check_token_expiration(self) -> None:
        """Check if token needs refresh and refresh if necessary."""
        self._http._check_token_expiration()

    def _save_token_to_config(
        self,
        token: str,
        expires_at: datetime | None = None,
        refresh_token: str | None = None,
    ) -> None:
        """Save auth token to auth state file for persistence."""
        self._http._save_token_to_config(token, expires_at, refresh_token)

    def set_auth_token(self, token: str) -> None:
        """Update authentication token."""
        self._http.set_auth_token(token)

    def _request(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        retry: bool = True,
        skip_auth_check: bool = False,
        response_schema: type[BaseModel] | None = None,
        request_id: str | None = None,
        client_request_start_ts: float | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with retry logic and optional response validation."""
        return self._http._request(
            method=method,
            endpoint=endpoint,
            json=json,
            retry=retry,
            skip_auth_check=skip_auth_check,
            response_schema=response_schema,
            request_id=request_id,
            client_request_start_ts=client_request_start_ts,
            timeout=timeout,
        )

    @classmethod
    def from_config(
        cls,
        config_path: "Any | None" = None,  # noqa: ARG003
        *,
        pool_retries: bool = True,
    ) -> "APIClient":
        """Create APIClient from configuration and auth state files.

        Args:
            config_path: Unused, kept for API compatibility. Auth is read
                from ~/.obra/auth.yaml.
            pool_retries: Enable connection pool retries for transient connect errors

        Returns:
            Configured APIClient instance

        Raises:
            ConfigurationError: If not authenticated or auth state is invalid
        """
        # Load auth credentials (triggers migration from old config if needed)
        auth_state = load_auth_state()
        if not auth_state:
            msg = f"Auth state not found: {AUTH_STATE_PATH}\n{get_message('recovery.auth.login')}"
            raise ConfigurationError(msg)

        # Get API base URL with proper precedence:
        # 1. OBRA_API_BASE_URL env var (for local emulator/staging)
        # 2. api_base_url from config file
        # 3. Default production URL
        base_url = get_api_base_url()

        auth_token = auth_state.get("auth_token")
        refresh_token = auth_state.get("refresh_token")
        firebase_api_key = auth_state.get("firebase_api_key") or FIREBASE_API_KEY

        # Check for authentication
        if not auth_token:
            msg = f"Not authenticated.\n{get_message('recovery.auth.login')}"
            raise ConfigurationError(msg)

        # Parse token expiration
        token_expires_at = None
        expires_at_str = auth_state.get("token_expires_at")
        if expires_at_str:
            try:
                token_expires_at = datetime.fromisoformat(expires_at_str)
                # Ensure timezone-aware for comparison with datetime.now(timezone.utc)
                if token_expires_at.tzinfo is None:
                    token_expires_at = token_expires_at.replace(tzinfo=UTC)
            except Exception as e:
                logger.warning(
                    "Failed to parse token expiration date '%s': %s (type: %s)",
                    expires_at_str,
                    str(e),
                    type(e).__name__,
                )

        # Create client
        client = cls(
            base_url=base_url,
            auth_token=auth_token,
            refresh_token=refresh_token,
            firebase_api_key=firebase_api_key,
            auto_refresh=True,
            pool_retries=pool_retries,
        )

        client.token_expires_at = token_expires_at

        # Refresh token if expired (or close to expiration)
        if token_expires_at and token_expires_at < datetime.now(UTC):
            if refresh_token and firebase_api_key:
                if not client.refresh_auth_token():
                    msg = (
                        "Authentication token expired and refresh failed.\n"
                        f"{get_message('recovery.auth.login')}"
                    )
                    raise ConfigurationError(msg)
            else:
                msg = f"Authentication token expired.\n{get_message('recovery.auth.login')}"
                raise ConfigurationError(msg)

        return client

    # =========================================================================
    # Health & Version Methods (stay on APIClient)
    # =========================================================================

    def health_check(self) -> dict[str, Any]:
        """Check API health.

        Returns:
            Health status dictionary

        Raises:
            APIError: If health check fails
        """
        return self._http._request("GET", "health", skip_auth_check=True)

    def get_version(self) -> dict[str, Any]:
        """Get API version and client compatibility info.

        Returns:
            Version info dictionary with fields:
            - api_version: Server API version
            - min_client_version: Minimum compatible client version
            - features: List of enabled features

        Raises:
            APIError: If version check fails
        """
        return self._http._request("GET", "version", skip_auth_check=True)

    def assert_client_version_supported(self) -> dict[str, Any]:
        """Fail fast when server marks this client version unsupported.

        Returns:
            Raw version payload from the server.

        Raises:
            APIError: If server reports this client version as unsupported.
        """
        from http import HTTPStatus

        version_info = self.get_version()

        client_info: dict[str, Any] = {}
        if isinstance(version_info, dict):
            raw_client_info = version_info.get("client", {})
            if isinstance(raw_client_info, dict):
                client_info = raw_client_info

        status = str(client_info.get("status", "")).strip().lower()
        if status != "unsupported":
            return version_info

        current_version = str(
            client_info.get("current_version") or HTTPCore._get_client_version()
        ).strip()
        min_supported = str(client_info.get("min_supported_version") or "unknown").strip()
        upgrade_message = str(client_info.get("upgrade_message") or "").strip()
        from obra.install_guidance import recommended_upgrade_command

        upgrade_command = recommended_upgrade_command()
        detail = (
            f"Client version {current_version} is no longer supported. "
            f"Minimum required: {min_supported}"
        )

        error_body = json.dumps(
            {
                "error": "upgrade_required",
                "message": detail,
                "min_version": min_supported,
                "current_version": current_version,
                "upgrade_message": upgrade_message or "Upgrade your local Obra CLI and retry.",
                "upgrade_command": upgrade_command,
            }
        )

        raise APIError(
            message=f"API error 426: upgrade_required: {detail}",
            status_code=HTTPStatus.UPGRADE_REQUIRED.value,
            response_body=error_body,
            recovery=f"Upgrade Obra and retry. {upgrade_command}",
        )

    # =========================================================================
    # Session Methods (forwarding to SessionClient)
    # =========================================================================

    def get_status(self, session_id: str) -> dict[str, Any]:
        """Query session status."""
        return self.sessions.get_status(session_id)

    def _expand_session_id(self, session_id: str) -> str:
        """Expand a short session ID to full UUID."""
        return self.sessions._expand_session_id(session_id)

    def get_session(self, session_id: str) -> dict[str, Any]:
        """Get session details with resume context."""
        return self.sessions.get_session(session_id)

    def list_sessions(
        self,
        limit: int = 10,
        status: str | None = None,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """List recent sessions for the current user."""
        return self.sessions.list_sessions(limit=limit, status=status, project_id=project_id)

    def cancel_session(self, session_id: str) -> dict[str, Any]:
        """Cancel a session by setting status to abandoned."""
        return self.sessions.cancel_session(session_id)

    def repair_session(self, session_id: str) -> dict[str, Any]:
        """Repair a session by auto-detecting and fixing common issues."""
        return self.sessions.repair_session(session_id)

    def force_complete_session(self, session_id: str, reason: str | None = None) -> dict[str, Any]:
        """Force-complete a session regardless of current phase."""
        return self.sessions.force_complete_session(session_id, reason=reason)

    def reset_review(self, session_id: str) -> dict[str, Any]:
        """Reset a session's review state and return to execution phase."""
        return self.sessions.reset_review(session_id)

    def get_session_events(
        self,
        session_id: str,
        limit: int = API_EVENTS_DEFAULT_LIMIT,
        offset: int = 0,
        event_type: str | None = None,
        severity: str | None = None,
    ) -> dict[str, Any]:
        """Query event history for a session."""
        return self.sessions.get_session_events(
            session_id, limit=limit, offset=offset, event_type=event_type, severity=severity
        )

    def get_session_plan(self, session_id: str) -> dict[str, Any]:
        """Get plan items with execution status for a session."""
        return self.sessions.get_session_plan(session_id)

    # =========================================================================
    # Project Methods (stay on APIClient)
    # =========================================================================

    def _normalize_project_id(self, project_id: str | int | None) -> str | None:
        """Normalize project identifiers to strings for API payloads."""
        if project_id is None:
            return None
        return str(project_id)

    def list_projects(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        """List projects for the current user."""
        query_string = "all=true" if include_deleted else "all=false"
        response = self._http._request("GET", f"list_projects?{query_string}")
        projects = response.get("projects")
        if isinstance(projects, list):
            return [project for project in projects if isinstance(project, dict)]
        logger.warning("Unexpected projects payload shape: %s", type(projects).__name__)
        return []

    def list_projects_with_selection(self, include_deleted: bool = False) -> dict[str, Any]:
        """List projects with the user's default selection.

        Returns:
            Dictionary with:
            - projects: List of project dictionaries
            - default_project_id: The user's selected default project ID (or None)
        """
        query_string = "all=true" if include_deleted else "all=false"
        response = self._http._request("GET", f"list_projects?{query_string}")
        projects = response.get("projects")
        if isinstance(projects, list):
            projects = [project for project in projects if isinstance(project, dict)]
        else:
            logger.warning("Unexpected projects payload shape: %s", type(projects).__name__)
            projects = []
        return {
            "projects": projects,
            "default_project_id": response.get("default_project_id"),
        }

    def get_project(self, project_id: str) -> dict[str, Any]:
        """Get a project by ID."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._http._request("GET", f"get_project?project_id={normalized_project_id}")

    def create_project(
        self,
        name: str,
        working_dir: str,
        description: str = "",
        config: dict[str, Any] | None = None,
        domain_id: str | None = None,
        reuse_existing_for_working_dir: bool = False,
    ) -> dict[str, Any]:
        """Create a project."""
        payload: dict[str, Any] = {
            "name": name,
            "working_dir": working_dir,
            "description": description,
            "config": config or {},
        }
        if domain_id is not None:
            payload["domain_id"] = domain_id
        if reuse_existing_for_working_dir:
            payload["reuse_existing_for_working_dir"] = True
        return self._http._request("POST", "create_project", json=payload)

    def update_project(
        self,
        project_id: str,
        name: str | None = None,
        working_dir: str | None = None,
        domain_id: str | None = None,
    ) -> dict[str, Any]:
        """Update a project."""
        normalized_project_id = self._normalize_project_id(project_id)
        payload: dict[str, Any] = {"project_id": normalized_project_id}
        if name is not None:
            payload["name"] = name
        if working_dir is not None:
            payload["working_dir"] = working_dir
        if domain_id is not None:
            payload["domain_id"] = domain_id
        return self._http._request("POST", "update_project", json=payload)

    def delete_project(self, project_id: str) -> dict[str, Any]:
        """Soft delete a project."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._http._request(
            "POST", "delete_project", json={"project_id": normalized_project_id}
        )

    def select_project(self, project_id: str) -> dict[str, Any]:
        """Set default project for the user."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._http._request(
            "POST", "select_project", json={"project_id": normalized_project_id}
        )

    # =========================================================================
    # Resume Method (stays on APIClient)
    # =========================================================================

    def resume(
        self,
        session_id: str,
        *,
        bypass_modes: list[str] | None = None,
        resume_target: str | None = None,
        workflow_lifecycle: dict[str, Any] | None = None,
        lifecycle_decisions: dict[str, Any] | None = None,
        legacy_phase_normalization: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resume an interrupted orchestration session.

        Args:
            session_id: Session ID to resume
            bypass_modes: Optional bypass modes for resume routing
            resume_target: Optional lifecycle-aware resume target
            workflow_lifecycle: Optional workflow lifecycle contract payload
            lifecycle_decisions: Optional workflow lifecycle routing decisions
            legacy_phase_normalization: Optional legacy phase-normalization metadata

        Returns:
            Response dictionary with fields:
            - session_id: Session ID
            - base_prompt: Continuation prompt
            - metadata: Prompt metadata
            - status: Session status ("active")
            - iteration: Current iteration number

        Raises:
            APIError: If resume request fails
        """
        from obra.api.protocol import ResumeRequest

        payload = ResumeRequest(
            session_id=session_id,
            bypass_modes=list(bypass_modes or []),
            resume_target=resume_target,
            workflow_lifecycle=workflow_lifecycle,
            lifecycle_decisions=lifecycle_decisions,
            legacy_phase_normalization=legacy_phase_normalization,
        ).to_dict()
        return self._http._request("POST", "resume", json=payload)

    # =========================================================================
    # Workflow Studio Bundle (stays on APIClient - composes session methods)
    # =========================================================================

    def get_workflow_studio_bundle(
        self,
        session_id: str,
        *,
        event_limit: int = API_EVENTS_DEFAULT_LIMIT,
    ) -> dict[str, Any]:
        """Load the Workflow Studio read bundle for one hybrid session."""
        session = self.get_session(session_id)
        plan = self.get_session_plan(session_id)
        events_response = self.get_session_events(session_id, limit=event_limit)
        return {
            "session": session,
            "plan": plan,
            "events": events_response.get("events", []),
            "event_count": events_response.get("count", 0),
            "has_more_events": events_response.get("has_more", False),
        }

    # =========================================================================
    # Workflow Methods (stay on APIClient)
    # =========================================================================

    def list_workflows(
        self,
        *,
        include_archived: bool = False,
        include_deleted: bool = False,
    ) -> dict[str, Any]:
        """List canonical workflow heads from the SaaS workflow store."""
        query = urlencode(
            {
                "include_archived": str(include_archived).lower(),
                "include_deleted": str(include_deleted).lower(),
            }
        )
        return self._http._request("GET", f"list_workflows?{query}")

    def get_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Get one canonical workflow head from the SaaS workflow store."""
        return self._http._request("GET", f"get_workflow?workflow_id={workflow_id}")

    def list_workflow_revisions(self, workflow_id: str) -> dict[str, Any]:
        """List canonical workflow revisions from the SaaS workflow store."""
        return self._http._request(
            "GET",
            f"list_workflow_revisions?workflow_id={workflow_id}",
        )

    def get_workflow_revision(self, workflow_id: str, revision_id: str) -> dict[str, Any]:
        """Get one canonical workflow revision from the SaaS workflow store."""
        return self._http._request(
            "GET",
            f"get_workflow_revision?workflow_id={workflow_id}&revision_id={revision_id}",
        )

    def create_workflow(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Create a canonical workflow in the SaaS workflow store."""
        return self._http._request("POST", "create_workflow", json=payload)

    def archive_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Archive one canonical workflow in the SaaS workflow store."""
        return self._http._request("POST", "archive_workflow", json={"workflow_id": workflow_id})

    def restore_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Restore one archived or soft-deleted canonical workflow."""
        return self._http._request("POST", "restore_workflow", json={"workflow_id": workflow_id})

    def soft_delete_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Move one canonical workflow to trash."""
        return self._http._request(
            "POST", "soft_delete_workflow", json={"workflow_id": workflow_id}
        )

    def hard_delete_workflow(self, workflow_id: str) -> None:
        """Permanently delete one canonical workflow."""
        self._http._request("DELETE", "hard_delete_workflow", json={"workflow_id": workflow_id})

    def validate_workflow_candidate(
        self,
        payload: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a canonical workflow candidate without persistence."""
        headers_payload = dict(payload)
        if expected_revision_id is not None and "expected_revision_id" not in headers_payload:
            headers_payload["expected_revision_id"] = expected_revision_id
        return self._http._request(
            "POST",
            "validate_workflow_candidate",
            json=headers_payload,
        )

    def apply_workflow_candidate(
        self,
        payload: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Apply a guarded canonical workflow candidate."""
        request_payload = dict(payload)
        if expected_revision_id is not None and "expected_revision_id" not in request_payload:
            request_payload["expected_revision_id"] = expected_revision_id
        return self._http._request(
            "PATCH",
            "apply_workflow_candidate",
            json=request_payload,
        )

    # =========================================================================
    # Runner Methods (stay on APIClient)
    # =========================================================================

    def list_runners(self) -> dict[str, Any]:
        """List canonical runner catalog entries."""
        return self._http._request("GET", "list_runners")

    def get_runner(
        self,
        runner_id: str,
        *,
        runner_version: str | None = None,
        runner_selector: str | None = None,
    ) -> dict[str, Any]:
        """Get one canonical runner detail payload."""
        params = [f"runner_id={runner_id}"]
        if runner_version:
            params.append(f"runner_version={runner_version}")
        if runner_selector:
            params.append(f"runner_selector={runner_selector}")
        return self._http._request("GET", f"get_runner?{'&'.join(params)}")

    def check_runner_compatibility(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Check one runner against an explicit compatibility context."""
        return self._http._request("POST", "check_runner_compatibility", json=payload)

    # =========================================================================
    # Terms & Auth Methods (stay on APIClient)
    # =========================================================================

    def log_terms_acceptance(
        self,
        terms_version: str,
        privacy_version: str,
        client_version: str,
        source: str = "cli_setup",
        user_id: str | None = None,
        email: str | None = None,
    ) -> bool:
        """Log terms acceptance to server for legal compliance audit trail.

        Args:
            terms_version: Version of terms accepted (e.g., "2.1")
            privacy_version: Version of privacy policy (e.g., "1.3")
            client_version: obra package version
            source: Where acceptance occurred (default: "cli_setup")
            user_id: Firebase UID (preferred identifier)
            email: User email address (fallback identifier)

        Returns:
            True if server logging succeeded, False otherwise
        """
        payload: dict[str, Any] = {
            "terms_version": terms_version,
            "privacy_version": privacy_version,
            "client_version": client_version,
            "source": source,
        }

        if user_id:
            payload["user_id"] = user_id
        if email:
            payload["email"] = email

        try:
            response = self._http._request(
                method="POST",
                endpoint="terms_accept",
                json=payload,
                retry=True,
                skip_auth_check=False,
            )

            success_value = response.get("success")
            if isinstance(success_value, bool):
                return success_value
            logger.warning(
                "Unexpected success flag type in terms_accept response: %s",
                type(success_value).__name__,
            )
            return False

        except Exception as e:
            # Graceful degradation: don't raise, just return False
            logger.warning(
                "Terms acceptance logging failed for endpoint=%s: %s",
                "terms_accept",
                str(e),
            )
            return False

    def close(self) -> None:
        """Close HTTP session and cleanup resources."""
        self._http.session.close()

    # =========================================================================
    # User Configuration Methods (stay on APIClient)
    # =========================================================================

    def get_user_config(
        self,
        *,
        retry: bool = True,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Get user's configuration (preset + overrides + resolved).

        Returns:
            Dictionary with fields:
            - preset: str - Current preset name
            - overrides: dict - User's custom overrides
            - resolved: dict - Full merged configuration
            - created_at: str - When config was created
            - updated_at: str - When config was last updated

        Args:
            retry: Whether to retry on transient failures
            timeout: Optional request timeout override (seconds)

        Raises:
            APIError: If request fails
        """
        return self._http._request("GET", "get_user_config", retry=retry, timeout=timeout)

    def update_user_config(
        self,
        preset: str | None = None,
        overrides: dict[str, Any] | None = None,
        clear_overrides: bool = False,
    ) -> dict[str, Any]:
        """Update user's configuration.

        Args:
            preset: New preset name (optional)
            overrides: Dict of dot-notation path overrides to merge
            clear_overrides: If True, clear all existing overrides

        Returns:
            Dictionary with updated config

        Raises:
            APIError: If request fails
        """
        payload: dict[str, Any] = {}

        if preset is not None:
            payload["preset"] = preset

        if overrides is not None:
            payload["overrides"] = overrides

        if clear_overrides:
            payload["clear_overrides"] = True

        if not payload:
            return self.get_user_config()

        return self._http._request("POST", "update_user_config", json=payload)

    def list_presets(self) -> dict[str, Any]:
        """List available configuration presets.

        Returns:
            Dictionary with fields:
            - presets: list of preset info dicts

        Raises:
            APIError: If request fails
        """
        return self._http._request("GET", "list_presets")

    # =========================================================================
    # Plan Management Methods (stay on APIClient)
    # =========================================================================

    def upload_plan(self, name: str, plan_data: dict) -> dict[str, Any]:
        """Upload a MACHINE_PLAN.yaml to the server.

        Uploads a parsed plan structure to Firestore for later use.
        The plan is stored in users/{uid}/plans/{plan_id} and can be
        referenced in subsequent derive commands via --plan-id.

        Args:
            name: Plan name (typically work_id from YAML)
            plan_data: Parsed YAML structure (dict representation)

        Returns:
            Dictionary with fields:
            - plan_id: UUID for the uploaded plan
            - name: Plan name
            - story_count: Number of stories in the plan
            - created_at: Timestamp when plan was uploaded

        Raises:
            APIError: If upload fails or validation fails
        """
        payload = {
            "name": name,
            "plan_data": plan_data,
        }
        return self._http._request("POST", "upload_plan", json=payload)

    def list_plans(self, limit: int = API_PLANS_DEFAULT_LIMIT) -> list[dict[str, Any]]:
        """List user's uploaded plans.

        Args:
            limit: Maximum number of plans to return (default: 50, max: 100)

        Returns:
            List of plan dictionaries

        Raises:
            APIError: If list request fails
        """
        params = f"limit={min(limit, API_LIMIT_MAX)}"
        # ISSUE-SAAS-019: Fixed endpoint name to match deployed Firebase function
        response = self._http._request("GET", f"list_plans?{params}")
        plans = response.get("plans")
        if isinstance(plans, list):
            return [plan for plan in plans if isinstance(plan, dict)]
        logger.warning("Unexpected plans payload shape: %s", type(plans).__name__)
        return []

    def get_plan(self, plan_id: str) -> dict[str, Any]:
        """Get details of a specific plan.

        Args:
            plan_id: UUID of the plan to retrieve

        Returns:
            Plan data dictionary

        Raises:
            APIError: If plan not found or request fails
        """
        return self._http._request("GET", f"get_plan?plan_id={plan_id}")

    def delete_plan(self, plan_id: str) -> dict[str, Any]:
        """Delete a plan from the server.

        Args:
            plan_id: UUID of the plan to delete

        Returns:
            Dictionary with deletion result

        Raises:
            APIError: If plan not found or deletion fails
        """
        return self._http._request("DELETE", f"delete_plan?plan_id={plan_id}")

    # =========================================================================
    # UserPlan Methods (forwarding to UserPlanClient)
    # =========================================================================

    def create_userplan(
        self,
        userplan_id: str,
        project_id: str,
        source: dict[str, Any],
        steps: list[dict[str, Any]],
        session_id: str | None = None,
        status: str = "draft",
        quality_score: float | None = None,
        quality_status: str = "not_assessed",
        work_type: str | None = None,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new UserPlan in storage."""
        return self.userplans.create_userplan(
            userplan_id=userplan_id,
            project_id=project_id,
            source=source,
            steps=steps,
            session_id=session_id,
            status=status,
            quality_score=quality_score,
            quality_status=quality_status,
            work_type=work_type,
            context=context,
            metadata=metadata,
        )

    def get_userplan(self, userplan_id: str) -> dict[str, Any] | None:
        """Get a UserPlan by ID."""
        return self.userplans.get_userplan(userplan_id)

    def list_userplans(
        self,
        project_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List UserPlans with optional filters."""
        return self.userplans.list_userplans(project_id=project_id, status=status, limit=limit)

    def update_userplan_quality(
        self,
        userplan_id: str,
        quality_score: float | None,
        quality_status: str,
        quality_hints: list[str] | None = None,
        quality_threshold: float = 0.6,
    ) -> dict[str, Any]:
        """Update UserPlan with quality assessment results."""
        return self.userplans.update_userplan_quality(
            userplan_id=userplan_id,
            quality_score=quality_score,
            quality_status=quality_status,
            quality_hints=quality_hints,
            quality_threshold=quality_threshold,
        )

    def update_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        title: str | None = None,
        description: str | None = None,
        expected_version: int | None = None,
        cascade: bool = False,
    ) -> dict[str, Any]:
        """Update a specific step in a UserPlan."""
        return self.userplans.update_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
            title=title,
            description=description,
            expected_version=expected_version,
            cascade=cascade,
        )

    def update_userplan_step_status(
        self,
        userplan_id: str,
        step_index: int,
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of a specific step in a UserPlan."""
        return self.userplans.update_userplan_step_status(
            userplan_id=userplan_id,
            step_index=step_index,
            derivation_status=derivation_status,
            expected_version=expected_version,
        )

    def update_userplan_steps_status_batch(
        self,
        userplan_id: str,
        step_indices: list[int],
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of multiple steps in a UserPlan."""
        return self.userplans.update_userplan_steps_status_batch(
            userplan_id=userplan_id,
            step_indices=step_indices,
            derivation_status=derivation_status,
            expected_version=expected_version,
        )

    def add_userplan_step(
        self,
        userplan_id: str,
        title: str,
        description: str,
        index: int | None = None,
        context: dict[str, Any] | None = None,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Add a new step to a UserPlan."""
        return self.userplans.add_userplan_step(
            userplan_id=userplan_id,
            title=title,
            description=description,
            index=index,
            context=context,
            expected_version=expected_version,
        )

    def remove_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Remove a step from a UserPlan."""
        return self.userplans.remove_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
            expected_version=expected_version,
        )

    def get_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
    ) -> dict[str, Any] | None:
        """Get a specific step from a UserPlan."""
        return self.userplans.get_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
        )

    def update_userplan_step_context(
        self,
        userplan_id: str,
        step_index: int,
        context: dict[str, Any],
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the context of a specific step in a UserPlan."""
        return self.userplans.update_userplan_step_context(
            userplan_id=userplan_id,
            step_index=step_index,
            context=context,
            expected_version=expected_version,
        )

    # =========================================================================
    # Feedback Methods (stay on APIClient)
    # =========================================================================

    def submit_feedback(self, feedback_data: dict[str, Any]) -> dict[str, Any]:
        """Submit beta tester feedback to the server."""
        return self._http._request(
            "POST",
            "feedback",
            json=feedback_data,
            timeout=get_api_client_config()[
                "default_timeout_s"
            ],  # E1 regression fix (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        )

    def get_feedback(self, report_id: str) -> dict[str, Any]:
        """Get a feedback report by ID."""
        return self._http._request("GET", f"feedback?report_id={report_id}")

    def list_user_feedback(self, limit: int = API_USER_FEEDBACK_DEFAULT_LIMIT) -> dict[str, Any]:
        """List feedback reports submitted by the current user."""
        return self._http._request("GET", f"feedback?limit={limit}")

    # =========================================================================
    # Quality Methods (stay on APIClient)
    # =========================================================================

    def get_quality_scorecard(self, session_id: str, item_id: str) -> dict[str, Any]:
        """Get quality scorecard for a specific plan item.

        Args:
            session_id: Session ID (full UUID or short prefix)
            item_id: Plan item identifier

        Returns:
            Dictionary with field:
            - scorecard: Quality scorecard dict
        """
        full_id = self._expand_session_id(session_id)
        return self._http._request(
            "GET",
            f"get_quality_scorecard?session_id={full_id}&item_id={item_id}",
        )
