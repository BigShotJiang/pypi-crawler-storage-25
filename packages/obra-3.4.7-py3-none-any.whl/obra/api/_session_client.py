"""Session resource sub-client for the Obra API.

Provides session management operations: status queries, session lifecycle
(cancel, repair, force-complete, reset-review), event history, and plan retrieval.

All HTTP operations delegate to the shared HTTPCore instance.
"""

from __future__ import annotations

from http import HTTPStatus
from typing import TYPE_CHECKING, Any

from obra.constants import (
    API_EVENTS_DEFAULT_LIMIT,
    API_PLANS_DEFAULT_LIMIT,
    API_SESSIONS_DEFAULT_LIMIT,
)
from obra.exceptions import APIError

if TYPE_CHECKING:
    from obra.api._http_core import HTTPCore

import logging

logger = logging.getLogger(__name__)


class SessionClient:
    """Sub-client for session-related API operations.

    Encapsulates session status, lifecycle management, event history,
    and plan retrieval. Delegates all HTTP transport to a shared HTTPCore.

    Example:
        from obra.api._http_core import HTTPCore

        http = HTTPCore(base_url="https://...", auth_token="...")
        sessions = SessionClient(http)
        status = sessions.get_status("sess-123")
    """

    def __init__(self, http: HTTPCore) -> None:
        """Initialize SessionClient.

        Args:
            http: Shared HTTPCore instance for HTTP transport
        """
        self._http = http

    def get_status(self, session_id: str) -> dict[str, Any]:
        """Query session status.

        Args:
            session_id: Session ID to query

        Returns:
            Status dictionary with fields:
            - session_id: Session ID
            - status: Current status (active, completed, expired, failed)
            - current_iteration: Current iteration number
            - objective: Task objective
            - task_type: Task type

        Raises:
            APIError: If status query fails
        """
        return self._http._request("GET", f"get_status?session_id={session_id}")

    def _expand_session_id(self, session_id: str) -> str:
        """Expand a short session ID to full UUID.

        Supports Git-style short IDs for better UX. If the provided ID is already
        a full UUID (36 chars with 4 dashes), returns it unchanged. Otherwise,
        queries recent sessions and finds the first match by prefix.

        Args:
            session_id: Full UUID or short ID prefix (e.g., "54439c55")

        Returns:
            Full UUID string

        Raises:
            APIError: If session not found (404) or ID is ambiguous (400)
        """
        # Check if it's already a full UUID (36 chars, 4 dashes)
        if len(session_id) == 36 and session_id.count("-") == 4:
            return session_id

        # Treat as short ID - query sessions and find match
        sessions = self.list_sessions(limit=API_PLANS_DEFAULT_LIMIT)
        matches = [s for s in sessions if s.get("session_id", "").startswith(session_id)]

        if len(matches) == 0:
            raise APIError(
                message="Session not found",
                status_code=HTTPStatus.NOT_FOUND.value,
                response_body=f"No session found matching ID prefix '{session_id}'",
            )

        if len(matches) > 1:
            # Multiple matches - require more specific ID
            match_ids = [s["session_id"][:16] + "..." for s in matches[:3]]
            raise APIError(
                message=f"Ambiguous session ID '{session_id}' matches {len(matches)} sessions",
                status_code=HTTPStatus.BAD_REQUEST.value,
                response_body=f"Matches: {', '.join(match_ids)}. Please provide more characters.",
            )

        # Exactly one match found
        session_id_value = matches[0].get("session_id")
        if not isinstance(session_id_value, str):
            raise APIError(
                message="Session ID missing or invalid in API response",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR.value,
                response_body=str(matches[0]),
            )

        return session_id_value

    def get_session(self, session_id: str) -> dict[str, Any]:
        """Get session details with resume context.

        This is the enhanced session endpoint per PRD Pre-Implementation #2.

        Supports both full UUIDs and short ID prefixes (Git-style). Short IDs
        are automatically expanded to full UUIDs by querying recent sessions.

        Args:
            session_id: Session ID (full UUID or short prefix like "54439c55")

        Returns:
            Session dictionary with fields:
            - session_id: Session ID
            - objective: Task objective
            - state: Current state
            - current_phase: Current orchestration phase
            - iteration: Current iteration number
            - resume_context: Context for resuming (if applicable)
            - quality_scorecard: Quality metrics (if available)
            - pending_escalation: Pending escalation notice (if any)
            - created_at: Session creation timestamp
            - updated_at: Last update timestamp
            - working_dir: Working directory path (for resume)
            - project_id: Project ID (for resume)

        Raises:
            APIError: If session query fails, session not found (404), or ID is ambiguous (400)
        """
        # Expand short ID to full UUID if needed (ISSUE-SAAS-044 fix)
        full_id = self._expand_session_id(session_id)

        try:
            return self._http._request("GET", f"get_hybrid_session?session_id={full_id}")
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return self.get_status(full_id)
            raise

    def list_sessions(
        self,
        limit: int = API_SESSIONS_DEFAULT_LIMIT,
        status: str | None = None,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """List recent sessions for the current user.

        Args:
            limit: Maximum number of sessions to return (default: 10)
            status: Filter by session status (active, completed, expired)

        Returns:
            List of session dictionaries with summary info

        Raises:
            APIError: If list request fails
        """
        params = [f"limit={limit}"]
        if status:
            params.append(f"status={status}")
        if project_id:
            params.append(f"project_id={project_id}")

        query_string = "&".join(params)
        # ISSUE-SAAS-020: Fixed endpoint name to match deployed Firebase function
        response = self._http._request("GET", f"list_sessions?{query_string}")
        sessions = response.get("sessions")
        if isinstance(sessions, list):
            return [session for session in sessions if isinstance(session, dict)]
        logger.warning("Unexpected sessions payload shape: %s", type(sessions).__name__)
        return []

    def cancel_session(self, session_id: str) -> dict[str, Any]:
        """Cancel a session by setting status to abandoned.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to cancel (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether cancellation succeeded
            - session_id: str - The cancelled session ID
            - message: str - Success message

        Raises:
            APIError: If cancellation request fails (403: not owner, 404: not found, 400: ambiguous)
        """
        # Expand short ID to full UUID if needed (ISSUE-SAAS-044 fix)
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._http._request("POST", "cancel_session", json=payload)

    def repair_session(self, session_id: str) -> dict[str, Any]:
        """Repair a session by auto-detecting and fixing common issues.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to repair (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether repair succeeded
            - message: str - Result message
            - repairs_applied: list[dict] - List of repairs, each with:
                - field: str - Field that was repaired (e.g., 'item_id', 'phase', 'status')
                - action: str - Action taken (e.g., 'recovered', 'advanced', 'reconciled')

        Possible repairs:
            - missing_item_id: Recovers missing item_id from execution_results
            - stuck_wait_state: Advances phase when stuck in WAIT status
            - inconsistent_status: Reconciles status/phase mismatches

        Raises:
            APIError: If repair request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._http._request("POST", "repair_session", json=payload)

    def force_complete_session(self, session_id: str, reason: str | None = None) -> dict[str, Any]:
        """Force-complete a session regardless of current phase.

        Marks the session as COMPLETED and preserves all execution results.
        Use this for stuck sessions that have completed work but cannot progress.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to force-complete (full UUID or short prefix)
            reason: Optional reason for force completion (for audit trail)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether force-complete succeeded
            - message: str - Result message
            - preserved_results: int - Count of execution results preserved
            - warnings: list[str] - Warnings about incomplete work

        Raises:
            APIError: If request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id, "reason": reason}
        return self._http._request("POST", "force_complete_session", json=payload)

    def reset_review(self, session_id: str) -> dict[str, Any]:
        """Reset a session's review state and return to execution phase.

        Clears review results for the current item and resets the session phase
        to EXECUTION, allowing the item to be re-executed. Useful when review
        keeps failing or incorrect review results need to be discarded.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to reset review for (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether reset succeeded
            - message: str - Result message
            - item_id: str - Item ID that was reset (if in review phase)
            - previous_phase: str - Phase before reset (if in review phase)

        Raises:
            APIError: If request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._http._request("POST", "reset_review", json=payload)

    def get_session_events(
        self,
        session_id: str,
        limit: int = API_EVENTS_DEFAULT_LIMIT,
        offset: int = 0,
        event_type: str | None = None,
        severity: str | None = None,
    ) -> dict[str, Any]:
        """Query event history for a session.

        Args:
            session_id: Session ID to query events for
            limit: Maximum number of events to return (default 100, max 1000)
            offset: Number of events to skip for pagination
            event_type: Filter by event type
            severity: Filter by severity level (INFO, WARNING, ERROR)

        Returns:
            Response dictionary with fields:
            - session_id: Session ID
            - events: List of event dicts
            - count: Number of events returned
            - has_more: Whether more events exist

        Raises:
            APIError: If request fails
        """
        params = [f"session_id={session_id}", f"limit={limit}", f"offset={offset}"]
        if event_type:
            params.append(f"event_type={event_type}")
        if severity:
            params.append(f"severity={severity}")

        query_string = "&".join(params)
        return self._http._request("GET", f"get_session_events?{query_string}")

    def get_session_plan(self, session_id: str) -> dict[str, Any]:
        """Get plan items with execution status for a session.

        Retrieves the derived execution plan for a session, including
        the status of each task (pending, in_progress, completed, failed).

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID (full UUID or short prefix like "54439c55")

        Returns:
            Dictionary with fields:
            - session_id: Full session UUID
            - plan_items: List of plan item dictionaries with:
                - item_id: Unique task identifier
                - title: Task title/description
                - status: pending | in_progress | completed | failed
                - order: Execution order (1-based)
                - started_at: Timestamp when task started (if applicable)
                - completed_at: Timestamp when task completed (if applicable)
            - total_count: Total number of plan items
            - completed_count: Number of completed items
            - objective: Session objective

        Raises:
            APIError: If session not found (404), ID ambiguous (400), or request fails

        Example:
            >>> sessions = SessionClient(http)
            >>> plan = sessions.get_session_plan("abc123")
            >>> for item in plan['plan_items']:
            ...     status = 'done' if item['status'] == 'completed' else 'pending'
            ...     print(f"{status} {item['title']}")
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        return self._http._request("GET", f"get_session_plan?session_id={full_id}")
