"""Shared HTTP infrastructure for the Obra API client.

Provides the core HTTP transport layer including request execution with retry,
token management, trace context, and standardized error handling.

All resource sub-clients (SessionClient, UserPlanClient, etc.) delegate
HTTP operations to a shared HTTPCore instance.
"""

import json
import logging
import platform
import secrets
import time
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, NoReturn, cast
from urllib.parse import urljoin

import requests  # type: ignore[import-untyped]
import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, ValidationError
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from obra.config import AUTH_STATE_PATH, FIREBASE_API_KEY
from obra.config.loaders import (
    get_api_connection_pool_config,
    get_api_retry_delays,
)
from obra.constants import (
    API_DEFAULT_TIMEOUT_S,
    API_MAX_RETRIES,
    API_TOKEN_REFRESH_THRESHOLD_MINUTES,
)
from obra.exceptions import (
    APIError,
    ConfigurationError,
    ErrorContext,
    TermsNotAcceptedError,
)
from obra.messages import get_message

logger = logging.getLogger(__name__)


class HTTPCore:
    """Shared HTTP transport layer for the Obra API client.

    Owns the requests.Session and provides:
    - Request execution with retry and exponential backoff
    - Token management (refresh, expiration checks, persistence)
    - Trace context for end-to-end observability
    - Standardized error handling and classification

    Example:
        http = HTTPCore(
            base_url="https://us-central1-obra-205b0.cloudfunctions.net",
            auth_token="your-firebase-token",
        )
        response = http._request("GET", "health", skip_auth_check=True)
    """

    DEFAULT_TIMEOUT = API_DEFAULT_TIMEOUT_S  # seconds
    MAX_RETRIES = API_MAX_RETRIES
    # Lazy-loaded from config to avoid circular imports
    RETRY_DELAYS: list[int] | None = None  # seconds (exponential backoff)
    TOKEN_REFRESH_THRESHOLD = timedelta(
        minutes=API_TOKEN_REFRESH_THRESHOLD_MINUTES
    )  # Refresh if <5 minutes until expiration

    # Firebase Token Refresh API endpoint
    FIREBASE_TOKEN_URL = "https://securetoken.googleapis.com/v1/token"

    @staticmethod
    def _get_client_version() -> str:
        """Get the installed obra package version.

        Returns:
            Version string from package metadata, or "0.0.0-dev" if not installed.
        """
        try:
            return version("obra")
        except PackageNotFoundError:
            return "0.0.0-dev"

    # TRY301: Helper methods to raise API errors outside try blocks
    @staticmethod
    def _raise_invalid_response(status_code: int, response_data: Any) -> None:
        """Raise APIError for invalid response format."""
        raise APIError(
            message="Expected JSON object in response",
            status_code=status_code,
            response_body=str(response_data),
        )

    @staticmethod
    def _raise_terms_not_accepted(error_json: dict[str, Any]) -> None:
        """Raise TermsNotAcceptedError for terms acceptance requirement."""
        raise TermsNotAcceptedError(
            message=error_json.get(
                "message",
                "You must accept the Obra Beta Software Agreement.",
            ),
            required_version=error_json.get("required_version", ""),
            terms_url=error_json.get("terms_url", "https://obra.dev/terms"),
            action=error_json.get("action", get_message("recovery.auth.terms")),
        )

    @staticmethod
    def _raise_validation_error(
        detailed_message: str,
        error_body: str,
        recovery: str = "",
        error_context: ErrorContext | None = None,
        error_code: str | None = None,
    ) -> None:
        """Raise APIError for validation failures (400)."""
        raise APIError(
            message=detailed_message,
            status_code=HTTPStatus.BAD_REQUEST.value,
            response_body=error_body,
            recovery=recovery,
            error_context=error_context,
            error_code=error_code,
        )

    @staticmethod
    def _raise_auth_expired(error_body: str) -> None:
        """Raise APIError for expired authentication."""
        raise APIError(
            message=f"Authentication token expired. {get_message('recovery.auth.login')}",
            status_code=HTTPStatus.UNAUTHORIZED.value,
            response_body=error_body,
        )

    @staticmethod
    def _raise_api_error(
        status_code: int,
        error_message: str,
        error_body: str,
        error_context: ErrorContext | None = None,
        error_code: str | None = None,
    ) -> None:
        """Raise generic APIError for non-retryable client errors."""
        raise APIError(
            message=f"API error {status_code}: {error_message}",
            status_code=status_code,
            response_body=error_body,
            error_context=error_context,
            error_code=error_code,
        )

    @staticmethod
    def _extract_server_context(
        error_json: dict[str, Any], response_headers: dict[str, str] | None = None
    ) -> ErrorContext | None:
        """Extract server context from error response.

        CHORE-SERVER-ERROR-CONTEXT-001: Parse server-provided investigation context.

        Args:
            error_json: Parsed error response JSON
            response_headers: Response headers from server

        Returns:
            ErrorContext populated from server data, or None if no context
        """
        server_ctx = error_json.get("context", {})
        if not server_ctx and not response_headers:
            return None

        # Extract from headers if available
        request_id = None
        server_trace_id = None
        if response_headers:
            request_id = response_headers.get("X-Obra-Request-Id")
            server_trace_id = response_headers.get("X-Obra-Server-Trace-Id")

        # Override with context body values if present
        if server_ctx:
            request_id = server_ctx.get("request_id", request_id)
            server_trace_id = server_ctx.get("server_trace_id", server_trace_id)

        # Build ErrorContext
        return ErrorContext(
            session_id=server_ctx.get("session_id"),
            request_id=request_id,
            server_trace_id=server_trace_id,
            phase=server_ctx.get("session_phase"),
            error_classification=server_ctx.get("error_classification"),
            recovery_suggestion=server_ctx.get("recovery_suggestion"),
            recent_activity=server_ctx.get("recent_activity"),
        )

    def _build_fallback_error_context(
        self,
        *,
        method: str,
        endpoint: str,
        request_id: str | None,
        payload: dict[str, Any] | None,
    ) -> ErrorContext | None:
        """Build minimal error context when server context is missing."""
        session_id = None
        project_id = None
        if isinstance(payload, dict):
            payload_session_id = payload.get("session_id")
            payload_project_id = payload.get("project_id")
            if isinstance(payload_session_id, str) and payload_session_id:
                session_id = payload_session_id
            if isinstance(payload_project_id, str) and payload_project_id:
                project_id = payload_project_id

        if not any([request_id, self.trace_id, session_id, project_id]):
            return None

        return ErrorContext(
            session_id=session_id,
            project_id=project_id,
            request_id=request_id,
            server_trace_id=self.trace_id,
            action=f"{method} /{endpoint}",
        )

    @staticmethod
    def _merge_error_context(
        primary: ErrorContext | None,
        fallback: ErrorContext | None,
    ) -> ErrorContext | None:
        """Merge fallback context into primary when fields are missing."""
        if primary is None:
            return fallback
        if fallback is None:
            return primary

        for field in (
            "session_id",
            "project_id",
            "request_id",
            "server_trace_id",
            "phase",
            "action",
            "log_path",
            "retry_count",
            "recovery_suggestion",
            "error_classification",
            "recent_activity",
        ):
            if getattr(primary, field) is None and getattr(fallback, field) is not None:
                setattr(primary, field, getattr(fallback, field))
        return primary

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        refresh_token: str | None = None,
        firebase_api_key: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
        enable_compression: bool = True,
        auto_refresh: bool = True,
        pool_retries: bool = True,
    ) -> None:
        """Initialize HTTPCore.

        Args:
            base_url: Base URL for Cloud Functions (e.g., https://us-central1-obra-205b0.cloudfunctions.net)
            auth_token: Firebase ID token for authentication
            refresh_token: Firebase refresh token for token renewal
            firebase_api_key: Firebase Web API key (required for token refresh)
            timeout: Request timeout in seconds (default: 30)
            enable_compression: Enable gzip compression for requests >5KB
            auto_refresh: Automatically refresh token when close to expiration
            pool_retries: Enable connection pool retries for transient connect errors

        Raises:
            ConfigurationError: If base_url is invalid
        """
        if not base_url or not base_url.startswith("http"):
            msg = f"Invalid base_url: {base_url}"
            raise ConfigurationError(msg)

        # Ensure base_url ends with / for proper urljoin() behavior
        self.base_url = base_url.rstrip("/") + "/"
        self.auth_token = auth_token
        self.refresh_token = refresh_token
        self.firebase_api_key = firebase_api_key or FIREBASE_API_KEY
        self.timeout = timeout
        self.enable_compression = enable_compression
        self.auto_refresh = auto_refresh

        # Token expiration tracking
        self.token_expires_at: datetime | None = None

        # Trace context for end-to-end observability
        self.trace_id: str | None = None
        self.trace_span_id: str | None = None

        self.session = requests.Session()

        # ISSUE-HYBRID-001: Configure connection pool with explicit retry for CLOSE_WAIT handling
        # Default HTTPAdapter has Retry(total=0) which means connection failures are not retried
        # at the pool level. This causes hangs when server closes connections (CLOSE_WAIT state).
        # By enabling connection-level retries, the pool will attempt to reconnect on failure.
        pool_cfg = get_api_connection_pool_config()
        if pool_retries:
            retry_strategy = Retry(
                total=int(pool_cfg["retry_total"]),
                connect=int(pool_cfg["retry_connect"]),
                read=0,  # Don't retry on read errors (handled by application-level retry)
                backoff_factor=pool_cfg["retry_backoff"],
                status_forcelist=None,  # Don't retry on HTTP status codes (handled by _request)
                allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            )
        else:
            retry_strategy = Retry(
                total=0,
                connect=0,
                read=0,
                backoff_factor=0,
                status_forcelist=None,
                allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=int(pool_cfg["connections"]),
            pool_maxsize=int(pool_cfg["maxsize"]),
        )
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        # Get client version for headers
        client_version = self._get_client_version()

        # Set default headers
        self.session.headers.update(
            {
                "Content-Type": "application/json",
                "User-Agent": f"obra/{client_version}",
                "X-Obra-Client-Version": client_version,
            }
        )
        if auth_token:
            self.session.headers.update({"Authorization": f"Bearer {auth_token}"})

    def set_trace_context(self, trace_id: str, span_id: str | None = None) -> None:
        """Set trace context headers for end-to-end observability.

        Args:
            trace_id: Trace ID for correlating client/server events
            span_id: Optional span ID (if not provided, generated per request)
        """
        self.trace_id = trace_id
        self.trace_span_id = span_id

    def _build_trace_header(self) -> str | None:
        """Build X-Cloud-Trace-Context header value.

        Returns:
            Header value if trace_id is set, otherwise None
        """
        if not self.trace_id:
            return None
        span_id = self.trace_span_id or str(secrets.randbits(63))
        return f"{self.trace_id}/{span_id};o=1"

    def refresh_auth_token(self) -> bool:
        """Refresh authentication token using Firebase refresh token.

        Uses Firebase Auth REST API to exchange refresh token for new ID token.

        Returns:
            True if refresh succeeded, False otherwise

        Note:
            This is called automatically if auto_refresh is enabled and
            token is close to expiration.
        """
        if not self.refresh_token or not self.firebase_api_key:
            return False

        try:
            # Firebase Token Refresh API endpoint
            url = f"https://securetoken.googleapis.com/v1/token?key={self.firebase_api_key}"

            # Use requests.post directly instead of self.session.post to avoid
            # the session's Content-Type: application/json header conflicting
            # with form-encoded data that Firebase expects
            response = requests.post(
                url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                },
                timeout=self.timeout,
            )

            if response.status_code == HTTPStatus.OK:
                data = response.json()
                new_id_token = data.get("id_token")
                new_refresh_token = data.get("refresh_token")

                if new_id_token:
                    self.set_auth_token(new_id_token)
                    if new_refresh_token:
                        self.refresh_token = new_refresh_token

                    # Firebase ID tokens expire in 1 hour
                    self.token_expires_at = datetime.now(UTC) + timedelta(hours=1)

                    # Save updated tokens to config
                    self._save_token_to_config(
                        new_id_token, self.token_expires_at, new_refresh_token
                    )
                    return True

            return False

        except Exception as e:
            logger.error(
                "Token refresh failed with exception: %s (type: %s)",
                str(e),
                type(e).__name__,
                exc_info=True,
            )
            return False

    def _check_token_expiration(self) -> None:
        """Check if token needs refresh and refresh if necessary.

        Called before authenticated requests if auto_refresh is enabled.
        """
        if not self.auto_refresh or not self.refresh_token:
            return

        if not self.token_expires_at:
            return

        # Check if token is close to expiration
        time_until_expiry = self.token_expires_at - datetime.now(UTC)

        if time_until_expiry < self.TOKEN_REFRESH_THRESHOLD:
            # Token is close to expiration, refresh it
            try:
                self.refresh_auth_token()
            except Exception:
                # Refresh failed, continue with existing token
                pass

    def _save_token_to_config(
        self,
        token: str,
        expires_at: datetime | None = None,
        refresh_token: str | None = None,
    ) -> None:
        """Save auth token to auth state file for persistence.

        Args:
            token: Firebase ID token
            expires_at: Token expiration datetime
            refresh_token: Firebase refresh token (optional)
        """
        auth_path = AUTH_STATE_PATH
        if not auth_path.exists():
            auth_path.parent.mkdir(parents=True, exist_ok=True)
            auth_path.write_text("{}\n", encoding="utf-8")
            if platform.system() != "Windows":
                auth_path.chmod(0o600)

        try:
            # Load existing auth state
            with auth_path.open(encoding="utf-8") as f:
                state = yaml.safe_load(f) or {}

            # Update token fields
            state["auth_token"] = token

            if expires_at:
                state["token_expires_at"] = expires_at.isoformat()

            if refresh_token:
                state["refresh_token"] = refresh_token

            # Save updated auth state
            with auth_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(state, f, default_flow_style=False, sort_keys=False)

        except Exception as e:
            # Failed to save token, but continue (token is still in memory)
            logger.error(
                "Failed to save auth token to auth state file at %s: %s (type: %s)",
                auth_path,
                str(e),
                type(e).__name__,
                exc_info=True,
            )
            return  # Exit early on I/O errors

        # Validate token save succeeded (after successful write)
        # TRY301: Validation checks outside try block, only wrap file I/O
        if not auth_path.exists():
            msg = f"Token save validation failed: Auth state file does not exist after write at {auth_path}"
            raise ConfigurationError(msg)

        # Verify token was actually written by reading back the file
        try:
            with auth_path.open(encoding="utf-8") as f:
                saved_state = yaml.safe_load(f)
        except Exception as e:
            # Validation itself failed (e.g., can't read file after writing)
            msg = f"Token save validation failed: Unable to verify token was saved to {auth_path}: {e}"
            raise ConfigurationError(msg) from e

        # Check token match outside try block (TRY301)
        if not saved_state or saved_state.get("auth_token") != token:
            msg = f"Token save validation failed: Token mismatch after write to {auth_path}"
            raise ConfigurationError(msg)

        if platform.system() != "Windows":
            try:
                auth_path.chmod(0o600)
            except OSError as e:
                msg = f"Token save validation failed: Unable to chmod auth state file at {auth_path}: {e}"
                raise ConfigurationError(msg) from e

    def set_auth_token(self, token: str) -> None:
        """Update authentication token.

        Args:
            token: New Firebase custom token
        """
        self.auth_token = token
        self.session.headers.update({"Authorization": f"Bearer {token}"})

    def _handle_400_error(
        self,
        response: requests.Response,
        error_json: dict[str, Any],
        error_body: str,
        error_message: str,
        method: str,
        endpoint: str,
        request_id: str | None,
        payload: dict[str, Any] | None,
    ) -> NoReturn:
        """Handle 400 Bad Request errors with detailed validation information.

        Extracts validation details, server context, and builds a rich error
        message before raising APIError.

        Args:
            response: The HTTP response object
            error_json: Parsed error response JSON (may be empty dict)
            error_body: Raw response body text
            error_message: Pre-extracted error message string
            method: HTTP method used
            endpoint: API endpoint called
            request_id: Client-generated request correlation ID
            payload: Original request JSON payload

        Raises:
            APIError: Always raised with detailed validation context
        """
        # Extract detailed validation error information
        error_code = error_json.get("code", "validation_error")
        error_details = str(error_json.get("details", error_json.get("message", error_message)))

        error_ctx = self._extract_server_context(error_json, dict(response.headers))
        fallback_ctx = self._build_fallback_error_context(
            method=method,
            endpoint=endpoint,
            request_id=request_id,
            payload=payload,
        )
        error_ctx = self._merge_error_context(error_ctx, fallback_ctx)

        # Build detailed error message
        detailed_message = f"API validation error: {error_message}"

        # Add error code if available
        if error_code and error_code not in {"validation_error", "schema_mismatch"}:
            detailed_message = f"API error ({error_code}): {error_message}"
        elif error_code == "schema_mismatch":
            detailed_message = f"API schema mismatch: {error_message}"

        # Add additional details if present
        if error_details and error_details != error_message:
            detailed_message += f"\nDetails: {error_details}"

        # Add missing fields information if available
        if "missing_fields" in error_json:
            detailed_message += f"\nMissing required fields: {error_json['missing_fields']}"

        # Add invalid fields information if available
        if "invalid_fields" in error_json:
            detailed_message += f"\nInvalid fields: {error_json['invalid_fields']}"

        # Include endpoint for debugging
        detailed_message += f"\nEndpoint: POST /{endpoint}"

        client_version = self._get_client_version()
        detailed_message += f"\nClient version: {client_version}"

        server_trace_id = None
        if error_ctx and error_ctx.server_trace_id:
            server_trace_id = error_ctx.server_trace_id
        else:
            server_trace_id = response.headers.get("X-Obra-Server-Trace-Id")
        if server_trace_id:
            detailed_message += f"\nServer trace ID: {server_trace_id}"

        recovery = ""
        if error_code in {"schema_mismatch", "validation_error"}:
            from obra.install_guidance import recommended_upgrade_command

            recovery = f"Upgrade your Obra CLI and retry. {recommended_upgrade_command()}"

        if error_ctx and error_code in {"schema_mismatch", "validation_error"}:
            error_ctx.error_classification = "schema_mismatch"

        self._raise_validation_error(
            detailed_message,
            error_body,
            recovery=recovery,
            error_context=error_ctx,
            error_code=error_code,
        )

    def _handle_error_response(
        self,
        response: requests.Response,
        method: str,
        endpoint: str,
        request_id: str | None,
        payload: dict[str, Any] | None,
        skip_auth_check: bool,
        response_schema: type[BaseModel] | None,
    ) -> dict[str, Any] | APIError:
        """Handle non-success HTTP responses (4xx and 5xx).

        Parses the error body, then routes to the appropriate handler based on
        status code:
        - 400: Delegates to ``_handle_400_error`` (always raises)
        - 401: Attempts token refresh via ``self.refresh_auth_token()``; on success
          returns the retried response dict to the caller
        - 403 (terms_not_accepted): Raises via ``self._raise_terms_not_accepted()``
        - Other 4xx: Raises generic APIError
        - 5xx: Returns an APIError instance to signal retry (does not raise)

        Args:
            response: The HTTP response object
            method: HTTP method used
            endpoint: API endpoint called
            request_id: Client-generated request correlation ID
            payload: Original request JSON payload
            skip_auth_check: Whether auth checks are being skipped
            response_schema: Optional Pydantic model class for response validation

        Returns:
            dict: Successful response from retried 401 request (token was refreshed)
            APIError: For 5xx errors (signals retry to caller)

        Raises:
            APIError: For all 4xx errors (400, 401 when refresh fails, other 4xx)
            TermsNotAcceptedError: For 403 terms_not_accepted errors
        """
        # Parse error response body
        error_body = response.text
        error_json: dict[str, Any] = {}
        try:
            parsed_error = response.json()
            if isinstance(parsed_error, dict):
                error_json = parsed_error
                error_message = error_json.get("error", error_body)
                # Include server's exception message for 5xx errors
                # Server sends {"error": "Internal server error", "message": str(e)}
                server_detail = error_json.get("message", "")
                if server_detail and server_detail != error_message:
                    error_message = f"{error_message}: {server_detail}"
            else:
                error_message = error_body
        except Exception:
            error_message = error_body

        error_code = error_json.get("code")
        if not isinstance(error_code, str):
            error_code = None

        # Handle client errors (4xx) - don't retry, except 401 token refresh
        if HTTPStatus.BAD_REQUEST <= response.status_code < HTTPStatus.INTERNAL_SERVER_ERROR:
            # Check for specific terms_not_accepted error (403)
            if (
                response.status_code == HTTPStatus.FORBIDDEN
                and error_json.get("error") == "terms_not_accepted"
            ):
                self._raise_terms_not_accepted(error_json)

            # Enhanced 400 error messages with validation details
            if response.status_code == HTTPStatus.BAD_REQUEST:
                self._handle_400_error(
                    response=response,
                    error_json=error_json,
                    error_body=error_body,
                    error_message=error_message,
                    method=method,
                    endpoint=endpoint,
                    request_id=request_id,
                    payload=payload,
                )

            # Handle 401 Unauthorized - attempt token refresh and retry once
            if response.status_code == HTTPStatus.UNAUTHORIZED and not skip_auth_check:
                if self.refresh_token and self.firebase_api_key:
                    # Try to refresh the token
                    if self.refresh_auth_token():
                        # Token refreshed, retry the request
                        return self._request(
                            method=method,
                            endpoint=endpoint,
                            json=payload,
                            retry=False,
                            skip_auth_check=True,
                            response_schema=response_schema,
                        )

                # Refresh failed or not possible
                self._raise_auth_expired(error_body)

            # Extract server context for debugging (CHORE-SERVER-ERROR-CONTEXT-001)
            error_ctx = self._extract_server_context(error_json, dict(response.headers))
            fallback_ctx = self._build_fallback_error_context(
                method=method,
                endpoint=endpoint,
                request_id=request_id,
                payload=payload,
            )
            error_ctx = self._merge_error_context(error_ctx, fallback_ctx)
            self._raise_api_error(
                response.status_code,
                error_message,
                error_body,
                error_ctx,
                error_code=error_code,
            )

        # Retry server errors (5xx) - extract context for debugging
        error_ctx = self._extract_server_context(error_json, dict(response.headers))
        fallback_ctx = self._build_fallback_error_context(
            method=method,
            endpoint=endpoint,
            request_id=request_id,
            payload=payload,
        )
        error_ctx = self._merge_error_context(error_ctx, fallback_ctx)
        return APIError(
            message=f"API error {response.status_code}: {error_message}",
            status_code=response.status_code,
            response_body=error_body,
            error_context=error_ctx,
            error_code=error_code,
        )

    def _request(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        retry: bool = True,
        skip_auth_check: bool = False,
        response_schema: type[BaseModel] | None = None,
        request_id: str | None = None,
        client_request_start_ts: float | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with retry logic and optional response validation.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., "/orchestrate")
            json: JSON payload for POST/PUT
            retry: Enable retry logic (default: True)
            skip_auth_check: Skip token expiration check
            response_schema: Optional Pydantic model class for response validation
            timeout: Request timeout in seconds (default: use instance timeout)

        Returns:
            Response JSON as dictionary (validated against schema if provided)

        Raises:
            APIError: If request fails after retries or response validation fails
        """
        # Check token expiration and refresh if needed (unless skipped)
        if not skip_auth_check:
            self._check_token_expiration()

        url = urljoin(self.base_url, endpoint)

        # Determine retry attempts
        max_attempts = self.MAX_RETRIES if retry else 1

        last_error: Exception | None = None

        for attempt in range(max_attempts):
            try:
                headers: dict[str, str] = {}
                trace_header = self._build_trace_header()
                if trace_header:
                    headers["X-Cloud-Trace-Context"] = trace_header
                if request_id:
                    headers["X-Obra-Request-Id"] = request_id
                if client_request_start_ts is not None:
                    headers["X-Obra-Request-Start"] = str(int(client_request_start_ts * 1000))

                # ISSUE-HYBRID-001: Use timeout tuple (connect, read) for better control
                # Connect timeout: how long to wait for connection establishment
                # Read timeout: how long to wait for response data
                # Using tuples helps detect hung connections vs slow responses
                request_timeout = timeout if timeout is not None else self.timeout
                if isinstance(request_timeout, (int, float)):
                    # Convert single timeout to tuple: (connect, read)
                    # Connect timeout is shorter as connection should be fast
                    pool_cfg = get_api_connection_pool_config()
                    connect_timeout = min(pool_cfg["timeout_s"], request_timeout)
                    timeout_tuple = (connect_timeout, request_timeout)
                else:
                    timeout_tuple = request_timeout  # Already a tuple

                response = self.session.request(
                    method=method,
                    url=url,
                    json=json,
                    timeout=timeout_tuple,
                    headers=headers or None,
                )

                # Handle response - check for success (2xx)
                if response.ok:
                    if response.status_code == 204 or not response.content:
                        response_data = {}
                    else:
                        response_data = response.json()
                    if not isinstance(response_data, dict):
                        self._raise_invalid_response(response.status_code, response_data)

                    # Validate response against schema if provided
                    if response_schema is not None:
                        try:
                            validated = response_schema(**response_data)
                            # Return the validated data as a dictionary
                            return cast(dict[str, Any], validated.model_dump())
                        except ValidationError as e:
                            # Convert Pydantic validation error to APIError
                            error_details = "; ".join(
                                [
                                    f"{'.'.join(map(str, err['loc']))}: {err['msg']}"
                                    for err in e.errors()
                                ]
                            )
                            raise APIError(
                                message=f"Response validation failed: {error_details}",
                                status_code=response.status_code,
                                response_body=str(response_data),
                            ) from e

                    return response_data

                # Delegate error status codes to handler
                # Raises for 4xx; returns APIError for 5xx (signals retry);
                # returns dict for successful 401 token-refresh retry
                error_result = self._handle_error_response(
                    response=response,
                    method=method,
                    endpoint=endpoint,
                    request_id=request_id,
                    payload=json,
                    skip_auth_check=skip_auth_check,
                    response_schema=response_schema,
                )
                # 401 token refresh may return a successful dict result
                if isinstance(error_result, dict):
                    return error_result
                # 5xx returns APIError to signal retry
                if isinstance(error_result, APIError):
                    last_error = error_result

            except requests.exceptions.Timeout as e:
                last_error = APIError(
                    message=f"Request timed out after {self.timeout}s ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            except requests.exceptions.ConnectionError as e:
                last_error = APIError(
                    message=f"Connection error ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            except (APIError, TermsNotAcceptedError):
                # Re-raise API errors and terms errors
                raise

            except Exception as e:
                last_error = APIError(
                    message=f"Request failed ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            # Retry with exponential backoff
            if attempt < max_attempts - 1:
                retry_delays = get_api_retry_delays()
                delay = retry_delays[attempt] if attempt < len(retry_delays) else retry_delays[-1]
                time.sleep(delay)
            else:
                break

        # All retries exhausted
        if last_error:
            raise last_error

        msg = "Request failed with unknown error"
        raise APIError(msg)
