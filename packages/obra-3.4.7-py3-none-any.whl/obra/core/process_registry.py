"""Process lifecycle management for Obra LLM subprocesses.

This module provides centralized tracking and cleanup of subprocess PIDs spawned
by LLM CLI tools (Claude Code, Gemini CLI, OpenAI Codex). It ensures that when
Obra exits (normally, via signal, or crash), all spawned processes are properly
terminated.

Key Features:
    - Instance-scoped registry (not singleton) for clean testing
    - PID recycling protection via process start time verification
    - Signal handlers for SIGTERM/SIGINT graceful shutdown
    - atexit handler for normal exit cleanup
    - Linux prctl(PR_SET_PDEATHSIG) for SIGKILL orphan prevention
    - Configurable terminate timeout
    - Thread-safe with threading.Lock

Usage:
    >>> from obra.core.process_registry import ProcessRegistry
    >>> registry = ProcessRegistry(terminate_timeout=3.0)
    >>> registry.install_signal_handlers()
    >>> registry.register_atexit()
    >>>
    >>> # In subprocess_runner.py:
    >>> process = subprocess.Popen(...)
    >>> registry.register(process.pid, "claude-code")
    >>> # ... process runs ...
    >>> registry.unregister(process.pid)  # On normal completion

Related:
    - docs/design/briefs/PROCESS_LIFECYCLE_MANAGEMENT_BRIEF.md
    - ADR-043: Unified Monitoring Architecture
    - ADR-041: Subprocess I/O Best Practices
"""

from __future__ import annotations

import atexit
import contextlib
import json
import logging
import os
import signal
import sys
import threading
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import psutil

if TYPE_CHECKING:
    from types import FrameType

logger = logging.getLogger(__name__)

# DEPRECATED: Use get_process_registry_config() from obra.config.loaders
# Default timeout before escalating from SIGTERM to SIGKILL
from obra.config.loaders import get_process_registry_config
from obra.utils.obra_home import get_runtime_dir

_process_config = get_process_registry_config()
DEFAULT_TERMINATE_TIMEOUT = _process_config["terminate_timeout_s"]
PID_START_TIME_TOLERANCE_S = 1.0

# Linux prctl constants
PR_SET_PDEATHSIG = 1
_PID_FILE_LOCK = threading.RLock()
_GLOBAL_TRACKED_PROCESSES: dict[int, "TrackedProcess"] = {}


@dataclass
class TrackedProcess:
    """Metadata for a tracked subprocess.

    Attributes:
        pid: Process ID
        command: Command identifier (e.g., "claude-code", "codex-cli", "gemini-cli")
        start_time: Process creation time (for PID recycling protection)
        registered_at: When the process was registered with the registry
    """

    pid: int
    command: str
    start_time: float
    registered_at: float = field(default_factory=time.time)


class ProcessRegistry:
    """Instance-scoped registry for LLM subprocess lifecycle management.

    Tracks subprocess PIDs spawned by LLM CLI tools and ensures cleanup on exit.
    Each Obra session should create its own ProcessRegistry instance.

    Thread Safety:
        This class is thread-safe. All operations on the process dict are
        protected by a threading.Lock.

    Attributes:
        terminate_timeout: Seconds to wait after SIGTERM before SIGKILL
    """

    def __init__(self, terminate_timeout: float = DEFAULT_TERMINATE_TIMEOUT):
        """Initialize the process registry.

        Args:
            terminate_timeout: Seconds to wait after SIGTERM before SIGKILL.
                              Configurable via config.yaml:
                              orchestration.process_cleanup.terminate_timeout
        """
        self._processes: dict[int, TrackedProcess] = {}
        self._lock = threading.Lock()
        self._terminate_timeout = terminate_timeout
        self._signal_handlers_installed = False
        self._atexit_registered = False
        self._original_sigterm: Callable[[int, FrameType | None], Any] | int | None = None
        self._original_sigint: Callable[[int, FrameType | None], Any] | int | None = None

        logger.debug(f"ProcessRegistry initialized: terminate_timeout={terminate_timeout}s")

    @classmethod
    def _pid_file_path(cls) -> Path:
        return get_runtime_dir() / "active_pids.json"

    @classmethod
    def _write_pid_file_payload(cls, payload: dict[str, dict[str, Any]]) -> None:
        with _PID_FILE_LOCK:
            pid_file = cls._pid_file_path()
            try:
                pid_file.parent.mkdir(parents=True, exist_ok=True)
                if not payload:
                    pid_file.unlink(missing_ok=True)
                    return

                temp_path = pid_file.with_suffix(".tmp")
                temp_path.write_text(
                    json.dumps(payload, indent=2, sort_keys=True),
                    encoding="utf-8",
                )
                temp_path.replace(pid_file)
            except OSError:
                logger.warning("Failed to persist process registry PID file", exc_info=True)

    @classmethod
    def _persist_pid_file(cls) -> None:
        payload = {
            str(pid): {
                "command": tracked.command,
                "registered_at": datetime.fromtimestamp(
                    tracked.registered_at, tz=UTC
                ).isoformat(),
                "parent_pid": os.getpid(),
                "start_time": tracked.start_time,
            }
            for pid, tracked in sorted(_GLOBAL_TRACKED_PROCESSES.items())
        }
        cls._write_pid_file_payload(payload)

    @classmethod
    def _read_pid_file_payload(cls) -> dict[str, dict[str, Any]]:
        pid_file = cls._pid_file_path()
        try:
            raw_payload = json.loads(pid_file.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, json.JSONDecodeError):
            logger.warning("Failed to read process registry PID file", exc_info=True)
            return {}

        if not isinstance(raw_payload, dict):
            return {}

        return {
            str(pid): metadata
            for pid, metadata in raw_payload.items()
            if isinstance(metadata, dict)
        }

    @staticmethod
    def _normalize_start_time(value: object) -> float | None:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            with contextlib.suppress(ValueError):
                return float(value)
        return None

    @classmethod
    def pid_matches_start_time(
        cls,
        pid: int,
        expected_start_time: object,
        *,
        tolerance_s: float = PID_START_TIME_TOLERANCE_S,
    ) -> bool:
        """Return whether the live PID still matches the expected process start time."""
        normalized_start_time = cls._normalize_start_time(expected_start_time)
        if pid <= 0 or normalized_start_time is None:
            return False
        try:
            process = psutil.Process(pid)
            return abs(process.create_time() - normalized_start_time) <= tolerance_s
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.Error):
            return False

    @classmethod
    def prune_pid_ledger_entries(cls, entries: Iterable[Mapping[str, Any]]) -> int:
        """Remove persisted PID-ledger entries that still match the provided identity."""
        payload = cls._read_pid_file_payload()
        if not payload:
            return 0

        removed = 0
        with _PID_FILE_LOCK:
            for entry in entries:
                raw_pid = entry.get("pid")
                try:
                    pid = int(raw_pid)
                except (TypeError, ValueError):
                    continue

                key = str(pid)
                metadata = payload.get(key)
                if metadata is None:
                    continue

                expected_start_time = cls._normalize_start_time(entry.get("start_time"))
                stored_start_time = cls._normalize_start_time(metadata.get("start_time"))
                if expected_start_time != stored_start_time:
                    continue

                payload.pop(key, None)
                removed += 1

                current = _GLOBAL_TRACKED_PROCESSES.get(pid)
                if current is not None and current.start_time == expected_start_time:
                    _GLOBAL_TRACKED_PROCESSES.pop(pid, None)

        if removed:
            cls._write_pid_file_payload(payload)
        return removed

    @classmethod
    def find_orphaned_pids(cls) -> list[dict[str, Any]]:
        """Return persisted PID records whose parent process or child no longer exists."""
        raw_payload = cls._read_pid_file_payload()
        if not raw_payload:
            return []

        orphaned: list[dict[str, Any]] = []
        for raw_pid, metadata in raw_payload.items():
            try:
                pid = int(raw_pid)
            except (TypeError, ValueError):
                continue

            parent_pid = metadata.get("parent_pid")
            child_alive = psutil.pid_exists(pid)
            parent_alive = isinstance(parent_pid, int) and psutil.pid_exists(parent_pid)
            if child_alive and parent_alive:
                continue

            reason = "parent_exited" if child_alive and not parent_alive else "process_missing"
            orphaned.append(
                {
                    "pid": pid,
                    "command": str(metadata.get("command") or ""),
                    "registered_at": metadata.get("registered_at"),
                    "parent_pid": parent_pid,
                    "start_time": cls._normalize_start_time(metadata.get("start_time")),
                    "reason": reason,
                }
            )
        return orphaned

    @property
    def active_count(self) -> int:
        """Return count of currently tracked processes."""
        with self._lock:
            return len(self._processes)

    @property
    def tracked_pids(self) -> list[int]:
        """Return list of currently tracked PIDs."""
        with self._lock:
            return list(self._processes.keys())

    def register(self, pid: int, command: str) -> None:
        """Register a spawned subprocess for lifecycle tracking.

        Args:
            pid: Process ID of spawned subprocess
            command: Command identifier (e.g., "claude-code", "codex-cli")

        Note:
            Captures process start time for PID recycling protection.
            If the process no longer exists, registration is skipped.
        """
        try:
            proc = psutil.Process(pid)
            start_time = proc.create_time()
        except psutil.NoSuchProcess:
            logger.warning(f"Cannot register pid={pid}: process no longer exists")
            return

        with self._lock:
            tracked = TrackedProcess(
                pid=pid,
                command=command,
                start_time=start_time,
            )
            self._processes[pid] = tracked
        with _PID_FILE_LOCK:
            _GLOBAL_TRACKED_PROCESSES[pid] = tracked
        self._persist_pid_file()
        logger.debug(f"Registered {command} process: pid={pid}")

    def unregister(self, pid: int) -> None:
        """Remove a process from tracking after normal completion.

        Args:
            pid: Process ID to unregister

        Note:
            Safe to call even if pid was never registered or already unregistered.
        """
        with self._lock:
            info = self._processes.pop(pid, None)
        if info is not None:
            with _PID_FILE_LOCK:
                current = _GLOBAL_TRACKED_PROCESSES.get(pid)
                if current and current.start_time == info.start_time:
                    _GLOBAL_TRACKED_PROCESSES.pop(pid, None)
            self._persist_pid_file()
            logger.debug(f"Unregistered {info.command} process: pid={pid}")

    def is_registered(self, pid: int) -> bool:
        """Check if a PID is currently tracked.

        Args:
            pid: Process ID to check

        Returns:
            True if pid is registered, False otherwise
        """
        with self._lock:
            return pid in self._processes

    def cleanup_all(self) -> int:
        """Terminate all tracked processes.

        Terminates each tracked process tree (process + children).
        Uses SIGTERM first, then SIGKILL after terminate_timeout.

        Returns:
            Count of processes successfully terminated
        """
        with self._lock:
            if not self._processes:
                return 0
            # Copy to avoid modification during iteration
            processes_copy = dict(self._processes)

        logger.info(f"Cleaning up {len(processes_copy)} tracked LLM processes...")
        terminated = 0

        for pid, info in processes_copy.items():
            if self._safe_terminate(pid, info):
                terminated += 1

        with self._lock:
            self._processes.clear()
        with _PID_FILE_LOCK:
            for pid in processes_copy:
                _GLOBAL_TRACKED_PROCESSES.pop(pid, None)
        self._persist_pid_file()

        logger.info(f"Terminated {terminated} processes")
        return terminated

    def _safe_terminate(self, pid: int, info: TrackedProcess) -> bool:
        """Terminate a process tree with PID recycling protection.

        Args:
            pid: Process ID to terminate
            info: TrackedProcess metadata

        Returns:
            True if process was terminated, False if not found or recycled
        """
        try:
            proc = psutil.Process(pid)

            # PID recycling check: verify it's the same process we spawned
            # Allow 1 second tolerance for timing differences
            if abs(proc.create_time() - info.start_time) > PID_START_TIME_TOLERANCE_S:
                logger.warning(
                    f"PID {pid} was recycled (start_time mismatch), skipping termination. "
                    f"Original: {info.start_time}, Current: {proc.create_time()}"
                )
                return False

            # Get all children recursively before terminating
            children: list[psutil.Process] = []
            with contextlib.suppress(psutil.NoSuchProcess):
                children = proc.children(recursive=True)

            # Send SIGTERM to all (children first, then parent)
            all_procs = [*children, proc]
            for p in all_procs:
                with contextlib.suppress(psutil.NoSuchProcess):
                    p.terminate()

            # Wait for graceful termination
            _gone, alive = psutil.wait_procs(
                all_procs,
                timeout=self._terminate_timeout,
            )

            # SIGKILL any survivors
            for p in alive:
                with contextlib.suppress(psutil.NoSuchProcess):
                    logger.debug(f"Process {p.pid} did not terminate, sending SIGKILL")
                    p.kill()

        except psutil.NoSuchProcess:
            logger.debug(f"Process {pid} already terminated")
            return False
        except psutil.AccessDenied:
            logger.exception(f"Access denied terminating pid={pid}")
            return False
        except Exception:
            logger.exception(f"Error terminating pid={pid}")
            return False
        else:
            logger.info(
                f"Terminated {info.command} process tree: pid={pid}, "
                f"children={len(children)}, killed={len(alive)}"
            )
            return True

    def install_signal_handlers(self) -> None:
        """Install SIGTERM/SIGINT handlers for graceful shutdown.

        When a signal is received, cleanup_all() is called before
        re-raising the signal to allow normal exit behavior.

        Note:
            Safe to call multiple times; handlers are only installed once.
            On Windows, only SIGINT is installed (SIGTERM not supported).
        """
        if self._signal_handlers_installed:
            logger.debug("Signal handlers already installed, skipping")
            return
        if threading.current_thread() is not threading.main_thread():
            logger.debug("Skipping signal handler installation outside main thread")
            return

        def make_handler(
            signum: int,
            original_handler: Callable[[int, FrameType | None], Any] | int | None,
        ) -> Callable[[int, FrameType | None], Any]:
            """Create a signal handler that cleans up then chains to original."""

            def handler(sig: int, frame: FrameType | None) -> None:
                signal_name = str(sig)
                try:
                    signal_name = signal.Signals(sig).name
                except Exception:
                    pass
                should_emit_cli_warning = not (sig == signal.SIGINT and callable(original_handler))
                if should_emit_cli_warning:
                    try:
                        from obra.display import print_warning

                        print_warning(
                            f"Received {signal_name} (signal {sig}). Cleaning up and exiting..."
                        )
                    except Exception:
                        pass
                logger.info(f"Received signal {sig}, cleaning up LLM processes...")
                self.cleanup_all()

                # Chain to original handler or use default behavior
                if callable(original_handler):
                    original_handler(sig, frame)
                elif original_handler == signal.SIG_DFL:
                    # Re-raise with default handler
                    signal.signal(signum, signal.SIG_DFL)
                    signal.raise_signal(signum)
                elif original_handler == signal.SIG_IGN:
                    pass  # Ignore
                else:
                    # Default: exit
                    sys.exit(128 + signum)

            return handler

        # Install SIGINT handler (works on all platforms)
        self._original_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, make_handler(signal.SIGINT, self._original_sigint))

        # Install SIGTERM handler (Unix only)
        if hasattr(signal, "SIGTERM"):
            self._original_sigterm = signal.getsignal(signal.SIGTERM)
            signal.signal(signal.SIGTERM, make_handler(signal.SIGTERM, self._original_sigterm))

        self._signal_handlers_installed = True
        logger.debug("Signal handlers installed for graceful shutdown")

    def uninstall_signal_handlers(self) -> None:
        """Restore original signal handlers.

        Useful for testing or when ProcessRegistry is no longer needed.
        """
        if not self._signal_handlers_installed:
            return

        if self._original_sigint is not None:
            signal.signal(signal.SIGINT, self._original_sigint)

        if hasattr(signal, "SIGTERM") and self._original_sigterm is not None:
            signal.signal(signal.SIGTERM, self._original_sigterm)

        self._signal_handlers_installed = False
        logger.debug("Signal handlers uninstalled")

    def register_atexit(self) -> None:
        """Register atexit handler for cleanup on normal exit.

        Note:
            Safe to call multiple times; handler is only registered once.
            atexit handlers do NOT run on SIGKILL or crashes.
        """
        if self._atexit_registered:
            return

        atexit.register(self._atexit_handler)
        self._atexit_registered = True
        logger.debug("atexit handler registered")

    def _atexit_handler(self) -> None:
        """Cleanup handler called on normal Obra exit."""
        if self._processes:
            logger.info(f"atexit: cleaning up {len(self._processes)} orphaned LLM processes")
            self.cleanup_all()


def get_prctl_death_signal_fn() -> Callable[[], None] | None:
    """Get a preexec_fn that sets PR_SET_PDEATHSIG on Linux.

    Deprecated: Import from obra.execution.os_compat instead.
    This is a re-export wrapper to preserve existing import paths.
    """
    from obra.execution.os_compat import (
        get_prctl_death_signal_fn as _canonical,
    )

    return _canonical()


def create_process_registry_from_config(
    config: Any, enabled_default: bool = True
) -> ProcessRegistry | None:
    """Factory function to create ProcessRegistry from Obra config.

    Args:
        config: Obra Config object with get() method or dict-like access
        enabled_default: Default value if config key not found

    Returns:
        Configured ProcessRegistry instance, or None if disabled
    """
    # Handle dict first (dicts also have .get() but use different access pattern)
    if isinstance(config, dict):
        process_cleanup = config.get("orchestration", {}).get("process_cleanup", {})
        enabled = process_cleanup.get("enabled", enabled_default)
        terminate_timeout = process_cleanup.get("terminate_timeout", DEFAULT_TERMINATE_TIMEOUT)
    # Config object with dotted-path get() method
    elif hasattr(config, "get") and callable(config.get):
        enabled = config.get("orchestration.process_cleanup.enabled", enabled_default)
        terminate_timeout = config.get(
            "orchestration.process_cleanup.terminate_timeout",
            DEFAULT_TERMINATE_TIMEOUT,
        )
    else:
        enabled = enabled_default
        terminate_timeout = DEFAULT_TERMINATE_TIMEOUT

    if not enabled:
        logger.debug("Process cleanup disabled in config")
        return None

    return ProcessRegistry(terminate_timeout=terminate_timeout)
