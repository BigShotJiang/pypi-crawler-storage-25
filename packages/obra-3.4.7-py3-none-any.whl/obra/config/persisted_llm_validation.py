"""Persist-time validation for saved LLM provider/model configuration."""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from obra.model_registry import get_provider_names, validate_model

_PROVIDER_SENTINELS = frozenset({"", "default", "inherit", "per-role", "per-tier"})
_MODEL_SENTINELS = frozenset({"", "default", "inherit", "per-role", "per-tier"})
_MODEL_PROVIDER_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"^opus$", "anthropic"),
    (r"^sonnet$", "anthropic"),
    (r"^haiku$", "anthropic"),
    (r"^claude", "anthropic"),
    (r"^gpt", "openai"),
    (r"^o[134]", "openai"),
    (r"^codex", "openai"),
    (r"^gemini", "google"),
)


@dataclass(frozen=True, slots=True)
class PersistedLLMConfigConflict:
    """One invalid provider/model pair found in a persistable config view."""

    provider_path: str
    model_path: str
    provider: str
    model: str
    message: str

    def to_dict(self) -> dict[str, str]:
        """Serialize the conflict for API responses."""
        return {
            "provider_path": self.provider_path,
            "model_path": self.model_path,
            "provider": self.provider,
            "model": self.model,
            "message": self.message,
        }


class PersistedLLMConfigValidationError(ValueError):
    """Raised when a saved config contains impossible provider/model pairs."""

    def __init__(self, conflicts: list[PersistedLLMConfigConflict]) -> None:
        self.conflicts = tuple(conflicts)
        details = "\n".join(
            f"- {conflict.model_path}: {conflict.message}" for conflict in self.conflicts
        )
        super().__init__(f"Invalid saved LLM configuration:\n{details}")

    @property
    def invalid_paths(self) -> list[str]:
        """Return the concrete config paths that failed validation."""
        return [conflict.model_path for conflict in self.conflicts]


def merge_config_layers(*layers: Mapping[str, Any] | None) -> dict[str, Any]:
    """Build one effective config view from layered config dictionaries."""
    merged: dict[str, Any] = {}
    for layer in layers:
        if isinstance(layer, Mapping):
            _deep_merge(merged, layer)
    return merged


def validate_persistable_llm_config(config: Mapping[str, Any]) -> None:
    """Reject impossible explicit provider/model pairs before persistence."""
    conflicts = collect_persistable_llm_config_conflicts(config)
    if conflicts:
        raise PersistedLLMConfigValidationError(conflicts)


def collect_persistable_llm_config_conflicts(
    config: Mapping[str, Any],
) -> list[PersistedLLMConfigConflict]:
    """Collect invalid provider/model pairs from a persistable config view."""
    conflicts: list[PersistedLLMConfigConflict] = []
    _collect_conflicts(config, prefix="", conflicts=conflicts)
    return conflicts


def _collect_conflicts(
    node: Mapping[str, Any],
    *,
    prefix: str,
    conflicts: list[PersistedLLMConfigConflict],
) -> None:
    provider = _normalized_string(node.get("provider"))
    if provider and provider not in _PROVIDER_SENTINELS:
        provider_path = _join_path(prefix, "provider")
        model = _normalized_string(node.get("model"))
        if model and model not in _MODEL_SENTINELS:
            _append_conflict_if_needed(
                provider_path=provider_path,
                model_path=_join_path(prefix, "model"),
                provider=provider,
                model=model,
                conflicts=conflicts,
            )

        tiers = node.get("tiers")
        if isinstance(tiers, Mapping):
            for tier_name, tier_model in tiers.items():
                if isinstance(tier_model, Mapping):
                    model_value = _normalized_string(tier_model.get("model"))
                else:
                    model_value = _normalized_string(tier_model)
                if not model_value or model_value in _MODEL_SENTINELS:
                    continue
                _append_conflict_if_needed(
                    provider_path=provider_path,
                    model_path=_join_path(_join_path(prefix, "tiers"), str(tier_name)),
                    provider=provider,
                    model=model_value,
                    conflicts=conflicts,
                )

    for key, value in node.items():
        if isinstance(value, Mapping):
            _collect_conflicts(
                value,
                prefix=_join_path(prefix, str(key)),
                conflicts=conflicts,
            )


def _append_conflict_if_needed(
    *,
    provider_path: str,
    model_path: str,
    provider: str,
    model: str,
    conflicts: list[PersistedLLMConfigConflict],
) -> None:
    if provider not in get_provider_names():
        conflicts.append(
            PersistedLLMConfigConflict(
                provider_path=provider_path,
                model_path=model_path,
                provider=provider,
                model=model,
                message=(
                    f"provider '{provider}' is unknown; valid providers: "
                    f"{', '.join(sorted(get_provider_names()))}"
                ),
            )
        )
        return

    inferred_provider = _infer_provider_from_model(model)
    if inferred_provider and inferred_provider != provider:
        conflicts.append(
            PersistedLLMConfigConflict(
                provider_path=provider_path,
                model_path=model_path,
                provider=provider,
                model=model,
                message=(
                    f"model '{model}' belongs to provider '{inferred_provider}', "
                    f"not '{provider}'"
                ),
            )
        )
        return

    validation = validate_model(provider, model)
    if not validation.valid:
        conflicts.append(
            PersistedLLMConfigConflict(
                provider_path=provider_path,
                model_path=model_path,
                provider=provider,
                model=model,
                message=validation.error or f"model '{model}' is not valid for '{provider}'",
            )
        )


def _deep_merge(target: dict[str, Any], source: Mapping[str, Any]) -> None:
    for key, value in source.items():
        if isinstance(value, Mapping) and isinstance(target.get(key), dict):
            _deep_merge(target[key], value)
        elif isinstance(value, Mapping):
            nested: dict[str, Any] = {}
            _deep_merge(nested, value)
            target[key] = nested
        else:
            target[key] = value


def _join_path(prefix: str, segment: str) -> str:
    return f"{prefix}.{segment}" if prefix else segment


def _normalized_string(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().lower()


def _infer_provider_from_model(model: str) -> str | None:
    if not model or model in _MODEL_SENTINELS:
        return None

    for pattern, provider in _MODEL_PROVIDER_PATTERNS:
        if re.match(pattern, model):
            return provider
    return None


__all__ = [
    "PersistedLLMConfigConflict",
    "PersistedLLMConfigValidationError",
    "collect_persistable_llm_config_conflicts",
    "merge_config_layers",
    "validate_persistable_llm_config",
]
