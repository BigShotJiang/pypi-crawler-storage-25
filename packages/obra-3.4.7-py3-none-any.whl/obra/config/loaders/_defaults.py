"""Pure data constants for obra.config.loaders.

Contains ONLY constant/data declarations — no functions, no mutable state.
Mutable state (_config_validated, _DEFAULT_SCHEMA_CACHE, _config_cache,
_config_cache_lock) lives in _core.py.
"""

import os
from pathlib import Path
from typing import Any

from obra.constants import MAX_PROMPT_FILES

# Config layer paths
CONFIG_LAYER_DIR = Path.home() / ".obra" / "config-layers"
CONFIG_PATH = CONFIG_LAYER_DIR / "01-user.yaml"
LEGACY_CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"
PROJECT_LAYER_PREFIX = "02-project-"
SESSION_LAYER_PREFIX = "03-session-"
SESSION_CONFIG_ENV_VAR = "OBRA_SESSION_CONFIG"

# Auth state file (separate from config - not subject to schema validation)
AUTH_STATE_PATH = Path.home() / ".obra" / "auth.yaml"

# Default API URL (production)
# Can be overridden via OBRA_API_BASE_URL environment variable
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"

# Local Firebase emulator project id
# Can be overridden via OBRA_FIREBASE_EMULATOR_PROJECT_ID environment variable
LOCAL_EMULATOR_PROJECT_ID = os.environ.get("OBRA_FIREBASE_EMULATOR_PROJECT_ID", "demo-obra-local")

# Local emulator API URL
# Used when --local flag is passed to CLI commands
LOCAL_EMULATOR_API_URL = f"http://localhost:5001/{LOCAL_EMULATOR_PROJECT_ID}/us-central1"

# Default baseline timeout for individual LLM calls (60 minutes)
# Can be overridden via OBRA_LLM_CALL_TIMEOUT environment variable
DEFAULT_LLM_CALL_TIMEOUT = 3600

# Deprecated compatibility alias for the canonical individual LLM timeout.
# Prefer DEFAULT_LLM_CALL_TIMEOUT and orchestration.timeouts.llm_call_s.
# Can be overridden via OBRA_LLM_TIMEOUT environment variable
DEFAULT_LLM_TIMEOUT = DEFAULT_LLM_CALL_TIMEOUT

# Default agent execution timeout (90 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_AGENT_EXECUTION_TIMEOUT environment variable
DEFAULT_AGENT_EXECUTION_TIMEOUT = 5400

# Default review agent timeout (30 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_REVIEW_AGENT_TIMEOUT environment variable
DEFAULT_REVIEW_AGENT_TIMEOUT = 1800

# Default CLI runner timeout (120 minutes) - CHORE-LLM-SUBPROCESS-001
# Used for orchestration LLM calls (derive, examine, revise, planning)
# Longest timeout because orchestration is the critical path
# Can be overridden via OBRA_CLI_RUNNER_TIMEOUT environment variable
# Default maximum iterations for orchestration loop
# Can be overridden via 01-user.yaml max_iterations setting
DEFAULT_MAX_ITERATIONS = 100

# =============================================================================
# DEPRECATED CONSTANTS - Fallbacks only, prefer config values
# =============================================================================
# These constants are maintained for backward compatibility but should not be
# used in new code. All operational defaults should come from default_config.yaml
# via config getters in this module. See ADR-047 for rationale.
# =============================================================================

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default auto runner story timeout (1 hour) - CHORE-CONFIG-DEFAULTS-001-E3
# Can be overridden via OBRA_AUTO_STORY_TIMEOUT_S environment variable
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default cleanup retry sleep cap (0.5 seconds) - CHORE-CONFIG-DEFAULTS-001-E3
# Can be overridden via OBRA_CLEANUP_SLEEP_CAP_S environment variable
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent detection thresholds - CHORE-CONFIG-DEFAULTS-001-E3
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent template settings - CHORE-CONFIG-DEFAULTS-001-E3
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default file tracking settings - CHORE-CONFIG-DEFAULTS-001-E3
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default cache monitor settings - CHORE-CONFIG-DEFAULTS-001-E3
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default derivation preview settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES = 180
# NOTE: _DERIVATION_LOOKBACK_DEPRECATION_LOGGED is NOT here — it lives in
# obra.config.loaders._outliers._legacy.

# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intake settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default skip tracking settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default tooling discovery settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default process registry settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default execution quality settings - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Default intent thresholds - CHORE-CONFIG-DEFAULTS-001-E3 S2
# DEPRECATED: This constant is a fallback only. Primary value should come from config.
# Log viewer, CLI, auth & validation defaults - CHORE-CONFIG-DEFAULTS-001-E3 S3
# Gateway server defaults (FEAT-GATEWAY-001)
DEFAULT_GATEWAY_HOST = "127.0.0.1"
DEFAULT_GATEWAY_PORT = 18790
DEFAULT_GATEWAY_MAX_SESSIONS = 5
DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S = 300.0
DEFAULT_GATEWAY_ENABLE_CORS = False
DEFAULT_GATEWAY_CORS_ORIGINS = ["*"]
# =============================================================================
# END DEPRECATED CONSTANTS
# =============================================================================

# Workflow configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 6)
# Priority order dict
DEFAULT_PRIORITY_ORDER = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}

# Work type configuration (CHORE-CONFIG-DEFAULTS-001-E2 Story 6, R31 GAP FIX)
# Network timeout configuration (C17)
# Default timeout for general network operations (seconds)
DEFAULT_NETWORK_TIMEOUT = 30
# Default effective timeout for API-style single-call LLM operations.
# Explicit overrides can still use orchestration.timeouts.llm_request_s.
DEFAULT_LLM_API_TIMEOUT = DEFAULT_LLM_CALL_TIMEOUT
# Default stream idle timeout for streaming LLM output (seconds)
# Set to 0 via config/env only when a provider-specific flow truly needs it disabled.
DEFAULT_LLM_STREAM_IDLE_TIMEOUT = 300

# Version check configuration (FEAT-CLI-VERSION-NOTIFY-001)
# Enable/disable automatic version checking
DEFAULT_CHECK_FOR_UPDATES = True
# Cooldown period between version notifications (minutes)
DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES = 10
# Auto-update configuration (FEAT-CLI-AUTO-UPDATE-001)
# Enable/disable automatic pipx upgrade on startup when behind
DEFAULT_AUTO_UPDATE = True
# Cooldown period between auto-update checks (minutes)
# Max retries for pipx upgrade (caching often needs 2+ runs)
# Base delay between retries in seconds (doubles each retry: 2s, 4s)
# Timeout per pipx upgrade attempt in seconds
# Prompt file retention
DEFAULT_PROMPT_MAX_FILES = MAX_PROMPT_FILES

# Template edit retention (LLM JSON templates)
DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS = False
DEFAULT_TEMPLATE_RETAIN_ON_ERROR = True

# Retry configuration defaults (matches default_config.yaml retry section)
# Balanced defaults reduce duplicate pressure when provider CLIs already retry internally.
DEFAULT_RETRY_MAX_ATTEMPTS = 3
DEFAULT_RETRY_AUTH_MAX_ATTEMPTS = 3
DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS = 1
DEFAULT_RETRY_BASE_DELAY = 8.0
DEFAULT_RETRY_MAX_DELAY = 120.0
DEFAULT_RETRY_BACKOFF_MULTIPLIER = 2.0
DEFAULT_RETRY_JITTER = 0.2
DEFAULT_RETRY_PATTERNS = [
    "rate limit",
    "rate_limit",
    "too many requests",
    "timeout",
    "timed out",
    "connection",
    "network",
    "service unavailable",
    "temporarily unavailable",
    "try again",
    "stream disconnected",
    "stream disconnected before completion",
    "error occurred while processing your request",
    "retry your request",
]

# Handler configuration defaults (CHORE-CONFIG-DEFAULTS-001-E2)
# All LLM timeouts: 10 min minimum per Rule 22
# Derive handler defaults
# Fix handler defaults
# Story0 handler defaults
DEFAULT_STORY0_PORT_MAPPINGS = {
    "postgres": 5432,
    "redis": 6379,
    "mysql": 3306,
    "mongodb": 27017,
}
DEFAULT_STORY0_SERVICE_IMAGES = {
    "postgres": "postgres:15",
    "redis": "redis:7",
    "mysql": "mysql:8",
    "mongodb": "mongo:6",
}
DEFAULT_STORY0_CAPABILITY_CHECKS: dict[str, dict[str, Any]] = {
    "python_runtime": {
        "indicators": [
            "python interpreter",
            "python 3 interpreter",
            "python3 interpreter",
            "python runtime",
            "python3 runtime",
        ],
        "commands": [["python3", "--version"], ["python", "--version"]],
    },
    "display": {
        "indicators": ["gui", "display", "window", "screen", "graphical"],
        "platforms": {
            "linux": {"env_vars": ["DISPLAY", "WAYLAND_DISPLAY"]},
            "darwin": {"always_available": True},
            "win32": {"always_available": True},
        },
        "fallback": {"env_vars": ["DISPLAY"]},
    },
    "audio": {
        "indicators": ["audio", "sound", "speaker", "microphone"],
        "platforms": {
            "linux": {"env_vars": ["PULSE_SERVER", "ALSA_CARD"]},
            "darwin": {"always_available": True},
            "win32": {"always_available": True},
        },
        "fallback": {"env_vars": ["PULSE_SERVER"]},
    },
    "filesystem_write": {
        "indicators": ["write permission", "writable", "filesystem"],
        "always_available": True,
    },
}

# Execute handler defaults
DEFAULT_EXECUTE_ZERO_OUTPUT_RETRY_MAX = 1  # Retry once on zero-output (ISSUE-SAAS-046)

# Review handler defaults
# Escalate handler defaults
# Intent handler defaults
# Examine handler defaults
# Revise handler defaults
# Story0 handler defaults
# Clarification handler defaults
# Template edit pipeline defaults
# Tooling discovery defaults
# Derivation module defaults
# Monitoring module defaults (CHORE-CONFIG-DEFAULTS-001-E2 Story 5)
DEFAULT_HANG_CONFIDENCE = {
    "real_hang": 0.95,
    "io_blocking_with_file": 0.85,
    "io_blocking_without": 0.65,
    "slow_progress": 0.60,
    "external_blocking": 0.75,
    "unknown": 0.30,
}

# Deprecated config keys mapped to new paths (schema reorg)
CONFIG_PATH_ALIASES: dict[str, str] = {
    "logging": "advanced.logging",
    "debug": "advanced.debug",
    "audit": "advanced.audit",
    "metrics": "advanced.metrics",
}

# Deprecated/legacy fields that should trigger migration warnings
# Maps old field path to (new field path or None, additional context)
# The deprecation message is generated using the message library
DEPRECATED_FIELDS: dict[str, tuple[str | None, str]] = {
    "llm.type": (
        "llm.provider",
        "Example: llm.provider: anthropic (not llm.type: claude-cli)",
    ),
    "llm.cli_command": (
        None,  # No replacement - should be removed
        "CLI is now derived automatically from llm.provider. "
        "Remove llm.cli_command from your config.",
    ),
}

# Semantic config aliases for intuitive access (UX-CONFIG-001)
# These map user-friendly paths to the actual config structure.
# Unlike CONFIG_PATH_ALIASES, these are bidirectional and don't trigger deprecation warnings.
SEMANTIC_CONFIG_ALIASES: dict[str, str] = {
    # Agent shortcuts - map intuitive names to features.quality_automation.agents.*
    "agents.security": "features.quality_automation.agents.security_audit.enabled",
    "agents.security_audit": "features.quality_automation.agents.security_audit.enabled",
    "agents.doc_audit": "features.quality_automation.agents.doc_audit.enabled",
    "agents.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "agents.rca": "features.quality_automation.agents.rca_agent.enabled",
    "agents.code_review": "features.quality_automation.agents.code_review.enabled",
    "agents.test_generation": "features.quality_automation.agents.test_generation.enabled",
    "agents.test_execution": "features.quality_automation.agents.test_execution.enabled",
    "agents.sense_check": "features.quality_automation.agents.sense_check.enabled",
    "agents.code_verify": "features.quality_automation.agents.code_verify.enabled",
    # Shorter agent aliases (match config schema)
    "agents.test_gen": "features.quality_automation.agents.test_generation.enabled",
    "agents.test_exec": "features.quality_automation.agents.test_execution.enabled",
    # Review shortcuts - common user mental model
    "review.security": "features.quality_automation.agents.security_audit.enabled",
    "review.security.enabled": "features.quality_automation.agents.security_audit.enabled",
    "review.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "review.documentation.enabled": "features.quality_automation.agents.doc_audit.enabled",
    "review.code": "features.quality_automation.agents.code_review.enabled",
    # Orchestration review shortcuts (common user confusion)
    "orchestration.review.security": "features.quality_automation.agents.security_audit.enabled",
    "orchestration.review.security.enabled": "features.quality_automation.agents.security_audit.enabled",
    "orchestration.review.documentation": "features.quality_automation.agents.doc_audit.enabled",
    "orchestration.review.documentation.enabled": "features.quality_automation.agents.doc_audit.enabled",
    # LLM shortcuts
    "llm.orchestrator.model": "llm.model",
    "llm.orchestrator_model": "llm.model",
    # Quality automation shortcuts
    "quality_automation": "features.quality_automation",
    "quality_automation.enabled": "features.quality_automation.enabled",
}

AGENT_LLM_DEFAULTS: dict[str, str] = {
    "provider": "inherit",
    "model": "inherit",
    "model_tier": "inherit",
    "reasoning_level": "inherit",
}

# Auth keys to migrate from old config location
_AUTH_STATE_KEYS = frozenset(
    {
        "firebase_uid",
        "user_email",
        "user_id",
        "auth_token",
        "refresh_token",
        "auth_provider",
        "auth_timestamp",
        "display_name",
        "token_expires_at",
    }
)

# ---- Input Budget Preflight Config (FEAT-LLM-CONTEXT-BUDGET-001) ----

DEFAULT_INPUT_BUDGET_ON_EXCEED = "warn"

# LLM logging defaults (FEAT-LLM-LOG-VIEWER-001)
DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS: dict[str, int] = {
    "fast": 15000,
    "balanced": 30000,
    "quality": 60000,
}
DEFAULT_SLOW_LLM_CALL_THRESHOLD_FALLBACK_MS = 60000

# Default watchdog settings (ISSUE-HYBRID-003)
DEFAULT_WATCHDOG_ENABLED = True
DEFAULT_WATCHDOG_STALL_TIMEOUT_S = 1800  # 30 minutes

# Adaptive decomposition defaults (FEAT-ADAPTIVE-DECOMP-001)
DEFAULT_DECOMPOSITION_ENABLED = True
DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S = 1800
DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_RATIO = 0.8
DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_S = int(
    DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S * DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_RATIO
)
DEFAULT_DECOMPOSITION_EXECUTE_STREAM_IDLE_S = DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S
DEFAULT_DECOMPOSITION_FAILURE_THRESHOLD = 3
DEFAULT_DECOMPOSITION_MAX_ATTEMPTS = 2
DEFAULT_DECOMPOSITION_SUMMARY_MAX_CHARS = 2000
# Session runtime limits (FEAT-SESSION-GUARD-001)
# Interactive guard defaults (FEAT-INTERACTIVE-GUARD-001)
DEFAULT_INTERACTIVE_GUARD_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_PATTERNS = [
    r"(?i)\bpassword\b",
    r"(?i)enter passphrase",
    r"(?i)are you sure.*\?(\s*\[y/n\]|\s*\(y/n\))?",
    r"(?i)continue\?\s*(\[y/n\]|\(y/n\))?",
    r"(?i)press any key",
    r"(?i)enter .* to continue",
]
DEFAULT_INTERACTIVE_GUARD_RETRY_MAX = 1
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES = ["LLM_INTERACTIVE_BLOCKED"]

# Default intent token budget (120K tokens)
# Quality threshold defaults
# Standard threshold for user-provided plans (0.6 = 60%)
DEFAULT_QUALITY_THRESHOLD = 0.6
# Relaxed threshold for Obra-generated plans (0.4 = 40%)
DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD = 0.4
# Quality policy mode (FEAT-QUALITY-POLICY-MODE-001)
VALID_QUALITY_POLICY_MODES = {"auto", "fast", "medium", "high"}
DEFAULT_QUALITY_POLICY_MODE = "auto"

# Working Directory Enforcement default (defense-in-depth)

# Parallel review agent defaults (FEAT-PARALLEL-REVIEW-001)
DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT = False
DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD = 1
DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED = True
DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES = 2
DEFAULT_REVIEW_LOOP_EXIT_POLICY_UNVERIFIABLE_ACCEPT_AFTER_CYCLES = 1
DEFAULT_REVIEW_LOOP_EXIT_POLICY_SCORE_PLATEAU_MIN_REVIEW_CYCLES = 2
DEFAULT_REVIEW_LOOP_EXIT_POLICY_SCORE_PLATEAU_MAX_DELTA = 0.0
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET = True
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS = False
DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL = True
DEFAULT_REVIEW_ESCALATION_FIXER_ENABLED = False
DEFAULT_REVIEW_ESCALATION_FIXER_TIMEOUT_S = 600
DEFAULT_REVIEW_ESCALATION_FIXER_MAX_ATTEMPTS_PER_EPISODE = 1
DEFAULT_REVIEW_ESCALATION_FIXER_ALLOWED_ROUTES = [
    "amend_plan",
    "fix_code",
    "reclassify_review",
    "retry_stage",
    "escalate",
]
DEFAULT_REVIEW_ESCALATION_FIXER_ELIGIBLE_REASON_CODES = [
    "blocking_issues_unresolved",
    "convergence_stalled",
    "quality_threshold_not_met",
    "max_iterations",
    "revision_merge_rejected",
    "max_refinement_iterations",
    "pre_dispatch_invariant",
]
DEFAULT_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD = 0.5
DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD = 0.5
DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD = 0.3
DEFAULT_REFINEMENT_STRAGGLER_ALERT_THRESHOLD = 1.5
DEFAULT_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER = 3.0
DEFAULT_REFINEMENT_REGRESSION_MIN_DELTA = 3

# Fix batching defaults (FEAT-PARALLEL-REVIEW-001)
# Fix test-gap inference defaults (FEAT-REVIEW-FIX-TESTGAP-LLM-001)
# Verification defaults (CHORE-LANG-AGNOSTIC-VERIFY-001)
DEFAULT_VERIFICATION_DISCOVERY_ENABLED = True
# Review complexity thresholds (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_REVIEW_COMPLEXITY_SIMPLE = {
    "max_words": 20,
    "max_files": 2,
    "max_lines": 50,
}
DEFAULT_REVIEW_COMPLEXITY_MEDIUM = {
    "max_files": 5,
    "max_lines": 200,
}

# Review feedback scoring (CHORE-CONFIG-DEFAULTS-001-E2 Story 8)
DEFAULT_REVIEW_FLAG_WEIGHTS = {
    "incorrect": 0.3,
    "off_topic": 0.25,
    "incomplete": 0.2,
    "unclear": 0.15,
    "quality_issue": 0.1,
}
DEFAULT_REVIEW_RATING_ADJUSTMENTS = {
    1: -0.3,
    2: -0.15,
    3: 0.0,
    4: 0.1,
    5: 0.2,
}
DEFAULT_REVIEW_PASS_ADJUSTMENT = 0.1
DEFAULT_REVIEW_FAIL_ADJUSTMENT = -0.2
DEFAULT_REVIEW_FLAG_PENALTY_CAP = 0.5
DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE = 0.7
DEFAULT_REVIEW_REDERIVATION_THRESHOLD = 0.4
DEFAULT_REVIEW_PASS_RATING_THRESHOLD = 3

# Intent constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_INTENT_CHUNKING_CONFIG = {
    "size_tokens": 80000,
    "overlap_tokens": 2000,
    "warning_threshold": 0.8,
}
DEFAULT_INTENT_RATE_LIMIT_CONFIG = {
    "max_retries": 3,
    "backoff_delays_s": [2.0, 4.0, 8.0],
}
# Derivation constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG = {
    "failure_threshold": 3,
    "max_depth": 3,
}
DEFAULT_DERIVATION_BUDGET_CONFIG = {
    "decompose_threshold": 0.80,
    "warning_threshold": 0.60,
    "min_subtask_ratio": 0.10,
}
DEFAULT_DERIVATION_TASK_CONFIG = {
    "token_budget": 100000,
    "cost_budget_usd": 0.50,
}

# Hybrid polling constants (CHORE-CONFIG-DEFAULTS-001-E2 Story 7)
DEFAULT_HYBRID_POLLING_CONFIG = {
    "max_delay_s": 30.0,
    "backoff_multiplier": 2.0,
    "base_delay_s": 1.0,
}

# Display limits getter (CHORE-MAGIC-VALUES-002)

# Valid display limit names
_DISPLAY_LIMIT_NAMES = frozenset(
    [
        "title_max_chars",
        "description_max_chars",
        "note_max_chars",
        "summary_max_chars",
        "objective_preview_max_chars",
        "list_preview_max_items",
        "seconds_before_minutes",
    ]
)

# Valid spinner config keys
_SPINNER_CONFIG_KEYS = frozenset(
    [
        "enabled",
        "accent_enabled",
        "phrase_rotation_interval_s",
        "phrase_rotation_min_s",
        "phrase_rotation_max_s",
        "accent_highlight_color",
        "accent_highlight_width",
        "accent_highlight_gradient",
        "accent_sweep_target_s",
        "accent_step_min_ms",
        "accent_step_max_ms",
        "accent_pause_min_s",
        "accent_pause_max_s",
        "refresh_rate_hz",
    ]
)

_SPINNER_BOOL_KEYS = frozenset({"enabled", "accent_enabled", "accent_highlight_gradient"})
_SPINNER_INT_KEYS = frozenset(
    {"refresh_rate_hz", "accent_highlight_width", "accent_step_min_ms", "accent_step_max_ms"}
)
_SPINNER_STR_KEYS = frozenset({"accent_highlight_color"})

# Valid timeout categories (CHORE-MAGIC-VALUES-002)
_TIMEOUT_CATEGORIES = frozenset(
    [
        "display",
        "http",
        "ollama",
        "handler",
        "subprocess_runner",
    ]
)

# Valid orchestration limit names (CHORE-MAGIC-VALUES-002)
_LIMIT_NAMES = frozenset(
    [
        "max_retries_default",
        "max_retries_critical",
        "batch_size_default",
        "page_limit",
        "max_iterations",
        "max_fix_attempts",
    ]
)

# Valid hierarchy limit names (CHORE-MAGIC-VALUES-002)
_HIERARCHY_LIMIT_NAMES = frozenset(
    [
        "max_stories_per_epic",
        "max_tasks_per_story",
        "max_subtasks_per_task",
    ]
)

# Valid trigger points for pipeline stages
VALID_TRIGGERS = [
    "after_intent",
    "after_derivation",
    "before_step",
    "after_step",
    "after_implementation",
    "before_review",
    "before_scorecard",
]
