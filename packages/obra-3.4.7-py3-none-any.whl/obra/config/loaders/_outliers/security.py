"""Security configuration getters."""

from __future__ import annotations

import os

from obra.exceptions import ConfigurationError

from .. import _core
from ._helpers import _coerce_bool

__all__ = [
    "get_prompt_sanitizer_strict_mode",
]

_PROMPT_SANITIZER_STRICT_MODE_ENV = "OBRA_SECURITY_PROMPT_SANITIZER_STRICT_MODE"


def get_prompt_sanitizer_strict_mode() -> bool:
    """Return the prompt-sanitizer strict-mode flag via env -> config lookup."""
    raw_env = os.environ.get(_PROMPT_SANITIZER_STRICT_MODE_ENV)
    if raw_env is not None:
        return _coerce_bool(raw_env)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    security = config.get("security")
    if not isinstance(security, dict):
        raise ConfigurationError(
            "Missing configuration section: security.prompt_sanitizer.strict_mode"
        )

    sanitizer = security.get("prompt_sanitizer")
    if not isinstance(sanitizer, dict) or "strict_mode" not in sanitizer:
        raise ConfigurationError(
            "Missing configuration key: security.prompt_sanitizer.strict_mode"
        )

    return _coerce_bool(sanitizer["strict_mode"])
