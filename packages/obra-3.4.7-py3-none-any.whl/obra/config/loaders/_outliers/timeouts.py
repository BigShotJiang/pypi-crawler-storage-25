"""Timeout getter owners."""

from __future__ import annotations

import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults

# Rule D: declare locally, do NOT import from _defaults
_TIMEOUT_ALIAS_WARNINGS_LOGGED: set[str] = set()

__all__ = [
    "get_benchmark_timeout_s",
    "get_derive_llm_timeout",
    "get_enrichment_stage_timeout_s",
    "get_fix_llm_suggestion_timeout",
    "get_fix_llm_test_gap_timeout",
    "get_intent_alignment_timeout_s",
    "get_intent_gap_check_timeout_s",
    "get_llm_api_timeout",
    "get_llm_call_timeout",
    "get_llm_timeout",
    "get_story0_llm_schema_timeout",
    "get_timeout",
    "get_user_story_generation_timeout_s",
]


def _warn_timeout_alias(alias: str, replacement: str) -> None:
    """Log a deprecation warning for a timeout alias once per process."""
    import logging

    if alias in _TIMEOUT_ALIAS_WARNINGS_LOGGED:
        return
    _TIMEOUT_ALIAS_WARNINGS_LOGGED.add(alias)
    logging.getLogger(__name__).warning(
        "Config timeout alias %s is deprecated; use %s instead.",
        alias,
        replacement,
    )


def _get_nested_config_value(config: dict[str, Any], path: str) -> Any:
    """Return a dotted-path value from a nested config dict."""
    current: Any = config
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def _parse_timeout_value(
    raw_value: Any,
    *,
    source: str,
    minimum: int = 600,
    allow_zero: bool = False,
) -> int:
    """Validate and coerce a timeout value."""
    try:
        timeout_s = int(raw_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"{source} must be an integer") from exc

    if allow_zero and timeout_s == 0:
        return timeout_s
    if timeout_s < minimum:
        raise ConfigurationError(f"{source} must be >= {minimum}")
    return timeout_s


def _load_runtime_config() -> dict[str, Any]:
    """Load layered config with defaults for timeout resolution."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    return config


def _resolve_timeout_override(
    *,
    config_path: str | None = None,
    env_var: str | None = None,
    fallback_timeout_s: int,
    deprecated_config_paths: tuple[str, ...] = (),
    deprecated_env_vars: tuple[str, ...] = (),
) -> int:
    """Resolve a timeout override and fall back to the provided baseline."""
    if env_var is not None:
        env_value = os.environ.get(env_var)
        if env_value is not None:
            return _parse_timeout_value(env_value, source=env_var)

    for deprecated_env_var in deprecated_env_vars:
        env_value = os.environ.get(deprecated_env_var)
        if env_value is not None:
            _warn_timeout_alias(deprecated_env_var, env_var or config_path or "canonical timeout")
            return _parse_timeout_value(env_value, source=deprecated_env_var)

    config = _load_runtime_config()
    if config_path is not None:
        config_value = _get_nested_config_value(config, config_path)
        if config_value is not None:
            return _parse_timeout_value(config_value, source=config_path)

    for deprecated_config_path in deprecated_config_paths:
        config_value = _get_nested_config_value(config, deprecated_config_path)
        if config_value is not None:
            _warn_timeout_alias(deprecated_config_path, config_path or "canonical timeout")
            return _parse_timeout_value(config_value, source=deprecated_config_path)

    return fallback_timeout_s


def get_llm_call_timeout() -> int:
    """Get the canonical timeout baseline for individual LLM calls."""
    return _resolve_timeout_override(
        config_path="orchestration.timeouts.llm_call_s",
        env_var="OBRA_LLM_CALL_TIMEOUT",
        fallback_timeout_s=_defaults.DEFAULT_LLM_CALL_TIMEOUT,
        deprecated_config_paths=("llm.timeout", "llm_timeout"),
        deprecated_env_vars=("OBRA_LLM_TIMEOUT",),
    )


def get_benchmark_timeout_s() -> int:
    """Get benchmark task timeout with env override support."""
    return _resolve_timeout_override(
        config_path="benchmark.timeout_s",
        env_var="OBRA_BENCHMARK_TIMEOUT_S",
        fallback_timeout_s=7200,
    )


def get_llm_timeout() -> int:
    """Compatibility wrapper for the canonical individual LLM timeout."""
    return get_llm_call_timeout()


def get_llm_api_timeout() -> int:
    """Get timeout for API-style single-call LLM requests."""
    return _resolve_timeout_override(
        config_path="orchestration.timeouts.llm_request_s",
        env_var="OBRA_LLM_API_TIMEOUT",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_derive_llm_timeout() -> int:
    """Get derive handler timeout, inheriting from the LLM call baseline."""
    return _resolve_timeout_override(
        config_path="handlers.derive.llm_timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_fix_llm_suggestion_timeout() -> int:
    """Get fix suggestion timeout, inheriting from the LLM call baseline."""
    return _resolve_timeout_override(
        config_path="handlers.fix.llm_suggestion_timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_fix_llm_test_gap_timeout() -> int:
    """Get fix test-gap timeout, inheriting from the LLM call baseline."""
    return _resolve_timeout_override(
        config_path="handlers.fix.llm_test_gap_timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_story0_llm_schema_timeout() -> int:
    """Get story0 schema timeout, inheriting from the LLM call baseline."""
    return _resolve_timeout_override(
        config_path="handlers.story0.llm_schema_timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_user_story_generation_timeout_s() -> int:
    """Get user-story generation timeout, inheriting from the LLM call baseline."""
    return _resolve_timeout_override(
        config_path="intent.user_stories.timeout_s",
        env_var="OBRA_USER_STORY_GENERATION_TIMEOUT_S",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_intent_alignment_timeout_s() -> int:
    """Get planning intent-alignment timeout, inheriting from the baseline."""
    return _resolve_timeout_override(
        config_path="planning.intent_alignment.timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_intent_gap_check_timeout_s() -> int:
    """Get post-execution intent-gap timeout, inheriting from the baseline."""
    return _resolve_timeout_override(
        config_path="planning.intent_gap_check.timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_enrichment_stage_timeout_s(
    stage_name: str,
    stage_config: dict[str, Any] | None = None,
) -> int:
    """Get enrichment-stage timeout, allowing null to inherit from the baseline."""
    base_stage = stage_name.split("_pass_", maxsplit=1)[0]
    if stage_config is not None and stage_config.get("timeout_s") is not None:
        return _parse_timeout_value(
            stage_config["timeout_s"],
            source=f"planning.enrichment.stages.{base_stage}.timeout_s",
        )

    return _resolve_timeout_override(
        config_path=f"planning.enrichment.stages.{base_stage}.timeout_s",
        fallback_timeout_s=get_llm_call_timeout(),
    )


def get_timeout(category: str, name: str) -> float:
    """Get timeout value by category and name.

    Resolution order (Rule 22):
    1. OBRA_TIMEOUT_{CATEGORY}_{NAME} environment variable (uppercase)
    2. timeouts.{category}.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        category: One of 'display', 'http', 'ollama', 'handler', 'subprocess_runner'
        name: Timeout name within the category.

    Returns:
        The timeout value as a float

    Raises:
        ConfigurationError: If category or name is invalid
        ConfigurationError: If timeout is not found in config
    """
    # Valid timeout names per category (defined here to avoid adding to _defaults)
    _TIMEOUT_NAMES: dict[str, frozenset[str]] = {
        "display": frozenset(["status_update_interval_s"]),
        "http": frozenset(["request_s", "upload_s"]),
        "ollama": frozenset(["default_s", "status_s", "status_ready_s"]),
        "handler": frozenset(["thread_join_s", "subprocess_s", "socket_connect_s"]),
        "subprocess_runner": frozenset(["poll_interval_s", "process_wait_s", "error_cleanup_s"]),
    }

    if category not in _defaults._TIMEOUT_CATEGORIES:
        valid_cats = ", ".join(sorted(_defaults._TIMEOUT_CATEGORIES))
        msg = f"Invalid timeout category '{category}'. Valid categories: {valid_cats}"
        raise ConfigurationError(msg)

    valid_names = _TIMEOUT_NAMES.get(category, frozenset())
    if name not in valid_names:
        valid_names_str = ", ".join(sorted(valid_names))
        msg = (
            f"Invalid timeout name '{name}' for category '{category}'. "
            f"Valid names: {valid_names_str}"
        )
        raise ConfigurationError(msg)

    env_name = f"OBRA_TIMEOUT_{category.upper()}_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        timeouts_config = config["timeouts"]
        category_config = timeouts_config[category]
        return float(category_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Timeout '{category}.{name}' not found in config at timeouts.{category}.{name}"
        raise ConfigurationError(msg) from exc
