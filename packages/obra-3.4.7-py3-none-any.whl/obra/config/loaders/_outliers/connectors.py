"""Connector credential getter owners."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from obra.exceptions import ConfigurationError

from ._helpers import resolve_int_config
from .. import _core

__all__ = [
    "get_connector_credentials_key_path",
    "get_connector_credentials_refresh_margin_s",
    "get_connector_credentials_store_path",
    "get_google_drive_credential_name",
    "get_google_drive_oauth_lifecycle_config",
    "get_google_drive_oauth_config",
]


def _connector_credentials_section() -> dict:
    config, _, _ = _core.load_layered_config(include_defaults=True)
    connectors = config.get("connectors")
    if not isinstance(connectors, dict):
        raise ConfigurationError("connectors section not found in config")
    credentials = connectors.get("credentials")
    if not isinstance(credentials, dict):
        raise ConfigurationError("connectors.credentials section not found in config")
    return credentials


def _connector_google_drive_oauth_section() -> dict[str, Any]:
    config, _, _ = _core.load_layered_config(include_defaults=True)
    connectors = config.get("connectors")
    if not isinstance(connectors, dict):
        raise ConfigurationError("connectors section not found in config")
    google_drive = connectors.get("google_drive")
    if not isinstance(google_drive, dict):
        raise ConfigurationError("connectors.google_drive section not found in config")
    oauth = google_drive.get("oauth")
    if not isinstance(oauth, dict):
        raise ConfigurationError("connectors.google_drive.oauth section not found in config")
    return oauth


def get_connector_credentials_store_path() -> str:
    """Resolve the local connector credential store directory."""
    value = (
        _connector_credentials_section().get("store_path")
        or "~/.obra/credentials"
    )
    return str(Path(str(value)).expanduser())


def get_connector_credentials_key_path() -> str:
    """Resolve the local connector credential key path."""
    value = (
        _connector_credentials_section().get("key_path")
        or "~/.obra/.machine-key"
    )
    return str(Path(str(value)).expanduser())


def get_connector_credentials_refresh_margin_s() -> int:
    """Resolve the pre-expiry OAuth2 refresh margin."""
    return resolve_int_config(
        "OBRA_CONNECTORS_CREDENTIALS_REFRESH_MARGIN_S",
        "connectors.credentials.refresh_margin_s",
        default=300,
        min_val=0,
        include_defaults=True,
        label="Connector credential refresh margin",
    )


def get_google_drive_credential_name() -> str:
    """Resolve the configured Google Drive local credential name."""
    oauth = _connector_google_drive_oauth_section()
    credential_name = str(oauth.get("credential_name") or "").strip()
    if not credential_name:
        raise ConfigurationError("connectors.google_drive.oauth.credential_name is required")
    return credential_name


def get_google_drive_oauth_lifecycle_config() -> dict[str, Any]:
    """Resolve Google Drive OAuth lifecycle settings without requiring secrets."""
    oauth = _connector_google_drive_oauth_section()

    scopes = oauth.get("scopes")
    if not isinstance(scopes, list) or not scopes:
        raise ConfigurationError("connectors.google_drive.oauth.scopes must be a non-empty list")

    authorize_url = str(oauth.get("authorize_url") or "").strip()
    token_url = str(oauth.get("token_url") or "").strip()
    revoke_url = str(oauth.get("revoke_url") or "").strip()
    credential_name = get_google_drive_credential_name()
    if not authorize_url or not token_url or not revoke_url:
        raise ConfigurationError(
            "connectors.google_drive.oauth authorize_url, token_url, revoke_url, and "
            "credential_name are required"
        )

    return {
        "client_id": os.getenv("OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_ID", str(oauth.get("client_id") or "")).strip(),
        "client_secret": os.getenv(
            "OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_SECRET",
            str(oauth.get("client_secret") or ""),
        ).strip(),
        "scopes": [str(scope) for scope in scopes if str(scope).strip()],
        "authorize_url": authorize_url,
        "token_url": token_url,
        "revoke_url": revoke_url,
        "credential_name": credential_name,
    }


def get_google_drive_oauth_config() -> dict[str, Any]:
    """Resolve Google Drive OAuth settings with env overrides for secrets."""
    config = get_google_drive_oauth_lifecycle_config()
    client_id = str(config["client_id"]).strip()
    client_secret = str(config["client_secret"]).strip()
    if not client_id:
        raise ValueError("Google Drive OAuth client_id is required")
    if not client_secret:
        raise ValueError("Google Drive OAuth client_secret is required")
    return {**config, "client_id": client_id, "client_secret": client_secret}
