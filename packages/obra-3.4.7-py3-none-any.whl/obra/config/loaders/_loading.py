"""Core layered config loading orchestration.

Implements the layered merge: default → user → project → session,
with caching, alias normalization, and automation-mode expansion.
"""

from __future__ import annotations

import logging
import os
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

from obra.config.persisted_llm_validation import (
    PersistedLLMConfigValidationError,
    merge_config_layers,
    validate_persistable_llm_config,
)
from obra.exceptions import ConfigurationError

from . import _defaults
from ._cache import _config_cache, _config_cache_lock, _invalidate_config_cache
from ._dict_utils import _set_nested_value
from ._paths import (
    _ensure_user_config_exists,
    _yaml_safe_load,
    get_config_path,
    get_project_layer_path,
    get_session_layer_override,
    get_session_layer_path,
)
from ._schema import _get_default_schema_cached
from ._transforms import (
    _apply_config_aliases,
    _normalize_agent_bool_configs,
    _normalize_pipeline_runner_catalog,
    _project_session_pipeline_compatibility,
)

logger = logging.getLogger(__name__)


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load configuration from ~/.obra/config-layers/01-user.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    path = config_path or _defaults.CONFIG_PATH
    if path == _defaults.CONFIG_PATH:
        _ensure_user_config_exists()
    if not path.exists():
        return {}

    try:
        content = path.read_text(encoding="utf-8")
        data = _yaml_safe_load(content) or {}
    except (OSError, yaml.YAMLError):
        return {}

    if not isinstance(data, dict):
        logger.warning(
            "Invalid user config at %s: expected mapping, got %s",
            path,
            type(data).__name__,
        )
        return {}

    return _apply_config_aliases(data)


def load_config_with_warnings(
    config_path: Path | None = None,
) -> tuple[dict[str, Any], list[str], bool]:
    """Load user configuration and return warnings instead of raising.

    Args:
        config_path: Optional override path for the config file.

    Returns:
        Tuple of (config dict, warnings list, file_exists).
    """
    path = config_path or _defaults.CONFIG_PATH
    warnings: list[str] = []

    if path == _defaults.CONFIG_PATH:
        _ensure_user_config_exists()

    if not path.exists():
        return {}, warnings, False

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    try:
        data = _yaml_safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid config at {path}: expected mapping, got {type(data).__name__}. "
            "Using defaults."
        )
        return {}, warnings, True

    return _apply_config_aliases(data, warnings), warnings, True


def _load_layer_file(
    path: Path,
    warnings: list[str],
    label: str,
) -> dict[str, Any]:
    if not path.exists():
        return {}

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read {label} at {path}: {exc}. Ignoring.")
        return {}

    try:
        data = _yaml_safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in {label} at {path}: {exc}. Ignoring.")
        return {}

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid {label} at {path}: expected mapping, got {type(data).__name__}. Ignoring."
        )
        return {}

    normalized = _apply_config_aliases(data, warnings)
    if label == "session config":
        return _project_session_pipeline_compatibility(
            normalized,
            warnings=warnings,
            path=path,
        )
    return normalized


def _record_origins(
    data: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            _record_origins(value, layer, origins, path)
        else:
            origins[path] = layer


def _merge_with_origins(
    base: dict[str, Any],
    override: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in override.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            base_value = base.get(key)
            if not isinstance(base_value, dict):
                base_value = {}
            base[key] = base_value
            _merge_with_origins(base_value, value, layer, origins, path)
        else:
            base[key] = value
            origins[path] = layer


def expand_automation_mode(
    config: dict[str, Any],
    origins: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Expand automation_mode into granular Story0/FIX defaults."""
    if config is None:
        return {}

    mode = config.get("automation_mode")
    if mode is None:
        mode = "auto_full"
        config["automation_mode"] = mode
        if origins is not None and "automation_mode" not in origins:
            origins["automation_mode"] = "derived"

    mode_defaults: dict[str, dict[str, Any]] = {
        "off": {
            "story0.auto_env_setup": False,
            "story0.install_policy": "manifest_only",
            "story0.allow_inferred_installs": False,
            "story0.auto_approve": False,
            "story0.install_target": "existing_env_only",
            "story0.env_creation": "never",
            "fix.verification.auto_install": False,
        },
        "guided": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": True,
            "story0.install_policy": "manifest_then_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": False,
            "story0.install_target": "project_local",
            "story0.env_creation": "when_missing",
            "fix.verification.auto_install": True,
        },
        "auto_safe": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": False,
            "story0.install_policy": "manifest_then_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": False,
            "story0.install_target": "project_local",
            "story0.env_creation": "when_missing",
            "fix.verification.auto_install": True,
        },
        "auto_full": {
            "story0.auto_env_setup": True,
            "story0.prompt_for_env_setup": False,
            "story0.install_policy": "manifest_or_inferred",
            "story0.allow_inferred_installs": True,
            "story0.auto_approve": True,
            "story0.install_target": "project_local",
            "story0.env_creation": "always",
            "fix.verification.auto_install": True,
        },
    }

    if mode not in mode_defaults:
        msg = f"Invalid automation_mode '{mode}'. Valid values: off, guided, auto_safe, auto_full."
        raise ConfigurationError(msg)

    # Legacy flags (story0.auto_approve, fix.verification.auto_install) predate
    # automation_mode. Preserve explicit values from non-default layers.
    derived = mode_defaults[mode]
    for path, value in derived.items():
        if origins is not None:
            origin = origins.get(path)
            if origin and origin != "default":
                logger.debug(
                    "Config key %s explicitly set in %s layer, not applying mode-derived default",
                    path,
                    origin,
                )
                continue
        _set_nested_value(config, path, value)
        if origins is not None and path not in origins:
            origins[path] = "derived"

    return config


def load_layered_config(
    project_id: str | None = None,
    session_path: Path | None = None,
    include_defaults: bool = False,
) -> tuple[dict[str, Any], dict[str, str], list[str]]:
    """Load layered config with deterministic precedence."""
    # Resolve both keys before cache lookup so the cache key is stable.
    resolved_project_id = project_id
    _project_id_warning: str | None = None
    if resolved_project_id is None:
        try:
            from obra.intent.storage import IntentStorage

            resolved_project_id = IntentStorage().get_project_id(Path.cwd())
        except Exception as exc:
            _project_id_warning = (
                f"Unable to resolve project ID for config layers: {exc}. Skipping project layer."
            )
            resolved_project_id = None

    resolved_session_path = session_path or get_session_layer_override()

    cache_key = (
        resolved_project_id,
        str(resolved_session_path) if resolved_session_path is not None else None,
        include_defaults,
    )

    with _config_cache_lock:
        if cache_key in _config_cache:
            return deepcopy(_config_cache[cache_key])

    # Cache miss — perform full disk I/O outside the lock.
    warnings: list[str] = []
    if _project_id_warning:
        warnings.append(_project_id_warning)

    user_config, user_warnings, _ = load_config_with_warnings()
    warnings.extend(user_warnings)

    project_config: dict[str, Any] = {}
    if resolved_project_id:
        project_path = get_project_layer_path(resolved_project_id)
        project_config = _load_layer_file(project_path, warnings, "project config")

    session_config: dict[str, Any] = {}
    if resolved_session_path:
        if not resolved_session_path.exists():
            warnings.append(f"Session config not found at {resolved_session_path}. Ignoring.")
        else:
            session_config = _load_layer_file(resolved_session_path, warnings, "session config")

    layers_empty = not user_config and not project_config and not session_config
    if _defaults.LEGACY_CONFIG_PATH.exists() and layers_empty:
        warnings.append(
            f"Legacy config detected at {_defaults.LEGACY_CONFIG_PATH}. "
            "Run 'obra setup' to regenerate config layers."
        )

    origins: dict[str, str] = {}
    merged: dict[str, Any] = {}
    if include_defaults:
        defaults = _get_default_schema_cached()
        merged = deepcopy(defaults)
        _record_origins(defaults, "default", origins)

    _merge_with_origins(merged, user_config, "user", origins)
    if project_config:
        _merge_with_origins(merged, project_config, "project", origins)
    if session_config:
        _merge_with_origins(merged, session_config, "session", origins)

    _normalize_agent_bool_configs(merged, origins, include_defaults)
    expand_automation_mode(merged, origins)
    _normalize_pipeline_runner_catalog(merged)

    result: tuple[dict[str, Any], dict[str, str], list[str]] = (merged, origins, warnings)
    with _config_cache_lock:
        _config_cache[cache_key] = result
    return deepcopy(result)


def load_project_layer(project_id: str) -> tuple[dict[str, Any], list[str], bool]:
    """Load a project-specific config layer."""
    warnings: list[str] = []
    path = get_project_layer_path(project_id)
    if not path.exists():
        return {}, warnings, False
    return _load_layer_file(path, warnings, "project config"), warnings, True


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/config-layers/01-user.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    default_config = _get_default_schema_cached()
    try:
        validate_persistable_llm_config(merge_config_layers(default_config, config))
    except PersistedLLMConfigValidationError as exc:
        raise ConfigurationError(
            str(exc),
            recovery=(
                "Choose a model that matches the configured provider, or reset the "
                "conflicting model/tier path to 'default'."
            ),
        ) from exc

    _defaults.CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with _defaults.CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)

    _invalidate_config_cache()


def enable_local_mode() -> None:
    """Enable local emulator mode for the current process.

    Sets the OBRA_API_BASE_URL environment variable to the local emulator URL.
    This affects all subsequent API calls in the current process.

    Called when --local flag is passed to CLI commands.

    Example:
        # In CLI command handler
        if local:
            enable_local_mode()
        # All subsequent APIClient calls will use the emulator
    """
    project_id = os.environ.get(
        "OBRA_FIREBASE_EMULATOR_PROJECT_ID",
        _defaults.LOCAL_EMULATOR_PROJECT_ID,
    )
    local_api_url = f"http://localhost:5001/{project_id.rstrip('/')}/us-central1"
    os.environ["OBRA_API_BASE_URL"] = local_api_url
    logger.info("Local mode enabled: API calls will use %s", local_api_url)


def get_isolated_mode() -> bool | None:
    """Get agent isolation mode from config.

    Returns:
        True: Enable isolation
        False: Disable isolation
        None: Use default (auto-detect from CLI/ENV/CI)

    Config location: ~/.obra/config-layers/01-user.yaml

    Example:
        # In 01-user.yaml:
        agent:
          isolated_mode: true
    """
    config, _, _ = load_layered_config()
    agent_config = config.get("agent", {})
    if isinstance(agent_config, dict):
        return agent_config.get("isolated_mode")
    return None


def set_isolated_mode(enabled: bool | None) -> None:
    """Set agent isolation mode in config.

    Args:
        enabled: True to enable, False to disable, None to clear

    Config location: ~/.obra/config-layers/01-user.yaml
    """
    config, _, _ = load_layered_config()

    if enabled is None:
        # Clear the setting
        if "agent" in config and isinstance(config["agent"], dict):
            config["agent"].pop("isolated_mode", None)
            if not config["agent"]:
                del config["agent"]
    else:
        if "agent" not in config:
            config["agent"] = {}
        config["agent"]["isolated_mode"] = enabled

    save_config(config)


def load_llm_section(config: dict[str, Any]) -> dict[str, Any]:
    """Extract and validate llm section from client config."""
    llm_config = config.get("llm")
    if llm_config is None:
        return {}
    if not isinstance(llm_config, dict):
        msg = "Invalid llm section in ~/.obra/config-layers/01-user.yaml."
        raise ConfigurationError(
            msg,
            "Set llm to a mapping. Example:\nllm:\n  provider: anthropic\n  model: sonnet",
        )
    return llm_config


def _empty_tools_config() -> dict[str, dict[str, str]]:
    """Return empty tools config with all categories."""
    return {
        "test": {"command": ""},
        "lint": {"command": ""},
        "format": {"command": ""},
        "typecheck": {"command": ""},
    }


def _convert_legacy_tools_config(tools: list) -> dict[str, dict[str, str]]:
    """Convert legacy list format to nested dict format."""
    result = _empty_tools_config()
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        category = str(tool.get("category", "")).strip()
        command = str(tool.get("command", "")).strip()
        if category in result:
            result[category]["command"] = command
    return result


def _normalize_tools_config(tools: dict) -> dict[str, dict[str, str]]:
    """Normalize nested dict format, ensuring all categories present."""
    result = _empty_tools_config()
    for category in result:
        if category in tools and isinstance(tools[category], dict):
            cmd = tools[category].get("command", "")
            result[category]["command"] = str(cmd).strip() if cmd else ""
    return result
