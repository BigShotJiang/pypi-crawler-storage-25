"""Settings catalog module for Obra.

Provides a structured, cacheable catalog of all configuration settings with
their metadata, section assignments, type information, and constraint data.

The catalog is the single source of truth consumed by the Settings UI
(Workflow Studio, TUI, CLI) to render setting editors without each surface
re-discovering schema details at runtime.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "CatalogEntry",
    "SectionDef",
    "build_catalog",
    "resolve_choices",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CatalogEntry:
    """A single setting in the catalog."""

    path: str
    label: str
    description: str
    value_type: str  # 'string' | 'integer' | 'boolean' | 'enum' | 'object'
    section: str  # section ID
    tier: str  # 'basic' | 'standard' | 'advanced'
    choices: tuple[str, ...] | None = None
    choices_resolver: str | None = None
    min_value: float | None = None
    max_value: float | None = None
    tags: tuple[str, ...] = ()
    stage: str | None = None
    default_value: Any = None
    readonly: bool = False
    cascade_targets: tuple[str, ...] = ()
    config_source: str = "local"
    sensitive: bool = False
    secret_edit_mode: str | None = None


@dataclass(frozen=True)
class SectionDef:
    """Navigation section definition."""

    id: str
    label: str
    description: str
    order: int


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------

SECTIONS: list[SectionDef] = [
    SectionDef(
        id="domain",
        label="Domain",
        description="Top-level context - Choose software, business, or installed domains.",
        order=0,
    ),
    SectionDef(
        id="personas",
        label="Personas",
        description="Behavior presets - Safety rails and autonomy level.",
        order=1,
    ),
    SectionDef(
        id="simple_llm",
        label="LLM Simple",
        description="Basic setup - Pick provider and model.",
        order=2,
    ),
    SectionDef(
        id="moderate_llm",
        label="LLM Moderate",
        description="Tier-based - Configure fast/medium/high models.",
        order=3,
    ),
    SectionDef(
        id="custom_llm",
        label="LLM Custom",
        description="Per-action - Fine-tune model for each pipeline action.",
        order=4,
    ),
    SectionDef(
        id="runtime_cli",
        label="Runtime & CLI",
        description="Execution runtime - Codex feature flags and headless CLI behavior.",
        order=5,
    ),
    SectionDef(
        id="pipeline",
        label="Pipeline Options",
        description="Behavior - Iterations, timeouts, thresholds. See inherited models.",
        order=6,
    ),
    SectionDef(
        id="agents",
        label="Specialized Agents",
        description="Specialized agents - Review, security, testing.",
        order=7,
    ),
    SectionDef(
        id="validation",
        label="Pre-Execution Setup",
        description="Environment preparation, tooling detection, and automation.",
        order=8,
    ),
    SectionDef(
        id="debug_advanced",
        label="Debug & Advanced",
        description="Prompts, logging, breakpoints, timeouts, and monitoring.",
        order=9,
    ),
    SectionDef(
        id="full_config",
        label="Full Config",
        description="Everything - Raw access to all settings.",
        order=10,
    ),
]

# ---------------------------------------------------------------------------
# Section prefix map  (longest-prefix match, sorted by length desc)
# ---------------------------------------------------------------------------

SECTION_PREFIX_MAP: dict[str, str] = {
    "features.quality_automation.agents": "agents",
    "features.development_debug": "debug_advanced",
    "orchestration.domain": "domain",
    "tooling_discovery": "validation",
    "observability.": "debug_advanced",
    "monitoring.": "debug_advanced",
    "derivation.": "pipeline",
    "execution.": "pipeline",
    "orchestration.": "pipeline",
    "advanced.": "debug_advanced",
    "pipeline.": "pipeline",
    "display.": "runtime_cli",
    "review.": "pipeline",
    "agents": "agents",
    "story0.": "validation",
    "llm.": "simple_llm",
    "cli.": "runtime_cli",
}

# Pre-sorted by key length descending for longest-prefix match.
_SORTED_PREFIXES: list[tuple[str, str]] = sorted(
    SECTION_PREFIX_MAP.items(),
    key=lambda item: len(item[0]),
    reverse=True,
)


def _resolve_section(path: str) -> str:
    """Resolve section ID for a config path via longest-prefix match."""
    for prefix, section_id in _SORTED_PREFIXES:
        if path == prefix or path.startswith(prefix) or path.startswith(prefix.rstrip(".")):
            # Exact match or starts-with (the prefix may or may not end with '.')
            if prefix.endswith("."):
                if path.startswith(prefix) or path == prefix.rstrip("."):
                    return section_id
            else:
                if path == prefix or path.startswith(prefix + "."):
                    return section_id
    return "full_config"


# ---------------------------------------------------------------------------
# Cascade targets
# ---------------------------------------------------------------------------

_CASCADE_TARGETS: dict[str, tuple[str, ...]] = {
    "llm.provider": (
        "llm.orchestrator.provider",
        "llm.implementation.provider",
    ),
    "llm.model": (
        "llm.orchestrator.model",
        "llm.implementation.model",
        "llm.orchestrator.tiers.fast",
        "llm.orchestrator.tiers.medium",
        "llm.orchestrator.tiers.high",
        "llm.implementation.tiers.fast",
        "llm.implementation.tiers.medium",
        "llm.implementation.tiers.high",
    ),
    "llm.orchestrator.model": (
        "llm.orchestrator.tiers.fast",
        "llm.orchestrator.tiers.medium",
        "llm.orchestrator.tiers.high",
    ),
    "llm.implementation.model": (
        "llm.implementation.tiers.fast",
        "llm.implementation.tiers.medium",
        "llm.implementation.tiers.high",
    ),
}

_SPECIAL_FIELD_METADATA: dict[str, dict[str, Any]] = {
    "connectors.google_drive.oauth.client_secret": {
        "sensitive": True,
        "secret_edit_mode": "explicit_ops",
    },
}


# ---------------------------------------------------------------------------
# Value type inference
# ---------------------------------------------------------------------------


def _infer_value_type(
    value: Any,
    choices: tuple[str, ...] | None,
) -> str:
    """Infer a catalog value_type string from a Python default value."""
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, str):
        return "enum" if choices else "string"
    if isinstance(value, dict):
        return "object"
    # None or other unknown types fall back to 'string'.
    return "string"


# ---------------------------------------------------------------------------
# Label derivation
# ---------------------------------------------------------------------------


def _label_from_path(path: str) -> str:
    """Derive a human-readable label from the last path segment."""
    last = path.rsplit(".", maxsplit=1)[-1]
    return last.replace("_", " ").title()


# ---------------------------------------------------------------------------
# Choices resolver helpers
# ---------------------------------------------------------------------------


def _is_llm_model_path(path: str) -> bool:
    """Return True if *path* should get the 'llm_models' resolver."""
    if path.endswith(".model"):
        return True
    # Tier paths only under the top-level llm section.
    if path.startswith("llm."):
        for suffix in (".tiers.fast", ".tiers.medium", ".tiers.high"):
            if path.endswith(suffix):
                return True
    return False


def _is_llm_provider_path(path: str) -> bool:
    """Return True if *path* should get the 'llm_providers' resolver."""
    # Any path ending with .provider that involves LLM config gets dynamic
    # provider choices — this includes llm.*.provider as well as
    # features.quality_automation.agents.*.llm.provider paths.
    return path.endswith(".provider")


# ---------------------------------------------------------------------------
# Choices resolvers registry
# ---------------------------------------------------------------------------


def _resolve_llm_models(path: str, full_config: dict | None) -> list[str] | None:
    from obra.config.explorer.descriptions import get_choices

    return get_choices(path, full_config)


def _resolve_llm_providers(path: str, full_config: dict | None) -> list[str] | None:
    from obra.config.explorer.descriptions import get_choices

    return get_choices(path, full_config)


CHOICES_RESOLVERS: dict[str, Any] = {
    "llm_models": _resolve_llm_models,
    "llm_providers": _resolve_llm_providers,
}


# ---------------------------------------------------------------------------
# build_catalog
# ---------------------------------------------------------------------------


def build_catalog() -> dict[str, Any]:
    """Build the settings catalog.

    Returns:
        Dict with 'sections' (list[SectionDef]) and 'fields' (dict[str, CatalogEntry]).
    """
    return _build_catalog_impl()


@lru_cache(maxsize=1)
def _build_catalog_impl() -> dict[str, Any]:
    """Cached implementation of build_catalog."""
    # Lazy imports to avoid circular dependencies.
    from obra.config.explorer.descriptions import (
        CONFIG_CHOICES,
        CONFIG_DESCRIPTIONS,
        get_choices as _get_choices,
        get_default,
        get_tier,
        is_locked,
    )
    from obra.config.explorer.metadata import get_tags, resolve_stage
    from obra.config.explorer.utils import (
        iter_schema_paths,
        load_default_config_schema,
    )
    from obra.config.loaders._descriptors import ConfigEntry as _ConfigEntry
    from obra.config.loaders._entries.constraints import CONSTRAINT_ENTRIES
    from obra.config.loaders._entries.domain import DOMAIN_ENTRIES
    from obra.config.loaders._entries.handlers import HANDLER_ENTRIES
    from obra.config.loaders._entries.infra import INFRA_ENTRIES
    from obra.config.loaders._entries.sections import SECTION_ENTRIES

    # ------------------------------------------------------------------
    # 1. Build an index of ConfigEntry descriptors keyed by config_path.
    # ------------------------------------------------------------------
    descriptor_index: dict[str, _ConfigEntry] = {}
    for entries_list in (
        DOMAIN_ENTRIES,
        HANDLER_ENTRIES,
        INFRA_ENTRIES,
        SECTION_ENTRIES,
        CONSTRAINT_ENTRIES,
    ):
        for entry in entries_list:
            if isinstance(entry, _ConfigEntry):
                descriptor_index[entry.config_path] = entry

    # ------------------------------------------------------------------
    # 2. Build a schema-value lookup from the default YAML.
    # ------------------------------------------------------------------
    default_schema = load_default_config_schema()
    schema_values: dict[str, Any] = {}
    if default_schema:
        for spath, svalue in iter_schema_paths(default_schema):
            schema_values[spath] = svalue

    # ------------------------------------------------------------------
    # 3. Iterate CONFIG_DESCRIPTIONS and build CatalogEntry objects.
    # ------------------------------------------------------------------
    fields: dict[str, CatalogEntry] = {}

    for path, desc_text in CONFIG_DESCRIPTIONS.items():
        tier = get_tier(path)
        readonly = is_locked(path)
        default_value = get_default(path)
        stage = resolve_stage(path)
        tags_list = get_tags(path)

        # Merge descriptor constraints (min_val, max_val, choices).
        min_value: float | None = None
        max_value: float | None = None
        choices: tuple[str, ...] | None = None

        descriptor = descriptor_index.get(path)
        if descriptor is not None:
            if descriptor.min_val is not None:
                min_value = float(descriptor.min_val)
            if descriptor.max_val is not None:
                max_value = float(descriptor.max_val)
            if descriptor.choices is not None:
                choices = tuple(str(c) for c in descriptor.choices)

        # Merge static choices from CONFIG_CHOICES (lower precedence than
        # descriptor choices).
        if choices is None:
            static = CONFIG_CHOICES.get(path)
            if static is not None:
                choices = tuple(str(c) for c in static)

        # Infer value_type from the default schema YAML value.
        schema_val = schema_values.get(path)
        value_type = _infer_value_type(schema_val, choices)

        # If we have static choices from the descriptor, override type to 'enum'.
        if choices and value_type == "string":
            value_type = "enum"

        # Resolve choices_resolver for dynamic LLM paths.
        choices_resolver: str | None = None
        if _is_llm_model_path(path):
            choices_resolver = "llm_models"
        elif _is_llm_provider_path(path):
            choices_resolver = "llm_providers"

        # If a dynamic resolver is set and no static choices, mark as 'enum'.
        if choices_resolver and value_type == "string":
            value_type = "enum"

        # Section assignment via longest-prefix match.
        section = _resolve_section(path)

        # Cascade targets.
        cascade_targets = _CASCADE_TARGETS.get(path, ())

        # Label from path.
        label = _label_from_path(path)

        entry = CatalogEntry(
            path=path,
            label=label,
            description=desc_text if isinstance(desc_text, str) else str(desc_text),
            value_type=value_type,
            section=section,
            tier=tier,
            choices=choices,
            choices_resolver=choices_resolver,
            min_value=min_value,
            max_value=max_value,
            tags=tuple(tags_list),
            stage=stage,
            default_value=default_value,
            readonly=readonly,
            cascade_targets=cascade_targets,
            sensitive=bool(_SPECIAL_FIELD_METADATA.get(path, {}).get("sensitive", False)),
            secret_edit_mode=_SPECIAL_FIELD_METADATA.get(path, {}).get("secret_edit_mode"),
        )
        fields[path] = entry

    return {
        "sections": list(SECTIONS),
        "fields": fields,
    }


# ---------------------------------------------------------------------------
# resolve_choices
# ---------------------------------------------------------------------------


def resolve_choices(
    entry: CatalogEntry | None,
    full_config: dict | None = None,
) -> list[str] | None:
    """Resolve the effective choice list for a catalog entry.

    Args:
        entry: A CatalogEntry, or None.
        full_config: Optional full runtime config dict used by dynamic resolvers
            (e.g. to determine the current provider when listing models).

    Returns:
        A list of valid choice strings, or None if the entry has no
        enumerated choices.
    """
    if entry is None:
        return None

    if entry.choices is not None:
        return list(entry.choices)

    if entry.choices_resolver is not None:
        resolver = CHOICES_RESOLVERS.get(entry.choices_resolver)
        if resolver is not None:
            return resolver(entry.path, full_config)

    return None
