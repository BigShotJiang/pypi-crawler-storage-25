"""Shared CLI discovery helpers for provider binaries."""

from __future__ import annotations

import os
import platform
import shutil
from pathlib import Path

_MACOS_FALLBACK_DIRS = (
    Path("/opt/homebrew/bin"),
    Path("/usr/local/bin"),
)


def resolve_cli_path(cli_name: str) -> str | None:
    """Resolve a provider CLI path from PATH or common macOS Homebrew prefixes."""
    resolved = shutil.which(cli_name)
    if resolved:
        return resolved

    if platform.system() != "Darwin":
        return None

    for base_dir in _MACOS_FALLBACK_DIRS:
        candidate = base_dir / cli_name
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None
