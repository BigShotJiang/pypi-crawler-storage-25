"""Shared LLM view-state projection for the config explorer."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from textual.containers import Container

from .widgets import (
    CustomLLMView,
    ModerateLLMView,
    PipelineOptionsView,
    RoleConfig,
    SimpleLLMView,
    SpecializedAgentsView,
)


class LLMViewState:
    """Builds and mounts shared LLM-oriented explorer views."""

    def __init__(self, app: Any) -> None:
        self._app = app

    def sanitize_model_value(self, model: str | None, provider: str) -> str:
        """Sanitize model values for widget compatibility."""
        from .llm_registry import get_models

        delegation_values = {"per-tier", "per-role", None, ""}
        if model in delegation_values:
            return "default"

        all_models = get_models()
        provider_models = all_models.get(provider, [])
        valid_model_ids = {model_info[0] for model_info in provider_models}
        if model not in valid_model_ids:
            return "default"
        return model

    def sanitize_reasoning_value(self, reasoning: str | None) -> str:
        """Sanitize reasoning-level values for Select widgets."""
        valid_levels = {"default", "off", "low", "medium", "high", "extra high", "maximum"}
        if isinstance(reasoning, str) and reasoning in valid_levels:
            return reasoning
        return "default"

    def extract_tier_model(self, tier_value: Any, provider: str, default: str = "default") -> str:
        """Extract the effective model from a tier entry."""
        if isinstance(tier_value, dict):
            model = tier_value.get("model", default)
            return self.sanitize_model_value(str(model), provider)
        if tier_value is None:
            return default
        return self.sanitize_model_value(str(tier_value), provider)

    def extract_tier_reasoning(self, tier_value: Any, fallback: str = "default") -> str:
        """Extract the effective reasoning level from a tier entry."""
        if isinstance(tier_value, dict):
            return self.sanitize_reasoning_value(str(tier_value.get("reasoning_level", fallback)))
        return self.sanitize_reasoning_value(fallback)

    def get_orchestrator_tier_config(self) -> tuple[str, dict[str, str]]:
        """Return the effective orchestrator tier projection."""
        return self._get_profile_tier_config("orchestrator")

    def get_implementation_tier_config(self) -> tuple[str, dict[str, str]]:
        """Return the effective implementation tier projection."""
        return self._get_profile_tier_config("implementation")

    def get_tier_reasoning_config(self, role: str) -> dict[str, str]:
        """Return effective per-tier reasoning for one role."""
        fallback = self.get_role_reasoning_level(role)
        reasoning_tiers = {"fast": fallback, "medium": fallback, "high": fallback}

        if not self._app._config_tree:
            return reasoning_tiers

        for tier in ("fast", "medium", "high"):
            tier_node = self._app._config_tree.get_node(f"llm.{role}.tiers.{tier}")
            if not tier_node:
                continue
            if tier_node.is_using_default:
                reasoning_tiers[tier] = fallback
            else:
                tier_value = self._resolve_node_value(tier_node)
                if tier_value is not None:
                    reasoning_tiers[tier] = self.extract_tier_reasoning(tier_value, fallback)

        return reasoning_tiers

    def get_role_reasoning_level(self, role: str) -> str:
        """Return the effective role-level reasoning selection."""
        if self._app._config_tree:
            node = self._app._config_tree.get_node(f"llm.{role}.reasoning_level")
            if node:
                if node.is_using_default:
                    return "default"
                if node.value:
                    return self.sanitize_reasoning_value(str(node.value))
        return "default"

    def get_role_configs(self) -> dict[str, dict[str, Any]]:
        """Return explicit Menu 3 role overrides."""
        from obra.config.explorer.widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        role_configs: dict[str, dict[str, Any]] = {}
        if self._app._config_tree:
            for action_id in DEFAULT_ACTION_CONFIG:
                node = self._app._config_tree.get_node(f"llm.roles.{action_id}")
                role_value = self._resolve_node_value(node)
                if isinstance(role_value, dict):
                    role_configs[action_id] = role_value
        return role_configs

    def get_fallback_state(self) -> dict[str, Any]:
        """Return projected llm.fallback config for the LLM views."""
        from obra.config.loaders import _core, get_fallback_config

        # The explorer should project against repository defaults plus the current
        # in-app config tree, not against whatever layered runtime config happens
        # to be active in the caller's shell.
        fallback_config = deepcopy(get_fallback_config(config=_core._load_default_schema()))
        if not self._app._config_tree:
            return fallback_config

        enabled_node = self._app._config_tree.get_node("llm.fallback.enabled")
        if enabled_node and enabled_node.value is not None:
            fallback_config["enabled"] = bool(enabled_node.value)
        for path in (
            "cooldown_s",
            "startup_failover_enabled",
            "transient_error_classes",
        ):
            node = self._app._config_tree.get_node(f"llm.fallback.{path}")
            if node and node.value is not None:
                fallback_config[path] = node.value

        recovery_config = fallback_config.get("recovery", {})
        if not isinstance(recovery_config, dict):
            recovery_config = {}
            fallback_config["recovery"] = recovery_config
        for path in (
            "enabled",
            "cooldown_s",
            "max_canary_attempts_per_session",
            "require_natural_boundary",
        ):
            node = self._app._config_tree.get_node(f"llm.fallback.recovery.{path}")
            if node and node.value is not None:
                recovery_config[path] = node.value

        for role in ("orchestrator", "implementation"):
            provider_node = self._app._config_tree.get_node(f"llm.fallback.{role}.provider")
            if provider_node and provider_node.value:
                fallback_config[role]["provider"] = str(provider_node.value)

            for tier in ("fast", "medium", "high"):
                tier_node = self._app._config_tree.get_node(f"llm.fallback.{role}.tiers.{tier}")
                if not tier_node or tier_node.is_using_default:
                    continue
                tier_value = self._resolve_node_value(tier_node)
                if tier_value is None:
                    continue
                fallback_config[role]["tiers"][tier] = {
                    "model": self.extract_tier_model(
                        tier_value,
                        str(fallback_config[role]["provider"]),
                    ),
                    "reasoning_level": self.extract_tier_reasoning(tier_value, "default"),
                }

        return fallback_config

    def mount_simple_llm_view(self) -> None:
        """Mount the Simple LLM view with current projected state."""
        from .debug import is_debug_enabled, log_action

        orch_provider = "anthropic"
        orch_model = "default"
        orch_reasoning = "default"
        impl_provider = "anthropic"
        impl_model = "default"
        impl_reasoning = "default"
        raw_orch_model = "default"
        raw_impl_model = "default"

        if self._app._config_tree:
            orch_prov_node = self._app._config_tree.get_node("llm.orchestrator.provider")
            if orch_prov_node and orch_prov_node.value:
                orch_provider = orch_prov_node.value

            orch_model_node = self._app._config_tree.get_node("llm.orchestrator.model")
            if orch_model_node:
                if orch_model_node.is_using_default:
                    orch_model = "default"
                elif orch_model_node.value:
                    orch_model = orch_model_node.value
                raw_orch_model = orch_model

            impl_prov_node = self._app._config_tree.get_node("llm.implementation.provider")
            if impl_prov_node and impl_prov_node.value:
                impl_provider = impl_prov_node.value

            impl_model_node = self._app._config_tree.get_node("llm.implementation.model")
            if impl_model_node:
                if impl_model_node.is_using_default:
                    impl_model = "default"
                elif impl_model_node.value:
                    impl_model = impl_model_node.value
                raw_impl_model = impl_model

            if orch_model == "per-tier":
                high_tier = self._app._config_tree.get_node("llm.orchestrator.tiers.high")
                if high_tier:
                    if high_tier.is_using_default:
                        orch_model = "default"
                    else:
                        tier_value = self._resolve_node_value(high_tier)
                        if tier_value:
                            orch_model = self.extract_tier_model(tier_value, orch_provider)

            if impl_model == "per-tier":
                high_tier = self._app._config_tree.get_node("llm.implementation.tiers.high")
                if high_tier:
                    if high_tier.is_using_default:
                        impl_model = "default"
                    else:
                        tier_value = self._resolve_node_value(high_tier)
                        if tier_value:
                            impl_model = self.extract_tier_model(tier_value, impl_provider)

            orch_reasoning_node = self._app._config_tree.get_node(
                "llm.orchestrator.reasoning_level"
            )
            if orch_reasoning_node:
                if orch_reasoning_node.is_using_default:
                    orch_reasoning = "default"
                elif orch_reasoning_node.value:
                    orch_reasoning = self.sanitize_reasoning_value(str(orch_reasoning_node.value))

            impl_reasoning_node = self._app._config_tree.get_node(
                "llm.implementation.reasoning_level"
            )
            if impl_reasoning_node:
                if impl_reasoning_node.is_using_default:
                    impl_reasoning = "default"
                elif impl_reasoning_node.value:
                    impl_reasoning = self.sanitize_reasoning_value(str(impl_reasoning_node.value))

        orch_model_sanitized = self.sanitize_model_value(orch_model, orch_provider)
        impl_model_sanitized = self.sanitize_model_value(impl_model, impl_provider)

        if is_debug_enabled():
            log_action(
                "_mount_simple_llm_view",
                f"RAW config: orch={orch_provider}/{raw_orch_model}, impl={impl_provider}/{raw_impl_model}",
            )
            log_action(
                "_mount_simple_llm_view",
                "SANITIZED: "
                f"orch={orch_provider}/{orch_model_sanitized}, "
                f"impl={impl_provider}/{impl_model_sanitized}",
            )

        _, preview_orch_tiers = self.get_orchestrator_tier_config()
        _, preview_impl_tiers = self.get_implementation_tier_config()
        preview_orch_reasoning_tiers = self.get_tier_reasoning_config("orchestrator")
        preview_impl_reasoning_tiers = self.get_tier_reasoning_config("implementation")
        role_configs = self.get_role_configs()
        fallback_state = self.get_fallback_state()

        view = SimpleLLMView(
            orchestrator_provider=orch_provider,
            orchestrator_model=orch_model_sanitized,
            orchestrator_reasoning=orch_reasoning,
            orchestrator_tiers=preview_orch_tiers,
            orchestrator_reasoning_tiers=preview_orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_model=impl_model_sanitized,
            implementation_reasoning=impl_reasoning,
            implementation_tiers=preview_impl_tiers,
            implementation_reasoning_tiers=preview_impl_reasoning_tiers,
            role_configs=role_configs,
            fallback_enabled=bool(fallback_state.get("enabled", False)),
            fallback_cooldown_s=int(fallback_state.get("cooldown_s", 300)),
            fallback_transient_error_classes=list(
                fallback_state.get("transient_error_classes", ["rate_limit", "transient"])
            ),
            fallback_startup_failover_enabled=bool(
                fallback_state.get("startup_failover_enabled", True)
            ),
            fallback_recovery_enabled=bool(
                fallback_state.get("recovery", {}).get("enabled", True)
            ),
            fallback_recovery_cooldown_s=int(
                fallback_state.get("recovery", {}).get("cooldown_s", 900)
            ),
            fallback_recovery_max_canary_attempts_per_session=int(
                fallback_state.get("recovery", {}).get("max_canary_attempts_per_session", 1)
            ),
            fallback_recovery_require_natural_boundary=bool(
                fallback_state.get("recovery", {}).get("require_natural_boundary", True)
            ),
            fallback_orchestrator_provider=str(
                fallback_state.get("orchestrator", {}).get("provider", "anthropic")
            ),
            fallback_orchestrator_model=str(
                self.extract_tier_model(
                    fallback_state.get("orchestrator", {}).get("tiers", {}).get("medium"),
                    str(fallback_state.get("orchestrator", {}).get("provider", "anthropic")),
                )
            ),
            fallback_orchestrator_reasoning=self.extract_tier_reasoning(
                fallback_state.get("orchestrator", {}).get("tiers", {}).get("medium"),
                "default",
            ),
            fallback_orchestrator_tiers={
                tier: self.extract_tier_model(
                    fallback_state.get("orchestrator", {}).get("tiers", {}).get(tier),
                    str(fallback_state.get("orchestrator", {}).get("provider", "anthropic")),
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_orchestrator_reasoning_tiers={
                tier: self.extract_tier_reasoning(
                    fallback_state.get("orchestrator", {}).get("tiers", {}).get(tier),
                    "default",
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_implementation_provider=str(
                fallback_state.get("implementation", {}).get("provider", "openai")
            ),
            fallback_implementation_model=str(
                self.extract_tier_model(
                    fallback_state.get("implementation", {}).get("tiers", {}).get("medium"),
                    str(fallback_state.get("implementation", {}).get("provider", "openai")),
                )
            ),
            fallback_implementation_reasoning=self.extract_tier_reasoning(
                fallback_state.get("implementation", {}).get("tiers", {}).get("medium"),
                "default",
            ),
            fallback_implementation_tiers={
                tier: self.extract_tier_model(
                    fallback_state.get("implementation", {}).get("tiers", {}).get(tier),
                    str(fallback_state.get("implementation", {}).get("provider", "openai")),
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_implementation_reasoning_tiers={
                tier: self.extract_tier_reasoning(
                    fallback_state.get("implementation", {}).get("tiers", {}).get(tier),
                    "default",
                )
                for tier in ("fast", "medium", "high")
            },
            classes="custom-view",
            id="simple-llm-view",
        )
        self._mount_view(view)

    def mount_moderate_llm_view(self) -> None:
        """Mount the Moderate LLM view with current projected state."""
        from obra.config.explorer.debug import is_debug_enabled, log_view_mount

        orch_provider, orch_tiers = self.get_orchestrator_tier_config()
        impl_provider, impl_tiers = self.get_implementation_tier_config()
        orch_reasoning_tiers = self.get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self.get_tier_reasoning_config("implementation")
        role_configs = self.get_role_configs()
        fallback_state = self.get_fallback_state()

        if is_debug_enabled():
            log_view_mount(
                "ModerateLLMView",
                {
                    "orch_provider": orch_provider,
                    "orch_tiers": orch_tiers,
                    "orch_reasoning_tiers": orch_reasoning_tiers,
                    "impl_provider": impl_provider,
                    "impl_tiers": impl_tiers,
                    "impl_reasoning_tiers": impl_reasoning_tiers,
                },
            )

        view = ModerateLLMView(
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers if orch_tiers else None,
            orchestrator_reasoning_tiers=orch_reasoning_tiers if orch_reasoning_tiers else None,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers if impl_tiers else None,
            implementation_reasoning_tiers=impl_reasoning_tiers if impl_reasoning_tiers else None,
            role_configs=role_configs,
            fallback_enabled=bool(fallback_state.get("enabled", False)),
            fallback_cooldown_s=int(fallback_state.get("cooldown_s", 300)),
            fallback_transient_error_classes=list(
                fallback_state.get("transient_error_classes", ["rate_limit", "transient"])
            ),
            fallback_startup_failover_enabled=bool(
                fallback_state.get("startup_failover_enabled", True)
            ),
            fallback_recovery_enabled=bool(
                fallback_state.get("recovery", {}).get("enabled", True)
            ),
            fallback_recovery_cooldown_s=int(
                fallback_state.get("recovery", {}).get("cooldown_s", 900)
            ),
            fallback_recovery_max_canary_attempts_per_session=int(
                fallback_state.get("recovery", {}).get("max_canary_attempts_per_session", 1)
            ),
            fallback_recovery_require_natural_boundary=bool(
                fallback_state.get("recovery", {}).get("require_natural_boundary", True)
            ),
            fallback_orchestrator_provider=str(
                fallback_state.get("orchestrator", {}).get("provider", "anthropic")
            ),
            fallback_orchestrator_tiers={
                tier: self.extract_tier_model(
                    fallback_state.get("orchestrator", {}).get("tiers", {}).get(tier),
                    str(fallback_state.get("orchestrator", {}).get("provider", "anthropic")),
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_orchestrator_reasoning_tiers={
                tier: self.extract_tier_reasoning(
                    fallback_state.get("orchestrator", {}).get("tiers", {}).get(tier),
                    "default",
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_implementation_provider=str(
                fallback_state.get("implementation", {}).get("provider", "openai")
            ),
            fallback_implementation_tiers={
                tier: self.extract_tier_model(
                    fallback_state.get("implementation", {}).get("tiers", {}).get(tier),
                    str(fallback_state.get("implementation", {}).get("provider", "openai")),
                )
                for tier in ("fast", "medium", "high")
            },
            fallback_implementation_reasoning_tiers={
                tier: self.extract_tier_reasoning(
                    fallback_state.get("implementation", {}).get("tiers", {}).get(tier),
                    "default",
                )
                for tier in ("fast", "medium", "high")
            },
            classes="custom-view",
            id="moderate-llm-view",
        )
        self._mount_view(view)

    def mount_custom_llm_view(self) -> None:
        """Mount the Custom LLM view with current projected state."""
        from .widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        orch_provider, orch_tiers = self.get_orchestrator_tier_config()
        impl_provider, impl_tiers = self.get_implementation_tier_config()
        orch_reasoning_tiers = self.get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self.get_tier_reasoning_config("implementation")
        fallback_state = self.get_fallback_state()

        role_configs: dict[str, RoleConfig] = {}
        for role_id, action_config in DEFAULT_ACTION_CONFIG.items():
            role_node = None
            if self._app._config_tree:
                role_node = self._app._config_tree.get_node(f"llm.roles.{role_id}")

            role_provider = None
            model = None
            reasoning_level = None
            profile = action_config["profile"]
            tier = action_config["tier"]

            role_value = self._resolve_node_value(role_node)
            if isinstance(role_value, str):
                profile = role_value
            elif isinstance(role_value, dict):
                profile = role_value.get("profile", profile)
                tier = role_value.get("tier", tier)
                role_provider = role_value.get("provider")
                model = role_value.get("model")
                reasoning_level = role_value.get("reasoning_level")

            role_configs[role_id] = RoleConfig(
                role_id=role_id,
                profile=profile,
                tier=tier,
                provider=role_provider,
                model=model,
                reasoning_level=reasoning_level,
            )

        view = CustomLLMView(
            current_configs=role_configs,
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers,
            orchestrator_reasoning_tiers=orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers,
            implementation_reasoning_tiers=impl_reasoning_tiers,
            fallback_enabled=bool(fallback_state.get("enabled", False)),
            classes="custom-view",
            id="custom-llm-view",
        )
        self._mount_view(view)

    def mount_pipeline_options_view(self) -> None:
        """Mount the Pipeline Options view with current projected state."""
        from obra.config.explorer.metadata import PHASE_SETTINGS

        def _node_to_value(node: Any) -> Any:
            if node.is_leaf:
                return node.value
            return {child.key: _node_to_value(child) for child in node.children}

        current_values: dict[str, Any] = {}
        if self._app._config_tree:
            for phase_settings in PHASE_SETTINGS.values():
                for setting_path in phase_settings:
                    node = self._app._config_tree.get_node(setting_path)
                    if node is None:
                        continue
                    if node.value is not None or node.children:
                        current_values[setting_path] = _node_to_value(node)

        orch_provider, orch_tiers = self.get_orchestrator_tier_config()
        impl_provider, impl_tiers = self.get_implementation_tier_config()
        orch_reasoning_tiers = self.get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self.get_tier_reasoning_config("implementation")
        role_configs = self.get_role_configs()

        view = PipelineOptionsView(
            current_values=current_values,
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers,
            orchestrator_reasoning_tiers=orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers,
            implementation_reasoning_tiers=impl_reasoning_tiers,
            role_configs=role_configs,
            classes="custom-view",
            id="pipeline-options-view",
        )
        self._mount_view(view)

    def mount_specialized_agents_view(self) -> None:
        """Mount the Specialized Agents view with current projected state."""
        from obra.config.explorer.widgets.specialized_agents_view import (
            AGENTS,
            LLM_FIELDS,
            SENSECHECK_FRAMEWORK_PATH,
            SENSECHECK_PIPELINE_STAGES,
        )

        current_values: dict[str, Any] = {}
        review_provider = "anthropic"
        review_thinking = "medium"
        review_tiers: dict[str, str] = {}
        review_tier = "high"

        if self._app._config_tree:
            review_role_node = self._app._config_tree.get_node("llm.roles.review")
            review_role_config = self._resolve_node_value(review_role_node)

            review_profile = "implementation"
            explicit_provider = None
            explicit_model = None
            explicit_reasoning = None

            if isinstance(review_role_config, dict):
                review_profile = review_role_config.get("profile", "implementation")
                review_tier = review_role_config.get("tier", "high")
                explicit_provider = review_role_config.get("provider")
                explicit_model = review_role_config.get("model")
                explicit_reasoning = review_role_config.get("reasoning_level")
            elif isinstance(review_role_config, str):
                review_profile = review_role_config

            if explicit_provider:
                review_provider = explicit_provider
            else:
                profile_prov_node = self._app._config_tree.get_node(
                    f"llm.{review_profile}.provider"
                )
                if profile_prov_node and profile_prov_node.value:
                    review_provider = profile_prov_node.value

            if explicit_reasoning:
                review_thinking = explicit_reasoning
            else:
                profile_thinking_node = self._app._config_tree.get_node(
                    f"llm.{review_profile}.reasoning_level"
                )
                if profile_thinking_node and profile_thinking_node.value:
                    review_thinking = profile_thinking_node.value

            if review_profile == "orchestrator":
                resolved_provider, resolved_tiers = self.get_orchestrator_tier_config()
            else:
                resolved_provider, resolved_tiers = self.get_implementation_tier_config()

            if not explicit_provider:
                review_provider = resolved_provider
            review_tiers = resolved_tiers

            if explicit_model:
                review_tiers[review_tier] = explicit_model

            for agent in AGENTS:
                node = self._app._config_tree.get_node(agent.enabled_path)
                if node and node.value is not None:
                    current_values[agent.enabled_path] = node.value

                if agent.llm_capable and agent.llm_config_path:
                    for field in LLM_FIELDS:
                        path = f"{agent.llm_config_path}.{field}"
                        node = self._app._config_tree.get_node(path)
                        if node and node.value is not None:
                            current_values[path] = node.value

            framework_node = self._app._config_tree.get_node(SENSECHECK_FRAMEWORK_PATH)
            if framework_node and framework_node.value is not None:
                current_values[SENSECHECK_FRAMEWORK_PATH] = framework_node.value

            for stage in SENSECHECK_PIPELINE_STAGES:
                node = self._app._config_tree.get_node(stage["config_path"])
                if node and node.value is not None:
                    current_values[stage["config_path"]] = node.value

        view = SpecializedAgentsView(
            current_values=current_values,
            implementation_provider=review_provider,
            implementation_tiers=review_tiers if review_tiers else None,
            implementation_reasoning_level=review_thinking,
            review_tier=review_tier,
            classes="custom-view",
            id="specialized-agents-view",
        )
        self._mount_view(view)

    def _get_profile_tier_config(self, profile: str) -> tuple[str, dict[str, str]]:
        """Return projected tier models for one LLM profile."""
        provider = "anthropic"
        tiers = {"fast": "default", "medium": "default", "high": "default"}

        if self._app._config_tree:
            prov_node = self._app._config_tree.get_node(f"llm.{profile}.provider")
            if prov_node and prov_node.value:
                provider = prov_node.value

            role_model_override = None
            role_model_node = self._app._config_tree.get_node(f"llm.{profile}.model")
            if role_model_node and role_model_node.value:
                sanitized_model = self.sanitize_model_value(str(role_model_node.value), provider)
                if sanitized_model != "default":
                    role_model_override = sanitized_model

            for tier in ("fast", "medium", "high"):
                tier_node = self._app._config_tree.get_node(f"llm.{profile}.tiers.{tier}")
                if tier_node:
                    if tier_node.is_using_default:
                        tiers[tier] = role_model_override or "default"
                    else:
                        tier_value = self._resolve_node_value(tier_node)
                        if tier_value:
                            tiers[tier] = self.extract_tier_model(tier_value, provider)

        return provider, tiers

    def _mount_view(self, view: Any) -> None:
        """Mount a custom view into the main content area."""
        main = self._app.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def _resolve_node_value(self, node: Any) -> Any:
        """Resolve a config node into its effective Python value.

        Object nodes in the explorer tree store their data in child nodes rather
        than on ``node.value``. Rehydrate them so shared views consume the same
        effective config regardless of whether the source was loaded from nested
        config or staged through pending changes.
        """
        if node is None:
            return None
        if node.is_leaf:
            return node.value
        if node.value is not None:
            return node.value

        hydrated: dict[str, Any] = {}
        for child in node.children:
            hydrated[child.key] = self._resolve_node_value(child)
        return hydrated
