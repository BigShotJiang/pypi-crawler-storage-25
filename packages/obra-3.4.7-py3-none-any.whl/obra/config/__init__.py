"""Configuration management for Obra.

Handles terms acceptance state and client configuration stored in
~/.obra/config-layers/01-user.yaml.

Example:
    from obra.config import load_config, save_config, get_api_base_url

    config = load_config()
    api_url = get_api_base_url()
"""

from datetime import UTC, datetime
from pathlib import Path

# =============================================================================
# Eager imports: Constants and core lightweight values
# =============================================================================

# Legal document versions - must match bundled documents
TERMS_VERSION = "2.1"
PRIVACY_VERSION = "1.3"

# Config file path
CONFIG_PATH = Path.home() / ".obra" / "config-layers" / "01-user.yaml"

# Auth state file (separate from config)
AUTH_STATE_PATH = Path.home() / ".obra" / "auth.yaml"

# Firebase configuration
# SEC-002: This is a PUBLIC Firebase Web API Key - intentionally included in client code.
#
# SECURITY NOTE: This is NOT a secret. Firebase Web API Keys are designed to be
# public and embedded in client applications. They are:
# - Safe to commit to version control
# - Safe to distribute in client packages
# - Restricted by Firebase Security Rules (not by key secrecy)
#
# This key is used for:
# - Custom token → ID token exchange via Firebase Auth REST API
# - Client-side Firebase SDK initialization
#
# Actual security is enforced by:
# - Firebase Security Rules (Firestore/Storage)
# - Cloud Functions authentication middleware
# - Server-side Firebase Admin SDK with service account credentials
#
# Project: obra-205b0
# Reference: https://firebase.google.com/docs/projects/api-keys
FIREBASE_API_KEY = "AIzaSyDHQNxR_4BQvK_W_i83H2hNH4p2OKFi2wM"  # pragma: allowlist secret

# =============================================================================
# Lazy loading registry (PEP 562)
# =============================================================================

_LAZY_IMPORTS = {
    # From loaders.py - Config I/O and getters
    "DEFAULT_API_BASE_URL": ".loaders",
    "DEFAULT_LLM_CALL_TIMEOUT": ".loaders",
    "DEFAULT_LLM_TIMEOUT": ".loaders",
    "DEFAULT_AGENT_EXECUTION_TIMEOUT": ".loaders",
    "DEFAULT_REVIEW_AGENT_TIMEOUT": ".loaders",
    "DEFAULT_MAX_ITERATIONS": ".loaders",
    "DEFAULT_NETWORK_TIMEOUT": ".loaders",
    "DEFAULT_LLM_API_TIMEOUT": ".loaders",
    "DEFAULT_LLM_STREAM_IDLE_TIMEOUT": ".loaders",
    "DEFAULT_CHECK_FOR_UPDATES": ".loaders",
    "DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES": ".loaders",
    "get_config_path": ".loaders",
    "load_config": ".loaders",
    "save_config": ".loaders",
    "load_auth_state": ".loaders",
    "save_auth_state": ".loaders",
    "get_api_base_url": ".loaders",
    "enable_local_mode": ".loaders",
    "is_local_mode": ".loaders",
    "LOCAL_EMULATOR_API_URL": ".loaders",
    "get_llm_call_timeout": ".loaders",
    "get_llm_timeout": ".loaders",
    "get_llm_api_timeout": ".loaders",
    "get_llm_stream_idle_timeout": ".loaders",
    "get_agent_execution_timeout": ".loaders",
    "get_review_agent_timeout": ".loaders",
    "get_cli_runner_timeout": ".loaders",
    "get_heartbeat_interval": ".loaders",
    "get_heartbeat_initial_delay": ".loaders",
    "get_watchdog_enabled": ".loaders",
    "get_watchdog_stall_timeout": ".loaders",
    "get_watchdog_max_silent_seconds": ".loaders",
    "get_nightly_wait_poll_interval_s": ".loaders",
    "get_nightly_max_total_loops": ".loaders",
    "get_nightly_max_target_retries": ".loaders",
    "get_nightly_max_fix_loops": ".loaders",
    "get_nightly_max_repair_attempts": ".loaders",
    "get_nightly_repair_cooldown_s": ".loaders",
    "get_nightly_worker_timeout_s": ".loaders",
    "get_nightly_analysis_tier": ".loaders",
    "get_nightly_fix_tier": ".loaders",
    "get_nightly_enable_llm_fixes": ".loaders",
    "get_nightly_enable_session_repair": ".loaders",
    "get_nightly_allow_force_complete": ".loaders",
    "get_nightly_simulation_config": ".loaders",
    "get_campaign_child_poll_interval_s": ".loaders",
    "get_campaign_bootstrap_ready_timeout_s": ".loaders",
    "get_campaign_max_fix_loops": ".loaders",
    "get_campaign_confirmation_reruns": ".loaders",
    "get_campaign_worker_timeout_s": ".loaders",
    "get_campaign_analysis_tier": ".loaders",
    "get_campaign_fix_tier": ".loaders",
    "get_campaign_enable_llm_fixes": ".loaders",
    "get_campaign_simulation_config": ".loaders",
    "DEFAULT_WATCHDOG_ENABLED": ".loaders",
    "DEFAULT_WATCHDOG_STALL_TIMEOUT_S": ".loaders",
    "get_max_iterations": ".loaders",
    "get_mcp_servers_config": ".loaders",
    "get_mcp_servers_enabled": ".loaders",
    "get_mcp_servers_max_tools": ".loaders",
    "get_default_project_override": ".loaders",
    "get_isolated_mode": ".loaders",
    "set_isolated_mode": ".loaders",
    "get_check_for_updates": ".loaders",
    "get_update_notification_cooldown_minutes": ".loaders",
    "get_auto_update": ".loaders",
    "get_auto_update_cooldown_minutes": ".loaders",
    "get_auto_update_max_retries": ".loaders",
    "get_auto_update_retry_delay_s": ".loaders",
    "get_auto_update_pipx_timeout_s": ".loaders",
    "get_project_detection_empty_threshold": ".loaders",
    "get_project_detection_existing_threshold": ".loaders",
    "get_project_detection_enabled": ".loaders",
    "get_prompt_max_files": ".loaders",
    "get_prompt_retention": ".loaders",
    "get_prompt_cleanup_age_hours": ".loaders",
    "get_derivation_step_timeout": ".loaders",
    "get_derivation_stall_threshold": ".loaders",
    # Additional loaders.py getters (generated + outliers) — S5.T1 completion
    "expand_automation_mode": ".loaders",
    "load_layered_config": ".loaders",
    "load_llm_section": ".loaders",
    "load_project_layer": ".loaders",
    "resolve_config_alias": ".loaders",
    "resolve_semantic_alias": ".loaders",
    "validate_default_schema": ".loaders",
    "validate_pipeline_config": ".loaders",
    "get_agent_base_timeout": ".loaders",
    "get_agent_extended_timeout": ".loaders",
    "get_agent_graceful_termination_wait": ".loaders",
    "get_agent_ignore_patterns": ".loaders",
    "get_agent_liveness_check_interval": ".loaders",
    "get_api_client_config": ".loaders",
    "get_api_connection_pool_config": ".loaders",
    "get_api_limits": ".loaders",
    "get_api_retry_delays": ".loaders",
    "get_api_timeouts": ".loaders",
    "get_benchmark_repo_root": ".loaders",
    "get_benchmark_timeout_s": ".loaders",
    "get_benchmark_workspace_directory": ".loaders",
    "get_cli_cleanup_runtime_log_config": ".loaders",
    "get_auto_retry_config": ".loaders",
    "get_auto_story_timeout_s": ".loaders",
    "get_cleanup_investigation_config": ".loaders",
    "get_cleanup_sleep_cap_s": ".loaders",
    "get_cli_cache_config": ".loaders",
    "get_cli_force_exit_threshold": ".loaders",
    "get_cli_interrupt_threshold": ".loaders",
    "get_cli_retry_config": ".loaders",
    "get_cli_update_check_config": ".loaders",
    "get_code_verify_config": ".loaders",
    "get_code_verify_preflight_config": ".loaders",
    "get_code_verify_timeout_s": ".loaders",
    "get_config_explorer_config": ".loaders",
    "get_decomposition_duration_threshold_s": ".loaders",
    "get_decomposition_max_attempts": ".loaders",
    "get_decomposition_summary_max_chars": ".loaders",
    "get_decomposition_warning_threshold_ratio": ".loaders",
    "get_decomposition_warning_threshold_s": ".loaders",
    "get_derivation_auto_decompose_config": ".loaders",
    "get_derivation_budget_config": ".loaders",
    "get_derivation_epic_item_rederive_threshold": ".loaders",
    "get_derivation_epic_output_token_limit": ".loaders",
    "get_derivation_exploration_lookback_minutes": ".loaders",
    "get_derivation_max_depth_warning_threshold": ".loaders",
    "get_derivation_pre_filter_timeout": ".loaders",
    "get_derivation_preview_config": ".loaders",
    "get_derivation_sizing_gate_timeout": ".loaders",
    "get_derivation_story_range": ".loaders",
    "get_derivation_strict_story_range": ".loaders",
    "get_derivation_strict_task_range": ".loaders",
    "get_derivation_task_config": ".loaders",
    "get_derivation_task_range": ".loaders",
    "get_derive_alignment_timeout": ".loaders",
    "get_derive_cache_max_age": ".loaders",
    "get_derive_complexity_thresholds": ".loaders",
    "get_derive_llm_timeout": ".loaders",
    "get_derive_mapping_timeout": ".loaders",
    "get_derive_max_relevant_files": ".loaders",
    "get_derive_max_retries": ".loaders",
    "get_derive_raw_response_log_preview": ".loaders",
    "get_display_limit": ".loaders",
    "get_execution_quality_config": ".loaders",
    "get_fallback_config": ".loaders",
    "get_failure_context_max_chars": ".loaders",
    "get_fix_batching_enabled": ".loaders",
    "get_fix_batching_max_size": ".loaders",
    "get_fix_batching_split_on_retry": ".loaders",
    "get_fix_handler_doc_timeout": ".loaders",
    "get_fix_handler_max_retries": ".loaders",
    "get_fix_handler_min_file_size": ".loaders",
    "get_fix_handler_parallel_enabled": ".loaders",
    "get_fix_handler_parallel_workers": ".loaders",
    "get_fix_llm_suggestion_timeout": ".loaders",
    "get_fix_llm_test_gap_timeout": ".loaders",
    "get_fix_test_gap_inference_confidence_threshold": ".loaders",
    "get_fix_test_gap_inference_enabled": ".loaders",
    "get_fix_test_gap_inference_max_candidates": ".loaders",
    "get_gateway_assistant_config": ".loaders",
    "get_gateway_config": ".loaders",
    "get_generated_plan_quality_threshold": ".loaders",
    "get_hang_confidence": ".loaders",
    "get_hierarchy_limit": ".loaders",
    "get_hybrid_polling_config": ".loaders",
    "get_intake_config": ".loaders",
    "get_intent_chunking_config": ".loaders",
    "get_intent_context_max_chars": ".loaders",
    "get_intent_context_max_item_chars": ".loaders",
    "get_intent_context_max_items": ".loaders",
    "get_intent_rate_limit_config": ".loaders",
    "get_intent_slug_max_length": ".loaders",
    "get_intent_thresholds_config": ".loaders",
    "get_intent_token_budget": ".loaders",
    "get_interactive_guard_enabled": ".loaders",
    "get_interactive_guard_patterns": ".loaders",
    "get_interactive_guard_retry_max": ".loaders",
    "get_interactive_guard_rollback_codes": ".loaders",
    "get_interactive_guard_rollback_enabled": ".loaders",
    "get_learned_patterns_config": ".loaders",
    "get_limit": ".loaders",
    "get_liveness_cpu_delta_threshold": ".loaders",
    "get_liveness_db_update_window": ".loaders",
    "get_liveness_file_mtime_window": ".loaders",
    "get_liveness_log_silence_threshold": ".loaders",
    "get_liveness_min_alive_indicators": ".loaders",
    "get_log_viewer_config": ".loaders",
    "get_oauth_config": ".loaders",
    "get_ollama_endpoint": ".loaders",
    "get_pipeline_custom_stages": ".loaders",
    "get_pipeline_max_iterations": ".loaders",
    "get_pipeline_stage_timeout": ".loaders",
    "get_plan_item_validation_config": ".loaders",
    "get_priority_order": ".loaders",
    "get_process_registry_config": ".loaders",
    "get_production_logger_config": ".loaders",
    "get_projects_default_directory": ".loaders",
    "get_spike_first_config": ".loaders",
    "get_project_layer_path": ".loaders",
    "get_provider_tier_defaults": ".loaders",
    "get_quality_config": ".loaders",
    "get_quality_threshold": ".loaders",
    "get_refinement_regression_min_delta": ".loaders",
    "get_refinement_regression_threshold_multiplier": ".loaders",
    "get_refinement_straggler_alert_threshold": ".loaders",
    "get_retry_config": ".loaders",
    "get_review_agents_max_workers": ".loaders",
    "get_review_agents_parallel": ".loaders",
    "get_review_blocking_low_priority_strict": ".loaders",
    "get_review_complexity_medium": ".loaders",
    "get_review_complexity_simple": ".loaders",
    "get_review_loop_exit_policy_enabled": ".loaders",
    "get_review_loop_exit_policy_max_non_critical_review_cycles": ".loaders",
    "get_review_loop_exit_policy_require_no_new_critical": ".loaders",
    "get_review_loop_exit_policy_require_required_checks_pass": ".loaders",
    "get_review_loop_exit_policy_require_threshold_met": ".loaders",
    "get_revision_plan_shrinkage_block_threshold": ".loaders",
    "get_revision_plan_shrinkage_warning_threshold": ".loaders",
    "get_role_tier_defaults": ".loaders",
    "get_session_layer_override": ".loaders",
    "get_session_layer_path": ".loaders",
    "get_skip_tracking_config": ".loaders",
    "get_spinner_config": ".loaders",
    "get_prompt_sanitizer_strict_mode": ".loaders",
    "get_story0_capability_checks": ".loaders",
    "get_story0_llm_schema_timeout": ".loaders",
    "get_thinking_config": ".loaders",
    "get_tier_fallbacks": ".loaders",
    "get_timeout": ".loaders",
    "get_tooling_discovery_config": ".loaders",
    "get_tooling_discovery_timeout": ".loaders",
    "get_triage_high_confidence": ".loaders",
    "get_triage_low_confidence": ".loaders",
    "get_triage_medium_confidence": ".loaders",
    "get_user_story_generation_enabled": ".loaders",
    "get_user_story_generation_timeout_s": ".loaders",
    "get_user_story_max_stories": ".loaders",
    "get_user_story_model_tier": ".loaders",
    "get_verification_auto_install": ".loaders",
    "get_verification_discovery_enabled": ".loaders",
    "get_verification_discovery_settings": ".loaders",
    "get_verification_force_refresh": ".loaders",
    "get_verification_max_retries": ".loaders",
    "get_verification_tool_installs": ".loaders",
    "get_verification_tools_config": ".loaders",
    "get_work_type_base_score": ".loaders",
    "get_work_type_keyword_weight": ".loaders",
    "get_work_type_max_bonus": ".loaders",
    "get_work_type_phrase_weight": ".loaders",
    "get_work_type_regex_weight": ".loaders",
    "get_workflow_keyword_weight": ".loaders",
    "get_workflow_pattern_weight": ".loaders",
    "get_working_dir_enforcement_enabled": ".loaders",
    "get_xhigh_supported_models": ".loaders",
    "is_decomposition_enabled": ".loaders",
    # From providers.py - LLM provider definitions and health check
    "LLM_PROVIDERS": ".providers",
    "LLM_AUTH_METHODS": ".providers",
    "DEFAULT_PROVIDER": ".providers",
    "DEFAULT_AUTH_METHOD": ".providers",
    "DEFAULT_MODEL": ".providers",
    "ProviderStatus": ".providers",
    "PROVIDER_CLI_INFO": ".providers",
    "check_provider_status": ".providers",
    "validate_provider_model_ready": ".providers",
    "validate_provider_ready": ".providers",
    # From llm.py - LLM config resolution and CLI building (ADR-073)
    "DEFAULT_REASONING_LEVEL": ".llm",
    "REASONING_LEVELS": ".llm",
    "REASONING_LEVEL_MAP": ".llm",
    "MODEL_SHORTCUTS": ".llm",
    "XHIGH_SUPPORTED_MODELS": ".llm",
    "MODEL_PROVIDER_PATTERNS": ".llm",
    "MODEL_PROVIDER_PREFIXES": ".llm",
    "infer_provider_from_model": ".llm",
    "get_reasoning_level_notes": ".llm",
    "get_effective_reasoning_value": ".llm",
    "validate_model": ".llm",
    "resolve_llm_config": ".llm",
    "get_llm_config": ".llm",
    "apply_provider_config": ".llm",
    "set_llm_config": ".llm",
    "get_llm_display": ".llm",
    "get_reasoning_keyword": ".llm",
    "build_llm_args": ".llm",
    "get_llm_cli": ".llm",
    "get_llm_command": ".llm",
    "PROVIDER_API_KEY_ENV_VARS": "obra.execution.os_compat",
    "build_subprocess_env": "obra.execution.os_compat",
    # From resolution.py - CLI run config resolution
    "RunConfig": ".resolution",
    "resolve_run_config": ".resolution",
    # From auth.py - Firebase auth state
    "get_firebase_uid": ".auth",
    "get_user_email": ".auth",
    "get_auth_token": ".auth",
    "get_refresh_token": ".auth",
    "get_auth_provider": ".auth",
    "is_authenticated": ".auth",
    "save_firebase_auth": ".auth",
    "clear_firebase_auth": ".auth",
}


def __getattr__(name: str):
    """Lazy load heavy components on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module = importlib.import_module(_LAZY_IMPORTS[name], __name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


# =============================================================================
# Terms acceptance functions (kept in __init__.py - core, lightweight)
# =============================================================================


def get_terms_acceptance() -> dict | None:
    """Get stored terms acceptance data.

    Returns:
        Dictionary with terms acceptance info, or None if not accepted:
        {
            "version": "2.1",
            "privacy_version": "1.3",
            "accepted_at": "2025-12-03T12:00:00+00:00"
        }
    """
    from .loaders import load_config

    config = load_config()
    return config.get("terms_accepted")


def is_terms_accepted() -> bool:
    """Check if current terms version has been accepted.

    Returns:
        True if terms are accepted and version matches current,
        False otherwise
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False

    # Check if accepted version matches current version
    accepted_version = acceptance.get("version")
    return accepted_version == TERMS_VERSION


def needs_reacceptance() -> bool:
    """Check if terms need to be re-accepted due to version change.

    Returns:
        True if terms were previously accepted but version changed,
        False if never accepted or current version is accepted
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False  # Never accepted, not "re-acceptance"

    accepted_version = acceptance.get("version")
    return accepted_version != TERMS_VERSION


def save_terms_acceptance(
    version: str = TERMS_VERSION,
    privacy_version: str = PRIVACY_VERSION,
) -> None:
    """Save terms acceptance to config file.

    Args:
        version: Terms version being accepted (default: current TERMS_VERSION)
        privacy_version: Privacy policy version (default: current PRIVACY_VERSION)
    """
    from .loaders import load_config, save_config

    config = load_config()

    config["terms_accepted"] = {
        "version": version,
        "privacy_version": privacy_version,
        "accepted_at": datetime.now(UTC).isoformat(),
    }

    save_config(config)


def clear_terms_acceptance() -> None:
    """Clear stored terms acceptance (for testing/reset)."""
    from .loaders import load_config, save_config

    config = load_config()

    if "terms_accepted" in config:
        del config["terms_accepted"]
        save_config(config)


# =============================================================================
# Public exports - complete for IDE/type checker support
# =============================================================================

__all__ = [
    "AUTH_STATE_PATH",
    "CONFIG_PATH",
    "DEFAULT_AGENT_EXECUTION_TIMEOUT",
    # Lazy: loaders.py
    "DEFAULT_API_BASE_URL",
    "DEFAULT_LLM_CALL_TIMEOUT",
    "DEFAULT_AUTH_METHOD",
    "DEFAULT_CHECK_FOR_UPDATES",
    "DEFAULT_LLM_API_TIMEOUT",
    "DEFAULT_LLM_STREAM_IDLE_TIMEOUT",
    "DEFAULT_LLM_TIMEOUT",
    "DEFAULT_MAX_ITERATIONS",
    "DEFAULT_MODEL",
    "DEFAULT_NETWORK_TIMEOUT",
    "DEFAULT_PROVIDER",
    "DEFAULT_REVIEW_AGENT_TIMEOUT",
    # Lazy: llm.py (ADR-073)
    "DEFAULT_REASONING_LEVEL",
    "DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES",
    "FIREBASE_API_KEY",
    "LLM_AUTH_METHODS",
    # Lazy: providers.py
    "LLM_PROVIDERS",
    "LOCAL_EMULATOR_API_URL",
    "MODEL_PROVIDER_PATTERNS",
    "MODEL_PROVIDER_PREFIXES",
    "MODEL_SHORTCUTS",
    "PRIVACY_VERSION",
    "PROVIDER_API_KEY_ENV_VARS",
    "PROVIDER_CLI_INFO",
    # Eager constants
    "TERMS_VERSION",
    "REASONING_LEVELS",
    "REASONING_LEVEL_MAP",
    "XHIGH_SUPPORTED_MODELS",
    "ProviderStatus",
    "build_llm_args",
    "build_subprocess_env",
    "check_provider_status",
    "clear_firebase_auth",
    "clear_terms_acceptance",
    "enable_local_mode",
    "get_agent_execution_timeout",
    "get_api_base_url",
    "get_auth_provider",
    "get_auth_token",
    "get_check_for_updates",
    "get_auto_update",
    "get_auto_update_cooldown_minutes",
    "get_auto_update_max_retries",
    "get_auto_update_retry_delay_s",
    "get_auto_update_pipx_timeout_s",
    "get_benchmark_repo_root",
    "get_benchmark_timeout_s",
    "get_benchmark_workspace_directory",
    "get_cli_runner_timeout",
    "get_config_path",
    "get_default_project_override",
    "get_derivation_stall_threshold",
    "get_derivation_step_timeout",
    "get_effective_reasoning_value",
    "get_prompt_sanitizer_strict_mode",
    # Lazy: auth.py
    "get_firebase_uid",
    "get_heartbeat_initial_delay",
    "get_heartbeat_interval",
    "get_isolated_mode",
    "get_llm_call_timeout",
    "get_llm_api_timeout",
    "get_llm_cli",
    "get_llm_command",
    "get_llm_config",
    "get_llm_display",
    "get_llm_stream_idle_timeout",
    "get_llm_timeout",
    "get_learned_patterns_config",
    "get_max_iterations",
    "get_mcp_servers_config",
    "get_mcp_servers_enabled",
    "get_mcp_servers_max_tools",
    "get_refresh_token",
    "get_review_agent_timeout",
    "get_spike_first_config",
    # Terms functions (in __init__.py)
    "get_terms_acceptance",
    "get_reasoning_keyword",
    "get_reasoning_level_notes",
    "get_update_notification_cooldown_minutes",
    "get_user_email",
    "infer_provider_from_model",
    "is_authenticated",
    "is_local_mode",
    "is_terms_accepted",
    "load_auth_state",
    "load_config",
    "needs_reacceptance",
    "resolve_llm_config",
    "resolve_run_config",
    "RunConfig",
    "save_auth_state",
    "save_config",
    "save_firebase_auth",
    "save_terms_acceptance",
    "set_isolated_mode",
    "apply_provider_config",
    "set_llm_config",
    "validate_model",
    "validate_provider_ready",
]
