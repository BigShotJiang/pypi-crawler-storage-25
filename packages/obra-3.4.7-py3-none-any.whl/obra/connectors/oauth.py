"""Browser-based OAuth helpers for connector authorization."""

from __future__ import annotations

import base64
import hashlib
import secrets
from urllib.parse import urlencode

import httpx

from obra.connectors.errors import ObraConnectorAuthError


class OAuthBrowserFlow:
    """Manage a one-shot OAuth authorization-code exchange with PKCE."""

    def __init__(
        self,
        *,
        client_id: str,
        client_secret: str,
        authorize_url: str,
        token_url: str,
        scopes: list[str],
        redirect_uri: str,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._authorize_url = authorize_url
        self._token_url = token_url
        self._scopes = list(scopes)
        self._redirect_uri = redirect_uri
        self._pending_flows: dict[str, str] = {}

    def build_authorize_url(self, state: str) -> str:
        """Return the consent URL and remember the PKCE verifier for the state."""
        return self.build_authorize_url_for_mode(state)

    def build_authorize_url_for_mode(
        self,
        state: str,
        *,
        reconnect: bool = False,
    ) -> str:
        """Return the consent URL for a connect or reconnect request."""
        code_verifier = secrets.token_urlsafe(64)
        self._pending_flows[state] = code_verifier
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode("utf-8")).digest())
            .decode("ascii")
            .rstrip("=")
        )
        params = {
            "client_id": self._client_id,
            "redirect_uri": self._redirect_uri,
            "response_type": "code",
            "scope": " ".join(self._scopes),
            "access_type": "offline",
            "include_granted_scopes": "true",
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "state": state,
        }
        if reconnect:
            params["prompt"] = "consent"
        query = urlencode(params)
        return f"{self._authorize_url}?{query}"

    def exchange_code(self, code: str, state: str) -> dict[str, object]:
        """Exchange the callback code for an OAuth token payload."""
        code_verifier = self._pending_flows.get(state)
        if not code_verifier:
            raise ObraConnectorAuthError("OAuth state is missing or expired")

        try:
            response = httpx.post(
                self._token_url,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": self._redirect_uri,
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "code_verifier": code_verifier,
                },
            )
        except Exception as exc:
            raise ObraConnectorAuthError("OAuth token exchange failed") from exc

        if response.status_code >= 400:
            raise ObraConnectorAuthError("OAuth token exchange failed")

        try:
            payload = response.json()
        except Exception as exc:
            raise ObraConnectorAuthError("OAuth token exchange returned invalid JSON") from exc

        access_token = str(payload.get("access_token") or "").strip()
        if not access_token:
            raise ObraConnectorAuthError("OAuth token exchange did not return an access token")

        self._pending_flows.pop(state, None)
        return {
            "access_token": access_token,
            "refresh_token": payload.get("refresh_token"),
            "expires_in": payload.get("expires_in"),
            "token_type": payload.get("token_type"),
        }
