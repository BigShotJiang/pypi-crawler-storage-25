"""Connector decorators and provider-scoped registration."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

from obra.connectors.async_patterns import PollResult

AuthType = Literal["oauth2", "api_key", "bearer"] | None
CompletionType = Literal["poll", "webhook"]


@dataclass(slots=True)
class ConnectorOperationDefinition:
    """Captured decorator metadata for a connector operation."""

    operation_id: str
    version: str
    function: Callable[..., dict[str, Any]]
    auth_type: AuthType = None
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)
    summary: str = ""
    description: str = ""
    provider_root: str = ""
    module_name: str = ""
    credential_param_name: str | None = None
    start_param_name: str = "inputs"
    async_mode: bool = False
    completion: CompletionType | None = None
    poll_function: Callable[..., PollResult] | None = None
    poll_interval_s: int = 30
    poll_max_duration_s: int = 600

    @property
    def requires_credentials(self) -> bool:
        """Whether the operation expects credential injection."""
        return self.credential_param_name is not None


_OPERATION_REGISTRY: dict[str, dict[tuple[str, str], ConnectorOperationDefinition]] = {}


def _provider_root_for(function: Callable[..., Any]) -> str:
    module_name = str(getattr(function, "__module__", "") or "")
    return module_name.split(".", 1)[0] if module_name else ""


def _inspect_function_signature(function: Callable[..., Any]) -> tuple[str, str | None]:
    signature = inspect.signature(function)
    input_param_name = ""
    credential_param_name: str | None = None
    for parameter in signature.parameters.values():
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            continue
        if input_param_name == "":
            input_param_name = parameter.name
            continue
        if credential_param_name is None and parameter.name == "credentials":
            credential_param_name = parameter.name
    if not input_param_name:
        msg = f"Connector operation {function.__name__} must accept an inputs parameter"
        raise ValueError(msg)
    return input_param_name, credential_param_name


def _register_definition(definition: ConnectorOperationDefinition) -> None:
    provider_operations = _OPERATION_REGISTRY.setdefault(definition.provider_root, {})
    provider_operations[(definition.operation_id, definition.version)] = definition


def operation(
    *,
    id: str,
    version: str,
    auth_type: AuthType = None,
    input_schema: dict[str, Any] | None = None,
    output_schema: dict[str, Any] | None = None,
    summary: str = "",
    description: str = "",
) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
    """Register a synchronous connector operation."""

    def decorator(function: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
        input_param_name, credential_param_name = _inspect_function_signature(function)
        definition = ConnectorOperationDefinition(
            operation_id=id,
            version=version,
            function=function,
            auth_type=auth_type,
            input_schema=dict(input_schema or {}),
            output_schema=dict(output_schema or {}),
            summary=summary,
            description=description,
            provider_root=_provider_root_for(function),
            module_name=str(getattr(function, "__module__", "") or ""),
            credential_param_name=credential_param_name,
            start_param_name=input_param_name,
        )
        _register_definition(definition)
        return function

    return decorator


def async_operation(
    *,
    id: str,
    version: str,
    completion: CompletionType,
    poll: Callable[..., PollResult] | None = None,
    auth_type: AuthType = None,
    input_schema: dict[str, Any] | None = None,
    output_schema: dict[str, Any] | None = None,
    summary: str = "",
    description: str = "",
    poll_interval_s: int = 30,
    poll_max_duration_s: int = 900,
) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
    """Register an async connector operation."""

    if completion != "poll":
        raise NotImplementedError("completion='webhook' is deferred from Connector SDK v1")
    if poll is None:
        raise ValueError("async_operation(completion='poll') requires a poll callback")

    def decorator(function: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
        input_param_name, credential_param_name = _inspect_function_signature(function)
        definition = ConnectorOperationDefinition(
            operation_id=id,
            version=version,
            function=function,
            auth_type=auth_type,
            input_schema=dict(input_schema or {}),
            output_schema=dict(output_schema or {}),
            summary=summary,
            description=description,
            provider_root=_provider_root_for(function),
            module_name=str(getattr(function, "__module__", "") or ""),
            credential_param_name=credential_param_name,
            start_param_name=input_param_name,
            async_mode=True,
            completion=completion,
            poll_function=poll,
            poll_interval_s=poll_interval_s,
            poll_max_duration_s=poll_max_duration_s,
        )
        _register_definition(definition)
        return function

    return decorator


def get_registered_operations(provider_root: str) -> list[ConnectorOperationDefinition]:
    """Return operations scoped to one provider root package."""
    definitions = _OPERATION_REGISTRY.get(provider_root, {})
    return [definitions[key] for key in sorted(definitions)]


def get_registered_operation(
    provider_root: str,
    operation_id: str,
    version: str,
) -> ConnectorOperationDefinition:
    """Resolve one registered operation for a provider root."""
    definitions = _OPERATION_REGISTRY.get(provider_root, {})
    try:
        return definitions[(operation_id, version)]
    except KeyError as exc:
        msg = (
            f"Connector operation '{operation_id}' version '{version}' is not registered "
            f"for provider '{provider_root}'"
        )
        raise KeyError(msg) from exc


def clear_registered_operations() -> None:
    """Clear registered operations for tests."""
    _OPERATION_REGISTRY.clear()
