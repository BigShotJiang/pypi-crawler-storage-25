"""Connector-specific exception taxonomy."""

from __future__ import annotations

from obra.exceptions import ObraError


class ObraConnectorError(ObraError):
    """Base error for connector execution failures."""


class ObraConnectorAuthError(ObraConnectorError):
    """Authentication or authorization failed for a connector call."""


class ObraConnectorRateLimitError(ObraConnectorError):
    """External API rate limit was exceeded."""

    def __init__(
        self,
        message: str,
        *,
        retry_after_s: int | None = None,
        max_retries: int = 5,
        recovery: str = "",
    ) -> None:
        super().__init__(message, recovery or "Wait for quota reset and retry the stage.")
        self.retry_after_s = retry_after_s
        self.max_retries = max_retries


class ObraConnectorValidationError(ObraConnectorError):
    """Input validation failed before or during a connector call."""


class ObraConnectorNotFoundError(ObraConnectorError):
    """An external resource required by the connector does not exist."""


class ObraConnectorTransientError(ObraConnectorError):
    """A transient external failure occurred and may succeed on retry."""


class ObraConnectorPermanentError(ObraConnectorError):
    """A non-retryable external failure occurred."""
