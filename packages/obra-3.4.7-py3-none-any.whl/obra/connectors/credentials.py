"""Connector credential protocol and encrypted local store."""

from __future__ import annotations

import base64
import json
import os
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol

import requests
from cryptography.fernet import Fernet

from obra.config.loaders import (
    get_connector_credentials_key_path,
    get_connector_credentials_refresh_margin_s,
    get_connector_credentials_store_path,
)
from obra.exceptions import ConfigurationError
from obra.connectors.errors import ObraConnectorAuthError, ObraConnectorTransientError

RefreshFailureClassification = Literal["revoked", "transient", "unknown"]
RevocationOutcome = Literal["revoked", "already_revoked", "failed", "not_attempted"]


class OAuthCredentialAuthError(ObraConnectorAuthError):
    """Auth error carrying the classified OAuth credential failure state."""

    def __init__(
        self,
        message: str,
        *,
        classification: Literal["revoked", "unknown"],
        recovery: str,
    ) -> None:
        super().__init__(message, recovery=recovery)
        self.classification = classification


@dataclass(frozen=True, slots=True)
class OAuthTokenRevocationResult:
    """Result of attempting to revoke one OAuth token."""

    attempted: bool
    outcome: RevocationOutcome
    message: str
    hint: str | None = None


class ObraCredentials(Protocol):
    """Protocol exposed to connector functions."""

    name: str
    credential_type: str

    def headers(self) -> dict[str, str]:
        """Return request headers for this credential."""

    def refresh(self) -> None:
        """Force refresh any renewable access token."""

    def refresh_if_needed(self) -> None:
        """Refresh only when the credential is near expiry."""


@dataclass(slots=True)
class ApiKeyCredential:
    """Static API key credential."""

    name: str
    api_key: str
    header_name: str = "Authorization"
    prefix: str = ""
    credential_type: str = field(init=False, default="api_key")

    def headers(self) -> dict[str, str]:
        value = f"{self.prefix}{self.api_key}" if self.prefix else self.api_key
        return {self.header_name: value}

    def refresh(self) -> None:
        return None

    def refresh_if_needed(self) -> None:
        return None


@dataclass(slots=True)
class BearerTokenCredential:
    """Static bearer token credential."""

    name: str
    access_token: str
    credential_type: str = field(init=False, default="bearer")

    def headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.access_token}"}

    def refresh(self) -> None:
        return None

    def refresh_if_needed(self) -> None:
        return None


@dataclass(slots=True)
class OAuth2Credential:
    """OAuth2 credential with refresh-token support."""

    name: str
    access_token: str
    refresh_token: str
    token_url: str
    client_id: str
    client_secret: str
    expires_at: float | None = None
    scope: str = ""
    token_type: str = "Bearer"
    refresh_margin_s: int = 300
    persist_callback: Callable[["OAuth2Credential"], None] | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    invalidate_callback: Callable[[str], bool] | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    credential_type: str = field(init=False, default="oauth2")

    def headers(self) -> dict[str, str]:
        return {"Authorization": f"{self.token_type} {self.access_token}"}

    def refresh(self) -> None:
        try:
            response = requests.post(
                self.token_url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                },
                timeout=30,
            )
        except requests.RequestException as exc:
            raise ObraConnectorTransientError(
                f"OAuth2 refresh temporarily failed for credential '{self.name}'",
                recovery=_oauth_refresh_recovery(self.name),
            ) from exc
        if response.status_code >= 400:
            classification = _classify_oauth_refresh_failure(self.name, response)
            if classification == "transient":
                raise ObraConnectorTransientError(
                    f"OAuth2 refresh temporarily failed for credential '{self.name}'",
                    recovery=_oauth_refresh_recovery(self.name),
                )
            if classification == "revoked":
                if self.invalidate_callback is not None:
                    self.invalidate_callback("revoked")
                raise OAuthCredentialAuthError(
                    f"OAuth2 refresh token was revoked for credential '{self.name}'",
                    classification="revoked",
                    recovery=_oauth_refresh_recovery(self.name),
                )
            raise OAuthCredentialAuthError(
                f"OAuth2 refresh failed for credential '{self.name}'",
                classification="unknown",
                recovery=_oauth_refresh_recovery(self.name),
            )
        payload = response.json()
        self.access_token = str(payload.get("access_token") or "")
        if not self.access_token:
            raise OAuthCredentialAuthError(
                f"OAuth2 refresh did not return an access token for '{self.name}'",
                classification="unknown",
                recovery=_oauth_refresh_recovery(self.name),
            )
        if payload.get("refresh_token"):
            self.refresh_token = str(payload.get("refresh_token"))
        expires_in = payload.get("expires_in")
        if expires_in is not None:
            self.expires_at = time.time() + float(expires_in)
        token_type = str(payload.get("token_type") or "").strip()
        if token_type:
            self.token_type = token_type
        if self.persist_callback is not None:
            self.persist_callback(self)

    def refresh_if_needed(self) -> None:
        if self.expires_at is None:
            return
        if time.time() >= (self.expires_at - float(self.refresh_margin_s)):
            self.refresh()


@contextmanager
def _locked_file(path: Path) -> Iterator[None]:
    """Lock one credential file for exclusive mutation."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            return

        import fcntl

        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


class CredentialStore:
    """Encrypted file-backed credential store."""

    def __init__(
        self,
        *,
        store_path: str | None = None,
        key_path: str | None = None,
        refresh_margin_s: int | None = None,
    ) -> None:
        self.store_path = Path(store_path or get_connector_credentials_store_path()).expanduser()
        self.key_path = Path(key_path or get_connector_credentials_key_path()).expanduser()
        self.refresh_margin_s = int(
            refresh_margin_s
            if refresh_margin_s is not None
            else get_connector_credentials_refresh_margin_s()
        )

    def _ensure_key(self) -> bytes:
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        if self.key_path.exists():
            return self.key_path.read_bytes()
        raw_key = os.urandom(32)
        key = base64.urlsafe_b64encode(raw_key)
        self.key_path.write_bytes(key)
        os.chmod(self.key_path, 0o600)
        return key

    def _fernet(self) -> Fernet:
        return Fernet(self._ensure_key())

    def _credential_path(self, name: str) -> Path:
        return self.store_path / f"{name}.json.enc"

    def put(self, name: str, payload: dict[str, Any]) -> None:
        """Store one encrypted credential payload."""
        self.store_path.mkdir(parents=True, exist_ok=True)
        path = self._credential_path(name)
        encrypted = self._fernet().encrypt(
            json.dumps(_normalize_payload_for_storage(name, payload)).encode("utf-8")
        )
        with _locked_file(path):
            path.write_bytes(encrypted)
            os.chmod(path, 0o600)

    def get_payload(self, name: str) -> dict[str, Any]:
        """Load and decrypt one stored credential payload."""
        path = self._credential_path(name)
        if not path.exists():
            raise ObraConnectorAuthError(
                f"Credential '{name}' is not configured",
                recovery=f"Run 'obra credentials add {name} ...' to create the credential.",
            )
        try:
            encrypted = path.read_bytes()
            decrypted = self._fernet().decrypt(encrypted)
            payload = json.loads(decrypted.decode("utf-8"))
        except Exception as exc:
            raise ObraConnectorAuthError(
                f"Credential store unavailable at {self.store_path} — error: {exc}",
                recovery=(
                    "Use 'obra credentials doctor' to diagnose the local store, or set "
                    f"OBRA_SECRET_{name.upper()} environment variables for static secrets."
                ),
            ) from exc
        if not isinstance(payload, dict):
            raise ObraConnectorAuthError(
                f"Credential '{name}' payload is corrupted",
                recovery="Run 'obra credentials doctor' and then re-add the credential.",
            )
        return payload

    def get(self, name: str) -> ObraCredentials:
        """Resolve one stored credential into a credential object."""
        payload = self.get_payload(name)
        return self._credential_from_payload(name, payload)

    def remove(self, name: str) -> bool:
        """Delete one stored credential."""
        path = self._credential_path(name)
        if not path.exists():
            return False
        with _locked_file(path):
            path.unlink(missing_ok=True)
        return True

    def list_credentials(self) -> list[dict[str, Any]]:
        """List credential metadata without exposing secret values."""
        self.store_path.mkdir(parents=True, exist_ok=True)
        items: list[dict[str, Any]] = []
        for path in sorted(self.store_path.glob("*.json.enc")):
            name = path.stem.replace(".json", "")
            try:
                payload = self.get_payload(name)
                items.append(
                    {
                        "name": name,
                        "type": str(payload.get("type") or ""),
                        "status": "ok",
                    }
                )
            except ObraConnectorAuthError as exc:
                items.append({"name": name, "type": "unknown", "status": "error", "error": str(exc)})
        return items

    def refresh(self, name: str) -> ObraCredentials:
        """Refresh and persist one renewable credential."""
        payload = self.get_payload(name)
        credential = self._credential_from_payload(name, payload)
        credential.refresh()
        self.put(name, self._payload_from_credential(credential))
        return credential

    def doctor(self) -> dict[str, Any]:
        """Return local store health details."""
        self.store_path.mkdir(parents=True, exist_ok=True)
        key_exists = self.key_path.exists()
        return {
            "store_path": str(self.store_path),
            "key_path": str(self.key_path),
            "store_exists": self.store_path.exists(),
            "key_exists": key_exists,
            "credential_count": len(list(self.store_path.glob("*.json.enc"))),
        }

    def _credential_from_payload(self, name: str, payload: dict[str, Any]) -> ObraCredentials:
        credential_type = str(payload.get("type") or "").strip()
        if credential_type == "api_key":
            return ApiKeyCredential(
                name=name,
                api_key=str(payload.get("api_key") or ""),
                header_name=str(payload.get("header_name") or "Authorization"),
                prefix=str(payload.get("prefix") or ""),
            )
        if credential_type == "bearer":
            return BearerTokenCredential(
                name=name,
                access_token=str(payload.get("access_token") or ""),
            )
        if credential_type == "oauth2":
            managed_oauth = _managed_oauth_runtime_fields(name)
            token_url = str(payload.get("token_url") or "")
            client_id = str(payload.get("client_id") or "")
            client_secret = str(payload.get("client_secret") or "")
            if managed_oauth is not None:
                token_url = managed_oauth["token_url"]
                client_id = managed_oauth["client_id"]
                client_secret = managed_oauth["client_secret"]
            return OAuth2Credential(
                name=name,
                access_token=str(payload.get("access_token") or ""),
                refresh_token=str(payload.get("refresh_token") or ""),
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret,
                expires_at=float(payload["expires_at"]) if payload.get("expires_at") else None,
                scope=str(payload.get("scope") or ""),
                token_type=str(payload.get("token_type") or "Bearer"),
                refresh_margin_s=self.refresh_margin_s,
                persist_callback=lambda credential: self.put(name, self._payload_from_credential(credential)),
                invalidate_callback=(
                    (lambda reason: self.remove(name))
                    if managed_oauth is not None
                    else None
                ),
            )
        raise ObraConnectorAuthError(
            f"Credential '{name}' has unsupported type '{credential_type}'",
            recovery="Remove the credential and add it again with a supported type.",
        )

    @staticmethod
    def _payload_from_credential(credential: ObraCredentials) -> dict[str, Any]:
        if isinstance(credential, ApiKeyCredential):
            return {
                "type": "api_key",
                "api_key": credential.api_key,
                "header_name": credential.header_name,
                "prefix": credential.prefix,
            }
        if isinstance(credential, BearerTokenCredential):
            return {
                "type": "bearer",
                "access_token": credential.access_token,
            }
        if isinstance(credential, OAuth2Credential):
            return {
                "type": "oauth2",
                "access_token": credential.access_token,
                "refresh_token": credential.refresh_token,
                "token_url": credential.token_url,
                "client_id": credential.client_id,
                "client_secret": credential.client_secret,
                "expires_at": credential.expires_at,
                "scope": credential.scope,
                "token_type": credential.token_type,
            }
        msg = f"Unsupported credential instance: {type(credential).__name__}"
        raise TypeError(msg)


_GOOGLE_DRIVE_CONFIGURATION_RECOVERY = (
    "Set OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_ID and OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_SECRET, "
    "or configure connectors.google_drive.oauth.client_id and "
    "connectors.google_drive.oauth.client_secret, then reconnect Google Drive."
)


def _configured_google_drive_credential_name() -> str | None:
    try:
        from obra.config.loaders import get_google_drive_credential_name

        return str(get_google_drive_credential_name() or "").strip() or None
    except (ConfigurationError, ValueError):
        return "google-drive"


def _is_managed_google_drive_credential(name: str) -> bool:
    configured_name = _configured_google_drive_credential_name()
    return configured_name is not None and name == configured_name


def _managed_oauth_runtime_fields(name: str) -> dict[str, str] | None:
    if not _is_managed_google_drive_credential(name):
        return None
    try:
        from obra.config.loaders import get_google_drive_oauth_config

        config = get_google_drive_oauth_config()
    except (ConfigurationError, ValueError) as exc:
        raise ObraConnectorAuthError(
            "Google Drive is not configured on this machine.",
            recovery=_GOOGLE_DRIVE_CONFIGURATION_RECOVERY,
        ) from exc
    return {
        "token_url": str(config["token_url"]),
        "client_id": str(config["client_id"]),
        "client_secret": str(config["client_secret"]),
    }


def revoke_google_drive_oauth_credential(credential: OAuth2Credential) -> OAuthTokenRevocationResult:
    """Attempt to revoke the active Google Drive OAuth token for one credential."""
    if not _is_managed_google_drive_credential(credential.name):
        return OAuthTokenRevocationResult(
            attempted=False,
            outcome="not_attempted",
            message="OAuth token revocation is only supported for the managed Google Drive credential.",
        )

    token = str(credential.refresh_token or credential.access_token or "").strip()
    if not token:
        return OAuthTokenRevocationResult(
            attempted=False,
            outcome="not_attempted",
            message="No Google Drive OAuth token is stored locally to revoke.",
        )

    try:
        from obra.config.loaders import get_google_drive_oauth_lifecycle_config

        config = get_google_drive_oauth_lifecycle_config()
    except (ConfigurationError, ValueError) as exc:
        return OAuthTokenRevocationResult(
            attempted=False,
            outcome="not_attempted",
            message="Google Drive revocation was not attempted because lifecycle config is unavailable.",
            hint=str(exc),
        )

    revoke_url = str(config.get("revoke_url") or "").strip()
    if not revoke_url:
        return OAuthTokenRevocationResult(
            attempted=False,
            outcome="not_attempted",
            message="Google Drive revocation was not attempted because revoke_url is not configured.",
        )

    try:
        response = requests.post(revoke_url, data={"token": token}, timeout=30)
    except requests.RequestException as exc:
        return OAuthTokenRevocationResult(
            attempted=True,
            outcome="failed",
            message="Google Drive revocation failed while contacting the provider.",
            hint=str(exc),
        )

    if response.status_code < 400:
        return OAuthTokenRevocationResult(
            attempted=True,
            outcome="revoked",
            message="Google Drive OAuth access was revoked.",
        )
    if _is_google_drive_already_revoked_response(response):
        return OAuthTokenRevocationResult(
            attempted=True,
            outcome="already_revoked",
            message="Google Drive OAuth access was already revoked.",
        )
    return OAuthTokenRevocationResult(
        attempted=True,
        outcome="failed",
        message="Google Drive revocation failed at the provider.",
        hint=_response_detail_text(response),
    )


def _normalize_payload_for_storage(name: str, payload: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(payload)
    if str(normalized.get("type") or "") != "oauth2" or not _is_managed_google_drive_credential(name):
        return normalized
    return {
        "type": "oauth2",
        "access_token": normalized.get("access_token"),
        "refresh_token": normalized.get("refresh_token"),
        "expires_at": normalized.get("expires_at"),
        "scope": normalized.get("scope", ""),
        "token_type": normalized.get("token_type", "Bearer"),
    }


def _oauth_refresh_recovery(name: str) -> str:
    if _is_managed_google_drive_credential(name):
        return "Reconnect Google Drive in Workflow Studio settings, then retry the operation."
    return f"Run 'obra credentials refresh {name}' to re-authorize the credential."


def _classify_oauth_refresh_failure(
    name: str,
    response: requests.Response,
) -> RefreshFailureClassification:
    if response.status_code == 429 or response.status_code >= 500:
        return "transient"
    if not _is_managed_google_drive_credential(name):
        return "unknown"

    payload = _response_detail_payload(response)
    error = str(payload.get("error") or "").strip().lower()
    description = " ".join(
        [
            str(payload.get("error_description") or "").strip().lower(),
            _response_detail_text(response).strip().lower(),
        ]
    ).strip()
    if error == "invalid_grant":
        return "revoked"
    if "revoked" in description or "expired or revoked" in description:
        return "revoked"
    return "unknown"


def _is_google_drive_already_revoked_response(response: requests.Response) -> bool:
    if response.status_code == 400:
        payload = _response_detail_payload(response)
        error = str(payload.get("error") or "").strip().lower()
        detail = _response_detail_text(response).strip().lower()
        if error in {"invalid_grant", "invalid_token"}:
            return True
        if "invalid token" in detail or "token revoked" in detail:
            return True
    return False


def _response_detail_payload(response: requests.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _response_detail_text(response: requests.Response) -> str:
    payload = _response_detail_payload(response)
    detail = str(
        payload.get("error_description")
        or payload.get("error")
        or getattr(response, "text", "")
        or ""
    ).strip()
    return detail
