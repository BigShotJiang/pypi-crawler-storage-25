"""Async connector helper types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class PollResult:
    """Result returned by async poll callbacks."""

    is_done: bool
    result: dict[str, Any] | None = None
    state: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def pending(
        cls,
        *,
        state: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "PollResult":
        """Return a pending poll result."""
        return cls(
            is_done=False,
            state=dict(state or {}),
            metadata=dict(metadata or {}),
        )

    @classmethod
    def done(
        cls,
        result: dict[str, Any],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> "PollResult":
        """Return a completed poll result."""
        return cls(
            is_done=True,
            result=dict(result),
            metadata=dict(metadata or {}),
        )
