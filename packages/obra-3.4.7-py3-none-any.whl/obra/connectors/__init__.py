"""Public Connector SDK surface."""

from __future__ import annotations

from importlib import import_module
from typing import Any

__all__ = [
    "ApiKeyCredential",
    "BearerTokenCredential",
    "CredentialStore",
    "OAuth2Credential",
    "ObraConnectorAuthError",
    "ObraConnectorError",
    "ObraConnectorNotFoundError",
    "ObraConnectorPermanentError",
    "ObraConnectorRateLimitError",
    "ObraConnectorTransientError",
    "ObraConnectorValidationError",
    "ObraCredentials",
    "PollResult",
    "async_operation",
    "clear_registered_operations",
    "get_registered_operation",
    "get_registered_operations",
    "operation",
]

_EXPORTS = {
    "ApiKeyCredential": ("obra.connectors.credentials", "ApiKeyCredential"),
    "BearerTokenCredential": ("obra.connectors.credentials", "BearerTokenCredential"),
    "CredentialStore": ("obra.connectors.credentials", "CredentialStore"),
    "OAuth2Credential": ("obra.connectors.credentials", "OAuth2Credential"),
    "ObraCredentials": ("obra.connectors.credentials", "ObraCredentials"),
    "PollResult": ("obra.connectors.async_patterns", "PollResult"),
    "operation": ("obra.connectors.decorators", "operation"),
    "async_operation": ("obra.connectors.decorators", "async_operation"),
    "get_registered_operations": ("obra.connectors.decorators", "get_registered_operations"),
    "get_registered_operation": ("obra.connectors.decorators", "get_registered_operation"),
    "clear_registered_operations": ("obra.connectors.decorators", "clear_registered_operations"),
    "ObraConnectorError": ("obra.connectors.errors", "ObraConnectorError"),
    "ObraConnectorAuthError": ("obra.connectors.errors", "ObraConnectorAuthError"),
    "ObraConnectorRateLimitError": ("obra.connectors.errors", "ObraConnectorRateLimitError"),
    "ObraConnectorValidationError": ("obra.connectors.errors", "ObraConnectorValidationError"),
    "ObraConnectorNotFoundError": ("obra.connectors.errors", "ObraConnectorNotFoundError"),
    "ObraConnectorTransientError": ("obra.connectors.errors", "ObraConnectorTransientError"),
    "ObraConnectorPermanentError": ("obra.connectors.errors", "ObraConnectorPermanentError"),
}


def __getattr__(name: str) -> Any:
    try:
        module_name, attr_name = _EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(__all__)
