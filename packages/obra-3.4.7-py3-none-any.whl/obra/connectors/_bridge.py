"""Bridge connector decorators into runner catalog entries and stage runners."""

from __future__ import annotations

import inspect
import time
from collections.abc import Callable
from typing import Any

from obra.api.protocol import (
    PipelineStageRequest,
    PipelineStageResult,
    StageLoopSignal,
    StageRoutingSignal,
)
from obra.connectors.async_patterns import PollResult
from obra.connectors.credentials import CredentialStore, ObraCredentials
from obra.connectors.decorators import ConnectorOperationDefinition, get_registered_operation
from obra.connectors.errors import (
    ObraConnectorAuthError,
    ObraConnectorError,
    ObraConnectorNotFoundError,
    ObraConnectorPermanentError,
    ObraConnectorRateLimitError,
    ObraConnectorTransientError,
    ObraConnectorValidationError,
)
from obra.workflow.runner_catalog import (
    RUNNER_CATALOG_API_VERSION,
    RunnerCatalogEntry,
    RunnerCompatibility,
    RunnerKind,
    RunnerPortability,
    RunnerScope,
    RunnerSource,
    RunnerSourceType,
    RunnerActivation,
)


class ConnectorStageRunner:
    """Execute one registered connector operation."""

    def __init__(
        self,
        definition: ConnectorOperationDefinition,
        *,
        credential_store: CredentialStore | None = None,
    ) -> None:
        self._definition = definition
        self._credential_store = credential_store or CredentialStore()

    def execute(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Execute one sync or async connector operation."""
        start_time = time.time()
        try:
            result = self._execute_once(request)
            metadata = dict(result.metadata or {})
            metadata.setdefault("runner_kind", "python_runner")
            metadata.setdefault("connector", {"id": self._definition.operation_id})
            metadata["duration_s"] = time.time() - start_time
            result.metadata = metadata
            return result
        except ObraConnectorAuthError as exc:
            retried = False
            credentials_ref = request.context.credentials_ref
            if credentials_ref:
                credential = self._credential_store.get(credentials_ref)
                try:
                    credential.refresh()
                    retried = True
                except ObraConnectorAuthError:
                    retried = False
            if retried:
                try:
                    result = self._execute_once(request)
                    metadata = dict(result.metadata or {})
                    metadata["duration_s"] = time.time() - start_time
                    result.metadata = metadata
                    return result
                except ObraConnectorAuthError as final_exc:
                    return _connector_failure_result(request, final_exc, retried=True)
            return _connector_failure_result(request, exc, retried=False)
        except ObraConnectorError as exc:
            return _connector_failure_result(request, exc, retried=False)
        except Exception as exc:
            fallback = ObraConnectorPermanentError(
                f"Connector '{self._definition.operation_id}' raised {type(exc).__name__}: {exc}",
                recovery="Inspect the connector implementation and retry after fixing the error.",
            )
            return _connector_failure_result(request, fallback, retried=False)

    def _execute_once(self, request: PipelineStageRequest) -> PipelineStageResult:
        credentials = self._resolve_credentials(request)
        if self._definition.async_mode:
            result_payload = self._run_async(request, credentials)
        else:
            result_payload = self._invoke_sync(self._definition.function, request.content, credentials)
        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status="complete",
            outcome="passed",
            findings=[],
            routing_signal=StageRoutingSignal(recommended_action="continue"),
            loop_signal=StageLoopSignal(
                recommended_action="continue",
                current_iteration=request.iteration,
                max_iterations=request.max_iterations,
            ),
            runner_id=request.runner_id,
            runner_version=request.runner_version,
            runner_selector=request.runner_selector,
            metadata={
                "result": result_payload,
                "connector": {
                    "id": self._definition.operation_id,
                    "version": self._definition.version,
                    "provider_root": self._definition.provider_root,
                },
            },
        )

    def _resolve_credentials(self, request: PipelineStageRequest) -> ObraCredentials | None:
        credentials_ref = request.context.credentials_ref
        if not self._definition.requires_credentials:
            return None
        if not credentials_ref:
            raise ObraConnectorAuthError(
                f"Connector '{self._definition.operation_id}' requires a stage credentials reference",
                recovery="Set the stage 'credentials' field to a configured local credential name.",
            )
        credential = self._credential_store.get(credentials_ref)
        credential.refresh_if_needed()
        return credential

    def _invoke_sync(
        self,
        function: Callable[..., dict[str, Any]],
        inputs: dict[str, Any],
        credentials: ObraCredentials | None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {self._definition.start_param_name: inputs}
        if self._definition.credential_param_name is not None and credentials is not None:
            kwargs[self._definition.credential_param_name] = credentials
        result = function(**kwargs)
        if not isinstance(result, dict):
            msg = f"Connector '{self._definition.operation_id}' must return a dictionary payload"
            raise ObraConnectorValidationError(msg)
        return dict(result)

    def _run_async(
        self,
        request: PipelineStageRequest,
        credentials: ObraCredentials | None,
    ) -> dict[str, Any]:
        if self._definition.poll_function is None:
            msg = f"Async connector '{self._definition.operation_id}' is missing a poll callback"
            raise ObraConnectorValidationError(msg)
        state = self._invoke_sync(self._definition.function, request.content, credentials)
        deadline = time.time() + min(
            int(self._definition.poll_max_duration_s),
            int(request.timeout_s),
        )
        poll_function = self._definition.poll_function
        while time.time() < deadline:
            time.sleep(float(self._definition.poll_interval_s))
            if credentials is not None:
                credentials.refresh_if_needed()
            poll_result = self._invoke_poll(poll_function, state, credentials)
            if poll_result.is_done:
                return dict(poll_result.result or {})
            state = dict(poll_result.state or state)
        raise ObraConnectorTransientError(
            f"Async connector '{self._definition.operation_id}' exceeded poll timeout",
            recovery="Increase stage timeout_s or reduce poll_max_duration_s for this operation.",
        )

    def _invoke_poll(
        self,
        poll_function: Callable[..., PollResult],
        state: dict[str, Any],
        credentials: ObraCredentials | None,
    ) -> PollResult:
        signature = inspect.signature(poll_function)
        kwargs: dict[str, Any] = {}
        params = list(signature.parameters.values())
        if params:
            kwargs[params[0].name] = state
        if len(params) > 1 and credentials is not None:
            kwargs[params[1].name] = credentials
        result = poll_function(**kwargs)
        if not isinstance(result, PollResult):
            msg = f"Poll callback for '{self._definition.operation_id}' must return PollResult"
            raise ObraConnectorValidationError(msg)
        return result


def build_provider_catalog_entries(
    *,
    provider_root: str,
    package_name: str,
    source_type: RunnerSourceType | str = RunnerSourceType.PYTHON_PACKAGE,
    portability: RunnerPortability | str = RunnerPortability.PORTABLE,
    scope: RunnerScope | str = RunnerScope.SHARED,
    domain_ids: list[str] | None = None,
    factory_path: str,
) -> list[dict[str, Any]]:
    """Build runner catalog entries for one provider root package."""
    from obra.connectors.decorators import get_registered_operations

    entries: list[dict[str, Any]] = []
    for definition in get_registered_operations(provider_root):
        entry = RunnerCatalogEntry(
            id=definition.operation_id,
            display_name=definition.operation_id.replace(".", " ").title(),
            kind=RunnerKind.PYTHON_RUNNER,
            version=definition.version,
            scope=scope,
            domain_ids=tuple(domain_ids or ()),
            portability=portability,
            compatibility=RunnerCompatibility(
                catalog_api_version=RUNNER_CATALOG_API_VERSION,
            ),
            source=RunnerSource(
                source_type=source_type,
                package=package_name,
                module=definition.module_name,
            ),
            activation=RunnerActivation(factory=factory_path),
            description=definition.description or definition.summary or None,
            tags=tuple(
                tag
                for tag in [
                    "connector",
                    definition.auth_type or "",
                    "async" if definition.async_mode else "sync",
                ]
                if tag
            ),
        )
        entries.append(entry.to_dict())
    return entries


def build_stage_runner(request: PipelineStageRequest, *, provider_root: str) -> ConnectorStageRunner:
    """Resolve a registered operation into a stage runner."""
    definition = get_registered_operation(provider_root, request.runner_id, request.runner_version)
    return ConnectorStageRunner(definition)


def _connector_failure_result(
    request: PipelineStageRequest,
    error: ObraConnectorError,
    *,
    retried: bool,
) -> PipelineStageResult:
    action = "block"
    retry_with: dict[str, Any] = {}
    if isinstance(error, (ObraConnectorTransientError,)):
        action = "retry"
    if isinstance(error, ObraConnectorRateLimitError):
        action = "retry"
        if error.retry_after_s is not None:
            retry_with["retry_after_s"] = int(error.retry_after_s)
    if isinstance(error, (ObraConnectorValidationError, ObraConnectorNotFoundError, ObraConnectorPermanentError)):
        action = "block"
    if isinstance(error, ObraConnectorAuthError):
        action = "block"
    return PipelineStageResult(
        stage_name=request.stage_name,
        stage_execution_id=request.stage_execution_id,
        execution_status="failed",
        outcome="blocked" if action == "block" else "retryable",
        findings=[
            {
                "id": type(error).__name__,
                "title": "Connector execution failed",
                "description": str(error),
                "priority": "P1",
                "recovery": error.recovery,
            }
        ],
        routing_signal=StageRoutingSignal(
            recommended_action=action,
            reason=type(error).__name__,
        ),
        loop_signal=StageLoopSignal(
            recommended_action=action,
            reason=type(error).__name__,
            current_iteration=request.iteration,
            max_iterations=request.max_iterations,
            retry_with=retry_with,
        ),
        runner_id=request.runner_id,
        runner_version=request.runner_version,
        runner_selector=request.runner_selector,
        metadata={
            "connector_error": {
                "type": type(error).__name__,
                "message": str(error),
                "retried_auth_refresh": retried,
            }
        },
    )
