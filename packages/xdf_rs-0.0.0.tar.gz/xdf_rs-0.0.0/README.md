# xdf_rs DO NOT USE YET

Soon to be released python bindings for the [xdf](https://github.com/Garfield100/xdf_rs) Rust library.