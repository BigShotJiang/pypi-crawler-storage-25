# django-realtime-chat

Plugin Django de chat temps réel via WebSocket (Django Channels + JWT).

## Installation

```bash
pip install django-realtime-chat
```

## Configuration rapide

### 1. `settings.py`

```python
INSTALLED_APPS = [
    ...
    "channels",
    "rest_framework",
    "django_realtime_chat",
]

# Django Channels
ASGI_APPLICATION = "monprojet.asgi.application"

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {"hosts": [("127.0.0.1", 6379)]},
    }
}
```

### 2. `urls.py` du projet

```python
from django.urls import path, include

urlpatterns = [
    ...
    path("chat/", include("django_realtime_chat.urls")),
]
```

### 3. `asgi.py` du projet

```python
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from django_realtime_chat.routing import websocket_urlpatterns

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "monprojet.settings")

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(
        URLRouter(websocket_urlpatterns)
    ),
})
```

> **Authentification JWT** : passez `?token=<access_token>` dans l'URL WebSocket
> pour utiliser le middleware JWT fourni à la place de `AuthMiddlewareStack`.

### 4. Migrations

```bash
python manage.py migrate
```

## URLs disponibles

| URL | Nom | Description |
|-----|-----|-------------|
| `GET /chat/` | `django_realtime_chat:chat_home` | Interface principale |
| `GET /chat/start/<user_id>/` | `django_realtime_chat:start_conversation` | Démarre une conversation |
| `GET /chat/history/<conv_id>/` | `django_realtime_chat:message_history` | Historique JSON |
| `POST /chat/upload/` | `django_realtime_chat:file_upload` | Upload de fichier |
| `GET /chat/users/` | `django_realtime_chat:user_list` | Liste des utilisateurs JSON |

## WebSocket

```
ws://<host>/ws/chat/
```

Payload envoyé par le client :
```json
{ "message": "Bonjour !", "receiver_id": 42 }
```

Payload reçu :
```json
{
  "message": "Bonjour !",
  "sender_id": 1,
  "sender_username": "alice",
  "conversation_id": 7,
  "message_id": 123,
  "created_at": "2025-04-06T10:30:00.000Z"
}
```
