import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model

User = get_user_model()


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]

        if not self.user or not self.user.is_authenticated:
            await self.close()
            return

        # Groupe personnel de l'utilisateur (pour recevoir les messages entrants)
        self.user_group = f"user_{self.user.id}"
        await self.channel_layer.group_add(self.user_group, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, "user_group"):
            await self.channel_layer.group_discard(self.user_group, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        message_text = data.get("message", "").strip()
        receiver_id = data.get("receiver_id")

        if not message_text or not receiver_id:
            return

        # Sauvegarder le message en base de données
        msg = await self.save_message(receiver_id, message_text)
        if not msg:
            return

        payload = {
            "type": "chat_message",
            "message": message_text,
            "sender_id": self.user.id,
            "sender_username": self.user.username,
            "conversation_id": msg["conversation_id"],
            "message_id": msg["id"],
            "created_at": msg["created_at"],
        }

        # Envoyer au destinataire (son groupe personnel)
        await self.channel_layer.group_send(f"user_{receiver_id}", payload)

        # Envoyer en écho à l'expéditeur
        await self.channel_layer.group_send(self.user_group, payload)

    async def chat_message(self, event):
        """Handler appelé quand un message arrive dans le groupe."""
        await self.send(text_data=json.dumps({
            "message": event["message"],
            "sender_id": event["sender_id"],
            "sender_username": event["sender_username"],
            "conversation_id": event["conversation_id"],
            "message_id": event["message_id"],
            "created_at": event["created_at"],
        }))

    @database_sync_to_async
    def save_message(self, receiver_id, content):
        from .models import Conversation, Message

        try:
            receiver = User.objects.get(id=receiver_id)
        except User.DoesNotExist:
            return None

        conv, _ = Conversation.objects.get_or_create_between(self.user, receiver)

        # Mettre à jour updated_at de la conversation
        conv.save()

        msg = Message.objects.create(
            conversation=conv,
            sender=self.user,
            content=content,
        )
        return {
            "id": msg.id,
            "conversation_id": conv.id,
            "created_at": msg.created_at.isoformat(),
        }
