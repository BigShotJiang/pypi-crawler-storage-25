default_app_config = "django_realtime_chat.apps.DjangoRealtimeChatConfig"
