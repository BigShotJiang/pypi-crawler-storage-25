from urllib.parse import parse_qs
from django.contrib.auth.models import AnonymousUser
from django.contrib.auth import get_user_model
from channels.db import database_sync_to_async

User = get_user_model()


@database_sync_to_async
def get_user_from_token(token_str):
    """Résout un JWT SimpleJWT ou un token de session Django."""
    try:
        from rest_framework_simplejwt.tokens import AccessToken
        access_token = AccessToken(token_str)
        user_id = access_token["user_id"]
        return User.objects.get(id=user_id)
    except Exception:
        return AnonymousUser()


class JWTAuthMiddleware:
    """
    Middleware WebSocket qui authentifie via :
      - JWT SimpleJWT passé en query string : ?token=<access_token>
      - Session Django classique (si channels est configuré avec SessionMiddlewareStack)
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        # Si l'utilisateur est déjà résolu (ex: SessionMiddleware en amont)
        if scope.get("user") and not isinstance(scope["user"], AnonymousUser):
            return await self.app(scope, receive, send)

        query_params = parse_qs(scope.get("query_string", b"").decode())
        token_list = query_params.get("token")

        if token_list:
            scope["user"] = await get_user_from_token(token_list[0])
        else:
            scope.setdefault("user", AnonymousUser())

        return await self.app(scope, receive, send)
