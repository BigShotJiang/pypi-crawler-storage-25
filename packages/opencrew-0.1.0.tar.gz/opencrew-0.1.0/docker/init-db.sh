#!/bin/bash
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE DATABASE letta;
    GRANT ALL PRIVILEGES ON DATABASE letta TO opencrew;
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname=letta <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS vector;
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname=opencrew <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS vector;
EOSQL
