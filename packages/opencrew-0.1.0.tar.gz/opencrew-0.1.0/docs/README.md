# OpenCrew CLI documentation

Index for the open-source `opencrew` package. The canonical quickstart remains the [project README](../README.md).

| Doc | Description |
|-----|-------------|
| [Quickstart](../README.md#quickstart) | Install, `opencrew init`, first run |
| [Architecture](../README.md#architecture) | CLI → FastAPI → Letta Code SDK → Letta server; Postgres roles |
| **CLI commands** | Use `opencrew --help` and `opencrew <cmd> --help` (Typer); reference TO BE expanded per command in this folder |
| **SDK** | `opencrew.sdk` — `OpenCrew`, `AsyncOpenCrew`, streaming helpers (`../opencrew/sdk/`) |
| **Agent config** | `agent.yaml` beside each agent directory; skills under `skills/` |
| **Testing** | `opencrew test` — YAML scenarios under `tests/` |
| **Troubleshooting** | Verify `LETTA_BASE_URL`, Node 20+, and Docker services from `opencrew init` |

## Related: OpenCrew Cloud

Hosted backend adds **workspace BYO Letta** via an HTTP API (not the Neon Data API). OSS CLI continues to use **environment and config** for Letta endpoints.

## `~/.opencrew/config.yaml` layout

Settings are grouped for clarity:

| Block | Purpose |
|--------|--------|
| **`local`** | Local dev stack: `db_url`, `letta_url`, `api_url` (default `http://localhost:8741`), `api_key` (local dev key), optional `anthropic_api_key` / `openai_api_key` for Letta. |
| **`remote`** | Hosted OpenCrew: `api_url`, `api_key` (workspace key). Optional `letta_base_url` / `letta_api_token` if you use BYO/self-hosted Letta and want them stored for tooling. |

The Python SDK and CLI call **`remote`** when both `api_url` and `api_key` are set; otherwise they use **`local`**. Legacy flat keys (pre-nested file) are migrated automatically on load.

## Security

Do not commit real API keys. Examples use placeholders such as `<your-workspace-api-key>`. Prefer environment variables for Anthropic/OpenAI keys in CI.
