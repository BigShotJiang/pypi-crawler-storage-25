from __future__ import annotations

import json
import logging
from typing import Any
from uuid import UUID

from opencrew.store.catalog import (
    get_agent_type,
    get_runtime_skill_rows,
    get_runtime_custom_tool_rows,
    get_runtime_mcp_server_rows,
)
from opencrew.types import (
    RuntimeBundle,
    RuntimeCustomTool,
    RuntimeMcpServer,
    RuntimeSkill,
    RuntimeSkillAsset,
    SessionOptions,
)

logger = logging.getLogger(__name__)


def _rows_to_runtime_skills(rows: list[dict]) -> list[RuntimeSkill]:
    skills: list[RuntimeSkill] = []
    for row in rows:
        files: list[RuntimeSkillAsset] = []
        skill_md = row.get("skill_md")
        if skill_md:
            files.append(RuntimeSkillAsset(path="SKILL.md", content=skill_md))
        bundle_json = row.get("bundle_json")
        if isinstance(bundle_json, str):
            bundle_json = json.loads(bundle_json)
        if isinstance(bundle_json, dict):
            for path, content in bundle_json.items():
                if path != "SKILL.md":
                    files.append(RuntimeSkillAsset(path=path, content=content))

        skills.append(
            RuntimeSkill(
                skill_id=row["skill_id"],
                skill_version_id=row["skill_version_id"],
                slug=row["skill_slug"],
                version=row.get("skill_version", "v1"),
                files=files,
            )
        )
    return skills


def _rows_to_runtime_custom_tools(rows: list[dict]) -> list[RuntimeCustomTool]:
    return [
        RuntimeCustomTool(
            custom_tool_id=row["custom_tool_id"],
            name=row["name"],
            slug=row["slug"],
            source_code=row["source_code"],
            source_type=row.get("source_type", "python"),
            args_json_schema=row.get("args_json_schema"),
            letta_tool_id=row.get("letta_tool_id"),
        )
        for row in rows
    ]


def _rows_to_runtime_mcp_servers(rows: list[dict]) -> list[RuntimeMcpServer]:
    result: list[RuntimeMcpServer] = []
    for row in rows:
        custom_headers = row.get("custom_headers")
        if isinstance(custom_headers, str):
            custom_headers = json.loads(custom_headers)
        args = row.get("args")
        if isinstance(args, str):
            args = json.loads(args)
        env = row.get("env")
        if isinstance(env, str):
            env = json.loads(env)
        result.append(
            RuntimeMcpServer(
                custom_mcp_server_id=row["custom_mcp_server_id"],
                name=row["name"],
                slug=row["slug"],
                server_url=row.get("server_url") or "",
                server_type=row.get("server_type", "streamable_http"),
                transport=row.get("transport", "streamable_http"),
                auth_header=row.get("auth_header"),
                auth_token=row.get("auth_token"),
                custom_headers=custom_headers,
                command=row.get("command"),
                args=args,
                env=env,
            )
        )
    return result


def build_runtime_bundle(
    run_id: str,
    owner_id: str,
    agent_type_id: str | UUID | None,
    *,
    entity_id: str | None = None,
    client_id: str | None = None,
    session_options: SessionOptions | None = None,
) -> RuntimeBundle:
    """Assemble a RuntimeBundle for a run by loading skills, tools, and MCP servers."""
    so = session_options or SessionOptions()
    model: str | None = None
    skills: list[RuntimeSkill] = []
    custom_tools: list[RuntimeCustomTool] = []
    custom_mcp_servers: list[RuntimeMcpServer] = []
    skill_manifest: dict[str, Any] = {}

    at_id = str(agent_type_id) if agent_type_id else None

    if at_id:
        agent_type_row = get_agent_type(at_id, owner_id)
        if agent_type_row:
            model = agent_type_row.get("model") or None

        skill_rows = get_runtime_skill_rows(at_id)
        skills = _rows_to_runtime_skills(skill_rows)

        tool_rows = get_runtime_custom_tool_rows(at_id, owner_id)
        custom_tools = _rows_to_runtime_custom_tools(tool_rows)

        mcp_rows = get_runtime_mcp_server_rows(at_id, owner_id)
        custom_mcp_servers = _rows_to_runtime_mcp_servers(mcp_rows)

        skill_manifest = {
            "skills": [
                {"slug": s.slug, "version": s.version, "file_count": len(s.files)}
                for s in skills
            ],
            "custom_tools": [{"slug": t.slug, "name": t.name} for t in custom_tools],
            "custom_mcp_servers": [
                {"slug": s.slug, "name": s.name} for s in custom_mcp_servers
            ],
        }

    return RuntimeBundle(
        run_id=run_id,
        owner_id=owner_id,
        entity_id=entity_id,
        client_id=client_id,
        agent_type_id=agent_type_id,
        model=model,
        skills=skills,
        skill_manifest=skill_manifest,
        session_options=so,
        custom_tools=custom_tools,
        custom_mcp_servers=custom_mcp_servers,
    )
