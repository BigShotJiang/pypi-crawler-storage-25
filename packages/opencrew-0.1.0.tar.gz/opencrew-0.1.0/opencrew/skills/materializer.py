from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from opencrew.types import RuntimeSkill

SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class SkillValidationError(ValueError):
    pass


def _parse_frontmatter(skill_md: str) -> tuple[dict[str, str], str]:
    lines = skill_md.splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        raise SkillValidationError("SKILL.md must start with YAML frontmatter")

    end_index = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_index = idx
            break
    if end_index is None:
        raise SkillValidationError("SKILL.md frontmatter is not terminated")

    frontmatter_lines = lines[1:end_index]
    body = "\n".join(lines[end_index + 1:]).strip()
    metadata: dict[str, str] = {}
    for raw in frontmatter_lines:
        if ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        metadata[key.strip()] = value.strip().strip('"').strip("'")
    return metadata, body


def validate_skill_markdown(
    skill_md: str, expected_slug: str | None = None
) -> dict[str, Any]:
    metadata, body = _parse_frontmatter(skill_md)
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    if not name:
        raise SkillValidationError("Skill frontmatter requires `name`")
    if not SKILL_NAME_RE.match(name):
        raise SkillValidationError(
            "Skill `name` must be lowercase letters, numbers, and hyphens"
        )
    if len(name) > 64:
        raise SkillValidationError("Skill `name` must be 64 characters or fewer")
    if expected_slug and name != expected_slug:
        raise SkillValidationError("Skill frontmatter `name` must match skill slug")
    if not description:
        raise SkillValidationError("Skill frontmatter requires `description`")
    if len(description) > 1024:
        raise SkillValidationError(
            "Skill `description` must be 1024 characters or fewer"
        )
    if not body:
        raise SkillValidationError("SKILL.md body must not be empty")

    return {
        "name": name,
        "description": description,
        "body_preview": body[:120],
    }


def _safe_join(root: Path, relative_path: str) -> Path:
    full_path = (root / relative_path).resolve()
    if not str(full_path).startswith(str(root.resolve())):
        raise SkillValidationError("Skill asset path escapes skill directory")
    return full_path


def materialize_skills(run_id: str, skills: list[RuntimeSkill]) -> str:
    """Write skill files to disk and return the workspace root path.

    Creates ``/tmp/opencrew_runs/{run_id}/workspace/.skills/`` and populates
    each skill's subdirectory with its files.
    """
    run_root = Path("/tmp/opencrew_runs") / run_id / "workspace"
    skills_root = run_root / ".skills"
    skills_root.mkdir(parents=True, exist_ok=True)

    for skill in skills:
        skill_md_asset = next(
            (asset for asset in skill.files if asset.path == "SKILL.md"), None
        )
        if skill_md_asset is None:
            raise SkillValidationError(
                "Each materialized skill requires a SKILL.md file"
            )
        validate_skill_markdown(skill_md_asset.content, expected_slug=skill.slug)

        skill_dir = skills_root / skill.slug
        skill_dir.mkdir(parents=True, exist_ok=True)
        for asset in skill.files:
            target = _safe_join(skill_dir, asset.path)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("w", encoding="utf-8") as f:
                f.write(asset.content)

    return os.fspath(run_root)
