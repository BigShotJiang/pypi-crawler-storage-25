"""Readable errors for failed HTTP API calls."""

from __future__ import annotations

import json

import httpx


def humanize_api_error(resp: httpx.Response) -> str:
    """Short, user-facing line from OpenCrew/FastAPI JSON (``detail`` dict or string)."""
    code = resp.status_code
    try:
        data = resp.json()
    except Exception:
        text = (resp.text or "").strip()
        if len(text) > 500:
            text = text[:500] + "…"
        return f"HTTP {code}: {text}" if text else f"HTTP {code}"
    detail = data.get("detail")
    if isinstance(detail, str):
        return f"HTTP {code}: {detail}"
    if isinstance(detail, dict):
        msg = detail.get("message")
        err = detail.get("error")
        req = detail.get("request_id")
        parts: list[str] = [f"HTTP {code}"]
        if isinstance(msg, str) and msg.strip():
            parts.append(msg.strip())
        elif err:
            parts.append(str(err))
        line = ": ".join(parts) if len(parts) > 1 else parts[0]
        if req:
            line = f"{line} [request_id={req}]"
        return line
    if isinstance(detail, list):
        return f"HTTP {code}: validation failed ({len(detail)} issue(s))"
    text = (resp.text or "").strip()
    if len(text) > 500:
        text = text[:500] + "…"
    if text:
        return f"HTTP {code}: {text}"
    return f"HTTP {code}"


def format_api_error(resp: httpx.Response, *, max_body: int = 6000) -> str:
    """Build a message suitable for HTTPStatusError (includes URL, status, and body snippet)."""
    req = resp.request
    line = f"HTTP {resp.status_code} for {req.method} {req.url}"
    body = ""
    try:
        data = resp.json()
        body = json.dumps(data, indent=2)
    except Exception:
        body = (resp.text or "").strip()
    if len(body) > max_body:
        body = body[:max_body] + "\n…"
    return f"{line}\n{body}" if body else line


def raise_for_api(resp: httpx.Response) -> None:
    """Like ``raise_for_status()`` but attach response JSON/text to the exception message."""
    if resp.is_success:
        return
    raise httpx.HTTPStatusError(format_api_error(resp), request=resp.request, response=resp)
