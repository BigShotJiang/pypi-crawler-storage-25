"""Apply agent YAML via standard /v1 routes when ``POST /v1/agent-types/apply`` is unavailable."""

from __future__ import annotations

import re
from typing import Any

import httpx


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")
    return s or "agent"


def _normalize_toolkits_list(raw: list[Any] | None) -> list[str]:
    if not raw:
        return []
    return sorted({str(x).strip().lower() for x in raw if str(x).strip()})


def _merged_memory_defaults(config: dict[str, Any], required_toolkits: list[str]) -> dict[str, Any]:
    """Single document stored on the agent type: rules + normalized Composio toolkit slugs."""
    raw = config.get("memory_defaults")
    if raw is not None and not isinstance(raw, dict):
        raise ValueError("memory_defaults must be a mapping")
    md = dict(raw or {})
    md["required_toolkits"] = required_toolkits
    md["toolkit_slugs"] = required_toolkits
    return md


def _required_toolkits_from_config(config: dict[str, Any]) -> list[str]:
    rt = config.get("required_toolkits")
    if rt is not None:
        if not isinstance(rt, list):
            return []
        return _normalize_toolkits_list(rt)
    md = config.get("memory_defaults") or {}
    if not isinstance(md, dict):
        return []
    inner = md.get("required_toolkits")
    return _normalize_toolkits_list(inner if isinstance(inner, list) else [])


def _instructions_from_skill_md(skill_md: str) -> str:
    md = (skill_md or "").strip()
    if md.startswith("---"):
        parts = md.split("---", 2)
        if len(parts) >= 3:
            return parts[2].strip()
    return md


def _capability_bindings_for_skill(skill_spec: dict[str, Any]) -> list[dict[str, Any]]:
    toolkits = skill_spec.get("toolkits") or []
    if not isinstance(toolkits, list):
        return []
    bindings: list[dict[str, Any]] = []
    for tk in toolkits:
        t = str(tk).strip().lower()
        if not t:
            continue
        bindings.append(
            {
                "capability_key": f"use_{t.replace('-', '_')}_toolkit",
                "capability_label": f"Use {t} toolkit",
                "toolkit_slug": t,
                "tool_slug": None,
                "arguments_schema_json": {"source": "agent_yaml"},
                "priority": "normal",
            }
        )
    return bindings


def _merge_apply_style_result(
    agent_type: dict[str, Any],
    *,
    tools_synced: int,
    mcp_synced: int,
    skills_synced: int,
    warnings: list[str],
) -> dict[str, Any]:
    out: dict[str, Any] = dict(agent_type)
    if tools_synced:
        out["tools_synced"] = tools_synced
    if mcp_synced:
        out["mcp_servers_synced"] = mcp_synced
    if skills_synced:
        out["skills_synced"] = skills_synced
    if warnings:
        out["warnings"] = warnings
    out.setdefault(
        "apply_mode",
        "multi_request (server has no POST /v1/agent-types/apply)",
    )
    return out


def _upsert_agent_type_via_api(
    http: httpx.Client,
    *,
    body: dict[str, Any],
    resolved_slug: str,
    full_memory_defaults: dict[str, Any],
) -> dict[str, Any]:
    """Create agent type or update by slug when the row already exists (avoids slug 409)."""
    get_r = http.get(f"/v1/agent-types/{resolved_slug}")
    if get_r.status_code == 200:
        patch: dict[str, Any] = {"memory_defaults": full_memory_defaults}
        for key in ("name", "description", "persona", "system_prompt", "model"):
            val = body.get(key)
            if val is not None:
                patch[key] = val
        pr = http.patch(f"/v1/agent-types/{resolved_slug}", json=patch)
        pr.raise_for_status()
        return pr.json()
    if get_r.status_code != 404:
        get_r.raise_for_status()

    r = http.post("/v1/agent-types", json=body)
    if r.status_code == 409:
        patch: dict[str, Any] = {"memory_defaults": full_memory_defaults}
        for key in ("name", "description", "persona", "system_prompt", "model"):
            val = body.get(key)
            if val is not None:
                patch[key] = val
        pr = http.patch(f"/v1/agent-types/{resolved_slug}", json=patch)
        pr.raise_for_status()
        return pr.json()

    r.raise_for_status()
    return r.json()


async def _upsert_agent_type_via_api_async(
    http: httpx.AsyncClient,
    *,
    body: dict[str, Any],
    resolved_slug: str,
    full_memory_defaults: dict[str, Any],
) -> dict[str, Any]:
    get_r = await http.get(f"/v1/agent-types/{resolved_slug}")
    if get_r.status_code == 200:
        patch: dict[str, Any] = {"memory_defaults": full_memory_defaults}
        for key in ("name", "description", "persona", "system_prompt", "model"):
            val = body.get(key)
            if val is not None:
                patch[key] = val
        pr = await http.patch(f"/v1/agent-types/{resolved_slug}", json=patch)
        pr.raise_for_status()
        return pr.json()
    if get_r.status_code != 404:
        get_r.raise_for_status()

    r = await http.post("/v1/agent-types", json=body)
    if r.status_code == 409:
        patch: dict[str, Any] = {"memory_defaults": full_memory_defaults}
        for key in ("name", "description", "persona", "system_prompt", "model"):
            val = body.get(key)
            if val is not None:
                patch[key] = val
        pr = await http.patch(f"/v1/agent-types/{resolved_slug}", json=patch)
        pr.raise_for_status()
        return pr.json()

    r.raise_for_status()
    return r.json()


def apply_without_apply_route(http: httpx.Client, config: dict[str, Any]) -> dict[str, Any]:
    """Mirror server apply using only public v1 endpoints (sync)."""
    warnings: list[str] = []

    name = str(config.get("name") or "Unnamed").strip() or "Unnamed"
    slug_raw = config.get("slug")
    resolved_slug = (str(slug_raw).strip() if slug_raw else None) or _slug(name)

    required_toolkits = _required_toolkits_from_config(config)
    full_md = _merged_memory_defaults(config, required_toolkits)

    body: dict[str, Any] = {
        "name": name,
        "slug": resolved_slug,
        "description": config.get("description"),
        "persona": config.get("persona"),
        "system_prompt": config.get("system_prompt"),
        "model": config.get("model"),
        "required_toolkits": required_toolkits,
        "memory_defaults": full_md,
    }

    agent_type = _upsert_agent_type_via_api(
        http,
        body=body,
        resolved_slug=resolved_slug,
        full_memory_defaults=full_md,
    )
    slug = str(agent_type.get("slug") or resolved_slug)

    tools_synced = 0
    for tool_spec in config.get("tools") or []:
        if not isinstance(tool_spec, dict):
            continue
        tool_slug = tool_spec.get("slug") or _slug(str(tool_spec.get("name") or "tool"))
        t_body: dict[str, Any] = {
            "name": str(tool_spec.get("name") or tool_slug),
            "slug": tool_slug,
            "source_code": str(tool_spec.get("source_code") or ""),
            "source_type": str(tool_spec.get("source_type", "python")),
        }
        if tool_spec.get("description") is not None:
            t_body["description"] = tool_spec["description"]
        if tool_spec.get("args_json_schema") is not None:
            t_body["args_json_schema"] = tool_spec["args_json_schema"]
        tr = http.post("/v1/custom-tools", json=t_body)
        tr.raise_for_status()
        tool = tr.json()
        ar = http.post(
            f"/v1/agent-types/{slug}/tools",
            json={"custom_tool_id": str(tool["id"])},
        )
        ar.raise_for_status()
        tools_synced += 1

    mcp_synced = 0
    for srv_spec in config.get("mcp_servers") or []:
        if not isinstance(srv_spec, dict):
            continue
        srv_slug = srv_spec.get("slug") or _slug(str(srv_spec.get("name") or "mcp"))
        transport = str(srv_spec.get("transport") or "streamable_http").lower()
        server_url = str(srv_spec.get("server_url") or "").strip()
        command = srv_spec.get("command")
        if not server_url and (command or transport == "stdio"):
            warnings.append(
                f"MCP '{srv_spec.get('name', srv_slug)}': stdio/local MCP not supported on this API; "
                "use a streamable HTTP or SSE server_url."
            )
            continue
        if not server_url:
            warnings.append(f"MCP '{srv_spec.get('name', srv_slug)}': missing server_url; skipped")
            continue
        server_type = str(srv_spec.get("server_type") or transport)
        m_body: dict[str, Any] = {
            "name": str(srv_spec.get("name") or srv_slug),
            "slug": srv_slug,
            "server_url": server_url,
            "server_type": server_type,
        }
        for opt in ("auth_header", "auth_token", "custom_headers", "description"):
            if srv_spec.get(opt) is not None:
                m_body[opt] = srv_spec[opt]
        mr = http.post("/v1/mcp-servers", json=m_body)
        mr.raise_for_status()
        srv = mr.json()
        ar = http.post(
            f"/v1/agent-types/{slug}/mcp-servers",
            json={"custom_mcp_server_id": str(srv["id"])},
        )
        ar.raise_for_status()
        mcp_synced += 1

    skills_synced = 0
    for skill_spec in config.get("skills") or []:
        if not isinstance(skill_spec, dict):
            continue
        skill_slug = skill_spec.get("slug") or _slug(str(skill_spec.get("name") or "skill"))
        skill_slug = str(skill_slug).strip().lower()
        skill_name = str(skill_spec.get("name") or skill_slug)

        resolved = skill_spec.get("_resolved_files")
        if resolved and isinstance(resolved, dict):
            skill_md = str(resolved.get("SKILL.md") or "")
            bundle_json = {k: v for k, v in resolved.items() if k != "SKILL.md"}
            description = str(skill_spec.get("description") or "")
            if not description and skill_md:
                for line in skill_md.splitlines():
                    if line.startswith("description:"):
                        description = line.split(":", 1)[1].strip().strip("'\"")
                        break
            if bundle_json:
                warnings.append(
                    f"Skill '{skill_slug}': extra files beside SKILL.md were not uploaded "
                    f"({', '.join(bundle_json.keys())}); use a server with POST /v1/agent-types/apply "
                    "or fold assets into SKILL.md."
                )
        else:
            skill_md = (
                f"---\nname: {skill_slug}\ndescription: {skill_spec.get('description', skill_slug)}\n"
                f"---\n\n{skill_spec.get('instructions', '')}\n"
            )
            description = str(skill_spec.get("description") or "")

        instructions = _instructions_from_skill_md(skill_md)
        if not instructions.strip():
            warnings.append(f"Skill '{skill_slug}': empty body; skipped")
            continue

        bindings = _capability_bindings_for_skill(skill_spec)
        sr = http.post(
            "/v1/skills",
            json={
                "slug": skill_slug,
                "name": skill_name,
                "description": description or f"Skill for {skill_name}",
                "instructions": instructions,
                "capability_bindings": bindings,
            },
        )
        sr.raise_for_status()
        created = sr.json()
        skill_row = created.get("skill") or created
        version_row = created.get("version") or {}
        sid = skill_row.get("id")
        vid = version_row.get("id")
        if not sid or not vid:
            warnings.append(f"Skill '{skill_slug}': unexpected API response; skipped attach")
            continue
        ar = http.post(
            f"/v1/agent-types/{slug}/skills",
            json={"skill_id": str(sid), "skill_version_id": str(vid)},
        )
        ar.raise_for_status()
        skills_synced += 1

    return _merge_apply_style_result(
        agent_type,
        tools_synced=tools_synced,
        mcp_synced=mcp_synced,
        skills_synced=skills_synced,
        warnings=warnings,
    )


async def apply_without_apply_route_async(
    http: httpx.AsyncClient, config: dict[str, Any]
) -> dict[str, Any]:
    """Same as :func:`apply_without_apply_route` for async clients."""
    warnings: list[str] = []

    name = str(config.get("name") or "Unnamed").strip() or "Unnamed"
    slug_raw = config.get("slug")
    resolved_slug = (str(slug_raw).strip() if slug_raw else None) or _slug(name)

    required_toolkits = _required_toolkits_from_config(config)
    full_md = _merged_memory_defaults(config, required_toolkits)

    body: dict[str, Any] = {
        "name": name,
        "slug": resolved_slug,
        "description": config.get("description"),
        "persona": config.get("persona"),
        "system_prompt": config.get("system_prompt"),
        "model": config.get("model"),
        "required_toolkits": required_toolkits,
        "memory_defaults": full_md,
    }

    agent_type = await _upsert_agent_type_via_api_async(
        http,
        body=body,
        resolved_slug=resolved_slug,
        full_memory_defaults=full_md,
    )
    slug = str(agent_type.get("slug") or resolved_slug)

    tools_synced = 0
    for tool_spec in config.get("tools") or []:
        if not isinstance(tool_spec, dict):
            continue
        tool_slug = tool_spec.get("slug") or _slug(str(tool_spec.get("name") or "tool"))
        t_body: dict[str, Any] = {
            "name": str(tool_spec.get("name") or tool_slug),
            "slug": tool_slug,
            "source_code": str(tool_spec.get("source_code") or ""),
            "source_type": str(tool_spec.get("source_type", "python")),
        }
        if tool_spec.get("description") is not None:
            t_body["description"] = tool_spec["description"]
        if tool_spec.get("args_json_schema") is not None:
            t_body["args_json_schema"] = tool_spec["args_json_schema"]
        tr = await http.post("/v1/custom-tools", json=t_body)
        tr.raise_for_status()
        tool = tr.json()
        ar = await http.post(
            f"/v1/agent-types/{slug}/tools",
            json={"custom_tool_id": str(tool["id"])},
        )
        ar.raise_for_status()
        tools_synced += 1

    mcp_synced = 0
    for srv_spec in config.get("mcp_servers") or []:
        if not isinstance(srv_spec, dict):
            continue
        srv_slug = srv_spec.get("slug") or _slug(str(srv_spec.get("name") or "mcp"))
        transport = str(srv_spec.get("transport") or "streamable_http").lower()
        server_url = str(srv_spec.get("server_url") or "").strip()
        command = srv_spec.get("command")
        if not server_url and (command or transport == "stdio"):
            warnings.append(
                f"MCP '{srv_spec.get('name', srv_slug)}': stdio/local MCP not supported on this API; "
                "use a streamable HTTP or SSE server_url."
            )
            continue
        if not server_url:
            warnings.append(f"MCP '{srv_spec.get('name', srv_slug)}': missing server_url; skipped")
            continue
        server_type = str(srv_spec.get("server_type") or transport)
        m_body: dict[str, Any] = {
            "name": str(srv_spec.get("name") or srv_slug),
            "slug": srv_slug,
            "server_url": server_url,
            "server_type": server_type,
        }
        for opt in ("auth_header", "auth_token", "custom_headers", "description"):
            if srv_spec.get(opt) is not None:
                m_body[opt] = srv_spec[opt]
        mr = await http.post("/v1/mcp-servers", json=m_body)
        mr.raise_for_status()
        srv = mr.json()
        ar = await http.post(
            f"/v1/agent-types/{slug}/mcp-servers",
            json={"custom_mcp_server_id": str(srv["id"])},
        )
        ar.raise_for_status()
        mcp_synced += 1

    skills_synced = 0
    for skill_spec in config.get("skills") or []:
        if not isinstance(skill_spec, dict):
            continue
        skill_slug = skill_spec.get("slug") or _slug(str(skill_spec.get("name") or "skill"))
        skill_slug = str(skill_slug).strip().lower()
        skill_name = str(skill_spec.get("name") or skill_slug)

        resolved = skill_spec.get("_resolved_files")
        if resolved and isinstance(resolved, dict):
            skill_md = str(resolved.get("SKILL.md") or "")
            bundle_json = {k: v for k, v in resolved.items() if k != "SKILL.md"}
            description = str(skill_spec.get("description") or "")
            if not description and skill_md:
                for line in skill_md.splitlines():
                    if line.startswith("description:"):
                        description = line.split(":", 1)[1].strip().strip("'\"")
                        break
            if bundle_json:
                warnings.append(
                    f"Skill '{skill_slug}': extra files beside SKILL.md were not uploaded "
                    f"({', '.join(bundle_json.keys())}); use POST /v1/agent-types/apply or fold into SKILL.md."
                )
        else:
            skill_md = (
                f"---\nname: {skill_slug}\ndescription: {skill_spec.get('description', skill_slug)}\n"
                f"---\n\n{skill_spec.get('instructions', '')}\n"
            )
            description = str(skill_spec.get("description") or "")

        instructions = _instructions_from_skill_md(skill_md)
        if not instructions.strip():
            warnings.append(f"Skill '{skill_slug}': empty body; skipped")
            continue

        bindings = _capability_bindings_for_skill(skill_spec)
        sr = await http.post(
            "/v1/skills",
            json={
                "slug": skill_slug,
                "name": skill_name,
                "description": description or f"Skill for {skill_name}",
                "instructions": instructions,
                "capability_bindings": bindings,
            },
        )
        sr.raise_for_status()
        created = sr.json()
        skill_row = created.get("skill") or created
        version_row = created.get("version") or {}
        sid = skill_row.get("id")
        vid = version_row.get("id")
        if not sid or not vid:
            warnings.append(f"Skill '{skill_slug}': unexpected API response; skipped attach")
            continue
        ar = await http.post(
            f"/v1/agent-types/{slug}/skills",
            json={"skill_id": str(sid), "skill_version_id": str(vid)},
        )
        ar.raise_for_status()
        skills_synced += 1

    return _merge_apply_style_result(
        agent_type,
        tools_synced=tools_synced,
        mcp_synced=mcp_synced,
        skills_synced=skills_synced,
        warnings=warnings,
    )
