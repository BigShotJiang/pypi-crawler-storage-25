from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Iterator, AsyncIterator
import httpx

@dataclass
class RunStreamEvent:
    type: str
    seq: int | None = None
    content: str = ""
    payload: dict = field(default_factory=dict)


def _flatten_content_value(value: object) -> str:
    """Turn Letta/OpenAI-style ``content`` (str, block list, or nested dict) into plain text."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(_flatten_content_value(p) for p in value)
    if isinstance(value, dict):
        t = value.get("text")
        if isinstance(t, str):
            return t
        inner = value.get("content")
        if inner is not None and inner != value:
            return _flatten_content_value(inner)
        return ""
    return ""


def payload_assistant_text(payload: dict) -> str:
    """Normalize Letta/OpenAI message or event payload to plain text."""
    if not isinstance(payload, dict):
        return ""
    t = payload.get("text")
    if isinstance(t, str):
        return t
    c = payload.get("content")
    if c is None:
        return ""
    return _flatten_content_value(c)


def assistant_text_from_run_result(res_data: dict) -> str:
    """Collect assistant text from ``result``, ``messages``, ``steps``, or ``reasoning`` (run / poll payload)."""
    direct = res_data.get("result")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    if isinstance(direct, dict):
        flat = payload_assistant_text(direct)
        if flat.strip():
            return flat.strip()
    messages = res_data.get("messages") or []
    lines: list[str] = []
    for m in messages:
        if isinstance(m, str) and m.strip():
            lines.append(m)
        elif isinstance(m, dict):
            piece = payload_assistant_text(m)
            if piece.strip():
                lines.append(piece.strip())
    if lines:
        return "\n".join(lines)
    joined = "".join(m for m in messages if isinstance(m, str))
    if joined.strip():
        return joined.strip()
    chunks: list[str] = []
    for step in res_data.get("steps") or []:
        if not isinstance(step, dict):
            continue
        if step.get("type") == "assistant":
            piece = payload_assistant_text(step)
            if piece:
                chunks.append(piece)
    if chunks:
        return "".join(chunks)
    reasoning = res_data.get("reasoning") or []
    rlines: list[str] = []
    for r in reasoning:
        if isinstance(r, str) and r.strip():
            rlines.append(r.strip())
    if rlines:
        return "\n".join(rlines)
    return ""


def parse_sse_stream(response: httpx.Response) -> Iterator[RunStreamEvent]:
    """Parse Server-Sent Events from an httpx streaming response."""
    event_type = ""
    event_id = None
    data_lines: list[str] = []

    for line in response.iter_lines():
        if line.startswith("event: "):
            event_type = line[7:]
        elif line.startswith("id: "):
            try:
                event_id = int(line[4:])
            except ValueError:
                event_id = None
        elif line.startswith("data: "):
            data_lines.append(line[6:])
        elif line == "":
            if event_type or data_lines:
                data_str = "\n".join(data_lines)
                try:
                    payload = json.loads(data_str) if data_str else {}
                except json.JSONDecodeError:
                    payload = {"raw": data_str}

                content = payload_assistant_text(payload) if isinstance(payload, dict) else ""
                yield RunStreamEvent(
                    type=event_type or "message",
                    seq=event_id,
                    content=content,
                    payload=payload,
                )
                event_type = ""
                event_id = None
                data_lines = []


async def parse_sse_stream_async(response: httpx.Response) -> AsyncIterator[RunStreamEvent]:
    """Parse SSE from an async httpx streaming response."""
    event_type = ""
    event_id = None
    data_lines: list[str] = []

    async for line in response.aiter_lines():
        if line.startswith("event: "):
            event_type = line[7:]
        elif line.startswith("id: "):
            try:
                event_id = int(line[4:])
            except ValueError:
                event_id = None
        elif line.startswith("data: "):
            data_lines.append(line[6:])
        elif line == "":
            if event_type or data_lines:
                data_str = "\n".join(data_lines)
                try:
                    payload = json.loads(data_str) if data_str else {}
                except json.JSONDecodeError:
                    payload = {"raw": data_str}

                content = payload_assistant_text(payload) if isinstance(payload, dict) else ""
                yield RunStreamEvent(
                    type=event_type or "message",
                    seq=event_id,
                    content=content,
                    payload=payload,
                )
                event_type = ""
                event_id = None
                data_lines = []
