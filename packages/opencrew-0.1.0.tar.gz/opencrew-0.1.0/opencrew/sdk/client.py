from __future__ import annotations
from typing import Any, Iterator
import httpx
from opencrew.sdk.http_util import raise_for_api
from opencrew.sdk.streaming import RunStreamEvent, parse_sse_stream


class _Resource:
    def __init__(self, client: httpx.Client):
        self._http = client


class AgentTypes(_Resource):
    def create(self, *, name: str, slug: str | None = None, description: str | None = None,
               persona: str | None = None, system_prompt: str | None = None,
               model: str | None = None, memory_defaults: dict | None = None) -> dict:
        body: dict[str, Any] = {"name": name}
        for k, v in [("slug", slug), ("description", description), ("persona", persona),
                      ("system_prompt", system_prompt), ("model", model), ("memory_defaults", memory_defaults)]:
            if v is not None:
                body[k] = v
        resp = self._http.post("/v1/agent-types", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self) -> list[dict]:
        resp = self._http.get("/v1/agent-types")
        resp.raise_for_status()
        return resp.json()

    def get(self, slug: str) -> dict:
        resp = self._http.get(f"/v1/agent-types/{slug}")
        resp.raise_for_status()
        return resp.json()

    def update(self, slug: str, **kwargs: Any) -> dict:
        resp = self._http.patch(f"/v1/agent-types/{slug}", json={k: v for k, v in kwargs.items() if v is not None})
        resp.raise_for_status()
        return resp.json()

    def delete(self, slug: str) -> dict:
        resp = self._http.delete(f"/v1/agent-types/{slug}")
        resp.raise_for_status()
        return resp.json()

    def apply(self, config: dict) -> dict:
        resp = self._http.post("/v1/agent-types/apply", json=config)
        if resp.status_code in (404, 405, 501):
            from opencrew.sdk.apply_fallback import apply_without_apply_route

            return apply_without_apply_route(self._http, config)
        raise_for_api(resp)
        return resp.json()

    def readiness(self, slug: str, *, client_id: str | None = None) -> dict[str, Any]:
        params: dict[str, str] = {}
        if client_id:
            params["client_id"] = client_id
        resp = self._http.get(f"/v1/agent-types/{slug}/readiness", params=params or None)
        raise_for_api(resp)
        return resp.json()

    def attach_tool(self, slug: str, *, tool_id: str) -> dict:
        resp = self._http.post(f"/v1/agent-types/{slug}/tools", json={"custom_tool_id": tool_id})
        resp.raise_for_status()
        return resp.json()

    def attach_mcp_server(self, slug: str, *, server_id: str) -> dict:
        resp = self._http.post(f"/v1/agent-types/{slug}/mcp-servers", json={"custom_mcp_server_id": server_id})
        resp.raise_for_status()
        return resp.json()

    def attach_skill(self, slug: str, *, skill_id: str, skill_version_id: str) -> dict:
        resp = self._http.post(f"/v1/agent-types/{slug}/skills", json={"skill_id": skill_id, "skill_version_id": skill_version_id})
        resp.raise_for_status()
        return resp.json()

    def list_tools(self, slug: str) -> list[dict]:
        resp = self._http.get(f"/v1/agent-types/{slug}/tools")
        raise_for_api(resp)
        return resp.json()

    def list_mcp_servers(self, slug: str) -> list[dict]:
        resp = self._http.get(f"/v1/agent-types/{slug}/mcp-servers")
        raise_for_api(resp)
        return resp.json()


class Instances(_Resource):
    def create(self, agent_type: str, *, name: str, client_id: str | None = None, display_name: str | None = None) -> dict:
        body: dict[str, Any] = {"name": name}
        if client_id:
            body["client_id"] = client_id
        if display_name:
            body["display_name"] = display_name
        resp = self._http.post(f"/v1/agent-types/{agent_type}/instances", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self, agent_type: str, *, client_id: str | None = None) -> list[dict]:
        params: dict[str, Any] = {}
        if client_id:
            params["client_id"] = client_id
        resp = self._http.get(f"/v1/agent-types/{agent_type}/instances", params=params)
        resp.raise_for_status()
        return resp.json()

    def delete(self, agent_type: str, instance_id: str) -> dict:
        resp = self._http.delete(f"/v1/agent-types/{agent_type}/instances/{instance_id}")
        resp.raise_for_status()
        return resp.json()

    def memory(self, agent_type: str, instance_id: str | None = None) -> list[dict]:
        if instance_id is None:
            instances = self.list(agent_type)
            if not instances:
                return []
            instance_id = instances[0]["id"]
        resp = self._http.get(f"/v1/agent-types/{agent_type}/instances/{instance_id}/memory")
        resp.raise_for_status()
        return resp.json()

    def messages(self, agent_type: str, instance_id: str, *, limit: int = 50) -> list[dict]:
        resp = self._http.get(f"/v1/agent-types/{agent_type}/instances/{instance_id}/messages", params={"limit": limit})
        resp.raise_for_status()
        return resp.json()

    def reset(self, agent_type: str, instance_id: str) -> dict:
        resp = self._http.post(f"/v1/agent-types/{agent_type}/instances/{instance_id}/reset")
        resp.raise_for_status()
        return resp.json()


class ToolConnections(_Resource):
    def list(self, *, client_id: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if client_id:
            params["client_id"] = client_id
        resp = self._http.get("/v1/tool-connections", params=params or None)
        raise_for_api(resp)
        return resp.json()

    def initiate(
        self,
        toolkit_slug: str,
        *,
        client_id: str | None = None,
        redirect_url: str | None = None,
        auth_method: str = "oauth",
        credentials: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"toolkit_slug": toolkit_slug, "auth_method": auth_method}
        if client_id:
            body["client_id"] = client_id
        if redirect_url:
            body["redirect_url"] = redirect_url
        if credentials:
            body["credentials"] = credentials
        resp = self._http.post("/v1/tool-connections/initiate", json=body)
        raise_for_api(resp)
        return resp.json()


class Runs(_Resource):
    def create(
        self,
        *,
        agent_type: str,
        message: str,
        client_id: str | None = None,
        instance_id: str | None = None,
        fresh: bool = False,
        new_conversation: bool = False,
        allow_partial: bool = False,
    ) -> dict:
        body: dict[str, Any] = {"agent_type": agent_type, "message": message}
        if client_id:
            body["client_id"] = client_id
        if instance_id:
            body["instance_id"] = instance_id
        if fresh:
            body["fresh"] = True
        if new_conversation:
            body["new_conversation"] = True
        if allow_partial:
            body["allow_partial"] = True
        resp = self._http.post("/v1/runs", json=body)
        raise_for_api(resp)
        return resp.json()

    def get(self, run_id: str, *, include_events: bool = False) -> dict:
        params: dict[str, bool] | None = None
        if include_events:
            params = {"include_events": True}
        resp = self._http.get(f"/v1/runs/{run_id}", params=params)
        resp.raise_for_status()
        return resp.json()

    def events(self, run_id: str) -> list[dict[str, Any]]:
        resp = self._http.get(f"/v1/runs/{run_id}/events")
        resp.raise_for_status()
        return resp.json()

    def list(self, *, status: str | None = None, agent_type: str | None = None,
             client_id: str | None = None, limit: int = 50, offset: int = 0) -> list[dict]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        if agent_type:
            params["agent_type"] = agent_type
        if client_id:
            params["client_id"] = client_id
        resp = self._http.get("/v1/runs", params=params)
        resp.raise_for_status()
        return resp.json()

    def stream(self, run_id: str) -> Iterator[RunStreamEvent]:
        with self._http.stream("GET", f"/v1/runs/{run_id}/stream") as resp:
            resp.raise_for_status()
            yield from parse_sse_stream(resp)


class Tools(_Resource):
    def create(self, *, name: str, source_code: str, slug: str | None = None,
               source_type: str = "python", description: str | None = None,
               args_json_schema: dict | None = None) -> dict:
        body: dict[str, Any] = {"name": name, "source_code": source_code, "source_type": source_type}
        if slug:
            body["slug"] = slug
        if description:
            body["description"] = description
        if args_json_schema:
            body["args_json_schema"] = args_json_schema
        resp = self._http.post("/v1/custom-tools", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self) -> list[dict]:
        resp = self._http.get("/v1/custom-tools")
        resp.raise_for_status()
        return resp.json()

    def get(self, tool_id: str) -> dict:
        resp = self._http.get(f"/v1/custom-tools/{tool_id}")
        resp.raise_for_status()
        return resp.json()

    def delete(self, tool_id: str) -> dict:
        resp = self._http.delete(f"/v1/custom-tools/{tool_id}")
        resp.raise_for_status()
        return resp.json()


class McpServers(_Resource):
    def create(self, *, name: str, server_url: str, slug: str | None = None,
               server_type: str = "streamable_http", auth_header: str | None = None,
               auth_token: str | None = None, description: str | None = None) -> dict:
        body: dict[str, Any] = {"name": name, "server_url": server_url, "server_type": server_type}
        if slug:
            body["slug"] = slug
        if auth_header:
            body["auth_header"] = auth_header
        if auth_token:
            body["auth_token"] = auth_token
        if description:
            body["description"] = description
        resp = self._http.post("/v1/mcp-servers", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self) -> list[dict]:
        resp = self._http.get("/v1/mcp-servers")
        resp.raise_for_status()
        return resp.json()

    def get(self, server_id: str) -> dict:
        resp = self._http.get(f"/v1/mcp-servers/{server_id}")
        resp.raise_for_status()
        return resp.json()

    def delete(self, server_id: str) -> dict:
        resp = self._http.delete(f"/v1/mcp-servers/{server_id}")
        resp.raise_for_status()
        return resp.json()


class Skills(_Resource):
    def create(self, *, slug: str, name: str, description: str, instructions: str) -> dict:
        resp = self._http.post("/v1/skills", json={"slug": slug, "name": name, "description": description, "instructions": instructions})
        resp.raise_for_status()
        return resp.json()

    def list(self) -> list[dict]:
        resp = self._http.get("/v1/skills")
        resp.raise_for_status()
        return resp.json()


class Clients(_Resource):
    def create(self, *, name: str, slug: str | None = None, metadata: dict | None = None) -> dict:
        body: dict[str, Any] = {"name": name}
        if slug:
            body["slug"] = slug
        if metadata:
            body["metadata"] = metadata
        resp = self._http.post("/v1/clients", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self) -> list[dict]:
        resp = self._http.get("/v1/clients")
        resp.raise_for_status()
        return resp.json()

    def update(
        self,
        client_id: str,
        *,
        name: str | None = None,
        slug: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        body = {k: v for k, v in [("name", name), ("slug", slug), ("metadata", metadata)] if v is not None}
        resp = self._http.patch(f"/v1/clients/{client_id}", json=body)
        resp.raise_for_status()
        return resp.json()

    def delete(self, client_id: str) -> dict:
        """Archive the client (soft delete). The API returns deleted: true."""
        resp = self._http.delete(f"/v1/clients/{client_id}")
        resp.raise_for_status()
        return resp.json()


class Memory(_Resource):
    def create(self, client_id: str, *, label: str, value: str, description: str | None = None) -> dict:
        body: dict[str, Any] = {"label": label, "value": value}
        if description:
            body["description"] = description
        resp = self._http.post(f"/v1/clients/{client_id}/memory", json=body)
        resp.raise_for_status()
        return resp.json()

    def list(self, client_id: str) -> list[dict]:
        resp = self._http.get(f"/v1/clients/{client_id}/memory")
        resp.raise_for_status()
        return resp.json()

    def update(self, client_id: str, block_id: str, **kwargs: Any) -> dict:
        resp = self._http.patch(f"/v1/clients/{client_id}/memory/{block_id}", json={k: v for k, v in kwargs.items() if v is not None})
        resp.raise_for_status()
        return resp.json()

    def delete(self, client_id: str, block_id: str) -> dict:
        resp = self._http.delete(f"/v1/clients/{client_id}/memory/{block_id}")
        resp.raise_for_status()
        return resp.json()


class Chats(_Resource):
    def create(self, *, agent_type: str, title: str | None = None, instance_id: str | None = None) -> dict:
        body: dict[str, Any] = {"agent_type": agent_type}
        if title:
            body["title"] = title
        if instance_id:
            body["instance_id"] = instance_id
        resp = self._http.post("/v1/chats", json=body)
        raise_for_api(resp)
        return resp.json()

    def list(self, *, agent_type: str | None = None, limit: int = 20) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if agent_type:
            params["agent_type"] = agent_type
        resp = self._http.get("/v1/chats", params=params)
        raise_for_api(resp)
        return resp.json()

    def get(self, chat_id: str) -> dict:
        resp = self._http.get(f"/v1/chats/{chat_id}")
        raise_for_api(resp)
        return resp.json()

    def messages(self, chat_id: str, *, limit: int = 100) -> list[dict]:
        resp = self._http.get(f"/v1/chats/{chat_id}/messages", params={"limit": limit})
        raise_for_api(resp)
        return resp.json()

    def add_message(self, chat_id: str, *, role: str, content: str, run_id: str | None = None) -> dict:
        body: dict[str, Any] = {"role": role, "content": content}
        if run_id:
            body["run_id"] = run_id
        resp = self._http.post(f"/v1/chats/{chat_id}/messages", json=body)
        raise_for_api(resp)
        return resp.json()

    def delete(self, chat_id: str) -> dict:
        resp = self._http.delete(f"/v1/chats/{chat_id}")
        raise_for_api(resp)
        return resp.json()


class Logs(_Resource):
    def list(self, *, status: str | None = None, agent_type: str | None = None, limit: int = 50) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if agent_type:
            params["agent_type"] = agent_type
        resp = self._http.get("/v1/logs", params=params)
        resp.raise_for_status()
        return resp.json()

    def get(self, run_id: str) -> list[dict]:
        resp = self._http.get(f"/v1/logs/{run_id}")
        resp.raise_for_status()
        return resp.json()

    def usage(self) -> dict:
        resp = self._http.get("/v1/logs/summary/usage")
        resp.raise_for_status()
        return resp.json()


class OpenCrew:
    """Synchronous OpenCrew API client."""

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8741",
        api_key: str | None = None,
        timeout: float = 60.0,
    ):
        headers: dict[str, str] = {}
        if api_key:
            headers["X-Api-Key"] = api_key
        self._http = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )
        self.agent_types = AgentTypes(self._http)
        self.instances = Instances(self._http)
        self.tool_connections = ToolConnections(self._http)
        self.runs = Runs(self._http)
        self.tools = Tools(self._http)
        self.mcp_servers = McpServers(self._http)
        self.skills = Skills(self._http)
        self.clients = Clients(self._http)
        self.memory = Memory(self._http)
        self.chats = Chats(self._http)
        self.logs = Logs(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> OpenCrew:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def api_base_url(self) -> str:
        """Origin + path prefix used by this client (for OAuth callback URLs)."""
        return str(self._http.base_url).rstrip("/")
