from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client

console = Console()

_SKILL_TEMPLATE = """\
---
name: {slug}
description: Describe what this skill teaches the agent
---

# {name}

Add instructions here that the agent should follow when this skill is active.
"""


def run_skills_create(name: str) -> None:
    """Scaffold a local skill directory with a SKILL.md template."""
    slug = name.lower().replace(" ", "-")
    target_dir = Path.cwd() / "skills" / slug
    target_file = target_dir / "SKILL.md"

    if target_file.exists():
        console.print(f"[yellow]Already exists: {target_file}[/yellow]")
        raise SystemExit(1)

    target_dir.mkdir(parents=True, exist_ok=True)
    target_file.write_text(_SKILL_TEMPLATE.format(slug=slug, name=name))

    console.print(f"[green]✓[/green] Created {target_file}")
    console.print(f"\n  Edit the skill, then add to your agent.yaml:")
    console.print(f"  [dim]skills:[/dim]")
    console.print(f"  [dim]  - slug: {slug}[/dim]")
    console.print(f"  [dim]    path: ./skills/{slug}/SKILL.md[/dim]")


def run_skills_install(source: str) -> None:
    """Install a skill from skills.sh or a GitHub URL."""
    if "/" in source and not source.startswith("http"):
        if _looks_like_github(source):
            _install_github(source)
        else:
            _install_skillssh(source)
    elif source.startswith("http"):
        _install_github_url(source)
    else:
        _install_skillssh(source)


def _looks_like_github(source: str) -> bool:
    parts = source.split("/")
    return len(parts) >= 2 and not source.startswith("@")


def _install_skillssh(package: str) -> None:
    from opencrew.resolvers.skill_fetcher import fetch_skillssh, SkillFetchError
    console.print(f"[dim]Fetching from skills.sh: {package}...[/dim]")
    try:
        files = fetch_skillssh(package)
    except SkillFetchError as exc:
        console.print(f"[red]Failed: {exc}[/red]")
        raise SystemExit(1)
    _store_skill(files, source_label=f"skills.sh:{package}")


def _install_github(source: str) -> None:
    from opencrew.resolvers.skill_fetcher import fetch_github, SkillFetchError
    parts = source.split("/", 2)
    if len(parts) < 2:
        console.print(f"[red]Invalid GitHub source: {source}. Use owner/repo or owner/repo/path[/red]")
        raise SystemExit(1)
    repo = f"{parts[0]}/{parts[1]}"
    path = parts[2] if len(parts) > 2 else ""
    console.print(f"[dim]Fetching from GitHub: {repo}/{path}...[/dim]")
    try:
        files = fetch_github(repo, path)
    except SkillFetchError as exc:
        console.print(f"[red]Failed: {exc}[/red]")
        raise SystemExit(1)
    _store_skill(files, source_label=f"github:{source}")


def _install_github_url(url: str) -> None:
    console.print(f"[red]Direct URL install not yet supported. Use owner/repo/path format.[/red]")
    raise SystemExit(1)


def _store_skill(files: dict[str, str], source_label: str) -> None:
    skill_md = files.get("SKILL.md", "")
    if not skill_md:
        console.print("[red]No SKILL.md found in fetched content.[/red]")
        raise SystemExit(1)

    slug = _extract_frontmatter_field(skill_md, "name")
    name = slug or "unnamed-skill"
    description = _extract_frontmatter_field(skill_md, "description") or ""

    bundle_json = {k: v for k, v in files.items() if k != "SKILL.md"}

    with get_client() as client:
        resp = client._http.post("/v1/skills", json={
            "slug": slug,
            "name": name,
            "description": description,
            "instructions": "",
        })
        resp.raise_for_status()
        skill = resp.json()
        skill_data = skill.get("skill", skill)
        console.print(f"[green]✓[/green] Installed skill [bold]{slug}[/bold] from {source_label}")


def _extract_frontmatter_field(skill_md: str, field: str) -> str | None:
    lines = skill_md.splitlines()
    in_frontmatter = False
    for line in lines:
        if line.strip() == "---":
            if in_frontmatter:
                break
            in_frontmatter = True
            continue
        if in_frontmatter and line.startswith(f"{field}:"):
            return line.split(":", 1)[1].strip().strip("'\"")
    return None


def run_skills_list(agent: str | None = None) -> None:
    """List skills, optionally filtered to a specific agent."""
    with get_client() as client:
        if agent:
            skills = client._http.get(f"/v1/agent-types/{agent}/skills")
            skills.raise_for_status()
            data = skills.json()
        else:
            skills = client._http.get("/v1/skills")
            skills.raise_for_status()
            data = skills.json()

    if not data:
        console.print("[dim]No skills found.[/dim]")
        return

    title = f"Skills — {agent}" if agent else "Skills"
    table = Table(title=title)
    table.add_column("Slug", style="cyan")
    table.add_column("Name")
    table.add_column("Description", max_width=50, style="dim")

    for s in data:
        table.add_row(
            s.get("skill_slug") or s.get("slug", ""),
            s.get("skill_name") or s.get("name", ""),
            s.get("description", "")[:50],
        )

    console.print(table)
