"""Shared Composio / tool-connection flow for CLI (browser OAuth + readiness polling)."""

from __future__ import annotations

import time
import webbrowser
from typing import TYPE_CHECKING

import httpx
from rich.console import Console

from opencrew.sdk.http_util import format_api_error

if TYPE_CHECKING:
    from opencrew.sdk.client import OpenCrew

console = Console()


def parse_missing_connections(exc: httpx.HTTPStatusError) -> dict | None:
    """If this is a ``missing_connections`` run error, return the API ``detail`` dict."""
    if exc.response.status_code != 422:
        return None
    try:
        payload = exc.response.json()
    except Exception:
        return None
    detail = payload.get("detail")
    if isinstance(detail, dict) and detail.get("error") == "missing_connections":
        return detail
    return None


def wait_until_toolkit_connected(
    client: OpenCrew,
    agent_type_slug: str,
    toolkit_slug: str,
    *,
    client_id: str | None,
    timeout_s: float = 240.0,
    poll_s: float = 2.0,
) -> None:
    """Poll agent type readiness until ``toolkit_slug`` is no longer listed as missing."""
    deadline = time.monotonic() + timeout_s
    missing: list = []
    while time.monotonic() < deadline:
        r = client.agent_types.readiness(agent_type_slug, client_id=client_id)
        missing = list(r.get("missing_toolkits") or [])
        if toolkit_slug not in missing:
            return
        time.sleep(poll_s)
    raise TimeoutError(
        f"Timed out waiting for '{toolkit_slug}' to become active "
        f"(still missing: {missing}). Finish OAuth in the browser, then retry."
    )


def run_connect_flow_for_toolkits(
    client: OpenCrew,
    agent_type_slug: str,
    toolkit_slugs: list[str],
    *,
    client_id: str | None = None,
) -> None:
    """For each toolkit: POST initiate, open browser if needed, poll readiness for this agent type."""
    callback = f"{client.api_base_url()}/v1/oauth/callback"
    for tk in toolkit_slugs:
        slug = str(tk).strip().lower()
        if not slug:
            continue
        console.print(f"\n[cyan]Connecting[/cyan] [bold]{slug}[/bold] …")
        try:
            data = client.tool_connections.initiate(
                slug,
                client_id=client_id,
                redirect_url=callback,
            )
        except httpx.HTTPStatusError as e:
            console.print(f"[red]{format_api_error(e.response)}[/red]")
            raise SystemExit(1) from e
        auth_url = data.get("auth_url")
        row_status = str(data.get("status") or "").lower()
        if auth_url:
            console.print(
                "[dim]Opening your browser. If nothing opens, use the URL below.[/dim]\n"
                f"[link={auth_url}]{auth_url}[/link]"
            )
            webbrowser.open(auth_url)
            console.print(
                f"[dim]When sign-in finishes, the API completes the link automatically. "
                f"Waiting for '{slug}' (up to ~4 minutes)…[/dim]"
            )
            wait_until_toolkit_connected(client, agent_type_slug, slug, client_id=client_id)
            console.print(f"[green]✓[/green] {slug} is connected for [bold]{agent_type_slug}[/bold].")
        elif row_status == "active":
            console.print(f"[green]✓[/green] {slug} — recorded as active (no browser step).")
        else:
            console.print(f"[yellow]Unexpected response for {slug}: {data}[/yellow]")
