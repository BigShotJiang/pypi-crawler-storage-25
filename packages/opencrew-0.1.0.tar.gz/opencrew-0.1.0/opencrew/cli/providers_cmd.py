"""``opencrew providers`` — manage LLM provider API keys (local + cloud)."""

from __future__ import annotations

from pathlib import Path

import httpx
import yaml
from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.cli.provider_key_verify import verify_provider_api_key
from opencrew.sdk.http_util import humanize_api_error
from opencrew.user_config import API_TARGET_AUTO, API_TARGET_LOCAL, get_local, normalize_config

console = Console()

CONFIG_PATH = Path.home() / ".opencrew" / "config.yaml"

KNOWN_PROVIDERS: dict[str, dict] = {
    "anthropic": {
        "config_key": "anthropic_api_key",
        "provider_type": "anthropic",
        "display": "Anthropic",
        "url": "https://console.anthropic.com",
        "models": "claude-sonnet-4-20250514, claude-haiku-4-5",
    },
    "openai": {
        "config_key": "openai_api_key",
        "provider_type": "openai",
        "display": "OpenAI",
        "url": "https://platform.openai.com",
        "models": "gpt-4o, gpt-4o-mini, o1, o3-mini",
    },
    "google": {
        "config_key": "google_api_key",
        "provider_type": "google_ai",
        # Letta model handles use this prefix (e.g. google_ai/gemini-2.5-flash), not ``google/``.
        "letta_provider_name": "google_ai",
        "display": "Google AI (Gemini)",
        "url": "https://aistudio.google.com/app/api-keys",
        "models": "gemini-2.5-pro, gemini-2.5-flash",
    },
    "xai": {
        "config_key": "xai_api_key",
        "provider_type": "xai",
        "display": "xAI (Grok)",
        "url": "https://docs.x.ai",
        "models": "grok-3, grok-3-mini",
    },
    "deepseek": {
        "config_key": "deepseek_api_key",
        "provider_type": "deepseek",
        "display": "DeepSeek",
        "url": "https://platform.deepseek.com",
        "models": "deepseek-chat, deepseek-reasoner",
    },
    "openrouter": {
        "config_key": "openrouter_api_key",
        "provider_type": "openrouter",
        "display": "OpenRouter",
        "url": "https://openrouter.ai/keys",
        "models": "any model on openrouter.ai",
    },
    "together": {
        "config_key": "together_api_key",
        "provider_type": "together",
        "display": "Together AI",
        "url": "https://api.together.ai",
        "models": "llama, mixtral, etc.",
    },
    "groq": {
        "config_key": "groq_api_key",
        "provider_type": "groq",
        "display": "Groq",
        "url": "https://console.groq.com",
        "models": "llama-3, mixtral (fast inference)",
    },
    "mistral": {
        "config_key": "mistral_api_key",
        "provider_type": "mistral",
        "display": "Mistral",
        "url": "https://console.mistral.ai",
        "models": "mistral-large, mistral-small",
    },
    "fireworks": {
        "config_key": "fireworks_api_key",
        "provider_type": "fireworks",
        "display": "Fireworks AI",
        "url": "https://fireworks.ai",
        "models": "llama, mixtral (fast inference)",
    },
    "azure": {
        "config_key": "azure_api_key",
        "provider_type": "azure",
        "display": "Azure OpenAI",
        "url": "https://portal.azure.com",
        "models": "gpt-4o, gpt-4o-mini (Azure hosted)",
        "extra_fields": ["azure_endpoint", "azure_api_version"],
    },
    "bedrock": {
        "config_key": "bedrock_api_key",
        "provider_type": "bedrock",
        "display": "AWS Bedrock",
        "url": "https://aws.amazon.com/bedrock",
        "models": "claude, llama (AWS hosted)",
        "extra_fields": ["aws_region", "aws_access_key_id", "aws_secret_access_key"],
    },
}


def _load_config() -> dict:
    if not CONFIG_PATH.exists():
        console.print("[red]OpenCrew not initialized. Run `opencrew init` first.[/red]")
        raise SystemExit(1)
    return normalize_config(yaml.safe_load(CONFIG_PATH.read_text()) or {})


def _save_config(cfg: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_config(cfg)
    out = {
        "setup_mode": normalized.get("setup_mode", "local"),
        "local": dict(normalized.get("local") or {}),
        "remote": dict(normalized.get("remote") or {}),
    }
    CONFIG_PATH.write_text(yaml.dump(out, default_flow_style=False, sort_keys=False))


def _mask_key(key: str) -> str:
    if len(key) <= 8:
        return "****"
    return key[:4] + "…" + key[-4:]


def _letta_url(cfg: dict) -> str | None:
    return get_local(cfg).get("letta_url")


def _letta_providers_base(letta_url: str) -> str:
    u = (letta_url or "").strip().rstrip("/")
    if u.endswith("/v1"):
        return f"{u}/providers/"
    return f"{u}/v1/providers/"


def _letta_server_bearer_token() -> str:
    from opencrew.cli.init_cmd import _resolve_default_letta_api_token

    return _resolve_default_letta_api_token()


def _letta_provider_request_headers() -> dict[str, str]:
    h = {"Content-Type": "application/json"}
    tok = _letta_server_bearer_token()
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def _parse_api_error_body(resp: httpx.Response) -> str:
    try:
        data = resp.json()
        if isinstance(data, dict):
            d = data.get("detail")
            if isinstance(d, str) and d.strip():
                return d.strip()[:500]
            if isinstance(d, dict):
                msg = d.get("message")
                err = d.get("error")
                if isinstance(msg, str) and msg.strip():
                    if isinstance(err, str) and err.strip() and err.strip() != msg.strip():
                        return f"{err}: {msg.strip()}"[:500]
                    return msg.strip()[:500]
            if isinstance(d, list) and d:
                first = d[0]
                if isinstance(first, dict) and first.get("msg"):
                    return str(first.get("msg"))[:500]
            for k in ("message", "error", "error_message"):
                v = data.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()[:500]
        if isinstance(data, str) and data.strip():
            return data.strip()[:500]
    except Exception:
        pass
    text = (resp.text or "").strip()
    return text[:500] if text else f"HTTP {resp.status_code}"


def _find_letta_provider_id(
    letta_url: str,
    provider_type: str,
    *,
    match_names: tuple[str, ...],
) -> str | None:
    """Return Letta provider id if one matches a known name or the same ``provider_type``."""
    try:
        resp = httpx.get(
            _letta_providers_base(letta_url),
            headers=_letta_provider_request_headers(),
            timeout=10,
        )
        if resp.status_code >= 400:
            return None
        data = resp.json()
        if not isinstance(data, list):
            return None
        names_l = {n.strip().lower() for n in match_names if isinstance(n, str) and n.strip()}
        ptype_l = provider_type.strip().lower()
        for p in data:
            if not isinstance(p, dict):
                continue
            pid = p.get("id")
            if not pid:
                continue
            n = (p.get("name") or "").strip().lower()
            if n in names_l:
                return str(pid)
        for p in data:
            if not isinstance(p, dict):
                continue
            pid = p.get("id")
            if not pid:
                continue
            t = (p.get("provider_type") or "").strip().lower()
            if t == ptype_l:
                return str(pid)
        return None
    except (httpx.RequestError, TypeError, ValueError):
        return None


def _sync_to_letta(
    letta_url: str,
    *,
    body_name: str,
    match_names: tuple[str, ...],
    provider_type: str,
    api_key: str,
) -> tuple[bool, str]:
    """Create provider on Letta, or update api_key if one exists (matched by name or type)."""
    base = _letta_providers_base(letta_url).rstrip("/")
    post_url = _letta_providers_base(letta_url)
    headers = _letta_provider_request_headers()
    try:
        existing_id = _find_letta_provider_id(
            letta_url, provider_type, match_names=match_names
        )
        if existing_id:
            patch = httpx.patch(
                f"{base}/{existing_id}",
                headers=headers,
                json={"api_key": api_key, "name": body_name},
                timeout=15,
            )
            if patch.status_code >= 400:
                patch = httpx.patch(
                    f"{base}/{existing_id}",
                    headers=headers,
                    json={"api_key": api_key},
                    timeout=15,
                )
            if patch.status_code < 400:
                return True, ""
            # Older Letta or PATCH unsupported: remove and recreate
            httpx.delete(f"{base}/{existing_id}", headers=headers, timeout=10)
        resp = httpx.post(
            post_url,
            headers=headers,
            json={"name": body_name, "provider_type": provider_type, "api_key": api_key},
            timeout=15,
        )
        if resp.status_code < 400:
            return True, ""
        return False, _parse_api_error_body(resp)
    except httpx.RequestError as exc:
        return False, f"Could not reach Letta: {exc}"


def _fetch_letta_provider_slugs(letta_url: str) -> set[str]:
    try:
        resp = httpx.get(
            _letta_providers_base(letta_url),
            headers=_letta_provider_request_headers(),
            timeout=10,
        )
        if resp.status_code >= 400:
            return set()
        data = resp.json()
        if not isinstance(data, list):
            return set()
        out: set[str] = set()
        for p in data:
            if not isinstance(p, dict):
                continue
            n = p.get("name")
            t = p.get("provider_type")
            if isinstance(n, str) and n.strip():
                out.add(n.strip().lower())
            if isinstance(t, str) and t.strip():
                out.add(t.strip().lower())
        return out
    except (httpx.RequestError, TypeError, ValueError):
        return set()


def _remove_from_letta(letta_url: str, name: str) -> bool:
    base = _letta_providers_base(letta_url).rstrip("/")
    headers = _letta_provider_request_headers()
    try:
        resp = httpx.get(f"{base}/", headers=headers, timeout=10)
        if resp.status_code >= 400:
            return False
        for p in resp.json():
            if p.get("name") == name or p.get("provider_type") == name:
                pid = p.get("id")
                if pid:
                    httpx.delete(f"{base}/{pid}", headers=headers, timeout=10)
                    return True
    except (httpx.RequestError, Exception):
        pass
    return False


def _is_local(api_target: str) -> bool:
    return api_target == API_TARGET_LOCAL or (
        api_target == API_TARGET_AUTO and not _has_remote()
    )


def _has_remote() -> bool:
    from opencrew.user_config import is_remote_configured
    try:
        return is_remote_configured(_load_config())
    except SystemExit:
        return False


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

def run_providers_list(*, api_target: str = API_TARGET_AUTO, check: bool = False) -> None:
    if _is_local(api_target):
        _list_local(check=check)
    else:
        _list_cloud(api_target, check=check)


def _format_local_status(
    *,
    has_key: bool,
    on_letta: bool,
    check: bool,
    v_ok: bool | None,
    v_detail: str,
) -> str:
    if not has_key:
        return "[dim]—[/dim]"
    parts: list[str] = ["[green]set[/green]"]
    if not on_letta:
        parts.append("[yellow]not on Letta[/yellow]")
    else:
        parts.append("[dim]Letta[/dim]")
    if check and has_key:
        if v_ok is True:
            parts.append("[green]API ok[/green]")
        elif v_ok is False:
            parts.append("[red]replace key[/red]")
        else:
            short = (v_detail or "")[:60]
            parts.append(f"[yellow]?[/yellow] [dim]{short}[/dim]" if short else "[yellow]?[/yellow]")
    return " · ".join(parts)


def _list_local(*, check: bool = False) -> None:
    cfg = _load_config()
    loc = get_local(cfg)
    letta_url = _letta_url(cfg)
    letta_slugs = _fetch_letta_provider_slugs(letta_url) if letta_url else set()

    title = "LLM Providers (local)" + (" — live key check" if check else "")
    table = Table(title=title)
    table.add_column("Provider", style="cyan", min_width=14)
    table.add_column("Status", min_width=28)
    table.add_column("Key", style="dim", width=12)
    table.add_column("Models", style="dim")

    issues: list[str] = []

    for slug, info in KNOWN_PROVIDERS.items():
        raw = loc.get(info["config_key"])
        has_key = bool(raw)
        key_str = str(raw) if raw else ""
        on_letta = slug in letta_slugs or info["provider_type"].lower() in letta_slugs
        v_ok: bool | None = None
        v_detail = ""
        if check and has_key:
            v_ok, v_detail = verify_provider_api_key(slug, key_str)
        status = _format_local_status(
            has_key=has_key,
            on_letta=on_letta,
            check=check,
            v_ok=v_ok,
            v_detail=v_detail,
        )
        if has_key and not on_letta:
            issues.append(
                f"[yellow]{info['display']}:[/yellow] key in ~/.opencrew/config.yaml but not registered on Letta — "
                f"run [bold]opencrew providers set {slug}[/bold] or [bold]opencrew start[/bold]"
            )
        if check and has_key:
            if v_ok is False:
                issues.append(
                    f"[red]{info['display']}:[/red] {v_detail} — [bold]opencrew providers set {slug}[/bold]"
                )
            elif v_ok is None and v_detail and "Rate limited" not in v_detail:
                issues.append(f"[dim]{info['display']}: {v_detail}[/dim]")

        table.add_row(
            info["display"],
            status,
            _mask_key(key_str) if has_key else "—",
            info["models"],
        )

    console.print(table)

    if letta_url:
        if letta_slugs:
            console.print(f"\n[dim]Letta ({letta_url}) has:[/dim] {', '.join(sorted(letta_slugs))}")
        else:
            try:
                r = httpx.get(
                    _letta_providers_base(letta_url),
                    headers=_letta_provider_request_headers(),
                    timeout=5,
                )
                if r.status_code >= 400:
                    console.print(f"\n[yellow]Could not list Letta providers[/yellow] [dim](HTTP {r.status_code})[/dim]")
            except httpx.RequestError:
                console.print(f"\n[yellow]Could not reach Letta at {letta_url}[/yellow]")

    if issues:
        console.print("\n[bold]Action needed[/bold]")
        for line in issues:
            console.print(f"  • {line}")

    console.print(
        "\n[dim]Set a key:[/dim]  opencrew providers set <provider>\n"
        "[dim]Test keys:[/dim]    opencrew providers list --check\n"
        f"[dim]Providers:[/dim]  {', '.join(KNOWN_PROVIDERS)}"
    )


def _list_cloud(api_target: str, *, check: bool = False) -> None:
    with get_client(api_target=api_target) as client:
        try:
            rows = client._http.get("/v1/workspaces/current/providers").json()
        except Exception:
            rows = []

    verify_rows: list[dict] = []
    if check:
        with get_client(api_target=api_target) as client:
            try:
                resp = client._http.post("/v1/workspaces/current/providers/verify")
                if resp.status_code < 400:
                    verify_rows = resp.json()
            except Exception:
                verify_rows = []

    verify_by_slug: dict[str, dict] = {}
    if isinstance(verify_rows, list):
        for vr in verify_rows:
            if isinstance(vr, dict) and vr.get("slug"):
                verify_by_slug[str(vr["slug"]).lower()] = vr

    title = "LLM Providers (cloud)" + (" — live key check" if check else "")
    table = Table(title=title)
    table.add_column("Provider", style="cyan", min_width=14)
    table.add_column("Status", min_width=24)
    table.add_column("Key", style="dim", width=12)
    table.add_column("Models", style="dim")

    cloud_map: dict[str, dict] = {}
    if isinstance(rows, list):
        for r in rows:
            if not isinstance(r, dict):
                continue
            pt = r.get("provider_type")
            sl = r.get("slug")
            if isinstance(pt, str):
                cloud_map[pt.lower()] = r
            if isinstance(sl, str):
                cloud_map[sl.lower()] = r

    issues: list[str] = []

    for slug, info in KNOWN_PROVIDERS.items():
        row = cloud_map.get(info["provider_type"].lower()) or cloud_map.get(slug)
        if row:
            masked = row.get("masked_key") or "****"
            status = "[green]set[/green]"
            if check:
                vr = verify_by_slug.get(slug)
                if vr:
                    st = vr.get("status")
                    det = (vr.get("detail") or "").strip()
                    if st == "valid":
                        status += " [green]API ok[/green]"
                    elif st == "invalid":
                        status += " [red]replace key[/red]"
                        issues.append(
                            f"[red]{info['display']}:[/red] {det or 'Key rejected'} — "
                            f"[bold]opencrew providers set {slug} --cloud[/bold]"
                        )
                    else:
                        status += f" [yellow]?[/yellow]"
                        if det:
                            issues.append(f"[dim]{info['display']}: {det}[/dim]")
            table.add_row(info["display"], status, masked, info["models"])
        else:
            table.add_row(info["display"], "[dim]—[/dim]", "—", info["models"])

    console.print(table)

    if check and not verify_rows:
        console.print(
            "\n[yellow]Live checks need API support.[/yellow] "
            "[dim]Deploy the latest OpenCrew backend, or use --local.[/dim]"
        )

    if issues:
        console.print("\n[bold]Action needed[/bold]")
        for line in issues:
            console.print(f"  • {line}")

    console.print(
        "\n[dim]Set a key:[/dim]  opencrew providers set <provider> --cloud\n"
        "[dim]Test keys:[/dim]    opencrew providers list --check --cloud\n"
        f"[dim]Providers:[/dim]  {', '.join(KNOWN_PROVIDERS)}"
    )


# ---------------------------------------------------------------------------
# Set
# ---------------------------------------------------------------------------

def run_providers_set(provider: str, *, api_target: str = API_TARGET_AUTO) -> None:
    slug = provider.strip().lower()
    info = KNOWN_PROVIDERS.get(slug)
    if not info:
        console.print(
            f"[red]Unknown provider '{provider}'.[/red]\n"
            f"[dim]Available:[/dim] {', '.join(KNOWN_PROVIDERS)}"
        )
        raise SystemExit(1)

    console.print(f"\n[bold]{info['display']}[/bold] [dim]({info['url']})[/dim]")
    if not _is_local(api_target):
        console.print(
            "[dim]Target: [bold]cloud[/bold] workspace API. "
            "Use [bold]--local[/bold] to store in ~/.opencrew and register with local Letta only.[/dim]"
        )
    key = console.input("  API key (hidden): ", password=True).strip()
    if not key:
        console.print("[dim]Cancelled.[/dim]")
        return

    if _is_local(api_target):
        _set_local(slug, info, key)
    else:
        _set_cloud(slug, info, key, api_target)


def _set_local(slug: str, info: dict, key: str) -> None:
    cfg = _load_config()
    loc = get_local(cfg)
    loc[info["config_key"]] = key
    cfg["local"] = loc
    _save_config(cfg)
    console.print(f"[green]✓[/green] {info['display']} key saved to config")

    letta_url = _letta_url(cfg)
    if letta_url:
        body_name = str(info.get("letta_provider_name") or slug).strip()
        match_parts = [slug, body_name]
        match_names = tuple(dict.fromkeys(p for p in match_parts if p))
        sync_ok, sync_detail = _sync_to_letta(
            letta_url,
            body_name=body_name,
            match_names=match_names,
            provider_type=info["provider_type"],
            api_key=key,
        )
        if sync_ok:
            console.print(f"[green]✓[/green] Registered with local Letta ({letta_url})")
        else:
            console.print(
                f"[yellow]Letta did not accept this provider registration.[/yellow]\n"
                f"[dim]{sync_detail}[/dim]\n"
                "[dim]Key is still saved locally. Fix the issue or replace the key, then run "
                "[bold]opencrew providers set {slug}[/bold] again.[/dim]".replace("{slug}", slug)
            )
    else:
        console.print("[dim]Key saved. Will sync when `opencrew start` runs.[/dim]")

    v_ok, v_detail = verify_provider_api_key(slug, key)
    if v_ok is True:
        console.print(f"[green]✓[/green] Provider API accepted this key (quick check).")
    elif v_ok is False:
        console.print(
            f"[red]This key does not work with {info['display']}'s API.[/red]\n"
            f"[dim]{v_detail}[/dim]\n"
            f"[dim]Replace it at {info['url']} and run [bold]opencrew providers set {slug}[/bold] again.[/dim]"
        )
    elif v_detail:
        console.print(f"[dim]{v_detail}[/dim]")

    console.print(f"\n[dim]Use in agent.yaml:[/dim]  model: {slug}/<model_name>")


def _set_cloud(slug: str, info: dict, key: str, api_target: str) -> None:
    save_ok = False
    with get_client(api_target=api_target) as client:
        try:
            resp = client._http.put(
                "/v1/workspaces/current/providers",
                json={
                    "provider_type": info["provider_type"],
                    "slug": slug,
                    "api_key": key,
                },
            )
            save_ok = resp.status_code < 400
            if save_ok:
                console.print(f"[green]✓[/green] {info['display']} key saved to cloud workspace")
            else:
                err_line = _parse_api_error_body(resp)
                console.print(
                    f"[red]OpenCrew cloud API did not save this key (HTTP {resp.status_code}).[/red]\n"
                    f"[dim]{err_line}[/dim]"
                )
                if resp.status_code == 404:
                    console.print(
                        "\n[yellow]This usually means the hosted API you are calling does not include "
                        "workspace provider storage yet[/yellow] (deploy the latest OpenCrew backend), "
                        "[dim]or the request URL is wrong — check[/dim] [bold]opencrew target[/bold]."
                    )
                    console.print(
                        "\n[dim]To store the key only on this machine and register it with your "
                        "[bold]local[/bold] Letta server instead, run:[/dim]\n"
                        f"  [bold]opencrew providers set {slug} --local[/bold]"
                    )
                elif resp.status_code == 503:
                    console.print(
                        "\n[yellow]The server cannot encrypt provider keys yet.[/yellow]\n"
                        "[dim]Set environment variable[/dim] [bold]OPENCREW_SECRETS_KEY[/bold] [dim]on your API host "
                        "(e.g. Vercel → Project → Settings → Environment Variables). "
                        "Use a Fernet key — generate one with [bold]python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"[/bold][/dim]."
                    )
                    try:
                        data = resp.json()
                        d = data.get("detail")
                        if isinstance(d, dict) and d.get("message"):
                            console.print(f"\n[dim]{d['message']}[/dim]")
                    except Exception:
                        console.print(f"\n[dim]{humanize_api_error(resp)}[/dim]")
        except httpx.RequestError as exc:
            console.print(f"[red]Could not reach cloud API: {exc}[/red]")

    v_ok, v_detail = verify_provider_api_key(slug, key)
    if v_ok is True:
        if save_ok:
            console.print("[dim]Provider quick-check: key accepted by vendor API.[/dim]")
        else:
            console.print(
                f"\n[yellow]Separate check:[/yellow] {info['display']}'s API [green]accepted[/green] this key, "
                "[dim]but it was [bold]not[/bold] stored in your OpenCrew cloud workspace (see errors above).[/dim]"
            )
    elif v_ok is False:
        console.print(
            f"\n[red]This key does not work with {info['display']}'s API.[/red]\n"
            f"[dim]{v_detail}[/dim]\n"
            f"[dim]Replace it at {info['url']} and run [bold]opencrew providers set {slug} --cloud[/bold] again.[/dim]"
        )
    elif v_detail:
        console.print(f"\n[dim]{v_detail}[/dim]")

    console.print(f"\n[dim]Use in agent.yaml:[/dim]  model: {slug}/<model_name>")


def run_providers_verify(*, api_target: str = API_TARGET_AUTO) -> None:
    """Re-run live API checks for all configured keys (same as list --check)."""
    run_providers_list(api_target=api_target, check=True)


# ---------------------------------------------------------------------------
# Remove
# ---------------------------------------------------------------------------

def run_providers_remove(provider: str, *, api_target: str = API_TARGET_AUTO) -> None:
    slug = provider.strip().lower()
    info = KNOWN_PROVIDERS.get(slug)
    if not info:
        console.print(
            f"[red]Unknown provider '{provider}'.[/red]\n"
            f"[dim]Available:[/dim] {', '.join(KNOWN_PROVIDERS)}"
        )
        raise SystemExit(1)

    if _is_local(api_target):
        _remove_local(slug, info)
    else:
        _remove_cloud(slug, info, api_target)


def _remove_local(slug: str, info: dict) -> None:
    cfg = _load_config()
    loc = get_local(cfg)

    if not loc.get(info["config_key"]):
        console.print(f"[dim]{info['display']} is not configured locally.[/dim]")
        return

    loc.pop(info["config_key"], None)
    cfg["local"] = loc
    _save_config(cfg)
    console.print(f"[green]✓[/green] {info['display']} key removed from config")

    letta_url = _letta_url(cfg)
    if letta_url:
        ok = _remove_from_letta(letta_url, slug)
        if ok:
            console.print(f"[green]✓[/green] Removed from local Letta")
        else:
            console.print("[dim]Could not remove from Letta (may not be running).[/dim]")


def _remove_cloud(slug: str, info: dict, api_target: str) -> None:
    with get_client(api_target=api_target) as client:
        try:
            resp = client._http.delete(
                f"/v1/workspaces/current/providers/{slug}",
            )
            if resp.status_code < 400:
                console.print(f"[green]✓[/green] {info['display']} key removed from cloud workspace")
            elif resp.status_code == 404:
                console.print(f"[dim]{info['display']} is not configured on cloud.[/dim]")
            else:
                console.print(f"[red]Failed: HTTP {resp.status_code}[/red]")
        except httpx.RequestError as exc:
            console.print(f"[red]Could not reach cloud API: {exc}[/red]")
