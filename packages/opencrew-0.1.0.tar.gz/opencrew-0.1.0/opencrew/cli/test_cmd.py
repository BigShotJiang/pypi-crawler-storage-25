from __future__ import annotations

import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from rich.console import Console
from rich.text import Text

from opencrew.cli._config import get_client
from opencrew.cli.run_cmd import _auto_apply_if_local
from opencrew.user_config import API_TARGET_AUTO
from opencrew.testing.models import TestResult
from opencrew.testing.runner import discover_tests, load_test_case, run_test_case

console = Console()


def run_tests(
    agent: str,
    *,
    path: str | None = None,
    verbose: bool = False,
    parallel: bool = False,
    json_output: bool = False,
    timeout: int = 120,
    api_target: str = API_TARGET_AUTO,
    no_apply: bool = False,
) -> None:
    test_files = discover_tests(agent, specific_path=path)
    if not test_files:
        console.print(f"[yellow]No test files found for '{agent}'.[/yellow]")
        console.print(f"[dim]Create tests in {agent}/tests/ or ./tests/[/dim]")
        raise SystemExit(1)

    test_cases = []
    for f in test_files:
        try:
            tc = load_test_case(f)
            test_cases.append((f, tc))
        except Exception as exc:
            console.print(f"[red]Failed to parse {f}: {exc}[/red]")

    if not test_cases:
        console.print("[red]No valid test cases found.[/red]")
        raise SystemExit(1)

    if not no_apply:
        _auto_apply_if_local(agent, api_target=api_target)

    if not json_output:
        total_steps = sum(len(tc.steps) for _, tc in test_cases)
        console.print(f"\n  Running {len(test_cases)} test(s) for [bold]{agent}[/bold] ({total_steps} steps)...\n")

    results: list[tuple[Path, TestResult]] = []

    if parallel and len(test_cases) > 1:
        results = _run_parallel(
            agent, test_cases, timeout=timeout, verbose=verbose, api_target=api_target
        )
    else:
        results = _run_sequential(
            agent,
            test_cases,
            timeout=timeout,
            verbose=verbose,
            json_output=json_output,
            api_target=api_target,
        )

    if json_output:
        _print_json(results)
    else:
        _print_summary(results)

    any_failed = any(not r.passed for _, r in results)
    if any_failed:
        raise SystemExit(1)


def _run_sequential(
    agent: str,
    test_cases: list[tuple[Path, any]],
    *,
    timeout: int,
    verbose: bool,
    json_output: bool,
    api_target: str,
) -> list[tuple[Path, TestResult]]:
    results = []
    with get_client(api_target=api_target) as client:
        for file_path, tc in test_cases:
            if not json_output:
                console.print(f"  [dim]{file_path.name}[/dim]")

            result = run_test_case(client, agent, tc, timeout=timeout, verbose=verbose)
            results.append((file_path, result))

            if not json_output:
                _print_test_result(result, verbose=verbose)

    return results


def _run_parallel(
    agent: str,
    test_cases: list[tuple[Path, any]],
    *,
    timeout: int,
    verbose: bool,
    api_target: str,
) -> list[tuple[Path, TestResult]]:
    results: list[tuple[Path, TestResult]] = []

    def _run_one(file_path: Path, tc):
        with get_client(api_target=api_target) as client:
            return file_path, run_test_case(client, agent, tc, timeout=timeout, verbose=verbose)

    with ThreadPoolExecutor(max_workers=min(4, len(test_cases))) as pool:
        futures = {
            pool.submit(_run_one, fp, tc): fp
            for fp, tc in test_cases
        }
        for future in as_completed(futures):
            fp, result = future.result()
            results.append((fp, result))
            console.print(f"  [dim]{fp.name}[/dim]")
            _print_test_result(result, verbose=verbose)

    return results


def _print_test_result(result: TestResult, *, verbose: bool = False) -> None:
    status = "[green]pass[/green]" if result.passed else "[red]fail[/red]"
    duration = f"{result.total_duration_s:.1f}s"

    console.print(f"    [bold]{result.name}[/bold]")

    if result.error:
        console.print(f"      [red]{result.error}[/red]")
        return

    for step in result.steps:
        send_preview = step.send[:50] + ("..." if len(step.send) > 50 else "")
        step_status = "[green]pass[/green]" if step.passed else "[red]fail[/red]"
        console.print(
            f"      Step {step.step_index + 1}: \"{send_preview}\"  "
            f"{step_status}  [dim]{step.duration_s}s[/dim]"
        )

        if verbose and step.response:
            preview = step.response[:200].replace("\n", " ")
            console.print(f"        [dim]Response: {preview}[/dim]")

        for a in step.assertions:
            if not a.passed:
                console.print(f"        [red]✗ {a.label}[/red]")
                if a.detail:
                    console.print(f"          [dim]{a.detail}[/dim]")
            elif verbose:
                console.print(f"        [green]✓ {a.label}[/green]")

    for a in result.after_results:
        prefix = "[green]✓[/green]" if a.passed else "[red]✗[/red]"
        console.print(f"    after: {prefix} {a.label}")
        if not a.passed and a.detail:
            console.print(f"      [dim]{a.detail}[/dim]")

    console.print()


def _print_summary(results: list[tuple[Path, TestResult]]) -> None:
    passed = sum(1 for _, r in results if r.passed)
    failed = len(results) - passed
    total_time = sum(r.total_duration_s for _, r in results)

    if failed == 0:
        console.print(f"  [bold green]Results: {passed} passed[/bold green] ({total_time:.1f}s)")
    else:
        console.print(
            f"  [bold]Results: [green]{passed} passed[/green], "
            f"[red]{failed} failed[/red][/bold] ({total_time:.1f}s)"
        )
    console.print()


def _print_json(results: list[tuple[Path, TestResult]]) -> None:
    output = []
    for fp, r in results:
        output.append({
            "file": str(fp),
            "name": r.name,
            "passed": r.passed,
            "duration_s": r.total_duration_s,
            "error": r.error,
            "steps": [
                {
                    "send": s.send,
                    "passed": s.passed,
                    "duration_s": s.duration_s,
                    "response_length": len(s.response),
                    "assertions": [
                        {"label": a.label, "passed": a.passed, "detail": a.detail}
                        for a in s.assertions
                    ],
                }
                for s in r.steps
            ],
            "after": [
                {"label": a.label, "passed": a.passed, "detail": a.detail}
                for a in r.after_results
            ],
        })
    print(json.dumps(output, indent=2))
