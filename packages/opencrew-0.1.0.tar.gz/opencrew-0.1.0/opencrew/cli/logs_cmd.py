from __future__ import annotations

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.user_config import API_TARGET_AUTO

console = Console()


def run_logs(
    *,
    agent_type: str | None = None,
    status: str | None = None,
    limit: int = 20,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """Show run history."""
    with get_client(api_target=api_target) as client:
        runs = client.logs.list(agent_type=agent_type, status=status, limit=limit)

    if not runs:
        console.print("[dim]No runs found.[/dim]")
        return

    table = Table(title="Run History")
    table.add_column("ID", style="dim", max_width=12)
    table.add_column("Agent")
    table.add_column("Status")
    table.add_column("Message", max_width=40)
    table.add_column("Created")

    for r in runs:
        run_id = str(r.get("run_id", r.get("id", "")))[:12]
        status_val = r.get("status", r.get("level", "—"))

        status_style = {
            "completed": "green",
            "running": "cyan",
            "pending": "yellow",
            "failed": "red",
        }.get(status_val, "")

        message = r.get("message", "")
        if len(message) > 40:
            message = message[:37] + "..."

        created = str(r.get("created_at", ""))[:19]

        table.add_row(
            run_id,
            r.get("agent_type", r.get("agent_type_slug", "—")),
            f"[{status_style}]{status_val}[/{status_style}]" if status_style else status_val,
            message,
            created,
        )

    console.print(table)
