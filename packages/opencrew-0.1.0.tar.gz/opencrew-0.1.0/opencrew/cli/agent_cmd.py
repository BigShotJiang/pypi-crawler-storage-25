from __future__ import annotations

import re
import shutil
from pathlib import Path

import httpx
import yaml
from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client, load_config, print_api_banner
from opencrew.sdk.client import OpenCrew
from opencrew.sdk.http_util import humanize_api_error
from opencrew.user_config import (
    API_TARGET_AUTO,
    API_TARGET_CLOUD,
    API_TARGET_LOCAL,
    api_client_url_and_key_for_target,
    is_remote_configured,
)

console = Console()

BUNDLED_DIR = Path(__file__).parent.parent / "_bundled"
DEV_ROOT = Path(__file__).parent.parent.parent


def _template_path() -> Path:
    bundled = BUNDLED_DIR / "templates" / "agent.yaml"
    if bundled.exists():
        return bundled
    dev = DEV_ROOT / "templates" / "agent.yaml"
    if dev.exists():
        return dev
    console.print("[red]Cannot find agent template.[/red]")
    raise SystemExit(1)


def _test_template_path() -> Path | None:
    bundled = BUNDLED_DIR / "templates" / "tests" / "basic.yaml"
    if bundled.exists():
        return bundled
    dev = DEV_ROOT / "templates" / "tests" / "basic.yaml"
    if dev.exists():
        return dev
    return None


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "my-agent"


def run_create(name: str) -> None:
    """Create a new agent configuration directory from template."""
    slug = _slugify(name)
    target_dir = Path.cwd() / slug
    target_file = target_dir / "agent.yaml"

    if target_file.exists():
        console.print(f"[yellow]Already exists: {target_file}[/yellow]")
        raise SystemExit(1)

    target_dir.mkdir(parents=True, exist_ok=True)

    template = _template_path().read_text()
    template = template.replace("name: my-agent", f"name: {name}")
    template = template.replace("slug: my-agent", f"slug: {slug}")

    target_file.write_text(template)

    tests_dir = target_dir / "tests"
    tests_dir.mkdir(exist_ok=True)
    test_template = _test_template_path()
    if test_template:
        shutil.copy2(test_template, tests_dir / "basic.yaml")

    console.print(f"[green]✓[/green] Created {target_file}")
    console.print(f"\n  Edit the config:  [cyan]{target_file}[/cyan]")
    console.print(
        "  Register the agent:  [cyan]opencrew apply {0} --local[/cyan] "
        "(local API) or [cyan]opencrew apply {0}[/cyan] / [cyan]deploy {0}[/cyan] (cloud if configured)"
        .format(slug)
    )
    console.print(
        "  Run / test:          use the same API target for both, e.g. "
        "[cyan]opencrew run {0} \"Hello!\" --local[/cyan] and [cyan]opencrew test {0} --local[/cyan], "
        "or omit flags if you only use cloud. [cyan]opencrew target[/cyan] shows URLs."
        .format(slug)
    )


def _resolve_skills(config: dict, yaml_dir: Path) -> None:
    """Resolve skill file contents client-side and inject into the config dict."""
    from opencrew.resolvers.skill_fetcher import fetch_local, fetch_skillssh, fetch_github, SkillFetchError

    for skill_spec in config.get("skills") or []:
        if not isinstance(skill_spec, dict):
            continue
        source = skill_spec.get("source", "local" if skill_spec.get("path") else "inline")
        if source == "inline" or "_resolved_files" in skill_spec:
            continue

        try:
            if source == "local":
                raw_path = skill_spec.get("path", "")
                skill_path = (yaml_dir / raw_path).resolve()
                files = fetch_local(skill_path)
            elif source == "skills.sh":
                files = fetch_skillssh(skill_spec["package"])
            elif source == "github":
                files = fetch_github(
                    skill_spec["repo"],
                    skill_spec.get("path", ""),
                    ref=skill_spec.get("ref", "main"),
                )
            else:
                continue
            skill_spec["_resolved_files"] = files
        except SkillFetchError as exc:
            console.print(f"[yellow]Warning: Could not fetch skill '{skill_spec.get('slug', '?')}': {exc}[/yellow]")


def _resolve_tool_sources(config: dict, *, resolve_composio: bool = True) -> None:
    """Resolve special tool/MCP source types into concrete definitions.

    - ``source_type: composio`` (under tools) → resolves to an MCP server entry
    - ``source_type: composio`` (under mcp_servers) → resolves server_url in-place
    - All other entries pass through unchanged.

    If ``resolve_composio`` is False (e.g. ``opencrew deploy``), Composio entries are
    left unchanged so the hosted API can use workspace toolkit connections instead
    of a local ``COMPOSIO_API_KEY``.
    """
    tools = config.get("tools") or []
    mcp_servers = list(config.get("mcp_servers") or [])
    remaining_tools = []

    for tool_spec in tools:
        if not isinstance(tool_spec, dict):
            remaining_tools.append(tool_spec)
            continue

        source_type = tool_spec.get("source_type", "python")

        if source_type == "composio" and not resolve_composio:
            app = tool_spec.get("composio_app")
            if not app:
                remaining_tools.append(tool_spec)
                continue
            mcp_servers.append(
                {
                    "name": tool_spec.get("name", str(app).lower()),
                    "slug": tool_spec.get("slug", str(app).lower()),
                    "source_type": "composio",
                    "composio_app": app,
                    "composio_actions": tool_spec.get("composio_actions"),
                }
            )
            continue

        if source_type == "composio":
            try:
                from opencrew.resolvers.composio import resolve as composio_resolve
                result = composio_resolve(
                    app=tool_spec["composio_app"],
                    actions=tool_spec.get("composio_actions"),
                )
                mcp_servers.append({
                    "name": tool_spec.get("name", tool_spec["composio_app"].lower()),
                    "slug": tool_spec.get("slug", tool_spec["composio_app"].lower()),
                    "server_url": result.server_url,
                    "auth_header": result.auth_header,
                    "auth_token": result.auth_token,
                    "transport": "composio",
                    "composio_app": tool_spec["composio_app"],
                    "composio_actions": tool_spec.get("composio_actions"),
                })
            except Exception as exc:
                console.print(f"[yellow]Warning: Composio resolution failed for '{tool_spec.get('composio_app', '?')}': {exc}[/yellow]")
            continue

        remaining_tools.append(tool_spec)

    config["tools"] = remaining_tools
    if mcp_servers:
        config["mcp_servers"] = mcp_servers

    for srv_spec in config.get("mcp_servers") or []:
        if not isinstance(srv_spec, dict):
            continue
        is_composio = (
            srv_spec.get("source_type") == "composio"
            or srv_spec.get("transport") == "composio"
        )
        if is_composio and not srv_spec.get("server_url"):
            if not resolve_composio:
                continue
            app = srv_spec.get("composio_app")
            if not app:
                continue
            try:
                from opencrew.resolvers.composio import resolve as composio_resolve
                result = composio_resolve(
                    app=app,
                    actions=srv_spec.get("composio_actions"),
                )
                srv_spec["server_url"] = result.server_url
                srv_spec["auth_header"] = result.auth_header
                srv_spec["auth_token"] = result.auth_token
                srv_spec["transport"] = "composio"
            except Exception as exc:
                console.print(f"[yellow]Warning: Composio resolution failed for '{app}': {exc}[/yellow]")


# Keep old name as alias so existing imports don't break
_resolve_composio_tools = _resolve_tool_sources


def resolve_agent_yaml_path(name_or_path: str) -> Path:
    """Resolve ``opencrew apply|deploy <arg>`` to an ``agent.yaml`` path.

    Accepts a YAML file path, a directory containing ``agent.yaml``, or a bare
    agent folder name (``<cwd>/<name>/agent.yaml``), matching ``opencrew run <slug>``.
    Also checks ``<cwd>/cli/<name>/agent.yaml`` so repo-root shells find agents under ``cli/``.
    """
    text = (name_or_path or "").strip() or "agent.yaml"
    if text in (".", "./"):
        here = Path.cwd() / "agent.yaml"
        if here.is_file():
            return here.resolve()
        console.print(f"[red]No agent.yaml in current directory: {Path.cwd()}[/red]")
        raise SystemExit(1)

    path = Path(text).expanduser()

    if path.is_file():
        out = path.resolve()
        if out.is_dir():
            console.print(f"[red]Expected a YAML file but got a directory: {out}[/red]")
            raise SystemExit(1)
        return out

    if path.is_dir():
        inner = path / "agent.yaml"
        if inner.is_file():
            return inner.resolve()
        console.print(f"[red]No agent.yaml in directory: {path}[/red]")
        raise SystemExit(1)

    cwd = Path.cwd()
    search_bases = [cwd, cwd / "cli"]
    tried: list[str] = []
    for base in search_bases:
        cand = (base / text / "agent.yaml").resolve()
        tried.append(str(cand))
        if cand.is_file():
            return cand

    if path.suffix in (".yaml", ".yml"):
        console.print(f"[red]File not found: {path}[/red]")
        raise SystemExit(1)

    console.print(
        f"[red]Could not find agent config for {text!r}.[/red]\n"
        f"[dim]Tried:[/dim]\n"
        + "\n".join(f"[dim]  • {p}[/dim]" for p in tried)
        + f"\n[dim]  • {path.resolve() / 'agent.yaml'}[/dim]"
    )
    raise SystemExit(1)


def _load_agent_yaml(config_path: Path) -> dict:
    """Read and parse agent.yaml with friendly error handling."""
    try:
        raw = config_path.read_text()
    except OSError as exc:
        console.print(f"[red]Could not read {config_path}: {exc}[/red]")
        raise SystemExit(1) from exc
    try:
        config = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        console.print(f"[red]Invalid YAML in {config_path}:[/red]\n{exc}")
        raise SystemExit(1) from exc
    if not isinstance(config, dict):
        console.print(f"[red]{config_path} must be a YAML mapping, got {type(config).__name__}[/red]")
        raise SystemExit(1)
    return config


def run_apply(name_or_path: str, *, api_target: str = API_TARGET_AUTO) -> None:
    """Sync agent YAML config to the server."""
    config_path = resolve_agent_yaml_path(name_or_path)
    config = _load_agent_yaml(config_path)
    yaml_dir = config_path.parent.resolve()

    _resolve_skills(config, yaml_dir)
    _resolve_tool_sources(config)

    with get_client(api_target=api_target) as client:
        print_api_banner(client, api_target)
        result = client.agent_types.apply(config)

    is_cloud = api_target == API_TARGET_CLOUD or (
        api_target == API_TARGET_AUTO and is_remote_configured(load_config())
    )
    _print_apply_result(result, config, deployed_to_cloud=is_cloud, api_target=api_target)


def run_deploy(name_or_path: str) -> None:
    """Push agent YAML to OpenCrew Cloud (remote API only)."""
    from opencrew.user_config import is_remote_configured

    from opencrew.cli._config import load_config

    cfg = load_config()
    if not is_remote_configured(cfg):
        console.print(
            "[red]Cloud API is not configured.[/red] Run [cyan]opencrew init --cloud[/cyan] "
            "with your workspace API URL and key, then retry."
        )
        raise SystemExit(1)

    config_path = resolve_agent_yaml_path(name_or_path)
    config = _load_agent_yaml(config_path)
    yaml_dir = config_path.parent.resolve()

    _resolve_skills(config, yaml_dir)
    _resolve_tool_sources(config, resolve_composio=False)

    with get_client(api_target=API_TARGET_CLOUD) as client:
        print_api_banner(client, API_TARGET_CLOUD)
        result = client.agent_types.apply(config)

    _print_apply_result(
        result, config, deployed_to_cloud=True, api_target=API_TARGET_CLOUD
    )


def _print_apply_result(
    result: dict, config: dict, *, deployed_to_cloud: bool, api_target: str = API_TARGET_AUTO
) -> None:
    slug = result.get("slug", config.get("slug", "?"))
    verb = "Deployed" if deployed_to_cloud else "Applied"
    console.print(f"[green]✓[/green] {verb} agent type [bold]{slug}[/bold]")
    flag = (
        "--local"
        if api_target == API_TARGET_LOCAL
        else ("--cloud" if api_target == API_TARGET_CLOUD else "")
    )
    test_hint = f"opencrew test {slug}" + (f" {flag}" if flag else "")
    console.print(
        "[dim]Run tests against this same API:[/dim] "
        f"[cyan]{test_hint}[/cyan]"
        " [dim](or match your apply flags;[/dim] [cyan]opencrew target[/cyan] [dim]shows URLs).[/dim]"
    )

    if result.get("tools_synced"):
        console.print(f"  [dim]Tools synced: {result['tools_synced']}[/dim]")
    if result.get("mcp_servers_synced"):
        console.print(f"  [dim]MCP servers synced: {result['mcp_servers_synced']}[/dim]")
    if result.get("skills_synced"):
        console.print(f"  [dim]Skills synced: {result['skills_synced']}[/dim]")
    for w in result.get("warnings") or []:
        console.print(f"  [yellow]Warning:[/yellow] {w}")
    if result.get("apply_mode"):
        console.print(f"  [dim]{result['apply_mode']}[/dim]")


def run_list(*, api_target: str = API_TARGET_AUTO) -> None:
    """List all agent types."""
    with get_client(api_target=api_target) as client:
        agents = client.agent_types.list()

    if not agents:
        console.print("[dim]No agent types found. Create one with `opencrew create <name>`.[/dim]")
        return

    table = Table(title="Agent Types")
    table.add_column("Slug", style="cyan")
    table.add_column("Name")
    table.add_column("Model", style="dim")
    table.add_column("Status")

    for a in agents:
        status = a.get("readiness_status", "ready")
        style = "green" if status == "ready" else "yellow"
        table.add_row(
            a.get("slug", ""),
            a.get("name", ""),
            a.get("model", "—"),
            f"[{style}]{status}[/{style}]",
        )

    console.print(table)


def _find_agent_project_roots(slug: str) -> list[Path]:
    """``./<slug>`` and ``./cli/<slug>`` if they contain ``agent.yaml`` with matching ``slug`` field."""
    slug = slug.strip()
    if not slug:
        return []
    cwd = Path.cwd()
    roots: list[Path] = []
    seen: set[str] = set()
    for base in (cwd, cwd / "cli"):
        root = (base / slug).resolve()
        key = str(root)
        if key in seen:
            continue
        cfg = root / "agent.yaml"
        if not cfg.is_file():
            continue
        try:
            data = yaml.safe_load(cfg.read_text())
        except (OSError, yaml.YAMLError):
            continue
        if not isinstance(data, dict):
            continue
        if str(data.get("slug", "")).strip() != slug:
            continue
        seen.add(key)
        roots.append(root)
    return roots


def _remove_local_agent_projects(slug: str, *, keep_local: bool) -> None:
    if keep_local:
        return
    roots = _find_agent_project_roots(slug)
    if not roots:
        console.print(
            f"[dim]No local project folder found for [bold]{slug}[/bold] "
            f"(looked for [bold]./{slug}/agent.yaml[/bold] and [bold]./cli/{slug}/agent.yaml[/bold] with matching slug).[/dim]"
        )
        return
    for root in roots:
        try:
            shutil.rmtree(root)
            console.print(f"[green]✓[/green] Removed local project [bold]{root}[/bold]")
        except OSError as exc:
            console.print(f"[yellow]Could not remove {root}:[/yellow] {exc}")


def _confirm_delete_agent_type(slug: str, *, skip_confirm: bool, everywhere: bool = False) -> bool:
    if skip_confirm:
        return True
    if everywhere:
        console.print(
            f"[yellow]This removes agent type[/yellow] [bold]{slug}[/bold] [yellow]from every configured API[/yellow] "
            "[dim](local OpenCrew server and cloud, when both are set in ~/.opencrew/config.yaml). "
            "Instances and runs metadata may become invalid. "
            "Matching local folders [bold]./{slug}/[/bold] or [bold]./cli/{slug}/[/bold] "
            "(with agent.yaml slug field) are deleted from disk.[/dim]".replace("{slug}", slug)
        )
    else:
        console.print(
            f"[yellow]This removes agent type[/yellow] [bold]{slug}[/bold] [yellow]from the API[/yellow] "
            "[dim](instances and runs metadata may become invalid). "
            "Matching local folders [bold]./{slug}/[/bold] or [bold]./cli/{slug}/[/bold] are deleted unless "
            "you pass [bold]--keep-local[/bold].[/dim]".replace("{slug}", slug)
        )
    confirm = console.input("[bold red]Type 'yes' to confirm: [/bold red]")
    if confirm.strip().lower() != "yes":
        console.print("[dim]Cancelled.[/dim]")
        return False
    return True


def run_delete_agent_type_everywhere(
    slug: str,
    *,
    skip_confirm: bool = False,
    keep_local: bool = False,
) -> None:
    """Remove agent type from local API and from cloud (if remote is configured), after one confirmation."""
    slug = slug.strip()
    if not slug:
        console.print("[red]Agent type slug is required.[/red]")
        raise SystemExit(1)

    if not _confirm_delete_agent_type(slug, skip_confirm=skip_confirm, everywhere=True):
        return

    cfg = load_config()
    targets: list[tuple[str, str]] = [("local", API_TARGET_LOCAL)]
    if is_remote_configured(cfg):
        targets.append(("cloud", API_TARGET_CLOUD))

    any_ok = False
    for label, tgt in targets:
        try:
            base_url, api_key = api_client_url_and_key_for_target(cfg, tgt)
        except ValueError as exc:
            console.print(f"[dim]{label}: skipped ({exc})[/dim]")
            continue
        client = OpenCrew(base_url=base_url, api_key=api_key)
        try:
            client.agent_types.delete(slug)
            console.print(f"[green]✓[/green] Removed [bold]{slug}[/bold] from [bold]{label}[/bold] [dim]({base_url})[/dim]")
            any_ok = True
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                console.print(f"[dim]{label}: agent type not found (404) — nothing to delete[/dim]")
            else:
                console.print(f"[yellow]{label}:[/yellow] {humanize_api_error(exc.response)}")
        except httpx.RequestError as exc:
            console.print(f"[yellow]{label}:[/yellow] could not reach API ({type(exc).__name__})")
        finally:
            client.close()

    if any_ok:
        console.print(f"[green]Done.[/green] [dim]({slug})[/dim]")
    else:
        console.print("[yellow]No API reported a successful delete.[/yellow]")

    _remove_local_agent_projects(slug, keep_local=keep_local)


def run_delete_agent_type(
    slug: str,
    *,
    skip_confirm: bool = False,
    api_target: str = API_TARGET_AUTO,
    keep_local: bool = False,
) -> None:
    """Remove an agent type from the OpenCrew API (catalog only — does not delete local files)."""
    slug = slug.strip()
    if not slug:
        console.print("[red]Agent type slug is required.[/red]")
        raise SystemExit(1)

    if not _confirm_delete_agent_type(slug, skip_confirm=skip_confirm, everywhere=False):
        return

    with get_client(api_target=api_target) as client:
        client.agent_types.delete(slug)

    console.print(f"[green]✓[/green] Deleted agent type [bold]{slug}[/bold]")
    _remove_local_agent_projects(slug, keep_local=keep_local)
