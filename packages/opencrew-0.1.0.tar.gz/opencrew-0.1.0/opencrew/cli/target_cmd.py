"""`opencrew target` — show which API base URL local/auto/cloud resolve to."""
from __future__ import annotations

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import CONFIG_PATH, load_config
from opencrew.user_config import (
    API_TARGET_AUTO,
    API_TARGET_CLOUD,
    API_TARGET_LOCAL,
    api_client_url_and_key_for_target,
    get_local,
    get_remote,
    has_local_stack,
)

console = Console()


def run_target_show() -> None:
    cfg = load_config()
    table = Table(title="OpenCrew API targets (~/.opencrew/config.yaml)")
    table.add_column("Mode", style="cyan")
    table.add_column("Base URL", style="white")
    table.add_column("Key", justify="center")

    for mode, label in (
        (API_TARGET_AUTO, "auto (default for run/apply)"),
        (API_TARGET_LOCAL, "local (--local)"),
        (API_TARGET_CLOUD, "cloud (--cloud)"),
    ):
        try:
            url, key = api_client_url_and_key_for_target(cfg, mode)
        except ValueError as exc:
            table.add_row(label, f"[red]{exc}[/red]", "—")
            continue
        table.add_row(label, url, "[green]set[/green]" if key else "[yellow]missing[/yellow]")

    console.print(table)

    auto_url, _ = api_client_url_and_key_for_target(cfg, API_TARGET_AUTO)
    console.print(
        f"\n[bold]Default[/bold] (no [bold]--local[/bold]/[bold]--cloud[/bold]): "
        f"[cyan]{auto_url}[/cyan]",
    )
    rem = get_remote(cfg)
    loc = get_local(cfg)
    console.print(
        f"[dim]remote:[/dim] api_url={'yes' if rem.get('api_url') else 'no'}, "
        f"api_key={'yes' if rem.get('api_key') else 'no'}, "
        f"letta_base_url={'yes' if rem.get('letta_base_url') else 'no'}\n"
        f"[dim]local:[/dim] api_url={loc.get('api_url') or 'http://localhost:8741 (default)'}, "
        f"Docker stack={'yes' if has_local_stack(cfg) else 'no'}",
    )
    console.print(
        f"\n[dim]Config file:[/dim] {CONFIG_PATH}\n"
        "[dim]Set hosted API credentials: [bold]opencrew remote[/bold][/dim]",
    )
