"""``opencrew connections`` — list and initiate workspace Composio tool links."""

from __future__ import annotations

import time
import webbrowser

import httpx
from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.cli.connection_flow import run_connect_flow_for_toolkits, wait_until_toolkit_connected
from opencrew.sdk.http_util import format_api_error
from opencrew.user_config import API_TARGET_AUTO

console = Console()


def run_connections_list(*, client_id: str | None, api_target: str = API_TARGET_AUTO) -> None:
    with get_client(api_target=api_target) as client:
        try:
            rows = client.tool_connections.list(client_id=client_id)
        except httpx.HTTPStatusError as e:
            console.print(f"[red]{format_api_error(e.response)}[/red]")
            raise SystemExit(1) from e

    if not rows:
        console.print("[dim]No tool connections for this workspace scope.[/dim]")
        return

    table = Table(title="Tool connections")
    table.add_column("Toolkit", style="cyan")
    table.add_column("Status")
    table.add_column("Connection ID", style="dim")
    for r in rows:
        table.add_row(
            str(r.get("toolkit_slug") or "—"),
            str(r.get("status") or "—"),
            str(r.get("id") or "—")[:8] + "…",
        )
    console.print(table)


def run_connections_connect(
    toolkit: str,
    *,
    client_id: str | None,
    agent: str | None,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """Start OAuth (or no-auth path) for one toolkit; optionally wait against an agent type's readiness."""
    slug = toolkit.strip().lower()
    if not slug:
        console.print("[red]Toolkit slug is required.[/red]")
        raise SystemExit(1)

    with get_client(api_target=api_target) as client:
        callback = f"{client.api_base_url()}/v1/oauth/callback"
        console.print(f"[cyan]Initiating[/cyan] [bold]{slug}[/bold] …")
        try:
            data = client.tool_connections.initiate(slug, client_id=client_id, redirect_url=callback)
        except httpx.HTTPStatusError as e:
            console.print(f"[red]{format_api_error(e.response)}[/red]")
            raise SystemExit(1) from e

        auth_url = data.get("auth_url")
        row_status = str(data.get("status") or "").lower()

        if auth_url:
            console.print(
                "[dim]Opening your browser. If nothing opens, use the URL below.[/dim]\n"
                f"[link={auth_url}]{auth_url}[/link]"
            )
            webbrowser.open(auth_url)
        elif row_status == "active":
            console.print(f"[green]✓[/green] {slug} is active (no browser step).")
            return
        else:
            console.print(f"[yellow]{data}[/yellow]")
            return

        if agent:
            console.print(
                f"[dim]Waiting for '{slug}' to satisfy readiness on agent type '{agent}'…[/dim]"
            )
            try:
                wait_until_toolkit_connected(client, agent, slug, client_id=client_id)
            except TimeoutError as exc:
                console.print(f"[red]{exc}[/red]")
                raise SystemExit(1) from exc
            console.print("[green]✓[/green] Ready for that agent type.")
        else:
            console.print(
                "[dim]When OAuth completes, verify with:[/dim]\n"
                f"  [bold]opencrew connections list[/bold]"
                + (f" --client {client_id}" if client_id else "")
                + "\n"
                "Or re-run your agent; use [bold]opencrew run … --connect[/bold] to auto-wait."
            )
            # light poll so unattended CLI sees success without --agent
            deadline = time.monotonic() + 300.0
            while time.monotonic() < deadline:
                rows = client.tool_connections.list(client_id=client_id)
                if any(
                    str(r.get("toolkit_slug") or "").lower() == slug
                    and str(r.get("status") or "").lower() == "active"
                    for r in rows
                ):
                    console.print(f"[green]✓[/green] {slug} now shows as active in tool connections.")
                    return
                time.sleep(2.0)
            console.print("[yellow]Still pending — finish the browser flow or check the dashboard.[/yellow]")


def run_connections_sync(
    agent: str,
    *,
    client_id: str | None,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """Connect every toolkit the agent type still needs (from readiness)."""
    with get_client(api_target=api_target) as client:
        try:
            r = client.agent_types.readiness(agent, client_id=client_id)
        except httpx.HTTPStatusError as e:
            console.print(f"[red]{format_api_error(e.response)}[/red]")
            raise SystemExit(1) from e
        missing = list(r.get("missing_toolkits") or [])
        if not missing:
            console.print(f"[green]Nothing missing[/green] — {agent} readiness is OK.")
            return
        console.print(f"[yellow]Missing integrations[/yellow] for [bold]{agent}[/bold]: {', '.join(missing)}")
        run_connect_flow_for_toolkits(client, agent, missing, client_id=client_id)
