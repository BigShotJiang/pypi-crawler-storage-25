from __future__ import annotations

import json
from pathlib import Path

import httpx
import yaml
from rich.console import Console
from rich.live import Live
from rich.text import Text

from opencrew.cli._config import get_client, load_config, print_api_banner
from opencrew.cli.connection_flow import parse_missing_connections, run_connect_flow_for_toolkits
from opencrew.cli.local_health import preflight_local_run, should_run_local_preflight
from opencrew.user_config import API_TARGET_AUTO
from opencrew.cli.provider_key_verify import provider_key_failure_hint
from opencrew.sdk.http_util import format_api_error, humanize_api_error
from opencrew.sdk.streaming import assistant_text_from_run_result, payload_assistant_text

console = Console()


def _normalize_run_result_value(raw: object) -> dict:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


def _assistant_from_stored_events(events: list[dict]) -> str:
    """Reconstruct assistant reply from persisted ``run_events`` rows."""
    chunks: list[str] = []
    for ev in events:
        et = str(ev.get("event_type") or "")
        payload = ev.get("payload")
        if not isinstance(payload, dict):
            continue
        if et == "assistant" or payload.get("type") == "assistant":
            c = payload_assistant_text(payload)
            if c:
                chunks.append(c)
    return "".join(chunks)


def _auto_apply_if_local(agent_slug: str, *, api_target: str) -> None:
    """If a local agent.yaml exists for this slug, auto-apply it."""
    from opencrew.cli.agent_cmd import _resolve_skills, _resolve_tool_sources

    cwd = Path.cwd()
    candidates = [
        cwd / "agent.yaml",
        cwd / agent_slug / "agent.yaml",
        cwd / "cli" / agent_slug / "agent.yaml",
        cwd / "tests" / agent_slug / "agent.yaml",
    ]
    for p in candidates:
        if p.exists():
            try:
                config = yaml.safe_load(p.read_text())
                if config.get("slug") == agent_slug:
                    yaml_dir = p.parent.resolve()
                    _resolve_skills(config, yaml_dir)
                    _resolve_tool_sources(config)
                    with get_client(api_target=api_target) as client:
                        client.agent_types.apply(config)
                    console.print(f"[dim]Auto-applied {p}[/dim]")
                    return
            except Exception:
                pass


def run_run(
    agent: str,
    message: str,
    *,
    client_id: str | None = None,
    verbose: bool = False,
    fresh: bool = False,
    allow_partial: bool = False,
    connect: bool = True,
    api_target: str = API_TARGET_AUTO,
    skip_local_preflight: bool = False,
) -> None:
    """Run an agent and stream the response."""
    cfg = load_config()
    if (
        not skip_local_preflight
        and should_run_local_preflight(cfg, api_target)
    ):
        preflight_local_run(cfg, verbose=verbose)

    _auto_apply_if_local(agent, api_target=api_target)

    with get_client(api_target=api_target) as client:
        print_api_banner(client, api_target)
        run: dict | None = None
        connect_attempts = 0
        while run is None:
            try:
                run = client.runs.create(
                    agent_type=agent,
                    message=message,
                    client_id=client_id,
                    fresh=fresh,
                    allow_partial=allow_partial,
                )
            except httpx.HTTPStatusError as e:
                detail = parse_missing_connections(e)
                if (
                    detail
                    and connect
                    and not allow_partial
                    and connect_attempts < 1
                ):
                    missing = list(detail.get("missing_toolkits") or [])
                    if not missing:
                        raise
                    connect_attempts += 1
                    console.print(
                        "[yellow]This agent type requires connected integrations:[/yellow] "
                        f"{', '.join(missing)}\n"
                        "[dim]Starting connection flow (browser). "
                        "Use --no-connect to skip, or --allow-partial to run without tools.[/dim]"
                    )
                    run_connect_flow_for_toolkits(client, agent, missing, client_id=client_id)
                    continue
                msg = humanize_api_error(e.response)
                console.print(f"[red]{msg}[/red]")
                hint = provider_key_failure_hint(msg)
                if hint:
                    console.print(hint)
                if verbose or e.response.status_code >= 500:
                    console.print(f"[dim]{format_api_error(e.response)}[/dim]")
                if should_run_local_preflight(cfg, api_target) and e.response.status_code >= 500:
                    console.print(
                        "[dim]See server logs: [bold]~/.opencrew/server.log[/bold] (daemon) or the terminal "
                        "where `uvicorn`/API is running.[/dim]",
                    )
                raise SystemExit(1) from e

        run_id = run.get("run_id") or run.get("id")
        console.print(f"[dim]Run {run_id}[/dim]\n")

        output_parts: list[str] = []

        try:
            with Live(Text(""), console=console, refresh_per_second=8, transient=True) as live:
                for event in client.runs.stream(run_id):
                    pl = event.payload if isinstance(event.payload, dict) else {}
                    eff_type = event.type
                    if eff_type == "message" and pl.get("type"):
                        eff_type = str(pl["type"])
                    if eff_type == "assistant":
                        chunk = (
                            event.content
                            if event.content
                            else payload_assistant_text(pl)
                        )
                        if chunk:
                            output_parts.append(chunk)
                            live.update(Text("".join(output_parts)))
                    elif event.type == "message" and event.content and not pl.get("type"):
                        output_parts.append(event.content)
                        live.update(Text("".join(output_parts)))
                    elif event.type == "reasoning" and verbose:
                        console.print(f"[dim italic]💭 {event.content}[/dim italic]")
                    elif event.type == "tool_call" and verbose:
                        tool_name = event.payload.get("name", "tool")
                        console.print(f"[dim]🔧 {tool_name}[/dim]")
                    elif event.type == "tool_return" and verbose:
                        status = event.payload.get("status", "")
                        console.print(f"[dim]   → {status}[/dim]")
                    elif event.type == "error":
                        err_text = str(event.content or "")
                        console.print(f"[red]Error: {err_text}[/red]")
                        hint = provider_key_failure_hint(err_text)
                        if hint:
                            console.print(hint)
                    elif event.type == "done":
                        if not output_parts and event.payload:
                            res = event.payload.get("result")
                            if isinstance(res, str) and res.strip():
                                output_parts.append(res.strip())
                                live.update(Text(output_parts[-1]))
                            elif isinstance(res, dict):
                                tail = assistant_text_from_run_result(res)
                                if tail:
                                    output_parts.append(tail)
                                    live.update(Text(tail))
                        break
        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted.[/dim]")
            return
        except httpx.HTTPStatusError as exc:
            partial = "".join(output_parts).strip()
            if partial:
                console.print(partial)
            msg = humanize_api_error(exc.response)
            console.print(f"\n[red]{msg}[/red]")
            hint = provider_key_failure_hint(msg)
            if hint:
                console.print(hint)
            console.print("[dim]The stream ended with an error. Fetching final result…[/dim]")
        except httpx.RequestError as exc:
            partial = "".join(output_parts).strip()
            if partial:
                console.print(partial)
            console.print(f"\n[red]Stream interrupted ({type(exc).__name__})[/red]")
            console.print("[dim]Connection lost during streaming. Fetching final result…[/dim]")

        combined_live = "".join(output_parts).strip()
        if combined_live:
            # Re-print after Live exits — Rich clears the live region on teardown.
            console.print(combined_live)
        else:
            result = client.runs.get(run_id, include_events=True)
            if result:
                res_data = _normalize_run_result_value(result.get("result"))
                combined = assistant_text_from_run_result(res_data)
                if combined.strip():
                    console.print(combined)
                else:
                    evs = result.get("events")
                    if evs is None:
                        try:
                            evs = client.runs.events(run_id)
                        except httpx.HTTPError:
                            evs = []
                    from_events = _assistant_from_stored_events(evs)
                    if from_events.strip():
                        console.print(from_events)
                    else:
                        status = result.get("status", "unknown")
                        error_text = result.get("error", "")
                        if status == "failed" and error_text:
                            console.print(f"[red]Run failed: {error_text}[/red]")
                            hint = provider_key_failure_hint(error_text)
                            if hint:
                                console.print(hint)
                        elif status == "failed":
                            console.print("[red]Run failed (no details)[/red]")
                        else:
                            console.print(
                                f"[dim]Run status: {status} "
                                f"(no assistant text — try -v or logs)[/dim]",
                            )
            else:
                console.print("[dim]Run completed (no result data)[/dim]")
