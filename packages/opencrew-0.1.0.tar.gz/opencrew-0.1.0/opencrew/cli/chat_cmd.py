from __future__ import annotations

import json
from pathlib import Path

import httpx
import yaml
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.text import Text
from rich.table import Table
from rich.prompt import Prompt

from opencrew.cli._config import get_client, load_config, print_api_banner
from opencrew.cli.local_health import preflight_local_run, should_run_local_preflight
from opencrew.cli.run_cmd import (
    _auto_apply_if_local,
    _assistant_from_stored_events,
    _normalize_run_result_value,
)
from opencrew.user_config import API_TARGET_AUTO
from opencrew.cli.provider_key_verify import provider_key_failure_hint
from opencrew.sdk.http_util import format_api_error, humanize_api_error
from opencrew.sdk.streaming import assistant_text_from_run_result, payload_assistant_text
from opencrew.sdk.client import OpenCrew

console = Console()


def _send_and_stream(client: OpenCrew, agent: str, message: str, *, verbose: bool) -> str:
    """Send a message, stream the response, return the assistant text."""
    try:
        run = client.runs.create(agent_type=agent, message=message)
    except httpx.HTTPStatusError as exc:
        from opencrew.sdk.http_util import humanize_api_error
        msg = humanize_api_error(exc.response)
        console.print(f"[red]{msg}[/red]")
        hint = provider_key_failure_hint(msg)
        if hint:
            console.print(hint)
        return ""
    except httpx.RequestError as exc:
        console.print(f"[red]Could not reach the API ({type(exc).__name__})[/red]")
        return ""

    run_id = run.get("run_id") or run.get("id")
    if not run_id:
        console.print("[red]Server returned no run ID.[/red]")
        return ""

    output_parts: list[str] = []
    waiting = True
    try:
        with Live(
            Spinner("dots", text="Thinking…", style="dim"),
            console=console,
            refresh_per_second=12,
            transient=True,
        ) as live:
            for event in client.runs.stream(run_id):
                pl = event.payload if isinstance(event.payload, dict) else {}
                eff_type = event.type
                if eff_type == "message" and pl.get("type"):
                    eff_type = str(pl["type"])
                if eff_type == "assistant":
                    chunk = event.content if event.content else payload_assistant_text(pl)
                    if chunk:
                        waiting = False
                        output_parts.append(chunk)
                        live.update(Text("".join(output_parts)))
                elif event.type == "reasoning":
                    if verbose:
                        console.print(f"[dim italic]  {event.content}[/dim italic]")
                    elif waiting:
                        live.update(Spinner("dots", text="Reasoning…", style="dim"))
                elif event.type == "tool_call":
                    tool_name = pl.get("name", "tool")
                    if verbose:
                        console.print(f"[dim]  {tool_name}[/dim]")
                    elif waiting:
                        live.update(Spinner("dots", text=f"Using {tool_name}…", style="dim"))
                elif event.type == "error":
                    err_text = str(event.content or "")
                    console.print(f"[red]Error: {err_text}[/red]")
                    hint = provider_key_failure_hint(err_text)
                    if hint:
                        console.print(hint)
                elif event.type == "done":
                    if not output_parts and event.payload:
                        res = event.payload.get("result")
                        if isinstance(res, str) and res.strip():
                            output_parts.append(res.strip())
                        elif isinstance(res, dict):
                            tail = assistant_text_from_run_result(res)
                            if tail:
                                output_parts.append(tail)
                    break
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted.[/dim]")
        return ""
    except httpx.HTTPStatusError as exc:
        from opencrew.sdk.http_util import humanize_api_error
        partial = "".join(output_parts).strip()
        if partial:
            console.print(partial)
        msg = humanize_api_error(exc.response)
        console.print(f"\n[red]{msg}[/red]")
        hint = provider_key_failure_hint(msg)
        if hint:
            console.print(hint)
    except httpx.RequestError as exc:
        partial = "".join(output_parts).strip()
        if partial:
            console.print(partial)
        console.print(f"\n[red]Stream interrupted ({type(exc).__name__})[/red]")

    combined = "".join(output_parts).strip()
    if combined:
        console.print(combined)
        return combined

    try:
        result = client.runs.get(run_id, include_events=True)
    except (httpx.HTTPStatusError, httpx.RequestError):
        console.print("[dim](could not fetch run result)[/dim]")
        return ""
    if result:
        res_data = _normalize_run_result_value(result.get("result"))
        text = assistant_text_from_run_result(res_data)
        if text.strip():
            console.print(text)
            return text.strip()
    console.print("[dim](no response)[/dim]")
    return ""


def _pick_chat(client: OpenCrew, agent: str) -> str | None:
    """Show a numbered list of recent chats and let the user pick one."""
    chats = client.chats.list(agent_type=agent, limit=10)
    if not chats:
        return None

    console.print()
    table = Table(title=f"Recent chats — {agent}", show_lines=False, padding=(0, 1))
    table.add_column("#", style="bold", width=3)
    table.add_column("Chat", min_width=30)
    table.add_column("Messages", justify="right", width=8)
    table.add_column("Last active", width=20)

    for i, c in enumerate(chats, 1):
        label = c.get("title") or c.get("first_message") or "(empty)"
        if len(label) > 50:
            label = label[:47] + "..."
        count = str(c.get("message_count", 0))
        updated = str(c.get("updated_at", ""))[:19]
        table.add_row(str(i), label, count, updated)

    console.print(table)
    console.print()

    choice = Prompt.ask(
        "[bold]Pick a chat to continue, or press Enter for a new one[/bold]",
        default="",
    )
    if not choice.strip():
        return None
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(chats):
            return str(chats[idx]["id"])
    except ValueError:
        for c in chats:
            if choice.strip() == str(c["id"])[:len(choice.strip())]:
                return str(c["id"])
    console.print("[dim]Starting a new chat.[/dim]")
    return None


def _show_chat_history(client: OpenCrew, chat_id: str) -> None:
    """Print existing messages in this chat."""
    msgs = client.chats.messages(chat_id)
    if not msgs:
        return
    console.print("[dim]─── chat history ───[/dim]")
    for m in msgs:
        role = m.get("role", "?")
        content = m.get("content", "")
        if role == "user":
            console.print(f"[bold cyan]You:[/bold cyan] {content}")
        else:
            console.print(f"[bold green]Agent:[/bold green] {content}")
    console.print("[dim]─── end history ────[/dim]\n")


def _record_message(client: OpenCrew, chat_id: str, role: str, content: str, run_id: str | None = None) -> None:
    """Record a message in the chat via the API."""
    try:
        client.chats.add_message(chat_id, role=role, content=content, run_id=run_id)
    except Exception:
        pass


def _resolve_chat_id(client: OpenCrew, agent: str, prefix: str) -> str | None:
    """Resolve a short prefix to a full chat UUID."""
    import re
    full_uuid = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
    )
    if full_uuid.match(prefix):
        return prefix
    chats = client.chats.list(agent_type=agent, limit=50)
    for c in chats:
        cid = str(c.get("id", ""))
        if cid.startswith(prefix):
            return cid
    return None


def run_chat(
    agent: str,
    *,
    chat_id: str | None = None,
    client_id: str | None = None,
    instance_id: str | None = None,
    verbose: bool = False,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """Interactive chat REPL with an agent."""
    cfg = load_config()
    if should_run_local_preflight(cfg, api_target):
        preflight_local_run(cfg, verbose=verbose)

    _auto_apply_if_local(agent, api_target=api_target)

    with get_client(api_target=api_target) as client:
        print_api_banner(client, api_target)

        if instance_id is not None:
            instances = client.instances.list(agent, client_id=client_id)
            match = None
            for inst in instances:
                iid = str(inst.get("id", ""))
                if iid == instance_id or iid.startswith(instance_id):
                    match = inst
                    break
            if match is None:
                console.print(f"[red]No instance matching '{instance_id}' for '{agent}'.[/red]")
                return
            instance_id = str(match["id"])
            display = match.get("display_name") or match.get("name") or instance_id[:8]
            console.print(f"[dim]Instance: {display} ({instance_id[:8]})[/dim]")

        if chat_id is not None:
            resolved = _resolve_chat_id(client, agent, chat_id)
            if resolved is None:
                console.print(f"[red]No chat found matching '{chat_id}'[/red]")
                chat_id = None
            else:
                chat_id = resolved
        else:
            chat_id = _pick_chat(client, agent)

        if chat_id:
            chat = client.chats.get(chat_id)
            console.print(f"[dim]Resuming chat {chat_id[:8]}…[/dim]")
            _show_chat_history(client, chat_id)
        else:
            chat = client.chats.create(agent_type=agent)
            chat_id = str(chat["id"])
            console.print(f"[dim]New chat {chat_id[:8]}…[/dim]")

        console.print(
            f"[bold]Chat with {agent}[/bold]  "
            "[dim](type /quit to exit, /history to show history)[/dim]\n"
        )

        while True:
            try:
                user_input = Prompt.ask("[bold cyan]You[/bold cyan]")
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Goodbye.[/dim]")
                break

            stripped = user_input.strip()
            if not stripped:
                continue
            if stripped.lower() in ("/quit", "/exit", "/q"):
                console.print("[dim]Goodbye.[/dim]")
                break
            if stripped.lower() in ("/history", "/h"):
                _show_chat_history(client, chat_id)
                continue

            _record_message(client, chat_id, "user", stripped)

            console.print()
            reply = _send_and_stream(client, agent, stripped, verbose=verbose)
            console.print()

            if reply:
                _record_message(client, chat_id, "assistant", reply)


def run_chat_list(
    agent: str | None = None,
    *,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """List recent chat sessions."""
    with get_client(api_target=api_target) as client:
        chats = client.chats.list(agent_type=agent, limit=20)

    if not chats:
        console.print("[dim]No chats yet. Start one with: opencrew chat <agent>[/dim]")
        return

    table = Table(title="Chat sessions", show_lines=False, padding=(0, 1))
    table.add_column("ID", style="dim", width=10)
    table.add_column("Agent", min_width=12)
    table.add_column("Title / first message", min_width=30)
    table.add_column("Msgs", justify="right", width=5)
    table.add_column("Last active", width=20)

    for c in chats:
        cid = str(c.get("id", ""))[:8]
        slug = c.get("agent_type_slug", "—")
        label = c.get("title") or c.get("first_message") or "—"
        if len(label) > 45:
            label = label[:42] + "..."
        count = str(c.get("message_count", 0))
        updated = str(c.get("updated_at", ""))[:19]
        table.add_row(cid, slug, label, count, updated)

    console.print(table)
    console.print(
        "\n[dim]Continue a chat:[/dim] opencrew chat <agent> --continue <id>"
    )
