from __future__ import annotations

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.user_config import API_TARGET_AUTO

console = Console()


def _resolve_instance_id(
    instances: list[dict], instance_id: str | None, agent: str,
) -> str | None:
    """Pick an instance: explicit prefix match, or default to first."""
    if not instances:
        console.print(f"[dim]No instances found for agent type '{agent}'.[/dim]")
        return None

    if instance_id is None:
        return str(instances[0]["id"])

    for inst in instances:
        iid = str(inst.get("id", ""))
        if iid == instance_id or iid.startswith(instance_id):
            return iid

    console.print(f"[red]No instance matching '{instance_id}' for '{agent}'.[/red]")
    return None


def run_memory(agent: str, *, client_id: str | None = None, instance_id: str | None = None, api_target: str = API_TARGET_AUTO) -> None:
    """Show agent memory blocks."""
    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent, client_id=client_id)
        resolved = _resolve_instance_id(instances, instance_id, agent)
        if resolved is None:
            return

        blocks = client.instances.memory(agent, resolved)

    if not blocks:
        console.print("[dim]No memory blocks found.[/dim]")
        return

    table = Table(title=f"Memory — {agent} ({resolved[:8]})")
    table.add_column("Label", style="cyan")
    table.add_column("Value", max_width=80)

    for block in blocks:
        label = block.get("label", "")
        value = block.get("value", "")
        if len(value) > 200:
            value = value[:200] + "..."
        table.add_row(label, value)

    console.print(table)


def run_reset(agent: str, *, client_id: str | None = None, instance_id: str | None = None, skip_confirm: bool = False, api_target: str = API_TARGET_AUTO) -> None:
    """Reset agent memory by resetting the instance."""
    if not skip_confirm:
        confirm = console.input(
            f"[bold red]Reset memory for '{agent}'? This cannot be undone. Type 'yes' to confirm: [/bold red]"
        )
        if confirm.strip().lower() != "yes":
            console.print("[dim]Cancelled.[/dim]")
            return

    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent, client_id=client_id)
        resolved = _resolve_instance_id(instances, instance_id, agent)
        if resolved is None:
            return

        client.instances.reset(agent, resolved)

    console.print(f"[green]✓[/green] Memory reset for [bold]{agent}[/bold] ({resolved[:8]})")
