import typer

from opencrew.user_config import API_TARGET_AUTO, API_TARGET_CLOUD, API_TARGET_DAYTONA, API_TARGET_LOCAL

app = typer.Typer(
    name="opencrew",
    help="Run persistent memory agents locally. Deploy in one command.",
    no_args_is_help=True,
)


def _resolve_target(
    local_api: bool,
    cloud_api: bool,
    daytona_api: bool = False,
) -> str:
    selected = sum([local_api, cloud_api, daytona_api])
    if selected > 1:
        typer.echo("Use only one of --local, --cloud, or --daytona.", err=True)
        raise typer.Exit(code=1)
    if local_api:
        return API_TARGET_LOCAL
    if cloud_api:
        return API_TARGET_CLOUD
    if daytona_api:
        return API_TARGET_DAYTONA
    return API_TARGET_AUTO


@app.command()
def init(
    anthropic_api_key: str = typer.Option(None, "--anthropic-key", envvar="ANTHROPIC_API_KEY", help="Anthropic API key (local mode: registered with Letta)"),
    openai_api_key: str = typer.Option(None, "--openai-key", envvar="OPENAI_API_KEY", help="OpenAI API key (local mode: registered with Letta)"),
    local: bool = typer.Option(
        False,
        "--local",
        help="Accepted for compatibility; init always configures this machine unless --cloud",
    ),
    cloud: bool = typer.Option(
        False,
        "--cloud",
        help="Remote-only setup (same as opencrew remote); skips Docker on this machine",
    ),
    api_url: str = typer.Option(
        None,
        "--api-url",
        envvar="OPENCREW_API_URL",
        help="OpenCrew API base URL (init default: https://api.opencrew.site/v1)",
    ),
    api_key: str = typer.Option(None, "--api-key", envvar="OPENCREW_API_KEY", help="Workspace API key (lmp_…)"),
):
    """Set up this machine (Docker, Letta, local API). Use ``--cloud`` for remote-only; or run ``opencrew remote`` anytime."""
    from opencrew.cli.init_cmd import run_init
    if local and cloud:
        typer.echo("Use only one of --local or --cloud.", err=True)
        raise typer.Exit(code=1)

    run_init(
        anthropic_api_key=anthropic_api_key,
        openai_api_key=openai_api_key,
        prefer_cloud=cloud,
        cloud_api_url=api_url,
        cloud_api_key=api_key,
    )


@app.command()
def remote(
    api_url: str = typer.Option(
        None,
        "--api-url",
        envvar="OPENCREW_API_URL",
        help="OpenCrew API base URL (default: https://api.opencrew.site/v1)",
    ),
    api_key: str = typer.Option(None, "--api-key", envvar="OPENCREW_API_KEY", help="Workspace API key (lmp_…)"),
):
    """Add or update cloud API credentials (``remote:`` in config). Your local stack is left as-is."""
    from opencrew.cli.init_cmd import run_remote_setup
    run_remote_setup(cloud_api_url=api_url, cloud_api_key=api_key)


@app.command()
def start():
    """Start the OpenCrew server and infrastructure."""
    from opencrew.cli.init_cmd import run_start
    run_start()


@app.command()
def stop():
    """Stop the OpenCrew server and infrastructure."""
    from opencrew.cli.init_cmd import run_stop
    run_stop()


@app.command()
def destroy():
    """Remove all OpenCrew data and infrastructure."""
    from opencrew.cli.init_cmd import run_destroy
    run_destroy()


@app.command()
def doctor():
    """Check that all OpenCrew prerequisites and services are healthy."""
    from opencrew.cli.init_cmd import run_doctor
    run_doctor()


@app.command()
def target():
    """Show which API URL ``auto``, ``--local``, and ``--cloud`` use (avoids local vs cloud mix-ups)."""
    from opencrew.cli.target_cmd import run_target_show

    run_target_show()


@app.command()
def create(name: str = typer.Argument(..., help="Agent name")):
    """Create a new agent configuration from template."""
    from opencrew.cli.agent_cmd import run_create
    run_create(name)


@app.command(name="apply")
def apply_cmd(
    agent: str = typer.Argument(
        "agent.yaml",
        help="Agent folder name (e.g. my-agent) or path to agent.yaml",
    ),
    local_api: bool = typer.Option(False, "--local", help="Apply to local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Apply to cloud API"),
):
    """Sync agent configuration to the API (``./agent.yaml`` if you omit the argument)."""
    from opencrew.cli.agent_cmd import run_apply
    run_apply(agent, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def deploy(
    agent: str = typer.Argument(
        "agent.yaml",
        help="Agent folder name (e.g. my-agent) or path to agent.yaml",
    ),
):
    """Push agent config to OpenCrew Cloud (needs ``opencrew init --cloud``)."""
    from opencrew.cli.agent_cmd import run_deploy
    run_deploy(agent)


@app.command(name="list")
def list_cmd(
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """List all agent types."""
    from opencrew.cli.agent_cmd import run_list
    run_list(api_target=_resolve_target(local_api, cloud_api))


@app.command("delete-type")
def delete_type_cmd(
    slug: str = typer.Argument(..., help="Agent type slug (as shown by opencrew list)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    keep_local: bool = typer.Option(
        False,
        "--keep-local",
        help="Do not delete ./<slug> or ./cli/<slug> from disk (API delete still runs)",
    ),
    local_api: bool = typer.Option(False, "--local", help="Only the local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Only the cloud API"),
):
    """Remove an agent type from the API and matching local project folder(s).

    With neither --local nor --cloud, deletes on local and on cloud (if remote is configured).
    """
    from opencrew.cli.agent_cmd import run_delete_agent_type, run_delete_agent_type_everywhere

    if local_api and cloud_api:
        typer.echo("Use only one of --local or --cloud.", err=True)
        raise typer.Exit(code=1)
    if not local_api and not cloud_api:
        run_delete_agent_type_everywhere(slug, skip_confirm=yes, keep_local=keep_local)
    else:
        run_delete_agent_type(
            slug,
            skip_confirm=yes,
            api_target=_resolve_target(local_api, cloud_api),
            keep_local=keep_local,
        )


# ---------------------------------------------------------------------------
# Instances
# ---------------------------------------------------------------------------

instances_app = typer.Typer(
    help="List and manage agent instances.",
    no_args_is_help=True,
)
app.add_typer(instances_app, name="instances")


@instances_app.command(name="list")
def instances_list_cmd(
    agent: str = typer.Argument(..., help="Agent type slug"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """List instances for an agent type."""
    from opencrew.cli.instances_cmd import run_instances_list

    run_instances_list(agent, client_id=client, api_target=_resolve_target(local_api, cloud_api))


@instances_app.command("inspect")
def instances_inspect_cmd(
    agent: str = typer.Argument(..., help="Agent type slug"),
    instance: str = typer.Argument(..., help="Instance ID (prefix match OK)"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Show details and memory for a specific instance."""
    from opencrew.cli.instances_cmd import run_instance_inspect

    run_instance_inspect(agent, instance, api_target=_resolve_target(local_api, cloud_api))


@instances_app.command("delete")
def instances_delete_cmd(
    agent: str = typer.Argument(..., help="Agent type slug"),
    instance: str | None = typer.Argument(
        None,
        help="Instance ID (prefix match OK); omit when using --all",
    ),
    all_instances: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Delete every instance for this agent (one confirmation for all)",
    ),
    client: str | None = typer.Option(
        None,
        "--client",
        "-c",
        help="With --all: only instances scoped to this client",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Delete one instance (AGENT + INSTANCE) or all instances (AGENT --all)."""
    from opencrew.cli.instances_cmd import run_instance_delete, run_instances_delete_all

    target = _resolve_target(local_api, cloud_api)
    if all_instances:
        if instance is not None:
            typer.echo("Do not pass INSTANCE when using --all.", err=True)
            raise typer.Exit(code=1)
        run_instances_delete_all(
            agent,
            client_id=client,
            skip_confirm=yes,
            api_target=target,
        )
        return
    if not instance:
        typer.echo(
            "Missing INSTANCE. Use: opencrew instances delete AGENT <id-prefix>  "
            "or: opencrew instances delete AGENT --all",
            err=True,
        )
        raise typer.Exit(code=1)
    run_instance_delete(agent, instance, skip_confirm=yes, api_target=target)


@app.command()
def run(
    agent: str = typer.Argument(..., help="Agent type slug"),
    message: str = typer.Argument(..., help="Message to send"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID for scoped memory"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show reasoning and tool calls"),
    fresh: bool = typer.Option(False, "--fresh", help="Use throwaway agent (no memory persistence)"),
    allow_partial: bool = typer.Option(
        False,
        "--allow-partial",
        "-p",
        help="Allow run even when required Composio connections are missing (tools may fail)",
    ),
    connect: bool = typer.Option(
        True,
        "--connect/--no-connect",
        help="On missing integrations, open browser OAuth then retry the run (default: on)",
    ),
    local_api: bool = typer.Option(
        False,
        "--local",
        help="Call your local OpenCrew API (config: local.api_url), not cloud",
    ),
    cloud_api: bool = typer.Option(
        False,
        "--cloud",
        help="Call OpenCrew Cloud / hosted API (config: remote.api_url)",
    ),
    daytona_api: bool = typer.Option(
        False,
        "--daytona",
        help="Call a Daytona-backed OpenCrew API (config: daytona.api_url)",
    ),
    skip_local_preflight: bool = typer.Option(
        False,
        "--skip-local-preflight",
        help="Skip GET /health checks before local API runs (advanced / CI)",
    ),
):
    """Run an agent with a message and stream the response.

    By default, the CLI uses cloud API when ``remote`` is set in ~/.opencrew/config.yaml, else local.
    Use ``--local``, ``--cloud``, or ``--daytona`` to force one target.
    """
    api_target = _resolve_target(local_api, cloud_api, daytona_api)

    from opencrew.cli.run_cmd import run_run
    run_run(
        agent,
        message,
        client_id=client,
        verbose=verbose,
        fresh=fresh,
        allow_partial=allow_partial,
        connect=connect,
        api_target=api_target,
        skip_local_preflight=skip_local_preflight,
    )


@app.command()
def chat(
    agent: str = typer.Argument(..., help="Agent type slug"),
    continue_chat: str = typer.Option(
        None,
        "--continue", "-C",
        help="Chat ID to continue (prefix match OK)",
    ),
    list_chats: bool = typer.Option(
        False,
        "--list", "-l",
        help="List recent chat sessions instead of starting one",
    ),
    client: str = typer.Option(None, "--client", "-c", help="Client ID for scoped memory"),
    instance: str = typer.Option(None, "--instance", "-i", help="Instance ID (prefix OK)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show reasoning and tool calls"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Interactive back-and-forth chat with an agent.

    Start a new session or continue an existing one.

    \b
    Examples:
      opencrew chat agent-avi              # new or pick from recent
      opencrew chat agent-avi -C abc123    # continue a specific chat
      opencrew chat agent-avi --list       # show recent chats
      opencrew chat agent-avi -i abc123    # chat with a specific instance
    """
    api_target = _resolve_target(local_api, cloud_api)

    if list_chats:
        from opencrew.cli.chat_cmd import run_chat_list
        run_chat_list(agent, api_target=api_target)
        return

    from opencrew.cli.chat_cmd import run_chat
    run_chat(
        agent,
        chat_id=continue_chat,
        client_id=client,
        instance_id=instance,
        verbose=verbose,
        api_target=api_target,
    )


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------

providers_app = typer.Typer(
    help="Manage LLM provider API keys (Anthropic, OpenAI, Google, xAI, and more).",
    invoke_without_command=True,
)
app.add_typer(providers_app, name="providers")


@providers_app.callback()
def providers_default(
    ctx: typer.Context,
    local_api: bool = typer.Option(False, "--local", help="Show local providers"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Show cloud providers"),
    check: bool = typer.Option(False, "--check", help="Ping each provider API to detect bad keys"),
):
    """Manage LLM provider API keys (Anthropic, OpenAI, Google, xAI, and more)."""
    if ctx.invoked_subcommand is None:
        from opencrew.cli.providers_cmd import run_providers_list

        run_providers_list(api_target=_resolve_target(local_api, cloud_api), check=check)


@providers_app.command(name="list")
def providers_list_cmd(
    local_api: bool = typer.Option(False, "--local", help="Show local providers"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Show cloud providers"),
    check: bool = typer.Option(False, "--check", help="Ping each provider API to detect bad keys"),
):
    """Show configured provider keys and their status."""
    from opencrew.cli.providers_cmd import run_providers_list

    run_providers_list(api_target=_resolve_target(local_api, cloud_api), check=check)


@providers_app.command("verify")
def providers_verify_cmd(
    local_api: bool = typer.Option(False, "--local", help="Verify local keys"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Verify cloud keys"),
):
    """Test configured keys against each provider's API (invalid keys must be replaced)."""
    from opencrew.cli.providers_cmd import run_providers_verify

    run_providers_verify(api_target=_resolve_target(local_api, cloud_api))


@providers_app.command("set")
def providers_set_cmd(
    provider: str = typer.Argument(..., help="Provider slug (e.g. anthropic, openai, google, xai)"),
    local_api: bool = typer.Option(False, "--local", help="Set on local"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Set on cloud"),
):
    """Set or update an LLM provider API key."""
    from opencrew.cli.providers_cmd import run_providers_set

    run_providers_set(provider, api_target=_resolve_target(local_api, cloud_api))


@providers_app.command("remove")
def providers_remove_cmd(
    provider: str = typer.Argument(..., help="Provider slug (e.g. anthropic, openai, google, xai)"),
    local_api: bool = typer.Option(False, "--local", help="Remove from local"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Remove from cloud"),
):
    """Remove an LLM provider API key."""
    from opencrew.cli.providers_cmd import run_providers_remove

    run_providers_remove(provider, api_target=_resolve_target(local_api, cloud_api))


connections_app = typer.Typer(
    help="List and connect Composio tools for your workspace API key.",
    invoke_without_command=True,
)
app.add_typer(connections_app, name="connections")


@connections_app.callback()
def connections_default(
    ctx: typer.Context,
    client: str = typer.Option(None, "--client", "-c", help="Client ID for scoped connections"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """List and connect Composio tools for your workspace API key."""
    if ctx.invoked_subcommand is None:
        from opencrew.cli.connections_cmd import run_connections_list

        run_connections_list(client_id=client, api_target=_resolve_target(local_api, cloud_api))


@connections_app.command("list")
def connections_list_cmd(
    client: str = typer.Option(None, "--client", "-c", help="Client ID for scoped connections"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Show tool connections for the current workspace (and client, if set)."""
    from opencrew.cli.connections_cmd import run_connections_list

    run_connections_list(client_id=client, api_target=_resolve_target(local_api, cloud_api))


@connections_app.command("connect")
def connections_connect_cmd(
    toolkit: str = typer.Argument(..., help="Composio toolkit slug, e.g. github, gmail"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID"),
    agent: str = typer.Option(
        None,
        "--agent",
        "-a",
        help="Agent type slug — if set, wait until readiness includes this toolkit",
    ),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Start OAuth (or no-auth) for one toolkit."""
    from opencrew.cli.connections_cmd import run_connections_connect

    run_connections_connect(toolkit, client_id=client, agent=agent, api_target=_resolve_target(local_api, cloud_api))


@connections_app.command("sync")
def connections_sync_cmd(
    agent: str = typer.Argument(..., help="Agent type slug to satisfy readiness for"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Connect every toolkit this agent type is still missing (from GET …/readiness)."""
    from opencrew.cli.connections_cmd import run_connections_sync

    run_connections_sync(agent, client_id=client, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def memory(
    agent: str = typer.Argument(..., help="Agent type slug"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID"),
    instance: str = typer.Option(None, "--instance", "-i", help="Instance ID (prefix OK; default: first instance)"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Show agent memory blocks."""
    from opencrew.cli.memory_cmd import run_memory
    run_memory(agent, client_id=client, instance_id=instance, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def reset(
    agent: str = typer.Argument(..., help="Agent type slug"),
    client: str = typer.Option(None, "--client", "-c", help="Client ID"),
    instance: str = typer.Option(None, "--instance", "-i", help="Instance ID (prefix OK; default: first instance)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Reset agent memory (delete and recreate instance)."""
    from opencrew.cli.memory_cmd import run_reset
    run_reset(agent, client_id=client, instance_id=instance, skip_confirm=yes, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def logs(
    agent: str = typer.Argument(None, help="Agent type slug (optional filter)"),
    status: str = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of runs to show"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Show run history."""
    from opencrew.cli.logs_cmd import run_logs
    run_logs(agent_type=agent, status=status, limit=limit, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def tools(
    action: str = typer.Argument("list", help="Action: list, add-mcp"),
    agent: str = typer.Option(None, "--agent", "-a", help="Show tools for a specific agent type"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
):
    """Manage tools and MCP servers.

    \b
    Examples:
      opencrew tools                     # list all workspace tools
      opencrew tools --agent agent-avi   # show tools for agent-avi
    """
    from opencrew.cli.tools_cmd import run_tools
    run_tools(action, agent=agent, api_target=_resolve_target(local_api, cloud_api))


@app.command()
def skills(
    action: str = typer.Argument("list", help="Action: list, create, install"),
    name_or_source: str = typer.Argument(None, help="Skill name (for create) or source (for install)"),
    agent: str = typer.Option(None, "--agent", "-a", help="Filter by agent type slug"),
):
    """Manage agent skills."""
    from opencrew.cli.skills_cmd import run_skills_create, run_skills_install, run_skills_list
    if action == "create":
        if not name_or_source:
            import rich
            rich.print("[red]Usage: opencrew skills create <name>[/red]")
            raise SystemExit(1)
        run_skills_create(name_or_source)
    elif action == "install":
        if not name_or_source:
            import rich
            rich.print("[red]Usage: opencrew skills install <source>[/red]")
            raise SystemExit(1)
        run_skills_install(name_or_source)
    elif action == "list":
        run_skills_list(agent=agent)
    else:
        import rich
        rich.print(f"[red]Unknown action: {action}. Use 'list', 'create', or 'install'.[/red]")
        raise SystemExit(1)


@app.command(name="test")
def test_cmd(
    agent: str = typer.Argument(..., help="Agent type slug"),
    path: str = typer.Argument(None, help="Specific test file (optional)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show responses and all assertions"),
    parallel: bool = typer.Option(False, "--parallel", help="Run tests concurrently"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
    timeout: int = typer.Option(120, "--timeout", help="Per-step timeout in seconds"),
    local_api: bool = typer.Option(False, "--local", help="Use local API"),
    cloud_api: bool = typer.Option(False, "--cloud", help="Use cloud API"),
    no_apply: bool = typer.Option(
        False,
        "--no-apply",
        help="Do not push local agent.yaml to the API before running (test server state as-is)",
    ),
):
    """Run agent test cases."""
    from opencrew.cli.test_cmd import run_tests
    run_tests(
        agent,
        path=path,
        verbose=verbose,
        parallel=parallel,
        json_output=json_output,
        timeout=timeout,
        api_target=_resolve_target(local_api, cloud_api),
        no_apply=no_apply,
    )


if __name__ == "__main__":
    app()
