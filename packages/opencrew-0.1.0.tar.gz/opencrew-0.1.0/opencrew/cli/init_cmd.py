from __future__ import annotations

import getpass
import hashlib
import os
import secrets
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from opencrew.user_config import (
    get_local,
    get_remote,
    has_local_stack,
    is_remote_configured,
    normalize_config,
)

console = Console()

OPENCREW_HOME = Path.home() / ".opencrew"
BUNDLED_DIR = Path(__file__).parent.parent / "_bundled"
DEV_ROOT = Path(__file__).parent.parent.parent  # cli/ directory in dev mode
CONFIG_PATH = OPENCREW_HOME / "config.yaml"
PID_PATH = OPENCREW_HOME / "server.pid"
LOG_PATH = OPENCREW_HOME / "server.log"

SETUP_MODE_LOCAL = "local"
SETUP_MODE_CLOUD = "cloud"

# Public OpenCrew Cloud API (shown as default in `init`; normalized to origin without /v1 for storage).
DEFAULT_CLOUD_API_BASE_URL = "https://api.opencrew.site/v1"

# Default Letta server for hosted OpenCrew Cloud (BYO row per workspace replaces missing API LETTA_* env).
DEFAULT_HOSTED_LETTA_BASE_URL = "https://server.opencrew.site"


def _is_hosted_opencrew_api(api_url: str) -> bool:
    from urllib.parse import urlparse

    host = (urlparse(api_url).hostname or "").lower()
    return host in ("api.opencrew.site", "www.api.opencrew.site")


def _resolve_default_letta_api_token() -> str:
    """Token for hosted Letta when the user leaves the prompt empty (shell env only — never commit secrets)."""
    for key in (
        "OPENCREW_DEFAULT_LETTA_API_TOKEN",
        "OPENCREW_LETTA_API_TOKEN",
        "LETTA_API_TOKEN",
    ):
        v = (os.environ.get(key) or "").strip()
        if v:
            return v
    return ""


def _letta_sync_blocked_response(resp: object) -> bool:
    try:
        import httpx

        if not isinstance(resp, httpx.Response) or resp.status_code != 409:
            return False
        data = resp.json()
        detail = data.get("detail")
        if isinstance(detail, dict):
            return detail.get("error") == "letta_connection_blocked"
    except Exception:
        return False
    return False


def _push_workspace_letta_to_api(
    api_base: str,
    api_key: str,
    letta_base_url: str,
    letta_api_token: str,
    *,
    interactive: bool,
) -> None:
    """POST-like PATCH so the workspace uses this Letta deployment (entity_letta_settings)."""
    import httpx

    base = api_base.rstrip("/")

    def _patch(*, force: bool) -> httpx.Response:
        q = {"force": "true"} if force else None
        return httpx.patch(
            f"{base}/v1/workspaces/current/letta-connection",
            json={"letta_base_url": letta_base_url, "api_token": letta_api_token},
            headers={"X-Api-Key": api_key},
            params=q,
            timeout=30.0,
        )

    try:
        r = _patch(force=False)
    except Exception as exc:
        console.print(
            f"[yellow]  Could not save Letta connection to the API: {exc}[/yellow]\n"
            "[dim]  You can retry later (dashboard or PATCH /v1/workspaces/current/letta-connection).[/dim]",
        )
        return

    if _letta_sync_blocked_response(r):
        do_force = False
        if interactive:
            console.print(
                "[yellow]  Existing agent instances block switching Letta.[/yellow]\n"
                "[dim]  Force update invalidates those instances (Letta agents must be recreated).[/dim]",
            )
            ans = console.input("  [bold]Force Letta connection anyway?[/bold] [dim][y/N][/dim]: ").strip().lower()
            do_force = ans == "y"
        elif (os.environ.get("OPENCREW_LETTA_SYNC_FORCE") or "").strip() in ("1", "true", "yes"):
            do_force = True
        if do_force:
            try:
                r = _patch(force=True)
            except Exception as exc:
                console.print(f"[yellow]  Forced Letta sync failed: {exc}[/yellow]")
                return
        else:
            console.print(
                "[dim]  Skipping server sync. Set OPENCREW_LETTA_SYNC_FORCE=1 to force in non-interactive mode, "
                "or delete agent instances in the dashboard.[/dim]",
            )
            return

    if r.is_success:
        console.print("  [green]✓[/green] Letta connection stored for this workspace on the server.")
    else:
        console.print(
            f"[yellow]  Letta sync failed (HTTP {r.status_code}).[/yellow]\n"
            f"[dim]  {r.text[:400]}[/dim]",
        )


def _remote_only_machine(config: dict | None) -> bool:
    """Remote API is configured and there is no local Docker/Postgres stack."""
    return is_remote_configured(config) and not has_local_stack(config)


def _prompt_reinit() -> bool:
    """If config exists, ask to proceed. Exit if user declines."""
    if not CONFIG_PATH.exists():
        return True
    console.print(f"\n[yellow]Found existing config at[/yellow] [cyan]{CONFIG_PATH}[/cyan]")
    console.print(
        "[dim][bold]opencrew init[/bold] refreshes your [bold]local[/bold] Docker/API setup and keeps "
        "[bold]remote:[/bold] (if any) unless you clear it in the file. "
        "To add or change cloud credentials, run [bold]opencrew remote[/bold].[/dim]",
    )
    ans = console.input("[bold]Continue with setup?[/bold] [dim][y/N][/dim]: ").strip().lower()
    if ans != "y":
        console.print(
            "[dim]Left config unchanged. Add cloud API: [bold]opencrew remote[/bold] · "
            "Edit [bold]~/.opencrew/config.yaml[/bold] for advanced changes.[/dim]",
        )
        raise SystemExit(0)
    return True


def _normalize_api_base_url(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if not u:
        return u
    if not u.startswith(("http://", "https://")):
        u = "https://" + u
    u = u.rstrip("/")
    # Many users (and docs) use ".../v1"; health + SDK expect the origin (paths already include /v1/...).
    if u.endswith("/v1"):
        u = u[: -len("/v1")].rstrip("/")
    return u


def _verify_cloud_connection(api_url: str, api_key: str) -> tuple[bool, str]:
    import httpx

    base = api_url.rstrip("/")
    try:
        r = httpx.get(f"{base}/health", timeout=15.0)
        if r.status_code >= 500:
            return False, f"/health returned HTTP {r.status_code}"
    except Exception as exc:
        return False, f"Could not reach {base}/health: {exc}"

    try:
        r2 = httpx.get(
            f"{base}/v1/agent-types",
            headers={"X-Api-Key": api_key},
            timeout=20.0,
        )
    except Exception as exc:
        return False, f"Could not call API: {exc}"

    if r2.status_code == 401:
        return False, "API key was rejected (401 — check the key spelling and that it is not revoked)"
    if r2.status_code == 403:
        return False, "Access forbidden (403 — key may be missing workspace scope)"
    if r2.status_code == 404:
        return False, "GET /v1/agent-types not found (404) — is this an OpenCrew API base URL?"
    if r2.status_code >= 500:
        return False, f"Server error HTTP {r2.status_code}"
    return True, ""


def _collect_llm_keys_for_local(
    anthropic_api_key: str | None,
    openai_api_key: str | None,
) -> tuple[str | None, str | None]:
    """Prompt for Anthropic / OpenAI so Letta can call models (local stack only)."""
    if anthropic_api_key is None:
        anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY")
    if openai_api_key is None:
        openai_api_key = os.environ.get("OPENAI_API_KEY")

    console.print()
    console.print(
        Panel.fit(
            "[bold]LLM providers (local Letta)[/bold]\n\n"
            "Your agents need at least one provider so Letta can run models.\n"
            "Keys are sent only to [bold]your local Letta[/bold] container (not to OpenCrew Cloud).\n\n"
            "[dim]You can skip both and add providers later in the Letta UI if you prefer.[/dim]",
            border_style="blue",
        )
    )

    if anthropic_api_key:
        console.print("[green]✓[/green] Using [bold]Anthropic[/bold] from environment or flag.")
    else:
        anthropic_api_key = console.input(
            "\n[bold]Anthropic API key[/bold] [dim](https://console.anthropic.com — Enter to skip)[/dim]:\n  ",
        ).strip() or None

    if openai_api_key:
        console.print("[green]✓[/green] Using [bold]OpenAI[/bold] from environment or flag.")
    else:
        openai_api_key = console.input(
            "[bold]OpenAI API key[/bold] [dim](https://platform.openai.com — optional, Enter to skip)[/dim]:\n  ",
        ).strip() or None

    if not anthropic_api_key and not openai_api_key:
        console.print(
            "\n[yellow]![/yellow] No provider keys yet — only free/Letta-default models may work until you add a key "
            "in Letta or re-run [bold]opencrew init[/bold]."
        )
    return anthropic_api_key, openai_api_key


def _bundled_docker_dir() -> Path:
    bundled = BUNDLED_DIR / "docker"
    if bundled.exists():
        return bundled
    dev = DEV_ROOT / "docker"
    if dev.exists():
        return dev
    console.print("[red]Cannot find bundled docker files.[/red]")
    raise SystemExit(1)


def _bundled_template_dir() -> Path:
    bundled = BUNDLED_DIR / "templates"
    if bundled.exists():
        return bundled
    dev = DEV_ROOT / "templates"
    if dev.exists():
        return dev
    console.print("[red]Cannot find bundled templates.[/red]")
    raise SystemExit(1)


def _load_config() -> dict:
    if not CONFIG_PATH.exists():
        console.print("[red]OpenCrew not initialized. Run `opencrew init` first.[/red]")
        raise SystemExit(1)
    return normalize_config(yaml.safe_load(CONFIG_PATH.read_text()) or {})


def _save_config(cfg: dict) -> None:
    """Write config with ``local`` / ``remote`` sections (normalized)."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_config(cfg)
    out = {
        "setup_mode": normalized.get("setup_mode", SETUP_MODE_LOCAL),
        "local": dict(normalized.get("local") or {}),
        "remote": dict(normalized.get("remote") or {}),
    }
    CONFIG_PATH.write_text(yaml.dump(out, default_flow_style=False, sort_keys=False))


def _check_command(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run(args: list[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True, **kwargs)


def _wait_for_health(url: str, label: str, timeout: int = 60) -> bool:
    """Poll a URL until it returns 200 or timeout expires."""
    import httpx
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            resp = httpx.get(url, timeout=5)
            if resp.status_code < 500:
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def _db_endpoint_hint(db_url: str) -> str:
    from urllib.parse import urlparse

    p = urlparse(db_url)
    host = p.hostname or "database"
    port = f":{p.port}" if p.port else ""
    return f"{host}{port}"


def _postgres_ping(db_url: str, *, connect_timeout: int = 5) -> bool:
    try:
        import psycopg
        with psycopg.connect(db_url, connect_timeout=connect_timeout) as conn:
            conn.execute("SELECT 1")
        return True
    except Exception:
        return False


def _wait_for_local_postgres(db_url: str, *, timeout: int = 120) -> bool:
    """Block until ``db_url`` accepts connections (Compose ``db`` service is up)."""
    hint = _db_endpoint_hint(db_url)
    console.print(f"[dim]Waiting for Postgres at {hint}…[/dim]")
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _postgres_ping(db_url):
            console.print("[green]✓[/green] Postgres is ready")
            return True
        time.sleep(2)
    console.print(
        f"[red]Postgres at {hint} did not become ready within {timeout}s.[/red]\n"
        "[dim]Check: docker compose ps (in ~/.opencrew/docker), Docker Desktop running, port 5432 free.[/dim]",
    )
    return False


def _docker_compose_up(docker_dir: Path) -> None:
    """``docker compose up -d``. Uses ``--wait`` when supported so ``db`` healthcheck passes before return."""
    r = subprocess.run(
        ["docker", "compose", "up", "-d", "--wait"],
        cwd=docker_dir,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if r.returncode == 0:
        console.print("[green]✓[/green] Docker Compose stack is up")
        return
    err = ((r.stderr or "") + (r.stdout or "")).lower()
    if any(s in err for s in ("unknown flag", "invalid choice", "unrecognized", "see 'docker compose up")):
        r2 = subprocess.run(
            ["docker", "compose", "up", "-d"],
            cwd=docker_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if r2.returncode != 0:
            console.print(f"[red]Failed to start containers: {r2.stderr or r2.stdout}[/red]")
            raise SystemExit(1)
        console.print("[green]✓[/green] Docker Compose containers started [dim](upgrade Docker for `compose up --wait`)[/dim]")
        return
    console.print(f"[red]Failed to start containers: {r.stderr or r.stdout}[/red]")
    raise SystemExit(1)


def _api_daemon_pid_running() -> tuple[int | None, bool]:
    """Return (pid, True) if PID file points to a live process."""
    if not PID_PATH.exists():
        return None, False
    try:
        pid = int(PID_PATH.read_text().strip())
    except ValueError:
        PID_PATH.unlink(missing_ok=True)
        return None, False
    try:
        os.kill(pid, 0)
        return pid, True
    except OSError:
        PID_PATH.unlink(missing_ok=True)
        return None, False


def _local_api_health_ok() -> bool:
    import httpx

    try:
        r = httpx.get("http://127.0.0.1:8741/health", timeout=5)
        if r.status_code != 200:
            return False
        data = r.json()
        return isinstance(data, dict) and data.get("status") == "ok"
    except Exception:
        return False


def _stop_api_daemon_silent() -> None:
    if not PID_PATH.exists():
        return
    try:
        pid = int(PID_PATH.read_text().strip())
        os.kill(pid, signal.SIGTERM)
    except (ValueError, OSError):
        pass
    PID_PATH.unlink(missing_ok=True)


def _generate_api_key() -> tuple[str, str]:
    """Generate an API key and return (raw_key, key_hash)."""
    raw = "lmp_" + secrets.token_hex(16)
    key_hash = hashlib.sha256(raw.encode()).hexdigest()
    return raw, key_hash


def run_init_cloud(
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    merge_base: dict | None = None,
) -> None:
    """Save ~/.opencrew/config for a remote OpenCrew API (workspace key)."""
    api_url = api_url or os.environ.get("OPENCREW_API_URL")
    api_key = api_key or os.environ.get("OPENCREW_API_KEY")

    console.print("\n[bold cyan]☁️  OpenCrew — connect to your API[/bold cyan]\n")

    if not (api_url and api_key):
        console.print(
            Panel.fit(
                "You’ll need:\n"
                "  • Base URL of the OpenCrew API (hosted default below, or your own host)\n"
                "  • A [bold]workspace[/bold] API key ([dim]often starts with lmp_[/dim])\n\n"
                f"[dim]Press Enter at the URL prompt to use [bold]{DEFAULT_CLOUD_API_BASE_URL}[/bold].[/dim]\n"
                f"[dim]For hosted OpenCrew, Letta defaults to [bold]{DEFAULT_HOSTED_LETTA_BASE_URL}[/bold]; "
                "set [bold]LETTA_API_TOKEN[/bold] in the shell or paste at the prompt.[/dim]\n\n"
                "[dim]The key is read with hidden input — it won’t echo to the screen.[/dim]",
                title="Cloud / remote",
                border_style="cyan",
            )
        )

    if api_url:
        raw_url = api_url
    else:
        raw_url = console.input(
            f"\n[bold]API base URL[/bold] "
            f"[dim](default: {DEFAULT_CLOUD_API_BASE_URL} — Enter to accept)[/dim]:\n  ",
        ).strip() or DEFAULT_CLOUD_API_BASE_URL
    url = _normalize_api_base_url(raw_url)
    if not url:
        console.print("[red]URL is required.[/red]")
        raise SystemExit(1)

    if api_key:
        key = api_key.strip()
    else:
        console.print(
            "\n[bold]Workspace API key[/bold] [dim](input hidden — paste and press Enter)[/dim]:",
        )
        key = getpass.getpass("  ").strip()

    if not key:
        console.print("[red]API key is required.[/red]")
        raise SystemExit(1)

    console.print("\n  Checking connection to your API…")
    ok, err = _verify_cloud_connection(url, key)
    if not ok:
        console.print(f"[red]  ✗ {err}[/red]")
        console.print(
            "[dim]Fix the URL or key, then run [bold]opencrew remote[/bold] again "
            "([bold]opencrew init --cloud[/bold] is the same) or set OPENCREW_API_URL and OPENCREW_API_KEY.[/dim]",
        )
        raise SystemExit(1)
    console.print("  [green]✓[/green] API reachable and key accepted\n")

    base = normalize_config(merge_base or {})
    local_part = dict(base.get("local") or {})
    remote_part = dict(base.get("remote") or {})
    remote_part["api_url"] = url
    remote_part["api_key"] = key

    # Hosted cloud: default Letta URL from env (scripted init / CI) when token is present.
    if _is_hosted_opencrew_api(url) and not (
        remote_part.get("letta_base_url") and remote_part.get("letta_api_token")
    ):
        env_tok = _resolve_default_letta_api_token()
        if env_tok:
            env_letta_url = (os.environ.get("OPENCREW_LETTA_BASE_URL") or "").strip()
            remote_part["letta_base_url"] = _normalize_api_base_url(
                env_letta_url or DEFAULT_HOSTED_LETTA_BASE_URL
            )
            remote_part["letta_api_token"] = env_tok

    has_saved_letta = bool(
        remote_part.get("letta_base_url") and remote_part.get("letta_api_token")
    )
    if sys.stdin.isatty() and not has_saved_letta:
        letta_url_final: str | None = None
        letta_token_final: str | None = None
        if _is_hosted_opencrew_api(url):
            console.print(
                "[dim]Hosted OpenCrew uses the shared Letta server by default. "
                "Press Enter to use it. For the token, paste one or leave blank to use "
                "[bold]LETTA_API_TOKEN[/bold] / [bold]OPENCREW_DEFAULT_LETTA_API_TOKEN[/bold] from your environment.[/dim]",
            )
            raw_letta = console.input(
                f"  Letta base URL [dim](default: {DEFAULT_HOSTED_LETTA_BASE_URL} — Enter)[/dim]:\n  ",
            ).strip() or DEFAULT_HOSTED_LETTA_BASE_URL
            letta_url_final = _normalize_api_base_url(raw_letta)
            console.print(
                "  [bold]Letta API token[/bold] [dim](hidden — Enter to use env default)[/dim]:",
            )
            letta_token_final = getpass.getpass("  ").strip()
            if not letta_token_final:
                letta_token_final = _resolve_default_letta_api_token()
                if letta_token_final:
                    console.print(
                        "  [dim]Using Letta token from [bold]LETTA_API_TOKEN[/bold] "
                        "or [bold]OPENCREW_DEFAULT_LETTA_API_TOKEN[/bold].[/dim]",
                    )
            if not letta_token_final:
                console.print(
                    "[yellow]  No token — set LETTA_API_TOKEN (or OPENCREW_DEFAULT_LETTA_API_TOKEN) and run "
                    "[bold]opencrew remote[/bold] again, or configure in the dashboard.[/yellow]",
                )
                letta_url_final = None
        else:
            console.print(
                "[dim]Optional — self-hosted Letta (BYO). Enter to skip.[/dim]",
            )
            raw_letta = console.input("  Letta base URL [dim](HTTPS, Enter to skip)[/dim]:\n  ").strip()
            if raw_letta:
                letta_url_final = _normalize_api_base_url(raw_letta)
                console.print("  [bold]Letta API token[/bold] [dim](hidden)[/dim]:")
                letta_token_final = getpass.getpass("  ").strip()
                if not letta_token_final:
                    console.print(
                        "[yellow]  Token is required when a URL is set — skipping Letta config.[/yellow]",
                    )
                    letta_url_final = None
        if letta_url_final and letta_token_final:
            remote_part["letta_base_url"] = letta_url_final
            remote_part["letta_api_token"] = letta_token_final

    _save_config(
        {
            "setup_mode": SETUP_MODE_CLOUD,
            "local": local_part,
            "remote": remote_part,
        },
    )

    console.print("[bold green]✅ Remote settings saved.[/bold green]")
    console.print(f"   [bold]remote.api_url[/bold]: [cyan]{url}[/cyan]")
    lb = remote_part.get("letta_base_url")
    if lb:
        console.print(f"   [bold]remote.letta_base_url[/bold]: [cyan]{lb}[/cyan]")
    if remote_part.get("letta_base_url") and remote_part.get("letta_api_token"):
        _push_workspace_letta_to_api(
            url,
            key,
            remote_part["letta_base_url"],
            remote_part["letta_api_token"],
            interactive=sys.stdin.isatty(),
        )
    if local_part.get("db_url"):
        console.print("   [dim]Your [bold]local[/bold] stack settings were kept — run [bold]opencrew start[/bold] to use Docker.[/dim]")
    console.print(f"   Config: [dim]{CONFIG_PATH}[/dim]")
    console.print(
        "\n[bold]Next steps[/bold]\n"
        "  • [bold]opencrew create my-agent[/bold] — scaffold [dim]agent.yaml[/dim]\n"
        "  • [bold]opencrew apply my-agent/agent.yaml[/bold] — push config to the API (if your server supports apply)\n"
        "  • [bold]opencrew run my-agent \"Hello\"[/bold] — start a run\n"
        "  • [bold]opencrew doctor[/bold] — verify connectivity\n",
    )


def _run_init_local(
    *,
    merge_base: dict,
    anthropic_api_key: str | None,
    openai_api_key: str | None,
) -> None:
    """Full local stack: Docker, Letta, migrations, API daemon."""
    console.print("\n[bold cyan]🖥️  OpenCrew — local stack[/bold cyan]\n")

    base = normalize_config(merge_base)
    anthropic_api_key, openai_api_key = _collect_llm_keys_for_local(anthropic_api_key, openai_api_key)

    # --- Prereq checks (before progress spinner) ---
    console.print("\n[bold]Step:[/bold] Checking Docker and Node.js…")
    if not _check_command("docker"):
        console.print("[red]  ✗ Docker not found. Install Docker Desktop: https://docker.com/products/docker-desktop[/red]")
        raise SystemExit(1)
    result = _run(["docker", "info"])
    if result.returncode != 0:
        console.print("[red]  ✗ Docker daemon not running. Start Docker Desktop and try again.[/red]")
        raise SystemExit(1)
    docker_ver = _run(["docker", "--version"]).stdout.strip()
    console.print(f"    [green]✓[/green] Docker ({docker_ver})")

    if not _check_command("node"):
        console.print("[red]  ✗ Node.js not found. Install from https://nodejs.org/[/red]")
        raise SystemExit(1)
    node_ver = _run(["node", "--version"]).stdout.strip()
    console.print(f"    [green]✓[/green] Node.js {node_ver}")

    console.print("\n[bold]Step:[/bold] Installing Letta Code SDK locally (for tooling)…")
    OPENCREW_HOME.mkdir(parents=True, exist_ok=True)
    result = _run(["npm", "install", "--prefix", str(OPENCREW_HOME), "@letta-ai/letta-code-sdk", "tsx"])
    if result.returncode != 0:
        console.print(f"[red]  ✗ Failed to install Letta SDK: {result.stderr[:300]}[/red]")
        raise SystemExit(1)
    console.print("    [green]✓[/green] Letta Code SDK + tsx installed")

    console.print()

    # --- Infrastructure setup (with progress spinner) ---
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        # 4. Create ~/.opencrew directory
        task = progress.add_task("Creating config directory...", total=None)
        OPENCREW_HOME.mkdir(parents=True, exist_ok=True)
        progress.update(task, description="[green]✓[/green] Config directory created")

        # 5. Copy docker-compose files
        task = progress.add_task("Setting up Docker Compose...", total=None)
        docker_src = _bundled_docker_dir()
        docker_dst = OPENCREW_HOME / "docker"
        if docker_dst.exists():
            shutil.rmtree(docker_dst)
        shutil.copytree(docker_src, docker_dst)
        os.chmod(docker_dst / "init-db.sh", 0o755)
        progress.update(task, description="[green]✓[/green] Docker Compose configured")

        # 6. Docker compose pull
        task = progress.add_task("Pulling Docker images...", total=None)
        result = _run(["docker", "compose", "pull"], cwd=docker_dst)
        if result.returncode != 0:
            console.print(f"[red]Failed to pull images: {result.stderr}[/red]")
            raise SystemExit(1)
        progress.update(task, description="[green]✓[/green] Docker images pulled")

        # 7. Docker compose up
        task = progress.add_task("Starting containers...", total=None)
        env = os.environ.copy()
        if anthropic_api_key:
            env["ANTHROPIC_API_KEY"] = anthropic_api_key
        if openai_api_key:
            env["OPENAI_API_KEY"] = openai_api_key
        result = _run(["docker", "compose", "up", "-d"], cwd=docker_dst, env=env)
        if result.returncode != 0:
            console.print(f"[red]Failed to start containers: {result.stderr}[/red]")
            raise SystemExit(1)
        progress.update(task, description="[green]✓[/green] Containers started")

        # 8. Wait for Postgres
        task = progress.add_task("Waiting for Postgres...", total=None)
        db_url = "postgresql://opencrew:opencrew@localhost:5432/opencrew"
        for _ in range(30):
            try:
                import psycopg
                with psycopg.connect(db_url) as conn:
                    conn.execute("SELECT 1")
                break
            except Exception:
                time.sleep(1)
        else:
            console.print("[red]Postgres did not become healthy in time.[/red]")
            raise SystemExit(1)
        progress.update(task, description="[green]✓[/green] Postgres healthy")

        # 9. Wait for Letta server
        task = progress.add_task("Waiting for Letta server...", total=None)
        letta_url = "http://localhost:8283"
        if not _wait_for_health(f"{letta_url}/v1/health", "Letta server", timeout=120):
            console.print("[red]Letta server did not become healthy in time.[/red]")
            raise SystemExit(1)
        progress.update(task, description="[green]✓[/green] Letta server healthy")

        # 9b. Configure LLM providers on Letta server
        if anthropic_api_key or openai_api_key:
            task = progress.add_task("Configuring LLM providers...", total=None)
            import httpx

            _lh = {"Content-Type": "application/json"}
            _tok = _resolve_default_letta_api_token()
            if _tok:
                _lh["Authorization"] = f"Bearer {_tok}"
            configured = []
            if anthropic_api_key:
                try:
                    resp = httpx.post(
                        f"{letta_url}/v1/providers/",
                        headers=_lh,
                        json={"name": "anthropic", "provider_type": "anthropic", "api_key": anthropic_api_key},
                        timeout=15,
                    )
                    if resp.status_code < 400:
                        configured.append("Anthropic")
                except Exception:
                    pass
            if openai_api_key:
                try:
                    resp = httpx.post(
                        f"{letta_url}/v1/providers/",
                        headers=_lh,
                        json={"name": "openai", "provider_type": "openai", "api_key": openai_api_key},
                        timeout=15,
                    )
                    if resp.status_code < 400:
                        configured.append("OpenAI")
                except Exception:
                    pass
            if configured:
                progress.update(task, description=f"[green]✓[/green] Providers configured: {', '.join(configured)}")
            else:
                progress.update(task, description="[yellow]![/yellow] No providers configured — only letta/letta-free available")

        # 10. Run database migrations
        task = progress.add_task("Running migrations...", total=None)
        from opencrew.store.migrate import run_migrations
        run_migrations(db_url)
        progress.update(task, description="[green]✓[/green] Migrations complete")

        # 11. Create entity and API key
        task = progress.add_task("Creating API key...", total=None)
        import psycopg
        raw_key, key_hash = _generate_api_key()
        owner_id = "local"
        entity_id = "local-entity"

        with psycopg.connect(db_url) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO entities (id, owner_id, name, slug) VALUES (%s, %s, %s, %s) ON CONFLICT (id) DO NOTHING",
                    (entity_id, owner_id, "Local Development", "local"),
                )
                cur.execute(
                    "INSERT INTO api_keys (owner_id, entity_id, label, key_hash, key_prefix) VALUES (%s, %s, %s, %s, %s)",
                    (owner_id, entity_id, "CLI default key", key_hash, raw_key[:8]),
                )
            conn.commit()
        progress.update(task, description="[green]✓[/green] API key created")

        # 12. Write config (``local:`` + preserve ``remote:``)
        task = progress.add_task("Writing config...", total=None)
        local_new: dict = {
            **dict(base.get("local") or {}),
            "db_url": db_url,
            "letta_url": letta_url,
            "api_url": "http://localhost:8741",
            "api_key": raw_key,
        }
        if anthropic_api_key:
            local_new["anthropic_api_key"] = anthropic_api_key
        if openai_api_key:
            local_new["openai_api_key"] = openai_api_key
        remote_part = dict(base.get("remote") or {})
        full_config = {
            "setup_mode": SETUP_MODE_LOCAL,
            "local": local_new,
            "remote": remote_part,
        }
        _save_config(full_config)
        progress.update(task, description="[green]✓[/green] Config saved")

        # 13. Start API server daemon
        task = progress.add_task("Starting API server...", total=None)
        _start_server_daemon(full_config)
        progress.update(task, description="[green]✓[/green] API server started")

    console.print("\n[bold green]✅ Local OpenCrew is ready![/bold green]")
    console.print(f"   API:    [cyan]http://localhost:8741[/cyan]")
    console.print(f"   Letta:  [cyan]http://localhost:8283[/cyan]")
    console.print(f"   API key [dim](save this — shown once)[/dim]:\n          [dim]{raw_key}[/dim]")
    console.print(f"   Config: [dim]{CONFIG_PATH}[/dim]")
    console.print(
        "\n[bold]Next steps[/bold]\n"
        "  • [bold]opencrew doctor[/bold] — health check\n"
        "  • [bold]opencrew create my-agent[/bold] — new [dim]agent.yaml[/dim]\n"
        "  • [bold]opencrew apply my-agent/agent.yaml[/bold] — sync to API\n"
        "  • [bold]opencrew run my-agent \"Hello\"[/bold] — chat with your agent\n\n"
        "[dim]Config uses [bold]local:[/bold] for Docker/API and [bold]remote:[/bold] for cloud (if you add it later). "
        "The SDK uses [bold]remote[/bold] when set, else [bold]local[/bold].[/dim]\n\n"
        "[dim]Stop stack: [bold]opencrew stop[/bold] · Start again: [bold]opencrew start[/bold][/dim]",
    )


def run_remote_setup(
    *,
    cloud_api_url: str | None = None,
    cloud_api_key: str | None = None,
) -> None:
    """Add or update ``remote:`` in config (preserves ``local:``)."""
    merge_base: dict = {}
    if CONFIG_PATH.exists():
        merge_base = yaml.safe_load(CONFIG_PATH.read_text()) or {}
    run_init_cloud(api_url=cloud_api_url, api_key=cloud_api_key, merge_base=merge_base)


def run_init(
    *,
    anthropic_api_key: str | None = None,
    openai_api_key: str | None = None,
    prefer_cloud: bool = False,
    cloud_api_url: str | None = None,
    cloud_api_key: str | None = None,
) -> None:
    """Local stack by default; use ``--cloud`` or :func:`run_remote_setup` for remote API only."""
    console.print("\n[bold cyan]🚀 OpenCrew setup[/bold cyan]")

    _prompt_reinit()

    merge_base: dict = {}
    if CONFIG_PATH.exists():
        merge_base = yaml.safe_load(CONFIG_PATH.read_text()) or {}

    if prefer_cloud:
        run_init_cloud(
            api_url=cloud_api_url,
            api_key=cloud_api_key,
            merge_base=merge_base,
        )
        return

    console.print(
        "[dim]This configures the [bold]local[/bold] stack on this machine. "
        "Add a hosted workspace API anytime with [bold]opencrew remote[/bold] "
        "([bold]opencrew init --cloud[/bold] does the same).[/dim]\n",
    )

    _run_init_local(
        merge_base=merge_base,
        anthropic_api_key=anthropic_api_key,
        openai_api_key=openai_api_key,
    )


def _start_server_daemon(config: dict) -> None:
    """Start the uvicorn server as a background daemon."""
    loc = get_local(config)
    env = os.environ.copy()
    env["OPENCREW_DB_URL"] = loc["db_url"]
    env["LETTA_BASE_URL"] = loc.get("letta_url", "http://localhost:8283")
    if loc.get("api_key"):
        env["OPENCREW_API_KEY"] = loc["api_key"]
    _lt = _resolve_default_letta_api_token()
    if _lt:
        env["LETTA_API_TOKEN"] = _lt

    try:
        import opencrew.server.app as _app  # noqa: PLC0415

        pkg_root = str(Path(_app.__file__).resolve().parent.parent)
    except Exception:
        pkg_root = "(unknown)"
    banner = (
        f"\n{'=' * 72}\n"
        f"OpenCrew API daemon {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"Python: {sys.executable}\n"
        f"Loaded opencrew from: {pkg_root}\n"
        f"{'=' * 72}\n"
    )
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as bf:
        bf.write(banner)

    log_file = open(LOG_PATH, "a", encoding="utf-8")
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "uvicorn",
            "opencrew.server.app:app",
            "--host", "0.0.0.0",
            "--port", "8741",
        ],
        stdout=log_file,
        stderr=log_file,
        env=env,
        start_new_session=True,
    )
    PID_PATH.write_text(str(proc.pid))

    time.sleep(2)
    if proc.poll() is not None:
        console.print(f"[yellow]Warning: Server exited early. Check {LOG_PATH}[/yellow]")


def _register_providers(config: dict, letta_url: str) -> None:
    """Re-register LLM providers with the Letta server."""
    import httpx

    loc = get_local(config)
    headers = {"Content-Type": "application/json"}
    tok = _resolve_default_letta_api_token()
    if tok:
        headers["Authorization"] = f"Bearer {tok}"
    providers: list[tuple[str, str, str]] = []
    if loc.get("anthropic_api_key"):
        providers.append(("anthropic", "anthropic", loc["anthropic_api_key"]))
    if loc.get("openai_api_key"):
        providers.append(("openai", "openai", loc["openai_api_key"]))
    if loc.get("google_api_key"):
        # Letta model handles use prefix ``google_ai/`` (see opencrew providers set google).
        providers.append(("google_ai", "google_ai", loc["google_api_key"]))
    for name, ptype, key in providers:
        try:
            httpx.post(
                f"{letta_url}/v1/providers/",
                headers=headers,
                json={"name": name, "provider_type": ptype, "api_key": key},
                timeout=15,
            )
        except Exception:
            pass


def run_start() -> None:
    """Start OpenCrew infrastructure and API server."""
    config = _load_config()
    if _remote_only_machine(config):
        rem = get_remote(config)
        console.print(
            "[cyan]Remote-only setup[/cyan] — no local Docker stack to start.\n"
            f"SDK/API calls use [bold]{rem.get('api_url', '')}[/bold] when [bold]remote[/bold] is configured.\n"
            "[dim]Check connectivity: [bold]opencrew doctor[/bold][/dim]",
        )
        return

    console.print("[cyan]Starting OpenCrew…[/cyan]")

    docker_dir = OPENCREW_HOME / "docker"
    if not docker_dir.exists():
        console.print("[red]Docker files not found. Run `opencrew init` first.[/red]")
        raise SystemExit(1)

    loc = get_local(config)
    db_url = loc.get("db_url")
    if not db_url:
        console.print("[red]local.db_url missing in config. Re-run `opencrew init` for a local stack.[/red]")
        raise SystemExit(1)

    # Always (re)apply Compose so Postgres/Letta are up — even if the API daemon PID is stale.
    _docker_compose_up(docker_dir)

    if not _wait_for_local_postgres(str(db_url), timeout=120):
        raise SystemExit(1)

    letta_url = loc.get("letta_url", "http://localhost:8283")
    if _wait_for_health(f"{letta_url.rstrip('/')}/v1/health", "Letta", timeout=90):
        _register_providers(config, letta_url)
    else:
        console.print("[yellow]Letta health check timed out — API will still start; check Letta logs.[/yellow]")

    pid, daemon_alive = _api_daemon_pid_running()
    if daemon_alive and _local_api_health_ok():
        console.print("[green]✓[/green] API server already running and healthy")
        console.print("\n[bold green]OpenCrew is running.[/bold green]")
        return

    if daemon_alive:
        console.print(
            "[yellow]API daemon is running but not healthy (e.g. DB was down). Restarting API…[/yellow]"
        )
        _stop_api_daemon_silent()

    _start_server_daemon(config)
    console.print("[green]✓[/green] API server started")
    if not _local_api_health_ok():
        console.print(f"[yellow]Warning: /health not OK yet — see {LOG_PATH}[/yellow]")
    console.print("\n[bold green]OpenCrew is running.[/bold green]")


def run_stop() -> None:
    """Stop OpenCrew infrastructure."""
    if not CONFIG_PATH.exists():
        console.print("[dim]No OpenCrew config — nothing to stop.[/dim]")
        return

    config = normalize_config(yaml.safe_load(CONFIG_PATH.read_text()) or {})
    if _remote_only_machine(config):
        console.print(
            "[cyan]Cloud setup[/cyan] — no local containers or API daemon to stop.",
        )
        return

    console.print("[cyan]Stopping OpenCrew…[/cyan]")

    if PID_PATH.exists():
        pid = int(PID_PATH.read_text().strip())
        try:
            os.kill(pid, signal.SIGTERM)
            console.print("[green]✓[/green] API server stopped")
        except OSError:
            console.print("[dim]API server was not running[/dim]")
        PID_PATH.unlink(missing_ok=True)

    docker_dir = OPENCREW_HOME / "docker"
    if docker_dir.exists():
        # `-t` gives Postgres a graceful shutdown window; stops db + letta and any other services.
        result = _run(["docker", "compose", "stop", "-t", "15"], cwd=docker_dir)
        if result.returncode == 0:
            console.print("[green]✓[/green] Docker stack stopped (Postgres, Letta, …)")
        else:
            console.print(f"[yellow]Warning: docker compose stop: {result.stderr or result.stdout}[/yellow]")

    console.print("[bold]OpenCrew stopped.[/bold]")


def run_destroy() -> None:
    """Remove all OpenCrew data."""
    if not OPENCREW_HOME.exists():
        console.print("[dim]Nothing to destroy — OpenCrew not initialized.[/dim]")
        return

    cfg = normalize_config(yaml.safe_load(CONFIG_PATH.read_text()) or {}) if CONFIG_PATH.exists() else {}
    if _remote_only_machine(cfg):
        confirm = console.input(
            "[bold red]Remove ~/.opencrew (remote-only — no local Docker)? Type 'yes' to confirm: [/bold red]",
        )
        if confirm.strip().lower() != "yes":
            console.print("[dim]Cancelled.[/dim]")
            return
        shutil.rmtree(OPENCREW_HOME)
        console.print("[green]✓[/green] ~/.opencrew removed")
        console.print("\n[bold]Config removed.[/bold] Run [bold]opencrew init[/bold] to set up again.")
        return

    confirm = console.input("[bold red]This will delete ALL OpenCrew local data. Type 'yes' to confirm: [/bold red]")
    if confirm.strip().lower() != "yes":
        console.print("[dim]Cancelled.[/dim]")
        return

    run_stop()

    docker_dir = OPENCREW_HOME / "docker"
    if docker_dir.exists():
        _run(["docker", "compose", "down", "-v"], cwd=docker_dir)
        console.print("[green]✓[/green] Docker volumes removed")

    shutil.rmtree(OPENCREW_HOME)
    console.print("[green]✓[/green] ~/.opencrew removed")
    console.print("\n[bold]OpenCrew destroyed.[/bold]")


def run_doctor() -> None:
    """Check prerequisites and service health."""
    console.print("\n[bold]OpenCrew Doctor[/bold]\n")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Status", width=3)
    table.add_column("Check")

    def _ok(msg: str) -> None:
        table.add_row("[green]✓[/green]", msg)

    def _fail(msg: str) -> None:
        table.add_row("[red]✗[/red]", msg)

    def _warn(msg: str) -> None:
        table.add_row("[yellow]![/yellow]", msg)

    if not CONFIG_PATH.exists():
        _fail("Config not found — run `opencrew init`")
        console.print(table)
        console.print()
        return

    config = normalize_config(yaml.safe_load(CONFIG_PATH.read_text()) or {})
    _ok(f"Config at {CONFIG_PATH} ([bold]local[/bold] + [bold]remote[/bold] sections)")

    # --- remote: OpenCrew API (+ optional BYO Letta metadata) ---
    if is_remote_configured(config):
        rem = get_remote(config)
        ok_c, err_c = _verify_cloud_connection(str(rem.get("api_url", "")), str(rem.get("api_key", "")))
        if ok_c:
            _ok(f"remote.api_url — API reachable ({rem.get('api_url')})")
        else:
            _fail(f"remote.api_url — {err_c}")
        if rem.get("letta_base_url"):
            _ok(f"remote.letta_base_url — stored [dim](BYO / self-hosted Letta)[/dim]")
        if rem.get("letta_api_token"):
            _ok("remote.letta_api_token — stored [dim](hidden in config file)[/dim]")
    else:
        _warn("remote — not set; CLI uses [bold]local[/bold] API only")

    # --- local API (`opencrew run --local`, default local base when remote unset) ---
    try:
        from opencrew.user_config import API_TARGET_LOCAL, api_client_url_and_key_for_target

        import httpx

        lb, _ = api_client_url_and_key_for_target(config, API_TARGET_LOCAL)
        health_url = f"{lb.rstrip('/')}/health"
        resp = httpx.get(health_url, timeout=8.0)
        if resp.status_code == 200:
            _ok(f"local target — GET {health_url} OK")
            try:
                oa = httpx.get(f"{lb.rstrip('/')}/openapi.json", timeout=8.0)
                if oa.status_code == 200:
                    paths = (oa.json() or {}).get("paths") or {}
                    if "/v1/runs/{run_id}/events" not in paths:
                        _warn(
                            "local API OpenAPI has no GET …/runs/{run_id}/events — likely an older "
                            "`opencrew` install. Fix: [bold]pip install -e /path/to/cli[/bold] then "
                            "[bold]opencrew stop && opencrew start[/bold]",
                        )
                    else:
                        _ok("local API OpenAPI lists GET …/runs/{run_id}/events [dim](+ include_events on poll)[/dim]")
            except Exception as exc:
                _warn(f"local API OpenAPI check skipped: {exc}")
        else:
            snippet = (resp.text or "").strip()
            if len(snippet) > 180:
                snippet = snippet[:180] + "…"
            extra = f" — {snippet}" if snippet else ""
            line = f"local target — GET {health_url} HTTP {resp.status_code}{extra}"
            if is_remote_configured(config) and not has_local_stack(config):
                _warn(f"{line} [dim](expected if you only use --cloud)[/dim]")
            else:
                _fail(line)
    except Exception as exc:
        line = f"local target — {exc}"
        if is_remote_configured(config) and not has_local_stack(config):
            _warn(f"{line} [dim](expected if you only use --cloud)[/dim]")
        else:
            _fail(line)

    # --- local: Docker dev stack ---
    if has_local_stack(config):
        if _check_command("docker"):
            result = _run(["docker", "info"])
            if result.returncode == 0:
                _ok("Docker daemon running")
            else:
                _fail("Docker installed but daemon not running")
        else:
            _fail("Docker not installed")

        if _check_command("node"):
            result = _run(["node", "--version"])
            _ok(f"Node.js {result.stdout.strip()}")
        else:
            _fail("Node.js not installed")

        loc = get_local(config)
        db_url = loc.get("db_url")
        if db_url:
            try:
                import psycopg
                with psycopg.connect(db_url) as conn:
                    conn.execute("SELECT 1")
                _ok("local.db_url — Postgres reachable")
            except Exception as e:
                _fail(f"local.db_url — Postgres unreachable: {e}")
        if db_url:
            try:
                from opencrew.store.migrate import check_migrations
                if check_migrations(db_url):
                    _ok("local — database migrations up to date")
                else:
                    _warn("local — migrations missing — run `opencrew init` → local")
            except Exception:
                _warn("local — could not check migrations")

        letta_url = loc.get("letta_url") or "http://localhost:8283"
        try:
            import httpx

            resp = httpx.get(f"{letta_url.rstrip('/')}/v1/health", timeout=8.0)
            if resp.status_code < 500:
                _ok(f"local.letta — Letta healthy ({letta_url})")
            else:
                _fail(f"local.letta — unhealthy (HTTP {resp.status_code})")
        except Exception:
            _fail(f"local.letta — unreachable ({letta_url})")

        if PID_PATH.exists():
            pid = int(PID_PATH.read_text().strip())
            try:
                os.kill(pid, 0)
                _ok(f"local — server daemon running (PID {pid})")
            except OSError:
                _warn(f"local — stale PID file (PID {pid})")
        else:
            _warn("local — no server PID file (run opencrew init / start)")
    else:
        _warn("local — no stack configured (no local.db_url); skip Docker/Postgres/Letta checks")

    console.print(table)
    console.print(
        "\n[dim][bold]SDK rule:[/bold] If [bold]remote[/bold] has api_url + api_key, "
        "`opencrew` commands default to [bold]remote[/bold]; otherwise [bold]local.api_url[/bold]. "
        "Add or change cloud: [bold]opencrew remote[/bold]. "
        "`opencrew run` can override with [bold]--local[/bold] or [bold]--cloud[/bold].[/dim]\n",
    )
