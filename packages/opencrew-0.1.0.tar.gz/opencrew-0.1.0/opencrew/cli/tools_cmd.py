from __future__ import annotations

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.user_config import API_TARGET_AUTO

console = Console()


def run_tools(action: str, *, agent: str | None = None, api_target: str = API_TARGET_AUTO) -> None:
    """Manage tools and MCP servers."""
    if action == "list":
        if agent:
            _list_for_agent(agent, api_target=api_target)
        else:
            _list_all(api_target=api_target)
    elif action == "add-mcp":
        console.print("[dim]Use `opencrew apply` with mcp_servers in your agent.yaml to add MCP servers.[/dim]")
    else:
        console.print(f"[red]Unknown action: {action}. Use 'list' or 'add-mcp'.[/red]")


def _list_for_agent(agent: str, *, api_target: str = API_TARGET_AUTO) -> None:
    """Show tools and MCP servers configured for a specific agent type."""
    with get_client(api_target=api_target) as client:
        try:
            tools = client.agent_types.list_tools(agent)
        except Exception:
            tools = []
        try:
            servers = client.agent_types.list_mcp_servers(agent)
        except Exception:
            servers = []

    if tools:
        table = Table(title=f"Tools — {agent}")
        table.add_column("Slug", style="cyan")
        table.add_column("Name")
        table.add_column("Type", style="dim")

        for t in tools:
            table.add_row(
                t.get("slug", ""),
                t.get("name", ""),
                t.get("source_type", "python"),
            )
        console.print(table)
    else:
        console.print(f"[dim]No custom tools attached to '{agent}'.[/dim]")

    if servers:
        console.print()
        table = Table(title=f"MCP Servers — {agent}")
        table.add_column("Slug", style="cyan")
        table.add_column("Name")
        table.add_column("Transport", style="dim", width=15)
        table.add_column("URL / Command", style="dim", max_width=45)

        for s in servers:
            transport = s.get("transport") or s.get("server_type") or "streamable_http"
            location = s.get("server_url") or s.get("command") or ""
            if s.get("composio_app"):
                transport = "composio"
                location = s["composio_app"]
            table.add_row(
                s.get("slug", ""),
                s.get("name", ""),
                transport,
                location,
            )
        console.print(table)
    else:
        console.print(f"[dim]No MCP servers attached to '{agent}'.[/dim]")

    if not tools and not servers:
        console.print("\n[dim]Add tools/MCP servers in your agent.yaml and run `opencrew apply`.[/dim]")


def _list_all(*, api_target: str = API_TARGET_AUTO) -> None:
    with get_client(api_target=api_target) as client:
        tools = client.tools.list()
        servers = client.mcp_servers.list()

    if tools:
        table = Table(title="Custom Tools (workspace)")
        table.add_column("Slug", style="cyan")
        table.add_column("Name")
        table.add_column("Type", style="dim")

        for t in tools:
            table.add_row(
                t.get("slug", ""),
                t.get("name", ""),
                t.get("source_type", "python"),
            )
        console.print(table)
    else:
        console.print("[dim]No custom tools.[/dim]")

    if servers:
        console.print()
        table = Table(title="MCP Servers (workspace)")
        table.add_column("Slug", style="cyan")
        table.add_column("Name")
        table.add_column("URL", style="dim", max_width=50)

        for s in servers:
            table.add_row(
                s.get("slug", ""),
                s.get("name", ""),
                s.get("server_url", ""),
            )
        console.print(table)
    else:
        console.print("[dim]No MCP servers.[/dim]")
