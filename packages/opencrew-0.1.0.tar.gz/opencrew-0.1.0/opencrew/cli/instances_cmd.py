from __future__ import annotations

from rich.console import Console
from rich.table import Table

from opencrew.cli._config import get_client
from opencrew.user_config import API_TARGET_AUTO

console = Console()


def run_instances_list(agent: str, *, client_id: str | None = None, api_target: str = API_TARGET_AUTO) -> None:
    """List all instances for an agent type."""
    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent, client_id=client_id)

    if not instances:
        console.print(f"[dim]No instances for '{agent}'. Run the agent to create one.[/dim]")
        return

    table = Table(title=f"Instances — {agent}")
    table.add_column("ID", style="dim", width=10)
    table.add_column("Name", min_width=12)
    table.add_column("Display Name", min_width=15)
    table.add_column("Default", width=7)
    table.add_column("Client", style="dim", width=10)
    table.add_column("Last used", width=20)

    for inst in instances:
        iid = str(inst.get("id", ""))[:8]
        name = inst.get("name") or "—"
        display = inst.get("display_name") or "—"
        default = "✓" if inst.get("is_default") else ""
        cid = str(inst.get("client_id") or "—")[:8]
        last = str(inst.get("last_used_at") or "—")[:19]
        table.add_row(iid, name, display, default, cid, last)

    console.print(table)


def run_instance_inspect(agent: str, instance_id: str, *, api_target: str = API_TARGET_AUTO) -> None:
    """Show details and memory for a specific instance."""
    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent)
        match = _resolve_instance(instances, instance_id)
        if match is None:
            console.print(f"[red]No instance matching '{instance_id}' for agent '{agent}'.[/red]")
            return

        full_id = str(match["id"])
        blocks = client.instances.memory(agent, full_id)

    console.print(f"\n[bold]Instance {full_id[:8]}[/bold]")
    for key in ("id", "name", "display_name", "is_default", "client_id",
                "letta_agent_id", "status", "created_at", "last_used_at"):
        val = match.get(key)
        if val is not None:
            console.print(f"  [cyan]{key}:[/cyan] {val}")

    if blocks:
        console.print()
        table = Table(title="Memory blocks")
        table.add_column("Label", style="cyan")
        table.add_column("Value", max_width=80)

        for block in blocks:
            label = block.get("label", "")
            value = block.get("value", "")
            if len(value) > 200:
                value = value[:200] + "..."
            table.add_row(label, value)
        console.print(table)
    else:
        console.print("[dim]No memory blocks.[/dim]")


def run_instance_delete(agent: str, instance_id: str, *, skip_confirm: bool = False, api_target: str = API_TARGET_AUTO) -> None:
    """Delete an instance."""
    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent)
        match = _resolve_instance(instances, instance_id)
        if match is None:
            console.print(f"[red]No instance matching '{instance_id}' for agent '{agent}'.[/red]")
            return

        full_id = str(match["id"])
        display = match.get("display_name") or match.get("name") or full_id[:8]

        if not skip_confirm:
            confirm = console.input(
                f"[bold red]Delete instance '{display}' ({full_id[:8]})? Type 'yes': [/bold red]"
            )
            if confirm.strip().lower() != "yes":
                console.print("[dim]Cancelled.[/dim]")
                return

        client.instances.delete(agent, full_id)
    console.print(f"[green]✓[/green] Deleted instance {full_id[:8]}")


def run_instances_delete_all(
    agent: str,
    *,
    client_id: str | None = None,
    skip_confirm: bool = False,
    api_target: str = API_TARGET_AUTO,
) -> None:
    """Delete every instance for an agent type (after one confirmation)."""
    with get_client(api_target=api_target) as client:
        instances = client.instances.list(agent, client_id=client_id)
        if not instances:
            scope = f" (client {client_id[:8]}…)" if client_id else ""
            console.print(f"[dim]No instances to delete for '{agent}'{scope}.[/dim]")
            return

        n = len(instances)
        preview = ", ".join(
            str(inst.get("id", ""))[:8] for inst in instances[:8]
        )
        if n > 8:
            preview += f", … (+{n - 8} more)"

        if not skip_confirm:
            console.print(
                f"[yellow]About to delete[/yellow] [bold]{n}[/bold] [yellow]instance(s) for[/yellow] "
                f"[bold]{agent}[/bold][dim]: {preview}[/dim]"
            )
            confirm = console.input("[bold red]Type 'yes' to delete all: [/bold red]")
            if confirm.strip().lower() != "yes":
                console.print("[dim]Cancelled.[/dim]")
                return

        deleted = 0
        for inst in instances:
            full_id = str(inst.get("id", ""))
            if not full_id:
                continue
            client.instances.delete(agent, full_id)
            deleted += 1

    console.print(f"[green]✓[/green] Deleted [bold]{deleted}[/bold] instance(s) for [bold]{agent}[/bold]")


def _resolve_instance(instances: list[dict], prefix: str) -> dict | None:
    """Match an instance by ID prefix."""
    for inst in instances:
        iid = str(inst.get("id", ""))
        if iid == prefix or iid.startswith(prefix):
            return inst
    return None
