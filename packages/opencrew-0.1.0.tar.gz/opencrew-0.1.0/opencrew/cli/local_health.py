"""Preflight checks for `opencrew run --local` (API + optional Docker Letta)."""
from __future__ import annotations

from typing import Any

import httpx
from rich.console import Console

from opencrew.user_config import (
    API_TARGET_AUTO,
    API_TARGET_LOCAL,
    api_client_url_and_key_for_target,
    get_local,
    has_local_stack,
    is_remote_configured,
)

console = Console()

LOG_PATH_TEXT = "~/.opencrew/server.log"


def should_run_local_preflight(config: dict[str, Any], api_target: str) -> bool:
    """True when the resolved OpenCrew API for this run is the local stack (not cloud)."""
    if api_target == API_TARGET_LOCAL:
        return True
    return api_target == API_TARGET_AUTO and not is_remote_configured(config)


def _health_url(base: str) -> str:
    return f"{base.rstrip('/')}/health"


def _letta_health_url(letta_base: str) -> str:
    return f"{letta_base.rstrip('/')}/v1/health"


def check_local_api_reachable(config: dict[str, Any]) -> tuple[bool, str, str | None]:
    """Return (ok, message, body_snippet) for GET ``/health`` on the local-target API base URL."""
    base, _ = api_client_url_and_key_for_target(config, API_TARGET_LOCAL)
    url = _health_url(base)
    try:
        r = httpx.get(url, timeout=8.0)
    except httpx.RequestError as exc:
        return False, f"Unreachable: {exc} ({url})", None
    body = (r.text or "").strip()
    snippet = (body[:500] + "…") if len(body) > 500 else body if body else None
    if r.status_code == 200:
        try:
            data = r.json()
            if isinstance(data, dict) and data.get("status") == "error":
                return (
                    False,
                    f"API reports unhealthy: {data.get('detail', data)}",
                    snippet,
                )
        except Exception:
            pass
        return True, f"OK ({base})", None
    if r.status_code == 503:
        return False, f"API up but dependencies down (HTTP 503) for {url}", snippet
    return False, f"HTTP {r.status_code} for {url}", snippet


def check_local_letta_if_docker_stack(config: dict[str, Any]) -> tuple[bool, str]:
    """When Docker local stack is configured, verify Letta responds."""
    if not has_local_stack(config):
        return True, "skipped (no Docker stack in config)"
    letta_base = get_local(config).get("letta_url") or "http://localhost:8283"
    url = _letta_health_url(letta_base)
    try:
        r = httpx.get(url, timeout=8.0)
    except httpx.RequestError as exc:
        return False, f"Letta unreachable: {exc} ({url})"
    if r.status_code < 500:
        return True, f"OK ({letta_base})"
    return False, f"Letta HTTP {r.status_code} ({url})"


def preflight_local_run(config: dict[str, Any], *, verbose: bool = False) -> None:
    """Exit with guidance if local API (and Letta, if applicable) are not healthy."""
    ok_api, msg_api, snippet = check_local_api_reachable(config)
    if not ok_api:
        console.print(f"[red]Local API check failed:[/red] {msg_api}")
        if snippet:
            console.print(f"[dim]{snippet}[/dim]")
        console.print(
            f"[dim]Start the stack: [bold]opencrew start[/bold] · diagnose: [bold]opencrew doctor[/bold] · "
            f"logs: {LOG_PATH_TEXT}[/dim]",
        )
        raise SystemExit(1)

    ok_lt, msg_lt = check_local_letta_if_docker_stack(config)
    if not ok_lt:
        console.print(f"[red]Local Letta check failed:[/red] {msg_lt}")
        console.print(
            "[dim]Ensure Docker is running and Letta is up (`docker compose up` under ~/.opencrew/docker).[/dim]",
        )
        raise SystemExit(1)

    if verbose:
        console.print(f"[dim]Local preflight OK — API {msg_api}; Letta {msg_lt}[/dim]")
