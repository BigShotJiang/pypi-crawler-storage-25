from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import httpx
import yaml
from rich.console import Console

from opencrew.sdk.client import OpenCrew
from opencrew.sdk.http_util import humanize_api_error
from opencrew.user_config import (
    API_TARGET_AUTO,
    API_TARGET_CLOUD,
    API_TARGET_DAYTONA,
    API_TARGET_LOCAL,
    api_client_url_and_key_for_target,
    normalize_config,
)

console = Console()

OPENCREW_HOME = Path.home() / ".opencrew"
CONFIG_PATH = OPENCREW_HOME / "config.yaml"


def load_config() -> dict:
    """Load config from ~/.opencrew/config.yaml."""
    if not CONFIG_PATH.exists():
        console.print("[red]OpenCrew not initialized. Run `opencrew init` first.[/red]")
        raise SystemExit(1)
    try:
        raw = CONFIG_PATH.read_text()
    except OSError as exc:
        console.print(f"[red]Could not read config file: {exc}[/red]")
        raise SystemExit(1) from exc
    try:
        return normalize_config(yaml.safe_load(raw) or {})
    except yaml.YAMLError as exc:
        console.print(f"[red]Config file has invalid YAML:[/red] {CONFIG_PATH}\n{exc}")
        raise SystemExit(1) from exc


@contextmanager
def get_client(*, api_target: str = API_TARGET_AUTO) -> Iterator[OpenCrew]:
    """Create an SDK client with automatic error handling.

    Catches connection errors, HTTP status errors, and network failures
    so commands get friendly messages instead of tracebacks.
    """
    config = load_config()
    try:
        base_url, api_key = api_client_url_and_key_for_target(config, api_target)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise SystemExit(1) from exc

    client = OpenCrew(base_url=base_url, api_key=api_key)
    try:
        yield client
    except httpx.ConnectError:
        _print_connection_error(base_url, api_target)
        raise SystemExit(1)
    except httpx.TimeoutException:
        console.print(f"[red]Request timed out connecting to {base_url}[/red]")
        if _is_local(base_url, api_target):
            console.print(
                "[dim]The local server may be slow to respond. "
                "Check it with:[/dim]  [bold]opencrew doctor[/bold]"
            )
        raise SystemExit(1)
    except httpx.HTTPStatusError as exc:
        _print_http_error(exc, base_url, api_target)
        raise SystemExit(1)
    except httpx.RequestError as exc:
        _print_network_error(exc, base_url, api_target)
        raise SystemExit(1)
    finally:
        client.close()


def _is_local(base_url: str, api_target: str) -> bool:
    return api_target == API_TARGET_LOCAL or "localhost" in base_url or "127.0.0.1" in base_url


def _print_connection_error(base_url: str, api_target: str) -> None:
    console.print(f"\n[red]Could not connect to {base_url}[/red]")
    if _is_local(base_url, api_target):
        console.print(
            "\n[yellow]The local OpenCrew server is not running.[/yellow]\n"
            "  Start it with:  [bold]opencrew start[/bold]\n"
            "  Or use cloud:   [bold]--cloud[/bold]\n"
        )
    else:
        console.print(
            "\n[yellow]The remote API is unreachable.[/yellow]\n"
            "  Check your internet connection or try:  [bold]--local[/bold]\n"
            "  Verify the URL with:  [bold]opencrew target[/bold]\n"
        )


_STATUS_HINTS: dict[int, str] = {
    401: "Your API key is invalid or expired. Update it with: [bold]opencrew remote[/bold]",
    403: "Your API key does not have permission for this action.",
    404: "Resource not found. Run [bold]opencrew apply[/bold] first, or check the agent name.",
    409: "Conflict — the resource may already exist or be in use.",
    422: "The server rejected the request (validation error). Check your input.",
    429: "Rate limited. Wait a moment and try again.",
    500: "Internal server error. Try again, or check [bold]opencrew logs[/bold].",
    502: "Bad gateway — the server may be restarting. Try again in a moment.",
    503: "Service unavailable — the server is temporarily down.",
}


def _print_http_error(exc: httpx.HTTPStatusError, base_url: str, api_target: str) -> None:
    msg = humanize_api_error(exc.response)
    console.print(f"\n[red]{msg}[/red]")

    hint = _STATUS_HINTS.get(exc.response.status_code)
    if hint:
        console.print(f"[yellow]{hint}[/yellow]")

    if _is_local(base_url, api_target) and exc.response.status_code >= 500:
        console.print("[dim]Check the local server: [bold]opencrew doctor[/bold][/dim]")


def _print_network_error(exc: httpx.RequestError, base_url: str, api_target: str) -> None:
    error_type = type(exc).__name__
    console.print(f"\n[red]Network error ({error_type}): {exc}[/red]")
    if _is_local(base_url, api_target):
        console.print(
            "[dim]The local server may have dropped the connection.\n"
            "Check it with:[/dim]  [bold]opencrew doctor[/bold]"
        )
    else:
        console.print(
            "[dim]The connection was interrupted.\n"
            "Check your network, or try again.[/dim]"
        )


def format_api_target_label(api_target: str) -> str:
    """Short label for banners (which resolution rule is active)."""
    if api_target == API_TARGET_LOCAL:
        return "local (--local)"
    if api_target == API_TARGET_CLOUD:
        return "cloud (--cloud)"
    if api_target == API_TARGET_DAYTONA:
        return "daytona (--daytona)"
    return "auto (remote if configured, else local)"


def print_api_banner(client: OpenCrew, api_target: str) -> None:
    """One line so runs are not ambiguous about local vs hosted API."""
    console.print(
        f"[dim]{format_api_target_label(api_target)} →[/dim] [cyan]{client.api_base_url()}[/cyan]",
    )
