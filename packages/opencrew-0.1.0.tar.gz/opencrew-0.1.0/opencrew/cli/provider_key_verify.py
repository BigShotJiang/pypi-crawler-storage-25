"""Lightweight checks that LLM provider API keys are accepted (HTTP round-trip)."""
from __future__ import annotations

import httpx


def verify_provider_api_key(slug: str, api_key: str) -> tuple[bool | None, str]:
    """Return (ok, detail).

    ``ok`` is True if the provider accepted the key, False if it clearly rejected it,
    None if we did not run a check (unsupported provider) or the result was inconclusive.
    """
    key = (api_key or "").strip()
    if not key:
        return False, "Empty API key."

    s = slug.strip().lower()
    try:
        if s == "anthropic":
            return _check_anthropic(key)
        if s == "openai":
            return _check_openai(key)
        if s in ("google", "google_ai"):
            return _check_google(key)
        if s == "groq":
            return _check_groq(key)
        if s == "together":
            return _check_together(key)
        if s == "mistral":
            return _check_mistral(key)
        if s == "openrouter":
            return _check_openrouter(key)
        if s == "deepseek":
            return _check_deepseek(key)
        if s == "xai":
            return _check_xai(key)
        if s == "fireworks":
            return _check_fireworks(key)
        if s in ("azure", "bedrock"):
            return None, (
                f"{s} needs extra configuration beyond a single API key; "
                "OpenCrew cannot auto-verify. Confirm in the provider console or run a short test prompt."
            )
    except httpx.RequestError as exc:
        return None, f"Network error while checking key: {exc}"

    return None, "No automatic check for this provider; if runs fail, replace the key in the provider console."


def _classify_auth_failure(status: int, body: str) -> tuple[bool | None, str]:
    if status in (401, 403):
        return False, "Provider rejected this key (invalid, expired, or revoked)."
    if status == 429:
        return None, "Rate limited while verifying — try opencrew providers list --check again shortly."
    snippet = (body or "").strip()[:280]
    if snippet:
        return False, f"Unexpected HTTP {status}: {snippet}"
    return False, f"Unexpected HTTP {status}."


def _check_anthropic(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.anthropic.com/v1/models",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_openai(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        params={"limit": 1},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_google(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://generativelanguage.googleapis.com/v1/models",
        params={"key": key},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_groq(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.groq.com/openai/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_together(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.together.xyz/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_mistral(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.mistral.ai/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_openrouter(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://openrouter.ai/api/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_deepseek(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.deepseek.com/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_xai(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.x.ai/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def _check_fireworks(key: str) -> tuple[bool | None, str]:
    r = httpx.get(
        "https://api.fireworks.ai/inference/v1/models",
        headers={"Authorization": f"Bearer {key}"},
        timeout=15.0,
    )
    if r.status_code < 400:
        return True, ""
    return _classify_auth_failure(r.status_code, r.text)


def provider_key_failure_hint(text: str) -> str | None:
    """If ``text`` looks like an LLM provider auth error, return a CLI hint."""
    t = (text or "").lower()
    needles = (
        "invalid_api_key",
        "incorrect api key",
        "invalid api key",
        "api key provided",
        "authentication",
        "unauthorized",
        "401",
        "403",
        "permission denied",
        "invalid x-api-key",
        "invalid bearer",
        "expired",
        "revoked",
    )
    if not any(n in t for n in needles):
        return None
    return (
        "[dim]This often means a provider API key is missing, expired, or revoked. "
        "Check with:[/dim]  [bold]opencrew providers list --check[/bold]  "
        "[dim](add --local or --cloud as needed).[/dim]"
    )
