from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from psycopg.rows import dict_row

from opencrew.store.db import get_conn


def create_run(
    owner_id: str,
    agent_type_id: UUID | None,
    entity_id: str | None,
    client_id: str | None,
    agent_id: str | None,
    message: str,
    session_options: dict[str, Any] | None = None,
    skill_manifest: dict[str, Any] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO runs (
                    owner_id, agent_type_id, entity_id, client_id,
                    agent_id, message, session_options, skill_manifest
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    owner_id,
                    str(agent_type_id) if agent_type_id else None,
                    entity_id,
                    client_id,
                    agent_id,
                    message,
                    json.dumps(session_options) if session_options else None,
                    json.dumps(skill_manifest) if skill_manifest else None,
                ),
            )
            row = cur.fetchone()
            conn.commit()

    return dict(row)


def update_run_status(
    run_id: UUID,
    status: str,
    *,
    result: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    parts = ["status = %s"]
    params: list[Any] = [status]

    if status == "running":
        parts.append("started_at = now()")
    if status in ("complete", "failed"):
        parts.append("completed_at = now()")

    if result is not None:
        parts.append("result = %s")
        params.append(json.dumps(result))
    if error is not None:
        parts.append("error = %s")
        params.append(error)

    params.append(str(run_id))

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"UPDATE runs SET {', '.join(parts)} WHERE id = %s",
                params,
            )
            conn.commit()


def get_run(run_id: UUID, owner_id: str | None = None) -> dict | None:
    clauses = ["id = %s"]
    params: list[Any] = [str(run_id)]

    if owner_id is not None:
        clauses.append("owner_id = %s")
        params.append(owner_id)

    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                f"SELECT * FROM runs WHERE {' AND '.join(clauses)}",
                params,
            )
            row = cur.fetchone()

    if row is None:
        return None
    return dict(row)


def list_runs(
    owner_id: str,
    *,
    status: str | None = None,
    agent_type_slug: str | None = None,
    client_id: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    clauses = ["r.owner_id = %s"]
    params: list[Any] = [owner_id]

    if status:
        clauses.append("r.status = %s")
        params.append(status)
    if agent_type_slug:
        clauses.append("at.slug = %s")
        params.append(agent_type_slug)
    if client_id:
        clauses.append("r.client_id = %s")
        params.append(client_id)

    where = " AND ".join(clauses)
    join = ""
    if agent_type_slug:
        join = "LEFT JOIN agent_types at ON at.id = r.agent_type_id"

    params.extend([limit, offset])

    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                f"SELECT r.* FROM runs r {join} WHERE {where} "
                f"ORDER BY r.created_at DESC LIMIT %s OFFSET %s",
                params,
            )
            rows = cur.fetchall()

    return [dict(r) for r in rows]


# --- Run Events (for live SSE streaming) ---


def insert_run_event(
    run_id: UUID,
    seq: int,
    event_type: str,
    payload: dict[str, Any],
) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO run_events (run_id, seq, event_type, payload)
                VALUES (%s, %s, %s, %s)
                """,
                (str(run_id), seq, event_type, json.dumps(payload)),
            )
            conn.commit()


def get_run_events(
    run_id: UUID,
    after_seq: int = 0,
) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT * FROM run_events
                WHERE run_id = %s AND seq > %s
                ORDER BY seq
                """,
                (str(run_id), after_seq),
            )
            rows = cur.fetchall()

    return [dict(r) for r in rows]


def fail_stale_runs(max_age_seconds: int = 3600) -> int:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                UPDATE runs
                SET status = 'failed',
                    error  = 'Reaped: exceeded maximum age in ' || status || ' state',
                    completed_at = now()
                WHERE status IN ('pending', 'running')
                  AND created_at < now() - make_interval(secs => %s)
                RETURNING id
                """,
                (max_age_seconds,),
            )
            reaped = cur.fetchall()

            for row in reaped:
                cur.execute(
                    """
                    INSERT INTO run_logs (run_id, level, message, metadata)
                    VALUES (%s, 'error', 'Run reaped: exceeded maximum age without completing', %s)
                    """,
                    (str(row["id"]), json.dumps({"phase": "stale_reaper"})),
                )

            conn.commit()

    return len(reaped)


# --- Run Logging ---


def log_run_start(run_id: UUID, metadata: dict[str, Any] | None = None) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO run_logs (run_id, level, message, metadata)
                VALUES (%s, 'info', 'run_started', %s)
                """,
                (str(run_id), json.dumps(metadata) if metadata else None),
            )
            conn.commit()


def log_run_complete(run_id: UUID, metadata: dict[str, Any] | None = None) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO run_logs (run_id, level, message, metadata)
                VALUES (%s, 'info', 'run_complete', %s)
                """,
                (str(run_id), json.dumps(metadata) if metadata else None),
            )
            conn.commit()


def log_run_failed(
    run_id: UUID,
    error: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    meta = metadata or {}
    meta["error"] = error
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO run_logs (run_id, level, message, metadata)
                VALUES (%s, 'error', 'run_failed', %s)
                """,
                (str(run_id), json.dumps(meta)),
            )
            conn.commit()


# --- Chats ---


def create_chat(owner_id: str, agent_type_slug: str, title: str | None = None, instance_id: str | None = None) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO chats (owner_id, agent_type_slug, title, instance_id)
                VALUES (%s, %s, %s, %s)
                RETURNING *
                """,
                (owner_id, agent_type_slug, title, instance_id),
            )
            row = cur.fetchone()
            conn.commit()
    return dict(row)


def list_chats(owner_id: str, agent_type_slug: str | None = None, limit: int = 20) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            if agent_type_slug:
                cur.execute(
                    """
                    SELECT c.*, (
                        SELECT cm.content FROM chat_messages cm
                        WHERE cm.chat_id = c.id AND cm.role = 'user'
                        ORDER BY cm.created_at ASC LIMIT 1
                    ) AS first_message,
                    (SELECT count(*) FROM chat_messages cm WHERE cm.chat_id = c.id) AS message_count
                    FROM chats c
                    WHERE c.owner_id = %s AND c.agent_type_slug = %s
                    ORDER BY c.updated_at DESC
                    LIMIT %s
                    """,
                    (owner_id, agent_type_slug, limit),
                )
            else:
                cur.execute(
                    """
                    SELECT c.*, (
                        SELECT cm.content FROM chat_messages cm
                        WHERE cm.chat_id = c.id AND cm.role = 'user'
                        ORDER BY cm.created_at ASC LIMIT 1
                    ) AS first_message,
                    (SELECT count(*) FROM chat_messages cm WHERE cm.chat_id = c.id) AS message_count
                    FROM chats c
                    WHERE c.owner_id = %s
                    ORDER BY c.updated_at DESC
                    LIMIT %s
                    """,
                    (owner_id, limit),
                )
            return [dict(r) for r in cur.fetchall()]


def get_chat(chat_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM chats WHERE id = %s AND owner_id = %s",
                (chat_id, owner_id),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def add_chat_message(chat_id: str, role: str, content: str, run_id: str | None = None) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO chat_messages (chat_id, role, content, run_id)
                VALUES (%s, %s, %s, %s)
                RETURNING *
                """,
                (chat_id, role, content, run_id),
            )
            row = cur.fetchone()
            cur.execute(
                "UPDATE chats SET updated_at = now() WHERE id = %s",
                (chat_id,),
            )
            conn.commit()
    return dict(row)


def get_chat_messages(chat_id: str, limit: int = 100) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT * FROM chat_messages
                WHERE chat_id = %s
                ORDER BY created_at ASC
                LIMIT %s
                """,
                (chat_id, limit),
            )
            return [dict(r) for r in cur.fetchall()]


def delete_chat(chat_id: str, owner_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM chats WHERE id = %s AND owner_id = %s",
                (chat_id, owner_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted
