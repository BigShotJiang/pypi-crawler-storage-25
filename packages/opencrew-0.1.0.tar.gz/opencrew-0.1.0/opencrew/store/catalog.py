from __future__ import annotations

import json
import re
from typing import Any
from uuid import uuid4

from psycopg.rows import dict_row

from opencrew.store.db import get_conn

_UNSET = object()


def _name_to_slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "unnamed"


def _to_json(value: Any | None) -> str | None:
    if value is None:
        return None
    return json.dumps(value)


# ---------------------------------------------------------------------------
# Agent Types
# ---------------------------------------------------------------------------


def create_agent_type(
    owner_id: str,
    name: str,
    slug: str,
    *,
    description: str | None = None,
    persona: str | None = None,
    system_prompt: str | None = None,
    model: str | None = None,
    memory_defaults: dict[str, Any] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO agent_types (
                    owner_id, name, slug, description, persona,
                    system_prompt, model, memory_defaults
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (owner_id, slug)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description,
                    persona = EXCLUDED.persona,
                    system_prompt = EXCLUDED.system_prompt,
                    model = EXCLUDED.model,
                    memory_defaults = EXCLUDED.memory_defaults,
                    updated_at = now()
                RETURNING *
                """,
                (
                    owner_id, name, slug, description, persona,
                    system_prompt, model, _to_json(memory_defaults),
                ),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_agent_type(agent_type_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM agent_types WHERE id = %s AND owner_id = %s",
                (agent_type_id, owner_id),
            )
            return cur.fetchone()


def get_agent_type_by_slug(slug: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM agent_types WHERE slug = %s AND owner_id = %s",
                (slug, owner_id),
            )
            return cur.fetchone()


def list_agent_types(owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT * FROM agent_types
                WHERE owner_id = %s
                ORDER BY created_at DESC
                """,
                (owner_id,),
            )
            return cur.fetchall()


def update_agent_type(agent_type_id: str, owner_id: str, **kwargs: Any) -> dict | None:
    updates: list[str] = []
    params: list[Any] = []
    allowed = {
        "name", "slug", "description", "persona",
        "system_prompt", "model", "memory_defaults",
    }
    for key, value in kwargs.items():
        if key not in allowed:
            continue
        if value is None:
            continue
        if key == "memory_defaults":
            updates.append("memory_defaults = %s")
            params.append(_to_json(value))
        else:
            updates.append(f"{key} = %s")
            params.append(value)
    if not updates:
        return get_agent_type(agent_type_id, owner_id)
    updates.append("updated_at = now()")
    params.extend([agent_type_id, owner_id])
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                f"""
                UPDATE agent_types
                SET {", ".join(updates)}
                WHERE id = %s AND owner_id = %s
                RETURNING *
                """,
                params,
            )
            row = cur.fetchone()
            conn.commit()
    return row


def delete_agent_type(agent_type_id: str, owner_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM agent_type_mcp_servers WHERE agent_type_id = %s",
                (agent_type_id,),
            )
            cur.execute(
                "DELETE FROM agent_type_tools WHERE agent_type_id = %s",
                (agent_type_id,),
            )
            cur.execute(
                "DELETE FROM agent_type_skills WHERE agent_type_id = %s",
                (agent_type_id,),
            )
            cur.execute(
                "DELETE FROM agent_instances WHERE agent_type_id = %s AND owner_id = %s",
                (agent_type_id, owner_id),
            )
            cur.execute(
                "DELETE FROM agent_types WHERE id = %s AND owner_id = %s",
                (agent_type_id, owner_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


# ---------------------------------------------------------------------------
# Agent Instances
# ---------------------------------------------------------------------------


def create_instance(
    owner_id: str,
    agent_type_id: str,
    letta_agent_id: str,
    *,
    entity_id: str | None = None,
    client_id: str | None = None,
    name: str | None = None,
    display_name: str | None = None,
    is_default: bool = False,
    letta_project_id: str | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO agent_instances (
                    owner_id, agent_type_id, letta_agent_id,
                    entity_id, client_id, name, display_name,
                    is_default, letta_project_id
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    owner_id, agent_type_id, letta_agent_id,
                    entity_id, client_id, name, display_name,
                    is_default, letta_project_id,
                ),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_instance(instance_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM agent_instances WHERE id = %s AND owner_id = %s",
                (instance_id, owner_id),
            )
            return cur.fetchone()


def get_default_instance(
    owner_id: str,
    agent_type_id: str,
    entity_id: str,
    client_id: str | None = None,
) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            if client_id is not None:
                cur.execute(
                    """
                    SELECT * FROM agent_instances
                    WHERE owner_id = %s AND agent_type_id = %s
                      AND entity_id = %s AND client_id = %s
                      AND is_default = true
                    """,
                    (owner_id, agent_type_id, entity_id, client_id),
                )
            else:
                cur.execute(
                    """
                    SELECT * FROM agent_instances
                    WHERE owner_id = %s AND agent_type_id = %s
                      AND entity_id = %s AND client_id IS NULL
                      AND is_default = true
                    """,
                    (owner_id, agent_type_id, entity_id),
                )
            return cur.fetchone()


def list_instances(
    owner_id: str,
    agent_type_id: str,
    *,
    entity_id: str | None = None,
    client_id: str | None = None,
) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            if entity_id is not None and client_id is not None:
                cur.execute(
                    """
                    SELECT * FROM agent_instances
                    WHERE owner_id = %s AND agent_type_id = %s
                      AND entity_id = %s AND client_id = %s
                    ORDER BY created_at DESC
                    """,
                    (owner_id, agent_type_id, entity_id, client_id),
                )
            elif entity_id is not None:
                cur.execute(
                    """
                    SELECT * FROM agent_instances
                    WHERE owner_id = %s AND agent_type_id = %s
                      AND entity_id = %s AND client_id IS NULL
                    ORDER BY created_at DESC
                    """,
                    (owner_id, agent_type_id, entity_id),
                )
            else:
                cur.execute(
                    """
                    SELECT * FROM agent_instances
                    WHERE owner_id = %s AND agent_type_id = %s
                    ORDER BY created_at DESC
                    """,
                    (owner_id, agent_type_id),
                )
            return cur.fetchall()


def delete_instance(instance_id: str, owner_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM agent_instances WHERE id = %s AND owner_id = %s",
                (instance_id, owner_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


def update_instance_last_used(instance_id: str) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE agent_instances SET last_used_at = now() WHERE id = %s",
                (instance_id,),
            )
            conn.commit()


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


def create_entity(
    owner_id: str,
    name: str,
    slug: str,
    metadata: dict[str, Any] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO entities (owner_id, name, slug, metadata)
                VALUES (%s, %s, %s, %s)
                RETURNING *
                """,
                (owner_id, name, slug, _to_json(metadata)),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_entity(entity_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM entities WHERE id = %s AND owner_id = %s",
                (entity_id, owner_id),
            )
            return cur.fetchone()


def list_entities(owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT * FROM entities
                WHERE owner_id = %s
                ORDER BY created_at DESC
                """,
                (owner_id,),
            )
            return cur.fetchall()


# ---------------------------------------------------------------------------
# Clients
# ---------------------------------------------------------------------------


def create_client(
    owner_id: str,
    entity_id: str,
    name: str,
    slug: str,
    metadata: dict[str, Any] | None = None,
) -> dict:
    client_id = f"cli_{uuid4().hex}"
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO clients (id, owner_id, entity_id, name, slug, metadata)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (client_id, owner_id, entity_id, name, slug, _to_json(metadata)),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_client(client_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM clients WHERE id = %s AND owner_id = %s",
                (client_id, owner_id),
            )
            return cur.fetchone()


def list_clients(owner_id: str, entity_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT * FROM clients
                WHERE owner_id = %s AND entity_id = %s AND archived_at IS NULL
                ORDER BY created_at DESC
                """,
                (owner_id, entity_id),
            )
            return cur.fetchall()


def update_client(
    client_id: str,
    owner_id: str,
    entity_id: str,
    *,
    name: str | None = None,
    slug: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict | None:
    updates: list[str] = []
    params: list[Any] = []
    if name is not None:
        updates.append("name = %s")
        params.append(name)
    if slug is not None:
        updates.append("slug = %s")
        params.append(slug)
    if metadata is not None:
        updates.append("metadata = %s")
        params.append(_to_json(metadata))
    updates.append("updated_at = now()")
    params.extend([client_id, owner_id, entity_id])
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                f"""
                UPDATE clients
                SET {", ".join(updates)}
                WHERE id = %s AND owner_id = %s AND entity_id = %s AND archived_at IS NULL
                RETURNING *
                """,
                params,
            )
            row = cur.fetchone()
            conn.commit()
            return row


def archive_client(client_id: str, owner_id: str, entity_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE clients
                SET archived_at = now(), updated_at = now()
                WHERE id = %s AND owner_id = %s AND entity_id = %s AND archived_at IS NULL
                """,
                (client_id, owner_id, entity_id),
            )
            changed = cur.rowcount > 0
            conn.commit()
            return changed


# ---------------------------------------------------------------------------
# Custom Tools
# ---------------------------------------------------------------------------


def create_custom_tool(
    owner_id: str,
    name: str,
    slug: str,
    source_code: str,
    *,
    source_type: str = "python",
    description: str | None = None,
    args_json_schema: dict[str, Any] | None = None,
    tags: list[str] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO custom_tools (
                    owner_id, name, slug, description,
                    source_code, source_type, args_json_schema, tags
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (owner_id, slug)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description,
                    source_code = EXCLUDED.source_code,
                    source_type = EXCLUDED.source_type,
                    args_json_schema = EXCLUDED.args_json_schema,
                    tags = EXCLUDED.tags,
                    letta_tool_id = NULL,
                    updated_at = now()
                RETURNING *
                """,
                (
                    owner_id, name, slug, description,
                    source_code, source_type,
                    _to_json(args_json_schema),
                    _to_json(tags or []),
                ),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_custom_tool(tool_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM custom_tools WHERE id = %s AND owner_id = %s",
                (tool_id, owner_id),
            )
            return cur.fetchone()


def list_custom_tools(owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM custom_tools WHERE owner_id = %s ORDER BY created_at DESC",
                (owner_id,),
            )
            return cur.fetchall()


def delete_custom_tool(tool_id: str, owner_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM agent_type_tools WHERE custom_tool_id = %s",
                (tool_id,),
            )
            cur.execute(
                "DELETE FROM custom_tools WHERE id = %s AND owner_id = %s",
                (tool_id, owner_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


def update_custom_tool_letta_id(tool_id: str, letta_tool_id: str) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE custom_tools SET letta_tool_id = %s WHERE id = %s",
                (letta_tool_id, tool_id),
            )
            conn.commit()


# ---------------------------------------------------------------------------
# Custom MCP Servers
# ---------------------------------------------------------------------------


def create_custom_mcp_server(
    owner_id: str,
    name: str,
    slug: str,
    server_url: str = "",
    *,
    server_type: str = "streamable_http",
    transport: str = "streamable_http",
    auth_header: str | None = None,
    auth_token: str | None = None,
    custom_headers: dict[str, str] | None = None,
    description: str | None = None,
    command: str | None = None,
    args: list[str] | None = None,
    env: dict[str, str] | None = None,
    composio_app: str | None = None,
    composio_actions: list[str] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO custom_mcp_servers (
                    owner_id, name, slug, server_url, server_type,
                    auth_header, auth_token, custom_headers, description,
                    transport, command, args, env,
                    composio_app, composio_actions
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (owner_id, slug)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    server_url = EXCLUDED.server_url,
                    server_type = EXCLUDED.server_type,
                    auth_header = EXCLUDED.auth_header,
                    auth_token = EXCLUDED.auth_token,
                    custom_headers = EXCLUDED.custom_headers,
                    description = EXCLUDED.description,
                    transport = EXCLUDED.transport,
                    command = EXCLUDED.command,
                    args = EXCLUDED.args,
                    env = EXCLUDED.env,
                    composio_app = EXCLUDED.composio_app,
                    composio_actions = EXCLUDED.composio_actions,
                    updated_at = now()
                RETURNING *
                """,
                (
                    owner_id, name, slug, server_url, server_type,
                    auth_header, auth_token, _to_json(custom_headers), description,
                    transport, command, _to_json(args), _to_json(env),
                    composio_app, _to_json(composio_actions),
                ),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_custom_mcp_server(server_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM custom_mcp_servers WHERE id = %s AND owner_id = %s",
                (server_id, owner_id),
            )
            return cur.fetchone()


def list_custom_mcp_servers(owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM custom_mcp_servers WHERE owner_id = %s ORDER BY created_at DESC",
                (owner_id,),
            )
            return cur.fetchall()


def delete_custom_mcp_server(server_id: str, owner_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM agent_type_mcp_servers WHERE custom_mcp_server_id = %s",
                (server_id,),
            )
            cur.execute(
                "DELETE FROM custom_mcp_servers WHERE id = %s AND owner_id = %s",
                (server_id, owner_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------


def create_skill(
    owner_id: str,
    slug: str,
    name: str,
    description: str,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO skills (owner_id, slug, name, description)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (owner_id, slug)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description,
                    updated_at = now()
                RETURNING *
                """,
                (owner_id, slug, name, description),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def create_skill_version(
    skill_id: str,
    version: str,
    skill_md: str,
    *,
    frontmatter_name: str | None = None,
    frontmatter_description: str | None = None,
    bundle_json: dict[str, str] | None = None,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO skill_versions (
                    skill_id, version, frontmatter_name,
                    frontmatter_description, skill_md, bundle_json
                )
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (skill_id, version)
                DO UPDATE SET
                    frontmatter_name = EXCLUDED.frontmatter_name,
                    frontmatter_description = EXCLUDED.frontmatter_description,
                    skill_md = EXCLUDED.skill_md,
                    bundle_json = EXCLUDED.bundle_json
                RETURNING *
                """,
                (
                    skill_id, version, frontmatter_name,
                    frontmatter_description, skill_md,
                    _to_json(bundle_json or {}),
                ),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_skill(skill_id: str, owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM skills WHERE id = %s AND owner_id = %s",
                (skill_id, owner_id),
            )
            return cur.fetchone()


def list_skills(owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM skills WHERE owner_id = %s ORDER BY created_at DESC",
                (owner_id,),
            )
            return cur.fetchall()


# ---------------------------------------------------------------------------
# Join Tables
# ---------------------------------------------------------------------------


def attach_skill_to_agent_type(
    agent_type_id: str,
    skill_id: str,
    skill_version_id: str,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO agent_type_skills (agent_type_id, skill_id, skill_version_id)
                VALUES (%s, %s, %s)
                ON CONFLICT (agent_type_id, skill_id)
                DO UPDATE SET skill_version_id = EXCLUDED.skill_version_id
                RETURNING *
                """,
                (agent_type_id, skill_id, skill_version_id),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def list_agent_type_skills(agent_type_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT ats.*, s.slug AS skill_slug, s.name AS skill_name,
                       sv.version AS skill_version
                FROM agent_type_skills ats
                JOIN skills s ON s.id = ats.skill_id
                JOIN skill_versions sv ON sv.id = ats.skill_version_id
                WHERE ats.agent_type_id = %s
                ORDER BY s.created_at ASC
                """,
                (agent_type_id,),
            )
            return cur.fetchall()


def attach_tool_to_agent_type(agent_type_id: str, custom_tool_id: str) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO agent_type_tools (agent_type_id, custom_tool_id)
                VALUES (%s, %s)
                ON CONFLICT (agent_type_id, custom_tool_id) DO NOTHING
                RETURNING *
                """,
                (agent_type_id, custom_tool_id),
            )
            row = cur.fetchone()
            if row is None:
                cur.execute(
                    """
                    SELECT * FROM agent_type_tools
                    WHERE agent_type_id = %s AND custom_tool_id = %s
                    """,
                    (agent_type_id, custom_tool_id),
                )
                row = cur.fetchone()
            conn.commit()
    return row


def list_agent_type_tools(agent_type_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT ct.*, att.id AS agent_type_tool_id, att.created_at AS attached_at
                FROM agent_type_tools att
                JOIN custom_tools ct ON ct.id = att.custom_tool_id
                WHERE att.agent_type_id = %s
                ORDER BY ct.created_at ASC
                """,
                (agent_type_id,),
            )
            return cur.fetchall()


def detach_tool_from_agent_type(agent_type_id: str, custom_tool_id: str) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM agent_type_tools
                WHERE agent_type_id = %s AND custom_tool_id = %s
                """,
                (agent_type_id, custom_tool_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


def attach_mcp_server_to_agent_type(
    agent_type_id: str,
    custom_mcp_server_id: str,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO agent_type_mcp_servers (agent_type_id, custom_mcp_server_id)
                VALUES (%s, %s)
                ON CONFLICT (agent_type_id, custom_mcp_server_id) DO NOTHING
                RETURNING *
                """,
                (agent_type_id, custom_mcp_server_id),
            )
            row = cur.fetchone()
            if row is None:
                cur.execute(
                    """
                    SELECT * FROM agent_type_mcp_servers
                    WHERE agent_type_id = %s AND custom_mcp_server_id = %s
                    """,
                    (agent_type_id, custom_mcp_server_id),
                )
                row = cur.fetchone()
            conn.commit()
    return row


def list_agent_type_mcp_servers(agent_type_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT cms.*, atms.id AS agent_type_mcp_server_id,
                       atms.created_at AS attached_at
                FROM agent_type_mcp_servers atms
                JOIN custom_mcp_servers cms ON cms.id = atms.custom_mcp_server_id
                WHERE atms.agent_type_id = %s
                ORDER BY cms.created_at ASC
                """,
                (agent_type_id,),
            )
            return cur.fetchall()


def detach_mcp_server_from_agent_type(
    agent_type_id: str,
    custom_mcp_server_id: str,
) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM agent_type_mcp_servers
                WHERE agent_type_id = %s AND custom_mcp_server_id = %s
                """,
                (agent_type_id, custom_mcp_server_id),
            )
            deleted = cur.rowcount > 0
            conn.commit()
    return deleted


# ---------------------------------------------------------------------------
# Letta Projects
# ---------------------------------------------------------------------------


def get_or_create_project(
    owner_id: str,
    letta_project_id: str,
    project_name: str,
) -> dict:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO letta_projects (owner_id, letta_project_id, project_name)
                VALUES (%s, %s, %s)
                ON CONFLICT (owner_id)
                DO UPDATE SET
                    letta_project_id = EXCLUDED.letta_project_id,
                    project_name = EXCLUDED.project_name,
                    updated_at = now()
                RETURNING *
                """,
                (owner_id, letta_project_id, project_name),
            )
            row = cur.fetchone()
            conn.commit()
    return row


def get_project_for_owner(owner_id: str) -> dict | None:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM letta_projects WHERE owner_id = %s",
                (owner_id,),
            )
            return cur.fetchone()


# ---------------------------------------------------------------------------
# Runtime helpers (for building RuntimeBundle)
# ---------------------------------------------------------------------------


def get_runtime_skill_rows(agent_type_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT
                    s.id AS skill_id,
                    s.slug AS skill_slug,
                    s.name AS skill_name,
                    sv.id AS skill_version_id,
                    sv.version AS skill_version,
                    sv.skill_md,
                    sv.bundle_json
                FROM agent_type_skills ats
                JOIN skills s ON s.id = ats.skill_id
                JOIN skill_versions sv ON sv.id = ats.skill_version_id
                WHERE ats.agent_type_id = %s
                ORDER BY s.created_at ASC
                """,
                (agent_type_id,),
            )
            return cur.fetchall()


def get_runtime_custom_tool_rows(agent_type_id: str, owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT
                    ct.id AS custom_tool_id,
                    ct.name,
                    ct.slug,
                    ct.source_code,
                    ct.source_type,
                    ct.args_json_schema,
                    ct.letta_tool_id
                FROM agent_type_tools att
                JOIN custom_tools ct ON ct.id = att.custom_tool_id
                WHERE att.agent_type_id = %s AND ct.owner_id = %s
                ORDER BY ct.created_at ASC
                """,
                (agent_type_id, owner_id),
            )
            return cur.fetchall()


def get_runtime_mcp_server_rows(agent_type_id: str, owner_id: str) -> list[dict]:
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT
                    cms.id AS custom_mcp_server_id,
                    cms.name,
                    cms.slug,
                    cms.server_url,
                    cms.server_type,
                    cms.transport,
                    cms.auth_header,
                    cms.auth_token,
                    cms.custom_headers,
                    cms.command,
                    cms.args,
                    cms.env
                FROM agent_type_mcp_servers atms
                JOIN custom_mcp_servers cms ON cms.id = atms.custom_mcp_server_id
                WHERE atms.agent_type_id = %s AND cms.owner_id = %s
                ORDER BY cms.created_at ASC
                """,
                (agent_type_id, owner_id),
            )
            return cur.fetchall()
