import atexit
import logging
import os
from contextlib import contextmanager

from psycopg_pool import ConnectionPool

logger = logging.getLogger(__name__)

_pool: ConnectionPool | None = None


def _close_pool() -> None:
    global _pool
    if _pool is not None:
        try:
            _pool.close()
        except Exception:
            pass
        _pool = None


atexit.register(_close_pool)


def _create_pool() -> ConnectionPool:
    db_url = os.environ.get("OPENCREW_DB_URL") or os.environ.get("DB_URL")
    if not db_url:
        try:
            from pathlib import Path
            import yaml
            from opencrew.user_config import local_db_url, normalize_config

            cfg_path = Path.home() / ".opencrew" / "config.yaml"
            if cfg_path.exists():
                cfg = normalize_config(yaml.safe_load(cfg_path.read_text()) or {})
                db_url = local_db_url(cfg)
        except Exception:
            pass
    if not db_url:
        raise RuntimeError(
            "Database URL not set. Set OPENCREW_DB_URL or run `opencrew init`."
        )
    return ConnectionPool(
        conninfo=db_url,
        min_size=1,
        max_size=5,
        check=ConnectionPool.check_connection,
        max_idle=300,
        reconnect_timeout=5,
    )


def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None or _pool.closed:
        _pool = _create_pool()
    return _pool


def reset_pool() -> None:
    """Tear down the current pool and force a fresh one on next use."""
    global _pool
    if _pool is not None:
        try:
            _pool.close()
        except Exception:
            pass
        _pool = None


@contextmanager
def get_conn():
    pool = get_pool()
    try:
        with pool.connection() as conn:
            yield conn
    except Exception as exc:
        err_msg = str(exc).lower()
        type_name = type(exc).__name__.lower()
        if "pooltimeout" in type_name or any(
            k in err_msg
            for k in (
                "ssl",
                "closed",
                "bad",
                "operational",
                "connection refused",
                "couldn't get a connection",
            )
        ):
            logger.warning("DB connection error, resetting pool: %s", exc)
            reset_pool()
        raise
