from __future__ import annotations

import psycopg


_TABLES = [
    """
    CREATE TABLE IF NOT EXISTS api_keys (
        id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id    text        NOT NULL,
        entity_id   text,
        label       text,
        key_hash    text        UNIQUE NOT NULL,
        key_prefix  text,
        created_at  timestamptz DEFAULT now(),
        revoked_at  timestamptz
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS entities (
        id          text        PRIMARY KEY,
        owner_id    text        NOT NULL,
        name        text        NOT NULL,
        slug        text        NOT NULL,
        metadata    jsonb,
        created_at  timestamptz DEFAULT now(),
        updated_at  timestamptz DEFAULT now(),
        archived_at timestamptz
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS clients (
        id          text        PRIMARY KEY,
        owner_id    text        NOT NULL,
        entity_id   text        REFERENCES entities(id),
        name        text        NOT NULL,
        slug        text        NOT NULL,
        metadata    jsonb,
        created_at  timestamptz DEFAULT now(),
        updated_at  timestamptz DEFAULT now(),
        archived_at timestamptz
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS agent_types (
        id               uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id         text        NOT NULL,
        name             text        NOT NULL,
        slug             text        NOT NULL,
        description      text,
        persona          text,
        system_prompt    text,
        model            text,
        memory_defaults  jsonb,
        readiness_status text        DEFAULT 'ready',
        created_at       timestamptz DEFAULT now(),
        updated_at       timestamptz DEFAULT now(),
        UNIQUE(owner_id, slug)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS agent_instances (
        id               uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id         text        NOT NULL,
        agent_type_id    uuid        REFERENCES agent_types(id),
        letta_agent_id   text        UNIQUE,
        letta_project_id text,
        entity_id        text,
        client_id        text,
        name             text,
        display_name     text,
        avatar_url       text,
        is_default       boolean     DEFAULT false,
        status           text        DEFAULT 'active',
        created_at       timestamptz DEFAULT now(),
        last_used_at     timestamptz
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS runs (
        id               uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id         text        NOT NULL,
        agent_type_id    uuid,
        entity_id        text,
        client_id        text,
        agent_id         text,
        message          text        NOT NULL,
        status           text        DEFAULT 'pending',
        session_options  jsonb,
        skill_manifest   jsonb,
        result           jsonb,
        error            text,
        created_at       timestamptz DEFAULT now(),
        started_at       timestamptz,
        completed_at     timestamptz
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS run_events (
        id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        run_id      uuid        NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
        seq         integer     NOT NULL,
        event_type  text        NOT NULL,
        payload     jsonb       DEFAULT '{}',
        created_at  timestamptz DEFAULT now()
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS run_logs (
        id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        run_id      uuid        REFERENCES runs(id),
        level       text        NOT NULL,
        message     text        NOT NULL,
        metadata    jsonb,
        created_at  timestamptz DEFAULT now()
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS skills (
        id                uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id          text        NOT NULL,
        slug              text        NOT NULL,
        name              text        NOT NULL,
        description       text,
        latest_version_id uuid,
        created_at        timestamptz DEFAULT now(),
        updated_at        timestamptz DEFAULT now(),
        UNIQUE(owner_id, slug)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS skill_versions (
        id                      uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        skill_id                uuid        REFERENCES skills(id),
        version                 text        NOT NULL,
        frontmatter_name        text,
        frontmatter_description text,
        skill_md                text,
        bundle_json             jsonb,
        created_by              text,
        created_at              timestamptz DEFAULT now(),
        UNIQUE(skill_id, version)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS custom_tools (
        id              uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id        text        NOT NULL,
        name            text        NOT NULL,
        slug            text        NOT NULL,
        description     text,
        source_code     text        NOT NULL,
        source_type     text        DEFAULT 'python',
        args_json_schema jsonb,
        tags            jsonb,
        letta_tool_id   text,
        created_at      timestamptz DEFAULT now(),
        updated_at      timestamptz DEFAULT now(),
        UNIQUE(owner_id, slug)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS custom_mcp_servers (
        id             uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id       text        NOT NULL,
        name           text        NOT NULL,
        slug           text        NOT NULL,
        server_url     text        NOT NULL,
        server_type    text        DEFAULT 'streamable_http',
        auth_header    text,
        auth_token     text,
        custom_headers jsonb,
        description    text,
        created_at     timestamptz DEFAULT now(),
        updated_at     timestamptz DEFAULT now(),
        UNIQUE(owner_id, slug)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS agent_type_skills (
        id               uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        agent_type_id    uuid REFERENCES agent_types(id),
        skill_id         uuid REFERENCES skills(id),
        skill_version_id uuid REFERENCES skill_versions(id),
        UNIQUE(agent_type_id, skill_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS agent_type_tools (
        id             uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        agent_type_id  uuid REFERENCES agent_types(id),
        custom_tool_id uuid REFERENCES custom_tools(id) ON DELETE CASCADE,
        UNIQUE(agent_type_id, custom_tool_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS agent_type_mcp_servers (
        id                   uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        agent_type_id        uuid REFERENCES agent_types(id),
        custom_mcp_server_id uuid REFERENCES custom_mcp_servers(id) ON DELETE CASCADE,
        UNIQUE(agent_type_id, custom_mcp_server_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS letta_projects (
        id               uuid DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id         text UNIQUE NOT NULL,
        letta_project_id text UNIQUE NOT NULL,
        project_name     text,
        created_at       timestamptz DEFAULT now()
    )
    """,
]

_MIGRATIONS = [
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS transport text DEFAULT 'streamable_http'",
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS command text",
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS args jsonb",
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS env jsonb",
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS composio_app text",
    "ALTER TABLE custom_mcp_servers ADD COLUMN IF NOT EXISTS composio_actions jsonb",
    """
    CREATE TABLE IF NOT EXISTS chats (
        id             uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        owner_id       text        NOT NULL,
        agent_type_slug text       NOT NULL,
        title          text,
        created_at     timestamptz DEFAULT now(),
        updated_at     timestamptz DEFAULT now()
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS chat_messages (
        id         uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
        chat_id    uuid        NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
        role       text        NOT NULL,
        content    text        NOT NULL,
        run_id     uuid        REFERENCES runs(id),
        created_at timestamptz DEFAULT now()
    )
    """,
    "ALTER TABLE chats ADD COLUMN IF NOT EXISTS instance_id uuid",
]

_REQUIRED_TABLES = frozenset(
    [
        "api_keys",
        "entities",
        "clients",
        "agent_types",
        "agent_instances",
        "runs",
        "run_events",
        "run_logs",
        "skills",
        "skill_versions",
        "custom_tools",
        "custom_mcp_servers",
        "agent_type_skills",
        "agent_type_tools",
        "agent_type_mcp_servers",
        "letta_projects",
    ]
)


def run_migrations(db_url: str) -> None:
    with psycopg.connect(db_url) as conn:
        with conn.cursor() as cur:
            for ddl in _TABLES:
                cur.execute(ddl)
            for ddl in _MIGRATIONS:
                cur.execute(ddl)
        conn.commit()


def check_migrations(db_url: str) -> bool:
    with psycopg.connect(db_url) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT tablename FROM pg_tables
                WHERE schemaname = 'public'
                """
            )
            existing = {row[0] for row in cur.fetchall()}

    return _REQUIRED_TABLES.issubset(existing)
