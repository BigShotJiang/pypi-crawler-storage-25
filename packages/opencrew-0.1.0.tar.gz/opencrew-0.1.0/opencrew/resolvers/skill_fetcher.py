"""Fetch skill contents from local paths, skills.sh, or GitHub."""
from __future__ import annotations

import base64
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class SkillFetchError(RuntimeError):
    pass


def fetch_local(path: Path) -> dict[str, str]:
    """Read a skill from a local directory containing SKILL.md."""
    skill_md_path = path if path.name == "SKILL.md" else path / "SKILL.md"
    if not skill_md_path.exists():
        raise SkillFetchError(f"SKILL.md not found at {skill_md_path}")

    skill_dir = skill_md_path.parent
    files: dict[str, str] = {}
    for f in skill_dir.rglob("*"):
        if f.is_file():
            rel = str(f.relative_to(skill_dir))
            try:
                files[rel] = f.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
    return files


def fetch_skillssh(package: str, *, timeout: int = 60) -> dict[str, str]:
    """Fetch a skill from skills.sh using ``npx skills add``."""
    with tempfile.TemporaryDirectory(prefix="opencrew_skill_") as tmpdir:
        target = Path(tmpdir) / "skill"
        target.mkdir()
        try:
            result = subprocess.run(
                ["npx", "-y", "skills", "add", package, "--dir", str(target)],
                capture_output=True, text=True, timeout=timeout,
                cwd=tmpdir,
            )
        except FileNotFoundError:
            raise SkillFetchError(
                "npx not found. Install Node.js to use skills.sh packages."
            )
        except subprocess.TimeoutExpired:
            raise SkillFetchError(f"Timed out fetching skill {package} from skills.sh")

        if result.returncode != 0:
            raise SkillFetchError(
                f"skills.sh fetch failed for {package}: {result.stderr[:500]}"
            )

        skill_md = _find_skill_md(target)
        if skill_md is None:
            raise SkillFetchError(
                f"No SKILL.md found after fetching {package} from skills.sh"
            )
        return _read_dir(skill_md.parent)


def fetch_github(
    repo: str,
    path: str = "",
    *,
    ref: str = "main",
    timeout: int = 30,
) -> dict[str, str]:
    """Fetch a skill directory from a GitHub repository via the contents API."""
    base_url = f"https://api.github.com/repos/{repo}/contents/{path}"
    params: dict[str, str] = {}
    if ref:
        params["ref"] = ref

    try:
        resp = httpx.get(base_url, params=params, timeout=timeout)
    except httpx.HTTPError as exc:
        raise SkillFetchError(f"GitHub API request failed: {exc}") from exc

    if resp.status_code == 404:
        raise SkillFetchError(f"GitHub path not found: {repo}/{path}")
    if resp.status_code >= 400:
        raise SkillFetchError(
            f"GitHub API error ({resp.status_code}): {resp.text[:300]}"
        )

    data = resp.json()
    files: dict[str, str] = {}

    if isinstance(data, list):
        for item in data:
            if item.get("type") == "file":
                content = _github_file_content(item, timeout=timeout)
                if content is not None:
                    files[item["name"]] = content
            elif item.get("type") == "dir":
                sub = fetch_github(repo, item["path"], ref=ref, timeout=timeout)
                for sub_name, sub_content in sub.items():
                    files[f"{item['name']}/{sub_name}"] = sub_content
    elif isinstance(data, dict) and data.get("type") == "file":
        content = _github_file_content(data, timeout=timeout)
        if content is not None:
            files[data["name"]] = content

    if not files.get("SKILL.md"):
        raise SkillFetchError(f"No SKILL.md found in {repo}/{path}")

    return files


def _github_file_content(item: dict[str, Any], *, timeout: int = 30) -> str | None:
    if item.get("content"):
        try:
            return base64.b64decode(item["content"]).decode("utf-8")
        except Exception:
            return None
    download_url = item.get("download_url")
    if download_url:
        try:
            resp = httpx.get(download_url, timeout=timeout)
            if resp.status_code == 200:
                return resp.text
        except Exception:
            pass
    return None


def _find_skill_md(root: Path) -> Path | None:
    for p in root.rglob("SKILL.md"):
        return p
    return None


def _read_dir(directory: Path) -> dict[str, str]:
    files: dict[str, str] = {}
    for f in directory.rglob("*"):
        if f.is_file():
            rel = str(f.relative_to(directory))
            try:
                files[rel] = f.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
    return files
