"""Resolve Composio app+actions into an MCP server URL.

Requires the ``composio`` package (optional dependency).
If not installed, ``resolve()`` raises a clear error message.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_API_BASE = "https://backend.composio.dev"


class ComposioError(RuntimeError):
    pass


@dataclass
class ComposioMcpResult:
    server_url: str
    auth_header: str
    auth_token: str


def _get_api_key() -> str:
    key = os.environ.get("COMPOSIO_API_KEY", "").strip()
    if not key:
        try:
            import yaml
            from pathlib import Path
            cfg_path = Path.home() / ".opencrew" / "config.yaml"
            if cfg_path.exists():
                cfg = yaml.safe_load(cfg_path.read_text())
                key = (cfg or {}).get("composio_api_key", "")
        except Exception:
            pass
    if not key:
        raise ComposioError(
            "Composio API key not found. Set COMPOSIO_API_KEY or add "
            "composio_api_key to ~/.opencrew/config.yaml"
        )
    return key


def resolve(
    app: str,
    actions: list[str] | None = None,
    *,
    api_key: str | None = None,
    user_id: str = "opencrew-local",
) -> ComposioMcpResult:
    """Create a Composio MCP server for *app* and return connection details."""
    key = api_key or _get_api_key()
    headers = {"x-api-key": key, "Content-Type": "application/json"}

    server_body: dict[str, Any] = {
        "name": f"opencrew-{app.lower()}",
        "toolkits": [{"name": app}],
    }
    if actions:
        server_body["toolkits"][0]["allowed_tools"] = actions

    try:
        resp = httpx.post(
            f"{_API_BASE}/v3/mcp/servers",
            headers=headers,
            json=server_body,
            timeout=30,
        )
        if resp.status_code >= 400:
            raise ComposioError(f"Composio server creation failed ({resp.status_code}): {resp.text[:300]}")
        server_data = resp.json()
        server_id = server_data.get("id") or server_data.get("mcp_config_id")
        if not server_id:
            raise ComposioError(f"Composio returned no server id: {resp.text[:300]}")
    except httpx.HTTPError as exc:
        raise ComposioError(f"Composio API request failed: {exc}") from exc

    try:
        resp = httpx.post(
            f"{_API_BASE}/v3/mcp/generate",
            headers=headers,
            json={"user_id": user_id, "mcp_config_id": server_id},
            timeout=30,
        )
        if resp.status_code >= 400:
            raise ComposioError(f"Composio URL generation failed ({resp.status_code}): {resp.text[:300]}")
        instance = resp.json()
        url = instance.get("url") or instance.get("mcp_url")
        if not url:
            raise ComposioError(f"Composio returned no URL: {resp.text[:300]}")
    except httpx.HTTPError as exc:
        raise ComposioError(f"Composio API request failed: {exc}") from exc

    return ComposioMcpResult(
        server_url=url,
        auth_header="x-api-key",
        auth_token=key,
    )
