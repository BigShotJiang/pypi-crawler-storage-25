"""Test execution engine that runs test cases against a live OpenCrew agent."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import httpx
import yaml

from opencrew.sdk.client import OpenCrew
from opencrew.sdk.http_util import format_api_error
from opencrew.sdk.streaming import assistant_text_from_run_result, payload_assistant_text
from opencrew.testing.evaluator import evaluate, evaluate_memory
from opencrew.testing.models import (
    AfterAssertions,
    AssertionResult,
    StepResult,
    TestCase,
    TestResult,
)

logger = logging.getLogger(__name__)


def _agent_type_404_tip(exc: httpx.HTTPStatusError) -> str:
    if exc.response.status_code != 404:
        return ""
    try:
        data = exc.response.json()
        detail = data.get("detail", "")
        ds = detail if isinstance(detail, str) else ""
    except Exception:
        ds = ""
    low = ds.lower()
    if "agent type" not in low or "not found" not in low:
        return ""
    host = (exc.request.url.host or "").lower()
    local = host in ("localhost", "127.0.0.1") or host.endswith(".local")
    if local:
        return (
            "\n\nTip: You are calling the local API, but this agent type was probably "
            "registered on cloud only. With remote credentials in ~/.opencrew/config.yaml, "
            "`opencrew apply` defaults to cloud (message says “Deployed”). "
            "Either run `opencrew apply … --local` then `opencrew test … --local`, "
            "or test without `--local` so both hit the same API. See `opencrew target`."
        )
    return (
        "\n\nTip: This agent type is not on the API you called. "
        "Use the same `--local` / `--cloud` / default (auto) for both "
        "`opencrew apply` and `opencrew test`. See `opencrew target`."
    )


def _assistant_text_from_recorded_stream_events(events: list[dict[str, Any]]) -> str:
    """Recover assistant text from SSE-shaped dicts when live aggregation missed a shape."""
    chunks: list[str] = []
    for ev in events:
        pl = ev.get("payload") if isinstance(ev.get("payload"), dict) else {}
        et = str(ev.get("type") or ev.get("event_type") or "")
        if et == "assistant" or pl.get("type") == "assistant":
            raw = ev.get("content")
            if isinstance(raw, str) and raw.strip():
                chunks.append(raw)
            else:
                t = payload_assistant_text(pl)
                if t:
                    chunks.append(t)
    return "".join(chunks)


def discover_tests(agent_slug: str, specific_path: str | None = None) -> list[Path]:
    """Find test YAML files for an agent."""
    if specific_path:
        p = Path(specific_path)
        if p.exists():
            return [p]
        return []

    candidates = [
        Path.cwd() / agent_slug / "tests",
        Path.cwd() / "tests",
    ]
    test_files: list[Path] = []
    for d in candidates:
        if d.is_dir():
            test_files.extend(sorted(d.glob("*.yaml")))
            test_files.extend(sorted(d.glob("*.yml")))

    return test_files


def load_test_case(path: Path) -> TestCase:
    """Parse a test YAML file into a TestCase model."""
    raw = yaml.safe_load(path.read_text())
    if not isinstance(raw, dict):
        raise ValueError(f"Test file {path} must be a YAML dict")
    return TestCase.model_validate(raw)


def run_test_case(
    client: OpenCrew,
    agent_slug: str,
    test: TestCase,
    *,
    timeout: int = 120,
    verbose: bool = False,
) -> TestResult:
    """Execute a single test case against a live agent, returning results."""
    instance_id: str | None = None
    step_results: list[StepResult] = []

    for i, step in enumerate(test.steps):
        t0 = time.monotonic()
        try:
            create_kwargs: dict[str, Any] = {
                "agent_type": agent_slug,
                "message": step.send,
            }
            if i == 0:
                create_kwargs["fresh"] = True
            if instance_id and i > 0:
                create_kwargs["instance_id"] = instance_id

            run = client.runs.create(**create_kwargs)
            run_id = run.get("run_id") or run.get("id")
            if i == 0 and run.get("instance_id"):
                instance_id = str(run["instance_id"])

            events: list[dict[str, Any]] = []
            response_parts: list[str] = []
            for event in client.runs.stream(run_id):
                ev_dict = {"type": event.type, "content": event.content}
                if hasattr(event, "payload") and event.payload:
                    ev_dict["payload"] = event.payload
                events.append(ev_dict)
                pl = event.payload if isinstance(event.payload, dict) else {}
                eff_type = event.type
                if eff_type == "message" and pl.get("type"):
                    eff_type = str(pl["type"])
                if eff_type == "assistant":
                    chunk = event.content if event.content else payload_assistant_text(pl)
                    if chunk:
                        response_parts.append(chunk)
                elif event.type == "message" and event.content and not pl.get("type"):
                    response_parts.append(event.content)
                elif event.type == "done":
                    if not "".join(response_parts) and event.payload:
                        res = event.payload.get("result")
                        if isinstance(res, str) and res.strip():
                            response_parts.append(res.strip())
                        elif isinstance(res, dict):
                            tail = assistant_text_from_run_result(res)
                            if tail:
                                response_parts.append(tail)
                    break

            response_text = "".join(response_parts)

            poll_result: dict[str, Any] | None = None
            try:
                pr = client.runs.get(run_id)
                poll_result = pr if isinstance(pr, dict) else None
            except Exception:
                poll_result = None

            if not response_text and poll_result:
                res_block = poll_result.get("result")
                if isinstance(res_block, dict):
                    response_text = assistant_text_from_run_result(res_block)
                elif isinstance(res_block, str) and res_block.strip():
                    response_text = res_block.strip()
            if not response_text:
                response_text = _assistant_text_from_recorded_stream_events(events)
            if not response_text:
                try:
                    api_events = client.runs.events(run_id)
                except Exception:
                    api_events = []
                if api_events:
                    normalized = [
                        {"type": e.get("event_type"), "payload": e.get("payload"), "content": ""}
                        for e in api_events
                        if isinstance(e, dict)
                    ]
                    response_text = _assistant_text_from_recorded_stream_events(normalized)

            duration = time.monotonic() - t0

            run_failed_detail = ""
            if poll_result and poll_result.get("status") == "failed":
                run_failed_detail = str(poll_result.get("error") or "").strip() or "run failed"

            assertion_results = [
                evaluate(a, response_text, events)
                for a in step.assert_
            ]
            if run_failed_detail:
                assertion_results.insert(
                    0,
                    AssertionResult(
                        passed=False,
                        label="run_failed",
                        detail=run_failed_detail[:8000],
                    ),
                )

            step_results.append(StepResult(
                step_index=i,
                send=step.send,
                response=response_text,
                duration_s=round(duration, 1),
                assertions=assertion_results,
                events=events,
            ))

        except httpx.HTTPStatusError as exc:
            duration = time.monotonic() - t0
            base = format_api_error(exc.response)
            tip = _agent_type_404_tip(exc)
            err = f"Step {i + 1} failed:\n{base}{tip}"
            return TestResult(
                name=test.name,
                description=test.description,
                steps=step_results,
                error=err,
            )
        except Exception as exc:
            duration = time.monotonic() - t0
            return TestResult(
                name=test.name,
                description=test.description,
                steps=step_results,
                error=f"Step {i + 1} failed with exception: {exc}",
            )

    after_results = []
    if test.after and instance_id:
        try:
            memory = client.instances.memory(agent_slug, instance_id)
            if test.after.memory_contains:
                after_results.append(
                    evaluate_memory("memory_contains", test.after.memory_contains, memory)
                )
            if test.after.memory_not_contains:
                after_results.append(
                    evaluate_memory("memory_not_contains", test.after.memory_not_contains, memory, negate=True)
                )
        except Exception as exc:
            after_results.append(
                _make_error_assertion(f"memory check failed: {exc}")
            )

    return TestResult(
        name=test.name,
        description=test.description,
        steps=step_results,
        after_results=after_results,
    )


def _make_error_assertion(msg: str):
    from opencrew.testing.models import AssertionResult
    return AssertionResult(passed=False, label="error", detail=msg)
