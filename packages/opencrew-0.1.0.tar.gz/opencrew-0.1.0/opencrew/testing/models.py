from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field


class Assertion(BaseModel):
    contains: str | None = None
    not_contains: str | None = None
    regex: str | None = None
    not_regex: str | None = None
    tool_called: str | None = None
    tool_not_called: str | None = None
    max_steps: int | None = None
    min_length: int | None = None
    max_length: int | None = None


class AfterAssertions(BaseModel):
    memory_contains: str | None = None
    memory_not_contains: str | None = None


class TestStep(BaseModel):
    send: str
    assert_: list[Assertion] = Field(default_factory=list, alias="assert")

    model_config = {"populate_by_name": True}


class TestCase(BaseModel):
    name: str
    description: str = ""
    steps: list[TestStep]
    after: AfterAssertions | None = None


@dataclass
class AssertionResult:
    passed: bool
    label: str
    detail: str = ""


@dataclass
class StepResult:
    step_index: int
    send: str
    response: str
    duration_s: float
    assertions: list[AssertionResult] = field(default_factory=list)
    events: list[dict[str, Any]] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(a.passed for a in self.assertions)


@dataclass
class TestResult:
    name: str
    description: str
    steps: list[StepResult] = field(default_factory=list)
    after_results: list[AssertionResult] = field(default_factory=list)
    error: str | None = None

    @property
    def passed(self) -> bool:
        if self.error:
            return False
        return all(s.passed for s in self.steps) and all(a.passed for a in self.after_results)

    @property
    def total_duration_s(self) -> float:
        return sum(s.duration_s for s in self.steps)
