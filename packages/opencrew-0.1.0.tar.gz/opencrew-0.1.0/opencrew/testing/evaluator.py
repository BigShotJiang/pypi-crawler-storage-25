"""Evaluate assertions against agent responses and event streams."""
from __future__ import annotations

import re
from typing import Any

from opencrew.testing.models import Assertion, AssertionResult


def evaluate(
    assertion: Assertion,
    response_text: str,
    events: list[dict[str, Any]],
) -> AssertionResult:
    """Evaluate a single assertion. Returns an AssertionResult."""
    if assertion.contains is not None:
        found = assertion.contains.lower() in response_text.lower()
        return AssertionResult(
            passed=found,
            label=f'contains "{assertion.contains}"',
            detail="" if found else f"not found in response ({len(response_text)} chars)",
        )

    if assertion.not_contains is not None:
        found = assertion.not_contains.lower() in response_text.lower()
        return AssertionResult(
            passed=not found,
            label=f'not_contains "{assertion.not_contains}"',
            detail="" if not found else "unexpectedly found in response",
        )

    if assertion.regex is not None:
        match = re.search(assertion.regex, response_text)
        return AssertionResult(
            passed=match is not None,
            label=f'regex "{assertion.regex}"',
            detail="" if match else "pattern not found in response",
        )

    if assertion.not_regex is not None:
        match = re.search(assertion.not_regex, response_text)
        return AssertionResult(
            passed=match is None,
            label=f'not_regex "{assertion.not_regex}"',
            detail="" if match is None else "pattern unexpectedly matched",
        )

    if assertion.tool_called is not None:
        called = any(
            e.get("type") == "tool_call" and
            (e.get("name") == assertion.tool_called or
             e.get("payload", {}).get("name") == assertion.tool_called)
            for e in events
        )
        return AssertionResult(
            passed=called,
            label=f'tool_called "{assertion.tool_called}"',
            detail="" if called else "tool was not called",
        )

    if assertion.tool_not_called is not None:
        called = any(
            e.get("type") == "tool_call" and
            (e.get("name") == assertion.tool_not_called or
             e.get("payload", {}).get("name") == assertion.tool_not_called)
            for e in events
        )
        return AssertionResult(
            passed=not called,
            label=f'tool_not_called "{assertion.tool_not_called}"',
            detail="" if not called else "tool was unexpectedly called",
        )

    if assertion.max_steps is not None:
        step_count = sum(
            1 for e in events
            if e.get("type") in ("reasoning", "tool_call")
        )
        ok = step_count <= assertion.max_steps
        return AssertionResult(
            passed=ok,
            label=f"max_steps {assertion.max_steps}",
            detail="" if ok else f"actual steps: {step_count}",
        )

    if assertion.min_length is not None:
        ok = len(response_text) >= assertion.min_length
        return AssertionResult(
            passed=ok,
            label=f"min_length {assertion.min_length}",
            detail="" if ok else f"actual length: {len(response_text)}",
        )

    if assertion.max_length is not None:
        ok = len(response_text) <= assertion.max_length
        return AssertionResult(
            passed=ok,
            label=f"max_length {assertion.max_length}",
            detail="" if ok else f"actual length: {len(response_text)}",
        )

    return AssertionResult(passed=True, label="(no assertion)", detail="")


def evaluate_memory(
    field_name: str,
    expected: str,
    memory_blocks: list[dict[str, Any]],
    *,
    negate: bool = False,
) -> AssertionResult:
    """Evaluate a memory assertion against agent memory blocks."""
    all_text = " ".join(
        str(block.get("value", "")) for block in memory_blocks
    ).lower()
    found = expected.lower() in all_text

    if negate:
        return AssertionResult(
            passed=not found,
            label=f'memory_not_contains "{expected}"',
            detail="" if not found else "unexpectedly found in memory",
        )
    return AssertionResult(
        passed=found,
        label=f'memory_contains "{expected}"',
        detail="" if found else "not found in agent memory blocks",
    )
