from __future__ import annotations

import hashlib
import secrets
from uuid import UUID

from psycopg.rows import dict_row

from opencrew.store.db import get_conn
from opencrew.types import ApiKey


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def validate_key(raw_key: str) -> ApiKey | None:
    normalized = raw_key.strip()
    if not normalized.startswith("lmp_") or len(normalized) != 36:
        return None
    key_hash = _hash_key(normalized)
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """SELECT id, owner_id, entity_id, label, key_prefix, created_at, revoked_at
                   FROM api_keys WHERE key_hash = %s AND revoked_at IS NULL""",
                (key_hash,),
            )
            row = cur.fetchone()
    if row is None:
        return None
    if row.get("entity_id") is None:
        return None
    return ApiKey(**row)


def generate_key(owner_id: str, entity_id: str, *, label: str = "default") -> tuple[str, dict]:
    """Generate a new API key. Returns (raw_key, db_row)."""
    raw = "lmp_" + secrets.token_hex(16)
    key_hash = _hash_key(raw)
    key_prefix = raw[:8]
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """INSERT INTO api_keys (owner_id, entity_id, label, key_hash, key_prefix)
                   VALUES (%s, %s, %s, %s, %s) RETURNING *""",
                (owner_id, entity_id, label, key_hash, key_prefix),
            )
            conn.commit()
            row = cur.fetchone()
    return raw, row
