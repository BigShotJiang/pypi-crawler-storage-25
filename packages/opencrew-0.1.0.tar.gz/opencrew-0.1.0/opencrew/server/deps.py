from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any
from uuid import UUID

from fastapi import Header, HTTPException

from opencrew.server.auth import validate_key
from opencrew.types import ApiKey, RuntimeBundle, SessionOptions
from opencrew.letta import client as letta
from opencrew.store import catalog, registry

logger = logging.getLogger(__name__)

_runner = None


def http_exception_from_letta_error(exc: BaseException) -> HTTPException:
    """Turn Letta client RuntimeError (HTTP status + body) into a FastAPI response the CLI can show."""
    msg = str(exc).strip() or repr(exc)
    m = re.search(r"Letta API error (\d{3})\s*:", msg)
    letta_code = int(m.group(1)) if m else None
    if letta_code == 404:
        status = 404
    elif letta_code is not None and 400 <= letta_code < 500:
        status = 400
    elif letta_code is not None and letta_code >= 500:
        status = 502
    else:
        status = 502
    return HTTPException(status_code=status, detail=msg)


def letta_get_agent_or_raise(letta_id: str) -> dict[str, Any] | None:
    try:
        return letta.get_agent(letta_id)
    except RuntimeError as e:
        raise http_exception_from_letta_error(e) from e


def get_runner():
    global _runner
    if _runner is None:
        from opencrew.runner.local import LocalRunner
        _runner = LocalRunner()
    return _runner


async def require_api_key(x_api_key: str = Header(...)) -> ApiKey:
    key = validate_key(x_api_key)
    if key is None:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")
    return key


def build_memory_blocks(agent_type: dict) -> list[dict[str, str]]:
    blocks: list[dict[str, str]] = []
    if agent_type.get("persona"):
        blocks.append({"label": "persona", "value": agent_type["persona"]})
    defaults = agent_type.get("memory_defaults")
    if isinstance(defaults, dict):
        for label, value in defaults.items():
            if label == "persona":
                continue
            if isinstance(value, str) and value.strip():
                blocks.append({"label": label, "value": value})
    return blocks


def resolve_agent_type(owner_id: str, slug: str) -> dict:
    agent_type = catalog.get_agent_type_by_slug(slug, owner_id)
    if agent_type is None:
        raise HTTPException(status_code=404, detail=f"Agent type '{slug}' not found")
    return agent_type


def resolve_or_create_instance(
    owner_id: str,
    agent_type: dict,
    *,
    instance_id: UUID | None = None,
    entity_id: str | None = None,
    client_id: str | None = None,
    fresh: bool = False,
) -> tuple[str, UUID | None]:
    """Returns (letta_agent_id, instance_id_or_None)."""
    agent_type_id = agent_type["id"]

    def _create_letta_agent(name_suffix: str) -> dict:
        memory_blocks = build_memory_blocks(agent_type)
        try:
            return letta.create_agent(
                project_id="",
                name=f"{agent_type.get('slug', 'agent')}-{name_suffix}",
                system=agent_type.get("system_prompt"),
                memory_blocks=memory_blocks,
                model=agent_type.get("model"),
            )
        except RuntimeError as e:
            raise http_exception_from_letta_error(e) from e

    if fresh:
        agent_data = _create_letta_agent(f"fresh-{os.urandom(4).hex()}")
        inst = catalog.create_instance(
            owner_id=owner_id,
            agent_type_id=str(agent_type_id),
            letta_agent_id=agent_data["id"],
            entity_id=entity_id or "",
            client_id=client_id,
        )
        return agent_data["id"], inst["id"]

    if instance_id:
        inst = catalog.get_instance(str(instance_id), owner_id)
        if not inst:
            raise HTTPException(status_code=404, detail="Instance not found")
        letta_id = inst["letta_agent_id"]
        if letta_get_agent_or_raise(letta_id) is None:
            raise HTTPException(status_code=404, detail="Letta agent no longer exists")
        catalog.update_instance_last_used(str(instance_id))
        return letta_id, instance_id

    default = catalog.get_default_instance(
        owner_id, str(agent_type_id), entity_id or "", client_id,
    )
    if default:
        letta_id = default["letta_agent_id"]
        if letta_get_agent_or_raise(letta_id) is not None:
            catalog.update_instance_last_used(str(default["id"]))
            return letta_id, default["id"]

    agent_data = _create_letta_agent("default")

    inst = catalog.create_instance(
        owner_id=owner_id,
        agent_type_id=str(agent_type_id),
        letta_agent_id=agent_data["id"],
        entity_id=entity_id,
        client_id=client_id,
        name=f"{agent_type.get('slug', 'agent')}-default",
        display_name=agent_type.get("name", "Agent"),
        is_default=True,
    )
    return agent_data["id"], inst["id"]


def setup_custom_tools(letta_agent_id: str, bundle: RuntimeBundle) -> list[str]:
    """Register custom tools on Letta and attach to agent."""
    tool_ids: list[str] = []
    for tool in (bundle.custom_tools or []):
        existing_id = tool.letta_tool_id
        if existing_id:
            existing = letta.get_tool(existing_id)
            if existing:
                letta.attach_tool_to_agent(letta_agent_id, existing_id)
                tool_ids.append(existing_id)
                continue

        created = letta.create_tool(
            tool.source_code,
            source_type=tool.source_type,
            name=tool.name,
            args_json_schema=tool.args_json_schema,
        )
        letta_tool_id = created["id"]
        letta.attach_tool_to_agent(letta_agent_id, letta_tool_id)
        catalog.update_custom_tool_letta_id(str(tool.custom_tool_id), letta_tool_id)
        tool_ids.append(letta_tool_id)
    return tool_ids


def setup_custom_mcp_servers(letta_agent_id: str, bundle: RuntimeBundle) -> list[str]:
    """Register MCP servers with Letta and attach tools.

    Supported transports:
      - streamable_http: default HTTP-based MCP (any remote URL)
      - sse: Server-Sent Events transport (any remote URL)
      - stdio: local subprocess (command + args)
      - composio: resolved to streamable_http at apply time
    """
    mcp_ids: list[str] = []
    for srv in (bundle.custom_mcp_servers or []):
        transport = srv.transport or srv.server_type or "streamable_http"
        logger.info("Registering MCP server %s (transport=%s)", srv.name, transport)

        if transport == "stdio" and srv.command:
            registered = letta.register_mcp_server_stdio(
                srv.name,
                command=srv.command,
                args=srv.args,
                env=srv.env,
            )
        elif srv.server_url:
            letta_transport = transport if transport in ("sse", "streamable_http") else "streamable_http"
            registered = letta.register_mcp_server(
                srv.name, srv.server_url,
                transport=letta_transport,
                auth_header=srv.auth_header,
                auth_token=srv.auth_token,
                custom_headers=srv.custom_headers,
            )
        else:
            logger.warning(
                "Skipping MCP server %s: no server_url and not stdio (transport=%s)",
                srv.name, transport,
            )
            continue

        mcp_id = registered["id"]
        mcp_ids.append(mcp_id)

        tools = letta.list_mcp_server_tools(mcp_id)
        for t in tools:
            tool_id = t.get("id") or t.get("tool_id")
            if tool_id:
                try:
                    letta.attach_tool_to_agent(letta_agent_id, tool_id)
                except Exception:
                    pass

    bundle.custom_mcp_server_ids = mcp_ids
    return mcp_ids


async def launch_local_run(
    *,
    run_id: str,
    agent_id: str,
    message: str,
    owner_id: str,
    runtime_bundle: dict,
) -> None:
    runner = get_runner()
    await runner.dispatch(run_id, agent_id, message, owner_id, runtime_bundle)


def model_to_jsonable_dict(obj: Any) -> dict:
    """Convert a Pydantic model to a JSON-serializable dict."""
    if hasattr(obj, "model_dump"):
        return json.loads(obj.model_dump_json())
    return json.loads(json.dumps(obj, default=str))
