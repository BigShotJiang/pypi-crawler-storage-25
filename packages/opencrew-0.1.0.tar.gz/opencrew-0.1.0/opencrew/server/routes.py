from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import StreamingResponse

from opencrew.types import (
    AgentTypeCreateRequest,
    AgentTypeMcpServerAttachRequest,
    AgentTypeSkillAttachRequest,
    AgentTypeToolAttachRequest,
    AgentTypeUpdateRequest,
    ApiKey,
    ClientCreateRequest,
    ClientUpdateRequest,
    ClientMemoryBlockCreateRequest,
    ClientMemoryBlockUpdateRequest,
    CustomMcpServerCreateRequest,
    CustomToolCreateRequest,
    EntityCreateRequest,
    InstanceCreateRequest,
    RunRequest,
    SkillCreateRequest,
)
from opencrew.server.deps import (
    build_memory_blocks,
    http_exception_from_letta_error,
    launch_local_run,
    model_to_jsonable_dict,
    require_api_key,
    resolve_agent_type,
    resolve_or_create_instance,
    setup_custom_mcp_servers,
    setup_custom_tools,
)
from opencrew.store import catalog, registry
from opencrew.letta import client as letta

logger = logging.getLogger(__name__)
router = APIRouter()


def _name_to_slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "unnamed"


# ---------------------------------------------------------------------------
# Agent types
# ---------------------------------------------------------------------------


@router.post("/agent-types")
async def post_agent_type(
    body: AgentTypeCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    slug = body.slug or _name_to_slug(body.name)
    return catalog.create_agent_type(
        owner_id=key.owner_id,
        name=body.name,
        slug=slug,
        description=body.description,
        persona=body.persona,
        system_prompt=body.system_prompt,
        model=body.model,
        memory_defaults=body.memory_defaults,
    )


@router.get("/agent-types")
async def list_agent_types(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    return catalog.list_agent_types(key.owner_id)


@router.get("/agent-types/{slug}")
async def get_agent_type(
    slug: str,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    return resolve_agent_type(key.owner_id, slug)


@router.patch("/agent-types/{slug}")
async def patch_agent_type(
    slug: str,
    body: AgentTypeUpdateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    updates: dict[str, Any] = {}
    for field in ("name", "slug", "description", "persona", "system_prompt", "model"):
        val = getattr(body, field, None)
        if val is not None:
            updates[field] = val
    row = catalog.update_agent_type(str(agent_type["id"]), key.owner_id, **updates)
    if row is None:
        raise HTTPException(status_code=404, detail="Agent type not found")
    return row


@router.delete("/agent-types/{slug}")
async def delete_agent_type(
    slug: str,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    deleted = catalog.delete_agent_type(str(agent_type["id"]), key.owner_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Agent type not found")
    return {"deleted": True, "slug": slug}


@router.post("/agent-types/apply")
async def apply_agent_type(
    body: dict,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    """Upsert an agent type from a dict (for YAML sync)."""
    name = body.get("name") or "Unnamed"
    slug = body.get("slug") or _name_to_slug(name)
    agent_type = catalog.create_agent_type(
        owner_id=key.owner_id,
        name=name,
        slug=slug,
        description=body.get("description"),
        persona=body.get("persona"),
        system_prompt=body.get("system_prompt"),
        model=body.get("model"),
        memory_defaults=body.get("memory_defaults"),
    )

    tools_synced = 0
    tools_spec = body.get("tools") or []
    for tool_spec in tools_spec:
        if not isinstance(tool_spec, dict):
            continue
        tool_slug = tool_spec.get("slug") or _name_to_slug(tool_spec.get("name", "tool"))
        tool = catalog.create_custom_tool(
            owner_id=key.owner_id,
            name=tool_spec.get("name", tool_slug),
            slug=tool_slug,
            source_code=tool_spec.get("source_code", ""),
            source_type=tool_spec.get("source_type", "python"),
            description=tool_spec.get("description"),
            args_json_schema=tool_spec.get("args_json_schema"),
        )
        catalog.attach_tool_to_agent_type(str(agent_type["id"]), str(tool["id"]))
        tools_synced += 1

    mcp_synced = 0
    mcp_spec = body.get("mcp_servers") or []
    for srv_spec in mcp_spec:
        if not isinstance(srv_spec, dict):
            continue
        srv_slug = srv_spec.get("slug") or _name_to_slug(srv_spec.get("name", "mcp"))
        transport = srv_spec.get("transport", "streamable_http")
        srv = catalog.create_custom_mcp_server(
            owner_id=key.owner_id,
            name=srv_spec.get("name", srv_slug),
            slug=srv_slug,
            server_url=srv_spec.get("server_url", ""),
            server_type=srv_spec.get("server_type", transport),
            transport=transport,
            auth_header=srv_spec.get("auth_header"),
            auth_token=srv_spec.get("auth_token"),
            custom_headers=srv_spec.get("custom_headers"),
            description=srv_spec.get("description"),
            command=srv_spec.get("command"),
            args=srv_spec.get("args"),
            env=srv_spec.get("env"),
            composio_app=srv_spec.get("composio_app"),
            composio_actions=srv_spec.get("composio_actions"),
        )
        catalog.attach_mcp_server_to_agent_type(str(agent_type["id"]), str(srv["id"]))
        mcp_synced += 1

    skills_synced = 0
    skills_spec = body.get("skills") or []
    for skill_spec in skills_spec:
        if not isinstance(skill_spec, dict):
            continue
        skill_slug = skill_spec.get("slug") or _name_to_slug(skill_spec.get("name", "skill"))
        skill_name = skill_spec.get("name", skill_slug)

        resolved = skill_spec.get("_resolved_files")
        if resolved and isinstance(resolved, dict):
            skill_md = resolved.get("SKILL.md", "")
            bundle_json = {k: v for k, v in resolved.items() if k != "SKILL.md"}
            description = skill_spec.get("description", "")
            if not description and skill_md:
                for line in skill_md.splitlines():
                    if line.startswith("description:"):
                        description = line.split(":", 1)[1].strip().strip("'\"")
                        break
        else:
            instructions = skill_spec.get("instructions", "")
            skill_md = f"---\nname: {skill_slug}\ndescription: {skill_spec.get('description', skill_slug)}\n---\n\n{instructions}\n"
            bundle_json = {}
            description = skill_spec.get("description", "")

        skill = catalog.create_skill(
            owner_id=key.owner_id,
            slug=skill_slug,
            name=skill_name,
            description=description,
        )
        version = catalog.create_skill_version(
            skill_id=str(skill["id"]),
            version="1",
            skill_md=skill_md,
            bundle_json=bundle_json if bundle_json else None,
        )
        catalog.attach_skill_to_agent_type(
            str(agent_type["id"]), str(skill["id"]), str(version["id"]),
        )
        skills_synced += 1

    result = dict(agent_type)
    if tools_synced:
        result["tools_synced"] = tools_synced
    if mcp_synced:
        result["mcp_servers_synced"] = mcp_synced
    if skills_synced:
        result["skills_synced"] = skills_synced
    return result


# ---------------------------------------------------------------------------
# Instances
# ---------------------------------------------------------------------------


@router.post("/agent-types/{slug}/instances")
async def post_instance(
    slug: str,
    body: InstanceCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    system = agent_type.get("system_prompt") or agent_type.get("persona") or ""
    memory_blocks = build_memory_blocks(agent_type)
    try:
        agent_data = letta.create_agent(
            project_id="",
            name=f"{slug}--{body.name}",
            system=system,
            memory_blocks=memory_blocks,
            description=body.description,
            model=agent_type.get("model"),
        )
    except RuntimeError as e:
        raise http_exception_from_letta_error(e) from e
    return catalog.create_instance(
        owner_id=key.owner_id,
        agent_type_id=str(agent_type["id"]),
        letta_agent_id=agent_data["id"],
        entity_id=key.entity_id,
        client_id=body.client_id,
        name=body.name,
        display_name=body.display_name,
        is_default=False,
    )


@router.get("/agent-types/{slug}/instances")
async def get_instances(
    slug: str,
    client_id: str | None = Query(None),
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.list_instances(
        key.owner_id,
        str(agent_type["id"]),
        entity_id=key.entity_id,
        client_id=client_id,
    )


@router.delete("/agent-types/{slug}/instances/{instance_id}")
async def delete_instance(
    slug: str,
    instance_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    instance = catalog.get_instance(str(instance_id), key.owner_id)
    if instance is None:
        raise HTTPException(status_code=404, detail="Instance not found")
    letta_agent_id = instance["letta_agent_id"]
    catalog.delete_instance(str(instance_id), key.owner_id)
    try:
        letta.delete_agent(letta_agent_id)
    except Exception:
        logger.warning("Failed to delete Letta agent %s", letta_agent_id)
    return {"deleted": True, "instance_id": str(instance_id)}


@router.get("/agent-types/{slug}/instances/{instance_id}/memory")
async def get_instance_memory(
    slug: str,
    instance_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    resolve_agent_type(key.owner_id, slug)
    instance = catalog.get_instance(str(instance_id), key.owner_id)
    if instance is None:
        raise HTTPException(status_code=404, detail="Instance not found")
    return letta.get_agent_memory(instance["letta_agent_id"])


@router.get("/agent-types/{slug}/instances/{instance_id}/messages")
async def get_instance_messages(
    slug: str,
    instance_id: UUID,
    key: ApiKey = Depends(require_api_key),
    limit: int = Query(50, ge=1, le=200),
    order: str = Query("desc"),
) -> list[dict]:
    resolve_agent_type(key.owner_id, slug)
    instance = catalog.get_instance(str(instance_id), key.owner_id)
    if instance is None:
        raise HTTPException(status_code=404, detail="Instance not found")
    return letta.get_agent_messages(instance["letta_agent_id"], limit=limit, order=order)


@router.post("/agent-types/{slug}/instances/{instance_id}/reset")
async def reset_instance(
    slug: str,
    instance_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    instance = catalog.get_instance(str(instance_id), key.owner_id)
    if instance is None:
        raise HTTPException(status_code=404, detail="Instance not found")

    try:
        letta.delete_agent(instance["letta_agent_id"])
    except Exception:
        logger.warning("Failed to delete old Letta agent %s during reset", instance["letta_agent_id"])

    system = agent_type.get("system_prompt") or agent_type.get("persona") or ""
    memory_blocks = build_memory_blocks(agent_type)
    try:
        new_agent = letta.create_agent(
            project_id="",
            name=f"{slug}--{instance.get('name') or 'reset'}",
            system=system,
            memory_blocks=memory_blocks,
            model=agent_type.get("model"),
        )
    except RuntimeError as e:
        raise http_exception_from_letta_error(e) from e

    from opencrew.store.db import get_conn
    from psycopg.rows import dict_row
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """UPDATE agent_instances
                   SET letta_agent_id = %s, last_used_at = now()
                   WHERE id = %s AND owner_id = %s
                   RETURNING *""",
                (new_agent["id"], str(instance_id), key.owner_id),
            )
            updated = cur.fetchone()
            conn.commit()
    if updated is None:
        raise HTTPException(status_code=404, detail="Instance not found after reset")
    return dict(updated)


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------


async def _prepare_and_launch_run(
    *,
    run_id: str,
    owner_id: str,
    agent_type_id: str,
    entity_id: str | None,
    client_id: str | None,
    letta_agent_id: str,
    message: str,
) -> None:
    from opencrew.types import RuntimeBundle, RuntimeCustomTool, RuntimeMcpServer, RuntimeSkill, RuntimeSkillAsset

    try:
        skill_rows = catalog.get_runtime_skill_rows(agent_type_id)
        tool_rows = catalog.get_runtime_custom_tool_rows(agent_type_id, owner_id)
        mcp_rows = catalog.get_runtime_mcp_server_rows(agent_type_id, owner_id)

        skills = []
        for sr in skill_rows:
            files = []
            if sr.get("skill_md"):
                files.append(RuntimeSkillAsset(path="SKILL.md", content=sr["skill_md"]))
            bundle_json = sr.get("bundle_json") or {}
            if isinstance(bundle_json, str):
                bundle_json = json.loads(bundle_json)
            for path, content in bundle_json.items():
                files.append(RuntimeSkillAsset(path=path, content=content))
            skills.append(RuntimeSkill(
                skill_id=sr["skill_id"],
                skill_version_id=sr["skill_version_id"],
                slug=sr["skill_slug"],
                version=sr.get("skill_version", "1"),
                files=files,
            ))

        custom_tools = [
            RuntimeCustomTool(
                custom_tool_id=tr["custom_tool_id"],
                name=tr["name"],
                slug=tr["slug"],
                source_code=tr["source_code"],
                source_type=tr.get("source_type", "python"),
                args_json_schema=tr.get("args_json_schema"),
                letta_tool_id=tr.get("letta_tool_id"),
            )
            for tr in tool_rows
        ]

        custom_mcp_servers = [
            RuntimeMcpServer(
                custom_mcp_server_id=mr["custom_mcp_server_id"],
                name=mr["name"],
                slug=mr["slug"],
                server_url=mr.get("server_url") or "",
                server_type=mr.get("server_type", "streamable_http"),
                transport=mr.get("transport", "streamable_http"),
                auth_header=mr.get("auth_header"),
                auth_token=mr.get("auth_token"),
                custom_headers=mr.get("custom_headers"),
                command=mr.get("command"),
                args=mr.get("args"),
                env=mr.get("env"),
            )
            for mr in mcp_rows
        ]

        at_row = catalog.get_agent_type(str(agent_type_id), owner_id)
        bundle_model = (at_row or {}).get("model")

        if bundle_model:
            try:
                existing = letta.get_agent(letta_agent_id)
                existing_model = existing.get("model") if existing else None
                if existing_model and existing_model != bundle_model:
                    logger.info(
                        "Model drift: Letta agent %s has %s, catalog wants %s — updating",
                        letta_agent_id, existing_model, bundle_model,
                    )
                    letta.update_agent(letta_agent_id, model=bundle_model)
            except Exception:
                logger.warning("Failed to sync model for agent %s", letta_agent_id, exc_info=True)

        bundle = RuntimeBundle(
            run_id=UUID(run_id),
            owner_id=owner_id,
            entity_id=entity_id,
            client_id=client_id,
            agent_type_id=UUID(agent_type_id),
            model=bundle_model,
            skills=skills,
            custom_tools=custom_tools,
            custom_mcp_servers=custom_mcp_servers,
        )

        setup_custom_tools(letta_agent_id, bundle)
        setup_custom_mcp_servers(letta_agent_id, bundle)

        bundle_dict = model_to_jsonable_dict(bundle)
        await launch_local_run(
            run_id=run_id,
            agent_id=letta_agent_id,
            message=message,
            owner_id=owner_id,
            runtime_bundle=bundle_dict,
        )
    except Exception as exc:
        logger.exception("Failed to launch run %s", run_id)
        registry.update_run_status(UUID(run_id), "failed", error=f"Launch failed: {exc}")


@router.post("/runs")
async def trigger_run(
    body: RunRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, body.agent_type)
    agent_type_id = agent_type["id"]

    letta_agent_id, resolved_instance_id = resolve_or_create_instance(
        key.owner_id,
        agent_type,
        instance_id=body.instance_id,
        entity_id=key.entity_id,
        client_id=body.client_id,
        fresh=body.fresh,
    )

    session_opts = body.session_options.model_dump() if body.session_options else None
    run = registry.create_run(
        owner_id=key.owner_id,
        agent_type_id=agent_type_id,
        entity_id=key.entity_id,
        client_id=body.client_id,
        agent_id=letta_agent_id,
        message=body.message,
        session_options=session_opts,
    )

    asyncio.create_task(
        _prepare_and_launch_run(
            run_id=str(run["id"]),
            owner_id=key.owner_id,
            agent_type_id=str(agent_type_id),
            entity_id=key.entity_id,
            client_id=body.client_id,
            letta_agent_id=letta_agent_id,
            message=body.message,
        )
    )

    result: dict[str, Any] = {"run_id": str(run["id"]), "status": run.get("status", "pending")}
    if resolved_instance_id:
        result["instance_id"] = str(resolved_instance_id)
    return result


@router.get("/runs")
async def list_runs(
    key: ApiKey = Depends(require_api_key),
    status: str | None = Query(None),
    agent_type: str | None = Query(None),
    client_id: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> list[dict]:
    return registry.list_runs(
        key.owner_id,
        status=status,
        agent_type_slug=agent_type,
        client_id=client_id,
        limit=limit,
        offset=offset,
    )


# Paths with static segments after ``{run_id}`` must be registered before ``/runs/{run_id}``
# or matching can fail (clients see 404 on ``…/events`` and ``…/stream``).


@router.get("/runs/{run_id}/events")
async def get_run_events_route(
    run_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> list[dict[str, Any]]:
    """Persisted stream events (assistant deltas, tools, etc.) for this run."""
    run = registry.get_run(run_id, key.owner_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run not found")
    return registry.get_run_events(run_id, after_seq=0)


@router.get("/runs/{run_id}/stream")
async def stream_run(
    run_id: UUID,
    request: Request,
    key: ApiKey = Depends(require_api_key),
):
    run = registry.get_run(run_id, key.owner_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run not found")

    last_event_id = request.headers.get("Last-Event-ID")
    after_seq = int(last_event_id) if last_event_id and last_event_id.isdigit() else 0

    async def event_generator():
        nonlocal after_seq
        yield ": connected\n\n"

        while True:
            if await request.is_disconnected():
                return

            events = registry.get_run_events(run_id, after_seq)
            for ev in events:
                after_seq = ev["seq"]
                yield f"event: {ev['event_type']}\nid: {ev['seq']}\ndata: {json.dumps(ev['payload'])}\n\n"

            current = registry.get_run(run_id)
            if current and current.get("status") in ("complete", "failed"):
                final_events = registry.get_run_events(run_id, after_seq)
                for ev in final_events:
                    after_seq = ev["seq"]
                    yield f"event: {ev['event_type']}\nid: {ev['seq']}\ndata: {json.dumps(ev['payload'])}\n\n"

                done_data: dict[str, Any] = {"status": current["status"]}
                if current.get("result"):
                    done_data["result"] = current["result"]
                if current.get("error"):
                    done_data["error"] = current["error"]
                yield f"event: done\ndata: {json.dumps(done_data)}\n\n"
                return

            await asyncio.sleep(0.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/runs/{run_id}")
async def poll_run(
    run_id: UUID,
    include_events: bool = Query(False),
    key: ApiKey = Depends(require_api_key),
) -> dict:
    run = registry.get_run(run_id, key.owner_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run not found")
    out: dict[str, Any] = dict(run)
    if include_events:
        out["events"] = registry.get_run_events(run_id, after_seq=0)
    return jsonable_encoder(out)


# ---------------------------------------------------------------------------
# Custom tools
# ---------------------------------------------------------------------------


@router.post("/custom-tools")
async def create_custom_tool(
    body: CustomToolCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    slug = body.slug or _name_to_slug(body.name)
    return catalog.create_custom_tool(
        owner_id=key.owner_id,
        name=body.name,
        slug=slug,
        source_code=body.source_code,
        source_type=body.source_type,
        description=body.description,
        args_json_schema=body.args_json_schema,
        tags=body.tags,
    )


@router.get("/custom-tools")
async def list_custom_tools(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    return catalog.list_custom_tools(key.owner_id)


@router.get("/custom-tools/{tool_id}")
async def get_custom_tool(
    tool_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    tool = catalog.get_custom_tool(str(tool_id), key.owner_id)
    if tool is None:
        raise HTTPException(status_code=404, detail="Custom tool not found")
    return tool


@router.delete("/custom-tools/{tool_id}")
async def delete_custom_tool(
    tool_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    deleted = catalog.delete_custom_tool(str(tool_id), key.owner_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Custom tool not found")
    return {"deleted": True}


@router.post("/agent-types/{slug}/tools")
async def attach_tool(
    slug: str,
    body: AgentTypeToolAttachRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.attach_tool_to_agent_type(
        str(agent_type["id"]), str(body.custom_tool_id),
    )


@router.get("/agent-types/{slug}/tools")
async def list_agent_type_tools(
    slug: str,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.list_agent_type_tools(str(agent_type["id"]))


@router.delete("/agent-types/{slug}/tools/{tool_id}")
async def detach_tool(
    slug: str,
    tool_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    removed = catalog.detach_tool_from_agent_type(str(agent_type["id"]), str(tool_id))
    if not removed:
        raise HTTPException(status_code=404, detail="Tool not attached to this agent type")
    return {"detached": True}


# ---------------------------------------------------------------------------
# Custom MCP servers
# ---------------------------------------------------------------------------


@router.post("/mcp-servers")
async def create_mcp_server(
    body: CustomMcpServerCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    slug = body.slug or _name_to_slug(body.name)
    return catalog.create_custom_mcp_server(
        owner_id=key.owner_id,
        name=body.name,
        slug=slug,
        server_url=body.server_url,
        server_type=body.server_type,
        transport=body.transport,
        auth_header=body.auth_header,
        auth_token=body.auth_token,
        custom_headers=body.custom_headers,
        description=body.description,
        command=body.command,
        args=body.args,
        env=body.env,
        composio_app=body.composio_app,
        composio_actions=body.composio_actions,
    )


@router.get("/mcp-servers")
async def list_mcp_servers(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    return catalog.list_custom_mcp_servers(key.owner_id)


@router.get("/mcp-servers/{server_id}")
async def get_mcp_server(
    server_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    server = catalog.get_custom_mcp_server(str(server_id), key.owner_id)
    if server is None:
        raise HTTPException(status_code=404, detail="MCP server not found")
    return server


@router.delete("/mcp-servers/{server_id}")
async def delete_mcp_server(
    server_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    deleted = catalog.delete_custom_mcp_server(str(server_id), key.owner_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="MCP server not found")
    return {"deleted": True}


@router.post("/agent-types/{slug}/mcp-servers")
async def attach_mcp_server(
    slug: str,
    body: AgentTypeMcpServerAttachRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.attach_mcp_server_to_agent_type(
        str(agent_type["id"]), str(body.custom_mcp_server_id),
    )


@router.get("/agent-types/{slug}/mcp-servers")
async def list_agent_type_mcp_servers(
    slug: str,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.list_agent_type_mcp_servers(str(agent_type["id"]))


@router.delete("/agent-types/{slug}/mcp-servers/{server_id}")
async def detach_mcp_server(
    slug: str,
    server_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    removed = catalog.detach_mcp_server_from_agent_type(
        str(agent_type["id"]), str(server_id),
    )
    if not removed:
        raise HTTPException(status_code=404, detail="MCP server not attached to this agent type")
    return {"detached": True}


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------


@router.post("/skills")
async def create_skill(
    body: SkillCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    skill = catalog.create_skill(
        owner_id=key.owner_id,
        slug=body.slug,
        name=body.name,
        description=body.description,
    )
    version = catalog.create_skill_version(
        skill_id=str(skill["id"]),
        version="1",
        skill_md=f"---\nname: {body.slug}\ndescription: {body.description}\n---\n\n{body.instructions}\n",
    )
    return {"skill": skill, "version": version}


@router.get("/skills")
async def list_skills(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    return catalog.list_skills(key.owner_id)


@router.post("/agent-types/{slug}/skills")
async def attach_skill(
    slug: str,
    body: AgentTypeSkillAttachRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.attach_skill_to_agent_type(
        str(agent_type["id"]),
        str(body.skill_id),
        str(body.skill_version_id),
    )


@router.get("/agent-types/{slug}/skills")
async def list_agent_type_skills(
    slug: str,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    agent_type = resolve_agent_type(key.owner_id, slug)
    return catalog.list_agent_type_skills(str(agent_type["id"]))


# ---------------------------------------------------------------------------
# Clients
# ---------------------------------------------------------------------------


@router.post("/clients")
async def create_client(
    body: ClientCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    entity_id = key.entity_id
    if not entity_id:
        raise HTTPException(status_code=403, detail="Entity-scoped API key required")
    slug = body.slug or _name_to_slug(body.name)
    return catalog.create_client(
        owner_id=key.owner_id,
        entity_id=entity_id,
        name=body.name,
        slug=slug,
        metadata=body.metadata,
    )


@router.get("/clients")
async def list_clients(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    entity_id = key.entity_id
    if not entity_id:
        raise HTTPException(status_code=403, detail="Entity-scoped API key required")
    return catalog.list_clients(key.owner_id, entity_id)


@router.patch("/clients/{client_id}")
async def update_client(
    client_id: str,
    body: ClientUpdateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    entity_id = key.entity_id
    if not entity_id:
        raise HTTPException(status_code=403, detail="Entity-scoped API key required")
    row = catalog.update_client(
        client_id,
        key.owner_id,
        entity_id,
        name=body.name,
        slug=body.slug,
        metadata=body.metadata,
    )
    if row is None:
        raise HTTPException(status_code=404, detail="Client not found")
    return row


@router.delete("/clients/{client_id}")
async def archive_client(
    client_id: str,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    entity_id = key.entity_id
    if not entity_id:
        raise HTTPException(status_code=403, detail="Entity-scoped API key required")
    archived = catalog.archive_client(client_id, key.owner_id, entity_id)
    if not archived:
        raise HTTPException(status_code=404, detail="Client not found")
    return {"deleted": True, "client_id": client_id}


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


@router.post("/entities")
async def create_entity(
    body: EntityCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    slug = body.slug or _name_to_slug(body.name)
    return catalog.create_entity(
        owner_id=key.owner_id,
        name=body.name,
        slug=slug,
        metadata=body.metadata,
    )


@router.get("/entities")
async def list_entities(key: ApiKey = Depends(require_api_key)) -> list[dict]:
    return catalog.list_entities(key.owner_id)


# ---------------------------------------------------------------------------
# Client memory
# ---------------------------------------------------------------------------


@router.post("/clients/{client_id}/memory")
async def create_client_memory_block(
    client_id: str,
    body: ClientMemoryBlockCreateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    block = letta.create_block(
        body.label,
        body.value,
        tags=["client-memory", f"client:{client_id}"],
        description=body.description,
    )
    return block


@router.get("/clients/{client_id}/memory")
async def list_client_memory_blocks(
    client_id: str,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    return letta.list_blocks(
        tags=[f"client:{client_id}"],
    )


@router.patch("/clients/{client_id}/memory/{block_id}")
async def update_client_memory_block(
    client_id: str,
    block_id: str,
    body: ClientMemoryBlockUpdateRequest,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    block = letta.get_block(block_id)
    if block is None:
        raise HTTPException(status_code=404, detail="Block not found")
    return letta.update_block(
        block_id,
        value=body.value,
        label=body.label,
        description=body.description,
    )


@router.delete("/clients/{client_id}/memory/{block_id}")
async def delete_client_memory_block(
    client_id: str,
    block_id: str,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agents = letta.list_block_agents(block_id)
    for agent in agents:
        try:
            letta.detach_block_from_agent(agent["id"], block_id)
        except Exception:
            logger.warning("Failed to detach block %s from agent %s", block_id, agent["id"])

    deleted = letta.delete_block(block_id)
    if not deleted:
        raise HTTPException(status_code=500, detail="Failed to delete block")
    return {"deleted": True, "block_id": block_id, "detached_from": len(agents)}


# ---------------------------------------------------------------------------
# Logs
# ---------------------------------------------------------------------------


@router.get("/logs")
async def get_logs(
    key: ApiKey = Depends(require_api_key),
    status: str | None = Query(None),
    agent_type: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> list[dict]:
    return registry.list_runs(
        key.owner_id,
        status=status,
        agent_type_slug=agent_type,
        limit=limit,
        offset=offset,
    )


@router.get("/logs/summary/usage")
async def usage_summary(key: ApiKey = Depends(require_api_key)) -> dict:
    from opencrew.store.db import get_conn
    from psycopg.rows import dict_row
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT
                    count(*)::int AS total_runs,
                    coalesce(sum((result->>'total_tokens')::int), 0)::int AS total_tokens,
                    coalesce(sum((result->>'input_tokens')::int), 0)::int AS input_tokens,
                    coalesce(sum((result->>'output_tokens')::int), 0)::int AS output_tokens,
                    coalesce(avg(
                        EXTRACT(EPOCH FROM (completed_at - started_at))
                    ), 0)::float AS avg_duration_seconds
                FROM runs
                WHERE owner_id = %s
                  AND status = 'complete'
                  AND result IS NOT NULL
                """,
                (key.owner_id,),
            )
            row = cur.fetchone()
    return dict(row) if row else {
        "total_runs": 0,
        "total_tokens": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "avg_duration_seconds": 0.0,
    }


@router.get("/logs/{run_id}")
async def get_run_logs(
    run_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    run = registry.get_run(run_id, key.owner_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run not found")
    from opencrew.store.db import get_conn
    from psycopg.rows import dict_row
    with get_conn() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "SELECT * FROM run_logs WHERE run_id = %s ORDER BY created_at",
                (str(run_id),),
            )
            rows = cur.fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Chats
# ---------------------------------------------------------------------------


@router.post("/chats")
async def create_chat(
    body: dict,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    agent_type_slug = body.get("agent_type")
    if not agent_type_slug:
        raise HTTPException(status_code=422, detail="agent_type is required")
    resolve_agent_type(key.owner_id, agent_type_slug)
    title = body.get("title")
    chat = registry.create_chat(key.owner_id, agent_type_slug, title=title)
    return jsonable_encoder(chat)


@router.get("/chats")
async def list_chats(
    agent_type: str | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    rows = registry.list_chats(key.owner_id, agent_type_slug=agent_type, limit=limit)
    return jsonable_encoder(rows)


@router.get("/chats/{chat_id}")
async def get_chat(
    chat_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    chat = registry.get_chat(str(chat_id), key.owner_id)
    if chat is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    return jsonable_encoder(chat)


@router.get("/chats/{chat_id}/messages")
async def get_chat_messages(
    chat_id: UUID,
    limit: int = Query(100, ge=1, le=500),
    key: ApiKey = Depends(require_api_key),
) -> list[dict]:
    chat = registry.get_chat(str(chat_id), key.owner_id)
    if chat is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    msgs = registry.get_chat_messages(str(chat_id), limit=limit)
    return jsonable_encoder(msgs)


@router.post("/chats/{chat_id}/messages")
async def add_chat_message(
    chat_id: UUID,
    body: dict,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    chat = registry.get_chat(str(chat_id), key.owner_id)
    if chat is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    role = body.get("role")
    content = body.get("content")
    if not role or not content:
        raise HTTPException(status_code=422, detail="role and content are required")
    run_id = body.get("run_id")
    msg = registry.add_chat_message(str(chat_id), role, content, run_id=run_id)
    return jsonable_encoder(msg)


@router.delete("/chats/{chat_id}")
async def delete_chat(
    chat_id: UUID,
    key: ApiKey = Depends(require_api_key),
) -> dict:
    deleted = registry.delete_chat(str(chat_id), key.owner_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Chat not found")
    return {"deleted": True}
