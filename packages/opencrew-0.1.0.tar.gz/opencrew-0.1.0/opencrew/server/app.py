from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from psycopg_pool import PoolTimeout

from opencrew.store.db import reset_pool

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Pool retries while Postgres is down flood stderr; keep them at WARNING+.
    logging.getLogger("psycopg_pool").setLevel(logging.WARNING)
    logging.getLogger("psycopg").setLevel(logging.WARNING)
    logger.info("OpenCrew server starting")
    yield
    reset_pool()
    logger.info("OpenCrew server stopped")


app = FastAPI(
    title="OpenCrew",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:*", "http://127.0.0.1:*"],
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    """Liveness + database connectivity. Returns 503 when Postgres is unreachable so preflight fails loudly."""
    from opencrew.store.db import get_conn, reset_pool

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
        return {"status": "ok"}
    except Exception as e:
        reset_pool()
        return JSONResponse(
            status_code=503,
            content={
                "status": "error",
                "detail": str(e),
                "hint": "Local API needs Postgres (OpenCrew Docker stack). Run: opencrew start",
            },
        )


from opencrew.server.routes import router  # noqa: E402

app.include_router(router, prefix="/v1")


@app.exception_handler(PoolTimeout)
async def _pool_timeout_handler(request, exc: PoolTimeout):
    """Return 503 instead of 500 + traceback when Postgres is down or the pool is starved."""
    reset_pool()
    return JSONResponse(
        status_code=503,
        content={
            "detail": "Database unavailable (connection pool timeout).",
            "hint": "Start Postgres: opencrew start — then retry.",
        },
    )
