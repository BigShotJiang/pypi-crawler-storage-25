from __future__ import annotations

import os
import time
from json import JSONDecodeError
from typing import Any
from urllib.parse import urlparse

import httpx

_TIMEOUT = 30.0


def _base_url() -> str:
    url = os.environ.get("LETTA_BASE_URL", "http://localhost:8283").rstrip("/")
    if not url.endswith("/v1"):
        url += "/v1"
    return url


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    token = os.environ.get("LETTA_API_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _raise_for_status(resp: httpx.Response) -> None:
    if resp.status_code >= 400:
        body = (resp.text or "").strip()
        if len(body) > 4000:
            body = body[:4000] + "…"
        raise RuntimeError(f"Letta API error {resp.status_code}: {body}")


def _json_or_none(resp: httpx.Response) -> Any | None:
    content = (resp.text or "").strip()
    if not content:
        return None
    try:
        return resp.json()
    except JSONDecodeError:
        return None


def _resource_id_from_location(location: str | None) -> str | None:
    if not location:
        return None
    path = urlparse(location).path.strip("/")
    if not path:
        return None
    return path.split("/")[-1] or None


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------

def create_project(name: str) -> dict[str, Any]:
    resp = httpx.post(
        f"{_base_url()}/projects/",
        headers=_headers(),
        json={"name": name},
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def list_projects() -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/projects/",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    if isinstance(data, dict) and "projects" in data:
        return data["projects"]
    if isinstance(data, list):
        return data
    return []


def delete_project(project_id: str) -> bool:
    resp = httpx.delete(
        f"{_base_url()}/projects/{project_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    return resp.status_code < 400


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def create_agent(
    *,
    project_id: str,
    name: str,
    system: str | None = None,
    memory_blocks: list[dict[str, str]] | None = None,
    model: str | None = None,
    description: str | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"name": name}
    if project_id:
        body["project_id"] = project_id
    if system:
        body["system"] = system
    if memory_blocks:
        body["memory_blocks"] = memory_blocks
    if model:
        body["model"] = model
    if description:
        body["description"] = description

    resp = httpx.post(
        f"{_base_url()}/agents/",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    if resp.status_code not in (200, 201):
        _raise_for_status(resp)
    return resp.json()


def list_agents(project_id: str | None = None) -> list[dict[str, Any]]:
    params: dict[str, str] = {}
    if project_id:
        params["project_id"] = project_id
    resp = httpx.get(
        f"{_base_url()}/agents/",
        headers=_headers(),
        params=params,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "agents" in data:
        return data["agents"]
    return []


def get_agent(agent_id: str) -> dict[str, Any] | None:
    resp = httpx.get(
        f"{_base_url()}/agents/{agent_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    _raise_for_status(resp)
    return resp.json()


def update_agent(agent_id: str, **kwargs: Any) -> dict[str, Any] | None:
    body: dict[str, Any] = {}
    for key in ("model", "system", "name", "description"):
        if key in kwargs and kwargs[key] is not None:
            body[key] = kwargs[key]
    if not body:
        return get_agent(agent_id)
    resp = httpx.patch(
        f"{_base_url()}/agents/{agent_id}",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    _raise_for_status(resp)
    return resp.json()


def delete_agent(agent_id: str) -> bool:
    resp = httpx.delete(
        f"{_base_url()}/agents/{agent_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    return resp.status_code < 400


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------

def _register_mcp(server_name: str, config: dict[str, Any], match_fn) -> dict[str, Any]:
    """Low-level MCP registration with fallback recovery."""
    resp = httpx.post(
        f"{_base_url()}/mcp-servers/",
        headers=_headers(),
        json={"server_name": server_name, "config": config},
        timeout=_TIMEOUT,
    )
    if resp.status_code == 409:
        for server in list_mcp_servers():
            if server.get("server_name") == server_name and server.get("id"):
                return server
    _raise_for_status(resp)
    data = _json_or_none(resp)
    if isinstance(data, dict) and data.get("id"):
        return data
    server_id = (
        _resource_id_from_location(resp.headers.get("location"))
        or resp.headers.get("x-resource-id")
        or resp.headers.get("x-mcp-server-id")
    )
    if server_id:
        recovered = get_mcp_server(server_id)
        if recovered is not None:
            return recovered

    for attempt in range(5):
        for server in list_mcp_servers():
            if server.get("server_name") != server_name:
                continue
            if match_fn(server) and server.get("id"):
                return server
        if attempt < 4:
            time.sleep(0.5 * (attempt + 1))

    raise RuntimeError(
        f"Letta MCP registration succeeded but could not recover server for server_name={server_name}"
    )


def register_mcp_server(
    server_name: str,
    server_url: str,
    *,
    transport: str = "streamable_http",
    auth_header: str | None = None,
    auth_token: str | None = None,
    custom_headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    config: dict[str, Any] = {
        "mcp_server_type": transport if transport in ("sse", "streamable_http") else "streamable_http",
        "server_url": server_url,
    }
    if auth_header:
        config["auth_header"] = auth_header
    if auth_token:
        config["auth_token"] = auth_token
    if custom_headers:
        config["custom_headers"] = custom_headers

    def _match(server: dict) -> bool:
        sc = server.get("config") if isinstance(server.get("config"), dict) else {}
        return (server.get("server_url") or sc.get("server_url")) == server_url

    return _register_mcp(server_name, config, _match)


def register_mcp_server_stdio(
    server_name: str,
    *,
    command: str,
    args: list[str] | None = None,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    config: dict[str, Any] = {
        "mcp_server_type": "stdio",
        "command": command,
    }
    if args:
        config["args"] = args
    if env:
        config["env"] = env

    def _match(server: dict) -> bool:
        sc = server.get("config") if isinstance(server.get("config"), dict) else {}
        return sc.get("command") == command

    return _register_mcp(server_name, config, _match)


def list_mcp_servers() -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/mcp-servers/",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = _json_or_none(resp)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("mcp_servers", "servers", "items"):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def get_mcp_server(server_id: str) -> dict[str, Any] | None:
    resp = httpx.get(
        f"{_base_url()}/mcp-servers/{server_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    _raise_for_status(resp)
    data = _json_or_none(resp)
    return data if isinstance(data, dict) else None


def list_mcp_server_tools(server_id: str) -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/mcp-servers/{server_id}/tools",
        headers=_headers(),
        timeout=60.0,
    )
    _raise_for_status(resp)
    data = resp.json()
    return data if isinstance(data, list) else []


def delete_mcp_server(server_id: str) -> bool:
    resp = httpx.delete(
        f"{_base_url()}/mcp-servers/{server_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    return resp.status_code < 400


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def create_tool(
    source_code: str,
    *,
    source_type: str = "python",
    name: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
    json_schema: dict[str, Any] | None = None,
    args_json_schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"source_code": source_code}
    if source_type:
        body["source_type"] = source_type
    if tags:
        body["tags"] = tags
    if json_schema:
        body["json_schema"] = json_schema
    if args_json_schema:
        body["args_json_schema"] = args_json_schema
    resp = httpx.post(
        f"{_base_url()}/tools/",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def get_tool(tool_id: str) -> dict[str, Any] | None:
    resp = httpx.get(
        f"{_base_url()}/tools/{tool_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    _raise_for_status(resp)
    return resp.json()


def patch_tool(
    tool_id: str,
    *,
    json_schema: dict[str, Any] | None = None,
    args_json_schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Update tool schemas on the Letta server."""
    body: dict[str, Any] = {}
    if json_schema is not None:
        body["json_schema"] = json_schema
    if args_json_schema is not None:
        body["args_json_schema"] = args_json_schema
    if not body:
        raise ValueError("patch_tool requires json_schema and/or args_json_schema")
    resp = httpx.patch(
        f"{_base_url()}/tools/{tool_id}",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def list_tools(*, project_id: str | None = None) -> list[dict[str, Any]]:
    params: dict[str, Any] = {}
    if project_id:
        params["project_id"] = project_id
    resp = httpx.get(
        f"{_base_url()}/tools/",
        headers=_headers(),
        params=params,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    return data if isinstance(data, list) else []


def delete_tool(tool_id: str) -> bool:
    resp = httpx.delete(
        f"{_base_url()}/tools/{tool_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    return resp.status_code < 400


# ---------------------------------------------------------------------------
# Agent tools
# ---------------------------------------------------------------------------

def attach_tool_to_agent(agent_id: str, tool_id: str) -> dict[str, Any]:
    resp = httpx.patch(
        f"{_base_url()}/agents/{agent_id}/tools/attach/{tool_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def list_agent_tools(agent_id: str) -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/agents/{agent_id}/tools",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    return data if isinstance(data, list) else []


# ---------------------------------------------------------------------------
# Standalone blocks
# ---------------------------------------------------------------------------

def list_blocks(
    *,
    project_id: str | None = None,
    tags: list[str] | None = None,
    label: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    params: dict[str, Any] = {"limit": limit}
    if project_id:
        params["project_id"] = project_id
    if tags:
        params["tags"] = tags
    if label:
        params["label"] = label
    resp = httpx.get(
        f"{_base_url()}/blocks/",
        headers=_headers(),
        params=params,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    data = resp.json()
    return data if isinstance(data, list) else []


def create_block(
    label: str,
    value: str,
    *,
    project_id: str | None = None,
    tags: list[str] | None = None,
    description: str | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"label": label, "value": value}
    if project_id:
        body["project_id"] = project_id
    if tags:
        body["tags"] = tags
    if description:
        body["description"] = description
    resp = httpx.post(
        f"{_base_url()}/blocks/",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def get_block(block_id: str) -> dict[str, Any] | None:
    resp = httpx.get(
        f"{_base_url()}/blocks/{block_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    _raise_for_status(resp)
    return resp.json()


def update_block(
    block_id: str,
    *,
    value: str | None = None,
    label: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {}
    if value is not None:
        body["value"] = value
    if label is not None:
        body["label"] = label
    if description is not None:
        body["description"] = description
    if tags is not None:
        body["tags"] = tags
    resp = httpx.patch(
        f"{_base_url()}/blocks/{block_id}",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def delete_block(block_id: str) -> bool:
    resp = httpx.delete(
        f"{_base_url()}/blocks/{block_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    return resp.status_code < 400


def list_block_agents(block_id: str) -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/blocks/{block_id}/agents",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return []
    _raise_for_status(resp)
    data = resp.json()
    return data if isinstance(data, list) else []


def attach_block_to_agent(agent_id: str, block_id: str) -> dict[str, Any]:
    resp = httpx.patch(
        f"{_base_url()}/agents/{agent_id}/core-memory/blocks/attach/{block_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


def detach_block_from_agent(agent_id: str, block_id: str) -> dict[str, Any]:
    resp = httpx.patch(
        f"{_base_url()}/agents/{agent_id}/core-memory/blocks/detach/{block_id}",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


# ---------------------------------------------------------------------------
# Agent memory
# ---------------------------------------------------------------------------

def get_agent_memory(agent_id: str) -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/agents/{agent_id}/core-memory/blocks",
        headers=_headers(),
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return []
    _raise_for_status(resp)
    data = resp.json()
    if isinstance(data, list):
        return data
    return []


def update_agent_memory_block(
    agent_id: str,
    block_id: str,
    *,
    value: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {}
    if value is not None:
        body["value"] = value
    if limit is not None:
        body["limit"] = limit
    resp = httpx.patch(
        f"{_base_url()}/agents/{agent_id}/core-memory/blocks/{block_id}",
        headers=_headers(),
        json=body,
        timeout=_TIMEOUT,
    )
    _raise_for_status(resp)
    return resp.json()


# ---------------------------------------------------------------------------
# Agent messages
# ---------------------------------------------------------------------------

def get_agent_messages(
    agent_id: str,
    *,
    limit: int = 50,
    order: str = "desc",
) -> list[dict[str, Any]]:
    resp = httpx.get(
        f"{_base_url()}/agents/{agent_id}/messages",
        headers=_headers(),
        params={"limit": limit, "order": order},
        timeout=_TIMEOUT,
    )
    if resp.status_code == 404:
        return []
    _raise_for_status(resp)
    data = resp.json()
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "messages" in data:
        return data["messages"]
    return []
