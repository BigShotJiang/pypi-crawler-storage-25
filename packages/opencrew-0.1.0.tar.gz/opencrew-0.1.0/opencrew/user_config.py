"""~/.opencrew/config.yaml — structured local vs remote settings (no Rich / CLI deps)."""
from __future__ import annotations

from typing import Any

LOCAL_SECTION = "local"
REMOTE_SECTION = "remote"

# Keys that belong under ``local:`` (flat legacy names).
_LOCAL_KEYS = frozenset(
    {
        "db_url",
        "letta_url",
        "api_url",
        "api_key",
        "anthropic_api_key",
        "openai_api_key",
    }
)


def normalize_config(raw: dict[str, Any] | None) -> dict[str, Any]:
    """Return config with ``local`` and ``remote`` dicts; migrate legacy flat keys into ``local``."""
    if raw is None:
        raw = {}
    has_nested = LOCAL_SECTION in raw or REMOTE_SECTION in raw
    local: dict[str, Any] = dict(raw.get(LOCAL_SECTION) or {})
    remote: dict[str, Any] = dict(raw.get(REMOTE_SECTION) or {})

    if not has_nested:
        for k in _LOCAL_KEYS:
            if k in raw and raw[k] is not None:
                local[k] = raw[k]
    else:
        for k in _LOCAL_KEYS:
            if k in raw and k not in ("local", "remote") and raw[k] is not None:
                local.setdefault(k, raw[k])

    meta: dict[str, Any] = {}
    for k, v in raw.items():
        if k in (LOCAL_SECTION, REMOTE_SECTION):
            continue
        if k in _LOCAL_KEYS:
            continue
        meta[k] = v

    return {**meta, LOCAL_SECTION: local, REMOTE_SECTION: remote}


def get_local(config: dict[str, Any] | None) -> dict[str, Any]:
    return dict(normalize_config(config).get(LOCAL_SECTION) or {})


def get_remote(config: dict[str, Any] | None) -> dict[str, Any]:
    return dict(normalize_config(config).get(REMOTE_SECTION) or {})


def has_local_stack(config: dict[str, Any] | None) -> bool:
    return bool(get_local(config).get("db_url"))


def is_remote_configured(config: dict[str, Any] | None) -> bool:
    rem = get_remote(config)
    return bool(rem.get("api_url") and rem.get("api_key"))


def api_client_url_and_key(config: dict[str, Any] | None) -> tuple[str, str | None]:
    """HTTP API base URL + key for SDK/CLI calls.

    If ``remote`` has both ``api_url`` and ``api_key``, use remote (OpenCrew Cloud / hosted API).
    Otherwise use ``local`` (default http://localhost:8741).
    """
    n = normalize_config(config)
    rem = n.get(REMOTE_SECTION) or {}
    if rem.get("api_url") and rem.get("api_key"):
        return str(rem["api_url"]).rstrip("/"), str(rem["api_key"])
    loc = n.get(LOCAL_SECTION) or {}
    return str(loc.get("api_url") or "http://localhost:8741").rstrip("/"), loc.get("api_key")


API_TARGET_AUTO = "auto"
API_TARGET_LOCAL = "local"
API_TARGET_CLOUD = "cloud"
API_TARGET_DAYTONA = "daytona"

_DAYTONA_SECTION = "daytona"


def api_client_url_and_key_for_target(
    config: dict[str, Any] | None,
    target: str,
) -> tuple[str, str | None]:
    """Resolve API URL + key for ``local``, ``cloud``, ``daytona``, or ``auto``."""
    if target == API_TARGET_AUTO:
        return api_client_url_and_key(config)
    n = normalize_config(config)
    loc = n.get(LOCAL_SECTION) or {}
    rem = n.get(REMOTE_SECTION) or {}
    if target == API_TARGET_CLOUD:
        url, key = rem.get("api_url"), rem.get("api_key")
        if not url or not key:
            raise ValueError(
                "Cloud API not configured: set remote.api_url and remote.api_key in ~/.opencrew/config.yaml "
                "(run: opencrew init --cloud)"
            )
        return str(url).rstrip("/"), str(key)
    if target == API_TARGET_LOCAL:
        url = loc.get("api_url") or "http://localhost:8741"
        return str(url).rstrip("/"), loc.get("api_key")
    if target == API_TARGET_DAYTONA:
        daytona_cfg = n.get(_DAYTONA_SECTION) or {}
        url = daytona_cfg.get("api_url")
        key = daytona_cfg.get("api_key")
        if not url:
            raise ValueError(
                "Daytona target not configured: set daytona.api_url in ~/.opencrew/config.yaml\n"
                "  Example:\n"
                "    daytona:\n"
                "      api_url: http://localhost:8741\n"
                "      api_key: <your-api-key>"
            )
        return str(url).rstrip("/"), str(key) if key else None
    raise ValueError(f"Unknown API target {target!r} (use auto, local, cloud, or daytona)")


def local_db_url(config: dict[str, Any] | None) -> str | None:
    url = get_local(config).get("db_url")
    return str(url) if url else None


def local_letta_url(config: dict[str, Any] | None) -> str | None:
    url = get_local(config).get("letta_url")
    return str(url) if url else None
