"""OpenCrew — Run persistent memory agents locally. Deploy in one command."""

from opencrew.sdk.client import OpenCrew
from opencrew.sdk.async_client import AsyncOpenCrew

__version__ = "0.1.0"
__all__ = ["OpenCrew", "AsyncOpenCrew"]
