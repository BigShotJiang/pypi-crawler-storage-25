from __future__ import annotations

from typing import Protocol


class RunnerBackend(Protocol):
    async def dispatch(
        self,
        run_id: str,
        agent_id: str,
        message: str,
        owner_id: str,
        runtime_bundle: dict,
    ) -> None:
        """Dispatch a run for execution. Fire-and-forget — results are written to DB."""
        ...
