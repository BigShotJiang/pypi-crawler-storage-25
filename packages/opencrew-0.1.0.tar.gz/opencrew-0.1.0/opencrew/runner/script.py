from __future__ import annotations

import json
import textwrap


def _build_credential_env_lines(credential_tokens: dict[str, str] | None) -> str:
    """Build JS lines that inject per-user credentials into process.env."""
    if not credential_tokens:
        return ""
    lines: list[str] = []
    for env_name, value in credential_tokens.items():
        if value:
            lines.append(f"process.env[{json.dumps(env_name)}] = {json.dumps(value)};")

    gh_token = credential_tokens.get("GITHUB_TOKEN") or credential_tokens.get("GH_TOKEN")
    if gh_token:
        import shlex
        safe_url = f"https://x-access-token:{gh_token}@github.com/"
        lines.append(
            "require('child_process').execSync("
            f"'git config --global url.{shlex.quote(safe_url)}.insteadOf https://github.com/'"
            ");"
        )
    return "\n        ".join(lines)


def generate_script(
    agent_id: str,
    message: str,
    *,
    letta_base_url: str,
    letta_api_token: str,
    session_mode: str = "resume",
    model: str | None = None,
    disallowed_tools: list[str] | None = None,
    allowed_tools: list[str] | None = None,
    skill_sources: list[str] | None = None,
    cwd: str | None = None,
    credential_tokens: dict[str, str] | None = None,
) -> str:
    """Generate the TypeScript source that runs a Letta Code SDK session.

    Returns the full script as a string, ready to be written to a .ts file
    and executed with ``npx tsx``.
    """
    if disallowed_tools is None:
        disallowed_tools = ["AskUserQuestion", "EnterPlanMode", "ExitPlanMode"]
    if skill_sources is None:
        skill_sources = ["project"]

    session_fn = "createSession" if session_mode == "create" else "resumeSession"

    model_line = f"model: {json.dumps(model)}," if model else ""
    disallowed_js = json.dumps(disallowed_tools)
    allowed_js = json.dumps(allowed_tools) if allowed_tools else "undefined"
    skill_sources_js = json.dumps(skill_sources)
    cwd_js = json.dumps(cwd) if cwd else "undefined"
    escaped_message = json.dumps(message)
    env_credentials = _build_credential_env_lines(credential_tokens)

    script = textwrap.dedent(f"""\
        import {{ {session_fn}, extractStreamTextDelta }} from "@letta-ai/letta-code-sdk";
        import {{ writeSync }} from "fs";

        process.env.LETTA_BASE_URL = {json.dumps(letta_base_url)};
        process.env.LETTA_API_KEY = {json.dumps(letta_api_token)};
        process.env.LETTA_API_TOKEN = {json.dumps(letta_api_token)};
        {env_credentials}

        /** Line-delimited JSON for the parent process: piped stdout is block-buffered unless we sync-write. */
        function emit(obj: Record<string, unknown>) {{
            writeSync(1, Buffer.from(JSON.stringify(obj) + "\\n", "utf8"));
        }}

        function turnResultToText(r: unknown): string | null {{
            if (r == null) return null;
            if (typeof r === "string") {{
                const t = r.trim();
                return t.length > 0 ? t : null;
            }}
            if (Array.isArray(r)) {{
                const parts: string[] = [];
                for (const x of r) {{
                    if (typeof x === "string") parts.push(x);
                    else if (x && typeof x === "object" && typeof (x as any).text === "string")
                        parts.push((x as any).text);
                }}
                const j = parts.join("").trim();
                return j.length > 0 ? j : null;
            }}
            if (typeof r === "object") {{
                const o = r as Record<string, unknown>;
                if (typeof o.text === "string" && o.text.trim()) return o.text.trim();
                if (typeof o.content === "string" && o.content.trim()) return o.content.trim();
            }}
            return null;
        }}

        function assistantTextFromContent(content: unknown): string {{
            if (typeof content === "string") return content;
            if (Array.isArray(content)) {{
                let s = "";
                for (const part of content) {{
                    if (typeof part === "string") s += part;
                    else if (part && typeof part === "object") {{
                        const p = part as Record<string, unknown>;
                        if (typeof p.text === "string") s += p.text;
                        else if (typeof p.content === "string") s += p.content;
                    }}
                }}
                return s;
            }}
            if (content && typeof content === "object") {{
                const o = content as Record<string, unknown>;
                if (typeof o.text === "string") return o.text;
                if (typeof o.content === "string") return o.content;
                // Gemini / GenAI: nested parts on content object
                if (Array.isArray(o.parts)) {{
                    const nested = assistantTextFromContent(o.parts);
                    if (nested) return nested;
                }}
            }}
            return "";
        }}

        /** ``extractStreamTextDelta`` only reads ``delta.text`` / ``delta.reasoning``; Gemini often uses ``delta.content``. */
        function assistantDeltaFromRecord(delta: Record<string, unknown>): {{ kind: "assistant"; text: string }} | null {{
            if (typeof delta.text === "string" && delta.text.length > 0)
                return {{ kind: "assistant", text: delta.text }};
            const c = delta.content;
            if (typeof c === "string" && c.length > 0)
                return {{ kind: "assistant", text: c }};
            const fromStructured = assistantTextFromContent(c);
            if (fromStructured) return {{ kind: "assistant", text: fromStructured }};
            return null;
        }}

        /** ``extractStreamTextDelta`` misses some headless shapes (e.g. ``content_block`` updates). */
        function streamDeltaFallback(ev: Record<string, unknown>) {{
            const d = ev.delta;
            if (d && typeof d === "object") {{
                const ad = assistantDeltaFromRecord(d as Record<string, unknown>);
                if (ad) return ad;
            }}
            const cb = ev.content_block;
            if (cb && typeof cb === "object") {{
                const t = (cb as Record<string, unknown>).text;
                if (typeof t === "string" && t.length > 0)
                    return {{ kind: "assistant" as const, text: t }};
            }}
            const partial = ev.partial;
            if (typeof partial === "string" && partial.length > 0)
                return {{ kind: "assistant" as const, text: partial }};
            return null;
        }}

        function turnResultToTextDeep(r: unknown): string | null {{
            let t = turnResultToText(r);
            if (t) return t;
            if (r && typeof r === "object") {{
                const o = r as Record<string, unknown>;
                for (const x of [o.output, o.output_text, o.response, o.message, o.content, o.text]) {{
                    t = turnResultToText(x);
                    if (t) return t;
                }}
            }}
            return null;
        }}

        async function main() {{
            const sessionConfig: any = {{
                permissionMode: "bypassPermissions",
                {model_line}
                disallowedTools: {disallowed_js},
                allowedTools: {allowed_js},
                skillSources: {skill_sources_js},
                cwd: {cwd_js},
            }};

            await using session = {session_fn}({json.dumps(agent_id)}, sessionConfig);

            await session.send({escaped_message});

            const assistantChunks: string[] = [];
            const reasoningChunks: string[] = [];
            const steps: Record<string, unknown>[] = [];
            let usageOut: Record<string, unknown> = {{}};
            let lastTurnResult: string | undefined;

            for await (const msg of session.stream()) {{
                const t = msg.type;

                if (t === "assistant" || t === "assistant_message") {{
                    const text = assistantTextFromContent((msg as any).content);
                    if (text) {{
                        assistantChunks.push(text);
                        const step = {{ type: "assistant", content: text }};
                        steps.push(step);
                        emit(step);
                    }}
                }} else if (t === "stream_event") {{
                    const m = msg as any;
                    const inner = (m.event ?? {{}}) as Record<string, unknown>;
                    const merged: Record<string, unknown> = {{ ...inner }};
                    if (typeof m.message_type === "string" && !("message_type" in merged))
                        merged.message_type = m.message_type;
                    if (m.content !== undefined && !("content" in merged))
                        merged.content = m.content;
                    if (m.reasoning !== undefined && !("reasoning" in merged))
                        merged.reasoning = m.reasoning;
                    let delta = extractStreamTextDelta(merged as any);
                    if (!delta)
                        delta = extractStreamTextDelta(m as any);
                    // Gemini / Google: text in delta.content (SDK extractStreamTextDelta does not read it).
                    if (!delta && merged.delta && typeof merged.delta === "object") {{
                        const ad = assistantDeltaFromRecord(merged.delta as Record<string, unknown>);
                        if (ad) delta = ad;
                    }}
                    if (!delta && inner.delta && typeof inner.delta === "object") {{
                        const ad = assistantDeltaFromRecord(inner.delta as Record<string, unknown>);
                        if (ad) delta = ad;
                    }}
                    if (!delta) {{
                        const fb = streamDeltaFallback(inner);
                        if (fb) delta = fb;
                    }}
                    if (!delta) {{
                        const fb2 = streamDeltaFallback(m as Record<string, unknown>);
                        if (fb2) delta = fb2;
                    }}
                    // Last resort: assistant-shaped payload on the stream_event itself.
                    if (!delta && merged.message_type === "assistant_message") {{
                        const tail = assistantTextFromContent(merged.content);
                        if (tail)
                            delta = {{ kind: "assistant" as const, text: tail }};
                    }}
                    if (delta) {{
                        if (delta.kind === "assistant" && delta.text) {{
                            assistantChunks.push(delta.text);
                            const step = {{ type: "assistant", content: delta.text }};
                            steps.push(step);
                            emit(step);
                        }} else if (delta.kind === "reasoning" && delta.text) {{
                            reasoningChunks.push(delta.text);
                            const step = {{ type: "reasoning", content: delta.text }};
                            steps.push(step);
                            emit(step);
                        }}
                    }}
                }} else if (t === "reasoning" || t === "reasoning_message") {{
                    const text = String((msg as any).content ?? (msg as any).reasoning ?? "");
                    if (text) {{
                        reasoningChunks.push(text);
                        const step = {{ type: "reasoning", content: text }};
                        steps.push(step);
                        emit(step);
                    }}
                }} else if (t === "tool_call") {{
                    const m = msg as any;
                    const name = m.toolName ?? m.toolCall?.name ?? m.tool_call?.name ?? "?";
                    let args: unknown = m.toolInput;
                    if (args === undefined) {{
                        const raw = m.rawArguments ?? m.toolCall?.arguments ?? m.tool_call?.arguments ?? "{{}}";
                        try {{
                            args = typeof raw === "string" ? JSON.parse(raw || "{{}}") : raw;
                        }} catch {{
                            args = {{ raw }};
                        }}
                    }}
                    const step = {{ type: "tool_call", name, arguments: args }};
                    steps.push(step);
                    emit(step);
                }} else if (t === "tool_result") {{
                    const m = msg as any;
                    const st = m.isError ? "error" : "success";
                    const body = typeof m.content === "string" ? m.content : JSON.stringify(m.content ?? "");
                    const step = {{ type: "tool_return", status: st, content: body }};
                    steps.push(step);
                    emit(step);
                }} else if (t === "tool_return") {{
                    const tr = (msg as any).toolReturn ?? (msg as any).tool_return ?? "";
                    const st = (msg as any).status ?? "success";
                    const step = {{
                        type: "tool_return",
                        status: st,
                        content: typeof tr === "string" ? tr : JSON.stringify(tr),
                    }};
                    steps.push(step);
                    emit(step);
                }} else if (t === "error") {{
                    const step = {{
                        type: "error",
                        content: (msg as any).message ?? (msg as any).content ?? JSON.stringify(msg),
                    }};
                    steps.push(step);
                    emit(step);
                }} else if (t === "result") {{
                    const m = msg as any;
                    if (typeof m.totalCostUsd === "number") usageOut.totalCostUsd = m.totalCostUsd;
                    let turnRaw: unknown = m.result;
                    if (typeof turnRaw === "string" && turnRaw.trim().startsWith("{{")) {{
                        try {{ turnRaw = JSON.parse(turnRaw); }} catch {{}}
                    }}
                    const turnText = turnResultToTextDeep(turnRaw);
                    if (turnText) {{
                        lastTurnResult = turnText;
                        if (assistantChunks.join("").trim() === "") {{
                            assistantChunks.push(turnText);
                            const step = {{ type: "assistant", content: turnText }};
                            steps.push(step);
                            emit(step);
                        }}
                    }}
                }}
            }}

            // Local Letta / older SDK builds sometimes omit assistant deltas on stream() even when
            // the turn succeeded — same agent works against hosted Letta. Pull latest assistant
            // from the active conversation (matches authoritative server history).
            if (assistantChunks.join("").trim() === "") {{
                try {{
                    const lm = await session.listMessages({{ limit: 30, order: "desc" }});
                    const msgs = lm?.messages ?? [];
                    for (const row of msgs) {{
                        const r = row as Record<string, unknown>;
                        const mt = typeof r.message_type === "string" ? r.message_type : "";
                        const role = typeof r.role === "string" ? r.role : "";
                        const isAssistant =
                            mt === "assistant_message" ||
                            role === "assistant" ||
                            mt === "assistant";
                        if (!isAssistant) continue;
                        const t = assistantTextFromContent(r.content);
                        if (t && t.trim()) {{
                            assistantChunks.push(t);
                            const step = {{ type: "assistant", content: t }};
                            steps.push(step);
                            emit(step);
                            lastTurnResult = lastTurnResult ?? t.trim();
                            break;
                        }}
                    }}
                }} catch {{
                    /* best-effort salvage */
                }}
            }}

            emit({{
                _final: true,
                messages: [assistantChunks.join("")],
                reasoning: reasoningChunks,
                steps: steps,
                usage: usageOut,
                ...(lastTurnResult ? {{ result: lastTurnResult }} : {{}}),
            }});
        }}

        main().catch((err) => {{
            try {{
                emit({{ type: "error", content: err.message || String(err) }});
            }} catch {{
                console.error(err);
            }}
            console.error(JSON.stringify({{ error: err.message || String(err) }}));
            process.exit(1);
        }});
    """)

    return script
