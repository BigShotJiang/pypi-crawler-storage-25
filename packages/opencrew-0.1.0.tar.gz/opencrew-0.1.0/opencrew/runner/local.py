from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import tempfile
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from opencrew.runner.script import generate_script
from opencrew.store.registry import (
    update_run_status,
    insert_run_event,
    log_run_start,
    log_run_complete,
    log_run_failed,
)
from opencrew.skills.materializer import materialize_skills
from opencrew.types import RuntimeBundle, SessionOptions

logger = logging.getLogger(__name__)


class LocalRunner:
    """Runs Letta Code SDK sessions in local subprocesses via a thread pool."""

    def __init__(self, max_workers: int = 4):
        self._pool = ThreadPoolExecutor(
            max_workers=max_workers, thread_name_prefix="opencrew-runner"
        )

    async def dispatch(
        self,
        run_id: str,
        agent_id: str,
        message: str,
        owner_id: str,
        runtime_bundle: dict,
    ) -> None:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            self._pool,
            self._execute,
            run_id,
            agent_id,
            message,
            owner_id,
            runtime_bundle,
        )

    def _execute(
        self,
        run_id: str,
        agent_id: str,
        message: str,
        owner_id: str,
        runtime_bundle_dict: dict | RuntimeBundle,
    ) -> None:
        bundle = (
            RuntimeBundle(**runtime_bundle_dict)
            if isinstance(runtime_bundle_dict, dict)
            else runtime_bundle_dict
        )

        try:
            update_run_status(run_id, "running")
            log_run_start(run_id, metadata={"agent_id": agent_id, "owner_id": owner_id})

            so = bundle.session_options or SessionOptions()
            disallowed = so.disallowedTools
            allowed = so.allowedTools
            skill_sources = so.skillSources

            runtime_cwd: str | None = None
            if bundle.skills:
                runtime_cwd = materialize_skills(run_id, bundle.skills)

            session_mode = "create" if bundle.new_conversation else "resume"

            letta_base_url = os.environ.get("LETTA_BASE_URL", "http://localhost:8283")
            letta_base_url = letta_base_url.rstrip("/").removesuffix("/v1")
            letta_token = os.environ.get("LETTA_API_TOKEN", "")

            # Align with Modal runner: use LETTA_DEFAULT_MODEL when the agent type has no model.
            bundle_model = bundle.model or (os.environ.get("LETTA_DEFAULT_MODEL") or "").strip() or None

            script_content = generate_script(
                agent_id,
                message,
                letta_base_url=letta_base_url,
                letta_api_token=letta_token,
                session_mode=session_mode,
                model=bundle_model,
                disallowed_tools=disallowed,
                allowed_tools=allowed,
                skill_sources=skill_sources,
                cwd=runtime_cwd,
                credential_tokens=bundle.credential_tokens,
            )

            script_path = os.path.join(
                tempfile.gettempdir(), f"opencrew_run_{uuid.uuid4().hex[:8]}.ts"
            )
            with open(script_path, "w") as f:
                f.write(script_content)

            try:
                env = os.environ.copy()
                node_modules = os.path.expanduser("~/.opencrew/node_modules")
                existing_node_path = env.get("NODE_PATH", "")
                env["NODE_PATH"] = (
                    f"{node_modules}:{existing_node_path}"
                    if existing_node_path
                    else node_modules
                )

                for key, val in (bundle.credential_tokens or {}).items():
                    env[key] = val

                proc = subprocess.Popen(
                    ["npx", "tsx", script_path],
                    cwd=tempfile.gettempdir(),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    env=env,
                )

                stderr_lines: list[str] = []

                def drain_stderr() -> None:
                    assert proc.stderr is not None
                    for line in proc.stderr:
                        stripped = line.rstrip()
                        if stripped:
                            stderr_lines.append(stripped)

                stderr_thread = threading.Thread(target=drain_stderr, daemon=True)
                stderr_thread.start()

                parsed_result: dict | None = None
                seq = 0
                assert proc.stdout is not None
                for raw_line in proc.stdout:
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if event.get("_final"):
                        parsed_result = event
                        continue

                    seq += 1
                    event_type = event.get("type", "unknown")
                    try:
                        insert_run_event(str(run_id), seq, event_type, event)
                    except Exception as e:
                        logger.warning("Failed to insert run event: %s", e)

                proc.wait()
                stderr_thread.join(timeout=5)

                if proc.returncode == 0 and parsed_result:
                    parsed_result.pop("_final", None)
                    result = {
                        "messages": parsed_result.get("messages", []),
                        "reasoning": parsed_result.get("reasoning", []),
                        "steps": parsed_result.get("steps", []),
                        "usage": parsed_result.get("usage", {}),
                    }
                    tr = parsed_result.get("result")
                    if isinstance(tr, str) and tr.strip():
                        result["result"] = tr.strip()
                    else:
                        msgs = parsed_result.get("messages") or []
                        joined = "".join(m for m in msgs if isinstance(m, str))
                        if joined.strip():
                            result["result"] = joined.strip()
                    update_run_status(str(run_id), "complete", result=result)
                    log_run_complete(str(run_id), metadata=result)
                else:
                    error_msg = (
                        "\n".join(stderr_lines[-10:])
                        if stderr_lines
                        else f"Process exited with code {proc.returncode}"
                    )
                    update_run_status(str(run_id), "failed", error=error_msg)
                    log_run_failed(str(run_id), error_msg)
            finally:
                try:
                    os.unlink(script_path)
                except OSError:
                    pass

                from opencrew.letta.client import delete_mcp_server, delete_agent

                for mcp_id in bundle.custom_mcp_server_ids or []:
                    try:
                        delete_mcp_server(mcp_id)
                    except Exception:
                        pass
                if bundle.is_fresh:
                    try:
                        delete_agent(agent_id)
                    except Exception:
                        pass

        except Exception as exc:
            logger.exception("Run %s failed with exception", run_id)
            try:
                update_run_status(str(run_id), "failed", error=str(exc))
                log_run_failed(str(run_id), str(exc))
            except Exception:
                pass

    def shutdown(self) -> None:
        self._pool.shutdown(wait=False)


def check_node_prerequisites() -> tuple[bool, str]:
    """Check that Node.js >= 20 and tsx are available. Returns (ok, message)."""
    import shutil

    if not shutil.which("node"):
        return False, "Node.js not found. Install Node.js 20+ from https://nodejs.org"
    try:
        result = subprocess.run(
            ["node", "--version"], capture_output=True, text=True, timeout=10
        )
        version = result.stdout.strip().lstrip("v")
        major = int(version.split(".")[0])
        if major < 20:
            return False, f"Node.js {version} found but >= 20 required"
    except Exception as e:
        return False, f"Failed to check Node.js version: {e}"

    if not shutil.which("npx"):
        return False, "npx not found. Install Node.js 20+ from https://nodejs.org"

    node_modules = (
        Path.home() / ".opencrew" / "node_modules" / "@letta-ai" / "letta-code-sdk"
    )
    if not node_modules.exists():
        return False, (
            "Letta Code SDK not found. Run `opencrew init` or "
            "`npm install --prefix ~/.opencrew @letta-ai/letta-code-sdk`"
        )

    return True, "OK"
