from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


# --- API Keys ---

class ApiKey(BaseModel):
    id: UUID
    owner_id: str
    entity_id: str | None = None
    label: str | None = None
    key_prefix: str
    created_at: datetime
    revoked_at: datetime | None = None


# --- Runs ---

class SessionOptions(BaseModel):
    disallowedTools: list[str] = Field(
        default_factory=lambda: ["AskUserQuestion", "EnterPlanMode", "ExitPlanMode"]
    )
    allowedTools: list[str] | None = None
    skillSources: list[str] = Field(default_factory=lambda: ["project"])


class RuntimeSkillAsset(BaseModel):
    path: str
    content: str


class RuntimeSkill(BaseModel):
    skill_id: UUID
    skill_version_id: UUID
    slug: str
    version: str
    files: list[RuntimeSkillAsset] = Field(default_factory=list)


class RuntimeCustomTool(BaseModel):
    custom_tool_id: UUID
    name: str
    slug: str
    source_code: str
    source_type: str = "python"
    args_json_schema: dict[str, Any] | None = None
    letta_tool_id: str | None = None


class RuntimeMcpServer(BaseModel):
    custom_mcp_server_id: UUID
    name: str
    slug: str
    server_url: str = ""
    server_type: str = "streamable_http"
    transport: str = "streamable_http"
    auth_header: str | None = None
    auth_token: str | None = None
    custom_headers: dict[str, str] | None = None
    command: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None


class RuntimeBundle(BaseModel):
    run_id: UUID
    owner_id: str
    entity_id: str | None = None
    client_id: str | None = None
    agent_type_id: UUID | None = None
    model: str | None = None
    skills: list[RuntimeSkill] = Field(default_factory=list)
    skill_manifest: dict[str, Any] = Field(default_factory=dict)
    session_options: SessionOptions = Field(default_factory=SessionOptions)
    credential_tokens: dict[str, str] = Field(default_factory=dict)
    custom_tools: list[RuntimeCustomTool] = Field(default_factory=list)
    custom_mcp_servers: list[RuntimeMcpServer] = Field(default_factory=list)
    custom_mcp_server_ids: list[str] = Field(default_factory=list)
    new_conversation: bool = False
    is_fresh: bool = False


class RunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    agent_type: str
    message: str
    instance_id: UUID | None = None
    client_id: str | None = None
    fresh: bool = False
    new_conversation: bool = False
    allow_partial: bool = False
    session_options: SessionOptions | None = None


class Run(BaseModel):
    id: UUID
    owner_id: str
    entity_id: str | None = None
    client_id: str | None = None
    agent_type_id: UUID | None = None
    agent_id: str | None = None
    message: str
    status: str = "pending"
    session_options: SessionOptions | None = None
    skill_manifest: dict[str, Any] | None = None
    result: dict[str, Any] | None = None
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0


class RunResult(BaseModel):
    messages: list[str] = Field(default_factory=list)
    reasoning: list[str] = Field(default_factory=list)
    steps: list[dict[str, Any]] = Field(default_factory=list)
    usage: dict[str, Any] = Field(default_factory=dict)


class RunEvent(BaseModel):
    id: UUID
    run_id: UUID
    seq: int
    event_type: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


# --- Agent setup ---

class AgentTypeCreateRequest(BaseModel):
    name: str
    slug: str | None = None
    description: str | None = None
    persona: str | None = None
    system_prompt: str | None = None
    model: str | None = None
    memory_defaults: dict[str, Any] | None = None


class AgentTypeUpdateRequest(BaseModel):
    name: str | None = None
    slug: str | None = None
    description: str | None = None
    persona: str | None = None
    system_prompt: str | None = None
    model: str | None = None
    readiness_status: str | None = None


class InstanceCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    description: str | None = None
    display_name: str | None = None
    client_id: str | None = None


class InstanceResponse(BaseModel):
    id: UUID
    agent_type_id: UUID
    agent_type_slug: str | None = None
    name: str | None = None
    display_name: str | None = None
    avatar_url: str | None = None
    is_default: bool = False
    status: str = "active"
    created_at: datetime
    last_used_at: datetime | None = None


class SkillCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    slug: str
    name: str
    description: str
    instructions: str


class SkillUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    description: str | None = None
    instructions: str | None = None
    publish_new_version: bool = False


class AgentTypeSkillAttachRequest(BaseModel):
    skill_id: UUID
    skill_version_id: UUID


# --- Agent type responses ---

class AgentTypeResponse(BaseModel):
    id: UUID
    slug: str
    name: str
    description: str | None = None
    persona: str | None = None
    system_prompt: str | None = None
    model: str | None = None
    memory_defaults: dict[str, Any] | None = None
    readiness_status: str | None = None
    created_at: datetime
    updated_at: datetime | None = None


class DeleteResponse(BaseModel):
    deleted: bool = True
    id: str | None = None
    slug: str | None = None


# --- Entities ---

class EntityCreateRequest(BaseModel):
    name: str
    slug: str | None = None
    metadata: dict[str, Any] | None = None


class EntityUpdateRequest(BaseModel):
    name: str | None = None
    slug: str | None = None
    metadata: dict[str, Any] | None = None


class EntityResponse(BaseModel):
    id: str
    owner_id: str
    name: str
    slug: str
    metadata: dict[str, Any] | None = None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None


class EntityListResponse(BaseModel):
    items: list[EntityResponse] = Field(default_factory=list)


class ClientCreateRequest(BaseModel):
    name: str
    slug: str | None = None
    metadata: dict[str, Any] | None = None


class ClientUpdateRequest(BaseModel):
    name: str | None = None
    slug: str | None = None
    metadata: dict[str, Any] | None = None


class ClientResponse(BaseModel):
    client_id: str
    workspace_id: str
    name: str
    slug: str
    metadata: dict[str, Any] | None = None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None


# --- Skill / memory responses ---

class SkillResponse(BaseModel):
    id: UUID
    slug: str
    name: str
    description: str | None = None
    version: str | None = None
    created_at: datetime | None = None


class ClientMemoryBlockResponse(BaseModel):
    id: str
    label: str
    value: str
    description: str | None = None
    project_id: str | None = None
    connected_agents_count: int = 0
    attach_pending: bool = False


class ClientMemoryBlockCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str
    value: str
    description: str | None = None
    attach_to_existing: bool = True


class ClientMemoryBlockUpdateRequest(BaseModel):
    value: str | None = None
    label: str | None = None
    description: str | None = None


# --- Logs ---

class RunLog(BaseModel):
    id: UUID
    run_id: UUID
    level: str
    message: str
    metadata: dict[str, Any] | None = None
    created_at: datetime


class UsageSummary(BaseModel):
    total_runs: int = 0
    total_tokens: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    avg_duration_seconds: float = 0.0


# --- Custom Tools ---

class CustomToolCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    slug: str | None = None
    description: str | None = None
    source_code: str
    source_type: Literal["python", "typescript"] = "python"
    args_json_schema: dict[str, Any] | None = None
    tags: list[str] | None = None


class CustomToolUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    description: str | None = None
    source_code: str | None = None
    source_type: Literal["python", "typescript"] | None = None
    tags: list[str] | None = None


class CustomToolResponse(BaseModel):
    id: UUID
    slug: str
    name: str
    description: str | None = None
    source_type: str = "python"
    letta_tool_id: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AgentTypeToolAttachRequest(BaseModel):
    custom_tool_id: UUID


# --- Custom MCP Servers ---

class CustomMcpServerCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    slug: str | None = None
    server_url: str = ""
    server_type: str = "streamable_http"
    transport: str = "streamable_http"
    auth_header: str | None = None
    auth_token: str | None = None
    custom_headers: dict[str, str] | None = None
    description: str | None = None
    command: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None
    composio_app: str | None = None
    composio_actions: list[str] | None = None


class CustomMcpServerUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    server_url: str | None = None
    server_type: str | None = None
    transport: str | None = None
    auth_header: str | None = None
    auth_token: str | None = None
    custom_headers: dict[str, str] | None = None
    description: str | None = None
    command: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None
    composio_app: str | None = None
    composio_actions: list[str] | None = None


class CustomMcpServerResponse(BaseModel):
    id: UUID
    slug: str
    name: str
    server_url: str
    server_type: str = "streamable_http"
    description: str | None = None
    source_registry: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AgentTypeMcpServerAttachRequest(BaseModel):
    custom_mcp_server_id: UUID
