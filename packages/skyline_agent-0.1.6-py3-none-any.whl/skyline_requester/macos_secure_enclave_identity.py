from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .local_identity_crypto import (
    LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
    fingerprint_public_key,
)


MACOS_SECURE_ENCLAVE_SIGNER_BACKEND_ID = "macos_secure_enclave"
MACOS_SECURE_ENCLAVE_DISABLE_ENV_VAR = "SKYLINE_DISABLE_MACOS_SECURE_ENCLAVE_SIGNER"
MACOS_SECURE_ENCLAVE_HELPER_ENV_VAR = "SKYLINE_MACOS_SECURE_ENCLAVE_SIGNER"
MACOS_SOFTWARE_SIGNER_DEV_OVERRIDE_ENV_VAR = "SKYLINE_DEV_ALLOW_MACOS_SOFTWARE_SIGNER"
MACOS_SECURE_ENCLAVE_HELPER_BUILD_ENV_VAR = (
    "SKYLINE_DEV_COMPILE_MACOS_SECURE_ENCLAVE_SIGNER"
)
MACOS_SECURE_ENCLAVE_HELPER_BINARY_NAME = "skyline-secure-enclave-signer"

MACOS_SECURE_ENCLAVE_STATUS_AVAILABLE = "available"
MACOS_SECURE_ENCLAVE_STATUS_HARDWARE_UNAVAILABLE = "hardware_unavailable"
MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE = "helper_unavailable"
MACOS_SECURE_ENCLAVE_STATUS_DISABLED = "disabled"
MACOS_SECURE_ENCLAVE_STATUS_PLATFORM_UNSUPPORTED = "platform_unsupported"
MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR = "helper_error"


class MacOSSecureEnclaveUnavailable(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        status: str = MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
    ) -> None:
        super().__init__(message)
        self.status = status


def _source_path() -> Path:
    return Path(__file__).with_name("macos_secure_enclave_signer.swift")


def _packaged_helper_path() -> Path | None:
    module_dir = Path(__file__).resolve().parent
    for candidate in (
        module_dir / "bin" / MACOS_SECURE_ENCLAVE_HELPER_BINARY_NAME,
        module_dir / MACOS_SECURE_ENCLAVE_HELPER_BINARY_NAME,
        module_dir.parent.parent
        / "requester"
        / "skyline_requester"
        / "bin"
        / MACOS_SECURE_ENCLAVE_HELPER_BINARY_NAME,
    ):
        if candidate.exists() and os.access(candidate, os.X_OK):
            return candidate
    return None


def _cache_dir() -> Path:
    root = os.environ.get("XDG_CACHE_HOME", "").strip()
    if root:
        return Path(root).expanduser() / "skyline" / "macos-secure-enclave-signer"
    return Path.home() / ".cache" / "skyline" / "macos-secure-enclave-signer"


def _source_digest(source: Path) -> str:
    return hashlib.sha256(source.read_bytes()).hexdigest()[:16]


def _compiled_helper_path() -> Path:
    source = _source_path()
    return _cache_dir() / _source_digest(source) / "skyline-secure-enclave-signer"


def _preconfigured_helper_path() -> Path | None:
    configured = os.environ.get(MACOS_SECURE_ENCLAVE_HELPER_ENV_VAR, "").strip()
    if not configured:
        return None
    path = Path(configured).expanduser()
    if path.exists() and os.access(path, os.X_OK):
        return path
    raise MacOSSecureEnclaveUnavailable(
        "configured macOS Secure Enclave signer helper is not executable",
        status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
    )


def _truthy_env(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes"}


def _xcode_tools_available() -> bool:
    swiftc = shutil.which("swiftc")
    if swiftc is None:
        return False
    try:
        completed = subprocess.run(
            ["xcode-select", "-p"],
            capture_output=True,
            check=False,
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return completed.returncode == 0


def _compile_dev_helper() -> Path:
    source = _source_path()
    if not source.exists():
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer source is missing",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
        )
    if not _xcode_tools_available():
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer helper is not packaged and dev compilation "
            "requires Xcode Command Line Tools",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
        )
    helper_path = _compiled_helper_path()
    if helper_path.exists() and os.access(helper_path, os.X_OK):
        return helper_path
    helper_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = helper_path.with_suffix(".tmp")
    completed = subprocess.run(
        ["swiftc", str(source), "-o", str(tmp_path)],
        capture_output=True,
        check=False,
        text=True,
        timeout=30,
    )
    if completed.returncode != 0:
        raise MacOSSecureEnclaveUnavailable(
            "failed to compile macOS Secure Enclave signer helper: "
            + (completed.stderr.strip() or completed.stdout.strip() or "unknown error"),
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
        )
    tmp_path.chmod(0o700)
    tmp_path.replace(helper_path)
    return helper_path


def _resolve_helper_path() -> Path:
    configured = _preconfigured_helper_path()
    if configured is not None:
        return configured
    if sys.platform != "darwin":
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer requires macOS",
            status=MACOS_SECURE_ENCLAVE_STATUS_PLATFORM_UNSUPPORTED,
        )
    if _truthy_env(MACOS_SECURE_ENCLAVE_DISABLE_ENV_VAR):
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer is disabled",
            status=MACOS_SECURE_ENCLAVE_STATUS_DISABLED,
        )
    packaged = _packaged_helper_path()
    if packaged is not None:
        return packaged
    if _truthy_env(MACOS_SECURE_ENCLAVE_HELPER_BUILD_ENV_VAR):
        return _compile_dev_helper()
    raise MacOSSecureEnclaveUnavailable(
        "packaged macOS Secure Enclave signer helper is missing; reinstall or update "
        "the Skyline CLI package",
        status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
    )


def _ensure_compiled_helper() -> Path:
    if not _truthy_env(MACOS_SECURE_ENCLAVE_HELPER_BUILD_ENV_VAR):
        raise MacOSSecureEnclaveUnavailable(
            "runtime compilation of the macOS Secure Enclave signer helper is dev-only",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
        )
    return _compile_dev_helper()


def _run_helper(payload: dict[str, Any]) -> dict[str, Any]:
    helper_path = _resolve_helper_path()
    completed = subprocess.run(
        [str(helper_path)],
        input=json.dumps(payload, separators=(",", ":"), sort_keys=True),
        capture_output=True,
        check=False,
        text=True,
        timeout=15,
    )
    raw_output = completed.stdout.strip()
    try:
        response = json.loads(raw_output or "{}")
    except json.JSONDecodeError as error:
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer helper returned invalid JSON: "
            + (completed.stderr.strip() or raw_output or str(error)),
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        ) from error
    if not isinstance(response, dict):
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer helper returned a non-object response",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        )
    if completed.returncode != 0:
        message = str(response.get("error") or "").strip()
        raise MacOSSecureEnclaveUnavailable(
            message
            or completed.stderr.strip()
            or "macOS Secure Enclave signer helper failed",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        )
    return response


def macos_secure_enclave_identity_status() -> dict[str, Any]:
    try:
        response = _run_helper({"operation": "probe"})
    except MacOSSecureEnclaveUnavailable as error:
        return {
            "available": False,
            "status": error.status,
            "reason": str(error),
            "key_algorithm": LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        }
    available = bool(response.get("available"))
    if available:
        return {
            "available": True,
            "status": MACOS_SECURE_ENCLAVE_STATUS_AVAILABLE,
            "reason": None,
            "key_algorithm": LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        }
    return {
        "available": False,
        "status": MACOS_SECURE_ENCLAVE_STATUS_HARDWARE_UNAVAILABLE,
        "reason": str(response.get("error") or "Secure Enclave is not available"),
        "key_algorithm": LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
    }


def macos_secure_enclave_identity_available() -> bool:
    return bool(macos_secure_enclave_identity_status().get("available"))


def generate_macos_secure_enclave_identity_keypair() -> dict[str, str]:
    response = _run_helper({"operation": "generate"})
    private_key_representation = str(response.get("privateKeyRepresentation") or "").strip()
    public_key = str(response.get("publicKey") or "").strip()
    if not private_key_representation or not public_key:
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer did not return a complete keypair",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        )
    fingerprint = fingerprint_public_key(public_key)
    return {
        "algorithm": LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        "private_key_representation": private_key_representation,
        "public_key": public_key,
        "key_id": fingerprint[:16],
        "key_fingerprint": fingerprint,
    }


def sign_macos_secure_enclave_identity_message(
    *,
    private_key_representation: str,
    message: str,
) -> str:
    if not str(private_key_representation or "").strip():
        raise MacOSSecureEnclaveUnavailable(
            "Secure Enclave key representation is missing",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        )
    response = _run_helper(
        {
            "operation": "sign",
            "privateKeyRepresentation": private_key_representation,
            "message": message,
        }
    )
    signature = str(response.get("signature") or "").strip()
    if not signature:
        raise MacOSSecureEnclaveUnavailable(
            "macOS Secure Enclave signer did not return a signature",
            status=MACOS_SECURE_ENCLAVE_STATUS_HELPER_ERROR,
        )
    return signature
