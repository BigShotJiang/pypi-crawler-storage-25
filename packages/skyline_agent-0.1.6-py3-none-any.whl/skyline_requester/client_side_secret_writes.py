from __future__ import annotations

import time
from typing import Any

from .secret_custody import (
    CUSTODY_MODE_AUTHORITY_USABLE,
    RecipientKeyReference,
    build_stored_blind_secret_package,
    is_blind_custody_mode,
)
from .vault_item_types import get_vault_item_type


KEY_HOLDER_REFETCH_RETRY_MARKER = "refetch active key holders and retry"


def should_refetch_key_holders_for_write_error(error: BaseException | str) -> bool:
    return KEY_HOLDER_REFETCH_RETRY_MARKER in str(error)


def with_client_side_presence_metadata(
    kind: str,
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> dict[str, Any]:
    metadata = dict(safe_metadata)
    if kind == "payment_card":
        pan = "".join(
            char for char in str(protected_fields.get("pan") or "") if char.isdigit()
        )
        if pan and "last4" not in metadata:
            metadata["last4"] = pan[-4:]
        if "has_cvv" not in metadata:
            metadata["has_cvv"] = bool(str(protected_fields.get("cvv") or "").strip())
    return metadata


def build_client_side_protected_write_payload(
    *,
    kind: str,
    item_id: str,
    item_revision: int,
    protected_fields: dict[str, Any],
    recipients: list[RecipientKeyReference],
    created_at_epoch_ms: int | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    definition = get_vault_item_type(kind)
    if definition is None:
        raise ValueError(f"unsupported protected item kind '{kind}'")
    active_recipients = [recipient for recipient in recipients if recipient.status == "active"]
    package_created_at = (
        int(time.time() * 1000)
        if created_at_epoch_ms is None
        else int(created_at_epoch_ms)
    )
    protected_packages: dict[str, Any] = {}
    authority_fields: dict[str, Any] = {}
    for field_name, value in protected_fields.items():
        normalized_field_name = str(field_name)
        field = definition.protected_fields.get(normalized_field_name)
        if field is None:
            raise ValueError(f"{kind} does not define protected field '{normalized_field_name}'")
        if field.custody_mode == CUSTODY_MODE_AUTHORITY_USABLE:
            authority_fields[normalized_field_name] = value
            continue
        if field.custody_mode is None or not is_blind_custody_mode(field.custody_mode):
            raise ValueError(f"{kind}.{normalized_field_name} is not blind-releasable")
        if not active_recipients:
            raise ValueError("normal secret writes require an active trusted key holder")
        protected_packages[normalized_field_name] = build_stored_blind_secret_package(
            item_id=item_id,
            field_name=normalized_field_name,
            item_revision=item_revision,
            plaintext_value=str(value),
            custody_mode=field.custody_mode,
            recipients=active_recipients,
            created_at_epoch_ms=package_created_at,
        ).to_json()
    return protected_packages, authority_fields
