from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import struct
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from queue import Empty, Queue
from threading import Event, Lock, Thread
from typing import Any

import httpx

from .helper_security import (
    browser_context_id,
    build_one_time_challenge,
    ensure_owner_only_directory,
    load_helper_metadata,
    require_metadata,
    save_helper_metadata,
    write_owner_only_text,
)


DEFAULT_CONFIG_PATH = Path.home() / ".skyline-browser-host.json"
DEFAULT_NATIVE_HOST_NAME = "com.skyline.browser_host"
DEFAULT_BROWSER_NAME = "Google Chrome"
DEFAULT_PROFILE_LABEL = "Default"
DEFAULT_BROWSER_CHANNEL_ID = "chrome-default"
DEFAULT_EXTENSION_CHANNEL = "development"
SUPPORTED_EXTENSION_CHANNELS = {"development", "release"}
DEFAULT_DEVELOPMENT_EXTENSION_ID = "kmiklhekbajmekcabmjhlnehjcfoebll"
NATIVE_HOST_RUNTIME_CONFIG_KEYS = (
    "browser_action_ready",
    "browser_channel_id",
    "delivery_target_id",
    "extension_version",
)
POLL_INTERVAL_SECONDS = 1.0
FILL_TIMEOUT_SECONDS = 15.0
CHALLENGE_TIMEOUT_SECONDS = 10.0
REQUEST_WAIT_TIMEOUT_MS = 15_000
ACTION_POLL_DELAY_SECONDS = 0.5
BROWSER_SESSION_HEADER = "x-skyline-browser-session"


@dataclass(slots=True)
class PopupActionRecord:
    action_id: str
    action_type: str
    request_id: str
    field_name: str | None
    item_id: str | None
    item_title: str | None
    status: str
    message: str | None
    approval_id: str | None
    result_type: str | None = None


def _native_manifest_dir(browser: str) -> Path:
    home = Path.home()
    normalized = browser.strip().lower()
    if sys.platform == "darwin":
        base = home / "Library" / "Application Support"
        if normalized == "chrome":
            return base / "Google" / "Chrome" / "NativeMessagingHosts"
        if normalized == "chrome_for_testing":
            return base / "Google" / "ChromeForTesting" / "NativeMessagingHosts"
        if normalized == "chromium":
            return base / "Chromium" / "NativeMessagingHosts"
    if sys.platform.startswith("linux"):
        base = home / ".config"
        if normalized == "chrome":
            return base / "google-chrome" / "NativeMessagingHosts"
        if normalized == "chrome_for_testing":
            return base / "google-chrome-for-testing" / "NativeMessagingHosts"
        if normalized == "chromium":
            return base / "chromium" / "NativeMessagingHosts"
    raise RuntimeError(
        "native messaging install currently supports macOS or Linux and browser "
        "values of chrome, chrome_for_testing, or chromium"
    )


def _browser_target_metadata(config: dict[str, Any], *, extension_version: str | None) -> dict[str, Any]:
    return {
        "browser_channel_id": str(
            config.get("browser_channel_id") or DEFAULT_BROWSER_CHANNEL_ID
        ),
        "browser_name": str(config.get("browser_name") or DEFAULT_BROWSER_NAME),
        "profile_label": str(config.get("profile_label") or DEFAULT_PROFILE_LABEL),
        "extension_id": str(config.get("extension_id") or ""),
        "extension_channel": str(
            config.get("extension_channel") or DEFAULT_EXTENSION_CHANNEL
        ),
        "extension_version": extension_version or config.get("extension_version"),
        "native_host_name": str(config.get("native_host_name") or DEFAULT_NATIVE_HOST_NAME),
    }


def default_extension_id_for_channel(channel: str) -> str | None:
    normalized = str(channel or DEFAULT_EXTENSION_CHANNEL).strip() or DEFAULT_EXTENSION_CHANNEL
    if normalized == "development":
        return DEFAULT_DEVELOPMENT_EXTENSION_ID
    env_value = os.environ.get("SKYLINE_BROWSER_EXTENSION_ID_RELEASE", "").strip()
    return env_value or None


def _preferred_skyline_cli_path() -> str | None:
    for command_name in ("skyline",):
        home_local_bin = Path.home() / ".local" / "bin" / command_name
        try:
            if home_local_bin.exists() and os.access(home_local_bin, os.X_OK):
                return str(home_local_bin.resolve())
        except Exception:
            pass
        installed_path = shutil.which(command_name)
        if installed_path:
            return str(Path(installed_path).resolve())
    return None


def install_native_host_manifest(
    *,
    config_path: Path,
    browser: str,
    extension_id: str | None,
    extension_channel: str,
    native_host_name: str,
    requester_config_path: str | None = None,
    requester_socket_path: str | None = None,
) -> dict[str, Any]:
    config = load_helper_metadata(config_path)
    resolved_extension_channel = (
        str(extension_channel or DEFAULT_EXTENSION_CHANNEL).strip()
        or DEFAULT_EXTENSION_CHANNEL
    )
    if resolved_extension_channel not in SUPPORTED_EXTENSION_CHANNELS:
        raise RuntimeError(
            "extension_channel must be one of: "
            + ", ".join(sorted(SUPPORTED_EXTENSION_CHANNELS))
        )
    resolved_extension_id = str(extension_id or "").strip() or (
        default_extension_id_for_channel(resolved_extension_channel) or ""
    )
    if not resolved_extension_id:
        raise RuntimeError(
            "extension_id must not be empty for the selected extension channel"
        )
    resolved_native_host_name = (
        str(native_host_name or DEFAULT_NATIVE_HOST_NAME).strip()
        or DEFAULT_NATIVE_HOST_NAME
    )
    launcher_dir = Path.home() / ".skyline" / "browser-host"
    ensure_owner_only_directory(launcher_dir)
    launcher_path = launcher_dir / f"{resolved_native_host_name}.sh"
    resolved_skyline_path = _preferred_skyline_cli_path()
    write_owner_only_text(
        launcher_path,
        "\n".join(
            [
                "#!/bin/sh",
                "set -eu",
                *(
                    [
                        f"SKYLINE_CLI='{resolved_skyline_path}'",
                        'if [ ! -x "$SKYLINE_CLI" ]; then',
                        '  echo "error: Skyline requester CLI is not installed" >&2',
                        "  exit 1",
                        "fi",
                    ]
                    if resolved_skyline_path
                    else [
                        'export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"',
                        "if command -v skyline >/dev/null 2>&1; then",
                        '  SKYLINE_CLI="$(command -v skyline)"',
                        "else",
                        '  echo "error: Skyline requester CLI is not installed" >&2',
                        "  exit 1",
                        "fi",
                    ]
                ),
                'exec "$SKYLINE_CLI" browser-host --config-path '
                f"'{config_path}' native-host \"$@\"",
                "",
            ]
        )
    )
    launcher_path.chmod(stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)

    manifest_dir = _native_manifest_dir(browser)
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = manifest_dir / f"{resolved_native_host_name}.json"
    manifest_path.write_text(
        json.dumps(
            {
                "name": resolved_native_host_name,
                "description": "Skyline browser companion native host",
                "path": str(launcher_path),
                "type": "stdio",
                "allowed_origins": [f"chrome-extension://{resolved_extension_id}/"],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )

    config.update(
        {
            "extension_id": resolved_extension_id,
            "extension_channel": resolved_extension_channel,
            "runtime_config_path": str(config_path.expanduser()),
            "native_host_name": resolved_native_host_name,
            "browser": browser,
            "native_host_manifest_path": str(manifest_path),
            "native_host_launcher_path": str(launcher_path),
        }
    )
    if requester_config_path is not None:
        config["requester_config_path"] = str(Path(requester_config_path).expanduser())
    if requester_socket_path is not None:
        config["requester_socket_path"] = requester_socket_path
    for runtime_key in NATIVE_HOST_RUNTIME_CONFIG_KEYS:
        config.pop(runtime_key, None)
    save_helper_metadata(config_path, config)
    return config


def _write_native_message(payload: dict[str, Any]) -> None:
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode(
        "utf-8"
    )
    sys.stdout.buffer.write(struct.pack("@I", len(payload_bytes)))
    sys.stdout.buffer.write(payload_bytes)
    sys.stdout.buffer.flush()


def _read_native_message() -> dict[str, Any] | None:
    header = sys.stdin.buffer.read(4)
    if not header:
        return None
    if len(header) != 4:
        raise RuntimeError("native host stdin closed mid-message header")
    (length,) = struct.unpack("@I", header)
    payload = sys.stdin.buffer.read(length)
    if len(payload) != length:
        raise RuntimeError("native host stdin closed mid-message payload")
    message = json.loads(payload.decode("utf-8"))
    if not isinstance(message, dict):
        raise RuntimeError("native host message must decode to an object")
    return message


def _debug_log(message: str) -> None:
    log_path = str(os.environ.get("SKYLINE_BROWSER_HOST_DEBUG_LOG") or "").strip()
    if not log_path:
        return
    try:
        path = Path(log_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(f"{int(time.time() * 1000)} {message}\n")
    except Exception:
        return


def _skip_runtime_config_hardening() -> bool:
    return os.environ.get("SKYLINE_BROWSER_HOST_SKIP_CONFIG_HARDENING") == "1"


def _load_runtime_metadata(path: Path) -> dict[str, Any]:
    if not _skip_runtime_config_hardening():
        return load_helper_metadata(path)
    if not path.exists():
        return {"slots": {}}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("browser host config did not decode to an object")
    slots = payload.get("slots")
    payload["slots"] = dict(slots) if isinstance(slots, dict) else {}
    return payload


def _save_runtime_metadata(path: Path, metadata: dict[str, Any]) -> None:
    if not _skip_runtime_config_hardening():
        save_helper_metadata(path, metadata)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def cmd_install_native_host(args: argparse.Namespace) -> int:
    config_path = Path(args.config_path).expanduser()
    config = install_native_host_manifest(
        config_path=config_path,
        browser=args.browser,
        extension_id=(str(args.extension_id or "").strip() or None),
        extension_channel=str(args.extension_channel or DEFAULT_EXTENSION_CHANNEL).strip(),
        native_host_name=str(args.native_host_name or DEFAULT_NATIVE_HOST_NAME).strip(),
    )
    print(f"Installed native host manifest at {config['native_host_manifest_path']}")
    print("Open the Skyline browser extension in Chrome and it should connect automatically.")
    return 0


class BrowserHostRuntime:
    def __init__(self, config_path: Path) -> None:
        self.config_path = config_path
        self.config = dict(_load_runtime_metadata(config_path))
        require_metadata(self.config, "extension_id")
        self._stop_event = Event()
        self._context_lock = Lock()
        self._current_context: dict[str, Any] | None = None
        self._pending_challenge_results: dict[str, Queue[dict[str, Any]]] = {}
        self._pending_challenge_lock = Lock()
        self._pending_fill_results: dict[str, Queue[dict[str, Any]]] = {}
        self._pending_fill_lock = Lock()
        self._popup_action_lock = Lock()
        self._popup_actions: dict[str, PopupActionRecord] = {}
        self._pending_hello_confirmation: dict[str, Any] | None = None
        self._browser_session_token: str | None = None

    def _save(self) -> None:
        _save_runtime_metadata(self.config_path, self.config)

    def _request_transport(self) -> tuple[httpx.BaseTransport, str]:
        socket_path = str(self.config.get("requester_socket_path") or "").strip()
        if not socket_path:
            raise RuntimeError(
                "Skyline is not ready on this machine yet. Run `skyline setup`, then configure the local STDIO MCP bridge."
            )
        return httpx.HTTPTransport(uds=socket_path), "http://local-requester"

    def _local_request_json(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        use_browser_session: bool = True,
    ) -> dict[str, Any]:
        transport, base_url = self._request_transport()
        headers: dict[str, str] = {}
        if use_browser_session and self._browser_session_token:
            headers[BROWSER_SESSION_HEADER] = self._browser_session_token
        with httpx.Client(
            transport=transport,
            base_url=base_url,
            timeout=60.0,
        ) as client:
            response = client.request(method, path, json=json_body, headers=headers)
        if response.status_code >= 400:
            try:
                payload = response.json()
            except Exception:
                payload = None
            message = None
            if isinstance(payload, dict):
                message = (
                    str(payload.get("message") or "").strip()
                    or str(payload.get("error") or "").strip()
                    or None
                )
            raise RuntimeError(message or response.text or "local browser companion request failed")
        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError("local browser companion response was not an object")
        return payload

    def _apply_browser_action_status(
        self,
        payload: dict[str, Any] | None,
    ) -> dict[str, Any]:
        data = dict(payload or {})
        if "browser_action_ready" in data:
            self.config["browser_action_ready"] = bool(data.get("browser_action_ready"))
        self._save()
        return self._browser_action_status_fields()

    def _browser_action_status_fields(
        self,
    ) -> dict[str, Any]:
        return {
            "browser_action_ready": bool(self.config.get("browser_action_ready")),
        }

    def _destination_context(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "target_kind": "browser_profile",
            "browser_context_id": browser_context_id(context),
            "browser_channel_id": context["browser_channel_id"],
            "tab_id": context["tab_id"],
            "window_id": context["window_id"],
            "page_url": context["page_url"],
            "page_title": context["page_title"],
            "top_level_origin": context["top_level_origin"],
            "frame_id": context["frame_id"],
            "frame_origin": context["frame_origin"],
            "form_session_id": context["form_session_id"],
        }

    def _current_context_snapshot(self) -> dict[str, Any] | None:
        with self._context_lock:
            if self._current_context is None:
                return None
            return dict(self._current_context)

    def _set_current_context(self, context: dict[str, Any] | None) -> None:
        with self._context_lock:
            self._current_context = dict(context) if context is not None else None

    def _sync_browser_context(self, payload: dict[str, Any]) -> None:
        delivery_target_id = str(self.config.get("delivery_target_id") or "").strip()
        if not delivery_target_id:
            raise RuntimeError("browser companion has not completed hello yet")
        browser_context = {
            "delivery_target_id": delivery_target_id,
            "browser_channel_id": str(
                payload.get("browser_channel_id")
                or self.config.get("browser_channel_id")
                or DEFAULT_BROWSER_CHANNEL_ID
            ),
            "browser_name": str(
                payload.get("browser_name")
                or self.config.get("browser_name")
                or DEFAULT_BROWSER_NAME
            ),
            "profile_label": str(
                payload.get("profile_label")
                or self.config.get("profile_label")
                or DEFAULT_PROFILE_LABEL
            ),
            "extension_id": str(payload.get("extension_id") or self.config.get("extension_id") or ""),
            "extension_channel": str(payload.get("extension_channel") or self.config.get("extension_channel") or DEFAULT_EXTENSION_CHANNEL),
            "extension_version": str(payload.get("extension_version") or "").strip() or None,
            "tab_id": int(payload["tab_id"]),
            "window_id": int(payload["window_id"]),
            "page_url": str(payload["page_url"]),
            "page_title": str(payload.get("page_title") or ""),
            "top_level_origin": str(payload["top_level_origin"]),
            "frame_id": int(payload["frame_id"]),
            "frame_origin": str(payload["frame_origin"]),
            "form_session_id": str(payload["form_session_id"]),
            "field_summary": dict(payload.get("field_summary") or {}),
            "last_seen_at_epoch_ms": int(
                payload.get("last_seen_at_epoch_ms") or int(time.time() * 1000)
            ),
        }
        self._set_current_context(browser_context)
        self._local_request_json(
            "POST",
            "/v1/local-requester/browser-companion/browser-contexts",
            json_body=browser_context,
        )

    def _clear_browser_context(self) -> None:
        delivery_target_id = str(self.config.get("delivery_target_id") or "").strip()
        if not delivery_target_id:
            self._set_current_context(None)
            return
        try:
            browser_channel_id = str(
                self.config.get("browser_channel_id") or DEFAULT_BROWSER_CHANNEL_ID
            )
            self._local_request_json(
                "DELETE",
                (
                    "/v1/local-requester/browser-companion/browser-contexts/"
                    f"{delivery_target_id}?browser_channel_id={browser_channel_id}"
                ),
            )
        finally:
            self._set_current_context(None)

    def _popup_action_snapshot(self, action: PopupActionRecord) -> dict[str, Any]:
        return {
            "action_id": action.action_id,
            "action_type": action.action_type,
            "request_id": action.request_id,
            "field_name": action.field_name,
            "item_id": action.item_id,
            "item_title": action.item_title,
            "status": action.status,
            "message": action.message,
            "approval_id": action.approval_id,
            "result_type": action.result_type,
        }

    def _update_popup_action(
        self,
        action_id: str,
        *,
        status: str,
        message: str | None = None,
        approval_id: str | None = None,
        result_type: str | None = None,
    ) -> None:
        with self._popup_action_lock:
            action = self._popup_actions.get(action_id)
            if action is None:
                return
            action.status = status
            action.message = message
            if approval_id is not None:
                action.approval_id = approval_id
            if result_type is not None:
                action.result_type = result_type
            snapshot = self._popup_action_snapshot(action)
        _write_native_message({"type": "action_update", "action": snapshot})

    def _start_popup_action(
        self,
        *,
        action_type: str,
        request_id: str,
        field_name: str | None,
        item_id: str | None,
        item_title: str | None,
        initial_status: str,
        initial_message: str | None,
        approval_id: str | None,
        result_type: str | None = None,
    ) -> dict[str, Any]:
        action = PopupActionRecord(
            action_id=f"browser_action_{uuid.uuid4().hex}",
            action_type=action_type,
            request_id=request_id,
            field_name=field_name,
            item_id=item_id,
            item_title=item_title,
            status=initial_status,
            message=initial_message,
            approval_id=approval_id,
            result_type=result_type,
        )
        with self._popup_action_lock:
            self._popup_actions[action.action_id] = action
        Thread(
            target=self._monitor_popup_action,
            args=(action.action_id, request_id),
            daemon=True,
        ).start()
        return self._popup_action_snapshot(action)

    def _monitor_popup_action(self, action_id: str, request_id: str) -> None:
        while not self._stop_event.is_set():
            try:
                payload = self._local_request_json(
                    "GET",
                    (
                        "/v1/local-requester/browser-companion/popup/requests/"
                        f"{request_id}/wait"
                        f"?delivery_target_id={self.config.get('delivery_target_id')}"
                        f"&browser_channel_id={self.config.get('browser_channel_id') or DEFAULT_BROWSER_CHANNEL_ID}"
                        f"&timeout_ms={REQUEST_WAIT_TIMEOUT_MS}"
                    ),
                )
            except Exception as error:
                self._update_popup_action(
                    action_id,
                    status="failed",
                    message=f"Failed to refresh request status: {error}",
                )
                return
            status = str(payload.get("status") or "").strip() or "processing"
            approval = payload.get("approval") if isinstance(payload.get("approval"), dict) else None
            approval_id = (
                str(approval.get("approval_id") or "").strip() if approval is not None else None
            ) or None
            message = None
            resolution = payload.get("resolution")
            if isinstance(resolution, dict):
                message = str(resolution.get("reason") or "").strip() or None
            result = payload.get("result")
            result_type = (
                str(result.get("result_type") or "").strip()
                if isinstance(result, dict)
                else None
            ) or None
            self._update_popup_action(
                action_id,
                status=status,
                message=message,
                approval_id=approval_id,
                result_type=result_type,
            )
            if status not in {"processing", "approval_required"}:
                return
            time.sleep(ACTION_POLL_DELAY_SECONDS)

    def _fetch_popup_candidates(
        self,
        delivery_target_id: str | None = None,
    ) -> dict[str, Any]:
        payload = self._local_request_json(
            "POST",
            "/v1/local-requester/browser-companion/popup/login-candidates",
            json_body={
                "delivery_target_id": delivery_target_id,
                "browser_channel_id": str(
                    self.config.get("browser_channel_id") or DEFAULT_BROWSER_CHANNEL_ID
                ),
            },
        )
        self._apply_browser_action_status(payload)
        return {
            **payload,
            **self._browser_action_status_fields(),
        }

    def _submit_popup_fill(
        self,
        *,
        delivery_target_id: str | None,
        selection_hint: dict[str, Any] | None,
    ) -> dict[str, Any]:
        payload = self._local_request_json(
            "POST",
            "/v1/local-requester/browser-companion/popup/fill",
            json_body={
                "delivery_target_id": delivery_target_id,
                "selection_hint": selection_hint,
                "browser_channel_id": str(
                    self.config.get("browser_channel_id") or DEFAULT_BROWSER_CHANNEL_ID
                ),
            },
        )
        self._apply_browser_action_status(payload)
        request_id = str(payload.get("request_id") or "").strip()
        if not request_id:
            return {
                "request": payload,
                "action": None,
                **self._browser_action_status_fields(),
            }
        item = payload.get("approval", {}).get("request", {}).get("prepared_result", {}).get("item")
        item_id = None
        item_title = None
        if isinstance(item, dict):
            item_id = str(item.get("item_id") or "").strip() or None
            item_title = str(item.get("title") or "").strip() or None
        action = self._start_popup_action(
            action_type="fill",
            request_id=request_id,
            field_name=None,
            item_id=item_id,
            item_title=item_title,
            initial_status=str(payload.get("status") or "processing"),
            initial_message=None,
            approval_id=(
                str(payload.get("approval", {}).get("approval_id") or "").strip() or None
                if isinstance(payload.get("approval"), dict)
                else None
            ),
            result_type=None,
        )
        return {
            "request": payload,
            "action": action,
            **self._browser_action_status_fields(),
        }

    def _poll_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                delivery_target_id = str(self.config.get("delivery_target_id") or "").strip()
                if not delivery_target_id:
                    time.sleep(POLL_INTERVAL_SECONDS)
                    continue
                job_payload = self._local_request_json(
                    "GET",
                    (
                        "/v1/local-requester/browser-companion/delivery-jobs/next"
                        f"?delivery_target_id={delivery_target_id}"
                        f"&browser_channel_id={self.config.get('browser_channel_id') or DEFAULT_BROWSER_CHANNEL_ID}"
                    ),
                )
                job = job_payload.get("delivery_job")
                if isinstance(job, dict):
                    self._handle_delivery_job(job)
            except Exception:
                time.sleep(POLL_INTERVAL_SECONDS)
            time.sleep(POLL_INTERVAL_SECONDS)

    def _ack_delivery_job(
        self,
        *,
        job_id: str,
        status: str,
        message: str | None,
    ) -> None:
        self._local_request_json(
            "POST",
            (
                "/v1/local-requester/browser-companion/delivery-jobs/"
                f"{job_id}/ack?browser_channel_id={self.config.get('browser_channel_id') or DEFAULT_BROWSER_CHANNEL_ID}"
            ),
            json_body={
                "status": status,
                "message": message,
            },
        )

    def _handle_delivery_job(self, job: dict[str, Any]) -> None:
        job_id = str(job.get("job_id") or "")
        context = self._current_context_snapshot()
        if not context:
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_target_mismatch",
                message="no live browser context matched the approved inject destination",
            )
            return
        payload = dict(job.get("payload") or {})
        if not payload:
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_failed",
                message="browser companion did not receive a decrypted delivery payload",
            )
            return
        expected_context = self._destination_context(context)
        if (
            str(payload.get("target_kind") or "") != "browser_profile"
            or str(payload.get("delivery_target_id") or "") != str(self.config.get("delivery_target_id") or "")
            or payload.get("destination_context") != expected_context
        ):
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_target_mismatch",
                message="browser page or form changed before inject delivery",
            )
            return
        challenge = build_one_time_challenge(
            destination_context=expected_context,
            ttl_ms=int(CHALLENGE_TIMEOUT_SECONDS * 1000),
            now_epoch_ms=int(time.time() * 1000),
        )
        challenge_queue: Queue[dict[str, Any]] = Queue(maxsize=1)
        with self._pending_challenge_lock:
            self._pending_challenge_results[challenge["challenge_id"]] = challenge_queue
        _write_native_message(
            {
                "type": "fill_challenge",
                "job_id": job_id,
                "challenge_id": challenge["challenge_id"],
                "challenge_nonce": challenge["challenge_nonce"],
                "browser_context_id": expected_context["browser_context_id"],
                "destination_context": expected_context,
            }
        )
        try:
            challenge_result = challenge_queue.get(timeout=CHALLENGE_TIMEOUT_SECONDS)
        except Empty:
            with self._pending_challenge_lock:
                self._pending_challenge_results.pop(challenge["challenge_id"], None)
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_failed",
                message="browser extension did not confirm the live form in time",
            )
            return
        if (
            str(challenge_result.get("challenge_id") or "").strip()
            != challenge["challenge_id"]
            or str(challenge_result.get("challenge_nonce") or "").strip()
            != challenge["challenge_nonce"]
        ):
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_failed",
                message="browser challenge response did not match the expected one-time nonce",
            )
            return
        challenge_status = str(challenge_result.get("status") or "").strip()
        challenge_message = str(challenge_result.get("message") or "").strip() or None
        if challenge_status != "ready":
            self._ack_delivery_job(
                job_id=job_id,
                status=(
                    "inject_target_mismatch"
                    if challenge_status == "target_mismatch"
                    else "inject_failed"
                ),
                message=challenge_message or "browser challenge failed",
            )
            return
        fill_queue: Queue[dict[str, Any]] = Queue(maxsize=1)
        with self._pending_fill_lock:
            self._pending_fill_results[job_id] = fill_queue
        _write_native_message(
            {
                "type": "fill",
                "job_id": job_id,
                "delivery_target_id": self.config.get("delivery_target_id"),
                "destination_context": expected_context,
                "browser_context_id": expected_context["browser_context_id"],
                "username_value": payload.get("username_value"),
                "password_value": payload.get("secret_value"),
            }
        )
        try:
            result = fill_queue.get(timeout=FILL_TIMEOUT_SECONDS)
        except Empty:
            with self._pending_fill_lock:
                self._pending_fill_results.pop(job_id, None)
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_failed",
                message="browser extension did not acknowledge the fill request in time",
            )
            return
        status = str(result.get("status") or "").strip()
        message = str(result.get("message") or "").strip() or None
        if status == "filled":
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_delivered",
                message=message,
            )
            return
        if status == "target_mismatch":
            self._ack_delivery_job(
                job_id=job_id,
                status="inject_target_mismatch",
                message=message,
            )
            return
        self._ack_delivery_job(
            job_id=job_id,
            status="inject_failed",
            message=message or "browser fill failed",
        )

    def _handle_challenge_result(self, payload: dict[str, Any]) -> None:
        challenge_id = str(payload.get("challenge_id") or "").strip()
        if not challenge_id:
            return
        with self._pending_challenge_lock:
            challenge_queue = self._pending_challenge_results.pop(challenge_id, None)
        if challenge_queue is not None:
            challenge_queue.put(payload)

    def _handle_fill_result(self, payload: dict[str, Any]) -> None:
        job_id = str(payload.get("job_id") or "").strip()
        if not job_id:
            return
        with self._pending_fill_lock:
            fill_queue = self._pending_fill_results.pop(job_id, None)
        if fill_queue is not None:
            fill_queue.put(payload)

    def _handle_hello(self, payload: dict[str, Any]) -> None:
        extension_id = str(payload.get("extension_id") or "").strip()
        if extension_id != str(self.config.get("extension_id") or "").strip():
            raise RuntimeError("extension_id did not match the installed native host manifest")
        extension_channel = str(payload.get("extension_channel") or "").strip()
        configured_channel = str(self.config.get("extension_channel") or DEFAULT_EXTENSION_CHANNEL)
        if extension_channel and extension_channel != configured_channel:
            raise RuntimeError("extension_channel did not match the helper configuration")
        browser_channel_id = str(payload.get("browser_channel_id") or "").strip()
        if not browser_channel_id:
            raise RuntimeError("browser hello did not include a browser_channel_id")
        if (
            self._browser_session_token
            and str(self.config.get("delivery_target_id") or "").strip()
            and browser_channel_id == str(self.config.get("browser_channel_id") or "").strip()
        ):
            _write_native_message(
                {
                    "type": "hello_ack",
                    "delivery_target_id": self.config.get("delivery_target_id"),
                    "browser_channel_id": browser_channel_id,
                    **self._browser_action_status_fields(),
                }
            )
            return
        response = self._local_request_json(
            "POST",
            "/v1/local-requester/browser-companion/hello",
            json_body={
                "browser_channel_id": browser_channel_id,
                "browser_name": str(self.config.get("browser_name") or DEFAULT_BROWSER_NAME),
                "profile_label": str(self.config.get("profile_label") or DEFAULT_PROFILE_LABEL),
                "extension_id": extension_id,
                "extension_channel": extension_channel or configured_channel,
                "extension_version": str(payload.get("extension_version") or "").strip() or None,
                "native_host_name": str(
                    self.config.get("native_host_name") or DEFAULT_NATIVE_HOST_NAME
                ),
            },
            use_browser_session=False,
        )
        hello_challenge = (
            dict(response.get("hello_challenge") or {})
            if isinstance(response.get("hello_challenge"), dict)
            else None
        )
        challenge_id = str((hello_challenge or {}).get("challenge_id") or "").strip()
        challenge_nonce = str((hello_challenge or {}).get("challenge_nonce") or "").strip()
        if not challenge_id or not challenge_nonce:
            raise RuntimeError("browser companion hello did not return a valid one-time challenge")
        self._pending_hello_confirmation = {
            "browser_channel_id": browser_channel_id,
            "challenge_id": challenge_id,
            "challenge_nonce": challenge_nonce,
        }
        self.config["extension_version"] = str(payload.get("extension_version") or "").strip() or None
        self._save()
        _write_native_message(
            {
                "type": "hello_challenge",
                "browser_channel_id": browser_channel_id,
                "challenge_id": challenge_id,
                "challenge_nonce": challenge_nonce,
                "expires_at_epoch_ms": hello_challenge.get("expires_at_epoch_ms"),
            }
        )

    def _handle_hello_confirm(self, payload: dict[str, Any]) -> None:
        pending = dict(self._pending_hello_confirmation or {})
        if not pending:
            raise RuntimeError("browser companion hello confirmation arrived without a pending challenge")
        browser_channel_id = str(payload.get("browser_channel_id") or "").strip()
        challenge_id = str(payload.get("challenge_id") or "").strip()
        challenge_nonce = str(payload.get("challenge_nonce") or "").strip()
        if (
            browser_channel_id != str(pending.get("browser_channel_id") or "").strip()
            or challenge_id != str(pending.get("challenge_id") or "").strip()
            or challenge_nonce != str(pending.get("challenge_nonce") or "").strip()
        ):
            raise RuntimeError("browser companion hello confirmation did not match the expected challenge")
        response = self._local_request_json(
            "POST",
            "/v1/local-requester/browser-companion/hello/confirm",
            json_body={
                "browser_channel_id": browser_channel_id,
                "challenge_id": challenge_id,
                "challenge_nonce": challenge_nonce,
            },
            use_browser_session=False,
        )
        delivery_target_id = str(response.get("delivery_target_id") or "").strip()
        browser_session_token = str(response.get("browser_session_token") or "").strip()
        if not delivery_target_id or not browser_session_token:
            raise RuntimeError("browser companion hello confirm did not return delivery target routing")
        self._pending_hello_confirmation = None
        self._browser_session_token = browser_session_token
        self.config["browser_channel_id"] = browser_channel_id
        self.config["delivery_target_id"] = delivery_target_id
        self._apply_browser_action_status(response)
        self._save()
        _write_native_message(
            {
                "type": "hello_ack",
                "delivery_target_id": delivery_target_id,
                "browser_channel_id": browser_channel_id,
                **self._browser_action_status_fields(),
            }
        )

    def run(self, origin: str | None) -> int:
        expected_origin = f"chrome-extension://{self.config.get('extension_id')}/"
        _debug_log(f"start origin={origin!r} expected={expected_origin!r}")
        if origin is not None and origin.strip() and origin.strip() != expected_origin:
            raise RuntimeError(
                f"native host expected caller origin {expected_origin!r}, got {origin.strip()!r}"
            )
        poller = Thread(target=self._poll_loop, daemon=True)
        poller.start()
        try:
            while not self._stop_event.is_set():
                message = _read_native_message()
                if message is None:
                    _debug_log("stdin_closed")
                    break
                message_type = str(message.get("type") or "").strip()
                _debug_log(f"message type={message_type!r}")
                if message_type == "hello":
                    self._handle_hello(message)
                elif message_type == "hello_confirm":
                    self._handle_hello_confirm(message)
                elif message_type == "context.upsert":
                    self._sync_browser_context(message)
                    _write_native_message({"type": "context_ack"})
                elif message_type == "context.clear":
                    self._clear_browser_context()
                    _write_native_message({"type": "context_cleared"})
                elif message_type == "challenge_result":
                    self._handle_challenge_result(message)
                elif message_type == "fill_result":
                    self._handle_fill_result(message)
                elif message_type == "popup.resolve_candidates":
                    response: dict[str, Any]
                    try:
                        response = self._fetch_popup_candidates(
                            delivery_target_id=(
                                str(message.get("delivery_target_id") or "").strip() or None
                            )
                        )
                    except Exception as error:
                        response = {
                            "status": "error",
                            "message": str(error),
                            "candidates": [],
                            "browser_context": None,
                        }
                    _write_native_message(
                        {
                            "type": "popup_candidates_result",
                            "request_id": message.get("request_id"),
                            "payload": response,
                        }
                    )
                elif message_type == "popup.start_fill":
                    try:
                        response = self._submit_popup_fill(
                            delivery_target_id=(
                                str(message.get("delivery_target_id") or "").strip() or None
                            ),
                            selection_hint=(
                                dict(message.get("selection_hint") or {})
                                if isinstance(message.get("selection_hint"), dict)
                                else None
                            ),
                        )
                    except Exception as error:
                        response = {
                            "request": {"status": "error", "message": str(error)},
                            "action": None,
                        }
                    _write_native_message(
                        {
                            "type": "popup_action_started",
                            "request_id": message.get("request_id"),
                            "payload": response,
                        }
                    )
                elif message_type == "ping":
                    _write_native_message({"type": "pong"})
        except Exception as error:
            _debug_log(f"error {type(error).__name__}: {error}")
            raise
        finally:
            self._stop_event.set()
            poller.join(timeout=1.0)
        return 0


def cmd_native_host(args: argparse.Namespace) -> int:
    runtime = BrowserHostRuntime(Path(args.config_path).expanduser())
    return runtime.run(args.origin)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Skyline Chrome browser companion native host")
    parser.set_defaults(func=None)
    parser.add_argument(
        "--config-path",
        default=str(DEFAULT_CONFIG_PATH),
        help="Path to browser-host helper config JSON (default: %(default)s)",
    )
    parser.add_argument(
        "--bootstrap-secret-file",
        help="Reserved for parity with CLI helper setup; browser hosts do not use encrypted-file storage.",
    )
    subparsers = parser.add_subparsers(dest="command")

    install_parser = subparsers.add_parser(
        "install-native-host",
        help="Install the Chrome native messaging host manifest pinned to one extension id",
    )
    install_parser.add_argument("--extension-id")
    install_parser.add_argument("--extension-channel", default=DEFAULT_EXTENSION_CHANNEL)
    install_parser.add_argument("--native-host-name", default=DEFAULT_NATIVE_HOST_NAME)
    install_parser.add_argument("--browser", default="chrome")
    install_parser.add_argument("--base-url", required=False)
    install_parser.set_defaults(func=cmd_install_native_host)

    native_host_parser = subparsers.add_parser(
        "native-host",
        help="Run the stdio native messaging host process (normally launched by Chrome)",
    )
    native_host_parser.add_argument("origin", nargs="?")
    native_host_parser.set_defaults(func=cmd_native_host)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.func is None:
        parser.print_help()
        return 2
    try:
        return int(args.func(args) or 0)
    except Exception as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
