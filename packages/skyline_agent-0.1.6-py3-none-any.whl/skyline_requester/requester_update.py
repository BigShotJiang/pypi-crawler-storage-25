from __future__ import annotations

import importlib.metadata
import os
import re
import shlex
import shutil
import subprocess
import tomllib
from pathlib import Path
from typing import Any


REQUESTER_CLI_DISTRIBUTION_NAME = "skyline-agent"
REQUESTER_CLI_PACKAGE_ENV = "SKYLINE_REQUESTER_CLI_PACKAGE"
REQUESTER_CLI_INDEX_URL_ENV = "SKYLINE_REQUESTER_CLI_INDEX_URL"
REQUESTER_CLI_MIN_VERSION_ENV = "SKYLINE_REQUESTER_CLI_MIN_VERSION"
REQUESTER_CLI_RECOMMENDED_VERSION_ENV = "SKYLINE_REQUESTER_CLI_RECOMMENDED_VERSION"
REQUESTER_CLI_UPDATE_MESSAGE_ENV = "SKYLINE_REQUESTER_CLI_UPDATE_MESSAGE"
DEFAULT_REQUESTER_CLI_PACKAGE = REQUESTER_CLI_DISTRIBUTION_NAME
PUBLIC_REQUESTER_CLI_SPEC_RE = re.compile(
    rf"^{re.escape(REQUESTER_CLI_DISTRIBUTION_NAME)}"
    r"(?:\s*==\s*[A-Za-z0-9][A-Za-z0-9._!+\-]*)?$"
)


class RequesterCliPackageConfigError(RuntimeError):
    pass


def requester_cli_package_spec() -> str:
    package_spec = str(os.environ.get(REQUESTER_CLI_PACKAGE_ENV) or "").strip()
    return package_spec or DEFAULT_REQUESTER_CLI_PACKAGE


def requester_cli_index_url() -> str | None:
    return str(os.environ.get(REQUESTER_CLI_INDEX_URL_ENV) or "").strip() or None


def is_public_requester_cli_package_spec(package_spec: str | None) -> bool:
    normalized = str(package_spec or "").strip() or DEFAULT_REQUESTER_CLI_PACKAGE
    return PUBLIC_REQUESTER_CLI_SPEC_RE.fullmatch(normalized) is not None


def _local_package_dir(package_spec: str) -> Path | None:
    if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", package_spec):
        return None
    candidate = Path(os.path.expanduser(package_spec))
    if not candidate.is_absolute() or not candidate.is_dir():
        return None
    return candidate


def _local_package_declares_skyline_agent(package_dir: Path) -> bool:
    pyproject = package_dir / "pyproject.toml"
    if not pyproject.is_file():
        return False
    try:
        payload = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return False
    project = payload.get("project")
    if not isinstance(project, dict):
        return False
    return str(project.get("name") or "").strip() == REQUESTER_CLI_DISTRIBUTION_NAME


def is_local_requester_cli_package_spec(package_spec: str | None) -> bool:
    normalized = str(package_spec or "").strip()
    if not normalized:
        return False
    package_dir = _local_package_dir(normalized)
    return package_dir is not None and _local_package_declares_skyline_agent(package_dir)


def validate_requester_cli_package_config(
    *,
    allow_local_package_override: bool = False,
) -> None:
    package_spec = requester_cli_package_spec()
    index_url = requester_cli_index_url()
    if is_public_requester_cli_package_spec(package_spec) and index_url is None:
        return
    if (
        allow_local_package_override
        and index_url is None
        and is_local_requester_cli_package_spec(package_spec)
    ):
        return
    if index_url is not None:
        raise RequesterCliPackageConfigError(
            f"{REQUESTER_CLI_INDEX_URL_ENV} is not allowed for generated setup scripts"
        )
    if is_local_requester_cli_package_spec(package_spec):
        raise RequesterCliPackageConfigError(
            f"{REQUESTER_CLI_PACKAGE_ENV} points at a local package; this requires an explicit local-dev setup mode"
        )
    raise RequesterCliPackageConfigError(
        f"{REQUESTER_CLI_PACKAGE_ENV} must be {REQUESTER_CLI_DISTRIBUTION_NAME} or a verified local {REQUESTER_CLI_DISTRIBUTION_NAME} package"
    )


def installed_requester_cli_version() -> str | None:
    for distribution_name in (REQUESTER_CLI_DISTRIBUTION_NAME, "aperture-core"):
        try:
            return importlib.metadata.version(distribution_name)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def requester_cli_update_command_parts(
    *,
    package_spec: str | None = None,
    index_url: str | None = None,
) -> list[str]:
    resolved_package_spec = package_spec or requester_cli_package_spec()
    command = ["uv", "tool", "install", "--force"]
    if is_local_requester_cli_package_spec(resolved_package_spec):
        command.append("--reinstall")
    resolved_index_url = requester_cli_index_url() if index_url is None else index_url
    if resolved_index_url:
        command.extend(["--default-index", resolved_index_url])
    command.append(resolved_package_spec)
    return command


def requester_cli_update_command(
    *,
    package_spec: str | None = None,
    index_url: str | None = None,
) -> str:
    return " ".join(
        shlex.quote(part)
        for part in requester_cli_update_command_parts(
            package_spec=package_spec,
            index_url=index_url,
        )
    )


def _version_parts(value: str | None) -> tuple[int, ...] | None:
    if not value:
        return None
    matches = re.findall(r"\d+", value)
    if not matches:
        return None
    return tuple(int(part) for part in matches)


def version_is_less_than(current_version: str | None, target_version: str | None) -> bool:
    current_parts = _version_parts(current_version)
    target_parts = _version_parts(target_version)
    if current_parts is None or target_parts is None:
        return False
    width = max(len(current_parts), len(target_parts))
    padded_current = current_parts + (0,) * (width - len(current_parts))
    padded_target = target_parts + (0,) * (width - len(target_parts))
    return padded_current < padded_target


def requester_cli_policy_from_env() -> dict[str, str | None]:
    return {
        "minimum_version": str(os.environ.get(REQUESTER_CLI_MIN_VERSION_ENV) or "").strip() or None,
        "recommended_version": str(os.environ.get(REQUESTER_CLI_RECOMMENDED_VERSION_ENV) or "").strip() or None,
        "message": str(os.environ.get(REQUESTER_CLI_UPDATE_MESSAGE_ENV) or "").strip() or None,
    }


def build_requester_cli_update_status(
    *,
    current_version: str | None = None,
    minimum_version: str | None = None,
    recommended_version: str | None = None,
    message: str | None = None,
    policy_check_error: str | None = None,
) -> dict[str, Any]:
    installed_version = current_version if current_version is not None else installed_requester_cli_version()
    status = "current"
    target_version = None
    if version_is_less_than(installed_version, minimum_version):
        status = "required"
        target_version = minimum_version
    elif version_is_less_than(installed_version, recommended_version):
        status = "recommended"
        target_version = recommended_version
    elif installed_version is None:
        status = "unknown"
    if policy_check_error:
        status = "unknown"

    guidance = {
        "status": status,
        "package": requester_cli_package_spec(),
        "installed_version": installed_version,
        "minimum_version": minimum_version,
        "recommended_version": recommended_version,
        "target_version": target_version,
        "message": message,
        "update_command": requester_cli_update_command(),
        "restart_required": True,
        "restart_guidance": (
            "After updating, restart any agent app or MCP session that is running "
            "`skyline bridge serve` so it loads the new CLI code."
        ),
    }
    if policy_check_error:
        guidance["policy_check_error"] = policy_check_error
    return guidance


def run_requester_cli_update() -> tuple[int, list[str]]:
    command = requester_cli_update_command_parts()
    if shutil.which("uv") is None:
        return 127, command
    completed = subprocess.run(command, check=False)
    return int(completed.returncode), command
