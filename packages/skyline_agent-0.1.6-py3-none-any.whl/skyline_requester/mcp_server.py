from __future__ import annotations

import asyncio
import hmac
import hashlib
import json
import os
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from dataclasses import dataclass
from typing import Any, Callable

import httpx
from mcp.server.auth.middleware.auth_context import (
    get_access_token as get_authenticated_access_token,
)
from mcp.server.auth.provider import AccessToken, TokenVerifier
from mcp.server.auth.settings import AuthSettings
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings

from .delivery_crypto import DELIVERY_KEY_ALGORITHM
from .client_side_secret_writes import (
    build_client_side_protected_write_payload,
    should_refetch_key_holders_for_write_error,
    with_client_side_presence_metadata,
)
from .release_features import chrome_extension_browser_companion_enabled
from .requester_update import installed_requester_cli_version
from .secret_custody import RecipientKeyReference


AsyncClientFactory = Callable[[], AbstractAsyncContextManager[httpx.AsyncClient]]
CoreRequestHeadersFactory = Callable[
    [str, str, dict[str, Any] | None, dict[str, Any] | None],
    dict[str, str],
]
SyncCoreRequestFactory = Callable[
    [str, str, dict[str, Any] | None, dict[str, Any] | None],
    dict[str, Any],
]
SyncConnectFactory = Callable[[], dict[str, Any]]
SyncUpdateInstructionsFactory = Callable[[], dict[str, Any]]
SessionIdResolver = Callable[[], str | None]


DEFAULT_MCP_HOST = "127.0.0.1"
DEFAULT_MCP_PORT = 8788
DEFAULT_MCP_STREAMABLE_HTTP_PATH = "/mcp"
# This default must stay above the core's inline response window for
# request-backed operations, otherwise the MCP bridge can time out before the
# core returns the initial request record. We intentionally left margin above the
# current ~45s inline window instead of pushing right up against the shortest
# observed host deadline, because wrapper/transport variance can consume the last
# few seconds. Tradeoff: because this HTTP timeout is shared by MCP-to-core calls
# generally, raising it also means some genuinely hung or failing core calls may
# take longer to surface as errors. Future tuning should weigh async request UX
# against slower failure visibility for ordinary calls.
DEFAULT_CORE_TIMEOUT_SECONDS = 60.0
# Keep the MCP follow-up semantics aligned with the core request model:
# - `processing` means Skyline has accepted the request and is still waiting on
#   internal work or a downstream service result. No human action is currently
#   required.
# - `approval_required` is reserved for pending human authorizer action and
#   should be returned promptly once created, not held open for the remaining
#   inline window.
#
# We return pollable request/task ids instead of assuming callers will hold the
# original MCP call open indefinitely. Different MCP hosts and agent wrappers
# use different deadlines, so future changes here should preserve the ability to
# hand back durable state before the caller gives up on the first request.
# We intentionally do not add a Skyline-specific MCP wait tool here for host
# agents that already have their own wait primitive, because that creates two competing "wait" concepts:
# the host's own wait tool and Skyline's custom one. Plain guidance plus the
# normal request-status tools keeps the model's choice surface simpler.
ASYNC_MCP_STATUS_GUIDANCE = (
    "Async semantics: `processing` means Skyline is still running internal "
    "policy/guardian or downstream service work; use your own "
    "wait/sleep capability if available and then re-check with "
    "`skyline_check_request` when needed. "
    "`approval_required` means Skyline is waiting for human approval and may "
    "take any amount of time; do not treat that as a failure. Try a few short "
    "waits first, then either switch to much longer waits if this request still "
    "matters, or use another viable approach and check back later. If polling "
    "returns `permission_granted_retry_action`, retry the same Skyline tool "
    "when the page, command, or file path is ready."
)
# Real-site probes showed auth flows succeed more often in the user's live tab
# than in fresh/headless profiles, which can lose session state or trigger bot checks.
BROWSER_CURRENT_TAB_GUIDANCE = (
    "Use the current browser tab when possible; avoid fresh/headless profiles."
)


def _with_local_bridge_connect_guidance(payload: dict[str, Any]) -> dict[str, Any]:
    if _payload_status(payload) != "connect_required":
        return payload

    annotated = dict(payload)
    request_id = annotated.get("request_id")
    has_pending_request = isinstance(request_id, str) and bool(request_id.strip())
    if has_pending_request:
        message = (
            "This MCP requester has an older pending connection request. Retry "
            "the original Skyline tool so Skyline can finish registration under "
            "the approved machine."
        )
    else:
        message = (
            "This MCP requester is not registered yet. Retry the original "
            "Skyline tool; after machine setup, requester registration does "
            "not need a second phone approval."
        )
    annotated["message"] = message
    annotated["mcp_follow_up"] = {
        "status": "connect_required",
        "recommended_action": "retry_original_tool",
        "human_action_required": False,
        "message": message,
    }
    return annotated


def _with_client_side_presence_metadata(
    kind: str,
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> dict[str, Any]:
    return with_client_side_presence_metadata(kind, safe_metadata, protected_fields)


def _normalize_binding_selector(binding: dict[str, Any]) -> dict[str, Any] | None:
    raw_selector = binding.get("selector")
    selector = dict(raw_selector) if isinstance(raw_selector, dict) else {}
    for key in ("item_id", "query", "kind"):
        if not selector.get(key) and isinstance(binding.get(key), str):
            selector[key] = binding[key]
    if not selector.get("field_name"):
        field_name = binding.get("field_name")
        if not isinstance(field_name, str) or not field_name.strip():
            field_name = binding.get("field")
        if isinstance(field_name, str) and field_name.strip():
            selector["field_name"] = field_name.strip()
    return selector or None


def _binding_label(binding: dict[str, Any], *, fallback: str) -> str:
    for key in ("binding_name", "name", "var", "env_var", "placeholder"):
        value = binding.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip().strip("{}").strip() or fallback
    selector = _normalize_binding_selector(binding)
    if selector is not None:
        field_name = selector.get("field_name")
        if isinstance(field_name, str) and field_name.strip():
            return field_name.strip()
    return fallback


def _normalize_run_secret_bindings(
    bindings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for index, raw_binding in enumerate(bindings):
        binding = dict(raw_binding)
        selector = _normalize_binding_selector(binding)
        if selector is not None:
            binding["selector"] = selector
        label = _binding_label(binding, fallback=f"binding_{index + 1}")
        if (
            not isinstance(binding.get("binding_name"), str)
            or not binding["binding_name"].strip()
        ):
            binding["binding_name"] = label
        if not isinstance(binding.get("env_var"), str) or not binding["env_var"].strip():
            binding["env_var"] = label
        normalized.append(binding)
    return normalized


def _normalize_render_secret_bindings(
    bindings: list[dict[str, Any]],
    *,
    template_text: str,
) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for index, raw_binding in enumerate(bindings):
        binding = dict(raw_binding)
        selector = _normalize_binding_selector(binding)
        if selector is not None:
            binding["selector"] = selector
        label = _binding_label(binding, fallback=f"binding_{index + 1}")
        if (
            not isinstance(binding.get("binding_name"), str)
            or not binding["binding_name"].strip()
        ):
            binding["binding_name"] = label
        if (
            not isinstance(binding.get("placeholder"), str)
            or not binding["placeholder"].strip()
        ):
            braced_label = "{{" + label + "}}"
            binding["placeholder"] = braced_label if braced_label in template_text else label
        normalized.append(binding)
    return normalized


class SkylineCoreAPIError(RuntimeError):
    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message

@dataclass(slots=True)
class MCPServerConfig:
    core_base_url: str
    access_token: str
    default_session_id: str
    timeout_seconds: float
    host: str
    port: int
    streamable_http_path: str
    inbound_bearer_token: str | None = None
    public_base_url: str | None = None

    @classmethod
    def from_env(
        cls,
        *,
        host: str | None = None,
        port: int | None = None,
        streamable_http_path: str | None = None,
    ) -> "MCPServerConfig":
        access_token = os.environ.get("SKYLINE_MCP_ACCESS_TOKEN", "").strip()
        if not access_token:
            raise RuntimeError(
                "SKYLINE_MCP_ACCESS_TOKEN must be set to a paired requester bearer token"
            )

        core_base_url = os.environ.get(
            "SKYLINE_MCP_CORE_BASE_URL", "http://127.0.0.1:8787"
        ).strip()
        session_id = os.environ.get("SKYLINE_MCP_SESSION_ID", "").strip()
        if not session_id:
            session_id = "session_mcp_" + hashlib.sha256(
                access_token.encode("utf-8")
            ).hexdigest()[:12]

        timeout_text = os.environ.get("SKYLINE_MCP_TIMEOUT_SECONDS", "").strip()
        timeout_seconds = (
            float(timeout_text) if timeout_text else DEFAULT_CORE_TIMEOUT_SECONDS
        )

        path = streamable_http_path or os.environ.get(
            "SKYLINE_MCP_PATH", DEFAULT_MCP_STREAMABLE_HTTP_PATH
        )
        if not path.startswith("/"):
            path = "/" + path

        inbound_bearer_token = (
            os.environ.get("SKYLINE_MCP_SERVER_BEARER_TOKEN", "").strip() or None
        )
        public_base_url = os.environ.get("SKYLINE_MCP_PUBLIC_BASE_URL", "").strip() or None

        return cls(
            core_base_url=core_base_url.rstrip("/"),
            access_token=access_token,
            default_session_id=session_id,
            timeout_seconds=timeout_seconds,
            host=host or os.environ.get("SKYLINE_MCP_HOST", DEFAULT_MCP_HOST),
            port=port
            if port is not None
            else int(os.environ.get("SKYLINE_MCP_PORT", str(DEFAULT_MCP_PORT))),
            streamable_http_path=path,
            inbound_bearer_token=inbound_bearer_token,
            public_base_url=public_base_url.rstrip("/") if public_base_url else None,
        )


class StaticBearerTokenVerifier(TokenVerifier):
    def __init__(self, bearer_token: str) -> None:
        self._bearer_token = bearer_token

    async def verify_token(self, token: str) -> AccessToken | None:
        if not hmac.compare_digest(token, self._bearer_token):
            return None
        return AccessToken(
            token=token,
            client_id="skyline_remote_client",
            scopes=[],
            resource=None,
        )


class DynamicBearerTokenVerifier(TokenVerifier):
    def __init__(self, client_id_resolver: Callable[[str], str | None]) -> None:
        self._client_id_resolver = client_id_resolver

    async def verify_token(self, token: str) -> AccessToken | None:
        client_id = self._client_id_resolver(token)
        if client_id is None:
            return None
        return AccessToken(
            token=token,
            client_id=client_id,
            scopes=[],
            resource=None,
        )


def resolve_resource_server_url(config: MCPServerConfig) -> str:
    if config.public_base_url:
        base_url = config.public_base_url
    else:
        base_url = f"http://{config.host}:{config.port}"
    return base_url.rstrip("/") + config.streamable_http_path


def build_fastmcp_auth_settings(config: MCPServerConfig) -> AuthSettings:
    resource_server_url = resolve_resource_server_url(config)
    return AuthSettings(
        issuer_url=resource_server_url,
        resource_server_url=resource_server_url,
        required_scopes=[],
    )


class SkylineCoreHTTPClient:
    def __init__(
        self,
        config: MCPServerConfig,
        *,
        client_factory: AsyncClientFactory | None = None,
        access_token_resolver: Callable[[], str] | None = None,
        extra_headers: dict[str, str] | None = None,
        request_headers_factory: CoreRequestHeadersFactory | None = None,
    ) -> None:
        self.config = config
        self._client_factory = client_factory or self._default_client_factory
        self._access_token_resolver = access_token_resolver
        self._extra_headers = dict(extra_headers or {})
        self._request_headers_factory = request_headers_factory

    @asynccontextmanager
    async def _default_client_factory(self) -> Any:
        async with httpx.AsyncClient(
            base_url=self.config.core_base_url,
            timeout=self.config.timeout_seconds,
        ) as client:
            yield client

    def _current_access_token(self) -> str:
        if self._access_token_resolver is not None:
            resolved = self._access_token_resolver().strip()
            if resolved:
                return resolved
        configured = self.config.access_token.strip()
        if configured:
            return configured
        access_token = get_authenticated_access_token()
        if access_token is None or not access_token.token.strip():
            raise RuntimeError("requester bearer token is not available for this MCP request")
        return access_token.token.strip()

    def _current_session_id(self) -> str:
        configured = self.config.default_session_id.strip()
        if configured:
            return configured
        access_token = self._current_access_token()
        return "session_mcp_" + hashlib.sha256(
            access_token.encode("utf-8")
        ).hexdigest()[:12]

    def _requester_context(
        self,
        *,
        request_mode: str,
        request_class: str,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "request_mode": request_mode,
            "request_class": request_class,
            "session_id": session_id or self._current_session_id(),
            "skyline_agent_version": installed_requester_cli_version(),
        }
        return payload

    async def list_services(self) -> list[dict[str, Any]]:
        payload = await self._request_json("GET", "/v1/services")
        services = payload.get("services")
        if not isinstance(services, list):
            raise RuntimeError("core returned an invalid services payload")
        return services

    async def list_tools(self, service_id: str | None = None) -> list[dict[str, Any]]:
        params = {"service_id": service_id} if service_id else None
        payload = await self._request_json("GET", "/v1/tools", params=params)
        tools = payload.get("tools")
        if not isinstance(tools, list):
            raise RuntimeError("core returned an invalid tools payload")
        return tools

    async def search_tools(
        self, query: str, *, service_id: str | None = None, limit: int = 10
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"query": query, "limit": limit}
        if service_id is not None:
            params["service_id"] = service_id
        payload = await self._request_json(
            "GET",
            "/v1/tools/search",
            params=params,
        )
        matches = payload.get("matches")
        if not isinstance(matches, list):
            raise RuntimeError("core returned an invalid tool search payload")
        return matches

    async def get_tool_schema(
        self, tool_id: str, *, service_id: str | None = None
    ) -> dict[str, Any]:
        normalized_tool_id = tool_id.strip()
        if not normalized_tool_id:
            raise ValueError("tool_id must not be empty")

        params = {"service_id": service_id} if service_id is not None else None
        payload = await self._request_json(
            "GET",
            f"/v1/tools/{normalized_tool_id}",
            params=params,
        )
        tool = payload.get("tool")
        if not isinstance(tool, dict):
            raise RuntimeError("core returned an invalid tool detail payload")
        return tool

    async def get_my_namespace(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/v1/vault/me/namespace")
        namespace = payload.get("namespace")
        if not isinstance(namespace, dict):
            raise RuntimeError("core returned an invalid namespace payload")
        return namespace

    async def list_my_namespace_files(
        self, *, prefix: str | None = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if prefix is not None:
            params["prefix"] = prefix
        payload = await self._request_json("GET", "/v1/vault/me/files", params=params)
        files = payload.get("files")
        if not isinstance(files, list):
            raise RuntimeError("core returned an invalid vault file listing payload")
        return files

    async def read_my_namespace_file(self, path: str) -> dict[str, Any]:
        normalized_path = path.strip()
        if not normalized_path:
            raise ValueError("path must not be empty")
        payload = await self._request_json(
            "GET",
            "/v1/vault/me/files/content",
            params={"path": normalized_path},
        )
        file = payload.get("file")
        if not isinstance(file, dict):
            raise RuntimeError("core returned an invalid vault file payload")
        return file

    async def write_my_namespace_file(
        self, *, path: str, content_text: str, media_type: str | None = None,
    ) -> dict[str, Any]:
        normalized_path = path.strip()
        if not normalized_path:
            raise ValueError("path must not be empty")
        payload = await self._request_json(
            "PUT",
            "/v1/vault/me/files/content",
            json={
                "path": normalized_path,
                "content_text": content_text,
                "media_type": media_type,
            },
        )
        file = payload.get("file")
        if not isinstance(file, dict):
            raise RuntimeError("core returned an invalid vault write payload")
        return file

    async def delete_my_namespace_file(self, path: str) -> dict[str, Any]:
        normalized_path = path.strip()
        if not normalized_path:
            raise ValueError("path must not be empty")
        return await self._request_json(
            "DELETE",
            "/v1/vault/me/files/content",
            params={"path": normalized_path},
        )

    async def search_my_namespace_files(
        self, query: str, *, prefix: str | None = None, limit: int = 20
    ) -> list[dict[str, Any]]:
        normalized_query = query.strip()
        if not normalized_query:
            raise ValueError("query must not be empty")
        params: dict[str, Any] = {"query": normalized_query, "limit": limit}
        if prefix is not None:
            params["prefix"] = prefix
        payload = await self._request_json("GET", "/v1/vault/me/search", params=params)
        matches = payload.get("matches")
        if not isinstance(matches, list):
            raise RuntimeError("core returned an invalid vault search payload")
        return matches

    async def search_all_namespace_files(
        self,
        *,
        query: str,
        path_prefix: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        normalized_query = query.strip()
        if not normalized_query:
            raise ValueError("query must not be empty")
        body: dict[str, Any] = {
            "query": normalized_query,
            "path_prefix": path_prefix,
            "limit": limit,
            "requester": self._requester_context(
                request_mode="tool",
                request_class="namespace_file_search",
            ),
        }
        return await self._request_json("POST", "/v1/vault/files/search-all", json=body)

    async def list_protected_items(
        self,
        *,
        kind: str | None = None,
        query: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if kind is not None:
            params["kind"] = kind
        if query is not None:
            params["query"] = query
        payload = await self._request_json("GET", "/v1/vault/protected-items", params=params)
        items = payload.get("items")
        if not isinstance(items, list):
            raise RuntimeError("core returned an invalid protected item listing payload")
        return items

    async def discover_protected_items(
        self,
        *,
        kind: str | None = None,
        query: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/vault/protected-items/discover",
            json={
                "kind": kind,
                "query": query,
                "limit": limit,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="protected_discovery",
                ),
            },
        )

    async def get_protected_item(self, item_id: str) -> dict[str, Any]:
        normalized_item_id = item_id.strip()
        if not normalized_item_id:
            raise ValueError("item_id must not be empty")
        payload = await self._request_json(
            "GET",
            f"/v1/vault/protected-items/{normalized_item_id}",
        )
        item = payload.get("item")
        if not isinstance(item, dict):
            raise RuntimeError("core returned an invalid protected item payload")
        return item

    async def list_delivery_targets(self) -> list[dict[str, Any]]:
        payload = await self._request_json("GET", "/v1/vault/delivery-targets")
        targets = payload.get("delivery_targets")
        if not isinstance(targets, list):
            raise RuntimeError("core returned an invalid delivery target payload")
        return targets

    async def _resolve_delivery_target_id(
        self,
        delivery_target_id: str | None,
        *,
        target_kind: str = "cli_slot",
    ) -> str:
        normalized = str(delivery_target_id or "").strip()
        if normalized:
            return normalized
        targets = await self.list_delivery_targets()
        matching_targets = [
            target
            for target in targets
            if isinstance(target, dict)
            and str(target.get("target_kind") or "").strip() == target_kind
            and isinstance(target.get("delivery_target_id"), str)
            and str(target.get("delivery_target_id") or "").strip()
        ]
        runtime_targets = [
            target
            for target in matching_targets
            if isinstance(target.get("target_metadata"), dict)
            and target["target_metadata"].get("runtime_managed")
        ]
        if len(runtime_targets) == 1:
            return str(runtime_targets[0]["delivery_target_id"]).strip()
        requester_slot_targets = [
            target
            for target in matching_targets
            if str(target.get("slot_id") or "").strip() == "requester-local-slot"
        ]
        if len(requester_slot_targets) == 1:
            return str(requester_slot_targets[0]["delivery_target_id"]).strip()
        if len(matching_targets) == 1:
            return str(matching_targets[0]["delivery_target_id"]).strip()
        if not matching_targets:
            raise ValueError(
                "No local Skyline delivery target is available yet. Finish machine "
                "setup first, then retry this Skyline tool."
            )
        raise ValueError(
            "Skyline found more than one local delivery target and could not choose "
            "safely. Restart Skyline setup or remove old helper targets, then retry."
        )

    async def call_secret_api(
        self,
        *,
        item_id: str,
        method: str,
        path: str | None = None,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        body_text: str | None = None,
    ) -> dict[str, Any]:
        normalized_item_id = item_id.strip()
        if not normalized_item_id:
            raise ValueError("item_id must not be empty")
        return await self._request_json(
            "POST",
            f"/v1/vault/protected-items/{normalized_item_id}/call-api",
            json={
                "method": method,
                "path": path,
                "url": url,
                "headers": headers or {},
                "params": params or {},
                "json_body": json_body,
                "body_text": body_text,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="api_proxy_connection_call",
                ),
            },
        )

    async def get_secret_delivery_capabilities(self) -> dict[str, Any]:
        return await self._request_json("GET", "/v1/vault/secret-delivery-capabilities")

    async def start_delivery_helper_setup(self, *, preset: str | None = None) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/vault/delivery-helper-setups",
            json={"preset": preset},
        )

    async def get_delivery_helper_setup_status(self, setup_id: str) -> dict[str, Any]:
        normalized_setup_id = setup_id.strip()
        if not normalized_setup_id:
            raise ValueError("setup_id must not be empty")
        return await self._request_json(
            "GET",
            f"/v1/vault/delivery-helper-setups/{normalized_setup_id}",
        )

    async def reveal_protected_item(
        self,
        *,
        item_id: str,
        fields: list[str],
    ) -> dict[str, Any]:
        normalized_item_id = item_id.strip()
        if not normalized_item_id:
            raise ValueError("item_id must not be empty")
        return await self._request_json(
            "POST",
            f"/v1/vault/protected-items/{normalized_item_id}/reveal",
            json={
                "fields": fields,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="protected_reveal",
                ),
            },
        )

    async def inject_protected_item(
        self,
        *,
        item_id: str,
        field_name: str,
        delivery_target_id: str,
        destination_context: dict[str, Any],
        output_path: str | None = None,
    ) -> dict[str, Any]:
        normalized_item_id = item_id.strip()
        if not normalized_item_id:
            raise ValueError("item_id must not be empty")
        normalized_field_name = field_name.strip()
        if not normalized_field_name:
            raise ValueError("field_name must not be empty")
        if not delivery_target_id.strip():
            raise ValueError("delivery_target_id must not be empty")
        normalized_destination_context = dict(destination_context)
        normalized_output_path = str(output_path or "").strip()
        if normalized_output_path:
            if "output_path" in normalized_destination_context or "command" in normalized_destination_context:
                raise ValueError(
                    "output_path cannot be combined with destination_context output_path or command"
                )
            normalized_destination_context["output_path"] = normalized_output_path
        return await self._request_json(
            "POST",
            f"/v1/vault/protected-items/{normalized_item_id}/inject",
            json={
                "field_name": normalized_field_name,
                "delivery_target_id": delivery_target_id,
                "destination_context": normalized_destination_context,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="protected_inject",
                ),
            },
        )

    async def run_secret_bundle(
        self,
        *,
        delivery_target_id: str | None,
        command: str,
        bindings: list[dict[str, Any]],
        working_directory: str | None = None,
    ) -> dict[str, Any]:
        normalized_delivery_target_id = await self._resolve_delivery_target_id(
            delivery_target_id,
            target_kind="cli_slot",
        )
        if not command.strip():
            raise ValueError("command must not be empty")
        return await self._request_json(
            "POST",
            "/v1/vault/secret-actions/run-bundles",
            json={
                "delivery_target_id": normalized_delivery_target_id,
                "command": command,
                "working_directory": working_directory,
                "bindings": _normalize_run_secret_bindings(bindings),
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="secret_run_bundle",
                ),
            },
        )

    async def render_secret_bundle(
        self,
        *,
        delivery_target_id: str | None,
        template_text: str,
        bindings: list[dict[str, Any]],
        output_path: str | None = None,
    ) -> dict[str, Any]:
        normalized_delivery_target_id = await self._resolve_delivery_target_id(
            delivery_target_id,
            target_kind="cli_slot",
        )
        return await self._request_json(
            "POST",
            "/v1/vault/secret-actions/render-bundles",
            json={
                "delivery_target_id": normalized_delivery_target_id,
                "template_text": template_text,
                "output_path": output_path,
                "bindings": _normalize_render_secret_bindings(
                    bindings,
                    template_text=template_text,
                ),
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="secret_render_bundle",
                ),
            },
        )

    async def request_secret_access(
        self,
        *,
        delivery_target_id: str | None,
        accesses: list[dict[str, Any]] | None = None,
        permission_request_plan_id: str | None = None,
        confirm_user_prompt: bool = False,
    ) -> dict[str, Any]:
        normalized_delivery_target_id = await self._resolve_delivery_target_id(
            delivery_target_id,
            target_kind="cli_slot",
        )
        if not accesses and not permission_request_plan_id:
            raise ValueError("accesses or permission_request_plan_id must be provided")
        return await self._request_json(
            "POST",
            "/v1/vault/secret-access-grants/request",
            json={
                "delivery_target_id": normalized_delivery_target_id,
                "accesses": accesses or [],
                "permission_request_plan_id": permission_request_plan_id,
                "confirm_user_prompt": confirm_user_prompt,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="secret_access_grant",
                ),
            },
        )

    async def request_password_health_list(self) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/requester/password-health/list",
            json={
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="password_health_list",
                ),
            },
        )

    async def browser_fill_bundle(
        self,
        *,
        delivery_target_id: str | None = None,
        selection_hint: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/vault/secret-actions/browser-fill-bundles",
            json={
                "delivery_target_id": delivery_target_id,
                "selection_hint": selection_hint,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="browser_fill_bundle",
                ),
            },
        )

    async def browser_password(
        self,
        *,
        action: str,
        delivery_target_id: str | None = None,
        selection_hint: dict[str, Any] | None = None,
        title: str | None = None,
        safe_metadata: dict[str, Any] | None = None,
        password_style: str | None = None,
        browser_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/vault/secret-actions/browser-password",
            json={
                "action": action,
                "delivery_target_id": delivery_target_id,
                "selection_hint": selection_hint,
                "title": title,
                "safe_metadata": safe_metadata,
                "password_style": password_style,
                "browser_context": browser_context,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="browser_secret_password",
                ),
            },
        )

    async def browser_capture_secret(
        self,
        *,
        kind: str,
        title: str,
        safe_metadata: dict[str, Any],
        field_name: str | None = None,
        capture_selector: str | None = None,
        reveal_selector: str | None = None,
        copy_button_selector: str | None = None,
        clear_selector: str | None = None,
        delivery_target_id: str | None = None,
        browser_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/vault/secret-actions/browser-capture-secret",
            json={
                "delivery_target_id": delivery_target_id,
                "kind": kind,
                "title": title,
                "safe_metadata": safe_metadata,
                "field_name": field_name,
                "capture_selector": capture_selector,
                "reveal_selector": reveal_selector,
                "copy_button_selector": copy_button_selector,
                "clear_selector": clear_selector,
                "browser_context": browser_context,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="browser_secret_capture",
                ),
            },
        )

    async def store_or_update_secret(
        self,
        *,
        kind: str,
        title: str,
        safe_metadata: dict[str, Any],
        protected_fields: dict[str, Any],
        item_id: str | None = None,
        delivery_mode: str | None = None,
        delivery_target_id: str | None = None,
    ) -> dict[str, Any]:
        resolved_item_id, item_revision = await self._resolve_blind_write_target(
            item_id=item_id
        )
        for attempt_index in range(2):
            protected_packages, authority_fields = await self._build_client_side_write_payload(
                kind=kind,
                item_id=resolved_item_id,
                item_revision=item_revision,
                protected_fields=protected_fields,
            )
            try:
                return await self._request_json(
                    "POST",
                    "/v1/vault/secret-actions/store-or-update",
                    json={
                        "item_id": resolved_item_id,
                        "kind": kind,
                        "title": title,
                        "safe_metadata": _with_client_side_presence_metadata(
                            kind,
                            safe_metadata,
                            protected_fields,
                        ),
                        "protected_packages": protected_packages,
                        "authority_fields": authority_fields,
                        "delivery_mode": delivery_mode,
                        "delivery_target_id": delivery_target_id,
                        "requester": self._requester_context(
                            request_mode="tool",
                            request_class="protected_write",
                        ),
                    },
                )
            except (RuntimeError, SkylineCoreAPIError) as error:
                if attempt_index == 0 and should_refetch_key_holders_for_write_error(error):
                    continue
                raise
        raise RuntimeError("store_or_update_secret retry did not return a response")

    async def create_protected_item(
        self,
        *,
        kind: str,
        title: str,
        safe_metadata: dict[str, Any],
        protected_fields: dict[str, Any],
    ) -> dict[str, Any]:
        item_id = await self.reserve_protected_item_id()
        protected_packages, authority_fields = await self._build_client_side_write_payload(
            kind=kind,
            item_id=item_id,
            item_revision=1,
            protected_fields=protected_fields,
        )
        return await self._request_json(
            "POST",
            "/v1/vault/protected-items",
            json={
                "item_id": item_id,
                "kind": kind,
                "title": title,
                "safe_metadata": _with_client_side_presence_metadata(
                    kind,
                    safe_metadata,
                    protected_fields,
                ),
                "protected_packages": protected_packages,
                "authority_fields": authority_fields,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="protected_write",
                ),
            },
        )

    async def update_protected_item(
        self,
        *,
        item_id: str,
        title: str | None = None,
        safe_metadata: dict[str, Any] | None = None,
        protected_fields: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        normalized_item_id = item_id.strip()
        if not normalized_item_id:
            raise ValueError("item_id must not be empty")
        protected_packages: dict[str, Any] | None = None
        authority_fields: dict[str, Any] | None = None
        if protected_fields:
            current_item = await self.get_protected_item(normalized_item_id)
            protected_packages, authority_fields = await self._build_client_side_write_payload(
                kind=str(current_item["kind"]),
                item_id=normalized_item_id,
                item_revision=int(current_item["revision"]) + 1,
                protected_fields=protected_fields,
            )
        return await self._request_json(
            "PATCH",
            f"/v1/vault/protected-items/{normalized_item_id}",
            json={
                "title": title,
                "safe_metadata": (
                    _with_client_side_presence_metadata(
                        str((await self.get_protected_item(normalized_item_id))["kind"]),
                        safe_metadata or {},
                        protected_fields or {},
                    )
                    if protected_fields
                    else safe_metadata
                ),
                "protected_packages": protected_packages,
                "authority_fields": authority_fields,
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="protected_write",
                ),
            },
        )

    async def reserve_protected_item_id(self) -> str:
        payload = await self._request_json("POST", "/v1/vault/protected-items/new-id")
        item_id = payload.get("item_id")
        if not isinstance(item_id, str) or not item_id.strip():
            raise RuntimeError("core returned an invalid protected item id")
        return item_id

    async def list_secret_key_holders(self) -> list[RecipientKeyReference]:
        payload = await self._request_json("GET", "/v1/vault/secret-key-holders")
        raw_holders = payload.get("key_holders")
        if not isinstance(raw_holders, list):
            raise RuntimeError("core returned an invalid secret key-holder payload")
        holders: list[RecipientKeyReference] = []
        for holder in raw_holders:
            if not isinstance(holder, dict):
                continue
            holders.append(
                RecipientKeyReference(
                    key_holder_id=str(holder["key_holder_id"]),
                    public_key=str(holder["public_key"]),
                    key_id=str(holder["key_id"]),
                    key_version=int(holder["key_version"]),
                    status=str(holder.get("status") or "active"),
                    key_algorithm=str(holder.get("key_algorithm") or DELIVERY_KEY_ALGORITHM),
                )
            )
        return [holder for holder in holders if holder.status == "active"]

    async def _resolve_blind_write_target(
        self,
        *,
        item_id: str | None,
    ) -> tuple[str, int]:
        normalized_item_id = str(item_id or "").strip()
        if not normalized_item_id:
            return await self.reserve_protected_item_id(), 1
        try:
            current_item = await self.get_protected_item(normalized_item_id)
        except SkylineCoreAPIError as error:
            if error.status_code != 404:
                raise
            return normalized_item_id, 1
        return normalized_item_id, int(current_item["revision"]) + 1

    async def _build_client_side_write_payload(
        self,
        *,
        kind: str,
        item_id: str,
        item_revision: int,
        protected_fields: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        return build_client_side_protected_write_payload(
            kind=kind,
            item_id=item_id,
            item_revision=item_revision,
            protected_fields=protected_fields,
            recipients=await self.list_secret_key_holders(),
        )

    async def list_record_categories(self) -> list[dict[str, Any]]:
        payload = await self._request_json("GET", "/v1/vault/record-categories")
        categories = payload.get("categories")
        if not isinstance(categories, list):
            raise RuntimeError("core returned an invalid record category payload")
        return categories

    async def search_records(
        self,
        *,
        category: str,
        query: str | None = None,
        service_id: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "category": category,
            "query": query,
            "service_id": service_id,
            "limit": limit,
            "requester": self._requester_context(
                request_mode="tool",
                request_class="record_search",
            ),
        }
        return await self._request_json("POST", "/v1/vault/records/search", json=body)

    async def get_record(self, *, record_id: str) -> dict[str, Any]:
        normalized_record_id = record_id.strip()
        if not normalized_record_id:
            raise ValueError("record_id must not be empty")
        return await self._request_json(
            "POST",
            f"/v1/vault/records/{normalized_record_id}/read",
            json={
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="record_read",
                )
            },
        )

    async def get_request_status(self, request_id: str) -> dict[str, Any]:
        normalized_request_id = request_id.strip()
        if not normalized_request_id:
            raise ValueError("request_id must not be empty")
        return await self._request_json(
            "GET", f"/v1/requests/{normalized_request_id}"
        )

    async def wait_for_request_status(
        self, request_id: str, *, timeout_seconds: int = 15,
    ) -> dict[str, Any]:
        normalized_request_id = request_id.strip()
        if not normalized_request_id:
            raise ValueError("request_id must not be empty")
        bounded_timeout_ms = max(0, min(timeout_seconds, 30) * 1000)
        return await self._request_json(
            "GET",
            f"/v1/requests/{normalized_request_id}/wait",
            params={"timeout_ms": bounded_timeout_ms},
        )

    async def get_task_status(self, task_id: str) -> dict[str, Any]:
        normalized_task_id = task_id.strip()
        if not normalized_task_id:
            raise ValueError("task_id must not be empty")
        return await self._request_json("GET", f"/v1/tasks/{normalized_task_id}")

    async def request_bootstrap_token(
        self,
        *,
        display_name: str,
        token_mode: str = "first_machine",
        source_kind: str | None = None,
        source_provider: str | None = None,
        source_account_or_project_id: str | None = None,
        source_scope_tags: list[str] | None = None,
        default_requester_instruction: str | None = None,
        default_requester_policy: str | None = None,
        default_requested_profile: str | None = None,
        default_requested_tags: list[str] | None = None,
        default_requested_metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        normalized_display_name = display_name.strip()
        if not normalized_display_name:
            raise ValueError("display_name must not be empty")
        return await self._request_json(
            "POST",
            "/v1/requesters/bootstrap-tokens",
            json={
                "display_name": normalized_display_name,
                "token_mode": token_mode,
                "source_kind": source_kind,
                "source_provider": source_provider,
                "source_account_or_project_id": source_account_or_project_id,
                "source_scope_tags": list(source_scope_tags or []),
                "default_requester_instruction": default_requester_instruction,
                "default_requester_policy": default_requester_policy,
                "default_requested_profile": default_requested_profile,
                "default_requested_tags": list(default_requested_tags or []),
                "default_requested_metadata": dict(default_requested_metadata or {}),
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="bootstrap_token_issue",
                ),
            },
        )

    async def rotate_bootstrap_token(
        self,
        bootstrap_token_id: str,
    ) -> dict[str, Any]:
        normalized_bootstrap_token_id = bootstrap_token_id.strip()
        if not normalized_bootstrap_token_id:
            raise ValueError("bootstrap_token_id must not be empty")
        return await self._request_json(
            "POST",
            f"/v1/requesters/bootstrap-tokens/{normalized_bootstrap_token_id}/rotate",
            json={
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="bootstrap_token_rotate",
                ),
            },
        )

    async def revoke_bootstrap_token(
        self,
        bootstrap_token_id: str,
    ) -> dict[str, Any]:
        normalized_bootstrap_token_id = bootstrap_token_id.strip()
        if not normalized_bootstrap_token_id:
            raise ValueError("bootstrap_token_id must not be empty")
        return await self._request_json(
            "POST",
            f"/v1/requesters/bootstrap-tokens/{normalized_bootstrap_token_id}/revoke",
            json={
                "requester": self._requester_context(
                    request_mode="tool",
                    request_class="bootstrap_token_revoke",
                ),
            },
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        headers = {"Authorization": f"Bearer {self._current_access_token()}"}
        headers.update(self._extra_headers)
        if self._request_headers_factory is not None:
            headers.update(self._request_headers_factory(method, path, params, json))
        async with self._client_factory() as client:
            response = await client.request(
                method,
                path,
                params=params,
                json=json,
                headers=headers,
            )
        if response.status_code >= 400:
            raise SkylineCoreAPIError(response.status_code, _response_error_message(response))

        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError("core returned a non-object JSON payload")
        return payload


class LocalRequesterMCPClient(SkylineCoreHTTPClient):
    def __init__(
        self,
        config: MCPServerConfig,
        *,
        core_request_factory: SyncCoreRequestFactory,
        connect_factory: SyncConnectFactory,
        update_instructions_factory: SyncUpdateInstructionsFactory | None = None,
        session_id_resolver: SessionIdResolver | None = None,
    ) -> None:
        super().__init__(
            config,
            access_token_resolver=lambda: "local-requester-bridge",
        )
        self._core_request_factory = core_request_factory
        self._connect_factory = connect_factory
        self._update_instructions_factory = update_instructions_factory
        self._session_id_resolver = session_id_resolver

    def _current_access_token(self) -> str:
        return "local-requester-bridge"

    def _current_session_id(self) -> str:
        if self._session_id_resolver is not None:
            resolved = str(self._session_id_resolver() or "").strip()
            if resolved:
                return resolved
        return super()._current_session_id()

    async def connect(self) -> dict[str, Any]:
        return await asyncio.to_thread(self._connect_factory)

    async def update_instructions(self) -> dict[str, Any]:
        if self._update_instructions_factory is None:
            return {
                "requester_update": {
                    "status": "unknown",
                    "message": "This Skyline MCP transport cannot inspect local CLI update state.",
                }
            }
        return await asyncio.to_thread(self._update_instructions_factory)

    @staticmethod
    def _connect_completed(payload: dict[str, Any]) -> bool:
        status = str(payload.get("status") or "").strip()
        if status in {"connected", "completed"}:
            return True
        result = payload.get("result")
        return isinstance(result, dict) and isinstance(
            result.get("requester_app_principal"),
            dict,
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = await asyncio.to_thread(
            self._core_request_factory,
            method,
            path,
            params,
            json,
        )
        if _payload_status(payload) == "connect_required":
            connect_payload = await self.connect()
            if self._connect_completed(connect_payload):
                payload = await asyncio.to_thread(
                    self._core_request_factory,
                    method,
                    path,
                    params,
                    json,
                )
        return _with_local_bridge_connect_guidance(payload)


def _response_error_message(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except ValueError:
        text = response.text.strip()
        return text or f"core returned HTTP {response.status_code}"

    if isinstance(payload, dict):
        error_message = payload.get("error")
        if isinstance(error_message, str) and error_message.strip():
            return error_message
    return f"core returned HTTP {response.status_code}"


def _payload_status(payload: dict[str, Any]) -> str | None:
    status = payload.get("status")
    if isinstance(status, str):
        return status

    task = payload.get("task")
    if isinstance(task, dict):
        task_status = task.get("status")
        if isinstance(task_status, str):
            return task_status
    return None


def _payload_ids(payload: dict[str, Any]) -> tuple[str | None, str | None, str | None]:
    request_id = payload.get("request_id")
    task_id = None
    approval_id = None

    task = payload.get("task")
    if isinstance(task, dict):
        maybe_request_id = task.get("request_id")
        if request_id is None and isinstance(maybe_request_id, str):
            request_id = maybe_request_id

        maybe_task_id = task.get("task_id")
        if isinstance(maybe_task_id, str):
            task_id = maybe_task_id

        maybe_approval_id = task.get("approval_id")
        if isinstance(maybe_approval_id, str):
            approval_id = maybe_approval_id

    approval = payload.get("approval")
    if approval_id is None and isinstance(approval, dict):
        maybe_approval_id = approval.get("approval_id")
        if isinstance(maybe_approval_id, str):
            approval_id = maybe_approval_id

    resolution = payload.get("resolution")
    if approval_id is None and isinstance(resolution, dict):
        maybe_approval_id = resolution.get("approval_id")
        if isinstance(maybe_approval_id, str):
            approval_id = maybe_approval_id

    normalized_request_id = request_id if isinstance(request_id, str) else None
    normalized_task_id = task_id if isinstance(task_id, str) else None
    if normalized_task_id is None:
        normalized_task_id = normalized_request_id
    return normalized_request_id, normalized_task_id, approval_id


def _build_mcp_follow_up(payload: dict[str, Any]) -> dict[str, Any] | None:
    status = _payload_status(payload)
    if status not in {"processing", "approval_required"}:
        return None

    request_id, task_id, approval_id = _payload_ids(payload)
    polling: dict[str, Any] = {
        "suggested": True,
        "recommended_initial_attempts": 4,
        "recommended_tool": "skyline_check_request",
    }
    if request_id is not None:
        polling["request_id"] = request_id
    if task_id is not None:
        polling["task_id"] = task_id
    if approval_id is not None:
        polling["approval_id"] = approval_id

    if status == "processing":
        polling["recommended_retry_after_ms"] = 30000
        polling["steady_state_retry_after_ms"] = 30000
        polling["after_initial_attempts"] = (
            "If it is still processing, keep waiting on the request instead of "
            "switching approaches just because the initial inline wait expired."
        )
        return {
            "status": status,
            "awaiting": "internal_processing",
            "human_action_required": False,
            "expected_wait": "variable",
            "message": (
                "Skyline is still running internal work or waiting on a downstream "
                "service result. Use your own short wait capability if available, "
                "then call `skyline_check_request` again instead of treating this as "
                "a failure."
            ),
            "polling": polling,
        }

    polling["recommended_retry_after_ms"] = 30000
    polling["steady_state_retry_after_ms"] = 300000
    polling["after_initial_attempts"] = (
        "If approval is still pending after a few short waits, either switch to "
        "much longer waits if this request still matters, or if there are other "
        "viable ways to keep making progress, do that and check back later."
    )
    return {
        "status": status,
        "awaiting": "human_approval",
        "human_action_required": True,
        "expected_wait": "indefinite",
        "message": (
            "A human authorizer must approve this request. Try a few short bounded "
            "waits first so the agent can continue immediately if approval lands "
            "soon. If approval still is not available after that, either switch to "
            "much longer waits if this request still matters, or if there are other "
            "viable ways to keep making progress, do those and check back later."
        ),
        "polling": polling,
    }


def _annotate_mcp_response(payload: dict[str, Any]) -> dict[str, Any]:
    follow_up = _build_mcp_follow_up(payload)
    if follow_up is None:
        return payload

    annotated = dict(payload)
    annotated["mcp_follow_up"] = follow_up
    return annotated


def _skyline_help_payload() -> dict[str, Any]:
    return {
        "what_is_skyline": (
            "Skyline is the user's vault for secrets and passwords. Use it when "
            "you need a password, API key, token, SSH key, or config secret."
        ),
        "how_to_choose": [
            (
                "Default to skyline_run_with_secrets for scripts, CLIs, tests, "
                "servers, and API calls that can read env vars."
            ),
            (
                "Use skyline_render_secret_file only when a tool requires a real "
                "credential/config file such as .env, credentials.json, kubeconfig, "
                "an SSH key, or MCP config."
            ),
            (
                "Use skyline_find_secrets to browse or search saved items by "
                "title, site, username/email, notes, or kind."
            ),
            (
                "Use skyline_reveal_secret_in_plaintext only as a last resort, "
                "because it returns the secret value into the agent context."
            ),
        ],
        "browser_rule": (
            "Browser tools act on the browser tab/page the agent already controls. "
            f"{BROWSER_CURRENT_TAB_GUIDANCE} "
            "Navigate to the correct password/API-key step first, fill non-secret "
            "fields yourself, then call the Skyline browser tool before revealing "
            "or reading any secret value."
        ),
        "bot_check_rule": (
            "If a page shows CAPTCHA, Turnstile, Cloudflare, hCaptcha, or another "
            "bot check, solve it in the browser before using or revealing a password. "
            "If the browser action fails after a bot check, retry from the same "
            "page once the check is solved."
        ),
        "approval_rule": (
            "If any Skyline tool returns processing or approval_required, wait if "
            "you can and call skyline_check_request with the returned request_id."
        ),
        "async_status_rule": ASYNC_MCP_STATUS_GUIDANCE,
        "parameter_hints": {
            "bindings": (
                "Map env vars or template placeholders to saved secrets using "
                "selector.item_id or selector.query plus selector.field_name."
            ),
            "safe_metadata": (
                "Non-secret account context. For login_secret use site, username "
                "(email is fine), optional email/login_url, and one-line notes "
                "under 240 chars; "
                "never include backup codes or secrets."
            ),
            "protected_fields": (
                "The actual secret values to store, such as password, token, or api_key."
            ),
            "browser_context.current_url": (
                "The current URL of the browser tab/page the agent is already controlling."
            ),
            "selector": (
                "A CSS selector such as #copy-token or input[name='password']; "
                "use precise selectors for browser capture."
            ),
        },
    }


def build_mcp_server(
    config: MCPServerConfig,
    *,
    client_factory: AsyncClientFactory | None = None,
    access_token_resolver: Callable[[], str] | None = None,
    request_headers_factory: CoreRequestHeadersFactory | None = None,
    token_verifier: TokenVerifier | None = None,
    transport_security: TransportSecuritySettings | None = None,
    bridge_client: SkylineCoreHTTPClient | None = None,
) -> FastMCP:
    # This built-in remote MCP surface is the network-path fallback for
    # requesters that cannot run Skyline's local setup/local-bridge flow deeply
    # enough. It is mounted by the same portable core service on Mac, Pi/Linux,
    # or hosted deployments; code-capable machines should normally use the
    # local requester path first.
    bridge = bridge_client or SkylineCoreHTTPClient(
        config,
        client_factory=client_factory,
        access_token_resolver=access_token_resolver,
        request_headers_factory=request_headers_factory,
    )
    inbound_token_verifier = (
        token_verifier
        or (
            StaticBearerTokenVerifier(config.inbound_bearer_token)
            if config.inbound_bearer_token
            else None
        )
    )
    auth_settings = (
        build_fastmcp_auth_settings(config) if inbound_token_verifier is not None else None
    )
    server = FastMCP(
        name="Skyline",
        instructions=(
            "Skyline is the user's vault for secrets and passwords. Prefer tools "
            "that use secrets without returning secret values to chat/tool output: "
            "browser login/capture, command execution with env vars, and local "
            "file writing. Use plaintext reveal only as an explicit last resort. "
            "Do not treat `processing` or `approval_required` as final failures; "
            "wait if you can, then check the returned request with "
            "`skyline_check_request`."
        ),
        host=config.host,
        port=config.port,
        streamable_http_path=config.streamable_http_path,
        json_response=True,
        auth=auth_settings,
        token_verifier=inbound_token_verifier,
        transport_security=transport_security,
    )

    if hasattr(bridge, "update_instructions"):
        @server.tool(
            name="skyline_update_instructions",
            description=(
                "Show the local Skyline CLI update command and whether the "
                "connected core recommends or requires an update. This does not "
                "perform the update; the human should run the returned command "
                "and restart any agent/MCP session using `skyline bridge serve`."
            ),
            structured_output=True,
        )
        async def skyline_update_instructions() -> dict[str, Any]:
            return await bridge.update_instructions()  # type: ignore[attr-defined]

    # Cut for V1: provider/data connector service discovery is dormant. Keep
    # the HTTP bridge methods for future revival, but do not register catalog
    # browsing tools on the normal MCP surface. skyline_help is the concise
    # orientation tool for requesters that need to choose a secret workflow.

    @server.tool(
        name="skyline_help",
        description="How to use Skyline, your vault for secrets and passwords.",
        structured_output=True,
    )
    async def skyline_help() -> dict[str, Any]:
        return _skyline_help_payload()

    # Cut for V1: workspace/namespace file MCP tools are intentionally not
    # registered. The bridge methods remain below for a future explicit revival.
    # These MCP `description=` strings are the short tool blurbs agents see in
    # their context. Do not rewrite, shorten, expand, or move guidance into/out
    # of them without showing Alex the exact proposed text first.

    @server.tool(
        name="skyline_find_secrets",
        description=(
            "List or search saved vault items by title, site, username/email, "
            "notes, or kind. Use empty query to browse accounts. Returns only "
            "non-secret metadata: item_id, title, kind, safe_metadata such as "
            "site, username/email, login_url, and notes; never passwords/API keys. "
            "Normal metadata lookup needs no approval. Use item_id with Skyline "
            "tools like skyline_use_password_in_current_browser, skyline_run_with_secrets, "
            "or skyline_render_secret_file. Params: optional query, kind, limit, password_health."
        ),
        structured_output=True,
    )
    async def skyline_find_secrets(
        query: str | None = None,
        kind: str | None = None,
        limit: int | None = None,
        password_health: str | None = None,
    ) -> dict[str, Any]:
        normalized_password_health = str(password_health or "").strip()
        if normalized_password_health:
            if normalized_password_health != "weak_or_reused":
                raise ValueError("password_health must be weak_or_reused")
            return _annotate_mcp_response(await bridge.request_password_health_list())
        return _annotate_mcp_response(
            await bridge.discover_protected_items(kind=kind, query=query, limit=limit)
        )

    # Cut for V1: API proxy is grouped with OAuth/provider connections and the
    # provider SDK. Keep the bridge method dormant, but do not expose
    # skyline_call_secret_api as an MCP tool.

    @server.tool(
        name="skyline_request_secret_access",
        description=(
            "For batches or permission-needed responses: request user permission "
            "for selected secrets/tools. item_id chooses the secret. Browser grants "
            "use browser_action and site/allowed_site. run_with_secrets may omit "
            "env_var; render_secret_file needs placeholder/output_path."
        ),
        structured_output=True,
    )
    async def skyline_request_secret_access(
        accesses: list[dict[str, Any]] | None = None,
        permission_request_plan_id: str | None = None,
        confirm_user_prompt: bool = False,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.request_secret_access(
                delivery_target_id=None,
                accesses=accesses,
                permission_request_plan_id=permission_request_plan_id,
                confirm_user_prompt=confirm_user_prompt,
            )
        )

    @server.tool(
        name="skyline_run_with_secrets",
        description=(
            "Run a command with saved secrets as env vars. Default for scripts, "
            "CLIs, tests, deploys, local servers, and API calls. Secrets go to "
            "the child process, not chat. Bindings map env_var to "
            "selector.item_id/query + field_name. item_id is the saved secret; "
            "Skyline chooses the local bridge/helper destination internally. "
            "Use skyline_render_secret_file only when a real file is required."
        ),
        structured_output=True,
    )
    async def skyline_run_with_secrets(
        command: str,
        bindings: list[dict[str, Any]],
        working_directory: str | None = None,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.run_secret_bundle(
                delivery_target_id=None,
                command=command,
                working_directory=working_directory,
                bindings=bindings,
            )
        )

    @server.tool(
        name="skyline_render_secret_file",
        description=(
            "Write a credential/config file from a template. Use only for tools "
            "that require a real file like .env, credentials.json, kubeconfig, "
            "SSH keys, or MCP config. Secrets are written to a local file, not "
            "chat and may persist until deleted. Bindings map placeholders to "
            "selector.item_id/query + field_name. item_id is the saved secret; "
            "Skyline chooses the local bridge/helper destination internally. "
            "Prefer skyline_run_with_secrets when env vars work."
        ),
        structured_output=True,
    )
    async def skyline_render_secret_file(
        template_text: str,
        bindings: list[dict[str, Any]],
        output_path: str | None = None,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.render_secret_bundle(
                delivery_target_id=None,
                template_text=template_text,
                output_path=output_path,
                bindings=bindings,
            )
        )

    if chrome_extension_browser_companion_enabled():
        @server.tool(
            name="skyline_browser_fill_bundle",
            description=(
                "Legacy browser companion fill path for Chrome-extension-driven "
                "flows. For agent-driven browsers such as Codex Browser or "
                "Playwright/CDP, prefer skyline_use_password_in_current_browser because fill-only "
                "can leave password values visible to the next DOM snapshot. This "
                "tool still verifies the active browser companion context before "
                "filling and supports selection_hint.item_id when the account is "
                "known."
            ),
            structured_output=True,
        )
        async def skyline_browser_fill_bundle(
            selection_hint: dict[str, Any] | None = None,
        ) -> dict[str, Any]:
            return _annotate_mcp_response(
                await bridge.browser_fill_bundle(
                    delivery_target_id=None,
                    selection_hint=selection_hint,
                )
            )

    @server.tool(
        name="skyline_use_password_in_current_browser",
        description=(
            "Use a password on the current browser page without returning it. "
            "action: login uses saved selection_hint.item_id; create_password "
            "generates/fills/stores a new login; change_password uses old saved "
            "password, fills current/new/confirm fields, submits, and updates Skyline "
            "only after clear success. Fill non-secret fields first. Pass "
            "browser_context.current_url or expected_origin."
        ),
        structured_output=True,
    )
    async def skyline_use_password_in_current_browser(
        action: str,
        selection_hint: dict[str, Any] | None = None,
        title: str | None = None,
        safe_metadata: dict[str, Any] | None = None,
        password_style: str | None = None,
        browser_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.browser_password(
                action=action,
                delivery_target_id=None,
                selection_hint=selection_hint,
                title=title,
                safe_metadata=safe_metadata,
                password_style=password_style,
                browser_context=browser_context,
            )
        )

    @server.tool(
        name="skyline_capture_secret_from_current_browser",
        description=(
            "Capture a newly generated API key/token from the browser page into "
            "Skyline without returning it. Call before the agent reveals, copies, "
            "or reads the secret; pass a precise capture, reveal, or copy selector. "
            "Include one-line non-secret safe_metadata.notes under 240 chars stating key/account purpose."
        ),
        structured_output=True,
    )
    async def skyline_capture_secret_from_current_browser(
        kind: str,
        title: str,
        safe_metadata: dict[str, Any],
        field_name: str | None = None,
        capture_selector: str | None = None,
        reveal_selector: str | None = None,
        copy_button_selector: str | None = None,
        clear_selector: str | None = None,
        browser_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.browser_capture_secret(
                kind=kind,
                title=title,
                safe_metadata=safe_metadata,
                field_name=field_name,
                capture_selector=capture_selector,
                reveal_selector=reveal_selector,
                copy_button_selector=copy_button_selector,
                clear_selector=clear_selector,
                delivery_target_id=None,
                browser_context=browser_context,
            )
        )

    @server.tool(
        name="skyline_save_secret",
        description=(
            "Store a secret value the agent already knows. Use for human-provided "
            "or agent-generated values only; prefer browser capture for web-generated "
            "keys. Include one-line non-secret safe_metadata.notes under 240 chars; never "
            "put backup codes or secrets in safe_metadata. The value is already "
            "exposed to the agent."
        ),
        structured_output=True,
    )
    async def skyline_save_secret(
        kind: str,
        title: str,
        safe_metadata: dict[str, Any],
        protected_fields: dict[str, Any],
        item_id: str | None = None,
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.store_or_update_secret(
                item_id=item_id,
                kind=kind,
                title=title,
                safe_metadata=safe_metadata,
                protected_fields=protected_fields,
            )
        )

    @server.tool(
        name="skyline_reveal_secret_in_plaintext",
        description=(
            "Last-resort plaintext reveal of saved password/API key fields into "
            "chat/tool output. Use only after safer browser, command, or file "
            "delivery cannot work. Safety: worst option, because it puts "
            "secret values in the agent context. Params: item_id and fields."
        ),
        structured_output=True,
    )
    async def skyline_reveal_secret_in_plaintext(
        item_id: str,
        fields: list[str],
    ) -> dict[str, Any]:
        return _annotate_mcp_response(
            await bridge.reveal_protected_item(item_id=item_id, fields=fields)
        )

    # Cut for V1: single-field inject, separate create/update aliases, helper
    # setup/debug tools, catalog browsing tools, and non-secret personal-data
    # record tools are intentionally not registered on the normal MCP surface.
    # Their bridge methods remain for internal flows and future explicit revival.

    @server.tool(
        name="skyline_check_request",
        description=(
            "Check status/result for a previous Skyline request after approval "
            "or processing. Does not use or return secret values. Params: "
            "request_id, or task_id only if a previous response gave no "
            "request_id."
        ),
        structured_output=True,
    )
    async def skyline_check_request(
        request_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        normalized_request_id = str(request_id or "").strip()
        if normalized_request_id:
            return _annotate_mcp_response(
                await bridge.get_request_status(normalized_request_id)
            )
        normalized_task_id = str(task_id or "").strip()
        if normalized_task_id:
            return _annotate_mcp_response(await bridge.get_task_status(normalized_task_id))
        raise ValueError("request_id is required")

    @server.resource(
        "skyline://tools",
        name="Skyline Tools",
        description="JSON snapshot of currently discovered Skyline tools.",
        mime_type="application/json",
    )
    async def tools_resource() -> str:
        return json.dumps({"tools": await bridge.list_tools()}, indent=2)

    return server
