from __future__ import annotations

import os


TRUTHY_ENV_VALUES = frozenset({"1", "true", "yes", "on"})


def chrome_extension_browser_companion_enabled() -> bool:
    return (
        os.environ.get("SKYLINE_ENABLE_CHROME_EXTENSION", "").strip().lower()
        in TRUTHY_ENV_VALUES
    )
