from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import httpx

from .delivery_crypto import generate_keypair
from .helper_security import (
    HelperSecurityContext,
    ack_delivery_job,
    decrypt_helper_blind_secret_package,
    load_helper_metadata,
    load_helper_security_context,
    open_helper_delivery_envelope,
    persist_helper_credentials,
    request_json,
    require_metadata,
    save_helper_metadata,
    write_owner_only_text,
)
from .requester_protocol import DELIVERY_HELPER_COMPONENT_KIND


DEFAULT_CONFIG_PATH = Path.home() / ".skyline-delivery-helper.json"
DEFAULT_ENV_VAR = "SKYLINE_INJECTED_SECRET"
LOCAL_CLI_PRESET = "local_cli"
PRESET_DEFINITIONS = {
    LOCAL_CLI_PRESET: {
        "slot_id": "local-cli",
        "slot_label": "Local CLI Slot",
    }
}


def _load_config(path: Path) -> dict[str, Any]:
    return load_helper_metadata(path)


def _save_config(path: Path, config: dict[str, Any]) -> None:
    save_helper_metadata(path, config)


def _require_preset_definition(preset: str) -> dict[str, str]:
    normalized = preset.strip()
    definition = PRESET_DEFINITIONS.get(normalized)
    if definition is None:
        raise RuntimeError(
            "unsupported preset; expected one of: "
            + ", ".join(sorted(PRESET_DEFINITIONS))
        )
    return dict(definition)


def _request_json(
    *,
    method: str,
    base_url: str,
    path: str,
    access_token: str | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return request_json(
        method=method,
        base_url=base_url,
        path=path,
        access_token=access_token,
        json_body=json_body,
    )


def cmd_pair(args: argparse.Namespace) -> int:
    config_path = Path(args.config_path).expanduser()
    keypair = generate_keypair()
    secret_unwrap_keypair = generate_keypair()
    payload = _request_json(
        method="POST",
        base_url=args.base_url,
        path=f"/v1/pairing/sessions/{args.pairing_session_id}/exchange",
        json_body={
            "pairing_code": args.pairing_code,
            "display_name": args.display_name,
            "platform": args.platform,
            "service_id": "vault",
            "component_kind": DELIVERY_HELPER_COMPONENT_KIND,
            "delivery_public_key": keypair["public_key"],
            "key_algorithm": keypair["algorithm"],
            "key_id": keypair["key_id"],
            "secret_unwrap_public_key": secret_unwrap_keypair["public_key"],
            "secret_unwrap_key_algorithm": secret_unwrap_keypair["algorithm"],
            "secret_unwrap_key_id": secret_unwrap_keypair["key_id"],
            "secret_unwrap_key_version": 1,
            "supported_target_kinds": ["cli_slot"],
        },
    )
    exchange = payload.get("exchange")
    if not isinstance(exchange, dict):
        raise RuntimeError("pair response did not include exchange")
    principal = exchange.get("principal", {})
    edge_component = principal.get("principal", {}) if isinstance(principal, dict) else {}
    config = _load_config(config_path)
    config.update(
        {
            "base_url": args.base_url.rstrip("/"),
            "helper_id": edge_component.get("edge_id"),
            "display_name": args.display_name,
            "platform": args.platform,
            "component_kind": DELIVERY_HELPER_COMPONENT_KIND,
            "key_algorithm": keypair["algorithm"],
            "key_id": keypair["key_id"],
            "key_fingerprint": keypair["key_fingerprint"],
            "public_key": keypair["public_key"],
            "secret_unwrap_key_algorithm": secret_unwrap_keypair["algorithm"],
            "secret_unwrap_key_id": secret_unwrap_keypair["key_id"],
            "secret_unwrap_key_fingerprint": secret_unwrap_keypair["key_fingerprint"],
            "secret_unwrap_public_key": secret_unwrap_keypair["public_key"],
            "secret_unwrap_key_version": 1,
            "slots": config.get("slots", {}),
        }
    )
    config, backend = persist_helper_credentials(
        config_path=config_path,
        helper_kind=DELIVERY_HELPER_COMPONENT_KIND,
        metadata=config,
        secrets={
            "access_token": str(exchange.get("access_token") or ""),
            "private_key": keypair["private_key"],
            "secret_unwrap_private_key": secret_unwrap_keypair["private_key"],
        },
        bootstrap_secret_file=getattr(args, "bootstrap_secret_file", None),
    )
    print(f"Paired helper {config.get('helper_id')} in status {edge_component.get('status')}.")
    print(f"Key fingerprint: {keypair['key_fingerprint']}")
    print(f"Secret unwrap fingerprint: {secret_unwrap_keypair['key_fingerprint']}")
    print(f"Credential storage: {backend}")
    print("Next step: approve the helper in the iPhone app, then register a slot.")
    return 0


def _require_config(config: dict[str, Any], *keys: str) -> None:
    require_metadata(config, *keys)


def _helper_context(
    args: argparse.Namespace,
    *,
    require_keys: tuple[str, ...] = ("base_url",),
) -> HelperSecurityContext:
    return load_helper_security_context(
        config_path=Path(args.config_path).expanduser(),
        helper_kind=DELIVERY_HELPER_COMPONENT_KIND,
        required_metadata_keys=require_keys,
        bootstrap_secret_file=getattr(args, "bootstrap_secret_file", None),
    )


def cmd_status(args: argparse.Namespace) -> int:
    context = _helper_context(args)
    config = context.metadata
    payload = _request_json(
        method="GET",
        base_url=str(config["base_url"]),
        path="/v1/edge/me",
        access_token=context.secrets.access_token,
    )
    edge = payload.get("edge_component")
    status_payload = {
        "config": {
            **config,
            "trust_tier": context.trust_tier,
        },
        "edge_component": edge,
    }
    import json
    print(json.dumps(status_payload, indent=2, sort_keys=True))
    return 0


def cmd_register_slot(args: argparse.Namespace) -> int:
    config_path = Path(args.config_path).expanduser()
    context = _helper_context(args)
    config = context.metadata
    payload = _request_json(
        method="POST",
        base_url=str(config["base_url"]),
        path="/v1/edge/delivery-targets",
        access_token=context.secrets.access_token,
        json_body={
            "target_kind": "cli_slot",
            "slot_id": args.slot_id,
            "slot_label": args.slot_label,
            "target_metadata": {
                "credential_storage_backend": context.credential_storage_backend,
                "trust_tier": context.trust_tier,
            },
        },
    )
    delivery_target = payload.get("delivery_target")
    if not isinstance(delivery_target, dict):
        raise RuntimeError("register-slot response did not include delivery_target")
    slots = config.setdefault("slots", {})
    slots[args.slot_id] = {
        "slot_label": args.slot_label,
        "command": args.command,
        "env_var": args.env_var,
        "delivery_target_id": delivery_target.get("delivery_target_id"),
    }
    _save_config(config_path, config)
    print(
        f"Registered slot {args.slot_id} as target "
        f"{delivery_target.get('delivery_target_id')}."
    )
    return 0


def cmd_register_preset(args: argparse.Namespace) -> int:
    definition = _require_preset_definition(args.preset)
    config_path = Path(args.config_path).expanduser()
    context = _helper_context(args)
    config = context.metadata
    payload = _request_json(
        method="POST",
        base_url=str(config["base_url"]),
        path="/v1/edge/delivery-targets",
        access_token=context.secrets.access_token,
        json_body={
            "target_kind": "cli_slot",
            "slot_id": definition["slot_id"],
            "slot_label": definition["slot_label"],
            "target_metadata": {
                "credential_storage_backend": context.credential_storage_backend,
                "trust_tier": context.trust_tier,
            },
        },
    )
    delivery_target = payload.get("delivery_target")
    if not isinstance(delivery_target, dict):
        raise RuntimeError("register-preset response did not include delivery_target")
    slots = config.setdefault("slots", {})
    slots[definition["slot_id"]] = {
        "slot_label": definition["slot_label"],
        "preset": args.preset,
        "delivery_target_id": delivery_target.get("delivery_target_id"),
    }
    _save_config(config_path, config)
    print(
        f"Registered preset {args.preset} as slot {definition['slot_id']} "
        f"and target {delivery_target.get('delivery_target_id')}."
    )
    return 0


def _wait_for_active_helper(config: dict[str, Any], *, quiet: bool) -> dict[str, Any]:
    context = load_helper_security_context(
        config_path=Path(str(config["_config_path"])).expanduser(),
        helper_kind=DELIVERY_HELPER_COMPONENT_KIND,
        required_metadata_keys=("base_url",),
        bootstrap_secret_file=config.get("_bootstrap_secret_file"),
    )
    while True:
        payload = _request_json(
            method="GET",
            base_url=str(config["base_url"]),
            path="/v1/edge/me",
            access_token=context.secrets.access_token,
        )
        edge = payload.get("edge_component")
        if not isinstance(edge, dict):
            raise RuntimeError("edge status response did not include edge_component")
        if str(edge.get("status") or "") == "active":
            return edge
        if not quiet:
            print("Waiting for helper approval in the iPhone app...", file=sys.stderr)
        time.sleep(2.0)


def _ack_job(
    config: dict[str, Any],
    job_id: str,
    status: str,
    message: str | None,
    *,
    details: dict[str, Any] | None = None,
) -> None:
    context = load_helper_security_context(
        config_path=Path(str(config["_config_path"])).expanduser(),
        helper_kind=DELIVERY_HELPER_COMPONENT_KIND,
        required_metadata_keys=("base_url",),
        bootstrap_secret_file=config.get("_bootstrap_secret_file"),
    )
    ack_delivery_job(
        metadata=context.metadata,
        secrets=context.secrets,
        job_id=job_id,
        status=status,
        message=message,
        details=details,
    )


def _run_preset_slot(
    slot_config: dict[str, Any],
    payload: dict[str, Any],
    secret_value: str,
) -> tuple[int, str | None]:
    preset = str(slot_config.get("preset") or "").strip()
    if preset != LOCAL_CLI_PRESET:
        return 1, f"unsupported preset '{preset}'"
    item_title = str(payload.get("item_title") or "secret")
    field_name = str(payload.get("field_name") or "field")
    print(
        f"Local CLI preset consumed {field_name} from {item_title} "
        f"(length {len(secret_value)})."
    )
    return 0, None


def _run_slot_command(
    slot_config: dict[str, Any],
    payload: dict[str, Any],
    secret_value: str,
) -> tuple[int, str | None]:
    preset = str(slot_config.get("preset") or "").strip()
    if preset:
        return _run_preset_slot(slot_config, payload, secret_value)
    command = str(slot_config.get("command") or "").strip()
    if not command:
        return 1, "slot has no configured command"
    env_var = str(slot_config.get("env_var") or DEFAULT_ENV_VAR).strip() or DEFAULT_ENV_VAR
    env = dict(os.environ)
    env[env_var] = secret_value
    completed = subprocess.run(
        command,
        shell=True,
        env=env,
        capture_output=True,
        text=True,
    )
    if completed.returncode == 0:
        return 0, None
    stderr = (completed.stderr or "").strip()
    message = stderr[:200] if stderr else f"command exited with status {completed.returncode}"
    return completed.returncode, message


def _run_secret_bundle_command(
    slot_config: dict[str, Any],
    payload: dict[str, Any],
) -> tuple[int, str | None, dict[str, Any]]:
    command = str(payload.get("command") or slot_config.get("command") or "").strip()
    if not command:
        return 1, "run bundle did not include a command", {"delivery_action": "run_bundle"}
    working_directory = (
        str(payload["working_directory"])
        if isinstance(payload.get("working_directory"), str)
        and str(payload.get("working_directory")).strip()
        else None
    )
    env = dict(os.environ)
    env_bindings = [
        dict(binding)
        for binding in payload.get("env_bindings", [])
        if isinstance(binding, dict)
    ]
    for binding in env_bindings:
        env_var = str(binding.get("env_var") or "").strip()
        secret_value = str(binding.get("secret_value") or "")
        if not env_var:
            return (
                1,
                "run bundle binding did not include env_var",
                {"delivery_action": "run_bundle"},
            )
        env[env_var] = secret_value
    completed = subprocess.run(
        command,
        shell=True,
        cwd=working_directory,
        env=env,
        capture_output=True,
        text=True,
    )
    details = {
        "delivery_action": "run_bundle",
        "binding_count": len(env_bindings),
        "command": command,
        "working_directory": working_directory,
        "exit_code": completed.returncode,
    }
    if completed.returncode == 0:
        return 0, None, details
    stderr = (completed.stderr or "").strip()
    message = stderr[:200] if stderr else f"command exited with status {completed.returncode}"
    return completed.returncode, message, details


def _render_secret_bundle(
    _slot_config: dict[str, Any],
    payload: dict[str, Any],
) -> tuple[int, str | None, dict[str, Any]]:
    rendered = str(payload.get("template_text") or "")
    render_bindings = [
        dict(binding)
        for binding in payload.get("render_bindings", [])
        if isinstance(binding, dict)
    ]
    for binding in render_bindings:
        placeholder = str(binding.get("placeholder") or "").strip()
        secret_value = str(binding.get("secret_value") or "")
        if not placeholder:
            return (
                1,
                "render bundle binding did not include placeholder",
                {"delivery_action": "render_bundle"},
            )
        rendered = rendered.replace(placeholder, secret_value)
    output_path = (
        Path(str(payload["output_path"])).expanduser()
        if isinstance(payload.get("output_path"), str)
        and str(payload.get("output_path")).strip()
        else None
    )
    if output_path is None:
        temp_file = tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            prefix="skyline-render-",
            suffix=".tmp",
            delete=False,
        )
        try:
            temp_file.write(rendered)
        finally:
            temp_file.close()
        output_path = Path(temp_file.name)
    else:
        write_owner_only_text(output_path, rendered)
    details = {
        "delivery_action": "render_bundle",
        "binding_count": len(render_bindings),
        "output_path": str(output_path),
    }
    return 0, None, details


def _resolve_secret_package_value(
    *,
    payload: dict[str, Any],
    context: HelperSecurityContext,
    package: dict[str, Any] | None,
) -> str:
    if not isinstance(package, dict):
        raise RuntimeError("blind delivery payload did not contain secret_package")
    key_holder_id = str(
        payload.get("key_holder_id") or payload.get("issued_to_helper_id") or ""
    ).strip()
    if not key_holder_id:
        raise RuntimeError("blind delivery payload did not include key_holder_id")
    key_version_raw = payload.get("key_version")
    key_version = int(key_version_raw) if key_version_raw is not None else None
    return decrypt_helper_blind_secret_package(
        package=package,
        secrets=context.secrets,
        key_holder_id=key_holder_id,
        key_version=key_version,
    )


def _resolve_blind_secret_payload(
    payload: dict[str, Any],
    context: HelperSecurityContext,
) -> dict[str, Any]:
    resolved = dict(payload)
    if "secret_package" in resolved:
        resolved["secret_value"] = _resolve_secret_package_value(
            payload=resolved,
            context=context,
            package=(
                resolved.get("secret_package")
                if isinstance(resolved.get("secret_package"), dict)
                else None
            ),
        )
        resolved.pop("secret_package", None)
    for binding_key in ("env_bindings", "render_bindings"):
        bindings = [
            dict(binding)
            for binding in resolved.get(binding_key, [])
            if isinstance(binding, dict)
        ]
        for binding in bindings:
            if "secret_package" in binding:
                binding["secret_value"] = _resolve_secret_package_value(
                    payload=resolved,
                    context=context,
                    package=(
                        binding.get("secret_package")
                        if isinstance(binding.get("secret_package"), dict)
                        else None
                    ),
                )
                binding.pop("secret_package", None)
        if bindings:
            resolved[binding_key] = bindings
    return resolved


def cmd_serve(args: argparse.Namespace) -> int:
    context = _helper_context(args)
    config = dict(context.metadata)
    config["_config_path"] = str(Path(args.config_path).expanduser())
    config["_bootstrap_secret_file"] = getattr(args, "bootstrap_secret_file", None)
    _wait_for_active_helper(config, quiet=args.quiet)
    poll_interval = max(float(args.poll_interval), 0.2)
    while True:
        payload = _request_json(
            method="GET",
            base_url=str(config["base_url"]),
            path="/v1/edge/delivery-jobs/next",
            access_token=context.secrets.access_token,
        )
        job = payload.get("delivery_job")
        if not isinstance(job, dict):
            if args.once:
                return 0
            time.sleep(poll_interval)
            continue
        job_id = str(job.get("job_id") or "")
        slot_id = str(job.get("slot_id") or "")
        slot_config = dict(config.get("slots", {}).get(slot_id) or {})
        if not slot_config:
            _ack_job(config, job_id, "inject_target_mismatch", "no local slot configuration matched")
            if args.once:
                return 1
            continue
        try:
            payload = open_helper_delivery_envelope(
                envelope=dict(job.get("envelope") or {}),
                secrets=context.secrets,
            )
            payload = _resolve_blind_secret_payload(payload, context)
        except Exception as error:
            _ack_job(config, job_id, "inject_failed", f"decrypt failed: {error}")
            if args.once:
                return 1
            continue
        if str(payload.get("slot_id") or "") != slot_id:
            _ack_job(config, job_id, "inject_target_mismatch", "slot id mismatch")
            if args.once:
                return 1
            continue
        delivery_action = str(payload.get("delivery_action") or "").strip()
        if delivery_action == "run_bundle":
            return_code, failure_message, details = _run_secret_bundle_command(
                slot_config,
                payload,
            )
            if return_code == 0:
                _ack_job(config, job_id, "inject_delivered", None, details=details)
                print(f"Delivered run bundle job {job_id} to slot {slot_id}.")
                if args.once:
                    return 0
            else:
                _ack_job(config, job_id, "inject_failed", failure_message, details=details)
                if args.once:
                    return return_code
            continue
        if delivery_action == "render_bundle":
            return_code, failure_message, details = _render_secret_bundle(
                slot_config,
                payload,
            )
            if return_code == 0:
                _ack_job(config, job_id, "inject_delivered", None, details=details)
                print(f"Delivered render bundle job {job_id} to slot {slot_id}.")
                if args.once:
                    return 0
            else:
                _ack_job(config, job_id, "inject_failed", failure_message, details=details)
                if args.once:
                    return return_code
            continue
        secret_value = str(payload.get("secret_value") or "")
        if not secret_value:
            _ack_job(config, job_id, "inject_failed", "payload did not contain a secret value")
            if args.once:
                return 1
            continue
        return_code, failure_message = _run_slot_command(slot_config, payload, secret_value)
        if return_code == 0:
            _ack_job(config, job_id, "inject_delivered", None)
            print(f"Delivered job {job_id} to slot {slot_id}.")
            if args.once:
                return 0
        else:
            _ack_job(config, job_id, "inject_failed", failure_message)
            if args.once:
                return return_code


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Skyline delivery helper CLI")
    parser.set_defaults(func=None)
    parser.add_argument(
        "--config-path",
        default=str(DEFAULT_CONFIG_PATH),
        help="Path to helper config JSON (default: %(default)s)",
    )
    parser.add_argument(
        "--bootstrap-secret-file",
        help=(
            "Optional file containing the bootstrap secret used for encrypted "
            "credential storage on headless Linux CLI helpers"
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    pair_parser = subparsers.add_parser("pair", help="Pair this helper with Skyline")
    pair_parser.add_argument("--base-url", required=True)
    pair_parser.add_argument("--pairing-session-id", required=True)
    pair_parser.add_argument("--pairing-code", required=True)
    pair_parser.add_argument("--display-name", required=True)
    pair_parser.add_argument("--platform", default="macos")
    pair_parser.set_defaults(func=cmd_pair)

    status_parser = subparsers.add_parser("status", help="Show current helper status")
    status_parser.set_defaults(func=cmd_status)

    register_slot_parser = subparsers.add_parser(
        "register-slot",
        help="Register a CLI slot and its local command",
    )
    register_slot_parser.add_argument("--slot-id", required=True)
    register_slot_parser.add_argument("--slot-label", required=True)
    register_slot_parser.add_argument("--command", required=True)
    register_slot_parser.add_argument("--env-var", default=DEFAULT_ENV_VAR)
    register_slot_parser.set_defaults(func=cmd_register_slot)

    register_preset_parser = subparsers.add_parser(
        "register-preset",
        help="Register a built-in preset delivery target",
    )
    register_preset_parser.add_argument("--preset", required=True)
    register_preset_parser.set_defaults(func=cmd_register_preset)

    serve_parser = subparsers.add_parser(
        "serve",
        help="Poll for delivery jobs and run the configured slot command",
    )
    serve_parser.add_argument("--poll-interval", type=float, default=2.0)
    serve_parser.add_argument("--once", action="store_true")
    serve_parser.add_argument("--quiet", action="store_true")
    serve_parser.set_defaults(func=cmd_serve)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.func is None:
        parser.print_help()
        return 2
    try:
        return int(args.func(args) or 0)
    except httpx.HTTPStatusError as error:
        detail = error.response.text.strip() or str(error)
        print(f"HTTP error: {detail}", file=sys.stderr)
        return 1
    except Exception as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
