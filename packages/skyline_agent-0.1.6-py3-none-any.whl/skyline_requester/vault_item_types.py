from __future__ import annotations

import copy
import importlib.metadata
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from .secret_custody import (
    CUSTODY_MODE_AUTHORITY_USABLE,
    CUSTODY_MODE_BLIND_VALUE_RELEASE,
)


JsonObject = dict[str, Any]
PayloadNormalizer = Callable[[dict[str, Any], dict[str, Any]], tuple[dict[str, Any], dict[str, str]]]

FIELD_VISIBILITY_SEARCHABLE = "searchable"
FIELD_VISIBILITY_SUMMARY_ONLY = "summary_only"
FIELD_VISIBILITY_PROTECTED = "protected"
CREATOR_REUSE_SAFE_METADATA_FIELDS = frozenset({
    "skyline_created_by_requester_display_name",
    "skyline_created_by_requester_app_id",
    "skyline_created_by_requester_app_principal_id",
    "skyline_created_from_browser_action",
    "skyline_created_from_browser_origin",
    "skyline_created_from_browser_url",
    "skyline_creator_reuse_expires_at_epoch_ms",
    "skyline_creator_reuse_secret_use_tiers",
    "skyline_creator_reuse_workflow_id",
})

REVEAL_DECISION_POLICIES: dict[str, list[str]] = {
    "credential_secret": ["approve_once", "approve_for_session"],
    "payment_card_pan": ["approve_once"],
    "payment_card_cvv": ["approve_once"],
    "protected_once": ["approve_once"],
}
UPDATE_DECISION_POLICIES: dict[str, list[str]] = {
    "credential_item": ["approve_once", "approve_for_session"],
    "payment_card_item": ["approve_once"],
    "protected_once": ["approve_once"],
}
PAN_RE = re.compile(r"^[0-9]{13,19}$")
CVV_RE = re.compile(r"^[0-9]{3,4}$")
SAFE_METADATA_NOTE_MAX_CHARS = 240


@dataclass(frozen=True, slots=True)
class VaultFieldDefinition:
    field_name: str
    storage_target: str
    visibility: str
    required: bool = False
    value_type: str = "string"
    sensitivity_class: str | None = None
    presence_scope_key: str | None = None
    custody_mode: str | None = None


@dataclass(frozen=True, slots=True)
class VaultItemTypeDefinition:
    kind: str
    display_name: str
    safe_fields: dict[str, VaultFieldDefinition]
    protected_fields: dict[str, VaultFieldDefinition]
    normalize_payload: PayloadNormalizer
    update_policy_class: str = "protected_once"
    catalog_entry: JsonObject = field(default_factory=dict)
    title_searchable: bool = True

    def searchable_safe_field_names(self) -> list[str]:
        return sorted(
            field_name
            for field_name, field in self.safe_fields.items()
            if field.visibility == FIELD_VISIBILITY_SEARCHABLE
        )

    def visible_safe_metadata(self, safe_metadata: dict[str, Any]) -> dict[str, Any]:
        visible: dict[str, Any] = {}
        for field_name in self.safe_fields:
            if field_name in safe_metadata:
                visible[field_name] = safe_metadata[field_name]
        return visible

    def reveal_allowed_decisions(self, field_names: list[str]) -> list[str]:
        allowed_sets: list[set[str]] = []
        for field_name in field_names:
            field = self.protected_fields.get(field_name)
            if field is None:
                raise ValueError(
                    f"{self.kind} does not define protected field '{field_name}'"
                )
            if field.sensitivity_class == "non_revealable":
                raise ValueError(
                    f"{self.kind}.{field_name} cannot be revealed directly"
                )
            policy = REVEAL_DECISION_POLICIES.get(
                field.sensitivity_class or "protected_once",
                REVEAL_DECISION_POLICIES["protected_once"],
            )
            allowed_sets.append(set(policy))
        if not allowed_sets:
            raise ValueError("protected field names must not be empty")
        intersection = set.intersection(*allowed_sets)
        ordered = [
            decision
            for decision in ["approve_once", "approve_for_session"]
            if decision in intersection
        ]
        if not ordered:
            raise ValueError(
                f"protected field combination for {self.kind} did not produce an approval policy"
            )
        return ordered

    def update_allowed_decisions(self) -> list[str]:
        policy = UPDATE_DECISION_POLICIES.get(
            self.update_policy_class,
            UPDATE_DECISION_POLICIES["protected_once"],
        )
        return list(policy)

    def scope_presence_flags(
        self,
        *,
        protected_field_names: list[str],
        safe_metadata: dict[str, Any],
    ) -> dict[str, Any]:
        flags: dict[str, Any] = {}
        present_protected_fields = set(protected_field_names)
        for field in self.protected_fields.values():
            if field.presence_scope_key is None:
                continue
            flags[field.presence_scope_key] = field.field_name in present_protected_fields
        for field_name, field in self.safe_fields.items():
            if field.presence_scope_key is None:
                continue
            flags[field.presence_scope_key] = bool(safe_metadata.get(field_name))
        return flags


class VaultItemTypeRegistry:
    def __init__(self) -> None:
        self._types: dict[str, VaultItemTypeDefinition] = {}

    def register(self, definition: VaultItemTypeDefinition) -> None:
        self._types[definition.kind] = definition

    def list_type_ids(self) -> list[str]:
        return list(self._types.keys())

    def get_type(self, kind: str) -> VaultItemTypeDefinition | None:
        definition = self._types.get(kind)
        return copy.deepcopy(definition) if definition is not None else None

    def list_types(self) -> list[JsonObject]:
        return [copy.deepcopy(definition.catalog_entry) for definition in self._types.values()]

    @classmethod
    def with_builtins(cls) -> "VaultItemTypeRegistry":
        registry = cls()
        for definition in _builtin_vault_item_types():
            registry.register(definition)
        return registry

    @classmethod
    def load_installed(cls) -> "VaultItemTypeRegistry":
        registry = cls.with_builtins()

        eps = importlib.metadata.entry_points()
        if hasattr(eps, "select"):
            group_eps = eps.select(group="aperture.vault_item_types")
        else:
            group_eps = eps.get("aperture.vault_item_types", [])

        for ep in group_eps:
            try:
                loaded = ep.load()
                definition = (
                    loaded()
                    if callable(loaded) and not isinstance(loaded, VaultItemTypeDefinition)
                    else loaded
                )
                if isinstance(definition, VaultItemTypeDefinition):
                    registry.register(definition)
            except Exception:
                continue
        return registry


def _normalize_optional_string(
    value: Any, field_name: str, *, allow_empty: bool = False
) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string when provided")
    normalized = value.strip()
    if not allow_empty and not normalized:
        raise ValueError(f"{field_name} must not be empty")
    return normalized if normalized or allow_empty else None


def _normalize_agent_visible_note(value: Any, field_name: str) -> str | None:
    # Notes are intentionally returned in MCP search/list results so agents can
    # pick the right account later. Keep them one-line and small so a vault full
    # of helpful hints does not quietly balloon the requester's context window.
    normalized = _normalize_optional_string(value, field_name, allow_empty=True)
    if normalized is None:
        return None
    normalized = " ".join(normalized.split())
    if not normalized:
        return None
    if len(normalized) > SAFE_METADATA_NOTE_MAX_CHARS:
        raise ValueError(
            f"{field_name} must be {SAFE_METADATA_NOTE_MAX_CHARS} characters or fewer"
        )
    return normalized


def _coerce_int(value: Any, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field_name} must be an integer")
    return value


def _passes_luhn(digits: str) -> bool:
    total = 0
    parity = len(digits) % 2
    for index, digit_char in enumerate(digits):
        digit = int(digit_char)
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def _validate_allowed_keys(
    name: str, payload: dict[str, Any], allowed_keys: set[str]
) -> None:
    unexpected = sorted(set(payload.keys()) - allowed_keys)
    if unexpected:
        raise ValueError(
            f"{name} included unsupported fields: {', '.join(unexpected)}"
        )


def _copy_creator_reuse_safe_metadata(safe_metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        key: copy.deepcopy(value)
        for key, value in safe_metadata.items()
        if key in CREATOR_REUSE_SAFE_METADATA_FIELDS
    }


def _normalize_login_secret_payload(
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, str]]:
    # Browser agents need enough safe context to pick the right account and
    # fill non-password fields before Skyline submits the protected password.
    # `username` stays the primary login identifier and may itself be an email.
    allowed_safe = {
        "site",
        "username",
        "email",
        "login_url",
        "url",
        "notes",
        "account_note",
        *CREATOR_REUSE_SAFE_METADATA_FIELDS,
    }
    allowed_protected = {"password"}
    _validate_allowed_keys("safe_metadata", safe_metadata, allowed_safe)
    _validate_allowed_keys("protected_fields", protected_fields, allowed_protected)
    site = _normalize_optional_string(safe_metadata.get("site"), "safe_metadata.site")
    username = _normalize_optional_string(
        safe_metadata.get("username"), "safe_metadata.username"
    )
    email = _normalize_optional_string(
        safe_metadata.get("email"), "safe_metadata.email", allow_empty=True
    )
    login_url = _normalize_optional_string(
        safe_metadata.get("login_url") or safe_metadata.get("url"),
        "safe_metadata.login_url",
        allow_empty=True,
    )
    notes = _normalize_agent_visible_note(
        safe_metadata.get("notes") or safe_metadata.get("account_note"),
        "safe_metadata.notes",
    )
    password = _normalize_optional_string(
        protected_fields.get("password"), "protected_fields.password"
    )
    if site is None or username is None or password is None:
        raise ValueError(
            "login_secret requires safe_metadata.site, safe_metadata.username, and protected_fields.password"
        )
    normalized_safe = {"site": site, "username": username}
    if email and email != username:
        normalized_safe["email"] = email
    if login_url:
        normalized_safe["login_url"] = login_url
    if notes is not None:
        normalized_safe["notes"] = notes
    normalized_safe.update(_copy_creator_reuse_safe_metadata(safe_metadata))
    return normalized_safe, {"password": password}


def _normalize_api_token_payload(
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, str]]:
    allowed_safe = {"service", "label", "url", "username", "notes", *CREATOR_REUSE_SAFE_METADATA_FIELDS}
    allowed_protected = {"token"}
    _validate_allowed_keys("safe_metadata", safe_metadata, allowed_safe)
    _validate_allowed_keys("protected_fields", protected_fields, allowed_protected)
    service = _normalize_optional_string(
        safe_metadata.get("service"), "safe_metadata.service"
    )
    label = _normalize_optional_string(safe_metadata.get("label"), "safe_metadata.label")
    url = _normalize_optional_string(
        safe_metadata.get("url"), "safe_metadata.url", allow_empty=True
    )
    username = _normalize_optional_string(
        safe_metadata.get("username"), "safe_metadata.username"
    )
    notes = _normalize_agent_visible_note(
        safe_metadata.get("notes"), "safe_metadata.notes"
    )
    token = _normalize_optional_string(
        protected_fields.get("token"), "protected_fields.token"
    )
    if service is None or label is None or token is None:
        raise ValueError(
            "api_token requires safe_metadata.service, safe_metadata.label, and protected_fields.token"
        )
    normalized_safe = {"service": service, "label": label}
    if url:
        normalized_safe["url"] = url
    if username is not None:
        normalized_safe["username"] = username
    if notes is not None:
        normalized_safe["notes"] = notes
    normalized_safe.update(_copy_creator_reuse_safe_metadata(safe_metadata))
    return normalized_safe, {"token": token}


def _normalize_api_proxy_connection_payload(
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, str]]:
    allowed_safe = {
        "service",
        "label",
        "description",
        "when_to_use",
        "base_url",
        "allowed_hosts",
        "allowed_methods",
        "allowed_path_prefixes",
        "minimum_interval_ms",
        "auth_header_name",
        "auth_header_prefix",
        "static_headers",
    }
    allowed_protected = {"token"}
    _validate_allowed_keys("safe_metadata", safe_metadata, allowed_safe)
    _validate_allowed_keys("protected_fields", protected_fields, allowed_protected)
    service = _normalize_optional_string(
        safe_metadata.get("service"), "safe_metadata.service"
    )
    label = _normalize_optional_string(safe_metadata.get("label"), "safe_metadata.label")
    description = _normalize_optional_string(
        safe_metadata.get("description"), "safe_metadata.description", allow_empty=True
    )
    when_to_use = _normalize_optional_string(
        safe_metadata.get("when_to_use"), "safe_metadata.when_to_use", allow_empty=True
    )
    base_url = _normalize_optional_string(
        safe_metadata.get("base_url"), "safe_metadata.base_url", allow_empty=True
    )
    allowed_hosts_raw = safe_metadata.get("allowed_hosts")
    if allowed_hosts_raw is None:
        allowed_hosts: list[str] = []
    elif isinstance(allowed_hosts_raw, list):
        allowed_hosts = [
            str(value).strip()
            for value in allowed_hosts_raw
            if str(value).strip()
        ]
    else:
        raise ValueError("safe_metadata.allowed_hosts must be a list when provided")
    allowed_methods_raw = safe_metadata.get("allowed_methods")
    if allowed_methods_raw is None:
        allowed_methods: list[str] = []
    elif isinstance(allowed_methods_raw, list):
        allowed_methods = [
            str(value).strip().upper()
            for value in allowed_methods_raw
            if str(value).strip()
        ]
    else:
        raise ValueError("safe_metadata.allowed_methods must be a list when provided")
    allowed_path_prefixes_raw = safe_metadata.get("allowed_path_prefixes")
    if allowed_path_prefixes_raw is None:
        allowed_path_prefixes: list[str] = []
    elif isinstance(allowed_path_prefixes_raw, list):
        allowed_path_prefixes = []
        for value in allowed_path_prefixes_raw:
            candidate = str(value).strip()
            if not candidate:
                continue
            if not candidate.startswith("/"):
                candidate = "/" + candidate
            allowed_path_prefixes.append(candidate)
    else:
        raise ValueError(
            "safe_metadata.allowed_path_prefixes must be a list when provided"
        )
    minimum_interval_raw = safe_metadata.get("minimum_interval_ms")
    minimum_interval_ms = 0
    if minimum_interval_raw is not None:
        minimum_interval_ms = max(_coerce_int(minimum_interval_raw, "safe_metadata.minimum_interval_ms"), 0)
    auth_header_name = _normalize_optional_string(
        safe_metadata.get("auth_header_name"),
        "safe_metadata.auth_header_name",
        allow_empty=True,
    )
    auth_header_prefix = safe_metadata.get("auth_header_prefix")
    if auth_header_prefix is not None and not isinstance(auth_header_prefix, str):
        raise ValueError("safe_metadata.auth_header_prefix must be a string when provided")
    static_headers_raw = safe_metadata.get("static_headers")
    if static_headers_raw is None:
        static_headers: dict[str, str] = {}
    elif isinstance(static_headers_raw, dict):
        static_headers = {
            str(key).strip(): str(value)
            for key, value in static_headers_raw.items()
            if str(key).strip()
        }
    else:
        raise ValueError("safe_metadata.static_headers must be an object when provided")
    token = _normalize_optional_string(
        protected_fields.get("token"), "protected_fields.token"
    )
    if service is None or label is None or token is None:
        raise ValueError(
            "api_proxy_connection requires safe_metadata.service, safe_metadata.label, and protected_fields.token"
        )
    normalized_safe: dict[str, Any] = {
        "service": service,
        "label": label,
        "allowed_hosts": allowed_hosts,
        "allowed_methods": allowed_methods,
        "allowed_path_prefixes": allowed_path_prefixes,
        "minimum_interval_ms": minimum_interval_ms,
        "auth_header_name": auth_header_name or "Authorization",
        "auth_header_prefix": auth_header_prefix if auth_header_prefix is not None else "Bearer ",
        "static_headers": static_headers,
    }
    if description is not None:
        normalized_safe["description"] = description
    if when_to_use is not None:
        normalized_safe["when_to_use"] = when_to_use
    if base_url is not None:
        normalized_safe["base_url"] = base_url
    return normalized_safe, {"token": token}


def _normalize_payment_card_payload(
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, str]]:
    allowed_safe = {
        "brand",
        "cardholder_name",
        "expiry_month",
        "expiry_year",
        "billing_zip",
        "last4",
        "has_cvv",
    }
    allowed_protected = {"pan", "cvv"}
    _validate_allowed_keys("safe_metadata", safe_metadata, allowed_safe)
    _validate_allowed_keys("protected_fields", protected_fields, allowed_protected)
    brand = _normalize_optional_string(safe_metadata.get("brand"), "safe_metadata.brand")
    cardholder_name = _normalize_optional_string(
        safe_metadata.get("cardholder_name"), "safe_metadata.cardholder_name"
    )
    billing_zip = _normalize_optional_string(
        safe_metadata.get("billing_zip"), "safe_metadata.billing_zip"
    )
    expiry_month = _coerce_int(safe_metadata.get("expiry_month"), "safe_metadata.expiry_month")
    expiry_year = _coerce_int(safe_metadata.get("expiry_year"), "safe_metadata.expiry_year")
    raw_pan = _normalize_optional_string(protected_fields.get("pan"), "protected_fields.pan")
    raw_cvv = _normalize_optional_string(
        protected_fields.get("cvv"), "protected_fields.cvv"
    )
    if brand is None or cardholder_name is None or raw_pan is None:
        raise ValueError(
            "payment_card requires safe_metadata.brand, safe_metadata.cardholder_name, expiry_month, expiry_year, and protected_fields.pan"
        )
    if not 1 <= expiry_month <= 12:
        raise ValueError("safe_metadata.expiry_month must be between 1 and 12")
    if expiry_year < 2000 or expiry_year > 9999:
        raise ValueError("safe_metadata.expiry_year must be a four-digit year")
    pan_digits = re.sub(r"\D", "", raw_pan)
    if not PAN_RE.fullmatch(pan_digits):
        raise ValueError("protected_fields.pan must contain 13 to 19 digits")
    if not _passes_luhn(pan_digits):
        raise ValueError("protected_fields.pan did not pass Luhn validation")
    normalized_protected = {"pan": pan_digits}
    if raw_cvv is not None:
        cvv_digits = re.sub(r"\D", "", raw_cvv)
        if not CVV_RE.fullmatch(cvv_digits):
            raise ValueError("protected_fields.cvv must be 3 or 4 digits")
        normalized_protected["cvv"] = cvv_digits
    normalized_safe: dict[str, Any] = {
        "brand": brand,
        "cardholder_name": cardholder_name,
        "expiry_month": expiry_month,
        "expiry_year": expiry_year,
        "last4": pan_digits[-4:],
        "has_cvv": "cvv" in normalized_protected,
    }
    if billing_zip is not None:
        normalized_safe["billing_zip"] = billing_zip
    return normalized_safe, normalized_protected


def _build_catalog_entry(
    definition: VaultItemTypeDefinition,
) -> JsonObject:
    return {
        "kind": definition.kind,
        "display_name": definition.display_name,
        "fields": [
            {
                "field_name": field.field_name,
                "storage_target": field.storage_target,
                "visibility": field.visibility,
                "required": field.required,
                "value_type": field.value_type,
                "sensitivity_class": field.sensitivity_class,
                "custody_mode": field.custody_mode,
            }
            for field in list(definition.safe_fields.values()) + list(definition.protected_fields.values())
        ],
        "update_policy_class": definition.update_policy_class,
    }


def _creator_reuse_safe_fields() -> dict[str, VaultFieldDefinition]:
    return {
        "skyline_created_by_requester_display_name": VaultFieldDefinition(
            "skyline_created_by_requester_display_name",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_created_by_requester_app_id": VaultFieldDefinition(
            "skyline_created_by_requester_app_id",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_created_by_requester_app_principal_id": VaultFieldDefinition(
            "skyline_created_by_requester_app_principal_id",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_created_from_browser_action": VaultFieldDefinition(
            "skyline_created_from_browser_action",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_created_from_browser_origin": VaultFieldDefinition(
            "skyline_created_from_browser_origin",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_created_from_browser_url": VaultFieldDefinition(
            "skyline_created_from_browser_url",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
        "skyline_creator_reuse_expires_at_epoch_ms": VaultFieldDefinition(
            "skyline_creator_reuse_expires_at_epoch_ms",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
            value_type="integer",
        ),
        "skyline_creator_reuse_secret_use_tiers": VaultFieldDefinition(
            "skyline_creator_reuse_secret_use_tiers",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
            value_type="string_list",
        ),
        "skyline_creator_reuse_workflow_id": VaultFieldDefinition(
            "skyline_creator_reuse_workflow_id",
            "safe_metadata",
            FIELD_VISIBILITY_SUMMARY_ONLY,
        ),
    }


def _builtin_vault_item_types() -> list[VaultItemTypeDefinition]:
    definitions = [
        VaultItemTypeDefinition(
            kind="login_secret",
            display_name="Password",
            safe_fields={
                "site": VaultFieldDefinition(
                    "site", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "username": VaultFieldDefinition(
                    "username", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                # These stay searchable because requester agents use them to choose
                # the right account and fill ordinary login fields before Skyline
                # submits only the protected password.
                "email": VaultFieldDefinition(
                    "email", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "login_url": VaultFieldDefinition(
                    "login_url", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "notes": VaultFieldDefinition(
                    "notes", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                **_creator_reuse_safe_fields(),
            },
            protected_fields={
                "password": VaultFieldDefinition(
                    "password",
                    "protected",
                    FIELD_VISIBILITY_PROTECTED,
                    required=True,
                    sensitivity_class="credential_secret",
                    custody_mode=CUSTODY_MODE_BLIND_VALUE_RELEASE,
                )
            },
            normalize_payload=_normalize_login_secret_payload,
            update_policy_class="credential_item",
        ),
        VaultItemTypeDefinition(
            kind="api_token",
            display_name="API Token",
            safe_fields={
                "service": VaultFieldDefinition(
                    "service", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "label": VaultFieldDefinition(
                    "label", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "url": VaultFieldDefinition(
                    "url", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "username": VaultFieldDefinition(
                    "username", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "notes": VaultFieldDefinition(
                    "notes", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                **_creator_reuse_safe_fields(),
            },
            protected_fields={
                "token": VaultFieldDefinition(
                    "token",
                    "protected",
                    FIELD_VISIBILITY_PROTECTED,
                    required=True,
                    sensitivity_class="credential_secret",
                    custody_mode=CUSTODY_MODE_BLIND_VALUE_RELEASE,
                )
            },
            normalize_payload=_normalize_api_token_payload,
            update_policy_class="credential_item",
        ),
        VaultItemTypeDefinition(
            kind="api_proxy_connection",
            display_name="Connected App",
            safe_fields={
                "service": VaultFieldDefinition(
                    "service", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "label": VaultFieldDefinition(
                    "label", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "description": VaultFieldDefinition(
                    "description", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "when_to_use": VaultFieldDefinition(
                    "when_to_use", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "base_url": VaultFieldDefinition(
                    "base_url", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY
                ),
                "allowed_hosts": VaultFieldDefinition(
                    "allowed_hosts", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY, value_type="string_list"
                ),
                "allowed_methods": VaultFieldDefinition(
                    "allowed_methods", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY, value_type="string_list"
                ),
                "allowed_path_prefixes": VaultFieldDefinition(
                    "allowed_path_prefixes", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY, value_type="string_list"
                ),
                "minimum_interval_ms": VaultFieldDefinition(
                    "minimum_interval_ms", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY, value_type="integer"
                ),
                "auth_header_name": VaultFieldDefinition(
                    "auth_header_name", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY
                ),
                "auth_header_prefix": VaultFieldDefinition(
                    "auth_header_prefix", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY
                ),
                "static_headers": VaultFieldDefinition(
                    "static_headers", "safe_metadata", FIELD_VISIBILITY_SUMMARY_ONLY, value_type="object"
                ),
            },
            protected_fields={
                "token": VaultFieldDefinition(
                    "token",
                    "protected",
                    FIELD_VISIBILITY_PROTECTED,
                    required=True,
                    sensitivity_class="non_revealable",
                    custody_mode=CUSTODY_MODE_AUTHORITY_USABLE,
                )
            },
            normalize_payload=_normalize_api_proxy_connection_payload,
            update_policy_class="credential_item",
        ),
        VaultItemTypeDefinition(
            kind="payment_card",
            display_name="Payment Card",
            safe_fields={
                "brand": VaultFieldDefinition(
                    "brand", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "cardholder_name": VaultFieldDefinition(
                    "cardholder_name",
                    "safe_metadata",
                    FIELD_VISIBILITY_SEARCHABLE,
                    required=True,
                ),
                "expiry_month": VaultFieldDefinition(
                    "expiry_month", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True, value_type="integer"
                ),
                "expiry_year": VaultFieldDefinition(
                    "expiry_year", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True, value_type="integer"
                ),
                "billing_zip": VaultFieldDefinition(
                    "billing_zip", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE
                ),
                "last4": VaultFieldDefinition(
                    "last4", "safe_metadata", FIELD_VISIBILITY_SEARCHABLE, required=True
                ),
                "has_cvv": VaultFieldDefinition(
                    "has_cvv",
                    "safe_metadata",
                    FIELD_VISIBILITY_SUMMARY_ONLY,
                    required=True,
                    value_type="boolean",
                    presence_scope_key="has_cvv",
                ),
            },
            protected_fields={
                "pan": VaultFieldDefinition(
                    "pan",
                    "protected",
                    FIELD_VISIBILITY_PROTECTED,
                    required=True,
                    sensitivity_class="payment_card_pan",
                    presence_scope_key="has_pan",
                    custody_mode=CUSTODY_MODE_BLIND_VALUE_RELEASE,
                ),
                "cvv": VaultFieldDefinition(
                    "cvv",
                    "protected",
                    FIELD_VISIBILITY_PROTECTED,
                    sensitivity_class="payment_card_cvv",
                    presence_scope_key="has_cvv",
                    custody_mode=CUSTODY_MODE_BLIND_VALUE_RELEASE,
                ),
            },
            normalize_payload=_normalize_payment_card_payload,
            update_policy_class="payment_card_item",
        ),
    ]
    return [
        VaultItemTypeDefinition(
            kind=definition.kind,
            display_name=definition.display_name,
            safe_fields=definition.safe_fields,
            protected_fields=definition.protected_fields,
            normalize_payload=definition.normalize_payload,
            update_policy_class=definition.update_policy_class,
            catalog_entry=_build_catalog_entry(definition),
            title_searchable=definition.title_searchable,
        )
        for definition in definitions
    ]


_default_registry: VaultItemTypeRegistry | None = None


def _registry() -> VaultItemTypeRegistry:
    global _default_registry
    if _default_registry is None:
        _default_registry = VaultItemTypeRegistry.load_installed()
    return _default_registry


def list_vault_item_type_ids() -> list[str]:
    return _registry().list_type_ids()


def list_vault_item_types() -> list[JsonObject]:
    return _registry().list_types()


def get_vault_item_type(kind: str) -> VaultItemTypeDefinition | None:
    return _registry().get_type(kind)
