from __future__ import annotations

from importlib import import_module
from pathlib import Path
import sys


def _load_packaged_or_source_main(module_name: str):
    packaged_name = f"skyline_requester.{module_name}"
    try:
        return import_module(packaged_name).main
    except ModuleNotFoundError as exc:
        if exc.name != packaged_name:
            raise
        repo_core = Path(__file__).resolve().parents[2] / "core"
        source_module = repo_core / "aperture_core" / f"{module_name}.py"
        if not source_module.exists():
            raise
        if str(repo_core) not in sys.path:
            sys.path.insert(0, str(repo_core))
        return import_module(f"aperture_core.{module_name}").main


def _load_packaged_or_source_attr(module_name: str, attr_name: str):
    packaged_name = f"skyline_requester.{module_name}"
    try:
        return getattr(import_module(packaged_name), attr_name)
    except ModuleNotFoundError as exc:
        if exc.name != packaged_name:
            raise
        repo_core = Path(__file__).resolve().parents[2] / "core"
        source_module = repo_core / "aperture_core" / f"{module_name}.py"
        if not source_module.exists():
            raise
        if str(repo_core) not in sys.path:
            sys.path.insert(0, str(repo_core))
        return getattr(import_module(f"aperture_core.{module_name}"), attr_name)


browser_host_main = _load_packaged_or_source_main("browser_host_helper")
delivery_helper_main = _load_packaged_or_source_main("delivery_helper_cli")
local_requester_main = _load_packaged_or_source_main("local_requester")
requester_cli_usage_guidance = _load_packaged_or_source_attr(
    "mcp_setup_guidance",
    "requester_cli_usage_guidance",
)


SKYLINE_BANNER = r"""
   ___|   |            | _)
 \___ \   |  /  |   |  |  |  __ \    _ \
       |    <   |   |  |  |  |   |   __/
 _____/  _|\_\ \__, | _| _| _|  _| \___|
               ____/
""".strip("\n")

USAGE = (
    f"{SKYLINE_BANNER}\n\n"
    "Skyline\n"
    "Set up this machine once, then let agents use Skyline through local MCP.\n\n"
    "Usage:\n"
    "  skyline setup --core-base-url <url> --setup-code <code>\n"
    "  skyline import\n"
    "  skyline mcp command <agent>\n"
    "  skyline bridge serve\n"
    "  skyline version\n"
    "  skyline update\n"
    "  skyline erase-connection\n\n"
    f"{requester_cli_usage_guidance()}\n\n"
    "After setup, agents should use the Skyline MCP tools through "
    "`skyline bridge serve`."
)
REQUESTER_COMMANDS = {
    "version",
    "update",
    "mcp",
    "mcp-command",
    "bridge",
    "import",
    "setup",
    "erase-connection",
}
REQUESTER_GLOBAL_OPTIONS_WITH_VALUES = {
    "--bootstrap-secret-file",
    "--config-path",
}


def _consume_requester_global_option(
    argv: list[str], index: int
) -> tuple[list[str] | None, int]:
    token = argv[index]
    for option in REQUESTER_GLOBAL_OPTIONS_WITH_VALUES:
        if token == option:
            if index + 1 >= len(argv):
                raise SystemExit(f"argument {option}: expected one argument")
            return [token, argv[index + 1]], index + 2
        if token.startswith(f"{option}="):
            return [token], index + 1
    return None, index


def _first_non_global_arg(argv: list[str]) -> str:
    index = 0
    while index < len(argv):
        consumed, next_index = _consume_requester_global_option(argv, index)
        if consumed is not None:
            index = next_index
            continue
        return argv[index]
    return ""


def _local_requester_argv(argv: list[str]) -> list[str]:
    global_args: list[str] = []
    command_args: list[str] = []
    index = 0
    while index < len(argv):
        consumed, next_index = _consume_requester_global_option(argv, index)
        if consumed is not None:
            global_args.extend(consumed)
            index = next_index
            continue
        command_args.append(argv[index])
        index += 1

    if command_args[:2] == ["bridge", "serve"]:
        return [*global_args, "bridge-serve", *command_args[2:]]
    if command_args[:1] == ["bridge"]:
        if len(command_args) == 1 or command_args[1] in {"-h", "--help"}:
            return [*global_args, "bridge-serve", "--help"]
        raise SystemExit("usage: skyline bridge serve [options]")
    if command_args[:2] == ["mcp", "command"]:
        return [*global_args, "mcp-command", *command_args[2:]]
    if command_args[:1] == ["mcp"]:
        if len(command_args) == 1 or command_args[1] in {"-h", "--help"}:
            return [*global_args, "mcp-command", "--help"]
        raise SystemExit("usage: skyline mcp command <agent>")
    return [*global_args, *command_args]


def _help_target_argv(argv: list[str]) -> list[str] | None:
    global_args: list[str] = []
    command_args: list[str] = []
    index = 0
    while index < len(argv):
        consumed, next_index = _consume_requester_global_option(argv, index)
        if consumed is not None:
            global_args.extend(consumed)
            index = next_index
            continue
        command_args.append(argv[index])
        index += 1

    if command_args[:1] != ["help"]:
        return None
    if len(command_args) == 1:
        return []
    return [*global_args, *command_args[1:], "--help"]


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if not args or args[0] in {"-h", "--help"}:
        print(USAGE)
        return 0
    help_args = _help_target_argv(args)
    if help_args is not None:
        if not help_args:
            print(USAGE)
            return 0
        command = _first_non_global_arg(help_args)
        if command in REQUESTER_COMMANDS:
            return int(local_requester_main(_local_requester_argv(help_args)) or 0)
        if command == "delivery-helper":
            return int(delivery_helper_main(["--help"]) or 0)
        if command == "browser-host":
            return int(browser_host_main(["--help"]) or 0)
        raise SystemExit(
            "unknown command "
            f"'{command}'; expected one of the commands in:\n"
            + USAGE
        )
    command = _first_non_global_arg(args)
    if command in REQUESTER_COMMANDS:
        return int(local_requester_main(_local_requester_argv(args)) or 0)
    command = args[0]
    if command == "delivery-helper":
        return int(delivery_helper_main(args[1:]) or 0)
    if command == "browser-host":
        return int(browser_host_main(args[1:]) or 0)
    raise SystemExit(
        "unknown command "
        f"'{command}'; expected one of the commands in:\n"
        + USAGE
    )


if __name__ == "__main__":
    raise SystemExit(main())
