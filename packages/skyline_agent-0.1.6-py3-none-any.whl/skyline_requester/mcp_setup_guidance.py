from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

DEFAULT_SKYLINE_COMMAND = "skyline"
SHELL_SKYLINE_COMMAND = "$(command -v skyline)"
SETUP_SCRIPT_SKYLINE_COMMAND = "$SKYLINE_CLI_COMMAND"
MCP_COMMAND_HELPER = "skyline mcp command"
MCP_SETUP_GUIDANCE_JSON_ENV = "SKYLINE_MCP_SETUP_GUIDANCE_JSON"
MCP_SETUP_GUIDANCE_PATH_ENV = "SKYLINE_MCP_SETUP_GUIDANCE_PATH"
MCP_SETUP_GUIDANCE_UPDATED_AT = "2026-05-15"
ALLOWED_MCP_HELPER_IDS = {
    "claude",
    "codex",
    "codex-desktop",
    "cursor",
    "openclaw",
    "other",
    "all",
}
_GUIDANCE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")


def codex_cli_setup_command(command: str = SHELL_SKYLINE_COMMAND) -> str:
    return f'codex mcp add skyline -- "{command}" bridge serve'


def claude_code_setup_command(command: str = SHELL_SKYLINE_COMMAND) -> str:
    return f'claude mcp add --scope user skyline -- "{command}" bridge serve'


def cursor_mcp_json(command: str) -> str:
    return (
        '{"mcpServers":{"skyline":{"type":"stdio","command":"'
        + command
        + '","args":["bridge","serve"]}}}'
    )


def openclaw_setup_command(command: str = SHELL_SKYLINE_COMMAND) -> str:
    return (
        "openclaw mcp set skyline "
        f'\'{{"command":"{command}","args":["bridge","serve"]}}\''
    )


def mcp_command_helper(agent: str) -> str:
    return f"{MCP_COMMAND_HELPER} {agent}"


def command_run_prompt(agent_name: str) -> str:
    return f"To set up {agent_name} with the Skyline MCP, copy and run this command:"


def agent_command_output_lines(agent: str, command: str) -> list[str]:
    normalized = agent.strip().lower()
    if normalized in {"claude", "claude-code", "claude-cowork", "cowork"}:
        return [
            command_run_prompt("Claude Code"),
            claude_code_setup_command(command),
        ]
    if normalized == "codex":
        return [
            command_run_prompt("Codex CLI"),
            codex_cli_setup_command(command),
        ]
    if normalized in {"codex-desktop", "codex-app"}:
        return [
            "Codex Desktop:",
            "Paste these values into Settings > MCP servers > Add > STDIO.",
            "Name: Skyline",
            "Transport: STDIO",
            f"Command to launch: {command}",
            "Arguments:",
            "  bridge",
            "  serve",
            "Environment variables: leave blank",
            "Environment variable passthrough: leave blank",
            "Working directory: leave blank",
            "",
            "Use the full Command to launch path shown above. Desktop apps may not see the same PATH as Terminal, so plain `skyline` can fail.",
        ]
    if normalized == "cursor":
        return [
            "Cursor Desktop:",
            "Use Settings > MCP, or put this in ~/.cursor/mcp.json:",
            cursor_mcp_json(command),
        ]
    if normalized == "openclaw":
        return [
            command_run_prompt("OpenClaw"),
            openclaw_setup_command(command),
        ]
    if normalized == "other":
        return [
            "Other local MCP apps:",
            "Name: Skyline",
            "Transport: STDIO",
            f"Command: {command}",
            "Arguments: bridge, serve",
        ]
    if normalized == "all":
        lines: list[str] = []
        for item in ["claude", "codex", "codex-desktop", "cursor", "openclaw", "other"]:
            if lines:
                lines.append("")
            lines.extend(agent_command_output_lines(item, command))
        return lines
    raise ValueError(f"unknown agent '{agent}'")


def local_mcp_ui_settings(command: str = DEFAULT_SKYLINE_COMMAND) -> list[str]:
    return [
        "Local MCP UI settings:",
        "  Name: Skyline",
        "  Transport: STDIO",
        f"  Command: {command}",
        "  Arguments: bridge, serve",
    ]


def requester_cli_usage_guidance() -> str:
    return "\n".join(
        [
            "Agent setup examples:",
            f"  Claude Code / Cowork: {mcp_command_helper('claude')}",
            f"  Codex CLI: {mcp_command_helper('codex')}",
            "",
            *local_mcp_ui_settings(),
        ]
    )


def local_requester_epilog() -> str:
    return (
        "Normal agent setup examples:\n"
        f"  Claude Code / Cowork: {mcp_command_helper('claude')}\n"
        f"  Codex CLI: {mcp_command_helper('codex')}\n\n"
        + "\n".join(local_mcp_ui_settings())
        + "\n\nThis is a local MCP, not a remote MCP.\n\n"
        "Agents should use the Skyline MCP tools through `skyline bridge serve`."
    )


def setup_command_description() -> str:
    return (
        "Set up this machine for Skyline. After setup completes, add Skyline "
        "to your agent app as a local STDIO MCP server. Run "
        f"`{mcp_command_helper('claude')}`, `{mcp_command_helper('codex')}`, "
        "or `skyline mcp command all` to print exact copyable setup commands."
    )


def setup_script_guidance_lines(command: str = SETUP_SCRIPT_SKYLINE_COMMAND) -> list[str]:
    return [
        "Next, connect Skyline to your agent app. This is a local MCP, not a remote MCP.",
        "",
        "Codex CLI:",
        f"  {command_run_prompt('Codex CLI')}",
        f"  {codex_cli_setup_command(command)}",
        "",
        "Codex Desktop:",
        "  Settings > MCP servers > Add, choose STDIO.",
        "  Paste these values into the matching fields:",
        "  Name: Skyline",
        f"  Command to launch: {command}",
        "  Arguments: bridge and serve as separate rows",
        "  Leave environment variables, environment variable passthrough, and working directory blank.",
        "",
        "Claude:",
        f"  {command_run_prompt('Claude Code')}",
        f"  {claude_code_setup_command(command)}",
        "",
        "Cursor Desktop:",
        "  Use Settings > MCP, or create ~/.cursor/mcp.json with:",
        f"  {cursor_mcp_json(command)}",
        "",
        "OpenClaw:",
        f"  {command_run_prompt('OpenClaw')}",
        f"  {openclaw_setup_command(command)}",
        "",
        "Other local MCP apps:",
        f"  Name Skyline, transport STDIO, command {command}, arguments bridge and serve.",
    ]


def startup_snippet_guidance_lines() -> list[str]:
    return [
        "after setup, choose a local STDIO MCP setup path:",
        f"  Claude Code / Cowork: {mcp_command_helper('claude')}",
        f"  Codex CLI: {mcp_command_helper('codex')}",
        f"  Codex Desktop: {mcp_command_helper('codex-desktop')}",
        f"  Local MCP UI: {mcp_command_helper('other')}",
        "  This is a local MCP, not a remote MCP.",
    ]


def default_mcp_setup_guidance() -> dict[str, Any]:
    return {
        "version": 1,
        "updated_at": MCP_SETUP_GUIDANCE_UPDATED_AT,
        "remote_url_warning": "This is a local MCP, not a remote MCP.",
        "recipes": [
            {
                "id": "codex_desktop",
                "title": "Codex Desktop",
                "summary": "Fill in Codex's MCP server form with the values Skyline prints.",
                "helper_command_id": "codex-desktop",
                "steps": [
                    "Run the helper command shown here.",
                    "Paste the printed values into Codex Settings > MCP servers > Add > STDIO.",
                ],
                "fields": [
                    {"title": "Name", "value": "Skyline"},
                    {"title": "Transport", "value": "STDIO"},
                    {
                        "title": "Command to launch",
                        "value": "the Command to launch value Skyline prints",
                    },
                    {"title": "Arguments", "value": "bridge\nserve"},
                    {"title": "Environment variables", "value": "blank"},
                    {"title": "Environment variable passthrough", "value": "blank"},
                    {"title": "Working directory", "value": "blank"},
                ],
            },
            {
                "id": "codex_cli",
                "title": "Codex CLI",
                "summary": "Add Skyline with one command.",
                "helper_command_id": "codex",
                "steps": [
                    "Run the helper command shown here.",
                    "Then run the command Skyline prints.",
                ],
                "fields": [],
            },
            {
                "id": "claude",
                "title": "Claude",
                "summary": "Use this for Claude Code CLI, Claude Code Desktop, and Cowork.",
                "helper_command_id": "claude",
                "steps": [
                    "Run the helper command shown here.",
                    "Then run the command Skyline prints.",
                ],
                "fields": [],
            },
            {
                "id": "cursor_desktop",
                "title": "Cursor Desktop",
                "summary": "Add Skyline from Cursor Settings or your Cursor MCP file.",
                "helper_command_id": "cursor",
                "steps": [
                    "Run the helper command shown here.",
                    "Paste the printed JSON into ~/.cursor/mcp.json, or use the same values in Cursor Settings > MCP.",
                ],
                "fields": [],
            },
            {
                "id": "openclaw",
                "title": "OpenClaw",
                "summary": "Add Skyline with one command.",
                "helper_command_id": "openclaw",
                "steps": [
                    "Run the helper command shown here.",
                    "Then run the command Skyline prints.",
                ],
                "fields": [],
            },
            {
                "id": "other",
                "title": "Other",
                "summary": "Use this only if your app has a local or STDIO MCP form.",
                "helper_command_id": "other",
                "steps": [
                    "Run the helper command shown here.",
                    "Use the printed values in your app's local MCP form.",
                ],
                "fields": [
                    {"title": "Name", "value": "Skyline"},
                    {"title": "Transport", "value": "STDIO or local command"},
                    {
                        "title": "Command",
                        "value": "the Command value Skyline prints",
                    },
                    {"title": "Arguments", "value": "bridge\nserve"},
                    {"title": "Environment variables", "value": "blank"},
                    {"title": "Working directory", "value": "blank"},
                ],
            },
        ],
    }


def _clean_guidance_text(value: Any, *, max_length: int, default: str = "") -> str:
    if not isinstance(value, str):
        return default
    cleaned = value.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not cleaned:
        return default
    return cleaned[:max_length]


def _validated_guidance_field(raw_field: Any) -> dict[str, str] | None:
    if not isinstance(raw_field, dict):
        return None
    title = _clean_guidance_text(raw_field.get("title"), max_length=80)
    value = _clean_guidance_text(raw_field.get("value"), max_length=400)
    if not title or not value:
        return None
    return {"title": title, "value": value}


def _validated_guidance_recipe(raw_recipe: Any) -> dict[str, Any] | None:
    if not isinstance(raw_recipe, dict):
        return None
    recipe_id = _clean_guidance_text(raw_recipe.get("id"), max_length=64)
    if not recipe_id or _GUIDANCE_ID_RE.fullmatch(recipe_id) is None:
        return None
    title = _clean_guidance_text(raw_recipe.get("title"), max_length=80)
    summary = _clean_guidance_text(raw_recipe.get("summary"), max_length=800)
    if not title or not summary:
        return None
    helper_command_id = _clean_guidance_text(
        raw_recipe.get("helper_command_id"),
        max_length=64,
    )
    if helper_command_id and helper_command_id not in ALLOWED_MCP_HELPER_IDS:
        return None
    raw_steps = raw_recipe.get("steps")
    steps = [
        step
        for step in (
            _clean_guidance_text(item, max_length=300)
            for item in (raw_steps if isinstance(raw_steps, list) else [])
        )
        if step
    ][:8]
    raw_fields = raw_recipe.get("fields")
    fields = [
        field
        for field in (
            _validated_guidance_field(item)
            for item in (raw_fields if isinstance(raw_fields, list) else [])
        )
        if field is not None
    ][:10]
    return {
        "id": recipe_id,
        "title": title,
        "summary": summary,
        "helper_command_id": helper_command_id or None,
        "steps": steps,
        "fields": fields,
    }


def validated_mcp_setup_guidance(raw_guidance: Any) -> dict[str, Any] | None:
    if not isinstance(raw_guidance, dict):
        return None
    source = raw_guidance.get("guidance") if isinstance(raw_guidance.get("guidance"), dict) else raw_guidance
    version = source.get("version", 1)
    if not isinstance(version, int) or version < 1:
        return None
    raw_recipes = source.get("recipes")
    recipes = [
        recipe
        for recipe in (
            _validated_guidance_recipe(item)
            for item in (raw_recipes if isinstance(raw_recipes, list) else [])
        )
        if recipe is not None
    ][:12]
    if not recipes:
        return None
    fallback = default_mcp_setup_guidance()
    return {
        "version": version,
        "updated_at": _clean_guidance_text(source.get("updated_at"), max_length=40),
        "remote_url_warning": _clean_guidance_text(
            source.get("remote_url_warning"),
            max_length=240,
            default=fallback["remote_url_warning"],
        ),
        "recipes": recipes,
    }


def load_mcp_setup_guidance() -> dict[str, Any]:
    raw_path = os.environ.get(MCP_SETUP_GUIDANCE_PATH_ENV, "").strip()
    if raw_path:
        try:
            loaded = json.loads(Path(raw_path).expanduser().read_text(encoding="utf-8"))
            validated = validated_mcp_setup_guidance(loaded)
            if validated is not None:
                return validated
        except Exception:
            pass

    raw_json = os.environ.get(MCP_SETUP_GUIDANCE_JSON_ENV, "").strip()
    if raw_json:
        try:
            loaded = json.loads(raw_json)
            validated = validated_mcp_setup_guidance(loaded)
            if validated is not None:
                return validated
        except Exception:
            pass

    return default_mcp_setup_guidance()


def mcp_setup_guidance_response() -> dict[str, Any]:
    return {"guidance": load_mcp_setup_guidance()}
