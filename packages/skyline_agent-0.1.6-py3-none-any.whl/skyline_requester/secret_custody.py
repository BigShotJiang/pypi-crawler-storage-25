from __future__ import annotations

import base64
import hashlib
import os
import uuid
from dataclasses import dataclass
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

from .delivery_crypto import (
    ADMIN_KEY_ALGORITHM,
    DELIVERY_KEY_ALGORITHM,
    canonical_json,
    fingerprint_public_key,
    open_sealed_payload,
    seal_payload_to_public_key,
)


CUSTODY_MODE_BLIND_VALUE_RELEASE = "blind_value_release"
CUSTODY_MODE_BLIND_PROTOCOL_LOCAL_USE = "blind_protocol_local_use"
CUSTODY_MODE_AUTHORITY_USABLE = "authority_usable"

BLIND_CUSTODY_MODES = {
    CUSTODY_MODE_BLIND_PROTOCOL_LOCAL_USE,
    CUSTODY_MODE_BLIND_VALUE_RELEASE,
}
SUPPORTED_CUSTODY_MODES = BLIND_CUSTODY_MODES | {CUSTODY_MODE_AUTHORITY_USABLE}

BLIND_SECRET_PACKAGE_VERSION = 1
LEGACY_BLIND_SECRET_PACKAGE_ALGORITHM = "chacha20poly1305_data_key_x25519_wrap_v1"
BLIND_SECRET_PACKAGE_ALGORITHM = "chacha20poly1305_data_key_recipient_wrap_v1"
SUPPORTED_RECIPIENT_KEY_ALGORITHMS = {
    ADMIN_KEY_ALGORITHM,
    DELIVERY_KEY_ALGORITHM,
}


def _b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64decode(data: str) -> bytes:
    padding = "=" * ((4 - len(data) % 4) % 4)
    return base64.urlsafe_b64decode((data + padding).encode("ascii"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def nowless_package_id() -> str:
    return f"blindpkg_{uuid.uuid4().hex}"


def validate_custody_mode(custody_mode: str) -> str:
    normalized = str(custody_mode or "").strip()
    if normalized not in SUPPORTED_CUSTODY_MODES:
        raise ValueError(
            "custody_mode must be one of: " + ", ".join(sorted(SUPPORTED_CUSTODY_MODES))
        )
    return normalized


def is_blind_custody_mode(custody_mode: str) -> bool:
    return validate_custody_mode(custody_mode) in BLIND_CUSTODY_MODES


@dataclass(frozen=True, slots=True)
class RecipientKeyReference:
    key_holder_id: str
    public_key: str
    key_id: str
    key_version: int
    status: str = "active"
    key_algorithm: str = DELIVERY_KEY_ALGORITHM

    @property
    def key_fingerprint(self) -> str:
        return fingerprint_public_key(self.public_key)


@dataclass(frozen=True, slots=True)
class RecipientKeyWrap:
    key_holder_id: str
    key_id: str
    key_fingerprint: str
    key_version: int
    algorithm: str
    wrapped_data_key_envelope: dict[str, Any]

    def to_json(self) -> dict[str, Any]:
        return {
            "key_holder_id": self.key_holder_id,
            "key_id": self.key_id,
            "key_fingerprint": self.key_fingerprint,
            "key_version": self.key_version,
            "algorithm": self.algorithm,
            "wrapped_data_key_envelope": dict(self.wrapped_data_key_envelope),
        }

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "RecipientKeyWrap":
        return cls(
            key_holder_id=str(payload["key_holder_id"]),
            key_id=str(payload["key_id"]),
            key_fingerprint=str(payload["key_fingerprint"]),
            key_version=int(payload["key_version"]),
            algorithm=str(payload["algorithm"]),
            wrapped_data_key_envelope=dict(payload["wrapped_data_key_envelope"]),
        )


@dataclass(frozen=True, slots=True)
class StoredBlindSecretPackage:
    version: int
    package_id: str
    item_id: str
    field_name: str
    item_revision: int
    custody_mode: str
    algorithm: str
    nonce: str
    ciphertext: str
    aad: dict[str, Any]
    recipient_key_wraps: list[RecipientKeyWrap]
    created_at_epoch_ms: int

    def to_json(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "package_id": self.package_id,
            "item_id": self.item_id,
            "field_name": self.field_name,
            "item_revision": self.item_revision,
            "custody_mode": self.custody_mode,
            "algorithm": self.algorithm,
            "nonce": self.nonce,
            "ciphertext": self.ciphertext,
            "aad": dict(self.aad),
            "recipient_key_wraps": [
                key_wrap.to_json() for key_wrap in self.recipient_key_wraps
            ],
            "created_at_epoch_ms": self.created_at_epoch_ms,
        }

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "StoredBlindSecretPackage":
        return cls(
            version=int(payload["version"]),
            package_id=str(payload["package_id"]),
            item_id=str(payload["item_id"]),
            field_name=str(payload["field_name"]),
            item_revision=int(payload["item_revision"]),
            custody_mode=validate_custody_mode(str(payload["custody_mode"])),
            algorithm=str(payload["algorithm"]),
            nonce=str(payload["nonce"]),
            ciphertext=str(payload["ciphertext"]),
            aad=dict(payload["aad"]),
            recipient_key_wraps=[
                RecipientKeyWrap.from_json(dict(key_wrap))
                for key_wrap in payload.get("recipient_key_wraps", [])
            ],
            created_at_epoch_ms=int(payload["created_at_epoch_ms"]),
        )

    def key_wrap_for(
        self,
        *,
        key_holder_id: str,
        key_version: int | None = None,
    ) -> RecipientKeyWrap | None:
        for key_wrap in self.recipient_key_wraps:
            if key_wrap.key_holder_id != key_holder_id:
                continue
            if key_version is not None and key_wrap.key_version != key_version:
                continue
            return key_wrap
        return None

    def narrowed_to_key_holder(
        self,
        *,
        key_holder_id: str,
        key_version: int | None = None,
    ) -> "StoredBlindSecretPackage":
        key_wrap = self.key_wrap_for(
            key_holder_id=key_holder_id,
            key_version=key_version,
        )
        if key_wrap is None:
            raise ValueError("no matching recipient key wrap for blind package")
        return StoredBlindSecretPackage(
            version=self.version,
            package_id=self.package_id,
            item_id=self.item_id,
            field_name=self.field_name,
            item_revision=self.item_revision,
            custody_mode=self.custody_mode,
            algorithm=self.algorithm,
            nonce=self.nonce,
            ciphertext=self.ciphertext,
            aad=dict(self.aad),
            recipient_key_wraps=[key_wrap],
            created_at_epoch_ms=self.created_at_epoch_ms,
        )


@dataclass(frozen=True, slots=True)
class AuthorityUsableSecretRecord:
    """A marker for credentials usable by the protected authority.

    This intentionally does not define a plaintext storage format. It exists so
    code can distinguish proxy/minting roots from blind normal-secret packages.
    """

    version: int
    item_id: str
    field_name: str
    item_revision: int
    custody_mode: str
    protected_reference: dict[str, Any]

    def __post_init__(self) -> None:
        if self.custody_mode != CUSTODY_MODE_AUTHORITY_USABLE:
            raise ValueError("authority-usable records must use authority_usable custody")


def build_stored_blind_secret_package(
    *,
    item_id: str,
    field_name: str,
    item_revision: int,
    plaintext_value: str,
    custody_mode: str,
    recipients: list[RecipientKeyReference],
    created_at_epoch_ms: int,
    package_id: str | None = None,
) -> StoredBlindSecretPackage:
    normalized_custody = validate_custody_mode(custody_mode)
    if normalized_custody == CUSTODY_MODE_AUTHORITY_USABLE:
        raise ValueError("authority-usable credentials cannot be stored as blind packages")
    if not recipients:
        raise ValueError("blind secret packages require at least one recipient key")
    for recipient in recipients:
        if recipient.status != "active":
            raise ValueError(f"recipient '{recipient.key_holder_id}' is not active")
        if recipient.key_version < 1:
            raise ValueError("recipient key_version must be positive")
        if recipient.key_algorithm not in SUPPORTED_RECIPIENT_KEY_ALGORITHMS:
            raise ValueError(
                f"unsupported recipient key algorithm '{recipient.key_algorithm}'"
            )

    resolved_package_id = package_id or nowless_package_id()
    data_key = os.urandom(32)
    nonce = os.urandom(12)
    aad = {
        "version": BLIND_SECRET_PACKAGE_VERSION,
        "package_id": resolved_package_id,
        "item_id": item_id,
        "field_name": field_name,
        "item_revision": int(item_revision),
        "custody_mode": normalized_custody,
    }
    ciphertext = ChaCha20Poly1305(data_key).encrypt(
        nonce,
        plaintext_value.encode("utf-8"),
        canonical_json(aad).encode("utf-8"),
    )
    key_wraps = [
        _wrap_data_key(
            data_key=data_key,
            package_aad=aad,
            recipient=recipient,
        )
        for recipient in recipients
    ]
    return StoredBlindSecretPackage(
        version=BLIND_SECRET_PACKAGE_VERSION,
        package_id=resolved_package_id,
        item_id=item_id,
        field_name=field_name,
        item_revision=int(item_revision),
        custody_mode=normalized_custody,
        algorithm=BLIND_SECRET_PACKAGE_ALGORITHM,
        nonce=_b64encode(nonce),
        ciphertext=_b64encode(ciphertext),
        aad=aad,
        recipient_key_wraps=key_wraps,
        created_at_epoch_ms=int(created_at_epoch_ms),
    )


def decrypt_stored_blind_secret_package(
    package: StoredBlindSecretPackage,
    *,
    key_holder_id: str,
    private_key: str,
    key_version: int | None = None,
) -> str:
    if package.algorithm != BLIND_SECRET_PACKAGE_ALGORITHM:
        if package.algorithm == LEGACY_BLIND_SECRET_PACKAGE_ALGORITHM:
            raise ValueError(
                "legacy blind package algorithm requires reset and re-pair for launch"
            )
        raise ValueError(f"unsupported blind package algorithm '{package.algorithm}'")
    if package.custody_mode not in BLIND_CUSTODY_MODES:
        raise ValueError("only blind custody packages can be locally decrypted")
    key_wrap = package.key_wrap_for(
        key_holder_id=key_holder_id,
        key_version=key_version,
    )
    if key_wrap is None:
        raise ValueError("no matching recipient key wrap for blind package")
    wrapped_payload = open_sealed_payload(
        key_wrap.wrapped_data_key_envelope,
        private_key=private_key,
    )
    if wrapped_payload.get("package_aad_sha256") != sha256_json(package.aad):
        raise ValueError("recipient key wrap does not match package aad")
    data_key = _b64decode(str(wrapped_payload["data_key"]))
    plaintext = ChaCha20Poly1305(data_key).decrypt(
        _b64decode(package.nonce),
        _b64decode(package.ciphertext),
        canonical_json(package.aad).encode("utf-8"),
    )
    return plaintext.decode("utf-8")


def rewrap_stored_blind_secret_package(
    package: StoredBlindSecretPackage,
    *,
    key_holder_id: str,
    private_key: str,
    recipients: list[RecipientKeyReference],
    key_version: int | None = None,
) -> StoredBlindSecretPackage:
    if package.algorithm != BLIND_SECRET_PACKAGE_ALGORITHM:
        if package.algorithm == LEGACY_BLIND_SECRET_PACKAGE_ALGORITHM:
            raise ValueError(
                "legacy blind package algorithm requires reset and re-pair for launch"
            )
        raise ValueError(f"unsupported blind package algorithm '{package.algorithm}'")
    if package.custody_mode not in BLIND_CUSTODY_MODES:
        raise ValueError("only blind custody packages can be rewrapped")
    if not recipients:
        raise ValueError("rewrap requires at least one recipient key")
    key_wrap = package.key_wrap_for(
        key_holder_id=key_holder_id,
        key_version=key_version,
    )
    if key_wrap is None:
        raise ValueError("no matching recipient key wrap for blind package")
    wrapped_payload = open_sealed_payload(
        key_wrap.wrapped_data_key_envelope,
        private_key=private_key,
    )
    if wrapped_payload.get("package_aad_sha256") != sha256_json(package.aad):
        raise ValueError("recipient key wrap does not match package aad")
    data_key = _b64decode(str(wrapped_payload["data_key"]))
    return StoredBlindSecretPackage(
        version=package.version,
        package_id=package.package_id,
        item_id=package.item_id,
        field_name=package.field_name,
        item_revision=package.item_revision,
        custody_mode=package.custody_mode,
        algorithm=package.algorithm,
        nonce=package.nonce,
        ciphertext=package.ciphertext,
        aad=dict(package.aad),
        recipient_key_wraps=[
            _wrap_data_key(
                data_key=data_key,
                package_aad=package.aad,
                recipient=recipient,
            )
            for recipient in recipients
        ],
        created_at_epoch_ms=package.created_at_epoch_ms,
    )


def prepare_encrypt_write_only_import_packages(
    *,
    item_id: str,
    item_revision: int,
    protected_fields: dict[str, str],
    field_custody_modes: dict[str, str],
    recipients: list[RecipientKeyReference],
    created_at_epoch_ms: int,
) -> dict[str, StoredBlindSecretPackage]:
    packages: dict[str, StoredBlindSecretPackage] = {}
    for field_name, plaintext_value in protected_fields.items():
        custody_mode = field_custody_modes.get(
            field_name,
            CUSTODY_MODE_BLIND_VALUE_RELEASE,
        )
        packages[field_name] = build_stored_blind_secret_package(
            item_id=item_id,
            field_name=field_name,
            item_revision=item_revision,
            plaintext_value=str(plaintext_value),
            custody_mode=custody_mode,
            recipients=recipients,
            created_at_epoch_ms=created_at_epoch_ms,
        )
    return packages


def _wrap_data_key(
    *,
    data_key: bytes,
    package_aad: dict[str, Any],
    recipient: RecipientKeyReference,
) -> RecipientKeyWrap:
    wrapped_payload = {
        "data_key": _b64encode(data_key),
        "package_aad_sha256": sha256_json(package_aad),
        "key_holder_id": recipient.key_holder_id,
        "key_version": recipient.key_version,
    }
    envelope = seal_payload_to_public_key(
        recipient.public_key,
        wrapped_payload,
        key_id=recipient.key_id,
        algorithm=recipient.key_algorithm,
        aad={
            "purpose": "skyline-blind-secret-data-key-wrap-v1",
            "package_aad_sha256": sha256_json(package_aad),
            "key_holder_id": recipient.key_holder_id,
            "key_version": recipient.key_version,
        },
    )
    return RecipientKeyWrap(
        key_holder_id=recipient.key_holder_id,
        key_id=recipient.key_id,
        key_fingerprint=recipient.key_fingerprint,
        key_version=recipient.key_version,
        algorithm=recipient.key_algorithm,
        wrapped_data_key_envelope=envelope,
    )
