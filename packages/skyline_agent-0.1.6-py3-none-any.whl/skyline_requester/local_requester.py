from __future__ import annotations

import asyncio
import argparse
import ast
import base64
import contextvars
import ctypes
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import html
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import secrets
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import webbrowser
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote
import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from uvicorn.protocols.http.h11_impl import (
    HIGH_WATER_LIMIT,
    H11Protocol,
    RequestResponseCycle,
    h11,
    service_unavailable,
)

from .browser_host_helper import (
    DEFAULT_CONFIG_PATH as DEFAULT_BROWSER_HOST_CONFIG_PATH,
    DEFAULT_BROWSER_NAME as DEFAULT_BROWSER_HOST_BROWSER_NAME,
    DEFAULT_EXTENSION_CHANNEL as DEFAULT_BROWSER_HOST_EXTENSION_CHANNEL,
    DEFAULT_NATIVE_HOST_NAME as DEFAULT_BROWSER_HOST_NATIVE_HOST_NAME,
    DEFAULT_PROFILE_LABEL as DEFAULT_BROWSER_HOST_PROFILE_LABEL,
    install_native_host_manifest,
)
from .delivery_crypto import (
    DELIVERY_KEY_ALGORITHM,
    generate_keypair as generate_delivery_keypair,
    open_sealed_payload,
)
from .client_side_secret_writes import (
    build_client_side_protected_write_payload,
    with_client_side_presence_metadata,
)
from .mcp_setup_guidance import (
    agent_command_output_lines,
    local_requester_epilog,
    setup_command_description,
)
from .secret_custody import (
    RecipientKeyReference,
    StoredBlindSecretPackage,
    decrypt_stored_blind_secret_package,
)
from .delivery_helper_cli import DEFAULT_CONFIG_PATH as DEFAULT_DELIVERY_HELPER_CONFIG_PATH
from .delivery_helper_cli import _render_secret_bundle, _run_secret_bundle_command
from .helper_security import (
    clear_stored_credentials as clear_local_stored_credentials,
    create_credential_store as create_local_credential_store,
    ensure_owner_only_directory,
    load_helper_metadata as load_local_metadata,
    request_json as request_core_json,
    resolve_credential_storage_backend as resolve_local_credential_storage_backend,
    save_helper_metadata as save_local_metadata,
    validate_runtime_environment as validate_local_environment,
    write_owner_only_text,
)
from .requester_core_client import (
    DEFAULT_CORE_TIMEOUT_SECONDS,
    SkylineCoreAPIError,
    SkylineCoreHTTPClient,
    RequesterCoreClientConfig,
)
from .release_features import chrome_extension_browser_companion_enabled
from .requester_update import (
    build_requester_cli_update_status,
    installed_requester_cli_version,
    requester_cli_update_command,
    requester_cli_update_command_parts,
    run_requester_cli_update,
)
from .vault_import import (
    PASSWORD_IMPORT_SOURCE_DISPLAY_NAMES,
    SUPPORTED_IMPORT_SOURCE_KINDS,
    parse_import_blob,
)
from .requester_protocol import (
    DEFAULT_REQUESTER_LOCAL_SLOT_ID,
    DEFAULT_REQUESTER_LOCAL_SLOT_LABEL,
    DELIVERY_BROWSER_HOST_COMPONENT_KIND,
    DELIVERY_HELPER_COMPONENT_KIND,
    REQUESTER_LOCAL_DELIVERY_METADATA_KEY,
    REQUESTER_APP_NONCE_HEADER,
    REQUESTER_APP_PRINCIPAL_ID_HEADER,
    REQUESTER_APP_PROFILE_ID_HEADER,
    REQUESTER_APP_SIGNATURE_HEADER,
    REQUESTER_APP_TIMESTAMP_HEADER,
)
from .vault_item_types import VaultItemTypeRegistry
from .local_identity_crypto import (
    LOCAL_IDENTITY_KEY_ALGORITHM_ED25519,
    LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
    build_requester_request_proof_message,
    canonical_json_dumps,
    canonical_query_string,
    generate_local_identity_keypair,
    sha256_bytes,
    sha256_text,
    sign_local_identity_message,
)
from .macos_secure_enclave_identity import (
    MACOS_SECURE_ENCLAVE_SIGNER_BACKEND_ID,
    MACOS_SECURE_ENCLAVE_STATUS_AVAILABLE,
    MACOS_SECURE_ENCLAVE_STATUS_HARDWARE_UNAVAILABLE,
    MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE,
    MACOS_SOFTWARE_SIGNER_DEV_OVERRIDE_ENV_VAR,
    generate_macos_secure_enclave_identity_keypair,
    macos_secure_enclave_identity_status,
    sign_macos_secure_enclave_identity_message,
)


MACHINE_SEED_CREDENTIAL_KIND = "machine_seed"
REQUESTER_APP_CREDENTIAL_KIND = "requester_app_principal"
DEFAULT_CONFIG_PATH = Path.home() / ".skyline-requester.json"
DEFAULT_REQUESTER_LOCAL_API_BASE_PATH = "/v1/local-requester"
HOSTED_TENANT_HEADER = "X-Skyline-Tenant-ID"
DEFAULT_INJECT_ENV_VAR = "SKYLINE_INJECTED_SECRET"
BROWSER_SECRET_RUNNER_DELIVERY_ACTION = "browser_secret_runner"
MACOS_SECURE_ENCLAVE_METADATA_KEY = "macos_secure_enclave"
BROWSER_SECRET_RUNNER_DIR_NAME = "browser-secret-runners"
CLIENT_PROFILE_ENV_VAR = "SKYLINE_CLIENT_PROFILE"
TRUSTED_SECRET_KEY_HOLDERS_METADATA_KEY = "trusted_secret_key_holders"
CLIENT_DISPLAY_NAME_ENV_VAR = "SKYLINE_CLIENT_DISPLAY_NAME"
CLIENT_APP_IDENTIFIER_ENV_VAR = "SKYLINE_CLIENT_APP_IDENTIFIER"
CLIENT_EXECUTABLE_PATH_ENV_VAR = "SKYLINE_CLIENT_EXECUTABLE_PATH"
CLIENT_CODE_SIGNING_IDENTITY_ENV_VAR = "SKYLINE_CLIENT_CODE_SIGNING_IDENTITY"
LOCAL_REQUESTER_CALLER_REASON_MISMATCH = "caller_mismatch"
LOCAL_REQUESTER_CALLER_REASON_UNVERIFIABLE = "caller_unverifiable"
LOCAL_REQUESTER_BROWSER_COMPANION_UNTRUSTED = "browser_companion_untrusted"
DEFAULT_BROWSER_HELLO_CHALLENGE_TTL_MS = 15_000
DEFAULT_BROWSER_SESSION_HEADER = "x-skyline-browser-session"
DEFAULT_MACHINE_SETUP_APPROVAL_TIMEOUT_SECONDS = 300.0
PASSWORD_IMPORT_CLIENT_PROFILE = "skyline-password-import"
PASSWORD_IMPORT_CLIENT_DISPLAY_NAME = "Password Import"
PASSWORD_IMPORT_CLIENT_APP_IDENTIFIER = "app.skyline.password-import"
EPHEMERAL_REQUESTER_METADATA_KEY = "skyline_ephemeral_requester"
PASSWORD_IMPORT_REQUESTER_METADATA = {
    EPHEMERAL_REQUESTER_METADATA_KEY: True,
    "skyline_ephemeral_purpose": "password_import",
}
DEMO_SEED_WRITEBACK_ENABLED_ENV_VAR = "SKYLINE_DEMO_SEED_WRITEBACK"
DEMO_SEED_WRITEBACK_PATH_ENV_VAR = "SKYLINE_DEMO_SEED_WRITEBACK_PATH"
DEMO_SEED_WRITEBACK_ALLOWLIST_PATH_ENV_VAR = "SKYLINE_DEMO_SEED_WRITEBACK_ALLOWLIST_PATH"
DEMO_LOCAL_SECRET_PREFIX = "APERTURE_DEMO_ITEM_"


@dataclass(frozen=True, slots=True)
class DemoSeedWritebackFixture:
    item_id: str | None
    kind: str
    title: str
    safe_metadata: dict[str, Any]
    protected_fields: dict[str, Any]


def _env_flag_enabled(name: str) -> bool:
    return str(os.environ.get(name) or "").strip().lower() in {"1", "true", "yes", "on"}


def _demo_seed_writeback_config() -> tuple[Path, Path] | None:
    if not _env_flag_enabled(DEMO_SEED_WRITEBACK_ENABLED_ENV_VAR):
        return None
    seed_path = str(os.environ.get(DEMO_SEED_WRITEBACK_PATH_ENV_VAR) or "").strip()
    allowlist_path = str(
        os.environ.get(DEMO_SEED_WRITEBACK_ALLOWLIST_PATH_ENV_VAR) or ""
    ).strip()
    if not seed_path:
        raise RuntimeError("demo seed writeback is enabled but no seed file path is configured")
    if not allowlist_path:
        raise RuntimeError("demo seed writeback is enabled but no allowlist path is configured")
    return Path(seed_path).expanduser().resolve(), Path(allowlist_path).expanduser().resolve()


def _ensure_demo_seed_writeback_ready(config: tuple[Path, Path] | None) -> None:
    if config is None:
        return
    seed_path, _allowlist_path = config
    if not seed_path.exists():
        raise RuntimeError(f"demo seed writeback refused because the seed file is missing: {seed_path}")


def _load_demo_seed_writeback_allowlist(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"version": 1, "items": {}}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise RuntimeError(f"demo seed writeback allowlist is invalid: {path}") from error
    if not isinstance(payload, dict):
        raise RuntimeError(f"demo seed writeback allowlist is invalid: {path}")
    items = payload.get("items")
    if not isinstance(items, dict):
        payload["items"] = {}
    payload["version"] = 1
    return payload


def _save_demo_seed_writeback_allowlist(path: Path, payload: dict[str, Any]) -> None:
    write_owner_only_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _decode_demo_seed_env_value(raw_value: str) -> str:
    candidate = raw_value.strip()
    if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in {"'", '"'}:
        try:
            decoded = ast.literal_eval(candidate)
        except (SyntaxError, ValueError):
            decoded = candidate[1:-1]
        return decoded if isinstance(decoded, str) else str(decoded)
    return candidate


def _parse_demo_seed_env_file(path: Path) -> dict[str, str]:
    entries: dict[str, str] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].lstrip()
        if "=" not in line:
            raise ValueError(
                f"invalid env assignment on line {line_number} in {path}: {raw_line!r}"
            )
        key, value = line.split("=", 1)
        normalized_key = key.strip()
        if not normalized_key:
            raise ValueError(f"empty env key on line {line_number} in {path}")
        entries[normalized_key] = _decode_demo_seed_env_value(value)
    return entries


def _normalize_demo_secret_slug(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", value.strip().lower())
    normalized = normalized.strip("_")
    if not normalized:
        raise ValueError("demo secret identifiers must contain at least one letter or digit")
    return normalized


def _demo_seed_writeback_payload(fixture: DemoSeedWritebackFixture) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "kind": fixture.kind,
        "title": fixture.title,
        "safe_metadata": dict(fixture.safe_metadata),
        "protected_fields": dict(fixture.protected_fields),
    }
    if fixture.item_id:
        payload["item_id"] = fixture.item_id
    return payload


def _encoded_demo_seed_json_value(payload: dict[str, Any]) -> str:
    json_text = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return json.dumps(json_text, ensure_ascii=True)


def _env_assignment_key(raw_line: str) -> str | None:
    line = raw_line.strip()
    if not line or line.startswith("#"):
        return None
    if line.startswith("export "):
        line = line[len("export ") :].lstrip()
    if "=" not in line:
        return None
    key = line.split("=", 1)[0].strip()
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
        return None
    return key


def _demo_seed_key_for_fixture(
    entries: dict[str, str],
    fixture: DemoSeedWritebackFixture,
    *,
    preferred_key: str | None,
) -> str:
    normalized_preferred = str(preferred_key or "").strip()
    if normalized_preferred:
        if not normalized_preferred.startswith(DEMO_LOCAL_SECRET_PREFIX):
            raise ValueError("demo seed env key must start with APERTURE_DEMO_ITEM_")
        _normalize_demo_secret_slug(normalized_preferred[len(DEMO_LOCAL_SECRET_PREFIX) :])
        return normalized_preferred

    for key, raw_payload in sorted(entries.items()):
        if not key.startswith(DEMO_LOCAL_SECRET_PREFIX):
            continue
        try:
            payload = json.loads(raw_payload)
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        if fixture.item_id and str(payload.get("item_id") or "").strip() == fixture.item_id:
            return key
        if (
            str(payload.get("kind") or "").strip() == fixture.kind
            and str(payload.get("title") or "").strip() == fixture.title
        ):
            return key

    base_slug = _normalize_demo_secret_slug(fixture.title).upper()
    candidate = f"{DEMO_LOCAL_SECRET_PREFIX}{base_slug}"
    if candidate not in entries:
        return candidate
    for index in range(2, 1000):
        candidate = f"{DEMO_LOCAL_SECRET_PREFIX}{base_slug}_{index}"
        if candidate not in entries:
            return candidate
    raise ValueError(f"could not choose a unique demo seed env key for {fixture.title!r}")


def _upsert_demo_seed_writeback_fixture(
    env_path: str | Path,
    fixture: DemoSeedWritebackFixture,
    *,
    preferred_key: str | None = None,
) -> str:
    path = Path(env_path)
    if not path.exists():
        raise FileNotFoundError(f"local demo secrets file does not exist: {path}")

    entries = _parse_demo_seed_env_file(path)
    key = _demo_seed_key_for_fixture(
        entries,
        fixture,
        preferred_key=preferred_key,
    )
    payload = _demo_seed_writeback_payload(fixture)
    encoded_line = f"{key}={_encoded_demo_seed_json_value(payload)}"

    lines = path.read_text(encoding="utf-8").splitlines()
    replaced = False
    updated_lines: list[str] = []
    for line in lines:
        if _env_assignment_key(line) == key:
            updated_lines.append(encoded_line)
            replaced = True
        else:
            updated_lines.append(line)
    if not replaced:
        if updated_lines and updated_lines[-1].strip():
            updated_lines.append("")
        updated_lines.append(encoded_line)

    write_owner_only_text(path, "\n".join(updated_lines) + "\n")
    return key


def _record_demo_seed_writeback(
    *,
    config: tuple[Path, Path] | None,
    item_id: str,
    kind: str,
    title: str,
    safe_metadata: dict[str, Any],
    protected_fields: dict[str, Any],
) -> dict[str, Any] | None:
    if config is None:
        return None
    seed_path, allowlist_path = config
    _ensure_demo_seed_writeback_ready(config)
    fixture = DemoSeedWritebackFixture(
        item_id=item_id,
        kind=kind,
        title=title,
        safe_metadata=dict(safe_metadata),
        protected_fields=dict(protected_fields),
    )
    allowlist = _load_demo_seed_writeback_allowlist(allowlist_path)
    item_records = allowlist.setdefault("items", {})
    existing_record = item_records.get(item_id)
    preferred_key = (
        str(existing_record.get("env_key") or "").strip()
        if isinstance(existing_record, dict)
        else None
    )
    env_key = _upsert_demo_seed_writeback_fixture(
        seed_path,
        fixture,
        preferred_key=preferred_key,
    )
    item_records[item_id] = {
        "item_id": item_id,
        "env_key": env_key,
        "kind": kind,
        "title": title,
        "safe_metadata": dict(safe_metadata),
        "protected_field_names": sorted(str(field) for field in protected_fields),
        "updated_at_epoch_ms": int(time.time() * 1000),
    }
    _save_demo_seed_writeback_allowlist(allowlist_path, allowlist)
    return {
        "status": "updated",
        "seed_path": str(seed_path),
        "allowlist_path": str(allowlist_path),
        "env_key": env_key,
        "item_id": item_id,
        "protected_field_names": sorted(str(field) for field in protected_fields),
    }


def _resolve_local_requester_module_name(
    module_name: str,
    module_spec_name: str | None,
) -> str:
    resolved = (module_spec_name or "").strip()
    if resolved:
        return resolved
    return module_name


LOCAL_REQUESTER_MODULE_NAME = _resolve_local_requester_module_name(
    __name__,
    getattr(__spec__, "name", None) if __spec__ is not None else None,
)
LOCAL_REQUESTER_MODULE_MARKERS = {
    "aperture_core.local_requester",
    "skyline_requester.local_requester",
}
_DARWIN_SOL_LOCAL = 0
_DARWIN_LOCAL_PEERPID = 0x002
_PROCESS_EXECUTABLE_PATH_BUFFER_SIZE = 4096
_AMBIENT_LAUNCHER_NAMES = {
    "alacritty",
    "bash",
    "env",
    "fish",
    "ghostty",
    "hyper",
    "iterm",
    "iterm2",
    "kitty",
    "login",
    "rio",
    "sh",
    "sudo",
    "tabby",
    "terminal",
    "timeout",
    "warp",
    "wezterm",
    "zsh",
}
_TARGET_ARGUMENT_LAUNCHER_NAMES = _AMBIENT_LAUNCHER_NAMES | {
    "bun",
    "deno",
    "node",
    "npm",
    "npx",
    "pnpm",
    "python",
    "python3",
    "uv",
    "uvx",
}
_REVERSE_DNS_PREFIXES = {
    "ai",
    "app",
    "com",
    "dev",
    "io",
    "net",
    "org",
}
SUPPORTED_BROWSER_INSTALL_FAMILIES = {
    "chrome",
    "chrome_for_testing",
    "chromium",
}


class RuntimeMachineSetupRequest(BaseModel):
    core_base_url: str
    setup_code: str
    hosted_tenant_id: str | None = None
    machine_name: str | None = None
    requester_note: str | None = None
    requester_profile: str | None = None
    requester_tags: list[str] = Field(default_factory=list)
    requested_metadata: dict[str, Any] = Field(default_factory=dict)
    approval_timeout_seconds: float = DEFAULT_MACHINE_SETUP_APPROVAL_TIMEOUT_SECONDS


class RequesterAppEnrollmentRequest(BaseModel):
    client_profile_id: str
    requested_display_name: str
    requested_note: str | None = None
    requested_profile: str | None = None
    requested_tags: list[str] = Field(default_factory=list)
    requested_metadata: dict[str, Any] = Field(default_factory=dict)
    requested_app_identifier: str | None = None
    requested_platform: str | None = None
    requested_executable_path: str | None = None
    requested_code_signing_identity: str | None = None


class LocalRequesterForwardRequest(BaseModel):
    client_profile_id: str
    core_method: str
    core_path: str
    core_params: dict[str, Any] = Field(default_factory=dict)
    core_json_body: dict[str, Any] | None = None
    require_pairing: bool = True


class BrowserSecretRunnerLocalStoreRequest(BaseModel):
    writeback_token: str
    browser_action: str
    secret_value: str


class BrowserSecretRunnerLocalSecretRequest(BaseModel):
    browser_action: str
    secret_fetch_token: str


class BrowserCompanionHelloRequest(BaseModel):
    browser_channel_id: str
    browser_name: str
    profile_label: str
    extension_id: str
    extension_channel: str
    extension_version: str | None = None
    native_host_name: str | None = None


class BrowserCompanionHelloConfirmRequest(BaseModel):
    browser_channel_id: str
    challenge_id: str
    challenge_nonce: str


class LocalBrowserContextSyncRequest(BaseModel):
    delivery_target_id: str
    browser_channel_id: str
    browser_name: str
    profile_label: str
    extension_id: str
    extension_channel: str
    extension_version: str | None = None
    tab_id: int
    window_id: int
    page_url: str
    page_title: str
    top_level_origin: str
    frame_id: int
    frame_origin: str
    form_session_id: str
    field_summary: dict[str, Any] = Field(default_factory=dict)
    last_seen_at_epoch_ms: int


class BrowserCompanionPopupLookupRequest(BaseModel):
    delivery_target_id: str | None = None
    browser_channel_id: str | None = None


class BrowserCompanionPopupFillRequest(BaseModel):
    delivery_target_id: str | None = None
    browser_channel_id: str | None = None
    selection_hint: dict[str, Any] | None = None


class BrowserCompanionDeliveryJobAckRequest(BaseModel):
    status: str
    message: str | None = None
    details: dict[str, Any] | None = None


class RequesterPairingRequired(RuntimeError):
    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload
        super().__init__(str(payload.get("message") or "requester pairing required"))


class StructuredCLIStatus(RuntimeError):
    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload
        super().__init__(str(payload.get("message") or "command status"))


def _resolved_config_path(raw_path: str) -> Path:
    return Path(raw_path).expanduser()


def _load_metadata(config_path: Path) -> dict[str, Any]:
    return load_local_metadata(config_path)


def _save_metadata(config_path: Path, metadata: dict[str, Any]) -> None:
    save_local_metadata(config_path, metadata)


def _secret_key_holder_pin(holder: RecipientKeyReference) -> dict[str, Any]:
    return {
        "key_holder_id": holder.key_holder_id,
        "key_id": holder.key_id,
        "key_algorithm": holder.key_algorithm,
        "key_version": int(holder.key_version),
        "key_fingerprint": holder.key_fingerprint,
    }


def _secret_key_holder_pin_key(pin: dict[str, Any]) -> tuple[str, int]:
    try:
        key_version = int(pin.get("key_version") or 0)
    except (TypeError, ValueError):
        key_version = 0
    return (
        str(pin.get("key_holder_id") or "").strip(),
        key_version,
    )


def _secret_key_holder_pin_matches(
    holder: RecipientKeyReference,
    pin: dict[str, Any],
) -> bool:
    return (
        str(pin.get("key_holder_id") or "") == holder.key_holder_id
        and str(pin.get("key_id") or "") == holder.key_id
        and str(pin.get("key_algorithm") or "") == holder.key_algorithm
        and _secret_key_holder_pin_key(pin)[1] == int(holder.key_version)
        and str(pin.get("key_fingerprint") or "") == holder.key_fingerprint
    )


def _trusted_secret_key_holder_pins(metadata: dict[str, Any]) -> list[dict[str, Any]]:
    raw_pins = metadata.get(TRUSTED_SECRET_KEY_HOLDERS_METADATA_KEY)
    if not isinstance(raw_pins, list):
        return []
    pins: list[dict[str, Any]] = []
    for raw_pin in raw_pins:
        if not isinstance(raw_pin, dict):
            continue
        key_holder_id, key_version = _secret_key_holder_pin_key(raw_pin)
        key_fingerprint = str(raw_pin.get("key_fingerprint") or "").strip()
        key_id = str(raw_pin.get("key_id") or "").strip()
        if key_holder_id and key_version > 0 and key_fingerprint and key_id:
            pins.append(dict(raw_pin))
    return pins


def _remember_trusted_secret_key_holders(
    config_path: Path,
    holders: list[RecipientKeyReference],
) -> None:
    metadata = _load_metadata(config_path)
    existing_pins = {
        _secret_key_holder_pin_key(pin): pin
        for pin in _trusted_secret_key_holder_pins(metadata)
    }
    for holder in holders:
        if holder.status != "active":
            continue
        pin = _secret_key_holder_pin(holder)
        existing_pins[_secret_key_holder_pin_key(pin)] = pin
    updated = dict(metadata)
    updated[TRUSTED_SECRET_KEY_HOLDERS_METADATA_KEY] = [
        existing_pins[key] for key in sorted(existing_pins)
    ]
    _save_metadata(config_path, updated)


def _enforce_trusted_secret_key_holders_for_write(
    config_path: Path,
    holders: list[RecipientKeyReference],
) -> list[RecipientKeyReference]:
    active_holders = [holder for holder in holders if holder.status == "active"]
    if not active_holders:
        return active_holders

    metadata = _load_metadata(config_path)
    pins = _trusted_secret_key_holder_pins(metadata)
    if not pins:
        _remember_trusted_secret_key_holders(config_path, active_holders)
        return active_holders

    untrusted: list[str] = []
    for holder in active_holders:
        matching_pin = next(
            (
                pin
                for pin in pins
                if _secret_key_holder_pin_key(pin)
                == (holder.key_holder_id, int(holder.key_version))
            ),
            None,
        )
        if matching_pin is None or not _secret_key_holder_pin_matches(holder, matching_pin):
            untrusted.append(f"{holder.key_holder_id}@v{holder.key_version}")
    if untrusted:
        raise RuntimeError(
            "Skyline saw a new or changed trusted key holder while preparing "
            "an encrypted write: "
            + ", ".join(sorted(untrusted))
            + ". Reconnect this machine after approving the new helper on your iPhone."
        )
    return active_holders


def _local_requester_state_dir(config_path: Path) -> Path:
    stem = config_path.stem.lstrip(".") or "skyline-requester"
    return config_path.parent / f".{stem}-state"


def _local_requester_service_socket_path(config_path: Path) -> Path:
    # Keep the Unix-domain socket filename short so requester configs nested
    # inside normal workspace paths still fit within macOS/Linux AF_UNIX limits.
    return _local_requester_state_dir(config_path) / "sock"


def _darwin_process_executable_path(pid: int) -> str | None:
    if sys.platform != "darwin" or pid <= 1:
        return None
    try:
        libproc = ctypes.CDLL("/usr/lib/libproc.dylib")
        proc_pidpath = libproc.proc_pidpath
        proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
        proc_pidpath.restype = ctypes.c_int
        buffer = ctypes.create_string_buffer(_PROCESS_EXECUTABLE_PATH_BUFFER_SIZE)
        size = proc_pidpath(int(pid), buffer, ctypes.sizeof(buffer))
    except Exception:
        return None
    if size <= 0:
        return None
    try:
        resolved = buffer.value.decode().strip()
    except Exception:
        resolved = buffer.value.decode(errors="ignore").strip()
    return resolved or None


def _linux_process_executable_path(pid: int) -> str | None:
    if not sys.platform.startswith("linux") or pid <= 1:
        return None
    try:
        return str(Path(f"/proc/{pid}/exe").resolve())
    except Exception:
        return None


def _process_executable_path(pid: int) -> str | None:
    if sys.platform == "darwin":
        return _darwin_process_executable_path(pid)
    if sys.platform.startswith("linux"):
        return _linux_process_executable_path(pid)
    return None


def _command_text_from_command_line(command_line: str | None) -> str | None:
    raw_command = str(command_line or "").strip()
    if not raw_command:
        return None
    raw_tokens = raw_command.split()
    if raw_tokens and raw_tokens[0].startswith("/"):
        best_match = None
        for index in range(1, len(raw_tokens) + 1):
            candidate = " ".join(raw_tokens[:index]).strip()
            if _resolved_file_path_if_available(candidate):
                best_match = candidate
        if best_match:
            return best_match
    try:
        tokens = shlex.split(raw_command)
    except ValueError:
        tokens = raw_tokens
    if not tokens:
        return None
    return str(tokens[0]).strip() or None


def _local_requester_service_state_path(config_path: Path) -> Path:
    return _local_requester_state_dir(config_path) / "local-requester.json"


def _browser_secret_runner_dir(state_dir: Path) -> Path:
    return state_dir / BROWSER_SECRET_RUNNER_DIR_NAME


def _browser_secret_runner_writeback_path(state_dir: Path, token: str) -> Path:
    return _browser_secret_runner_dir(state_dir) / f"{token}.writeback.json"


def _browser_secret_runner_secret_path(state_dir: Path, token: str) -> Path:
    return _browser_secret_runner_dir(state_dir) / f"{token}.secret.json"


def _safe_browser_secret_runner_token(value: Any) -> str:
    token = str(value or "").strip()
    if not token.startswith("bsr_"):
        raise RuntimeError("browser secret runner token is missing")
    suffix = token.removeprefix("bsr_")
    if not suffix or any(char not in "0123456789abcdef" for char in suffix.lower()):
        raise RuntimeError("browser secret runner token is invalid")
    return token


def _requester_app_profiles_path(config_path: Path) -> Path:
    return _local_requester_state_dir(config_path) / "requester-profiles.json"


def _requester_app_config_path(config_path: Path, profile_id: str) -> Path:
    normalized = _slugify_client_id(profile_id)
    if not normalized:
        raise RuntimeError("requester app profile id is missing")
    return _local_requester_state_dir(config_path) / "requester-profiles" / f"{normalized}.json"


def _resolve_local_credential_backend(
    *,
    config_path: Path,
    credential_kind: str,
    bootstrap_secret_file: str | None,
) -> str:
    return resolve_local_credential_storage_backend(
        helper_kind=credential_kind,
        config_path=config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )


def _validate_local_credential_backend(
    *,
    credential_kind: str,
    credential_storage_backend: str,
) -> None:
    validate_local_environment(
        helper_kind=credential_kind,
        credential_storage_backend=credential_storage_backend,
    )


def _create_local_credential_store(
    *,
    config_path: Path,
    credential_kind: str,
    credential_storage_backend: str,
    bootstrap_secret_file: str | None,
):
    return create_local_credential_store(
        config_path=config_path,
        helper_kind=credential_kind,
        credential_storage_backend=credential_storage_backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )


def _load_requester_app_profiles(config_path: Path) -> dict[str, dict[str, Any]]:
    path = _requester_app_profiles_path(config_path)
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("requester app profile store is invalid")
    profiles: dict[str, dict[str, Any]] = {}
    for raw_profile_id, raw_profile in payload.items():
        if not isinstance(raw_profile_id, str) or not isinstance(raw_profile, dict):
            continue
        profiles[raw_profile_id] = dict(raw_profile)
    return profiles


def _save_requester_app_profiles(
    config_path: Path,
    profiles: dict[str, dict[str, Any]],
) -> None:
    path = _requester_app_profiles_path(config_path)
    ensure_owner_only_directory(path.parent)
    write_owner_only_text(
        path,
        json.dumps(profiles, indent=2, sort_keys=True) + "\n",
    )


def _remove_requester_app_profile(
    config_path: Path,
    *,
    profile_id: str,
) -> None:
    normalized_profile_id = _slugify_client_id(profile_id)
    if not normalized_profile_id:
        raise RuntimeError("requester app profile id is missing")
    profiles = _load_requester_app_profiles(config_path)
    profiles.pop(normalized_profile_id, None)
    profiles_path = _requester_app_profiles_path(config_path)
    if profiles:
        _save_requester_app_profiles(config_path, profiles)
    elif profiles_path.exists():
        profiles_path.unlink()


def _default_profile_metadata(profile_id: str) -> dict[str, Any]:
    normalized_profile_id = _slugify_client_id(profile_id)
    return {
        "client_profile_id": normalized_profile_id,
        "display_name": _default_client_label(normalized_profile_id),
        "app_identifier": normalized_profile_id,
        "platform": _current_platform_name(),
        "executable_path": None,
        "code_signing_identity": None,
        "status": "unpaired",
    }


def _load_requester_app_credentials(
    config_path: Path,
    *,
    profile_id: str,
    bootstrap_secret_file: str | None,
) -> tuple[dict[str, str], str]:
    profile_config_path = _requester_app_config_path(config_path, profile_id)
    backend = _resolve_local_credential_backend(
        config_path=profile_config_path,
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    _validate_local_credential_backend(
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        credential_storage_backend=backend,
    )
    store = _create_local_credential_store(
        config_path=profile_config_path,
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    return (store.load() or {}), backend


def _save_requester_app_credentials(
    config_path: Path,
    *,
    profile_id: str,
    credentials: dict[str, str],
    bootstrap_secret_file: str | None,
) -> str:
    profile_config_path = _requester_app_config_path(config_path, profile_id)
    backend = _resolve_local_credential_backend(
        config_path=profile_config_path,
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    _validate_local_credential_backend(
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        credential_storage_backend=backend,
    )
    store = _create_local_credential_store(
        config_path=profile_config_path,
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    payload = {
        str(key): str(value)
        for key, value in credentials.items()
        if str(value).strip()
    }
    store.save(payload)
    return backend


def _machine_seed_credential_store(config_path: Path, *, bootstrap_secret_file: str | None):
    backend = _resolve_local_credential_backend(
        config_path=config_path,
        credential_kind=MACHINE_SEED_CREDENTIAL_KIND,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    _validate_local_credential_backend(
        credential_kind=MACHINE_SEED_CREDENTIAL_KIND,
        credential_storage_backend=backend,
    )
    store = _create_local_credential_store(
        config_path=config_path,
        credential_kind=MACHINE_SEED_CREDENTIAL_KIND,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    return store, backend


def _load_machine_seed_credentials(
    config_path: Path,
    *,
    bootstrap_secret_file: str | None,
) -> tuple[dict[str, str], str]:
    store, backend = _machine_seed_credential_store(
        config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    return (store.load() or {}), backend


def _save_machine_seed_credentials(
    config_path: Path,
    *,
    metadata: dict[str, Any],
    credentials: dict[str, str],
    bootstrap_secret_file: str | None,
) -> str:
    store, backend = _machine_seed_credential_store(
        config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    payload = store.load() or {}
    for key in (
        "private_key",
        "private_key_representation",
        "access_token",
        "access_token_expires_at_epoch_ms",
    ):
        if key not in credentials:
            payload.pop(key, None)
    payload.update({str(key): str(value) for key, value in credentials.items() if str(value)})
    store.save(payload)
    updated_metadata = dict(metadata)
    updated_metadata["credential_storage_backend"] = backend
    _save_metadata(config_path, updated_metadata)
    return backend


def _clear_local_credentials(
    *,
    config_path: Path,
    credential_kind: str,
    credential_storage_backend: str,
    bootstrap_secret_file: str | None,
) -> None:
    clear_local_stored_credentials(
        config_path=config_path,
        helper_kind=credential_kind,
        credential_storage_backend=credential_storage_backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )


def _current_platform_name() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("linux"):
        return "linux"
    if sys.platform.startswith("win"):
        return "windows"
    return sys.platform or "unknown"


def _macos_identity_identifier(signing_identity: Any) -> str | None:
    if not isinstance(signing_identity, dict):
        return None
    return str(
        signing_identity.get("identifier")
        or signing_identity.get("team_identifier")
        or ""
    ).strip() or None


def _normalize_browser_install_family(raw: str | None) -> str | None:
    normalized = str(raw or "").strip().lower()
    if not normalized:
        return None
    if normalized in SUPPORTED_BROWSER_INSTALL_FAMILIES:
        return normalized
    return None


def _candidate_browser_executable_paths(browser_family: str) -> list[Path]:
    home = Path.home()
    if sys.platform == "darwin":
        candidates = {
            "chrome": [
                Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
                home / "Applications" / "Google Chrome.app" / "Contents" / "MacOS" / "Google Chrome",
            ],
            "chrome_for_testing": [
                Path(
                    "/Applications/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing"
                ),
                home
                / "Applications"
                / "Google Chrome for Testing.app"
                / "Contents"
                / "MacOS"
                / "Google Chrome for Testing",
                Path("/Applications/Chrome for Testing.app/Contents/MacOS/Chrome for Testing"),
                home
                / "Applications"
                / "Chrome for Testing.app"
                / "Contents"
                / "MacOS"
                / "Chrome for Testing",
            ],
            "chromium": [
                Path("/Applications/Chromium.app/Contents/MacOS/Chromium"),
                home / "Applications" / "Chromium.app" / "Contents" / "MacOS" / "Chromium",
            ],
        }
        result = list(candidates.get(browser_family, []))
        if (
            browser_family == "chrome_for_testing"
            and os.environ.get("SKYLINE_TEST_ALLOW_UNSIGNED_CHROME_FOR_TESTING") == "1"
        ):
            explicit_test_browser = str(
                os.environ.get("SKYLINE_TEST_CHROME_FOR_TESTING_EXECUTABLE") or ""
            ).strip()
            if explicit_test_browser:
                result.append(Path(explicit_test_browser).expanduser())
            result.extend(
                sorted(
                    (
                        home
                        / "Library"
                        / "Caches"
                        / "ms-playwright"
                    ).glob(
                        "chromium-*/chrome-mac*/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing"
                    ),
                    reverse=True,
                )
            )
        return result
    if sys.platform.startswith("linux"):
        commands = {
            "chrome": ["google-chrome", "google-chrome-stable", "chrome"],
            "chrome_for_testing": ["google-chrome-for-testing", "chrome-for-testing"],
            "chromium": ["chromium", "chromium-browser"],
        }
        paths: list[Path] = []
        for command in commands.get(browser_family, []):
            resolved = shutil.which(command)
            if resolved:
                paths.append(Path(resolved))
        return paths
    return []


def _browser_install_identity_from_executable(
    *,
    browser_family: str,
    executable_realpath: str,
    signing_identity: dict[str, Any] | None,
) -> str:
    if sys.platform == "darwin":
        identifier = _macos_identity_identifier(signing_identity)
        if identifier:
            return identifier
    return executable_realpath


def _browser_family_accepts_macos_identifier(
    browser_family: str,
    identifier: str | None,
) -> bool:
    normalized = str(identifier or "").strip()
    if not normalized:
        return False
    if browser_family in {"chrome", "chrome_for_testing"}:
        return normalized == "com.google.Chrome" or normalized.startswith("com.google.Chrome.")
    if browser_family == "chromium":
        return normalized == "org.chromium.Chromium"
    return False


def _resolved_browser_install_guard(
    *,
    browser_family: str,
    local_uid: int,
) -> dict[str, Any] | None:
    for candidate in _candidate_browser_executable_paths(browser_family):
        resolved = _resolved_file_path_if_available(str(candidate))
        if not resolved:
            continue
        signing_identity = _macos_signing_identity(resolved)
        if sys.platform == "darwin":
            allow_playwright_test_browser = (
                browser_family == "chrome_for_testing"
                and os.environ.get("SKYLINE_TEST_ALLOW_UNSIGNED_CHROME_FOR_TESTING") == "1"
                and "/Library/Caches/ms-playwright/" in str(resolved)
            )
            if not allow_playwright_test_browser and not _browser_family_accepts_macos_identifier(
                browser_family,
                _macos_identity_identifier(signing_identity),
            ):
                continue
        elif sys.platform.startswith("linux"):
            if not _linux_binary_is_root_owned(resolved):
                continue
        else:
            continue
        return {
            "local_uid": local_uid,
            "platform": _current_platform_name(),
            "browser_family": browser_family,
            "browser_basename": _executable_basename(resolved),
            "browser_identity": _browser_install_identity_from_executable(
                browser_family=browser_family,
                executable_realpath=resolved,
                signing_identity=signing_identity,
            ),
            "browser_realpath": resolved,
            "browser_macos_signing_identity": signing_identity,
        }
    return None


def _browser_host_manifest_path(
    *,
    browser_family: str,
    native_host_name: str,
) -> Path | None:
    home = Path.home()
    if sys.platform == "darwin":
        base = home / "Library" / "Application Support"
        if browser_family == "chrome":
            return base / "Google" / "Chrome" / "NativeMessagingHosts" / f"{native_host_name}.json"
        if browser_family == "chrome_for_testing":
            return (
                base
                / "Google"
                / "ChromeForTesting"
                / "NativeMessagingHosts"
                / f"{native_host_name}.json"
            )
        if browser_family == "chromium":
            return base / "Chromium" / "NativeMessagingHosts" / f"{native_host_name}.json"
    if sys.platform.startswith("linux"):
        base = home / ".config"
        if browser_family == "chrome":
            return base / "google-chrome" / "NativeMessagingHosts" / f"{native_host_name}.json"
        if browser_family == "chrome_for_testing":
            return (
                base
                / "google-chrome-for-testing"
                / "NativeMessagingHosts"
                / f"{native_host_name}.json"
            )
        if browser_family == "chromium":
            return base / "chromium" / "NativeMessagingHosts" / f"{native_host_name}.json"
    return None


def _browser_host_launcher_matches_config(
    *,
    launcher_path: Path,
    config_path: Path,
) -> bool:
    resolved_launcher = _resolved_file_path_if_available(str(launcher_path))
    if not resolved_launcher:
        return False
    try:
        launcher_text = Path(resolved_launcher).read_text(encoding="utf-8")
    except Exception:
        return False
    expected_config = str(config_path.expanduser())
    return (
        "browser-host --config-path " in launcher_text
        and expected_config in launcher_text
        and " native-host " in launcher_text
    )


def _browser_peer_local_uid(peer: dict[str, Any]) -> int | None:
    transport = str(peer.get("transport") or "").strip()
    current_uid = _current_local_uid()
    if transport == "test":
        return current_uid if current_uid is not None else 0
    if transport != "unix_socket":
        return None
    peer_uid = peer.get("uid")
    if not isinstance(peer_uid, int) or peer_uid < 0:
        return None
    if current_uid is not None and peer_uid != current_uid:
        return None
    return peer_uid


def _configured_browser_companion_guard(
    *,
    peer: dict[str, Any],
    browser_host_metadata: dict[str, Any],
) -> tuple[dict[str, Any] | None, str]:
    local_uid = _browser_peer_local_uid(peer)
    if local_uid is None:
        return None, "browser_peer_not_same_local_user"
    browser_family = _normalize_browser_install_family(
        str(browser_host_metadata.get("browser") or "").strip() or "chrome"
    )
    if browser_family is None:
        return None, "browser_family_not_supported"
    native_host_name = (
        str(browser_host_metadata.get("native_host_name") or "").strip()
        or DEFAULT_BROWSER_HOST_NATIVE_HOST_NAME
    )
    extension_id = str(browser_host_metadata.get("extension_id") or "").strip()
    if not extension_id:
        return None, "browser_extension_id_missing"
    manifest_path = (
        Path(str(browser_host_metadata.get("native_host_manifest_path") or "")).expanduser()
        if str(browser_host_metadata.get("native_host_manifest_path") or "").strip()
        else _browser_host_manifest_path(
            browser_family=browser_family,
            native_host_name=native_host_name,
        )
    )
    if manifest_path is None or not manifest_path.exists():
        return None, "browser_native_host_manifest_missing"
    try:
        manifest_payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return None, "browser_native_host_manifest_invalid"
    if not isinstance(manifest_payload, dict):
        return None, "browser_native_host_manifest_invalid"
    launcher_path = (
        Path(str(browser_host_metadata.get("native_host_launcher_path") or "")).expanduser()
        if str(browser_host_metadata.get("native_host_launcher_path") or "").strip()
        else _default_browser_launcher_path(native_host_name)
    )
    manifest_launcher_path = str(manifest_payload.get("path") or "").strip()
    if (
        str(manifest_payload.get("name") or "").strip() != native_host_name
        or not manifest_launcher_path
        or _realpath_if_available(manifest_launcher_path)
        != _realpath_if_available(str(launcher_path))
    ):
        return None, "browser_native_host_manifest_mismatch"
    if manifest_payload.get("type") != "stdio":
        return None, "browser_native_host_manifest_mismatch"
    expected_origins = [f"chrome-extension://{extension_id}/"]
    if manifest_payload.get("allowed_origins") != expected_origins:
        return None, "browser_native_host_manifest_origin_mismatch"
    runtime_config_path = Path(
        str(browser_host_metadata.get("runtime_config_path") or DEFAULT_BROWSER_HOST_CONFIG_PATH)
    ).expanduser()
    if not _browser_host_launcher_matches_config(
        launcher_path=launcher_path,
        config_path=runtime_config_path,
    ):
        return None, "browser_native_host_launcher_mismatch"
    install_guard = _resolved_browser_install_guard(
        browser_family=browser_family,
        local_uid=local_uid,
    )
    if install_guard is None:
        return None, "browser_install_not_verified"
    return install_guard, ""


def _machine_seed_is_bound(metadata: dict[str, Any]) -> bool:
    return bool(
        str(metadata.get("base_url") or "").strip()
        and str(metadata.get("seeded_machine_id") or "").strip()
    )


def _macos_secure_enclave_metadata(
    *,
    probe: dict[str, Any],
    signer_backend: str,
    key_algorithm: str,
) -> dict[str, Any]:
    status = str(probe.get("status") or "").strip()
    reason = str(probe.get("reason") or "").strip() or None
    return {
        "available": bool(probe.get("available")),
        "status": "enabled" if status == MACOS_SECURE_ENCLAVE_STATUS_AVAILABLE else "software_fallback",
        "probe_status": status,
        "reason": reason,
        "signer_backend": signer_backend,
        "key_algorithm": key_algorithm,
    }


def _with_macos_secure_enclave_metadata(
    metadata: dict[str, Any],
    secure_enclave_metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    if not secure_enclave_metadata:
        return dict(metadata)
    updated = dict(metadata)
    updated[MACOS_SECURE_ENCLAVE_METADATA_KEY] = dict(secure_enclave_metadata)
    return updated


def _identity_private_material_present(
    credentials: dict[str, str],
    *,
    key_algorithm: str | None = None,
) -> bool:
    normalized_algorithm = str(key_algorithm or "").strip()
    if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE:
        return bool(str(credentials.get("private_key_representation") or "").strip())
    if normalized_algorithm:
        return bool(str(credentials.get("private_key") or "").strip())
    return bool(
        str(credentials.get("private_key") or "").strip()
        or str(credentials.get("private_key_representation") or "").strip()
    )


def _apply_identity_keypair_credentials(
    credentials: dict[str, str],
    keypair: dict[str, str],
) -> None:
    credentials.pop("private_key", None)
    credentials.pop("private_key_representation", None)
    if str(keypair.get("private_key") or "").strip():
        credentials["private_key"] = keypair["private_key"]
    if str(keypair.get("private_key_representation") or "").strip():
        credentials["private_key_representation"] = keypair["private_key_representation"]


def _missing_machine_seed_identity_fields(
    *,
    metadata: dict[str, Any],
    credentials: dict[str, str],
    required_key_algorithm: str | None = None,
) -> list[str]:
    missing: list[str] = []
    expected_algorithm = str(required_key_algorithm or metadata.get("key_algorithm") or "").strip()
    if required_key_algorithm and metadata.get("key_algorithm") != required_key_algorithm:
        missing.append("machine key algorithm")
    if not _identity_private_material_present(
        credentials,
        key_algorithm=expected_algorithm or None,
    ):
        if expected_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE:
            missing.append("Secure Enclave machine key representation")
        else:
            missing.append("machine private key material")
    if not str(metadata.get("public_key") or "").strip():
        missing.append("machine public key")
    if not str(credentials.get("delivery_private_key") or "").strip():
        missing.append("delivery private key")
    if not str(metadata.get("delivery_public_key") or "").strip():
        missing.append("delivery public key")
    if not str(credentials.get("secret_unwrap_private_key") or "").strip():
        missing.append("secret unwrap private key")
    if not str(metadata.get("secret_unwrap_public_key") or "").strip():
        missing.append("secret unwrap public key")
    return missing


def _is_incomplete_seeded_machine_identity_error(error: BaseException) -> bool:
    return "seeded machine identity is incomplete" in str(error).lower()


def _ensure_machine_seed_identity(
    config_path: Path,
    *,
    metadata: dict[str, Any],
    credentials: dict[str, str],
    bootstrap_secret_file: str | None,
    identity_keypair_factory=None,
    required_key_algorithm: str | None = None,
) -> tuple[dict[str, Any], dict[str, str]]:
    updated_metadata = dict(metadata)
    updated_credentials = dict(credentials)

    missing_identity_fields = _missing_machine_seed_identity_fields(
        metadata=updated_metadata,
        credentials=updated_credentials,
        required_key_algorithm=required_key_algorithm,
    )
    if _machine_seed_is_bound(updated_metadata) and missing_identity_fields:
        raise RuntimeError(
            "seeded machine identity is incomplete; restore the stored requester "
            "credentials or reseed instead of rotating identity (missing: "
            + ", ".join(missing_identity_fields)
            + ")"
        )

    if not (
        _identity_private_material_present(
            updated_credentials,
            key_algorithm=required_key_algorithm or updated_metadata.get("key_algorithm"),
        )
        and str(updated_metadata.get("public_key") or "").strip()
        and (
            required_key_algorithm is None
            or updated_metadata.get("key_algorithm") == required_key_algorithm
        )
    ):
        keypair_factory = identity_keypair_factory or generate_local_identity_keypair
        keypair = keypair_factory()
        updated_metadata.update(
            {
                "key_algorithm": keypair["algorithm"],
                "key_id": keypair["key_id"],
                "key_fingerprint": keypair["key_fingerprint"],
                "public_key": keypair["public_key"],
            }
        )
        _apply_identity_keypair_credentials(updated_credentials, keypair)

    if not (
        str(updated_credentials.get("delivery_private_key") or "").strip()
        and str(updated_metadata.get("delivery_public_key") or "").strip()
    ):
        delivery_keypair = generate_delivery_keypair()
        updated_metadata.update(
            {
                "delivery_key_algorithm": delivery_keypair["algorithm"],
                "delivery_key_id": delivery_keypair["key_id"],
                "delivery_key_fingerprint": delivery_keypair["key_fingerprint"],
                "delivery_public_key": delivery_keypair["public_key"],
            }
        )
        updated_credentials["delivery_private_key"] = delivery_keypair["private_key"]

    if not (
        str(updated_credentials.get("secret_unwrap_private_key") or "").strip()
        and str(updated_metadata.get("secret_unwrap_public_key") or "").strip()
    ):
        secret_unwrap_keypair = generate_delivery_keypair()
        updated_metadata.update(
            {
                "secret_unwrap_key_algorithm": secret_unwrap_keypair["algorithm"],
                "secret_unwrap_key_id": secret_unwrap_keypair["key_id"],
                "secret_unwrap_key_fingerprint": secret_unwrap_keypair["key_fingerprint"],
                "secret_unwrap_public_key": secret_unwrap_keypair["public_key"],
                "secret_unwrap_key_version": 1,
            }
        )
        updated_credentials["secret_unwrap_private_key"] = secret_unwrap_keypair["private_key"]

    _save_machine_seed_credentials(
        config_path,
        metadata=updated_metadata,
        credentials=updated_credentials,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    return updated_metadata, updated_credentials


def _default_machine_name() -> str:
    hostname = socket.gethostname().strip()
    return hostname or "Machine"


def _persist_machine_seed_state(
    config_path: Path,
    *,
    metadata: dict[str, Any],
    credentials: dict[str, str],
    bootstrap_secret_file: str | None,
    base_url: str,
    machine_seed: dict[str, Any],
    requester_note: str | None,
    requester_profile: str | None,
    requester_tags: list[str],
    requester_metadata: dict[str, Any],
    local_delivery: dict[str, Any] | None,
    hosted_tenant_id: str | None,
) -> tuple[dict[str, Any], dict[str, str]]:
    previous_seeded_machine_id = str(metadata.get("seeded_machine_id") or "").strip()
    next_seeded_machine_id = str(machine_seed.get("machine_seed_id") or "").strip()
    updated_metadata = dict(metadata)
    updated_metadata.pop("requester_id", None)
    updated_metadata.pop("app_id", None)
    updated_metadata.pop("display_name", None)
    updated_metadata.update(
        {
            "base_url": base_url.rstrip("/"),
            "hosted_tenant_id": (hosted_tenant_id or "").strip() or None,
            "seeded_machine_id": machine_seed.get("machine_seed_id"),
            "machine_display_name": machine_seed.get("display_name"),
            "bootstrap_token_id": machine_seed.get("bootstrap_token_id"),
            "requested_note": requester_note,
            "requested_profile": requester_profile,
            "requested_tags": list(requester_tags),
            "requested_metadata": dict(requester_metadata),
            "platform": _current_platform_name(),
        }
    )
    if isinstance(local_delivery, dict):
        updated_metadata.update(
            {
                "delivery_component_id": local_delivery.get("helper_id"),
                "delivery_target_id": local_delivery.get("delivery_target_id"),
                "delivery_slot_id": local_delivery.get("slot_id"),
                "delivery_slot_label": local_delivery.get("slot_label"),
            }
        )
    updated_credentials = dict(credentials)
    updated_credentials.pop("bootstrap_token", None)
    updated_credentials.pop("access_token", None)
    updated_credentials.pop("access_token_expires_at_epoch_ms", None)
    credential_storage_backend = _save_machine_seed_credentials(
        config_path,
        metadata=updated_metadata,
        credentials=updated_credentials,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    updated_metadata["credential_storage_backend"] = credential_storage_backend
    if next_seeded_machine_id and next_seeded_machine_id != previous_seeded_machine_id:
        profiles = _load_requester_app_profiles(config_path)
        if profiles:
            _save_requester_app_profiles(
                config_path,
                {
                    profile_id: _clear_requester_app_pairing_state(profile)
                    for profile_id, profile in profiles.items()
                },
            )
    return updated_metadata, updated_credentials


def _hosted_tenant_headers_from_id(hosted_tenant_id: str | None) -> dict[str, str]:
    normalized = str(hosted_tenant_id or "").strip()
    if not normalized:
        return {}
    return {HOSTED_TENANT_HEADER: normalized}


def _hosted_tenant_headers_from_metadata(metadata: dict[str, Any]) -> dict[str, str]:
    return _hosted_tenant_headers_from_id(str(metadata.get("hosted_tenant_id") or ""))


def _load_machine_metadata_from_context(context: Any) -> dict[str, Any]:
    loader = getattr(context, "load_machine_metadata", None)
    if callable(loader):
        return dict(loader())
    return {}


def _request_core_json_with_optional_headers(
    *,
    method: str,
    base_url: str,
    path: str,
    access_token: str | None = None,
    extra_headers: dict[str, str] | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "method": method,
        "base_url": base_url,
        "path": path,
        "access_token": access_token,
        "json_body": json_body,
    }
    if extra_headers:
        kwargs["extra_headers"] = extra_headers
    return request_core_json(**kwargs)


def _requester_update_status_for_metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    current_version = installed_requester_cli_version()
    base_url = str(metadata.get("base_url") or "").strip()
    if not base_url:
        return build_requester_cli_update_status(current_version=current_version)

    path = "/v1/requester-cli/update-policy"
    if current_version:
        path = f"{path}?current_version={quote(current_version, safe='')}"
    try:
        payload = _request_core_json_with_optional_headers(
            method="GET",
            base_url=base_url,
            path=path,
            extra_headers=_hosted_tenant_headers_from_metadata(metadata),
        )
    except Exception as error:
        return build_requester_cli_update_status(
            current_version=current_version,
            policy_check_error=str(error),
        )
    update_status = payload.get("requester_update")
    if isinstance(update_status, dict):
        local_status = dict(update_status)
        local_status.setdefault("installed_version", current_version)
        local_status.setdefault("update_command", requester_cli_update_command())
        local_status.setdefault("restart_required", True)
        local_status.setdefault(
            "restart_guidance",
            (
                "After updating, restart any agent app or MCP session that is "
                "running `skyline bridge serve` so it loads the new CLI code."
            ),
        )
        return local_status
    return build_requester_cli_update_status(current_version=current_version)


def _attach_requester_update_status(
    payload: dict[str, Any],
    *,
    config_path: Path,
) -> dict[str, Any]:
    metadata = _load_metadata(config_path)
    annotated = dict(payload)
    annotated["requester_update"] = _requester_update_status_for_metadata(metadata)
    return annotated


def _requester_update_instructions(config_path: Path) -> dict[str, Any]:
    metadata = _load_metadata(config_path)
    return {"requester_update": _requester_update_status_for_metadata(metadata)}


class LocalSignerBackend:
    backend_id = "software_secure_storage"

    def load_machine_metadata(self) -> dict[str, Any]:
        raise NotImplementedError

    def ensure_machine_identity(self) -> dict[str, Any]:
        raise NotImplementedError

    def load_machine_access_token(self) -> tuple[str | None, int]:
        raise NotImplementedError

    def store_machine_access_token(self, *, access_token: str, expires_at_epoch_ms: int) -> None:
        raise NotImplementedError

    def sign_machine_challenge(self, *, message: str) -> str:
        raise NotImplementedError

    def setup_machine(
        self,
        *,
        core_base_url: str,
        setup_code: str,
        machine_name: str | None,
        requested_note: str | None,
        requested_profile: str | None,
        requested_tags: list[str],
        requested_metadata: dict[str, Any],
        approval_timeout_seconds: float,
        hosted_tenant_id: str | None = None,
    ) -> dict[str, Any]:
        raise NotImplementedError

    def ensure_requester_profile(
        self,
        *,
        profile_id: str,
        requested_display_name: str | None,
        requested_app_identifier: str | None,
        requested_executable_path: str | None,
        requested_code_signing_identity: str | None,
        caller_guard: dict[str, Any] | None,
        rotate_keypair: bool = False,
        preserve_pairing_state: bool = True,
    ) -> dict[str, Any]:
        raise NotImplementedError

    def sign_requester_message(self, *, profile_id: str, message: str) -> str:
        raise NotImplementedError

    def open_delivery_envelope(self, envelope: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError

    def decrypt_blind_secret_package(
        self,
        *,
        package: dict[str, Any],
        key_holder_id: str,
        key_version: int | None,
    ) -> str:
        raise NotImplementedError


def _sign_identity_message_from_credentials(
    *,
    credentials: dict[str, str],
    key_algorithm: str,
    message: str,
    missing_message: str,
) -> str:
    normalized_algorithm = str(key_algorithm or "").strip() or LOCAL_IDENTITY_KEY_ALGORITHM_ED25519
    if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE:
        private_key_representation = str(
            credentials.get("private_key_representation") or ""
        ).strip()
        if not private_key_representation:
            raise RuntimeError(missing_message)
        return sign_macos_secure_enclave_identity_message(
            private_key_representation=private_key_representation,
            message=message,
        )
    private_key = str(credentials.get("private_key") or "").strip()
    if not private_key:
        raise RuntimeError(missing_message)
    return sign_local_identity_message(
        private_key=private_key,
        message=message,
        key_algorithm=normalized_algorithm,
    )


class SoftwareLocalSignerBackend(LocalSignerBackend):
    def __init__(
        self,
        *,
        config_path: Path,
        bootstrap_secret_file: str | None,
    ) -> None:
        self.config_path = config_path
        self.bootstrap_secret_file = bootstrap_secret_file

    def _load_machine_credentials(self) -> dict[str, str]:
        credentials, _backend = _load_machine_seed_credentials(
            self.config_path,
            bootstrap_secret_file=self.bootstrap_secret_file,
        )
        return dict(credentials)

    def _save_machine_credentials(
        self,
        *,
        metadata: dict[str, Any],
        credentials: dict[str, str],
    ) -> None:
        _save_machine_seed_credentials(
            self.config_path,
            metadata=metadata,
            credentials=credentials,
            bootstrap_secret_file=self.bootstrap_secret_file,
        )

    def load_machine_metadata(self) -> dict[str, Any]:
        return dict(_load_metadata(self.config_path))

    def ensure_machine_identity(self) -> dict[str, Any]:
        metadata = self.load_machine_metadata()
        credentials = self._load_machine_credentials()
        metadata, _credentials = _ensure_machine_seed_identity(
            self.config_path,
            metadata=metadata,
            credentials=credentials,
            bootstrap_secret_file=self.bootstrap_secret_file,
        )
        if metadata.get("signer_backend") != self.backend_id:
            metadata = dict(metadata)
            metadata["signer_backend"] = self.backend_id
            _save_metadata(self.config_path, metadata)
        return dict(metadata)

    def load_machine_access_token(self) -> tuple[str | None, int]:
        credentials = self._load_machine_credentials()
        access_token = str(credentials.get("access_token") or "").strip() or None
        expires_text = str(credentials.get("access_token_expires_at_epoch_ms") or "")
        expires_at = int(expires_text) if expires_text.isdigit() else 0
        return access_token, expires_at

    def store_machine_access_token(self, *, access_token: str, expires_at_epoch_ms: int) -> None:
        metadata = self.load_machine_metadata()
        credentials = self._load_machine_credentials()
        credentials["access_token"] = access_token
        credentials["access_token_expires_at_epoch_ms"] = str(expires_at_epoch_ms)
        self._save_machine_credentials(metadata=metadata, credentials=credentials)

    def sign_machine_challenge(self, *, message: str) -> str:
        credentials = self._load_machine_credentials()
        metadata = self.load_machine_metadata()
        return _sign_identity_message_from_credentials(
            credentials=credentials,
            key_algorithm=str(metadata.get("key_algorithm") or LOCAL_IDENTITY_KEY_ALGORITHM_ED25519),
            message=message,
            missing_message="machine seed private key is missing",
        )

    def setup_machine(
        self,
        *,
        core_base_url: str,
        setup_code: str,
        machine_name: str | None,
        requested_note: str | None,
        requested_profile: str | None,
        requested_tags: list[str],
        requested_metadata: dict[str, Any],
        approval_timeout_seconds: float,
        hosted_tenant_id: str | None = None,
    ) -> dict[str, Any]:
        try:
            metadata = self.ensure_machine_identity()
        except RuntimeError as error:
            if not _is_incomplete_seeded_machine_identity_error(error):
                raise
            _clear_machine_seed_local_state(
                self.config_path,
                bootstrap_secret_file=self.bootstrap_secret_file,
            )
            metadata = self.ensure_machine_identity()
        credentials = self._load_machine_credentials()
        credential_storage_backend = str(metadata.get("credential_storage_backend") or "").strip()
        if not credential_storage_backend:
            _, credential_storage_backend = _machine_seed_credential_store(
                self.config_path,
                bootstrap_secret_file=self.bootstrap_secret_file,
            )
        metadata, _credentials = _setup_machine_with_approval(
            config_path=self.config_path,
            metadata=metadata,
            credentials=credentials,
            bootstrap_secret_file=self.bootstrap_secret_file,
            credential_storage_backend=credential_storage_backend,
            base_url=core_base_url,
            hosted_tenant_id=hosted_tenant_id,
            setup_code=setup_code,
            machine_name=machine_name,
            requested_note=requested_note,
            requested_profile=requested_profile,
            requested_tags=requested_tags,
            requested_metadata=requested_metadata,
            approval_timeout_seconds=approval_timeout_seconds,
        )
        if metadata.get("signer_backend") != self.backend_id:
            metadata = dict(metadata)
            metadata["signer_backend"] = self.backend_id
            _save_metadata(self.config_path, metadata)
        return dict(metadata)

    def ensure_requester_profile(
        self,
        *,
        profile_id: str,
        requested_display_name: str | None,
        requested_app_identifier: str | None,
        requested_executable_path: str | None,
        requested_code_signing_identity: str | None,
        caller_guard: dict[str, Any] | None,
        rotate_keypair: bool = False,
        preserve_pairing_state: bool = True,
    ) -> dict[str, Any]:
        profile = _load_or_create_requester_app_profile(
            self.config_path,
            bootstrap_secret_file=self.bootstrap_secret_file,
            requested_profile_id=profile_id,
            requested_display_name=requested_display_name,
            requested_app_identifier=requested_app_identifier,
            requested_executable_path=requested_executable_path,
            requested_code_signing_identity=requested_code_signing_identity,
            ensure_keys=True,
            rotate_keypair=rotate_keypair,
        )
        if rotate_keypair and not preserve_pairing_state:
            profile = _clear_requester_app_pairing_state(profile)
        if caller_guard is not None:
            profile["caller_guard"] = dict(caller_guard)
        profile["signer_backend"] = self.backend_id
        _update_requester_app_profile(self.config_path, profile)
        return profile

    def sign_requester_message(self, *, profile_id: str, message: str) -> str:
        credentials, _backend = _load_requester_app_credentials(
            self.config_path,
            profile_id=profile_id,
            bootstrap_secret_file=self.bootstrap_secret_file,
        )
        profile = _load_requester_app_profiles(self.config_path).get(profile_id) or {}
        return _sign_identity_message_from_credentials(
            credentials=dict(credentials),
            key_algorithm=str(
                profile.get("key_algorithm") or LOCAL_IDENTITY_KEY_ALGORITHM_ED25519
            ),
            message=message,
            missing_message="requester app private key is missing",
        )

    def open_delivery_envelope(self, envelope: dict[str, Any]) -> dict[str, Any]:
        credentials = self._load_machine_credentials()
        private_key = str(credentials.get("delivery_private_key") or "").strip()
        if not private_key:
            raise RuntimeError("local delivery private key is missing")
        return open_sealed_payload(dict(envelope or {}), private_key=private_key)

    def decrypt_blind_secret_package(
        self,
        *,
        package: dict[str, Any],
        key_holder_id: str,
        key_version: int | None,
    ) -> str:
        credentials = self._load_machine_credentials()
        private_key = str(credentials.get("secret_unwrap_private_key") or "").strip()
        if not private_key:
            raise RuntimeError("local secret unwrap private key is missing")
        return decrypt_stored_blind_secret_package(
            StoredBlindSecretPackage.from_json(dict(package)),
            private_key=private_key,
            key_holder_id=key_holder_id,
            key_version=key_version,
        )


class MacOSSecureEnclaveLocalSignerBackend(SoftwareLocalSignerBackend):
    backend_id = MACOS_SECURE_ENCLAVE_SIGNER_BACKEND_ID

    def _secure_enclave_metadata(self) -> dict[str, Any]:
        return _macos_secure_enclave_metadata(
            probe=macos_secure_enclave_identity_status(),
            signer_backend=self.backend_id,
            key_algorithm=LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        )

    def ensure_machine_identity(self) -> dict[str, Any]:
        metadata = self.load_machine_metadata()
        credentials = self._load_machine_credentials()
        metadata, _credentials = _ensure_machine_seed_identity(
            self.config_path,
            metadata=metadata,
            credentials=credentials,
            bootstrap_secret_file=self.bootstrap_secret_file,
            identity_keypair_factory=generate_macos_secure_enclave_identity_keypair,
            required_key_algorithm=LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        )
        if metadata.get("signer_backend") != self.backend_id:
            metadata = dict(metadata)
            metadata["signer_backend"] = self.backend_id
        metadata = _with_macos_secure_enclave_metadata(
            metadata,
            self._secure_enclave_metadata(),
        )
        _save_metadata(self.config_path, metadata)
        return dict(metadata)

    def ensure_requester_profile(
        self,
        *,
        profile_id: str,
        requested_display_name: str | None,
        requested_app_identifier: str | None,
        requested_executable_path: str | None,
        requested_code_signing_identity: str | None,
        caller_guard: dict[str, Any] | None,
        rotate_keypair: bool = False,
        preserve_pairing_state: bool = True,
    ) -> dict[str, Any]:
        profile = _load_or_create_requester_app_profile(
            self.config_path,
            bootstrap_secret_file=self.bootstrap_secret_file,
            requested_profile_id=profile_id,
            requested_display_name=requested_display_name,
            requested_app_identifier=requested_app_identifier,
            requested_executable_path=requested_executable_path,
            requested_code_signing_identity=requested_code_signing_identity,
            ensure_keys=True,
            rotate_keypair=rotate_keypair,
            identity_keypair_factory=generate_macos_secure_enclave_identity_keypair,
            signer_backend_id=self.backend_id,
            required_key_algorithm=LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        )
        if rotate_keypair and not preserve_pairing_state:
            profile = _clear_requester_app_pairing_state(profile)
        if caller_guard is not None:
            profile["caller_guard"] = dict(caller_guard)
        profile["signer_backend"] = self.backend_id
        profile = _with_macos_secure_enclave_metadata(
            profile,
            self._secure_enclave_metadata(),
        )
        _update_requester_app_profile(self.config_path, profile)
        return profile


class MacOSSoftwareFallbackLocalSignerBackend(SoftwareLocalSignerBackend):
    backend_id = "macos_software_fallback"

    def __init__(
        self,
        *,
        config_path: Path,
        bootstrap_secret_file: str | None,
        secure_enclave_probe: dict[str, Any],
    ) -> None:
        super().__init__(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
        self.secure_enclave_probe = dict(secure_enclave_probe)

    def _secure_enclave_metadata(self, *, key_algorithm: str) -> dict[str, Any]:
        return _macos_secure_enclave_metadata(
            probe=self.secure_enclave_probe,
            signer_backend=self.backend_id,
            key_algorithm=key_algorithm,
        )

    def ensure_machine_identity(self) -> dict[str, Any]:
        metadata = super().ensure_machine_identity()
        metadata = _with_macos_secure_enclave_metadata(
            metadata,
            self._secure_enclave_metadata(
                key_algorithm=str(
                    metadata.get("key_algorithm") or LOCAL_IDENTITY_KEY_ALGORITHM_ED25519
                ),
            ),
        )
        _save_metadata(self.config_path, metadata)
        return dict(metadata)

    def ensure_requester_profile(
        self,
        *,
        profile_id: str,
        requested_display_name: str | None,
        requested_app_identifier: str | None,
        requested_executable_path: str | None,
        requested_code_signing_identity: str | None,
        caller_guard: dict[str, Any] | None,
        rotate_keypair: bool = False,
        preserve_pairing_state: bool = True,
    ) -> dict[str, Any]:
        profile = super().ensure_requester_profile(
            profile_id=profile_id,
            requested_display_name=requested_display_name,
            requested_app_identifier=requested_app_identifier,
            requested_executable_path=requested_executable_path,
            requested_code_signing_identity=requested_code_signing_identity,
            caller_guard=caller_guard,
            rotate_keypair=rotate_keypair,
            preserve_pairing_state=preserve_pairing_state,
        )
        profile = _with_macos_secure_enclave_metadata(
            profile,
            self._secure_enclave_metadata(
                key_algorithm=str(
                    profile.get("key_algorithm") or LOCAL_IDENTITY_KEY_ALGORITHM_ED25519
                ),
            ),
        )
        _update_requester_app_profile(self.config_path, profile)
        return dict(profile)


def _select_local_signer_backend(
    *,
    config_path: Path,
    bootstrap_secret_file: str | None,
) -> LocalSignerBackend:
    metadata = _load_metadata(config_path)
    existing_backend = str(metadata.get("signer_backend") or "").strip()
    existing_algorithm = str(metadata.get("key_algorithm") or "").strip()
    software_backend = SoftwareLocalSignerBackend(
        config_path=config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    if sys.platform != "darwin":
        return software_backend
    if os.environ.get(MACOS_SOFTWARE_SIGNER_DEV_OVERRIDE_ENV_VAR, "").strip() in {
        "1",
        "true",
        "yes",
    }:
        return MacOSSoftwareFallbackLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
            secure_enclave_probe={
                "available": False,
                "status": "dev_override",
                "reason": "macOS software signer dev override is enabled",
            },
        )
    if existing_backend == MacOSSecureEnclaveLocalSignerBackend.backend_id:
        return MacOSSecureEnclaveLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if existing_backend == MacOSSoftwareFallbackLocalSignerBackend.backend_id:
        probe = macos_secure_enclave_identity_status()
        if probe.get("status") == MACOS_SECURE_ENCLAVE_STATUS_HELPER_UNAVAILABLE:
            raise RuntimeError(str(probe.get("reason") or "macOS Secure Enclave helper is missing"))
        return MacOSSoftwareFallbackLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
            secure_enclave_probe=probe,
        )
    if existing_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE:
        return MacOSSecureEnclaveLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    probe = macos_secure_enclave_identity_status()
    if probe.get("available"):
        return MacOSSecureEnclaveLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if probe.get("status") == MACOS_SECURE_ENCLAVE_STATUS_HARDWARE_UNAVAILABLE:
        return MacOSSoftwareFallbackLocalSignerBackend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
            secure_enclave_probe=probe,
        )
    raise RuntimeError(
        str(probe.get("reason") or "")
        or "macOS Secure Enclave helper is unavailable; reinstall or update Skyline."
    )


class LocalRequesterContext:
    def __init__(
        self,
        *,
        config_path: Path,
        bootstrap_secret_file: str | None,
    ) -> None:
        self.config_path = config_path
        self.bootstrap_secret_file = bootstrap_secret_file
        self.signer_backend: LocalSignerBackend = _select_local_signer_backend(
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
        self._lock = threading.RLock()

    def load_machine_metadata(self) -> dict[str, Any]:
        return self.signer_backend.load_machine_metadata()

    def ensure_machine_identity(self) -> dict[str, Any]:
        with self._lock:
            return self.signer_backend.ensure_machine_identity()

    @property
    def base_url(self) -> str:
        metadata = self.load_machine_metadata()
        base_url = str(metadata.get("base_url") or "").strip()
        if not base_url:
            raise RuntimeError("local requester service base_url is missing")
        return base_url

    @property
    def seeded_machine_id(self) -> str:
        metadata = self.load_machine_metadata()
        seeded_machine_id = str(metadata.get("seeded_machine_id") or "").strip()
        if not seeded_machine_id:
            raise RuntimeError("machine seed id is missing")
        return seeded_machine_id

    def is_seeded(self) -> bool:
        metadata = self.load_machine_metadata()
        return bool(
            str(metadata.get("seeded_machine_id") or "").strip()
            and str(metadata.get("base_url") or "").strip()
        )

    def ensure_access_token(self) -> str:
        with self._lock:
            metadata = self.load_machine_metadata()
            base_url = str(metadata.get("base_url") or "").strip()
            seeded_machine_id = str(metadata.get("seeded_machine_id") or "").strip()
            if not base_url or not seeded_machine_id:
                raise RuntimeError("this machine is not set up yet; run `skyline setup` first")
            access_token, expires_at = self.signer_backend.load_machine_access_token()
            if access_token and expires_at > int(time.time() * 1000) + 60_000:
                return access_token
            try:
                challenge_payload = _request_core_json_with_optional_headers(
                    method="POST",
                    base_url=base_url,
                    path="/v1/machine-seed/session-challenge",
                    extra_headers=_hosted_tenant_headers_from_metadata(metadata),
                    json_body={"machine_seed_id": seeded_machine_id},
                )
            except httpx.HTTPStatusError as error:
                if error.response.status_code in {400, 401, 403, 404}:
                    raise RuntimeError(
                        "machine seed session could not be refreshed; run `skyline setup` "
                        "with a fresh setup link, then configure the agent with local STDIO MCP."
                    ) from error
                raise
            challenge = challenge_payload.get("challenge")
            message = str(challenge_payload.get("message") or "").strip()
            if not isinstance(challenge, dict) or not message:
                raise RuntimeError("machine seed session challenge response was incomplete")
            signature = self.signer_backend.sign_machine_challenge(message=message)
            try:
                exchange_payload = _request_core_json_with_optional_headers(
                    method="POST",
                    base_url=base_url,
                    path="/v1/machine-seed/session-exchange",
                    extra_headers=_hosted_tenant_headers_from_metadata(metadata),
                    json_body={
                        "machine_seed_id": seeded_machine_id,
                        "challenge_id": challenge["challenge_id"],
                        "signature": signature,
                    },
                )
            except httpx.HTTPStatusError as error:
                if error.response.status_code in {400, 401, 403, 404}:
                    raise RuntimeError(
                        "machine seed session could not be refreshed; run `skyline setup` "
                        "with a fresh setup link, then configure the agent with local STDIO MCP."
                    ) from error
                raise
            refreshed_token = str(exchange_payload.get("access_token") or "").strip()
            expires_at_epoch_ms = int(exchange_payload.get("expires_at_epoch_ms") or 0)
            if not refreshed_token or expires_at_epoch_ms <= 0:
                raise RuntimeError("machine seed session exchange did not return a token")
            self.signer_backend.store_machine_access_token(
                access_token=refreshed_token,
                expires_at_epoch_ms=expires_at_epoch_ms,
            )
            return refreshed_token

    def setup_machine(
        self,
        *,
        core_base_url: str,
        setup_code: str,
        machine_name: str | None,
        requested_note: str | None,
        requested_profile: str | None,
        requested_tags: list[str],
        requested_metadata: dict[str, Any],
        approval_timeout_seconds: float,
        hosted_tenant_id: str | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            return self.signer_backend.setup_machine(
                core_base_url=core_base_url,
                hosted_tenant_id=hosted_tenant_id,
                setup_code=setup_code,
                machine_name=machine_name,
                requested_note=requested_note,
                requested_profile=requested_profile,
                requested_tags=requested_tags,
                requested_metadata=requested_metadata,
                approval_timeout_seconds=approval_timeout_seconds,
            )

    def ensure_requester_profile(
        self,
        *,
        profile_id: str,
        requested_display_name: str | None,
        requested_app_identifier: str | None,
        requested_executable_path: str | None,
        requested_code_signing_identity: str | None,
        caller_guard: dict[str, Any] | None,
        rotate_keypair: bool = False,
        preserve_pairing_state: bool = True,
    ) -> dict[str, Any]:
        with self._lock:
            return self.signer_backend.ensure_requester_profile(
                profile_id=profile_id,
                requested_display_name=requested_display_name,
                requested_app_identifier=requested_app_identifier,
                requested_executable_path=requested_executable_path,
                requested_code_signing_identity=requested_code_signing_identity,
                caller_guard=caller_guard,
                rotate_keypair=rotate_keypair,
                preserve_pairing_state=preserve_pairing_state,
            )

    def requester_forward_headers(
        self,
        *,
        profile_id: str,
        requester_app_principal_id: str,
        core_method: str,
        core_path: str,
        core_params: dict[str, Any] | None,
        core_json_body: dict[str, Any] | None,
    ) -> dict[str, str]:
        timestamp_ms = int(time.time() * 1000)
        nonce = uuid.uuid4().hex
        body_sha256 = (
            sha256_bytes(b"")
            if core_json_body is None
            else sha256_text(canonical_json_dumps(core_json_body))
        )
        message = build_requester_request_proof_message(
            seeded_machine_id=self.seeded_machine_id,
            requester_app_principal_id=requester_app_principal_id,
            method=core_method,
            path=core_path,
            query_string=canonical_query_string(core_params),
            body_sha256=body_sha256,
            timestamp_ms=timestamp_ms,
            nonce=nonce,
        )
        signature = self.signer_backend.sign_requester_message(
            profile_id=profile_id,
            message=message,
        )
        return {
            REQUESTER_APP_PRINCIPAL_ID_HEADER: requester_app_principal_id,
            REQUESTER_APP_PROFILE_ID_HEADER: profile_id,
            REQUESTER_APP_TIMESTAMP_HEADER: str(timestamp_ms),
            REQUESTER_APP_NONCE_HEADER: nonce,
            REQUESTER_APP_SIGNATURE_HEADER: signature,
        }

    def open_delivery_envelope(self, envelope: dict[str, Any]) -> dict[str, Any]:
        return self.signer_backend.open_delivery_envelope(envelope)

    def decrypt_blind_secret_package(
        self,
        *,
        package: dict[str, Any],
        key_holder_id: str,
        key_version: int | None = None,
    ) -> str:
        return self.signer_backend.decrypt_blind_secret_package(
            package=package,
            key_holder_id=key_holder_id,
            key_version=key_version,
        )


def _coerce_metadata_json(raw: str | None) -> dict[str, Any]:
    if raw is None or not raw.strip():
        return {}
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise RuntimeError("--metadata-json must decode to an object")
    return payload


def _local_delivery_metadata(
    *,
    metadata: dict[str, Any],
    credentials_backend: str,
    machine_name: str,
) -> dict[str, Any]:
    return {
        "public_key": metadata["delivery_public_key"],
        "key_algorithm": metadata["delivery_key_algorithm"],
        "key_id": metadata["delivery_key_id"],
        "secret_unwrap_public_key": metadata["secret_unwrap_public_key"],
        "secret_unwrap_key_algorithm": metadata["secret_unwrap_key_algorithm"],
        "secret_unwrap_key_id": metadata["secret_unwrap_key_id"],
        "secret_unwrap_key_version": int(metadata.get("secret_unwrap_key_version") or 1),
        "helper_display_name": f"{machine_name} Local Delivery",
        "platform": str(metadata.get("platform") or _current_platform_name()),
        "slot_id": DEFAULT_REQUESTER_LOCAL_SLOT_ID,
        "slot_label": DEFAULT_REQUESTER_LOCAL_SLOT_LABEL,
        "credential_storage_backend": credentials_backend,
    }


def _resolved_requester_defaults(
    args: argparse.Namespace,
    *,
    metadata: dict[str, Any],
) -> tuple[str | None, str | None, list[str], dict[str, Any]]:
    requested_note = (
        str(args.requester_note or "").strip()
        or str(metadata.get("requested_note") or "").strip()
        or None
    )
    requested_profile = (
        str(args.requester_profile or "").strip()
        or str(metadata.get("requested_profile") or "").strip()
        or None
    )
    requested_tags = list(args.requester_tag or []) or list(metadata.get("requested_tags") or [])
    raw_requested_metadata = _coerce_metadata_json(args.metadata_json)
    if not raw_requested_metadata and isinstance(metadata.get("requested_metadata"), dict):
        raw_requested_metadata = dict(metadata.get("requested_metadata") or {})
    requested_metadata = raw_requested_metadata
    return requested_note, requested_profile, requested_tags, requested_metadata


def _setup_machine_with_approval(
    *,
    config_path: Path,
    metadata: dict[str, Any],
    credentials: dict[str, str],
    bootstrap_secret_file: str | None,
    credential_storage_backend: str,
    base_url: str,
    setup_code: str,
    machine_name: str | None,
    requested_note: str | None,
    requested_profile: str | None,
    requested_tags: list[str],
    requested_metadata: dict[str, Any],
    approval_timeout_seconds: float,
    hosted_tenant_id: str | None = None,
) -> tuple[dict[str, Any], dict[str, str]]:
    machine_name = (
        str(machine_name or metadata.get("machine_display_name") or metadata.get("display_name") or "").strip()
        or _default_machine_name()
    )
    effective_requested_note = (
        str(requested_note or metadata.get("requested_note") or "").strip() or None
    )
    effective_requested_profile = (
        str(requested_profile or metadata.get("requested_profile") or "").strip() or None
    )
    effective_requested_tags = list(requested_tags or []) or list(metadata.get("requested_tags") or [])
    effective_requested_metadata = dict(requested_metadata or {})
    if not effective_requested_metadata and isinstance(metadata.get("requested_metadata"), dict):
        effective_requested_metadata = dict(metadata.get("requested_metadata") or {})
    if isinstance(metadata.get(MACOS_SECURE_ENCLAVE_METADATA_KEY), dict):
        effective_requested_metadata[MACOS_SECURE_ENCLAVE_METADATA_KEY] = dict(
            metadata[MACOS_SECURE_ENCLAVE_METADATA_KEY]
        )
    effective_requested_metadata[REQUESTER_LOCAL_DELIVERY_METADATA_KEY] = _local_delivery_metadata(
        metadata=metadata,
        credentials_backend=credential_storage_backend,
        machine_name=machine_name,
    )
    setup_code = setup_code.strip().upper()
    if not setup_code:
        raise RuntimeError("setup_code must not be empty")
    payload = _request_core_json_with_optional_headers(
        method="POST",
        base_url=base_url,
        path="/v1/bootstrap/setup-sessions",
        extra_headers=_hosted_tenant_headers_from_id(hosted_tenant_id),
        json_body={
            "setup_code": setup_code,
            "display_name": machine_name,
            "requested_note": effective_requested_note,
            "requested_profile": effective_requested_profile,
            "requested_tags": effective_requested_tags,
            "requested_metadata": effective_requested_metadata,
            "machine_public_key": metadata["public_key"],
            "key_algorithm": metadata["key_algorithm"],
            "key_id": metadata["key_id"],
        },
    )
    setup_session_id = str(
        payload.get("setup_session_id") or payload.get("request_id") or ""
    ).strip()
    if not setup_session_id:
        raise RuntimeError("machine setup response did not include a setup session id")
    resolved_hosted_tenant_id = str(payload.get("hosted_tenant_id") or "").strip()
    effective_hosted_tenant_id = (
        str(hosted_tenant_id or "").strip() or resolved_hosted_tenant_id or None
    )
    deadline = time.monotonic() + max(float(approval_timeout_seconds or 0), 1.0)
    while True:
        status = str(payload.get("status") or "").strip()
        if status == "completed":
            break
        if status == "denied":
            resolution = payload.get("resolution")
            reason = (
                str(resolution.get("reason") or resolution.get("path") or "").strip()
                if isinstance(resolution, dict)
                else ""
            )
            raise RuntimeError(
                "machine setup was not approved" + (f": {reason}" if reason else "")
            )
        if time.monotonic() >= deadline:
            raise RuntimeError("timed out waiting for iPhone machine setup approval")
        remaining_ms = max(int((deadline - time.monotonic()) * 1000), 0)
        poll_ms = min(remaining_ms, 15_000)
        payload = _request_core_json_with_optional_headers(
            method="GET",
            base_url=base_url,
            path=f"/v1/bootstrap/setup-sessions/{setup_session_id}/wait?timeout_ms={poll_ms}",
            extra_headers=_hosted_tenant_headers_from_id(effective_hosted_tenant_id),
        )

    result = payload.get("result")
    if not isinstance(result, dict):
        raise RuntimeError("machine setup result was incomplete")
    machine_seed = result.get("machine_seed")
    if not isinstance(machine_seed, dict):
        raise RuntimeError("machine setup did not return a machine seed")
    local_delivery = (
        result.get("helper_delivery")
        if isinstance(result.get("helper_delivery"), dict)
        else None
    )
    return _persist_machine_seed_state(
        config_path,
        metadata=metadata,
        credentials=credentials,
        bootstrap_secret_file=bootstrap_secret_file,
        base_url=base_url,
        machine_seed=machine_seed,
        requester_note=effective_requested_note,
        requester_profile=effective_requested_profile,
        requester_tags=effective_requested_tags,
        requester_metadata=effective_requested_metadata,
        local_delivery=local_delivery,
        hosted_tenant_id=effective_hosted_tenant_id,
    )


def _slugify_client_id(value: str) -> str:
    normalized = "".join(
        char.lower() if char.isalnum() else "-"
        for char in value.strip()
    )
    cleaned = "-".join(part for part in normalized.split("-") if part)
    return cleaned


def _default_client_label(client_id: str) -> str:
    parts = [
        part
        for part in client_id.replace("_", "-").split("-")
        if part.strip()
    ]
    if len(parts) >= 3 and parts[0] in _REVERSE_DNS_PREFIXES:
        parts = parts[2:]
    return " ".join(parts).title()


def _client_identity_error() -> RuntimeError:
    return RuntimeError(
        "missing app/profile metadata; Skyline could not infer a stable app or "
        "harness identity for this requester. For terminal-hosted agents, configure "
        "the local bridge with `skyline bridge serve` so Skyline can bind the "
        "requester to the agent instead of the terminal shell."
    )


def _multiple_client_profiles_error() -> RuntimeError:
    return RuntimeError(
        "multiple requester profiles are already paired on this machine and "
        "Skyline could not infer which one this app or harness should use; "
        "for terminal-hosted agents, configure the local bridge with "
        "`skyline bridge serve` so the caller can be verified."
    )


def _explicit_requester_app_args(args: argparse.Namespace) -> dict[str, str | None]:
    env = os.environ
    return {
        "client_profile": str(
            getattr(args, "client_profile", None)
            or env.get(CLIENT_PROFILE_ENV_VAR)
            or ""
        ).strip()
        or None,
        "client_display_name": str(
            getattr(args, "client_display_name", None)
            or env.get(CLIENT_DISPLAY_NAME_ENV_VAR)
            or ""
        ).strip()
        or None,
        "client_app_identifier": str(
            getattr(args, "client_app_identifier", None)
            or env.get(CLIENT_APP_IDENTIFIER_ENV_VAR)
            or ""
        ).strip()
        or None,
        "client_executable_path": str(
            getattr(args, "client_executable_path", None)
            or env.get(CLIENT_EXECUTABLE_PATH_ENV_VAR)
            or ""
        ).strip()
        or None,
        "client_code_signing_identity": str(
            getattr(args, "client_code_signing_identity", None)
            or env.get(CLIENT_CODE_SIGNING_IDENTITY_ENV_VAR)
            or ""
        ).strip()
        or None,
    }


def _process_snapshot(pid: int) -> tuple[int | None, str | None, str | None]:
    if pid <= 1:
        return None, None, None
    try:
        result = subprocess.run(
            [
                "ps",
                "-p",
                str(pid),
                "-o",
                "ppid=",
                "-o",
                "command=",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None, None, None
    line = result.stdout.strip()
    if not line:
        return None, None, None
    parts = line.split(None, 1)
    if len(parts) < 2:
        return None, None, None
    try:
        parent_pid = int(parts[0])
    except ValueError:
        parent_pid = None
    args_text = parts[1].strip() if len(parts) > 1 else None
    command = _process_executable_path(pid) or _command_text_from_command_line(args_text)
    return parent_pid, command, args_text


def _current_local_uid() -> int | None:
    getuid = getattr(os, "getuid", None)
    if getuid is None:
        return None
    try:
        return int(getuid())
    except Exception:
        return None


def _realpath_if_available(raw_path: str | None) -> str | None:
    path_text = str(raw_path or "").strip()
    if not path_text:
        return None
    candidate = Path(path_text).expanduser()
    if not candidate.is_absolute():
        resolved = shutil.which(path_text)
        if resolved:
            candidate = Path(resolved)
    try:
        if candidate.exists():
            return str(candidate.resolve())
    except Exception:
        return None
    return None


def _resolved_file_path_if_available(raw_path: str | None) -> str | None:
    resolved_path = _realpath_if_available(raw_path)
    if not resolved_path:
        return None
    try:
        if not Path(resolved_path).is_file():
            return None
    except Exception:
        return None
    return resolved_path


def _file_identity_if_available(raw_path: str | None) -> tuple[int | None, int | None]:
    resolved_path = _realpath_if_available(raw_path)
    if not resolved_path:
        return None, None
    try:
        file_stat = os.stat(resolved_path)
    except Exception:
        return None, None
    return int(file_stat.st_dev), int(file_stat.st_ino)


def _executable_basename(raw_path: str | None) -> str | None:
    path_text = str(raw_path or "").strip()
    if not path_text:
        return None
    return Path(path_text).name.strip().lower() or None


def _is_skyline_process(command_text: str, args_text: str | None) -> bool:
    command_name = _executable_basename(command_text) or ""
    normalized_args = str(args_text or "").strip().lower()
    token_basenames = [
        Path(token).name.strip().lower()
        for token in _tokenize_process_args(args_text)
        if str(token).strip()
    ]
    return (
        command_name == "skyline"
        or "skyline" in token_basenames
        or any(marker in normalized_args for marker in LOCAL_REQUESTER_MODULE_MARKERS)
    )


def _password_import_cli_identity_from_process(
    command_text: str,
    args_text: str | None,
) -> dict[str, Any] | None:
    if not _is_skyline_process(command_text, args_text):
        return None
    tokens = _tokenize_process_args(args_text)
    if "import" not in [token.strip().lower() for token in tokens]:
        return None
    skyline_token = str(command_text or "").strip()
    for token in tokens:
        if Path(token).name.strip().lower() == "skyline":
            skyline_token = token
            break
    skyline_realpath = _resolved_file_path_if_available(skyline_token)
    if skyline_realpath is None and Path(skyline_token).name.strip().lower() == "skyline":
        resolved = shutil.which("skyline")
        skyline_realpath = _resolved_file_path_if_available(resolved) if resolved else None
    skyline_device, skyline_inode = _file_identity_if_available(skyline_realpath)
    return {
        "stable_executable_kind": "first_party_cli",
        "stable_executable_identity": skyline_realpath or skyline_token or "skyline",
        "stable_executable_path": skyline_realpath or skyline_token or None,
        "stable_executable_realpath": skyline_realpath,
        "stable_executable_basename": "skyline",
        "stable_executable_device": skyline_device,
        "stable_executable_inode": skyline_inode,
        "stable_macos_signing_identity": _macos_signing_identity(skyline_realpath or ""),
        "launch_wrapper_kind": None,
        "launch_wrapper_identity": None,
        "launch_wrapper_basename": None,
        "first_party_cli_command": "import",
    }


def _tokenize_process_args(args_text: str | None) -> list[str]:
    raw_args = str(args_text or "").strip()
    if not raw_args:
        return []
    try:
        return shlex.split(raw_args)
    except ValueError:
        return raw_args.split()


def _strip_repeated_argv0(
    tokens: list[str],
    *,
    command_name: str,
    launcher_realpath: str | None,
) -> list[str]:
    stripped = list(tokens)
    while stripped:
        first_token = str(stripped[0]).strip()
        if not first_token:
            stripped = stripped[1:]
            continue
        first_name = Path(first_token).name.strip().lower()
        first_realpath = _realpath_if_available(first_token)
        if (
            first_name == command_name
            or (launcher_realpath and first_realpath and first_realpath == launcher_realpath)
        ):
            stripped = stripped[1:]
            continue
        break
    return stripped


def _module_identity_candidate(
    module_name: str,
    *,
    launcher_identity: str,
    launcher_basename: str,
    launcher_realpath: str | None,
) -> dict[str, Any] | None:
    normalized_module = str(module_name or "").strip()
    if not normalized_module:
        return None
    module_host_realpath = launcher_realpath or _resolved_file_path_if_available(launcher_identity)
    if not module_host_realpath:
        return None
    module_host_device, module_host_inode = _file_identity_if_available(module_host_realpath)
    module_host_signing_identity = _macos_signing_identity(module_host_realpath or "")
    stable_basename = (
        normalized_module.rsplit(".", 1)[-1].strip().lower()
        or normalized_module.strip().lower()
    )
    if not stable_basename:
        return None
    return {
        "stable_executable_kind": "module",
        "stable_executable_identity": normalized_module,
        "stable_executable_path": None,
        "stable_executable_realpath": None,
        "stable_executable_basename": stable_basename,
        "stable_executable_device": None,
        "stable_executable_inode": None,
        "stable_macos_signing_identity": None,
        "module_host_realpath": module_host_realpath,
        "module_host_device": module_host_device,
        "module_host_inode": module_host_inode,
        "module_host_macos_signing_identity": module_host_signing_identity,
        "launch_wrapper_kind": "executable",
        "launch_wrapper_identity": launcher_identity,
        "launch_wrapper_basename": launcher_basename,
    }


def _file_identity_candidate(
    raw_target: str,
    *,
    launcher_identity: str,
    launcher_basename: str,
) -> dict[str, Any] | None:
    resolved_target = _resolved_file_path_if_available(raw_target)
    if not resolved_target:
        return None
    stable_basename = _executable_basename(resolved_target)
    if not stable_basename:
        return None
    stable_device, stable_inode = _file_identity_if_available(resolved_target)
    stable_signing_identity = _macos_signing_identity(resolved_target)
    stable_kind = "script" if resolved_target.endswith((".py", ".pyz")) else "executable"
    return {
        "stable_executable_kind": stable_kind,
        "stable_executable_identity": resolved_target,
        "stable_executable_path": resolved_target,
        "stable_executable_realpath": resolved_target,
        "stable_executable_basename": stable_basename,
        "stable_executable_device": stable_device,
        "stable_executable_inode": stable_inode,
        "stable_macos_signing_identity": stable_signing_identity,
        "launch_wrapper_kind": "executable",
        "launch_wrapper_identity": launcher_identity,
        "launch_wrapper_basename": launcher_basename,
    }


def _generic_launch_target_identity(
    *,
    command_text: str,
    command_name: str,
    args_text: str | None,
    launcher_realpath: str | None,
) -> dict[str, Any] | None:
    tokens = _strip_repeated_argv0(
        _tokenize_process_args(args_text),
        command_name=command_name,
        launcher_realpath=launcher_realpath,
    )
    if not tokens:
        return None
    if "--" in tokens:
        separator_index = tokens.index("--")
        tokens = tokens[separator_index + 1 :]
    launcher_identity = launcher_realpath or command_text or command_name
    index = 0
    while index < len(tokens):
        token = str(tokens[index]).strip()
        if not token:
            index += 1
            continue
        if token == "-m":
            if index + 1 < len(tokens):
                return _module_identity_candidate(
                    tokens[index + 1],
                    launcher_identity=launcher_identity,
                    launcher_basename=command_name,
                    launcher_realpath=launcher_realpath,
                )
            return None
        if token == "-c":
            return None
        if token.startswith("--"):
            if "=" in token:
                index += 1
                continue
            if index + 1 < len(tokens) and not str(tokens[index + 1]).startswith("-"):
                index += 2
            else:
                index += 1
            continue
        if token.startswith("-"):
            if len(token) == 2 and index + 1 < len(tokens) and not str(tokens[index + 1]).startswith("-"):
                index += 2
            else:
                index += 1
            continue
        candidate = _file_identity_candidate(
            token,
            launcher_identity=launcher_identity,
            launcher_basename=command_name,
        )
        if candidate is not None:
            return candidate
        index += 1
    return None


def _should_parse_launch_target_args(command_name: str, args_text: str | None) -> bool:
    normalized_name = command_name.strip().lower()
    if normalized_name in _TARGET_ARGUMENT_LAUNCHER_NAMES:
        return True
    if normalized_name.startswith("python"):
        return True
    return "--" in _tokenize_process_args(args_text)


@lru_cache(maxsize=256)
def _macos_signing_identity(executable_realpath: str) -> dict[str, Any] | None:
    if sys.platform != "darwin":
        return None
    resolved_path = _realpath_if_available(executable_realpath)
    if not resolved_path:
        return None
    try:
        result = subprocess.run(
            ["codesign", "-dv", "--verbose=4", resolved_path],
            check=False,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None
    output = (result.stderr or "") + "\n" + (result.stdout or "")
    identifier = None
    team_identifier = None
    authorities: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if stripped.startswith("Identifier="):
            identifier = stripped.partition("=")[2].strip() or None
        elif stripped.startswith("TeamIdentifier="):
            team_identifier = stripped.partition("=")[2].strip() or None
        elif stripped.startswith("Authority="):
            authority = stripped.partition("=")[2].strip()
            if authority:
                authorities.append(authority)
    if not identifier and not team_identifier:
        return None
    return {
        "identifier": identifier,
        "team_identifier": team_identifier,
        "authorities": authorities,
    }


def _transport_peer_identity(transport: asyncio.Transport) -> dict[str, Any]:
    payload: dict[str, Any] = {"transport": "unix_socket"}
    socket_info: socket.socket | None = transport.get_extra_info("socket")
    if socket_info is None:
        return payload
    if sys.platform.startswith("linux") and getattr(socket, "SO_PEERCRED", None) is not None:
        try:
            raw = socket_info.getsockopt(
                socket.SOL_SOCKET,
                socket.SO_PEERCRED,
                struct.calcsize("3i"),
            )
            pid, uid, gid = struct.unpack("3i", raw)
            payload.update({"pid": int(pid), "uid": int(uid), "gid": int(gid)})
            return payload
        except Exception:
            return payload
    if sys.platform == "darwin":
        try:
            raw_pid = socket_info.getsockopt(_DARWIN_SOL_LOCAL, _DARWIN_LOCAL_PEERPID, 4)
            payload["pid"] = int.from_bytes(raw_pid, byteorder=sys.byteorder, signed=False)
        except Exception:
            pass
        try:
            libc = ctypes.CDLL(None)
            uid = ctypes.c_uint()
            gid = ctypes.c_uint()
            result = libc.getpeereid(
                socket_info.fileno(),
                ctypes.byref(uid),
                ctypes.byref(gid),
            )
            if result == 0:
                payload["uid"] = int(uid.value)
                payload["gid"] = int(gid.value)
        except Exception:
            pass
    return payload


class _LocalRequesterProtocol(H11Protocol):
    def connection_made(self, transport: asyncio.Transport) -> None:  # type: ignore[override]
        super().connection_made(transport)
        self._aperture_local_peer = _transport_peer_identity(transport)

    def handle_events(self) -> None:  # type: ignore[override]
        while True:
            try:
                event = self.conn.next_event()
            except h11.RemoteProtocolError:
                msg = "Invalid HTTP request received."
                self.logger.warning(msg)
                self.send_400_response(msg)
                return

            if event is h11.NEED_DATA:
                break
            if event is h11.PAUSED:
                self.flow.pause_reading()
                break
            if isinstance(event, h11.Request):
                self.headers = [(key.lower(), value) for key, value in event.headers]
                raw_path, _, query_string = event.target.partition(b"?")
                path = unquote(raw_path.decode("ascii"))
                full_path = self.root_path + path
                full_raw_path = self.root_path.encode("ascii") + raw_path
                state = self.app_state.copy()
                state["aperture_local_peer"] = dict(
                    getattr(self, "_aperture_local_peer", {}) or {}
                )
                self.scope = {
                    "type": "http",
                    "asgi": {"version": self.config.asgi_version, "spec_version": "2.3"},
                    "http_version": event.http_version.decode("ascii"),
                    "server": self.server,
                    "client": self.client,
                    "scheme": self.scheme,  # type: ignore[typeddict-item]
                    "method": event.method.decode("ascii"),
                    "root_path": self.root_path,
                    "path": full_path,
                    "raw_path": full_raw_path,
                    "query_string": query_string,
                    "headers": self.headers,
                    "state": state,
                    "aperture_local_peer": dict(getattr(self, "_aperture_local_peer", {}) or {}),
                }
                if self._should_upgrade():
                    self.handle_websocket_upgrade(event)
                    return
                if self.limit_concurrency is not None and (
                    len(self.connections) >= self.limit_concurrency or len(self.tasks) >= self.limit_concurrency
                ):
                    app = service_unavailable
                    message = "Exceeded concurrency limit."
                    self.logger.warning(message)
                else:
                    app = self.app
                self._unset_keepalive_if_required()
                self.cycle = RequestResponseCycle(
                    scope=self.scope,
                    conn=self.conn,
                    transport=self.transport,
                    flow=self.flow,
                    logger=self.logger,
                    access_logger=self.access_logger,
                    access_log=self.access_log,
                    default_headers=self.server_state.default_headers,
                    message_event=asyncio.Event(),
                    on_response=self.on_response_complete,
                )
                task = contextvars.Context().run(self.loop.create_task, self.cycle.run_asgi(app))
                task.add_done_callback(self.tasks.discard)
                self.tasks.add(task)
                continue
            if isinstance(event, h11.Data):
                if self.conn.our_state is h11.DONE:
                    continue
                self.cycle.body += event.data
                if len(self.cycle.body) > HIGH_WATER_LIMIT:
                    self.flow.pause_reading()
                self.cycle.message_event.set()
                continue
            if isinstance(event, h11.EndOfMessage):
                if self.conn.our_state is h11.DONE:
                    self.transport.resume_reading()
                    self.conn.start_next_cycle()
                    continue
                self.cycle.more_body = False
                self.cycle.message_event.set()
                if self.conn.their_state == h11.MUST_CLOSE:
                    break


def _request_scope_local_peer(request: Request) -> dict[str, Any]:
    peer = request.scope.get("aperture_local_peer")
    if isinstance(peer, dict) and peer:
        return dict(peer)
    state_peer = getattr(request.state, "aperture_local_peer", None)
    if isinstance(state_peer, dict) and state_peer:
        return dict(state_peer)
    client = request.scope.get("client")
    if isinstance(client, tuple) and client and client[0] == "testclient":
        payload: dict[str, Any] = {"transport": "test"}
        current_uid = _current_local_uid()
        if current_uid is not None:
            payload["uid"] = current_uid
        payload["pid"] = os.getpid()
        return payload
    return {}


def _request_connect_required_payload(
    *,
    client_profile_id: str,
    message: str,
    reason: str,
    request_id: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "status": "connect_required",
        "message": message,
        "reason": reason,
        "client_profile_id": client_profile_id,
    }
    if request_id:
        payload["request_id"] = request_id
    return payload


def _stable_executable_identity_from_process(
    *,
    command_text: str,
    command_name: str,
    args_text: str | None,
) -> dict[str, Any] | None:
    launcher_realpath = _resolved_file_path_if_available(command_text)
    launcher_device, launcher_inode = _file_identity_if_available(launcher_realpath)
    launcher_signing_identity = _macos_signing_identity(launcher_realpath or "")
    if _should_parse_launch_target_args(command_name, args_text):
        target_identity = _generic_launch_target_identity(
            command_text=command_text,
            command_name=command_name,
            args_text=args_text,
            launcher_realpath=launcher_realpath,
        )
        if target_identity is not None:
            return target_identity
    if command_name in _AMBIENT_LAUNCHER_NAMES:
        return None
    if not launcher_signing_identity and not launcher_realpath:
        return None
    return {
        "stable_executable_kind": "executable",
        "stable_executable_identity": launcher_realpath or command_text or command_name,
        "stable_executable_path": launcher_realpath or command_text or None,
        "stable_executable_realpath": launcher_realpath,
        "stable_executable_basename": command_name,
        "stable_executable_device": launcher_device,
        "stable_executable_inode": launcher_inode,
        "stable_macos_signing_identity": launcher_signing_identity,
        "launch_wrapper_kind": None,
        "launch_wrapper_identity": None,
        "launch_wrapper_basename": None,
    }


def _requester_profile_seed_from_identity(identity: dict[str, Any]) -> str:
    stable_kind = str(identity.get("stable_executable_kind") or "").strip()
    stable_identity = str(identity.get("stable_executable_identity") or "").strip()
    if stable_kind == "module":
        return stable_identity
    signing_identifier = _macos_identity_identifier(
        identity.get("stable_macos_signing_identity")
    )
    if signing_identifier:
        return signing_identifier
    basename = str(identity.get("stable_executable_basename") or "").strip()
    if basename.endswith((".cjs", ".js", ".mjs", ".py", ".pyz", ".sh")):
        basename = Path(basename).stem.strip()
    return basename or stable_identity


def _derive_caller_guard_from_peer(
    *,
    peer: dict[str, Any],
    requester_profile_id: str,
) -> dict[str, Any] | None:
    current_uid = peer.get("uid")
    peer_pid = peer.get("pid")
    if not isinstance(current_uid, int) or current_uid < 0 or not isinstance(peer_pid, int) or peer_pid <= 1:
        return None
    platform = _current_platform_name()
    visited: set[int] = set()
    pid = peer_pid
    while pid > 1 and pid not in visited:
        visited.add(pid)
        parent_pid, command, args_text = _process_snapshot(pid)
        command_text = str(command or "").strip()
        command_name = _executable_basename(command_text) or ""
        if not command_name:
            pid = parent_pid or 0
            continue
        if requester_profile_id == PASSWORD_IMPORT_CLIENT_PROFILE:
            identity = _password_import_cli_identity_from_process(
                command_text,
                args_text,
            )
            if identity is not None:
                return {
                    "local_uid": current_uid,
                    "platform": platform,
                    "requester_profile_id": requester_profile_id,
                    **identity,
                }
        if _is_skyline_process(command_text, args_text):
            pid = parent_pid or 0
            continue
        identity = _stable_executable_identity_from_process(
            command_text=command_text,
            command_name=command_name,
            args_text=args_text,
        )
        if identity is not None:
            return {
                "local_uid": current_uid,
                "platform": platform,
                "requester_profile_id": requester_profile_id,
                **identity,
            }
        pid = parent_pid or 0
    return None


def _caller_guard_matches(
    stored_guard: dict[str, Any] | None,
    current_guard: dict[str, Any] | None,
) -> bool:
    if not isinstance(stored_guard, dict) or not isinstance(current_guard, dict):
        return False
    for field in ("local_uid", "platform", "requester_profile_id"):
        if stored_guard.get(field) != current_guard.get(field):
            return False
    stable_kind = str(stored_guard.get("stable_executable_kind") or "").strip()
    if stable_kind != str(current_guard.get("stable_executable_kind") or "").strip():
        return False
    if stored_guard.get("stable_executable_basename") != current_guard.get("stable_executable_basename"):
        return False
    stored_identity = str(stored_guard.get("stable_executable_identity") or "").strip()
    current_identity = str(current_guard.get("stable_executable_identity") or "").strip()
    if not stored_identity or stored_identity != current_identity:
        return False
    if stable_kind == "module":
        stored_host_signing = stored_guard.get("module_host_macos_signing_identity")
        current_host_signing = current_guard.get("module_host_macos_signing_identity")
        if stored_host_signing and current_host_signing:
            return stored_host_signing == current_host_signing
        stored_host_realpath = str(stored_guard.get("module_host_realpath") or "").strip()
        current_host_realpath = str(current_guard.get("module_host_realpath") or "").strip()
        if bool(stored_host_realpath) != bool(current_host_realpath):
            return False
        if stored_host_realpath and stored_host_realpath != current_host_realpath:
            return False
        stored_host_device = stored_guard.get("module_host_device")
        current_host_device = current_guard.get("module_host_device")
        stored_host_inode = stored_guard.get("module_host_inode")
        current_host_inode = current_guard.get("module_host_inode")
        if (
            isinstance(stored_host_device, int)
            and isinstance(current_host_device, int)
            and isinstance(stored_host_inode, int)
            and isinstance(current_host_inode, int)
            and (stored_host_device != current_host_device or stored_host_inode != current_host_inode)
        ):
            return False
        return True
    stored_signing = stored_guard.get("stable_macos_signing_identity")
    current_signing = current_guard.get("stable_macos_signing_identity")
    if stored_signing and current_signing:
        return stored_signing == current_signing
    stored_realpath = str(stored_guard.get("stable_executable_realpath") or "").strip()
    current_realpath = str(current_guard.get("stable_executable_realpath") or "").strip()
    if bool(stored_realpath) != bool(current_realpath):
        return False
    if stored_realpath and stored_realpath != current_realpath:
        return False
    stored_device = stored_guard.get("stable_executable_device")
    current_device = current_guard.get("stable_executable_device")
    stored_inode = stored_guard.get("stable_executable_inode")
    current_inode = current_guard.get("stable_executable_inode")
    if (
        isinstance(stored_device, int)
        and isinstance(current_device, int)
        and isinstance(stored_inode, int)
        and isinstance(current_inode, int)
        and (stored_device != current_device or stored_inode != current_inode)
    ):
        return False
    return True


def _linux_binary_is_root_owned(realpath: str | None) -> bool:
    if not realpath or not sys.platform.startswith("linux"):
        return False
    try:
        file_stat = os.stat(realpath)
    except Exception:
        return False
    return int(file_stat.st_uid) == 0 and not bool(file_stat.st_mode & stat.S_IWOTH)


def _browser_install_identity(
    *,
    browser_guard: dict[str, Any],
) -> str:
    payload = {
        "platform": str(browser_guard.get("platform") or "").strip() or None,
        "browser_family": str(browser_guard.get("browser_family") or "").strip() or None,
        "browser_identity": str(browser_guard.get("browser_identity") or "").strip() or None,
        "browser_realpath": str(browser_guard.get("browser_realpath") or "").strip() or None,
    }
    canonical = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"browser_install_{digest[:24]}"


def _infer_requester_identity_from_process_tree() -> dict[str, str | None] | None:
    pid = os.getppid()
    visited: set[int] = set()
    while pid and pid > 1 and pid not in visited:
        visited.add(pid)
        parent_pid, command, args_text = _process_snapshot(pid)
        command_text = str(command or "").strip()
        command_name = _executable_basename(command_text) or ""
        if not command_name:
            pid = parent_pid or 0
            continue
        if _is_skyline_process(command_text, args_text):
            pid = parent_pid or 0
            continue
        identity = _stable_executable_identity_from_process(
            command_text=command_text,
            command_name=command_name,
            args_text=args_text,
        )
        if identity is not None:
            stable_kind = str(identity.get("stable_executable_kind") or "").strip()
            stable_identity = str(identity.get("stable_executable_identity") or "").strip()
            profile_seed = _requester_profile_seed_from_identity(identity)
            profile_id = _slugify_client_id(profile_seed)
            if profile_id:
                identifier = _macos_identity_identifier(
                    identity.get("stable_macos_signing_identity")
                )
                executable_path = (
                    str(identity.get("module_host_realpath") or "").strip()
                    if stable_kind == "module"
                    else str(
                        identity.get("stable_executable_realpath")
                        or identity.get("stable_executable_path")
                        or ""
                    ).strip()
                ) or None
                return {
                    "client_profile": profile_id,
                    "client_display_name": _default_client_label(profile_id),
                    "client_app_identifier": stable_identity,
                    "client_executable_path": executable_path,
                    "client_code_signing_identity": (
                        _macos_identity_identifier(identity.get("module_host_macos_signing_identity"))
                        or identifier
                    ),
                }
        pid = parent_pid or 0
    return None


def _resolved_requester_app_args(args: argparse.Namespace) -> dict[str, str | None]:
    explicit_args = _explicit_requester_app_args(args)
    if explicit_args["client_profile"] and explicit_args["client_display_name"]:
        return explicit_args
    detected = _infer_requester_identity_from_process_tree()
    if detected is None:
        return explicit_args
    merged = dict(explicit_args)
    for key, value in detected.items():
        if not merged.get(key) and value:
            merged[key] = value
    return merged


def _derive_requester_app_identity(
    *,
    explicit_args: dict[str, str | None],
    existing_profile: dict[str, Any] | None = None,
) -> tuple[str, str, str | None, str | None, str | None]:
    explicit_profile = explicit_args["client_profile"]
    explicit_display_name = explicit_args["client_display_name"]
    explicit_app_identifier = explicit_args["client_app_identifier"]
    explicit_executable_path = explicit_args["client_executable_path"]
    explicit_code_signing_identity = explicit_args["client_code_signing_identity"]

    if existing_profile is not None:
        profile_id = _slugify_client_id(
            str(existing_profile.get("client_profile_id") or "")
        )
        if not profile_id:
            raise _client_identity_error()
        display_name = (
            explicit_display_name
            or str(existing_profile.get("display_name") or "").strip()
            or _default_client_label(profile_id)
        )
        app_identifier = (
            explicit_app_identifier
            or str(existing_profile.get("app_identifier") or "").strip()
            or profile_id
        )
        executable_path = explicit_executable_path or str(
            existing_profile.get("executable_path") or ""
        ).strip() or None
        code_signing_identity = explicit_code_signing_identity or str(
            existing_profile.get("code_signing_identity") or ""
        ).strip() or None
        return (
            profile_id,
            display_name,
            app_identifier,
            executable_path,
            code_signing_identity,
        )

    if not any(explicit_args.values()):
        raise _client_identity_error()

    profile_seed = (
        explicit_profile
        or explicit_app_identifier
        or (
            Path(explicit_executable_path).name
            if explicit_executable_path
            else None
        )
        or explicit_display_name
        or ""
    )
    profile_id = _slugify_client_id(profile_seed)
    if not profile_id:
        raise _client_identity_error()
    display_name = explicit_display_name or _default_client_label(profile_id)
    app_identifier = explicit_app_identifier or profile_id
    return (
        profile_id,
        display_name,
        app_identifier,
        explicit_executable_path,
        explicit_code_signing_identity,
    )


def _load_or_create_requester_app_profile(
    config_path: Path,
    *,
    bootstrap_secret_file: str | None,
    requested_profile_id: str,
    requested_display_name: str | None = None,
    requested_app_identifier: str | None = None,
    requested_executable_path: str | None = None,
    requested_code_signing_identity: str | None = None,
    ensure_keys: bool = True,
    rotate_keypair: bool = False,
    identity_keypair_factory=None,
    signer_backend_id: str | None = None,
    required_key_algorithm: str | None = None,
) -> dict[str, Any]:
    profile_id = _slugify_client_id(requested_profile_id)
    if not profile_id:
        raise _client_identity_error()
    profiles = _load_requester_app_profiles(config_path)
    profile = dict(profiles.get(profile_id) or _default_profile_metadata(profile_id))
    profile["client_profile_id"] = profile_id
    if requested_display_name and requested_display_name.strip():
        profile["display_name"] = requested_display_name.strip()
    else:
        profile.setdefault("display_name", _default_client_label(profile_id))
    if requested_app_identifier and requested_app_identifier.strip():
        profile["app_identifier"] = requested_app_identifier.strip()
    else:
        profile.setdefault("app_identifier", profile_id)
    if requested_executable_path and requested_executable_path.strip():
        profile["executable_path"] = requested_executable_path.strip()
    else:
        profile.setdefault("executable_path", None)
    if requested_code_signing_identity and requested_code_signing_identity.strip():
        profile["code_signing_identity"] = requested_code_signing_identity.strip()
    else:
        profile.setdefault("code_signing_identity", None)
    profile["platform"] = str(profile.get("platform") or _current_platform_name())
    if signer_backend_id:
        profile["signer_backend"] = signer_backend_id
    else:
        profile.setdefault("signer_backend", SoftwareLocalSignerBackend.backend_id)

    profile_credentials, credential_storage_backend = _load_requester_app_credentials(
        config_path,
        profile_id=profile_id,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    if rotate_keypair:
        profile_credentials.pop("private_key", None)
        profile_credentials.pop("private_key_representation", None)
        profile.pop("public_key", None)
        profile.pop("key_algorithm", None)
        profile.pop("key_id", None)
        profile.pop("key_fingerprint", None)
    required_algorithm_mismatch = bool(
        required_key_algorithm and profile.get("key_algorithm") != required_key_algorithm
    )
    if required_algorithm_mismatch:
        profile = _clear_requester_app_pairing_state(profile)
    if ensure_keys and not (
        _identity_private_material_present(
            profile_credentials,
            key_algorithm=required_key_algorithm or profile.get("key_algorithm"),
        )
        and str(profile.get("public_key") or "").strip()
        and not required_algorithm_mismatch
    ):
        keypair_factory = identity_keypair_factory or generate_local_identity_keypair
        keypair = keypair_factory()
        _apply_identity_keypair_credentials(profile_credentials, keypair)
        profile.update(
            {
                "public_key": keypair["public_key"],
                "key_algorithm": keypair["algorithm"],
                "key_id": keypair["key_id"],
                "key_fingerprint": keypair["key_fingerprint"],
                "credential_storage_backend": credential_storage_backend,
            }
        )
        _save_requester_app_credentials(
            config_path,
            profile_id=profile_id,
            credentials=profile_credentials,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    elif ensure_keys:
        profile["credential_storage_backend"] = credential_storage_backend
    else:
        profile.setdefault("credential_storage_backend", credential_storage_backend)

    profiles[profile_id] = profile
    _save_requester_app_profiles(config_path, profiles)
    return profile


def _update_requester_app_profile(
    config_path: Path,
    profile: dict[str, Any],
) -> None:
    profile_id = _slugify_client_id(str(profile.get("client_profile_id") or ""))
    if not profile_id:
        raise RuntimeError("requester app profile is missing client_profile_id")
    profiles = _load_requester_app_profiles(config_path)
    profiles[profile_id] = dict(profile)
    _save_requester_app_profiles(config_path, profiles)


def _clear_requester_app_pairing_state(profile: dict[str, Any]) -> dict[str, Any]:
    updated = dict(profile)
    for key in (
        "requester_app_principal_id",
        "requester_app_id",
        "enrollment_request_id",
    ):
        updated.pop(key, None)
    updated["status"] = "unpaired"
    return updated


def _default_browser_launcher_path(native_host_name: str) -> Path:
    return Path.home() / ".skyline" / "browser-host" / f"{native_host_name}.sh"


def _load_browser_host_metadata() -> dict[str, Any]:
    return load_local_metadata(DEFAULT_BROWSER_HOST_CONFIG_PATH)


def _save_browser_host_metadata(metadata: dict[str, Any]) -> None:
    save_local_metadata(DEFAULT_BROWSER_HOST_CONFIG_PATH, metadata)


def _browser_host_socket_path_for_config(config_path: Path) -> str:
    return str(_local_requester_service_socket_path(config_path))


def _install_or_refresh_browser_host(
    *,
    config_path: Path,
) -> dict[str, Any]:
    browser_metadata = _load_browser_host_metadata()
    browser_name = (
        str(browser_metadata.get("browser_name") or "").strip()
        or DEFAULT_BROWSER_HOST_BROWSER_NAME
    )
    profile_label = (
        str(browser_metadata.get("profile_label") or "").strip()
        or DEFAULT_BROWSER_HOST_PROFILE_LABEL
    )
    config = install_native_host_manifest(
        config_path=DEFAULT_BROWSER_HOST_CONFIG_PATH,
        browser=str(browser_metadata.get("browser") or "").strip() or "chrome",
        extension_id=(
            str(browser_metadata.get("extension_id") or "").strip() or None
        ),
        extension_channel=(
            str(browser_metadata.get("extension_channel") or "").strip()
            or DEFAULT_BROWSER_HOST_EXTENSION_CHANNEL
        ),
        native_host_name=(
            str(browser_metadata.get("native_host_name") or "").strip()
            or DEFAULT_BROWSER_HOST_NATIVE_HOST_NAME
        ),
        requester_config_path=str(config_path),
        requester_socket_path=_browser_host_socket_path_for_config(config_path),
    )
    config["browser_name"] = browser_name
    config["profile_label"] = profile_label
    _save_browser_host_metadata(config)
    return config


def _maybe_install_or_skip_browser_host(
    *,
    payload: dict[str, Any],
    config_path: Path,
    success_context: str,
) -> None:
    if not chrome_extension_browser_companion_enabled():
        return
    try:
        _install_or_refresh_browser_host(config_path=config_path)
        payload["browser_companion_status"] = "installed"
    except Exception as error:
        payload["browser_companion_status"] = "install_failed"
        payload["browser_companion_message"] = (
            f"{success_context}, but Skyline could not refresh the browser "
            "companion native host manifest automatically."
        )
        payload["browser_companion_error"] = str(error)


def _remove_path_if_present(path: Path | None) -> bool:
    if path is None:
        return False
    expanded = path.expanduser()
    if not expanded.exists() and not expanded.is_symlink():
        return False
    if expanded.is_dir() and not expanded.is_symlink():
        shutil.rmtree(expanded)
        return True
    expanded.unlink()
    return True


def _prune_parent_dirs(path: Path, *, stop_at: Path) -> None:
    current = path.expanduser().parent
    stop = stop_at.expanduser()
    while True:
        if current == stop:
            try:
                current.rmdir()
            except OSError:
                pass
            return
        if current == current.parent:
            return
        try:
            current.rmdir()
        except OSError:
            return
        current = current.parent


def _clear_requester_app_profile_credentials(
    config_path: Path,
    *,
    profile: dict[str, Any],
    bootstrap_secret_file: str | None,
) -> None:
    profile_id = _slugify_client_id(str(profile.get("client_profile_id") or ""))
    if not profile_id:
        raise RuntimeError("requester app profile is missing client_profile_id")
    credential_storage_backend = str(profile.get("credential_storage_backend") or "").strip()
    if not credential_storage_backend:
        credential_storage_backend = _resolve_local_credential_backend(
            config_path=_requester_app_config_path(config_path, profile_id),
            credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    _clear_local_credentials(
        config_path=_requester_app_config_path(config_path, profile_id),
        credential_kind=REQUESTER_APP_CREDENTIAL_KIND,
        credential_storage_backend=credential_storage_backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )


def _clear_machine_seed_local_state(
    config_path: Path,
    *,
    bootstrap_secret_file: str | None,
) -> bool:
    metadata = _load_metadata(config_path)
    cleared_any = False
    credential_storage_backend = str(metadata.get("credential_storage_backend") or "").strip()
    if not credential_storage_backend and config_path.exists():
        credential_storage_backend = _resolve_local_credential_backend(
            config_path=config_path,
            credential_kind=MACHINE_SEED_CREDENTIAL_KIND,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if credential_storage_backend:
        _clear_local_credentials(
            config_path=config_path,
            credential_kind=MACHINE_SEED_CREDENTIAL_KIND,
            credential_storage_backend=credential_storage_backend,
            bootstrap_secret_file=bootstrap_secret_file,
        )
        cleared_any = True
    if config_path.exists():
        config_path.unlink()
        cleared_any = True
    state_dir = _local_requester_state_dir(config_path)
    if state_dir.exists():
        shutil.rmtree(state_dir)
        cleared_any = True
    return cleared_any


def _clear_delivery_helper_local_state(
    *,
    bootstrap_secret_file: str | None,
) -> bool:
    config_path = DEFAULT_DELIVERY_HELPER_CONFIG_PATH
    if not config_path.exists():
        return False
    metadata = load_local_metadata(config_path)
    credential_storage_backend = str(metadata.get("credential_storage_backend") or "").strip()
    if not credential_storage_backend:
        credential_storage_backend = _resolve_local_credential_backend(
            config_path=config_path,
            credential_kind=DELIVERY_HELPER_COMPONENT_KIND,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if credential_storage_backend:
        _clear_local_credentials(
            config_path=config_path,
            credential_kind=DELIVERY_HELPER_COMPONENT_KIND,
            credential_storage_backend=credential_storage_backend,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    config_path.unlink()
    return True


def _clear_browser_host_local_state(
    *,
    bootstrap_secret_file: str | None,
) -> bool:
    config_path = DEFAULT_BROWSER_HOST_CONFIG_PATH
    if not config_path.exists():
        return False
    metadata = load_local_metadata(config_path)
    credential_storage_backend = str(metadata.get("credential_storage_backend") or "").strip()
    if not credential_storage_backend:
        credential_storage_backend = _resolve_local_credential_backend(
            config_path=config_path,
            credential_kind=DELIVERY_BROWSER_HOST_COMPONENT_KIND,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if credential_storage_backend:
        _clear_local_credentials(
            config_path=config_path,
            credential_kind=DELIVERY_BROWSER_HOST_COMPONENT_KIND,
            credential_storage_backend=credential_storage_backend,
            bootstrap_secret_file=bootstrap_secret_file,
        )
    removed_any = False
    manifest_path_text = str(metadata.get("native_host_manifest_path") or "").strip()
    launcher_path_text = str(metadata.get("native_host_launcher_path") or "").strip()
    native_host_name = str(metadata.get("native_host_name") or "").strip() or "com.skyline.browser_host"
    if manifest_path_text:
        manifest_path = Path(manifest_path_text).expanduser()
        removed_any = _remove_path_if_present(manifest_path) or removed_any
        _prune_parent_dirs(manifest_path, stop_at=Path.home())
    launcher_path = (
        Path(launcher_path_text).expanduser()
        if launcher_path_text
        else _default_browser_launcher_path(native_host_name)
    )
    removed_any = _remove_path_if_present(launcher_path) or removed_any
    _prune_parent_dirs(launcher_path, stop_at=Path.home() / ".skyline")
    config_path.unlink()
    return True


def _requester_shared_state_exists(config_path: Path) -> bool:
    return bool(
        config_path.exists()
        or _local_requester_state_dir(config_path).exists()
        or DEFAULT_DELIVERY_HELPER_CONFIG_PATH.exists()
        or DEFAULT_BROWSER_HOST_CONFIG_PATH.exists()
    )


def _local_requester_service_matches_pid(config_path: Path, pid: int) -> bool:
    if pid <= 1:
        return False
    _parent_pid, command, args_text = _process_snapshot(pid)
    command_text = str(command or "").strip()
    if not _is_skyline_process(command_text, args_text):
        return False
    tokens = _tokenize_process_args(args_text)
    if "serve" not in tokens:
        return False
    if not any(marker in " ".join(tokens) for marker in LOCAL_REQUESTER_MODULE_MARKERS):
        return False
    resolved_config_path = str(config_path.expanduser())
    if "--config-path" not in tokens:
        return False
    config_index = tokens.index("--config-path")
    if config_index + 1 >= len(tokens):
        return False
    return str(Path(tokens[config_index + 1]).expanduser()) == resolved_config_path


def _stop_local_requester_service(config_path: Path) -> bool:
    service_state = _read_local_requester_service_state(config_path)
    raw_pid = service_state.get("pid")
    if not isinstance(raw_pid, int) or raw_pid <= 1:
        return False
    if not _local_requester_service_matches_pid(config_path, raw_pid):
        return False
    try:
        os.kill(raw_pid, signal.SIGTERM)
    except ProcessLookupError:
        return False
    return True


def _profile_id_for_local_reset(
    *,
    args: argparse.Namespace,
    profiles: dict[str, dict[str, Any]],
) -> str | None:
    explicit_requester_args = _explicit_requester_app_args(args)
    explicit_candidate_profile_id = _slugify_client_id(
        str(
            explicit_requester_args["client_profile"]
            or explicit_requester_args["client_app_identifier"]
            or (
                Path(explicit_requester_args["client_executable_path"]).name
                if explicit_requester_args["client_executable_path"]
                else ""
            )
            or explicit_requester_args["client_display_name"]
            or ""
        )
    )
    if explicit_candidate_profile_id:
        if explicit_candidate_profile_id not in profiles:
            raise RuntimeError(
                "that requester profile is not currently paired on this machine; "
                "normally you should run `skyline erase-connection` from the requester "
                "you want to erase, and only use --client-profile for rare manual cleanup."
            )
        return explicit_candidate_profile_id
    resolved_args = _resolved_requester_app_args(args)
    candidate_profile_id = _slugify_client_id(
        str(
            resolved_args["client_profile"]
            or resolved_args["client_app_identifier"]
            or (
                Path(resolved_args["client_executable_path"]).name
                if resolved_args["client_executable_path"]
                else ""
            )
            or resolved_args["client_display_name"]
            or ""
        )
    )
    if candidate_profile_id and candidate_profile_id in profiles:
        return candidate_profile_id
    if len(profiles) == 1:
        return next(iter(profiles))
    if len(profiles) > 1:
        raise RuntimeError(
            "multiple requester profiles are paired on this machine and Skyline could "
            "not tell which requester asked to erase itself; rerun this command from the "
            "requester you want to erase, or use --client-profile for rare manual cleanup."
        )
    return None


def cmd_erase_connection(args: argparse.Namespace) -> int:
    config_path = _resolved_config_path(args.config_path)
    bootstrap_secret_file = getattr(args, "bootstrap_secret_file", None)
    profiles = _load_requester_app_profiles(config_path)
    profile_id = _profile_id_for_local_reset(args=args, profiles=profiles)
    removed_profile_id: str | None = None
    if profile_id is not None:
        _clear_requester_app_profile_credentials(
            config_path,
            profile=profiles[profile_id],
            bootstrap_secret_file=bootstrap_secret_file,
        )
        _remove_requester_app_profile(
            config_path,
            profile_id=profile_id,
        )
        profile_dir = _requester_app_config_path(config_path, profile_id).parent
        try:
            profile_dir.rmdir()
        except OSError:
            pass
        removed_profile_id = profile_id
    remaining_profiles = _load_requester_app_profiles(config_path)
    shared_requester_state_cleared = False
    delivery_helper_cleared = False
    browser_helper_cleared = False
    local_requester_service_stopped = False
    if not remaining_profiles and _requester_shared_state_exists(config_path):
        local_requester_service_stopped = _stop_local_requester_service(config_path)
        shared_requester_state_cleared = _clear_machine_seed_local_state(
            config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
        delivery_helper_cleared = _clear_delivery_helper_local_state(
            bootstrap_secret_file=bootstrap_secret_file,
        )
        browser_helper_cleared = _clear_browser_host_local_state(
            bootstrap_secret_file=bootstrap_secret_file,
        )
    if removed_profile_id is None and not shared_requester_state_cleared:
        return _print_json(
            {
                "status": "not_connected",
                "message": "No local requester connection state was found to erase.",
                "config_path": str(config_path),
            }
        )
    return _print_json(
        {
            "status": "erased",
            "message": (
                "The selected requester was erased locally. "
                "Vault-side requester records and audit history were left intact."
                if removed_profile_id is not None
                else "Shared requester-side state was erased locally."
            ),
            "config_path": str(config_path),
            "client_profile_id": removed_profile_id,
            "remaining_requester_profiles": sorted(remaining_profiles),
            "shared_requester_state_cleared": shared_requester_state_cleared,
            "delivery_helper_cleared": delivery_helper_cleared,
            "browser_helper_cleared": browser_helper_cleared,
            "local_requester_service_stopped": local_requester_service_stopped,
        }
    )


def _resolved_caller_guard(
    request: Request,
    *,
    requester_profile_id: str,
) -> dict[str, Any] | None:
    peer = _request_scope_local_peer(request)
    return _derive_caller_guard_from_peer(
        peer=peer,
        requester_profile_id=requester_profile_id,
    )


def _core_client_for_requester_app(
    context: LocalRequesterContext,
    *,
    profile: dict[str, Any],
    forwarded_headers: dict[str, str],
) -> SkylineCoreHTTPClient:
    seeded_machine_id = context.seeded_machine_id
    config = RequesterCoreClientConfig(
        core_base_url=context.base_url,
        access_token="",
        default_session_id=_requester_default_session_id(
            seeded_machine_id=seeded_machine_id,
            profile=profile,
        ),
        timeout_seconds=DEFAULT_CORE_TIMEOUT_SECONDS,
    )
    tenant_headers = _hosted_tenant_headers_from_metadata(
        _load_machine_metadata_from_context(context)
    )
    return SkylineCoreHTTPClient(
        config,
        access_token_resolver=context.ensure_access_token,
        extra_headers={**tenant_headers, **forwarded_headers},
    )


def _requester_default_session_id(
    *,
    seeded_machine_id: str,
    profile: dict[str, Any],
) -> str:
    profile_id = _slugify_client_id(str(profile.get("client_profile_id") or ""))
    base = f"requester_{seeded_machine_id}_{profile_id}"
    requester_app_id = str(profile.get("requester_app_id") or "").strip()
    if not requester_app_id:
        return base
    app_hash = hashlib.sha256(requester_app_id.encode("utf-8")).hexdigest()[:12]
    return f"{base}_{app_hash}"


def _print_json(payload: Any) -> int:
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _connect_status_payload(
    status: str,
    *,
    message: str,
    **extra: Any,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "status": status,
        "message": message,
    }
    payload.update(extra)
    return payload


def _read_local_requester_service_state(config_path: Path) -> dict[str, Any]:
    state_path = _local_requester_service_state_path(config_path)
    if not state_path.exists():
        return {}
    try:
        payload = json.loads(state_path.read_text())
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _local_requester_service_healthcheck(config_path: Path) -> bool:
    service_state = _read_local_requester_service_state(config_path)
    socket_path = str(service_state.get("socket_path") or "").strip()
    if not socket_path:
        return False
    try:
        transport = httpx.HTTPTransport(uds=socket_path)
        with httpx.Client(
            transport=transport,
            base_url="http://local-requester",
            timeout=2.0,
        ) as client:
            response = client.get("/healthz")
    except Exception:
        return False
    return response.status_code == 200


def _classify_connect_error(text: str) -> tuple[str, str]:
    normalized = text.strip().lower()
    if not normalized:
        return (
            "rejected",
            "Skyline connect failed before local requester services were ready.",
        )
    if (
        "not seeded yet" in normalized
        or "not set up yet" in normalized
        or "run `skyline setup`" in normalized
        or "run `skyline setup`" in normalized
    ):
        return (
            "seed_required",
            "This machine has not been set up yet. Run `skyline setup`, then retry.",
        )
    if "consumed" in normalized:
        return (
            "token_consumed",
            "That bootstrap token has already been consumed and cannot create another pending requester.",
        )
    if "revoked" in normalized:
        return (
            "token_revoked",
            "That bootstrap token was revoked and can no longer create pending requesters.",
        )
    if "source_scope_mismatch" in normalized:
        return (
            "source_scope_mismatch",
            "This machine did not match the allowed bootstrap source scope for that token.",
        )
    if (
        "seeded machine identity is incomplete" in normalized
        or "machine seed session could not be refreshed" in normalized
    ):
        return (
            "seed_required",
            "This machine setup is no longer usable. Create a fresh setup link, run `skyline setup`, then configure the agent with local STDIO MCP.",
        )
    if "rejected" in normalized:
        return (
            "rejected",
            "The requester bootstrap was rejected on the authorizer device.",
        )
    if "missing" in normalized and "profile" in normalized:
        return (
            "missing_required_app_profile_metadata",
            "Skyline could not infer a stable app or harness identity. For terminal-hosted agents, configure `skyline bridge serve` as the local STDIO MCP bridge.",
        )
    if "multiple requester profiles" in normalized:
        return (
            "missing_required_app_profile_metadata",
            "Skyline could not safely choose among multiple local requester profiles. For terminal-hosted agents, configure `skyline bridge serve` as the local STDIO MCP bridge.",
        )
    return (
        "rejected",
        text.strip(),
    )


def _local_requester_service_command_args(args: argparse.Namespace) -> list[str]:
    command = [
        sys.executable,
        "-m",
        LOCAL_REQUESTER_MODULE_NAME,
        "--config-path",
        str(_resolved_config_path(args.config_path)),
    ]
    bootstrap_secret_file = getattr(args, "bootstrap_secret_file", None)
    if bootstrap_secret_file:
        command.extend(["--bootstrap-secret-file", str(bootstrap_secret_file)])
    command.append("serve")
    if getattr(args, "api_socket_path", None):
        command.extend(["--api-socket-path", str(args.api_socket_path)])
    if getattr(args, "delivery_poll_interval", None) is not None:
        command.extend(["--delivery-poll-interval", str(args.delivery_poll_interval)])
    return command


def _spawn_local_requester_service_background(
    args: argparse.Namespace,
) -> tuple[subprocess.Popen[bytes], Path]:
    config_path = _resolved_config_path(args.config_path)
    state_dir = _local_requester_state_dir(config_path)
    ensure_owner_only_directory(state_dir)
    log_path = state_dir / "connect.log"
    log_fd = os.open(log_path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
    log_file = os.fdopen(log_fd, "ab")
    os.chmod(log_path, stat.S_IRUSR | stat.S_IWUSR)
    process = subprocess.Popen(
        _local_requester_service_command_args(args),
        stdout=log_file,
        stderr=log_file,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    log_file.close()
    return process, log_path


def _ensure_local_requester_service_started(
    args: argparse.Namespace,
    *,
    allow_unseeded: bool = False,
) -> dict[str, Any]:
    config_path = _resolved_config_path(args.config_path)
    metadata = _load_metadata(config_path)
    if _local_requester_service_healthcheck(config_path):
        seeded_machine_id = str(metadata.get("seeded_machine_id") or "").strip()
        if not seeded_machine_id and not allow_unseeded:
            return _connect_status_payload(
                "seed_required",
                message=(
                    "This machine has not been set up yet. Create a setup link from the "
                    "iPhone Agents tab, then run the setup command."
                ),
            )
        return _connect_status_payload(
            "local_service_ready",
            message="Local requester services are already running.",
        )

    seeded_machine_id = str(metadata.get("seeded_machine_id") or "").strip()
    if not seeded_machine_id and not allow_unseeded:
        return _connect_status_payload(
            "seed_required",
            message=(
                "This machine has not been set up yet. "
                "Create a setup link from the iPhone Requesters tab, run the setup command, "
                "then configure the agent with local STDIO MCP."
            ),
        )
    process, log_path = _spawn_local_requester_service_background(args)
    deadline = time.time() + float(getattr(args, "startup_timeout_seconds", 8.0) or 8.0)
    while time.time() < deadline:
        if _local_requester_service_healthcheck(config_path):
            return _connect_status_payload(
                "local_service_ready",
                message="Local requester services are running and ready to pair this requester.",
            )
        if process.poll() is not None:
            break
        time.sleep(0.25)

    log_text = ""
    if log_path.exists():
        try:
            log_text = log_path.read_text()[-4000:]
        except Exception:
            log_text = ""
    status, message = _classify_connect_error(log_text)
    return _connect_status_payload(status, message=message, log_path=str(log_path))


def create_local_requester_service_app(
    *,
    config_path: Path,
    context: LocalRequesterContext,
) -> FastAPI:
    app = FastAPI(title="Skyline Local Requester Service")
    browser_session_lock = threading.RLock()
    pending_browser_hello_challenges: dict[str, dict[str, Any]] = {}
    active_browser_sessions: dict[str, dict[str, Any]] = {}

    @app.exception_handler(SkylineCoreAPIError)
    async def handle_core_api_error(
        _request: Request,
        error: SkylineCoreAPIError,
    ) -> JSONResponse:
        return JSONResponse(status_code=error.status_code, content={"error": error.message})

    @app.exception_handler(RuntimeError)
    async def handle_local_service_error(
        _request: Request,
        error: RuntimeError,
    ) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": str(error)})

    def _seed_required_response() -> JSONResponse:
        return JSONResponse(
            status_code=409,
            content=_connect_status_payload(
                "seed_required",
                message=(
                    "This machine has not been set up yet. Create a setup link, "
                    "run `skyline setup`, then retry."
                ),
            ),
        )

    def _connect_required_response(
        *,
        client_profile_id: str,
        reason: str,
        request_id: str | None = None,
    ) -> JSONResponse:
        if reason == LOCAL_REQUESTER_CALLER_REASON_UNVERIFIABLE:
            message = (
                "Skyline could not verify enough local caller facts for this requester. "
                "For terminal-hosted agents, use the local bridge with "
                "`skyline bridge serve` so Skyline can bind approval to the agent "
                "instead of the terminal shell."
            )
        else:
            message = (
                "This local caller no longer matches the paired requester fingerprint. "
                "Use the local STDIO MCP bridge so Skyline can register the changed "
                "requester identity under this approved machine."
            )
        return JSONResponse(
            status_code=409,
            content=_request_connect_required_payload(
                client_profile_id=client_profile_id,
                message=message,
                reason=reason,
                request_id=request_id,
            ),
        )

    def _browser_companion_error_response(message: str, *, status_code: int = 403) -> JSONResponse:
        return JSONResponse(
            status_code=status_code,
            content={
                "status": "browser_companion_unavailable",
                "message": message,
            },
        )

    def _prune_browser_hello_challenges(now_epoch_ms: int) -> None:
        expired_ids = [
            challenge_id
            for challenge_id, challenge in pending_browser_hello_challenges.items()
            if int(challenge.get("expires_at_epoch_ms") or 0) <= now_epoch_ms
        ]
        for challenge_id in expired_ids:
            pending_browser_hello_challenges.pop(challenge_id, None)

    def _browser_session_token_from_request(request: Request) -> str | None:
        return str(request.headers.get(DEFAULT_BROWSER_SESSION_HEADER) or "").strip() or None

    def _prepare_browser_companion(
        *,
        request: Request,
        browser_channel_id: str,
        extension_id: str | None = None,
        extension_channel: str | None = None,
        native_host_name: str | None = None,
        require_session: bool = True,
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any] | None] | JSONResponse:
        if not context.is_seeded():
            return _seed_required_response()
        peer = _request_scope_local_peer(request)
        browser_host_metadata = _load_browser_host_metadata()
        browser_guard, _browser_guard_reason = _configured_browser_companion_guard(
            peer=peer,
            browser_host_metadata=browser_host_metadata,
        )
        if browser_guard is None:
            return _browser_companion_error_response(
                "Skyline could not verify the configured local Chrome-family browser install for this native host."
            )
        expected_extension_id = str(browser_host_metadata.get("extension_id") or "").strip()
        expected_extension_channel = (
            str(browser_host_metadata.get("extension_channel") or "").strip()
            or DEFAULT_BROWSER_HOST_EXTENSION_CHANNEL
        )
        if extension_id is not None and expected_extension_id and extension_id != expected_extension_id:
            return _browser_companion_error_response(
                "This browser extension does not match the native host manifest installed for Skyline."
            )
        if (
            extension_channel is not None
            and expected_extension_channel
            and extension_channel != expected_extension_channel
        ):
            return _browser_companion_error_response(
                "This browser extension channel does not match the Skyline native host manifest."
            )
        active_session: dict[str, Any] | None = None
        if require_session:
            normalized_session_token = _browser_session_token_from_request(request)
            with browser_session_lock:
                active_session = active_browser_sessions.get(browser_channel_id)
            if (
                active_session is None
                or not normalized_session_token
                or normalized_session_token != str(active_session.get("session_token") or "").strip()
            ):
                return _browser_companion_error_response(
                    "This browser companion session is not ready yet. Refresh the extension and retry."
                )
            current_install_identity = _browser_install_identity(
                browser_guard=browser_guard,
            )
            if current_install_identity != str(active_session.get("browser_install_identity") or "").strip():
                with browser_session_lock:
                    active_browser_sessions.pop(browser_channel_id, None)
                return _browser_companion_error_response(
                    "This browser companion session no longer matches the active local browser install. Refresh the extension and retry."
                )
        return browser_host_metadata, browser_guard, active_session

    def _machine_seed_core_request(
        *,
        method: str,
        path: str,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return _request_core_json_with_optional_headers(
            method=method,
            base_url=context.base_url,
            path=path,
            access_token=context.ensure_access_token(),
            extra_headers=_hosted_tenant_headers_from_metadata(
                _load_machine_metadata_from_context(context)
            ),
            json_body=json_body,
        )

    def _runner_core_request(
        *,
        profile_id: str,
        requester_app_principal_id: str,
        method: str,
        path: str,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        forwarded_headers = context.requester_forward_headers(
            profile_id=profile_id,
            requester_app_principal_id=requester_app_principal_id,
            core_method=method,
            core_path=path,
            core_params=None,
            core_json_body=json_body,
        )
        return _request_core_json_with_optional_headers(
            method=method,
            base_url=context.base_url,
            path=path,
            access_token=context.ensure_access_token(),
            extra_headers={
                **_hosted_tenant_headers_from_metadata(
                    _load_machine_metadata_from_context(context)
                ),
                **forwarded_headers,
            },
            json_body=json_body,
        )

    def _runner_key_holders(
        *,
        profile_id: str,
        requester_app_principal_id: str,
    ) -> list[RecipientKeyReference]:
        payload = _runner_core_request(
            profile_id=profile_id,
            requester_app_principal_id=requester_app_principal_id,
            method="GET",
            path="/v1/vault/secret-key-holders",
        )
        raw_holders = payload.get("key_holders")
        if not isinstance(raw_holders, list):
            raise RuntimeError("core returned an invalid secret key-holder payload")
        holders: list[RecipientKeyReference] = []
        for holder in raw_holders:
            if not isinstance(holder, dict):
                continue
            holders.append(
                RecipientKeyReference(
                    key_holder_id=str(holder["key_holder_id"]),
                    public_key=str(holder["public_key"]),
                    key_id=str(holder["key_id"]),
                    key_version=int(holder["key_version"]),
                    status=str(holder.get("status") or "active"),
                    key_algorithm=str(holder.get("key_algorithm") or DELIVERY_KEY_ALGORITHM),
                )
            )
        return _enforce_trusted_secret_key_holders_for_write(config_path, holders)

    def _reserve_runner_item_id(
        *,
        profile_id: str,
        requester_app_principal_id: str,
    ) -> str:
        payload = _runner_core_request(
            profile_id=profile_id,
            requester_app_principal_id=requester_app_principal_id,
            method="POST",
            path="/v1/vault/protected-items/new-id",
        )
        item_id = str(payload.get("item_id") or "").strip()
        if not item_id:
            raise RuntimeError("core returned an invalid protected item id")
        return item_id

    def _profile_payload_from_principal(
        *,
        existing_profile: dict[str, Any],
        principal: dict[str, Any],
        body: RequesterAppEnrollmentRequest,
        caller_guard: dict[str, Any] | None,
    ) -> dict[str, Any]:
        profile = dict(existing_profile)
        profile.update(
            {
                "client_profile_id": body.client_profile_id,
                "display_name": principal.get("display_name") or body.requested_display_name,
                "app_identifier": principal.get("app_identifier") or body.requested_app_identifier,
                "platform": principal.get("platform") or body.requested_platform,
                "executable_path": principal.get("executable_path") or body.requested_executable_path,
                "code_signing_identity": principal.get("code_signing_identity")
                or body.requested_code_signing_identity,
                "requester_app_principal_id": principal.get("requester_app_principal_id"),
                "requester_app_id": principal.get("requester_app_id") or profile.get("requester_app_id"),
                "status": "active",
            }
        )
        if caller_guard is not None:
            profile["caller_guard"] = dict(caller_guard)
        profile.pop("enrollment_request_id", None)
        return profile

    def _prepare_core_forward_client(
        request: Request,
        body: LocalRequesterForwardRequest,
    ) -> tuple[SkylineCoreHTTPClient, dict[str, Any]] | JSONResponse:
        if not context.is_seeded():
            return _seed_required_response()
        normalized_profile_id = _slugify_client_id(body.client_profile_id)
        if not normalized_profile_id:
            raise HTTPException(
                status_code=400,
                detail="client_profile_id is required for local requester forwarding",
            )
        profile = dict(
            _load_requester_app_profiles(config_path).get(normalized_profile_id)
            or _default_profile_metadata(normalized_profile_id)
        )
        caller_guard = _resolved_caller_guard(
            request,
            requester_profile_id=normalized_profile_id,
        )
        if caller_guard is None:
            return _connect_required_response(
                client_profile_id=normalized_profile_id,
                reason=LOCAL_REQUESTER_CALLER_REASON_UNVERIFIABLE,
                request_id=str(profile.get("enrollment_request_id") or "").strip() or None,
            )
        stored_guard = profile.get("caller_guard")
        if not _caller_guard_matches(
            stored_guard if isinstance(stored_guard, dict) else None,
            caller_guard,
        ):
            return _connect_required_response(
                client_profile_id=normalized_profile_id,
                reason=LOCAL_REQUESTER_CALLER_REASON_MISMATCH,
                request_id=str(profile.get("enrollment_request_id") or "").strip() or None,
            )
        forwarded_headers: dict[str, str] = {}
        if body.require_pairing:
            principal_id = str(profile.get("requester_app_principal_id") or "").strip()
            if not principal_id:
                return _connect_required_response(
                    client_profile_id=normalized_profile_id,
                    reason=LOCAL_REQUESTER_CALLER_REASON_MISMATCH,
                    request_id=str(profile.get("enrollment_request_id") or "").strip() or None,
                )
            forwarded_headers = context.requester_forward_headers(
                profile_id=normalized_profile_id,
                requester_app_principal_id=principal_id,
                core_method=body.core_method,
                core_path=body.core_path,
                core_params=body.core_params,
                core_json_body=body.core_json_body,
            )
        return _core_client_for_requester_app(
            context,
            profile=profile,
            forwarded_headers=forwarded_headers,
        ), profile

    @app.get("/healthz")
    async def health() -> dict[str, Any]:
        return {"ok": True, "service": "skyline-requester-service"}

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/setup")
    async def setup_machine(body: RuntimeMachineSetupRequest) -> dict[str, Any]:
        metadata = context.setup_machine(
            core_base_url=body.core_base_url,
            hosted_tenant_id=body.hosted_tenant_id,
            setup_code=body.setup_code,
            machine_name=body.machine_name,
            requested_note=body.requester_note,
            requested_profile=body.requester_profile,
            requested_tags=list(body.requester_tags),
            requested_metadata=dict(body.requested_metadata),
            approval_timeout_seconds=body.approval_timeout_seconds,
        )
        return _connect_status_payload(
            "machine_setup_completed",
            message=(
                "This machine is set up. Next, configure your agent as a local "
                "STDIO MCP server with command `skyline` and arguments `bridge`, "
                "`serve`."
            ),
            config_path=str(config_path),
            credential_storage_backend=metadata.get("credential_storage_backend"),
            bootstrap_token_id=metadata.get("bootstrap_token_id"),
            machine_display_name=metadata.get("machine_display_name"),
            macos_secure_enclave=metadata.get(MACOS_SECURE_ENCLAVE_METADATA_KEY),
            mcp_server=_stdio_mcp_server_setup_payload(),
        )

    @app.post(
        f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/requester-profiles/ensure",
        response_model=None,
    )
    async def ensure_requester_app_profile(
        request: Request,
        body: RequesterAppEnrollmentRequest,
    ) -> Any:
        if not context.is_seeded():
            return _seed_required_response()
        caller_guard = _resolved_caller_guard(
            request,
            requester_profile_id=body.client_profile_id,
        )
        if caller_guard is None:
            return _request_connect_required_payload(
                client_profile_id=body.client_profile_id,
                message=(
                    "Skyline could not verify enough local caller facts for this requester. "
                    "For terminal-hosted agents, use the local bridge with "
                    "`skyline bridge serve` so Skyline can bind approval to the agent "
                    "instead of the terminal shell."
                ),
                reason=LOCAL_REQUESTER_CALLER_REASON_UNVERIFIABLE,
            )
        existing_profile = dict(
            _load_requester_app_profiles(config_path).get(body.client_profile_id)
            or _default_profile_metadata(body.client_profile_id)
        )
        stored_guard = existing_profile.get("caller_guard")
        guard_changed = bool(stored_guard) and not _caller_guard_matches(
            stored_guard if isinstance(stored_guard, dict) else None,
            caller_guard,
        )
        profile = context.ensure_requester_profile(
            profile_id=body.client_profile_id,
            requested_display_name=body.requested_display_name,
            requested_app_identifier=body.requested_app_identifier,
            requested_executable_path=body.requested_executable_path,
            requested_code_signing_identity=body.requested_code_signing_identity,
            caller_guard=caller_guard,
            rotate_keypair=guard_changed,
            preserve_pairing_state=not guard_changed,
        )
        effective_requested_metadata = dict(body.requested_metadata)
        if isinstance(profile.get(MACOS_SECURE_ENCLAVE_METADATA_KEY), dict):
            effective_requested_metadata[MACOS_SECURE_ENCLAVE_METADATA_KEY] = dict(
                profile[MACOS_SECURE_ENCLAVE_METADATA_KEY]
            )
        payload = _request_core_json_with_optional_headers(
            method="POST",
            base_url=context.base_url,
            path="/v1/machine-seed/requester-apps/connect",
            access_token=context.ensure_access_token(),
            extra_headers=_hosted_tenant_headers_from_metadata(
                _load_machine_metadata_from_context(context)
            ),
            json_body={
                "client_profile_id": body.client_profile_id,
                "requested_display_name": body.requested_display_name,
                "requested_note": body.requested_note,
                "requested_profile": body.requested_profile,
                "requested_tags": list(body.requested_tags),
                "requested_metadata": effective_requested_metadata,
                "requested_app_identifier": body.requested_app_identifier,
                "requested_platform": body.requested_platform,
                "requested_executable_path": body.requested_executable_path,
                "requested_code_signing_identity": body.requested_code_signing_identity,
                "client_public_key": profile.get("public_key"),
                "key_algorithm": profile.get("key_algorithm"),
                "key_id": profile.get("key_id"),
            },
        )
        result = payload.get("result")
        if isinstance(result, dict):
            principal = result.get("requester_app_principal")
            if isinstance(principal, dict):
                _update_requester_app_profile(
                    config_path,
                    _profile_payload_from_principal(
                        existing_profile=profile,
                        principal=principal,
                        body=body,
                        caller_guard=caller_guard,
                    ),
                )
                return payload
        if isinstance(payload.get("request_id"), str) and payload["request_id"].strip():
            profile["enrollment_request_id"] = payload["request_id"].strip()
            if caller_guard is not None:
                profile["caller_guard"] = dict(caller_guard)
            _update_requester_app_profile(config_path, profile)
        return payload

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/core/request")
    async def forward_core_request(
        request: Request,
        body: LocalRequesterForwardRequest,
    ) -> Any:
        client_result = _prepare_core_forward_client(request, body)
        if isinstance(client_result, JSONResponse):
            return client_result
        core_client, _profile = client_result
        try:
            payload = await core_client._request_json(
                body.core_method,
                body.core_path,
                params=dict(body.core_params or {}) or None,
                json=dict(body.core_json_body) if body.core_json_body is not None else None,
            )
            return _resolve_local_password_health_handoff_payload(payload, context)
        except httpx.HTTPStatusError as error:
            try:
                payload = error.response.json()
            except Exception:
                payload = {"error": error.response.text.strip() or error.response.reason_phrase}
            return JSONResponse(
                status_code=error.response.status_code,
                content=payload if isinstance(payload, dict) else {"error": str(payload)},
            )

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-secret-runners/{{runner_token}}/store")
    async def browser_secret_runner_store(
        request: Request,
        runner_token: str,
        body: BrowserSecretRunnerLocalStoreRequest,
    ) -> Any:
        if not context.is_seeded():
            return _seed_required_response()
        peer = _request_scope_local_peer(request)
        current_uid = _current_local_uid()
        if (
            current_uid is not None
            and isinstance(peer.get("uid"), int)
            and peer.get("uid") != current_uid
        ):
            raise HTTPException(status_code=403, detail="runner writeback uid mismatch")
        token = _safe_browser_secret_runner_token(runner_token)
        state_dir = _local_requester_state_dir(config_path)
        writeback_path = _browser_secret_runner_writeback_path(state_dir, token)
        if not writeback_path.exists():
            raise HTTPException(status_code=404, detail="runner writeback grant was not found")
        try:
            writeback_record = json.loads(writeback_path.read_text(encoding="utf-8"))
        except Exception as error:
            raise HTTPException(status_code=400, detail="runner writeback grant was invalid") from error
        if not isinstance(writeback_record, dict):
            raise HTTPException(status_code=400, detail="runner writeback grant was invalid")
        expires_at_epoch_ms = int(writeback_record.get("expires_at_epoch_ms") or 0)
        if expires_at_epoch_ms and int(time.time() * 1000) > expires_at_epoch_ms:
            writeback_path.unlink(missing_ok=True)
            raise HTTPException(status_code=400, detail="runner writeback grant expired")
        expected_writeback_hash = str(writeback_record.get("writeback_token_sha256") or "").strip()
        actual_writeback_hash = hashlib.sha256(
            str(body.writeback_token or "").encode("utf-8")
        ).hexdigest()
        if not expected_writeback_hash or actual_writeback_hash != expected_writeback_hash:
            raise HTTPException(status_code=403, detail="runner writeback token mismatch")
        action = str(body.browser_action or "").strip()
        if action != str(writeback_record.get("browser_action") or "").strip():
            raise HTTPException(status_code=400, detail="runner writeback action mismatch")
        secret_value = str(body.secret_value or "")
        if not secret_value:
            raise HTTPException(status_code=400, detail="runner writeback secret is empty")
        profile_id = str(writeback_record.get("requester_app_profile_id") or "").strip()
        requester_app_principal_id = str(
            writeback_record.get("requester_app_principal_id") or ""
        ).strip()
        if not profile_id or not requester_app_principal_id:
            raise HTTPException(status_code=400, detail="runner writeback requester metadata is missing")
        kind = str(writeback_record.get("kind") or "").strip()
        title = str(writeback_record.get("title") or "").strip()
        field_name = str(writeback_record.get("field_name") or "").strip()
        safe_metadata = (
            dict(writeback_record.get("safe_metadata"))
            if isinstance(writeback_record.get("safe_metadata"), dict)
            else {}
        )
        try:
            demo_writeback_config = _demo_seed_writeback_config()
            _ensure_demo_seed_writeback_ready(demo_writeback_config)
        except RuntimeError as error:
            raise HTTPException(status_code=500, detail=str(error)) from error
        try:
            definition = VaultItemTypeRegistry.load_installed().get_type(kind)
            if definition is None:
                raise ValueError(f"unsupported protected item kind '{kind}'")
            definition.normalize_payload(safe_metadata, {field_name: secret_value})
        except ValueError as error:
            writeback_path.unlink(missing_ok=True)
            raise HTTPException(status_code=400, detail=str(error)) from error

        if action == "change_password":
            item_id = str(writeback_record.get("item_id") or "").strip()
            item_revision = int(writeback_record.get("item_revision") or 0) + 1
            if not item_id or item_revision <= 1:
                writeback_path.unlink(missing_ok=True)
                raise HTTPException(status_code=400, detail="runner writeback item metadata is missing")
        else:
            item_id = _reserve_runner_item_id(
                profile_id=profile_id,
                requester_app_principal_id=requester_app_principal_id,
            )
            item_revision = 1
        protected_fields = {field_name: secret_value}
        try:
            protected_packages, authority_fields = build_client_side_protected_write_payload(
                kind=kind,
                item_id=item_id,
                item_revision=item_revision,
                protected_fields=protected_fields,
                recipients=_runner_key_holders(
                    profile_id=profile_id,
                    requester_app_principal_id=requester_app_principal_id,
                ),
            )
        except ValueError as error:
            writeback_path.unlink(missing_ok=True)
            raise HTTPException(status_code=400, detail=str(error)) from error
        core_body = {
            "request_id": writeback_record.get("request_id"),
            "runner_token": token,
            "writeback_token": body.writeback_token,
            "browser_action": action,
            "item_id": item_id,
            "kind": kind,
            "title": title,
            "safe_metadata": with_client_side_presence_metadata(
                kind,
                safe_metadata,
                protected_fields,
            ),
            "field_name": field_name,
            "protected_packages": protected_packages,
            "authority_fields": authority_fields,
            "requester": {
                "session_id": writeback_record.get("session_id"),
                "workflow_id": writeback_record.get("workflow_id"),
                "request_mode": "tool",
                "request_class": (
                    "browser_secret_password"
                    if action in {"generate_password", "change_password"}
                    else "browser_secret_capture"
                ),
            },
        }
        payload = _runner_core_request(
            profile_id=profile_id,
            requester_app_principal_id=requester_app_principal_id,
            method="POST",
            path="/v1/vault/secret-actions/browser-runner-store",
            json_body=core_body,
        )
        try:
            demo_seed_writeback = _record_demo_seed_writeback(
                config=demo_writeback_config,
                item_id=item_id,
                kind=kind,
                title=title,
                safe_metadata=safe_metadata,
                protected_fields=protected_fields,
            )
        except (FileNotFoundError, RuntimeError, ValueError) as error:
            raise HTTPException(status_code=500, detail=str(error)) from error
        if isinstance(payload, dict) and demo_seed_writeback is not None:
            payload = {
                **payload,
                "demo_seed_writeback": demo_seed_writeback,
            }
        writeback_path.unlink(missing_ok=True)
        return payload

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-secret-runners/{{runner_token}}/secret")
    async def browser_secret_runner_secret(
        request: Request,
        runner_token: str,
        body: BrowserSecretRunnerLocalSecretRequest,
    ) -> Any:
        if not context.is_seeded():
            return _seed_required_response()
        peer = _request_scope_local_peer(request)
        current_uid = _current_local_uid()
        if (
            current_uid is not None
            and isinstance(peer.get("uid"), int)
            and peer.get("uid") != current_uid
        ):
            raise HTTPException(status_code=403, detail="runner secret uid mismatch")
        token = _safe_browser_secret_runner_token(runner_token)
        state_dir = _local_requester_state_dir(config_path)
        secret_path = _browser_secret_runner_secret_path(state_dir, token)
        if not secret_path.exists():
            raise HTTPException(status_code=404, detail="runner secret grant was not found")
        try:
            secret_record = json.loads(secret_path.read_text(encoding="utf-8"))
        except Exception as error:
            raise HTTPException(status_code=400, detail="runner secret grant was invalid") from error
        if not isinstance(secret_record, dict):
            raise HTTPException(status_code=400, detail="runner secret grant was invalid")
        expires_at_epoch_ms = int(secret_record.get("expires_at_epoch_ms") or 0)
        if expires_at_epoch_ms and int(time.time() * 1000) > expires_at_epoch_ms:
            secret_path.unlink(missing_ok=True)
            raise HTTPException(status_code=400, detail="runner secret grant expired")
        action = str(body.browser_action or "").strip()
        if action != str(secret_record.get("browser_action") or "").strip():
            raise HTTPException(status_code=400, detail="runner secret action mismatch")
        expected_fetch_hash = str(secret_record.get("secret_fetch_token_sha256") or "").strip()
        actual_fetch_hash = hashlib.sha256(
            str(body.secret_fetch_token or "").encode("utf-8")
        ).hexdigest()
        if not expected_fetch_hash or actual_fetch_hash != expected_fetch_hash:
            raise HTTPException(status_code=403, detail="runner secret fetch token mismatch")
        package = (
            dict(secret_record.get("secret_package"))
            if isinstance(secret_record.get("secret_package"), dict)
            else None
        )
        key_holder_id = str(
            secret_record.get("key_holder_id") or secret_record.get("issued_to_helper_id") or ""
        ).strip()
        key_version_raw = secret_record.get("key_version")
        key_version = int(key_version_raw) if key_version_raw is not None else None
        if package is None or not key_holder_id:
            raise HTTPException(status_code=400, detail="runner secret grant was incomplete")
        try:
            secret_value = context.decrypt_blind_secret_package(
                package=package,
                key_holder_id=key_holder_id,
                key_version=key_version,
            )
        except Exception as error:
            raise HTTPException(status_code=400, detail="runner secret decrypt failed") from error
        secret_path.unlink(missing_ok=True)
        return {
            "status": "ready",
            "browser_action": action,
            "secret_value": secret_value,
        }

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/hello")
    async def browser_companion_hello(
        request: Request,
        body: BrowserCompanionHelloRequest,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=body.browser_channel_id,
            extension_id=body.extension_id,
            extension_channel=body.extension_channel,
            native_host_name=body.native_host_name,
            require_session=False,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        browser_host_metadata, browser_guard, _active_session = prepared
        browser_name = str(body.browser_name or "").strip() or str(
            browser_host_metadata.get("browser_name") or DEFAULT_BROWSER_HOST_BROWSER_NAME
        )
        profile_label = str(body.profile_label or "").strip() or str(
            browser_host_metadata.get("profile_label") or DEFAULT_BROWSER_HOST_PROFILE_LABEL
        )
        resolved_native_host_name = (
            body.native_host_name
            or browser_host_metadata.get("native_host_name")
            or DEFAULT_BROWSER_HOST_NATIVE_HOST_NAME
        )
        browser_install_identity = _browser_install_identity(
            browser_guard=browser_guard,
        )
        challenge_id = f"browser_hello_{uuid.uuid4().hex}"
        challenge_nonce = uuid.uuid4().hex
        now_epoch_ms = int(time.time() * 1000)
        with browser_session_lock:
            _prune_browser_hello_challenges(now_epoch_ms)
            active_browser_sessions.pop(body.browser_channel_id, None)
            pending_browser_hello_challenges[challenge_id] = {
                "challenge_id": challenge_id,
                "challenge_nonce": challenge_nonce,
                "browser_channel_id": body.browser_channel_id,
                "browser_install_identity": browser_install_identity,
                "browser_name": browser_name,
                "profile_label": profile_label,
                "extension_id": body.extension_id,
                "extension_channel": body.extension_channel,
                "extension_version": body.extension_version,
                "native_host_name": resolved_native_host_name,
                "created_at_epoch_ms": now_epoch_ms,
                "expires_at_epoch_ms": now_epoch_ms + DEFAULT_BROWSER_HELLO_CHALLENGE_TTL_MS,
            }
        browser_host_metadata.update(
            {
                "browser_channel_id": body.browser_channel_id,
                "browser_install_identity": browser_install_identity,
                "browser_name": browser_name,
                "profile_label": profile_label,
                "extension_id": body.extension_id,
                "extension_channel": body.extension_channel,
                "extension_version": body.extension_version,
                "native_host_name": resolved_native_host_name,
                "browser_action_ready": False,
            }
        )
        _save_browser_host_metadata(browser_host_metadata)
        return {
            "status": "hello_challenge_required",
            "browser_channel_id": body.browser_channel_id,
            "browser_action_ready": False,
            "hello_challenge": {
                "challenge_id": challenge_id,
                "challenge_nonce": challenge_nonce,
                "expires_at_epoch_ms": now_epoch_ms + DEFAULT_BROWSER_HELLO_CHALLENGE_TTL_MS,
            },
        }

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/hello/confirm")
    async def browser_companion_hello_confirm(
        request: Request,
        body: BrowserCompanionHelloConfirmRequest,
    ) -> Any:
        browser_host_metadata = _load_browser_host_metadata()
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=body.browser_channel_id,
            extension_id=str(browser_host_metadata.get("extension_id") or "").strip() or None,
            extension_channel=(
                str(browser_host_metadata.get("extension_channel") or "").strip()
                or DEFAULT_BROWSER_HOST_EXTENSION_CHANNEL
            ),
            native_host_name=(
                str(browser_host_metadata.get("native_host_name") or "").strip()
                or DEFAULT_BROWSER_HOST_NATIVE_HOST_NAME
            ),
            require_session=False,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        browser_host_metadata, browser_guard, _active_session = prepared
        with browser_session_lock:
            _prune_browser_hello_challenges(int(time.time() * 1000))
            challenge = pending_browser_hello_challenges.pop(body.challenge_id, None)
        if challenge is None:
            return _browser_companion_error_response(
                "This browser hello challenge has expired. Refresh the extension and retry."
            )
        if (
            str(challenge.get("browser_channel_id") or "").strip() != body.browser_channel_id
            or str(challenge.get("challenge_nonce") or "").strip() != body.challenge_nonce
        ):
            return _browser_companion_error_response(
                "The browser hello confirmation did not match the expected one-time challenge."
            )
        browser_install_identity = _browser_install_identity(
            browser_guard=browser_guard,
        )
        if browser_install_identity != str(challenge.get("browser_install_identity") or "").strip():
            return _browser_companion_error_response(
                "This browser hello confirmation no longer matches the active local browser install."
            )
        payload = _machine_seed_core_request(
            method="POST",
            path="/v1/machine-seed/browser-companion/hello",
            json_body={
                "browser_channel_id": body.browser_channel_id,
                "browser_install_identity": browser_install_identity,
                "browser_name": challenge.get("browser_name"),
                "profile_label": challenge.get("profile_label"),
                "extension_id": challenge.get("extension_id"),
                "extension_channel": challenge.get("extension_channel"),
                "extension_version": challenge.get("extension_version"),
                "native_host_name": challenge.get("native_host_name"),
            },
        )
        browser_session_token = uuid.uuid4().hex
        with browser_session_lock:
            active_browser_sessions[body.browser_channel_id] = {
                "session_token": browser_session_token,
                "browser_install_identity": browser_install_identity,
                "delivery_target_id": payload.get("delivery_target_id"),
            }
        browser_host_metadata.update(
            {
                "browser_channel_id": body.browser_channel_id,
                "browser_install_identity": browser_install_identity,
                "delivery_target_id": payload.get("delivery_target_id"),
                "browser_action_ready": bool(payload.get("browser_action_ready")),
            }
        )
        _save_browser_host_metadata(browser_host_metadata)
        return {
            **payload,
            "browser_session_token": browser_session_token,
        }

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/browser-contexts")
    async def browser_companion_upsert_context(
        request: Request,
        body: LocalBrowserContextSyncRequest,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=body.browser_channel_id,
            extension_id=body.extension_id,
            extension_channel=body.extension_channel,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        return _machine_seed_core_request(
            method="POST",
            path="/v1/machine-seed/browser-contexts",
            json_body={
                "delivery_target_id": body.delivery_target_id,
                "browser_channel_id": body.browser_channel_id,
                "browser_name": body.browser_name,
                "profile_label": body.profile_label,
                "extension_id": body.extension_id,
                "extension_channel": body.extension_channel,
                "extension_version": body.extension_version,
                "tab_id": body.tab_id,
                "window_id": body.window_id,
                "page_url": body.page_url,
                "page_title": body.page_title,
                "top_level_origin": body.top_level_origin,
                "frame_id": body.frame_id,
                "frame_origin": body.frame_origin,
                "form_session_id": body.form_session_id,
                "field_summary": dict(body.field_summary),
                "last_seen_at_epoch_ms": body.last_seen_at_epoch_ms,
            },
        )

    @app.delete(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/browser-contexts/{{delivery_target_id}}")
    async def browser_companion_clear_context(
        request: Request,
        delivery_target_id: str,
        browser_channel_id: str,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=browser_channel_id,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        return _machine_seed_core_request(
            method="DELETE",
            path=(
                f"/v1/machine-seed/browser-contexts/{delivery_target_id}"
                f"?browser_channel_id={browser_channel_id}"
            ),
        )

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/popup/login-candidates")
    async def browser_companion_popup_login_candidates(
        request: Request,
        body: BrowserCompanionPopupLookupRequest,
    ) -> Any:
        delivery_target_id = str(body.delivery_target_id or "").strip() or None
        browser_channel_id = (
            str(body.browser_channel_id or "").strip()
            or str(_load_browser_host_metadata().get("browser_channel_id") or "").strip()
            or "browser-companion"
        )
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=browser_channel_id,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        return _machine_seed_core_request(
            method="POST",
            path="/v1/machine-seed/browser-popup/login-candidates",
            json_body={
                "delivery_target_id": delivery_target_id,
                "browser_channel_id": browser_channel_id,
            },
        )

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/popup/fill")
    async def browser_companion_popup_fill(
        request: Request,
        body: BrowserCompanionPopupFillRequest,
    ) -> Any:
        delivery_target_id = str(body.delivery_target_id or "").strip() or None
        browser_channel_id = (
            str(body.browser_channel_id or "").strip()
            or str(_load_browser_host_metadata().get("browser_channel_id") or "").strip()
            or "browser-companion"
        )
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=browser_channel_id,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        return _machine_seed_core_request(
            method="POST",
            path="/v1/machine-seed/browser-popup/fill",
            json_body={
                "delivery_target_id": delivery_target_id,
                "browser_channel_id": browser_channel_id,
                "selection_hint": (
                    dict(body.selection_hint)
                    if isinstance(body.selection_hint, dict)
                    else None
                ),
            },
        )

    @app.get(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/popup/requests/{{request_id}}/wait")
    async def browser_companion_popup_wait(
        request: Request,
        request_id: str,
        delivery_target_id: str | None = None,
        browser_channel_id: str | None = None,
        timeout_ms: int | None = None,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=str(browser_channel_id or "").strip() or "browser-companion",
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        query_parts: list[str] = []
        if delivery_target_id:
            query_parts.append(f"delivery_target_id={delivery_target_id}")
        if timeout_ms is not None:
            query_parts.append(f"timeout_ms={int(timeout_ms)}")
        query = f"?{'&'.join(query_parts)}" if query_parts else ""
        return _machine_seed_core_request(
            method="GET",
            path=f"/v1/machine-seed/browser-popup/requests/{request_id}/wait{query}",
        )

    @app.get(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/delivery-jobs/next")
    async def browser_companion_claim_next_delivery_job(
        request: Request,
        delivery_target_id: str,
        browser_channel_id: str,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=browser_channel_id,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        payload = _machine_seed_core_request(
            method="GET",
            path=(
                "/v1/machine-seed/delivery-jobs/next"
                f"?target_kind=browser_profile&delivery_target_id={delivery_target_id}"
                f"&browser_channel_id={browser_channel_id}"
            ),
        )
        job = payload.get("delivery_job")
        if not isinstance(job, dict):
            return payload
        try:
            decrypted = context.open_delivery_envelope(dict(job.get("envelope") or {}))
            decrypted = _resolve_local_blind_secret_payload(decrypted, context)
        except Exception as error:
            return _browser_companion_error_response(
                f"Skyline could not decrypt the browser delivery payload: {error}",
                status_code=500,
            )
        redacted_job = dict(job)
        redacted_job["payload"] = decrypted
        redacted_job.pop("envelope", None)
        return {"delivery_job": redacted_job}

    @app.post(f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-companion/delivery-jobs/{{job_id}}/ack")
    async def browser_companion_ack_delivery_job(
        request: Request,
        job_id: str,
        browser_channel_id: str,
        body: BrowserCompanionDeliveryJobAckRequest,
    ) -> Any:
        prepared = _prepare_browser_companion(
            request=request,
            browser_channel_id=browser_channel_id,
        )
        if isinstance(prepared, JSONResponse):
            return prepared
        return _machine_seed_core_request(
            method="POST",
            path=f"/v1/machine-seed/delivery-jobs/{job_id}/ack",
            json_body={
                "status": body.status,
                "message": body.message,
                "details": dict(body.details) if isinstance(body.details, dict) else None,
            },
        )

    return app


class RequesterLocalClient:
    def __init__(
        self,
        *,
        config_path: Path,
        seeded_machine_id: str,
        bootstrap_secret_file: str | None,
        socket_path: str | None,
        profile: dict[str, Any],
        requested_note: str | None,
        requested_profile: str | None,
        requested_tags: list[str],
        requested_metadata: dict[str, Any],
    ) -> None:
        self.config_path = config_path
        self.seeded_machine_id = seeded_machine_id
        self.bootstrap_secret_file = bootstrap_secret_file
        self.socket_path = socket_path
        self.profile = dict(profile)
        self.requested_note = requested_note
        self.requested_profile = requested_profile
        self.requested_tags = list(requested_tags)
        self.requested_metadata = dict(requested_metadata)

    @property
    def client_profile_id(self) -> str:
        return _slugify_client_id(str(self.profile.get("client_profile_id") or ""))

    @property
    def default_session_id(self) -> str:
        return _requester_default_session_id(
            seeded_machine_id=self.seeded_machine_id,
            profile=self.profile,
        )

    def _refresh_profile_from_store(self) -> dict[str, Any]:
        stored_profile = _load_requester_app_profiles(self.config_path).get(self.client_profile_id)
        if isinstance(stored_profile, dict):
            profile_id = self.client_profile_id
            refreshed_profile = dict(stored_profile)
            refreshed_profile.setdefault("client_profile_id", profile_id)
            self.profile = refreshed_profile
        return dict(self.profile)

    def connect_required_payload(self) -> dict[str, Any]:
        pending_request_id = str(self.profile.get("enrollment_request_id") or "").strip() or None
        if pending_request_id is not None:
            message = (
                "This requester app has an older pending registration. "
                "Retry the original Skyline MCP tool so the local STDIO bridge "
                "can finish registration under this approved machine."
            )
        else:
            message = (
                "This requester app is not registered yet. Retry the original "
                "Skyline MCP tool; after machine setup, requester registration "
                "does not need a second phone approval."
            )
        payload = {
            "status": "connect_required",
            "message": message,
            "client_profile_id": self.client_profile_id,
        }
        if pending_request_id is not None:
            payload["request_id"] = pending_request_id
        return payload

    def _request_transport(self) -> tuple[httpx.BaseTransport | None, str]:
        if self.socket_path:
            return httpx.HTTPTransport(uds=self.socket_path), "http://local-requester"
        raise RuntimeError("local requester service endpoint is not configured")

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        transport, base_url = self._request_transport()
        with httpx.Client(
            transport=transport,
            base_url=base_url,
            timeout=60.0,
        ) as client:
            response = client.request(
                method,
                path,
                json=json_body,
            )
        if response.is_error:
            try:
                payload = response.json()
            except Exception:
                payload = None
            if isinstance(payload, dict) and payload.get("status") in {
                "connect_required",
                "seed_required",
            }:
                raise RequesterPairingRequired(payload)
            if isinstance(payload, dict) and isinstance(payload.get("error"), str):
                raise RuntimeError(payload["error"])
            response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError("local requester service returned a non-object payload")
        return payload

    def requester_context(
        self,
        *,
        request_mode: str,
        request_class: str,
        session_id: str | None = None,
        workflow_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "session_id": session_id or self.default_session_id,
            "request_mode": request_mode,
            "request_class": request_class,
            "skyline_agent_version": installed_requester_cli_version(),
        }
        if workflow_id is not None:
            payload["workflow_id"] = workflow_id
        return payload

    def ensure_profile_ready(self) -> dict[str, Any] | None:
        payload = self._request(
            "POST",
            f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/requester-profiles/ensure",
            json_body={
                "client_profile_id": self.client_profile_id,
                "requested_display_name": str(
                    self.profile.get("display_name")
                    or _default_client_label(self.client_profile_id)
                ),
                "requested_note": self.requested_note,
                "requested_profile": self.requested_profile,
                "requested_tags": list(self.requested_tags),
                "requested_metadata": dict(self.requested_metadata),
                "requested_app_identifier": self.profile.get("app_identifier"),
                "requested_platform": self.profile.get("platform"),
                "requested_executable_path": self.profile.get("executable_path"),
                "requested_code_signing_identity": self.profile.get("code_signing_identity"),
            },
        )
        result = payload.get("result")
        if isinstance(result, dict):
            principal = result.get("requester_app_principal")
            if isinstance(principal, dict):
                self._refresh_profile_from_store()
                self.profile.update(
                    {
                        "display_name": principal.get("display_name") or self.profile.get("display_name"),
                        "app_identifier": principal.get("app_identifier") or self.profile.get("app_identifier"),
                        "platform": principal.get("platform") or self.profile.get("platform"),
                        "executable_path": principal.get("executable_path") or self.profile.get("executable_path"),
                        "code_signing_identity": principal.get("code_signing_identity") or self.profile.get("code_signing_identity"),
                        "requester_app_id": principal.get("requester_app_id") or self.profile.get("requester_app_id"),
                        "requester_app_principal_id": principal.get("requester_app_principal_id"),
                        "status": "active",
                    }
                )
                _update_requester_app_profile(self.config_path, self.profile)
                return None
        if isinstance(payload.get("request_id"), str) and payload["request_id"].strip():
            self._refresh_profile_from_store()
            self.profile["enrollment_request_id"] = payload["request_id"].strip()
            _update_requester_app_profile(self.config_path, self.profile)
        return payload

    def request_json(
        self,
        *,
        core_method: str,
        core_path: str,
        core_params: dict[str, Any] | None = None,
        core_json_body: dict[str, Any] | None = None,
        require_pairing: bool = True,
    ) -> dict[str, Any]:
        if require_pairing:
            if not str(self.profile.get("requester_app_principal_id") or "").strip():
                raise RequesterPairingRequired(self.connect_required_payload())
        payload = self._request(
            "POST",
            f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/core/request",
            json_body={
                "client_profile_id": self.client_profile_id,
                "core_method": core_method,
                "core_path": core_path,
                "core_params": dict(core_params or {}),
                "core_json_body": core_json_body,
                "require_pairing": require_pairing,
            },
        )
        result = payload.get("result")
        if isinstance(result, dict):
            principal = result.get("requester_app_principal")
            if isinstance(principal, dict):
                self._refresh_profile_from_store()
                self.profile.update(
                    {
                        "display_name": principal.get("display_name") or self.profile.get("display_name"),
                        "app_identifier": principal.get("app_identifier") or self.profile.get("app_identifier"),
                        "platform": principal.get("platform") or self.profile.get("platform"),
                        "executable_path": principal.get("executable_path") or self.profile.get("executable_path"),
                        "code_signing_identity": principal.get("code_signing_identity") or self.profile.get("code_signing_identity"),
                        "requester_app_id": principal.get("requester_app_id") or self.profile.get("requester_app_id"),
                        "requester_app_principal_id": principal.get("requester_app_principal_id"),
                        "status": "active",
                    }
                )
                _update_requester_app_profile(self.config_path, self.profile)
        return payload


def _load_requester_local_client(args: argparse.Namespace) -> RequesterLocalClient:
    config_path = _resolved_config_path(args.config_path)
    metadata = _load_metadata(config_path)
    service_state = _read_local_requester_service_state(config_path)
    socket_path = str(service_state.get("socket_path") or "").strip() or None
    explicit_args = _resolved_requester_app_args(args)
    profiles = _load_requester_app_profiles(config_path)
    explicit_selection = any(explicit_args.values())
    existing_profile: dict[str, Any] | None = None
    if explicit_selection:
        candidate_profile_id = _slugify_client_id(
            str(
                explicit_args["client_profile"]
                or explicit_args["client_app_identifier"]
                or (
                    Path(explicit_args["client_executable_path"]).name
                    if explicit_args["client_executable_path"]
                    else ""
                )
                or explicit_args["client_display_name"]
                or ""
            )
        )
        if candidate_profile_id:
            existing_profile = profiles.get(candidate_profile_id)
    elif len(profiles) > 1:
        raise _multiple_client_profiles_error()
    elif len(profiles) == 1:
        raise _client_identity_error()
    profile_id, display_name, app_identifier, executable_path, code_signing_identity = (
        _derive_requester_app_identity(
            explicit_args=explicit_args,
            existing_profile=existing_profile,
        )
    )
    profile = _load_or_create_requester_app_profile(
        config_path,
        bootstrap_secret_file=getattr(args, "bootstrap_secret_file", None),
        requested_profile_id=profile_id,
        requested_display_name=display_name,
        requested_app_identifier=app_identifier,
        requested_executable_path=executable_path,
        requested_code_signing_identity=code_signing_identity,
        ensure_keys=False,
    )
    return RequesterLocalClient(
        config_path=config_path,
        seeded_machine_id=str(
            metadata.get("seeded_machine_id") or ""
        ).strip(),
        bootstrap_secret_file=getattr(args, "bootstrap_secret_file", None),
        socket_path=socket_path,
        profile=profile,
        requested_note=(
            str(getattr(args, "requester_note", None) or metadata.get("requested_note") or "").strip()
            or None
        ),
        requested_profile=(
            str(getattr(args, "requester_profile", None) or metadata.get("requested_profile") or "").strip()
            or None
        ),
        requested_tags=list(getattr(args, "requester_tag", []) or metadata.get("requested_tags") or []),
        requested_metadata=(
            _coerce_metadata_json(getattr(args, "metadata_json", None))
            if getattr(args, "metadata_json", None)
            else (
                dict(metadata.get("requested_metadata") or {})
                if isinstance(metadata.get("requested_metadata"), dict)
                else {}
            )
        ),
    )


def _write_local_requester_service_state(
    *,
    config_path: Path,
    api_socket_path: str | None,
    pid: int,
) -> None:
    state_path = _local_requester_service_state_path(config_path)
    ensure_owner_only_directory(state_path.parent)
    state_payload: dict[str, Any] = {"pid": pid}
    if api_socket_path:
        state_payload["socket_path"] = api_socket_path
    write_owner_only_text(state_path, json.dumps(state_payload, indent=2, sort_keys=True) + "\n")


def _run_local_api_server(
    app: FastAPI,
    *,
    socket_path: str | None,
) -> None:
    if not socket_path:
        raise RuntimeError("local requester service requires a private Unix socket on macOS/Linux")
    socket_file = Path(socket_path)
    ensure_owner_only_directory(socket_file.parent)
    if socket_file.exists():
        socket_file.unlink()
    config = uvicorn.Config(
        app,
        uds=socket_path,
        log_level="info",
        http=_LocalRequesterProtocol,
    )
    server = uvicorn.Server(config)
    previous_umask = os.umask(0o077)
    try:
        server.run()
    finally:
        os.umask(previous_umask)


def _run_slot_command(
    *,
    command: str,
    secret_value: str,
    env_var: str,
) -> tuple[int, str | None]:
    env = dict(os.environ)
    env[env_var] = secret_value
    completed = subprocess.run(
        command,
        shell=True,
        env=env,
        capture_output=True,
        text=True,
    )
    if completed.returncode == 0:
        return 0, None
    stderr = (completed.stderr or "").strip()
    message = stderr[:200] if stderr else f"command exited with status {completed.returncode}"
    return completed.returncode, message


def _deliver_plain_inject(
    *,
    state_dir: Path,
    payload: dict[str, Any],
) -> tuple[int, str | None, dict[str, Any]]:
    destination_context = (
        dict(payload.get("destination_context", {}))
        if isinstance(payload.get("destination_context"), dict)
        else {}
    )
    secret_value = str(payload.get("secret_value") or "")
    delivery_action = str(payload.get("delivery_action") or "inject").strip() or "inject"
    if not secret_value:
        return 1, "payload did not contain a secret value", {"delivery_action": delivery_action}
    command = str(destination_context.get("command") or "").strip()
    env_var = str(destination_context.get("env_var") or DEFAULT_INJECT_ENV_VAR).strip() or DEFAULT_INJECT_ENV_VAR
    if command:
        return_code, message = _run_slot_command(
            command=command,
            secret_value=secret_value,
            env_var=env_var,
        )
        details = {
            "delivery_action": delivery_action,
            "delivery_mode": "command",
            "command": command,
            "env_var": env_var,
        }
        return return_code, message, details

    output_path_text = str(destination_context.get("output_path") or "").strip()
    if output_path_text:
        output_path = Path(output_path_text).expanduser()
        write_owner_only_text(output_path, secret_value)
        return 0, None, {
            "delivery_action": delivery_action,
            "delivery_mode": "file",
            "output_path": str(output_path),
        }

    inbox_dir_name = "reveal-inbox" if delivery_action == "local_reveal" else "inject-inbox"
    inbox_prefix = "skyline-reveal-" if delivery_action == "local_reveal" else "skyline-inject-"
    inbox_dir = state_dir / inbox_dir_name
    ensure_owner_only_directory(inbox_dir)
    temp_file = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        prefix=inbox_prefix,
        suffix=".secret",
        dir=str(inbox_dir),
        delete=False,
    )
    try:
        temp_file.write(secret_value)
    finally:
        temp_file.close()
    os.chmod(temp_file.name, stat.S_IRUSR | stat.S_IWUSR)
    return 0, None, {
        "delivery_action": delivery_action,
        "delivery_mode": "local_inbox",
        "output_path": temp_file.name,
        "env_var": env_var,
    }


def _stage_browser_secret_runner(
    *,
    state_dir: Path,
    payload: dict[str, Any],
    local_requester_socket_path: str | None = None,
) -> tuple[int, str | None, dict[str, Any]]:
    token = _safe_browser_secret_runner_token(payload.get("runner_token"))
    action = str(payload.get("browser_action") or "").strip()
    expires_at_epoch_ms = int(payload.get("expires_at_epoch_ms") or 0)
    writeback_token = str(payload.get("writeback_token") or "").strip()
    runner_dir = _browser_secret_runner_dir(state_dir)
    ensure_owner_only_directory(runner_dir)
    path = runner_dir / f"{token}.json"
    resolved_local_socket_path = (
        str(Path(local_requester_socket_path).expanduser())
        if local_requester_socket_path
        else None
    )
    record: dict[str, Any] = {
        "version": 1,
        "runner_token": token,
        "browser_action": action,
        "expires_at_epoch_ms": expires_at_epoch_ms,
        "request_id": payload.get("request_id"),
        "approval_id": payload.get("approval_id"),
        "expected_context": (
            dict(payload.get("expected_context"))
            if isinstance(payload.get("expected_context"), dict)
            else {}
        ),
        "username_value": payload.get("username_value"),
        "item_id": payload.get("item_id"),
        "item_title": payload.get("item_title"),
        "item_kind": payload.get("item_kind"),
        "field_name": payload.get("field_name"),
        "title": payload.get("title"),
        "kind": payload.get("kind"),
        "safe_metadata": (
            dict(payload.get("safe_metadata"))
            if isinstance(payload.get("safe_metadata"), dict)
            else {}
        ),
        "password_style": payload.get("password_style"),
        "capture_selector": payload.get("capture_selector"),
        "reveal_selector": payload.get("reveal_selector"),
        "copy_button_selector": payload.get("copy_button_selector"),
        "clear_selector": payload.get("clear_selector"),
        "created_secret_reuse_ttl_ms": payload.get("created_secret_reuse_ttl_ms"),
    }
    writeback_record: dict[str, Any] | None = None
    secret_record: dict[str, Any] | None = None
    if action in {"login", "change_password"}:
        secret_package = (
            dict(payload.get("secret_package"))
            if isinstance(payload.get("secret_package"), dict)
            else None
        )
        key_holder_id = str(
            payload.get("key_holder_id") or payload.get("issued_to_helper_id") or ""
        ).strip()
        key_version_raw = payload.get("key_version")
        key_version = int(key_version_raw) if key_version_raw is not None else None
        if secret_package is None or not key_holder_id:
            return 1, "browser password runner requires an encrypted secret package", {}
        if not resolved_local_socket_path:
            return 1, "browser password runner requires the local requester socket", {}
        secret_fetch_token = f"bsf_{uuid.uuid4().hex}"
        secret_record = {
            "version": 1,
            "runner_token": token,
            "browser_action": action,
            "expires_at_epoch_ms": expires_at_epoch_ms,
            "secret_fetch_token_sha256": hashlib.sha256(
                secret_fetch_token.encode("utf-8")
            ).hexdigest(),
            "request_id": payload.get("request_id"),
            "approval_id": payload.get("approval_id"),
            "item_id": payload.get("item_id"),
            "item_title": payload.get("item_title"),
            "item_kind": payload.get("item_kind"),
            "field_name": payload.get("field_name"),
            "secret_package": secret_package,
            "key_holder_id": key_holder_id,
            "key_version": key_version,
            "issued_to_helper_id": payload.get("issued_to_helper_id"),
        }
        record["secret_fetch"] = {
            "socket_path": resolved_local_socket_path,
            "path": f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-secret-runners/{token}/secret",
            "secret_fetch_token": secret_fetch_token,
        }
    if action in {"generate_password", "change_password", "capture_secret"} and writeback_token:
        writeback_record = {
            "version": 1,
            "runner_token": token,
            "writeback_token_sha256": hashlib.sha256(
                writeback_token.encode("utf-8")
            ).hexdigest(),
            "browser_action": action,
            "expires_at_epoch_ms": expires_at_epoch_ms,
            "request_id": payload.get("request_id"),
            "requester_app_profile_id": payload.get("requester_app_profile_id"),
            "requester_app_principal_id": payload.get("requester_app_principal_id"),
            "session_id": payload.get("session_id"),
            "workflow_id": payload.get("workflow_id"),
            "item_id": payload.get("item_id"),
            "item_revision": payload.get("item_revision"),
            "title": payload.get("title"),
            "kind": payload.get("kind"),
            "field_name": payload.get("field_name"),
            "safe_metadata": (
                dict(payload.get("safe_metadata"))
                if isinstance(payload.get("safe_metadata"), dict)
                else {}
            ),
            "expected_context": dict(record["expected_context"]),
            "password_style": payload.get("password_style"),
        }
        record["writeback"] = {
            "socket_path": resolved_local_socket_path,
            "path": f"{DEFAULT_REQUESTER_LOCAL_API_BASE_PATH}/browser-secret-runners/{token}/store",
            "writeback_token": writeback_token,
        }
    write_owner_only_text(path, json.dumps(record, indent=2, sort_keys=True) + "\n")
    if writeback_record is not None:
        writeback_path = _browser_secret_runner_writeback_path(state_dir, token)
        write_owner_only_text(
            writeback_path,
            json.dumps(writeback_record, indent=2, sort_keys=True) + "\n",
        )
    if secret_record is not None:
        secret_path = _browser_secret_runner_secret_path(state_dir, token)
        write_owner_only_text(
            secret_path,
            json.dumps(secret_record, indent=2, sort_keys=True) + "\n",
        )
    return 0, None, {
        "delivery_action": BROWSER_SECRET_RUNNER_DELIVERY_ACTION,
        "browser_action": action,
        "runner_token": token,
        "writeback_token_sha256": (
            hashlib.sha256(writeback_token.encode("utf-8")).hexdigest()
            if writeback_token
            else None
        ),
        "runner_secret_ready": True,
        "expected_context": dict(record["expected_context"]),
        "expires_at_epoch_ms": expires_at_epoch_ms,
        "secret_returned": False,
    }


def _resolve_local_secret_package_value(
    *,
    context: LocalRequesterContext,
    payload: dict[str, Any],
    package: dict[str, Any] | None,
) -> str:
    if not isinstance(package, dict):
        raise RuntimeError("blind delivery payload did not contain secret_package")
    key_holder_id = str(
        payload.get("key_holder_id") or payload.get("issued_to_helper_id") or ""
    ).strip()
    if not key_holder_id:
        raise RuntimeError("blind delivery payload did not include key_holder_id")
    key_version_raw = payload.get("key_version")
    key_version = int(key_version_raw) if key_version_raw is not None else None
    return context.decrypt_blind_secret_package(
        package=package,
        key_holder_id=key_holder_id,
        key_version=key_version,
    )


def _resolve_local_blind_secret_payload(
    payload: dict[str, Any],
    context: LocalRequesterContext,
) -> dict[str, Any]:
    resolved = dict(payload)
    if "secret_package" in resolved:
        resolved["secret_value"] = _resolve_local_secret_package_value(
            context=context,
            payload=resolved,
            package=(
                resolved.get("secret_package")
                if isinstance(resolved.get("secret_package"), dict)
                else None
            ),
        )
        resolved.pop("secret_package", None)
    for binding_key in ("env_bindings", "render_bindings"):
        bindings = [
            dict(binding)
            for binding in resolved.get(binding_key, [])
            if isinstance(binding, dict)
        ]
        for binding in bindings:
            if "secret_package" in binding:
                binding["secret_value"] = _resolve_local_secret_package_value(
                    context=context,
                    payload=resolved,
                    package=(
                        binding.get("secret_package")
                        if isinstance(binding.get("secret_package"), dict)
                        else None
                    ),
                )
                binding.pop("secret_package", None)
        if bindings:
            resolved[binding_key] = bindings
    return resolved


def _resolve_local_password_health_handoff_payload(
    payload: dict[str, Any],
    context: LocalRequesterContext,
) -> dict[str, Any]:
    result = payload.get("result")
    if not isinstance(result, dict):
        return payload
    if str(result.get("result_type") or "").strip() != "password_health_list_handoff":
        return payload
    expires_at = int(result.get("expires_at_epoch_ms") or 0)
    if expires_at > 0 and int(time.time() * 1000) > expires_at:
        resolved = dict(payload)
        resolved["status"] = "expired"
        resolved["result"] = None
        resolution = dict(resolved.get("resolution") or {})
        resolution["path"] = "password_health_handoff_expired"
        resolution["reason"] = "approved password health handoff expired"
        resolved["resolution"] = resolution
        return resolved
    handoff_package = result.get("handoff_package")
    if not isinstance(handoff_package, dict):
        raise RuntimeError("password health handoff is missing its encrypted package")
    opened = context.open_delivery_envelope(dict(handoff_package))
    if str(opened.get("result_type") or "").strip() != "password_health_list":
        raise RuntimeError("password health handoff decrypted to an unexpected result")
    resolved = dict(payload)
    resolved["result"] = opened
    return resolved


class LocalDeliveryPoller:
    def __init__(
        self,
        *,
        context: LocalRequesterContext,
        state_dir: Path,
        local_requester_socket_path: str | None,
        poll_interval: float,
    ) -> None:
        self.context = context
        self.state_dir = state_dir
        self.local_requester_socket_path = local_requester_socket_path
        self.poll_interval = max(poll_interval, 0.2)

    def run_forever(self) -> None:
        while True:
            try:
                if not self.context.is_seeded():
                    time.sleep(self.poll_interval)
                    continue
                access_token = self.context.ensure_access_token()
                payload = _request_core_json_with_optional_headers(
                    method="GET",
                    base_url=self.context.base_url,
                    path="/v1/machine-seed/delivery-jobs/next?target_kind=cli_slot",
                    access_token=access_token,
                    extra_headers=_hosted_tenant_headers_from_metadata(
                        _load_machine_metadata_from_context(self.context)
                    ),
                )
                job = payload.get("delivery_job")
                if not isinstance(job, dict):
                    time.sleep(self.poll_interval)
                    continue
                self._handle_job(access_token=access_token, job=job)
            except Exception as error:
                print(f"[Skyline Local Requester Service] delivery poller error: {error}", file=sys.stderr)
                time.sleep(self.poll_interval)

    def _ack(
        self,
        *,
        access_token: str,
        seeded_machine_id: str,
        job_id: str,
        status: str,
        message: str | None,
        details: dict[str, Any] | None = None,
    ) -> None:
        _request_core_json_with_optional_headers(
            method="POST",
            base_url=self.context.base_url,
            path=f"/v1/machine-seed/delivery-jobs/{job_id}/ack",
            access_token=access_token,
            extra_headers=_hosted_tenant_headers_from_metadata(
                _load_machine_metadata_from_context(self.context)
            ),
            json_body={
                "status": status,
                "message": message,
                "details": details,
            },
        )

    def _handle_job(self, *, access_token: str, job: dict[str, Any]) -> None:
        seeded_machine_id = self.context.seeded_machine_id
        job_id = str(job.get("job_id") or "")
        try:
            payload = self.context.open_delivery_envelope(dict(job.get("envelope") or {}))
            if str(payload.get("delivery_action") or "").strip() != BROWSER_SECRET_RUNNER_DELIVERY_ACTION:
                payload = _resolve_local_blind_secret_payload(payload, self.context)
        except Exception as error:
            self._ack(
                access_token=access_token,
                seeded_machine_id=seeded_machine_id,
                job_id=job_id,
                status="inject_failed",
                message=f"decrypt failed: {error}",
            )
            return
        delivery_action = str(payload.get("delivery_action") or "").strip()
        if delivery_action == "run_bundle":
            return_code, failure_message, details = _run_secret_bundle_command({}, payload)
        elif delivery_action == "render_bundle":
            return_code, failure_message, details = _render_secret_bundle({}, payload)
        elif delivery_action == BROWSER_SECRET_RUNNER_DELIVERY_ACTION:
            return_code, failure_message, details = _stage_browser_secret_runner(
                state_dir=self.state_dir,
                payload=payload,
                local_requester_socket_path=self.local_requester_socket_path,
            )
        else:
            return_code, failure_message, details = _deliver_plain_inject(
                state_dir=self.state_dir,
                payload=payload,
            )
        status = "inject_delivered" if return_code == 0 else "inject_failed"
        self._ack(
            access_token=access_token,
            seeded_machine_id=seeded_machine_id,
            job_id=job_id,
            status=status,
            message=failure_message,
            details=details,
        )


def cmd_serve(args: argparse.Namespace) -> int:
    config_path = _resolved_config_path(args.config_path)
    state_dir = _local_requester_state_dir(config_path)
    ensure_owner_only_directory(state_dir)
    api_socket_path = (
        str(args.api_socket_path).strip()
        if getattr(args, "api_socket_path", None)
        else (
            str(_local_requester_service_socket_path(config_path))
            if not sys.platform.startswith("win")
            else None
        )
    )
    context = LocalRequesterContext(
        config_path=config_path,
        bootstrap_secret_file=args.bootstrap_secret_file,
    )
    context.ensure_machine_identity()

    _write_local_requester_service_state(
        config_path=config_path,
        api_socket_path=api_socket_path,
        pid=os.getpid(),
    )

    local_api_app = create_local_requester_service_app(
        config_path=config_path,
        context=context,
    )
    poller = LocalDeliveryPoller(
        context=context,
        state_dir=state_dir,
        local_requester_socket_path=api_socket_path,
        poll_interval=args.delivery_poll_interval,
    )
    poller_thread = threading.Thread(target=poller.run_forever, daemon=True)
    poller_thread.start()
    _run_local_api_server(
        local_api_app,
        socket_path=api_socket_path,
    )
    return 0


def cmd_setup(args: argparse.Namespace) -> int:
    config_path = _resolved_config_path(args.config_path)
    base_url = str(args.core_base_url or "").strip()
    setup_code = str(args.setup_code or "").strip()
    if not base_url or not setup_code:
        return _print_json(
            _connect_status_payload(
                "seed_required",
                message=(
                    "Machine setup needs both a core base URL and a setup code."
                ),
            )
        )
    approval_timeout_seconds = float(
        args.approval_timeout_seconds
        or DEFAULT_MACHINE_SETUP_APPROVAL_TIMEOUT_SECONDS
    )
    context = LocalRequesterContext(
        config_path=config_path,
        bootstrap_secret_file=args.bootstrap_secret_file,
    )
    metadata = context.setup_machine(
        core_base_url=base_url,
        hosted_tenant_id=getattr(args, "hosted_tenant_id", None),
        setup_code=setup_code,
        machine_name=args.machine_name,
        requested_note=args.requester_note,
        requested_profile=args.requester_profile,
        requested_tags=list(args.requester_tag or []),
        requested_metadata=_coerce_metadata_json(args.metadata_json),
        approval_timeout_seconds=approval_timeout_seconds,
    )
    payload = _connect_status_payload(
        "machine_setup_completed",
        message=(
            "This machine is set up. Next, configure your agent as a local "
            "STDIO MCP server with command `skyline` and arguments `bridge`, "
            "`serve`."
        ),
        config_path=str(config_path),
        credential_storage_backend=metadata.get("credential_storage_backend"),
        bootstrap_token_id=metadata.get("bootstrap_token_id"),
        machine_display_name=metadata.get("machine_display_name"),
        macos_secure_enclave=metadata.get(MACOS_SECURE_ENCLAVE_METADATA_KEY),
        mcp_server=_stdio_mcp_server_setup_payload(),
    )
    service_state = _ensure_local_requester_service_started(args)
    payload["local_service_status"] = service_state.get("status")
    payload["local_service_message"] = service_state.get("message")
    _maybe_install_or_skip_browser_host(
        payload=payload,
        config_path=config_path,
        success_context="This machine was set up",
    )
    payload = _attach_requester_update_status(payload, config_path=config_path)
    return _print_json(payload)


def _load_ready_requester_client(args: argparse.Namespace) -> RequesterLocalClient:
    service_state = _ensure_local_requester_service_started(args)
    if service_state["status"] != "local_service_ready":
        raise StructuredCLIStatus(service_state)
    metadata = _load_metadata(_resolved_config_path(args.config_path))
    if not str(metadata.get("seeded_machine_id") or "").strip():
        raise StructuredCLIStatus(
            _connect_status_payload(
                "seed_required",
                message="This machine has not been set up yet. Run `skyline setup`, then retry.",
            )
        )
    try:
        return _load_requester_local_client(args)
    except Exception as error:
        status, message = _classify_connect_error(str(error))
        raise StructuredCLIStatus(_connect_status_payload(status, message=message)) from error


def _connect_requester_payload(args: argparse.Namespace) -> dict[str, Any]:
    config_path = _resolved_config_path(args.config_path)
    service_state = _ensure_local_requester_service_started(args)
    if service_state["status"] != "local_service_ready":
        return _attach_requester_update_status(service_state, config_path=config_path)
    metadata = _load_metadata(config_path)
    if not str(metadata.get("seeded_machine_id") or "").strip():
        return _attach_requester_update_status(
            _connect_status_payload(
                "seed_required",
                message="This machine has not been set up yet. Run `skyline setup`, then retry.",
            ),
            config_path=config_path,
        )

    try:
        client = _load_requester_local_client(args)
    except Exception as error:
        status, message = _classify_connect_error(str(error))
        return _attach_requester_update_status(
            _connect_status_payload(status, message=message),
            config_path=config_path,
        )

    try:
        pending = client.ensure_profile_ready()
    except RequesterPairingRequired as error:
        return _attach_requester_update_status(error.payload, config_path=config_path)
    except Exception as error:
        status, message = _classify_connect_error(str(error))
        return _attach_requester_update_status(
            _connect_status_payload(status, message=message),
            config_path=config_path,
        )
    if pending is None:
        payload = _connect_status_payload(
            "connected",
            message="This requester is connected and ready to use Skyline.",
            requester_id=client.profile.get("requester_app_principal_id"),
            app_id=client.profile.get("requester_app_id"),
            client_profile_id=client.client_profile_id,
            config_path=str(config_path),
        )
        _maybe_install_or_skip_browser_host(
            payload=payload,
            config_path=config_path,
            success_context="This requester connected successfully",
        )
        return _attach_requester_update_status(payload, config_path=config_path)

    payload = dict(pending)
    status = str(payload.get("status") or "").strip()
    if status == "approval_required":
        approval = payload.get("approval") if isinstance(payload.get("approval"), dict) else {}
        resolution = payload.get("resolution") if isinstance(payload.get("resolution"), dict) else {}
        return _attach_requester_update_status(
            _connect_status_payload(
                "approval_required",
                message="Phone approval is required before this requester can connect.",
                request_id=payload.get("request_id"),
                approval_id=approval.get("approval_id") or resolution.get("approval_id"),
                app_id=client.profile.get("requester_app_id"),
                client_profile_id=client.client_profile_id,
            ),
            config_path=config_path,
        )
    if status == "completed":
        result = payload.get("result") if isinstance(payload.get("result"), dict) else {}
        principal = (
            result.get("requester_app_principal")
            if isinstance(result.get("requester_app_principal"), dict)
            else {}
        )
        response_payload = _connect_status_payload(
            "connected",
            message="This requester is connected and ready to use Skyline.",
            requester_id=principal.get("requester_app_principal_id")
            or client.profile.get("requester_app_principal_id"),
            app_id=principal.get("requester_app_id") or client.profile.get("requester_app_id"),
            client_profile_id=client.client_profile_id,
            config_path=str(config_path),
        )
        _maybe_install_or_skip_browser_host(
            payload=response_payload,
            config_path=config_path,
            success_context="This requester connected successfully",
        )
        return _attach_requester_update_status(response_payload, config_path=config_path)
    return _attach_requester_update_status(payload, config_path=config_path)


def _local_bridge_session_id(args: argparse.Namespace) -> str | None:
    try:
        client = _load_requester_local_client(args)
    except Exception:
        return None
    return client.default_session_id


def _local_bridge_core_request(
    args: argparse.Namespace,
    method: str,
    path: str,
    params: dict[str, Any] | None,
    json_body: dict[str, Any] | None,
) -> dict[str, Any]:
    try:
        client = _load_ready_requester_client(args)
        prepared_json_body = (
            dict(json_body) if isinstance(json_body, dict) else json_body
        )
        if (
            path
            in {
                "/v1/vault/secret-actions/browser-password",
                "/v1/vault/secret-actions/browser-capture-secret",
            }
            and isinstance(prepared_json_body, dict)
            and not str(prepared_json_body.get("delivery_target_id") or "").strip()
        ):
            prepared_json_body["delivery_target_id"] = _resolve_default_delivery_target_id(
                client
            )
        return client.request_json(
            core_method=method,
            core_path=path,
            core_params=dict(params or {}),
            core_json_body=prepared_json_body,
        )
    except RequesterPairingRequired as error:
        return error.payload
    except StructuredCLIStatus as error:
        return error.payload
    except Exception as error:
        status, message = _classify_connect_error(str(error))
        if status != "rejected":
            return _connect_status_payload(status, message=message)
        raise


def cmd_bridge_serve(args: argparse.Namespace) -> int:
    from .mcp_server import (
        LocalRequesterMCPClient,
        MCPServerConfig,
        build_mcp_server,
    )

    config = MCPServerConfig(
        core_base_url="local-requester://core",
        access_token="",
        default_session_id="requester_local_bridge",
        timeout_seconds=DEFAULT_CORE_TIMEOUT_SECONDS,
        host="127.0.0.1",
        port=0,
        streamable_http_path="/",
    )
    bridge_client = LocalRequesterMCPClient(
        config,
        core_request_factory=lambda method, path, params, json_body: _local_bridge_core_request(
            args,
            method,
            path,
            params,
            json_body,
        ),
        connect_factory=lambda: _connect_requester_payload(args),
        update_instructions_factory=lambda: _requester_update_instructions(
            _resolved_config_path(args.config_path)
        ),
        session_id_resolver=lambda: _local_bridge_session_id(args),
    )
    server = build_mcp_server(
        config,
        bridge_client=bridge_client,
    )
    server.run("stdio")
    return 0


def _resolve_default_delivery_target_id(client: RequesterLocalClient) -> str:
    metadata = _load_metadata(client.config_path)
    delivery_target_id = str(metadata.get("delivery_target_id") or "").strip()
    if delivery_target_id:
        return delivery_target_id
    raise StructuredCLIStatus(
        {
            "status": "helper_setup_required",
            "message": (
                "No local delivery target is ready on this machine yet. "
                "Finish machine setup, then retry the Skyline MCP tool."
            ),
        }
    )


def _parse_secret_key_holders_payload(payload: dict[str, Any]) -> list[RecipientKeyReference]:
    raw_holders = payload.get("key_holders")
    if not isinstance(raw_holders, list):
        raise RuntimeError("core returned an invalid secret key-holder payload")
    holders: list[RecipientKeyReference] = []
    for holder in raw_holders:
        if not isinstance(holder, dict):
            continue
        holders.append(
            RecipientKeyReference(
                key_holder_id=str(holder["key_holder_id"]),
                public_key=str(holder["public_key"]),
                key_id=str(holder["key_id"]),
                key_version=int(holder["key_version"]),
                status=str(holder.get("status") or "active"),
                key_algorithm=str(holder.get("key_algorithm") or DELIVERY_KEY_ALGORITHM),
            )
        )
    return holders


def _local_list_import_secret_key_holders(
    client: Any,
    *,
    import_session_id: str,
    session_token: str,
) -> list[RecipientKeyReference]:
    payload = client.request_json(
        core_method="POST",
        core_path=f"/v1/vault/import-sessions/{import_session_id}/secret-key-holders",
        core_json_body={"session_token": session_token},
    )
    holders = _parse_secret_key_holders_payload(payload)
    return _enforce_trusted_secret_key_holders_for_write(client.config_path, holders)


LOCAL_IMPORT_MAX_FILE_BYTES = 50 * 1024 * 1024


def _infer_password_import_source_kind(filename: str, source_kind: str | None) -> str:
    normalized = str(source_kind or "").strip()
    if normalized:
        if normalized not in SUPPORTED_IMPORT_SOURCE_KINDS:
            raise RuntimeError(
                "source kind must be one of: "
                + ", ".join(sorted(SUPPORTED_IMPORT_SOURCE_KINDS))
            )
        return normalized
    if filename.lower().endswith(".1pux"):
        return "1password_1pux"
    raise RuntimeError("CSV import needs --source-kind so Skyline knows the export format")


def _import_warning_json(warning: Any) -> dict[str, Any]:
    if hasattr(warning, "to_json"):
        return dict(warning.to_json())
    if isinstance(warning, dict):
        return dict(warning)
    return {"code": "warning", "message": str(warning)}


def _upload_encrypted_password_import_draft(
    *,
    client: RequesterLocalClient,
    import_session_id: str,
    session_token: str,
    source_kind: str,
    filename: str,
    content: bytes,
) -> dict[str, Any]:
    if not import_session_id.strip():
        raise RuntimeError("import session id is required")
    if not session_token.strip():
        raise RuntimeError("import session token is required")
    parsed = parse_import_blob(
        source_kind=source_kind,
        filename=filename,
        content=content,
    )
    if not parsed.candidates:
        raise RuntimeError("No importable passwords were found in that file.")
    recipients = _local_list_import_secret_key_holders(
        client,
        import_session_id=import_session_id,
        session_token=session_token,
    )
    if not recipients:
        raise RuntimeError("No trusted key holder is available for encrypted import.")
    items: list[dict[str, Any]] = []
    for candidate in parsed.candidates:
        item_id = "protected_import_" + uuid.uuid4().hex
        protected_packages, authority_fields = build_client_side_protected_write_payload(
            kind=candidate.kind,
            item_id=item_id,
            item_revision=1,
            protected_fields=candidate.protected_fields,
            recipients=recipients,
        )
        items.append(
            {
                "item_id": item_id,
                "kind": candidate.kind,
                "title": candidate.title,
                "safe_metadata": with_client_side_presence_metadata(
                    candidate.kind,
                    candidate.safe_metadata,
                    candidate.protected_fields,
                ),
                "protected_packages": protected_packages,
                "authority_fields": authority_fields,
                "source_item_id": candidate.source_item_id,
                "source_item_type": candidate.source_item_type,
                "source_label": candidate.source_label,
                "warnings": [_import_warning_json(warning) for warning in candidate.warnings],
            }
        )
    body = {
        "session_token": session_token,
        "source_kind": parsed.source_kind,
        "source_filename": filename,
        "items": items,
        "skipped_items": [item.to_json() for item in parsed.skipped_items],
        "warnings": [warning.to_json() for warning in parsed.warnings],
    }
    return client.request_json(
        core_method="POST",
        core_path=f"/v1/vault/import-sessions/{import_session_id}/encrypted-draft",
        core_json_body=body,
    )


def _ensure_password_import_requester_ready(client: RequesterLocalClient) -> None:
    pending = client.ensure_profile_ready()
    if pending is None:
        return
    status = str(pending.get("status") or "").strip()
    message = str(pending.get("message") or "").strip()
    if status == "approval_required":
        message = message or "Phone approval is required before this importer can connect."
    elif not message:
        message = "Skyline could not connect this password importer yet."
    payload = dict(pending)
    payload.setdefault("status", status or "connect_required")
    payload["message"] = message
    raise StructuredCLIStatus(payload)


def _apply_password_import_requester_defaults(args: argparse.Namespace) -> None:
    if not str(getattr(args, "client_profile", "") or "").strip():
        setattr(args, "client_profile", PASSWORD_IMPORT_CLIENT_PROFILE)
    if not str(getattr(args, "client_display_name", "") or "").strip():
        setattr(args, "client_display_name", PASSWORD_IMPORT_CLIENT_DISPLAY_NAME)
    if not str(getattr(args, "client_app_identifier", "") or "").strip():
        setattr(args, "client_app_identifier", PASSWORD_IMPORT_CLIENT_APP_IDENTIFIER)
    if not str(getattr(args, "metadata_json", "") or "").strip():
        setattr(args, "metadata_json", json.dumps(PASSWORD_IMPORT_REQUESTER_METADATA))


def _forget_password_import_requester_profile(client: RequesterLocalClient) -> None:
    try:
        profile = client._refresh_profile_from_store()
        _clear_requester_app_profile_credentials(
            config_path=client.config_path,
            profile=profile,
            bootstrap_secret_file=client.bootstrap_secret_file,
        )
        _remove_requester_app_profile(
            client.config_path,
            profile_id=PASSWORD_IMPORT_CLIENT_PROFILE,
        )
    except Exception as error:
        print(
            f"warning: could not remove temporary password import requester state: {error}",
            file=sys.stderr,
        )


def _claim_pending_password_import_session(client: RequesterLocalClient) -> tuple[str, str]:
    payload = client.request_json(
        core_method="POST",
        core_path="/v1/vault/import-sessions/pending-upload/claim",
    )
    import_session = payload.get("import_session")
    if not isinstance(import_session, dict):
        raise RuntimeError("core did not return a password import session")
    import_session_id = str(import_session.get("import_session_id") or "").strip()
    session_token = str(import_session.get("session_token") or "").strip()
    if not import_session_id or not session_token:
        raise RuntimeError("core did not return a usable password import session")
    return import_session_id, session_token


def _ensure_password_import_session_args(
    args: argparse.Namespace,
    client: RequesterLocalClient,
) -> None:
    if str(getattr(args, "session_id", "") or "").strip() and str(
        getattr(args, "session_token", "") or ""
    ).strip():
        return
    import_session_id, session_token = _claim_pending_password_import_session(client)
    setattr(args, "session_id", import_session_id)
    setattr(args, "session_token", session_token)


def _password_import_source_options_html() -> str:
    options = []
    for source_kind in sorted(SUPPORTED_IMPORT_SOURCE_KINDS):
        label = PASSWORD_IMPORT_SOURCE_DISPLAY_NAMES.get(source_kind, source_kind)
        options.append(
            f'<option value="{html.escape(source_kind)}">{html.escape(label)}</option>'
        )
    return "\n".join(options)


def _password_import_page_html(upload_path: str = "/upload") -> bytes:
    upload_path_json = json.dumps(upload_path)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skyline Import</title>
  <style>
    body {{ font: 15px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 0; color: #17202a; background: #f6f7f9; }}
    main {{ max-width: 680px; margin: 48px auto; padding: 0 20px; }}
    section {{ background: white; border: 1px solid #d9dee7; border-radius: 8px; padding: 22px; }}
    h1 {{ font-size: 24px; margin: 0 0 8px; }}
    p {{ margin: 0 0 18px; color: #536070; }}
    label {{ display: block; font-weight: 600; margin: 16px 0 6px; }}
    select, input {{ width: 100%; box-sizing: border-box; font: inherit; padding: 10px; border: 1px solid #c7ced9; border-radius: 6px; }}
    button {{ margin-top: 18px; width: 100%; border: 0; border-radius: 6px; padding: 12px 14px; background: #1769e0; color: white; font: inherit; font-weight: 700; }}
    button:disabled {{ background: #9aa8ba; }}
    #status {{ margin-top: 16px; white-space: pre-wrap; }}
  </style>
</head>
<body>
  <main>
    <section>
      <h1>Import to Skyline</h1>
      <p>Choose your export file here. After upload, finish reviewing what to save on your iPhone.</p>
      <label for="source">Export type</label>
      <select id="source">{_password_import_source_options_html()}</select>
      <label for="file">Export file</label>
      <input id="file" type="file" accept=".csv,.1pux">
      <button id="upload">Upload encrypted draft</button>
      <div id="status"></div>
    </section>
  </main>
  <script>
    const status = document.getElementById('status');
    const button = document.getElementById('upload');
    function setStatus(text) {{ status.textContent = text; }}
    function toBase64(buffer) {{
      let binary = '';
      const bytes = new Uint8Array(buffer);
      const chunkSize = 0x8000;
      for (let i = 0; i < bytes.length; i += chunkSize) {{
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
      }}
      return btoa(binary);
    }}
    button.addEventListener('click', async () => {{
      const file = document.getElementById('file').files[0];
      if (!file) {{ setStatus('Choose an export file first.'); return; }}
      button.disabled = true;
      setStatus('Encrypting and uploading...');
      try {{
        const contentBase64 = toBase64(await file.arrayBuffer());
        const response = await fetch({upload_path_json}, {{
          method: 'POST',
          headers: {{ 'content-type': 'application/json' }},
          body: JSON.stringify({{
            source_kind: document.getElementById('source').value,
            filename: file.name,
            content_base64: contentBase64
          }})
        }});
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || 'Upload failed.');
        setStatus('Encrypted draft uploaded. Finish on your iPhone.');
      }} catch (error) {{
        setStatus(error.message || String(error));
        button.disabled = false;
      }}
    }});
  </script>
</body>
</html>
""".encode("utf-8")


def _serve_password_import_page(args: argparse.Namespace, client: RequesterLocalClient) -> int:
    session_id = str(args.session_id or "").strip()
    session_token = str(args.session_token or "").strip()
    upload_path = f"/upload/{secrets.token_urlsafe(24)}"
    upload_done = threading.Event()
    result: dict[str, Any] = {}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, status_code: int, payload: dict[str, Any]) -> None:
            data = json.dumps(payload).encode("utf-8")
            self.send_response(status_code)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            if self.path != "/":
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            data = _password_import_page_html(upload_path)
            self.send_response(HTTPStatus.OK)
            self.send_header("content-type", "text/html; charset=utf-8")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self) -> None:
            if self.path != upload_path:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            try:
                content_length = int(self.headers.get("content-length") or "0")
                if content_length <= 0 or content_length > LOCAL_IMPORT_MAX_FILE_BYTES * 2:
                    raise RuntimeError("Import upload is too large.")
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                filename = str(payload.get("filename") or "import").strip() or "import"
                content = base64.b64decode(str(payload.get("content_base64") or ""), validate=True)
                if len(content) > LOCAL_IMPORT_MAX_FILE_BYTES:
                    raise RuntimeError("Import file is too large.")
                source_kind = _infer_password_import_source_kind(
                    filename,
                    str(payload.get("source_kind") or ""),
                )
                result.clear()
                result.update(
                    _upload_encrypted_password_import_draft(
                        client=client,
                        import_session_id=session_id,
                        session_token=session_token,
                        source_kind=source_kind,
                        filename=filename,
                        content=content,
                    )
                )
                upload_done.set()
                self._send_json(HTTPStatus.OK, {"status": "uploaded"})
            except Exception as error:
                self._send_json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": str(error) or "Upload failed."},
                )

    host = "127.0.0.1"
    with ThreadingHTTPServer((host, int(args.port or 0)), Handler) as server:
        port = int(server.server_address[1])
        url = f"http://{host}:{port}/"
        print(f"Open this page on this computer to import: {url}")
        if not args.no_open:
            webbrowser.open(url)
        while not upload_done.is_set():
            server.handle_request()
    _forget_password_import_requester_profile(client)
    return _print_json({"status": "encrypted_draft_uploaded", "next_step": "finish_on_iphone"})


def cmd_import_passwords(args: argparse.Namespace) -> int:
    _apply_password_import_requester_defaults(args)
    client = _load_ready_requester_client(args)
    _ensure_password_import_requester_ready(client)
    _ensure_password_import_session_args(args, client)
    if args.file:
        path = Path(args.file).expanduser()
        content = path.read_bytes()
        if len(content) > LOCAL_IMPORT_MAX_FILE_BYTES:
            raise RuntimeError("Import file is too large.")
        source_kind = _infer_password_import_source_kind(path.name, args.source_kind)
        payload = _upload_encrypted_password_import_draft(
            client=client,
            import_session_id=str(args.session_id or "").strip(),
            session_token=str(args.session_token or "").strip(),
            source_kind=source_kind,
            filename=path.name,
            content=content,
        )
        redacted_session = payload.get("import_session") if isinstance(payload, dict) else None
        _forget_password_import_requester_profile(client)
        return _print_json(
            {
                "status": "encrypted_draft_uploaded",
                "next_step": "finish_on_iphone",
                "import_session": redacted_session,
            }
        )
    return _serve_password_import_page(args, client)


def cmd_version(args: argparse.Namespace) -> int:
    update_status = build_requester_cli_update_status()
    payload = {
        "product": "Skyline",
        "package": update_status["package"],
        "installed_version": update_status["installed_version"],
        "update_command": update_status["update_command"],
    }
    if sys.platform == "darwin":
        payload[MACOS_SECURE_ENCLAVE_METADATA_KEY] = macos_secure_enclave_identity_status()
    if getattr(args, "json", False):
        return _print_json(payload)
    version = payload["installed_version"] or "unknown"
    print(f"Skyline CLI {version}")
    print(f"Package: {payload['package']}")
    print(f"Update: {payload['update_command']}")
    if MACOS_SECURE_ENCLAVE_METADATA_KEY in payload:
        status = payload[MACOS_SECURE_ENCLAVE_METADATA_KEY]
        if isinstance(status, dict):
            print(f"Mac Secure Enclave: {status.get('status')}")
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    command = requester_cli_update_command_parts()
    print("Updating Skyline CLI with:")
    print("  " + " ".join(shlex.quote(part) for part in command))
    exit_code, _ = run_requester_cli_update()
    if exit_code != 0:
        if exit_code == 127:
            print(
                "Skyline update failed because `uv` is not installed or not on PATH.",
                file=sys.stderr,
            )
        return exit_code

    stopped_service = False
    if not getattr(args, "no_stop_service", False):
        stopped_service = _stop_local_requester_service(_resolved_config_path(args.config_path))
    print("Skyline CLI update installed.")
    if stopped_service:
        print("Stopped the hidden local Skyline service so it restarts with the new CLI.")
    print("Restart any agent app or MCP session using `skyline bridge serve`.")
    return 0


def _current_skyline_command_path() -> str:
    resolved = shutil.which("skyline")
    if resolved:
        return resolved
    invoked_as = Path(sys.argv[0]).expanduser()
    if invoked_as.name == "skyline" and (
        invoked_as.is_absolute() or len(invoked_as.parts) > 1
    ):
        return str(invoked_as.resolve())
    return "skyline"


def cmd_mcp_command(args: argparse.Namespace) -> int:
    try:
        lines = agent_command_output_lines(args.agent, _current_skyline_command_path())
    except ValueError as error:
        raise SystemExit(str(error)) from error
    print("\n".join(lines))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="skyline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Skyline sets up this machine once, then exposes a local STDIO MCP "
            "bridge for agents."
        ),
        epilog=local_requester_epilog(),
    )
    parser.add_argument(
        "--config-path",
        default=str(DEFAULT_CONFIG_PATH),
        help="Path to the local requester state metadata file.",
    )
    parser.add_argument(
        "--bootstrap-secret-file",
        default=None,
        help="Optional bootstrap secret file for encrypted-file credential storage on headless Linux.",
    )
    subparsers = parser.add_subparsers(
        dest="command",
        required=False,
        metavar="{version,update,setup,mcp-command,import,erase-connection}",
    )

    version_parser = subparsers.add_parser("version", help="Show the installed Skyline CLI version.")
    version_parser.add_argument("--json", action="store_true", help="Print version details as JSON.")
    version_parser.set_defaults(func=cmd_version)

    update_parser = subparsers.add_parser(
        "update",
        help="Update the Skyline CLI from the configured package index.",
        description=(
            "Update the Skyline CLI explicitly. This uses `uv tool install --force` "
            "against the configured Skyline package and stops the hidden local "
            "service afterward so the next bridge/session starts with new code."
        ),
    )
    update_parser.add_argument(
        "--no-stop-service",
        action="store_true",
        help="Install the update but leave the hidden local Skyline service running.",
    )
    update_parser.set_defaults(func=cmd_update)

    mcp_command_parser = subparsers.add_parser(
        "mcp-command",
        prog="skyline mcp command",
        help="Print the copyable MCP setup command for an agent app.",
        description=(
            "Print the exact command or config needed to add Skyline as a local "
            "STDIO MCP server. Run this after `skyline setup`."
        ),
    )
    mcp_command_parser.add_argument(
        "agent",
        choices=[
            "claude",
            "claude-code",
            "claude-cowork",
            "cowork",
            "codex",
            "codex-desktop",
            "codex-app",
            "cursor",
            "openclaw",
            "other",
            "all",
        ],
        help="Agent app to generate setup for.",
    )
    mcp_command_parser.set_defaults(func=cmd_mcp_command)

    def add_requester_app_args(
        command_parser: argparse.ArgumentParser,
        *,
        suppress_help: bool = False,
    ) -> None:
        def help_text(value: str) -> str:
            return argparse.SUPPRESS if suppress_help else value

        command_parser.add_argument(
            "--client-profile",
            default=None,
            help=help_text(
                "Stable profile/workload id for this app or harness. "
                f"May also be supplied with {CLIENT_PROFILE_ENV_VAR}."
            ),
        )
        command_parser.add_argument(
            "--client-display-name",
            default=None,
            help=help_text(
                "Human-facing display name for this app or harness. "
                f"May also be supplied with {CLIENT_DISPLAY_NAME_ENV_VAR}."
            ),
        )
        command_parser.add_argument(
            "--client-app-identifier",
            default=None,
            help=help_text(
                f"Optional app or workload identifier. May also be supplied with {CLIENT_APP_IDENTIFIER_ENV_VAR}."
            ),
        )
        command_parser.add_argument(
            "--client-executable-path",
            default=None,
            help=help_text(
                f"Optional executable path hint. May also be supplied with {CLIENT_EXECUTABLE_PATH_ENV_VAR}."
            ),
        )
        command_parser.add_argument(
            "--client-code-signing-identity",
            default=None,
            help=help_text(
                "Optional signing identity hint. "
                f"May also be supplied with {CLIENT_CODE_SIGNING_IDENTITY_ENV_VAR}."
            ),
        )
    serve_parser = subparsers.add_parser("serve", help=argparse.SUPPRESS)
    serve_parser.add_argument("--api-socket-path", default=None)
    serve_parser.add_argument("--delivery-poll-interval", type=float, default=2.0)
    serve_parser.set_defaults(func=cmd_serve)

    bridge_serve_parser = subparsers.add_parser(
        "bridge-serve",
        prog="skyline bridge serve",
        help=argparse.SUPPRESS,
        description=(
            "Run the local Skyline agent bridge over MCP stdio. This should be "
            "launched by the agent as a configured local tool/server, not by a "
            "generic terminal shell."
        ),
    )
    bridge_serve_parser.add_argument("--requester-note", default=None)
    bridge_serve_parser.add_argument("--requester-profile", default=None)
    bridge_serve_parser.add_argument("--requester-tag", action="append", default=[])
    bridge_serve_parser.add_argument("--metadata-json", default=None)
    bridge_serve_parser.add_argument("--startup-timeout-seconds", type=float, default=8.0)
    add_requester_app_args(bridge_serve_parser)
    bridge_serve_parser.set_defaults(func=cmd_bridge_serve)

    setup_parser = subparsers.add_parser(
        "setup",
        help="Set up this machine after iPhone approval so requester apps can connect.",
        description=setup_command_description(),
    )
    setup_parser.add_argument("--core-base-url", required=True)
    setup_parser.add_argument("--hosted-tenant-id", default=None)
    setup_parser.add_argument("--setup-code", required=True)
    setup_parser.add_argument("--machine-name", default=None)
    setup_parser.add_argument("--requester-note", default=None)
    setup_parser.add_argument("--requester-profile", default=None)
    setup_parser.add_argument("--requester-tag", action="append", default=[])
    setup_parser.add_argument("--metadata-json", default=None)
    setup_parser.add_argument(
        "--approval-timeout-seconds",
        type=float,
        default=DEFAULT_MACHINE_SETUP_APPROVAL_TIMEOUT_SECONDS,
    )
    setup_parser.set_defaults(func=cmd_setup)

    import_parser = subparsers.add_parser(
        "import",
        help="Import an encrypted file draft from this connected computer.",
        description=(
            "Import a password-manager export from this connected computer. "
            "Skyline encrypts the draft locally, uploads it, then finishes review "
            "on the iPhone."
        ),
    )
    import_parser.set_defaults(
        func=cmd_import_passwords,
        session_id=None,
        session_token=None,
        source_kind=None,
        file=None,
        port=0,
        no_open=False,
    )
    import_parser.add_argument(
        "import_command",
        nargs="?",
        default="passwords",
        choices=["passwords"],
        help=argparse.SUPPRESS,
    )
    import_parser.add_argument("--session-id", default=None, help=argparse.SUPPRESS)
    import_parser.add_argument("--session-token", default=None, help=argparse.SUPPRESS)
    import_parser.add_argument(
        "--source-kind",
        choices=sorted(SUPPORTED_IMPORT_SOURCE_KINDS),
        default=None,
        help="Required for CSV files; inferred for .1pux files.",
    )
    import_parser.add_argument(
        "--file",
        default=None,
        help="Optional file path for non-interactive import; omitted to open the local page.",
    )
    import_parser.add_argument("--port", type=int, default=0)
    import_parser.add_argument("--no-open", action="store_true")
    add_requester_app_args(import_parser, suppress_help=True)

    erase_connection_parser = subparsers.add_parser(
        "erase-connection",
        help=(
            "Erase this requester locally. If it was the last local requester, "
            "also clear shared machine/helper/browser requester state."
        ),
        description=(
            "Erase the current requester locally.\n\n"
            "Normally run this with no arguments from the requester you want to "
            "disconnect. Only use --client-profile for rare manual cleanup when "
            "multiple local requester profiles exist and Skyline cannot tell "
            "which requester asked to erase itself.\n\n"
            "If this was the last local requester on the machine, Skyline also "
            "clears shared local requester/helper/browser state so the next "
            "`skyline setup` behaves like first-time setup again. This does not "
            "delete vault-side history or audit logs."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    erase_connection_parser.add_argument(
        "--client-profile",
        default=None,
        help=(
            "Optional stable requester profile id to erase. Normally omit this "
            "and run the command from the requester you want to erase."
        ),
    )
    erase_connection_parser.set_defaults(func=cmd_erase_connection)

    hidden_from_help = {"serve", "bridge-serve"}
    subparsers._choices_actions = [  # type: ignore[attr-defined]
        action
        for action in subparsers._choices_actions  # type: ignore[attr-defined]
        if action.dest not in hidden_from_help
    ]

    return parser


def _stdio_mcp_server_setup_payload() -> dict[str, Any]:
    command = shutil.which("skyline") or "skyline"
    return {
        "name": "Skyline",
        "transport": "STDIO",
        "command": command,
        "args": ["bridge", "serve"],
        "environment_variables": {},
        "environment_variable_passthrough": [],
        "working_directory": None,
    }


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    if raw_argv[:1] == ["help"]:
        raw_argv = ["--help"] if len(raw_argv) == 1 else [*raw_argv[1:], "--help"]
    args = parser.parse_args(raw_argv)
    command = args.command or "serve"
    if not hasattr(args, "func"):
        raise SystemExit(f"unknown command '{command}'")
    try:
        return int(args.func(args) or 0)
    except StructuredCLIStatus as error:
        print(json.dumps(error.payload, indent=2, sort_keys=True))
        return 1
    except RequesterPairingRequired as error:
        print(json.dumps(error.payload, indent=2, sort_keys=True))
        return 1
    except httpx.HTTPStatusError as error:
        detail_message = ""
        try:
            payload = error.response.json()
        except Exception:
            payload = None
        if isinstance(payload, dict):
            detail_message = str(payload.get("error") or payload.get("detail") or "").strip()
            status, message = _classify_connect_error(detail_message)
            if status != "rejected":
                print(json.dumps(_connect_status_payload(status, message=message), indent=2, sort_keys=True))
                return 1
        detail = detail_message or error.response.text.strip() or str(error)
        print(f"HTTP error: {detail}", file=sys.stderr)
        return 1
    except Exception as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
