"""Requester-side Skyline CLI package."""
