from __future__ import annotations

import csv
import io
import json
import re
import zipfile
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse


SUPPORTED_IMPORT_SOURCE_KINDS = {
    "1password_csv",
    "1password_1pux",
    "apple_passwords_csv",
    "google_password_manager_csv",
}

PASSWORD_IMPORT_SOURCE_DISPLAY_NAMES = {
    "1password_csv": "1Password CSV",
    "1password_1pux": "1Password 1PUX",
    "apple_passwords_csv": "Apple Passwords CSV",
    "google_password_manager_csv": "Google Password Manager CSV",
}

LOGIN_FIELD_NAMES = {
    "username",
    "user",
    "user_name",
    "login",
    "email",
    "email_address",
}
PASSWORD_FIELD_NAMES = {"password", "pass", "passphrase"}
CARD_NUMBER_FIELD_NAMES = {
    "creditcardnumber",
    "credit_card_number",
    "cardnumber",
    "card_number",
    "ccnumber",
    "cc_number",
    "number",
    "ccnum",
}
CARDHOLDER_FIELD_NAMES = {
    "cardholder",
    "cardholdername",
    "card_holder",
    "card_holder_name",
    "nameoncard",
    "name_on_card",
    "cardholder_name",
    "fullname",
}
CARD_BRAND_FIELD_NAMES = {
    "creditcardtype",
    "credit_card_type",
    "cardtype",
    "card_type",
    "type",
    "brand",
}
CARD_EXPIRY_FIELD_NAMES = {
    "monthyear",
    "month_year",
    "expiry",
    "expiration",
    "expirationdate",
    "expirydate",
    "expiry_date",
    "expiration_date",
}
CARD_CVV_FIELD_NAMES = {
    "cvv",
    "cvc",
    "cvn",
    "verificationnumber",
    "securitycode",
    "security_code",
}
CARD_BILLING_ZIP_FIELD_NAMES = {
    "billingzip",
    "billing_zip",
    "postalcode",
    "postal_code",
    "zipcode",
    "zip_code",
    "zip",
}
OTP_FIELD_NAMES = {
    "otp",
    "totp",
    "onetimepassword",
    "one_time_password",
    "one-timepassword",
    "one-time_password",
    "one-timepassword",
    "otpauth",
    "verificationcode",
    "verification_code",
}

TRUE_VALUES = {"1", "true", "yes", "y", "archived"}
MONTH_YEAR_RE = re.compile(r"^(?P<year>\d{4})[/-]?(?P<month>\d{2})$")


@dataclass(slots=True)
class ImportWarning:
    code: str
    message: str
    source_label: str | None = None

    def to_json(self) -> dict[str, Any]:
        payload = {
            "code": self.code,
            "message": self.message,
        }
        if self.source_label:
            payload["source_label"] = self.source_label
        return payload


@dataclass(slots=True)
class ImportSkippedItem:
    source_item_type: str
    source_label: str
    reason_code: str
    reason: str

    def to_json(self) -> dict[str, Any]:
        return {
            "source_item_type": self.source_item_type,
            "source_label": self.source_label,
            "reason_code": self.reason_code,
            "reason": self.reason,
        }


@dataclass(slots=True)
class ImportCandidateItem:
    kind: str
    title: str
    safe_metadata: dict[str, Any]
    protected_fields: dict[str, Any]
    source_item_type: str
    source_label: str
    source_item_id: str | None = None
    warnings: list[ImportWarning] = field(default_factory=list)


@dataclass(slots=True)
class ParsedImport:
    source_kind: str
    source_display_name: str
    total_items: int
    candidates: list[ImportCandidateItem]
    skipped_items: list[ImportSkippedItem]
    warnings: list[ImportWarning]


def parse_import_blob(
    *,
    source_kind: str,
    filename: str,
    content: bytes,
) -> ParsedImport:
    normalized_source_kind = source_kind.strip()
    if normalized_source_kind not in SUPPORTED_IMPORT_SOURCE_KINDS:
        raise ValueError(
            "source_kind must be one of: "
            + ", ".join(sorted(SUPPORTED_IMPORT_SOURCE_KINDS))
        )
    if normalized_source_kind == "1password_1pux":
        return _parse_1password_1pux(filename, content)
    return _parse_password_csv(
        source_kind=normalized_source_kind,
        filename=filename,
        content=content,
    )


def _parse_password_csv(
    *,
    source_kind: str,
    filename: str,
    content: bytes,
) -> ParsedImport:
    if not filename.lower().endswith(".csv"):
        raise ValueError("password-manager CSV import requires a .csv file")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError(f"could not decode CSV as UTF-8: {error}") from error
    reader = csv.DictReader(io.StringIO(text))
    if reader.fieldnames is None:
        raise ValueError("CSV file is missing a header row")
    rows = list(reader)
    candidates: list[ImportCandidateItem] = []
    skipped_items: list[ImportSkippedItem] = []
    warnings: list[ImportWarning] = []
    for index, row in enumerate(rows, start=1):
        normalized = _normalize_csv_row(row)
        label = (
            normalized.get("title")
            or normalized.get("name")
            or normalized.get("website")
            or normalized.get("url")
            or f"Row {index}"
        )
        if _is_truthy(normalized.get("archivedstatus") or normalized.get("archived")):
            skipped_items.append(
                ImportSkippedItem(
                    source_item_type=source_kind,
                    source_label=label,
                    reason_code="archived_item",
                    reason="Archived items are skipped in the phase-1 importer.",
                )
            )
            continue

        raw_login_url = (
            normalized.get("website")
            or normalized.get("url")
            or normalized.get("loginuri")
            or normalized.get("loginurl")
            or normalized.get("origin")
        )
        site = (
            _canonical_site_from_url(raw_login_url)
            or normalized.get("website")
            or normalized.get("url")
            or normalized.get("origin")
        )
        email = normalized.get("email") or normalized.get("emailaddress")
        username = (
            normalized.get("username")
            or normalized.get("user")
            or normalized.get("login")
            or email
        )
        password = normalized.get("password")
        notes = normalized.get("notes") or normalized.get("note")
        if not site or not username or not password:
            skipped_items.append(
                ImportSkippedItem(
                    source_item_type=source_kind,
                    source_label=label,
                    reason_code="missing_required_login_fields",
                    reason=(
                        "Phase-1 login import requires site, username, and password."
                    ),
                )
            )
            continue
        item_warnings: list[ImportWarning] = []
        otp_value = (
            normalized.get("onetimepassword")
            or normalized.get("otp")
            or normalized.get("totp")
        )
        if otp_value:
            warning = ImportWarning(
                code="totp_deferred",
                message=(
                    "This item includes a one-time password value, but TOTP import is "
                    "deferred until a follow-on release."
                ),
                source_label=label,
            )
            item_warnings.append(warning)
            warnings.append(warning)
        safe_metadata: dict[str, Any] = {
            "site": site,
            "username": username,
        }
        if email and email != username:
            safe_metadata["email"] = email
        if raw_login_url:
            safe_metadata["login_url"] = raw_login_url
        if notes:
            warning = ImportWarning(
                code="notes_deferred",
                message=(
                    "This item includes notes, but note import is deferred because "
                    "notes can contain secrets."
                ),
                source_label=label,
            )
            item_warnings.append(warning)
            warnings.append(warning)
        candidates.append(
            ImportCandidateItem(
                kind="login_secret",
                title=(
                    normalized.get("title")
                    or normalized.get("name")
                    or site
                ),
                safe_metadata=safe_metadata,
                protected_fields={"password": password},
                source_item_type=source_kind,
                source_label=label,
                warnings=item_warnings,
            )
        )

    return ParsedImport(
        source_kind=source_kind,
        source_display_name=PASSWORD_IMPORT_SOURCE_DISPLAY_NAMES[source_kind],
        total_items=len(rows),
        candidates=candidates,
        skipped_items=skipped_items,
        warnings=warnings,
    )


def _parse_1password_1pux(filename: str, content: bytes) -> ParsedImport:
    if not filename.lower().endswith(".1pux"):
        raise ValueError("1Password 1PUX import requires a .1pux file")
    try:
        archive = zipfile.ZipFile(io.BytesIO(content))
    except zipfile.BadZipFile as error:
        raise ValueError("1PUX file is not a valid ZIP archive") from error

    try:
        export_data_bytes = archive.read("export.data")
    except KeyError as error:
        raise ValueError("1PUX archive is missing export.data") from error
    try:
        payload = json.loads(export_data_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError(f"1PUX export.data could not be parsed: {error}") from error

    accounts = payload.get("accounts")
    if not isinstance(accounts, list):
        raise ValueError("1PUX export.data is missing accounts")

    candidates: list[ImportCandidateItem] = []
    skipped_items: list[ImportSkippedItem] = []
    warnings: list[ImportWarning] = []
    total_items = 0

    for account in accounts:
        if not isinstance(account, dict):
            continue
        account_attrs = account.get("attrs") if isinstance(account.get("attrs"), dict) else {}
        account_name = (
            str(account_attrs.get("name") or account_attrs.get("accountName") or "").strip()
        )
        vaults = account.get("vaults")
        if not isinstance(vaults, list):
            continue
        for vault in vaults:
            if not isinstance(vault, dict):
                continue
            items = vault.get("items")
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                total_items += 1
                parsed = _parse_1pux_item(item=item, account_name=account_name)
                if isinstance(parsed, ImportCandidateItem):
                    candidates.append(parsed)
                    warnings.extend(parsed.warnings)
                elif isinstance(parsed, ImportSkippedItem):
                    skipped_items.append(parsed)

    return ParsedImport(
        source_kind="1password_1pux",
        source_display_name=PASSWORD_IMPORT_SOURCE_DISPLAY_NAMES["1password_1pux"],
        total_items=total_items,
        candidates=candidates,
        skipped_items=skipped_items,
        warnings=warnings,
    )


def _parse_1pux_item(
    *,
    item: dict[str, Any],
    account_name: str,
) -> ImportCandidateItem | ImportSkippedItem:
    state = str(item.get("state") or "").strip().lower()
    overview = item.get("overview") if isinstance(item.get("overview"), dict) else {}
    details = item.get("details") if isinstance(item.get("details"), dict) else {}
    category_uuid = str(item.get("categoryUuid") or "").strip() or "unknown"
    title = str(overview.get("title") or item.get("uuid") or "1Password item").strip()
    source_item_id = str(item.get("uuid") or "").strip() or None
    if state == "archived":
        return ImportSkippedItem(
            source_item_type=f"1password_1pux:{category_uuid}",
            source_label=title,
            reason_code="archived_item",
            reason="Archived items are skipped in the phase-1 importer.",
        )

    login_candidate = _parse_1pux_login_item(
        title=title,
        overview=overview,
        details=details,
        source_item_id=source_item_id,
    )
    if login_candidate is not None:
        return login_candidate

    card_candidate = _parse_1pux_payment_card_item(
        title=title,
        overview=overview,
        details=details,
        account_name=account_name,
        source_item_id=source_item_id,
    )
    if card_candidate is not None:
        return card_candidate

    flattened_text = _flatten_1pux_search_text(item)
    if any(marker in flattened_text for marker in {"passkey", "webauthn", "fido"}):
        return ImportSkippedItem(
            source_item_type=f"1password_1pux:{category_uuid}",
            source_label=title,
            reason_code="passkey_requires_native_import",
            reason=(
                "Passkeys are deferred to a later native migration path rather than "
                "the phase-1 bulk importer."
            ),
        )
    if any(marker in flattened_text for marker in {"one time password", "one-time password", "otpauth", "totp"}):
        return ImportSkippedItem(
            source_item_type=f"1password_1pux:{category_uuid}",
            source_label=title,
            reason_code="totp_deferred",
            reason="TOTP import is deferred until a follow-on release.",
        )
    return ImportSkippedItem(
        source_item_type=f"1password_1pux:{category_uuid}",
        source_label=title,
        reason_code="unsupported_item_type",
        reason="This item type is not part of the phase-1 importer scope.",
    )


def _parse_1pux_login_item(
    *,
    title: str,
    overview: dict[str, Any],
    details: dict[str, Any],
    source_item_id: str | None,
) -> ImportCandidateItem | None:
    login_fields = details.get("loginFields")
    if not isinstance(login_fields, list) or not login_fields:
        return None

    username = None
    email = None
    password = None
    for raw_field in login_fields:
        if not isinstance(raw_field, dict):
            continue
        designation = str(raw_field.get("designation") or "").strip().lower()
        value = _1pux_field_value_to_string(raw_field.get("value"))
        if not value:
            continue
        field_name = _normalize_key(raw_field.get("name") or raw_field.get("id"))
        if email is None and field_name in {"email", "emailaddress"}:
            email = value
        if designation == "username" and username is None:
            username = value
        elif designation == "password" and password is None:
            password = value
        else:
            if username is None and field_name in LOGIN_FIELD_NAMES:
                username = value
            elif password is None and field_name in PASSWORD_FIELD_NAMES:
                password = value

    raw_login_url = str(overview.get("url") or "").strip() or _first_1pux_url(
        overview.get("urls")
    )
    site = _canonical_site_from_url(
        raw_login_url
    )
    if not site or not username or not password:
        return None

    warnings: list[ImportWarning] = []
    if _1pux_item_contains_otp(details):
        warnings.append(
            ImportWarning(
                code="totp_deferred",
                message=(
                    "This login includes a one-time password value, but TOTP import is "
                    "deferred until a follow-on release."
                ),
                source_label=title,
            )
        )

    safe_metadata: dict[str, Any] = {
        "site": site,
        "username": username,
    }
    if email and email != username:
        safe_metadata["email"] = email
    if raw_login_url:
        safe_metadata["login_url"] = raw_login_url
    notes_plain = str(details.get("notesPlain") or "").strip()
    if notes_plain:
        warnings.append(
            ImportWarning(
                code="notes_deferred",
                message=(
                    "This login includes notes, but note import is deferred because "
                    "notes can contain secrets."
                ),
                source_label=title,
            )
        )
    return ImportCandidateItem(
        kind="login_secret",
        title=title or site,
        safe_metadata=safe_metadata,
        protected_fields={"password": password},
        source_item_type="1password_1pux:login",
        source_label=title or site,
        source_item_id=source_item_id,
        warnings=warnings,
    )


def _parse_1pux_payment_card_item(
    *,
    title: str,
    overview: dict[str, Any],
    details: dict[str, Any],
    account_name: str,
    source_item_id: str | None,
) -> ImportCandidateItem | None:
    flattened_fields = _flatten_1pux_section_fields(details)
    if not flattened_fields:
        return None
    pan = _find_first_matching_field(flattened_fields, CARD_NUMBER_FIELD_NAMES)
    expiry = _find_first_matching_field(flattened_fields, CARD_EXPIRY_FIELD_NAMES)
    if not pan or not expiry:
        return None
    parsed_expiry = _parse_month_year(expiry)
    if parsed_expiry is None:
        return None
    brand = _find_first_matching_field(flattened_fields, CARD_BRAND_FIELD_NAMES)
    if not brand:
        brand = _derive_card_brand(pan)
    cardholder_name = _find_first_matching_field(flattened_fields, CARDHOLDER_FIELD_NAMES)
    if not cardholder_name:
        cardholder_name = account_name or None
    if not brand or not cardholder_name:
        return None
    safe_metadata: dict[str, Any] = {
        "brand": brand,
        "cardholder_name": cardholder_name,
        "expiry_month": parsed_expiry["month"],
        "expiry_year": parsed_expiry["year"],
    }
    billing_zip = _find_first_matching_field(flattened_fields, CARD_BILLING_ZIP_FIELD_NAMES)
    if billing_zip:
        safe_metadata["billing_zip"] = billing_zip
    protected_fields: dict[str, Any] = {"pan": pan}
    cvv = _find_first_matching_field(flattened_fields, CARD_CVV_FIELD_NAMES)
    if cvv:
        protected_fields["cvv"] = cvv
    return ImportCandidateItem(
        kind="payment_card",
        title=title or f"{brand} **** {re.sub(r'\\D', '', pan)[-4:]}",
        safe_metadata=safe_metadata,
        protected_fields=protected_fields,
        source_item_type="1password_1pux:payment_card",
        source_label=title or brand,
        source_item_id=source_item_id,
    )


def _normalize_csv_row(row: dict[str, Any]) -> dict[str, str]:
    normalized: dict[str, str] = {}
    for key, value in row.items():
        normalized_key = _normalize_key(key)
        if not normalized_key:
            continue
        normalized[normalized_key] = str(value or "").strip()
    return normalized


def _normalize_key(value: Any) -> str:
    text = str(value or "").strip().lower()
    if not text:
        return ""
    return re.sub(r"[^a-z0-9]+", "", text)


def _is_truthy(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in TRUE_VALUES


def _canonical_site_from_url(value: str | None) -> str | None:
    candidate = str(value or "").strip()
    if not candidate:
        return None
    parsed = urlparse(candidate if "://" in candidate else f"https://{candidate}")
    host = parsed.netloc or parsed.path
    host = host.strip().lower()
    return host or None


def _first_1pux_url(raw_urls: Any) -> str | None:
    if not isinstance(raw_urls, list):
        return None
    for entry in raw_urls:
        if not isinstance(entry, dict):
            continue
        url = str(entry.get("url") or "").strip()
        if url:
            return url
    return None


def _1pux_field_value_to_string(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    if isinstance(value, dict):
        for key in (
            "concealed",
            "string",
            "value",
            "email",
            "url",
            "phone",
            "reference",
            "totp",
            "monthYear",
            "monthyear",
        ):
            if key in value:
                nested = value.get(key)
                if isinstance(nested, str) and nested.strip():
                    return nested.strip()
        return None
    return None


def _flatten_1pux_section_fields(details: dict[str, Any]) -> list[dict[str, str]]:
    sections = details.get("sections")
    if not isinstance(sections, list):
        return []
    flattened: list[dict[str, str]] = []
    for section in sections:
        if not isinstance(section, dict):
            continue
        fields = section.get("fields")
        if not isinstance(fields, list):
            continue
        for field in fields:
            if not isinstance(field, dict):
                continue
            value = _1pux_field_value_to_string(field.get("value"))
            if not value:
                continue
            flattened.append(
                {
                    "key": _normalize_key(field.get("id") or field.get("title")),
                    "title": str(field.get("title") or "").strip(),
                    "value": value,
                }
            )
    return flattened


def _find_first_matching_field(
    flattened_fields: list[dict[str, str]],
    field_names: set[str],
) -> str | None:
    for field in flattened_fields:
        key = field.get("key", "")
        if key in field_names:
            return str(field.get("value") or "").strip() or None
    for field in flattened_fields:
        title_key = _normalize_key(field.get("title"))
        if title_key in field_names:
            return str(field.get("value") or "").strip() or None
    return None


def _parse_month_year(value: str) -> dict[str, int] | None:
    normalized = re.sub(r"\s+", "", value)
    match = MONTH_YEAR_RE.fullmatch(normalized)
    if match is None:
        return None
    year = int(match.group("year"))
    month = int(match.group("month"))
    if not 1 <= month <= 12:
        return None
    return {"year": year, "month": month}


def _derive_card_brand(pan: str) -> str | None:
    digits = re.sub(r"\D", "", pan)
    if not digits:
        return None
    if digits.startswith("4"):
        return "Visa"
    if re.match(r"^5[1-5]", digits) or re.match(r"^2(2[2-9]|[3-6]|7[01]|720)", digits):
        return "Mastercard"
    if re.match(r"^3[47]", digits):
        return "American Express"
    if digits.startswith("6"):
        return "Discover"
    return None


def _1pux_item_contains_otp(details: dict[str, Any]) -> bool:
    for field in _flatten_1pux_section_fields(details):
        key = field.get("key", "")
        title_key = _normalize_key(field.get("title"))
        if key in OTP_FIELD_NAMES or title_key in OTP_FIELD_NAMES:
            return True
    return False


def _flatten_1pux_search_text(payload: Any) -> str:
    parts: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for nested in value.values():
                walk(nested)
            return
        if isinstance(value, list):
            for nested in value:
                walk(nested)
            return
        if isinstance(value, str):
            parts.append(value.lower())

    walk(payload)
    return " ".join(parts)
