from __future__ import annotations

from contextlib import AbstractAsyncContextManager, asynccontextmanager
from dataclasses import dataclass
from typing import Any, Callable

import httpx


AsyncClientFactory = Callable[[], AbstractAsyncContextManager[httpx.AsyncClient]]

DEFAULT_CORE_TIMEOUT_SECONDS = 60.0


class SkylineCoreAPIError(RuntimeError):
    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message


@dataclass(slots=True)
class RequesterCoreClientConfig:
    core_base_url: str
    access_token: str
    default_session_id: str
    timeout_seconds: float


class SkylineCoreHTTPClient:
    def __init__(
        self,
        config: RequesterCoreClientConfig,
        *,
        client_factory: AsyncClientFactory | None = None,
        access_token_resolver: Callable[[], str] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        self.config = config
        self._client_factory = client_factory or self._default_client_factory
        self._access_token_resolver = access_token_resolver
        self._extra_headers = dict(extra_headers or {})

    @asynccontextmanager
    async def _default_client_factory(self) -> Any:
        async with httpx.AsyncClient(
            base_url=self.config.core_base_url,
            timeout=self.config.timeout_seconds,
        ) as client:
            yield client

    def _current_access_token(self) -> str:
        if self._access_token_resolver is not None:
            resolved = self._access_token_resolver().strip()
            if resolved:
                return resolved
        configured = self.config.access_token.strip()
        if configured:
            return configured
        raise RuntimeError("requester bearer token is not available for this request")

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        headers = {"Authorization": f"Bearer {self._current_access_token()}"}
        headers.update(self._extra_headers)
        async with self._client_factory() as client:
            response = await client.request(
                method,
                path,
                params=params,
                json=json,
                headers=headers,
            )
        if response.status_code >= 400:
            raise SkylineCoreAPIError(response.status_code, _response_error_message(response))

        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError("core returned a non-object JSON payload")
        return payload


def _response_error_message(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except ValueError:
        text = response.text.strip()
        return text or f"core returned HTTP {response.status_code}"

    if isinstance(payload, dict):
        error_message = payload.get("error")
        if isinstance(error_message, str) and error_message.strip():
            return error_message
    return f"core returned HTTP {response.status_code}"
