from __future__ import annotations

import base64
import hashlib
import json
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


LOCAL_IDENTITY_KEY_ALGORITHM_ED25519 = "ed25519"
LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256 = "p256_ecdsa_sha256"
LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE = "p256_secure_enclave_signing_sha256"
LOCAL_IDENTITY_KEY_ALGORITHM = LOCAL_IDENTITY_KEY_ALGORITHM_ED25519
SUPPORTED_LOCAL_IDENTITY_KEY_ALGORITHMS = {
    LOCAL_IDENTITY_KEY_ALGORITHM_ED25519,
    LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256,
    LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
}
REQUESTER_APP_REQUEST_MAX_AGE_MS = 5 * 60 * 1000


def _b64encode(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _b64decode(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"))


def fingerprint_public_key(public_key: str) -> str:
    return hashlib.sha256(_b64decode(public_key)).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical_json_dumps(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def canonical_query_string(params: Mapping[str, Any] | None) -> str:
    if not params:
        return ""
    pairs: list[tuple[str, str]] = []
    for raw_key, raw_value in params.items():
        key = str(raw_key)
        if isinstance(raw_value, (list, tuple)):
            for item in raw_value:
                pairs.append((key, "" if item is None else str(item)))
        else:
            pairs.append((key, "" if raw_value is None else str(raw_value)))
    pairs.sort()
    return "&".join(f"{key}={value}" for key, value in pairs)


def build_requester_request_proof_message(
    *,
    seeded_machine_id: str,
    requester_app_principal_id: str,
    method: str,
    path: str,
    query_string: str,
    body_sha256: str,
    timestamp_ms: int,
    nonce: str,
) -> str:
    return canonical_json_dumps(
        {
            "body_sha256": body_sha256,
            "requester_app_principal_id": requester_app_principal_id,
            "method": method.upper(),
            "nonce": nonce,
            "path": path,
            "query_string": query_string,
            "seeded_machine_id": seeded_machine_id,
            "timestamp_ms": int(timestamp_ms),
        }
    )


def generate_local_identity_keypair() -> dict[str, str]:
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    public_key_b64 = _b64encode(public_bytes)
    fingerprint = fingerprint_public_key(public_key_b64)
    return {
        "algorithm": LOCAL_IDENTITY_KEY_ALGORITHM,
        "private_key": _b64encode(private_bytes),
        "public_key": public_key_b64,
        "key_id": fingerprint[:16],
        "key_fingerprint": fingerprint,
    }


def generate_p256_software_identity_keypair() -> dict[str, str]:
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    public_key_b64 = _b64encode(public_bytes)
    fingerprint = fingerprint_public_key(public_key_b64)
    return {
        "algorithm": LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256,
        "private_key": _b64encode(private_bytes),
        "public_key": public_key_b64,
        "key_id": fingerprint[:16],
        "key_fingerprint": fingerprint,
    }


def validate_local_identity_key_algorithm(key_algorithm: str) -> str:
    normalized = str(key_algorithm or "").strip()
    if normalized not in SUPPORTED_LOCAL_IDENTITY_KEY_ALGORITHMS:
        raise ValueError(
            "unsupported local identity key_algorithm "
            f"'{normalized or '<empty>'}'; expected one of: "
            + ", ".join(sorted(SUPPORTED_LOCAL_IDENTITY_KEY_ALGORITHMS))
        )
    return normalized


def validate_local_identity_public_key(*, public_key: str, key_algorithm: str) -> None:
    normalized_algorithm = validate_local_identity_key_algorithm(key_algorithm)
    try:
        if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_ED25519:
            Ed25519PublicKey.from_public_bytes(_b64decode(public_key))
            return
        if normalized_algorithm in {
            LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256,
            LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        }:
            _load_p256_public_key(public_key)
            return
    except Exception as error:
        raise ValueError(
            f"invalid public_key for local identity key_algorithm '{normalized_algorithm}'"
        ) from error
    raise ValueError(f"unsupported local identity key_algorithm '{normalized_algorithm}'")


def sign_local_identity_message(
    *,
    private_key: str,
    message: str,
    key_algorithm: str = LOCAL_IDENTITY_KEY_ALGORITHM_ED25519,
) -> str:
    normalized_algorithm = validate_local_identity_key_algorithm(key_algorithm)
    if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_ED25519:
        private_key_obj = Ed25519PrivateKey.from_private_bytes(_b64decode(private_key))
        signature = private_key_obj.sign(message.encode("utf-8"))
        return _b64encode(signature)
    if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256:
        private_key_obj = serialization.load_der_private_key(
            _b64decode(private_key),
            password=None,
        )
        if not isinstance(private_key_obj, ec.EllipticCurvePrivateKey):
            raise ValueError("P-256 local identity private key was not an EC key")
        signature = private_key_obj.sign(message.encode("utf-8"), ec.ECDSA(hashes.SHA256()))
        return _b64encode(signature)
    raise ValueError(
        f"local signing for key_algorithm '{normalized_algorithm}' requires a hardware backend"
    )


def _load_p256_public_key(public_key: str) -> ec.EllipticCurvePublicKey:
    public_bytes = _b64decode(public_key)
    if len(public_bytes) == 64:
        public_bytes = b"\x04" + public_bytes
    loaded = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), public_bytes)
    return loaded


def verify_local_identity_signature(
    *,
    public_key: str,
    message: str,
    signature: str,
    key_algorithm: str = LOCAL_IDENTITY_KEY_ALGORITHM_ED25519,
) -> bool:
    try:
        normalized_algorithm = validate_local_identity_key_algorithm(key_algorithm)
        if normalized_algorithm == LOCAL_IDENTITY_KEY_ALGORITHM_ED25519:
            public_key_obj = Ed25519PublicKey.from_public_bytes(_b64decode(public_key))
            public_key_obj.verify(_b64decode(signature), message.encode("utf-8"))
        elif normalized_algorithm in {
            LOCAL_IDENTITY_KEY_ALGORITHM_P256_ECDSA_SHA256,
            LOCAL_IDENTITY_KEY_ALGORITHM_P256_SECURE_ENCLAVE,
        }:
            public_key_obj = _load_p256_public_key(public_key)
            public_key_obj.verify(
                _b64decode(signature),
                message.encode("utf-8"),
                ec.ECDSA(hashes.SHA256()),
            )
        else:
            return False
    except InvalidSignature:
        return False
    except Exception:
        return False
    return True
