from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

from .delivery_crypto import open_sealed_payload
from .secret_custody import StoredBlindSecretPackage, decrypt_stored_blind_secret_package


HELPER_TRUST_TIER_RELEASE = "release"
HELPER_TRUST_TIER_DEVELOPMENT = "development"
SUPPORTED_HELPER_TRUST_TIERS = {
    HELPER_TRUST_TIER_DEVELOPMENT,
    HELPER_TRUST_TIER_RELEASE,
}

# Helper credential custody is intentionally a narrow requester-side OS adapter.
# Keep macOS/Linux storage differences here instead of leaking them into core
# vault semantics or same-machine shortcuts.
CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN = "macos_keychain"
CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE = "linux_secret_service"
CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE = "linux_encrypted_file"
SUPPORTED_CREDENTIAL_STORAGE_BACKENDS = {
    CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE,
    CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE,
    CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN,
}

HELPER_STORAGE_BACKEND_ENV_VAR = "SKYLINE_HELPER_STORAGE_BACKEND"
HELPER_BOOTSTRAP_SECRET_ENV_VAR = "SKYLINE_HELPER_BOOTSTRAP_SECRET"
_PBKDF2_ITERATIONS = 600_000
OWNER_ONLY_DIR_MODE = 0o700
OWNER_ONLY_FILE_MODE = 0o600


@dataclass(slots=True)
class HelperSecrets:
    access_token: str
    private_key: str
    secret_unwrap_private_key: str


@dataclass(slots=True)
class HelperSecurityContext:
    metadata: dict[str, Any]
    secrets: HelperSecrets
    credential_storage_backend: str
    trust_tier: str


class HelperSecurityError(RuntimeError):
    pass


def ensure_owner_only_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        path.chmod(OWNER_ONLY_DIR_MODE)
    except OSError as error:
        raise HelperSecurityError(
            f"failed to lock down local Skyline directory {path}: {error}"
        ) from error


def harden_existing_file(path: Path) -> None:
    if not path.exists() or path.is_symlink() or not path.is_file():
        return
    try:
        path.chmod(OWNER_ONLY_FILE_MODE)
    except OSError as error:
        raise HelperSecurityError(
            f"failed to lock down local Skyline file {path}: {error}"
        ) from error


def write_owner_only_text(path: Path, text: str, *, encoding: str = "utf-8") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_name: str | None = None
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=str(path.parent),
        text=True,
    )
    try:
        with os.fdopen(fd, "w", encoding=encoding) as handle:
            handle.write(text)
        os.chmod(tmp_name, OWNER_ONLY_FILE_MODE)
        os.replace(tmp_name, path)
        tmp_name = None
        path.chmod(OWNER_ONLY_FILE_MODE)
    finally:
        if tmp_name is not None:
            try:
                Path(tmp_name).unlink()
            except FileNotFoundError:
                pass


class HelperCredentialStore:
    backend_name: str

    def load(self) -> dict[str, str] | None:
        raise NotImplementedError

    def save(self, payload: dict[str, str]) -> None:
        raise NotImplementedError

    def clear(self) -> None:
        raise NotImplementedError


SUPPORTED_HELPER_SECRET_KEYS = {
    "access_token",
    "private_key",
    "secret_unwrap_private_key",
}
LEGACY_HELPER_SECRET_KEYS = {
    "requester_access_token",
}


def _normalize_secret_payload(payload: dict[str, str]) -> dict[str, str]:
    normalized: dict[str, str] = {}
    for key, value in payload.items():
        key_text = str(key).strip()
        if key_text not in SUPPORTED_HELPER_SECRET_KEYS:
            continue
        value_text = str(value).strip()
        if value_text:
            normalized[key_text] = value_text
    return normalized


def _normalize_metadata_defaults(
    metadata: dict[str, Any],
) -> dict[str, Any]:
    normalized = dict(metadata)
    slots = normalized.get("slots")
    normalized["slots"] = dict(slots) if isinstance(slots, dict) else {}
    return normalized


def load_helper_metadata(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"slots": {}}
    harden_existing_file(path)
    return _normalize_metadata_defaults(json.loads(path.read_text()))


def save_helper_metadata(path: Path, metadata: dict[str, Any]) -> None:
    persisted = {
        key: value
        for key, value in _normalize_metadata_defaults(metadata).items()
        if key not in SUPPORTED_HELPER_SECRET_KEYS
        and key not in LEGACY_HELPER_SECRET_KEYS
    }
    write_owner_only_text(path, json.dumps(persisted, indent=2, sort_keys=True) + "\n")


def require_metadata(metadata: dict[str, Any], *keys: str) -> None:
    missing = [key for key in keys if not str(metadata.get(key) or "").strip()]
    if missing:
        raise HelperSecurityError("helper config is missing: " + ", ".join(missing))


def request_json(
    *,
    method: str,
    base_url: str,
    path: str,
    access_token: str | None = None,
    extra_headers: dict[str, str] | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    headers: dict[str, str] = dict(extra_headers or {})
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    response = httpx.request(
        method,
        base_url.rstrip("/") + path,
        headers=headers,
        json=json_body,
        timeout=30.0,
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise HelperSecurityError("expected object response from Skyline core")
    return payload


def ack_delivery_job(
    *,
    metadata: dict[str, Any],
    secrets: HelperSecrets,
    job_id: str,
    status: str,
    message: str | None,
    details: dict[str, Any] | None = None,
) -> None:
    request_json(
        method="POST",
        base_url=str(metadata["base_url"]),
        path=f"/v1/edge/delivery-jobs/{job_id}/ack",
        access_token=secrets.access_token,
        json_body={"status": status, "message": message, "details": details},
    )


def open_helper_delivery_envelope(
    *,
    envelope: dict[str, Any],
    secrets: HelperSecrets,
) -> dict[str, Any]:
    return open_sealed_payload(envelope, private_key=secrets.private_key)


def decrypt_helper_blind_secret_package(
    *,
    package: dict[str, Any],
    secrets: HelperSecrets,
    key_holder_id: str,
    key_version: int | None = None,
) -> str:
    if not secrets.secret_unwrap_private_key:
        raise HelperSecurityError(
            "helper secure storage is missing secret_unwrap_private_key; re-pair the helper"
        )
    return decrypt_stored_blind_secret_package(
        StoredBlindSecretPackage.from_json(dict(package)),
        private_key=secrets.secret_unwrap_private_key,
        key_holder_id=key_holder_id,
        key_version=key_version,
    )


def helper_trust_tier(
    *,
    component_kind: str | None,
    target_metadata: dict[str, Any] | None = None,
    extension_channel: str | None = None,
) -> str:
    metadata = dict(target_metadata or {})
    channel = str(extension_channel or metadata.get("extension_channel") or "").strip()
    if channel and (metadata.get("browser_companion") or metadata.get("extension_id")):
        if channel == HELPER_TRUST_TIER_RELEASE:
            return HELPER_TRUST_TIER_RELEASE
        return HELPER_TRUST_TIER_DEVELOPMENT
    return HELPER_TRUST_TIER_RELEASE


def helper_posture_hash(
    *,
    helper_id: str,
    component_kind: str,
    target_kind: str,
    target_metadata: dict[str, Any] | None = None,
    browser_context: dict[str, Any] | None = None,
    trust_tier: str | None = None,
) -> str:
    posture = {
        "helper_id": helper_id,
        "component_kind": component_kind,
        "target_kind": target_kind,
        "target_metadata": dict(target_metadata or {}),
        "browser_context_identity": {
            key: browser_context.get(key)
            for key in (
                "browser_channel_id",
                "browser_name",
                "profile_label",
                "extension_id",
                "extension_channel",
                "extension_version",
            )
        }
        if isinstance(browser_context, dict)
        else None,
        "trust_tier": trust_tier or helper_trust_tier(
            component_kind=component_kind,
            target_metadata=target_metadata,
            extension_channel=(
                browser_context.get("extension_channel")
                if isinstance(browser_context, dict)
                else None
            ),
        ),
    }
    canonical = json.dumps(posture, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def browser_context_id(browser_context: dict[str, Any]) -> str:
    canonical = json.dumps(
        {
            key: browser_context.get(key)
            for key in (
                "delivery_target_id",
                "browser_channel_id",
                "tab_id",
                "window_id",
                "page_url",
                "frame_id",
                "frame_origin",
                "form_session_id",
            )
        },
        separators=(",", ":"),
        sort_keys=True,
    )
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"browserctx_{digest[:24]}"


def build_one_time_challenge(
    *,
    destination_context: dict[str, Any],
    ttl_ms: int,
    now_epoch_ms: int,
) -> dict[str, Any]:
    return {
        "challenge_id": f"challenge_{uuid.uuid4().hex}",
        "challenge_nonce": uuid.uuid4().hex,
        "destination_context": dict(destination_context),
        "destination_context_hash": hashlib.sha256(
            json.dumps(destination_context, separators=(",", ":"), sort_keys=True).encode(
                "utf-8"
            )
        ).hexdigest(),
        "created_at_epoch_ms": now_epoch_ms,
        "expires_at_epoch_ms": now_epoch_ms + ttl_ms,
    }


def linux_secret_service_available() -> bool:
    return shutil.which("secret-tool") is not None and bool(
        os.environ.get("DBUS_SESSION_BUS_ADDRESS")
        or os.environ.get("DISPLAY")
        or os.environ.get("WAYLAND_DISPLAY")
        or os.environ.get("XDG_CURRENT_DESKTOP")
    )


def linux_desktop_session_available() -> bool:
    return bool(
        os.environ.get("DBUS_SESSION_BUS_ADDRESS")
        or os.environ.get("DISPLAY")
        or os.environ.get("WAYLAND_DISPLAY")
        or os.environ.get("XDG_CURRENT_DESKTOP")
    )


def bootstrap_secret_from_sources(
    bootstrap_secret_file: str | None = None,
) -> str | None:
    env_secret = os.environ.get(HELPER_BOOTSTRAP_SECRET_ENV_VAR, "").strip()
    if env_secret:
        return env_secret
    if bootstrap_secret_file:
        path = Path(bootstrap_secret_file).expanduser()
        if path.exists():
            return path.read_text().strip() or None
    return None


def resolve_credential_storage_backend(
    *,
    helper_kind: str,
    config_path: Path,
    bootstrap_secret_file: str | None = None,
) -> str:
    override = os.environ.get(HELPER_STORAGE_BACKEND_ENV_VAR, "").strip()
    if override:
        if override not in SUPPORTED_CREDENTIAL_STORAGE_BACKENDS:
            raise HelperSecurityError(
                f"unsupported {HELPER_STORAGE_BACKEND_ENV_VAR} override "
                f"'{override}'; expected one of: "
                + ", ".join(sorted(SUPPORTED_CREDENTIAL_STORAGE_BACKENDS))
            )
        return override

    if sys.platform == "darwin":
        return CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN

    if sys.platform.startswith("linux"):
        if linux_secret_service_available():
            return CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE
        bootstrap_secret = bootstrap_secret_from_sources(bootstrap_secret_file)
        if bootstrap_secret:
            return CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE
        raise HelperSecurityError(
            "CLI helpers on headless Linux require Secret Service or "
            f"{HELPER_BOOTSTRAP_SECRET_ENV_VAR}/--bootstrap-secret-file"
        )

    raise HelperSecurityError(
        "helper credential storage currently supports macOS or Linux only"
    )


def validate_runtime_environment(
    *,
    helper_kind: str,
    credential_storage_backend: str,
) -> None:
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN:
        if shutil.which("security") is None:
            raise HelperSecurityError("macOS helper storage requires the `security` command")
        return
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE:
        if shutil.which("secret-tool") is None:
            raise HelperSecurityError("Linux helper storage requires `secret-tool`")
        return
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE:
        return
    raise HelperSecurityError(
        "unsupported credential storage backend "
        f"'{credential_storage_backend}'"
    )


def _run_subprocess(
    args: list[str],
    *,
    input_text: str | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        input=input_text,
        capture_output=True,
        check=False,
        text=True,
    )


def _secret_store_account(config_path: Path, helper_kind: str) -> str:
    resolved = str(config_path.expanduser().resolve())
    digest = hashlib.sha256(resolved.encode("utf-8")).hexdigest()[:20]
    return f"{helper_kind}:{digest}"


def encrypted_credential_state_path(config_path: Path) -> Path:
    return config_path.with_suffix(config_path.suffix + ".credentials.enc")


class MacOSKeychainCredentialStore(HelperCredentialStore):
    backend_name = CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN

    def __init__(self, *, config_path: Path, helper_kind: str) -> None:
        self._account = _secret_store_account(config_path, helper_kind)
        self._service = "Skyline Helper Credentials"

    def load(self) -> dict[str, str] | None:
        completed = _run_subprocess(
            [
                "security",
                "find-generic-password",
                "-a",
                self._account,
                "-s",
                self._service,
                "-w",
            ]
        )
        if completed.returncode != 0:
            stderr = (completed.stderr or "").lower()
            if "could not be found" in stderr or "item could not be found" in stderr:
                return None
            raise HelperSecurityError(
                "failed to read helper credentials from macOS Keychain: "
                + (completed.stderr.strip() or completed.stdout.strip() or "unknown error")
            )
        payload = json.loads(completed.stdout.strip() or "{}")
        if not isinstance(payload, dict):
            raise HelperSecurityError("macOS Keychain payload was not a JSON object")
        return {str(key): str(value) for key, value in payload.items()}

    def save(self, payload: dict[str, str]) -> None:
        completed = _run_subprocess(
            [
                "security",
                "add-generic-password",
                "-a",
                self._account,
                "-s",
                self._service,
                "-U",
                "-w",
                json.dumps(payload, separators=(",", ":"), sort_keys=True),
            ]
        )
        if completed.returncode != 0:
            raise HelperSecurityError(
                "failed to write helper credentials to macOS Keychain: "
                + (completed.stderr.strip() or completed.stdout.strip() or "unknown error")
            )

    def clear(self) -> None:
        completed = _run_subprocess(
            [
                "security",
                "delete-generic-password",
                "-a",
                self._account,
                "-s",
                self._service,
            ]
        )
        if completed.returncode != 0:
            stderr = (completed.stderr or "").lower()
            if "could not be found" in stderr or "item could not be found" in stderr:
                return
            raise HelperSecurityError(
                "failed to clear helper credentials from macOS Keychain: "
                + (completed.stderr.strip() or completed.stdout.strip() or "unknown error")
            )


class LinuxSecretServiceCredentialStore(HelperCredentialStore):
    backend_name = CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE

    def __init__(self, *, config_path: Path, helper_kind: str) -> None:
        self._helper_kind = helper_kind
        self._config_path = str(config_path.expanduser().resolve())
        self._label = f"Skyline {helper_kind} credentials"

    def load(self) -> dict[str, str] | None:
        completed = _run_subprocess(
            [
                "secret-tool",
                "lookup",
                "skyline-helper-kind",
                self._helper_kind,
                "skyline-config-path",
                self._config_path,
            ]
        )
        if completed.returncode != 0:
            return None
        payload = json.loads(completed.stdout.strip() or "{}")
        if not isinstance(payload, dict):
            raise HelperSecurityError("Linux Secret Service payload was not a JSON object")
        return {str(key): str(value) for key, value in payload.items()}

    def save(self, payload: dict[str, str]) -> None:
        completed = _run_subprocess(
            [
                "secret-tool",
                "store",
                "--label",
                self._label,
                "skyline-helper-kind",
                self._helper_kind,
                "skyline-config-path",
                self._config_path,
            ],
            input_text=json.dumps(payload, separators=(",", ":"), sort_keys=True),
        )
        if completed.returncode != 0:
            raise HelperSecurityError(
                "failed to write helper credentials to Secret Service: "
                + (completed.stderr.strip() or completed.stdout.strip() or "unknown error")
            )

    def clear(self) -> None:
        _run_subprocess(
            [
                "secret-tool",
                "clear",
                "skyline-helper-kind",
                self._helper_kind,
                "skyline-config-path",
                self._config_path,
            ]
        )


class LinuxEncryptedFileCredentialStore(HelperCredentialStore):
    backend_name = CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE

    def __init__(
        self,
        *,
        config_path: Path,
        bootstrap_secret: str,
    ) -> None:
        if not bootstrap_secret.strip():
            raise HelperSecurityError(
                "encrypted-file helper storage requires a non-empty bootstrap secret"
            )
        self._state_path = encrypted_credential_state_path(config_path)
        self._bootstrap_secret = bootstrap_secret

    def _derive_key(self, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=_PBKDF2_ITERATIONS,
        )
        return kdf.derive(self._bootstrap_secret.encode("utf-8"))

    def load(self) -> dict[str, str] | None:
        if not self._state_path.exists():
            return None
        harden_existing_file(self._state_path)
        payload = json.loads(self._state_path.read_text())
        salt = base64.b64decode(payload["salt"])
        nonce = base64.b64decode(payload["nonce"])
        ciphertext = base64.b64decode(payload["ciphertext"])
        plaintext = AESGCM(self._derive_key(salt)).decrypt(nonce, ciphertext, None)
        decoded = json.loads(plaintext.decode("utf-8"))
        if not isinstance(decoded, dict):
            raise HelperSecurityError("encrypted credential payload was not a JSON object")
        return {str(key): str(value) for key, value in decoded.items()}

    def save(self, payload: dict[str, str]) -> None:
        salt = os.urandom(16)
        nonce = os.urandom(12)
        plaintext = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode(
            "utf-8"
        )
        ciphertext = AESGCM(self._derive_key(salt)).encrypt(nonce, plaintext, None)
        write_owner_only_text(
            self._state_path,
            json.dumps(
                {
                    "salt": base64.b64encode(salt).decode("ascii"),
                    "nonce": base64.b64encode(nonce).decode("ascii"),
                    "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
        )

    def clear(self) -> None:
        if self._state_path.exists():
            self._state_path.unlink()


def create_credential_store(
    *,
    config_path: Path,
    helper_kind: str,
    credential_storage_backend: str,
    bootstrap_secret_file: str | None = None,
) -> HelperCredentialStore:
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_MACOS_KEYCHAIN:
        return MacOSKeychainCredentialStore(
            config_path=config_path,
            helper_kind=helper_kind,
        )
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_LINUX_SECRET_SERVICE:
        return LinuxSecretServiceCredentialStore(
            config_path=config_path,
            helper_kind=helper_kind,
        )
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE:
        bootstrap_secret = bootstrap_secret_from_sources(bootstrap_secret_file)
        if bootstrap_secret is None:
            raise HelperSecurityError(
                "encrypted-file helper storage requires "
                f"{HELPER_BOOTSTRAP_SECRET_ENV_VAR} or --bootstrap-secret-file"
            )
        return LinuxEncryptedFileCredentialStore(
            config_path=config_path,
            bootstrap_secret=bootstrap_secret,
        )
    raise HelperSecurityError(
        "unsupported credential storage backend "
        f"'{credential_storage_backend}'"
    )


def clear_stored_credentials(
    *,
    config_path: Path,
    helper_kind: str,
    credential_storage_backend: str,
    bootstrap_secret_file: str | None = None,
) -> None:
    if credential_storage_backend == CREDENTIAL_STORAGE_BACKEND_LINUX_ENCRYPTED_FILE:
        encrypted_path = encrypted_credential_state_path(config_path)
        if encrypted_path.exists():
            encrypted_path.unlink()
        return
    validate_runtime_environment(
        helper_kind=helper_kind,
        credential_storage_backend=credential_storage_backend,
    )
    store = create_credential_store(
        config_path=config_path,
        helper_kind=helper_kind,
        credential_storage_backend=credential_storage_backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    store.clear()


def persist_helper_credentials(
    *,
    config_path: Path,
    helper_kind: str,
    metadata: dict[str, Any],
    secrets: dict[str, str],
    bootstrap_secret_file: str | None = None,
) -> tuple[dict[str, Any], str]:
    backend = resolve_credential_storage_backend(
        helper_kind=helper_kind,
        config_path=config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    validate_runtime_environment(
        helper_kind=helper_kind,
        credential_storage_backend=backend,
    )
    store = create_credential_store(
        config_path=config_path,
        helper_kind=helper_kind,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    merged_payload = _normalize_secret_payload(store.load() or {})
    merged_payload.update(
        _normalize_secret_payload({str(key): str(value) for key, value in secrets.items()})
    )
    store.save(merged_payload)
    updated_metadata = dict(metadata)
    updated_metadata["credential_storage_backend"] = backend
    save_helper_metadata(config_path, updated_metadata)
    return updated_metadata, backend


def update_helper_credentials(
    *,
    config_path: Path,
    helper_kind: str,
    metadata: dict[str, Any],
    secrets: dict[str, str | None],
    bootstrap_secret_file: str | None = None,
) -> tuple[dict[str, Any], str]:
    backend = resolve_credential_storage_backend(
        helper_kind=helper_kind,
        config_path=config_path,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    validate_runtime_environment(
        helper_kind=helper_kind,
        credential_storage_backend=backend,
    )
    store = create_credential_store(
        config_path=config_path,
        helper_kind=helper_kind,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )
    payload = _normalize_secret_payload(store.load() or {})
    for key, value in secrets.items():
        key_text = str(key).strip()
        if key_text not in SUPPORTED_HELPER_SECRET_KEYS:
            continue
        normalized = str(value or "").strip()
        if normalized:
            payload[key_text] = normalized
        else:
            payload.pop(key_text, None)
    store.save(payload)
    updated_metadata = dict(metadata)
    updated_metadata["credential_storage_backend"] = backend
    save_helper_metadata(config_path, updated_metadata)
    return updated_metadata, backend


def load_helper_security_context(
    *,
    config_path: Path,
    helper_kind: str,
    required_metadata_keys: tuple[str, ...],
    bootstrap_secret_file: str | None = None,
) -> HelperSecurityContext:
    metadata = load_helper_metadata(config_path)
    require_metadata(metadata, *required_metadata_keys)
    configured_backend = str(metadata.get("credential_storage_backend") or "").strip()
    if configured_backend:
        backend = configured_backend
    else:
        backend = resolve_credential_storage_backend(
            helper_kind=helper_kind,
            config_path=config_path,
            bootstrap_secret_file=bootstrap_secret_file,
        )
        metadata["credential_storage_backend"] = backend
        save_helper_metadata(config_path, metadata)
    validate_runtime_environment(
        helper_kind=helper_kind,
        credential_storage_backend=backend,
    )
    store = create_credential_store(
        config_path=config_path,
        helper_kind=helper_kind,
        credential_storage_backend=backend,
        bootstrap_secret_file=bootstrap_secret_file,
    )

    migrated_access_token = str(metadata.pop("access_token", "") or "").strip()
    migrated_private_key = str(metadata.pop("private_key", "") or "").strip()
    migrated_secret_unwrap_private_key = str(
        metadata.pop("secret_unwrap_private_key", "") or ""
    ).strip()
    if migrated_access_token or migrated_private_key or migrated_secret_unwrap_private_key:
        if not (
            migrated_access_token
            and migrated_private_key
            and migrated_secret_unwrap_private_key
        ):
            raise HelperSecurityError(
                "legacy helper config contained incomplete credentials; re-pair the helper"
            )
        store.save(
            {
                "access_token": migrated_access_token,
                "private_key": migrated_private_key,
                "secret_unwrap_private_key": migrated_secret_unwrap_private_key,
            }
        )
        save_helper_metadata(config_path, metadata)

    payload = store.load()
    if payload is None:
        raise HelperSecurityError(
            "helper credentials were not found in secure storage; re-pair the helper"
        )
    normalized_payload = _normalize_secret_payload(payload)
    if normalized_payload != payload:
        store.save(normalized_payload)
        payload = normalized_payload
    secrets = HelperSecrets(
        access_token=str(payload.get("access_token") or "").strip(),
        private_key=str(payload.get("private_key") or "").strip(),
        secret_unwrap_private_key=str(
            payload.get("secret_unwrap_private_key") or ""
        ).strip(),
    )
    if (
        not secrets.access_token
        or not secrets.private_key
        or not secrets.secret_unwrap_private_key
    ):
        raise HelperSecurityError(
            "helper secure storage is missing access_token, private_key, or secret_unwrap_private_key; re-pair the helper"
        )
    metadata["credential_storage_backend"] = backend
    trust_tier = helper_trust_tier(
        component_kind=helper_kind,
        target_metadata=metadata,
        extension_channel=str(metadata.get("extension_channel") or "").strip() or None,
    )
    return HelperSecurityContext(
        metadata=metadata,
        secrets=secrets,
        credential_storage_backend=backend,
        trust_tier=trust_tier,
    )
