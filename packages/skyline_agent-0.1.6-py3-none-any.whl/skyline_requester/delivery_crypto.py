from __future__ import annotations

import base64
import hashlib
import json
import os
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


DELIVERY_KEY_ALGORITHM = "x25519_chacha20poly1305"
ADMIN_KEY_ALGORITHM = "p256_key_agreement_chacha20poly1305"
DELIVERY_ENVELOPE_VERSION = 1
X25519_ENVELOPE_HKDF_INFO = b"skyline-delivery-envelope-v1"
P256_ENVELOPE_HKDF_INFO = b"skyline-p256-recipient-envelope-v1"


def canonical_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def _b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64decode(data: str) -> bytes:
    padding = "=" * ((4 - len(data) % 4) % 4)
    return base64.urlsafe_b64decode((data + padding).encode("ascii"))


def fingerprint_public_key(public_key: str) -> str:
    return hashlib.sha256(_b64decode(public_key)).hexdigest()


def generate_keypair() -> dict[str, str]:
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    public_key_b64 = _b64encode(public_bytes)
    fingerprint = fingerprint_public_key(public_key_b64)
    return {
        "algorithm": DELIVERY_KEY_ALGORITHM,
        "private_key": _b64encode(private_bytes),
        "public_key": public_key_b64,
        "key_id": fingerprint[:16],
        "key_fingerprint": fingerprint,
    }


def generate_software_p256_test_keypair() -> dict[str, str]:
    """Generate an exportable P-256 keypair for tests and smoke scripts only.

    Production admin/root iOS keys must be generated and kept by Secure Enclave.
    """
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    public_key_b64 = _b64encode(public_bytes)
    fingerprint = fingerprint_public_key(public_key_b64)
    return {
        "algorithm": ADMIN_KEY_ALGORITHM,
        "private_key": _b64encode(private_bytes),
        "public_key": public_key_b64,
        "key_id": fingerprint[:16],
        "key_fingerprint": fingerprint,
    }


def validate_public_key_for_algorithm(public_key: str, *, algorithm: str) -> None:
    normalized_algorithm = str(algorithm or "").strip()
    try:
        public_bytes = _b64decode(str(public_key or "").strip())
    except Exception as error:
        raise ValueError(
            f"invalid public key for algorithm '{normalized_algorithm}'"
        ) from error

    try:
        if normalized_algorithm == DELIVERY_KEY_ALGORITHM:
            X25519PublicKey.from_public_bytes(public_bytes)
            return
        if normalized_algorithm == ADMIN_KEY_ALGORITHM:
            ec.EllipticCurvePublicKey.from_encoded_point(
                ec.SECP256R1(),
                public_bytes,
            )
            return
    except ValueError as error:
        raise ValueError(
            f"invalid public key for algorithm '{normalized_algorithm}'"
        ) from error
    raise ValueError(f"unsupported recipient key algorithm '{normalized_algorithm}'")


def seal_payload_to_public_key(
    public_key: str,
    payload: dict[str, Any],
    *,
    key_id: str,
    aad: dict[str, Any],
    algorithm: str = DELIVERY_KEY_ALGORITHM,
) -> dict[str, Any]:
    normalized_algorithm = str(algorithm or "").strip() or DELIVERY_KEY_ALGORITHM
    if normalized_algorithm == DELIVERY_KEY_ALGORITHM:
        return _seal_payload_to_x25519_public_key(
            public_key,
            payload,
            key_id=key_id,
            aad=aad,
        )
    if normalized_algorithm == ADMIN_KEY_ALGORITHM:
        return _seal_payload_to_p256_public_key(
            public_key,
            payload,
            key_id=key_id,
            aad=aad,
        )
    raise ValueError(f"unsupported recipient key algorithm '{normalized_algorithm}'")


def _seal_payload_to_x25519_public_key(
    public_key: str,
    payload: dict[str, Any],
    *,
    key_id: str,
    aad: dict[str, Any],
) -> dict[str, Any]:
    peer_key = X25519PublicKey.from_public_bytes(_b64decode(public_key))
    ephemeral_private_key = X25519PrivateKey.generate()
    ephemeral_public_key = ephemeral_private_key.public_key()
    shared_secret = ephemeral_private_key.exchange(peer_key)
    nonce = os.urandom(12)
    aad_bytes = canonical_json(aad).encode("utf-8")
    payload_bytes = canonical_json(payload).encode("utf-8")
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=X25519_ENVELOPE_HKDF_INFO,
    ).derive(shared_secret)
    ciphertext = ChaCha20Poly1305(derived_key).encrypt(
        nonce,
        payload_bytes,
        aad_bytes,
    )
    ephemeral_public_bytes = ephemeral_public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return {
        "version": DELIVERY_ENVELOPE_VERSION,
        "algorithm": DELIVERY_KEY_ALGORITHM,
        "key_id": key_id,
        "ephemeral_public_key": _b64encode(ephemeral_public_bytes),
        "nonce": _b64encode(nonce),
        "ciphertext": _b64encode(ciphertext),
        "aad": aad,
    }


def _seal_payload_to_p256_public_key(
    public_key: str,
    payload: dict[str, Any],
    *,
    key_id: str,
    aad: dict[str, Any],
) -> dict[str, Any]:
    peer_key = ec.EllipticCurvePublicKey.from_encoded_point(
        ec.SECP256R1(),
        _b64decode(public_key),
    )
    ephemeral_private_key = ec.generate_private_key(ec.SECP256R1())
    ephemeral_public_key = ephemeral_private_key.public_key()
    shared_secret = ephemeral_private_key.exchange(ec.ECDH(), peer_key)
    nonce = os.urandom(12)
    aad_bytes = canonical_json(aad).encode("utf-8")
    payload_bytes = canonical_json(payload).encode("utf-8")
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=P256_ENVELOPE_HKDF_INFO,
    ).derive(shared_secret)
    ciphertext = ChaCha20Poly1305(derived_key).encrypt(
        nonce,
        payload_bytes,
        aad_bytes,
    )
    ephemeral_public_bytes = ephemeral_public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    return {
        "version": DELIVERY_ENVELOPE_VERSION,
        "algorithm": ADMIN_KEY_ALGORITHM,
        "key_id": key_id,
        "ephemeral_public_key": _b64encode(ephemeral_public_bytes),
        "nonce": _b64encode(nonce),
        "ciphertext": _b64encode(ciphertext),
        "aad": aad,
    }


def open_sealed_payload(
    envelope: dict[str, Any],
    *,
    private_key: str,
) -> dict[str, Any]:
    algorithm = str(envelope.get("algorithm") or "").strip()
    aad = envelope.get("aad")
    if not isinstance(aad, dict):
        raise ValueError("delivery envelope is missing aad")
    ephemeral_public_key = str(envelope.get("ephemeral_public_key") or "").strip()
    nonce = str(envelope.get("nonce") or "").strip()
    ciphertext = str(envelope.get("ciphertext") or "").strip()
    if not ephemeral_public_key or not nonce or not ciphertext:
        raise ValueError("delivery envelope is missing ciphertext components")
    if algorithm == DELIVERY_KEY_ALGORITHM:
        private_key_obj = X25519PrivateKey.from_private_bytes(_b64decode(private_key))
        peer_public_key = X25519PublicKey.from_public_bytes(_b64decode(ephemeral_public_key))
        shared_secret = private_key_obj.exchange(peer_public_key)
        hkdf_info = X25519_ENVELOPE_HKDF_INFO
    elif algorithm == ADMIN_KEY_ALGORITHM:
        private_key_obj = serialization.load_der_private_key(
            _b64decode(private_key),
            password=None,
        )
        if not isinstance(private_key_obj, ec.EllipticCurvePrivateKey):
            raise ValueError("p256 delivery private key is invalid")
        peer_public_key = ec.EllipticCurvePublicKey.from_encoded_point(
            ec.SECP256R1(),
            _b64decode(ephemeral_public_key),
        )
        shared_secret = private_key_obj.exchange(ec.ECDH(), peer_public_key)
        hkdf_info = P256_ENVELOPE_HKDF_INFO
    else:
        raise ValueError(f"unsupported delivery algorithm '{algorithm}'")
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=hkdf_info,
    ).derive(shared_secret)
    plaintext = ChaCha20Poly1305(derived_key).decrypt(
        _b64decode(nonce),
        _b64decode(ciphertext),
        canonical_json(aad).encode("utf-8"),
    )
    payload = json.loads(plaintext.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("delivery payload must decode to an object")
    return payload
