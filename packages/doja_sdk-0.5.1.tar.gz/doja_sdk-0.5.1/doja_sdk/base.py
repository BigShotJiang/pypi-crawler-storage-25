import requests
import uuid
import time
import logging
import httpx
from typing import Optional, List, Dict, Any
from .exceptions import DojaAuthError, DojaQuotaExceeded

# Configure logger
logger = logging.getLogger("doja_sdk")

class DojaBase:
    """
    Base class for all DoJa service clients.
    Handles license validation and message consumption against the DoJa Central Server.
    """

    _VALIDATE_URL = "https://core.dojaconsulting.cloud/v1/license/validate"
    _CONSUME_URL = "https://core.dojaconsulting.cloud/v1/license/consume"
    _CONSUME_EMAIL_URL = "https://core.dojaconsulting.cloud/v1/license/consume-email"

    def __init__(self, doja_token: str, cache_ttl: int = 300):
        self._doja_token = doja_token
        self.account_id = None
        self.account_name = None
        self.plan_tier = None
        self.subscription_status = None
        self.allowed_channels = []

        # Cache system
        self._cache_ttl = cache_ttl
        self._last_validation_time = 0
        self._cached_data = {}

        # Validate the license (Sync)
        self._validate_license()

    def _get_cache_key(self) -> str:
        return f"license_{self._doja_token}"

    def _is_cache_valid(self) -> bool:
        if not self._cached_data:
            return False
        return (time.time() - self._last_validation_time) < self._cache_ttl

    def _update_from_data(self, data: Dict[str, Any]):
        self.account_id = data.get("accountId")
        self.account_name = data.get("accountName")
        self.plan_tier = data.get("planTier")
        self.subscription_status = data.get("subscriptionStatus")
        self.allowed_channels = data.get("allowedChannels", ["whatsapp", "email"])
        self._cached_data = data
        self._last_validation_time = time.time()

    def _handle_validation_response(self, response: httpx.Response):
        """Standardized handler for license validation responses"""
        if response.status_code == 404:
            raise DojaAuthError("DOJA LICENSE INVALID (404): LICENSE_NOT_FOUND. Comprueba que el token sea correcto.")

        elif response.status_code == 409:
            err_text = response.text
            if "MESSAGE_LIMIT_REACHED" in err_text:
                raise DojaQuotaExceeded("DOJA QUOTA EXCEEDED (409): MESSAGE_LIMIT_REACHED. Renueva tu plan para seguir enviando.")
            elif "EMAIL_LIMIT_REACHED" in err_text:
                raise DojaQuotaExceeded("DOJA QUOTA EXCEEDED (409): EMAIL_LIMIT_REACHED. Renueva tu plan para seguir enviando correos.")
            else:
                raise DojaAuthError("DOJA LICENSE INVALID (409): LICENSE_NOT_ACTIVE. Tu licencia esta suspendida o inactiva.")

        elif response.status_code == 422:
            raise DojaAuthError("DOJA VALIDATION ERROR (422): El formato del token es invalido.")

        elif not (200 <= response.status_code < 300):
            raise DojaAuthError(f"HTTP Error {response.status_code} al validar licencia.")

        data = response.json().get("data", {})

        if not data.get("valid", False):
            reason = data.get("reason", "")
            suffix = f" ({reason})" if reason else ""
            raise DojaAuthError(
                f"DOJA LICENSE INVALID: The provided 'doja_token' is suspended, expired, or invalid.{suffix}"
            )

        if not data.get("canSend", False):
            reason = data.get("reason", "")
            suffix = f" ({reason})" if reason else ""
            raise DojaQuotaExceeded(
                f"DOJA QUOTA EXCEEDED: Your license is valid, but your message or email quota has been exhausted.{suffix}"
            )

        self._update_from_data(data)
        logger.info(f"DoJa License Validated - Account: {self.account_name} | Plan: {self.plan_tier}")

    def _validate_license(self):
        """Calls DoJa Central Server (Sync) using cache if possible."""
        if self._is_cache_valid():
            return

        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.post(
                    self._VALIDATE_URL,
                    json={"license_key": self._doja_token}
                )
                self._handle_validation_response(response)
        except (DojaAuthError, DojaQuotaExceeded):
            raise
        except Exception as e:
            logger.error(f"Error connecting to DoJa license server: {str(e)}")
            raise DojaAuthError(f"Could not reach DoJa license server: {str(e)}")

    async def _validate_license_async(self):
        """Calls DoJa Central Server (Async) using cache if possible."""
        if self._is_cache_valid():
            return

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    self._VALIDATE_URL,
                    json={"license_key": self._doja_token}
                )
                self._handle_validation_response(response)
        except (DojaAuthError, DojaQuotaExceeded):
            raise
        except Exception as e:
            logger.error(f"Error connecting to DoJa license server (async): {str(e)}")
            raise DojaAuthError(f"Could not reach DoJa license server: {str(e)}")

    def _check_channel_access(self, channel: str):
        if channel not in self.allowed_channels:
            raise DojaAuthError(
                f"DOJA ACCESS DENIED: Your license does not include the '{channel}' channel. "
                f"Your plan covers: {', '.join(self.allowed_channels)}. "
            )

    def _consume_whatsapp(self, message_id: str):
        if not message_id:
            message_id = f"wamid-{uuid.uuid4()}"

        try:
            requests.post(
                self._CONSUME_URL,
                json={
                    "license_key": self._doja_token,
                    "message_id": message_id,
                    "direction": "OUTBOUND",
                    "quantity": 1
                },
                timeout=5
            )
        except Exception as e:
            logger.warning(f"Failed to consume WhatsApp credit on server: {e}")

    async def _consume_whatsapp_async(self, message_id: str):
        if not message_id:
            message_id = f"wamid-{uuid.uuid4()}"

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    self._CONSUME_URL,
                    json={
                        "license_key": self._doja_token,
                        "message_id": message_id,
                        "direction": "OUTBOUND",
                        "quantity": 1
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to consume WhatsApp credit on server (async): {e}")

    def _consume_email(self, external_id: str, subject: str = "No Subject"):
        if not external_id:
            external_id = f"email-uuid-{uuid.uuid4()}"

        try:
            requests.post(
                self._CONSUME_EMAIL_URL,
                json={
                    "license_key": self._doja_token,
                    "external_id": external_id,
                    "subject": subject
                },
                timeout=5
            )
        except Exception as e:
            logger.warning(f"Failed to consume Email credit on server: {e}")

    async def _consume_email_async(self, external_id: str, subject: str = "No Subject"):
        if not external_id:
            external_id = f"email-uuid-{uuid.uuid4()}"

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    self._CONSUME_EMAIL_URL,
                    json={
                        "license_key": self._doja_token,
                        "external_id": external_id,
                        "subject": subject
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to consume Email credit on server (async): {e}")
