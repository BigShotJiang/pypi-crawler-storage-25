# doja_sdk/email_client.py
import httpx
import base64
import os

from .base import DojaBase
from .exceptions import DojaAPIError


class DojaEmailClient(DojaBase):
    """
    DoJa Email Client - Send emails via DoJa Gateway, protected by DoJa License validation.

    Usage:
        from doja_sdk import DojaEmailClient

        email = DojaEmailClient(
            doja_token="your-doja-license",
            external_id="LA_LLAVE_DE_SERVICIO",
            from_address="no-reply@tuempresa.com"
        )

        email.send(
            to="cliente@empresa.com",
            subject="Bienvenido",
            body="Gracias por registrarte."
        )
    """

    DOJA_EMAIL_API = "https://api.resend.com/emails"

    def __init__(
        self,
        doja_token: str,
        external_id: str,
        from_address: str,
    ):
        """
        Initialize the DoJa Email Client.

        Args:
            doja_token:      Your DoJa license key.
            external_id:     Your DoJa external service identifier.
            from_address:    Default sender address.
        """
        # Validate DoJa license
        super().__init__(doja_token)

        # Verify this license includes Email access
        self._check_channel_access("email")

        self.external_id = external_id
        self.from_address = from_address
        self._headers = {
            "Authorization": f"Bearer {self.external_id}",
            "Content-Type": "application/json"
        }

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        html: bool = False,
        from_address: str = None,
        cc: list = None,
        bcc: list = None,
        reply_to: str = None,
        attachments: list = None,
    ) -> dict:
        """
        Send an email via the DoJa Gateway.

        Args:
            to:            Recipient email (string or comma-separated for multiple).
            subject:       Email subject line.
            body:          Email body content (plain text or HTML).
            html:          If True, body is treated as HTML. Default: False.
            from_address:  Override the default sender address.
            cc:            List of CC email addresses.
            bcc:           List of BCC email addresses.
            reply_to:      Reply-To email address.
            attachments:   List of file paths or URLs to attach.

        Returns:
            dict with API response (includes message id).

        Raises:
            DojaQuotaExceeded: If the license has no remaining emails.
            DojaAPIError: If the sending gateway rejects the email.
        """
        # Re-validate quota before sending
        self._validate_license()

        sender = from_address or self.from_address

        # Build recipients
        if isinstance(to, str):
            to_list = [addr.strip() for addr in to.split(",")]
        else:
            to_list = to

        # Build Gateway payload
        payload = {
            "from": sender,
            "to": to_list,
            "subject": subject,
        }

        # Body type
        if html:
            payload["html"] = body
        else:
            payload["text"] = body

        # Optional fields
        if cc:
            payload["cc"] = cc if isinstance(cc, list) else [cc]
        if bcc:
            payload["bcc"] = bcc if isinstance(bcc, list) else [bcc]
        if reply_to:
            payload["reply_to"] = reply_to

        # Attachments (Gateway accepts base64 encoded files or URLs)
        if attachments:
            file_attachments = []
            for item in attachments:
                if item.startswith("http://") or item.startswith("https://"):
                    filename = item.split("/")[-1].split("?")[0]
                    if not filename:
                        filename = "attachment"
                    file_attachments.append({
                        "filename": filename,
                        "path": item,
                    })
                else:
                    if not os.path.isfile(item):
                        raise DojaAPIError(f"Attachment not found: {item}")
                    filename = os.path.basename(item)
                    with open(item, "rb") as f:
                        content = base64.b64encode(f.read()).decode("utf-8")
                    file_attachments.append({
                        "filename": filename,
                        "content": content,
                    })
            payload["attachments"] = file_attachments

        # Send via DoJa Gateway API
        try:
            with httpx.Client(timeout=15.0) as client:
                response = client.post(
                    self.DOJA_EMAIL_API,
                    headers=self._headers,
                    json=payload
                )

                if response.status_code not in [200, 201]:
                    err_msg = f"DoJa Email Gateway Error {response.status_code}: {response.text}"
                    raise DojaAPIError(err_msg, response.status_code, response.json())

                res_json = response.json()

        except httpx.RequestError as e:
            raise DojaAPIError(f"Email send failed: {str(e)}")

        # Consume 1 email credit after successful send
        external_service_id = res_json.get("id", None)
        self._consume_email(external_id=external_service_id, subject=subject)

        return {
            "status": "sent",
            "id": external_service_id,
            "to": to_list,
            "subject": subject,
            "from": sender
        }


class AsyncDojaEmailClient(DojaBase):
    """
    Asynchronous DoJa Email Client.
    Uses httpx.AsyncClient for non-blocking I/O.
    """

    DOJA_EMAIL_API = "https://api.resend.com/emails"

    def __init__(self, doja_token: str, external_id: str, from_address: str):
        super().__init__(doja_token)
        self._check_channel_access("email")
        self.external_id = external_id
        self.from_address = from_address
        self._headers = {
            "Authorization": f"Bearer {self.external_id}",
            "Content-Type": "application/json"
        }

    async def send(
        self,
        to: str,
        subject: str,
        body: str,
        html: bool = False,
        from_address: str = None,
        cc: list = None,
        bcc: list = None,
        reply_to: str = None,
        attachments: list = None,
    ) -> dict:
        """Send an email via the DoJa Gateway (Async)"""
        await self._validate_license_async()

        sender = from_address or self.from_address
        to_list = [addr.strip() for addr in to.split(",")] if isinstance(to, str) else to

        payload = {
            "from": sender,
            "to": to_list,
            "subject": subject,
        }

        if html:
            payload["html"] = body
        else:
            payload["text"] = body

        if cc: payload["cc"] = cc if isinstance(cc, list) else [cc]
        if bcc: payload["bcc"] = bcc if isinstance(bcc, list) else [bcc]
        if reply_to: payload["reply_to"] = reply_to

        if attachments:
            file_attachments = []
            for item in attachments:
                if item.startswith("http://") or item.startswith("https://"):
                    filename = item.split("/")[-1].split("?")[0] or "attachment"
                    file_attachments.append({"filename": filename, "path": item})
                else:
                    if not os.path.isfile(item):
                        raise DojaAPIError(f"Attachment not found: {item}")
                    filename = os.path.basename(item)
                    # For now we still read in memory, but in async we are non-blocking for the request
                    with open(item, "rb") as f:
                        content = base64.b64encode(f.read()).decode("utf-8")
                    file_attachments.append({"filename": filename, "content": content})
            payload["attachments"] = file_attachments

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    self.DOJA_EMAIL_API,
                    headers=self._headers,
                    json=payload
                )

                if response.status_code not in [200, 201]:
                    err_msg = f"DoJa Email Gateway Error {response.status_code}: {response.text}"
                    raise DojaAPIError(err_msg, response.status_code, response.json())

                res_json = response.json()

        except httpx.RequestError as e:
            raise DojaAPIError(f"Async Email send failed: {str(e)}")

        external_service_id = res_json.get("id")
        await self._consume_email_async(external_id=external_service_id, subject=subject)

        return {
            "status": "sent",
            "id": external_service_id,
            "to": to_list,
            "subject": subject,
            "from": sender
        }
