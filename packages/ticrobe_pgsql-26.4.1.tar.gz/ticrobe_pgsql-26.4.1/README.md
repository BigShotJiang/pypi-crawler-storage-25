# ticrobe.pgsql

Python package for PostgreSQL database operations.

Published package name: `ticrobe.pgsql`

Version: `26.4.1`

## Install

```bash
pip install ticrobe.pgsql
```

For local development from this workspace:

```bash
pip install -e .
```

## Build and upload to PyPI

Build from inside `tX.tPgSql`:

```bash
python -m pip install --upgrade pip build twine
python -m build
python -m twine check dist/*
```

Upload using a PyPI API token:

```bash
python -m twine upload -u __token__ -p pypi-YOUR_API_TOKEN dist/*
```

Important:

- In `twine`, the "password" is your PyPI API token
- The username should be exactly `__token__`
- The package files are generated in `tX.tPgSql/dist/`

## Quick start

```python
from ticrobe.pgsql import DatabaseConfig, PostgresDB

config = DatabaseConfig(
    host="localhost",
    port=5432,
    database="mydb",
    schema="public",
    user="postgres",
    password="secret",
)

with PostgresDB(config) as db:
    db.create_table(
        "users",
        {
            "id": "SERIAL PRIMARY KEY",
            "name": "VARCHAR(100) NOT NULL",
            "email": "VARCHAR(255) UNIQUE NOT NULL",
            "created_at": "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        },
    )

    db.insert("users", {"name": "Asha", "email": "asha@example.com"})
    db.update(
        "users",
        {"name": "Asha R"},
        "email = %s",
        ["asha@example.com"],
    )
    rows = db.fetch_all("SELECT * FROM users ORDER BY id")
    db.delete("users", "email = %s", ["asha@example.com"])
```

You can also load connection settings from PostgreSQL environment variables:

```python
config = DatabaseConfig.from_env()
```

Supported environment variables include `PGHOST`, `PGPORT`, `PGDATABASE`, `PGSCHEMA`,
`PGUSER`, `PGPASSWORD`, and `PGCONNECT_TIMEOUT`.
