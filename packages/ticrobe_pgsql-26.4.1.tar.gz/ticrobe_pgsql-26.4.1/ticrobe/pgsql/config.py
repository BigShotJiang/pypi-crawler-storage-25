from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(slots=True)
class DatabaseConfig:
    host: str = "localhost"
    port: int = 5432
    database: str = "postgres"
    schema: str = "public"
    user: str = "postgres"
    password: str = ""
    connect_timeout: int = 10

    @classmethod
    def from_env(cls) -> "DatabaseConfig":
        return cls(
            host=os.getenv("PGHOST", "localhost"),
            port=int(os.getenv("PGPORT", "5432")),
            database=os.getenv("PGDATABASE", "postgres"),
            schema=os.getenv("PGSCHEMA", "public"),
            user=os.getenv("PGUSER", "postgres"),
            password=os.getenv("PGPASSWORD", "postgres"),
            connect_timeout=int(os.getenv("PGCONNECT_TIMEOUT", "10")),
        )

    def dsn(self) -> str:
        return (
            f"host={self.host} "
            f"port={self.port} "
            f"dbname={self.database} "
            f"user={self.user} "
            f"password={self.password} "
            f"connect_timeout={self.connect_timeout}"
        )
