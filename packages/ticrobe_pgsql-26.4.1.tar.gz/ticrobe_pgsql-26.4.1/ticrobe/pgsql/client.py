from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterable, Iterator, Mapping, Sequence

import psycopg
from psycopg import sql
from psycopg.rows import dict_row

from .config import DatabaseConfig


class PostgresDB:
    def __init__(self, config: DatabaseConfig):
        self.config = config
        self.connection: psycopg.Connection | None = None

    def connect(self) -> psycopg.Connection:
        if self.connection is None or self.connection.closed:
            self.connection = psycopg.connect(self.config.dsn(), row_factory=dict_row)
            if self.config.schema.strip():
                with self.connection.cursor() as cursor:
                    cursor.execute(
                        sql.SQL("SET search_path TO {}").format(
                            sql.Identifier(self.config.schema)
                        )
                    )
        return self.connection

    def disconnect(self) -> None:
        if self.connection is not None and not self.connection.closed:
            self.connection.close()
        self.connection = None

    def __enter__(self) -> "PostgresDB":
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.disconnect()

    @contextmanager
    def cursor(self) -> Iterator[psycopg.Cursor]:
        connection = self.connect()
        with connection.cursor() as cursor:
            yield cursor

    def execute(
        self,
        query: str | sql.SQL,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
        *,
        commit: bool = True,
    ) -> None:
        connection = self.connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(query, params)
            if commit:
                connection.commit()
        except Exception:
            connection.rollback()
            raise

    def _execute_returning(
        self,
        query: str | sql.SQL,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
        *,
        fetch_one: bool,
    ) -> dict[str, Any] | list[dict[str, Any]] | None:
        connection = self.connect()
        try:
            with connection.cursor() as cursor:
                cursor.execute(query, params)
                result = cursor.fetchone() if fetch_one else list(cursor.fetchall())
            connection.commit()
            return result
        except Exception:
            connection.rollback()
            raise

    def fetch_one(
        self,
        query: str | sql.SQL,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        with self.cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchone()

    def fetch_all(
        self,
        query: str | sql.SQL,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        with self.cursor() as cursor:
            cursor.execute(query, params)
            return list(cursor.fetchall())

    def create_table(
        self,
        table_name: str,
        columns: Mapping[str, str],
        *,
        if_not_exists: bool = True,
    ) -> None:
        if not columns:
            raise ValueError("columns cannot be empty")

        column_defs = [
            sql.SQL("{} {}").format(sql.Identifier(name), sql.SQL(definition))
            for name, definition in columns.items()
        ]
        prefix = sql.SQL("IF NOT EXISTS ") if if_not_exists else sql.SQL("")
        query = sql.SQL("CREATE TABLE {}{} ({})").format(
            prefix,
            sql.Identifier(table_name),
            sql.SQL(", ").join(column_defs),
        )
        self.execute(query)

    def drop_table(self, table_name: str, *, if_exists: bool = True) -> None:
        prefix = sql.SQL("IF EXISTS ") if if_exists else sql.SQL("")
        query = sql.SQL("DROP TABLE {}{}").format(prefix, sql.Identifier(table_name))
        self.execute(query)

    def insert(
        self,
        table_name: str,
        data: Mapping[str, Any],
        *,
        returning: Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        if not data:
            raise ValueError("data cannot be empty")

        columns = list(data.keys())
        values = list(data.values())
        query = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
            sql.Identifier(table_name),
            sql.SQL(", ").join(sql.Identifier(column) for column in columns),
            sql.SQL(", ").join(sql.Placeholder() for _ in values),
        )

        if returning:
            query += sql.SQL(" RETURNING {}").format(
                sql.SQL(", ").join(sql.Identifier(column) for column in returning)
            )
            result = self._execute_returning(query, values, fetch_one=True)
            return result if isinstance(result, dict) or result is None else None

        self.execute(query, values)
        return None

    def update(
        self,
        table_name: str,
        data: Mapping[str, Any],
        where_clause: str,
        where_params: Sequence[Any] | None = None,
        *,
        returning: Iterable[str] | None = None,
    ) -> list[dict[str, Any]] | None:
        if not data:
            raise ValueError("data cannot be empty")
        if not where_clause.strip():
            raise ValueError("where_clause cannot be empty")

        assignments = sql.SQL(", ").join(
            sql.SQL("{} = {}").format(sql.Identifier(column), sql.Placeholder())
            for column in data.keys()
        )
        params = list(data.values()) + list(where_params or [])
        query = sql.SQL("UPDATE {} SET {} WHERE {}").format(
            sql.Identifier(table_name),
            assignments,
            sql.SQL(where_clause),
        )

        if returning:
            query += sql.SQL(" RETURNING {}").format(
                sql.SQL(", ").join(sql.Identifier(column) for column in returning)
            )
            result = self._execute_returning(query, params, fetch_one=False)
            return result if isinstance(result, list) else None

        self.execute(query, params)
        return None

    def delete(
        self,
        table_name: str,
        where_clause: str,
        where_params: Sequence[Any] | None = None,
        *,
        returning: Iterable[str] | None = None,
    ) -> list[dict[str, Any]] | None:
        if not where_clause.strip():
            raise ValueError("where_clause cannot be empty")

        query = sql.SQL("DELETE FROM {} WHERE {}").format(
            sql.Identifier(table_name),
            sql.SQL(where_clause),
        )

        if returning:
            query += sql.SQL(" RETURNING {}").format(
                sql.SQL(", ").join(sql.Identifier(column) for column in returning)
            )
            result = self._execute_returning(query, where_params, fetch_one=False)
            return result if isinstance(result, list) else None

        self.execute(query, where_params)
        return None
