# Copyright 2023 The GWKokab Authors
# SPDX-License-Identifier: Apache-2.0


from jax import numpy as jnp
from jaxtyping import ArrayLike


def m1_times_m2(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        m_1m_2(m_1, m_2) = m_1 m_2
    """
    return m1 * m2


def total_mass(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        M(m_1, m_2) = m_1 + m_2
    """
    return m1 + m2


def mass_ratio(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        q(m_1, m_2) = \frac{m_2}{m_1}
    """
    return m2 / m1


def chirp_mass(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        M_c(m_1, m_2) = \frac{(m_1m_2)^{3/5}}{(m_1 + m_2)^{1/5}}
    """
    return jnp.power(m1 * m2, 0.6) / jnp.power(m1 + m2, 0.2)


def log_chirp_mass(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \log(M_c(m_1, m_2)) = 3/5\times (\log(m_1) + \log(m_2)) - \log(m_1 + m_2)/5
    """
    return 0.6 * (jnp.log(m1) + jnp.log(m2)) - 0.2 * jnp.log(m1 + m2)


def symmetric_mass_ratio(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \eta(m_1, m_2) = \frac{m_1m_2}{(m_1 + m_2)^2}
    """
    return m1 * m2 * jnp.power(m1 + m2, -2.0)


def reduced_mass(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        M_r(m_1, m_2) = \frac{m_1m_2}{m_1 + m_2}
    """
    return m1 * m2 / (m1 + m2)


def delta_m(m1: ArrayLike, m2: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \delta_m(m_1, m_2) = \frac{m_1 - m_2}{m_1 + m_2}
    """
    return (m1 - m2) / (m1 + m2)


def delta_m_to_symmetric_mass_ratio(delta_m: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \eta(\delta_m) = \frac{1 - \delta_m^2}{4}
    """
    delta_m_sq = jnp.square(delta_m)  # delta_m^2
    eta = 0.25 * (1 - delta_m_sq)  # (1 - delta_m^2) / 4
    return eta


def symmetric_mass_ratio_to_delta_m(eta: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \delta_m(\eta) = \sqrt{1 - 4\eta}
    """
    eta_4 = jnp.multiply(eta, 4)  #  eta*4
    delta_m = jnp.sqrt(jnp.subtract(1, eta_4))  # sqrt(1 - 4 * eta)
    return delta_m


def m_det_z_to_m_source(m_det: ArrayLike, z: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        m_{\text{source}}(m_{\text{det}}, z) = \frac{m_{\text{det}}}{1 + z}
    """
    return m_det / (1.0 + z)


def m_source_z_to_m_det(m_source: ArrayLike, z: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        m_{\text{det}}(m_{\text{source}}, z) = m_{\text{source}}(1 + z)
    """
    return m_source * (1.0 + z)


def m1_q_to_m2(m1: ArrayLike, q: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        m_2(m_1, q) = m_1q
    """
    return m1 * q


def m2_q_to_m1(m2: ArrayLike, q: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        m_1(m_2, q) = \frac{m_2}{q}
    """
    return m2 / q


def chi_costilt_to_chiz(chi: ArrayLike, costilt: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \chi_z(\chi, \cos(\theta)) = \chi \cos(\theta)
    """
    return chi * costilt


def m1_m2_chi1z_chi2z_to_chiminus(
    m1: ArrayLike, m2: ArrayLike, chi1z: ArrayLike, chi2z: ArrayLike
) -> ArrayLike:
    r"""
    .. math::
        \chi_{\text{minus}}(m_1, m_2, \chi_{1z}, \chi_{2z}) = \frac{m_1\chi_{1z} - m_2\chi_{2z}}{m_1 + m_2}
    """
    m1_chi1z = m1 * chi1z
    m2_chi2z = m2 * chi2z
    M = m1 + m2
    diff = m1_chi1z - m2_chi2z
    return diff / M


def chieff(
    m1: ArrayLike, m2: ArrayLike, chi1z: ArrayLike, chi2z: ArrayLike
) -> ArrayLike:
    r"""
    .. math::
        \chi_{\text{eff}}(m_1, m_2, \chi_{1z}, \chi_{2z}) = \frac{m_1\chi_{1z} + m_2\chi_{2z}}{m_1 + m_2}
    """
    m1_chi1z = m1 * chi1z
    m2_chi2z = m2 * chi2z
    M = m1 + m2
    m_dot_chi = m1_chi1z + m2_chi2z
    return m_dot_chi / M


def m1_m2_chi1_chi2_costilt1_costilt2_to_chieff(
    *,
    m1: ArrayLike,
    m2: ArrayLike,
    chi1: ArrayLike,
    chi2: ArrayLike,
    costilt1: ArrayLike,
    costilt2: ArrayLike,
) -> ArrayLike:
    r"""
    .. math::
        \chi_{\text{eff}}(m_1, m_2, \chi_1, \chi_2, \cos(\theta_1), \cos(\theta_2)) =
        \frac{m_1\chi_1\cos(\theta_1) + m_2\chi_2\cos(\theta_2)}{m_1 + m_2}
    """
    chi1z = chi_costilt_to_chiz(chi=chi1, costilt=costilt1)
    chi2z = chi_costilt_to_chiz(chi=chi2, costilt=costilt2)
    return chieff(m1=m1, m2=m2, chi1z=chi1z, chi2z=chi2z)


def m1_m2_chi1_chi2_costilt1_costilt2_to_chiminus(
    *,
    m1: ArrayLike,
    m2: ArrayLike,
    chi1: ArrayLike,
    chi2: ArrayLike,
    costilt1: ArrayLike,
    costilt2: ArrayLike,
) -> ArrayLike:
    r"""
    .. math::
        \chi_{\text{minus}}(m_1, m_2, \chi_1, \chi_2, \cos(\theta_1), \cos(\theta_2)) =
        \frac{m_1\chi_1\cos(\theta_1) - m_2\chi_2\cos(\theta_2)}{m_1 + m_2}
    """
    chi1z = chi_costilt_to_chiz(chi=chi1, costilt=costilt1)
    chi2z = chi_costilt_to_chiz(chi=chi2, costilt=costilt2)
    return m1_m2_chi1z_chi2z_to_chiminus(m1=m1, m2=m2, chi1z=chi1z, chi2z=chi2z)


def m1_m2_chieff_chiminus_to_chi1z_chi2z(
    m1: ArrayLike, m2: ArrayLike, chieff: ArrayLike, chiminus: ArrayLike
) -> tuple[ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
        \chi_{1z}(m_1, m_2, \chi_{\text{eff}}, \chi_{\text{minus}}) &=
        \frac{m_1+m_2}{2m_1} \left( \chi_{\text{eff}} + \chi_{\text{minus}} \right)\\
        \chi_{2z}(m_1, m_2, \chi_{\text{eff}}, \chi_{\text{minus}}) &=
        \frac{m_1+m_2}{2m_2} \left( \chi_{\text{eff}} - \chi_{\text{minus}} \right)
        \end{align*}
    """
    half_M = jnp.multiply(0.5, total_mass(m1=m1, m2=m2))  # M/2
    chi1z = jnp.divide(
        jnp.multiply(half_M, jnp.add(chieff, chiminus)), m1
    )  # chi1z = M/2 * (chieff + chiminus) / m1
    chi2z = jnp.divide(
        jnp.multiply(half_M, jnp.subtract(chieff, chiminus)), m2
    )  # chi2z = M/2 * (chieff - chiminus) / m2
    return chi1z, chi2z


def Mc_eta_to_m1_m2(Mc: ArrayLike, eta: ArrayLike) -> tuple[ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
            m_1(M_c, \eta) &= \frac{M_c}{2} \eta^{-0.6} (1 + \sqrt{1 - 4\eta}) \\
            m_2(M_c, \eta) &= \frac{M_c}{2} \eta^{-0.6} (1 - \sqrt{1 - 4\eta})
        \end{align*}
    """
    delta_sq = jnp.subtract(1, jnp.multiply(4.0, eta))  # 1 - 4 * eta
    delta_sq = jnp.maximum(
        delta_sq, jnp.zeros_like(delta_sq)
    )  # to avoid negative values
    delta = jnp.sqrt(delta_sq)  # sqrt(1 - 4 * eta)
    half_Mc = jnp.multiply(0.5, Mc)  # Mc/2
    eta_pow_neg_point_six = jnp.power(eta, -0.6)  # eta^-0.6
    half_Mc_times_eta_pow_neg_point_six = jnp.multiply(
        half_Mc, eta_pow_neg_point_six
    )  # Mc/2 * eta^-0.6
    m2 = jnp.multiply(
        half_Mc_times_eta_pow_neg_point_six, jnp.subtract(1.0, delta)
    )  # m2 = Mc/2 * eta^-0.6 * (1 - delta)
    m1 = jnp.multiply(
        half_Mc_times_eta_pow_neg_point_six, jnp.add(1.0, delta)
    )  # m1 = Mc/2 * eta^-0.6 * (1 + delta)
    return m1, m2


def eta_from_q(q: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \eta(q) = \frac{q}{(1 + q)^2}
    """
    return q / (1.0 + q) ** 2.0


def q_from_eta(eta: ArrayLike) -> ArrayLike:
    r"""

    .. math ::
        q(\eta) = \frac{1 - 2\eta - \sqrt{1 - 4\eta}}{2\eta}

    Parameters
    ----------
    eta : ArrayLike
        Symmetric mass ratio

    Returns
    -------
    ArrayLike
        Mass ratio
    """
    return (1.0 - 2.0 * eta - jnp.sqrt(1.0 - 4.0 * eta)) / (2.0 * eta)


def polar_to_cart(r: ArrayLike, theta: ArrayLike) -> tuple[ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
            x(r, \theta) &= r \cos(\theta) \\
            y(r, \theta) &= r \sin(\theta)
        \end{align*}
    """
    x = r * jnp.cos(theta)
    y = r * jnp.sin(theta)
    return x, y


def cart_to_polar(x: ArrayLike, y: ArrayLike) -> tuple[ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
            r(x, y) &= \sqrt{x^2 + y^2} \\
            \theta(x, y) &= \arctan(y/x)
        \end{align*}
    """
    r = jnp.sqrt(x * x + y * y)
    theta = jnp.arctan2(y, x)
    return r, theta


def spherical_to_cart(
    r: ArrayLike, theta: ArrayLike, phi: ArrayLike
) -> tuple[ArrayLike, ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
            x(r, \theta, \phi) &= r \sin(\theta) \cos(\phi) \\
            y(r, \theta, \phi) &= r \sin(\theta) \sin(\phi) \\
            z(r, \theta, \phi) &= r \cos(\theta)
        \end{align*}
    """
    x = r * jnp.sin(theta) * jnp.cos(phi)  # x = r * sin(theta) * cos(phi)
    y = r * jnp.sin(theta) * jnp.sin(phi)  # y = r * sin(theta) * sin(phi)
    z = r * jnp.cos(theta)  # z = r * cos(theta)
    return x, y, z


def cart_to_spherical(
    x: ArrayLike, y: ArrayLike, z: ArrayLike
) -> tuple[ArrayLike, ArrayLike, ArrayLike]:
    r"""
    .. math::
        \begin{align*}
            r(x, y, z) &= \sqrt{x^2 + y^2 + z^2} \\
            \theta(x, y, z) &= \arccos\left(\frac{z}{r}\right) \\
            \phi(x, y, z) &= \arctan\left(\frac{y}{x}\right)
        \end{align*}
    """
    r = jnp.sqrt(x * x + y * y + z * z)  # r = sqrt(x^2 + y^2 + z^2)
    safe_r = jnp.where(r == 0.0, 1.0, r)
    theta = jnp.arccos(
        jnp.where(r == 0.0, jnp.inf, z / safe_r)
    )  # theta = arccos(z / r)
    phi = jnp.arctan2(y, x)  # phi = arctan(y / x)
    return r, theta, phi


def sin_tilt(costilt: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        \sin(\theta) = \sqrt{1 - \cos^2(\theta)}
    """
    return jnp.sqrt(1 - jnp.square(costilt))


def chi_p_from_components(
    a_1: ArrayLike,
    cos_tilt_1: ArrayLike,
    a_2: ArrayLike,
    cos_tilt_2: ArrayLike,
    mass_ratio: ArrayLike,
) -> ArrayLike:
    r"""
    .. math::
        \chi_p(a_1, \cos(\theta_1), a_2, \cos(\theta_2), q) =
        \max \left(
            a_1 \sin(\theta_1),
            \frac{3 + 4q}{4 + 3q} q a_2 \sin(\theta_2)
        \right)
    """
    sin_tilt_1 = sin_tilt(cos_tilt_1)
    sin_tilt_2 = sin_tilt(cos_tilt_2)
    return jnp.maximum(
        a_1 * sin_tilt_1,
        (3.0 + 4.0 * mass_ratio)
        / (4.0 + 3.0 * mass_ratio)
        * mass_ratio
        * a_2
        * sin_tilt_2,
    )


def spin_magnitude_from_components(
    chi_x: ArrayLike, chi_y: ArrayLike, chi_z: ArrayLike
) -> ArrayLike:
    r"""
    .. math::
        \chi(\chi_x, \chi_y, \chi_z) = \sqrt{\chi_x^2 + \chi_y^2 + \chi_z^2}
    """
    return jnp.sqrt(jnp.square(chi_x) + jnp.square(chi_y) + jnp.square(chi_z))


def spin_costilt_from_components(
    chi_x: ArrayLike, chi_y: ArrayLike, chi_z: ArrayLike
) -> ArrayLike:
    r"""
    .. math::
        \cos(\theta)(\chi_x, \chi_y, \chi_z) = \frac{\chi_z}{\sqrt{\chi_x^2 + \chi_y^2 + \chi_z^2}}
    """
    spin_magnitude = spin_magnitude_from_components(chi_x, chi_y, chi_z)
    safe_spin_magnitude = jnp.where(spin_magnitude == 0.0, 1.0, spin_magnitude)
    return jnp.where(spin_magnitude == 0.0, jnp.inf, chi_z / safe_spin_magnitude)


def chirp_mass_from_m1_q(m1: ArrayLike, q: ArrayLike) -> ArrayLike:
    r"""
    .. math::
        M_c(m_1, q) = \frac{(m_1^3 q^3)^{1/5}}{(m_1 + m_1 q)^{1/5}} = m_1 \frac{q^{3/5}}{(1 + q)^{1/5}}
    """
    return m1 * jnp.power(q, 0.6) / jnp.power(1 + q, 0.2)
