# Copyright 2023 The GWKokab Authors
# SPDX-License-Identifier: Apache-2.0


from abc import ABC, abstractmethod
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
from collections.abc import Callable

import h5py
import numpy as np
from jax import nn as jnn, numpy as jnp, random as jrd
from loguru import logger
from numpyro.distributions.distribution import enable_validation

from gwkokab.analysis.core.inference_io import PoissonMeanEstimationLoader
from gwkokab.analysis.core.utils import PRNGKeyMixin, to_structured
from gwkokab.analysis.utils.common import read_json
from gwkokab.analysis.utils.regex import match_all
from gwkokab.models.utils import ScaledMixture
from gwkokab.parameters import default_relation_mesh, Parameters as P
from gwkokab.utils.exceptions import LoggedUserWarning, LoggedValueError


class SyntheticEventsBase(PRNGKeyMixin, ABC):
    def __init__(
        self,
        filename: str,
        model_fn: Callable[..., ScaledMixture],
        model_params_filename: str,
        poisson_mean_filename: str,
        n_buffer_events: int,
        derive_parameters: bool = False,
    ) -> None:
        self.filename = filename
        self.poisson_mean_filename = poisson_mean_filename
        self.derive_parameters = derive_parameters
        self.n_buffer_events = n_buffer_events

        # Initialize model
        raw_params = read_json(model_params_filename)
        matched_params = match_all(self.model_parameters, raw_params)
        self.model_params = self.modify_model_params(matched_params)
        self.model_fn = model_fn(**self.model_params)

    @property
    @abstractmethod
    def parameters(self) -> tuple[str, ...]:
        """Returns the parameters (intrinsic + extrinsic).

        Returns
        -------
        tuple[str, ...]
            list of parameters.
        """
        pass

    @property
    @abstractmethod
    def model_parameters(self) -> list[str]:
        """Returns the model parameters.

        Returns
        -------
        list[str]
            list of model parameters.
        """
        pass

    def modify_model_params(self, params: dict) -> dict:
        """Hook for subclasses to modify parameters before model instantiation."""
        return params

    def _ensure_mass_ordering(self, population: jnp.ndarray) -> jnp.ndarray:
        """Enforces m1 >= m2 for mass parameters if present in the dataset."""
        mass_pairs = [
            (P.PRIMARY_MASS_SOURCE, P.SECONDARY_MASS_SOURCE),
            (P.PRIMARY_MASS_DETECTED, P.SECONDARY_MASS_DETECTED),
        ]

        for m1_key, m2_key in mass_pairs:
            if m1_key in self.parameters and m2_key in self.parameters:
                idx1, idx2 = (
                    self.parameters.index(m1_key),
                    self.parameters.index(m2_key),
                )
                m1, m2 = population[:, idx1], population[:, idx2]

                swapped_mask = m2 > m1
                if jnp.any(swapped_mask):
                    logger.debug(
                        f"Ordering masses for {jnp.sum(swapped_mask)} samples."
                    )
                    new_m1 = jnp.maximum(m1, m2)
                    new_m2 = jnp.minimum(m1, m2)
                    population = population.at[:, idx1].set(new_m1)
                    population = population.at[:, idx2].set(new_m2)

        return population

    def _generate_population(
        self, size: int, log_selection_fn: Callable
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Generate population for a realization via rejection/importance sampling."""
        # Oversample to account for selection effects
        buffer_pop, [buffer_indices] = self.model_fn.sample_with_intermediates(
            self.rng_key, (self.n_buffer_events,)
        )

        buffer_pop = self._ensure_mass_ordering(buffer_pop)

        # Compute selection weights (VT)
        log_selection = log_selection_fn(buffer_pop)
        log_selection = jnp.nan_to_num(
            log_selection, nan=-jnp.inf, posinf=-jnp.inf, neginf=-jnp.inf
        )
        weights = jnn.softmax(log_selection)

        count_nonzero = jnp.sum(weights > 0)
        if count_nonzero < size:
            logger.warning(
                f"Only {count_nonzero} samples have non-zero selection probability. Consider increasing the buffer size.",
                LoggedUserWarning,
            )

        # Resample based on weights
        resample_idx = np.asarray(
            jrd.choice(
                self.rng_key,
                jnp.arange(self.n_buffer_events),
                p=weights,
                shape=(size,),
                replace=False,
            )
        )
        if np.unique(resample_idx).size < size:
            logger.warning(
                "Resampling resulted in duplicate indices. Consider increasing the buffer size.",
                LoggedUserWarning,
            )

        return (
            np.asarray(buffer_pop),
            np.asarray(buffer_indices, np.uint32),
            np.asarray(buffer_pop[resample_idx]),
            np.asarray(buffer_indices[resample_idx]),
            np.asarray(resample_idx, np.uint32),
            np.asarray(weights),
        )

    def from_inverse_transform_sampling(self) -> None:
        pmean_loader = PoissonMeanEstimationLoader.from_json(
            self.poisson_mean_filename, self.rng_key, self.parameters
        )
        log_selection_fn, poisson_mean_estimator, pmean_kwargs = (
            pmean_loader.get_estimators()
        )

        exp_rate, _ = poisson_mean_estimator(self.model_fn, **pmean_kwargs)
        size = int(jrd.poisson(self.rng_key, exp_rate))

        if size >= self.n_buffer_events:
            raise LoggedValueError(
                f"Number of events to generate are greater than number of buffer events. Number of events to generate: {size}, and number of buffer events: {self.n_buffer_events}. Consider increasing the number of buffer events."
            )

        logger.info(f"Expected rate: {exp_rate:.2f} | Realized size: {size}")

        if size <= 0:
            raise LoggedValueError(
                f"Population size is {size}. Check your VT or model configs."
            )

        buffer_pop, buffer_idx, pop, idx, resample_idx, resample_prob = (
            self._generate_population(size, log_selection_fn)
        )
        self.save_population(
            pop, idx, buffer_pop, buffer_idx, resample_idx, resample_prob
        )

    def save_population(
        self,
        population: np.ndarray,
        indices: np.ndarray,
        buffer_population: np.ndarray,
        buffer_indices: np.ndarray,
        resample_idx: np.ndarray,
        resample_prob: np.ndarray,
    ) -> None:
        current_params = self.parameters

        if self.derive_parameters:
            mesh = default_relation_mesh()
            population, current_params = mesh.resolve_from_arrays(
                population, self.parameters
            )
            buffer_population, _ = mesh.resolve_from_arrays(
                buffer_population, self.parameters
            )

        compression_args = {"compression": "gzip", "compression_opts": 9}
        with h5py.File(self.filename, "w") as f:
            f.create_dataset(
                "events",
                data=to_structured(population, current_params),
                **compression_args,
            )
            f.create_dataset(
                "indices", data=indices.astype(np.uint32), **compression_args
            )
            f.create_dataset(
                "buffer_events",
                data=to_structured(buffer_population, current_params),
                **compression_args,
            )
            f.create_dataset(
                "buffer_indices",
                data=buffer_indices.astype(np.uint32),
                **compression_args,
            )
            f.create_dataset(
                "resample_indices",
                data=resample_idx.astype(np.uint32),
                **compression_args,
            )
            f.create_dataset(
                "resample_prob",
                data=resample_prob.astype(np.float32),
                **compression_args,
            )
            f.attrs["parameters"] = np.array(current_params, dtype="S")


def injection_generator_parser() -> ArgumentParser:
    enable_validation()
    parser = ArgumentParser(
        formatter_class=ArgumentDefaultsHelpFormatter,
        description="Generate a population of CBCs",
    )
    # Grouping arguments for better --help readability
    io_group = parser.add_argument_group("Input/Output")
    io_group.add_argument(
        "--output-filename",
        default="synthetic_events.hdf5",
        help="Output HDF5 path",
        type=str,
    )
    io_group.add_argument(
        "--model-params", help="JSON model params", type=str, required=True
    )
    io_group.add_argument(
        "--pmean-cfg", help="Poisson mean config", type=str, default="pmean.json"
    )

    proc_group = parser.add_argument_group("Processing")
    proc_group.add_argument("--derive-parameters", action="store_true")
    proc_group.add_argument("--seed", default=37, type=int)
    proc_group.add_argument(
        "--n-buffer-events",
        default=10_000,
        type=int,
        help="Number of extra events from which few events will be selected based on selection effects.",
    )

    return parser
