# Copyright 2023 The GWKokab Authors
# SPDX-License-Identifier: Apache-2.0


from abc import abstractmethod
from argparse import ArgumentParser
from collections import defaultdict
from collections.abc import Callable
from typing import Any, Dict, List, Set, Tuple, Union

import jax
from jax import lax
from jaxtyping import Array
from loguru import logger
from numpyro.distributions.distribution import Distribution

from gwkokab.analysis.core.utils import PRNGKeyMixin
from gwkokab.analysis.utils.common import read_json, write_json
from gwkokab.analysis.utils.priors import get_processed_priors
from gwkokab.models.utils import JointDistribution, LazyJointDistribution
from gwkokab.utils.exceptions import LoggedValueError


def _topological_sort(graph: Dict[str, Set[str]]) -> List[str]:
    visited = set()
    result = []

    def dfs(node: str) -> None:
        visited.add(node)
        for neighbor in graph.get(node, set()):
            if neighbor not in visited:
                dfs(neighbor)
        result.append(node)

    for node in graph:
        if node not in visited:
            dfs(node)
    result.reverse()
    return result


def _check_cycles(graph: Dict[str, Set[str]]) -> bool:
    """Checks if a directed graph has cycles using Depth-First Search (DFS).

    Parameters
    ----------
    graph : Dict[str, Set[str]]
        A directed graph represented as an adjacency list.

    Returns
    -------
    bool
        True if the graph has cycles, False otherwise.
    """
    visited = set()
    rec_stack = set()

    def dfs(node: str) -> bool:
        visited.add(node)
        rec_stack.add(node)

        for neighbor in graph.get(node, set()):
            if neighbor not in visited:
                if dfs(neighbor):
                    return True
            elif neighbor in rec_stack:
                return True

        rec_stack.remove(node)
        return False

    for node in graph:
        if node not in visited:
            if dfs(node):
                return True
    return False


def _classify_model_parameters(
    **params: Any,
) -> Tuple[
    Dict[str, int | float | None],
    Dict[str, Distribution],
    Dict[str, str],
    Dict[str, Dict[str, str]],
    List[str],
]:
    """Separate constants, random variables, and lazy variables from model parameters.

    Parameters
    ----------
    dist_factory : Distribution | Callable[..., Distribution]
        A distribution class or a callable that constructs a distribution.

    Returns
    -------
    Tuple[
        Dict[str, int | float | None],
        Dict[str, Distribution],
        Dict[str, str],
        Dict[str, Dict[str, str]],
        List[str],
    ]
        A tuple containing:
        - constants: fixed numeric or None values
        - variables: distribution instances or lazy callables
        - aliases: mapping of parameter aliases to their original names
        - lazy_dependencies: mapping of lazy variable definitions
        - lazy_order: topological order of dependent lazy variables

    Raises
    ------
    ValueError
        If a parameter has an invalid type.
    """
    constants: Dict[str, int | float | None] = {}
    variables: Dict[str, Distribution] = {}
    aliases: Dict[str, str] = {}
    lazy_dependencies: Dict[str, Dict[str, str]] = {}

    dependency_graph: Dict[str, Set[str]] = defaultdict(set)
    variable_roots: List[str] = []

    # Pass 1: classify parameters
    for name, value in params.items():
        if value is None:
            constants[name] = None

        elif isinstance(value, str):
            # string aliases handled later
            continue

        elif isinstance(value, Distribution):
            variables[name] = value
            variable_roots.append(name)

        elif isinstance(value, tuple):
            lazy_fn, lazy_args = value
            if not isinstance(lazy_fn, jax.tree_util.Partial):
                raise LoggedValueError(
                    f"Lazy distribution '{name}' must be a `jax.tree_util.Partial`.",
                )
            if not isinstance(lazy_args, dict):
                raise LoggedValueError(
                    f"Lazy distribution '{name}' must have a dictionary of dependencies."
                )

            variables[name] = lazy_fn
            lazy_dependencies[name] = lazy_args

            for _, dep_name in lazy_args.items():
                dependency_graph[dep_name].add(name)

        elif isinstance(value, (int, float)):
            constants[name] = lax.stop_gradient(value)

        else:
            raise LoggedValueError(
                f"Invalid parameter '{name}' with type {type(value)} and value {value}"
            )

    # Pass 2: resolve string aliases
    for name, value in params.items():
        if isinstance(value, str):
            if value in constants:
                constants[name] = constants[value]
            elif value in variables:
                aliases[name] = value

    if not lazy_dependencies:
        lazy_order = []
    else:  # Compute lazy evaluation order
        if _check_cycles(dependency_graph):
            import pprint

            raise LoggedValueError(
                "Cyclic dependencies detected among lazy variables. Dependency graph:\n"
                + pprint.pformat(dependency_graph)
            )

        lazy_order = [
            var
            for var in _topological_sort(dependency_graph)
            if var not in variable_roots
        ]

    return (
        constants,
        variables,
        aliases,
        lazy_dependencies,
        lazy_order,
    )


class Guru(PRNGKeyMixin):
    """Guru is a class which contains all the common functionality among Genie, Sage and
    Guru classes.
    """

    output_directory: str

    def __init__(
        self,
        *,
        analysis_name: str,
        check_leaks: bool,
        debug_nans: bool,
        model: Union[Distribution, Callable[..., Distribution]],
        poisson_mean_filename: str,
        prior_filename: str,
        profile_memory: bool,
        sampler_cfg,
        variance_cut_threshold: float | None,
    ) -> None:
        self.analysis_name = analysis_name
        self.prior_filename = prior_filename
        self.model = model
        self.sampler_cfg = sampler_cfg
        self.debug_nans = debug_nans
        self.profile_memory = profile_memory
        self.check_leaks = check_leaks
        self.poisson_mean_filename = poisson_mean_filename
        self.variance_cut_threshold = variance_cut_threshold

    def modify_model_params(self, params: dict) -> dict:
        """Hook for subclasses to modify parameters before model instantiation."""
        return params

    def classify_model_parameters(
        self,
    ) -> Tuple[
        Dict[str, Union[int, float, bool, None]],
        JointDistribution,
        Dict[str, int],
        Dict[str, int],
    ]:
        """Classify model parameters into constants, priors, and variables index.

        Returns
        -------
        Tuple[ Dict[str, Union[int, float, bool, None]], Callable[..., Distribution], JointDistribution, Dict[str, int], ]
            A tuple containing the constants, the distribution function, the prior
            distribution, and the variables index.
        """
        prior_dict = read_json(self.prior_filename)
        model_prior_param = self.modify_model_params(
            get_processed_priors(self.model_parameters, prior_dict)
        )

        logger.debug("Classifying model parameters into constants and variables.")
        constants, variables, duplicates, lazy_deps, lazy_order = (
            _classify_model_parameters(**model_prior_param)
        )  # type: ignore

        variables_index: dict[str, int] = {
            key: i for i, key in enumerate(sorted(variables.keys()))
        }
        for key, value in duplicates.items():
            variables_index[key] = variables_index[value]

        group_variables: dict[int, list[str]] = {}
        for key, value in variables_index.items():  # type: ignore
            group_variables[value] = group_variables.get(value, []) + [key]  # type: ignore

        logger.debug(
            "Number of recovering variables: {num_vars}", num_vars=len(group_variables)
        )

        for key, value in constants.items():  # type: ignore
            logger.debug(
                "Constant variable: {name} = {variable}", name=key, variable=value
            )

        for value in group_variables.values():  # type: ignore
            logger.debug("Recovering variable: {variable}", variable=", ".join(value))

        write_json("constants.json", constants)
        write_json("nf_samples_mapping.json", variables_index)

        sorted_variables = sorted(variables.keys())
        if len(lazy_order) == 0:
            priors = JointDistribution(
                *[variables[key] for key in sorted_variables],
                validate_args=True,
            )
        else:
            lazy_deps_new = {
                sorted_variables.index(k): {
                    k_: sorted_variables.index(v) for k_, v in deps.items()
                }
                for k, deps in lazy_deps.items()
            }
            priors = LazyJointDistribution(
                *[variables[key] for key in sorted_variables],
                dependencies=lazy_deps_new,
                partial_order=[sorted_variables.index(k) for k in lazy_order],
                validate_args=True,
            )

        return constants, priors, variables, variables_index

    @property
    @logger.catch(reraise=True)
    def parameters(self) -> Union[List[str], Tuple[str, ...]]:
        """Returns the parameters (intrinsic + extrinsic).

        Returns
        -------
        Union[List[str], Tuple[str, ...]]
            List or tuple of parameter names.

        Raises
        ------
        NotImplementedError
            If the Guru class is used directly, this method raises a NotImplementedError.
            It is expected that subclasses of Guru will implement this method.
        """
        raise NotImplementedError(
            "The Guru class should not be used directly. Please use a subclass that "
            "implements the parameters property."
        )

    @property
    @logger.catch(reraise=True)
    def model_parameters(self) -> List[str]:
        """Returns the model parameters.

        Returns
        -------
        List[str]
            List of model parameters.

        Raises
        ------
        NotImplementedError
            If the Guru class is used directly, this method raises a NotImplementedError.
            It is expected that subclasses of Guru will implement this method.
        """
        raise NotImplementedError(
            "The Guru class should not be used directly. Please use a subclass that "
            "implements the model_parameters property."
        )

    @abstractmethod
    def driver(
        self,
        *,
        logpdf: Callable[[Array, Dict[str, Any]], Array],
        priors: JointDistribution,
        data: Any,
        labels: List[str],
    ) -> None:
        raise NotImplementedError()


def guru_arg_parser(parser: ArgumentParser) -> ArgumentParser:
    """Populate the command line argument parser with the arguments for the Guru script.

    Parameters
    ----------
    parser : ArgumentParser
        Parser to add the arguments to

    Returns
    -------
    ArgumentParser
        the command line argument parser
    """
    parser.add_argument(
        "--seed",
        help="Seed for the random number generator.",
        default=37,
        type=int,
    )

    pmean_group = parser.add_argument_group("Poisson Mean Options")
    pmean_group.add_argument(
        "--pmean-cfg",
        help="Path to the JSON file containing the Poisson mean options.",
        type=str,
        default="pmean.json",
    )

    sampler_group = parser.add_argument_group("Sampler Options")
    sampler_group.add_argument(
        "--sampler-cfg",
        help="Path to the JSON file containing the sampler configuration.",
        type=str,
        required=True,
    )
    sampler_group.add_argument(
        "--variance-cut-threshold",
        help="Threshold for variance cut in the sampler. If the variance of the "
        "likelihood is above this threshold, the sample will be rejected. By default is"
        " infinite (i.e., no cut by setting it to the maximum float value).",
        type=float,
        default=None,
    )

    prior_group = parser.add_argument_group("Prior Options")
    prior_group.add_argument(
        "--prior-cfg",
        type=str,
        help="Path to a JSON file containing the prior distributions.",
        default="prior.json",
    )

    dev_group = parser.add_argument_group(
        "Developer Options",
        description="These options are intended for developers. They will not work in "
        "production mode.",
    )
    dev_group.add_argument(
        "--debug-nans",
        help="Checks for NaNs in each computation. See details in the documentation: "
        "https://jax.readthedocs.io/en/latest/_autosummary/jax.debug_nans.html#jax.debug_nans.",
        action="store_true",
    )
    dev_group.add_argument(
        "--profile-memory",
        help="Enable memory profiling.",
        action="store_true",
    )
    dev_group.add_argument(
        "--check-leaks",
        help="Check for JAX Tracer leaks. See details in the documentation: "
        "https://jax.readthedocs.io/en/latest/_autosummary/jax.checking_leaks.html#jax.checking_leaks.",
        action="store_true",
    )

    return parser
