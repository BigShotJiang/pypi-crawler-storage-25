from __future__ import annotations


import json
import os
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "Heron Intelligence",
    instructions=(
        "Heron Intelligence provides financial research intelligence based on curated earnings call "
        "transcripts and due diligence interviews.\n\n"
        "Recommended workflow:\n"
        "1. search_company — find the company and get its ID (use ticker for speed, name when unsure)\n"
        "2. get_company_overview — (optional) check coverage depth before committing to analysis\n"
        "3. get_recent_transcripts — browse available transcripts and select which to examine\n"
        "4. get_transcript_content — fetch verbatim Q&A for a specific transcript\n"
        "5. analyze_red_flags — run a full structured risk analysis across multiple transcripts\n\n"
        "Always start with search_company to obtain the company ID required by other tools."
    ),
)

_API_URL = "https://ubjzp9xp6w.us-west-2.awsapprunner.com"
_API_KEY = os.environ.get("HERON_API_KEY", "")
_TIMEOUT = float(os.environ.get("HERON_TIMEOUT", "120.0"))


def _headers() -> dict[str, str]:
    return {"X-API-KEY": _API_KEY, "Content-Type": "application/json"}


def _check_config() -> str | None:
    if not _API_KEY:
        return "HERON_API_KEY is not set. Add it to the MCP server environment config."
    return None


class QuotaExceededError(Exception):
    """Raised when the API returns HTTP 429."""


def _quota_error_message(resp: httpx.Response) -> str:
    """Return a human-readable message for 429 quota responses."""
    reset_at = resp.headers.get("X-Quota-Reset", "")
    retry_after = resp.headers.get("Retry-After", "")
    try:
        detail = resp.json().get("detail", "Quota exceeded.")
    except Exception:
        detail = "Quota exceeded."
    msg = f"Heron Intelligence quota limit reached: {detail}"
    if reset_at:
        msg += f" Your quota resets at {reset_at}."
    elif retry_after:
        msg += f" Retry after {retry_after} seconds."
    msg += " Please contact us to upgrade your plan."
    return msg


async def _post(path: str, body: dict) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(f"{_API_URL}{path}", json=body, headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


async def _get(path: str) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.get(f"{_API_URL}{path}", headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


@mcp.tool()
async def search_company(query: str) -> str:
    """
    Search the Heron Intelligence catalog and return the single best-matching company.

    Use this FIRST before any other tool — all other tools require the company ID
    this returns.

    Search strategy:
    - Use the exact ticker when you know it (e.g. "NU", "MELI") — faster and unambiguous
    - Use the company name when you're unsure of the ticker (e.g. "Nubank", "MercadoLibre")
    - Descriptions also work (e.g. "Brazilian digital bank") but are less reliable

    Returns ONE best match (not a list). If the wrong company is returned, try a more
    specific query.

    Args:
        query: Ticker symbol, company name, or description
               (e.g. "Nubank", "NU", "Mexican e-commerce")

    Returns:
        JSON with the best-matched company:
        {"id": "uuid", "name": "Nu Holdings Ltd.", "ticker": "NU", "exchange": "NYSE"}
        Returns {"error": "..."} if no match is found or the API is unreachable.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/companies/search", {"query": query})
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"API {exc.response.status_code}: {exc.response.text}"})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_recent_transcripts(company_id: str, quarters: int = 3) -> str:
    """
    List metadata for the most recent transcripts available for a company.

    Returns METADATA ONLY — no transcript text. To read the actual content of a
    specific transcript, call get_transcript_content with its ID.

    Use this after search_company to browse what research materials exist and decide
    which transcripts are worth examining before running a full analysis.

    Key fields in each result:
    - due_diligence_type: "earnings_call" or "due_diligence_interview"
    - call_quality: signal for transcript reliability — prioritize "high" quality docs
    - source_tone: management sentiment signal — "cautious", "confident", "defensive", etc.
    - id: pass this to get_transcript_content or cite it in analyze_red_flags

    Args:
        company_id: The company ID returned by search_company
        quarters:   How many past quarters to look back (default: 3)

    Returns:
        JSON list of transcript metadata. Example entry:
        {
          "id": "uuid",
          "title": "Nu Holdings Q3 2024 Earnings Call",
          "date": "2024-11-12",
          "due_diligence_type": "earnings_call",
          "call_quality": "high",
          "source_tone": "confident"
        }
        Returns {"error": "..."} on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post(
            "/api/v1/transcripts/search",
            {"company_id": company_id, "quarters": quarters},
        )
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"API {exc.response.status_code}: {exc.response.text}"})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_company_overview(company_id: str) -> str:
    """
    Get a high-level summary of a company's research coverage in Heron Intelligence.

    Use this after search_company to understand what coverage exists before
    committing to a full analysis. Returns: transcript count, date range covered,
    types of documents available, and a brief coverage quality assessment.

    This is more efficient than get_recent_transcripts when you only need to know
    whether sufficient coverage exists to support a meaningful analysis.

    Args:
        company_id: The company ID returned by search_company

    Returns:
        JSON with coverage summary:
        {
          "company_id": "uuid",
          "total_transcripts": 8,
          "earliest_date": "2022-08-10",
          "latest_date": "2024-11-12",
          "document_types": ["earnings_call", "due_diligence_interview"],
          "quarters_available": 8,
          "recommended_quarters": 4
        }
        Returns {"error": "..."} on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post(
            "/api/v1/transcripts/search",
            {"company_id": company_id, "quarters": 12},
        )

        transcripts: list[dict] = data if isinstance(data, list) else data.get("results", [])

        if not transcripts:
            return json.dumps(
                {
                    "company_id": company_id,
                    "total_transcripts": 0,
                    "earliest_date": None,
                    "latest_date": None,
                    "document_types": [],
                    "quarters_available": 0,
                    "recommended_quarters": 0,
                }
            )

        dates = sorted(
            t["date"] for t in transcripts if t.get("date")
        )
        doc_types = sorted(
            set(t["due_diligence_type"] for t in transcripts if t.get("due_diligence_type"))
        )

        # Approximate distinct quarters from distinct year-quarter strings
        quarters_set: set[str] = set()
        for t in transcripts:
            d = t.get("date", "")
            if len(d) >= 7:
                year, month = d[:4], int(d[5:7])
                quarter = (month - 1) // 3 + 1
                quarters_set.add(f"{year}Q{quarter}")

        n_quarters = len(quarters_set)
        recommended = min(n_quarters, 4)

        summary = {
            "company_id": company_id,
            "total_transcripts": len(transcripts),
            "earliest_date": dates[0] if dates else None,
            "latest_date": dates[-1] if dates else None,
            "document_types": doc_types,
            "quarters_available": n_quarters,
            "recommended_quarters": recommended,
        }
        return json.dumps(summary, ensure_ascii=False)

    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"API {exc.response.status_code}: {exc.response.text}"})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_transcript_content(transcript_id: str) -> str:
    """
    Retrieve the full verbatim content of a specific transcript.

    The response is an array of Q&A pairs, each with:
    - speaker: name of the person speaking
    - role: their role (e.g. "CEO", "Analyst", "CFO")
    - text: verbatim spoken content

    When to use this vs. analyze_red_flags:
    - Use get_transcript_content for verbatim quotes, close reading, or when you need
      the exact words management used
    - Use analyze_red_flags for high-level risk synthesis across multiple transcripts —
      it is faster and does not consume your token budget on raw text

    WARNING: Transcripts can be large (10,000+ tokens). Avoid fetching multiple
    transcripts in a single response unless necessary. Use get_recent_transcripts
    to identify the most relevant transcript first.

    Args:
        transcript_id: The UUID of the transcript (from get_recent_transcripts or
                       a citation in analyze_red_flags output)

    Returns:
        JSON with full transcript payload. The Q&A content is in a "content" array:
        [
          {"speaker": "David Vélez", "role": "CEO", "text": "We saw record..."},
          {"speaker": "James Friedman", "role": "Analyst", "text": "Can you clarify..."},
          ...
        ]
        Returns {"error": "..."} on failure or {"found": false} if ID is not found.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _get(f"/api/v1/transcripts/{transcript_id}")
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return json.dumps({"found": False, "message": f"No transcript found: '{transcript_id}'"})
        return json.dumps({"error": f"API {exc.response.status_code}: {exc.response.text}"})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def analyze_red_flags(company: str, quarters: int = 3) -> str:
    """
    Flagship analysis tool. Runs a deep, structured risk analysis for a company using
    Heron Intelligence's ReAct agent, powered by curated transcripts and due diligence
    interviews.

    This tool automatically searches for the company, retrieves and cross-references
    multiple transcripts across the requested time window, and produces a structured
    risk report with source citations. Prefer this over manually chaining
    get_transcript_content calls for risk analysis.

    Args:
        company: Company name or ticker (e.g. "Rappi", "MELI", "Nubank")
        quarters: How many past quarters to analyze (default: 3, max recommended: 8)

    Returns:
        Structured markdown analysis covering red flags by category, key quotes,
        positive signals, and an overall risk rating with citations. Returns a
        formatted error message (starting with "## Error") if analysis cannot be run.
    """
    err = _check_config()
    if err:
        return f"## Error\n\n{err}"
    try:
        prompt = (
            f"Perform a comprehensive red flag analysis for **{company}** "
            f"covering the last {quarters} quarters.\n\n"
            "Instructions:\n"
            "- Cross-reference ALL available transcripts in the window, not just the most recent one. "
            "Note when signals appear consistently across multiple periods.\n"
            "- Pay close attention to management language: flag evasive answers, hedging that "
            "increases over time, sudden changes in tone between quarters, or topics that are "
            "consistently avoided.\n"
            "- Identify discrepancies between stated strategy and actual results — e.g. guidance "
            "misses, pivots that contradict prior commitments, or KPIs that are quietly redefined.\n"
            "- Where data allows, compare the company's trajectory against sector peers or macro "
            "context (e.g. rising rates, FX pressure, regulatory shifts in its market).\n\n"
            "Structure your response as follows:\n"
            "1. **Executive Summary** — 2-3 sentence overview of the risk profile\n"
            "2. **Red Flags** — organized by category (Operational, Financial, Management, "
            "Competitive, Macro). For each flag: description, severity (high/medium/low), "
            "trend (improving/worsening/stable), and source citations\n"
            "3. **Positive Signals** — counter-evidence or strengths worth noting\n"
            "4. **Overall Risk Assessment** — high / medium / low with rationale\n"
            "5. **Key Quotes** — 3-5 verbatim quotes from transcripts that best capture the "
            "risk sentiment or management posture. Format each as:\n"
            '   > "Quote text here."\n'
            "   — Speaker Name, Role, [Document Type: title](ID), Date\n\n"
            "Include [Document Type: title](ID) citations for every factual claim. "
            "If no transcripts are found for this company, clearly state that."
        )
        data = await _post("/api/v1/agents/aura/query", {"query": prompt})
        return data.get("response", json.dumps(data, ensure_ascii=False))
    except QuotaExceededError as exc:
        return f"## Error: Quota Exceeded\n\n{str(exc)}"
    except httpx.HTTPStatusError as exc:
        return f"## Error\n\nAPI error {exc.response.status_code}: {exc.response.text}"
    except Exception as exc:
        return f"## Error\n\nAnalysis could not be completed: {str(exc)}"
