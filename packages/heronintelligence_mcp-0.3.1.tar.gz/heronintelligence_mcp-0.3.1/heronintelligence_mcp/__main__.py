"""Entry point for `uvx --from HeronIntelligence-mcp heronintelligence-mcp`."""
from heronintelligence_mcp.server import mcp


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
