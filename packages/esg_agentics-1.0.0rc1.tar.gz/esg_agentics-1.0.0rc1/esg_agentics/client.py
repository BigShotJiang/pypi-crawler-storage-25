"""Thin synchronous client for the ESG Agentics v1 API."""
from __future__ import annotations

import time
from typing import Any, Dict, Optional

import httpx

PROD_BASE_URL    = "https://ufulfekvcznezqucdefy.supabase.co/functions/v1/api-v1/v1"
PROD_TOKEN_URL   = "https://ufulfekvcznezqucdefy.supabase.co/functions/v1/api-v1-auth-token"
SANDBOX_BASE_URL  = "https://sandbox.esgagentics.com/functions/v1/api-v1/v1"
SANDBOX_TOKEN_URL = "https://sandbox.esgagentics.com/functions/v1/api-v1-auth-token"


class ESGAgentics:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        environment: str = "live",   # "live" or "sandbox"
        base_url: Optional[str] = None,   # explicit override beats `environment`
        token_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        if environment not in ("live", "sandbox"):
            raise ValueError("environment must be 'live' or 'sandbox'")
        default_base  = SANDBOX_BASE_URL  if environment == "sandbox" else PROD_BASE_URL
        default_token = SANDBOX_TOKEN_URL if environment == "sandbox" else PROD_TOKEN_URL
        self._cid = client_id
        self._csec = client_secret
        self._base = (base_url or default_base).rstrip("/")
        self._token_url = token_url or default_token
        self._http = httpx.Client(timeout=timeout)
        self._token: Optional[str] = None
        self._exp: float = 0.0
        self.vehicles = _Vehicles(self)
        self.trips = _Trips(self)
        self.evidence = _Evidence(self)
        self.reports = _Reports(self)
        self.ileap = _ILeap(self)

    # ---- internal -----------------------------------------------------
    def _access_token(self) -> str:
        if self._token and time.time() < self._exp - 60:
            return self._token
        r = self._http.post(
            self._token_url,
            json={
                "grant_type": "client_credentials",
                "client_id": self._cid,
                "client_secret": self._csec,
            },
        )
        r.raise_for_status()
        data = r.json()
        self._token = data["access_token"]
        self._exp = time.time() + int(data.get("expires_in", 3600))
        return self._token

    def request(self, method: str, path: str, **kw: Any) -> Any:
        headers = kw.pop("headers", {}) or {}
        headers["Authorization"] = f"Bearer {self._access_token()}"
        r = self._http.request(method, f"{self._base}{path}", headers=headers, **kw)
        if r.status_code >= 400:
            raise httpx.HTTPStatusError(r.text, request=r.request, response=r)
        return r.json() if r.content else None


class _Resource:
    def __init__(self, c: ESGAgentics) -> None:
        self._c = c


class _Vehicles(_Resource):
    def list(self, **q: Any) -> Dict[str, Any]:
        return self._c.request("GET", "/vehicles", params=q)

    def get(self, id: str) -> Dict[str, Any]:
        return self._c.request("GET", f"/vehicles/{id}")

    def create(self, **body: Any) -> Dict[str, Any]:
        return self._c.request("POST", "/vehicles", json=body)


class _Trips(_Resource):
    def list(self, **q: Any) -> Dict[str, Any]:
        return self._c.request("GET", "/trips", params=q)

    def create(self, **body: Any) -> Dict[str, Any]:
        return self._c.request("POST", "/trips", json=body)


class _Evidence(_Resource):
    def list_receipts(self, **q: Any) -> Dict[str, Any]:
        return self._c.request("GET", "/evidence/receipts", params=q)

    def create_receipt(self, **body: Any) -> Dict[str, Any]:
        return self._c.request("POST", "/evidence/receipts", json=body)


class _Reports(_Resource):
    def generate(self, **body: Any) -> Dict[str, Any]:
        return self._c.request("POST", "/reports/generate", json=body)


class _ILeap(_Resource):
    def footprint(self, **body: Any) -> Dict[str, Any]:
        return self._c.request("POST", "/ileap/footprints", json=body)