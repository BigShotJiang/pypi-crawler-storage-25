"""Official Python SDK for the ESG Agentics public API."""
from .client import ESGAgentics

__all__ = ["ESGAgentics"]
__version__ = "1.0.0rc1"