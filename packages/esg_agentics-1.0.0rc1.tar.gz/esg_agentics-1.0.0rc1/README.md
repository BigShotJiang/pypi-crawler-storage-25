# esg-agentics

Official Python SDK for the **ESG Agentics** public API
(OAuth 2.1 client-credentials, REST surface, iLEAP / PACT footprints,
CloudEvents 1.0 webhooks).

```bash
pip install esg-agentics
```

```python
from esg_agentics import ESGAgentics

client = ESGAgentics(client_id="...", client_secret="...")
vehicles = client.vehicles.list()
```

Docs: https://esgagentics.com/developers