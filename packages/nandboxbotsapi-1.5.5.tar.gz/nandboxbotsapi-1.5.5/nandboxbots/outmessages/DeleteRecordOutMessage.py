import json

from nandboxbots.outmessages.OutMessage import OutMessage


class DeleteRecordOutMessage(OutMessage):
    __KEY_DOC_ID = "doc_id"
    __KEY_DOC_TYPE = "doc_type"

    def __init__(self):
        self.method = "extensionDeleteDoc"

        self.id = None
        self.table_name = None

    def to_json_obj(self):
        _, obj = super(DeleteRecordOutMessage, self).to_json_obj()

        if self.id is not None:
            obj[self.__KEY_DOC_ID] = self.id

        if self.table_name is not None:
            obj[self.__KEY_DOC_TYPE] = self.table_name

        return json.dumps(obj), obj