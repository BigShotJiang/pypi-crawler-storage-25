import pytest
from pypi_demo_hello_aymg import greet, hello


def test_hello():
    assert hello() == "Hello, World!"


def test_greet():
    assert greet("Alice") == "Hello, Alice!"


def test_greet_strips_whitespace():
    assert greet("  Bob  ") == "Hello, Bob!"


def test_greet_empty_raises():
    with pytest.raises(ValueError):
        greet("")


def test_greet_whitespace_only_raises():
    with pytest.raises(ValueError):
        greet("   ")
