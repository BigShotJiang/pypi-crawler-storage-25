#!/usr/bin/env python3
"""
Replicates the CDN propagation race described in:
  TestPyPiMetadataBodyFilter_CDNDivergence_StaleJSON_MustNotLeakNewVersion
  TestPyPiMetadataBodyFilter_JSONMissingVersion_MustNotLeakNewVersion

Run this script right after publishing a new version to PyPI.
The window is usually 30-120 seconds after `twine upload`.

Usage:
    python scripts/replicate_stale_cache.py pypi-demo-hello-aymg 0.2.0
"""

import sys
import time
import json
import urllib.request
from datetime import datetime, timezone


def fetch(url: str, etag: str | None = None) -> tuple[int, bytes, str | None]:
    req = urllib.request.Request(url)
    req.add_header("Accept", "text/html,application/json")
    if etag:
        req.add_header("If-None-Match", etag)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, resp.read(), resp.headers.get("ETag")
    except urllib.error.HTTPError as e:
        return e.code, b"", None


def poll_divergence(package: str, new_version: str, max_attempts: int = 30, interval: float = 5.0):
    html_url = f"https://pypi.org/simple/{package}/"
    json_url = f"https://pypi.org/pypi/{package}/json"

    print(f"\nPolling for CDN divergence on '{package}' v{new_version}")
    print(f"  HTML: {html_url}")
    print(f"  JSON: {json_url}")
    print(f"  Interval: {interval}s  Max attempts: {max_attempts}\n")

    # Capture baseline ETag before publishing (simulate old cached state)
    _, _, baseline_etag = fetch(html_url)
    print(f"Baseline ETag: {baseline_etag}\n")

    for attempt in range(1, max_attempts + 1):
        ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
        html_status, html_body, html_etag = fetch(html_url, baseline_etag)
        json_status, json_body, _ = fetch(json_url, baseline_etag)

        html_has_new = new_version in html_body.decode(errors="replace")
        json_has_new = False
        json_missing_version = False

        if json_status == 200 and json_body:
            try:
                data = json.loads(json_body)
                releases = data.get("releases", {})
                json_has_new = new_version in releases
                json_missing_version = html_has_new and not json_has_new
            except json.JSONDecodeError:
                pass

        print(f"[{ts}] attempt={attempt:02d}")
        print(f"  HTML: status={html_status}  has_new_version={html_has_new}")
        print(f"  JSON: status={json_status}  has_new_version={json_has_new}")

        # --- Scenario 1: CDNDivergence (HTML=200 new, JSON=304 stale) ---
        if html_has_new and json_status == 304:
            print("\n>>> BUG REPLICATED: CDNDivergence_StaleJSON")
            print("    HTML returned 200 with new version.")
            print("    JSON returned 304 (stale) — additionalMetadata would be nil.")
            print("    FilterPublishedVersions would short-circuit and leak the version.\n")
            return "cdn_divergence"

        # --- Scenario 2: JSONMissingVersion (HTML=200 new, JSON=200 but version absent) ---
        if json_missing_version:
            print("\n>>> BUG REPLICATED: JSONMissingVersion")
            print("    HTML returned 200 with new version.")
            print(f"    JSON returned 200 but '{new_version}' is absent from releases.")
            print("    getVersionsToFilter would never add it to versionsToRemove.\n")
            return "json_missing_version"

        if html_has_new and json_has_new:
            print("  Both endpoints agree — propagation complete, window missed.\n")
            return "propagation_complete"

        time.sleep(interval)

    print("Max attempts reached without capturing the race window.")
    return "timeout"


if __name__ == "__main__":
    pkg = sys.argv[1] if len(sys.argv) > 1 else "pypi-demo-hello-aymg"
    ver = sys.argv[2] if len(sys.argv) > 2 else "0.2.0"
    result = poll_divergence(pkg, ver)
    print(f"Result: {result}")
