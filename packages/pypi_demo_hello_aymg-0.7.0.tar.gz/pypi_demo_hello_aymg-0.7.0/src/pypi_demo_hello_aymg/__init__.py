from .core import greet, hello

__version__ = "0.1.0"
__all__ = ["greet", "hello"]