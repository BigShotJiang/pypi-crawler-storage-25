# hello-world-lib

A simple hello world library — minimal example for publishing to PyPI.

## Installation

```bash
pip install hello-world-lib
```

## Usage

```python
from hello_world_lib import hello, greet

print(hello())          # Hello, World!
print(greet("Alice"))   # Hello, Alice!
```

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest
```

## Publishing

```bash
# Build
python -m build

# Upload to TestPyPI first
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```