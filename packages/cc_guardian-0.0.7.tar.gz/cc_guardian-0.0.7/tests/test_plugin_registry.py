"""Registry sanity: three entries, sides, default profile, list_by_side filtering."""

from __future__ import annotations

from cc_guard.plugins import BUILTIN_PLUGINS, PluginSide, get_plugin, list_by_side


def test_three_entries_present():
    assert set(BUILTIN_PLUGINS) == {"input_guard", "output_guard", "tool_guard"}


def test_all_entries_are_both_side():
    for meta in BUILTIN_PLUGINS.values():
        assert meta.side == PluginSide.BOTH


def test_default_profile_assignment():
    assert BUILTIN_PLUGINS["input_guard"].default_profile == [PluginSide.CLIENT]
    assert BUILTIN_PLUGINS["output_guard"].default_profile == [PluginSide.CLIENT]
    assert BUILTIN_PLUGINS["tool_guard"].default_profile == [PluginSide.SERVER]


def test_module_paths_point_at_adapters():
    assert BUILTIN_PLUGINS["input_guard"].module == "cc_guard.plugins.adapters.input_guard"
    assert BUILTIN_PLUGINS["output_guard"].module == "cc_guard.plugins.adapters.output_guard"
    assert BUILTIN_PLUGINS["tool_guard"].module == "cc_guard.plugins.adapters.tool_guard"


def test_list_by_side_returns_all_since_both():
    # Since every plugin is side=both, any side query returns the full list.
    assert len(list_by_side(PluginSide.CLIENT)) == 3
    assert len(list_by_side(PluginSide.SERVER)) == 3
    assert len(list_by_side(PluginSide.BOTH)) == 3


def test_get_plugin_returns_none_for_unknown():
    assert get_plugin("nope") is None
    assert get_plugin("input_guard") is not None


def test_applicable_to():
    meta = BUILTIN_PLUGINS["input_guard"]
    assert meta.applicable_to(PluginSide.CLIENT)
    assert meta.applicable_to(PluginSide.SERVER)
