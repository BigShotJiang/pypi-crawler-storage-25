"""plugin_config: read/write, apply_defaults, validation, flowlens injection."""

from __future__ import annotations

import pytest

from cc_guard.plugin_config import (
    PluginSideMismatchError,
    UnknownPluginError,
    apply_defaults,
    enabled_plugins_for_flowlens,
    load_plugin_config,
    plugin_config_path,
    save_plugin_config,
    set_config_value,
    set_enabled,
)
from cc_guard.plugins import PluginSide


def test_missing_file_returns_empty(fake_home):
    assert load_plugin_config(PluginSide.CLIENT) == []
    assert load_plugin_config(PluginSide.SERVER) == []


def test_apply_defaults_seeds_both_sides(fake_home):
    newly = apply_defaults()
    assert set(n for n in newly[PluginSide.CLIENT]) == {"input_guard", "output_guard"}
    assert set(n for n in newly[PluginSide.SERVER]) == {"tool_guard"}

    client_entries = load_plugin_config(PluginSide.CLIENT)
    assert {e.name for e in client_entries} == {"input_guard", "output_guard"}
    assert all(e.enabled for e in client_entries)

    server_entries = load_plugin_config(PluginSide.SERVER)
    assert {e.name for e in server_entries} == {"tool_guard"}
    assert server_entries[0].enabled


def test_apply_defaults_is_idempotent(fake_home):
    apply_defaults()
    second_run = apply_defaults()
    assert second_run[PluginSide.CLIENT] == []
    assert second_run[PluginSide.SERVER] == []


def test_set_enabled_creates_entry_with_default_config(fake_home):
    entry = set_enabled(PluginSide.CLIENT, "input_guard", True)
    assert entry.enabled
    assert entry.config == {"block_on_suspicious": False}

    reloaded = load_plugin_config(PluginSide.CLIENT)
    assert len(reloaded) == 1
    assert reloaded[0].name == "input_guard"


def test_set_enabled_unknown_raises(fake_home):
    with pytest.raises(UnknownPluginError):
        set_enabled(PluginSide.CLIENT, "nope", True)


def test_set_config_value_persists(fake_home):
    set_enabled(PluginSide.CLIENT, "input_guard", True)
    set_config_value(PluginSide.CLIENT, "input_guard", "block_on_suspicious", True)
    entries = load_plugin_config(PluginSide.CLIENT)
    assert entries[0].config["block_on_suspicious"] is True


def test_set_config_value_on_missing_entry_creates_disabled(fake_home):
    set_config_value(PluginSide.CLIENT, "input_guard", "max_qps", 10)
    entries = load_plugin_config(PluginSide.CLIENT)
    assert entries[0].enabled is False
    assert entries[0].config["max_qps"] == 10


def test_enabled_plugins_for_flowlens(fake_home):
    apply_defaults()
    client = enabled_plugins_for_flowlens(PluginSide.CLIENT)
    assert len(client) == 2
    assert all("path" in p and "config" in p for p in client)
    paths = {p["path"] for p in client}
    assert "cc_guard.plugins.adapters.input_guard" in paths
    assert "cc_guard.plugins.adapters.output_guard" in paths


def test_enabled_plugins_excludes_disabled(fake_home):
    apply_defaults()
    set_enabled(PluginSide.CLIENT, "input_guard", False)
    client = enabled_plugins_for_flowlens(PluginSide.CLIENT)
    assert len(client) == 1
    assert client[0]["path"] == "cc_guard.plugins.adapters.output_guard"


def test_atomic_write_file_permissions(fake_home):
    apply_defaults()
    path = plugin_config_path(PluginSide.CLIENT)
    # 0600 — same as other cc-guard-managed files
    mode = path.stat().st_mode & 0o777
    assert mode == 0o600


def test_bad_plugin_config_path_rejects_both(fake_home):
    with pytest.raises(ValueError):
        plugin_config_path(PluginSide.BOTH)
