"""build_sidecar_config / build_hub_config inject the right plugin entries."""

from __future__ import annotations

from cc_guard.plugin_config import apply_defaults, set_enabled
from cc_guard.plugins import PluginSide
from cc_guard.sidecar import (
    HubSettings,
    SidecarSettings,
    build_hub_config,
    build_sidecar_config,
)


def test_sidecar_has_no_plugins_when_none_enabled(fake_home):
    cfg = build_sidecar_config(SidecarSettings(listen="http://127.0.0.1:9999"))
    assert "plugins" not in cfg


def test_sidecar_config_injects_client_plugins(fake_home):
    apply_defaults()
    cfg = build_sidecar_config(SidecarSettings(listen="http://127.0.0.1:9999"))
    assert "plugins" in cfg
    paths = {p["path"] for p in cfg["plugins"]}
    assert paths == {
        "cc_guard.plugins.adapters.input_guard",
        "cc_guard.plugins.adapters.output_guard",
    }


def test_sidecar_config_does_not_leak_server_plugins(fake_home):
    apply_defaults()
    cfg = build_sidecar_config(SidecarSettings(listen="http://127.0.0.1:9999"))
    paths = {p["path"] for p in cfg.get("plugins", [])}
    assert "cc_guard.plugins.adapters.tool_guard" not in paths


def test_hub_config_injects_server_plugins(fake_home):
    apply_defaults()
    cfg = build_hub_config(HubSettings(listen="0.0.0.0:8787", token="abc"))
    assert cfg["mode"] == "hub"
    assert "plugins" in cfg
    paths = {p["path"] for p in cfg["plugins"]}
    assert paths == {"cc_guard.plugins.adapters.tool_guard"}


def test_hub_config_has_no_plugins_when_none_enabled(fake_home):
    cfg = build_hub_config(HubSettings(listen="0.0.0.0:8787", token="abc"))
    assert "plugins" not in cfg


def test_enabling_client_only_plugin_on_server_side(fake_home):
    # All plugins are side=both so any is legal on any side
    set_enabled(PluginSide.SERVER, "input_guard", True)
    cfg = build_hub_config(HubSettings(listen="0.0.0.0:8787", token="abc"))
    paths = {p["path"] for p in cfg.get("plugins", [])}
    assert "cc_guard.plugins.adapters.input_guard" in paths
