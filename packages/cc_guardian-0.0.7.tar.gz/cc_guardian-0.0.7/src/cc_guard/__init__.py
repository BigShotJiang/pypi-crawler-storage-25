"""cc-guard: security gateway for Claude Code traffic."""

__version__ = "0.0.7"
