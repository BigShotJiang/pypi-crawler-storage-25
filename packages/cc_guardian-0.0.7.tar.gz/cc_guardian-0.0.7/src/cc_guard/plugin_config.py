"""Read/write ~/.cc-guard/plugins.{client,server}.yaml.

These are user-facing declaration files: a list of {name, enabled, config}
entries per side. `sidecar.build_sidecar_config()` and
`sidecar.build_hub_config()` consult them at install/start time and
inject the enabled entries into the flowlens `plugins` array.

Atomic writes, tolerant reads (missing file → empty list). Schema
validation is delegated to agent-guard engine constructors — this layer
only enforces that the plugin `name` is known in BUILTIN_PLUGINS.
"""

from __future__ import annotations

import copy
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .plugins import BUILTIN_PLUGINS, PluginMeta, PluginSide
from .sidecar import cc_guard_dir


@dataclass
class PluginEntry:
    name: str
    enabled: bool = False
    config: dict[str, Any] = field(default_factory=dict)


class UnknownPluginError(ValueError):
    pass


class PluginSideMismatchError(ValueError):
    pass


# ── paths ────────────────────────────────────────────────────

def plugin_config_path(side: PluginSide) -> Path:
    if side == PluginSide.BOTH:
        raise ValueError("plugin_config_path requires CLIENT or SERVER")
    return cc_guard_dir() / f"plugins.{side.value}.yaml"


# ── load / save ──────────────────────────────────────────────

def load_plugin_config(side: PluginSide) -> list[PluginEntry]:
    """Read the per-side declaration file. Missing file → empty list."""
    path = plugin_config_path(side)
    if not path.exists():
        return []
    raw = yaml.safe_load(path.read_text()) or {}
    entries_raw = raw.get("plugins") or []
    entries: list[PluginEntry] = []
    for item in entries_raw:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if not name:
            continue
        entries.append(PluginEntry(
            name=name,
            enabled=bool(item.get("enabled", False)),
            config=dict(item.get("config") or {}),
        ))
    return entries


_GENERATED_HEADER = (
    "# Managed by cc-guard plugin CLI. Edit with `cc-guard plugin enable/disable/config`\n"
    "# or hand-edit if you know the schema. Regenerated on every CLI mutation.\n\n"
)


def save_plugin_config(side: PluginSide, entries: list[PluginEntry]) -> Path:
    """Atomically write the declaration file. Creates parent dir, 0600 perms."""
    path = plugin_config_path(side)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "plugins": [asdict(e) for e in entries],
    }
    body = _GENERATED_HEADER + yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    try:
        tmp.write_text(body)
        os.replace(tmp, path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise
    os.chmod(path, 0o600)
    return path


# ── mutation helpers (used by CLI) ───────────────────────────

def _require_known(name: str) -> PluginMeta:
    meta = BUILTIN_PLUGINS.get(name)
    if meta is None:
        raise UnknownPluginError(
            f"unknown plugin: {name!r}. "
            f"Known plugins: {', '.join(sorted(BUILTIN_PLUGINS))}"
        )
    return meta


def _require_side_applicable(meta: PluginMeta, side: PluginSide) -> None:
    if not meta.applicable_to(side):
        raise PluginSideMismatchError(
            f"plugin {meta.name!r} is not applicable to side={side.value!r} "
            f"(registry side={meta.side.value!r})"
        )


def _find_entry(entries: list[PluginEntry], name: str) -> PluginEntry | None:
    for e in entries:
        if e.name == name:
            return e
    return None


def set_enabled(side: PluginSide, name: str, enabled: bool) -> PluginEntry:
    """Enable or disable a plugin on a given side. Creates entry if absent.

    First-time enable seeds `config` from the registry's default_config so
    the user sees the same knobs they'd get from a fresh install.
    """
    meta = _require_known(name)
    _require_side_applicable(meta, side)
    entries = load_plugin_config(side)
    entry = _find_entry(entries, name)
    if entry is None:
        entry = PluginEntry(
            name=name,
            enabled=enabled,
            config=copy.deepcopy(meta.default_config),
        )
        entries.append(entry)
    else:
        entry.enabled = enabled
    save_plugin_config(side, entries)
    return entry


def set_config_value(side: PluginSide, name: str, key: str, value: Any) -> PluginEntry:
    """Set a single config key on a plugin entry. Creates entry if absent.

    Value parsing (bool/int/float/str) is the CLI's responsibility — this
    helper takes the value as-is.
    """
    meta = _require_known(name)
    _require_side_applicable(meta, side)
    entries = load_plugin_config(side)
    entry = _find_entry(entries, name)
    if entry is None:
        entry = PluginEntry(
            name=name,
            enabled=False,
            config=copy.deepcopy(meta.default_config),
        )
        entries.append(entry)
    entry.config[key] = value
    save_plugin_config(side, entries)
    return entry


def apply_defaults() -> dict[PluginSide, list[str]]:
    """Seed both declaration files from each plugin's `default_profile`.

    Existing entries are preserved; only new ones are added (enabled) and
    missing entries get created. Returns a map side → names that were
    newly enabled.
    """
    newly_enabled: dict[PluginSide, list[str]] = {
        PluginSide.CLIENT: [],
        PluginSide.SERVER: [],
    }
    for side in (PluginSide.CLIENT, PluginSide.SERVER):
        entries = load_plugin_config(side)
        changed = False
        for meta in BUILTIN_PLUGINS.values():
            if side not in meta.default_profile:
                continue
            entry = _find_entry(entries, meta.name)
            if entry is None:
                entries.append(PluginEntry(
                    name=meta.name,
                    enabled=True,
                    config=copy.deepcopy(meta.default_config),
                ))
                newly_enabled[side].append(meta.name)
                changed = True
            elif not entry.enabled:
                entry.enabled = True
                newly_enabled[side].append(meta.name)
                changed = True
        if changed:
            save_plugin_config(side, entries)
    return newly_enabled


# ── flowlens injection ───────────────────────────────────────

def enabled_plugins_for_flowlens(side: PluginSide) -> list[dict[str, Any]]:
    """Build the `plugins` list that goes into sidecar.yaml / hub.yaml.

    Drops unknown / disabled entries silently — unknown names might be
    leftovers from a previous cc-guard version, and warning about them
    every `install` would be noisy. (Future work: a `cc-guard plugin
    lint` command that surfaces them.)
    """
    entries = load_plugin_config(side)
    result: list[dict[str, Any]] = []
    for entry in entries:
        if not entry.enabled:
            continue
        meta = BUILTIN_PLUGINS.get(entry.name)
        if meta is None:
            continue
        if not meta.applicable_to(side):
            continue
        result.append({
            "path": meta.module,
            "config": dict(entry.config),
        })
    return result
