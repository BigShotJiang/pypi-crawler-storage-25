"""cc-guard plugin system: registry + config layer + adapters.

Plugin declarations live in ~/.cc-guard/plugins.{client,server}.yaml and get
injected into flowlens configs (sidecar.yaml / hub.yaml) at install time.
The actual plugin implementations are thin adapters over agent-guard engines.
"""

from .registry import (
    BUILTIN_PLUGINS,
    PluginMeta,
    PluginSide,
    get_plugin,
    list_by_side,
)

__all__ = [
    "BUILTIN_PLUGINS",
    "PluginMeta",
    "PluginSide",
    "get_plugin",
    "list_by_side",
]
