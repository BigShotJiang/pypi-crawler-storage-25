"""Prompt-injection detection adapter. Wraps agent-guard InputGuard."""

from __future__ import annotations

from typing import Any

from agentic_guard.input_guard import InputGuard

from ._shared import extract_latest_user_text, guard_result_to_action


class Plugin:
    def __init__(self, **config: Any):
        enforce_block = config.pop("enforce_block", True)
        self._enforce_block = bool(enforce_block)
        self._guard = InputGuard(**config)

    async def on_request(self, context: dict) -> dict | None:
        text = extract_latest_user_text(context)
        if not text:
            body = context.get("request", {}).get("body", "")
            if not isinstance(body, str) or not body:
                return None
            text = body
        result = self._guard.check(text)
        return guard_result_to_action(
            result,
            guard_name="input_guard",
            enforce_block=self._enforce_block,
        )
