"""Destructive tool-call review adapter. Wraps agent-guard ToolGuard.

Invoked by flowlens hub via /_internal/review_block RPC with phase=tool_use.
The review context shape (see flowlens/hub_endpoints.py:review_block) is:

    {
        "phase": "tool_use",
        "tool_use": {"id": str, "name": str, "input": dict},
        "request_id": str,
        "session": {...},
    }
"""

from __future__ import annotations

from typing import Any

from agentic_guard.tool_guard import ToolGuard

from ._shared import guard_result_to_action


class Plugin:
    def __init__(self, **config: Any):
        enforce_block = config.pop("enforce_block", True)
        self._enforce_block = bool(enforce_block)
        self._guard = ToolGuard(**config)

    async def on_tool_use(self, context: dict) -> dict | None:
        tool = context.get("tool_use") or {}
        name = tool.get("name", "")
        params = tool.get("input") or {}
        if not isinstance(params, dict):
            params = {}

        # Per-request session key — keeps per-session call counts scoped
        # to a single conversation rather than globally.
        session_key = context.get("request_id") or "__default__"
        confirm = bool(params.pop("_agent_guard_confirm", False))

        result = self._guard.check(
            name,
            params,
            session_key=str(session_key),
            confirm=confirm,
        )
        return guard_result_to_action(
            result,
            guard_name="tool_guard",
            enforce_block=self._enforce_block,
        )
