"""Secret/PII redaction adapter. Wraps agent-guard OutputGuard.

Handles both streaming (SSE) and buffered responses. `create_transform`
is what flowlens calls — the returned object must implement
`async transform(chunk: bytes) -> bytes | None` and
`async flush() -> bytes | None`.
"""

from __future__ import annotations

from typing import Any

from agentic_guard.output_guard import OutputGuard
from agentic_guard.sse_transform import SSERedactTransform

from ._shared import detect_api_type, is_stream_request


class _BufferedRedactTransform:
    """Per-chunk redaction for non-streaming JSON responses."""

    def __init__(self, guard: OutputGuard):
        self._guard = guard

    async def transform(self, chunk: bytes) -> bytes | None:
        text = chunk.decode("utf-8", errors="replace")
        result = self._guard.check(text)
        if result.action == "allow":
            return chunk
        if result.action == "block":
            return b'{"error": "response blocked by output_guard"}'
        if result.modified_content is not None:
            return result.modified_content.encode("utf-8")
        return chunk

    async def flush(self) -> bytes | None:
        return None


class Plugin:
    def __init__(self, **config: Any):
        self._guard = OutputGuard(**config)

    async def create_transform(self, context: dict):
        api_type = detect_api_type(context)
        if is_stream_request(context):
            return SSERedactTransform(self._guard, api_type=api_type)
        return _BufferedRedactTransform(self._guard)
