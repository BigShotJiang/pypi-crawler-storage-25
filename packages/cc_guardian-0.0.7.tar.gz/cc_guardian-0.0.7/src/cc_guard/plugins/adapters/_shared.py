"""Context extraction + flowlens action conversion shared by all adapters.

Copied (not imported) from agent-guard's internal plugin.py so we don't
depend on its private API. Kept in sync manually: if flowlens changes
the context shape or agent-guard evolves its GuardResult, update here.
"""

from __future__ import annotations

import json
from typing import Any

from agentic_guard.input_guard import GuardResult


def detect_api_type(context: dict) -> str:
    """Classify the upstream API flavor by request path."""
    path = context.get("request", {}).get("path", "")
    if "/messages" in path:
        return "anthropic"
    if "generateContent" in path or "/gemini" in path:
        return "gemini"
    return "openai"


def is_stream_request(context: dict) -> bool:
    body = context.get("request", {}).get("body", "")
    try:
        data = json.loads(body)
        return bool(data.get("stream"))
    except (json.JSONDecodeError, TypeError, AttributeError):
        return False


def extract_latest_user_text(context: dict) -> str | None:
    """Pull the most recent user-role message text from `context['parsed']`.

    `parsed` is populated by flowlens's request parser; shape is
    {"messages": [{"role": "...", "blocks": [{"type": "text", "text": "..."}]}]}.
    Returns None if no user message is present.
    """
    parsed = context.get("parsed") or {}
    messages = parsed.get("messages")
    if not messages:
        return None
    for msg in reversed(messages):
        if msg.get("role") == "user":
            texts: list[str] = []
            for block in msg.get("blocks", []):
                if isinstance(block, dict) and block.get("type") == "text":
                    texts.append(block.get("text", ""))
                elif isinstance(block, str):
                    texts.append(block)
            if texts:
                return " ".join(texts)
    return None


def extract_tool_calls(data: dict, api_type: str) -> list[dict]:
    """Extract tool calls from a decoded response body (anthropic/openai/gemini)."""
    results: list[dict] = []
    if api_type == "anthropic":
        for block in data.get("content", []):
            if isinstance(block, dict) and block.get("type") == "tool_use":
                results.append({
                    "name": block.get("name", ""),
                    "arguments": json.dumps(block.get("input", {})),
                })
    else:
        for choice in data.get("choices", []):
            msg = choice.get("message", {})
            for tc in msg.get("tool_calls", []):
                fn = tc.get("function", {})
                results.append({
                    "name": fn.get("name", ""),
                    "arguments": fn.get("arguments", "{}"),
                })
    return results


def guard_result_to_action(
    result: GuardResult,
    *,
    guard_name: str,
    enforce_block: bool = True,
) -> dict[str, Any] | None:
    """Map agent-guard's GuardResult to flowlens's {action, reason, events} dict.

    - action=="allow" and no matched rules → return None (pass-through)
    - action=="block" and enforce_block → block request
    - everything else → allow with an event attached for audit
    """
    if result.action == "allow" and not result.matched_rules:
        return None

    event = {
        "guard": guard_name,
        "action": result.action,
        "severity": result.severity,
        "reason": result.reason,
        "matched_rules": result.matched_rules,
    }

    if result.action == "block" and enforce_block:
        return {"action": "block", "reason": result.reason, "events": [event]}

    if result.action == "modify" and result.modified_content is not None:
        return {
            "action": "modify",
            "modified_body": result.modified_content,
            "events": [event],
        }

    return {"action": "allow", "events": [event]}
