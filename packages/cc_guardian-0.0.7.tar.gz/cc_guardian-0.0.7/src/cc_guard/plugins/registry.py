"""Built-in plugin registry.

Each entry points at a thin adapter module under
`cc_guard.plugins.adapters.*` that wraps one agent-guard engine. Users
enable/disable entries through `cc-guard plugin` CLI; the declarations
live in ~/.cc-guard/plugins.{side}.yaml and get serialized into
flowlens's `plugins` array at install time.

`side` tells CLI/config where the plugin may run. `default_profile`
says which side(s) the "--defaults" shortcut enables it on.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class PluginSide(str, Enum):
    CLIENT = "client"
    SERVER = "server"
    BOTH = "both"


class PluginMeta(BaseModel):
    name: str
    module: str                          # importable path, e.g. "cc_guard.plugins.adapters.input_guard"
    side: PluginSide
    description: str
    default_config: dict[str, Any] = Field(default_factory=dict)
    default_profile: list[PluginSide] = Field(default_factory=list)

    def applicable_to(self, side: PluginSide) -> bool:
        """True if this plugin may run on the given side."""
        if self.side == PluginSide.BOTH:
            return side in (PluginSide.CLIENT, PluginSide.SERVER)
        return self.side == side


BUILTIN_PLUGINS: dict[str, PluginMeta] = {
    "input_guard": PluginMeta(
        name="input_guard",
        module="cc_guard.plugins.adapters.input_guard",
        side=PluginSide.BOTH,
        description="Prompt-injection detection on outbound user messages (agent-guard InputGuard)",
        default_config={"block_on_suspicious": False},
        default_profile=[PluginSide.CLIENT],
    ),
    "output_guard": PluginMeta(
        name="output_guard",
        module="cc_guard.plugins.adapters.output_guard",
        side=PluginSide.BOTH,
        description="Secret/PII redaction on responses, including SSE streaming (agent-guard OutputGuard)",
        default_config={"block_on_leak": False, "entropy_enabled": False},
        default_profile=[PluginSide.CLIENT],
    ),
    "tool_guard": PluginMeta(
        name="tool_guard",
        module="cc_guard.plugins.adapters.tool_guard",
        side=PluginSide.BOTH,
        description="Destructive tool-call review on accumulated model response (agent-guard ToolGuard)",
        default_config={},
        default_profile=[PluginSide.SERVER],
    ),
}


def get_plugin(name: str) -> PluginMeta | None:
    return BUILTIN_PLUGINS.get(name)


def list_by_side(side: PluginSide) -> list[PluginMeta]:
    """Plugins that may run on the given side. `BOTH` returns every plugin."""
    if side == PluginSide.BOTH:
        return list(BUILTIN_PLUGINS.values())
    return [p for p in BUILTIN_PLUGINS.values() if p.applicable_to(side)]
