"""Managed sidecar — optional local proxy process tied to install/uninstall.

Design: cc-guard stays a nothing-fancy configurator at its core, but when
the user opts in (via the wizard or `ccg install --upstream ...`), it can
also generate a minimal sidecar config and spawn/kill a `flow run`
subprocess on their behalf. The goal is zero-configuration UX for the
common case "I want Claude Code to go through a local proxy".

Contents:
  1. Config generation (build_sidecar_config + write_sidecar_config)
  2. Process lifecycle (start_managed / stop_managed / status)
  3. Runner discovery (find_flow_runner) — prefers `flow` on PATH,
     falls back to `python -m flowlens` so users that installed
     cc-guard[sidecar] get it out of the box via the optional extra.

No flowlens imports — everything talks to flowlens via subprocess so
the two projects stay fully decoupled at the code level.
"""

from __future__ import annotations

import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import yaml

# Win32 process creation flags. Hard-coded so this module imports cleanly on
# POSIX (where `subprocess.DETACHED_PROCESS` doesn't exist as an attribute).
# Values are Win32 API constants — stable since NT, see MSDN process_creation_flags.
_WIN32_DETACHED_PROCESS = 0x00000008
_WIN32_CREATE_NEW_PROCESS_GROUP = 0x00000200


# ── config locations ────────────────────────────────────────

def cc_guard_dir() -> Path:
    return Path.home() / ".cc-guard"


def sidecar_config_path() -> Path:
    return cc_guard_dir() / "sidecar.yaml"


def sidecar_pid_file() -> Path:
    return cc_guard_dir() / "sidecar.pid"


def sidecar_log_dir() -> Path:
    return cc_guard_dir() / "sidecar-logs"


def sidecar_stdout_log() -> Path:
    return cc_guard_dir() / "sidecar.out"


def hub_token_file() -> Path:
    return cc_guard_dir() / "hub-token"


def hub_config_path() -> Path:
    return cc_guard_dir() / "hub.yaml"


def hub_pid_file() -> Path:
    return cc_guard_dir() / "hub.pid"


def hub_log_dir() -> Path:
    return cc_guard_dir() / "hub-logs"


def hub_stdout_log() -> Path:
    return cc_guard_dir() / "hub.out"


# ── config generation ──────────────────────────────────────

@dataclass
class SidecarSettings:
    """Inputs needed to generate a sidecar config.

    `listen` is the URL cc-guard puts into settings.json; sidecar's
    listen address is derived from it (host:port stripped of scheme).

    `upstream` is what the sidecar forwards to (the real anthropic API
    by default; can point at a local mock for testing).

    `hub_url` + `hub_token` are optional — if provided, the generated
    config uses mode=sidecar with RPC to a remote hub; otherwise it
    uses mode=proxy for a pure local capture.
    """
    listen: str                            # e.g. "http://127.0.0.1:9999"
    upstream: str = "https://api.anthropic.com"
    hub_url: str | None = None
    hub_token: str | None = None


def _parse_listen(url: str) -> str:
    """Extract host:port from a URL like http://127.0.0.1:9999.

    Sidecar's `listen` field expects the bare form (no scheme).
    """
    # strip scheme
    for prefix in ("http://", "https://"):
        if url.startswith(prefix):
            url = url[len(prefix):]
            break
    # strip trailing slash and anything after the first /
    url = url.split("/", 1)[0]
    return url


def build_sidecar_config(s: SidecarSettings) -> dict[str, Any]:
    """Build the dict that will be dumped to ~/.cc-guard/sidecar.yaml."""
    listen_host_port = _parse_listen(s.listen)

    cfg: dict[str, Any] = {
        "listen": listen_host_port,
        "providers": {
            "anthropic": {
                "url": s.upstream,
                "models": ["*"],
                "parser": "claude",
            },
        },
        "log": {
            "dir": str(sidecar_log_dir()),
            "body_mode": "messages",
        },
    }

    if s.hub_url:
        cfg["mode"] = "sidecar"
        cfg["hub"] = {
            "url": s.hub_url,
            "token": "${CC_GUARD_HUB_TOKEN}",
            "fail_open": True,
        }
        cfg["sidecar"] = {
            "upstream": s.upstream,
        }
        # body_mode none in sidecar mode: hub is the audit sink,
        # avoid double-storing locally
        cfg["log"]["body_mode"] = "none"
    else:
        cfg["mode"] = "proxy"

    # Inject cc-guard-managed client-side plugins. Imported lazily so this
    # module stays importable even if plugin_config has issues.
    from .plugin_config import enabled_plugins_for_flowlens
    from .plugins import PluginSide

    client_plugins = enabled_plugins_for_flowlens(PluginSide.CLIENT)
    if client_plugins:
        cfg["plugins"] = client_plugins

    return cfg


# ── hub config generation ──────────────────────────────────

@dataclass
class HubSettings:
    """Inputs needed to generate a flowlens hub config.

    Hub mode aggregates sidecars: it owns centralized policy (tool_use
    review, audit log) and exposes /_internal/* endpoints that sidecars
    call via RPC. A hub does not proxy upstream LLM traffic itself — it
    only runs plugins that received forwarded blocks from sidecars.
    """
    listen: str                             # "host:port" — bare, no scheme
    token: str                              # bearer token sidecars send
    upstream: str = "https://api.anthropic.com"  # reference only, not proxied here


def build_hub_config(s: HubSettings) -> dict[str, Any]:
    """Build the dict dumped to ~/.cc-guard/hub.yaml.

    plugins[] comes from plugins.server.yaml; if no server plugins are
    enabled the hub still runs (it's useful purely as an audit sink).
    """
    listen_host_port = _parse_listen(s.listen)

    cfg: dict[str, Any] = {
        "mode": "hub",
        "listen": listen_host_port,
        "providers": {
            "anthropic": {
                "url": s.upstream,
                "models": ["*"],
                "parser": "claude",
            },
        },
        "hub": {
            "token": "${CC_GUARD_HUB_TOKEN}",
        },
        "log": {
            "dir": str(hub_log_dir()),
            "body_mode": "messages",
        },
    }

    from .plugin_config import enabled_plugins_for_flowlens
    from .plugins import PluginSide

    server_plugins = enabled_plugins_for_flowlens(PluginSide.SERVER)
    if server_plugins:
        cfg["plugins"] = server_plugins

    return cfg


_HUB_GENERATED_HEADER = (
    "# Managed by cc-guard — regenerate with `ccg hub install`.\n"
    "# Manual edits allowed but will be overwritten on the next hub install.\n\n"
)


def write_hub_config(cfg: dict[str, Any], path: Path | None = None) -> Path:
    """Write the hub config atomically. Creates parent dir, 0600 perms."""
    path = path or hub_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    body = _HUB_GENERATED_HEADER + yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    try:
        tmp.write_text(body)
        os.replace(tmp, path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise
    os.chmod(path, 0o600)
    return path


_GENERATED_HEADER = (
    "# Managed by cc-guard — regenerate with `ccg install`.\n"
    "# Manual edits are allowed but will be overwritten on the next install.\n"
    "# For a fully custom config, use `ccg install --sidecar-config PATH`.\n\n"
)


def write_sidecar_config(cfg: dict[str, Any], path: Path | None = None) -> Path:
    """Write the generated config atomically. Creates parent dir, 0600 perms."""
    path = path or sidecar_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    body = _GENERATED_HEADER + yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    try:
        tmp.write_text(body)
        os.replace(tmp, path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise
    os.chmod(path, 0o600)
    return path


def write_hub_token(token: str) -> Path:
    """Store the hub token at 0600 perms in ~/.cc-guard/hub-token.

    Kept out of state.yaml (which is readable) and out of sidecar.yaml
    (which is regenerated by `ccg install`). We export it as an env var
    when we launch the sidecar subprocess.
    """
    path = hub_token_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(token + "\n")
    os.chmod(path, 0o600)
    return path


def read_hub_token() -> str | None:
    path = hub_token_file()
    if not path.exists():
        return None
    return path.read_text().strip() or None


def remove_hub_token() -> None:
    path = hub_token_file()
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


# ── runner discovery ───────────────────────────────────────

def find_flow_runner() -> list[str] | None:
    """Return the command-line prefix for launching flowlens, or None.

    Preference order:
      1. `flow` executable on PATH (user installed flowlens separately)
      2. `python -m flowlens` (cc-guard[sidecar] extra pulled it in;
         flowlens is importable from the current interpreter)

    Returns a list like ["flow"] or [sys.executable, "-m", "flowlens"],
    ready to be extended with `run -c <config>` by the caller.
    """
    flow_bin = shutil.which("flow")
    if flow_bin:
        return [flow_bin]

    # Fallback: can we import flowlens from here?
    try:
        import flowlens  # noqa: F401
    except ImportError:
        return None
    return [sys.executable, "-m", "flowlens"]


class FlowlensNotInstalled(RuntimeError):
    """Raised when cc-guard can't find any way to launch flowlens."""


# ── process lifecycle ──────────────────────────────────────

@dataclass
class ManagedSidecarHandle:
    """What gets written to state.yaml for tracking the spawned process."""
    pid: int
    config_path: str
    started_at: str           # ISO 8601
    listen: str               # host:port form


def _port_in_use(host: str, port: int) -> bool:
    """Best-effort TCP bind check. False if the port is free.

    On POSIX we set SO_REUSEADDR to avoid spurious "in use" errors from
    sockets stuck in TIME_WAIT. On Windows SO_REUSEADDR has the OPPOSITE
    semantics (it allows two simultaneous active binds, defeating this
    check entirely), so we deliberately skip it there.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        if os.name != "nt":
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((host, port))
            return False
        except OSError:
            return True


def _split_host_port(host_port: str, default_host: str = "127.0.0.1") -> tuple[str, int]:
    """Parse listen string like '127.0.0.1:9999' or ':9999'."""
    if ":" not in host_port:
        return default_host, int(host_port)
    host, port = host_port.rsplit(":", 1)
    return (host or default_host), int(port)


def _start_managed_flowlens(
    *,
    config_path: Path,
    listen: str,
    hub_token: str | None,
    pid_file: Path,
    log_path: Path,
    label: str,
    running_check: Callable[[], dict[str, Any]],
) -> ManagedSidecarHandle:
    """Shared spawn logic for both sidecar and hub flowlens processes.

    The two differ only in which pid/log files they write to and what
    status function to consult for "already running" guarding. All the
    real work (port probe, runner discovery, env, detach, readiness
    polling) is identical.
    """
    existing = running_check()
    if existing["state"] == "running":
        raise RuntimeError(
            f"{label} already running (pid {existing['pid']}); stop it first"
        )

    runner = find_flow_runner()
    if runner is None:
        raise FlowlensNotInstalled(
            f"flowlens is required for managed {label} but not found. "
            "Install it with `uv tool install cc-guard[sidecar]` or "
            "`pip install flowlens`."
        )

    host, port = _split_host_port(_parse_listen(listen))
    if _port_in_use(host, port):
        raise RuntimeError(
            f"port {host}:{port} is already in use. "
            f"Check if another {label} is running or stop the conflicting process."
        )

    cmd = [*runner, "run", "-c", str(config_path)]

    env = os.environ.copy()
    if hub_token:
        env["CC_GUARD_HUB_TOKEN"] = hub_token

    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_fh = open(log_path, "ab", buffering=0)

    detach_kwargs: dict[str, Any] = {}
    if os.name == "nt":
        detach_kwargs["creationflags"] = (
            _WIN32_DETACHED_PROCESS | _WIN32_CREATE_NEW_PROCESS_GROUP
        )
    else:
        detach_kwargs["start_new_session"] = True

    proc = subprocess.Popen(
        cmd,
        env=env,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        **detach_kwargs,
    )

    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            log_fh.close()
            try:
                tail = log_path.read_text()[-800:]
            except OSError:
                tail = ""
            raise RuntimeError(
                f"{label} exited with code {proc.returncode} before binding. "
                f"Log tail:\n{tail}"
            )
        if _port_in_use(host, port):
            break
        time.sleep(0.05)

    pid = proc.pid
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(pid))

    from datetime import datetime, timezone
    return ManagedSidecarHandle(
        pid=pid,
        config_path=str(config_path),
        started_at=datetime.now(timezone.utc).isoformat(),
        listen=f"{host}:{port}",
    )


def start_managed_sidecar(
    config_path: Path,
    listen: str,
    hub_token: str | None = None,
) -> ManagedSidecarHandle:
    """Spawn a sidecar subprocess and write its pid to ~/.cc-guard/sidecar.pid."""
    return _start_managed_flowlens(
        config_path=config_path,
        listen=listen,
        hub_token=hub_token,
        pid_file=sidecar_pid_file(),
        log_path=sidecar_stdout_log(),
        label="sidecar",
        running_check=sidecar_status,
    )


def start_managed_hub(
    config_path: Path,
    listen: str,
    hub_token: str | None = None,
) -> ManagedSidecarHandle:
    """Spawn a hub flowlens subprocess (mode=hub) and write its pid to ~/.cc-guard/hub.pid."""
    return _start_managed_flowlens(
        config_path=config_path,
        listen=listen,
        hub_token=hub_token,
        pid_file=hub_pid_file(),
        log_path=hub_stdout_log(),
        label="hub",
        running_check=hub_status,
    )


def _is_pid_alive(pid: int) -> bool:
    """Cross-platform PID liveness check.

    POSIX: signal 0 tests for existence without actually killing the process.
    Windows: os.kill(pid, 0) would call TerminateProcess and actually kill
    it (Python docs explicit warning). Use psutil.pid_exists instead.
    psutil is a required dependency so the import always succeeds.
    """
    if os.name == "nt":
        import psutil
        return psutil.pid_exists(pid)

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # process exists but owned by someone else; still "alive"
        return True
    return True


def _stop_managed_flowlens(pid_file: Path, timeout: float = 5.0) -> dict[str, Any]:
    """Send SIGTERM to the managed process identified by `pid_file` and wait."""
    if not pid_file.exists():
        return {"state": "not_running", "pid": None}

    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        pid_file.unlink(missing_ok=True)
        return {"state": "not_running", "pid": None}

    if not _is_pid_alive(pid):
        pid_file.unlink(missing_ok=True)
        return {"state": "not_running", "pid": pid}

    # First-pass termination signal.
    # POSIX SIGTERM = polite ask. Windows SIGTERM is actually TerminateProcess
    # (immediate strong kill) — there's no graceful-stop concept on Windows.
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pid_file.unlink(missing_ok=True)
        return {"state": "not_running", "pid": pid}
    except OSError:
        pid_file.unlink(missing_ok=True)
        return {"state": "not_running", "pid": pid}

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _is_pid_alive(pid):
            pid_file.unlink(missing_ok=True)
            return {"state": "stopped", "pid": pid}
        time.sleep(0.1)

    # Didn't exit in time — escalate. SIGKILL only exists on POSIX; on
    # Windows the SIGTERM above already was TerminateProcess so escalation
    # doesn't gain anything, just retry once as a courtesy.
    if os.name == "nt":
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    else:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    pid_file.unlink(missing_ok=True)
    return {"state": "killed", "pid": pid}


def _managed_flowlens_status(pid_file: Path) -> dict[str, Any]:
    """Inspect a pid file and report liveness.

    Returns one of:
      - {state: "running", pid: int, uptime_s: float}
      - {state: "dead", pid: int}          (pid file stale)
      - {state: "not_managed", pid: None}  (no pid file at all)
    """
    if not pid_file.exists():
        return {"state": "not_managed", "pid": None}

    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        return {"state": "not_managed", "pid": None}

    if not _is_pid_alive(pid):
        return {"state": "dead", "pid": pid}

    uptime_s: float | None = None
    try:
        stat_path = Path(f"/proc/{pid}/stat")
        if stat_path.exists():
            mtime = stat_path.stat().st_mtime
            uptime_s = time.time() - mtime
    except OSError:
        uptime_s = None

    result: dict[str, Any] = {"state": "running", "pid": pid}
    if uptime_s is not None:
        result["uptime_s"] = round(uptime_s, 1)
    return result


def stop_managed_sidecar(timeout: float = 5.0) -> dict[str, Any]:
    """Send SIGTERM to the managed sidecar. Idempotent."""
    return _stop_managed_flowlens(sidecar_pid_file(), timeout=timeout)


def stop_managed_hub(timeout: float = 5.0) -> dict[str, Any]:
    """Send SIGTERM to the managed hub. Idempotent."""
    return _stop_managed_flowlens(hub_pid_file(), timeout=timeout)


def sidecar_status() -> dict[str, Any]:
    return _managed_flowlens_status(sidecar_pid_file())


def hub_status() -> dict[str, Any]:
    return _managed_flowlens_status(hub_pid_file())
