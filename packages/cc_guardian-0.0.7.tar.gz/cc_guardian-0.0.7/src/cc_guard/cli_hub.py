"""CLI sub-app: `cc-guard hub ...`.

Mirror of the sidecar lifecycle commands, but for a hub-mode flowlens
process. Hubs are typically deployed separately from sidecars — this
sub-app is here so a hub operator can use the same cc-guard binary
they already know.
"""

from __future__ import annotations

import secrets
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from . import sidecar as sidecar_mgmt
from .sidecar import (
    FlowlensNotInstalled,
    HubSettings,
    build_hub_config,
    hub_config_path,
    hub_stdout_log,
    read_hub_token,
    start_managed_hub,
    stop_managed_hub,
    write_hub_config,
    write_hub_token,
)

hub_app = typer.Typer(
    name="hub",
    help="Manage a flowlens hub-mode process (centralized audit + server-side plugins).",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


@hub_app.command("install")
def install_cmd(
    listen: Annotated[
        str,
        typer.Option("--listen", help="Bind address, e.g. 0.0.0.0:8787"),
    ],
    token: Annotated[
        Optional[str],
        typer.Option(
            "--token",
            help="Bearer token sidecars must send. Auto-generated if omitted.",
        ),
    ] = None,
    upstream: Annotated[
        str,
        typer.Option(
            "--upstream",
            help="Upstream LLM URL (for provider config, not proxied here).",
        ),
    ] = "https://api.anthropic.com",
    start: Annotated[
        bool,
        typer.Option("--start/--no-start", help="Start the hub process after writing config."),
    ] = True,
) -> None:
    """Generate ~/.cc-guard/hub.yaml and (optionally) start the hub process."""
    if token is None:
        token = "hub_" + secrets.token_urlsafe(24)
        console.print(f"[green]✓[/] generated hub token: {token}")
        console.print("  [yellow]save this — sidecars pointing at this hub will need it[/]")

    cfg = build_hub_config(HubSettings(listen=listen, token=token, upstream=upstream))
    cfg_path = write_hub_config(cfg)
    write_hub_token(token)
    console.print(f"[green]✓[/] wrote {cfg_path}")

    if not start:
        console.print("[dim]hub not started (--no-start)[/]")
        return

    # Stop any stale hub before starting, so `install` is re-runnable
    prev = sidecar_mgmt.hub_status()
    if prev["state"] == "running":
        console.print("[dim]stopping previous hub...[/]")
        stop_managed_hub()

    try:
        handle = start_managed_hub(
            config_path=cfg_path,
            listen=listen,
            hub_token=token,
        )
    except (FlowlensNotInstalled, RuntimeError) as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=1)
    console.print(
        f"[green]✓[/] hub started (pid {handle.pid}, listening on {handle.listen})"
    )


@hub_app.command("start")
def start_cmd() -> None:
    """Start a previously-configured hub process."""
    cfg_path = hub_config_path()
    if not cfg_path.exists():
        console.print(
            f"[red]error:[/] hub config not found at {cfg_path}. "
            "Run `cc-guard hub install` first."
        )
        raise typer.Exit(code=2)

    live = sidecar_mgmt.hub_status()
    if live["state"] == "running":
        console.print(f"hub already running (pid {live['pid']})")
        raise typer.Exit(code=0)

    token = read_hub_token()
    # Listen is embedded in the yaml config; rediscover it from there for
    # the port-probe inside start_managed_hub. We read instead of trusting
    # the user to pass it again.
    import yaml as _yaml
    cfg = _yaml.safe_load(cfg_path.read_text()) or {}
    listen = cfg.get("listen")
    if not listen:
        console.print(f"[red]error:[/] hub config missing `listen`: {cfg_path}")
        raise typer.Exit(code=1)

    try:
        handle = start_managed_hub(
            config_path=cfg_path,
            listen=str(listen),
            hub_token=token,
        )
    except (FlowlensNotInstalled, RuntimeError) as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=1)
    console.print(
        f"[green]✓[/] hub started (pid {handle.pid}, listening on {handle.listen})"
    )


@hub_app.command("stop")
def stop_cmd() -> None:
    """Stop the hub process."""
    result = stop_managed_hub()
    st = result["state"]
    if st == "stopped":
        console.print(f"[green]✓[/] hub stopped (pid {result['pid']})")
    elif st == "killed":
        console.print(f"[yellow]![/] hub force-killed (pid {result['pid']})")
    elif st == "not_running":
        console.print("[dim]hub was not running[/]")


@hub_app.command("restart")
def restart_cmd() -> None:
    """Stop then start the hub process (for picking up plugin changes)."""
    stop_cmd()
    start_cmd()


@hub_app.command("status")
def status_cmd() -> None:
    """Show hub liveness and config path."""
    live = sidecar_mgmt.hub_status()
    state = live["state"]
    if state == "running":
        uptime = live.get("uptime_s")
        suffix = f", uptime {uptime}s" if uptime is not None else ""
        console.print(f"[green]running[/] (pid {live['pid']}{suffix})")
    elif state == "dead":
        console.print(f"[red]dead[/] (stale pid {live['pid']})")
    elif state == "not_managed":
        console.print("[dim]not running[/]")
    console.print(f"  [dim]config: {hub_config_path()}[/]")
    console.print(f"  [dim]log:    {hub_stdout_log()}[/]")
