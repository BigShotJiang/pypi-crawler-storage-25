"""CLI sub-app: `cc-guard plugin ...`.

Thin adapter between the typer command surface and `plugin_config` /
`plugins.registry`. All config mutations go through `plugin_config`
helpers, which handle atomic writes and registry validation.
"""

from __future__ import annotations

from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from .plugin_config import (
    PluginEntry,
    PluginSideMismatchError,
    UnknownPluginError,
    apply_defaults,
    load_plugin_config,
    plugin_config_path,
    set_config_value,
    set_enabled,
)
from .plugins import BUILTIN_PLUGINS, PluginSide
from . import sidecar as sidecar_mgmt

plugin_app = typer.Typer(
    name="plugin",
    help="Manage built-in security plugins (declare in plugins.{client,server}.yaml).",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


def _parse_side(value: str, *, allow_all: bool = False) -> PluginSide:
    v = value.lower()
    if allow_all and v == "all":
        return PluginSide.BOTH
    if v == "client":
        return PluginSide.CLIENT
    if v == "server":
        return PluginSide.SERVER
    raise typer.BadParameter(
        f"side must be {'client|server|all' if allow_all else 'client|server'}, got {value!r}"
    )


def _coerce_scalar(raw: str):
    """Parse CLI config values: bool/int/float fall out of str when unambiguous."""
    low = raw.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if low == "null":
        return None
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        pass
    return raw


def _notify_restart_if_running(side: PluginSide) -> None:
    """Warn the user to restart the corresponding flowlens process if live."""
    if side == PluginSide.CLIENT:
        status = sidecar_mgmt.sidecar_status()
        if status["state"] == "running":
            console.print(
                "[yellow]![/] sidecar is running — restart with `cc-guard stop && cc-guard start` for changes to take effect"
            )
    elif side == PluginSide.SERVER:
        status = sidecar_mgmt.hub_status()
        if status["state"] == "running":
            console.print(
                "[yellow]![/] hub is running — restart with `cc-guard hub stop && cc-guard hub start` for changes to take effect"
            )


def _side_entries(side: PluginSide) -> dict[str, PluginEntry]:
    return {e.name: e for e in load_plugin_config(side)}


# ── commands ─────────────────────────────────────────────────

@plugin_app.command("list")
def list_cmd(
    side: Annotated[
        str,
        typer.Option("--side", help="client | server | all"),
    ] = "all",
) -> None:
    """List built-in plugins with enable state and current config."""
    want = _parse_side(side, allow_all=True)
    client_map = _side_entries(PluginSide.CLIENT)
    server_map = _side_entries(PluginSide.SERVER)

    sides_to_show: list[PluginSide] = []
    if want == PluginSide.BOTH:
        sides_to_show = [PluginSide.CLIENT, PluginSide.SERVER]
    else:
        sides_to_show = [want]

    for show_side in sides_to_show:
        entries_map = client_map if show_side == PluginSide.CLIENT else server_map
        table = Table(
            title=f"Plugins — side={show_side.value}",
            show_lines=False,
        )
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("State")
        table.add_column("Default?", no_wrap=True)
        table.add_column("Config")
        table.add_column("Description")

        for meta in BUILTIN_PLUGINS.values():
            if not meta.applicable_to(show_side):
                continue
            entry = entries_map.get(meta.name)
            if entry is None:
                state = "[dim]not set[/]"
                cfg_repr = "[dim]-[/]"
            else:
                state = "[green]enabled[/]" if entry.enabled else "[yellow]disabled[/]"
                cfg_repr = ", ".join(f"{k}={v}" for k, v in entry.config.items()) or "[dim]-[/]"
            is_default = "yes" if show_side in meta.default_profile else "[dim]no[/]"
            table.add_row(meta.name, state, is_default, cfg_repr, meta.description)
        console.print(table)
        console.print()


@plugin_app.command("enable")
def enable_cmd(
    name: Annotated[Optional[str], typer.Argument(help="Plugin name (omit with --defaults)")] = None,
    side: Annotated[
        Optional[str],
        typer.Option("--side", help="client | server (required unless --defaults)"),
    ] = None,
    defaults: Annotated[
        bool,
        typer.Option("--defaults", help="Enable every plugin on its registry default_profile side(s)."),
    ] = False,
) -> None:
    """Enable a plugin on a given side, or seed both sides from default profiles."""
    if defaults:
        if name or side:
            console.print("[red]error:[/] --defaults does not accept a name or --side")
            raise typer.Exit(code=2)
        newly = apply_defaults()
        any_changes = False
        for s, names in newly.items():
            if names:
                any_changes = True
                console.print(f"[green]✓[/] {s.value}: enabled {', '.join(names)}")
        if not any_changes:
            console.print("[dim]all default plugins already enabled[/]")
        _notify_restart_if_running(PluginSide.CLIENT)
        _notify_restart_if_running(PluginSide.SERVER)
        return

    if name is None or side is None:
        console.print("[red]error:[/] specify NAME and --side, or use --defaults")
        raise typer.Exit(code=2)

    parsed_side = _parse_side(side)
    try:
        entry = set_enabled(parsed_side, name, True)
    except (UnknownPluginError, PluginSideMismatchError) as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=2)
    console.print(f"[green]✓[/] enabled {name} on {parsed_side.value}")
    console.print(f"  [dim]declaration: {plugin_config_path(parsed_side)}[/]")
    if entry.config:
        cfg_repr = ", ".join(f"{k}={v}" for k, v in entry.config.items())
        console.print(f"  [dim]config: {cfg_repr}[/]")
    _notify_restart_if_running(parsed_side)


@plugin_app.command("disable")
def disable_cmd(
    name: Annotated[str, typer.Argument(help="Plugin name")],
    side: Annotated[str, typer.Option("--side", help="client | server")],
) -> None:
    """Disable a plugin on a given side."""
    parsed_side = _parse_side(side)
    try:
        set_enabled(parsed_side, name, False)
    except (UnknownPluginError, PluginSideMismatchError) as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=2)
    console.print(f"[green]✓[/] disabled {name} on {parsed_side.value}")
    _notify_restart_if_running(parsed_side)


@plugin_app.command("config")
def config_cmd(
    name: Annotated[str, typer.Argument(help="Plugin name")],
    side: Annotated[str, typer.Option("--side", help="client | server")],
    set_items: Annotated[
        Optional[list[str]],
        typer.Option("--set", help="key=value (repeat for multiple). Values parsed as bool/int/float/string."),
    ] = None,
) -> None:
    """Set config values on a plugin. Validation is deferred to engine construction."""
    parsed_side = _parse_side(side)
    if not set_items:
        console.print("[red]error:[/] at least one --set key=value required")
        raise typer.Exit(code=2)

    for item in set_items:
        if "=" not in item:
            console.print(f"[red]error:[/] --set expects key=value, got {item!r}")
            raise typer.Exit(code=2)
        key, raw = item.split("=", 1)
        value = _coerce_scalar(raw)
        try:
            set_config_value(parsed_side, name, key.strip(), value)
        except (UnknownPluginError, PluginSideMismatchError) as e:
            console.print(f"[red]error:[/] {e}")
            raise typer.Exit(code=2)
        console.print(
            f"[green]✓[/] {name} [cyan]({parsed_side.value})[/] "
            f"{key.strip()} = {value!r}"
        )
    _notify_restart_if_running(parsed_side)


@plugin_app.command("show")
def show_cmd(
    name: Annotated[str, typer.Argument(help="Plugin name")],
) -> None:
    """Show registry metadata + current config on both sides."""
    meta = BUILTIN_PLUGINS.get(name)
    if meta is None:
        console.print(f"[red]error:[/] unknown plugin {name!r}")
        raise typer.Exit(code=2)

    console.print(f"[bold cyan]{meta.name}[/]")
    console.print(f"  [cyan]module[/]:         {meta.module}")
    console.print(f"  [cyan]side[/]:           {meta.side.value}")
    console.print(f"  [cyan]description[/]:    {meta.description}")
    console.print(
        f"  [cyan]default profile[/]: "
        + (", ".join(s.value for s in meta.default_profile) if meta.default_profile else "[dim]none[/]")
    )
    console.print(f"  [cyan]default config[/]: {meta.default_config or '[dim]empty[/]'}")
    console.print()

    for side in (PluginSide.CLIENT, PluginSide.SERVER):
        if not meta.applicable_to(side):
            continue
        entries = _side_entries(side)
        entry = entries.get(name)
        if entry is None:
            console.print(f"  [dim]{side.value}: not set[/]")
            continue
        state = "[green]enabled[/]" if entry.enabled else "[yellow]disabled[/]"
        cfg = entry.config or "[dim]empty[/]"
        console.print(f"  {side.value}: {state}  config={cfg}")
