"""Tiny i18n — two side-by-side classes, one per language.

Why this shape:
- ~50 strings is not enough to justify gettext / a key→dict abstraction.
- Two classes mean adding/removing a string is a one-line property edit
  in two adjacent files, and the IDE catches `t().nonexistent_attr`.
- Translation completeness is enforced by Python itself: if `Zh` is
  missing a property that `En` has, the first call site that touches
  it raises AttributeError loudly. No "completeness" test needed.

Resolution priority for the active language:
  1. StateStore's persisted `language` (set via wizard menu)
  2. Auto-detect from $LANG / $LC_ALL / $LC_MESSAGES (zh* → "zh")
  3. English fallback

Public surface:
  - `t()`                  — return the active strings namespace
  - `current_language()`   — what's active right now ("en" / "zh")
  - `set_language(lang)`   — persist a new choice + clear cache
  - `available_languages()` — for the wizard's selection menu
  - `reset_cache()`        — for tests
"""

from __future__ import annotations

import os
from typing import Literal

# ── Supported languages ─────────────────────────────────────

Language = Literal["en", "zh"]
SUPPORTED: tuple[Language, ...] = ("en", "zh")
_DEFAULT: Language = "en"


def available_languages() -> list[tuple[Language, str]]:
    """Return [(code, display_name)] for the wizard's selection menu."""
    return [
        ("en", "English"),
        ("zh", "中文 (Chinese)"),
    ]


# ── Detection ───────────────────────────────────────────────

def _detect_from_env() -> Language:
    """Inspect $LC_ALL / $LC_MESSAGES / $LANG (POSIX convention).
    First non-empty wins; if it starts with `zh`, return Chinese.
    """
    for var in ("LC_ALL", "LC_MESSAGES", "LANG"):
        val = os.environ.get(var, "")
        if val:
            # Strip encoding/modifier suffixes: "zh_CN.UTF-8" -> "zh_cn"
            base = val.split(".", 1)[0].split("@", 1)[0].lower()
            return "zh" if base.startswith("zh") else "en"
    return _DEFAULT


def _resolve_active_language() -> Language:
    """Apply the priority chain. StateStore is imported lazily so this
    module has no hard dependency on state.py (avoids import cycles).
    """
    try:
        from .state import StateStore
        persisted = StateStore().get_language()
        if persisted in SUPPORTED:
            return persisted  # type: ignore[return-value]
    except Exception:
        pass
    return _detect_from_env()


# Cached so repeated `t()` calls in a single command don't re-read state.yaml.
# `set_language()` clears it; tests use `reset_cache()`.
_cached_lang: Language | None = None


def current_language() -> Language:
    global _cached_lang
    if _cached_lang is None:
        _cached_lang = _resolve_active_language()
    return _cached_lang


def set_language(lang: Language) -> None:
    """Persist a new language choice and clear the cache."""
    global _cached_lang
    if lang not in SUPPORTED:
        raise ValueError(f"unsupported language: {lang!r}; supported={SUPPORTED}")
    from .state import StateStore
    StateStore().set_language(lang)
    _cached_lang = lang


def reset_cache() -> None:
    """For tests — force the next `t()` call to re-resolve from env/state."""
    global _cached_lang
    _cached_lang = None


# ── Active namespace lookup ─────────────────────────────────

def t() -> type["En"]:
    """Return the active strings namespace.

    Usage:
        from .i18n import t
        console.print(t().tagline)
        console.print(t().will_install.format(url=upstream))
    """
    if current_language() == "zh":
        return Zh  # type: ignore[return-value]
    return En


# ══════════════════════════════════════════════════════════
#  STRINGS — En is the source of truth, Zh mirrors it.
#  Adding a new string: add to BOTH classes with the same attr name.
#  Forgot to translate? AttributeError fires the first time it's used.
# ══════════════════════════════════════════════════════════

class En:
    """All English user-facing strings, in one scroll."""

    # ── Wizard main panel ──
    tagline = "Claude Code security gateway"
    subtitle = "audit · policy · clean teardown"
    summary_installed_yes = "Installed:   yes → {url}"
    summary_installed_no = "Installed:   no"
    summary_current_url = "Current URL: {url}  (set externally, not by cc-guard)"
    summary_shell_env_warning = (
        "Shell env:   ANTHROPIC_BASE_URL={val} will override settings.json"
    )
    summary_shell_rc_conflict = (
        "Shell rc:    {path} has {n} conflicting export(s)"
    )

    # ── Wizard main menu ──
    menu_prompt = "What would you like to do?"
    menu_install = "Install   — set up the gateway with current defaults"
    menu_uninstall = "Uninstall — restore original settings"
    menu_configure = "Configure — edit Hub URL, token, and other defaults"
    menu_doctor = "Doctor    — run diagnostic checks"
    menu_status = "Status    — show current state only"
    menu_language = "Language  — switch English / 中文"
    menu_exit = "Exit"

    # ── Language picker ──
    language_prompt = "Choose a language:"
    language_changed = "Language set to {lang}."

    # ── Wizard install flow (single-confirm summary) ──
    install_summary_title = "About to install:"
    install_summary_listen = "  Local route:    {url}"
    install_summary_upstream = "  Upstream:       {url}"
    install_summary_sidecar_on = "  Sidecar:        on"
    install_summary_sidecar_off = (
        "  Sidecar:        off  (you must run your own proxy on this port)"
    )
    install_summary_hub_set = "  Hub:            {url}"
    install_summary_hub_unset = "  Hub:            ⚠ not set"
    install_summary_mode_remote = "  Audit mode:     remote (sidecar mode — via hub)"
    install_summary_mode_local = (
        "  Audit mode:     local (proxy mode — no remote review)"
    )
    install_summary_timeout = "  API timeout:    {ms} ms"
    install_summary_no_timeout = "  API timeout:    not set"
    install_hint_no_hub = (
        "→ Want remote audit? Go back to main menu → Configure → set Hub URL"
    )
    install_prompt_proceed = "Proceed?"
    install_prompt_proceed_no_hub = "Continue with local-only audit?"
    cancelled = "Cancelled."
    install_prompt_hub_token_missing = (
        "Hub URL is set but no Hub token configured. Set the token in "
        "Configure first, or remove the Hub URL to install in local mode."
    )

    # ── Configure menu ──
    configure_title = "Configure"
    configure_prompt = "Configure what?"
    configure_hub_url = "Hub URL:       {value}"
    configure_hub_token = "Hub token:     {value}"
    configure_listen = "Local route:   {value}"
    configure_upstream = "Upstream:      {value}"
    configure_api_timeout = "API timeout:   {value}"
    configure_sidecar = "Sidecar:       {value}"
    configure_reset = "── Reset to factory defaults"
    configure_back = "← Back to main menu"
    configure_value_unset = "(not set)"
    configure_value_set = "(set)"

    # ── Configure field editors ──
    configure_edit_hub_url = "Hub URL (empty to clear):"
    configure_edit_hub_token = "Hub token (input hidden, empty to clear):"
    configure_edit_listen = "Local route URL:"
    configure_edit_upstream = "Upstream URL (where sidecar forwards to):"
    configure_edit_api_timeout = "API timeout in milliseconds (0 to clear):"
    configure_edit_sidecar = "Sidecar:"
    configure_edit_sidecar_on = "on  — cc-guard spawns flowlens"
    configure_edit_sidecar_off = "off — you run your own proxy"
    configure_saved = "Saved."
    configure_reset_done = "Defaults reset to factory values."
    configure_token_cleared = "Hub token cleared."
    configure_token_saved = "Hub token saved (0600)."

    # ── Wizard uninstall flow ──
    uninstall_not_installed = "Nothing to uninstall — cc-guard is not installed."
    uninstall_current = "Current install: {url}"
    uninstall_will_restore = "Will restore to: {url}"
    uninstall_will_remove = "Will restore to: removed (was unset before install)"
    uninstall_shell_rc_info = "Shell rc: {path} ({n} line(s) removed)"
    uninstall_prompt_restore_rc = "Also restore shell rc from backup?"

    # ── Status table ──
    status_title = "cc-guard status"
    status_installed = "Installed"
    status_installed_yes = "yes ({when})"
    status_installed_no = "no"
    status_routed_to = "Routed to"
    status_routed_to_external = "{url}  (set externally, not by cc-guard)"
    status_routed_to_unset = "not set — Claude Code → api.anthropic.com directly"
    status_drift_label = "drift"
    status_drift_value = (
        "settings.json says {url} — does not match install record"
    )
    status_restores_to = "Restores to"
    status_api_timeout = "API timeout"
    status_settings_file = "Settings file"
    status_shell_rc = "Shell rc"
    status_shell_rc_value = "{path} ({n} line(s) removed, backup preserved)"
    status_sidecar = "Sidecar"
    status_sidecar_running = "running (pid {pid}{uptime})"
    status_sidecar_dead = "dead (recorded pid {pid}, process not alive anymore)"
    status_sidecar_pid_missing = "pid file missing (was pid {pid})"
    status_sidecar_drift_label = "sidecar drift"
    status_sidecar_drift_value = (
        "sidecar bound to {bound} but Claude Code is routed to {routed} — "
        "requests will not reach the sidecar"
    )
    status_sidecar_config = "Sidecar config"
    status_hint_install = "Run `cc-guard install URL` to install."


class Zh:
    """All Chinese user-facing strings, in one scroll.

    属性名必须和 En 一一对应。漏了 IDE 不警告但运行时会 AttributeError,
    所以新增字符串时务必两边都加。
    """

    # ── Wizard 主面板 ──
    tagline = "Claude Code 安全网关"
    subtitle = "审计 · 策略 · 干净卸载"
    summary_installed_yes = "已安装:      是 → {url}"
    summary_installed_no = "已安装:      否"
    summary_current_url = "当前 URL:    {url}  (外部设置,非 cc-guard)"
    summary_shell_env_warning = (
        "Shell 环境:  ANTHROPIC_BASE_URL={val} 会覆盖 settings.json"
    )
    summary_shell_rc_conflict = "Shell rc:    {path} 有 {n} 条冲突的 export 行"

    # ── Wizard 主菜单 ──
    menu_prompt = "你想做什么?"
    menu_install = "安装       — 用当前默认值启动安全网关"
    menu_uninstall = "卸载       — 还原原始配置"
    menu_configure = "配置       — 编辑 Hub URL / Token / 默认值"
    menu_doctor = "诊断       — 运行体检检查"
    menu_status = "状态       — 只显示当前状态"
    menu_language = "语言       — 切换 English / 中文"
    menu_exit = "退出"

    # ── 语言选择 ──
    language_prompt = "选择语言:"
    language_changed = "语言已设置为 {lang}。"

    # ── Wizard 安装流程 (单确认) ──
    install_summary_title = "即将安装:"
    install_summary_listen = "  本地路由:      {url}"
    install_summary_upstream = "  上游地址:      {url}"
    install_summary_sidecar_on = "  Sidecar:       开启"
    install_summary_sidecar_off = "  Sidecar:       关闭 (你需要自己启动代理)"
    install_summary_hub_set = "  Hub:           {url}"
    install_summary_hub_unset = "  Hub:           ⚠ 未设置"
    install_summary_mode_remote = "  审核模式:      远程 (sidecar 模式 — 经 hub 审核)"
    install_summary_mode_local = "  审核模式:      本地 (proxy 模式 — 无远程审核)"
    install_summary_timeout = "  API 超时:      {ms} 毫秒"
    install_summary_no_timeout = "  API 超时:      未设置"
    install_hint_no_hub = (
        "→ 想使用远程审核?返回主菜单 → 配置 → 设置 Hub URL"
    )
    install_prompt_proceed = "确认?"
    install_prompt_proceed_no_hub = "以仅本地模式继续?"
    cancelled = "已取消。"
    install_prompt_hub_token_missing = (
        "Hub URL 已设置但 Hub token 未配置。请先在配置中设置 token,"
        "或清空 Hub URL 以本地模式安装。"
    )

    # ── 配置菜单 ──
    configure_title = "配置"
    configure_prompt = "配置什么?"
    configure_hub_url = "Hub URL:       {value}"
    configure_hub_token = "Hub token:     {value}"
    configure_listen = "本地路由:      {value}"
    configure_upstream = "上游地址:      {value}"
    configure_api_timeout = "API 超时:      {value}"
    configure_sidecar = "Sidecar:       {value}"
    configure_reset = "── 重置为出厂默认"
    configure_back = "← 返回主菜单"
    configure_value_unset = "(未设置)"
    configure_value_set = "(已设置)"

    # ── 配置字段编辑 ──
    configure_edit_hub_url = "Hub URL (留空清除):"
    configure_edit_hub_token = "Hub token (隐藏输入,留空清除):"
    configure_edit_listen = "本地路由 URL:"
    configure_edit_upstream = "上游 URL (sidecar 转发目标):"
    configure_edit_api_timeout = "API 超时(毫秒,0 清除):"
    configure_edit_sidecar = "Sidecar:"
    configure_edit_sidecar_on = "开启 — cc-guard 启动 flowlens"
    configure_edit_sidecar_off = "关闭 — 你自己运行代理"
    configure_saved = "已保存。"
    configure_reset_done = "默认值已重置为出厂值。"
    configure_token_cleared = "Hub token 已清除。"
    configure_token_saved = "Hub token 已保存 (0600)。"

    # ── Wizard 卸载流程 ──
    uninstall_not_installed = "没有可卸载的内容 — cc-guard 未安装。"
    uninstall_current = "当前安装: {url}"
    uninstall_will_restore = "将还原为: {url}"
    uninstall_will_remove = "将还原为: 删除 (安装前本来就未设置)"
    uninstall_shell_rc_info = "Shell rc: {path} (移除了 {n} 行)"
    uninstall_prompt_restore_rc = "同时从备份还原 shell rc 吗?"

    # ── 状态表格 ──
    status_title = "cc-guard 状态"
    status_installed = "已安装"
    status_installed_yes = "是 ({when})"
    status_installed_no = "否"
    status_routed_to = "路由到"
    status_routed_to_external = "{url}  (外部设置,非 cc-guard)"
    status_routed_to_unset = "未设置 — Claude Code 直连 api.anthropic.com"
    status_drift_label = "漂移"
    status_drift_value = "settings.json 里是 {url} — 和安装记录不一致"
    status_restores_to = "卸载还原为"
    status_api_timeout = "API 超时"
    status_settings_file = "Settings 文件"
    status_shell_rc = "Shell rc"
    status_shell_rc_value = "{path} (移除 {n} 行,备份已保留)"
    status_sidecar = "Sidecar"
    status_sidecar_running = "运行中 (pid {pid}{uptime})"
    status_sidecar_dead = "已死 (记录 pid {pid},进程已不存在)"
    status_sidecar_pid_missing = "pid 文件丢失 (原 pid {pid})"
    status_sidecar_drift_label = "sidecar 漂移"
    status_sidecar_drift_value = (
        "sidecar 绑定在 {bound},但 Claude Code 路由到 {routed} — "
        "请求到不了 sidecar"
    )
    status_sidecar_config = "Sidecar 配置"
    status_hint_install = "运行 `cc-guard install URL` 来安装。"
