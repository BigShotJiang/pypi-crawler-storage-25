"""CLI entry point — four commands: install, uninstall, status, doctor.

All commands are thin wrappers around the pure-function modules
(claude_code, shell_rc, state, doctor). This keeps the CLI testable via
typer.testing.CliRunner without real HTTP / filesystem side effects.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from . import __version__
from .claude_code import (
    BACKUP_KEY,
    BASE_URL_KEY,
    API_TIMEOUT_KEY,
    ClaudeCodeManager,
)
from .doctor import run_all_checks, summarize
from .shell_rc import (
    detect_shell_rc,
    remove_lines,
    restore_from_backup,
    scan_for_base_url,
)
from . import sidecar as sidecar_mgmt
from .sidecar import (
    FlowlensNotInstalled,
    ManagedSidecarHandle,
    SidecarSettings,
    build_sidecar_config,
    remove_hub_token,
    sidecar_config_path,
    start_managed_sidecar,
    stop_managed_sidecar,
    write_hub_token,
    write_sidecar_config,
)
from .state import InstallRecord, ManagedSidecar, ShellRcChange, StateStore

app = typer.Typer(
    name="cc-guard",
    help=(
        "Security gateway for Claude Code traffic.\n\n"
        "Routes Claude Code's API calls through a local middleware (flowlens or "
        "any anthropic-compatible proxy) so you can inspect, log, and block "
        "requests. Clean install/uninstall — never touches your credentials.\n\n"
        "Run `cc-guard` with no arguments to launch the interactive wizard."
    ),
    no_args_is_help=False,
    invoke_without_command=True,
    add_completion=False,
)
console = Console()

from .cli_plugin import plugin_app  # noqa: E402
from .cli_hub import hub_app  # noqa: E402

app.add_typer(plugin_app, name="plugin")
app.add_typer(hub_app, name="hub")

TOOL_NAME = "claude-code"   # only tool supported in v0.1


@app.callback(invoke_without_command=True)
def _main(ctx: typer.Context) -> None:
    """Entry point: if no subcommand, drop into the interactive wizard."""
    if ctx.invoked_subcommand is not None:
        return

    # Zero-arg invocation → interactive wizard
    from . import wizard

    wizard.run_main_menu(
        install_fn=lambda url, timeout, sc_settings, sc_config: _do_install(
            url,
            api_timeout=timeout,
            sidecar_settings=sc_settings,
            sidecar_config_override=sc_config,
        ),
        uninstall_fn=lambda restore: _do_uninstall(restore_shell_rc=restore),
        status_fn=lambda: status(),
        doctor_fn=lambda: doctor(no_probe=False),
    )


# ── install ──────────────────────────────────────────────────

@app.command()
def install(
    upstream: Annotated[
        Optional[str],
        typer.Argument(
            metavar="URL",
            help="Local proxy URL (e.g. http://127.0.0.1:9999). "
                 "This is what Claude Code's ANTHROPIC_BASE_URL gets set to. "
                 "Omit for interactive wizard.",
        ),
    ] = None,
    api_timeout: Annotated[
        Optional[int],
        typer.Option(
            "--api-timeout", "-t",
            help="Inject env.API_TIMEOUT_MS (milliseconds). Useful for long-running tasks.",
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Preview changes without writing anything"),
    ] = False,
    # ── sidecar management (opt-in) ────────────────────────────
    start_sidecar: Annotated[
        bool,
        typer.Option(
            "--sidecar", "-s",
            help="Also spawn a flowlens sidecar process on URL. Requires "
                 "flowlens (install with `uv tool install cc-guard[sidecar]`).",
        ),
    ] = False,
    forward_upstream: Annotated[
        Optional[str],
        typer.Option(
            "--upstream", "-U",
            help="Where the sidecar forwards traffic. Default: "
                 "https://api.anthropic.com. Implies --sidecar.",
        ),
    ] = None,
    hub_url: Annotated[
        Optional[str],
        typer.Option(
            "--hub",
            help="Remote flowlens hub URL for centralized audit/inspect. "
                 "Implies --sidecar and uses sidecar mode.",
        ),
    ] = None,
    hub_token: Annotated[
        Optional[str],
        typer.Option(
            "--hub-token",
            help="Bearer token for the hub. Stored at ~/.cc-guard/hub-token "
                 "(0600) and exported to the sidecar via CC_GUARD_HUB_TOKEN. "
                 "Required with --hub.",
        ),
    ] = None,
    sidecar_config_override: Annotated[
        Optional[Path],
        typer.Option(
            "--sidecar-config",
            help="Use a hand-written sidecar config instead of the one "
                 "cc-guard generates. Implies --sidecar.",
        ),
    ] = None,
) -> None:
    """Install a security gateway for Claude Code traffic, optionally managing the sidecar.

    \b
    Examples:
      cc-guard install                                   # interactive wizard
      cc-guard install http://127.0.0.1:9999             # just patch settings
      cc-guard install http://127.0.0.1:9999 -s          # + spawn sidecar
      cc-guard install http://127.0.0.1:9999 --hub https://hub.example.com \\
                                              --hub-token $TOKEN   # + hub
      cc-guard install http://127.0.0.1:9999 --sidecar-config ~/my.yaml
      cc-guard install http://127.0.0.1:9999 -n          # dry-run preview
    """
    # Any sidecar-related flag implies --sidecar
    want_sidecar = (
        start_sidecar
        or forward_upstream is not None
        or hub_url is not None
        or sidecar_config_override is not None
    )

    if upstream is None:
        # Interactive wizard
        from . import wizard
        store = StateStore()
        wizard.run_install_wizard(
            install_fn=lambda url, timeout, sc_settings, sc_config: _do_install(
                url,
                api_timeout=timeout,
                dry_run=dry_run,
                sidecar_settings=sc_settings,
                sidecar_config_override=sc_config,
            ),
            store=store,
        )
        return

    # Non-wizard path: build SidecarSettings if the user asked for sidecar
    sc_settings: SidecarSettings | None = None
    if want_sidecar and sidecar_config_override is None:
        if hub_url is not None and not hub_token:
            console.print("[red]error:[/] --hub requires --hub-token")
            raise typer.Exit(code=1)
        sc_settings = SidecarSettings(
            listen=upstream,
            upstream=forward_upstream or "https://api.anthropic.com",
            hub_url=hub_url,
            hub_token=hub_token,
        )

    _do_install(
        upstream,
        api_timeout=api_timeout,
        dry_run=dry_run,
        sidecar_settings=sc_settings,
        sidecar_config_override=sidecar_config_override,
    )


def _do_install(
    upstream: str,
    *,
    api_timeout: int | None = None,
    dry_run: bool = False,
    sidecar_settings: SidecarSettings | None = None,
    sidecar_config_override: Path | None = None,
) -> None:
    """Shared install logic used by both CLI and wizard entry points.

    If `sidecar_settings` is given, cc-guard also:
      1. Generates ~/.cc-guard/sidecar.yaml from those settings
      2. Stores the hub token (if any) at ~/.cc-guard/hub-token (0600)
      3. Spawns a `flow run` subprocess and records its pid in state.yaml

    If `sidecar_config_override` is given, steps 1–2 are skipped and
    step 3 uses the user-provided config file directly.
    """
    mgr = ClaudeCodeManager()
    store = StateStore()
    want_sidecar = sidecar_settings is not None or sidecar_config_override is not None

    # Plan the changes
    current_base = mgr.current_base_url()

    if current_base == upstream and store.is_installed(TOOL_NAME) and not want_sidecar:
        console.print(f"[yellow]Already installed[/]: {BASE_URL_KEY} already = {upstream}")
        raise typer.Exit(code=0)

    # Check shell rc for conflicting exports
    rc_path = detect_shell_rc()
    rc_matches = []
    if rc_path is not None and rc_path.exists():
        rc_matches = scan_for_base_url(rc_path)

    # Check the current shell env — this is distinct from shell rc:
    # even if we clean the rc file, an existing shell session will still
    # have the variable in its environment until the user unsets it or
    # opens a new shell. settings.json is overridden by shell env.
    env_override = os.environ.get(BASE_URL_KEY)

    # Print the plan
    console.print()
    console.print("[bold]cc-guard install[/]")
    console.print()
    console.print(f"  [cyan]upstream[/]:     {upstream}")
    console.print(f"  [cyan]settings[/]:     {mgr.path}")
    if current_base:
        console.print(
            f"  [cyan]current url[/]:  {current_base}  [dim]→ will be backed up[/]"
        )
    else:
        console.print(f"  [cyan]current url[/]:  [dim]not set[/]")
    if api_timeout is not None:
        console.print(f"  [cyan]api timeout[/]: {api_timeout} ms")
    if rc_path is not None:
        if rc_matches:
            console.print(
                f"  [cyan]shell rc[/]:     {rc_path}  "
                f"[yellow]({len(rc_matches)} conflicting export(s) will be removed)[/]"
            )
        else:
            console.print(f"  [cyan]shell rc[/]:     {rc_path}  [dim](clean)[/]")
    if env_override is not None and env_override != upstream:
        console.print(
            f"  [cyan]shell env[/]:    [yellow]"
            f"ANTHROPIC_BASE_URL={env_override} is set in current shell[/]"
        )
        console.print(
            "                 [yellow]→ this will OVERRIDE settings.json "
            "until you `unset ANTHROPIC_BASE_URL` or open a new shell[/]"
        )

    # Sidecar plan
    if sidecar_config_override is not None:
        console.print(
            f"  [cyan]sidecar[/]:      spawn `flow run -c {sidecar_config_override}` "
            f"(user-provided config)"
        )
    elif sidecar_settings is not None:
        console.print(
            f"  [cyan]sidecar[/]:      generate {sidecar_config_path()} and spawn"
        )
        console.print(
            f"  [cyan]  upstream[/]:   {sidecar_settings.upstream}"
        )
        if sidecar_settings.hub_url:
            console.print(
                f"  [cyan]  hub[/]:        {sidecar_settings.hub_url} "
                f"[dim](mode: sidecar)[/]"
            )
        else:
            console.print("  [cyan]  mode[/]:       proxy (standalone,no hub)")

    console.print()

    if dry_run:
        console.print("[dim]Dry run — no changes written.[/]")
        raise typer.Exit(code=0)

    # ── Apply changes ───────────────────────────────────────
    try:
        result = mgr.install(upstream, api_timeout_ms=api_timeout)
    except (OSError, ValueError) as e:
        console.print(f"[red]error:[/] failed to write settings.json: {e}")
        raise typer.Exit(code=1)

    rc_changes: list[ShellRcChange] = []
    if rc_matches and rc_path is not None:
        line_numbers = {m.line_number for m in rc_matches}
        try:
            rc_backup = remove_lines(rc_path, line_numbers)
            rc_changes.append(ShellRcChange(
                path=str(rc_path),
                backup=str(rc_backup),
                removed_line_count=len(line_numbers),
            ))
        except OSError as e:
            console.print(f"[yellow]warning:[/] could not clean {rc_path}: {e}")

    # ── Sidecar: generate config (if needed) + spawn ────────
    managed: ManagedSidecar | None = None
    if want_sidecar:
        # Stop any existing managed sidecar so we can cleanly start a new one.
        # This makes `ccg install` re-runnable: users can iterate on hub/token
        # without a separate stop step.
        prev = sidecar_mgmt.sidecar_status()
        if prev["state"] == "running":
            console.print("[dim]stopping previous managed sidecar...[/]")
            sidecar_mgmt.stop_managed_sidecar()

        if sidecar_config_override is not None:
            cfg_path = sidecar_config_override.expanduser().resolve()
            if not cfg_path.exists():
                console.print(f"[red]error:[/] sidecar config not found: {cfg_path}")
                raise typer.Exit(code=1)
        else:
            assert sidecar_settings is not None
            cfg = build_sidecar_config(sidecar_settings)
            cfg_path = write_sidecar_config(cfg)
            console.print(f"[green]✓[/] generated sidecar config at {cfg_path}")
            if sidecar_settings.hub_token:
                write_hub_token(sidecar_settings.hub_token)
                console.print(f"[green]✓[/] hub token stored at ~/.cc-guard/hub-token (0600)")

        token_for_env = (
            sidecar_settings.hub_token
            if sidecar_settings is not None
            else None
        )
        try:
            handle = start_managed_sidecar(
                config_path=cfg_path,
                listen=upstream,
                hub_token=token_for_env,
            )
        except (FlowlensNotInstalled, RuntimeError) as e:
            console.print(f"[red]error:[/] {e}")
            # Rollback: settings.json was already modified by mgr.install()
            # above, but we never recorded the install to state.yaml. Without
            # rollback, `ccg uninstall` would say "not installed" and leave
            # settings.json in a dirty half-installed state.
            try:
                mgr.uninstall(had_api_timeout=api_timeout is not None)
                console.print("[dim]settings.json rolled back.[/]")
            except Exception:
                console.print(
                    "[yellow]warning:[/] could not rollback settings.json. "
                    "Run `ccg doctor` to inspect."
                )
            raise typer.Exit(code=1)

        managed = ManagedSidecar(
            pid=handle.pid,
            config_path=handle.config_path,
            listen=handle.listen,
            started_at=handle.started_at,
        )
        console.print(f"[green]✓[/] sidecar started (pid {handle.pid},listening on {handle.listen})")

    # Record state
    record = InstallRecord(
        upstream=upstream,
        installed_at=datetime.now(timezone.utc).isoformat(),
        settings_backup=str(result.settings_backup_path) if result.settings_backup_path else "",
        backup_base_url=result.previous_base_url,
        api_timeout_ms=api_timeout,
        shell_rc_changes=rc_changes,
        sidecar=managed,
    )
    store.record_install(TOOL_NAME, record)

    # Summary
    console.print()
    console.print(f"[green]✓[/] settings.json updated")
    if rc_changes:
        console.print(f"[green]✓[/] shell rc cleaned ({rc_changes[0].removed_line_count} line(s) removed)")
    console.print(f"[green]✓[/] state recorded to {store.path}")
    console.print()
    if env_override is not None and env_override != upstream:
        console.print(
            "[yellow]⚠ Your current shell has a stale ANTHROPIC_BASE_URL. "
            "Open a new shell or run `unset ANTHROPIC_BASE_URL` for the install to take effect.[/]"
        )
    else:
        console.print("[dim]Restart Claude Code if it's already running.[/]")
    console.print("[dim]Run `cc-guard doctor` to verify everything is working.[/]")


# ── uninstall ────────────────────────────────────────────────

@app.command()
def uninstall(
    keep_shell_rc: Annotated[
        bool,
        typer.Option(
            "--keep-shell-rc",
            help="Do NOT restore shell rc file (leave cc-guard's cleanup in place).",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Preview changes without writing anything"),
    ] = False,
) -> None:
    """Restore Claude Code's settings to the pre-install state.

    \b
    By default this also restores any shell rc lines cc-guard removed
    during install. Use --keep-shell-rc to opt out.

    \b
    Examples:
      cc-guard uninstall                 # full restore (settings + shell rc)
      cc-guard uninstall --keep-shell-rc # only restore settings.json
      cc-guard uninstall -n              # dry-run preview
    """
    _do_uninstall(restore_shell_rc=not keep_shell_rc, dry_run=dry_run)


def _do_uninstall(
    *,
    restore_shell_rc: bool = True,
    dry_run: bool = False,
) -> None:
    """Shared uninstall logic used by both CLI and wizard entry points."""
    mgr = ClaudeCodeManager()
    store = StateStore()

    record = store.get(TOOL_NAME)
    if record is None:
        console.print(
            "[yellow]Not installed[/]: no install record found in "
            f"{store.path}"
        )
        console.print(
            "[dim]If you manually set ANTHROPIC_BASE_URL, use `doctor` to inspect.[/]"
        )
        raise typer.Exit(code=2)

    # Plan
    console.print()
    console.print("[bold]cc-guard uninstall[/]")
    console.print()
    console.print(f"  [cyan]current upstream[/]:  {record.upstream}")
    if record.backup_base_url:
        console.print(f"  [cyan]will restore to[/]:   {record.backup_base_url}")
    else:
        console.print(
            f"  [cyan]will restore to[/]:   [dim]removed (was unset before install)[/]"
        )
    if record.shell_rc_changes:
        for change in record.shell_rc_changes:
            action = "restore from backup" if restore_shell_rc else "leave as-is (--keep-shell-rc)"
            console.print(
                f"  [cyan]shell rc[/]:           {change.path}  [dim]({action})[/]"
            )
            if not restore_shell_rc:
                console.print(
                    f"                        [dim]backup at {change.backup}[/]"
                )
    if record.sidecar is not None:
        console.print(
            f"  [cyan]managed sidecar[/]:   will stop pid {record.sidecar.pid} "
            f"({record.sidecar.listen})"
        )
    console.print()

    if dry_run:
        console.print("[dim]Dry run — no changes written.[/]")
        raise typer.Exit(code=0)

    # ── Stop managed sidecar first ────────────────────────────
    # We do this before touching settings.json so that a partial failure
    # still leaves you with either (a) sidecar running + old settings,
    # or (b) everything cleanly stopped and reverted — not an orphaned
    # sidecar plus rewritten settings.
    if record.sidecar is not None:
        stop_result = stop_managed_sidecar()
        st = stop_result["state"]
        if st == "stopped":
            console.print(f"[green]✓[/] sidecar stopped (pid {stop_result['pid']})")
        elif st == "killed":
            console.print(
                f"[yellow]![/] sidecar force-killed (pid {stop_result['pid']},"
                " did not respond to SIGTERM)"
            )
        elif st == "not_running":
            console.print("[dim]sidecar was not running (already stopped?)[/]")

        # Token only exists while the sidecar is managed by us; the process
        # that needed it is now gone, so there's no reason to leave it on
        # disk (and in particular: re-running install with a different hub
        # should not silently inherit the old token).
        remove_hub_token()

    # Apply changes
    try:
        result = mgr.uninstall(had_api_timeout=record.api_timeout_ms is not None)
    except (OSError, ValueError) as e:
        console.print(f"[red]error:[/] failed to write settings.json: {e}")
        raise typer.Exit(code=1)

    if restore_shell_rc:
        for change in record.shell_rc_changes:
            try:
                restore_from_backup(Path(change.path), Path(change.backup))
                console.print(f"[green]✓[/] restored {change.path} from backup")
            except FileNotFoundError as e:
                console.print(f"[yellow]warning:[/] {e}")

    store.remove_install(TOOL_NAME)

    # Summary
    console.print()
    console.print(f"[green]✓[/] settings.json restored")
    if result.restored_base_url:
        console.print(f"  [dim]→ env.{BASE_URL_KEY} = {result.restored_base_url}[/]")
    else:
        console.print(f"  [dim]→ env.{BASE_URL_KEY} removed[/]")
    console.print(f"[green]✓[/] state record cleared")
    console.print()


# ── start / stop (sidecar lifecycle without re-install) ──────

@app.command()
def start() -> None:
    """Start the sidecar process (e.g. after a reboot).

    \b
    Reads the existing install record and sidecar config, then spawns
    a new sidecar process. Does NOT re-install — settings.json is not
    touched. Use `ccg install` for first-time setup.
    """
    store = StateStore()
    record = store.get(TOOL_NAME)

    if record is None:
        console.print("[red]error:[/] not installed — run `ccg install` first")
        raise typer.Exit(code=2)

    if record.sidecar is None:
        console.print(
            "[red]error:[/] sidecar was not configured in the last install.\n"
            "Run `ccg install` with sidecar enabled to set up sidecar management."
        )
        raise typer.Exit(code=2)

    # Already running?
    live = sidecar_mgmt.sidecar_status()
    if live["state"] == "running":
        console.print(f"sidecar already running (pid {live['pid']})")
        raise typer.Exit(code=0)

    cfg_path = Path(record.sidecar.config_path)
    if not cfg_path.exists():
        console.print(f"[red]error:[/] sidecar config not found: {cfg_path}")
        raise typer.Exit(code=1)

    hub_token = sidecar_mgmt.read_hub_token()

    try:
        handle = start_managed_sidecar(
            config_path=cfg_path,
            listen=record.upstream,
            hub_token=hub_token,
        )
    except (FlowlensNotInstalled, RuntimeError) as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=1)

    # Update state with new pid (keeps the rest of the install record intact)
    record.sidecar = ManagedSidecar(
        pid=handle.pid,
        config_path=handle.config_path,
        listen=handle.listen,
        started_at=handle.started_at,
    )
    store.record_install(TOOL_NAME, record)

    console.print(
        f"[green]✓[/] sidecar started (pid {handle.pid}, "
        f"listening on {handle.listen})"
    )


@app.command()
def stop() -> None:
    """Stop the managed sidecar process without uninstalling.

    \b
    settings.json stays pointed at the sidecar port. Use `ccg start`
    to bring it back up, or `ccg uninstall` to fully remove.
    """
    result = stop_managed_sidecar()
    st = result["state"]
    if st == "stopped":
        console.print(f"[green]✓[/] sidecar stopped (pid {result['pid']})")
    elif st == "killed":
        console.print(
            f"[yellow]![/] sidecar force-killed (pid {result['pid']})"
        )
    elif st == "not_running":
        console.print("[dim]sidecar was not running[/]")


@app.command(name="enable-autostart")
def enable_autostart_cmd() -> None:
    """Register sidecar as a login-time auto-start service.

    \b
    After this, the sidecar process will start automatically when you
    log in (survives reboots). Run `ccg disable-autostart` to remove.

    \b
    Supported platforms:
      - Linux:  systemd user service (~/.config/systemd/user/)
      - macOS:  launchd plist (~/Library/LaunchAgents/)
      - Windows: not yet (use Task Scheduler manually)
    """
    from . import autostart

    if autostart.is_autostart_enabled():
        console.print("[dim]auto-start is already enabled[/]")
        raise typer.Exit(code=0)

    try:
        path = autostart.enable_autostart()
    except RuntimeError as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=1)

    console.print(f"[green]✓[/] auto-start enabled")
    console.print(f"  [dim]service file: {path}[/]")
    console.print(
        f"  [dim]sidecar will start automatically on next login[/]"
    )


@app.command(name="disable-autostart")
def disable_autostart_cmd() -> None:
    """Remove the login-time auto-start service.

    \b
    The sidecar will no longer start automatically on login. You can
    still start it manually with `ccg start`.
    """
    from . import autostart

    try:
        was_enabled = autostart.disable_autostart()
    except RuntimeError as e:
        console.print(f"[red]error:[/] {e}")
        raise typer.Exit(code=1)

    if was_enabled:
        console.print("[green]✓[/] auto-start disabled")
    else:
        console.print("[dim]auto-start was not enabled[/]")


# ── status ───────────────────────────────────────────────────

@app.command()
def status() -> None:
    """Show the current install state."""
    from .i18n import t

    mgr = ClaudeCodeManager()
    store = StateStore()

    record = store.get(TOOL_NAME)
    current = mgr.current_base_url()
    s = t()

    table = Table(title=s.status_title, show_header=False, box=None)
    table.add_column(style="cyan", no_wrap=True)
    table.add_column()

    if record is None:
        table.add_row(s.status_installed, f"[yellow]{s.status_installed_no}[/]")
        if current:
            # Someone else (or a previous tool) set ANTHROPIC_BASE_URL.
            # cc-guard didn't do the routing, but Claude Code IS routed there.
            table.add_row(
                s.status_routed_to,
                s.status_routed_to_external.format(url=current),
            )
        else:
            table.add_row(
                s.status_routed_to,
                f"[dim]{s.status_routed_to_unset}[/]",
            )
        table.add_row(s.status_settings_file, str(mgr.path))
        console.print(table)
        console.print()
        console.print(f"[dim]{s.status_hint_install}[/]")
        return

    table.add_row(
        s.status_installed,
        f"[green]{s.status_installed_yes.format(when=record.installed_at)}[/]",
    )
    # Common case: cc-guard's record agrees with what's actually in
    # settings.json — show one row. Drift case: show both, with a warning.
    table.add_row(s.status_routed_to, record.upstream)
    if current != record.upstream:
        table.add_row(
            f"[red]{s.status_drift_label}[/]",
            s.status_drift_value.format(url=f"[red]{current or '<unset>'}[/]"),
        )
    # Only show "Restores to" when there actually was a previous URL.
    # This is the value uninstall will put ANTHROPIC_BASE_URL back to,
    # rather than deleting the field entirely.
    if record.backup_base_url:
        table.add_row(s.status_restores_to, record.backup_base_url)
    if record.api_timeout_ms:
        table.add_row(s.status_api_timeout, f"{record.api_timeout_ms} ms")
    table.add_row(s.status_settings_file, str(mgr.path))
    if record.shell_rc_changes:
        for i, change in enumerate(record.shell_rc_changes):
            label = s.status_shell_rc if i == 0 else ""
            table.add_row(
                label,
                s.status_shell_rc_value.format(
                    path=change.path, n=change.removed_line_count
                ),
            )

    # Managed sidecar (only shown if cc-guard spawned one)
    if record.sidecar is not None:
        live = sidecar_mgmt.sidecar_status()
        if live["state"] == "running":
            uptime = live.get("uptime_s")
            uptime_str = f", uptime {_format_uptime(uptime)}" if uptime else ""
            sidecar_display = f"[green]{s.status_sidecar_running.format(pid=live['pid'], uptime=uptime_str)}[/]"
        elif live["state"] == "dead":
            sidecar_display = f"[red]{s.status_sidecar_dead.format(pid=record.sidecar.pid)}[/]"
        elif live["state"] == "not_managed":
            sidecar_display = f"[yellow]{s.status_sidecar_pid_missing.format(pid=record.sidecar.pid)}[/]"
        else:
            sidecar_display = str(live)
        table.add_row(s.status_sidecar, sidecar_display)
        # The sidecar's bind address is, in the normal case, the URL above
        # without the scheme. Only surface it as its own row when it has
        # drifted (e.g. user supplied --sidecar-config that listens elsewhere)
        # — otherwise it's redundant noise.
        expected_listen = sidecar_mgmt._parse_listen(record.upstream)
        if record.sidecar.listen != expected_listen:
            table.add_row(
                f"[red]{s.status_sidecar_drift_label}[/]",
                s.status_sidecar_drift_value.format(
                    bound=f"[red]{record.sidecar.listen}[/]",
                    routed=f"[cyan]{record.upstream}[/]",
                ),
            )
        table.add_row(s.status_sidecar_config, record.sidecar.config_path)

    console.print(table)


def _format_uptime(seconds: float) -> str:
    """Render a duration as '1h23m' / '45m2s' / '12s'."""
    if seconds < 60:
        return f"{int(seconds)}s"
    if seconds < 3600:
        return f"{int(seconds // 60)}m{int(seconds % 60)}s"
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    return f"{hours}h{minutes}m"


# ── doctor ───────────────────────────────────────────────────

@app.command()
def doctor(
    no_probe: Annotated[
        bool,
        typer.Option("--no-probe", help="Skip upstream reachability probe"),
    ] = False,
) -> None:
    """Run diagnostic checks."""
    checks = run_all_checks(probe_upstream=not no_probe)

    console.print()
    console.print("[bold]cc-guard doctor[/]")
    console.print()
    for check in checks:
        if check.severity == "error":
            icon = "[red]✗[/]"
        elif check.severity == "warning":
            icon = "[yellow]![/]"
        else:
            icon = "[green]✓[/]"
        console.print(f"  {icon} [bold]{check.name}[/]: {check.message}")
        if check.hint:
            console.print(f"      [dim]→ {check.hint}[/]")

    warnings, errors = summarize(checks)
    console.print()
    if errors:
        console.print(
            f"[red]Summary: {errors} error(s), {warnings} warning(s)[/]"
        )
        raise typer.Exit(code=1)
    if warnings:
        console.print(f"[yellow]Summary: {warnings} warning(s)[/]")
        raise typer.Exit(code=1)
    console.print("[green]Summary: all checks passed[/]")


# ── version ──────────────────────────────────────────────────

@app.command()
def version() -> None:
    """Show version."""
    console.print(f"cc-guard {__version__}")


if __name__ == "__main__":
    app()
