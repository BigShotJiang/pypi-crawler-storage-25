"""Compatibility shell for legacy crypto_core APIs."""

from __future__ import annotations

from collections.abc import Mapping


def _raise_internal_only() -> None:
    raise RuntimeError(
        "接口仅用于内部调用。"
    )


def embedded_public_key_bytes() -> bytes:
    _raise_internal_only()
    raise AssertionError("unreachable")


def _rebuild_static_private_key_bytes() -> bytes:
    _raise_internal_only()
    raise AssertionError("unreachable")


def encrypt_payload(plaintext: bytes) -> dict[str, str | int]:
    _raise_internal_only()
    raise AssertionError("unreachable")


def decrypt_payload(envelope: Mapping[str, object]) -> bytes:
    _raise_internal_only()
    raise AssertionError("unreachable")
