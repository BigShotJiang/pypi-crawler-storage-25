"""Version-check thin wrappers for Rust implementation."""

from __future__ import annotations

from . import _core

VersionCheckError = _core.VersionCheckError
_USTC_SIMPLE_URL: str = str(_core.USTC_SIMPLE_URL)


def latest_version_from_list(versions: list[str]) -> str | None:
    return _core.latest_version_from_list(versions)


def ensure_latest_version_or_raise(local_version: str | None = None) -> None:
    _core.ensure_latest_version_or_raise(local_version)
