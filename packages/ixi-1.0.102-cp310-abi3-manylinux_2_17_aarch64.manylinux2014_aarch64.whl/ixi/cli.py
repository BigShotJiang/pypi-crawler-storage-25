"""CLI for ixi."""

from __future__ import annotations

import argparse
import sys

from . import __version__
from .encryptor import encrypt_script


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ixi", description="Encrypt and run protected Python scripts.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-v", "--version", action="store_true", help="Print ixi version.")
    group.add_argument("-e", "--encrypt", metavar="SCRIPT", help="Encrypt target Python script.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(__version__)
        return 0

    try:
        output_path = encrypt_script(args.encrypt)
    except Exception as exc:
        print(f"[ixi] Encryption failed: {exc}", file=sys.stderr)
        return 1

    print(str(output_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
