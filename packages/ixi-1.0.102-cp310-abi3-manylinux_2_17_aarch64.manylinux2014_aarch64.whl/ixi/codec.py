"""Compatibility shell for legacy codec APIs."""

from __future__ import annotations


def _raise_internal_only() -> None:
    raise RuntimeError(
        "接口仅用于内部调用。"
    )


def generate_xor_key(length: int = 42) -> str:
    _raise_internal_only()
    raise AssertionError("unreachable")


def xor_bytes(data: bytes, key: str) -> bytes:
    _raise_internal_only()
    raise AssertionError("unreachable")


def encode_private_base64(data: bytes) -> str:
    _raise_internal_only()
    raise AssertionError("unreachable")


def decode_private_base64(text: str) -> bytes:
    _raise_internal_only()
    raise AssertionError("unreachable")
