"""Script encryption wrapper around Rust core."""

from __future__ import annotations

from pathlib import Path

from . import _core


def encrypt_script(input_script: str | Path) -> Path:
    """Encrypt a Python script and emit a runnable launcher file."""
    source_path = Path(input_script)
    if source_path.suffix.lower() != ".py":
        raise ValueError("必须是 .py 格式的脚本文件。")
    if not source_path.exists():
        raise FileNotFoundError(source_path)

    output_path = str(_core.encrypt_script_file(str(source_path)))
    return Path(output_path)
