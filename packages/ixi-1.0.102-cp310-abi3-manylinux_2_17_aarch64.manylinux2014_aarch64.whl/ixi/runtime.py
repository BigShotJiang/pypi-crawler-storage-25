"""Runtime launcher thin wrapper around Rust core."""

from __future__ import annotations

from . import _core
from .versioning import VersionCheckError


def _bootstrap_and_run(
    payload: str,
    source_name: str = "https://github.com/3ixi",
) -> None:
    """Internal entry point invoked by generated encrypted scripts."""
    try:
        _core.bootstrap_and_run(payload, source_name)
    except VersionCheckError as exc:
        raise SystemExit(1) from exc
    except Exception as exc:
        raise SystemExit(1) from exc
