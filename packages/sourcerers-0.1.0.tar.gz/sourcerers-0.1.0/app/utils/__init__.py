"""Common utilities."""
