from __future__ import annotations
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from mosesaic.llm.providers.groq import GroqProvider
from mosesaic.llm.provider import LLMMessage


def _make_response(content: str, input_tokens: int = 10, output_tokens: int = 20):
    resp = MagicMock()
    resp.choices = [MagicMock()]
    resp.choices[0].message.content = content
    resp.usage.prompt_tokens = input_tokens
    resp.usage.completion_tokens = output_tokens
    resp.model = "llama-3.3-70b-versatile"
    return resp


@pytest.fixture
def provider():
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        yield GroqProvider(api_key="test-key")


def test_provider_name(provider):
    assert provider.name == "groq"


def test_models_include_llama(provider):
    assert "llama-3.3-70b-versatile" in provider.models
    assert "llama-3.1-8b-instant" in provider.models


def test_llama_8b_is_free_tier(provider):
    caps = provider.models["llama-3.1-8b-instant"]
    assert caps.cost_per_1m_input == 0.0
    assert caps.cost_per_1m_output == 0.0


@pytest.mark.anyio
async def test_chat_returns_content(provider):
    provider._client.chat.completions.create = AsyncMock(
        return_value=_make_response("Groq reply")
    )
    result = await provider.chat(
        model="llama-3.3-70b-versatile",
        messages=[LLMMessage(role="user", content="hello")],
    )
    assert result.content == "Groq reply"
    assert result.model == "llama-3.3-70b-versatile"


def test_chat_uses_groq_base_url():
    """Groq client must be initialised with api.groq.com base URL."""
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        GroqProvider(api_key="gk-test")
        call_kwargs = mock_cls.call_args.kwargs
        assert "groq.com" in call_kwargs.get("base_url", "")
