import pytest

from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry


def make_registry() -> ProviderRegistry:
    registry = ProviderRegistry()
    registry.register(MockProvider(
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "mock-smart": Capabilities(
                vision=True, tools=True, thinking=True,
                context_k=200, cost_per_1m_input=5.00, cost_per_1m_output=15.00,
            ),
        }
    ))
    return registry


def test_find_cheapest_by_default():
    registry = make_registry()
    model_id, _ = registry.find(task_hint="general")
    assert model_id == "mock-cheap"


def test_find_prefers_thinking_for_reasoning():
    registry = make_registry()
    model_id, _ = registry.find(task_hint="reasoning")
    assert model_id == "mock-smart"


def test_find_filters_by_capability():
    registry = make_registry()
    model_id, _ = registry.find(require=["thinking"])
    assert model_id == "mock-smart"


def test_find_raises_when_no_model_meets_requirements():
    registry = make_registry()
    with pytest.raises(ValueError, match="No model satisfies"):
        registry.find(require=["thinking", "vision"], budget_usd=0.000001)


def test_find_filters_by_budget():
    registry = make_registry()
    # mock-smart estimated cost > 0.001 → filtered out
    model_id, _ = registry.find(budget_usd=0.01)
    assert model_id == "mock-cheap"


def test_all_models_returns_both():
    registry = make_registry()
    models = registry.all_models()
    assert "mock-cheap" in models
    assert "mock-smart" in models
