from __future__ import annotations
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from mosesaic.llm.providers.openai import OpenAIProvider
from mosesaic.llm.provider import LLMMessage


def _make_response(content: str, input_tokens: int, output_tokens: int):
    resp = MagicMock()
    resp.choices = [MagicMock()]
    resp.choices[0].message.content = content
    resp.usage.prompt_tokens = input_tokens
    resp.usage.completion_tokens = output_tokens
    resp.model = "gpt-4o-mini"
    return resp


@pytest.fixture
def provider():
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        yield OpenAIProvider(api_key="test-key")


def test_provider_name(provider):
    assert provider.name == "openai"


def test_models_include_gpt4o(provider):
    assert "gpt-4o" in provider.models
    assert "gpt-4o-mini" in provider.models


def test_model_capabilities(provider):
    caps = provider.models["gpt-4o"]
    assert caps.tools is True
    assert caps.vision is True
    assert caps.cost_per_1m_input > 0


@pytest.mark.anyio
async def test_chat_returns_response(provider):
    mock_resp = _make_response("Hello!", 50, 10)
    provider._client.chat.completions.create = AsyncMock(return_value=mock_resp)

    result = await provider.chat(
        model="gpt-4o-mini",
        messages=[LLMMessage(role="user", content="Hi")],
    )

    assert result.content == "Hello!"
    assert result.model == "gpt-4o-mini"
    assert result.input_tokens == 50
    assert result.output_tokens == 10
    assert result.cost_usd > 0


@pytest.mark.anyio
async def test_chat_passes_system_message(provider):
    mock_resp = _make_response("ok", 10, 5)
    provider._client.chat.completions.create = AsyncMock(return_value=mock_resp)

    await provider.chat(
        model="gpt-4o-mini",
        messages=[
            LLMMessage(role="system", content="You are a helper."),
            LLMMessage(role="user", content="Hi"),
        ],
    )

    call_kwargs = provider._client.chat.completions.create.call_args.kwargs
    msgs = call_kwargs["messages"]
    assert msgs[0]["role"] == "system"
    assert msgs[0]["content"] == "You are a helper."


@pytest.mark.anyio
async def test_chat_cost_calculated(provider):
    mock_resp = _make_response("x", 1_000_000, 1_000_000)
    provider._client.chat.completions.create = AsyncMock(return_value=mock_resp)

    result = await provider.chat(model="gpt-4o-mini", messages=[LLMMessage(role="user", content="x")])
    caps = provider.models["gpt-4o-mini"]
    expected = caps.estimate_cost(1_000_000, 1_000_000)
    assert abs(result.cost_usd - expected) < 0.0001


def test_provider_name_override():
    with patch("openai.AsyncOpenAI"):
        p = OpenAIProvider(api_key="key", provider_name="groq")
    assert p.name == "groq"


def test_empty_provider_name_raises():
    with pytest.raises(ValueError, match="provider_name"):
        with patch("openai.AsyncOpenAI"):
            OpenAIProvider(api_key="key", provider_name="")
