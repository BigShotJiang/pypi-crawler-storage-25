from __future__ import annotations
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from mosesaic.llm.providers.cerebras import CerebrasProvider
from mosesaic.llm.provider import LLMMessage


def _make_response(content: str, input_tokens: int = 10, output_tokens: int = 20):
    resp = MagicMock()
    resp.choices = [MagicMock()]
    resp.choices[0].message.content = content
    resp.usage.prompt_tokens = input_tokens
    resp.usage.completion_tokens = output_tokens
    return resp


@pytest.fixture
def provider():
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        yield CerebrasProvider(api_key="test-key")


def test_provider_name(provider):
    assert provider.name == "cerebras"


def test_models_list(provider):
    assert "llama3.1-8b" in provider.models
    assert "llama3.1-70b" in provider.models


def test_all_models_are_free(provider):
    for model_id, caps in provider.models.items():
        assert caps.cost_per_1m_input == 0.0, f"{model_id} should be free"
        assert caps.cost_per_1m_output == 0.0, f"{model_id} should be free"


def test_raises_without_api_key(monkeypatch):
    monkeypatch.delenv("CEREBRAS_API_KEY", raising=False)
    with pytest.raises(ValueError, match="CEREBRAS_API_KEY"):
        CerebrasProvider()


def test_reads_key_from_env(monkeypatch):
    monkeypatch.setenv("CEREBRAS_API_KEY", "env-key")
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        p = CerebrasProvider()
    assert p.name == "cerebras"


def test_uses_cerebras_base_url():
    with patch("openai.AsyncOpenAI") as mock_cls:
        mock_cls.return_value = MagicMock()
        CerebrasProvider(api_key="test-key")
        call_kwargs = mock_cls.call_args.kwargs
        assert "cerebras.ai" in call_kwargs.get("base_url", "")


@pytest.mark.anyio
async def test_chat_returns_content(provider):
    provider._client.chat.completions.create = AsyncMock(
        return_value=_make_response("Cerebras reply")
    )
    result = await provider.chat(
        model="llama3.1-8b",
        messages=[LLMMessage(role="user", content="hello")],
    )
    assert result.content == "Cerebras reply"
    assert result.cost_usd == 0.0
