"""Tests for LLMContext — ctx.llm.chat() with routing, budget enforcement, cost recording."""
import pytest

from mosesaic.core.cost import CostTracker
from mosesaic.exceptions import MosesaicBudgetExceeded
from mosesaic.llm.context import LLMContext
from mosesaic.llm.provider import Capabilities, LLMMessage
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry


def make_context(budget_usd=None) -> tuple[LLMContext, MockProvider]:
    provider = MockProvider(
        responses={"mock-cheap": "summary done", "mock-smart": "deep analysis"},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "mock-smart": Capabilities(
                vision=True, tools=True, thinking=True,
                context_k=200, cost_per_1m_input=5.00, cost_per_1m_output=15.00,
            ),
        },
        input_tokens=100,
        output_tokens=50,
    )
    registry = ProviderRegistry()
    registry.register(provider)
    cost_tracker = CostTracker(budget_usd=budget_usd, agent_name="test-agent")
    ctx = LLMContext(registry=registry, cost_tracker=cost_tracker, agent_name="test-agent")
    return ctx, provider


@pytest.mark.anyio
async def test_chat_returns_response():
    ctx, _ = make_context()
    response = await ctx.chat(
        messages=[{"role": "user", "content": "Summarise this"}],
        task_hint="extraction",
    )
    assert response.content == "summary done"
    assert response.model == "mock-cheap"
    assert response.input_tokens == 100
    assert response.output_tokens == 50


@pytest.mark.anyio
async def test_chat_accepts_llmmessage_objects():
    ctx, _ = make_context()
    response = await ctx.chat(
        messages=[LLMMessage(role="user", content="hello")],
    )
    assert response.content is not None


@pytest.mark.anyio
async def test_chat_records_cost_in_tracker():
    ctx, _ = make_context()
    await ctx.chat(messages=[{"role": "user", "content": "go"}])
    assert ctx._cost_tracker.spent_usd > 0


@pytest.mark.anyio
async def test_chat_routes_to_smart_for_reasoning():
    ctx, provider = make_context()
    response = await ctx.chat(
        messages=[{"role": "user", "content": "explain"}],
        task_hint="reasoning",
    )
    assert response.model == "mock-smart"
    assert provider.calls[-1]["model"] == "mock-smart"


@pytest.mark.anyio
async def test_chat_enforces_budget_before_call():
    ctx, _ = make_context(budget_usd=0.000001)
    with pytest.raises(MosesaicBudgetExceeded):
        await ctx.chat(messages=[{"role": "user", "content": "go"}])


@pytest.mark.anyio
async def test_chat_filters_by_require():
    ctx, _ = make_context()
    response = await ctx.chat(
        messages=[{"role": "user", "content": "analyse image"}],
        require=["vision"],
    )
    assert response.model == "mock-smart"


@pytest.mark.anyio
async def test_chat_prepends_system_prompt():
    from mosesaic.core.cost import CostTracker
    provider = MockProvider(
        responses={"mock-cheap": "ok"},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
        },
        input_tokens=10,
        output_tokens=10,
    )
    registry = ProviderRegistry()
    registry.register(provider)
    cost_tracker = CostTracker(agent_name="test")
    ctx = LLMContext(
        registry=registry,
        cost_tracker=cost_tracker,
        agent_name="test",
        system_prompt="You are a robot.",
    )
    await ctx.chat(messages=[{"role": "user", "content": "hello"}])
    sent = provider.calls[0]["messages"]
    assert sent[0].role == "system"
    assert sent[0].content == "You are a robot."
    assert sent[1].role == "user"


@pytest.mark.anyio
async def test_chat_without_system_prompt_no_extra_message():
    from mosesaic.core.cost import CostTracker
    provider = MockProvider(
        responses={"mock-cheap": "ok"},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
        },
        input_tokens=10,
        output_tokens=10,
    )
    registry = ProviderRegistry()
    registry.register(provider)
    cost_tracker = CostTracker(agent_name="test")
    ctx = LLMContext(registry=registry, cost_tracker=cost_tracker, agent_name="test")
    await ctx.chat(messages=[{"role": "user", "content": "hello"}])
    sent = provider.calls[0]["messages"]
    assert sent[0].role == "user"
    assert len(sent) == 1


@pytest.mark.anyio
async def test_preferred_model_bypasses_routing():
    """When preferred_model is set, chat() uses that model directly, ignoring task_hint."""
    from mosesaic.core.cost import CostTracker
    provider = MockProvider(
        responses={"mock-cheap": "cheap answer", "mock-smart": "smart answer"},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "mock-smart": Capabilities(
                vision=True, tools=True, thinking=True,
                context_k=200, cost_per_1m_input=5.00, cost_per_1m_output=15.00,
            ),
        },
        input_tokens=10,
        output_tokens=10,
    )
    registry = ProviderRegistry()
    registry.register(provider)
    cost_tracker = CostTracker(agent_name="test")
    # Prefer mock-smart even though task_hint="extraction" would pick mock-cheap
    ctx = LLMContext(
        registry=registry,
        cost_tracker=cost_tracker,
        agent_name="test",
        preferred_model="mock-smart",
    )
    response = await ctx.chat(
        messages=[{"role": "user", "content": "hello"}],
        task_hint="extraction",
    )
    assert response.model == "mock-smart"
    assert response.content == "smart answer"
