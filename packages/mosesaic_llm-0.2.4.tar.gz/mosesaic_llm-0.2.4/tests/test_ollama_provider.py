from __future__ import annotations
import pytest
import respx
import httpx
from mosesaic.llm.providers.ollama import OllamaProvider
from mosesaic.llm.provider import LLMMessage

_BASE = "http://localhost:11434"


@pytest.fixture
def provider():
    return OllamaProvider(base_url=_BASE)


def test_provider_name(provider):
    assert provider.name == "ollama"


def test_default_models_present(provider):
    assert "llama3.2" in provider.models
    assert "mistral" in provider.models


def test_models_are_free(provider):
    for caps in provider.models.values():
        assert caps.cost_per_1m_input == 0.0
        assert caps.cost_per_1m_output == 0.0


@pytest.mark.anyio
async def test_chat_returns_content(provider):
    payload = {
        "message": {"role": "assistant", "content": "Hello from Ollama!"},
        "prompt_eval_count": 15,
        "eval_count": 8,
        "done": True,
    }
    with respx.mock:
        respx.post(f"{_BASE}/api/chat").mock(
            return_value=httpx.Response(200, json=payload)
        )
        result = await provider.chat(
            model="llama3.2",
            messages=[LLMMessage(role="user", content="Hi")],
        )
    assert result.content == "Hello from Ollama!"
    assert result.model == "llama3.2"
    assert result.input_tokens == 15
    assert result.output_tokens == 8
    assert result.cost_usd == 0.0


@pytest.mark.anyio
async def test_chat_sends_correct_payload(provider):
    payload = {
        "message": {"role": "assistant", "content": "ok"},
        "prompt_eval_count": 5,
        "eval_count": 3,
        "done": True,
    }
    with respx.mock:
        route = respx.post(f"{_BASE}/api/chat").mock(
            return_value=httpx.Response(200, json=payload)
        )
        await provider.chat(
            model="mistral",
            messages=[
                LLMMessage(role="system", content="Be helpful."),
                LLMMessage(role="user", content="hello"),
            ],
        )
    sent = route.calls[0].request
    import json
    body = json.loads(sent.content)
    assert body["model"] == "mistral"
    assert body["stream"] is False
    assert body["messages"][0]["role"] == "system"


@pytest.mark.anyio
async def test_chat_connection_error_raises(provider):
    with respx.mock:
        respx.post(f"{_BASE}/api/chat").mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(RuntimeError, match="Ollama not reachable"):
            await provider.chat(
                model="llama3.2",
                messages=[LLMMessage(role="user", content="hi")],
            )
