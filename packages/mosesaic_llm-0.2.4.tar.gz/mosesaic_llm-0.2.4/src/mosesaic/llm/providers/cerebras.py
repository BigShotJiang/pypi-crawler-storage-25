from __future__ import annotations
import os
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.openai import OpenAIProvider

_CEREBRAS_MODELS: dict[str, Capabilities] = {
    "llama3.1-8b": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "llama3.1-70b": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
}

_CEREBRAS_BASE_URL = "https://api.cerebras.ai/v1"


class CerebrasProvider(OpenAIProvider):
    """Cerebras provider — ultra-fast inference, free tier for llama3.1 models.

    The api_key defaults to the CEREBRAS_API_KEY environment variable.
    """

    def __init__(
        self,
        api_key: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("CEREBRAS_API_KEY")
        if resolved_key is None:
            raise ValueError(
                "No API key provided for 'cerebras'. "
                "Set api_key or the CEREBRAS_API_KEY environment variable."
            )
        super().__init__(
            api_key=resolved_key,
            base_url=_CEREBRAS_BASE_URL,
            provider_name="cerebras",
        )
        self._models = {**_CEREBRAS_MODELS, **(extra_models or {})}
