from __future__ import annotations
import os
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.openai import OpenAIProvider

_GEMINI_MODELS: dict[str, Capabilities] = {
    "gemini-2.0-flash": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=1000, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "gemini-1.5-flash": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=1000, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "gemini-1.5-flash-8b": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=1000, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
}

_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"


class GeminiProvider(OpenAIProvider):
    """Google Gemini provider via the OpenAI-compatible REST endpoint.

    Free models: gemini-2.0-flash, gemini-1.5-flash, gemini-1.5-flash-8b.
    The api_key defaults to the GEMINI_API_KEY environment variable.
    """

    def __init__(
        self,
        api_key: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("GEMINI_API_KEY")
        if resolved_key is None:
            raise ValueError(
                "No API key provided for 'gemini'. "
                "Set api_key or the GEMINI_API_KEY environment variable."
            )
        super().__init__(
            api_key=resolved_key,
            base_url=_GEMINI_BASE_URL,
            provider_name="gemini",
        )
        self._models = {**_GEMINI_MODELS, **(extra_models or {})}
