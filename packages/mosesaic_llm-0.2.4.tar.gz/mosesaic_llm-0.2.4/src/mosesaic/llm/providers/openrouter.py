from __future__ import annotations
import os
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.openai import OpenAIProvider

_OPENROUTER_MODELS: dict[str, Capabilities] = {
    "meta-llama/llama-3.2-3b-instruct:free": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "google/gemini-2.0-flash-exp:free": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=1000, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "qwen/qwen2.5-72b-instruct:free": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "mistralai/mistral-7b-instruct:free": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
}

_OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


class OpenRouterProvider(OpenAIProvider):
    """OpenRouter provider — aggregates 50+ models, 4 free-tier models included.

    Free models: llama-3.2-3b, gemini-2.0-flash-exp, qwen2.5-72b, mistral-7b.
    The api_key defaults to the OPENROUTER_API_KEY environment variable.
    """

    def __init__(
        self,
        api_key: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("OPENROUTER_API_KEY")
        if resolved_key is None:
            raise ValueError(
                "No API key provided for 'openrouter'. "
                "Set api_key or the OPENROUTER_API_KEY environment variable."
            )
        super().__init__(
            api_key=resolved_key,
            base_url=_OPENROUTER_BASE_URL,
            provider_name="openrouter",
        )
        self._models = {**_OPENROUTER_MODELS, **(extra_models or {})}
