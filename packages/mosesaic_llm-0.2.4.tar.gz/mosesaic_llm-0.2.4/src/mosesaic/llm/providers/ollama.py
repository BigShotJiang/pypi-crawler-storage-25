from __future__ import annotations
from typing import Any
import httpx
from mosesaic.llm.provider import Capabilities, LLMMessage, LLMProvider, LLMResponse

# Pricing per 1M tokens (2026) — all free (local compute)
_OLLAMA_MODELS: dict[str, Capabilities] = {
    "llama3.2": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "llama3.2:1b": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "mistral": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "codellama": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=16, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "qwen2.5-coder": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
}


class OllamaProvider(LLMProvider):
    """LLM provider for locally-running Ollama models (free, no API key).

    Requires Ollama to be installed and running: https://ollama.com
    Pull models first: `ollama pull llama3.2`

    Note: stream=True is not supported — pass stream=False (default).
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._models = {**_OLLAMA_MODELS, **(extra_models or {})}

    @property
    def name(self) -> str:
        return "ollama"

    @property
    def models(self) -> dict[str, Capabilities]:
        return self._models

    async def chat(
        self,
        model: str,
        messages: list[LLMMessage],
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call Ollama REST API and return a structured response.

        Raises RuntimeError if Ollama is not running at base_url.
        """
        payload = {
            "model": model,
            "stream": False,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "options": {"num_predict": max_tokens},
        }
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    f"{self._base_url}/api/chat", json=payload
                )
                response.raise_for_status()
        except httpx.ConnectError as exc:
            raise RuntimeError(
                f"Ollama not reachable at {self._base_url}. "
                "Is Ollama running? Start it with: ollama serve"
            ) from exc

        data = response.json()
        content = data["message"]["content"]
        input_tokens = data.get("prompt_eval_count", 0)
        output_tokens = data.get("eval_count", 0)

        return LLMResponse(
            content=content,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=0.0,
            raw=data,
        )
