from __future__ import annotations
import os
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.openai import OpenAIProvider

# Pricing per 1M tokens (2026) — Groq free tier within rate limits
_GROQ_MODELS: dict[str, Capabilities] = {
    "llama-3.3-70b-versatile": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "llama-3.1-8b-instant": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
    "mixtral-8x7b-32768": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    ),
}

_GROQ_BASE_URL = "https://api.groq.com/openai/v1"


class GroqProvider(OpenAIProvider):
    """Groq LLM provider — OpenAI-compatible API, free tier within rate limits.

    The api_key defaults to the GROQ_API_KEY environment variable if not passed.
    Inherits OpenAIProvider.chat() — only models and base_url differ.
    """

    def __init__(
        self,
        api_key: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("GROQ_API_KEY")
        if resolved_key is None:
            raise ValueError(
                "No API key provided for 'groq'. "
                "Set api_key or the GROQ_API_KEY environment variable."
            )
        super().__init__(
            api_key=resolved_key,
            base_url=_GROQ_BASE_URL,
            provider_name="groq",
        )
        # Override parent's OpenAI models with Groq-only models
        self._models = {**_GROQ_MODELS, **(extra_models or {})}
