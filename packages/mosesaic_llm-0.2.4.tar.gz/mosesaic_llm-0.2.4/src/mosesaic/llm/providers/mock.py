from __future__ import annotations

from typing import Any

from mosesaic.llm.provider import Capabilities, LLMMessage, LLMProvider, LLMResponse


class MockProvider(LLMProvider):
    """Deterministic provider for tests — no API calls, no network.

    Usage:
        provider = MockProvider(responses={"my-model": "Fixed reply"})
        registry = ProviderRegistry()
        registry.register(provider)
    """

    def __init__(
        self,
        responses: dict[str, str] | None = None,
        capabilities: dict[str, Capabilities] | None = None,
        input_tokens: int = 10,
        output_tokens: int = 20,
    ) -> None:
        self._responses = responses or {}
        self._capabilities = capabilities or {
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "mock-smart": Capabilities(
                vision=True, tools=True, thinking=True,
                context_k=200, cost_per_1m_input=5.00, cost_per_1m_output=15.00,
            ),
        }
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens
        self.calls: list[dict] = []  # recorded for assertions

    @property
    def name(self) -> str:
        return "mock"

    @property
    def models(self) -> dict[str, Capabilities]:
        return self._capabilities

    async def chat(
        self,
        model: str,
        messages: list[LLMMessage],
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        self.calls.append({"model": model, "messages": messages, **kwargs})
        caps = self._capabilities.get(model, Capabilities())
        # _next_response allows tests to inject a one-shot fixed reply
        if hasattr(self, "_next_response"):
            content = self._next_response
        else:
            content = self._responses.get(model, f"[mock:{model}] {messages[-1].content}")
        cost = caps.estimate_cost(self._input_tokens, self._output_tokens)
        return LLMResponse(
            content=content,
            model=model,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            cost_usd=cost,
        )
