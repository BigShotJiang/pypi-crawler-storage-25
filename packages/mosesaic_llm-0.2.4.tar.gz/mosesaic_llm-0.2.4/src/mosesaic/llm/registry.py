from __future__ import annotations

from mosesaic.llm.provider import Capabilities, LLMProvider


class ProviderRegistry:
    """Holds all registered LLM providers and their model capabilities.

    Usage:
        registry = ProviderRegistry()
        registry.register(AnthropicProvider(...))
        registry.register(OllamaProvider(...))

        model_id, provider = registry.find(
            task_hint="reasoning",
            budget_usd=0.10,
            require=["tools"],
        )
    """

    def __init__(self) -> None:
        self._providers: dict[str, LLMProvider] = {}
        # Flat map: model_id → (provider, capabilities)
        self._models: dict[str, tuple[LLMProvider, Capabilities]] = {}

    def register(self, provider: LLMProvider) -> None:
        """Register a provider and index all its models."""
        self._providers[provider.name] = provider
        for model_id, caps in provider.models.items():
            self._models[model_id] = (provider, caps)

    def find(
        self,
        task_hint: str = "general",
        budget_usd: float | None = None,
        require: list[str] | None = None,
        max_output_tokens: int = 4096,
    ) -> tuple[str, LLMProvider]:
        """Select the best model given routing constraints.

        Strategy:
        1. Filter out models that don't meet capability requirements
        2. Filter out models whose estimated cost exceeds budget_usd
        3. Prefer models matching task_hint (reasoning → thinking, extraction → cheap)
        4. Among remaining, pick cheapest that meets all constraints

        Raises ValueError if no model satisfies constraints.
        """
        require = require or []
        candidates: list[tuple[str, LLMProvider, Capabilities]] = []

        for model_id, (provider, caps) in self._models.items():
            if not caps.supports(require):
                continue
            if budget_usd is not None:
                # Estimate worst-case cost: max_output_tokens output
                estimated = caps.estimate_cost(
                    input_tokens=4096, output_tokens=max_output_tokens
                )
                if estimated > budget_usd:
                    continue
            candidates.append((model_id, provider, caps))

        if not candidates:
            raise ValueError(
                f"No model satisfies constraints: task_hint={task_hint!r}, "
                f"budget_usd={budget_usd}, require={require}"
            )

        # Routing preference by task_hint
        def score(item: tuple[str, LLMProvider, Capabilities]) -> float:
            model_id, _, caps = item
            cost = caps.cost_per_1m_input + caps.cost_per_1m_output

            if task_hint == "reasoning" and caps.thinking:
                return -cost * 0.1   # strongly prefer thinking models
            if task_hint == "extraction" or task_hint == "cheap":
                return cost          # prefer cheapest (higher = worse, flip sign below)
            if task_hint == "vision" and caps.vision:
                return -cost * 0.1
            return cost              # default: cheapest wins

        # For "extraction"/"cheap", higher score = more expensive = worse
        # For others, lower score = better thinking model
        # Normalize: always sort ascending
        if task_hint in ("extraction", "cheap", "general"):
            candidates.sort(key=lambda x: x[2].cost_per_1m_input + x[2].cost_per_1m_output)
        else:
            candidates.sort(key=lambda x: score(x))

        model_id, provider, _ = candidates[0]
        return model_id, provider

    def all_models(self) -> dict[str, Capabilities]:
        return {mid: caps for mid, (_, caps) in self._models.items()}

    def iter_models(self):
        """Yield (model_id, provider, capabilities) for all registered models."""
        for model_id, (provider, caps) in self._models.items():
            yield model_id, provider, caps
