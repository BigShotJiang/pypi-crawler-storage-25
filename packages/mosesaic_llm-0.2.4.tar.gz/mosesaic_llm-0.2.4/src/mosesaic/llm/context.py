from __future__ import annotations

from typing import TYPE_CHECKING, Any

from mosesaic.llm.provider import LLMMessage, LLMResponse

if TYPE_CHECKING:
    from mosesaic.core.cost import AgentCostEvent, CostTracker
    from mosesaic.llm.registry import ProviderRegistry


class LLMContext:
    """The ``ctx.llm`` interface available to agents.

    Wraps the provider registry and cost tracker so agent code never imports
    provider SDKs or tracks costs manually.

    Usage (inside an agent):
        response = await ctx.llm.chat(
            messages=[{"role": "user", "content": "Summarise this..."}],
            task_hint="extraction",
            budget_usd=0.02,
        )
        print(response.content)
    """

    def __init__(
        self,
        registry: ProviderRegistry,
        cost_tracker: CostTracker,
        agent_name: str,
        system_prompt: str | None = None,
        preferred_model: str | None = None,
    ) -> None:
        self._registry = registry
        self._cost_tracker = cost_tracker
        self._agent_name = agent_name
        self._system_prompt = system_prompt
        self._preferred_model = preferred_model

    async def chat(
        self,
        messages: list[dict[str, str]] | list[LLMMessage],
        task_hint: str = "general",
        budget_usd: float | None = None,
        require: list[str] | None = None,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        """Send a chat request to the best available model.

        Args:
            messages: List of {"role": ..., "content": ...} dicts or LLMMessage objects.
            task_hint: Routing hint — "reasoning", "extraction", "vision", "cheap", "general".
            budget_usd: Hard cap for this single call. Raises if estimated cost exceeds it.
            require: List of required capabilities, e.g. ["vision"], ["tools", "thinking"].
            max_tokens: Maximum output tokens.

        Returns:
            LLMResponse with content, token counts, and actual cost_usd.

        Raises:
            MosesaicBudgetExceeded: If this call would exceed the agent's total budget.
            ValueError: If no model satisfies the routing constraints.
        """
        # Prepend system prompt if configured
        if self._system_prompt:
            messages = [{"role": "system", "content": self._system_prompt}, *messages]

        # Normalise messages to LLMMessage objects
        normalised: list[LLMMessage] = []
        for m in messages:
            if isinstance(m, dict):
                normalised.append(LLMMessage(role=m["role"], content=m["content"]))
            else:
                normalised.append(m)

        # Find the model: use pin if set, otherwise route via registry
        if self._preferred_model is not None:
            model_id = self._preferred_model
            # Look up provider for this model
            provider = None
            for mid, (p, _) in self._registry._models.items():
                if mid == model_id:
                    provider = p
                    break
            if provider is None:
                raise ValueError(
                    f"preferred_model={model_id!r} is not registered in the ProviderRegistry."
                )
        else:
            model_id, provider = self._registry.find(
                task_hint=task_hint,
                budget_usd=budget_usd,
                require=require or [],
                max_output_tokens=max_tokens,
            )

        # Budget circuit breaker — check BEFORE calling the API
        caps = self._registry.all_models().get(model_id)
        if caps is not None:
            estimated_cost = caps.estimate_cost(input_tokens=4096, output_tokens=max_tokens)
        else:
            estimated_cost = 0.0
        self._cost_tracker.check_before_call(
            estimated_cost_usd=estimated_cost,
            call_description=f"llm.chat({model_id})",
        )

        # Make the actual LLM call
        response = await provider.chat(
            model=model_id,
            messages=normalised,
            max_tokens=max_tokens,
            **kwargs,
        )

        # Record actual cost (not estimate) after the call
        from mosesaic.core.cost import AgentCostEvent
        self._cost_tracker.record(AgentCostEvent(
            agent_name=self._agent_name,
            model=model_id,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            cost_usd=response.cost_usd,
            trace_id=str(id(self)),  # placeholder until trace propagation is wired
        ))

        # Emit progress event so the SSE stream can show model/provider/cost
        from mosesaic.core.progress import emit_progress, ProgressEvent
        emit_progress(ProgressEvent(
            type="llm_call",
            agent=self._agent_name,
            model=model_id,
            provider=provider.name,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            cost_usd=response.cost_usd,
        ))

        return response
