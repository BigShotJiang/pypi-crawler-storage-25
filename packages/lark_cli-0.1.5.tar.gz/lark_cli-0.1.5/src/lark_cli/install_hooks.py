import os
from pathlib import Path

from .release import ensure_installed_binary, expected_binary_path


def download_release_during_install() -> None:
    force_download = os.environ.get("LARK_CLI_FORCE_DOWNLOAD") == "1"
    cached_binary = Path(expected_binary_path())
    if force_download:
        print("[lark-cli] force download is enabled (LARK_CLI_FORCE_DOWNLOAD=1)")
    elif cached_binary.exists():
        print(f"[lark-cli] using cached binary: {cached_binary}")
    else:
        print("[lark-cli] downloading latest release binary during install...")

    installed = ensure_installed_binary(force=force_download)
    print(f"[lark-cli] binary ready: {installed}")
