import json
import os
import shutil
import tarfile
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path
from platform import machine, system
from stat import S_IXGRP, S_IXOTH, S_IXUSR
from typing import Dict, Iterable, Tuple


LATEST_RELEASE_API = "https://api.github.com/repos/larksuite/cli/releases/latest"


def normalize_platform(raw_system: str, raw_machine: str) -> Tuple[str, str, str]:
    os_name = raw_system.lower()
    if os_name not in {"darwin", "linux", "windows"}:
        raise RuntimeError(f"Unsupported OS: {raw_system}")

    normalized_machine = raw_machine.lower()
    if normalized_machine in {"x86_64", "amd64"}:
        arch = "amd64"
    elif normalized_machine in {"arm64", "aarch64"}:
        arch = "arm64"
    else:
        raise RuntimeError(f"Unsupported architecture: {raw_machine}")

    extension = ".zip" if os_name == "windows" else ".tar.gz"
    return os_name, arch, extension


def choose_asset(assets: Iterable[Dict[str, str]], os_name: str, arch: str, extension: str) -> Dict[str, str]:
    target_suffix = f"-{os_name}-{arch}{extension}"
    for asset in assets:
        name = asset.get("name", "")
        if name.startswith("lark-cli-") and name.endswith(target_suffix):
            return asset
    raise RuntimeError(f"No matching release asset for {os_name}/{arch}{extension}")


def _fetch_latest_release() -> Dict[str, object]:
    request = urllib.request.Request(
        LATEST_RELEASE_API,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "lark-cli-python-wrapper",
        },
    )

    last_error = None
    for _ in range(3):
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                payload = json.loads(response.read().decode("utf-8"))
            return payload
        except Exception as error:  # noqa: BLE001
            last_error = error
            time.sleep(1)

    if last_error is not None:
        raise last_error

    raise RuntimeError("Failed to fetch latest release")


def _default_install_root() -> Path:
    custom_root = os.environ.get("LARK_CLI_WRAPPER_HOME")
    if custom_root:
        return Path(custom_root)

    home = Path.home()
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", home))
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache"))
    return base / "lark-cli-python-wrapper"


def _cached_binary_path(os_name: str) -> Path:
    binary_name = "lark-cli.exe" if os_name == "windows" else "lark-cli"
    return _default_install_root() / "current" / binary_name


def _find_binary(extracted_dir: Path, binary_name: str) -> Path:
    for root, _, files in os.walk(extracted_dir):
        if binary_name in files:
            return Path(root) / binary_name
    raise RuntimeError(f"Binary '{binary_name}' not found in extracted release archive")


def _extract_archive(archive_path: Path, destination: Path) -> None:
    if archive_path.name.endswith(".tar.gz"):
        with tarfile.open(archive_path, mode="r:gz") as tar:
            tar.extractall(destination)
        return

    if archive_path.name.endswith(".zip"):
        with zipfile.ZipFile(archive_path, mode="r") as archive:
            archive.extractall(destination)
        return

    raise RuntimeError(f"Unsupported archive format: {archive_path.name}")


def _download_file(url: str, destination: Path) -> None:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/octet-stream",
            "User-Agent": "lark-cli-python-wrapper",
        },
    )

    last_error = None
    for _ in range(3):
        try:
            with urllib.request.urlopen(request, timeout=60) as response, destination.open("wb") as file_obj:
                shutil.copyfileobj(response, file_obj)
            return
        except Exception as error:  # noqa: BLE001
            last_error = error
            time.sleep(1)

    if last_error is not None:
        raise last_error


def ensure_installed_binary(force: bool = False) -> str:
    os_name, arch, extension = normalize_platform(system(), machine())
    binary_name = "lark-cli.exe" if os_name == "windows" else "lark-cli"
    binary_path = _cached_binary_path(os_name)
    target_dir = binary_path.parent

    if binary_path.exists() and not force:
        return str(binary_path)

    release = _fetch_latest_release()
    assets = release.get("assets", [])
    if not isinstance(assets, list):
        raise RuntimeError("Release payload missing assets list")
    selected_asset = choose_asset(assets, os_name, arch, extension)

    target_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        archive_path = temp_path / selected_asset["name"]
        _download_file(selected_asset["browser_download_url"], archive_path)

        extract_dir = temp_path / "extract"
        extract_dir.mkdir(parents=True, exist_ok=True)
        _extract_archive(archive_path, extract_dir)
        extracted_binary = _find_binary(extract_dir, binary_name)

        shutil.copy2(extracted_binary, binary_path)

    if os_name != "windows":
        current_mode = binary_path.stat().st_mode
        binary_path.chmod(current_mode | S_IXUSR | S_IXGRP | S_IXOTH)

    return str(binary_path)


def get_installed_binary_path() -> str:
    os_name, _, _ = normalize_platform(system(), machine())
    binary_path = _cached_binary_path(os_name)

    if not binary_path.exists():
        raise RuntimeError(
            "lark-cli binary is not installed yet. Please reinstall package to trigger install-time download."
        )

    return str(binary_path)


def expected_binary_path() -> str:
    os_name, _, _ = normalize_platform(system(), machine())
    return str(_cached_binary_path(os_name))
