import subprocess
import sys

from .release import ensure_installed_binary, get_installed_binary_path


def main() -> None:
    try:
        binary_path = get_installed_binary_path()
    except RuntimeError:
        binary_path = ensure_installed_binary()

    result = subprocess.run([binary_path, *sys.argv[1:]])
    raise SystemExit(result.returncode)
