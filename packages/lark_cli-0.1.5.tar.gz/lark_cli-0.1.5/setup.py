from pathlib import Path
import sys

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop
from setuptools.command.install import install

try:
    from setuptools.command.editable_wheel import editable_wheel
except ImportError:  # pragma: no cover
    editable_wheel = None

try:
    from wheel.bdist_wheel import bdist_wheel
except ImportError:  # pragma: no cover
    bdist_wheel = None


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_DIR = PROJECT_ROOT / "src"
sys.path.insert(0, str(SRC_DIR))


class InstallWithBinary(install):
    def run(self):
        super().run()
        from lark_cli.install_hooks import download_release_during_install

        download_release_during_install()


class DevelopWithBinary(develop):
    def run(self):
        super().run()
        from lark_cli.install_hooks import download_release_during_install

        download_release_during_install()


class BuildPyWithBinary(build_py):
    def run(self):
        super().run()
        from lark_cli.install_hooks import download_release_during_install

        download_release_during_install()


if bdist_wheel is not None:
    class BdistWheelWithBinary(bdist_wheel):
        def run(self):
            super().run()
            from lark_cli.install_hooks import download_release_during_install

            download_release_during_install()
else:  # pragma: no cover
    BdistWheelWithBinary = None


if editable_wheel is not None:
    class EditableWheelWithBinary(editable_wheel):
        def run(self):
            super().run()
            from lark_cli.install_hooks import download_release_during_install

            download_release_during_install()
else:  # pragma: no cover
    EditableWheelWithBinary = None


cmdclass = {
    "install": InstallWithBinary,
    "develop": DevelopWithBinary,
    "build_py": BuildPyWithBinary,
}

if BdistWheelWithBinary is not None:
    cmdclass["bdist_wheel"] = BdistWheelWithBinary

if EditableWheelWithBinary is not None:
    cmdclass["editable_wheel"] = EditableWheelWithBinary


setup(
    cmdclass=cmdclass,
)
