from lark_cli import install_hooks


def test_install_hook_triggers_download(monkeypatch):
    called = {"value": False}

    def fake_download(force=False):
        called["value"] = force is False

    monkeypatch.setattr(install_hooks, "ensure_installed_binary", fake_download)
    install_hooks.download_release_during_install()

    assert called["value"] is True


def test_install_hook_supports_force_download(monkeypatch):
    called = {"force": None}

    def fake_download(force=False):
        called["force"] = force
        return "/tmp/lark-cli"

    monkeypatch.setenv("LARK_CLI_FORCE_DOWNLOAD", "1")
    monkeypatch.setattr(install_hooks, "ensure_installed_binary", fake_download)
    monkeypatch.setattr(install_hooks, "expected_binary_path", lambda: "/tmp/lark-cli")

    install_hooks.download_release_during_install()
    assert called["force"] is True
