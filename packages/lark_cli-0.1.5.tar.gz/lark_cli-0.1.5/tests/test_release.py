from lark_cli.release import choose_asset, normalize_platform
from lark_cli import release


def test_normalize_platform_for_macos_arm64():
    os_name, arch, ext = normalize_platform("Darwin", "arm64")
    assert os_name == "darwin"
    assert arch == "arm64"
    assert ext == ".tar.gz"


def test_choose_asset_for_linux_amd64():
    assets = [
        {"name": "lark-cli-1.0.0-darwin-arm64.tar.gz", "browser_download_url": "a"},
        {"name": "lark-cli-1.0.0-linux-amd64.tar.gz", "browser_download_url": "b"},
    ]

    selected = choose_asset(assets, "linux", "amd64", ".tar.gz")
    assert selected["browser_download_url"] == "b"


def test_ensure_binary_uses_cached_file_without_network(monkeypatch, tmpdir):
    root = tmpdir.mkdir("wrapper-home")
    current_dir = root.mkdir("current")
    binary_path = current_dir.join("lark-cli")
    binary_path.write("#!/bin/sh\n")

    monkeypatch.setenv("LARK_CLI_WRAPPER_HOME", str(root))
    monkeypatch.setattr(release, "system", lambda: "Darwin")
    monkeypatch.setattr(release, "machine", lambda: "arm64")

    def fail_fetch():
        raise AssertionError("network should not be called when cached binary exists")

    monkeypatch.setattr(release, "_fetch_latest_release", fail_fetch)

    resolved = release.ensure_installed_binary()
    assert resolved == str(binary_path)
