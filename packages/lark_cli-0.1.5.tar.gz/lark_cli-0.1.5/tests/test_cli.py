import pytest

from lark_cli import cli


def test_main_forwards_all_args_without_download_when_binary_exists(monkeypatch):
    captured = {}

    def fake_get_installed_binary_path():
        return "/tmp/lark-cli"

    class Result:
        returncode = 7

    def fake_run(cmd):
        captured["cmd"] = cmd
        return Result()

    def fail_download(*_args, **_kwargs):
        raise AssertionError("should not download when binary exists")

    monkeypatch.setattr(cli, "get_installed_binary_path", fake_get_installed_binary_path)
    monkeypatch.setattr(cli, "ensure_installed_binary", fail_download)
    monkeypatch.setattr(cli.subprocess, "run", fake_run)
    monkeypatch.setattr(cli.sys, "argv", ["lark-cli", "im", "send", "--text", "hello"])

    with pytest.raises(SystemExit) as raised:
        cli.main()

    assert raised.value.code == 7
    assert captured["cmd"] == ["/tmp/lark-cli", "im", "send", "--text", "hello"]


def test_main_downloads_when_binary_is_missing(monkeypatch):
    captured = {}

    def missing_installed_binary():
        raise RuntimeError("missing")

    def fake_download_binary():
        captured["downloaded"] = True
        return "/tmp/lark-cli"

    class Result:
        returncode = 0

    def fake_run(cmd):
        captured["cmd"] = cmd
        return Result()

    monkeypatch.setattr(cli, "get_installed_binary_path", missing_installed_binary)
    monkeypatch.setattr(cli, "ensure_installed_binary", fake_download_binary)
    monkeypatch.setattr(cli.subprocess, "run", fake_run)
    monkeypatch.setattr(cli.sys, "argv", ["lark-cli"])

    with pytest.raises(SystemExit) as raised:
        cli.main()

    assert raised.value.code == 0
    assert captured["downloaded"] is True
    assert captured["cmd"] == ["/tmp/lark-cli"]
