# lark-cli

Python wrapper for the official `larksuite/cli` release binary.

## What it does

- Resolves the latest GitHub release from `https://github.com/larksuite/cli`
- Chooses the current platform asset automatically
- Downloads and caches the binary during package installation
- Runs the extracted `lark-cli` binary
- Passes all CLI arguments through unchanged

## Usage

```bash
lark-cli <any-args>
```

Example:

```bash
lark-cli api list --page 1
```

## Local binary cache location

- macOS/Linux: `~/.cache/lark-cli-python-wrapper/current/lark-cli`
- Windows: `%LOCALAPPDATA%\lark-cli-python-wrapper\current\lark-cli.exe`

Set `LARK_CLI_WRAPPER_HOME` to override this location.

If the cached binary is missing at runtime, `lark-cli` will automatically download it before execution.

If you want to see install-time download logs, install with verbose mode:

```bash
python3 -m pip install -e . -v
```

By default, install reuses the cached binary if it already exists. To force re-download during install:

```bash
LARK_CLI_FORCE_DOWNLOAD=1 python3 -m pip install -e . -v
```

## Build & publish to PyPI

```bash
python3 -m pip install --upgrade build twine
python3 -m build
python3 -m twine check dist/*
```

Before upload, bump `version` in `pyproject.toml` (for example `0.1.4` -> `0.1.5`).

> Do not upload with `dist/*` if old files still exist in `dist/`, otherwise PyPI may reject duplicates.

Upload only the current version files explicitly (replace `<version>` with the exact value in `pyproject.toml`):

```bash
python3 -m twine upload \
  dist/lark_cli-<version>-py3-none-any.whl \
  dist/lark-cli-<version>.tar.gz \
  --verbose
```
