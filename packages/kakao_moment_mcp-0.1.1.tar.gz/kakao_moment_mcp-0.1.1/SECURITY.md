# Security Policy

## 토큰/시크릿 저장 위치

이 프로젝트는 카카오 OAuth 자격증명을 다룹니다. 모든 시크릿은 **사용자 홈 디렉토리**에 저장되며 레포 외부입니다.

| 파일 | 권한 | 내용 |
| --- | --- | --- |
| `~/.kakao-moment-mcp/.env` | 0600 | REST API Key, Client Secret, Ad Account ID |
| `~/.kakao-moment-mcp/tokens.json` | 0600 | OAuth access/refresh 토큰 |
| `~/.kakao-moment-mcp/logs/server.jsonl*` | 0600 (디렉토리 0700) | 호출 로그 (시크릿 미포함) |

- `.env` / `tokens.json` 은 절대 커밋되지 않도록 `.gitignore` 처리되어 있습니다.
- 로그에는 Authorization 헤더, Client Secret 등 시크릿이 **기록되지 않습니다**. (httpx event hook 이 method/path/status/duration만 남김)

## 시크릿 노출 의심 시 대응

1. **즉시** [카카오 디벨로퍼스 콘솔](https://developers.kakao.com/console/app) → Client Secret 재발급.
2. `rm ~/.kakao-moment-mcp/tokens.json` 으로 로컬 토큰 제거.
3. `kakao-moment-mcp-authorize` 재실행.
4. 이슈가 GitHub PR/이슈/스크린샷에서 발생했다면 해당 자료 삭제 + 히스토리(`git filter-repo`) 정리.

## 취약점 제보

공개 이슈로 등록하지 마시고 **GitHub Security Advisory** 로 비공개 제보해 주세요:

https://github.com/jun7680/kakao-moment-mcp/security/advisories/new

48시간 내 1차 회신을 목표로 합니다.

## 운영 권한 (Phase 2~) 안전장치

향후 추가될 Write 도구(ON/OFF, 예산 변경, 소재 생성)는 다음 안전장치를 **필수**로 갖춥니다:
- `dry_run=true` 기본 옵션
- 일예산/입찰가 변경은 기존 대비 ±50% 상한 (환경변수 조정 가능)
- 모든 Write 호출은 JSON 로그로 변경 전/후 값 기록
- 카카오 API 에러 시에도 로그 기록 (request_id 로 추적)

세부 사양은 Confluence 기술 스펙 §5 참고.
