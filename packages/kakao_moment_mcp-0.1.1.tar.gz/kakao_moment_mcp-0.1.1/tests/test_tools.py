"""도구 함수들의 응답 정규화 검증."""
from __future__ import annotations

import httpx
import pytest
import respx

from kakao_moment_mcp.kakao.client import KakaoMomentClient
from kakao_moment_mcp.tools.account import get_ad_account_info, get_bizmoney
from kakao_moment_mcp.tools.adgroups import list_adgroups
from kakao_moment_mcp.tools.campaigns import list_campaigns
from kakao_moment_mcp.tools.creatives import list_creatives
from kakao_moment_mcp.tools.reports import get_performance_report


@pytest.mark.asyncio
@respx.mock
async def test_get_ad_account_info_extracts_fields(settings, patch_token_store):
    respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/9999").mock(
        return_value=httpx.Response(
            200, json={"data": {"id": 1, "name": "메인", "config": "ON"}}
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await get_ad_account_info(client)
    finally:
        await client.aclose()
    assert res["id"] == 1
    assert res["name"] == "메인"
    assert res["status"] == "ON"


@pytest.mark.asyncio
@respx.mock
async def test_get_bizmoney_normalizes_balance(settings, patch_token_store):
    respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/balance").mock(
        return_value=httpx.Response(200, json={"data": {"cash": 123456}})
    )
    client = KakaoMomentClient(settings)
    try:
        res = await get_bizmoney(client)
    finally:
        await client.aclose()
    assert res["balance"] == 123456


@pytest.mark.asyncio
@respx.mock
async def test_list_campaigns_with_status_filter(settings, patch_token_store):
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/campaigns").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {"id": 1, "name": "A", "config": "ON", "dailyBudgetAmount": 50000},
                    {"id": 2, "name": "B", "config": "ON", "dailyBudgetAmount": 30000},
                ]
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await list_campaigns(client, status_filter="on")
    finally:
        await client.aclose()
    assert res["count"] == 2
    assert res["items"][0]["daily_budget"] == 50000
    assert route.calls.last.request.url.params["config"] == "ON"


@pytest.mark.asyncio
@respx.mock
async def test_list_adgroups_filters_by_campaign(settings, patch_token_store):
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/adGroups").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    client = KakaoMomentClient(settings)
    try:
        await list_adgroups(client, campaign_id="C1")
    finally:
        await client.aclose()
    assert route.calls.last.request.url.params["campaignId"] == "C1"


@pytest.mark.asyncio
@respx.mock
async def test_list_creatives_filters_by_adgroup(settings, patch_token_store):
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/creatives").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    client = KakaoMomentClient(settings)
    try:
        await list_creatives(client, adgroup_id="G1")
    finally:
        await client.aclose()
    assert route.calls.last.request.url.params["adGroupId"] == "G1"


@pytest.mark.asyncio
@respx.mock
async def test_performance_report_computes_derived_metrics(settings, patch_token_store):
    respx.get("https://apis.moment.kakao.com/openapi/v4/campaigns/report").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "id": "C1",
                        "name": "A",
                        "imp": 10000,
                        "click": 200,
                        "cost": 50000,
                        "conv": 10,
                        "conversionAmount": 100000,
                    }
                ]
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await get_performance_report(
            client,
            target="campaign",
            date_from="2026-05-10",
            date_to="2026-05-10",
        )
    finally:
        await client.aclose()
    assert res["totals"]["impressions"] == 10000
    assert res["totals"]["clicks"] == 200
    assert res["totals"]["ctr_pct"] == 2.0  # 200/10000
    assert res["totals"]["cpc"] == 250.0
    assert res["totals"]["roas_pct"] == 200.0


@pytest.mark.asyncio
async def test_performance_report_validates_dates(settings, patch_token_store):
    client = KakaoMomentClient(settings)
    try:
        with pytest.raises(ValueError, match="YYYY-MM-DD"):
            await get_performance_report(
                client, target="campaign", date_from="2026/05/01", date_to="2026-05-02"
            )
        with pytest.raises(ValueError, match="date_to 가 date_from"):
            await get_performance_report(
                client, target="campaign", date_from="2026-05-10", date_to="2026-05-01"
            )
        with pytest.raises(ValueError, match="target"):
            await get_performance_report(
                client, target="invalid", date_from="2026-05-01", date_to="2026-05-02"  # type: ignore[arg-type]
            )
    finally:
        await client.aclose()
