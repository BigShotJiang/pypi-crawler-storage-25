"""테스트 공통 fixtures."""
from __future__ import annotations

import time
from pathlib import Path

import pytest

from kakao_moment_mcp.auth.token_store import TokenSet
from kakao_moment_mcp.config import Settings


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        rest_api_key="test_key",
        client_secret="test_secret",
        redirect_uri="http://localhost:8765/callback",
        ad_account_id="9999",
        oauth_scopes=("moment_management",),
        log_level="INFO",
        log_dir=tmp_path / "logs",
    )


@pytest.fixture
def fresh_tokens() -> TokenSet:
    return TokenSet(
        access_token="atk_fresh",
        refresh_token="",
        expires_at=time.time() + 3600,
        scope="moment_management",
    )


@pytest.fixture
def patch_token_store(fresh_tokens, monkeypatch):
    """token_store 의 load/save 를 메모리로 대체."""
    state = {"tokens": fresh_tokens}

    def fake_load(*a, **kw):
        return state["tokens"]

    def fake_save(t, *a, **kw):
        state["tokens"] = t

    monkeypatch.setattr("kakao_moment_mcp.auth.token_store.load_tokens", fake_load)
    monkeypatch.setattr("kakao_moment_mcp.kakao.client.load_tokens", fake_load)
    # client.py no longer imports save_tokens (biz tokens don't refresh).
    monkeypatch.setattr("kakao_moment_mcp.auth.token_store.save_tokens", fake_save)
    return state
