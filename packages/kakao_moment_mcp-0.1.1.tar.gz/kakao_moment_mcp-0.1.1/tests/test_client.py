"""KakaoMomentClient 의 401 자동 refresh, 429 백오프, 헤더 주입 검증."""
from __future__ import annotations

import time

import httpx
import pytest
import respx

from kakao_moment_mcp.auth.token_store import TokenSet
from kakao_moment_mcp.kakao.client import KakaoApiError, KakaoMomentClient


@pytest.mark.asyncio
@respx.mock
async def test_get_success_with_headers(settings, patch_token_store):
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/9999").mock(
        return_value=httpx.Response(200, json={"data": {"id": 9999, "name": "테스트"}})
    )
    client = KakaoMomentClient(settings)
    try:
        data = await client.get("/openapi/v4/adAccounts/9999")
    finally:
        await client.aclose()
    assert data["data"]["id"] == 9999
    req = route.calls.last.request
    assert req.headers["Authorization"] == "Bearer atk_fresh"
    assert req.headers["adAccountId"] == "9999"


@pytest.mark.asyncio
@respx.mock
async def test_401_with_business_token_raises(settings, patch_token_store):
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/balance").mock(
        return_value=httpx.Response(
            401,
            json={
                "code": -401,
                "msg": "target biz token is not supplied.",
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        with pytest.raises(KakaoApiError) as exc:
            await client.get("/openapi/v4/adAccounts/balance")
    finally:
        await client.aclose()
    assert exc.value.status == 401
    assert route.call_count == 1


@pytest.mark.asyncio
@respx.mock
async def test_429_backoff_then_success(settings, patch_token_store, monkeypatch):
    sleeps: list[float] = []

    async def fake_sleep(d):
        sleeps.append(d)

    monkeypatch.setattr("asyncio.sleep", fake_sleep)

    route = respx.get("https://apis.moment.kakao.com/openapi/v4/campaigns").mock(
        side_effect=[
            httpx.Response(429),
            httpx.Response(429),
            httpx.Response(200, json={"data": []}),
        ]
    )
    client = KakaoMomentClient(settings)
    try:
        data = await client.get("/openapi/v4/campaigns")
    finally:
        await client.aclose()
    assert data == {"data": []}
    assert route.call_count == 3
    assert sleeps == [1.0, 2.0]


@pytest.mark.asyncio
@respx.mock
async def test_4xx_raises_friendly_error(settings, patch_token_store):
    respx.get("https://apis.moment.kakao.com/openapi/v4/campaigns").mock(
        return_value=httpx.Response(400, json={"code": -10, "msg": "잘못된 파라미터"})
    )
    client = KakaoMomentClient(settings)
    try:
        with pytest.raises(KakaoApiError) as exc:
            await client.get("/openapi/v4/campaigns")
    finally:
        await client.aclose()
    assert exc.value.status == 400
    assert exc.value.code == -10


@pytest.mark.asyncio
@respx.mock
async def test_expired_business_token_requires_reauth(settings, patch_token_store):
    # 만료된 토큰으로 시작
    patch_token_store["tokens"] = TokenSet(
        access_token="atk_old",
        refresh_token="",
        expires_at=time.time() - 10,
    )
    client = KakaoMomentClient(settings)
    try:
        with pytest.raises(RuntimeError, match="다시 인증"):
            await client.get("/openapi/v4/adAccounts/9999")
    finally:
        await client.aclose()
