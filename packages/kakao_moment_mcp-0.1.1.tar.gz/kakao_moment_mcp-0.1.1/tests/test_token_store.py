"""토큰 저장 파일 권한 0600 검증."""
from __future__ import annotations

import os
import stat
import sys
import time

import pytest

from kakao_moment_mcp.auth.token_store import TokenSet, load_tokens, save_tokens


@pytest.mark.skipif(sys.platform.startswith("win"), reason="POSIX file mode only")
def test_save_tokens_chmod_600(tmp_path):
    path = tmp_path / "tokens.json"
    tokens = TokenSet(
        access_token="a",
        refresh_token="r",
        expires_at=time.time() + 100,
    )
    save_tokens(tokens, path=path)
    mode = stat.S_IMODE(os.stat(path).st_mode)
    assert mode == 0o600, f"기대: 0o600, 실제: {oct(mode)}"


def test_load_tokens_roundtrip(tmp_path):
    path = tmp_path / "tokens.json"
    tokens = TokenSet(
        access_token="atk", refresh_token="rtk", expires_at=time.time() + 100
    )
    save_tokens(tokens, path=path)
    loaded = load_tokens(path=path)
    assert loaded is not None
    assert loaded.access_token == "atk"
    assert loaded.refresh_token == "rtk"


def test_load_tokens_missing_returns_none(tmp_path):
    assert load_tokens(path=tmp_path / "absent.json") is None


def test_load_tokens_corrupt_returns_none(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text("not json")
    assert load_tokens(path=path) is None
