"""_unwrap_metrics + metricsGroups 파라미터 회귀 방지."""
from __future__ import annotations

import httpx
import pytest
import respx

from kakao_moment_mcp.kakao.client import KakaoMomentClient
from kakao_moment_mcp.tools.reports import _unwrap_metrics, get_performance_report


def test_unwrap_metrics_handles_nested_shape():
    row = {
        "start": "2026-05-18",
        "end": "2026-05-18",
        "dimensions": {"campaignId": 1},
        "metrics": {"imp": 100, "click": 5, "cost": 1000},
    }
    flat = _unwrap_metrics(row)
    assert flat["imp"] == 100
    assert flat["click"] == 5
    assert flat["cost"] == 1000
    assert flat["campaignId"] == 1
    assert flat["start"] == "2026-05-18"


def test_unwrap_metrics_passes_through_flat_shape():
    row = {"start": "x", "imp": 1, "click": 1, "cost": 100}
    flat = _unwrap_metrics(row)
    assert flat == row


@pytest.mark.asyncio
@respx.mock
async def test_get_performance_report_sends_metricsGroups_plural(
    settings, patch_token_store
):
    """단수 metricsGroup 은 카카오가 400 으로 거부 → 복수 metricsGroups 만 사용."""
    route = respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/report").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": []})
    )
    client = KakaoMomentClient(settings)
    try:
        await get_performance_report(
            client,
            target="account",
            date_from="2026-05-12",
            date_to="2026-05-18",
            breakdown="day",
        )
    finally:
        await client.aclose()
    call = route.calls.last
    params = dict(call.request.url.params)
    assert params.get("metricsGroups") == "DAY"
    assert "metricsGroup" not in params  # 단수형은 절대 보내지 않음


@pytest.mark.asyncio
@respx.mock
async def test_get_performance_report_unwraps_metrics_in_rows(
    settings, patch_token_store
):
    respx.get("https://apis.moment.kakao.com/openapi/v4/adAccounts/report").mock(
        return_value=httpx.Response(
            200,
            json={
                "code": 200,
                "data": [
                    {
                        "start": "2026-05-18",
                        "end": "2026-05-18",
                        "dimensions": {},
                        "metrics": {"imp": 200, "click": 10, "cost": 2500},
                    }
                ],
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await get_performance_report(
            client, target="account", date_from="2026-05-18", date_to="2026-05-18"
        )
    finally:
        await client.aclose()
    assert res["totals"]["impressions"] == 200
    assert res["totals"]["clicks"] == 10
    assert res["totals"]["cost"] == 2500
