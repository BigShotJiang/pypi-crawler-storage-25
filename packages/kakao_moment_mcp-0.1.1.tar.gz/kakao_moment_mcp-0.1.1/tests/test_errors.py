"""kakao.errors 의 한글 가이드 매핑 검증."""
from __future__ import annotations

import httpx

from kakao_moment_mcp.kakao.errors import from_response


def _resp(status: int, body: dict) -> httpx.Response:
    return httpx.Response(status, json=body, request=httpx.Request("GET", "http://x"))


def test_friendly_for_known_kakao_code():
    err = from_response(_resp(401, {"code": -401, "msg": "Invalid"}))
    assert err.status == 401
    assert err.code == -401
    assert "재인증" in str(err)


def test_friendly_for_http_status_when_code_unknown():
    err = from_response(_resp(429, {"msg": "Too many"}))
    assert err.status == 429
    assert "잠시 후" in str(err)


def test_missing_required_param_813_message_mentions_campaign_id():
    err = from_response(_resp(400, {"code": -813, "msg": "KakaoMomentException"}))
    assert "campaign_id" in str(err) or "adgroup_id" in str(err)


def test_unknown_status_falls_back_to_raw():
    err = from_response(_resp(418, {"msg": "I am a teapot"}))
    assert "418" in str(err) or "teapot" in str(err)
