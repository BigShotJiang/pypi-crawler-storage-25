"""logging.setup_logging 의 파일/레벨/환경변수 동작 검증."""
from __future__ import annotations

import json
import logging

import structlog

from kakao_moment_mcp.logging import setup_logging


def test_setup_logging_creates_dir_and_writes_jsonl(tmp_path):
    log_dir = tmp_path / "logs"
    setup_logging(level="INFO", log_dir=log_dir)
    structlog.get_logger("test").info("hello", k="v")
    # 모든 핸들러 flush
    for h in logging.getLogger().handlers:
        h.flush()

    files = list(log_dir.glob("server.jsonl*"))
    assert files, "로그 파일이 생성되지 않았습니다"
    content = files[0].read_text()
    # logging_initialized + hello 두 줄 이상
    lines = [line for line in content.splitlines() if line.strip()]
    assert any('"event": "hello"' in line for line in lines)
    # JSONL 유효성
    for line in lines:
        json.loads(line)


def test_setup_logging_env_overrides(tmp_path, monkeypatch):
    log_dir = tmp_path / "env_logs"
    monkeypatch.setenv("KAKAO_MCP_LOG_LEVEL", "WARNING")
    monkeypatch.setenv("KAKAO_MCP_LOG_DIR", str(log_dir))
    setup_logging()  # 인자 미전달 — env 가 적용돼야 함
    assert log_dir.exists()
    assert logging.getLogger().level == logging.WARNING
