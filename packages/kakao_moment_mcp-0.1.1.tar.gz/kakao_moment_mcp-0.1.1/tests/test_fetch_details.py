"""list_* 도구의 detail 동시 fetch (with_details) 검증."""
from __future__ import annotations

import httpx
import pytest
import respx

from kakao_moment_mcp.kakao.client import KakaoMomentClient
from kakao_moment_mcp.tools.adgroups import list_adgroups
from kakao_moment_mcp.tools.campaigns import list_campaigns


@pytest.mark.asyncio
@respx.mock
async def test_list_campaigns_enriches_with_details(settings, patch_token_store):
    base = "https://apis.moment.kakao.com"
    respx.get(f"{base}/openapi/v4/campaigns").mock(
        return_value=httpx.Response(
            200,
            json={
                "content": [
                    {"id": 1, "name": "A", "config": "ON"},
                    {"id": 2, "name": "B", "config": "OFF"},
                ]
            },
        )
    )
    respx.get(f"{base}/openapi/v4/campaigns/1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 1,
                "name": "A",
                "config": "ON",
                "dailyBudgetAmount": 50000,
                "campaignTypeGoal": {"campaignType": "DISPLAY", "goal": "VISITING"},
            },
        )
    )
    respx.get(f"{base}/openapi/v4/campaigns/2").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 2,
                "name": "B",
                "config": "OFF",
                "dailyBudgetAmount": 100000,
                "campaignTypeGoal": {"campaignType": "DISPLAY", "goal": "VISITING"},
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await list_campaigns(client)
    finally:
        await client.aclose()

    assert res["count"] == 2
    assert res["items"][0]["daily_budget"] == 50000
    assert res["items"][0]["campaign_type"] == "DISPLAY"
    assert "일예산 합계 150,000원" in res["summary"]


@pytest.mark.asyncio
@respx.mock
async def test_list_campaigns_with_details_false_skips_detail_calls(
    settings, patch_token_store
):
    base = "https://apis.moment.kakao.com"
    list_route = respx.get(f"{base}/openapi/v4/campaigns").mock(
        return_value=httpx.Response(
            200, json={"content": [{"id": 1, "name": "A", "config": "ON"}]}
        )
    )
    detail_route = respx.get(f"{base}/openapi/v4/campaigns/1")
    client = KakaoMomentClient(settings)
    try:
        res = await list_campaigns(client, with_details=False)
    finally:
        await client.aclose()
    assert list_route.called
    assert not detail_route.called
    assert res["items"][0]["daily_budget"] is None


@pytest.mark.asyncio
@respx.mock
async def test_list_adgroups_pulls_bid_and_schedule(settings, patch_token_store):
    base = "https://apis.moment.kakao.com"
    respx.get(f"{base}/openapi/v4/adGroups").mock(
        return_value=httpx.Response(
            200, json={"content": [{"id": 11, "name": "G", "config": "ON"}]}
        )
    )
    respx.get(f"{base}/openapi/v4/adGroups/11").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 11,
                "name": "G",
                "config": "ON",
                "dailyBudgetAmount": 30000,
                "bidAmount": 500,
                "bidStrategy": "MANUAL",
                "pricingType": "CPC",
                "schedule": {"beginDate": "2026-01-01", "endDate": "2026-12-31"},
            },
        )
    )
    client = KakaoMomentClient(settings)
    try:
        res = await list_adgroups(client, campaign_id="999")
    finally:
        await client.aclose()
    item = res["items"][0]
    assert item["bid_amount"] == 500
    assert item["bid_strategy"] == "MANUAL"
    assert item["daily_budget"] == 30000
    assert item["begin_date"] == "2026-01-01"
    assert item["end_date"] == "2026-12-31"
