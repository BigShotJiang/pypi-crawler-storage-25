# Changelog

이 프로젝트의 모든 주목할만한 변경은 이 파일에 기록됩니다.
형식은 [Keep a Changelog](https://keepachangelog.com/ko/1.1.0/) 를 따르며,
버전은 [SemVer](https://semver.org/lang/ko/) 를 사용합니다.

## [0.1.1] - 2026-05-19

### Fixed
- 패키지 메타데이터 정정: author/Copyright/Homepage URL 을 개인 계정으로 교체. (0.1.0 은 yank 예정)
- README 의 머신별 절대경로 → 일반화된 placeholder.
- SECURITY.md 의 취약점 제보 채널을 GitHub Security Advisory 로 단일화.

## [Unreleased]

### Added
- **구조화 로깅**: `~/.kakao-moment-mcp/logs/server.jsonl` (자정 회전, 7일 보관). 도구별 `request_id` 응답에 자동 포함. 환경변수 `KAKAO_MCP_LOG_LEVEL`, `KAKAO_MCP_LOG_DIR`.
- **HTTP 호출 자동 로깅**: httpx event hook 으로 method/path/status/duration/call_id 기록. 429/5xx 재시도 시도 횟수도 로그.
- **사용자 친화 에러 메시지**: 카카오 코드 + HTTP status 별 한글 가이드 (`kakao/errors.py` 매핑 확장).
- **도구 응답 보강**:
  - 모든 도구에 한국어 `summary` 1줄.
  - `get_today_status`: 시간대별 페이스, 현재 페이스 기준 마감 예상 소진율.
  - `get_bizmoney`: 최근 7일 일별 소진 추이, 잔액 기준 잔여 일수 추정.
  - `list_*`: detail 엔드포인트 자동 동시 fetch 로 daily_budget/bid_amount/createdDate 등 보강 (`with_details=True` 기본).
- **자연어 트리거**: 7개 도구 docstring 에 "이런 질문에 사용하세요" 섹션. LLM 의 도구 선택 정확도 향상.
- **다중 MCP 클라이언트 자동 등록**: Cursor (`~/.cursor/mcp.json`), Cline (VSCode 확장) 자동 감지/등록. Claude Desktop/Code 와 동일 마법사로.
- **`kakao-moment-mcp-doctor`**: 진단 CLI. env/토큰/로그/클라이언트 등록 상태 한 줄로 점검. `--live` 로 실제 API 호출 검증.
- **OS 별 설치 가이드**: README 에 macOS/Windows/Linux 접이식 블록.

### Changed
- 리포트 응답 신형 포맷(`{dimensions, metrics}`) 자동 unwrap. 구형 flat 포맷도 계속 지원.
- 리포트 breakdown 파라미터를 `metricsGroup` (단수) → `metricsGroups` (복수) 로 수정. 카카오가 단수형을 거부하던 회귀 픽스.
- 재시도 대상 확장: 기존 429 + 5xx(500/502/503/504) 도 동일 backoff.

### Fixed
- `list_campaigns`/`list_adgroups`/`list_creatives` 의 `daily_budget`/`bid_amount` 가 항상 null 이던 문제. LIST 엔드포인트가 lightweight 라 detail 별도 호출 필요했음.

## [0.1.0] - 2026-05-18

### Added
- 초기 릴리즈. Phase 1 조회/리포트 도구 7개:
  - `get_ad_account_info`, `get_bizmoney`, `get_today_status`
  - `list_campaigns`, `list_adgroups`, `list_creatives`
  - `get_performance_report`
- CLI 마법사 `kakao-moment-mcp-setup` 으로 자격증명 입력 → OAuth → Claude Desktop/Code 자동 등록.
- 비즈니스 OAuth 토큰 저장 (`~/.kakao-moment-mcp/tokens.json`, 0600).
