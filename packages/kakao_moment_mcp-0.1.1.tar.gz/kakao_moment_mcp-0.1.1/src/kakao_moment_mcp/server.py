"""Kakao Moment MCP 서버 엔트리포인트.

FastMCP 기반. stdio 트랜스포트로 Claude Desktop 과 통신.
"""
from __future__ import annotations

import asyncio
import sys

import structlog
from mcp.server.fastmcp import FastMCP

from .config import ConfigError, load_settings
from .kakao.client import KakaoApiError, KakaoMomentClient
from .logging import setup_logging
from .tools.account import get_ad_account_info, get_bizmoney, get_today_status
from .tools.adgroups import list_adgroups
from .tools.campaigns import list_campaigns
from .tools.creatives import list_creatives
from .tools.reports import get_performance_report

_LOG = structlog.get_logger("kakao_moment_mcp")


def build_server() -> FastMCP:
    settings = load_settings()
    setup_logging(level=settings.log_level, log_dir=settings.log_dir)
    client = KakaoMomentClient(settings)
    mcp = FastMCP("kakao-moment")

    async def _safe(coro_factory, **ctx):
        import time
        import uuid

        request_id = uuid.uuid4().hex[:12]
        tool_name = ctx.get("tool", "unknown")
        token = structlog.contextvars.bind_contextvars(
            request_id=request_id, tool=tool_name
        )
        started = time.perf_counter()
        _LOG.info("tool_started", **ctx)
        try:
            result = await coro_factory()
            duration_ms = int((time.perf_counter() - started) * 1000)
            summary: dict = {"duration_ms": duration_ms}
            if isinstance(result, dict):
                if "count" in result:
                    summary["count"] = result["count"]
                if "totals" in result:
                    summary["has_totals"] = True
            _LOG.info("tool_completed", **summary, **ctx)
            if isinstance(result, dict):
                result.setdefault("_meta", {})["request_id"] = request_id
            return result
        except KakaoApiError as e:
            duration_ms = int((time.perf_counter() - started) * 1000)
            _LOG.warning(
                "kakao_api_error",
                status=e.status,
                code=e.code,
                duration_ms=duration_ms,
                **ctx,
            )
            return {
                "error": str(e),
                "status": e.status,
                "code": e.code,
                "_meta": {"request_id": request_id},
            }
        except Exception as e:  # noqa: BLE001
            duration_ms = int((time.perf_counter() - started) * 1000)
            _LOG.exception(
                "tool_error", error=str(e), duration_ms=duration_ms, **ctx
            )
            return {
                "error": str(e),
                "_meta": {"request_id": request_id},
            }
        finally:
            structlog.contextvars.reset_contextvars(**token)

    @mcp.tool(name="get_ad_account_info")
    async def tool_get_ad_account_info() -> dict:
        """카카오모먼트 광고계정 정보(이름, 상태, 사업자, 잔액부족 여부 등)를 조회합니다.

        이런 질문에 사용하세요:
          • "광고계정 상태 어때?" / "광고계정 정보 보여줘"
          • "지금 광고계정 잘 돌아가고 있어?"
          • "광고계정에 문제 있어?" / "잔액부족 상태야?"
          • "내 광고계정 ID/이름 뭐였지?"
        """
        return await _safe(
            lambda: get_ad_account_info(client), tool="get_ad_account_info"
        )

    @mcp.tool(name="get_bizmoney")
    async def tool_get_bizmoney() -> dict:
        """비즈머니 잔액 + 최근 7일 소진 추이 + 현재 페이스 기준 잔여 일수 예상.

        이런 질문에 사용하세요:
          • "비즈머니 얼마 남았어?" / "잔액 얼마야?" / "광고비 얼마 남았어?"
          • "이대로 가면 며칠 더 쓸 수 있어?" / "비즈머니 며칠치 남았어?"
          • "최근 일주일 광고비 얼마 썼어?"
          • "비즈머니 충전해야 해?" / "잔액 부족하지 않아?"
        """
        return await _safe(lambda: get_bizmoney(client), tool="get_bizmoney")

    @mcp.tool(name="list_campaigns")
    async def tool_list_campaigns(
        status_filter: str | None = None,
        with_details: bool = True,
    ) -> dict:
        """전체 캠페인 목록(이름·상태·일예산·캠페인 타입) 조회.

        이런 질문에 사용하세요:
          • "캠페인 목록 보여줘" / "어떤 캠페인 돌고 있어?"
          • "지금 켜져 있는 캠페인만 알려줘" → status_filter="ON"
          • "꺼져 있는 캠페인" / "OFF 상태 캠페인" → status_filter="OFF"
          • "캠페인 ID 뭐였지?" / "캠페인 일예산 얼마야?"

        Args:
            status_filter: ON / OFF / DELETED 등의 상태 필터 (선택)
            with_details: True(기본) 면 캠페인별 detail 을 함께 조회해 일예산/타입을 채움.
                          캠페인이 많아 느릴 때 False 로 끄세요.
        """
        return await _safe(
            lambda: list_campaigns(client, status_filter, with_details=with_details),
            tool="list_campaigns",
        )

    @mcp.tool(name="list_adgroups")
    async def tool_list_adgroups(
        campaign_id: str | None = None,
        with_details: bool = True,
    ) -> dict:
        """특정 캠페인 내 광고그룹 목록(입찰가·일예산·집행기간·디바이스) 조회.

        이런 질문에 사용하세요:
          • "캠페인 X 의 광고그룹 보여줘" / "X 안에 어떤 그룹 있어?"
          • "광고그룹 입찰가 얼마야?" / "그룹 일예산 얼마로 잡혀있어?"
          • "그룹 집행기간 언제까지야?"
          ⚠️ 광고그룹 ID 만 알고 캠페인 ID 모르면, 먼저 list_campaigns 로 캠페인을 찾으세요.

        Args:
            campaign_id: 특정 캠페인의 광고그룹만 조회 (필수에 가까움)
            with_details: True(기본) 면 광고그룹별 detail 로 입찰가/일예산/기간 보강.
        """
        return await _safe(
            lambda: list_adgroups(client, campaign_id, with_details=with_details),
            tool="list_adgroups",
        )

    @mcp.tool(name="list_creatives")
    async def tool_list_creatives(
        adgroup_id: str | None = None,
        with_details: bool = True,
    ) -> dict:
        """특정 광고그룹의 소재 목록(포맷·심사상태·미리보기·랜딩URL·제목/설명) 조회.

        이런 질문에 사용하세요:
          • "광고그룹 X 의 소재 보여줘" / "어떤 소재가 돌고 있어?"
          • "소재 심사상태 어떻게 돼?" / "반려된 소재 있어?"
          • "소재 미리보기 / 이미지 URL 줘"
          • "소재 랜딩 페이지 어디로 가?"
          ⚠️ 소재의 성과(클릭률/소진)는 get_performance_report(target="creative") 로 별도 조회.

        Args:
            adgroup_id: 특정 광고그룹의 소재만 조회 (필수에 가까움)
            with_details: True(기본) 면 소재별 detail 로 포맷/심사상태/이미지 보강.
        """
        return await _safe(
            lambda: list_creatives(client, adgroup_id, with_details=with_details),
            tool="list_creatives",
        )

    @mcp.tool(name="get_performance_report")
    async def tool_get_performance_report(
        target: str,
        date_from: str,
        date_to: str,
        target_id: str | None = None,
        breakdown: str | None = None,
    ) -> dict:
        """기간별 성과 리포트(노출·클릭·비용·전환·CTR·CPC·ROAS).

        이런 질문에 사용하세요 (예시 → 인자):
          • "어제 성과 요약해줘" → target="account", date_from/date_to=어제
          • "어제 캠페인별 성과" → target="campaign", date_from/date_to=어제
          • "지난주 광고그룹별 성과" → target="adgroup", date_from/date_to=지난주 월~일
          • "최근 7일 ROAS 좋은 광고그룹" → target="adgroup", 최근 7일
          • "캠페인 X 의 어제 성과" → target="campaign", target_id="X", 어제
          • "어제 클릭률 낮은 소재" → target="creative", date_from/date_to=어제
          • "지난주 대비 이번주 성과 변화" → 두 번 호출 후 비교
          • "오늘 시간대별 페이스" → 단발이면 get_today_status 가 더 적합.
          • "디바이스별 / 지면별 성과" → breakdown="device" / "placement"

        Args:
            target: account | campaign | adgroup | creative
            date_from: YYYY-MM-DD (오늘 = today.isoformat())
            date_to: YYYY-MM-DD
            target_id: campaign/adgroup/creative 일 때 특정 ID (선택). 전체 대상이면 비움.
            breakdown: day | hour | device | placement (선택)
        """
        return await _safe(
            lambda: get_performance_report(
                client,
                target=target,  # type: ignore[arg-type]
                date_from=date_from,
                date_to=date_to,
                target_id=target_id,
                breakdown=breakdown,  # type: ignore[arg-type]
            ),
            tool="get_performance_report",
            target=target,
        )

    @mcp.tool(name="get_today_status")
    async def tool_get_today_status() -> dict:
        """오늘 광고계정 상태: 누적 소진·시간당 페이스·마감 예상 소진율·노출/클릭·잔액.

        이런 질문에 사용하세요:
          • "오늘 일예산 얼마나 썼어?" / "오늘 소진액 얼마야?"
          • "지금 페이스 어때?" / "이대로 가면 오늘 얼마 쓸 것 같아?"
          • "오늘 광고 잘 돌고 있어?" / "오늘 노출/클릭 어때?"
          • "오늘 마감 예상 소진율" / "현재 시간당 평균 얼마야?"
          ⚠️ 어제/지난주 같은 과거 기간은 get_performance_report 로.
        """
        return await _safe(lambda: get_today_status(client), tool="get_today_status")

    return mcp


def main() -> int:
    try:
        mcp = build_server()
    except ConfigError as e:
        print(f"❌ 설정 오류: {e}", file=sys.stderr)
        return 2
    try:
        asyncio.run(mcp.run_stdio_async())
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
