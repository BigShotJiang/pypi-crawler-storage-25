"""도구 공통 유틸."""
from __future__ import annotations

import asyncio
from typing import Any

from ..kakao.client import KakaoMomentClient

_DETAIL_CONCURRENCY = 8


def extract_rows(payload: Any) -> list[dict[str, Any]]:
    """카카오모먼트 응답에서 row 리스트를 안전하게 추출.

    카카오는 엔드포인트별로 응답 형태가 달라서 여러 경우를 다 시도한다:
      - {"content": [...], ...}              (페이지네이션 응답)
      - {"data": [...]}                     (단순 리스트)
      - {"data": {...}}                      (단일 객체)
      - [...]                                (배열 직접)
      - {...}                                (객체 직접)
    """
    if isinstance(payload, list):
        return [r for r in payload if isinstance(r, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("content", "data"):
        v = payload.get(key)
        if isinstance(v, list):
            return [r for r in v if isinstance(r, dict)]
    # data 가 단일 객체이거나 keys 가 그대로 row 인 경우
    if "data" in payload and isinstance(payload["data"], dict):
        return [payload["data"]]
    return []


async def fetch_details(
    client: KakaoMomentClient,
    path_template: str,
    ids: list[Any],
) -> dict[Any, dict[str, Any]]:
    """ID 리스트를 받아 path_template.format(id=...) 로 detail 을 동시 조회한다.

    카카오모먼트의 list 엔드포인트는 daily_budget/bid_amount 등을 포함하지 않으므로
    list 한 뒤 각 항목의 detail 을 N+1 로 받아 보강한다. 동시 호출은 카카오 레이트리밋
    완화를 위해 _DETAIL_CONCURRENCY 로 제한.

    실패한 ID 는 dict 에서 누락된다(빈 dict). 호출 측은 .get(id, {}) 패턴으로 안전 접근.
    """
    sem = asyncio.Semaphore(_DETAIL_CONCURRENCY)

    async def one(item_id: Any) -> tuple[Any, dict[str, Any]]:
        async with sem:
            try:
                data = await client.get(path_template.format(id=item_id))
            except Exception:  # noqa: BLE001 — detail 실패는 silent (raw fallback)
                return item_id, {}
        body = data.get("data") if isinstance(data, dict) and "data" in data else data
        return item_id, body if isinstance(body, dict) else {}

    results = await asyncio.gather(*(one(i) for i in ids if i is not None))
    return {k: v for k, v in results}
