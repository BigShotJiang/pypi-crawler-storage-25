"""캠페인 목록 조회."""
from __future__ import annotations

from typing import Any

from ..kakao.client import KakaoMomentClient
from ._common import extract_rows, fetch_details


async def list_campaigns(
    client: KakaoMomentClient,
    status_filter: str | None = None,
    *,
    with_details: bool = True,
) -> dict[str, Any]:
    """캠페인 목록.

    Args:
        status_filter: ON / OFF / DELETED 등 카카오 상태 코드. None 이면 전체.
        with_details: True 면 캠페인별 detail 을 동시 호출해 일예산/타입/생성일 보강.
                      카카오 list 엔드포인트는 id/name/config 만 반환하므로 기본 ON.
                      대규모 계정(수백개)에서 부담되면 False 로 끌 수 있음.
    """
    params: dict[str, Any] = {}
    if status_filter:
        params["config"] = status_filter.upper()
    data = await client.get("/openapi/v4/campaigns", params=params or None)
    rows = extract_rows(data)

    details: dict[Any, dict[str, Any]] = {}
    if with_details and rows:
        details = await fetch_details(
            client,
            "/openapi/v4/campaigns/{id}",
            [r.get("id") for r in rows],
        )

    items: list[dict[str, Any]] = []
    for r in rows:
        merged = {**r, **details.get(r.get("id"), {})}
        type_goal = merged.get("campaignTypeGoal")
        items.append(
            {
                "id": merged.get("id"),
                "name": merged.get("name"),
                "campaign_type": (
                    type_goal.get("campaignType")
                    if isinstance(type_goal, dict)
                    else merged.get("campaignType")
                ),
                "goal": (
                    type_goal.get("goal") if isinstance(type_goal, dict) else None
                ),
                "status": merged.get("config") or merged.get("status"),
                "daily_budget": merged.get("dailyBudgetAmount")
                or merged.get("dailyBudget"),
                "is_over_budget": merged.get("isDailyBudgetAmountOver"),
                "status_description": merged.get("statusDescription"),
                "created_at": merged.get("createdDate"),
            }
        )

    on_count = sum(1 for it in items if str(it.get("status", "")).upper() == "ON")
    off_count = sum(
        1 for it in items if str(it.get("status", "")).upper() in ("OFF", "PAUSED")
    )
    total_budget = sum(
        float(it.get("daily_budget") or 0) for it in items if it.get("daily_budget")
    )
    summary = (
        f"캠페인 {len(items)}개 (진행 {on_count} · 일시정지 {off_count})"
        f" · 일예산 합계 {int(total_budget):,}원"
    )
    return {
        "count": len(items),
        "items": items,
        "summary": summary,
        "raw": data,
    }
