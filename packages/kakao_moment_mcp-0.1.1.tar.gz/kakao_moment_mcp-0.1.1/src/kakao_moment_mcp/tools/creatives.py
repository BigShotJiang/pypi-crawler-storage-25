"""소재 목록 조회."""
from __future__ import annotations

from typing import Any

from ..kakao.client import KakaoMomentClient
from ._common import extract_rows, fetch_details


def _preview_url(merged: dict[str, Any]) -> str | None:
    """detail 응답에서 표시 가능한 미리보기 URL 추출."""
    image = merged.get("image")
    if isinstance(image, dict) and image.get("url"):
        url = image["url"]
        if isinstance(url, str) and url.startswith("//"):
            return f"https:{url}"
        return url
    return merged.get("pcLandingUrl") or merged.get("previewUrl")


async def list_creatives(
    client: KakaoMomentClient,
    adgroup_id: str | None = None,
    *,
    with_details: bool = True,
) -> dict[str, Any]:
    """소재 목록.

    Args:
        adgroup_id: 특정 광고그룹의 소재만 필터. 카카오모먼트는 adgroup_id 가
                    없으면 KakaoMomentException(-813) 을 던지므로 필수에 가깝습니다.
        with_details: True 면 소재별 detail 을 동시 호출해 포맷/심사상태/이미지/생성일 보강.
    """
    if not adgroup_id:
        raise ValueError(
            "list_creatives 는 adgroup_id 가 필요합니다. "
            "list_adgroups 로 ID 를 먼저 얻어 전달하세요."
        )
    params: dict[str, Any] = {"adGroupId": adgroup_id}
    data = await client.get("/openapi/v4/creatives", params=params)
    rows = extract_rows(data)

    details: dict[Any, dict[str, Any]] = {}
    if with_details and rows:
        details = await fetch_details(
            client,
            "/openapi/v4/creatives/{id}",
            [r.get("id") for r in rows],
        )

    items: list[dict[str, Any]] = []
    for r in rows:
        merged = {**r, **details.get(r.get("id"), {})}
        items.append(
            {
                "id": merged.get("id"),
                "name": merged.get("name"),
                "adgroup_id": merged.get("adGroupId") or adgroup_id,
                "status": merged.get("config") or merged.get("status"),
                "creative_type": merged.get("format")
                or merged.get("creativeFormat")
                or merged.get("creativeType"),
                "preview_url": _preview_url(merged),
                "landing_url": merged.get("pcLandingUrl"),
                "review_status": merged.get("reviewStatus"),
                "creative_status": merged.get("creativeStatus"),
                "title": merged.get("title"),
                "description": merged.get("description"),
                "rejected_reason": merged.get("rejectedReason") or None,
                "status_description": merged.get("statusDescription"),
                "created_at": merged.get("createdDate"),
            }
        )

    on_count = sum(1 for it in items if str(it.get("status", "")).upper() == "ON")
    review_ok = sum(
        1
        for it in items
        if str(it.get("review_status", "")).upper() in ("APPROVED", "OK")
    )
    summary = f"소재 {len(items)}개 (진행 {on_count} · 심사완료 {review_ok})"
    return {
        "count": len(items),
        "items": items,
        "summary": summary,
        "raw": data,
    }
