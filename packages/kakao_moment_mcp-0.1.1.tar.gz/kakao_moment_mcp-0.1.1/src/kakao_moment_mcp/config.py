"""환경변수 로드 및 검증.

자격증명은 다음 순서로 탐색:
1. 프로세스 환경변수 (Claude Desktop config 의 env 키로 주입된 경우)
2. ~/.kakao-moment-mcp/.env
3. 현재 작업 디렉토리의 .env (개발용)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

HOME_CONFIG_DIR = Path.home() / ".kakao-moment-mcp"
HOME_ENV_PATH = HOME_CONFIG_DIR / ".env"
TOKEN_PATH = HOME_CONFIG_DIR / "tokens.json"


def _load_dotenv_files() -> None:
    # 홈 디렉토리 우선, 그 다음 cwd. 이미 로드된 환경변수는 덮어쓰지 않음.
    if HOME_ENV_PATH.exists():
        load_dotenv(HOME_ENV_PATH, override=False)
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        load_dotenv(cwd_env, override=False)


class ConfigError(RuntimeError):
    """필수 환경변수 누락 등 설정 오류."""


@dataclass(frozen=True)
class Settings:
    rest_api_key: str
    client_secret: str
    redirect_uri: str
    ad_account_id: str
    oauth_scopes: tuple[str, ...]
    log_level: str
    log_dir: Path

    @property
    def authorize_url(self) -> str:
        return "https://kauth.kakao.com/oauth/business/authorize"

    @property
    def token_url(self) -> str:
        return "https://kauth.kakao.com/oauth/business/token"

    @property
    def api_base_url(self) -> str:
        return "https://apis.moment.kakao.com"


def load_settings() -> Settings:
    _load_dotenv_files()

    def required(key: str) -> str:
        val = os.environ.get(key, "").strip()
        if not val:
            raise ConfigError(
                f"환경변수 {key} 가 설정되지 않았습니다. "
                f"{HOME_ENV_PATH} 또는 Claude Desktop config 의 env 항목을 확인하세요."
            )
        return val

    scopes_raw = os.environ.get("KAKAO_OAUTH_SCOPES", "moment_management")
    scopes = tuple(s.strip() for s in scopes_raw.split(",") if s.strip())

    log_dir_raw = os.environ.get("KAKAO_MCP_LOG_DIR")
    log_dir = (
        Path(log_dir_raw).expanduser()
        if log_dir_raw
        else HOME_CONFIG_DIR / "logs"
    )
    log_level = (
        os.environ.get("KAKAO_MCP_LOG_LEVEL")
        or os.environ.get("LOG_LEVEL")
        or "INFO"
    ).upper()

    return Settings(
        rest_api_key=required("KAKAO_REST_API_KEY"),
        client_secret=required("KAKAO_CLIENT_SECRET"),
        redirect_uri=os.environ.get(
            "KAKAO_REDIRECT_URI", "http://localhost:8765/callback"
        ),
        ad_account_id=required("KAKAO_AD_ACCOUNT_ID"),
        oauth_scopes=scopes,
        log_level=log_level,
        log_dir=log_dir,
    )
