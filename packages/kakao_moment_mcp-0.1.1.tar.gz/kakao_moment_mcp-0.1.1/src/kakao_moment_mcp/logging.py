"""구조화 로깅 설정.

- stderr: 사람이 읽기 좋은 한 줄 포맷 (Claude Desktop / Cursor 의 MCP 로그 패널에 노출)
- 파일:   ~/.kakao-moment-mcp/logs/server-YYYY-MM-DD.jsonl (JSONL, 자정 회전, 7일 보관)

stdout 은 MCP 프로토콜 전용이므로 절대 로그를 흘리지 않는다.
"""
from __future__ import annotations

import logging
import logging.handlers
import os
import sys
from pathlib import Path

import structlog

DEFAULT_LOG_DIR = Path.home() / ".kakao-moment-mcp" / "logs"
_BACKUP_DAYS = 7


def _resolve_log_dir(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit
    env_dir = os.environ.get("KAKAO_MCP_LOG_DIR")
    if env_dir:
        return Path(env_dir).expanduser()
    return DEFAULT_LOG_DIR


def _resolve_level(explicit: str | None) -> int:
    raw = (
        explicit
        or os.environ.get("KAKAO_MCP_LOG_LEVEL")
        or os.environ.get("LOG_LEVEL")
        or "INFO"
    )
    return getattr(logging, raw.upper(), logging.INFO)


def setup_logging(*, level: str | None = None, log_dir: Path | None = None) -> Path:
    """루트 logger 와 structlog 을 설정. 반환값은 실제 파일 로그 경로(디렉토리).

    여러 번 호출돼도 핸들러가 중복되지 않도록 기존 핸들러를 비운 뒤 재구성.
    """
    resolved_dir = _resolve_log_dir(log_dir)
    resolved_level = _resolve_level(level)

    try:
        resolved_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(resolved_dir, 0o700)
        except (PermissionError, OSError):
            pass
        file_path = resolved_dir / "server.jsonl"
        file_handler: logging.Handler = logging.handlers.TimedRotatingFileHandler(
            file_path,
            when="midnight",
            backupCount=_BACKUP_DAYS,
            encoding="utf-8",
            utc=False,
        )
        # 회전 파일은 server.jsonl.YYYY-MM-DD 로 남는다.
        file_handler.suffix = "%Y-%m-%d"
        file_handler.setFormatter(logging.Formatter("%(message)s"))
    except (PermissionError, OSError) as e:
        # 로그 디렉토리에 쓸 수 없어도 서버는 계속 돌아야 한다.
        file_handler = None  # type: ignore[assignment]
        print(
            f"⚠️  로그 디렉토리 사용 불가({resolved_dir}): {e}. stderr 로그만 사용합니다.",
            file=sys.stderr,
        )

    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setFormatter(logging.Formatter("%(message)s"))

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(stderr_handler)
    if file_handler is not None:
        root.addHandler(file_handler)
    root.setLevel(resolved_level)

    # httpx / urllib3 은 기본이 너무 시끄러워 INFO 이상에서만 노출.
    logging.getLogger("httpx").setLevel(max(resolved_level, logging.WARNING))
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    shared_processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=False),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.processors.JSONRenderer(ensure_ascii=False),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(resolved_level),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    structlog.get_logger("kakao_moment_mcp").info(
        "logging_initialized",
        log_dir=str(resolved_dir),
        level=logging.getLevelName(resolved_level),
    )
    return resolved_dir


__all__ = ["setup_logging", "DEFAULT_LOG_DIR"]
