"""날짜 검증 유틸 (YYYY-MM-DD)."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def validate_date(s: str, *, field: str = "date") -> date:
    if not _DATE_RE.match(s):
        raise ValueError(f"{field} 는 YYYY-MM-DD 형식이어야 합니다. (입력: {s})")
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError as e:
        raise ValueError(f"{field} 가 유효한 날짜가 아닙니다: {s}") from e


def to_yyyymmdd(d: date) -> str:
    """카카오 리포트 API 의 dateFrom/dateTo 는 YYYYMMDD 형식."""
    return d.strftime("%Y%m%d")


def yesterday_kst() -> date:
    """KST 기준 어제 (서버 TZ 와 무관하게 KST 사용)."""
    # UTC today - 1. 카카오는 KST 기준이라 자정 근처 경계는 사용자 명령 컨텍스트에서 보정.
    return date.today() - timedelta(days=1)
