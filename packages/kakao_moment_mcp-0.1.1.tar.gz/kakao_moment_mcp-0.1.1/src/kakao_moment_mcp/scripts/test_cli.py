"""로컬 CLI 테스트 도구.

MCP 프로토콜을 거치지 않고 도구 함수를 직접 호출해 응답을 확인한다.
Claude Desktop / Claude Code 연동 전 빠르게 검증할 때 사용.

사용 예:
    # 도구 목록
    uv run kakao-moment-mcp-test list

    # 인자 없는 도구 호출
    uv run kakao-moment-mcp-test call get_ad_account_info
    uv run kakao-moment-mcp-test call get_bizmoney
    uv run kakao-moment-mcp-test call get_today_status

    # 인자 있는 도구 호출 (--arg 반복 또는 --json)
    uv run kakao-moment-mcp-test call list_campaigns --arg status_filter=ON
    uv run kakao-moment-mcp-test call list_adgroups --arg campaign_id=12345
    uv run kakao-moment-mcp-test call get_performance_report \\
        --arg target=campaign --arg date_from=2026-05-10 --arg date_to=2026-05-10
    uv run kakao-moment-mcp-test call get_performance_report \\
        --json '{"target":"campaign","date_from":"2026-05-10","date_to":"2026-05-10"}'

    # 한 번에 전부 핑(get_*) 실행해서 인증/네트워크 확인
    uv run kakao-moment-mcp-test smoke
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Awaitable, Callable
from datetime import date, timedelta
from typing import Any

from ..config import ConfigError, load_settings
from ..kakao.client import KakaoApiError, KakaoMomentClient
from ..logging import setup_logging
from ..tools.account import get_ad_account_info, get_bizmoney, get_today_status
from ..tools.adgroups import list_adgroups
from ..tools.campaigns import list_campaigns
from ..tools.creatives import list_creatives
from ..tools.reports import get_performance_report

# 도구명 -> (호출 함수, 허용 인자 목록)
TOOLS: dict[str, tuple[Callable[..., Awaitable[Any]], list[str]]] = {
    "get_ad_account_info": (get_ad_account_info, []),
    "get_bizmoney": (get_bizmoney, []),
    "get_today_status": (get_today_status, []),
    "list_campaigns": (list_campaigns, ["status_filter"]),
    "list_adgroups": (list_adgroups, ["campaign_id"]),
    "list_creatives": (list_creatives, ["adgroup_id"]),
    "get_performance_report": (
        get_performance_report,
        ["target", "date_from", "date_to", "target_id", "breakdown"],
    ),
}


def _print_json(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


async def _skip(reason: str) -> dict[str, str]:
    """smoke 에서 chain 호출 불가능 케이스를 SKIP 처럼 표시."""
    return {"skipped": reason}


def _parse_args_list(arg_pairs: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for pair in arg_pairs:
        if "=" not in pair:
            raise SystemExit(f"--arg 는 key=value 형식이어야 합니다. (입력: {pair})")
        k, v = pair.split("=", 1)
        out[k.strip()] = v
    return out


async def _call(tool_name: str, kwargs: dict[str, Any]) -> Any:
    if tool_name not in TOOLS:
        raise SystemExit(
            f"알 수 없는 도구: {tool_name}\n사용 가능: {', '.join(TOOLS.keys())}"
        )
    fn, allowed = TOOLS[tool_name]
    unknown = set(kwargs) - set(allowed)
    if unknown:
        raise SystemExit(
            f"도구 {tool_name} 가 받지 않는 인자: {sorted(unknown)}\n"
            f"허용: {allowed or '(없음)'}"
        )

    settings = load_settings()
    setup_logging(level=settings.log_level, log_dir=settings.log_dir)
    client = KakaoMomentClient(settings)
    try:
        return await fn(client, **kwargs)
    finally:
        await client.aclose()


async def _smoke() -> int:
    """인증과 네트워크가 정상인지 빠르게 확인.

    list_adgroups / list_creatives 는 상위 ID 가 필수라, 먼저 list_campaigns 에서
    한 건을 골라 그 ID 로 chain 호출한다.
    """
    settings = load_settings()
    setup_logging(level=settings.log_level, log_dir=settings.log_dir)
    client = KakaoMomentClient(settings)
    yesterday = (date.today() - timedelta(days=1)).isoformat()

    # 캠페인 한 건 먼저 가져와서 chain 에 사용
    first_campaign_id: str | None = None
    first_adgroup_id: str | None = None
    try:
        camp = await list_campaigns(client)
        if camp.get("items"):
            first_campaign_id = str(camp["items"][0]["id"])
    except Exception:  # noqa: BLE001
        pass
    if first_campaign_id:
        try:
            ag = await list_adgroups(client, campaign_id=first_campaign_id)
            if ag.get("items"):
                first_adgroup_id = str(ag["items"][0]["id"])
        except Exception:  # noqa: BLE001
            pass

    plan: list[tuple[str, Callable[[], Awaitable[Any]]]] = [
        ("get_ad_account_info", lambda: get_ad_account_info(client)),
        ("get_bizmoney", lambda: get_bizmoney(client)),
        ("get_today_status", lambda: get_today_status(client)),
        ("list_campaigns", lambda: list_campaigns(client)),
        (
            f"list_adgroups(campaign_id={first_campaign_id})",
            lambda: list_adgroups(client, campaign_id=first_campaign_id)  # type: ignore[arg-type]
            if first_campaign_id
            else _skip("캠페인 없음"),
        ),
        (
            f"list_creatives(adgroup_id={first_adgroup_id})",
            lambda: list_creatives(client, adgroup_id=first_adgroup_id)  # type: ignore[arg-type]
            if first_adgroup_id
            else _skip("광고그룹 없음"),
        ),
        (
            "get_performance_report(어제, account)",
            lambda: get_performance_report(
                client, target="account", date_from=yesterday, date_to=yesterday
            ),
        ),
    ]
    failed = 0
    try:
        for label, coro in plan:
            print(f"\n▶ {label}")
            try:
                result = await coro()
            except KakaoApiError as e:
                failed += 1
                print(f"  ❌ KakaoApiError status={e.status} code={e.code}: {e}")
                continue
            except Exception as e:  # noqa: BLE001
                failed += 1
                print(f"  ❌ {type(e).__name__}: {e}")
                continue
            preview = json.dumps(result, ensure_ascii=False, default=str)
            if len(preview) > 400:
                preview = preview[:400] + "..."
            print(f"  ✅ {preview}")
    finally:
        await client.aclose()
    print(
        f"\n=== smoke 결과: {len(plan) - failed} 성공 / {failed} 실패 (총 {len(plan)}) ==="
    )
    return 0 if failed == 0 else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="kakao-moment-mcp-test",
        description="Kakao Moment MCP 도구를 MCP 프로토콜 없이 직접 호출",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="도구 목록 출력")

    call = sub.add_parser("call", help="도구 호출")
    call.add_argument("tool", help=f"도구 이름. 선택지: {', '.join(TOOLS.keys())}")
    call.add_argument(
        "--arg",
        action="append",
        default=[],
        metavar="key=value",
        help="도구 인자 (반복 가능)",
    )
    call.add_argument(
        "--json",
        dest="json_args",
        help="도구 인자를 JSON 객체로 한 번에 지정",
    )

    sub.add_parser("smoke", help="모든 조회 도구를 순차 호출해 인증/네트워크 확인")
    sub.add_parser("scopes", help="현재 비즈니스 토큰의 권한/광고계정 접근 범위 조회")
    return p


async def _scopes() -> int:
    """비즈니스 토큰 권한 조회 (GET https://kapi.kakao.com/v1/business/tokeninfo).

    카카오모먼트 API는 일반 카카오 로그인 토큰이 아니라 비즈니스 토큰을 요구한다.
    """
    from ..auth.token_store import load_tokens

    tokens = load_tokens()
    if tokens is None:
        print(
            "❌ 토큰이 없습니다. 먼저 `kakao-moment-mcp-authorize` 를 실행하세요.",
            file=sys.stderr,
        )
        return 2
    if tokens.is_expired():
        print("❌ 비즈니스 토큰이 만료되었습니다. 다시 인증하세요.", file=sys.stderr)
        return 1

    import httpx

    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.get(
            "https://kapi.kakao.com/v1/business/tokeninfo",
            headers={"Authorization": f"Bearer {tokens.access_token}"},
        )
    if resp.status_code >= 400:
        print(f"❌ 비즈니스 토큰 조회 실패: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1
    body = resp.json()
    print(f"status: {body.get('status')}")
    print(f"token_user_id: {body.get('token_user_id')}")
    print()
    print(f"{'group':<12} {'scopes':<45} ad_account_ids")
    print("-" * 90)
    for agreement in body.get("biz_agreements", []):
        group = str(agreement.get("group", ""))
        scopes = ",".join(str(s) for s in agreement.get("scope", []))
        ad_accounts = ",".join(str(a) for a in agreement.get("ad_account_ids", []))
        print(f"{group:<12} {scopes:<45} {ad_accounts}")
    return 0


def main() -> int:
    args = build_parser().parse_args()

    if args.cmd == "list":
        for name, (_, allowed) in TOOLS.items():
            arg_doc = ", ".join(allowed) if allowed else "(없음)"
            print(f"  {name}  — 인자: {arg_doc}")
        return 0

    try:
        if args.cmd == "smoke":
            return asyncio.run(_smoke())

        if args.cmd == "scopes":
            return asyncio.run(_scopes())

        if args.cmd == "call":
            kwargs: dict[str, Any] = {}
            if args.json_args:
                kwargs.update(json.loads(args.json_args))
            kwargs.update(_parse_args_list(args.arg))
            result = asyncio.run(_call(args.tool, kwargs))
            _print_json(result)
            return 0
    except ConfigError as e:
        print(f"❌ 설정 오류: {e}", file=sys.stderr)
        return 2
    except KakaoApiError as e:
        print(f"❌ KakaoApiError status={e.status} code={e.code}: {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
