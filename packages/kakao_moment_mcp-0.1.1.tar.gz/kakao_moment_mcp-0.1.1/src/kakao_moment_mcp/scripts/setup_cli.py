"""최초 설치 대화형 CLI.

실행 흐름:
1. 카카오 디벨로퍼스 자격증명 입력 (REST API Key, Client Secret, 광고계정 ID)
2. ~/.kakao-moment-mcp/.env 에 저장 (chmod 600)
3. (선택) OAuth 인증 즉시 실행
4. Claude Desktop / Claude Code 등록 가이드 출력

사용:
    uv run kakao-moment-mcp-setup
    uvx --from kakao-moment-mcp kakao-moment-mcp-setup
"""
from __future__ import annotations

import getpass
import json
import os
import sys
from pathlib import Path

from ..config import HOME_CONFIG_DIR, HOME_ENV_PATH, TOKEN_PATH

DEFAULT_REDIRECT = "http://localhost:8765/callback"
# 기본 비움 → OAuth 요청에 scope 파라미터를 보내지 않음 → 카카오는 콘솔에서
# 활성화된 동의항목을 자동으로 사용. 필요 시 .env 에서 수동 지정.
DEFAULT_SCOPES = ""


def _prompt(label: str, *, default: str | None = None, secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    while True:
        prompt = f"{label}{suffix}: "
        value = getpass.getpass(prompt) if secret else input(prompt)
        value = value.strip()
        if not value and default is not None:
            return default
        if value:
            return value
        print("  값을 입력해주세요.")


def _confirm(label: str, *, default: bool = True) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    while True:
        ans = input(f"{label}{suffix}: ").strip().lower()
        if not ans:
            return default
        if ans in ("y", "yes"):
            return True
        if ans in ("n", "no"):
            return False
        print("  y 또는 n 으로 답해주세요.")


def _write_env(values: dict[str, str]) -> Path:
    HOME_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(HOME_CONFIG_DIR, 0o700)
    except PermissionError:
        pass

    existing = ""
    if HOME_ENV_PATH.exists():
        existing = HOME_ENV_PATH.read_text()

    lines = []
    keys_set = set(values.keys())
    # 기존 .env 의 다른 키들은 보존
    for line in existing.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            lines.append(line)
            continue
        if "=" in stripped:
            k = stripped.split("=", 1)[0].strip()
            if k in keys_set:
                continue  # 새 값으로 덮어쓰기 위해 제거
        lines.append(line)

    # 헤더 코멘트가 비어있으면 추가
    if not any(line.startswith("# Kakao Moment MCP") for line in lines):
        lines = ["# Kakao Moment MCP 자격증명 (절대 공유 금지)", *lines]

    for k, v in values.items():
        lines.append(f"{k}={v}")

    HOME_ENV_PATH.write_text("\n".join(lines).rstrip() + "\n")
    try:
        os.chmod(HOME_ENV_PATH, 0o600)
    except PermissionError:
        pass
    return HOME_ENV_PATH


def _detect_claude_code() -> bool:
    """`claude` 바이너리 존재 여부."""
    from shutil import which

    return which("claude") is not None


def _claude_desktop_config_path() -> Path | None:
    if sys.platform == "darwin":
        return (
            Path.home()
            / "Library"
            / "Application Support"
            / "Claude"
            / "claude_desktop_config.json"
        )
    if sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
        return None
    # Linux 는 공식 데스크탑 앱이 없음
    return None


def _cursor_config_path() -> Path:
    """Cursor 의 사용자 레벨 MCP 설정 (OS 무관)."""
    return Path.home() / ".cursor" / "mcp.json"


def _cline_config_path() -> Path | None:
    """Cline (VSCode 확장)의 MCP 설정 파일."""
    home = Path.home()
    if sys.platform == "darwin":
        base = home / "Library" / "Application Support" / "Code"
    elif sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA")
        if not appdata:
            return None
        base = Path(appdata) / "Code"
    else:
        base = home / ".config" / "Code"
    return (
        base
        / "User"
        / "globalStorage"
        / "saoudrizwan.claude-dev"
        / "settings"
        / "cline_mcp_settings.json"
    )


def _mcp_server_entry() -> dict:
    """MCP 서버 실행 명령.

    - PyPI 에 배포되어 `uvx` 로 패키지명만 호출 가능하면 그 방식 (권장, clone 불필요).
    - 로컬 개발/테스트 중이면 현재 체크아웃 디렉토리를 가리키는 `uv --directory` 방식.

    구분은 환경변수 KAKAO_MCP_LOCAL=1 (setup 시 자동 감지) 또는
    부모 디렉토리에 pyproject.toml + src/kakao_moment_mcp 가 있으면 로컬로 판단.
    """
    repo_root = Path(__file__).resolve().parents[3]
    is_local_checkout = (repo_root / "pyproject.toml").exists() and (
        repo_root / "src" / "kakao_moment_mcp"
    ).exists()
    if is_local_checkout and os.environ.get("KAKAO_MCP_PUBLISHED") != "1":
        return {
            "command": "uv",
            "args": [
                "--directory",
                str(repo_root),
                "run",
                "kakao-moment-mcp",
            ],
        }
    return {
        "command": "uvx",
        "args": ["kakao-moment-mcp"],
    }


def _write_mcp_json_config(path: Path) -> tuple[bool, str]:
    """`mcpServers` 키를 가진 JSON config 파일에 kakao-moment 항목을 병합.

    Claude Desktop / Cursor / Cline 등 동일 포맷을 쓰는 클라이언트에 공통 사용.
    Returns: (변경 발생 여부, 메시지)
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    cfg: dict = {}
    if path.exists():
        try:
            cfg = json.loads(path.read_text() or "{}")
        except json.JSONDecodeError:
            return False, (
                f"기존 {path} 가 유효한 JSON 이 아닙니다. 수동으로 편집해주세요."
            )

    servers = cfg.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        return False, "mcpServers 가 객체가 아닙니다. 수동 편집 필요."

    new_entry = _mcp_server_entry()
    existing = servers.get("kakao-moment")
    if existing == new_entry:
        return False, "이미 동일한 설정이 등록되어 있습니다."

    if path.exists():
        backup = path.with_suffix(".json.bak")
        backup.write_text(path.read_text())

    servers["kakao-moment"] = new_entry
    path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False))
    return True, f"등록 완료: {path}"


# 기존 이름 유지 — 외부에서 참조 시 안전.
_write_claude_desktop_config = _write_mcp_json_config


def _setup_claude_desktop() -> None:
    cfg_path = _claude_desktop_config_path()
    if cfg_path is None:
        print()
        print("ℹ️  이 OS 에서는 Claude Desktop 자동 설정을 지원하지 않습니다.")
        return

    if not cfg_path.parent.exists():
        print()
        print(f"ℹ️  Claude Desktop 이 설치되어 있지 않은 것 같습니다 ({cfg_path.parent}).")
        print("   설치 후 다시 실행하거나, 수동 등록 가이드를 참고하세요.")
        return

    print()
    print(f"🖥️  Claude Desktop 설정 파일 감지: {cfg_path}")
    if not _confirm("Claude Desktop 에 kakao-moment 를 자동 등록할까요?", default=True):
        print("   건너뜁니다. 수동 등록은 README 참고.")
        return

    changed, msg = _write_claude_desktop_config(cfg_path)
    print(f"   {'✅' if changed else 'ℹ️'} {msg}")
    if changed:
        print("   ⚠️  변경 사항을 적용하려면 Claude Desktop 을 완전히 종료 후 재시작하세요.")


def _setup_cursor() -> None:
    cfg_path = _cursor_config_path()
    detected = cfg_path.exists() or cfg_path.parent.exists()
    print()
    label = "Cursor" + (" (감지됨)" if detected else "")
    if not _confirm(f"{label} 에 kakao-moment 를 등록할까요?", default=detected):
        return
    changed, msg = _write_mcp_json_config(cfg_path)
    print(f"   {'✅' if changed else 'ℹ️'} {msg}")
    if changed:
        print("   ⚠️  Cursor 를 재시작하면 도구가 보입니다.")


def _setup_cline() -> None:
    cfg_path = _cline_config_path()
    if cfg_path is None:
        return
    detected = cfg_path.exists() or cfg_path.parent.parent.parent.exists()
    print()
    label = "Cline(VSCode 확장)" + (" (감지됨)" if detected else "")
    if not _confirm(f"{label} 에 kakao-moment 를 등록할까요?", default=detected):
        return
    changed, msg = _write_mcp_json_config(cfg_path)
    print(f"   {'✅' if changed else 'ℹ️'} {msg}")
    if changed:
        print("   ⚠️  VSCode/Cline 패널을 새로고침하면 도구가 보입니다.")


def _setup_claude_code() -> None:
    if not _detect_claude_code():
        return
    print()
    if not _confirm(
        "Claude Code(CLI) 가 감지되었습니다. 글로벌 MCP 로 등록할까요?",
        default=True,
    ):
        return
    import subprocess

    entry = _mcp_server_entry()
    cmd = [
        "claude",
        "mcp",
        "add",
        "kakao-moment",
        "--",
        entry["command"],
        *entry["args"],
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        print(f"   ❌ 등록 실패: {e}")
        return
    if result.returncode == 0:
        print("   ✅ Claude Code 에 등록 완료. `claude` 세션에서 자연어 호출 가능.")
    else:
        # 이미 등록된 경우 등 — stderr 그대로 출력
        print(f"   ℹ️  {result.stderr.strip() or result.stdout.strip()}")


def main() -> int:
    print("=" * 60)
    print("  Kakao Moment MCP — Setup")
    print("=" * 60)
    print()
    print("카카오 디벨로퍼스 (https://developers.kakao.com/console/app) 에서")
    print("미리 다음을 준비해주세요:")
    print("  • 비즈앱 전환 + 카카오모먼트 API 사용 권한 승인 완료")
    print("  • 앱 → 앱 키 → REST API 키")
    print("  • 앱 → 보안 → Client Secret (활성화)")
    print(f"  • 앱 → 카카오 로그인 → Redirect URI 에 {DEFAULT_REDIRECT} 추가")
    print("  • 광고계정 ID (카카오모먼트 → 광고계정 설정)")
    print()
    if not _confirm("준비되셨나요?", default=True):
        print("준비 후 다시 실행해주세요.")
        return 1

    print()
    print("▶ 자격증명 입력 (Client Secret 은 입력 시 화면에 표시되지 않습니다)")
    print()

    rest_key = _prompt("KAKAO_REST_API_KEY", secret=True)
    client_secret = _prompt("KAKAO_CLIENT_SECRET", secret=True)
    ad_account_id = _prompt("KAKAO_AD_ACCOUNT_ID (숫자)")
    redirect_uri = _prompt("KAKAO_REDIRECT_URI", default=DEFAULT_REDIRECT)
    # scope 는 비워서 카카오 콘솔의 "활성 동의항목" 자동 적용. 명시할 필요 없음.
    scopes = DEFAULT_SCOPES
    print("  KAKAO_OAUTH_SCOPES: (비움 — 카카오 콘솔 활성 항목 자동 적용)")

    env_path = _write_env(
        {
            "KAKAO_REST_API_KEY": rest_key,
            "KAKAO_CLIENT_SECRET": client_secret,
            "KAKAO_AD_ACCOUNT_ID": ad_account_id,
            "KAKAO_REDIRECT_URI": redirect_uri,
            "KAKAO_OAUTH_SCOPES": scopes,
        }
    )
    print()
    if sys.platform.startswith("win"):
        print(f"✅ 자격증명을 저장했습니다: {env_path}")
        print(
            "   (Windows 는 chmod 가 무력하지만, "
            "%USERPROFILE% 폴더 자체가 사용자별로 격리되어 있습니다.)"
        )
    else:
        print(f"✅ 자격증명을 저장했습니다: {env_path} (권한 0600)")

    print()
    if _confirm("지금 OAuth 인증을 진행할까요? (브라우저가 열립니다)", default=True):
        # 환경변수에 즉시 반영해서 load_settings 가 새 값을 읽도록
        os.environ["KAKAO_REST_API_KEY"] = rest_key
        os.environ["KAKAO_CLIENT_SECRET"] = client_secret
        os.environ["KAKAO_AD_ACCOUNT_ID"] = ad_account_id
        os.environ["KAKAO_REDIRECT_URI"] = redirect_uri
        os.environ["KAKAO_OAUTH_SCOPES"] = scopes

        from ..auth.oauth import authorize_interactive
        from ..config import load_settings

        try:
            settings = load_settings()
            tokens = authorize_interactive(settings)
        except Exception as e:  # noqa: BLE001
            print(f"❌ 인증 실패: {e}")
            print(
                "   자격증명/Redirect URI 등록 여부를 확인 후 "
                "`uv run kakao-moment-mcp-authorize` 로 재시도하세요."
            )
            return 1
        print()
        print("✅ 인증 완료")
        print(f"   토큰: {TOKEN_PATH}")
        print(f"   scope: {tokens.scope or '(unknown)'}")
    else:
        print()
        print("⏭  나중에 `uv run kakao-moment-mcp-authorize` 로 인증해주세요.")

    print()
    print("▶ CLI 테스트")
    print("   uv run kakao-moment-mcp-test list")
    print("   uv run kakao-moment-mcp-test smoke")
    print("   uv run kakao-moment-mcp-test call get_ad_account_info")

    print()
    print("▶ MCP 클라이언트 등록")
    print("   감지된 클라이언트는 기본값 [Y], 그 외는 [N] 입니다.")
    _setup_claude_code()
    _setup_claude_desktop()
    _setup_cursor()
    _setup_cline()

    print()
    print("🎉 Setup 완료")
    print()
    print("문제가 생기면 다음 명령으로 진단:")
    print("   uvx --from kakao-moment-mcp kakao-moment-mcp-doctor")
    print("로그는 ~/.kakao-moment-mcp/logs/server.jsonl 에 저장됩니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
