"""최초 OAuth 인증 CLI.

실행:
    uvx --from kakao-moment-mcp kakao-moment-mcp-authorize
또는 개발 시:
    uv run kakao-moment-mcp-authorize
"""
from __future__ import annotations

import sys

from ..auth.oauth import authorize_interactive
from ..config import TOKEN_PATH, ConfigError, load_settings


def main() -> int:
    try:
        settings = load_settings()
    except ConfigError as e:
        print(f"❌ 설정 오류: {e}", file=sys.stderr)
        return 2

    print(f"📂 토큰 저장 경로: {TOKEN_PATH}")
    print(f"📍 Redirect URI:  {settings.redirect_uri}")
    print(f"🔐 Scopes:        {', '.join(settings.oauth_scopes) or '(none)'}")
    try:
        tokens = authorize_interactive(settings)
    except RuntimeError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"❌ 예기치 못한 오류: {e}", file=sys.stderr)
        return 1

    print("\n✅ 인증 완료!")
    print(f"   - 토큰이 {TOKEN_PATH} 에 저장되었습니다 (권한 0600).")
    print(f"   - scope: {tokens.scope or '(unknown)'}")
    print("\n이제 Claude Desktop 을 재시작하면 카카오모먼트 도구를 사용할 수 있습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
