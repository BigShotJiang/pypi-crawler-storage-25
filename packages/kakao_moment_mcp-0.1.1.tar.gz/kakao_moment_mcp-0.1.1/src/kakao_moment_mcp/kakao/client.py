"""카카오모먼트 API HTTP 클라이언트.

- Business Bearer token 자동 주입
- 401 응답 시 재인증 안내
- 429 / 5xx 응답 시 exponential backoff (1s, 2s, 4s, 최대 3회), 시도 횟수 로그
- adAccountId 헤더 자동 추가 (카카오모먼트 표준)
- httpx event hook 으로 모든 요청/응답 구조화 로그
"""
from __future__ import annotations

import asyncio
import time
import uuid
from typing import Any

import httpx
import structlog

from ..auth.token_store import TokenSet, load_tokens
from ..config import Settings
from .errors import KakaoApiError, from_response

_LOG = structlog.get_logger("kakao_moment_mcp.http")

_MAX_RETRIES = 3
_BACKOFF_BASE = 1.0
_RETRY_STATUSES = {429, 500, 502, 503, 504}


async def _on_request(request: httpx.Request) -> None:
    request.extensions["kakao_started_at"] = time.perf_counter()
    request.extensions["kakao_call_id"] = uuid.uuid4().hex[:8]
    _LOG.debug(
        "http_request",
        method=request.method,
        path=request.url.path,
        call_id=request.extensions["kakao_call_id"],
    )


async def _on_response(response: httpx.Response) -> None:
    request = response.request
    started = request.extensions.get("kakao_started_at")
    duration_ms = (
        int((time.perf_counter() - started) * 1000) if started else None
    )
    level = "info" if response.status_code < 400 else "warning"
    getattr(_LOG, level)(
        "http_response",
        method=request.method,
        path=request.url.path,
        http_status=response.status_code,
        duration_ms=duration_ms,
        call_id=request.extensions.get("kakao_call_id"),
    )


class KakaoMomentClient:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._tokens: TokenSet | None = load_tokens()
        self._http = httpx.AsyncClient(
            base_url=settings.api_base_url,
            timeout=30.0,
            headers={"User-Agent": "kakao-moment-mcp/0.1"},
            event_hooks={"request": [_on_request], "response": [_on_response]},
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    @property
    def ad_account_id(self) -> str:
        return self._settings.ad_account_id

    def _require_tokens(self) -> TokenSet:
        if not self._tokens:
            raise RuntimeError(
                "토큰이 없습니다. 먼저 `uvx --from kakao-moment-mcp "
                "kakao-moment-mcp-authorize` 를 실행해 인증하세요."
            )
        return self._tokens

    async def _ensure_fresh(self) -> TokenSet:
        tokens = self._require_tokens()
        if tokens.is_expired():
            raise RuntimeError(
                "비즈니스 토큰이 만료되었거나 유효하지 않습니다. "
                "`uv run kakao-moment-mcp-authorize` 로 다시 인증하세요."
            )
        assert self._tokens is not None
        return self._tokens

    def _headers(self, tokens: TokenSet) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {tokens.access_token}",
            # 카카오모먼트는 광고계정 ID 를 헤더로 받는다.
            "adAccountId": str(self._settings.ad_account_id),
        }

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        tokens = await self._ensure_fresh()
        attempt = 0
        while True:
            resp = await self._http.request(
                method,
                path,
                params=params,
                json=json,
                headers=self._headers(tokens),
            )
            if resp.status_code == 401:
                raise from_response(resp)
            if resp.status_code in _RETRY_STATUSES and attempt < _MAX_RETRIES:
                delay = _BACKOFF_BASE * (2**attempt)
                attempt += 1
                _LOG.warning(
                    "http_retry",
                    method=method,
                    path=path,
                    http_status=resp.status_code,
                    attempt=attempt,
                    delay_s=delay,
                )
                await asyncio.sleep(delay)
                continue
            if resp.status_code >= 400:
                raise from_response(resp)
            if not resp.content:
                return None
            return resp.json()

    async def get(self, path: str, **kw: Any) -> Any:
        return await self.request("GET", path, **kw)


__all__ = ["KakaoMomentClient", "KakaoApiError"]
