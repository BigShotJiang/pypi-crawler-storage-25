"""카카오 API 에러 → 사용자 친화 메시지.

원본 카카오 응답 본문은 로그에만 남기고, MCP 사용자(광고 운영자)에게는 "왜 실패했고
다음에 뭘 해야 하는지"가 한 문장으로 보이도록 변환한다.
"""
from __future__ import annotations

import httpx


class KakaoApiError(RuntimeError):
    def __init__(
        self,
        status: int,
        code: str | int | None,
        message: str,
        *,
        raw: str | None = None,
    ):
        self.status = status
        self.code = code
        self.raw = raw
        super().__init__(message if not code else f"[{code}] {message}")


# 카카오 공통 + 카카오모먼트 자주 보는 에러 코드.
# 모르는 코드는 응답 본문 그대로 노출 + HTTP status 힌트.
_FRIENDLY: dict[int, str] = {
    -401: (
        "액세스 토큰이 만료됐어요. "
        "`kakao-moment-mcp-authorize` 를 다시 실행해 재인증해 주세요."
    ),
    -402: (
        "권한이 없어요. 카카오 디벨로퍼스 → 동의항목과 광고계정 권한이 "
        "활성화되어 있는지 확인해 주세요."
    ),
    -10: "요청 파라미터가 잘못됐어요. 도구에 넘긴 인자를 다시 확인해 주세요.",
    -103: "리프레시 토큰이 무효 상태예요. 재인증이 필요합니다.",
    -301: "사용자(앱)가 등록되지 않았어요. 카카오 디벨로퍼스 앱 상태를 확인하세요.",
    -813: (
        "필수 파라미터가 빠졌어요. (예: list_adgroups 에는 campaign_id 가, "
        "list_creatives 에는 adgroup_id 가 필요합니다.)"
    ),
    -1907: "비즈머니 잔액이 부족해요. 충전 후 다시 시도하세요.",
}


def _friendly_for_status(status: int) -> str | None:
    if status == 401:
        return (
            "인증에 실패했어요. 토큰이 만료됐을 가능성이 큽니다. "
            "`kakao-moment-mcp-authorize` 를 다시 실행해 주세요."
        )
    if status == 403:
        return (
            "권한이 없어요. 카카오 디벨로퍼스에서 광고계정 권한과 "
            "동의항목을 확인해 주세요."
        )
    if status == 404:
        return (
            "리소스를 찾을 수 없어요. 광고계정 ID 또는 캠페인/그룹/소재 ID 를 확인해 주세요."
        )
    if status == 429:
        return (
            "카카오 API 호출이 잠시 제한됐어요(429). 잠시 후 다시 시도해 주세요."
        )
    if 500 <= status < 600:
        return "카카오 서버 일시 장애로 보입니다. 잠시 후 다시 시도해 주세요."
    return None


def from_response(resp: httpx.Response) -> KakaoApiError:
    code: str | int | None = None
    raw_msg: str = resp.text[:500]
    parsed_msg = raw_msg
    try:
        body = resp.json()
        if isinstance(body, dict):
            code = body.get("code", body.get("error_code"))
            parsed_msg = (
                body.get("msg")
                or body.get("message")
                or body.get("error_description")
                or body.get("error")
                or raw_msg
            )
    except ValueError:
        pass

    code_int = code if isinstance(code, int) else None
    friendly = _FRIENDLY.get(code_int) if code_int is not None else None
    if friendly is None:
        friendly = _friendly_for_status(resp.status_code)

    if friendly:
        message = f"{friendly} (원본: {parsed_msg})"
    else:
        message = f"[HTTP {resp.status_code}] {parsed_msg}"
    return KakaoApiError(resp.status_code, code, message, raw=raw_msg)
