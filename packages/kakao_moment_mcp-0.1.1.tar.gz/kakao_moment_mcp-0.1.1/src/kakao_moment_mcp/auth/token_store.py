"""OAuth 토큰을 ~/.kakao-moment-mcp/tokens.json 에 파일 권한 0600 으로 저장.

오픈소스 배포이므로 절대 평문으로 환경변수나 레포에 저장하지 않는다.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from ..config import HOME_CONFIG_DIR, TOKEN_PATH


@dataclass
class TokenSet:
    access_token: str
    refresh_token: str
    expires_at: float  # epoch seconds
    token_type: str = "bearer"
    scope: str = ""

    def is_expired(self, leeway: int = 60) -> bool:
        return time.time() >= (self.expires_at - leeway)


def _ensure_dir() -> None:
    HOME_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(HOME_CONFIG_DIR, 0o700)
    except PermissionError:
        # Windows 등에서는 chmod 의미가 다르거나 실패할 수 있음. 조용히 통과.
        pass


def save_tokens(tokens: TokenSet, path: Path = TOKEN_PATH) -> None:
    _ensure_dir()
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(asdict(tokens), ensure_ascii=False, indent=2))
    try:
        os.chmod(tmp, 0o600)
    except PermissionError:
        pass
    tmp.replace(path)
    try:
        os.chmod(path, 0o600)
    except PermissionError:
        pass


def load_tokens(path: Path = TOKEN_PATH) -> TokenSet | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return TokenSet(**data)
    except (json.JSONDecodeError, TypeError, KeyError):
        return None


def clear_tokens(path: Path = TOKEN_PATH) -> None:
    if path.exists():
        path.unlink()
