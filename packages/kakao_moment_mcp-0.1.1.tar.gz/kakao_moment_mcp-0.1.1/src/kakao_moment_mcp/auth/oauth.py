"""카카오 비즈니스 인증 OAuth 2.0 Authorization Code Grant.

- authorize: 브라우저 인증 → 로컬 콜백 서버에서 code 수신 → business token 교환

토큰은 token_store 를 통해 ~/.kakao-moment-mcp/tokens.json 에 저장.
"""
from __future__ import annotations

import secrets
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread

import httpx

from ..config import Settings
from .token_store import TokenSet, save_tokens


@dataclass
class _Capture:
    code: str | None = None
    state: str | None = None
    error: str | None = None


class _CallbackHandler(BaseHTTPRequestHandler):
    capture: _Capture = _Capture()
    expected_state: str = ""

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return
        qs = urllib.parse.parse_qs(parsed.query)
        if "error" in qs:
            type(self).capture.error = qs.get("error_description", ["unknown"])[0]
            self._respond("인증 실패. 터미널로 돌아가세요.".encode())
            return
        state = qs.get("state", [""])[0]
        if state != type(self).expected_state:
            type(self).capture.error = "state mismatch (CSRF 가능성)"
            self._respond(b"state mismatch")
            return
        code = qs.get("code", [""])[0]
        type(self).capture.code = code
        type(self).capture.state = state
        # UTF-8 인코딩된 한국어 성공 메시지
        body = (
            "<html><head><meta charset='utf-8'><title>OK</title></head>"
            "<body style='font-family: sans-serif; padding: 40px;'>"
            "<h2>✅ 카카오 인증 완료</h2>"
            "<p>이 창을 닫고 터미널로 돌아가세요.</p>"
            "</body></html>"
        ).encode()
        self._respond(body, content_type="text/html; charset=utf-8")

    def _respond(self, body: bytes, content_type: str = "text/plain; charset=utf-8") -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):  # noqa: A002
        # 콘솔에 액세스 로그 찍지 않음 (토큰 코드가 URL 에 포함되므로 잠재적 위험)
        return


def _exchange_code(
    settings: Settings, code: str
) -> TokenSet:
    data = {
        "grant_type": "authorization_code",
        "client_id": settings.rest_api_key,
        "client_secret": settings.client_secret,
        "redirect_uri": settings.redirect_uri,
        "code": code,
    }
    resp = httpx.post(settings.token_url, data=data, timeout=20.0)
    if resp.status_code >= 400:
        # 카카오 토큰 발급 실패: invalid_client (Client Secret 틀림),
        # invalid_grant (code 만료/Redirect URI 불일치) 등이 응답 본문에 명시됨.
        body = resp.text[:500]
        hint = ""
        if '"invalid_client"' in body or "client" in body.lower():
            hint = (
                "\n💡 Client Secret 이 다를 가능성이 큽니다. "
                "다른 키로 `kakao-moment-mcp-setup` 을 다시 실행해보세요."
            )
        raise RuntimeError(
            f"토큰 발급 실패 (status={resp.status_code}): {body}{hint}"
        )
    j = resp.json()
    return TokenSet(
        access_token=j["access_token"],
        refresh_token=j.get("refresh_token", ""),
        # Business token 응답은 refresh_token/expires_in 을 제공하지 않는다.
        # 로컬 만료는 넉넉하게 두고, 서버가 401을 반환하면 재인증을 안내한다.
        expires_at=time.time() + int(j.get("expires_in", 10 * 365 * 24 * 60 * 60)),
        token_type=j.get("token_type", "bearer"),
        scope=j.get("scope", ""),
    )


def authorize_interactive(settings: Settings) -> TokenSet:
    """브라우저 OAuth 인증 흐름 실행 (CLI). 블로킹."""
    parsed = urllib.parse.urlparse(settings.redirect_uri)
    host = parsed.hostname or "localhost"
    port = parsed.port or 8765

    state = secrets.token_urlsafe(24)
    _CallbackHandler.expected_state = state
    _CallbackHandler.capture = _Capture()

    server = HTTPServer((host, port), _CallbackHandler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()

    params = {
        "response_type": "code",
        "client_id": settings.rest_api_key,
        "redirect_uri": settings.redirect_uri,
        "state": state,
        "resource_ids": f"moment:{settings.ad_account_id}",
    }
    if settings.oauth_scopes:
        params["scope"] = ",".join(settings.oauth_scopes)
    auth_url = f"{settings.authorize_url}?{urllib.parse.urlencode(params)}"

    print("\n🌐 브라우저에서 카카오 로그인을 진행해주세요.")
    print(f"   브라우저가 자동으로 열리지 않으면 아래 URL 을 직접 열어주세요:\n   {auth_url}\n")
    try:
        webbrowser.open(auth_url)
    except Exception:
        pass

    try:
        # 콜백 수신까지 폴링 (최대 10분)
        deadline = time.time() + 600
        while time.time() < deadline:
            if _CallbackHandler.capture.code or _CallbackHandler.capture.error:
                break
            time.sleep(0.2)
    finally:
        server.shutdown()
        server.server_close()

    cap = _CallbackHandler.capture
    if cap.error:
        raise RuntimeError(f"OAuth 인증 실패: {cap.error}")
    if not cap.code:
        raise RuntimeError("OAuth 인증 시간 초과 (10분)")

    tokens = _exchange_code(settings, cap.code)
    save_tokens(tokens)
    return tokens


async def refresh_access_token(settings: Settings, refresh_token: str) -> TokenSet:
    data = {
        "grant_type": "refresh_token",
        "client_id": settings.rest_api_key,
        "client_secret": settings.client_secret,
        "refresh_token": refresh_token,
    }
    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.post(settings.token_url, data=data)
        resp.raise_for_status()
        j = resp.json()
    new_refresh = j.get("refresh_token") or refresh_token
    return TokenSet(
        access_token=j["access_token"],
        refresh_token=new_refresh,
        expires_at=time.time() + int(j.get("expires_in", 3600)),
        token_type=j.get("token_type", "bearer"),
        scope=j.get("scope", ""),
    )
