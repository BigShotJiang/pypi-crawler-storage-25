# Contributing to kakao-moment-mcp

기여 환영합니다! 광고 운영자가 자연어로 카카오모먼트를 다룰 수 있게 만드는 작은 도구입니다.

## 개발 환경 셋업

```bash
git clone https://github.com/jun7680/kakao-moment-mcp.git
cd kakao-moment-mcp
uv sync --extra dev
cp .env.example ~/.kakao-moment-mcp/.env  # 본인의 카카오 자격증명 입력
uv run kakao-moment-mcp-authorize          # OAuth 1회
```

## 로컬에서 확인하기

```bash
# 린트
uv run ruff check src/ tests/

# 테스트 (16 + 13 = 29 케이스)
uv run pytest -q

# 실제 카카오 API 호출 (인증 필요)
uv run kakao-moment-mcp-test smoke
uv run kakao-moment-mcp-test call get_today_status

# 진단
uv run kakao-moment-mcp-doctor
```

## PR 가이드

- **테스트가 필요한 변경**: 도구 응답 스키마, 카카오 API 파라미터/응답 처리, 인증/토큰 흐름 → 단위 테스트 추가.
- **테스트가 필요 없는 변경**: README 문구, docstring, 로그 메시지.
- **모든 PR은 CI(ruff + pytest)를 통과해야 머지**.
- 커밋 메시지는 한국어/영어 모두 환영. 제목은 50자 이내, 본문은 "왜" 위주.

## 새 도구 추가 절차 (Phase 2~4)

1. `src/kakao_moment_mcp/tools/<area>.py` 에 함수 추가
2. `src/kakao_moment_mcp/server.py` 에 `@mcp.tool` 데코레이터로 등록
3. **docstring에 "이런 질문에 사용하세요" 트리거 문구 작성** — Claude가 자연어를 매칭하는 핵심.
4. Write 도구(Phase 2~4)는 반드시:
   - `dry_run: bool = True` 파라미터 지원
   - 변경 금액 ±50% 상한 (`safety/` 헬퍼)
   - JSON 로그 기록 (`@logged_tool` 자동 처리 + previous_value 캡처)
5. 테스트 추가 (`tests/test_<area>.py`)

## 카카오 API 응답 형태 변동

카카오는 응답 스키마를 예고 없이 바꾸는 경우가 있습니다. 신형/구형 모두 지원하도록:
- 리포트 응답은 `tools/reports.py._unwrap_metrics()` 를 거치게 하세요.
- LIST 엔드포인트가 lightweight면 detail 보강을 `_common.fetch_details()` 로.

## 릴리즈 / PyPI 배포 (메인테이너용)

PyPI 는 2024년부터 username/password 인증을 더 이상 받지 않습니다. **반드시 API 토큰**을 사용하세요.

1. https://pypi.org/manage/account/token/ 에서 API 토큰 발급 (Scope: project: `kakao-moment-mcp` 권장).
2. 환경변수로 박아두면 프롬프트가 뜨지 않습니다:
   ```bash
   export UV_PUBLISH_TOKEN='pypi-AgEI...'      # 셸 세션에만
   # 또는 ~/.zshrc 에 추가해 영구
   ```
3. 버전 올리고 빌드 → 배포:
   ```bash
   # pyproject.toml 의 version 수정, CHANGELOG.md 갱신
   uv build
   uv publish
   git tag v0.1.x && git push --tags
   ```

> ⚠️ 토큰은 시크릿입니다. 커밋/Slack/스크린샷 노출 금지. 노출 시 즉시 PyPI 콘솔에서 revoke.

## 이슈 등록

- 버그: `kakao-moment-mcp-doctor` 출력 + 재현 시나리오 첨부.
- 기능 요청: 운영 시나리오(자연어 질문 예시) 와 함께.

## 보안 이슈

`SECURITY.md` 참고. 토큰/시크릿이 포함된 경우 공개 이슈 대신 비공개 채널로 알려주세요.
