# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date

import httpx

from ..types import individual_list_params, individual_create_params, individual_update_params
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursorPagination, AsyncCursorPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.individual import Individual

__all__ = ["IndividualsResource", "AsyncIndividualsResource"]


class IndividualsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> IndividualsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return IndividualsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> IndividualsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return IndividualsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        first_name: str,
        household_id: str,
        last_name: str,
        address_line1: Optional[str] | Omit = omit,
        address_line2: Optional[str] | Omit = omit,
        city: Optional[str] | Omit = omit,
        country: Optional[str] | Omit = omit,
        date_of_birth: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        is_beneficiary: bool | Omit = omit,
        is_deceased: bool | Omit = omit,
        is_grantor: bool | Omit = omit,
        is_primary: bool | Omit = omit,
        is_trustee: bool | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        notes: Optional[str] | Omit = omit,
        postal_code: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Create a new client profile/individual with the provided data

        Args:
          first_name: First name of the individual

          household_id: Household ID this individual belongs to

          last_name: Last name of the individual

          address_line1: Street address line 1

          address_line2: Street address line 2

          city: City

          country: Country

          date_of_birth: Date of birth

          email: Email address

          is_beneficiary: Whether this client profile should be an eligible beneficiary for entities and
              gifts

          is_deceased: Whether the individual is deceased

          is_grantor: Whether this client profile should be an eligible grantor/owner/other principal
              for entities

          is_primary: Whether this is a primary client of the household (at most 2 per household)

          is_trustee: Whether this client profile should be an eligible trustee for entities

          middle_name: Middle name of the individual

          notes: Notes about the client profile

          postal_code: ZIP or postal code

          state: State or province code (2 letter code)

          suffix: Name suffix

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/individuals",
            body=maybe_transform(
                {
                    "first_name": first_name,
                    "household_id": household_id,
                    "last_name": last_name,
                    "address_line1": address_line1,
                    "address_line2": address_line2,
                    "city": city,
                    "country": country,
                    "date_of_birth": date_of_birth,
                    "email": email,
                    "is_beneficiary": is_beneficiary,
                    "is_deceased": is_deceased,
                    "is_grantor": is_grantor,
                    "is_primary": is_primary,
                    "is_trustee": is_trustee,
                    "middle_name": middle_name,
                    "notes": notes,
                    "postal_code": postal_code,
                    "state": state,
                    "suffix": suffix,
                },
                individual_create_params.IndividualCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Retrieve detailed information about a specific client profile

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/individuals/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    def update(
        self,
        id: str,
        *,
        address_line1: Optional[str] | Omit = omit,
        address_line2: Optional[str] | Omit = omit,
        city: Optional[str] | Omit = omit,
        country: Optional[str] | Omit = omit,
        date_of_birth: Union[str, date, None] | Omit = omit,
        date_of_death: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        first_name: str | Omit = omit,
        is_beneficiary: bool | Omit = omit,
        is_deceased: bool | Omit = omit,
        is_grantor: bool | Omit = omit,
        is_primary: bool | Omit = omit,
        is_trustee: bool | Omit = omit,
        last_name: str | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        notes: Optional[str] | Omit = omit,
        postal_code: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Update an existing client profile with new data

        Args:
          address_line1: Street address line 1

          address_line2: Street address line 2

          city: City

          country: Country

          date_of_birth: Date of birth

          date_of_death: Date of death if applicable

          email: Email address

          first_name: First name of the individual

          is_beneficiary: Whether this client profile should be an eligible beneficiary for entities and
              gifts

          is_deceased: Whether the individual is deceased

          is_grantor: Whether this client profile should be an eligible grantor/owner/other principal
              for entities

          is_primary: Whether this is a primary client of the household (at most 2 per household)

          is_trustee: Whether this client profile should be an eligible trustee for entities

          last_name: Last name of the individual

          middle_name: Middle name of the individual

          notes: Notes about the client profile

          postal_code: ZIP or postal code

          state: State or province code (2 letter code)

          suffix: Name suffix

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            path_template("/individuals/{id}", id=id),
            body=maybe_transform(
                {
                    "address_line1": address_line1,
                    "address_line2": address_line2,
                    "city": city,
                    "country": country,
                    "date_of_birth": date_of_birth,
                    "date_of_death": date_of_death,
                    "email": email,
                    "first_name": first_name,
                    "is_beneficiary": is_beneficiary,
                    "is_deceased": is_deceased,
                    "is_grantor": is_grantor,
                    "is_primary": is_primary,
                    "is_trustee": is_trustee,
                    "last_name": last_name,
                    "middle_name": middle_name,
                    "notes": notes,
                    "postal_code": postal_code,
                    "state": state,
                    "suffix": suffix,
                },
                individual_update_params.IndividualUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        household_id: str | Omit = omit,
        is_primary: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[Individual]:
        """
        Retrieve a paginated list of client profiles/individuals using cursor-based
        pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          household_id: Filter individuals by household ID

          is_primary: Filter by primary client status

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/individuals",
            page=SyncCursorPagination[Individual],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "household_id": household_id,
                        "is_primary": is_primary,
                        "limit": limit,
                    },
                    individual_list_params.IndividualListParams,
                ),
            ),
            model=Individual,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Soft delete a client profile (marks as deleted but preserves data)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/individuals/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncIndividualsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncIndividualsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncIndividualsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncIndividualsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return AsyncIndividualsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        first_name: str,
        household_id: str,
        last_name: str,
        address_line1: Optional[str] | Omit = omit,
        address_line2: Optional[str] | Omit = omit,
        city: Optional[str] | Omit = omit,
        country: Optional[str] | Omit = omit,
        date_of_birth: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        is_beneficiary: bool | Omit = omit,
        is_deceased: bool | Omit = omit,
        is_grantor: bool | Omit = omit,
        is_primary: bool | Omit = omit,
        is_trustee: bool | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        notes: Optional[str] | Omit = omit,
        postal_code: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Create a new client profile/individual with the provided data

        Args:
          first_name: First name of the individual

          household_id: Household ID this individual belongs to

          last_name: Last name of the individual

          address_line1: Street address line 1

          address_line2: Street address line 2

          city: City

          country: Country

          date_of_birth: Date of birth

          email: Email address

          is_beneficiary: Whether this client profile should be an eligible beneficiary for entities and
              gifts

          is_deceased: Whether the individual is deceased

          is_grantor: Whether this client profile should be an eligible grantor/owner/other principal
              for entities

          is_primary: Whether this is a primary client of the household (at most 2 per household)

          is_trustee: Whether this client profile should be an eligible trustee for entities

          middle_name: Middle name of the individual

          notes: Notes about the client profile

          postal_code: ZIP or postal code

          state: State or province code (2 letter code)

          suffix: Name suffix

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/individuals",
            body=await async_maybe_transform(
                {
                    "first_name": first_name,
                    "household_id": household_id,
                    "last_name": last_name,
                    "address_line1": address_line1,
                    "address_line2": address_line2,
                    "city": city,
                    "country": country,
                    "date_of_birth": date_of_birth,
                    "email": email,
                    "is_beneficiary": is_beneficiary,
                    "is_deceased": is_deceased,
                    "is_grantor": is_grantor,
                    "is_primary": is_primary,
                    "is_trustee": is_trustee,
                    "middle_name": middle_name,
                    "notes": notes,
                    "postal_code": postal_code,
                    "state": state,
                    "suffix": suffix,
                },
                individual_create_params.IndividualCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Retrieve detailed information about a specific client profile

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/individuals/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    async def update(
        self,
        id: str,
        *,
        address_line1: Optional[str] | Omit = omit,
        address_line2: Optional[str] | Omit = omit,
        city: Optional[str] | Omit = omit,
        country: Optional[str] | Omit = omit,
        date_of_birth: Union[str, date, None] | Omit = omit,
        date_of_death: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        first_name: str | Omit = omit,
        is_beneficiary: bool | Omit = omit,
        is_deceased: bool | Omit = omit,
        is_grantor: bool | Omit = omit,
        is_primary: bool | Omit = omit,
        is_trustee: bool | Omit = omit,
        last_name: str | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        notes: Optional[str] | Omit = omit,
        postal_code: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Individual:
        """
        Update an existing client profile with new data

        Args:
          address_line1: Street address line 1

          address_line2: Street address line 2

          city: City

          country: Country

          date_of_birth: Date of birth

          date_of_death: Date of death if applicable

          email: Email address

          first_name: First name of the individual

          is_beneficiary: Whether this client profile should be an eligible beneficiary for entities and
              gifts

          is_deceased: Whether the individual is deceased

          is_grantor: Whether this client profile should be an eligible grantor/owner/other principal
              for entities

          is_primary: Whether this is a primary client of the household (at most 2 per household)

          is_trustee: Whether this client profile should be an eligible trustee for entities

          last_name: Last name of the individual

          middle_name: Middle name of the individual

          notes: Notes about the client profile

          postal_code: ZIP or postal code

          state: State or province code (2 letter code)

          suffix: Name suffix

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            path_template("/individuals/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "address_line1": address_line1,
                    "address_line2": address_line2,
                    "city": city,
                    "country": country,
                    "date_of_birth": date_of_birth,
                    "date_of_death": date_of_death,
                    "email": email,
                    "first_name": first_name,
                    "is_beneficiary": is_beneficiary,
                    "is_deceased": is_deceased,
                    "is_grantor": is_grantor,
                    "is_primary": is_primary,
                    "is_trustee": is_trustee,
                    "last_name": last_name,
                    "middle_name": middle_name,
                    "notes": notes,
                    "postal_code": postal_code,
                    "state": state,
                    "suffix": suffix,
                },
                individual_update_params.IndividualUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Individual,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        household_id: str | Omit = omit,
        is_primary: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Individual, AsyncCursorPagination[Individual]]:
        """
        Retrieve a paginated list of client profiles/individuals using cursor-based
        pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          household_id: Filter individuals by household ID

          is_primary: Filter by primary client status

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/individuals",
            page=AsyncCursorPagination[Individual],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "household_id": household_id,
                        "is_primary": is_primary,
                        "limit": limit,
                    },
                    individual_list_params.IndividualListParams,
                ),
            ),
            model=Individual,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Soft delete a client profile (marks as deleted but preserves data)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/individuals/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class IndividualsResourceWithRawResponse:
    def __init__(self, individuals: IndividualsResource) -> None:
        self._individuals = individuals

        self.create = to_raw_response_wrapper(
            individuals.create,
        )
        self.retrieve = to_raw_response_wrapper(
            individuals.retrieve,
        )
        self.update = to_raw_response_wrapper(
            individuals.update,
        )
        self.list = to_raw_response_wrapper(
            individuals.list,
        )
        self.delete = to_raw_response_wrapper(
            individuals.delete,
        )


class AsyncIndividualsResourceWithRawResponse:
    def __init__(self, individuals: AsyncIndividualsResource) -> None:
        self._individuals = individuals

        self.create = async_to_raw_response_wrapper(
            individuals.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            individuals.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            individuals.update,
        )
        self.list = async_to_raw_response_wrapper(
            individuals.list,
        )
        self.delete = async_to_raw_response_wrapper(
            individuals.delete,
        )


class IndividualsResourceWithStreamingResponse:
    def __init__(self, individuals: IndividualsResource) -> None:
        self._individuals = individuals

        self.create = to_streamed_response_wrapper(
            individuals.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            individuals.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            individuals.update,
        )
        self.list = to_streamed_response_wrapper(
            individuals.list,
        )
        self.delete = to_streamed_response_wrapper(
            individuals.delete,
        )


class AsyncIndividualsResourceWithStreamingResponse:
    def __init__(self, individuals: AsyncIndividualsResource) -> None:
        self._individuals = individuals

        self.create = async_to_streamed_response_wrapper(
            individuals.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            individuals.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            individuals.update,
        )
        self.list = async_to_streamed_response_wrapper(
            individuals.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            individuals.delete,
        )
