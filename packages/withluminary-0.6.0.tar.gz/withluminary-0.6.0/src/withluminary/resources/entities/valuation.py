# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.entities import valuation_create_params
from ...types.entities.valuation import Valuation

__all__ = ["ValuationResource", "AsyncValuationResource"]


class ValuationResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ValuationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return ValuationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ValuationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return ValuationResourceWithStreamingResponse(self)

    def create(
        self,
        id: str,
        *,
        directly_held_assets: Iterable[valuation_create_params.DirectlyHeldAsset],
        effective_date: Union[str, date],
        description: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Valuation:
        """
        Add a new valuation to the entity's history

        Args:
          directly_held_assets: List of assets to include in this valuation

          effective_date: The date this valuation is effective

          description: Free-form notes about this valuation

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/entities/{id}/valuation", id=id),
            body=maybe_transform(
                {
                    "directly_held_assets": directly_held_assets,
                    "effective_date": effective_date,
                    "description": description,
                },
                valuation_create_params.ValuationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Valuation,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Valuation:
        """
        Retrieve the most recent valuation with flattened asset values by type

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/entities/{id}/valuation", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Valuation,
        )


class AsyncValuationResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncValuationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncValuationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncValuationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return AsyncValuationResourceWithStreamingResponse(self)

    async def create(
        self,
        id: str,
        *,
        directly_held_assets: Iterable[valuation_create_params.DirectlyHeldAsset],
        effective_date: Union[str, date],
        description: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Valuation:
        """
        Add a new valuation to the entity's history

        Args:
          directly_held_assets: List of assets to include in this valuation

          effective_date: The date this valuation is effective

          description: Free-form notes about this valuation

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/entities/{id}/valuation", id=id),
            body=await async_maybe_transform(
                {
                    "directly_held_assets": directly_held_assets,
                    "effective_date": effective_date,
                    "description": description,
                },
                valuation_create_params.ValuationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Valuation,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Valuation:
        """
        Retrieve the most recent valuation with flattened asset values by type

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/entities/{id}/valuation", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Valuation,
        )


class ValuationResourceWithRawResponse:
    def __init__(self, valuation: ValuationResource) -> None:
        self._valuation = valuation

        self.create = to_raw_response_wrapper(
            valuation.create,
        )
        self.retrieve = to_raw_response_wrapper(
            valuation.retrieve,
        )


class AsyncValuationResourceWithRawResponse:
    def __init__(self, valuation: AsyncValuationResource) -> None:
        self._valuation = valuation

        self.create = async_to_raw_response_wrapper(
            valuation.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            valuation.retrieve,
        )


class ValuationResourceWithStreamingResponse:
    def __init__(self, valuation: ValuationResource) -> None:
        self._valuation = valuation

        self.create = to_streamed_response_wrapper(
            valuation.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            valuation.retrieve,
        )


class AsyncValuationResourceWithStreamingResponse:
    def __init__(self, valuation: AsyncValuationResource) -> None:
        self._valuation = valuation

        self.create = async_to_streamed_response_wrapper(
            valuation.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            valuation.retrieve,
        )
