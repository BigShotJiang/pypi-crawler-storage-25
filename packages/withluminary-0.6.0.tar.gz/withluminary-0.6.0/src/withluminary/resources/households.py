# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ..types import (
    EntityKind,
    DocumentType,
    household_list_params,
    household_create_params,
    household_update_params,
    household_list_entities_params,
    household_list_documents_params,
    household_list_individuals_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursorPagination, AsyncCursorPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.entity import Entity
from ..types.document import Document
from ..types.household import Household
from ..types.individual import Individual
from ..types.entity_kind import EntityKind
from ..types.document_type import DocumentType

__all__ = ["HouseholdsResource", "AsyncHouseholdsResource"]


class HouseholdsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> HouseholdsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return HouseholdsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> HouseholdsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return HouseholdsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        primary_relationship_owner_id: str,
        notes: Optional[str] | Omit = omit,
        primary_individuals: Iterable[household_create_params.PrimaryIndividual] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Create a new household with the provided data

        Args:
          primary_relationship_owner_id: User ID of the primary relationship owner

          notes: Optional notes about the household

          primary_individuals: Primary client profiles to create for this household (at most 2)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/households",
            body=maybe_transform(
                {
                    "primary_relationship_owner_id": primary_relationship_owner_id,
                    "notes": notes,
                    "primary_individuals": primary_individuals,
                },
                household_create_params.HouseholdCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Retrieve detailed information about a specific household

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/households/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    def update(
        self,
        id: str,
        *,
        notes: Optional[str] | Omit = omit,
        primary_relationship_owner_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Update an existing household with new data

        Args:
          notes: Notes about the household

          primary_relationship_owner_id: User ID of the primary relationship owner

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            path_template("/households/{id}", id=id),
            body=maybe_transform(
                {
                    "notes": notes,
                    "primary_relationship_owner_id": primary_relationship_owner_id,
                },
                household_update_params.HouseholdUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[Household]:
        """
        Retrieve a paginated list of households using cursor-based pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/households",
            page=SyncCursorPagination[Household],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                    },
                    household_list_params.HouseholdListParams,
                ),
            ),
            model=Household,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Soft delete a household (marks as deleted but preserves data)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/households/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_documents(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        type: DocumentType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[Document]:
        """
        Retrieve a paginated list of documents belonging to a specific household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          limit: Maximum number of items to return

          type: Filter by document type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/documents", id=id),
            page=SyncCursorPagination[Document],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                        "type": type,
                    },
                    household_list_documents_params.HouseholdListDocumentsParams,
                ),
            ),
            model=Document,
        )

    def list_entities(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        kind: EntityKind | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[Entity]:
        """
        Retrieve a paginated list of entities belonging to a specific household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          kind: Filter by entity kind/type

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/entities", id=id),
            page=SyncCursorPagination[Entity],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "kind": kind,
                        "limit": limit,
                    },
                    household_list_entities_params.HouseholdListEntitiesParams,
                ),
            ),
            model=Entity,
        )

    def list_individuals(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        is_primary: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[Individual]:
        """
        Retrieve a paginated list of client profiles/individuals belonging to a specific
        household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          is_primary: Filter by primary client status

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/individuals", id=id),
            page=SyncCursorPagination[Individual],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "is_primary": is_primary,
                        "limit": limit,
                    },
                    household_list_individuals_params.HouseholdListIndividualsParams,
                ),
            ),
            model=Individual,
        )


class AsyncHouseholdsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncHouseholdsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncHouseholdsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncHouseholdsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return AsyncHouseholdsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        primary_relationship_owner_id: str,
        notes: Optional[str] | Omit = omit,
        primary_individuals: Iterable[household_create_params.PrimaryIndividual] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Create a new household with the provided data

        Args:
          primary_relationship_owner_id: User ID of the primary relationship owner

          notes: Optional notes about the household

          primary_individuals: Primary client profiles to create for this household (at most 2)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/households",
            body=await async_maybe_transform(
                {
                    "primary_relationship_owner_id": primary_relationship_owner_id,
                    "notes": notes,
                    "primary_individuals": primary_individuals,
                },
                household_create_params.HouseholdCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Retrieve detailed information about a specific household

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/households/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    async def update(
        self,
        id: str,
        *,
        notes: Optional[str] | Omit = omit,
        primary_relationship_owner_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Household:
        """
        Update an existing household with new data

        Args:
          notes: Notes about the household

          primary_relationship_owner_id: User ID of the primary relationship owner

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            path_template("/households/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "notes": notes,
                    "primary_relationship_owner_id": primary_relationship_owner_id,
                },
                household_update_params.HouseholdUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Household,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Household, AsyncCursorPagination[Household]]:
        """
        Retrieve a paginated list of households using cursor-based pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/households",
            page=AsyncCursorPagination[Household],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                    },
                    household_list_params.HouseholdListParams,
                ),
            ),
            model=Household,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Soft delete a household (marks as deleted but preserves data)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/households/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_documents(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        type: DocumentType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Document, AsyncCursorPagination[Document]]:
        """
        Retrieve a paginated list of documents belonging to a specific household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          limit: Maximum number of items to return

          type: Filter by document type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/documents", id=id),
            page=AsyncCursorPagination[Document],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                        "type": type,
                    },
                    household_list_documents_params.HouseholdListDocumentsParams,
                ),
            ),
            model=Document,
        )

    def list_entities(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        kind: EntityKind | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Entity, AsyncCursorPagination[Entity]]:
        """
        Retrieve a paginated list of entities belonging to a specific household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          kind: Filter by entity kind/type

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/entities", id=id),
            page=AsyncCursorPagination[Entity],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "kind": kind,
                        "limit": limit,
                    },
                    household_list_entities_params.HouseholdListEntitiesParams,
                ),
            ),
            model=Entity,
        )

    def list_individuals(
        self,
        id: str,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        is_primary: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Individual, AsyncCursorPagination[Individual]]:
        """
        Retrieve a paginated list of client profiles/individuals belonging to a specific
        household

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          is_primary: Filter by primary client status

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            path_template("/households/{id}/individuals", id=id),
            page=AsyncCursorPagination[Individual],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "is_primary": is_primary,
                        "limit": limit,
                    },
                    household_list_individuals_params.HouseholdListIndividualsParams,
                ),
            ),
            model=Individual,
        )


class HouseholdsResourceWithRawResponse:
    def __init__(self, households: HouseholdsResource) -> None:
        self._households = households

        self.create = to_raw_response_wrapper(
            households.create,
        )
        self.retrieve = to_raw_response_wrapper(
            households.retrieve,
        )
        self.update = to_raw_response_wrapper(
            households.update,
        )
        self.list = to_raw_response_wrapper(
            households.list,
        )
        self.delete = to_raw_response_wrapper(
            households.delete,
        )
        self.list_documents = to_raw_response_wrapper(
            households.list_documents,
        )
        self.list_entities = to_raw_response_wrapper(
            households.list_entities,
        )
        self.list_individuals = to_raw_response_wrapper(
            households.list_individuals,
        )


class AsyncHouseholdsResourceWithRawResponse:
    def __init__(self, households: AsyncHouseholdsResource) -> None:
        self._households = households

        self.create = async_to_raw_response_wrapper(
            households.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            households.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            households.update,
        )
        self.list = async_to_raw_response_wrapper(
            households.list,
        )
        self.delete = async_to_raw_response_wrapper(
            households.delete,
        )
        self.list_documents = async_to_raw_response_wrapper(
            households.list_documents,
        )
        self.list_entities = async_to_raw_response_wrapper(
            households.list_entities,
        )
        self.list_individuals = async_to_raw_response_wrapper(
            households.list_individuals,
        )


class HouseholdsResourceWithStreamingResponse:
    def __init__(self, households: HouseholdsResource) -> None:
        self._households = households

        self.create = to_streamed_response_wrapper(
            households.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            households.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            households.update,
        )
        self.list = to_streamed_response_wrapper(
            households.list,
        )
        self.delete = to_streamed_response_wrapper(
            households.delete,
        )
        self.list_documents = to_streamed_response_wrapper(
            households.list_documents,
        )
        self.list_entities = to_streamed_response_wrapper(
            households.list_entities,
        )
        self.list_individuals = to_streamed_response_wrapper(
            households.list_individuals,
        )


class AsyncHouseholdsResourceWithStreamingResponse:
    def __init__(self, households: AsyncHouseholdsResource) -> None:
        self._households = households

        self.create = async_to_streamed_response_wrapper(
            households.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            households.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            households.update,
        )
        self.list = async_to_streamed_response_wrapper(
            households.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            households.delete,
        )
        self.list_documents = async_to_streamed_response_wrapper(
            households.list_documents,
        )
        self.list_entities = async_to_streamed_response_wrapper(
            households.list_entities,
        )
        self.list_individuals = async_to_streamed_response_wrapper(
            households.list_individuals,
        )
