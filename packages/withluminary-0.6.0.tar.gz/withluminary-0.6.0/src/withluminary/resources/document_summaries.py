# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    DocumentSummaryFormat,
    DocumentSummaryEntryMode,
    document_summary_list_params,
    document_summary_update_params,
    document_summary_download_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    to_custom_raw_response_wrapper,
    async_to_streamed_response_wrapper,
    to_custom_streamed_response_wrapper,
    async_to_custom_raw_response_wrapper,
    async_to_custom_streamed_response_wrapper,
)
from ..pagination import SyncCursorPagination, AsyncCursorPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.document_summary import DocumentSummary
from ..types.document_summary_format import DocumentSummaryFormat
from ..types.document_summary_entry_mode import DocumentSummaryEntryMode

__all__ = ["DocumentSummariesResource", "AsyncDocumentSummariesResource"]


class DocumentSummariesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> DocumentSummariesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return DocumentSummariesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DocumentSummariesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return DocumentSummariesResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentSummary:
        """
        Retrieve a specific document summary

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/document-summaries/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentSummary,
        )

    def update(
        self,
        id: str,
        *,
        display_name: str | Omit = omit,
        entry_mode: DocumentSummaryEntryMode | Omit = omit,
        summary: str | Omit = omit,
        summary_format: DocumentSummaryFormat | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentSummary:
        """
        Update an existing document summary

        Args:
          display_name: Display name for the summary

          entry_mode: Indicates if the summary was AI-generated or user-entered

          summary: The summary text content

          summary_format: Format of the summary content

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            path_template("/document-summaries/{id}", id=id),
            body=maybe_transform(
                {
                    "display_name": display_name,
                    "entry_mode": entry_mode,
                    "summary": summary,
                    "summary_format": summary_format,
                },
                document_summary_update_params.DocumentSummaryUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentSummary,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        document_id: str | Omit = omit,
        household_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPagination[DocumentSummary]:
        """
        Retrieve a paginated list of document summaries using cursor-based pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          document_id: Filter summaries by document ID

          household_id: Filter summaries by household ID

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/document-summaries",
            page=SyncCursorPagination[DocumentSummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "document_id": document_id,
                        "household_id": household_id,
                        "limit": limit,
                    },
                    document_summary_list_params.DocumentSummaryListParams,
                ),
            ),
            model=DocumentSummary,
        )

    def download(
        self,
        id: str,
        *,
        format: Literal["pdf"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """
        Download the document summary content in the specified format

        Args:
          format: Output format for the download

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "application/pdf", **(extra_headers or {})}
        return self._get(
            path_template("/document-summaries/{id}/download", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"format": format}, document_summary_download_params.DocumentSummaryDownloadParams
                ),
            ),
            cast_to=BinaryAPIResponse,
        )


class AsyncDocumentSummariesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncDocumentSummariesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/withluminary/python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncDocumentSummariesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDocumentSummariesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/withluminary/python-sdk#with_streaming_response
        """
        return AsyncDocumentSummariesResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentSummary:
        """
        Retrieve a specific document summary

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/document-summaries/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentSummary,
        )

    async def update(
        self,
        id: str,
        *,
        display_name: str | Omit = omit,
        entry_mode: DocumentSummaryEntryMode | Omit = omit,
        summary: str | Omit = omit,
        summary_format: DocumentSummaryFormat | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentSummary:
        """
        Update an existing document summary

        Args:
          display_name: Display name for the summary

          entry_mode: Indicates if the summary was AI-generated or user-entered

          summary: The summary text content

          summary_format: Format of the summary content

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            path_template("/document-summaries/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "display_name": display_name,
                    "entry_mode": entry_mode,
                    "summary": summary,
                    "summary_format": summary_format,
                },
                document_summary_update_params.DocumentSummaryUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentSummary,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        document_id: str | Omit = omit,
        household_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[DocumentSummary, AsyncCursorPagination[DocumentSummary]]:
        """
        Retrieve a paginated list of document summaries using cursor-based pagination

        Args:
          after: Cursor for forward pagination. Returns items after this cursor.

          before: Cursor for backward pagination. Returns items before this cursor.

          document_id: Filter summaries by document ID

          household_id: Filter summaries by household ID

          limit: Maximum number of items to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/document-summaries",
            page=AsyncCursorPagination[DocumentSummary],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "document_id": document_id,
                        "household_id": household_id,
                        "limit": limit,
                    },
                    document_summary_list_params.DocumentSummaryListParams,
                ),
            ),
            model=DocumentSummary,
        )

    async def download(
        self,
        id: str,
        *,
        format: Literal["pdf"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """
        Download the document summary content in the specified format

        Args:
          format: Output format for the download

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "application/pdf", **(extra_headers or {})}
        return await self._get(
            path_template("/document-summaries/{id}/download", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"format": format}, document_summary_download_params.DocumentSummaryDownloadParams
                ),
            ),
            cast_to=AsyncBinaryAPIResponse,
        )


class DocumentSummariesResourceWithRawResponse:
    def __init__(self, document_summaries: DocumentSummariesResource) -> None:
        self._document_summaries = document_summaries

        self.retrieve = to_raw_response_wrapper(
            document_summaries.retrieve,
        )
        self.update = to_raw_response_wrapper(
            document_summaries.update,
        )
        self.list = to_raw_response_wrapper(
            document_summaries.list,
        )
        self.download = to_custom_raw_response_wrapper(
            document_summaries.download,
            BinaryAPIResponse,
        )


class AsyncDocumentSummariesResourceWithRawResponse:
    def __init__(self, document_summaries: AsyncDocumentSummariesResource) -> None:
        self._document_summaries = document_summaries

        self.retrieve = async_to_raw_response_wrapper(
            document_summaries.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            document_summaries.update,
        )
        self.list = async_to_raw_response_wrapper(
            document_summaries.list,
        )
        self.download = async_to_custom_raw_response_wrapper(
            document_summaries.download,
            AsyncBinaryAPIResponse,
        )


class DocumentSummariesResourceWithStreamingResponse:
    def __init__(self, document_summaries: DocumentSummariesResource) -> None:
        self._document_summaries = document_summaries

        self.retrieve = to_streamed_response_wrapper(
            document_summaries.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            document_summaries.update,
        )
        self.list = to_streamed_response_wrapper(
            document_summaries.list,
        )
        self.download = to_custom_streamed_response_wrapper(
            document_summaries.download,
            StreamedBinaryAPIResponse,
        )


class AsyncDocumentSummariesResourceWithStreamingResponse:
    def __init__(self, document_summaries: AsyncDocumentSummariesResource) -> None:
        self._document_summaries = document_summaries

        self.retrieve = async_to_streamed_response_wrapper(
            document_summaries.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            document_summaries.update,
        )
        self.list = async_to_streamed_response_wrapper(
            document_summaries.list,
        )
        self.download = async_to_custom_streamed_response_wrapper(
            document_summaries.download,
            AsyncStreamedBinaryAPIResponse,
        )
