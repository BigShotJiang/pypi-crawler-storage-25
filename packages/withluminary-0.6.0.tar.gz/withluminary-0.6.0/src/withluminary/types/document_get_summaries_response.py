# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .document_summary import DocumentSummary

__all__ = ["DocumentGetSummariesResponse"]


class DocumentGetSummariesResponse(BaseModel):
    data: List[DocumentSummary]
