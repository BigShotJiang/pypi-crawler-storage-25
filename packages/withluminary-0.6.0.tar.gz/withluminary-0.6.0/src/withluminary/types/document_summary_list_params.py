# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["DocumentSummaryListParams"]


class DocumentSummaryListParams(TypedDict, total=False):
    after: str
    """Cursor for forward pagination. Returns items after this cursor."""

    before: str
    """Cursor for backward pagination. Returns items before this cursor."""

    document_id: str
    """Filter summaries by document ID"""

    household_id: str
    """Filter summaries by household ID"""

    limit: int
    """Maximum number of items to return"""
