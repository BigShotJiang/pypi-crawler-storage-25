# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .page_info import PageInfo
from .individual import Individual

__all__ = ["IndividualList"]


class IndividualList(BaseModel):
    data: List[Individual]

    page_info: PageInfo

    total_count: int
    """Total number of items matching the query (across all pages)"""
