# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .entity import Entity
from .._models import BaseModel
from .page_info import PageInfo

__all__ = ["EntityList"]


class EntityList(BaseModel):
    data: List[Entity]

    page_info: PageInfo

    total_count: int
    """Total number of items matching the query (across all pages)"""
