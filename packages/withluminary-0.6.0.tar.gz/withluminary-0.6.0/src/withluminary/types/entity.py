# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel
from .entity_kind import EntityKind

__all__ = ["Entity"]


class Entity(BaseModel):
    id: str
    """Unique identifier with entity\\__ prefix"""

    created_at: datetime
    """Timestamp when the entity was created"""

    display_name: str
    """Display name of the entity"""

    household_id: str
    """Household ID this entity belongs to"""

    in_estate_status: Literal["in_estate", "out_of_estate", "none"]
    """Whether the entity is in or out of the estate"""

    kind: EntityKind
    """Type of entity - determines the specific subtype and applicable fields"""

    stage: Literal[
        "PRE_CREATED",
        "AI_CREATING",
        "AI_CREATION_FAILED",
        "AI_NEEDS_REVIEW",
        "DRAFT",
        "READY_FOR_PROPOSAL",
        "IMPLEMENTATION",
        "ACTIVE",
        "COMPLETED",
        "ARCHIVED",
    ]
    """Lifecycle stage of the entity"""

    updated_at: datetime
    """Timestamp when the entity was last updated"""
