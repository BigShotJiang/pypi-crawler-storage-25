# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .document import Document
from .page_info import PageInfo

__all__ = ["DocumentList"]


class DocumentList(BaseModel):
    data: List[Document]

    page_info: PageInfo

    total_count: int
    """Total number of items matching the query (across all pages)"""
