# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date, datetime

from ..._models import BaseModel

__all__ = ["Valuation", "DirectlyHeldAsset", "DirectlyHeldAssetAssetClass"]


class DirectlyHeldAssetAssetClass(BaseModel):
    id: str
    """Asset class ID"""

    display_name: str
    """Display name of the asset class"""


class DirectlyHeldAsset(BaseModel):
    id: str
    """Asset ID"""

    asset_class: DirectlyHeldAssetAssetClass

    display_name: str
    """Display name of the asset"""

    value: float
    """Value of this asset in USD"""

    external_id: Optional[str] = None
    """External ID from the static asset (if available)"""


class Valuation(BaseModel):
    id: str
    """Unique identifier with valuationv2\\__ prefix"""

    created_at: datetime
    """Timestamp when the valuation was created"""

    directly_held_asset_value: float
    """Total value of all directly held assets in USD"""

    directly_held_assets: List[DirectlyHeldAsset]
    """List of individual assets in this valuation"""

    effective_date: date
    """The date this valuation is effective"""

    entity_id: str
    """Entity ID this valuation belongs to"""

    total_value: float
    """Total value of all assets minus liabilities in USD"""

    updated_at: datetime
    """Timestamp when the valuation was last updated"""

    description: Optional[str] = None
    """Free-form notes about this valuation"""
