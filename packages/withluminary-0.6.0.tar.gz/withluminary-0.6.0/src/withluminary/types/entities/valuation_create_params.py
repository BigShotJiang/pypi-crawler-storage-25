# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ValuationCreateParams", "DirectlyHeldAsset"]


class ValuationCreateParams(TypedDict, total=False):
    directly_held_assets: Required[Iterable[DirectlyHeldAsset]]
    """List of assets to include in this valuation"""

    effective_date: Required[Annotated[Union[str, date], PropertyInfo(format="iso8601")]]
    """The date this valuation is effective"""

    description: Optional[str]
    """Free-form notes about this valuation"""


class DirectlyHeldAsset(TypedDict, total=False):
    asset_class_id: Required[str]
    """Asset class ID to associate with this asset"""

    display_name: Required[str]
    """Display name of the asset"""

    value: Required[float]
    """Value of this asset in USD"""

    external_id: Optional[str]
    """External ID for the asset"""
