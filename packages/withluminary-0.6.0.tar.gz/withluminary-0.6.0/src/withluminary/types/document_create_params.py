# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .._types import FileTypes
from .document_type import DocumentType

__all__ = ["DocumentCreateParams"]


class DocumentCreateParams(TypedDict, total=False):
    file: Required[FileTypes]
    """The document file to upload"""

    household_id: Required[str]
    """Household ID this document belongs to"""

    name: Required[str]
    """Display name of the document"""

    type: Required[DocumentType]
    """Type of document"""

    enable_ai_suggestions: bool
    """Whether this document should be used for AI suggestions"""

    entity_id: str
    """Entity ID if this document is owned by an entity"""

    individual_id: str
    """Individual ID if associated with an individual"""
