# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel
from .document_summary_format import DocumentSummaryFormat
from .document_summary_entry_mode import DocumentSummaryEntryMode

__all__ = ["DocumentSummary"]


class DocumentSummary(BaseModel):
    id: str
    """Unique identifier for the document summary"""

    created_at: datetime
    """Timestamp when the summary was created"""

    display_name: str
    """Display name for the summary"""

    document_id: str
    """ID of the document this summary belongs to"""

    household_id: str
    """ID of the household this summary belongs to"""

    summary: str
    """The summary text content"""

    updated_at: datetime
    """Timestamp when the summary was last updated"""

    entry_mode: Optional[DocumentSummaryEntryMode] = None
    """Indicates if the summary was AI-generated or user-entered"""

    summary_format: Optional[DocumentSummaryFormat] = None
    """Format of the summary content"""
