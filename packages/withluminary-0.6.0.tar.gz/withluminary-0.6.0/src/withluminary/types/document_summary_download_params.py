# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["DocumentSummaryDownloadParams"]


class DocumentSummaryDownloadParams(TypedDict, total=False):
    format: Literal["pdf"]
    """Output format for the download"""
