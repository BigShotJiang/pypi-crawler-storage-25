# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from .._models import BaseModel

__all__ = ["User"]


class User(BaseModel):
    id: str
    """Unique identifier with user\\__ prefix"""

    created_at: datetime
    """Timestamp when the user was created"""

    email: str
    """Email address of the user"""

    first_name: str
    """First name of the user"""

    last_name: str
    """Last name of the user"""

    updated_at: datetime
    """Timestamp when the user was last updated"""
