# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["HouseholdCreateParams", "PrimaryIndividual"]


class HouseholdCreateParams(TypedDict, total=False):
    primary_relationship_owner_id: Required[str]
    """User ID of the primary relationship owner"""

    notes: Optional[str]
    """Optional notes about the household"""

    primary_individuals: Iterable[PrimaryIndividual]
    """Primary client profiles to create for this household (at most 2)"""


class PrimaryIndividual(TypedDict, total=False):
    first_name: Required[str]
    """First name of the individual"""

    last_name: Required[str]
    """Last name of the individual"""

    state: Required[str]
    """State or province code (2 letter code)"""

    address_line1: Optional[str]
    """Street address line 1"""

    address_line2: Optional[str]
    """Street address line 2"""

    city: Optional[str]
    """City"""

    country: Optional[str]
    """Country"""

    date_of_birth: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Date of birth"""

    email: Optional[str]
    """Email address"""

    is_beneficiary: bool
    """
    Whether this client profile should be an eligible beneficiary for entities and
    gifts
    """

    is_deceased: bool
    """Whether the individual is deceased"""

    is_trustee: bool
    """Whether this client profile should be an eligible trustee for entities"""

    middle_name: Optional[str]
    """Middle name of the individual"""

    notes: Optional[str]
    """Notes about the client profile"""

    postal_code: Optional[str]
    """ZIP or postal code"""

    suffix: Optional[str]
    """Name suffix"""
