# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

from .document_type import DocumentType

__all__ = ["DocumentUpdateParams"]


class DocumentUpdateParams(TypedDict, total=False):
    enable_ai_suggestions: bool
    """Whether this document should be used for AI suggestions"""

    entity_id: Optional[str]
    """Entity ID if this document is owned by an entity"""

    individual_id: Optional[str]
    """Individual ID if associated with an individual"""

    name: str
    """Display name of the document"""

    type: DocumentType
    """Type of document"""
