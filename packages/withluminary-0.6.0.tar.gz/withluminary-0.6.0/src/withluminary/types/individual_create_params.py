# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["IndividualCreateParams"]


class IndividualCreateParams(TypedDict, total=False):
    first_name: Required[str]
    """First name of the individual"""

    household_id: Required[str]
    """Household ID this individual belongs to"""

    last_name: Required[str]
    """Last name of the individual"""

    address_line1: Optional[str]
    """Street address line 1"""

    address_line2: Optional[str]
    """Street address line 2"""

    city: Optional[str]
    """City"""

    country: Optional[str]
    """Country"""

    date_of_birth: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Date of birth"""

    email: Optional[str]
    """Email address"""

    is_beneficiary: bool
    """
    Whether this client profile should be an eligible beneficiary for entities and
    gifts
    """

    is_deceased: bool
    """Whether the individual is deceased"""

    is_grantor: bool
    """
    Whether this client profile should be an eligible grantor/owner/other principal
    for entities
    """

    is_primary: bool
    """Whether this is a primary client of the household (at most 2 per household)"""

    is_trustee: bool
    """Whether this client profile should be an eligible trustee for entities"""

    middle_name: Optional[str]
    """Middle name of the individual"""

    notes: Optional[str]
    """Notes about the client profile"""

    postal_code: Optional[str]
    """ZIP or postal code"""

    state: Optional[str]
    """State or province code (2 letter code)"""

    suffix: Optional[str]
    """Name suffix"""
