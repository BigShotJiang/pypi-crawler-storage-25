# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import date, datetime

from .._models import BaseModel

__all__ = ["Individual"]


class Individual(BaseModel):
    id: str
    """Unique identifier with client*profile* prefix"""

    created_at: datetime
    """Timestamp when the individual was created"""

    first_name: str
    """First name of the individual"""

    household_id: str
    """Household ID this individual belongs to"""

    is_beneficiary: bool
    """
    Whether this client profile should be an eligible beneficiary for entities and
    gifts
    """

    is_deceased: bool
    """Whether this client profile is deceased"""

    is_grantor: bool
    """
    Whether this client profile should be an eligible grantor/owner/other principal
    for entities
    """

    is_primary: bool
    """Whether this is one of the (at most) two primary clients on this household"""

    is_trustee: bool
    """Whether this client profile should be an eligible trustee for entities"""

    last_name: str
    """Last name of the individual"""

    updated_at: datetime
    """Timestamp when the individual was last updated"""

    address_line1: Optional[str] = None
    """Street address line 1 (from address edge)"""

    address_line2: Optional[str] = None
    """Street address line 2 (from address edge)"""

    city: Optional[str] = None
    """City (from address edge)"""

    country: Optional[str] = None
    """Country (from address edge)"""

    date_of_birth: Optional[date] = None
    """Date of birth (encrypted field)"""

    date_of_death: Optional[date] = None
    """Date of death if applicable (encrypted field)"""

    deleted_at: Optional[datetime] = None
    """Timestamp when the individual was soft deleted"""

    email: Optional[str] = None
    """Email address"""

    middle_name: Optional[str] = None
    """Middle name of the individual"""

    notes: Optional[str] = None
    """Notes about the client profile"""

    postal_code: Optional[str] = None
    """ZIP or postal code (from address edge)"""

    state: Optional[str] = None
    """State or province (from address edge)"""

    suffix: Optional[str] = None
    """Name suffix (Jr., Sr., III, etc.)"""
