# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

from .document_type import DocumentType

__all__ = ["HouseholdListDocumentsParams"]


class HouseholdListDocumentsParams(TypedDict, total=False):
    after: str
    """Cursor for forward pagination. Returns items after this cursor."""

    before: str
    """Cursor for backward pagination. Returns items before this cursor."""

    limit: int
    """Maximum number of items to return"""

    type: DocumentType
    """Filter by document type"""
