# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

from .document_summary_format import DocumentSummaryFormat
from .document_summary_entry_mode import DocumentSummaryEntryMode

__all__ = ["DocumentSummaryUpdateParams"]


class DocumentSummaryUpdateParams(TypedDict, total=False):
    display_name: str
    """Display name for the summary"""

    entry_mode: DocumentSummaryEntryMode
    """Indicates if the summary was AI-generated or user-entered"""

    summary: str
    """The summary text content"""

    summary_format: DocumentSummaryFormat
    """Format of the summary content"""
