# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel
from .document_type import DocumentType

__all__ = ["Document"]


class Document(BaseModel):
    id: str
    """Unique identifier with document\\__ prefix"""

    created_at: datetime
    """Timestamp when the document was created"""

    household_id: str
    """Household ID this document belongs to"""

    name: str
    """Display name of the document"""

    type: DocumentType
    """Type of document"""

    updated_at: datetime
    """Timestamp when the document was last updated"""

    enable_ai_suggestions: Optional[bool] = None
    """Whether this document should be used for AI suggestions"""

    entity_id: Optional[str] = None
    """Entity ID if this document is owned by an entity"""

    individual_id: Optional[str] = None
    """Individual ID if this document is associated with an individual"""
