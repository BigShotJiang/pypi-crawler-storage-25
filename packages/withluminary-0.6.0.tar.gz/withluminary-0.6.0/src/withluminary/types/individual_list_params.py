# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["IndividualListParams"]


class IndividualListParams(TypedDict, total=False):
    after: str
    """Cursor for forward pagination. Returns items after this cursor."""

    before: str
    """Cursor for backward pagination. Returns items before this cursor."""

    household_id: str
    """Filter individuals by household ID"""

    is_primary: bool
    """Filter by primary client status"""

    limit: int
    """Maximum number of items to return"""
