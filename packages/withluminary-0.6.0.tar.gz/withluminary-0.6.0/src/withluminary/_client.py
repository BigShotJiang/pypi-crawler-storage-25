# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Mapping
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import (
    is_given,
    is_mapping_t,
    get_async_library,
)
from ._compat import cached_property
from ._models import SecurityOptions
from ._oauth2 import OAuth2ClientCredentials, make_oauth2
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import LuminaryError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import users, entities, documents, households, individuals, document_summaries
    from .resources.users import UsersResource, AsyncUsersResource
    from .resources.documents import DocumentsResource, AsyncDocumentsResource
    from .resources.households import HouseholdsResource, AsyncHouseholdsResource
    from .resources.individuals import IndividualsResource, AsyncIndividualsResource
    from .resources.entities.entities import EntitiesResource, AsyncEntitiesResource
    from .resources.document_summaries import DocumentSummariesResource, AsyncDocumentSummariesResource

__all__ = [
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "Luminary",
    "AsyncLuminary",
    "Client",
    "AsyncClient",
]


class Luminary(SyncAPIClient):
    # client options
    client_id: str
    client_secret: str
    subdomain: str

    def __init__(
        self,
        *,
        client_id: str | None = None,
        client_secret: str | None = None,
        subdomain: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Luminary client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `client_id` from `CLIENT_ID`
        - `client_secret` from `CLIENT_SECRET`
        - `subdomain` from `WITHLUMINARY_SUBDOMAIN`
        """
        if client_id is None:
            client_id = os.environ.get("CLIENT_ID")
        if client_id is None:
            raise LuminaryError(
                "The client_id client option must be set either by passing client_id to the client or by setting the CLIENT_ID environment variable"
            )
        self.client_id = client_id

        if client_secret is None:
            client_secret = os.environ.get("CLIENT_SECRET")
        if client_secret is None:
            raise LuminaryError(
                "The client_secret client option must be set either by passing client_secret to the client or by setting the CLIENT_SECRET environment variable"
            )
        self.client_secret = client_secret

        if subdomain is None:
            subdomain = os.environ.get("WITHLUMINARY_SUBDOMAIN") or "lum"
        self.subdomain = subdomain

        if base_url is None:
            base_url = os.environ.get("LUMINARY_BASE_URL")
        if base_url is None:
            base_url = f"https://{subdomain}.withluminary.com/api/public/v1"

        custom_headers_env = os.environ.get("LUMINARY_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def document_summaries(self) -> DocumentSummariesResource:
        from .resources.document_summaries import DocumentSummariesResource

        return DocumentSummariesResource(self)

    @cached_property
    def documents(self) -> DocumentsResource:
        from .resources.documents import DocumentsResource

        return DocumentsResource(self)

    @cached_property
    def entities(self) -> EntitiesResource:
        from .resources.entities import EntitiesResource

        return EntitiesResource(self)

    @cached_property
    def households(self) -> HouseholdsResource:
        from .resources.households import HouseholdsResource

        return HouseholdsResource(self)

    @cached_property
    def individuals(self) -> IndividualsResource:
        from .resources.individuals import IndividualsResource

        return IndividualsResource(self)

    @cached_property
    def users(self) -> UsersResource:
        from .resources.users import UsersResource

        return UsersResource(self)

    @cached_property
    def with_raw_response(self) -> LuminaryWithRawResponse:
        return LuminaryWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LuminaryWithStreamedResponse:
        return LuminaryWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _custom_auth(self, security: SecurityOptions) -> httpx.Auth | None:
        if security.get("oauth2", False) and self._oauth2 is not None:
            return self._oauth2
        return None

    @property
    def _oauth2(self) -> httpx.Auth | None:
        if self.client_id and self.client_secret:
            return make_oauth2(
                client_id=self.client_id,
                client_secret=self.client_secret,
                token_url=self._prepare_url("https://auth.withluminary.com/oauth2/token"),
                header="Authorization",
            )
        return None

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    @override
    def _should_retry(self, response: httpx.Response) -> bool:
        # Retry on 401 if we are using OAuth2 and the token might be expired
        if response.status_code == 401 and isinstance(self.custom_auth, OAuth2ClientCredentials):
            if self.custom_auth.token_is_expired():
                self.custom_auth.invalidate_token()
                return True
        return super()._should_retry(response)

    def copy(
        self,
        *,
        client_id: str | None = None,
        client_secret: str | None = None,
        subdomain: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            client_id=client_id or self.client_id,
            client_secret=client_secret or self.client_secret,
            subdomain=subdomain or self.subdomain,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncLuminary(AsyncAPIClient):
    # client options
    client_id: str
    client_secret: str
    subdomain: str

    def __init__(
        self,
        *,
        client_id: str | None = None,
        client_secret: str | None = None,
        subdomain: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncLuminary client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `client_id` from `CLIENT_ID`
        - `client_secret` from `CLIENT_SECRET`
        - `subdomain` from `WITHLUMINARY_SUBDOMAIN`
        """
        if client_id is None:
            client_id = os.environ.get("CLIENT_ID")
        if client_id is None:
            raise LuminaryError(
                "The client_id client option must be set either by passing client_id to the client or by setting the CLIENT_ID environment variable"
            )
        self.client_id = client_id

        if client_secret is None:
            client_secret = os.environ.get("CLIENT_SECRET")
        if client_secret is None:
            raise LuminaryError(
                "The client_secret client option must be set either by passing client_secret to the client or by setting the CLIENT_SECRET environment variable"
            )
        self.client_secret = client_secret

        if subdomain is None:
            subdomain = os.environ.get("WITHLUMINARY_SUBDOMAIN") or "lum"
        self.subdomain = subdomain

        if base_url is None:
            base_url = os.environ.get("LUMINARY_BASE_URL")
        if base_url is None:
            base_url = f"https://{subdomain}.withluminary.com/api/public/v1"

        custom_headers_env = os.environ.get("LUMINARY_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def document_summaries(self) -> AsyncDocumentSummariesResource:
        from .resources.document_summaries import AsyncDocumentSummariesResource

        return AsyncDocumentSummariesResource(self)

    @cached_property
    def documents(self) -> AsyncDocumentsResource:
        from .resources.documents import AsyncDocumentsResource

        return AsyncDocumentsResource(self)

    @cached_property
    def entities(self) -> AsyncEntitiesResource:
        from .resources.entities import AsyncEntitiesResource

        return AsyncEntitiesResource(self)

    @cached_property
    def households(self) -> AsyncHouseholdsResource:
        from .resources.households import AsyncHouseholdsResource

        return AsyncHouseholdsResource(self)

    @cached_property
    def individuals(self) -> AsyncIndividualsResource:
        from .resources.individuals import AsyncIndividualsResource

        return AsyncIndividualsResource(self)

    @cached_property
    def users(self) -> AsyncUsersResource:
        from .resources.users import AsyncUsersResource

        return AsyncUsersResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncLuminaryWithRawResponse:
        return AsyncLuminaryWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLuminaryWithStreamedResponse:
        return AsyncLuminaryWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _custom_auth(self, security: SecurityOptions) -> httpx.Auth | None:
        if security.get("oauth2", False) and self._oauth2 is not None:
            return self._oauth2
        return None

    @property
    def _oauth2(self) -> httpx.Auth | None:
        if self.client_id and self.client_secret:
            return make_oauth2(
                client_id=self.client_id,
                client_secret=self.client_secret,
                token_url=self._prepare_url("https://auth.withluminary.com/oauth2/token"),
                header="Authorization",
            )
        return None

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    @override
    def _should_retry(self, response: httpx.Response) -> bool:
        # Retry on 401 if we are using OAuth2 and the token might be expired
        if response.status_code == 401 and isinstance(self.custom_auth, OAuth2ClientCredentials):
            if self.custom_auth.token_is_expired():
                self.custom_auth.invalidate_token()
                return True
        return super()._should_retry(response)

    def copy(
        self,
        *,
        client_id: str | None = None,
        client_secret: str | None = None,
        subdomain: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            client_id=client_id or self.client_id,
            client_secret=client_secret or self.client_secret,
            subdomain=subdomain or self.subdomain,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class LuminaryWithRawResponse:
    _client: Luminary

    def __init__(self, client: Luminary) -> None:
        self._client = client

    @cached_property
    def document_summaries(self) -> document_summaries.DocumentSummariesResourceWithRawResponse:
        from .resources.document_summaries import DocumentSummariesResourceWithRawResponse

        return DocumentSummariesResourceWithRawResponse(self._client.document_summaries)

    @cached_property
    def documents(self) -> documents.DocumentsResourceWithRawResponse:
        from .resources.documents import DocumentsResourceWithRawResponse

        return DocumentsResourceWithRawResponse(self._client.documents)

    @cached_property
    def entities(self) -> entities.EntitiesResourceWithRawResponse:
        from .resources.entities import EntitiesResourceWithRawResponse

        return EntitiesResourceWithRawResponse(self._client.entities)

    @cached_property
    def households(self) -> households.HouseholdsResourceWithRawResponse:
        from .resources.households import HouseholdsResourceWithRawResponse

        return HouseholdsResourceWithRawResponse(self._client.households)

    @cached_property
    def individuals(self) -> individuals.IndividualsResourceWithRawResponse:
        from .resources.individuals import IndividualsResourceWithRawResponse

        return IndividualsResourceWithRawResponse(self._client.individuals)

    @cached_property
    def users(self) -> users.UsersResourceWithRawResponse:
        from .resources.users import UsersResourceWithRawResponse

        return UsersResourceWithRawResponse(self._client.users)


class AsyncLuminaryWithRawResponse:
    _client: AsyncLuminary

    def __init__(self, client: AsyncLuminary) -> None:
        self._client = client

    @cached_property
    def document_summaries(self) -> document_summaries.AsyncDocumentSummariesResourceWithRawResponse:
        from .resources.document_summaries import AsyncDocumentSummariesResourceWithRawResponse

        return AsyncDocumentSummariesResourceWithRawResponse(self._client.document_summaries)

    @cached_property
    def documents(self) -> documents.AsyncDocumentsResourceWithRawResponse:
        from .resources.documents import AsyncDocumentsResourceWithRawResponse

        return AsyncDocumentsResourceWithRawResponse(self._client.documents)

    @cached_property
    def entities(self) -> entities.AsyncEntitiesResourceWithRawResponse:
        from .resources.entities import AsyncEntitiesResourceWithRawResponse

        return AsyncEntitiesResourceWithRawResponse(self._client.entities)

    @cached_property
    def households(self) -> households.AsyncHouseholdsResourceWithRawResponse:
        from .resources.households import AsyncHouseholdsResourceWithRawResponse

        return AsyncHouseholdsResourceWithRawResponse(self._client.households)

    @cached_property
    def individuals(self) -> individuals.AsyncIndividualsResourceWithRawResponse:
        from .resources.individuals import AsyncIndividualsResourceWithRawResponse

        return AsyncIndividualsResourceWithRawResponse(self._client.individuals)

    @cached_property
    def users(self) -> users.AsyncUsersResourceWithRawResponse:
        from .resources.users import AsyncUsersResourceWithRawResponse

        return AsyncUsersResourceWithRawResponse(self._client.users)


class LuminaryWithStreamedResponse:
    _client: Luminary

    def __init__(self, client: Luminary) -> None:
        self._client = client

    @cached_property
    def document_summaries(self) -> document_summaries.DocumentSummariesResourceWithStreamingResponse:
        from .resources.document_summaries import DocumentSummariesResourceWithStreamingResponse

        return DocumentSummariesResourceWithStreamingResponse(self._client.document_summaries)

    @cached_property
    def documents(self) -> documents.DocumentsResourceWithStreamingResponse:
        from .resources.documents import DocumentsResourceWithStreamingResponse

        return DocumentsResourceWithStreamingResponse(self._client.documents)

    @cached_property
    def entities(self) -> entities.EntitiesResourceWithStreamingResponse:
        from .resources.entities import EntitiesResourceWithStreamingResponse

        return EntitiesResourceWithStreamingResponse(self._client.entities)

    @cached_property
    def households(self) -> households.HouseholdsResourceWithStreamingResponse:
        from .resources.households import HouseholdsResourceWithStreamingResponse

        return HouseholdsResourceWithStreamingResponse(self._client.households)

    @cached_property
    def individuals(self) -> individuals.IndividualsResourceWithStreamingResponse:
        from .resources.individuals import IndividualsResourceWithStreamingResponse

        return IndividualsResourceWithStreamingResponse(self._client.individuals)

    @cached_property
    def users(self) -> users.UsersResourceWithStreamingResponse:
        from .resources.users import UsersResourceWithStreamingResponse

        return UsersResourceWithStreamingResponse(self._client.users)


class AsyncLuminaryWithStreamedResponse:
    _client: AsyncLuminary

    def __init__(self, client: AsyncLuminary) -> None:
        self._client = client

    @cached_property
    def document_summaries(self) -> document_summaries.AsyncDocumentSummariesResourceWithStreamingResponse:
        from .resources.document_summaries import AsyncDocumentSummariesResourceWithStreamingResponse

        return AsyncDocumentSummariesResourceWithStreamingResponse(self._client.document_summaries)

    @cached_property
    def documents(self) -> documents.AsyncDocumentsResourceWithStreamingResponse:
        from .resources.documents import AsyncDocumentsResourceWithStreamingResponse

        return AsyncDocumentsResourceWithStreamingResponse(self._client.documents)

    @cached_property
    def entities(self) -> entities.AsyncEntitiesResourceWithStreamingResponse:
        from .resources.entities import AsyncEntitiesResourceWithStreamingResponse

        return AsyncEntitiesResourceWithStreamingResponse(self._client.entities)

    @cached_property
    def households(self) -> households.AsyncHouseholdsResourceWithStreamingResponse:
        from .resources.households import AsyncHouseholdsResourceWithStreamingResponse

        return AsyncHouseholdsResourceWithStreamingResponse(self._client.households)

    @cached_property
    def individuals(self) -> individuals.AsyncIndividualsResourceWithStreamingResponse:
        from .resources.individuals import AsyncIndividualsResourceWithStreamingResponse

        return AsyncIndividualsResourceWithStreamingResponse(self._client.individuals)

    @cached_property
    def users(self) -> users.AsyncUsersResourceWithStreamingResponse:
        from .resources.users import AsyncUsersResourceWithStreamingResponse

        return AsyncUsersResourceWithStreamingResponse(self._client.users)


Client = Luminary

AsyncClient = AsyncLuminary
