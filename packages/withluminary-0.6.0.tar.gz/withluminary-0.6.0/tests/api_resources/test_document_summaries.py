# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from tests.utils import assert_matches_type
from withluminary import Luminary, AsyncLuminary
from withluminary.types import (
    DocumentSummary,
)
from withluminary._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)
from withluminary.pagination import SyncCursorPagination, AsyncCursorPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDocumentSummaries:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Luminary) -> None:
        document_summary = client.document_summaries.retrieve(
            "id",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Luminary) -> None:
        response = client.document_summaries.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = response.parse()
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Luminary) -> None:
        with client.document_summaries.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = response.parse()
            assert_matches_type(DocumentSummary, document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.document_summaries.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Luminary) -> None:
        document_summary = client.document_summaries.update(
            id="id",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Luminary) -> None:
        document_summary = client.document_summaries.update(
            id="id",
            display_name="x",
            entry_mode="AI_AUTO",
            summary="summary",
            summary_format="MARKDOWN",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Luminary) -> None:
        response = client.document_summaries.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = response.parse()
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Luminary) -> None:
        with client.document_summaries.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = response.parse()
            assert_matches_type(DocumentSummary, document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.document_summaries.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Luminary) -> None:
        document_summary = client.document_summaries.list()
        assert_matches_type(SyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Luminary) -> None:
        document_summary = client.document_summaries.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            document_id="document_id",
            household_id="household_id",
            limit=1,
        )
        assert_matches_type(SyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Luminary) -> None:
        response = client.document_summaries.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = response.parse()
        assert_matches_type(SyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Luminary) -> None:
        with client.document_summaries.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = response.parse()
            assert_matches_type(SyncCursorPagination[DocumentSummary], document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_download(self, client: Luminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document_summary = client.document_summaries.download(
            id="id",
        )
        assert document_summary.is_closed
        assert document_summary.json() == {"foo": "bar"}
        assert cast(Any, document_summary.is_closed) is True
        assert isinstance(document_summary, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_download_with_all_params(self, client: Luminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document_summary = client.document_summaries.download(
            id="id",
            format="pdf",
        )
        assert document_summary.is_closed
        assert document_summary.json() == {"foo": "bar"}
        assert cast(Any, document_summary.is_closed) is True
        assert isinstance(document_summary, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_download(self, client: Luminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        document_summary = client.document_summaries.with_raw_response.download(
            id="id",
        )

        assert document_summary.is_closed is True
        assert document_summary.http_request.headers.get("X-Stainless-Lang") == "python"
        assert document_summary.json() == {"foo": "bar"}
        assert isinstance(document_summary, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_download(self, client: Luminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.document_summaries.with_streaming_response.download(
            id="id",
        ) as document_summary:
            assert not document_summary.is_closed
            assert document_summary.http_request.headers.get("X-Stainless-Lang") == "python"

            assert document_summary.json() == {"foo": "bar"}
            assert cast(Any, document_summary.is_closed) is True
            assert isinstance(document_summary, StreamedBinaryAPIResponse)

        assert cast(Any, document_summary.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_path_params_download(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.document_summaries.with_raw_response.download(
                id="",
            )


class TestAsyncDocumentSummaries:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLuminary) -> None:
        document_summary = await async_client.document_summaries.retrieve(
            "id",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLuminary) -> None:
        response = await async_client.document_summaries.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = await response.parse()
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLuminary) -> None:
        async with async_client.document_summaries.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = await response.parse()
            assert_matches_type(DocumentSummary, document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.document_summaries.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLuminary) -> None:
        document_summary = await async_client.document_summaries.update(
            id="id",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLuminary) -> None:
        document_summary = await async_client.document_summaries.update(
            id="id",
            display_name="x",
            entry_mode="AI_AUTO",
            summary="summary",
            summary_format="MARKDOWN",
        )
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLuminary) -> None:
        response = await async_client.document_summaries.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = await response.parse()
        assert_matches_type(DocumentSummary, document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLuminary) -> None:
        async with async_client.document_summaries.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = await response.parse()
            assert_matches_type(DocumentSummary, document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.document_summaries.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLuminary) -> None:
        document_summary = await async_client.document_summaries.list()
        assert_matches_type(AsyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLuminary) -> None:
        document_summary = await async_client.document_summaries.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            document_id="document_id",
            household_id="household_id",
            limit=1,
        )
        assert_matches_type(AsyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLuminary) -> None:
        response = await async_client.document_summaries.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document_summary = await response.parse()
        assert_matches_type(AsyncCursorPagination[DocumentSummary], document_summary, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLuminary) -> None:
        async with async_client.document_summaries.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document_summary = await response.parse()
            assert_matches_type(AsyncCursorPagination[DocumentSummary], document_summary, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_download(self, async_client: AsyncLuminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document_summary = await async_client.document_summaries.download(
            id="id",
        )
        assert document_summary.is_closed
        assert await document_summary.json() == {"foo": "bar"}
        assert cast(Any, document_summary.is_closed) is True
        assert isinstance(document_summary, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_download_with_all_params(self, async_client: AsyncLuminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document_summary = await async_client.document_summaries.download(
            id="id",
            format="pdf",
        )
        assert document_summary.is_closed
        assert await document_summary.json() == {"foo": "bar"}
        assert cast(Any, document_summary.is_closed) is True
        assert isinstance(document_summary, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_download(self, async_client: AsyncLuminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        document_summary = await async_client.document_summaries.with_raw_response.download(
            id="id",
        )

        assert document_summary.is_closed is True
        assert document_summary.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await document_summary.json() == {"foo": "bar"}
        assert isinstance(document_summary, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_download(self, async_client: AsyncLuminary, respx_mock: MockRouter) -> None:
        respx_mock.get("/document-summaries/id/download").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.document_summaries.with_streaming_response.download(
            id="id",
        ) as document_summary:
            assert not document_summary.is_closed
            assert document_summary.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await document_summary.json() == {"foo": "bar"}
            assert cast(Any, document_summary.is_closed) is True
            assert isinstance(document_summary, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, document_summary.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_path_params_download(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.document_summaries.with_raw_response.download(
                id="",
            )
