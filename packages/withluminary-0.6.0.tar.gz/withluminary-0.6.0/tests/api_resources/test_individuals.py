# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from withluminary import Luminary, AsyncLuminary
from withluminary.types import Individual
from withluminary._utils import parse_date
from withluminary.pagination import SyncCursorPagination, AsyncCursorPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestIndividuals:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Luminary) -> None:
        individual = client.individuals.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Luminary) -> None:
        individual = client.individuals.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
            address_line1="x",
            address_line2="x",
            city="x",
            country="x",
            date_of_birth=parse_date("2019-12-27"),
            email="dev@stainless.com",
            is_beneficiary=True,
            is_deceased=True,
            is_grantor=True,
            is_primary=True,
            is_trustee=True,
            middle_name="x",
            notes="notes",
            postal_code="x",
            state="xx",
            suffix="x",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Luminary) -> None:
        response = client.individuals.with_raw_response.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Luminary) -> None:
        with client.individuals.with_streaming_response.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Luminary) -> None:
        individual = client.individuals.retrieve(
            "id",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Luminary) -> None:
        response = client.individuals.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Luminary) -> None:
        with client.individuals.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.individuals.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Luminary) -> None:
        individual = client.individuals.update(
            id="id",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Luminary) -> None:
        individual = client.individuals.update(
            id="id",
            address_line1="x",
            address_line2="x",
            city="x",
            country="x",
            date_of_birth=parse_date("2019-12-27"),
            date_of_death=parse_date("2019-12-27"),
            email="dev@stainless.com",
            first_name="x",
            is_beneficiary=True,
            is_deceased=True,
            is_grantor=True,
            is_primary=True,
            is_trustee=True,
            last_name="x",
            middle_name="x",
            notes="notes",
            postal_code="x",
            state="xx",
            suffix="x",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Luminary) -> None:
        response = client.individuals.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Luminary) -> None:
        with client.individuals.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.individuals.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Luminary) -> None:
        individual = client.individuals.list()
        assert_matches_type(SyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Luminary) -> None:
        individual = client.individuals.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            household_id="household_id",
            is_primary=True,
            limit=1,
        )
        assert_matches_type(SyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Luminary) -> None:
        response = client.individuals.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = response.parse()
        assert_matches_type(SyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Luminary) -> None:
        with client.individuals.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = response.parse()
            assert_matches_type(SyncCursorPagination[Individual], individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Luminary) -> None:
        individual = client.individuals.delete(
            "id",
        )
        assert individual is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Luminary) -> None:
        response = client.individuals.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = response.parse()
        assert individual is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Luminary) -> None:
        with client.individuals.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = response.parse()
            assert individual is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.individuals.with_raw_response.delete(
                "",
            )


class TestAsyncIndividuals:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
            address_line1="x",
            address_line2="x",
            city="x",
            country="x",
            date_of_birth=parse_date("2019-12-27"),
            email="dev@stainless.com",
            is_beneficiary=True,
            is_deceased=True,
            is_grantor=True,
            is_primary=True,
            is_trustee=True,
            middle_name="x",
            notes="notes",
            postal_code="x",
            state="xx",
            suffix="x",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLuminary) -> None:
        response = await async_client.individuals.with_raw_response.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = await response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLuminary) -> None:
        async with async_client.individuals.with_streaming_response.create(
            first_name="John",
            household_id="household_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            last_name="Smith",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = await response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.retrieve(
            "id",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLuminary) -> None:
        response = await async_client.individuals.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = await response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLuminary) -> None:
        async with async_client.individuals.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = await response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.individuals.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.update(
            id="id",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.update(
            id="id",
            address_line1="x",
            address_line2="x",
            city="x",
            country="x",
            date_of_birth=parse_date("2019-12-27"),
            date_of_death=parse_date("2019-12-27"),
            email="dev@stainless.com",
            first_name="x",
            is_beneficiary=True,
            is_deceased=True,
            is_grantor=True,
            is_primary=True,
            is_trustee=True,
            last_name="x",
            middle_name="x",
            notes="notes",
            postal_code="x",
            state="xx",
            suffix="x",
        )
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLuminary) -> None:
        response = await async_client.individuals.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = await response.parse()
        assert_matches_type(Individual, individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLuminary) -> None:
        async with async_client.individuals.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = await response.parse()
            assert_matches_type(Individual, individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.individuals.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.list()
        assert_matches_type(AsyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            household_id="household_id",
            is_primary=True,
            limit=1,
        )
        assert_matches_type(AsyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLuminary) -> None:
        response = await async_client.individuals.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = await response.parse()
        assert_matches_type(AsyncCursorPagination[Individual], individual, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLuminary) -> None:
        async with async_client.individuals.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = await response.parse()
            assert_matches_type(AsyncCursorPagination[Individual], individual, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncLuminary) -> None:
        individual = await async_client.individuals.delete(
            "id",
        )
        assert individual is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncLuminary) -> None:
        response = await async_client.individuals.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        individual = await response.parse()
        assert individual is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncLuminary) -> None:
        async with async_client.individuals.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            individual = await response.parse()
            assert individual is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.individuals.with_raw_response.delete(
                "",
            )
