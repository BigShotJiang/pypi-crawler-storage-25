# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from withluminary import Luminary, AsyncLuminary
from withluminary._utils import parse_date
from withluminary.types.entities import Valuation

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestValuation:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Luminary) -> None:
        valuation = client.entities.valuation.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Luminary) -> None:
        valuation = client.entities.valuation.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                    "external_id": "AAPL-12345",
                }
            ],
            effective_date=parse_date("2024-01-15"),
            description="description",
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Luminary) -> None:
        response = client.entities.valuation.with_raw_response.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        valuation = response.parse()
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Luminary) -> None:
        with client.entities.valuation.with_streaming_response.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            valuation = response.parse()
            assert_matches_type(Valuation, valuation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_create(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.entities.valuation.with_raw_response.create(
                id="",
                directly_held_assets=[
                    {
                        "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                        "display_name": "Apple Inc. Stock",
                        "value": 50000,
                    }
                ],
                effective_date=parse_date("2024-01-15"),
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Luminary) -> None:
        valuation = client.entities.valuation.retrieve(
            "id",
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Luminary) -> None:
        response = client.entities.valuation.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        valuation = response.parse()
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Luminary) -> None:
        with client.entities.valuation.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            valuation = response.parse()
            assert_matches_type(Valuation, valuation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.entities.valuation.with_raw_response.retrieve(
                "",
            )


class TestAsyncValuation:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLuminary) -> None:
        valuation = await async_client.entities.valuation.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLuminary) -> None:
        valuation = await async_client.entities.valuation.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                    "external_id": "AAPL-12345",
                }
            ],
            effective_date=parse_date("2024-01-15"),
            description="description",
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLuminary) -> None:
        response = await async_client.entities.valuation.with_raw_response.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        valuation = await response.parse()
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLuminary) -> None:
        async with async_client.entities.valuation.with_streaming_response.create(
            id="id",
            directly_held_assets=[
                {
                    "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "display_name": "Apple Inc. Stock",
                    "value": 50000,
                }
            ],
            effective_date=parse_date("2024-01-15"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            valuation = await response.parse()
            assert_matches_type(Valuation, valuation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.entities.valuation.with_raw_response.create(
                id="",
                directly_held_assets=[
                    {
                        "asset_class_id": "asset_class_01ARZ3NDEKTSV4RRFFQ69G5FAV",
                        "display_name": "Apple Inc. Stock",
                        "value": 50000,
                    }
                ],
                effective_date=parse_date("2024-01-15"),
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLuminary) -> None:
        valuation = await async_client.entities.valuation.retrieve(
            "id",
        )
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLuminary) -> None:
        response = await async_client.entities.valuation.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        valuation = await response.parse()
        assert_matches_type(Valuation, valuation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLuminary) -> None:
        async with async_client.entities.valuation.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            valuation = await response.parse()
            assert_matches_type(Valuation, valuation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.entities.valuation.with_raw_response.retrieve(
                "",
            )
