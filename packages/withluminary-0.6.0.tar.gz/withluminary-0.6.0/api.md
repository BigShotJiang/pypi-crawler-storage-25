# DocumentSummaries

Types:

```python
from withluminary.types import (
    DocumentSummary,
    DocumentSummaryEntryMode,
    DocumentSummaryFormat,
    PageInfo,
)
```

Methods:

- <code title="get /document-summaries/{id}">client.document_summaries.<a href="./src/withluminary/resources/document_summaries.py">retrieve</a>(id) -> <a href="./src/withluminary/types/document_summary.py">DocumentSummary</a></code>
- <code title="put /document-summaries/{id}">client.document_summaries.<a href="./src/withluminary/resources/document_summaries.py">update</a>(id, \*\*<a href="src/withluminary/types/document_summary_update_params.py">params</a>) -> <a href="./src/withluminary/types/document_summary.py">DocumentSummary</a></code>
- <code title="get /document-summaries">client.document_summaries.<a href="./src/withluminary/resources/document_summaries.py">list</a>(\*\*<a href="src/withluminary/types/document_summary_list_params.py">params</a>) -> <a href="./src/withluminary/types/document_summary.py">SyncCursorPagination[DocumentSummary]</a></code>
- <code title="get /document-summaries/{id}/download">client.document_summaries.<a href="./src/withluminary/resources/document_summaries.py">download</a>(id, \*\*<a href="src/withluminary/types/document_summary_download_params.py">params</a>) -> BinaryAPIResponse</code>

# Documents

Types:

```python
from withluminary.types import Document, DocumentList, DocumentType, DocumentGetSummariesResponse
```

Methods:

- <code title="post /documents">client.documents.<a href="./src/withluminary/resources/documents.py">create</a>(\*\*<a href="src/withluminary/types/document_create_params.py">params</a>) -> <a href="./src/withluminary/types/document.py">Document</a></code>
- <code title="get /documents/{id}">client.documents.<a href="./src/withluminary/resources/documents.py">retrieve</a>(id) -> <a href="./src/withluminary/types/document.py">Document</a></code>
- <code title="put /documents/{id}">client.documents.<a href="./src/withluminary/resources/documents.py">update</a>(id, \*\*<a href="src/withluminary/types/document_update_params.py">params</a>) -> <a href="./src/withluminary/types/document.py">Document</a></code>
- <code title="get /documents">client.documents.<a href="./src/withluminary/resources/documents.py">list</a>(\*\*<a href="src/withluminary/types/document_list_params.py">params</a>) -> <a href="./src/withluminary/types/document.py">SyncCursorPagination[Document]</a></code>
- <code title="delete /documents/{id}">client.documents.<a href="./src/withluminary/resources/documents.py">delete</a>(id) -> None</code>
- <code title="get /documents/{id}/download">client.documents.<a href="./src/withluminary/resources/documents.py">download</a>(id) -> BinaryAPIResponse</code>
- <code title="get /documents/{id}/document-summaries">client.documents.<a href="./src/withluminary/resources/documents.py">get_summaries</a>(id) -> <a href="./src/withluminary/types/document_get_summaries_response.py">DocumentGetSummariesResponse</a></code>

# Entities

Types:

```python
from withluminary.types import Entity, EntityKind, EntityList
```

Methods:

- <code title="get /entities/{id}">client.entities.<a href="./src/withluminary/resources/entities/entities.py">retrieve</a>(id) -> <a href="./src/withluminary/types/entity.py">Entity</a></code>
- <code title="get /entities">client.entities.<a href="./src/withluminary/resources/entities/entities.py">list</a>(\*\*<a href="src/withluminary/types/entity_list_params.py">params</a>) -> <a href="./src/withluminary/types/entity.py">SyncCursorPagination[Entity]</a></code>
- <code title="delete /entities/{id}">client.entities.<a href="./src/withluminary/resources/entities/entities.py">delete</a>(id) -> None</code>

## Valuation

Types:

```python
from withluminary.types.entities import Valuation
```

Methods:

- <code title="post /entities/{id}/valuation">client.entities.valuation.<a href="./src/withluminary/resources/entities/valuation.py">create</a>(id, \*\*<a href="src/withluminary/types/entities/valuation_create_params.py">params</a>) -> <a href="./src/withluminary/types/entities/valuation.py">Valuation</a></code>
- <code title="get /entities/{id}/valuation">client.entities.valuation.<a href="./src/withluminary/resources/entities/valuation.py">retrieve</a>(id) -> <a href="./src/withluminary/types/entities/valuation.py">Valuation</a></code>

# Households

Types:

```python
from withluminary.types import Household, IndividualList
```

Methods:

- <code title="post /households">client.households.<a href="./src/withluminary/resources/households.py">create</a>(\*\*<a href="src/withluminary/types/household_create_params.py">params</a>) -> <a href="./src/withluminary/types/household.py">Household</a></code>
- <code title="get /households/{id}">client.households.<a href="./src/withluminary/resources/households.py">retrieve</a>(id) -> <a href="./src/withluminary/types/household.py">Household</a></code>
- <code title="put /households/{id}">client.households.<a href="./src/withluminary/resources/households.py">update</a>(id, \*\*<a href="src/withluminary/types/household_update_params.py">params</a>) -> <a href="./src/withluminary/types/household.py">Household</a></code>
- <code title="get /households">client.households.<a href="./src/withluminary/resources/households.py">list</a>(\*\*<a href="src/withluminary/types/household_list_params.py">params</a>) -> <a href="./src/withluminary/types/household.py">SyncCursorPagination[Household]</a></code>
- <code title="delete /households/{id}">client.households.<a href="./src/withluminary/resources/households.py">delete</a>(id) -> None</code>
- <code title="get /households/{id}/documents">client.households.<a href="./src/withluminary/resources/households.py">list_documents</a>(id, \*\*<a href="src/withluminary/types/household_list_documents_params.py">params</a>) -> <a href="./src/withluminary/types/document.py">SyncCursorPagination[Document]</a></code>
- <code title="get /households/{id}/entities">client.households.<a href="./src/withluminary/resources/households.py">list_entities</a>(id, \*\*<a href="src/withluminary/types/household_list_entities_params.py">params</a>) -> <a href="./src/withluminary/types/entity.py">SyncCursorPagination[Entity]</a></code>
- <code title="get /households/{id}/individuals">client.households.<a href="./src/withluminary/resources/households.py">list_individuals</a>(id, \*\*<a href="src/withluminary/types/household_list_individuals_params.py">params</a>) -> <a href="./src/withluminary/types/individual.py">SyncCursorPagination[Individual]</a></code>

# Individuals

Types:

```python
from withluminary.types import Individual
```

Methods:

- <code title="post /individuals">client.individuals.<a href="./src/withluminary/resources/individuals.py">create</a>(\*\*<a href="src/withluminary/types/individual_create_params.py">params</a>) -> <a href="./src/withluminary/types/individual.py">Individual</a></code>
- <code title="get /individuals/{id}">client.individuals.<a href="./src/withluminary/resources/individuals.py">retrieve</a>(id) -> <a href="./src/withluminary/types/individual.py">Individual</a></code>
- <code title="put /individuals/{id}">client.individuals.<a href="./src/withluminary/resources/individuals.py">update</a>(id, \*\*<a href="src/withluminary/types/individual_update_params.py">params</a>) -> <a href="./src/withluminary/types/individual.py">Individual</a></code>
- <code title="get /individuals">client.individuals.<a href="./src/withluminary/resources/individuals.py">list</a>(\*\*<a href="src/withluminary/types/individual_list_params.py">params</a>) -> <a href="./src/withluminary/types/individual.py">SyncCursorPagination[Individual]</a></code>
- <code title="delete /individuals/{id}">client.individuals.<a href="./src/withluminary/resources/individuals.py">delete</a>(id) -> None</code>

# Users

Types:

```python
from withluminary.types import User
```

Methods:

- <code title="get /users/{id}">client.users.<a href="./src/withluminary/resources/users.py">retrieve</a>(id) -> <a href="./src/withluminary/types/user.py">User</a></code>
- <code title="get /users">client.users.<a href="./src/withluminary/resources/users.py">list</a>(\*\*<a href="src/withluminary/types/user_list_params.py">params</a>) -> <a href="./src/withluminary/types/user.py">SyncCursorPagination[User]</a></code>
