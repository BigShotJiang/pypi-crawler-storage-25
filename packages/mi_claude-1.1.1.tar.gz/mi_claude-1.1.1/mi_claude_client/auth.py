"""
Mi-Claude Client - Local auth/session storage
Lưu token vào ~/.mi-claude-client/ để auto-login lần sau
"""

import json
import platform
from pathlib import Path

AUTH_DIR  = Path.home() / ".mi-claude-client"
AUTH_FILE = AUTH_DIR / "session.json"


def save_session(token: str, username: str, tier: str, server: str):
    """Save login session locally"""
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        "token": token,
        "username": username,
        "tier": tier,
        "server": server,
    }
    AUTH_FILE.write_text(json.dumps(data, indent=2))
    if platform.system() != "Windows":
        AUTH_FILE.chmod(0o600)


def load_session() -> dict:
    """Load saved session. Returns {} if not found."""
    if AUTH_FILE.exists():
        try:
            return json.loads(AUTH_FILE.read_text())
        except Exception:
            pass
    return {}


def clear_session():
    """Remove saved session (logout)"""
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()


def get_config_path() -> Path:
    return AUTH_DIR
