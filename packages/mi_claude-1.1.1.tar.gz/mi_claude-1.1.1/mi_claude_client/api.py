"""
Mi-Claude API Client
Handles all HTTP communication with Mi-Claude server
"""

import json
import urllib.request
import urllib.error
from typing import Generator, Optional

DEFAULT_SERVER = "https://mi-claude.fly.dev"


class MiClaudeAPI:
    def __init__(self, server_url: str = DEFAULT_SERVER):
        self.server = server_url.rstrip("/")
        self.token = None

    def _headers(self, auth: bool = True) -> dict:
        h = {"Content-Type": "application/json", "User-Agent": "mi-claude-cli/1.0"}
        if auth and self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _request(self, method: str, path: str, data: dict = None,
                 auth: bool = True, timeout: int = 30) -> dict:
        url = f"{self.server}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(url, data=body, headers=self._headers(auth), method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            raw = e.read().decode(errors="replace")
            try:
                err = json.loads(raw)
                detail = err.get("detail", raw[:200])
                if isinstance(detail, list):
                    msgs = []
                    for d in detail:
                        field = d.get("loc", ["", ""])[-1]
                        msg = d.get("msg", "")
                        msgs.append(f"{field}: {msg}")
                    detail = "; ".join(msgs)
            except Exception:
                detail = raw[:200]
            return {"error": True, "status": e.code, "detail": detail}
        except Exception as e:
            return {"error": True, "detail": str(e)}

    def _get(self, path, **kw):
        return self._request("GET", path, **kw)

    def _post(self, path, data, **kw):
        return self._request("POST", path, data, **kw)

    # ── Auth ──
    def login(self, username: str, password: str) -> dict:
        r = self._post("/api/auth/login", {"username": username, "password": password}, auth=False)
        if not r.get("error") and r.get("token"):
            self.token = r["token"]
        return r

    def register(self, username: str, password: str, invite_token: str) -> dict:
        r = self._post("/api/auth/register", {
            "username": username, "password": password, "invite_token": invite_token,
        }, auth=False)
        if not r.get("error") and r.get("token"):
            self.token = r["token"]
        return r

    def status(self) -> dict:
        return self._get("/api/auth/status")

    # ── Models ──
    def models(self) -> dict:
        return self._get("/api/models", auth=False)

    # ── Chat ──
    def chat(self, message: str, model: str = "sonnet", history: list = None,
             temperature: float = 0.7, max_tokens: int = 4096, system_prompt: str = "") -> dict:
        return self._post("/api/chat", {
            "message": message, "model": model, "history": history or [],
            "temperature": temperature, "max_tokens": max_tokens, "system_prompt": system_prompt,
        }, timeout=300)

    # ── Agent (tool_use) ──
    def agent(self, messages: list, tools: list, model: str = "sonnet",
              temperature: float = 0.7, max_tokens: int = 4096, system_prompt: str = "") -> dict:
        """Agent chat with tool_use - returns raw Anthropic response"""
        return self._post("/api/agent", {
            "messages": messages, "model": model, "tools": tools,
            "temperature": temperature, "max_tokens": max_tokens, "system_prompt": system_prompt,
        }, timeout=300)

    # ── Stream ──
    def stream(self, message: str, model: str = "sonnet", history: list = None,
               temperature: float = 0.7, max_tokens: int = 4096, system_prompt: str = "") -> Generator:
        """Streaming chat - yields text chunks"""
        url = f"{self.server}/api/chat/stream"
        payload = json.dumps({
            "message": message, "model": model, "history": history or [],
            "temperature": temperature, "max_tokens": max_tokens, "system_prompt": system_prompt,
        }).encode()

        req = urllib.request.Request(url, data=payload, headers=self._headers(), method="POST")
        try:
            resp = urllib.request.urlopen(req, timeout=600)
        except urllib.error.HTTPError as e:
            raw = e.read().decode(errors="replace")
            try:
                detail = json.loads(raw).get("detail", raw[:200])
            except Exception:
                detail = raw[:200]
            yield f"[Error] {e.code}: {detail}"
            return
        except Exception as e:
            yield f"[Error] {e}"
            return

        try:
            for raw_line in resp:
                line = raw_line.decode("utf-8").rstrip()
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str == "[DONE]":
                    break
                try:
                    event = json.loads(data_str)
                    if event.get("type") == "text":
                        yield event.get("text", "")
                    elif event.get("type") == "error":
                        yield f"\n[Error] {event.get('text', '')}"
                except json.JSONDecodeError:
                    continue
        except Exception as e:
            yield f"\n[Error] Stream: {e}"
        finally:
            resp.close()
