"""Mi-Claude - AI Agent CLI Client"""
__version__ = "1.1.1"
SERVER_URL = "https://mi-claude.fly.dev"
