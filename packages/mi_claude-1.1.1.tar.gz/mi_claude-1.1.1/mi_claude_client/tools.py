"""
Mi-Claude Client - Local Tools
Tools chạy trực tiếp trên máy user (bash, file, web, python)
Tương thích với Anthropic tool_use API format.
"""

import os
import re
import sys
import json
import shutil
import platform
import subprocess
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from html.parser import HTMLParser


# ═══════════════════════════════════════════
#   TOOL DEFINITIONS (Anthropic format)
# ═══════════════════════════════════════════
TOOL_DEFINITIONS = [
    {
        "name": "bash",
        "description": "Execute a bash shell command. Use for running scripts, system commands, git, etc.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The bash command to execute"},
                "timeout": {"type": "integer", "description": "Timeout in seconds (default: 30)"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read the contents of a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "start_line": {"type": "integer", "description": "Start line (1-indexed)"},
                "end_line": {"type": "integer", "description": "End line (1-indexed)"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write or create a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to write"},
                "content": {"type": "string", "description": "Content to write"},
                "append": {"type": "boolean", "description": "Append instead of overwrite"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "list_dir",
        "description": "List directory contents with file sizes.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: .)"},
                "recursive": {"type": "boolean", "description": "List recursively"},
            },
            "required": [],
        },
    },
    {
        "name": "web_fetch",
        "description": "Fetch content from a URL (HTML, JSON, text).",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "max_chars": {"type": "integer", "description": "Max chars to return (default: 5000)"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "python_eval",
        "description": "Execute Python code and return output. Good for calculations and data processing.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
            },
            "required": ["code"],
        },
    },
]


# ═══════════════════════════════════════════
#   TOOL IMPLEMENTATIONS
# ═══════════════════════════════════════════
_cwd = os.getcwd()


def run_bash(command: str, timeout: int = 30) -> str:
    global _cwd
    try:
        # Handle cd command
        cmd_strip = command.strip()
        if cmd_strip.startswith("cd "):
            new_dir = cmd_strip[3:].strip().strip('"').strip("'")
            new_path = os.path.expanduser(new_dir)
            if not os.path.isabs(new_path):
                new_path = os.path.join(_cwd, new_path)
            new_path = os.path.normpath(new_path)
            if os.path.isdir(new_path):
                _cwd = new_path
                return f"Changed directory to: {_cwd}"
            return f"Directory not found: {new_dir}"

        if platform.system() == "Windows":
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                timeout=timeout, cwd=_cwd, encoding="utf-8", errors="replace",
            )
        else:
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                timeout=timeout, cwd=_cwd, executable="/bin/bash",
            )

        out = result.stdout.strip()
        err = result.stderr.strip()
        output = ""
        if out:
            output += out
        if err:
            output += ("\n" if output else "") + f"[stderr] {err}"
        if result.returncode != 0 and not output:
            output = f"[Exit code: {result.returncode}]"
        return output or "(no output)"

    except subprocess.TimeoutExpired:
        return f"[Timeout] Command exceeded {timeout}s"
    except Exception as e:
        return f"[Error] {e}"


def run_read_file(path: str, start_line: int = None, end_line: int = None) -> str:
    try:
        p = Path(path).expanduser()
        if not p.exists():
            return f"[Error] File not found: {path}"
        if p.stat().st_size > 5 * 1024 * 1024:
            return f"[Error] File too large (>5MB): {path}"
        text = p.read_text(encoding="utf-8", errors="replace")
        if start_line or end_line:
            lines = text.splitlines()
            s = (start_line or 1) - 1
            e = end_line or len(lines)
            text = "\n".join(lines[s:e])
        return text
    except Exception as e:
        return f"[Error] {e}"


def run_write_file(path: str, content: str, append: bool = False) -> str:
    try:
        p = Path(path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        mode = "a" if append else "w"
        with open(p, mode, encoding="utf-8") as f:
            f.write(content)
        action = "Appended to" if append else "Written"
        return f"[OK] {action}: {p} ({len(content)} chars)"
    except Exception as e:
        return f"[Error] {e}"


def run_list_dir(path: str = ".", recursive: bool = False) -> str:
    try:
        p = Path(path).expanduser()
        if not p.exists():
            return f"[Error] Path not found: {path}"
        if recursive:
            lines = [str(p.resolve())]
            for item in sorted(p.rglob("*")):
                rel = item.relative_to(p)
                if any(part.startswith(".") for part in rel.parts):
                    continue
                try:
                    size = item.stat().st_size
                    prefix = "  " * (len(rel.parts) - 1)
                    if item.is_dir():
                        lines.append(f"{prefix}{rel}/")
                    else:
                        lines.append(f"{prefix}{rel} ({_fmt_size(size)})")
                except Exception:
                    lines.append(f"  {rel}")
            return "\n".join(lines[:500])
        else:
            items = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
            lines = [f"Directory: {p.resolve()}\n"]
            for item in items:
                if item.name.startswith("."):
                    continue
                try:
                    stat = item.stat()
                    mtime = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
                    if item.is_dir():
                        lines.append(f"  [DIR]  {item.name}/   {mtime}")
                    else:
                        lines.append(f"  [FILE] {item.name}   {_fmt_size(stat.st_size)}   {mtime}")
                except Exception:
                    lines.append(f"  {item.name}")
            return "\n".join(lines)
    except Exception as e:
        return f"[Error] {e}"


class _TextExtractor(HTMLParser):
    SKIP_TAGS = {"script", "style", "head", "meta", "link", "noscript"}
    def __init__(self):
        super().__init__()
        self._skip = False
        self._depth = 0
        self.texts = []
    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP_TAGS:
            self._skip = True
            self._depth = 1
    def handle_endtag(self, tag):
        if self._skip and tag in self.SKIP_TAGS:
            self._depth -= 1
            if self._depth <= 0:
                self._skip = False
    def handle_data(self, data):
        if not self._skip and data.strip():
            self.texts.append(data.strip())
    def get_text(self):
        return "\n".join(self.texts)


def run_web_fetch(url: str, max_chars: int = 5000) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Mi-Claude/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            ct = resp.headers.get("Content-Type", "")
            raw = resp.read()
            enc = "utf-8"
            if "charset=" in ct:
                enc = ct.split("charset=")[-1].strip().split(";")[0]
            try:
                html = raw.decode(enc, errors="replace")
            except Exception:
                html = raw.decode("utf-8", errors="replace")

            if "application/json" in ct:
                return html[:max_chars]

            parser = _TextExtractor()
            parser.feed(html)
            text = parser.get_text()
            text = re.sub(r"\n{3,}", "\n\n", text)
            if len(text) > max_chars:
                text = text[:max_chars] + f"\n...[truncated at {max_chars} chars]"
            return text or "(no readable content)"
    except urllib.error.HTTPError as e:
        return f"[HTTP Error] {e.code}: {url}"
    except Exception as e:
        return f"[Error] {e}"


def run_python_eval(code: str) -> str:
    try:
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(code, {"__builtins__": __builtins__})
        output = buf.getvalue().strip()
        return output or "(no output)"
    except Exception as e:
        return f"[Error] {type(e).__name__}: {e}"


def _fmt_size(size: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


# ═══════════════════════════════════════════
#   TOOL EXECUTOR
# ═══════════════════════════════════════════
def execute_tool(name: str, inputs: dict) -> str:
    dispatch = {
        "bash": lambda i: run_bash(i["command"], i.get("timeout", 30)),
        "read_file": lambda i: run_read_file(i["path"], i.get("start_line"), i.get("end_line")),
        "write_file": lambda i: run_write_file(i["path"], i["content"], i.get("append", False)),
        "list_dir": lambda i: run_list_dir(i.get("path", "."), i.get("recursive", False)),
        "web_fetch": lambda i: run_web_fetch(i["url"], i.get("max_chars", 5000)),
        "python_eval": lambda i: run_python_eval(i["code"]),
    }
    fn = dispatch.get(name)
    if fn:
        return fn(inputs)
    return f"[Error] Unknown tool: {name}"
