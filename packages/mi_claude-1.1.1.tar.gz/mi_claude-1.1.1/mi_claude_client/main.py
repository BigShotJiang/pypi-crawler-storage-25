#!/usr/bin/env python3
"""
Mi-Claude CLI - AI Agent Client
Full-featured: chat, tools (bash, file, web, python), agent mode.
"""

import sys
import os
import json
import argparse

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich import box
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style

from mi_claude_client import SERVER_URL, __version__
from mi_claude_client.api import MiClaudeAPI
from mi_claude_client.auth import save_session, load_session, clear_session, get_config_path
from mi_claude_client.tools import TOOL_DEFINITIONS, execute_tool

console = Console()
HISTORY_FILE = get_config_path() / ".prompt_history"
PT_STYLE = Style.from_dict({"prompt": "ansicyan bold"})
DOCS_URL = "https://mi-claude.fly.dev/guide"

SYSTEM_PROMPT = (
    "You are Mi-Claude, a powerful AI coding assistant and personal agent "
    "running locally on the user's machine. You have access to tools: bash, "
    "read_file, write_file, list_dir, web_fetch, python_eval. "
    "Use tools to help users with coding, file management, and system tasks. "
    "Answer in the same language the user uses. "
    "When making tool calls, complete ALL steps in a single turn."
)

MAX_AGENT_ITERS = 20  # Max tool_use loops per turn


# ─────────────────────────────────────
#   BANNER & HELP
# ─────────────────────────────────────
def _banner(username="", tier="", model=""):
    console.print()
    console.print(Panel(
        "[bold cyan]Mi-Claude[/bold cyan] — AI Agent\n"
        f"[dim]v{__version__}  •  mi-claude.fly.dev  •  Tools enabled[/dim]\n"
        f"[dim]{DOCS_URL}[/dim]",
        border_style="cyan",
    ))
    if username:
        console.print(f"  [green]✓[/green] {username} ({tier})  •  Model: [cyan]{model}[/cyan]  •  Tools: [green]bash, file, web, python[/green]")
    console.print()


def _help():
    t = Table(box=box.ROUNDED, title="Commands", header_style="bold cyan")
    t.add_column("Command", style="cyan", min_width=18)
    t.add_column("Description")
    for cmd, desc in [
        ("/help", "Show this help"),
        ("/status", "Account status & quota"),
        ("/model [name]", "Switch model (opus, sonnet, haiku)"),
        ("/models", "List available models"),
        ("/tools", "List available tools"),
        ("/clear", "Clear chat history"),
        ("/new", "New conversation"),
        ("/shell <cmd>", "Run shell command directly"),
        ("/file read <path>", "Read file"),
        ("/file list [path]", "List directory"),
        ("/web <url>", "Fetch URL"),
        ("/python <code>", "Run Python code"),
        ("/guide", "Open docs in browser"),
        ("/logout", "Logout"),
        ("/exit", "Exit"),
    ]:
        t.add_row(cmd, desc)
    console.print(t)
    console.print(f"  [dim]📖 Full docs: {DOCS_URL}[/dim]")
    console.print(f"  [dim]💡 Mi-Claude can also use tools automatically when you ask![/dim]")


# ─────────────────────────────────────
#   AUTH SCREEN
# ─────────────────────────────────────
def auth_screen(api: MiClaudeAPI) -> bool:
    console.print(Panel(
        "[bold cyan]Mi-Claude[/bold cyan]\n[dim]Login or Register to continue[/dim]",
        border_style="cyan",
    ))
    while True:
        console.print("\n  [yellow]1.[/yellow] Login")
        console.print("  [yellow]2.[/yellow] Register (need invite token)")
        console.print("  [yellow]3.[/yellow] Exit")
        choice = Prompt.ask("  [cyan]Choose[/cyan]", choices=["1", "2", "3"])

        if choice == "1":
            username = Prompt.ask("  [cyan]Username[/cyan]")
            password = Prompt.ask("  [cyan]Password[/cyan]", password=True)
            with console.status("[cyan]Logging in...[/cyan]"):
                r = api.login(username, password)
            if r.get("error"):
                console.print(f"  [red]✗ {r['detail']}[/red]")
            else:
                user = r["user"]
                save_session(r["token"], user["username"], user["tier"], api.server)
                console.print(f"  [green]✓ Welcome, {user['username']}! (tier: {user['tier']})[/green]")
                return True

        elif choice == "2":
            console.print("  [dim]Password: ≥8 chars, uppercase + lowercase + number[/dim]")
            username = Prompt.ask("  [cyan]Username[/cyan]")
            password = Prompt.ask("  [cyan]Password[/cyan]", password=True)
            confirm  = Prompt.ask("  [cyan]Confirm password[/cyan]", password=True)
            if password != confirm:
                console.print("  [red]Passwords don't match[/red]")
                continue
            invite = Prompt.ask("  [cyan]Invite token[/cyan]")
            with console.status("[cyan]Registering...[/cyan]"):
                r = api.register(username, password, invite)
            if r.get("error"):
                console.print(f"  [red]✗ {r['detail']}[/red]")
            else:
                user = r["user"]
                save_session(r["token"], user["username"], user["tier"], api.server)
                console.print(f"  [green]✓ Registered! Welcome, {user['username']}![/green]")
                return True
        else:
            return False


# ─────────────────────────────────────
#   AGENT LOOP (tool_use)
# ─────────────────────────────────────
def agent_chat(api: MiClaudeAPI, user_input: str, history: list, model: str) -> str:
    """
    Full agent loop: send message → Claude may request tools →
    execute locally → send results back → repeat until done.
    """
    # Build messages
    messages = list(history) + [{"role": "user", "content": user_input}]

    full_text = ""

    for iteration in range(MAX_AGENT_ITERS):
        # Call server /api/agent with tools
        r = api.agent(
            messages=messages,
            tools=TOOL_DEFINITIONS,
            model=model,
            max_tokens=4096,
            system_prompt=SYSTEM_PROMPT,
        )

        if r.get("error"):
            error_msg = r.get("detail", "Unknown error")
            console.print(f"\n[red][Error] {error_msg}[/red]")
            return ""

        content = r.get("content", [])
        stop_reason = r.get("stop_reason", "end_turn")

        # Process response blocks
        for block in content:
            if block.get("type") == "text":
                text = block.get("text", "")
                console.print(text, end="", markup=False)
                full_text += text

        # If stop_reason is end_turn → done
        if stop_reason != "tool_use":
            console.print()
            break

        # Tool use → execute locally
        console.print()
        tool_results = []
        for block in content:
            if block.get("type") != "tool_use":
                continue

            tool_name = block["name"]
            tool_input = block.get("input", {})
            tool_id = block["id"]

            # Show tool call
            input_display = json.dumps(tool_input, ensure_ascii=False)
            if len(input_display) > 120:
                input_display = input_display[:120] + "..."
            console.print(f"  [yellow]⚡ {tool_name}[/yellow] [dim]{input_display}[/dim]")

            # Execute tool locally
            try:
                result = execute_tool(tool_name, tool_input)
            except Exception as e:
                result = f"[Error] {e}"

            # Show result preview
            preview = result[:200].replace("\n", " ")
            if len(result) > 200:
                preview += "..."
            console.print(f"  [green]  → {preview}[/green]")

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result[:50000],  # Limit result size
            })

        # Add assistant response + tool results to messages
        messages.append({"role": "assistant", "content": content})
        messages.append({"role": "user", "content": tool_results})

        console.print()

    else:
        console.print(f"\n[yellow]⚠ Max iterations ({MAX_AGENT_ITERS}) reached[/yellow]")

    return full_text


# ─────────────────────────────────────
#   DIRECT TOOL COMMANDS
# ─────────────────────────────────────
def handle_tool_command(cmd: str, args_str: str):
    """Handle /shell, /file, /web, /python commands"""
    if cmd == "/shell":
        if not args_str:
            console.print("[red]Usage: /shell <command>[/red]")
            return
        result = execute_tool("bash", {"command": args_str})
        console.print(Panel(result, title="Shell Output", border_style="yellow"))

    elif cmd == "/file":
        parts = args_str.split(None, 1)
        if not parts:
            console.print("[red]Usage: /file read <path> | /file list [path] | /file info <path>[/red]")
            return
        action = parts[0]
        path = parts[1] if len(parts) > 1 else "."
        if action == "read":
            result = execute_tool("read_file", {"path": path})
            console.print(Panel(result[:3000], title=f"📄 {path}", border_style="blue"))
        elif action == "list":
            result = execute_tool("list_dir", {"path": path})
            console.print(Panel(result, title=f"📁 {path}", border_style="blue"))
        elif action == "write":
            console.print("[dim]Use Mi-Claude agent: 'write hello world to test.txt'[/dim]")
        else:
            console.print(f"[red]Unknown action: {action}. Use: read, list[/red]")

    elif cmd == "/web":
        if not args_str:
            console.print("[red]Usage: /web <url>[/red]")
            return
        with console.status("[cyan]Fetching...[/cyan]"):
            result = execute_tool("web_fetch", {"url": args_str})
        console.print(Panel(result[:2000], title=f"🌐 {args_str}", border_style="blue"))

    elif cmd == "/python":
        if not args_str:
            console.print("[red]Usage: /python <code>[/red]")
            return
        result = execute_tool("python_eval", {"code": args_str})
        console.print(Panel(result, title="🐍 Python", border_style="green"))


# ─────────────────────────────────────
#   MAIN
# ─────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Mi-Claude AI Agent")
    parser.add_argument("--server", default=None, help="Server URL")
    parser.add_argument("--register", action="store_true", help="Register new account")
    parser.add_argument("--logout", action="store_true", help="Logout")
    parser.add_argument("--version", action="version", version=f"mi-claude {__version__}")
    args = parser.parse_args()

    if args.logout:
        clear_session()
        console.print("[green]Logged out[/green]")
        return

    # Load session
    session = load_session()
    server = args.server or session.get("server", SERVER_URL)
    api = MiClaudeAPI(server)

    # Auto-login
    logged_in = False
    if session.get("token") and not args.register:
        api.token = session["token"]
        r = api.status()
        if not r.get("error"):
            logged_in = True
            username = r["username"]
            tier = r["tier"]
        else:
            clear_session()

    if not logged_in:
        console.clear()
        if not auth_screen(api):
            return
        session = load_session()
        username = session["username"]
        tier = session["tier"]

    # Setup
    model = "sonnet"
    history = []
    console.clear()
    _banner(username, tier, model)
    _help()

    get_config_path().mkdir(parents=True, exist_ok=True)
    pt = PromptSession(
        history=FileHistory(str(HISTORY_FILE)),
        auto_suggest=AutoSuggestFromHistory(),
    )

    while True:
        try:
            user_input = pt.prompt(
                f"[{model}] {username} > ",
                style=PT_STYLE,
            ).strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[cyan]Goodbye![/cyan]")
            break

        if not user_input:
            continue

        # ── Commands ──
        if user_input.startswith("/"):
            parts = user_input.split(None, 1)
            cmd = parts[0].lower()
            args_str = parts[1] if len(parts) > 1 else ""

            if cmd in ("/exit", "/quit"):
                console.print("[cyan]Goodbye![/cyan]")
                break

            elif cmd == "/help":
                _help()

            elif cmd == "/status":
                with console.status("[cyan]Fetching...[/cyan]"):
                    r = api.status()
                if r.get("error"):
                    console.print(f"[red]{r['detail']}[/red]")
                else:
                    t = Table(box=box.SIMPLE, title="Account Status")
                    t.add_column("Key", style="cyan")
                    t.add_column("Value")
                    t.add_row("Username", r["username"])
                    t.add_row("Tier", r["tier"])
                    t.add_row("Daily", f"{r['daily']['used']} / {r['daily']['limit']}")
                    t.add_row("Monthly", f"{r['monthly']['used']} / {r['monthly']['limit']}")
                    console.print(t)

            elif cmd == "/models":
                with console.status("[cyan]Fetching...[/cyan]"):
                    r = api.models()
                if r.get("error"):
                    console.print(f"[red]{r['detail']}[/red]")
                else:
                    t = Table(box=box.SIMPLE, title="Available Models")
                    t.add_column("Model", style="cyan")
                    t.add_column("Alias", style="yellow")
                    t.add_column("Context", style="green")
                    aliases_rev = {}
                    for alias, full in r.get("aliases", {}).items():
                        aliases_rev.setdefault(full, []).append(alias)
                    for name, info in r["models"].items():
                        alias_str = ", ".join(aliases_rev.get(name, ["-"]))
                        t.add_row(name, alias_str, f"{info['context']:,}")
                    console.print(t)
                    console.print()
                    console.print("  [dim]💡 Switch model:[/dim] [cyan]/model <name>[/cyan]")
                    console.print("  [dim]   Example: /model opus  •  /model haiku  •  /model sonnet[/dim]")

            elif cmd == "/model":
                if args_str:
                    model = args_str.strip()
                    console.print(f"[green]✓ Model → {model}[/green]")
                else:
                    console.print(f"[cyan]Current model: {model}[/cyan]")
                    console.print("[dim]  Usage: /model <name>  (opus, sonnet, haiku)[/dim]")

            elif cmd == "/tools":
                t = Table(box=box.SIMPLE, title="Available Tools")
                t.add_column("Tool", style="cyan")
                t.add_column("Description")
                for tool in TOOL_DEFINITIONS:
                    t.add_row(tool["name"], tool["description"][:60])
                console.print(t)
                console.print("  [dim]💡 Tools are used automatically, or use /shell /file /web /python[/dim]")

            elif cmd in ("/shell", "/file", "/web", "/python"):
                handle_tool_command(cmd, args_str)

            elif cmd == "/clear":
                history = []
                console.print("[green]Chat history cleared[/green]")

            elif cmd == "/new":
                history = []
                console.clear()
                _banner(username, tier, model)
                console.print("[green]New conversation started[/green]")

            elif cmd == "/guide":
                import webbrowser
                webbrowser.open(DOCS_URL)
                console.print(f"[green]Opening {DOCS_URL}[/green]")

            elif cmd == "/logout":
                clear_session()
                console.print("[green]Logged out[/green]")
                break

            else:
                console.print(f"[red]Unknown command: {cmd}[/red]")
                console.print("[dim]  Type /help to see all commands[/dim]")

            console.print()
            continue

        # ── Agent Chat (with tools) ──
        console.print()
        console.print("[bold cyan]Mi-Claude:[/bold cyan]")

        full_response = agent_chat(api, user_input, history, model)

        # Update history (simplified - just user + final text)
        if full_response:
            history.append({"role": "user", "content": user_input})
            history.append({"role": "assistant", "content": full_response})
            if len(history) > 30:
                history = history[-30:]

        console.print()


if __name__ == "__main__":
    main()
