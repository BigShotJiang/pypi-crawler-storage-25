# Mi-Claude — AI Agent in Your Terminal

Chat with Claude AI (Opus, Sonnet, Haiku) directly from your terminal.  
No API key needed. Just install, register, and chat.  
**NEW: Full Agent Mode** — Claude uses tools (bash, file, web, python) locally on your machine!

## Install

```bash
pip install mi-claude
```

## Usage

```bash
mi-claude
```

**First time:** Choose Register → enter username, password, invite token → done!  
**After that:** Auto-login, just type and chat.

```
  ╔═══════════════════════════════╗
  ║         Mi-Claude             ║
  ║   AI Agent Client v1.1.0     ║
  ║   Tools: bash, file, web, py ║
  ╚═══════════════════════════════╝

  ✓ john (pro)  •  Model: sonnet  •  Tools: bash, file, web, python

  [sonnet] john > List files in current directory
    ⚡ bash {"command": "ls -la"}
    → total 48 ...
  Here are your files: ...
```

## Agent Mode (NEW ✨)

Mi-Claude is now a full AI agent. Just ask naturally and Claude will use tools:

```
> What's my disk usage?
  ⚡ bash {"command": "df -h"}

> Read and summarize README.md  
  ⚡ read_file {"path": "README.md"}

> Create a hello world script
  ⚡ write_file {"path": "hello.py", "content": "print('Hello!')"}
```

### Available Tools

| Tool | Description |
|------|-------------|
| `bash` | Run shell commands |
| `read_file` | Read file contents (with line range) |
| `write_file` | Create/write/append files |
| `list_dir` | List directory contents |
| `web_fetch` | Fetch URL content (HTML→text) |
| `python_eval` | Execute Python code |

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show commands |
| `/status` | Account quota |
| `/model sonnet` | Switch model |
| `/models` | List all models |
| `/tools` | List available agent tools |
| `/shell <cmd>` | Run shell command directly |
| `/file read <path>` | Read file |
| `/file list [path]` | List directory |
| `/web <url>` | Fetch URL |
| `/python <code>` | Run Python code |
| `/clear` | Clear chat |
| `/new` | New conversation |
| `/logout` | Logout |
| `/exit` | Exit |

## Models

- `opus` — Claude Opus 4 (most capable)
- `sonnet` — Claude Sonnet 4 (balanced, default)
- `haiku` — Claude Haiku 4.5 (fastest)

## Register

Ask admin for an invite token, then:

```bash
mi-claude --register
```

## Requirements

- Python 3.8+
- Internet connection

## License

MIT
