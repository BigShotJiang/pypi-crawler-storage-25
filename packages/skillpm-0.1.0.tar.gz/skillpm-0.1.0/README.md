# agentskill

Agent skill manager for the [Agent Skills standard](https://agentskills.io).

Install, update, remove, and list agent skills across Claude Code, Cursor, Codex, and other AI coding agents.

## Install

```bash
pip install agentskill
```

## Usage

```bash
agentskill install owner/repo           # install from GitHub
agentskill install ./local/skill        # install from local path
agentskill list                         # list installed skills
agentskill update skill-name            # update a skill
agentskill remove skill-name            # remove a skill
agentskill info skill-name              # show skill details
```

## Library

```python
from agentskill import installSkill, listSkills, removeSkill

installSkill("owner/repo/skill-name")
skills = listSkills()
removeSkill("skill-name")
```

## License

MIT
