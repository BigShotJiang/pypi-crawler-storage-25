from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

# check if it can import correctly
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

if "email_validator" not in sys.modules:
    email_validator_stub = types.ModuleType("email_validator")

    class EmailNotValidError(Exception):
        pass

    def validate_email(value, check_deliverability=False):
        return types.SimpleNamespace(normalized=value)

    email_validator_stub.EmailNotValidError = EmailNotValidError
    email_validator_stub.validate_email = validate_email
    sys.modules["email_validator"] = email_validator_stub

from smtpmailmime.main import EasyMail


class TestEasyMail(unittest.TestCase):
    def test_can_create_easymail_instance(self):
        mailer = EasyMail()
        self.assertIsInstance(mailer, EasyMail)

    def test_sent_requires_username(self):
        mailer = EasyMail()
        mailer.password = "secret"

        with self.assertRaisesRegex(RuntimeError, "Missing email address"):
            mailer.sent = {"recipient": "user@example.com"}

    def test_sent_requires_password(self):
        mailer = EasyMail()
        mailer.username = "sender@example.com"

        with self.assertRaisesRegex(RuntimeError, "Missing email password"):
            mailer.sent = {"recipient": "user@example.com"}

    @patch("smtpmailmime.main.get_provider_config", return_value=None)
    def test_sent_rejects_unsupported_provider(self, mock_get_provider_config):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        with self.assertRaisesRegex(RuntimeError, "Unsupported email provider"):
            mailer.sent = {"recipient": "user@example.com"}

        mock_get_provider_config.assert_called_once_with("example.com")

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_uses_autodetected_config_and_sends_email(
        self, mock_get_provider_config, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        smtp_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = smtp_server

        mailer.sent = {
            "recipient": "alice@example.com, bob@example.com",
            "cc": "carol@example.com",
            "bcc": "dave@example.com",
            "body": "<p>Hello team</p>",
            "body_type": "html",
        }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_called_once_with("smtp.test.local", 587)
        smtp_server.starttls.assert_called_once_with()
        smtp_server.login.assert_called_once_with("sender@example.com", "secret")
        smtp_server.send_message.assert_called_once()

        message = smtp_server.send_message.call_args.args[0]
        recipients = smtp_server.send_message.call_args.kwargs["to_addrs"]

        self.assertEqual(message["From"], "sender@example.com")
        self.assertEqual(message["To"], "alice@example.com, bob@example.com")
        self.assertEqual(message["Cc"], "carol@example.com")
        self.assertEqual(message["Subject"], "No subject")
        self.assertEqual(
            recipients,
            [
                "alice@example.com",
                "bob@example.com",
                "carol@example.com",
                "dave@example.com",
            ],
        )

        body_part = message.get_payload()[0]
        self.assertEqual(body_part.get_content_type(), "text/html")
        self.assertIn("Hello team", body_part.get_payload())

    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_requires_recipient(self, mock_get_provider_config):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        with self.assertRaisesRegex(RuntimeError, "Missing recipient email address"):
            mailer.sent = {"subject": "Hello"}

        mock_get_provider_config.assert_called_once_with("example.com")

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_rejects_invalid_attachment_path(
        self, mock_get_provider_config, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        with self.assertRaisesRegex(FileNotFoundError, "missing-file.txt not found"):
            mailer.sent = {
                "recipient": "alice@example.com",
                "attachment": "missing-file.txt",
            }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_not_called()

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_rejects_multiple_attachments_when_one_path_is_invalid(
        self, mock_get_provider_config, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        with tempfile.NamedTemporaryFile(delete=False) as valid_file:
            valid_path = Path(valid_file.name)
            valid_file.write(b"hello attachment")

        self.addCleanup(valid_path.unlink, missing_ok=True)

        with self.assertRaisesRegex(FileNotFoundError, "missing-file.txt not found"):
            mailer.sent = {
                "recipient": "alice@example.com",
                "attachment": f"{valid_path}, missing-file.txt",
            }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_not_called()

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_rejects_mixed_valid_and_invalid_attachment_paths(
        self, mock_get_provider_config, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        with tempfile.NamedTemporaryFile(delete=False) as first_file:
            first_path = Path(first_file.name)
            first_file.write(b"first attachment")

        with tempfile.NamedTemporaryFile(delete=False) as second_file:
            second_path = Path(second_file.name)
            second_file.write(b"second attachment")

        self.addCleanup(first_path.unlink, missing_ok=True)
        self.addCleanup(second_path.unlink, missing_ok=True)

        with self.assertRaisesRegex(FileNotFoundError, "missing-file.txt not found"):
            mailer.sent = {
                "recipient": "alice@example.com",
                "attachment": f"{first_path}, missing-file.txt, {second_path}",
            }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_not_called()

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch("smtpmailmime.main.email_validation")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_rejects_invalid_cc_address(
        self, mock_get_provider_config, mock_email_validation, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        def fake_validation(address):
            if address == "not-an-email":
                return "invalid"
            return None

        mock_email_validation.side_effect = fake_validation

        with self.assertRaisesRegex(
            RuntimeError, "Invalid cc email address: not-an-email"
        ):
            mailer.sent = {
                "recipient": "alice@example.com",
                "cc": "not-an-email",
            }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_not_called()

    @patch("smtpmailmime.main.smtplib.SMTP")
    @patch("smtpmailmime.main.email_validation")
    @patch(
        "smtpmailmime.main.get_provider_config",
        return_value={
            "imap": {"server": "imap.test.local", "port": "993"},
            "smtp": {"server": "smtp.test.local", "port": 587},
        },
    )
    def test_sent_rejects_invalid_bcc_address(
        self, mock_get_provider_config, mock_email_validation, mock_smtp
    ):
        mailer = EasyMail()
        mailer.username = "sender@example.com"
        mailer.password = "secret"

        def fake_validation(address):
            if address == "not-an-email":
                return "invalid"
            return None

        mock_email_validation.side_effect = fake_validation

        with self.assertRaisesRegex(
            RuntimeError, "Invalid bcc email address: not-an-email"
        ):
            mailer.sent = {
                "recipient": "alice@example.com",
                "bcc": "not-an-email",
            }

        mock_get_provider_config.assert_called_once_with("example.com")
        mock_smtp.assert_not_called()


if __name__ == "__main__":
    unittest.main()
