import smtplib
from email.mime.text import MIMEText
# This is a test email sending script, it will send an email to the local SMTP server running on port 4025, with the sender email address as
msg = MIMEText("Hello test mail")
msg["Subject"] = "Test"
msg["From"] = "test@example.org"
msg["To"] = "receiver@example.org"

with smtplib.SMTP("localhost", 4025) as server:
    server.login("test@example.org", "abc")  # username + password
    server.send_message(msg)