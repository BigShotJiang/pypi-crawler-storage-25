# EasyMail

EasyMail is a lightweight Python library for sending emails with minimal setup. It automatically detects your email provider's SMTP settings so you don't have to configure them manually.

---

## Installation

```bash
pip install EasyMail
```

**Dependencies:**
- `requests` — fetches provider SMTP config automatically
- `email-validator` — validates email addresses before sending

---

## Quick Start

```python
from smtpmailmime import EasyMail

email = EasyMail()
email.username = "you@gmail.com"
email.password = "your_password"

email.sent = {
    "To": "recipient@example.com",
    "Subject": "Hello!",
    "Body": "This is the email body."
}
```

That's it. EasyMail will auto-detect the SMTP server for your provider and send the email.

---

## Email Fields

| Field | Required | Description |
|-------|----------|-------------|
| `To` | Yes | Recipient email address(es). Separate multiple with commas. |
| `Cc` | No | Carbon copy recipient(s). Separate multiple with commas. |
| `Bcc` | No | Blind carbon copy recipient(s). Not visible to other recipients. |
| `Subject` | No | Email subject line. Defaults to `"No subject"` if omitted. |
| `Body` | No | Email body text. |
| `Body_type` | No | Set to `"html"` to send an HTML email. Defaults to `"plain"`. |
| `Attachment` | No | File path(s) to attach. Separate multiple paths with commas. |

---

## Examples

### Sending to multiple recipients

```python
email.sent = {
    "To": "alice@example.com, bob@example.com",
    "Subject": "Team Update",
    "Body": "Here is the latest update."
}
```

### CC and BCC

```python
email.sent = {
    "To": "alice@example.com",
    "Cc": "manager@example.com",
    "Bcc": "archive@example.com",
    "Subject": "Project Report",
    "Body": "Please find the report attached."
}
```

### HTML email

```python
email.sent = {
    "To": "recipient@example.com",
    "Subject": "HTML Email",
    "Body": "<h1>Hello!</h1><p>This is an <b>HTML</b> email.</p>",
    "Body_type": "html"
}
```

### Sending attachments

```python
email.sent = {
    "To": "recipient@example.com",
    "Subject": "Files attached",
    "Body": "See attached files.",
    "Attachment": "report.pdf"
}
```

### Sending multiple attachments

```python
email.sent = {
    "To": "recipient@example.com",
    "Subject": "Multiple Files",
    "Body": "See the attached files.",
    "Attachment": "report.pdf, photo.png, data.csv"
}
```

---

## Provider Auto-Configuration

EasyMail uses [Thunderbird's autoconfig service](https://autoconfig.thunderbird.net) to look up SMTP settings based on your email domain. This means it works out of the box for most major providers (Gmail, Outlook, Yahoo, iCloud, etc.) without any manual setup.

### Manual SMTP Configuration

If your provider is not supported or auto-config fails, you can override the settings manually:

```python
email.username = "you@yourdomain.com"
email.password = "your_password"
email._config = {
    "smtp": {
        "server": "smtp.yourdomain.com",
        "port": "587"
    }
}

email.sent = {
    "To": "recipient@example.com",
    "Subject": "Manual config test",
    "Body": "Sent using manual SMTP config."
}
```

---

## Common Errors

| Error | Cause |
|-------|-------|
| `Missing email address` | `username` was not set |
| `Missing email password` | `password` was not set |
| `Unsupported email provider` | Auto-config could not find SMTP settings for your domain |
| `Missing recipient email address` | `To` field was not provided |
| `Invalid recipient email address` | One of the addresses in `To`, `Cc`, or `Bcc` is malformed |
| `Invalid email credentials` | Wrong username or password (SMTP auth failed) |
| `FileNotFoundError` | An attachment path does not exist |

---

## Notes

- Emails are sent over SMTP with **STARTTLS** encryption (port 587).
- For Gmail, you may need to use an [App Password](https://support.google.com/accounts/answer/185833) if 2-factor authentication is enabled.
- BCC recipients are included in delivery but their addresses are not visible to `To` or `Cc` recipients.
