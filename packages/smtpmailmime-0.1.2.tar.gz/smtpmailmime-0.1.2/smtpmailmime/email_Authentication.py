import requests
import xml.etree.ElementTree as ET
from email_validator import validate_email, EmailNotValidError
def email_validation(email):
    try:
        # Check that the email address is valid. Turn on check_deliverability
        # for first-time validations like on account creation pages (but not
        # login pages).
        emailinfo = validate_email(email, check_deliverability=False)

        # After this point, use only the normalized form of the email address,
        # especially before going to a database query.
        email = emailinfo.normalized

    except EmailNotValidError as e:

        # The exception message is human-readable explanation of why it's
        # not a valid (or deliverable) email address.
        return str(e)


# Get email provider configuration using Thunderbird's autoconfig service
# if it fails, return None
# else return a dict with imap and smtp server and port
def get_provider_config(domain):
    url = f"https://autoconfig.thunderbird.net/v1.1/{domain}"
    r = requests.get(url)

    if r.status_code != 200:
        return None

    root = ET.fromstring(r.text)

    imap = root.find(".//incomingServer")
    smtp = root.find(".//outgoingServer")

    return {
        "imap": {
            "server": imap.find("hostname").text,
            "port": imap.find("port").text
        },
        "smtp": {
            "server": smtp.find("hostname").text,
            "port": smtp.find("port").text
        }
    }

#print(get_provider_config("icloud.com"))
