from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from pathlib import Path
from smtpmailmime.email_Authentication import email_validation, get_provider_config
class EasyMail:
    def __init__(self):
        self.username = None
        self.password = None
        self._config = None  # store smtp config
    def _validate_credentials(self):
        if not self.username:
            raise RuntimeError("Missing email address")
        if not self.password:
            raise RuntimeError("Missing email password")
        if not self._config:
            self._config = get_provider_config(self.username.split("@")[1])
            if not self._config:
                raise RuntimeError("Unsupported email provider")
    # validate the recipient email address, cc and bcc email address, if there is any invalid email address, raise an error    
    def _validate_email_address(self, email_address,recipient_type):
        if not email_address:
            return
        email_list = [r.strip() for r in email_address.split(",")]
        for email in email_list:
            error = email_validation(email)
            if error:
                if recipient_type == 'Cc':
                    raise RuntimeError(f"Invalid cc email address: {email}, error: {error}")
                if recipient_type == 'Bcc':
                    raise RuntimeError(f"Invalid bcc email address: {email}, error: {error}")
                raise RuntimeError(f"Invalid recipient email address: {email}, error: {error}")
    def sent_email(self,data):
        # sender email address and password
        email_sender = self.username
        email_password = self.password
        sender_stmp_server = self._config["smtp"]["server"]
        sender_stmp_port = self._config["smtp"]["port"]
        msg = MIMEMultipart()
        msg["From"] = email_sender
        if not data.get("To"):
            raise RuntimeError("Missing recipient email address")
        self._validate_email_address(data.get("To"), "To")
        msg["To"] = data.get("To")
        recipient = [r.strip() for r in data.get("To").split(",")]
        # cc
        if data.get("Cc"):
            self._validate_email_address(data.get("Cc"), "Cc")
            msg["Cc"] = data.get("Cc")
            recipient.extend([r.strip() for r in data.get("Cc").split(",")])
        # bcc
        if data.get("Bcc"):
            self._validate_email_address(data.get("Bcc"), "Bcc")
            recipient.extend([r.strip() for r in data.get("Bcc").split(",")])
        # subject
        if not data.get("Subject"):
            msg["Subject"] = "No subject"
        else:
            msg["Subject"] = data.get("Subject")
        # if data.get("body") is not empty string or None, use it as email body, otherwise use default body
        body_type = "html" if data.get("Body_type") == "html" else "plain"
        if data.get("Body"):
            body = MIMEText(data.get("Body"), body_type)
        else:
            body = MIMEText('', 'plain')
        msg.attach(body)
        # if there is an attachment
        if data.get("Attachment"):
            attachement_list = [r.strip() for r in data.get("Attachment").split(",")]
            for attachment in attachement_list:
                attachment_path = Path(attachment) if attachment else None
                if not attachment_path.exists():
                    raise FileNotFoundError(f"{attachment_path} not found")
                with open(attachment_path, "rb") as f:
                    attachment_part = MIMEApplication(
                        f.read(),
                        Name=attachment_path.name
                    )

                attachment_part["Content-Disposition"] = (
                    f'attachment; filename="{attachment_path.name}"'
                )

                msg.attach(attachment_part)

        try:
            with smtplib.SMTP(sender_stmp_server, sender_stmp_port) as server:
                server.starttls()
                server.login(email_sender, email_password)
                server.send_message(msg, to_addrs=recipient)

        except smtplib.SMTPAuthenticationError:
            raise RuntimeError("Invalid email credentials")
        except Exception as e:
            raise RuntimeError(f"Failed to send email: {e}")
    @property
    def sent(self):
        return None
    @sent.setter
    def sent(self, value):
        self._validate_credentials()
        self.sent_email(value)