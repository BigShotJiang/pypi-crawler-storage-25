"""EasyMail - lightweight email sending library."""
from smtpmailmime.main import EasyMail

__all__ = ["EasyMail"]
