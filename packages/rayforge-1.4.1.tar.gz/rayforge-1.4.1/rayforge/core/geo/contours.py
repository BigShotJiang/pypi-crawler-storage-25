from __future__ import annotations
import logging
from typing import List, Tuple, TypedDict, Optional
import numpy as np
from .analysis import (
    get_subpath_area_from_array,
    get_subpath_vertices_from_array,
    is_closed,
)
from .constants import (
    CMD_TYPE_MOVE,
    CMD_TYPE_LINE,
    CMD_TYPE_ARC,
    CMD_TYPE_BEZIER,
    COL_TYPE,
    COL_X,
    COL_Y,
    COL_Z,
    COL_I,
    COL_J,
    COL_CW,
    COL_C1X,
    COL_C1Y,
    COL_C2X,
    COL_C2Y,
)
from .geometry import Geometry
from .primitives import is_point_in_polygon
from .split import split_into_contours
from .types import Point, Rect


class ContourData(TypedDict):
    geo: Geometry
    vertices: List[Point]
    is_closed: bool
    original_index: int


class _NormalizeContourData(TypedDict):
    geo: Geometry
    verts: List[Point]
    rect: Rect
    test_point: Point
    is_closed: bool


logger = logging.getLogger(__name__)


def get_valid_contours_data(
    contour_geometries: List[Geometry],
) -> List[ContourData]:
    """
    Filters degenerate contours and pre-calculates their data.

    This function processes a list of contour geometries and returns a list of
    dictionaries containing pre-calculated data for each valid, closed contour.
    Degenerate contours (empty, too small, or not closed) are filtered out.

    Args:
        contour_geometries: A list of Geometry objects, where each object is
                           assumed to represent a single contour.

    Returns:
        A list of dictionaries, each containing:
        - "geo": The Geometry object for the contour.
        - "vertices": A list of 2D vertices extracted from the contour.
        - "is_closed": Boolean indicating if the contour is closed.
        - "original_index": The index of the contour in the input list.

    Note:
        Only closed contours with a non-zero bounding box area are included
        in the result. The function requires contours to start with a MoveTo
        command and have at least 2 commands.
    """
    contour_data: List[ContourData] = []
    for i, contour_geo in enumerate(contour_geometries):
        if contour_geo.is_empty():
            continue

        data = contour_geo.data
        if (
            data is None
            or data.shape[0] < 2
            or data[0, COL_TYPE] != CMD_TYPE_MOVE
        ):
            continue

        min_x, min_y, max_x, max_y = contour_geo.rect()
        bbox_area = (max_x - min_x) * (max_y - min_y)
        is_closed_flag = is_closed(data) and bbox_area > 1e-9

        if not is_closed_flag:
            continue

        vertices_2d = get_subpath_vertices_from_array(data, 0)

        contour_data.append(
            {
                "geo": contour_geo,
                "vertices": vertices_2d,
                "is_closed": is_closed_flag,
                "original_index": i,
            }
        )
    return contour_data


def reverse_contour(contour: Geometry) -> Geometry:
    """Reverses the direction of a single-contour Geometry object."""
    contour._sync_to_numpy()
    data = contour._data
    if data is None or len(data) == 0:
        return contour.copy()

    if data[0, COL_TYPE] != CMD_TYPE_MOVE:
        return contour.copy()  # Can only reverse single contours

    new_rows = []

    # New path starts at the old path's end
    last_row = data[-1]
    new_rows.append(
        [
            CMD_TYPE_MOVE,
            last_row[COL_X],
            last_row[COL_Y],
            last_row[COL_Z],
            0.0,
            0.0,
            0.0,
            0.0,
        ]
    )
    last_point = last_row[COL_X : COL_Z + 1]

    # Iterate backwards through rows
    for i in range(len(data) - 1, 0, -1):
        end_row = data[i]
        start_row = data[i - 1]
        start_point = start_row[COL_X : COL_Z + 1]
        cmd_type = end_row[COL_TYPE]

        if cmd_type == CMD_TYPE_LINE:
            new_rows.append(
                [
                    CMD_TYPE_LINE,
                    start_point[0],
                    start_point[1],
                    start_point[2],
                    0,
                    0,
                    0,
                    0,
                ]
            )
        elif cmd_type == CMD_TYPE_ARC:
            center_abs_x = start_point[0] + end_row[COL_I]
            center_abs_y = start_point[1] + end_row[COL_J]
            new_offset_x = center_abs_x - last_point[0]
            new_offset_y = center_abs_y - last_point[1]
            new_cw = 1.0 - end_row[COL_CW]  # Flip clockwise flag
            new_rows.append(
                [
                    CMD_TYPE_ARC,
                    start_point[0],
                    start_point[1],
                    start_point[2],
                    new_offset_x,
                    new_offset_y,
                    new_cw,
                    0.0,
                ]
            )
        elif cmd_type == CMD_TYPE_BEZIER:
            # For a reversed bezier P0->(C1,C2)->P1, the new curve is
            # P1->(C2,C1)->P0.
            new_rows.append(
                [
                    CMD_TYPE_BEZIER,
                    start_point[0],
                    start_point[1],
                    start_point[2],
                    end_row[COL_C2X],  # old C2 becomes new C1
                    end_row[COL_C2Y],
                    end_row[COL_C1X],  # old C1 becomes new C2
                    end_row[COL_C1Y],
                ]
            )

        last_point = start_point

    new_geo = Geometry()
    new_geo._data = np.array(new_rows)
    new_geo.last_move_to = (
        new_rows[0][COL_X],
        new_rows[0][COL_Y],
        new_rows[0][COL_Z],
    )
    return new_geo


def split_inner_and_outer_contours(
    contours: List[Geometry],
) -> Tuple[List[Geometry], List[Geometry]]:
    """
    Splits a list of single-contour Geometries into two lists: external
    contours (solids) and internal ones (holes).

    This function robustly partitions the list into two groups based on the
    even-odd fill rule.

    Args:
        contours: A list of Geometry objects, where each object is assumed
                  to represent a single, closed contour.

    Returns:
        A tuple containing two lists: (internal_contours, external_contours).
    """
    if not contours:
        return [], []

    # filter_to_external_contours correctly identifies all contours that are
    # "solid" based on the even-odd rule.
    external_contours = filter_to_external_contours(contours)
    external_set = set(external_contours)

    # All other contours are, by definition, "internal" (holes).
    internal_contours = [c for c in contours if c not in external_set]

    return internal_contours, external_contours


def close_all_contours(geometry: Geometry) -> Geometry:
    """
    Closes all open contours in the given geometry.

    Splits the geometry into individual contours, closes any that are not
    already closed, and returns a new geometry with all contours closed.

    Args:
        geometry: The geometry to process.

    Returns:
        A new Geometry with all contours closed.
    """
    if geometry.is_empty():
        return geometry.copy()

    contours = split_into_contours(geometry)
    if not contours:
        return geometry.copy()

    result = Geometry()
    for contour in contours:
        if not contour.is_closed():
            contour.close_path()
            contour._sync_to_numpy()
        result.extend(contour)

    result.last_move_to = geometry.last_move_to
    return result


def normalize_winding_orders(contours: List[Geometry]) -> List[Geometry]:
    """
    Analyzes a list of contours and enforces the correct winding order
    (CCW for solids, CW for holes) based on their nesting level.

    This is crucial for ensuring that filtering algorithms based on the
    even-odd rule work correctly, especially with vector data from sources
    that do not guarantee winding order.

    Note: Open paths are passed through unchanged since winding order
    only applies to closed contours.
    """
    if not contours:
        return []

    count = len(contours)

    # 1. Pre-calculate data to avoid re-computing per iteration
    # Store: (geometry, start_point_2d, bounding_box, is_closed)
    contour_data: List[Optional[_NormalizeContourData]] = []

    for c in contours:
        if c.is_empty():
            contour_data.append(None)
            continue
        c._sync_to_numpy()  # Ensure data is available
        if c.data is None:
            contour_data.append(None)
            continue
        segments = c.segments()
        if not segments:
            contour_data.append(None)
            continue

        c_is_closed = is_closed(c.data)

        # Get vertices for point-in-poly check
        verts_3d = segments[0]
        verts_2d: List[Point] = [p[:2] for p in verts_3d]

        # Get Bounding Box (min_x, min_y, max_x, max_y)
        rect = c.rect()

        # We only need one test point to determine nesting
        test_point = verts_2d[0]

        contour_data.append(
            {
                "geo": c,
                "verts": verts_2d,
                "rect": rect,
                "test_point": test_point,
                "is_closed": c_is_closed,
            }
        )

    normalized_contours: List[Geometry] = []

    for i in range(count):
        current = contour_data[i]
        if current is None:
            continue

        # Open paths pass through unchanged - winding order only
        # matters for closed contours (fill vs hole determination)
        if not current["is_closed"]:
            normalized_contours.append(current["geo"])
            continue

        nesting_level = 0
        tx, ty = current["test_point"]

        # Optimization: Filter candidates by Bounding Box first
        # We check if 'current' is inside 'other'
        # Only check against CLOSED contours for nesting
        # Open paths cannot contain other paths
        for j in range(count):
            if i == j:
                continue

            other = contour_data[j]
            if other is None or not other["is_closed"]:
                continue

            # Bounding Box Check:
            # If current.x is outside other.bbox, it strictly cannot be
            # inside other.
            o_min_x, o_min_y, o_max_x, o_max_y = other["rect"]

            if tx < o_min_x or tx > o_max_x or ty < o_min_y or ty > o_max_y:
                continue

            # Detailed Check:
            # Use the raw point-in-polygon test
            if is_point_in_polygon(current["test_point"], other["verts"]):
                nesting_level += 1

        current_data = current["geo"].data
        if current_data is None:
            continue
        signed_area = get_subpath_area_from_array(current_data, 0)
        is_ccw = signed_area > 0
        is_nested_odd = nesting_level % 2 != 0

        # An outer shape (even nesting) should be CCW.
        # A hole (odd nesting) should be CW.
        # If the current state is wrong, reverse the contour.
        if (is_nested_odd and is_ccw) or (not is_nested_odd and not is_ccw):
            normalized_contours.append(reverse_contour(current["geo"]))
        else:
            normalized_contours.append(current["geo"])

    return normalized_contours


def filter_to_external_contours(contours: List[Geometry]) -> List[Geometry]:
    """
    Filters a list of single-contour geometries, returning only those
    that represent external paths (i.e., solid filled areas).

    This function is robust to the initial winding order of the input contours.
    It automatically normalizes all paths according to the even-odd fill rule
    and returns only the contours that represent solid material (those with
    a final CCW winding order).

    Args:
        contours: A list of Geometry objects, where each object is assumed
                  to represent a single, closed contour.

    Returns:
        A new list of Geometry objects containing only the external contours.
    """
    if not contours:
        return []

    # First, ensure all winding orders are correct relative to each other.
    normalized_contours = normalize_winding_orders(contours)

    # After normalization, any "external" or "solid" area will have a CCW
    # winding order (positive area). Holes will be CW (negative area).
    # We simply need to keep the CCW ones.
    final_contours = []
    for c in normalized_contours:
        c._sync_to_numpy()
        data = c.data
        if data is not None and get_subpath_area_from_array(data, 0) > 1e-9:
            final_contours.append(c)
    return final_contours


def remove_inner_edges(geometry: Geometry) -> Geometry:
    """
    Filters a geometry, keeping all open paths and only the external-most
    closed paths (contours).

    This function first splits the input geometry into individual contours.
    It then separates these contours into two groups: open paths and closed
    paths. The closed paths are filtered to remove any inner contours (holes),
    and finally, the remaining external closed paths are recombined with the
    original open paths into a new Geometry object.

    Args:
        geometry: The input Geometry object to filter.

    Returns:
        A new Geometry object containing only the external contours and all
        original open paths.
    """
    if geometry.is_empty():
        return Geometry()

    all_contours = split_into_contours(geometry)
    if not all_contours:
        return Geometry()

    closed_contours: List[Geometry] = []
    open_contours: List[Geometry] = []

    for contour in all_contours:
        # Use a reasonably small tolerance for checking if a path is closed.
        if contour.is_closed(tolerance=1e-6):
            closed_contours.append(contour)
        else:
            open_contours.append(contour)

    # Filter the closed contours to get only the external ones
    external_closed_contours = filter_to_external_contours(closed_contours)

    # Reassemble the final geometry
    final_geo = Geometry()
    for contour in external_closed_contours:
        final_geo.extend(contour)
    for contour in open_contours:
        final_geo.extend(contour)

    # Preserve the last_move_to from the original, as it's the most
    # sensible value, although its direct relevance might be diminished.
    final_geo.last_move_to = geometry.last_move_to

    return final_geo
