# src/py_async_log/core.py
import logging
import logging.handlers
import multiprocessing
from pathlib import Path
from typing import Optional

# --- 模块级全局变量，模块变量法；
# 模块级全局变量在 Python 中是天然且最正宗的单例模式
# 在 Python 的设计哲学里，模块（Module）本身就是对象，而且它们在同一个进程中只会被加载和执行一次。
# 运行模块代码，并将生成的对象、函数和变量放入一个缓存字典中（即 sys.modules） ---
_instance = None
_defalut_log_format = "%(asctime)s %(processName)s(%(process)d) %(threadName)s[%(thread)d] %(filename)s[line:%(lineno)d] %(levelname)s %(message)s"
_date_fmt = "%Y-%m-%d %H:%M:%S"


def _worker_configurer_internal(queue, level):
    h = logging.handlers.QueueHandler(queue)
    root = logging.getLogger()
    root.handlers.clear()  # 清除旧的handler
    root.addHandler(h)
    root.setLevel(level)


class AsyncLogManager:
    """Python 类中的构造函数,初始化异步日志管理器,默认使用无界队列"""

    def __init__(
        self,
        filename: str,
        level: int = logging.INFO,
        max_queue_size: int = -1,
        max_bytes: int = 10 * 1024 * 1024,
        backup_count: int = 100,
        log_format: str = _defalut_log_format,
    ):
        self.check_log_dir(filename)
        self._level = level
        self._manager = multiprocessing.Manager()
        self._queue = self._manager.Queue(max_queue_size)
        # Optional来自Python的typing模块，用于类型标注（Type Hints）。未来会存储一个QueueListener类型的对象。
        # QueueListener是一个后台守护线程，用于处理队列中的日志记录
        self._listener: Optional[logging.handlers.QueueListener] = None
        self._maxBytes = max_bytes
        self._backupCount = backup_count
        self._log_format = log_format

    def check_log_dir(self, filename: str):
        """
        检查并创建日志目录，兼容跨平台。
        返回：str 格式的完整绝对路径（包含文件名）
        """
        try:
            if filename.strip() == "":
                filename = "app.log"
            # 1. 将传入的字符串转换为 Path 对象
            path_obj = Path(filename)

            # 2. 判断逻辑：如果没有父级目录（即只传了文件名 'app.log'）
            if path_obj.parent == Path("."):
                # 在当前目录下创建 logs 文件夹，并拼接文件名
                # 结果类似于：logs/app.log (Linux) 或 logs\app.log (Windows)
                final_path = Path("logs") / path_obj.name
            else:
                # 如果用户传了 'data/logs/app.log'，则直接使用
                final_path = path_obj

            # 3. 创建目录
            # parents=True: 相当于 makedirs，如果父目录不存在也会一并创建
            # exist_ok=True: 如果目录已存在，不会抛出异常
            final_path.parent.mkdir(parents=True, exist_ok=True)

            # 转换为绝对路径
            self._filename = str(final_path.absolute())
        except Exception as err:
            logging.error("check_log_dir error,%s", str(err))

    def start_logging(self):
        """在主进程中启动监听器"""
        # 配置主进程的最终写入方式
        handlers = []

        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(self._log_format))
        handlers.append(console_handler)

        file_handler = logging.handlers.RotatingFileHandler(
            filename=self._filename,
            maxBytes=self._maxBytes,
            backupCount=self._backupCount,
            encoding="utf-8",
            delay=True,  # 延迟打开文件，避免在进程启动时立即打开文件
        )
        file_handler.setFormatter(logging.Formatter(self._log_format))
        handlers.append(file_handler)

        # 启动监听名为QueueListener守护线程,用于处理队列中的日志记录
        # *称为拆包运算符（Unpacking Operator），将一个**列表（List）或元组（Tuple）**中的元素解开，作为独立的参数传递给函数。
        # respect_handler_level为不同Handler设置的level能够真正生效。
        self._listener = logging.handlers.QueueListener(
            self._queue, *handlers, respect_handler_level=True
        )
        self._listener.start()
        logging.info("AsyncLogManager start logging, log file path: %s", self._filename)

    def get_worker_config_args(self):
        """返回子进程初始化所需的参数包"""
        # 不返回函数，而是返回 (函数, 参数) 的元组，或者只返回参数
        return _worker_configurer_internal, (self._queue, self._level)

    def stop_logging(self):
        if self._listener:
            self._listener.stop()
        self._manager.shutdown()  # 显式关闭 Manager


# --- 显式的单例获取函数，模块变量法 (推荐Explicit is better than implicit 显式优于隐式) ---
def get_manager(
    filename: str = "app.log",
    level: int = logging.INFO,
    max_queue_size: int = -1,
    max_bytes: int = 10 * 1024 * 1024,
    backup_count: int = 100,
) -> AsyncLogManager:
    """显式的单例获取函数"""
    global _instance
    if _instance is None:
        _instance = AsyncLogManager(
            filename, level, max_queue_size, max_bytes, backup_count
        )
    return _instance
