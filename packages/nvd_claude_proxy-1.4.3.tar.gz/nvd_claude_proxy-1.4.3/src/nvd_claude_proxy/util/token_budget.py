from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class TokenBudgetResult:
    max_tokens: int
    thinking_budget_tokens: int
    was_raised_for_thinking: bool = False
    was_clamped_for_hard_cap: bool = False
    was_clamped_for_model_output: bool = False
    was_clamped_for_context: bool = False


class TokenBudgetError(ValueError):
    pass


def extract_thinking_budget_tokens(thinking: Any) -> int:
    if not isinstance(thinking, dict):
        return 0
    raw = thinking.get("budget_tokens")
    if raw is None:
        return 0
    try:
        budget = int(raw)
    except (TypeError, ValueError):
        return 0
    return max(0, budget)


def resolve_max_tokens(
    *,
    requested_max_tokens: int | None,
    default_max_tokens: int,
    hard_max_tokens: int,
    model_max_output: int,
    model_context_window: int,
    estimated_input_tokens: int,
    thinking: Any,
    context_headroom: int,
    min_output_tokens: int,
) -> TokenBudgetResult:
    thinking_budget = extract_thinking_budget_tokens(thinking)
    current = int(requested_max_tokens) if requested_max_tokens is not None else int(default_max_tokens)
    current = max(1, current)

    was_raised_for_thinking = False
    if thinking_budget and current <= thinking_budget:
        current = thinking_budget + 1
        was_raised_for_thinking = True

    before_hard = current
    current = min(current, int(hard_max_tokens))
    was_clamped_for_hard_cap = current != before_hard

    before_model = current
    current = min(current, int(model_max_output))
    was_clamped_for_model_output = current != before_model

    # Thinking budget overrides hard cap and model output clamp
    if thinking_budget and current <= thinking_budget:
        current = thinking_budget + 1
        # Re-apply model_max_output only if it's higher than the forced value
        if int(model_max_output) > current:
            current = min(current, int(model_max_output))
        was_clamped_for_hard_cap = True
        was_raised_for_thinking = True

    context_budget = int(model_context_window) - int(estimated_input_tokens) - int(context_headroom)
    if context_budget < int(min_output_tokens):
        context_budget = int(model_context_window) - int(estimated_input_tokens)

    if context_budget <= 0:
        raise TokenBudgetError(
            f"Estimated input tokens ({estimated_input_tokens}) leave no output room in "
            f"context window ({model_context_window})."
        )

    before_context = current
    current = min(current, context_budget)
    was_clamped_for_context = current != before_context

    if thinking_budget and current <= thinking_budget:
        raise TokenBudgetError(
            "Cannot satisfy Anthropic requirement max_tokens > thinking.budget_tokens: "
            f"max_tokens={current}, thinking.budget_tokens={thinking_budget}, "
            f"estimated_input_tokens={estimated_input_tokens}, context_window={model_context_window}."
        )

    current = max(int(min_output_tokens), current)
    if thinking_budget and current <= thinking_budget:
        raise TokenBudgetError(
            "Cannot satisfy Anthropic requirement max_tokens > thinking.budget_tokens after min-output floor."
        )

    return TokenBudgetResult(
        max_tokens=int(current),
        thinking_budget_tokens=thinking_budget,
        was_raised_for_thinking=was_raised_for_thinking,
        was_clamped_for_hard_cap=was_clamped_for_hard_cap,
        was_clamped_for_model_output=was_clamped_for_model_output,
        was_clamped_for_context=was_clamped_for_context,
    )