"""nvd-claude-proxy: Anthropic Messages ↔ NVIDIA NIM proxy."""

from ._version import __version__ as __version__
