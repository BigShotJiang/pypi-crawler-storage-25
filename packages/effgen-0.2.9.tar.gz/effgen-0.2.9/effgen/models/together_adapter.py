"""
Together AI SDK adapter for effGen.

Supports all Together AI chat models with built-in rate-limit coordination,
real streaming via SSE, native function-calling on supported models, and
per-request cost tracking via CostTracker.

Together AI uses an OpenAI-compatible API shape (chat.completions.create),
so the implementation mirrors GroqAdapter closely with Together-specific
rate limits and the serverless/dedicated-endpoint distinction.
"""

from __future__ import annotations

import json
import logging
import os
import random
import time
from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from effgen.models._cost import CostTracker
from effgen.models._multimodal import require_vision_support
from effgen.models._rate_limit import RateLimitCoordinator
from effgen.models.base import (
    BaseModel,
    GenerationConfig,
    GenerationResult,
    TokenCount,
)
from effgen.models.errors import ModelAuthError, ModelNotFoundError
from effgen.models.latency_tracker import timed_call
from effgen.models.together_models import (
    TOGETHER_DEFAULT_MODEL,
    TOGETHER_MODELS,
    available_models,
    serverless_models,
)
from effgen.observability.spans import ModelAttrs
from effgen.observability.tracing import set_span_attribute as _set_span_attr

if TYPE_CHECKING:
    from effgen.models._rate_limit_store import SQLiteRateLimitStore

logger = logging.getLogger(__name__)

_TOGETHER_MODEL_TYPE_VALUE = "together"


class _TogetherModelType:
    """Sentinel so ModelType enum doesn't need patching."""
    value = _TOGETHER_MODEL_TYPE_VALUE


class TogetherAdapter(BaseModel):
    """
    Adapter for Together AI inference API.

    Wraps the ``together`` SDK with the standard effGen BaseModel interface.
    Together mirrors the OpenAI API shape. Supports:

    - Synchronous and async generation
    - Real token-by-token streaming (``generate_stream``)
    - Native function-calling on supported models (``generate_with_tools``)
    - Per-request cost tracking via :class:`~effgen.models._cost.CostTracker`
    - Per-model rate-limit coordination (RPM, TPM)
    - Automatic warning when non-serverless models are used

    Args:
        model_name: Together model ID. Must be a key in
            :data:`~effgen.models.together_models.TOGETHER_MODELS`.
            Defaults to ``"meta-llama/Meta-Llama-3-8B-Instruct-Lite"``.
        api_key: Together API key. If omitted, reads ``TOGETHER_API_KEY``
            from the environment.
        max_retries: Maximum number of SDK retry attempts.
        timeout: Per-request timeout in seconds.
        enable_rate_limiting: Wire built-in
            :class:`~effgen.models._rate_limit.RateLimitCoordinator`.
        enable_cost_tracking: Record token usage in the global
            :class:`~effgen.models._cost.CostTracker`.

    Example::

        from effgen.models.together_adapter import TogetherAdapter

        adapter = TogetherAdapter("meta-llama/Llama-3.3-70B-Instruct-Turbo")
        adapter.load()

        result = adapter.generate("What is the capital of France?")
        print(result.text)

        for chunk in adapter.generate_stream("Count from 1 to 5."):
            print(chunk, end="", flush=True)

        adapter.unload()
    """

    def __init__(
        self,
        model_name: str = TOGETHER_DEFAULT_MODEL,
        api_key: str | None = None,
        max_retries: int = 3,
        timeout: int = 60,
        enable_rate_limiting: bool = True,
        enable_cost_tracking: bool = True,
        rate_limit_storage: "SQLiteRateLimitStore | None" = None,
        **kwargs: Any,
    ) -> None:
        if model_name not in TOGETHER_MODELS:
            raise ModelNotFoundError(
                provider="together",
                model_name=model_name,
                message=f"Unknown Together model '{model_name}'. "
                        f"Available: {available_models()}\n"
                        f"Serverless (no dedicated endpoint): {serverless_models()}",
            )

        info = TOGETHER_MODELS[model_name]

        # Warn if model requires a dedicated endpoint
        if not info.get("serverless", False):
            logger.warning(
                "Together model '%s' may require a dedicated endpoint. "
                "If you get a 400 error, start the endpoint at "
                "https://api.together.ai/models/%s",
                model_name, model_name,
            )

        super().__init__(
            model_name=model_name,
            model_type=_TogetherModelType(),  # type: ignore[arg-type]
            context_length=info.get("context", 131_072),
        )
        self._api_key = api_key
        self.max_retries = max_retries
        self.timeout = timeout
        self._extra_kwargs = kwargs
        self._client: Any = None
        self._enable_cost_tracking = enable_cost_tracking

        self._rate_limiter: RateLimitCoordinator | None = None
        if enable_rate_limiting:
            self._rate_limiter = RateLimitCoordinator(
                provider="together",
                model=model_name,
                rpm=info.get("rpm", 100),
                rph=info.get("rpm", 100) * 60,
                rpd=100_000,
                tpm=info.get("tpm", 100_000),
                tph=info.get("tpm", 100_000) * 60,
                tpd=10_000_000,
                storage=rate_limit_storage,
            )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Instantiate the Together SDK client.

        Raises:
            RuntimeError: If ``together`` is not installed.
            ValueError: If no API key is available.
        """
        try:
            from together import Together
        except ImportError as exc:
            raise RuntimeError(
                "together SDK is not installed. "
                "Install with: pip install 'effgen[together]'"
            ) from exc

        if not (self._api_key or os.getenv("TOGETHER_API_KEY")):
            raise ValueError(
                "Together API key not found. Set the TOGETHER_API_KEY "
                "environment variable or pass api_key= to TogetherAdapter."
            )

        self._client = Together(
            api_key=self._api_key or os.getenv("TOGETHER_API_KEY"),
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self._is_loaded = True

        info = TOGETHER_MODELS.get(self.model_name, {})
        self._metadata = {
            "model_name": self.model_name,
            "context_length": self.get_context_length(),
            "provider": "together",
            "family": info.get("family", ""),
            "organization": info.get("organization", ""),
            "modality": info.get("modality", "chat"),
            "supports_native_tools": info.get("supports_native_tools", False),
            "supports_streaming": info.get("supports_streaming", True),
            "serverless": info.get("serverless", False),
            "pricing_per_1m_input": info.get("pricing_per_1m_input", 0),
            "pricing_per_1m_output": info.get("pricing_per_1m_output", 0),
            "rpm": info.get("rpm"),
            "tpm": info.get("tpm"),
        }
        logger.info("TogetherAdapter loaded for model '%s'", self.model_name)

    def unload(self) -> None:
        """Release SDK client resources."""
        self._client = None
        self._is_loaded = False
        logger.info("TogetherAdapter unloaded")

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def generate(
        self,
        prompt: str,
        config: GenerationConfig | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate a response synchronously via the Together AI API.

        Args:
            prompt: User prompt text.
            config: Optional generation config.
            **kwargs: Forwarded to ``chat.completions.create``.

        Returns:
            GenerationResult with text and token usage.
        """
        import asyncio

        if not self._is_loaded or self._client is None:
            raise RuntimeError("TogetherAdapter not loaded. Call load() first.")

        if config is None:
            config = GenerationConfig()

        require_vision_support(
            prompt,
            provider="together",
            model_name=self.model_name,
            supports_vision=TOGETHER_MODELS.get(self.model_name, {}).get("supports_vision", False),
            hint="Use a Together model with supports_vision=True for image inputs.",
        )

        try:
            prompt_text = prompt if isinstance(prompt, str) else str(getattr(prompt, "text", prompt))
            est_tokens = self.count_tokens(prompt_text).count + (config.max_tokens or 500)
        except Exception:
            est_tokens = 500

        if self._rate_limiter is not None:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    logger.debug("Skipping blocking rate-limit acquire (nested event loop)")
                else:
                    loop.run_until_complete(self._rate_limiter.acquire(est_tokens))
            except RuntimeError:
                asyncio.run(self._rate_limiter.acquire(est_tokens))

        with timed_call("together", self.model_name):
            result = self._do_generate(prompt, config, **kwargs)

        if self._rate_limiter is not None:
            actual = result.metadata.get("total_tokens", 0) if result.metadata else 0
            self._rate_limiter.record(actual)

        return result

    async def async_generate(
        self,
        prompt: str,
        config: GenerationConfig | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Async version of :meth:`generate` — preferred inside async contexts."""
        if not self._is_loaded or self._client is None:
            raise RuntimeError("TogetherAdapter not loaded. Call load() first.")

        if config is None:
            config = GenerationConfig()

        require_vision_support(
            prompt,
            provider="together",
            model_name=self.model_name,
            supports_vision=TOGETHER_MODELS.get(self.model_name, {}).get("supports_vision", False),
            hint="Use a Together model with supports_vision=True for image inputs.",
        )

        try:
            prompt_text = prompt if isinstance(prompt, str) else str(getattr(prompt, "text", prompt))
            est_tokens = self.count_tokens(prompt_text).count + (config.max_tokens or 500)
        except Exception:
            est_tokens = 500

        if self._rate_limiter is not None:
            await self._rate_limiter.acquire(est_tokens)

        result = self._do_generate(prompt, config, **kwargs)

        if self._rate_limiter is not None:
            actual = result.metadata.get("total_tokens", 0) if result.metadata else 0
            self._rate_limiter.record(actual)

        return result

    @staticmethod
    def _message_to_together(message: Any) -> dict[str, Any]:
        """Convert an effGen Message to a Together/OpenAI-compatible dict."""
        import base64

        from effgen.core.messages import ImagePart, TextPart, VideoPart
        from effgen.multimodal.image_pre import prepare as _preprocess_image

        role = message.role.value
        content_parts: list[dict[str, Any]] = []

        for part in message.content:
            if isinstance(part, TextPart):
                content_parts.append({"type": "text", "text": part.text})
            elif isinstance(part, ImagePart):
                processed = _preprocess_image(part, "together", "")
                b64 = base64.b64encode(processed.image).decode()
                content_parts.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{processed.mime};base64,{b64}"},
                })
            elif isinstance(part, VideoPart):
                for frame in part.frames:
                    b64 = base64.b64encode(frame).decode()
                    content_parts.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:{part.mime};base64,{b64}"},
                    })

        if len(content_parts) == 1 and content_parts[0].get("type") == "text":
            return {"role": role, "content": content_parts[0]["text"]}
        return {"role": role, "content": content_parts}

    def _do_generate(
        self,
        prompt: str,
        config: GenerationConfig,
        tools: list[dict[str, Any]] | None = None,
        messages: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Internal: make the SDK call and return a GenerationResult."""
        if messages is None:
            try:
                from effgen.core.messages import Message
                if isinstance(prompt, Message):
                    messages = [self._message_to_together(prompt)]
                elif isinstance(prompt, list) and prompt and isinstance(prompt[0], Message):
                    messages = [self._message_to_together(m) for m in prompt]
                else:
                    messages = [{"role": "user", "content": prompt}]
            except ImportError:
                messages = [{"role": "user", "content": prompt}]

        request_params: dict[str, Any] = {
            "model": self.model_name,
            "messages": messages,
        }

        if config.temperature is not None and config.temperature != 0.7:
            request_params["temperature"] = config.temperature
        if config.top_p is not None and config.top_p != 0.9:
            request_params["top_p"] = config.top_p
        if config.max_tokens is not None:
            request_params["max_tokens"] = config.max_tokens
        if config.stop_sequences:
            request_params["stop"] = config.stop_sequences
        if config.seed is not None:
            request_params["seed"] = config.seed

        info = TOGETHER_MODELS.get(self.model_name, {})
        if tools and info.get("supports_native_tools", False):
            openai_tools = []
            for t in tools:
                if isinstance(t, dict):
                    openai_tools.append(t if "type" in t else {"type": "function", "function": t})
                else:
                    openai_tools.append({"type": "function", "function": t.metadata.to_json_schema()})
            request_params["tools"] = openai_tools
            request_params["tool_choice"] = "auto"

        request_params.update(kwargs)

        _MAX_RETRIES = max(1, self.max_retries)
        _last_exc: Exception | None = None
        for _attempt in range(1, _MAX_RETRIES + 1):
            try:
                response = self._client.chat.completions.create(**request_params)
                break
            except Exception as exc:
                _last_exc = exc
                msg = str(exc)
                msg_lower = msg.lower()

                is_auth = (
                    "401" in msg
                    or "403" in msg
                    or "invalid_api_key" in msg_lower
                    or "invalid api key" in msg_lower
                    or "unauthorized" in msg_lower
                    or "authentication" in msg_lower
                )
                if is_auth:
                    raise ModelAuthError(
                        provider="together",
                        model_name=self.model_name,
                        message=msg,
                    ) from exc

                # Non-serverless model — dedicated endpoint not running
                is_endpoint_error = (
                    "model_not_available" in msg_lower
                    or "dedicated_endpoint_not_running" in msg_lower
                    or "unable to access non-serverless" in msg_lower
                    or "dedicated endpoint" in msg_lower
                )
                if is_endpoint_error:
                    raise RuntimeError(
                        f"Together model '{self.model_name}' requires a dedicated endpoint "
                        f"that is not running. Start it at "
                        f"https://api.together.ai/models/{self.model_name} or use a "
                        f"serverless model: {serverless_models()}"
                    ) from exc

                is_rate = "429" in msg or "rate_limit" in msg_lower or "rate limit" in msg_lower
                is_server = "500" in msg or "503" in msg or "internal" in msg_lower
                is_timeout = "timeout" in msg_lower

                if is_rate:
                    from effgen.models._rate_limit import RateLimitExceeded as _RLE

                    raise _RLE(
                        f"Together rate limit hit for {self.model_name}: {msg}"
                    ) from exc

                if is_server or is_timeout:
                    if _attempt >= _MAX_RETRIES:
                        logger.error("Together API error after %d retries: %s", _attempt, exc)
                        if is_timeout:
                            from effgen.models.errors import ModelTimeoutError as _MTE

                            raise _MTE(
                                provider="together",
                                model_name=self.model_name,
                                timeout_seconds=self.timeout,
                            ) from exc
                        from effgen.models.errors import ProviderTransientError as _PTE

                        raise _PTE(
                            provider="together",
                            model_name=self.model_name,
                            status_code=500,
                            message=f"Together API failed after {_MAX_RETRIES} retries: {exc}",
                        ) from exc
                    delay = min(60.0, 2.0 * (2 ** (_attempt - 1)) + random.uniform(0, 0.5))
                    logger.warning(
                        "Together transient error on attempt %d/%d — retrying in %.1fs: %s",
                        _attempt, _MAX_RETRIES, delay, exc,
                    )
                    time.sleep(delay)
                    continue

                logger.error("Together API call failed: %s", exc)
                raise RuntimeError(f"Together generation failed: {exc}") from exc
        else:
            assert _last_exc is not None
            raise RuntimeError(
                f"Together generation failed after {_MAX_RETRIES} retries: {_last_exc}"
            ) from _last_exc

        choice = response.choices[0]
        message = choice.message
        text = message.content or ""
        finish_reason = choice.finish_reason or "stop"

        usage = response.usage
        prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
        completion_tokens = getattr(usage, "completion_tokens", 0) or 0
        total_tokens = getattr(usage, "total_tokens", prompt_tokens + completion_tokens) or 0

        tool_calls: list[dict[str, Any]] = []
        if hasattr(message, "tool_calls") and message.tool_calls:
            for tc in message.tool_calls:
                try:
                    arguments = tc.function.arguments
                    if isinstance(arguments, str):
                        arguments = json.loads(arguments)
                except (json.JSONDecodeError, AttributeError):
                    arguments = {}
                tool_calls.append({
                    "id": getattr(tc, "id", ""),
                    "type": getattr(tc, "type", "function"),
                    "function": {
                        "name": tc.function.name,
                        "arguments": arguments,
                    },
                })

        cost = 0.0
        if self._enable_cost_tracking:
            cost = CostTracker.get().record(
                provider="together",
                model=self.model_name,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
            )

        logger.info(
            "Together generated %d tokens (prompt=%d, completion=%d, cost=$%.6f)",
            total_tokens, prompt_tokens, completion_tokens, cost,
        )
        _set_span_attr(ModelAttrs.PROVIDER, "together")
        _set_span_attr(ModelAttrs.NAME, self.model_name)
        _set_span_attr(ModelAttrs.INPUT_TOKENS, prompt_tokens)
        _set_span_attr(ModelAttrs.OUTPUT_TOKENS, completion_tokens)
        _set_span_attr(ModelAttrs.COST_USD, float(cost))
        _set_span_attr(ModelAttrs.OUTCOME, "ok")

        return GenerationResult(
            text=text,
            tokens_used=completion_tokens,
            finish_reason=finish_reason,
            model_name=self.model_name,
            metadata={
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
                "provider": "together",
                "cost_usd": cost,
                "tool_calls": tool_calls,
            },
        )

    def generate_with_tools(
        self,
        prompt: str,
        tools: list[dict[str, Any]],
        messages: list[dict[str, Any]] | None = None,
        config: GenerationConfig | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate with native tool calling (OpenAI function-calling format).

        Args:
            prompt: User prompt text (ignored when *messages* is provided).
            tools: List of OpenAI-format tool dicts or effGen BaseTool objects.
            messages: Optional full conversation history (overrides *prompt*).
            config: Optional generation config.

        Returns:
            GenerationResult whose ``metadata["tool_calls"]`` contains parsed calls.
        """
        if not self._is_loaded or self._client is None:
            raise RuntimeError("TogetherAdapter not loaded. Call load() first.")
        if config is None:
            config = GenerationConfig()
        return self._do_generate(prompt, config, tools=tools, messages=messages, **kwargs)

    def generate_stream(
        self,
        prompt: str,
        config: GenerationConfig | None = None,
        **kwargs: Any,
    ) -> Iterator[str]:
        """Stream a response token-by-token from the Together AI API.

        Yields:
            str: Successive text chunks from the model.
        """
        if not self._is_loaded or self._client is None:
            raise RuntimeError("TogetherAdapter not loaded. Call load() first.")

        if config is None:
            config = GenerationConfig()

        require_vision_support(
            prompt,
            provider="together",
            model_name=self.model_name,
            supports_vision=TOGETHER_MODELS.get(self.model_name, {}).get("supports_vision", False),
            hint="Use a Together model with supports_vision=True for image inputs.",
        )

        try:
            from effgen.core.messages import Message

            if isinstance(prompt, Message):
                messages = [self._message_to_together(prompt)]
            elif isinstance(prompt, list) and prompt and isinstance(prompt[0], Message):
                messages = [self._message_to_together(m) for m in prompt]
            else:
                messages = [{"role": "user", "content": prompt}]
        except ImportError:
            messages = [{"role": "user", "content": prompt}]
        request_params: dict[str, Any] = {
            "model": self.model_name,
            "messages": messages,
            "stream": True,
        }

        if config.temperature is not None and config.temperature != 0.7:
            request_params["temperature"] = config.temperature
        if config.top_p is not None and config.top_p != 0.9:
            request_params["top_p"] = config.top_p
        if config.max_tokens is not None:
            request_params["max_tokens"] = config.max_tokens
        if config.stop_sequences:
            request_params["stop"] = config.stop_sequences
        if config.seed is not None:
            request_params["seed"] = config.seed

        request_params.update(kwargs)

        self._last_stream_tool_calls: list[dict[str, Any]] = []
        self._last_stream_finish_reason: str | None = None

        try:
            with timed_call("together", self.model_name) as _stream_timer:
                _first_token = True
                stream = self._client.chat.completions.create(**request_params)

                prompt_tokens = 0
                completion_tokens = 0
                tool_calls_buf: dict[int, dict[str, Any]] = {}

                for chunk in stream:
                    if not chunk.choices:
                        continue
                    choice = chunk.choices[0]
                    delta = choice.delta
                    if delta and delta.content:
                        if _first_token:
                            _stream_timer.mark_first_token()
                            _first_token = False
                        yield delta.content

                    if delta and getattr(delta, "tool_calls", None):
                        for tc in delta.tool_calls:
                            idx = tc.index if getattr(tc, "index", None) is not None else 0
                            buf = tool_calls_buf.setdefault(
                                idx, {"id": "", "type": "function",
                                      "function": {"name": "", "arguments": ""}}
                            )
                            if getattr(tc, "id", None):
                                buf["id"] = tc.id
                            fn = getattr(tc, "function", None)
                            if fn is not None:
                                if getattr(fn, "name", None):
                                    buf["function"]["name"] = fn.name
                                if getattr(fn, "arguments", None):
                                    buf["function"]["arguments"] += fn.arguments

                    if choice.finish_reason:
                        self._last_stream_finish_reason = choice.finish_reason

                    if hasattr(chunk, "usage") and chunk.usage is not None:
                        usage = chunk.usage
                        prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
                        completion_tokens = getattr(usage, "completion_tokens", 0) or 0

                finalized: list[dict[str, Any]] = []
                for _idx, buf in sorted(tool_calls_buf.items()):
                    raw_args = buf["function"]["arguments"]
                    try:
                        parsed_args = json.loads(raw_args) if raw_args else {}
                    except (json.JSONDecodeError, TypeError):
                        parsed_args = {}
                    finalized.append({
                        "id": buf["id"],
                        "type": buf["type"],
                        "function": {
                            "name": buf["function"]["name"],
                            "arguments": parsed_args,
                        },
                    })
                self._last_stream_tool_calls = finalized

            if self._enable_cost_tracking and (prompt_tokens or completion_tokens):
                CostTracker.get().record(
                    provider="together",
                    model=self.model_name,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                )

        except Exception as exc:
            msg = str(exc)
            msg_lower = msg.lower()
            if (
                "401" in msg
                or "403" in msg
                or "invalid_api_key" in msg_lower
                or "invalid api key" in msg_lower
                or "unauthorized" in msg_lower
                or "authentication" in msg_lower
            ):
                raise ModelAuthError(
                    provider="together",
                    model_name=self.model_name,
                    message=msg,
                ) from exc
            if (
                "model_not_available" in msg_lower
                or "dedicated_endpoint_not_running" in msg_lower
                or "unable to access non-serverless" in msg_lower
            ):
                raise RuntimeError(
                    f"Together model '{self.model_name}' requires a dedicated endpoint. "
                    f"Start it at https://api.together.ai/models/{self.model_name} "
                    f"or use a serverless model: {serverless_models()}"
                ) from exc
            if "429" in msg or "rate_limit" in msg_lower or "rate limit" in msg_lower:
                from effgen.models._rate_limit import RateLimitExceeded as _RLE

                raise _RLE(f"Together rate limit hit for {self.model_name}: {msg}") from exc
            if "timeout" in msg_lower:
                from effgen.models.errors import ModelTimeoutError as _MTE

                raise _MTE(
                    provider="together",
                    model_name=self.model_name,
                    timeout_seconds=self.timeout,
                ) from exc
            if "500" in msg or "503" in msg or "internal" in msg_lower:
                from effgen.models.errors import ProviderTransientError as _PTE

                raise _PTE(
                    provider="together",
                    model_name=self.model_name,
                    status_code=500,
                    message=msg,
                ) from exc
            logger.error("Together streaming failed: %s", exc)
            raise RuntimeError(f"Together streaming failed: {exc}") from exc

    # ------------------------------------------------------------------
    # Token counting / context length
    # ------------------------------------------------------------------

    def count_tokens(self, text: str) -> TokenCount:
        """Estimate token count via tiktoken (cl100k_base)."""
        try:
            import tiktoken
            enc = tiktoken.get_encoding("cl100k_base")
            count = len(enc.encode(text))
        except Exception:
            count = max(1, len(text) // 4)
        return TokenCount(count=count, model_name=self.model_name)

    def get_context_length(self) -> int:
        """Return the context window size for the loaded model."""
        return TOGETHER_MODELS.get(self.model_name, {}).get("context", 131_072)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def rate_limit_status(self) -> dict[str, Any]:
        """Return current rate-limit window status from the coordinator."""
        if self._rate_limiter is None:
            return {"enabled": False}
        return {"enabled": True, "status": str(self._rate_limiter)}

    @property
    def supports_native_tools(self) -> bool:
        """True if this model supports OpenAI-format function calling."""
        return TOGETHER_MODELS.get(self.model_name, {}).get("supports_native_tools", False)

    def supports_tool_calling(self) -> bool:
        """Return True if the loaded model supports native tool-calling."""
        return TOGETHER_MODELS.get(self.model_name, {}).get("supports_native_tools", False)

    def supports_function_calling(self) -> bool:
        """Alias for :meth:`supports_tool_calling`."""
        return self.supports_tool_calling()

    @property
    def supports_streaming(self) -> bool:
        """True if this model supports streaming responses."""
        return TOGETHER_MODELS.get(self.model_name, {}).get("supports_streaming", True)

    @property
    def is_serverless(self) -> bool:
        """True if this model is accessible without a dedicated endpoint."""
        return TOGETHER_MODELS.get(self.model_name, {}).get("serverless", False)

    def pricing(self) -> dict[str, float]:
        """Return per-request pricing info for the loaded model."""
        info = TOGETHER_MODELS.get(self.model_name, {})
        return {
            "input_per_1m_usd": info.get("pricing_per_1m_input", 0),
            "output_per_1m_usd": info.get("pricing_per_1m_output", 0),
        }


# ---------------------------------------------------------------------------
# Self-register with the ProviderRegistry on first import (idempotent)
# ---------------------------------------------------------------------------
def _register() -> None:
    try:
        from effgen.models.capabilities import Capability
        from effgen.models.registry import ProviderRegistry
        from effgen.models.together_models import TOGETHER_MODELS
        ProviderRegistry.register(
            "together",
            TogetherAdapter,
            TOGETHER_MODELS,
            env_keys=["TOGETHER_API_KEY"],
            capabilities={Capability.chat, Capability.streaming, Capability.tools, Capability.json_schema, Capability.vision},
            # $1 free credits on signup; pay-per-token after. Provider default = cheapest LLM.
            # LFM2 24B A2B: $0.03/$0.12; gpt-oss-20B: $0.05/$0.20; Llama 3.3 70B: $0.88/$0.88 per 1M.
            # Pricing verified: https://together.ai/pricing (2026-05-11)
            pricing={"input_per_1m": 0.03, "output_per_1m": 0.12, "free_tier": False},
        )
    except Exception:
        pass


_register()
