from __future__ import annotations

import os
from pathlib import Path

from cooper_beta.config import build_config
from cooper_beta.pipeline_workers import prepare_file_batch, prepare_one_file
from cooper_beta.prepare_cache import _executable_state


class FakeChain:
    def __init__(self, chain_id: str):
        self.id = chain_id


class FakeLoader:
    calls = 0

    def __init__(self, file_path, model_id=0, dssp_bin=None, fail_on_dssp_error=True):
        del model_id, dssp_bin, fail_on_dssp_error
        type(self).calls += 1
        self.file_path = file_path
        self.model = [FakeChain("A")]

    def get_chain_data(self, chain_id):
        assert chain_id == "A"
        return [
            {"res_id": 1, "coord": [0.0, 0.0, 0.0], "is_sheet": True},
            {"res_id": 2, "coord": [1.0, 0.0, 0.0], "is_sheet": True},
        ]


def test_prepare_one_file_reuses_cached_payloads(tmp_path: Path, monkeypatch):
    input_file = tmp_path / "toy.pdb"
    input_file.write_text("HEADER\n")

    cfg = build_config(
        {
            "input.min_chain_residues": 1,
            "runtime.prepare_cache_enabled": True,
            "runtime.prepare_cache_dir": str(tmp_path / "cache"),
        }
    )

    monkeypatch.setattr("cooper_beta.pipeline_workers.ProteinLoader", FakeLoader)
    FakeLoader.calls = 0

    first = prepare_one_file(str(input_file), cfg)
    second = prepare_one_file(str(input_file), cfg)

    assert isinstance(first, list)
    assert first == second
    assert FakeLoader.calls == 1


def test_prepare_cache_invalidates_when_file_changes(tmp_path: Path, monkeypatch):
    input_file = tmp_path / "toy.pdb"
    input_file.write_text("HEADER\n")

    cfg = build_config(
        {
            "input.min_chain_residues": 1,
            "runtime.prepare_cache_enabled": True,
            "runtime.prepare_cache_dir": str(tmp_path / "cache"),
        }
    )

    monkeypatch.setattr("cooper_beta.pipeline_workers.ProteinLoader", FakeLoader)
    FakeLoader.calls = 0

    first = prepare_one_file(str(input_file), cfg)
    input_file.write_text("HEADER UPDATED\n")
    second = prepare_one_file(str(input_file), cfg)

    assert isinstance(first, list)
    assert isinstance(second, list)
    assert FakeLoader.calls == 2


def test_prepare_cache_invalidates_when_same_size_file_content_changes(
    tmp_path: Path,
    monkeypatch,
):
    input_file = tmp_path / "toy.pdb"
    input_file.write_text("HEADER\n")

    cfg = build_config(
        {
            "input.min_chain_residues": 1,
            "runtime.prepare_cache_enabled": True,
            "runtime.prepare_cache_dir": str(tmp_path / "cache"),
        }
    )

    monkeypatch.setattr("cooper_beta.pipeline_workers.ProteinLoader", FakeLoader)
    FakeLoader.calls = 0

    first = prepare_one_file(str(input_file), cfg)
    stat = input_file.stat()
    input_file.write_text("HEADEQ\n")
    os.utime(input_file, ns=(stat.st_atime_ns, stat.st_mtime_ns))
    second = prepare_one_file(str(input_file), cfg)

    assert isinstance(first, list)
    assert isinstance(second, list)
    assert FakeLoader.calls == 2


def test_executable_cache_state_includes_content_hash(tmp_path: Path):
    executable = tmp_path / "mkdssp"
    executable.write_text("version-a\n", encoding="utf-8")
    executable.chmod(0o755)
    first = _executable_state(str(executable))
    assert first is not None

    stat = executable.stat()
    executable.write_text("version-b\n", encoding="utf-8")
    os.utime(executable, ns=(stat.st_atime_ns, stat.st_mtime_ns))
    second = _executable_state(str(executable))

    assert second is not None
    assert first["size"] == second["size"]
    assert first["mtime_ns"] == second["mtime_ns"]
    assert first["sha256"] != second["sha256"]


def test_prepare_file_batch_aggregates_payloads_and_errors(monkeypatch):
    cfg = build_config({"input.min_chain_residues": 1})

    def fake_prepare_one_file(file_path: str, cfg):
        del cfg
        if file_path == "bad.pdb":
            return {"_error": "bad.pdb: parse failed"}
        return [{"filename": file_path, "chain": "A", "residues_data": []}]

    monkeypatch.setattr("cooper_beta.pipeline_workers.prepare_one_file", fake_prepare_one_file)

    result = prepare_file_batch(["good-1.pdb", "bad.pdb", "good-2.pdb"], cfg)

    assert result["processed"] == 3
    assert result["errors"] == ["bad.pdb: parse failed"]
    assert result["payloads"] == [
        {"filename": "good-1.pdb", "chain": "A", "residues_data": []},
        {"filename": "good-2.pdb", "chain": "A", "residues_data": []},
    ]
