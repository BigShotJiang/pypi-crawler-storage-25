"""Default bundled CAO skills."""
