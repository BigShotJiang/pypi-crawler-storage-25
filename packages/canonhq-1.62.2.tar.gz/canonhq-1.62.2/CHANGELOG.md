# CHANGELOG

<!-- version list -->

## v1.62.2 (2026-05-03)

### Bug Fixes

- **infra**: Use explicit OpenSearch version 2.19 (DO requires exact version)
  ([`7b7be61`](https://github.com/canonhq/canon-private/commit/7b7be61ac2e62fb89c944aed400c0e06f5ab48a8))

### Documentation

- Snapshot v1.62 docs
  ([`a52ff2f`](https://github.com/canonhq/canon-private/commit/a52ff2fa789f2433f38bc711ccf2f5abaf7adcf3))


## v1.62.1 (2026-05-03)

### Bug Fixes

- **helm**: Remove hard fail for missing OPENSEARCH_URL, disable new crons in preview
  ([`b7bbfc9`](https://github.com/canonhq/canon-private/commit/b7bbfc9f88ef1c01d7a6aaaea53676454898c31f))

- **infra**: Change OpenSearch VPC CIDR to avoid DO reserved range
  ([`7ca5794`](https://github.com/canonhq/canon-private/commit/7ca5794ce5656abe366e4fbcfac59f6aa677d2b3))

### Documentation

- Snapshot v1.62 docs
  ([`b83f9e1`](https://github.com/canonhq/canon-private/commit/b83f9e1edfc186a11b9ea1f68a0be1a4cce277b9))


## v1.62.0 (2026-05-03)

### Documentation

- Snapshot v1.61 docs
  ([`83ff9c8`](https://github.com/canonhq/canon-private/commit/83ff9c8a0604b602adbb84ce6f2474f9140875a8))

### Features

- OpenSearch integration + GitHub content caching (Phases 1-3)
  ([`a930e2e`](https://github.com/canonhq/canon-private/commit/a930e2e15cdc4f988af931fd7d4512f06b46d238))


## v1.61.0 (2026-05-02)

### Bug Fixes

- **seo**: Strip CRLF from base_url in robots.txt for defense-in-depth
  ([#644](https://github.com/canonhq/canon-private/pull/644),
  [`1092ffb`](https://github.com/canonhq/canon-private/commit/1092ffbb45d59fe249cb44179d80622af8dbe69e))

- **seo**: Use canon_base_url instead of Host header for sitemap URLs
  ([#644](https://github.com/canonhq/canon-private/pull/644),
  [`1092ffb`](https://github.com/canonhq/canon-private/commit/1092ffbb45d59fe249cb44179d80622af8dbe69e))

- **seo**: Use dynamic base_url in landing template and tighten xml escaping
  ([#644](https://github.com/canonhq/canon-private/pull/644),
  [`1092ffb`](https://github.com/canonhq/canon-private/commit/1092ffbb45d59fe249cb44179d80622af8dbe69e))

### Chores

- **canon**: Sync ticket statuses in docs/specs/admin-ui-user-org-management.md
  ([`751cd99`](https://github.com/canonhq/canon-private/commit/751cd99f6f094b040642b5d828685db888be9c8c))

- **canon**: Sync ticket statuses in docs/specs/analytics-dashboard.md
  ([`1b015b5`](https://github.com/canonhq/canon-private/commit/1b015b58da9a32eeb1da02fed6365c03e4b2c229))

- **canon**: Sync ticket statuses in docs/specs/canon-rebrand.md
  ([`04267c3`](https://github.com/canonhq/canon-private/commit/04267c3654cdd8d59bb7f5440738034291742535))

- **canon**: Sync ticket statuses in docs/specs/cli-integrations-onboarding.md
  ([`5935f53`](https://github.com/canonhq/canon-private/commit/5935f5355f316fc38edea0db7dca9cb5408369bb))

- **canon**: Sync ticket statuses in docs/specs/devbox-testing.md
  ([`b74fe6e`](https://github.com/canonhq/canon-private/commit/b74fe6e001efc0fdd9c7b5ab28b5fad2b21d5543))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`d806be1`](https://github.com/canonhq/canon-private/commit/d806be1bd439d43c64250882f5a4b12d2caff787))

- **canon**: Sync ticket statuses in docs/specs/enterprise-adoption-enablement.md
  ([`44238ad`](https://github.com/canonhq/canon-private/commit/44238adece76ad13418533f703b78cda127414e3))

- **canon**: Sync ticket statuses in docs/specs/enterprise-scale-infrastructure.md
  ([`3247448`](https://github.com/canonhq/canon-private/commit/3247448053f50a77ae6005fecb06866d9f0e3257))

- **canon**: Sync ticket statuses in docs/specs/github-actions-suite.md
  ([`35336f3`](https://github.com/canonhq/canon-private/commit/35336f3021318e6fde65eab30707f44b1a062fc7))

- **canon**: Sync ticket statuses in docs/specs/llm-observability.md
  ([`f0cac86`](https://github.com/canonhq/canon-private/commit/f0cac864e8a92c36b317d0973e88e06def497f08))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ede4019`](https://github.com/canonhq/canon-private/commit/ede4019eb4244ae8735b47b0cab3d2c87de9bdfd))

- **canon**: Sync ticket statuses in docs/specs/multi-org-personal-accounts.md
  ([`fd7649c`](https://github.com/canonhq/canon-private/commit/fd7649c0d16d765152e5963478c97891c7af19f2))

- **canon**: Sync ticket statuses in docs/specs/platform-observability-coverage.md
  ([`c159548`](https://github.com/canonhq/canon-private/commit/c1595482e5c37e0acf71172eaa3f3118e6e3fa27))

- **canon**: Sync ticket statuses in docs/specs/plugin-ecosystem.md
  ([`51a67a7`](https://github.com/canonhq/canon-private/commit/51a67a70640426c1865cd5ee1f086d171a500bec))

- **canon**: Sync ticket statuses in docs/specs/plugin-product-polish.md
  ([`a4957dd`](https://github.com/canonhq/canon-private/commit/a4957ddc91c542da23d0f22f7eaf2f9f328d4bd8))

- **canon**: Sync ticket statuses in docs/specs/security-vulnerabilities.md
  ([`f38e81d`](https://github.com/canonhq/canon-private/commit/f38e81dd7c3124bf5a410da8a178dfeca0ee53cc))

- **canon**: Sync ticket statuses in docs/specs/setup-ux-improvements.md
  ([`ee74ee9`](https://github.com/canonhq/canon-private/commit/ee74ee932c114e83865f11b11db9a57bb2a50835))

- **canon**: Sync ticket statuses in docs/specs/slack-product-experience.md
  ([`539eaac`](https://github.com/canonhq/canon-private/commit/539eaac174847f9796dc19994b64d5df9304a874))

- **canon**: Sync ticket statuses in docs/specs/superpowers-parity.md
  ([`68c9e78`](https://github.com/canonhq/canon-private/commit/68c9e78197e028219ea80d73104ab56b560bcc91))

- **canon**: Sync ticket statuses in docs/specs/ticket-mapping-model.md
  ([`6f3f8a1`](https://github.com/canonhq/canon-private/commit/6f3f8a19466f4b7cb5cf91b70689411625c073f6))

- **canon**: Sync ticket statuses in docs/specs/ticket-sync-enhancements.md
  ([`746528a`](https://github.com/canonhq/canon-private/commit/746528a43ab715461f2a8a0d61862eb0684e0e21))

- **canon**: Sync ticket statuses in docs/specs/ticket-sync-reliability.md
  ([`2909c07`](https://github.com/canonhq/canon-private/commit/2909c07a0aa604a38e6a0a2a77dd34f2ca79c3f1))

- **canon**: Sync ticket statuses in docs/specs/user-profile-page.md
  ([`ec8d63e`](https://github.com/canonhq/canon-private/commit/ec8d63eca547c557c13e9840229e6b0fbaf9e00d))

- **canon**: Sync ticket statuses in docs/specs/web-app-ux-polish.md
  ([`3dc9b57`](https://github.com/canonhq/canon-private/commit/3dc9b57c9486834c042d68d8675ae05e4833833e))

- **canon**: Update specs from PR #644
  ([`3f6f03a`](https://github.com/canonhq/canon-private/commit/3f6f03af016378f79ced35f6e489f2e2b317ede4))

- **canon**: Update specs from PR #644
  ([`7ae6542`](https://github.com/canonhq/canon-private/commit/7ae65428aed2dc14833e5cd5238789012d94040e))

- **canon**: Update specs from PR #644
  ([`7fd5a69`](https://github.com/canonhq/canon-private/commit/7fd5a695158dba76f8d6906c61feb20fe2c2fdd9))

### Code Style

- Fix ruff formatting in routes.py ([#644](https://github.com/canonhq/canon-private/pull/644),
  [`1092ffb`](https://github.com/canonhq/canon-private/commit/1092ffbb45d59fe249cb44179d80622af8dbe69e))

### Documentation

- Snapshot v1.60 docs
  ([`16eb103`](https://github.com/canonhq/canon-private/commit/16eb10388d0646d9960508bbc963388f79eff05c))

### Features

- **seo**: Add root robots.txt, sitemap.xml, and landing JSON-LD
  ([#644](https://github.com/canonhq/canon-private/pull/644),
  [`1092ffb`](https://github.com/canonhq/canon-private/commit/1092ffbb45d59fe249cb44179d80622af8dbe69e))


## v1.60.2 (2026-04-26)

### Bug Fixes

- **audit**: Auto-promote context sections to done and fix stale spec statuses
  ([`7b64e17`](https://github.com/canonhq/canon-private/commit/7b64e172a64ca1a9f9b6cb29f1e5da22d884298d))

### Documentation

- Bulk promote 559 context sections to done via audit
  ([`fbe18a3`](https://github.com/canonhq/canon-private/commit/fbe18a324b4d7f795d9397e07c8f22e436fae6da))

- Snapshot v1.60 docs
  ([`43b52c1`](https://github.com/canonhq/canon-private/commit/43b52c18bb0e008c971a1b65a5e3bff5dc4f3245))


## v1.60.1 (2026-04-25)

### Bug Fixes

- **sync**: Address review findings — fail-loud, truncation check, test coverage
  ([#630](https://github.com/canonhq/canon-private/pull/630),
  [`036363c`](https://github.com/canonhq/canon-private/commit/036363c7c4e8d83bc86c497eaab0e8c3b49ac875))

- **sync**: Harden cron jobs against GitHub API failures and rate limits
  ([#630](https://github.com/canonhq/canon-private/pull/630),
  [`036363c`](https://github.com/canonhq/canon-private/commit/036363c7c4e8d83bc86c497eaab0e8c3b49ac875))

- **tests**: Update reindex test mocks for list_installation_repos
  ([#630](https://github.com/canonhq/canon-private/pull/630),
  [`036363c`](https://github.com/canonhq/canon-private/commit/036363c7c4e8d83bc86c497eaab0e8c3b49ac875))

### Chores

- Regenerate uv.lock for version 1.59.1 ([#630](https://github.com/canonhq/canon-private/pull/630),
  [`036363c`](https://github.com/canonhq/canon-private/commit/036363c7c4e8d83bc86c497eaab0e8c3b49ac875))

- **canon**: Update specs from PR #630
  ([`9f588ea`](https://github.com/canonhq/canon-private/commit/9f588ea097798a66b25a6ec07ff38bbd629dfb63))

### Documentation

- Snapshot v1.60 docs
  ([`5cea736`](https://github.com/canonhq/canon-private/commit/5cea7360419e942ba28c83b521fae355076424c4))


## v1.60.0 (2026-04-25)

### Bug Fixes

- Add healthchecks to WireMock containers
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Address CI failures and code review feedback
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Address documentation review findings ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Address interrogation findings ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Correct CANON.yaml format in scenario fixtures and relax doctor assertions
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Relax broken-config lint/status assertions — only doctor validates config
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Remove --version from package smoke test (CLI doesn't support it)
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Rename TMPDIR to avoid clobbering env + validate scenario name
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Use single connection in _get_alembic_version to avoid race
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- Use uv pip install in package smoke test (uv venv has no pip)
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- **oss**: Exclude all internal specs from OSS export
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- **security**: Prevent expression injection in scenario-tests.yml
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

### Chores

- Regenerate uv.lock for v1.59.1 ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- **canon**: Add ticket links to docs/specs/devbox-testing.md
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

### Documentation

- Snapshot v1.59 docs
  ([`ef3b886`](https://github.com/canonhq/canon-private/commit/ef3b886c5678e60a1828c7ae0d181df13f6a1c87))

- Update devbox-testing spec statuses to reflect implementation
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

### Features

- **testing**: Add devbox environment, scenario-based lifecycle tests, and adapter contract testing
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))

- **testing**: Devbox environment, scenario lifecycle tests, and adapter contract testing
  ([#629](https://github.com/canonhq/canon-private/pull/629),
  [`c9e73b4`](https://github.com/canonhq/canon-private/commit/c9e73b41979244f30b33f82713e897279b830636))


## v1.59.1 (2026-04-24)

### Bug Fixes

- **setup**: Rename templates dir to fix missing data files in PyPI wheel
  ([#626](https://github.com/canonhq/canon-private/pull/626),
  [`d5342a1`](https://github.com/canonhq/canon-private/commit/d5342a1ca7f74cecde8a3dc56743c0ba112843fc))

### Chores

- Update uv.lock to match 1.59.0 version ([#626](https://github.com/canonhq/canon-private/pull/626),
  [`d5342a1`](https://github.com/canonhq/canon-private/commit/d5342a1ca7f74cecde8a3dc56743c0ba112843fc))

### Documentation

- Snapshot v1.59 docs
  ([`d35f799`](https://github.com/canonhq/canon-private/commit/d35f799764e072b523b5d414816acab3a67fb4d0))


## v1.59.0 (2026-04-24)

### Bug Fixes

- **plugin**: Address review findings — grep fallback, variable naming, test gaps
  ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))

- **plugin**: UserPromptSubmit hook blocking fresh repos + add canon-interrogate
  ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))

### Chores

- Sync pyproject.toml version and lockfile with main (1.57.2)
  ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))

### Code Style

- Ruff format test_skills_content.py ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))

### Documentation

- Comprehensive docs site update — 19 findings across 8 pages
  ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))

- Snapshot v1.58 docs
  ([`f35da19`](https://github.com/canonhq/canon-private/commit/f35da19ae303d235510427028aed07045a82e062))

### Features

- **plugin**: Fix UserPromptSubmit hook blocking fresh repos + add canon-interrogate skill
  ([#625](https://github.com/canonhq/canon-private/pull/625),
  [`2eb58a8`](https://github.com/canonhq/canon-private/commit/2eb58a8e40e90d613cd8db5235cb8588768b397b))


## v1.58.0 (2026-04-24)

### Bug Fixes

- Address PR review — duplicate breadcrumbs, reactivity, a11y, palette
  ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))

- Inline task detail panel, editor narrow default, clear filters
  ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))

### Chores

- Regenerate uv.lock for v1.57.0 ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))

### Documentation

- Snapshot v1.57 docs
  ([`2b32e06`](https://github.com/canonhq/canon-private/commit/2b32e064e25f2ce28cdf6598ab01c7bf64464a7b))

### Features

- Cross-linking, sortable tasks, and UX polish
  ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))

- Web app UI/UX overhaul — sidebar nav, design system, polish
  ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))

- Web app UI/UX overhaul — sidebar navigation and design system
  ([#624](https://github.com/canonhq/canon-private/pull/624),
  [`87f87f6`](https://github.com/canonhq/canon-private/commit/87f87f63766afcf2952216b65e8c75b30297abc0))


## v1.57.2 (2026-04-24)

### Bug Fixes

- Address PR review — shared ETag cache, HTML routes, network errors
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

- ETag cache eviction guard and 304 without cached data handling
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

- Guard _inflight cleanup to avoid evicting successor tasks
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

- Handle GitHub API errors gracefully in dashboard
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

- Handle GitHub API errors gracefully in web dashboard routes
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

### Chores

- Update uv.lock for v1.57.0 ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))

### Documentation

- Snapshot v1.57 docs
  ([`c2d6440`](https://github.com/canonhq/canon-private/commit/c2d64400d6938b0424726eadf4fec27c8cdc4a87))

### Performance Improvements

- Reduce GitHub API usage with ETags, request coalescing, and longer cache TTLs
  ([#621](https://github.com/canonhq/canon-private/pull/621),
  [`0a495e7`](https://github.com/canonhq/canon-private/commit/0a495e76700d71b07a9ec63393bfb96e84f04cbc))


## v1.57.1 (2026-04-24)

### Bug Fixes

- Address PR review — XSS protection, editor round-trip, test coverage
  ([#623](https://github.com/canonhq/canon-private/pull/623),
  [`21b6a3a`](https://github.com/canonhq/canon-private/commit/21b6a3acd9c5d40df55a626a9050c2f39dc95c2f))

- Unify GitHub App URLs and fix broken ticket links
  ([#623](https://github.com/canonhq/canon-private/pull/623),
  [`21b6a3a`](https://github.com/canonhq/canon-private/commit/21b6a3acd9c5d40df55a626a9050c2f39dc95c2f))

- Unify GitHub App URLs to canonhq slug and fix broken ticket links
  ([#623](https://github.com/canonhq/canon-private/pull/623),
  [`21b6a3a`](https://github.com/canonhq/canon-private/commit/21b6a3acd9c5d40df55a626a9050c2f39dc95c2f))

### Chores

- Regenerate uv.lock for v1.57.0 ([#623](https://github.com/canonhq/canon-private/pull/623),
  [`21b6a3a`](https://github.com/canonhq/canon-private/commit/21b6a3acd9c5d40df55a626a9050c2f39dc95c2f))

- Regenerate uv.lock for v1.57.0 ([#622](https://github.com/canonhq/canon-private/pull/622),
  [`3c9f1e4`](https://github.com/canonhq/canon-private/commit/3c9f1e45887a444d91e36d5f814a11a6b540bf0e))

- **canon**: Github ticket 339 → done in docs/specs/canon-rebrand.md
  ([`9d3887e`](https://github.com/canonhq/canon-private/commit/9d3887ef48e5f8928ccb7e66896214cfae3d7204))

- **canon**: Github ticket 342 → done in docs/specs/canon-rebrand.md
  ([`f861e7d`](https://github.com/canonhq/canon-private/commit/f861e7dc580943c7d6b2d5d3e129cdbc5fd97e13))

- **canon**: Github ticket 342 → done in docs/specs/canon-rebrand.md
  ([`912a3a3`](https://github.com/canonhq/canon-private/commit/912a3a3f11d3779fca97a71ec9a4bc43441fe30c))

- **canon**: Sync ticket statuses in docs/specs/canon-rebrand.md
  ([`ad79b08`](https://github.com/canonhq/canon-private/commit/ad79b08ff5346523e102a3f63d8fb9b1592762eb))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b6e9558`](https://github.com/canonhq/canon-private/commit/b6e95587792b32180957509ec144d5de27d026c5))

- **canon**: Sync ticket statuses in docs/specs/superpowers-parity.md
  ([`b8be331`](https://github.com/canonhq/canon-private/commit/b8be331e182a628217d3f0cd7682660f9ee2c6ed))

- **canon**: Update specs from PR #623
  ([`664bdfc`](https://github.com/canonhq/canon-private/commit/664bdfce666f46d7e5013b3507a0344c9207e9b8))

- **canon**: Update specs from PR #623
  ([`a727fde`](https://github.com/canonhq/canon-private/commit/a727fde10e769725816b411c2e282f46bdcb7e3d))

### Documentation

- Fix review issues — canon --help, missing skill, mcp args
  ([#622](https://github.com/canonhq/canon-private/pull/622),
  [`3c9f1e4`](https://github.com/canonhq/canon-private/commit/3c9f1e45887a444d91e36d5f814a11a6b540bf0e))

- Rewrite getting-started for better onboarding
  ([#622](https://github.com/canonhq/canon-private/pull/622),
  [`3c9f1e4`](https://github.com/canonhq/canon-private/commit/3c9f1e45887a444d91e36d5f814a11a6b540bf0e))

- Rewrite getting-started pages for better onboarding
  ([#622](https://github.com/canonhq/canon-private/pull/622),
  [`3c9f1e4`](https://github.com/canonhq/canon-private/commit/3c9f1e45887a444d91e36d5f814a11a6b540bf0e))

- Snapshot v1.57 docs
  ([`519d735`](https://github.com/canonhq/canon-private/commit/519d735edcd5ebb17a01018bf21d8cfb52624bda))


## v1.57.0 (2026-04-24)

### Bug Fixes

- Address PR review findings — auth, security, error handling
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Address PR review — UnboundLocalError and missing org check
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Address second round of bot review findings
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Clamp limit lower bound, add since/until filters, fix store init
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Correct triggerSync/retrySync return types for TypeScript build
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Dark mode styling for select dropdowns in sync UI
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Include closed/reopened in partial-success status check
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Overhaul sync UI — repo dropdown, data loss bug, better trigger modal
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Parse JSONB detail field returned as string by asyncpg
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Prevent duplicate sync runs and stale SHA on direction=both
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Show error detail when sync repos query fails in settings tab
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Show meaningful error on failed sync runs, improve empty state UX
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Use db_pool not pool for sync store initialization
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Validate UUIDs, validate config before commit, fix lockfile
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

### Chores

- Updates for canon plugin
  ([`7344547`](https://github.com/canonhq/canon-private/commit/7344547c2a28f60cc0d2f3ab52690b637e954cf3))

- **canon**: Add ticket links to docs/specs/admin-ui-user-org-management.md
  ([`2d3c5de`](https://github.com/canonhq/canon-private/commit/2d3c5de2ccaabb2265cb9f510c3da94e29a2b898))

- **canon**: Add ticket links to docs/specs/analytics-dashboard.md
  ([`8655fd2`](https://github.com/canonhq/canon-private/commit/8655fd25fc162f98d0abf566eeb69003e3a2f280))

- **canon**: Add ticket links to docs/specs/enhanced-platform-testing.md
  ([`442b0b7`](https://github.com/canonhq/canon-private/commit/442b0b73d644b3984c22aa670fd35c40ffd9a66b))

- **canon**: Add ticket links to docs/specs/enterprise-adoption-enablement.md
  ([`095e013`](https://github.com/canonhq/canon-private/commit/095e013bbfa66f7647a291f6474f2335d36ef6b9))

- **canon**: Add ticket links to docs/specs/enterprise-scale-infrastructure.md
  ([`9bc620f`](https://github.com/canonhq/canon-private/commit/9bc620f6274e82158b172183e4990251a661b05c))

- **canon**: Add ticket links to docs/specs/github-actions-suite.md
  ([`9e50000`](https://github.com/canonhq/canon-private/commit/9e500009fd568ba2a0030744a4a46a5d1393063a))

- **canon**: Add ticket links to docs/specs/infrastructure-independence.md
  ([`df0f4bf`](https://github.com/canonhq/canon-private/commit/df0f4bff27a2249b2a2b7a87397c64937b87cabb))

- **canon**: Add ticket links to docs/specs/llm-observability.md
  ([`31ea459`](https://github.com/canonhq/canon-private/commit/31ea45939a7cddcef80a85982b9c8408a72055fc))

- **canon**: Add ticket links to docs/specs/multi-org-personal-accounts.md
  ([`7196514`](https://github.com/canonhq/canon-private/commit/719651455ec376936f498c77e55d935998e2f124))

- **canon**: Add ticket links to docs/specs/platform-observability-coverage.md
  ([`7ac2c60`](https://github.com/canonhq/canon-private/commit/7ac2c602ca40308dc1b18adb5553dda631726e8f))

- **canon**: Add ticket links to docs/specs/plugin-product-polish.md
  ([`8e865bd`](https://github.com/canonhq/canon-private/commit/8e865bd192181339258df331133db116749517da))

- **canon**: Add ticket links to docs/specs/security-vulnerabilities.md
  ([`d6d7e2a`](https://github.com/canonhq/canon-private/commit/d6d7e2a45e505f66f08dbffbb7273b769dff278e))

- **canon**: Add ticket links to docs/specs/slack-product-experience.md
  ([`a19103f`](https://github.com/canonhq/canon-private/commit/a19103f97c2f20d7a0f9b5ecffd9966db7f00f30))

- **canon**: Add ticket links to docs/specs/superpowers-parity.md
  ([`fd597f6`](https://github.com/canonhq/canon-private/commit/fd597f69444c366ff22d00eafd65260e4a214b9b))

- **canon**: Add ticket links to docs/specs/ticket-mapping-model.md
  ([`650c233`](https://github.com/canonhq/canon-private/commit/650c2333a7458a108522f6dd21c3f0eff633f958))

- **canon**: Add ticket links to docs/specs/web-app-ux-polish.md
  ([`56adadb`](https://github.com/canonhq/canon-private/commit/56adadb2ec58c2108d2209bcaa0a7a396f2209c8))

### Code Style

- Ruff format sync_routes.py ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

### Documentation

- Snapshot v1.56 docs
  ([`b372918`](https://github.com/canonhq/canon-private/commit/b372918c61019ff0c89f3a5539d292ca2592ecfb))

### Features

- Add Sync Now trigger button, improve empty state and editor visibility
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Add sync UI for ticket mapping and sync management
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Sync UI for ticket mapping and sync management
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))

- Wire manual sync trigger to actual sync engine
  ([#535](https://github.com/canonhq/canon-private/pull/535),
  [`66524b3`](https://github.com/canonhq/canon-private/commit/66524b33fef96f4ee986d26a6987c589dab1836a))


## v1.56.0 (2026-04-23)

### Bug Fixes

- **chart**: Disable refreshTokensCronJob in preview values
  ([`409a0e9`](https://github.com/canonhq/canon-private/commit/409a0e9ed3943f2436a9fd853e1bf33b1c164c66))

### Documentation

- Snapshot v1.55 docs
  ([`c4ea54e`](https://github.com/canonhq/canon-private/commit/c4ea54e10d0475f2aea4d319b9ca977b071154e6))

- Update CLAUDE.md with current project structure and gotchas
  ([`293bdd2`](https://github.com/canonhq/canon-private/commit/293bdd2a991d0da337af59784cdd225384b0ba6a))

### Features

- Automatic Jira OAuth token refresh on 401 and via cron
  ([`cec0c87`](https://github.com/canonhq/canon-private/commit/cec0c87014d642e356bc5a0d4e6e1ec7e95ab8ed))

- **chart**: Add refresh-tokens CronJob (every 30 min)
  ([`7bbcf9b`](https://github.com/canonhq/canon-private/commit/7bbcf9bd32f5565e68cbf5b95f3cf8a010b61f72))


## v1.55.1 (2026-04-23)

### Bug Fixes

- **doctor**: Suppress misleading org_id warning for device-flow tokens
  ([`5e5841e`](https://github.com/canonhq/canon-private/commit/5e5841e4b7b04bf9cd658f2c90ad39edb0cd9eff))

### Documentation

- Snapshot v1.55 docs
  ([`221bd5d`](https://github.com/canonhq/canon-private/commit/221bd5d0b07ec3330a53054ef1423779ef5aa1ce))


## v1.55.0 (2026-04-23)

### Bug Fixes

- Atomic YAML writes, wizard preserves config on reconfigure, org validation
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- IndexError on empty repo and OAuth polling response parsing
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Init alias shares setup args, org slug validation in login, env var reminder
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Non-interactive setup preserves existing config, doctor JWT check graceful
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Persist Jira host in CANON.yaml, don't store unconfirmed org in credentials
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Replace silent except-pass patterns with debug/warning logging
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Source filter excludes not_configured stubs, YAML edits preserve comments
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Validate org slug and use lambda in re.sub replacements
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Wizard preserves existing config, doctor --fix gives feedback, org validation
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

### Chores

- Update uv.lock version to match main ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- **canon**: Add ticket links to docs/specs/cli-integrations-onboarding.md
  ([`d4a1ec2`](https://github.com/canonhq/canon-private/commit/d4a1ec2af991ce8ef1b4574460c6de77c5ac2463))

### Code Style

- Fix lint errors in test files ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Format integration_manager.py ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

### Documentation

- Snapshot v1.54 docs
  ([`c77825b`](https://github.com/canonhq/canon-private/commit/c77825b2a5c5d4dd43e5216668c6edc9baa5098b))

### Features

- CLI integration management, doctor command, and guided onboarding
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))

- Doctor checks JWT org scope, tests integration connections, validates project key
  ([#522](https://github.com/canonhq/canon-private/pull/522),
  [`f38c0e0`](https://github.com/canonhq/canon-private/commit/f38c0e0567cbd4d7994a05aa5f6d0f9e2af7848a))


## v1.54.3 (2026-04-22)

### Bug Fixes

- Resolve org_login from request URL when JWT lacks org_id
  ([`10ac177`](https://github.com/canonhq/canon-private/commit/10ac177af92e30b75c6515ca6486d45e7cc869a3))

### Documentation

- Snapshot v1.54 docs
  ([`410327d`](https://github.com/canonhq/canon-private/commit/410327d31165cf18a9c0dd714305168bd7b449b7))


## v1.54.2 (2026-04-22)

### Bug Fixes

- Allow bearer tokens without org_id to access org-scoped routes
  ([`8355b71`](https://github.com/canonhq/canon-private/commit/8355b7193aa7b76dd12a7504a6e8fe070ae843f0))

### Documentation

- Snapshot v1.54 docs
  ([`873b0ae`](https://github.com/canonhq/canon-private/commit/873b0ae0e7ad675440af8e4d9304c40d49c3ed78))


## v1.54.1 (2026-04-22)

### Bug Fixes

- Exclude non-package directories from sdist to stay under PyPI 100MB limit
  ([`65893c2`](https://github.com/canonhq/canon-private/commit/65893c25ebe95973140e3b75686cfe363b09f638))


## v1.54.0 (2026-04-22)

### Bug Fixes

- Address Phase 2-3 PR review findings ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))

- Address silent-failure-hunter findings for Phase 2-3
  ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))

- Shell-quote ext root, atomic hooks.json, cwd-based project root, agent name validation
  ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))

### Chores

- Sync uv.lock with main (v1.53.0) ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))

### Documentation

- Add extension system documentation pages
  ([`ed44cdb`](https://github.com/canonhq/canon-private/commit/ed44cdb958541a73848bc827fab2925fd90a13b1))

- Add testing extensions locally guide
  ([`9e88dbb`](https://github.com/canonhq/canon-private/commit/9e88dbbf1478662a156552a3d2a739b8ae431561))

### Features

- Implement plugin ecosystem Phase 2-3 ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))

- Plugin ecosystem Phase 2-3 — adapters, catalog, hooks, MCP tools, agents
  ([#521](https://github.com/canonhq/canon-private/pull/521),
  [`45c186b`](https://github.com/canonhq/canon-private/commit/45c186ba511749126c9b07b6e16e12e92091105f))


## v1.53.0 (2026-04-15)

### Bug Fixes

- Address PR comment review findings ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Address PR review findings — path traversal, facade stubs, sys.path
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Address remaining PR review findings ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Clean up partial file placement on _place_skills/_place_commands failure
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Fail-closed on invalid specifier, atomic registry write, copytree symlinks
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Guard IdentityStore init when Slack extension unavailable
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Tighten name validation, log uninstall cleanup failures, fix format
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Validate_file_references bounds check, _remove_placed_files bounds check
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- YAML injection in template author field, remove dead _compare_versions
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

### Chores

- Sync uv.lock with pyproject.toml version bump
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- **canon**: Add ticket links to docs/specs/plugin-ecosystem.md
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

### Features

- Add plugin ecosystem with extension system, first-party extensions, and Slack extraction
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))

- Plugin ecosystem with extension system and Slack extraction
  ([#520](https://github.com/canonhq/canon-private/pull/520),
  [`6474b38`](https://github.com/canonhq/canon-private/commit/6474b38853d773ac565ca4a0de1fdc8dbf812cd6))


## v1.52.6 (2026-04-15)

### Bug Fixes

- **cron**: Skip reverse sync commit when file content is unchanged
  ([`f453fc6`](https://github.com/canonhq/canon-private/commit/f453fc6ec07b5183bfeab5687368a0a2fe0e7de3))

### Chores

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e2a70a4`](https://github.com/canonhq/canon-private/commit/e2a70a4d6df37b1d4702d1bf404b34584ffe1d2c))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`904786b`](https://github.com/canonhq/canon-private/commit/904786b64028165873238a4465eafb269c026479))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`ffff764`](https://github.com/canonhq/canon-private/commit/ffff7644d15ecad2890d919150aa6bb42e43f819))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`11f3d5a`](https://github.com/canonhq/canon-private/commit/11f3d5acabb4037e9251fb9e8735a332fc63cf42))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`7030ca8`](https://github.com/canonhq/canon-private/commit/7030ca89180b939437fa6772ba8fd83797fecc90))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`8b5c26b`](https://github.com/canonhq/canon-private/commit/8b5c26b9bbc8bfc5d8fff84356783c4d9ca5f099))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`79e8f5a`](https://github.com/canonhq/canon-private/commit/79e8f5a9fe016c11e835cf7a3b10ac663d1c0809))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`fe9372f`](https://github.com/canonhq/canon-private/commit/fe9372f9875788e312248f9e2b4a725265cb5dc5))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`ef1e860`](https://github.com/canonhq/canon-private/commit/ef1e860844f2260a25fde8c078319b6e22b5a390))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`63e6408`](https://github.com/canonhq/canon-private/commit/63e6408327f2b52bc1e0e9b6a0639cf64a49b2cc))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`345fefd`](https://github.com/canonhq/canon-private/commit/345fefdebabe0343529f0336232f5bdc60688a90))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e0b5f5d`](https://github.com/canonhq/canon-private/commit/e0b5f5d587f17b805405916859d1ee2bad6fef0e))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`2254161`](https://github.com/canonhq/canon-private/commit/22541616bbd8e64a6fbcfdaf2da7715191392856))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`7430aec`](https://github.com/canonhq/canon-private/commit/7430aec9463b7472f0a825d7fccf9b321b37f96e))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e9878b1`](https://github.com/canonhq/canon-private/commit/e9878b1583220b851d9bbaf0c2aa65428a552d54))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`6c47500`](https://github.com/canonhq/canon-private/commit/6c47500f015eeb1ed15a6fc0a7d409ef0f285d3c))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`64a6d84`](https://github.com/canonhq/canon-private/commit/64a6d84be1305a38bf873a73ec4ed5fe714ebc74))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`72dcbf0`](https://github.com/canonhq/canon-private/commit/72dcbf0fd8af3a116cfda4efb88b9ee06bf4d1da))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e9d93d3`](https://github.com/canonhq/canon-private/commit/e9d93d3d1f79e97a0dd1bc0139f23a58cb85e214))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`a65ccd3`](https://github.com/canonhq/canon-private/commit/a65ccd3f1c8c1bdf586a84897f6cb207440fb4dc))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`c6f0329`](https://github.com/canonhq/canon-private/commit/c6f032919b74a81e5b347e032667c10e6dc65c0a))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`1a93008`](https://github.com/canonhq/canon-private/commit/1a93008e27f45175db9231f3075ea594666a3b14))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`a9a90c2`](https://github.com/canonhq/canon-private/commit/a9a90c2df3226a435bc53d0443c469cd9f6764b8))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`604c58b`](https://github.com/canonhq/canon-private/commit/604c58b1b288c83908086d0ee6b49cd7c8b71b83))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`ff0e77f`](https://github.com/canonhq/canon-private/commit/ff0e77fcef0272df371d5dc42ca19c2f3e998ab2))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`6e76a60`](https://github.com/canonhq/canon-private/commit/6e76a6036fd6484bfaded6a2a7a9c5ba939644b6))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`47cc611`](https://github.com/canonhq/canon-private/commit/47cc6118037ea9749b306b61e5be0b359eac079c))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`ce49855`](https://github.com/canonhq/canon-private/commit/ce49855ee12289367bef6aa10ea945f167a9fb2a))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`158e786`](https://github.com/canonhq/canon-private/commit/158e786001abc09c96b2a3640e0ea0bfca091a69))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`6620cb4`](https://github.com/canonhq/canon-private/commit/6620cb48cf9e27e0e2ab98409ea9a066f75b8744))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`8dd4658`](https://github.com/canonhq/canon-private/commit/8dd4658c1cf058c6d4a9bc511e534520d65016f7))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`302f852`](https://github.com/canonhq/canon-private/commit/302f852a4a208b8c6af7b67d6903a190de38aab0))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`ffea446`](https://github.com/canonhq/canon-private/commit/ffea446b5a446fbf07885173e248dfd10c6f4da9))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`fb90fe0`](https://github.com/canonhq/canon-private/commit/fb90fe07828c40a9fbbb90e2bf7fcafba42fddd9))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`81b717b`](https://github.com/canonhq/canon-private/commit/81b717b2f05ca37267996f31672c7c259ec528f4))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`4a4346b`](https://github.com/canonhq/canon-private/commit/4a4346b43497fb0a829c183d306641a8da526ff8))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`0ec4041`](https://github.com/canonhq/canon-private/commit/0ec40415e9fed20f2430bce89023e8741661692c))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`9512241`](https://github.com/canonhq/canon-private/commit/9512241dcd4a42b2773da035ea79783095155527))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`1a805be`](https://github.com/canonhq/canon-private/commit/1a805be7af05c62441c91cca808b5c782bf2f167))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`172253b`](https://github.com/canonhq/canon-private/commit/172253ba779f517fad11cbaae95480a2a9fcf8c2))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`14dd5ea`](https://github.com/canonhq/canon-private/commit/14dd5eafabed3c26ce238db5257d20c551d36ec5))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`46f4882`](https://github.com/canonhq/canon-private/commit/46f488234b2ebaf4ac66f44d577133d3887342e0))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`f7115a6`](https://github.com/canonhq/canon-private/commit/f7115a66499ce5bd6b3b8521a169b00def263a86))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`4440ab1`](https://github.com/canonhq/canon-private/commit/4440ab14cba5017bb0638151e6eb562d33af92dc))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`c89fdbf`](https://github.com/canonhq/canon-private/commit/c89fdbfe9bf8d37aff5f85e01a0ee93c7f78aba4))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`9401f37`](https://github.com/canonhq/canon-private/commit/9401f3727b59525ffb6f33852c2c11399fff4bd0))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b298f7f`](https://github.com/canonhq/canon-private/commit/b298f7f4532fce3d9370e8d720442f5c83101740))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`653a6f7`](https://github.com/canonhq/canon-private/commit/653a6f7fbebe5193626a080f08a83d7ae428d0b6))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`e1051e7`](https://github.com/canonhq/canon-private/commit/e1051e7a76931b4ae069bd59e206f93ec42670c0))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b43bc59`](https://github.com/canonhq/canon-private/commit/b43bc59d9df6cbfda9bbca465e7e51543ba9868b))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`c0519d1`](https://github.com/canonhq/canon-private/commit/c0519d174a18259401b99820a4a8780b78fa4f20))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b6b70a5`](https://github.com/canonhq/canon-private/commit/b6b70a57cd019dc281a95d56d973d65b6db69d8e))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`8b57387`](https://github.com/canonhq/canon-private/commit/8b57387028fb94dd0a9a2c25c79d67f988d0c589))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`9bc7470`](https://github.com/canonhq/canon-private/commit/9bc74701fd2a511a2552818703b0d09ca3ac347f))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`38a54df`](https://github.com/canonhq/canon-private/commit/38a54df296b46cac1c93898ab9f492995dd20c1e))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`4b20192`](https://github.com/canonhq/canon-private/commit/4b20192c70c65cbd0e168503af6e7d8f85c6c349))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`1b32141`](https://github.com/canonhq/canon-private/commit/1b3214124e1f1c5066f3da3cc10694605bd81fba))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`e9e06ee`](https://github.com/canonhq/canon-private/commit/e9e06ee41e46dcb787bb37581ed13adb6c041abc))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6769cdb`](https://github.com/canonhq/canon-private/commit/6769cdbab46cd300f78db3b22172fb4856c60b31))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`604bf40`](https://github.com/canonhq/canon-private/commit/604bf40207214abf5c3a202cf45057dd6ef1b6bc))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6f2299d`](https://github.com/canonhq/canon-private/commit/6f2299def7004733a8ad6450653ccef1b9280310))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`15ddf15`](https://github.com/canonhq/canon-private/commit/15ddf15eea07c1c95607f9616b1ab7115616ccc4))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6ba99f4`](https://github.com/canonhq/canon-private/commit/6ba99f4f5b04c47ba28b3aaa5162a673b2276196))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`2c6fa55`](https://github.com/canonhq/canon-private/commit/2c6fa557ff608855ee3d5eb2667a243ba012a1c2))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`0e748e8`](https://github.com/canonhq/canon-private/commit/0e748e8c882b5ca96dea2e8f6d5de12010757b9e))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b3a2717`](https://github.com/canonhq/canon-private/commit/b3a271784ad01a32caf85e5f75c96278fee1fa40))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`84c38d0`](https://github.com/canonhq/canon-private/commit/84c38d0fbd5026689da01683e762574b80e89e9d))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`2a44c30`](https://github.com/canonhq/canon-private/commit/2a44c30e51abaf8aa2a65552e967ca8b433c73fe))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`b9f6451`](https://github.com/canonhq/canon-private/commit/b9f6451119b2c402f1421158b30af9c12a56beee))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`dccfa76`](https://github.com/canonhq/canon-private/commit/dccfa766a44cbbbe725a0c2269492f5d931ec687))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3ce8bcd`](https://github.com/canonhq/canon-private/commit/3ce8bcdc2ac0d6476a25d3e101a125b2192d5322))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`8d28778`](https://github.com/canonhq/canon-private/commit/8d28778cb6f3d77fdb4d819d953882d1a9d31893))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`5198761`](https://github.com/canonhq/canon-private/commit/5198761b1ece4d0905f38ff7c6f4bcf9fa68a16a))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`f63d35b`](https://github.com/canonhq/canon-private/commit/f63d35b63667609979721b10c80522360627fb68))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`4a0d1d0`](https://github.com/canonhq/canon-private/commit/4a0d1d064ca1a69c9c446295b14ad7ff8010a192))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`26b5eea`](https://github.com/canonhq/canon-private/commit/26b5eea9e498da5efa4d713404664a40531b1b6c))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`5ea48ce`](https://github.com/canonhq/canon-private/commit/5ea48cee63e8b0dc3669119ef8f5ffa5ad6b308c))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`1874a7c`](https://github.com/canonhq/canon-private/commit/1874a7cf7489df693a68ef4e5f7add848144edb5))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`9cd46e2`](https://github.com/canonhq/canon-private/commit/9cd46e2025c7d3403a97fab78efd5e7cf5980dea))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`b03a500`](https://github.com/canonhq/canon-private/commit/b03a5005dbcd827719a885758ab54b3e71cfe1cd))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`8e95d43`](https://github.com/canonhq/canon-private/commit/8e95d433e371ccc9eec4e691ff422f64cac1dc82))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`c121bcd`](https://github.com/canonhq/canon-private/commit/c121bcd84eec674c42a17832bc33ca01b4f15c65))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`f754c31`](https://github.com/canonhq/canon-private/commit/f754c31e6eadfe3cd1d4a32765f0172585b624f0))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`6a70371`](https://github.com/canonhq/canon-private/commit/6a703719a3d63b0716c70093df636e1d0fb738bb))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`5b82be6`](https://github.com/canonhq/canon-private/commit/5b82be6ea69234b8dea51f09cb7e031b1c2464dc))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`5df9fe7`](https://github.com/canonhq/canon-private/commit/5df9fe7c1c581ba43c48d83ddf1c3b58e3452069))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`ebd1bb2`](https://github.com/canonhq/canon-private/commit/ebd1bb22b54ef8e7a5c7449d01ef3bf04c06f0bf))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`928dd85`](https://github.com/canonhq/canon-private/commit/928dd85e4f02cac7985724bc61a402484ad269a8))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`2376e66`](https://github.com/canonhq/canon-private/commit/2376e66b97824f72f0fac0f94af3c53d6f633f66))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`7943ede`](https://github.com/canonhq/canon-private/commit/7943ede0ae1c31f34e2ca9a4e59466177c994e85))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3fd7771`](https://github.com/canonhq/canon-private/commit/3fd77717c0cfd0a8c206058eb3a4d7ef448acdb5))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`e964bc8`](https://github.com/canonhq/canon-private/commit/e964bc8a5e5cf8a0250ec5cd0dbbce5edfbbee60))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`296b192`](https://github.com/canonhq/canon-private/commit/296b19229446f2e86f29fe87a0b77fd6d550d58d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`2d5a207`](https://github.com/canonhq/canon-private/commit/2d5a20760459f9273c83379ca266b96898421e0a))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`efd8e4d`](https://github.com/canonhq/canon-private/commit/efd8e4dcafa7a45e91294cfb236fe2c6e01bc517))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`a756595`](https://github.com/canonhq/canon-private/commit/a7565953b14b278cdaab0e82ec34c67d0dac5d12))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`c044b36`](https://github.com/canonhq/canon-private/commit/c044b364790e9b0449cc5f194421a905a2e6b32e))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`32a80fe`](https://github.com/canonhq/canon-private/commit/32a80fefaeb6cd5c3701c3ac8787c68db787ca7f))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ed02427`](https://github.com/canonhq/canon-private/commit/ed02427fbe97e950443d09302516d9471f6afdfd))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`d9fbc7a`](https://github.com/canonhq/canon-private/commit/d9fbc7a1b38648ce43f065fca81eaa69ce3fe690))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`74b0a48`](https://github.com/canonhq/canon-private/commit/74b0a482ae023ce844b5c8249cf694c185b4e63d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7842a70`](https://github.com/canonhq/canon-private/commit/7842a70818f20131ef3ef2a4e81dee908318c466))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`f6340af`](https://github.com/canonhq/canon-private/commit/f6340af92a049826c299eb23bbc3f880b2729999))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`c6b3575`](https://github.com/canonhq/canon-private/commit/c6b3575d92a45cdd40c196c7aed73fb9daa95022))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`6d0314a`](https://github.com/canonhq/canon-private/commit/6d0314a3a2301bf5d7e1b2c75abf4c93417c8e80))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`a1237bd`](https://github.com/canonhq/canon-private/commit/a1237bd749364426e829546d53f9edea36497ea2))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`98325bf`](https://github.com/canonhq/canon-private/commit/98325bf801a73e6b1832378ea144597a41c60e37))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`cb01ebd`](https://github.com/canonhq/canon-private/commit/cb01ebdb5b6397aafa8e59ac919e4f9a4ed6f405))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`49b667a`](https://github.com/canonhq/canon-private/commit/49b667aab144dc5a90e2483a94ecf3baf72e92d7))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`95f01a3`](https://github.com/canonhq/canon-private/commit/95f01a3a157734d32e3e25eccaad946c18e5691e))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7fa203e`](https://github.com/canonhq/canon-private/commit/7fa203e1c9400e42eae744af3997f75e822951cd))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`a888065`](https://github.com/canonhq/canon-private/commit/a888065ebbc097a97caa1411098f798fc8102632))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`b013d06`](https://github.com/canonhq/canon-private/commit/b013d06a882875842ad6885b870dd5606aa5a72d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`1457ef7`](https://github.com/canonhq/canon-private/commit/1457ef7a0d68f7c897c40cdc534c0fe83cc60606))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`0a06bfd`](https://github.com/canonhq/canon-private/commit/0a06bfdd87267533479a27316a1ad8898d7fc593))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`805d705`](https://github.com/canonhq/canon-private/commit/805d705984420d1de7587b5be5b66768658f5392))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`6c5ea56`](https://github.com/canonhq/canon-private/commit/6c5ea5605db8e61557de7edfe3cb1c6d4a76716c))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`4cecf77`](https://github.com/canonhq/canon-private/commit/4cecf775ea3d5aad703d07bc3a3839dcd49bd080))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`1433fc3`](https://github.com/canonhq/canon-private/commit/1433fc36a583aa70dbec7ec3f86952c54b12aee1))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`ff6106e`](https://github.com/canonhq/canon-private/commit/ff6106eb94924304e3ead4cdbea0bb60866a530f))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`9d4b81e`](https://github.com/canonhq/canon-private/commit/9d4b81edd0b268e45ef8292f123fafcfb29c7032))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`393d36d`](https://github.com/canonhq/canon-private/commit/393d36de9edc5f75aeb27731e879a27fc62b5e8e))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`00910af`](https://github.com/canonhq/canon-private/commit/00910af3a79960a10953644c18411ca6ee294e90))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`8b583b0`](https://github.com/canonhq/canon-private/commit/8b583b0b85c5bd7a052a515c8c95c00b3904814c))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`02043a9`](https://github.com/canonhq/canon-private/commit/02043a9f421de03ea8f72f7052a97879989ab45e))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`fd41a45`](https://github.com/canonhq/canon-private/commit/fd41a452ea5cc510828a8b7377ccf643bd8e55df))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`8f33c4e`](https://github.com/canonhq/canon-private/commit/8f33c4ec16da68986cc54b7c67e2410db23f1cfa))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`6e54eeb`](https://github.com/canonhq/canon-private/commit/6e54eeb12a2cb253dc69353aba1981aabe8881a0))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`74d6928`](https://github.com/canonhq/canon-private/commit/74d6928db753af0915b0acc14cd68931b12f08d3))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`06b49f3`](https://github.com/canonhq/canon-private/commit/06b49f334f8edb05ee5cd8e376a79bdfdf58cf6b))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`1e8d453`](https://github.com/canonhq/canon-private/commit/1e8d453b2ddbd2242b260fa29cf06f6f7fd2aecd))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`a0910d4`](https://github.com/canonhq/canon-private/commit/a0910d4f14c48eb401cac49c5d6428b65f9819be))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`1e6366c`](https://github.com/canonhq/canon-private/commit/1e6366cc984c6b9588a396d62fc8c0dd9b93c43d))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`1c9c341`](https://github.com/canonhq/canon-private/commit/1c9c341fdf5f9b0fdc6d8206ec0692c9b8ee4df7))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`dcc9eff`](https://github.com/canonhq/canon-private/commit/dcc9eff237feecce18de252573dac3de4966db77))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`f7e39a7`](https://github.com/canonhq/canon-private/commit/f7e39a73b0b1b71a8012323381c78c80bb0cbaa2))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`137d164`](https://github.com/canonhq/canon-private/commit/137d1649c6d2355e8a13a710abba72cf57ee2954))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`0fc111f`](https://github.com/canonhq/canon-private/commit/0fc111ff7fd7e533e32e05d2f9a4df723cacffe3))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`488e484`](https://github.com/canonhq/canon-private/commit/488e4843130a173af9135d7ee5aa3fe36e214d4f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`8c69012`](https://github.com/canonhq/canon-private/commit/8c690128999f783a6ddf4b4842d974589b88b61b))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`ba16c47`](https://github.com/canonhq/canon-private/commit/ba16c47795fd7b74c249f4af44339898658d5c2f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`10507e9`](https://github.com/canonhq/canon-private/commit/10507e9710121482bc376cafd9613adf51a93292))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`49a7898`](https://github.com/canonhq/canon-private/commit/49a7898ab4eb0ffcdab1fdd90e072757c70a96d6))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`022248f`](https://github.com/canonhq/canon-private/commit/022248f999d8b3bd64c10818dcd1b13d8659efb8))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`dcc6631`](https://github.com/canonhq/canon-private/commit/dcc663131919875c45b847f3d2b8dd3d8e3673fd))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`010ec14`](https://github.com/canonhq/canon-private/commit/010ec14cb2603b87772c51a18b09a8567d63b591))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`502bc70`](https://github.com/canonhq/canon-private/commit/502bc702d871b9189939f9a9f945813f02f40ed3))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`b40d7c8`](https://github.com/canonhq/canon-private/commit/b40d7c8472d1d85bc6a1ef972446a4e507b5d286))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`c7ba9dd`](https://github.com/canonhq/canon-private/commit/c7ba9dd21d6f704bf99638f4b3fdf02b78205564))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`42f200c`](https://github.com/canonhq/canon-private/commit/42f200c0638c313bb69207b96d25fcad41f20a96))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`06ab99a`](https://github.com/canonhq/canon-private/commit/06ab99a518e5ecd42292ab60beddb9332efe1682))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`8ef8e1d`](https://github.com/canonhq/canon-private/commit/8ef8e1de276fe0c8e2a7045b6610b32d3ccc8f21))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`0da28ee`](https://github.com/canonhq/canon-private/commit/0da28ee5de5b241429600704490f22b8435f3cd7))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`f579a7c`](https://github.com/canonhq/canon-private/commit/f579a7ca027b75e4228534ae47fb5616a73222ea))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`18823f3`](https://github.com/canonhq/canon-private/commit/18823f38072807f528fcacb81ce5ab43a13f4782))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`2191703`](https://github.com/canonhq/canon-private/commit/2191703cd92a751a20b8abaa6c18db8c68649ddc))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`102a70b`](https://github.com/canonhq/canon-private/commit/102a70b2ffde5cfeb5c9732bad1f37bd54a2c139))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`d001913`](https://github.com/canonhq/canon-private/commit/d0019137180f098990644e56771c7135bf214923))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`76ebef3`](https://github.com/canonhq/canon-private/commit/76ebef3fa8149f79e07c7ab7964188cb968f46f5))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`bd9625f`](https://github.com/canonhq/canon-private/commit/bd9625fa29bc7df2ce878a262377b624a1dedb67))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`e5f3ba5`](https://github.com/canonhq/canon-private/commit/e5f3ba5144bd4ef6d8e8c7ebe25dbef92d6aaf77))


## v1.52.5 (2026-04-15)

### Bug Fixes

- **ci**: Add cancel-in-progress to Release & Publish workflow
  ([`f53ba06`](https://github.com/canonhq/canon-private/commit/f53ba0644a167f2054b14be8a0e35297673b6705))

### Chores

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`6902de2`](https://github.com/canonhq/canon-private/commit/6902de246c48c15b14ee5b45f49cb8ce62e4cd33))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`a295fd9`](https://github.com/canonhq/canon-private/commit/a295fd9c6ca9059e179bd3cd0bcfd2a8901807af))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`4c58dfc`](https://github.com/canonhq/canon-private/commit/4c58dfcca7433e7888f05f7ff85490aee866188d))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e062601`](https://github.com/canonhq/canon-private/commit/e0626012ca44da909b7998cbab8028e76cca5fb9))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`30b4ca8`](https://github.com/canonhq/canon-private/commit/30b4ca8cd875f220f922249370560d1d44b89aae))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`1eaf823`](https://github.com/canonhq/canon-private/commit/1eaf8239897586082633b8569b8076380b2e4e06))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`b219ff8`](https://github.com/canonhq/canon-private/commit/b219ff83301242d22745efd28bffe351e2f3c62a))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`67c49c4`](https://github.com/canonhq/canon-private/commit/67c49c4a78e3f5cf3fa277f9b2a6907635000cb7))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`7bf0433`](https://github.com/canonhq/canon-private/commit/7bf0433b750d48a732cf8b7eb139bf8375a44207))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`812f40a`](https://github.com/canonhq/canon-private/commit/812f40a399a04beee3c7558cc8267925c36b0e60))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`5137b01`](https://github.com/canonhq/canon-private/commit/5137b01c87c66eb3c041735cf5470c98acc1a018))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`06b5713`](https://github.com/canonhq/canon-private/commit/06b57130da26aadccc561c88a15a5e446b4e50cf))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`5076767`](https://github.com/canonhq/canon-private/commit/50767675c61df7fbfd44d5205c59afc33c342af2))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e456389`](https://github.com/canonhq/canon-private/commit/e456389e1015f009864826079810b783e1b1c1bd))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`4a7d6a8`](https://github.com/canonhq/canon-private/commit/4a7d6a88c8c653d9a055e5d98088940c690a2516))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`7fb9b53`](https://github.com/canonhq/canon-private/commit/7fb9b5354ff716a63314ca2b0d86d1c3861e4bca))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`ba39ecd`](https://github.com/canonhq/canon-private/commit/ba39ecdcd0057944919889e594b76e837d25c962))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`12f2495`](https://github.com/canonhq/canon-private/commit/12f24957a143076ea71a8d14b3fc427f15e7324a))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e21d175`](https://github.com/canonhq/canon-private/commit/e21d1753a7633e24cd13190c8de51fae530a9d6e))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`efe8eba`](https://github.com/canonhq/canon-private/commit/efe8eba39c263e3ef73cadb0973d861e74068ce8))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`af7baa8`](https://github.com/canonhq/canon-private/commit/af7baa896b28b8a0795bc42b2cb26e13a9162b7c))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`a841da0`](https://github.com/canonhq/canon-private/commit/a841da0d5f71b919d048013be375d6ac93695bf8))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`9f5ec3c`](https://github.com/canonhq/canon-private/commit/9f5ec3cb295d1f590ec1b3112c7790739f97945f))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`6bc031d`](https://github.com/canonhq/canon-private/commit/6bc031d190f1a15d4ea52b2c216b68436c13089d))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`db71437`](https://github.com/canonhq/canon-private/commit/db714371d03e0e62455d5051452510c106899bdd))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`ab101f0`](https://github.com/canonhq/canon-private/commit/ab101f034adee72ba4ec5aef73527caae474e7b3))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`0f59c31`](https://github.com/canonhq/canon-private/commit/0f59c31f80aa28058f7f18f7137b3d0806f19569))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`10ff848`](https://github.com/canonhq/canon-private/commit/10ff84821464d75b485f057fb8e631b85408e536))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`7ce7fb2`](https://github.com/canonhq/canon-private/commit/7ce7fb28b1af4f1970c3a0e8822bfce9737848df))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`69d0bb0`](https://github.com/canonhq/canon-private/commit/69d0bb0dd94718de9c9506de234b581d382f0da7))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`2a918b0`](https://github.com/canonhq/canon-private/commit/2a918b0cce92fff717df9c9eec68257f1cec94b3))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`fb7535f`](https://github.com/canonhq/canon-private/commit/fb7535fb73ee58931a59a0b2056209833b405570))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`3e10a44`](https://github.com/canonhq/canon-private/commit/3e10a44cd9ebed28e73aa9301fb99201905705a2))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`55bb6f6`](https://github.com/canonhq/canon-private/commit/55bb6f68b1d42b07cad74441dd0ed68e2ecd819b))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`8c7d639`](https://github.com/canonhq/canon-private/commit/8c7d639e9d8f6518f4a44b8c99dc1fee9a25c73f))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`6374fd6`](https://github.com/canonhq/canon-private/commit/6374fd63fdd01b39ffd84a046a01be0eb6b5ff59))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`be75c85`](https://github.com/canonhq/canon-private/commit/be75c8547885fcbeeef83713bbd07768a509bcf4))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`5d8d469`](https://github.com/canonhq/canon-private/commit/5d8d469fa0e35105bd3d4a1941c6ab29052f5e4c))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`14a2ad0`](https://github.com/canonhq/canon-private/commit/14a2ad020bfccafd017f27d8ce2b1ccf8154c704))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`ccb9c17`](https://github.com/canonhq/canon-private/commit/ccb9c1723c6852286069d3226e88aeb346970745))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`039d6ff`](https://github.com/canonhq/canon-private/commit/039d6ff0113036f4e421924bbf9d765766b2e28a))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`11d1cee`](https://github.com/canonhq/canon-private/commit/11d1cee6256c52a7c8bd92547d4724448e8b5510))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`e52088f`](https://github.com/canonhq/canon-private/commit/e52088ff34961fd5425c673803b0b7700083f439))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`cb58493`](https://github.com/canonhq/canon-private/commit/cb5849373330a7965047e2e1a59d85f57b787135))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`8845c39`](https://github.com/canonhq/canon-private/commit/8845c39ba31cda44b7423961c15e470879541a7b))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`d58b253`](https://github.com/canonhq/canon-private/commit/d58b25373d7fb02a56562c94f436069e0b7b57e8))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`f87e7ec`](https://github.com/canonhq/canon-private/commit/f87e7ec56d0e45107c98eb67f6bba32f012ceab3))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`a607b1e`](https://github.com/canonhq/canon-private/commit/a607b1e38c15f0e5afb8f27edd0f5e030d63a81d))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`b18362a`](https://github.com/canonhq/canon-private/commit/b18362a31ec7d780dde5d4822d83abf2dcc4a91d))

- **canon**: Sync ticket statuses in docs/specs/auth-hardening.md
  ([`bdd0e75`](https://github.com/canonhq/canon-private/commit/bdd0e75059a13e9e5ff6240b907468894a7da186))

- **canon**: Sync ticket statuses in docs/specs/canon-rebrand.md
  ([`9488312`](https://github.com/canonhq/canon-private/commit/9488312025aed56184a68a94d19fbc0b142d745e))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`f0d3999`](https://github.com/canonhq/canon-private/commit/f0d3999aeeba7447b712d6aecea94c96c18f780b))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`998ab4d`](https://github.com/canonhq/canon-private/commit/998ab4dc77994fee09400ff483db499c7b783bbd))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`df7bdba`](https://github.com/canonhq/canon-private/commit/df7bdbaa0b1a35ce1a6c80b072cad357cc71a39b))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`afe79a9`](https://github.com/canonhq/canon-private/commit/afe79a9900b242624e5debd868d674435e9be528))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`d890a72`](https://github.com/canonhq/canon-private/commit/d890a72186b9dc91b3244f72b0b3acdc2f00e5c9))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`88ba42f`](https://github.com/canonhq/canon-private/commit/88ba42f9a6fe277c0ab7d5cf68df8d394ec856cc))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`8cebaab`](https://github.com/canonhq/canon-private/commit/8cebaab29cf868ba5ead274a3d4525fe78ff7b6a))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`b2b1feb`](https://github.com/canonhq/canon-private/commit/b2b1feb805b23ca111060d79fca610cc56726ac0))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`dd9bc99`](https://github.com/canonhq/canon-private/commit/dd9bc99d2eb027e5a709b0bf6e3d59dabfa93514))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`8327f0f`](https://github.com/canonhq/canon-private/commit/8327f0fcaabffd993044ac6e173aede53378d2fe))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`2cf98d1`](https://github.com/canonhq/canon-private/commit/2cf98d164530fd4f4080b00e72ca6bed7f2e3a9e))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`84cb032`](https://github.com/canonhq/canon-private/commit/84cb03254f2e9c875f2e5c7b2aefa3284a5146d8))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`ca46f18`](https://github.com/canonhq/canon-private/commit/ca46f18fa17bc032670a82cf88fce29e30efc2de))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`a9ed135`](https://github.com/canonhq/canon-private/commit/a9ed135c89fc9bd5dec08ec0d51144fd51e24b11))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`16d1cb8`](https://github.com/canonhq/canon-private/commit/16d1cb89509aadac1fa145cb2a8cf23ec7d49a22))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`c85dbd5`](https://github.com/canonhq/canon-private/commit/c85dbd5c5d8ad68be812bf1db84b77154abfd4ae))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`11cdb87`](https://github.com/canonhq/canon-private/commit/11cdb874cfa73e41e5aa80a70f3e282173c3fa8a))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`e4cebb6`](https://github.com/canonhq/canon-private/commit/e4cebb61329cd2021121347e79febeb5d326796e))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`bce6034`](https://github.com/canonhq/canon-private/commit/bce6034f4d3bf0058aa60ca78e443a68badfd76d))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`04a493a`](https://github.com/canonhq/canon-private/commit/04a493a644520e4c5a7b91a3d07ee4b71afe87bd))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`dc5eaa2`](https://github.com/canonhq/canon-private/commit/dc5eaa2be83b4edf69d78b56352c52b77a89c34d))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`317969d`](https://github.com/canonhq/canon-private/commit/317969dc87755565f26598d27673586883b824d9))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`f09cfce`](https://github.com/canonhq/canon-private/commit/f09cfce046e244815f87fd39736bac95a4ef09f4))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`ef95a34`](https://github.com/canonhq/canon-private/commit/ef95a34f91524038c909b4037b0eb56287542282))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`f32f8b8`](https://github.com/canonhq/canon-private/commit/f32f8b8260450386086513916d5a1a2e9354b8c6))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`b26423d`](https://github.com/canonhq/canon-private/commit/b26423ded9ef920e0231633075082058505224b8))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`7b07c74`](https://github.com/canonhq/canon-private/commit/7b07c746a361c5a760740b6ae689a1123124dc1c))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`46e6bbe`](https://github.com/canonhq/canon-private/commit/46e6bbec65c019907a97098db51f8ee252eb1d46))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`7b7db10`](https://github.com/canonhq/canon-private/commit/7b7db10b2fdb9656a784c750f31f66fa1f72dac1))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`19854b6`](https://github.com/canonhq/canon-private/commit/19854b622cbeecfae0c5b9b645a9e01d44eb8624))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`af01f75`](https://github.com/canonhq/canon-private/commit/af01f75553a77db95678bc2e804477bae9f25f67))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`08051ad`](https://github.com/canonhq/canon-private/commit/08051ad875691bd433e30f0a0c930dcc438bf264))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`07ea828`](https://github.com/canonhq/canon-private/commit/07ea828e30cfb2cc400c98780e5189260df8ea8c))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`96bb2ed`](https://github.com/canonhq/canon-private/commit/96bb2ed28d9bcd2275b7d56783486a9fd57fbb03))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`b56862e`](https://github.com/canonhq/canon-private/commit/b56862efb0bb4ca537ce5c4f2f99c82f467841f4))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`720aed4`](https://github.com/canonhq/canon-private/commit/720aed4d7277517565e197a6fffdb4709768ad74))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`330ca4e`](https://github.com/canonhq/canon-private/commit/330ca4e9539557c8ef8c5096bc71b0262d2f7c8e))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`2c008ff`](https://github.com/canonhq/canon-private/commit/2c008ff8a478131c000656d2ccbf5af0dd0fe90b))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`05f649e`](https://github.com/canonhq/canon-private/commit/05f649e1f0996cbc60f7b50d7059fb6a020f1f04))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`5e508d6`](https://github.com/canonhq/canon-private/commit/5e508d6f9002ce07d14273fadbf648c5fe4c4b5b))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`4540d79`](https://github.com/canonhq/canon-private/commit/4540d79330a0d03d4cd6cf0a584103153615dce7))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`53bd72f`](https://github.com/canonhq/canon-private/commit/53bd72fdd77d4683234c1a11bdd9d55cbf586c46))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`49c4881`](https://github.com/canonhq/canon-private/commit/49c4881d535dc1b18ae369414fc0bddc01057012))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`c7a672e`](https://github.com/canonhq/canon-private/commit/c7a672ed6b96014f0f468261ced62512f6bee1c1))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`1488079`](https://github.com/canonhq/canon-private/commit/1488079e95b296b813ebffe38a88fb552e257abd))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`a5ac8bb`](https://github.com/canonhq/canon-private/commit/a5ac8bbe3caf0405ca664613d4a323dc1fce1e62))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`70c0434`](https://github.com/canonhq/canon-private/commit/70c04343f8593ffc32ee3e045fe2fed5a67a3619))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`374bd69`](https://github.com/canonhq/canon-private/commit/374bd695df5d40129e506d9a83d908866a9fbdce))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`38ad82d`](https://github.com/canonhq/canon-private/commit/38ad82d0a7f8aa97a7474b5dd5e4489071aa1299))

- **canon**: Sync ticket statuses in docs/specs/developer-docs-site.md
  ([`da5ff05`](https://github.com/canonhq/canon-private/commit/da5ff051ce325d318a7a7944a60029e9ea14af81))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`530997f`](https://github.com/canonhq/canon-private/commit/530997fe1c45d4c40da50d0184525d4e2fff5dd3))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`0596b4b`](https://github.com/canonhq/canon-private/commit/0596b4b574b09320d877d8194f7d2e82bd563812))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`7de483e`](https://github.com/canonhq/canon-private/commit/7de483eefd228cbcd71d64ffdca656227516a165))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`ca54f94`](https://github.com/canonhq/canon-private/commit/ca54f946c57636ea6890b6c04cbd6fd23301413f))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`c28f327`](https://github.com/canonhq/canon-private/commit/c28f32716cdd714dcb04b66c5a75ca4072747cfb))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`a607f60`](https://github.com/canonhq/canon-private/commit/a607f60887dbc9d37070f4cb36a147983da9871a))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`3054afc`](https://github.com/canonhq/canon-private/commit/3054afc041068aba4f9110c761a0eec1e89b6f8d))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`d45fe9b`](https://github.com/canonhq/canon-private/commit/d45fe9bc6551b9d4edcf455d233a6ee2626f3237))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`0136f1e`](https://github.com/canonhq/canon-private/commit/0136f1e24fd70f42546cc023df454637b034cc83))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`46111d6`](https://github.com/canonhq/canon-private/commit/46111d6aa5898e9b65e5d6e1652651bdc6d8fe3d))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6482d25`](https://github.com/canonhq/canon-private/commit/6482d2509e17ba6b7dd1311f0c6ab6be4c16ab19))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`7a4b2ce`](https://github.com/canonhq/canon-private/commit/7a4b2cece13b0ac66cc30b074b0c6a933b1dd6d5))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`728635e`](https://github.com/canonhq/canon-private/commit/728635e1ae0d1c6df40d8d854ed94be43198ed81))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`a325a00`](https://github.com/canonhq/canon-private/commit/a325a00b2705faa601d3e6546aa2b438dece261c))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`650efaa`](https://github.com/canonhq/canon-private/commit/650efaa09046a68e700c8ad5aa81b8553531b4a5))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`7e3e5bd`](https://github.com/canonhq/canon-private/commit/7e3e5bd4144eae089343dfe70fa4acdd594a6967))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`94c0809`](https://github.com/canonhq/canon-private/commit/94c08090156c375675d7455b8f5253b556986c46))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`a2b094f`](https://github.com/canonhq/canon-private/commit/a2b094fb61dfe52fcbe76b25fab1b516351c5d39))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`1c79f2e`](https://github.com/canonhq/canon-private/commit/1c79f2e24b97084e5a892689aaf67ce65096ddea))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`9a1b8b8`](https://github.com/canonhq/canon-private/commit/9a1b8b854006e94df0cf7d62c745ab1c40fff0cf))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`4c35031`](https://github.com/canonhq/canon-private/commit/4c35031dd28209cb20c8be13f76626a3a3bd4c05))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`2ec7b00`](https://github.com/canonhq/canon-private/commit/2ec7b0041de92c5e4e3f070de03e05a228a79631))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`47d5e01`](https://github.com/canonhq/canon-private/commit/47d5e01e88eb4c8057ba5bec6158f72e3bf8fdf5))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`1312b39`](https://github.com/canonhq/canon-private/commit/1312b39006b98d74dcd539e20fa74a4bf7f816bc))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`43130bd`](https://github.com/canonhq/canon-private/commit/43130bd45b4a71a959c80419489897918dec9a2a))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`3c775ce`](https://github.com/canonhq/canon-private/commit/3c775ce7779196e58abbac6d6d7d1b30053f67ad))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`34d0ed4`](https://github.com/canonhq/canon-private/commit/34d0ed47d1a40ff6178c2171acbbff59b4c1bf52))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`a2a454f`](https://github.com/canonhq/canon-private/commit/a2a454f9de4c4c533c425b20d299237a9ea712c4))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`edf3344`](https://github.com/canonhq/canon-private/commit/edf33440f3d55212a00447ba4db9b17f086366e0))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6ff20a3`](https://github.com/canonhq/canon-private/commit/6ff20a3802be02c0d1f018558b7937e035f23264))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`60f3076`](https://github.com/canonhq/canon-private/commit/60f3076d0178bab0f392b10cba8d2a775690a936))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`3e598e2`](https://github.com/canonhq/canon-private/commit/3e598e23f71ce183fd1ec5223c808a2f90205ecf))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`94c9188`](https://github.com/canonhq/canon-private/commit/94c918829a825876def9e3edf0433616e6591830))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`d7712b9`](https://github.com/canonhq/canon-private/commit/d7712b9957752722978dff7713101a66fae96cb4))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`4016e37`](https://github.com/canonhq/canon-private/commit/4016e37794e60d4cdb24c6eb624267e19120972b))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`1749510`](https://github.com/canonhq/canon-private/commit/1749510e44b03166200f230195280f440fef6686))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`c87ddba`](https://github.com/canonhq/canon-private/commit/c87ddbaed69b6cb915ad98d3c815a72c31f01d24))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`d698016`](https://github.com/canonhq/canon-private/commit/d69801634800b78d88052c633c66b529c0eb10d5))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`f0a215a`](https://github.com/canonhq/canon-private/commit/f0a215ab7b3fd6a031f96c3ce63a07d3748645a8))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`5b53649`](https://github.com/canonhq/canon-private/commit/5b5364913a66577d9d782dd959ea6c7525dbde63))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`2c4ec62`](https://github.com/canonhq/canon-private/commit/2c4ec62d16ee8c5eef3c46a375aadba575db8909))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`6054d47`](https://github.com/canonhq/canon-private/commit/6054d47f7b885082237ee68eedbe6688af3d2f47))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`1957669`](https://github.com/canonhq/canon-private/commit/1957669600ea31b2285c65d8528592d4834f22a8))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`9b7663c`](https://github.com/canonhq/canon-private/commit/9b7663c08d32a314d8e66bd56b3344006e0a3c95))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`727583f`](https://github.com/canonhq/canon-private/commit/727583f3aaad1e134416c29b8edc81914b9b7de9))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`7dd2907`](https://github.com/canonhq/canon-private/commit/7dd2907e43bd273774b478f41299d707190e1d67))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`90e4db0`](https://github.com/canonhq/canon-private/commit/90e4db0779d5707ab0a2db7a02355d02b2278a84))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`013072b`](https://github.com/canonhq/canon-private/commit/013072bc640766f2eebcff88b3f5ad02dd508f5c))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`469af59`](https://github.com/canonhq/canon-private/commit/469af59bdd32f9bb63a6bb2d6109b1da53c20b17))

- **canon**: Sync ticket statuses in docs/specs/enhanced-platform-testing.md
  ([`ade30b7`](https://github.com/canonhq/canon-private/commit/ade30b751676c6b718fc6e422124d84a47780467))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`9fe3e9d`](https://github.com/canonhq/canon-private/commit/9fe3e9d224cc98b0dc4e11c559a18aaa55dc449f))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`19d55de`](https://github.com/canonhq/canon-private/commit/19d55de1717876399a85cedac7c687dedf00812a))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`4d0d2b5`](https://github.com/canonhq/canon-private/commit/4d0d2b58d138ec1dc79b731c5d5a743c89e48d40))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`dbaedb7`](https://github.com/canonhq/canon-private/commit/dbaedb7b50db7a88860311db9fa73afae8f70035))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`09ced44`](https://github.com/canonhq/canon-private/commit/09ced44449aefebba43264d470a312c66268a2d6))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3d66c33`](https://github.com/canonhq/canon-private/commit/3d66c33f73480ce2c50c3b123dad497d90ac9c84))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`ed2aee0`](https://github.com/canonhq/canon-private/commit/ed2aee0c99ac2209e181d5e8d2c4557ac60d0433))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`eae592a`](https://github.com/canonhq/canon-private/commit/eae592a3c49d6d2a6e7d5642394d863a39d58e87))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`8ea37a3`](https://github.com/canonhq/canon-private/commit/8ea37a370eb43a14a444aa7ca10523c4ab6e267c))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`7612217`](https://github.com/canonhq/canon-private/commit/76122175dc8c05726931c1ea1375030ef7ce5572))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`33a37b6`](https://github.com/canonhq/canon-private/commit/33a37b607b62edc0a9cf7b15d00f64cd487cdde1))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`2341d8f`](https://github.com/canonhq/canon-private/commit/2341d8fd05e4ef1d9a890a6f01a07b193f469dcd))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`52b217c`](https://github.com/canonhq/canon-private/commit/52b217c0f9f8633d53b9dc29dcce118c863457dd))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`17f9c8f`](https://github.com/canonhq/canon-private/commit/17f9c8f7dbeecbf2d58e769ad09eed42ca7a2eae))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3f93aff`](https://github.com/canonhq/canon-private/commit/3f93aff141883d64830e1bdf1016f2460dfc14f8))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`01d9d8f`](https://github.com/canonhq/canon-private/commit/01d9d8f1b5e2df97f24df8cd94ee372f0fdf39e9))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`012e841`](https://github.com/canonhq/canon-private/commit/012e8412b4662ee764fae3e0bd6a40e0e01d81ee))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`7062a6f`](https://github.com/canonhq/canon-private/commit/7062a6f48ceca4f9781ce72dacacd4c1aec12650))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`189f9bf`](https://github.com/canonhq/canon-private/commit/189f9bf57c933bd00d07902bfbdb71d70f57ac9d))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`db87580`](https://github.com/canonhq/canon-private/commit/db87580ea289e415abc8b471320374a2f06c4ae4))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3183a1a`](https://github.com/canonhq/canon-private/commit/3183a1a5a09f26e169f41dfce6866058b53361c0))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`d15be49`](https://github.com/canonhq/canon-private/commit/d15be49601e32abf1aa2c8fc467526a2ad431ce3))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3c47b21`](https://github.com/canonhq/canon-private/commit/3c47b21a49d6ac13c4873aa1bd0235f42d041a53))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`1afbe82`](https://github.com/canonhq/canon-private/commit/1afbe8238c594e39dd0ffb3565b177225e42e28a))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`6b27ce2`](https://github.com/canonhq/canon-private/commit/6b27ce2e3c40ce2ad13d2d320808be7b984fbc48))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`d8dea44`](https://github.com/canonhq/canon-private/commit/d8dea44f5a9e1a90c41a3c77419f0a4362053d3f))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`f306d09`](https://github.com/canonhq/canon-private/commit/f306d09a96a2e8bda20df8f023bf71ecab8c8d32))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`f227192`](https://github.com/canonhq/canon-private/commit/f227192644edf227caf14d8d3a5b6e41a6533137))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`c907901`](https://github.com/canonhq/canon-private/commit/c907901f845cce05f73bc819e908b1ea8409c9fc))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`25a7ad1`](https://github.com/canonhq/canon-private/commit/25a7ad1369135862ccb1892c5e324541a6f50193))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3a9d1c4`](https://github.com/canonhq/canon-private/commit/3a9d1c446d29b8bfa5e1f92d65778af50a79263b))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`81998ba`](https://github.com/canonhq/canon-private/commit/81998bade65796998a7d64c945b1ad3dc1d77237))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`d21b951`](https://github.com/canonhq/canon-private/commit/d21b951f8245bfaa485f5dd9d3fcc5800ddce83e))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`dfaf8de`](https://github.com/canonhq/canon-private/commit/dfaf8de9e42638742ecf17a609214bbd92d92707))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`5d49d8b`](https://github.com/canonhq/canon-private/commit/5d49d8b21916dc07e59a3fa0252036a8449864f3))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`d1142b3`](https://github.com/canonhq/canon-private/commit/d1142b330bebff0870d73566bcd12ed2793c14aa))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`70609e0`](https://github.com/canonhq/canon-private/commit/70609e04285cd6ab2e54f39cccd49a7499449ea6))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`3c90602`](https://github.com/canonhq/canon-private/commit/3c90602a8b0cc706d9c052f6c7b9be1894ba92ed))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`2ba97b4`](https://github.com/canonhq/canon-private/commit/2ba97b45a9865dcd71fa1c9769daa7ca447a9d33))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`9f59c2a`](https://github.com/canonhq/canon-private/commit/9f59c2a7b6fa8af76e998142c1912520d668a465))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`b30bc65`](https://github.com/canonhq/canon-private/commit/b30bc65f526edcac41805f331aa52ade413be4f1))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`20d9902`](https://github.com/canonhq/canon-private/commit/20d9902cac0def3688083f82c9951e6df7d717c3))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`e3961e4`](https://github.com/canonhq/canon-private/commit/e3961e42fe387a37ed3f243f780f7ea8ba73eb35))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`84e75d7`](https://github.com/canonhq/canon-private/commit/84e75d77071480584739d8318cb59c27fb373170))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`d657494`](https://github.com/canonhq/canon-private/commit/d65749418bab7e0adcdc8c97588c034757019cfe))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`bb8b0e1`](https://github.com/canonhq/canon-private/commit/bb8b0e18018980b2993fc76613907488cbf0f4bf))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`f4b3ff7`](https://github.com/canonhq/canon-private/commit/f4b3ff75af18d70f41d9525215ed89bc524d6aba))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`9d0cca3`](https://github.com/canonhq/canon-private/commit/9d0cca3aeea7be14604ad1ddbd976cc6d778e7e2))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`6a784e5`](https://github.com/canonhq/canon-private/commit/6a784e52a7037e8e7e21637b5df86d64a64b8f73))

- **canon**: Sync ticket statuses in docs/specs/integration-testing.md
  ([`420d4d7`](https://github.com/canonhq/canon-private/commit/420d4d720abcdc37e6c272716fa9800b08081e8b))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7ba19ba`](https://github.com/canonhq/canon-private/commit/7ba19ba94f67c58b8427f59ea2802f94e938a9b8))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`f368b28`](https://github.com/canonhq/canon-private/commit/f368b287d9048adc29e3151ba922a8443db0a873))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`2ed9e3d`](https://github.com/canonhq/canon-private/commit/2ed9e3dfae8a72d0c8ead802b0a7c71cba3b9a56))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`9654aee`](https://github.com/canonhq/canon-private/commit/9654aee6580524a96157045bbad3c5b0606e3a96))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`3cc5e53`](https://github.com/canonhq/canon-private/commit/3cc5e530b49a56cf56e488fb5b79adb067989784))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`c3db0d3`](https://github.com/canonhq/canon-private/commit/c3db0d39ca13503d70ef2299fc76f0aa506e32f9))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`e3422fa`](https://github.com/canonhq/canon-private/commit/e3422fa10c0bfc0d2b019956b8d1c3504eed6aa1))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`388b0fa`](https://github.com/canonhq/canon-private/commit/388b0fa2adebf099029cd47271a5b1dd53fb4af3))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`6ed2b39`](https://github.com/canonhq/canon-private/commit/6ed2b39e958510a3a8e1eb09f16b6a8af91c269d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`945ed5b`](https://github.com/canonhq/canon-private/commit/945ed5b07b7699a7edab87dbe98a108812e1e56b))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`a2f3de7`](https://github.com/canonhq/canon-private/commit/a2f3de7fecd4f47c73b8bc4ea9909ab8a9d10ce6))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`510f41b`](https://github.com/canonhq/canon-private/commit/510f41ba132703b9584369daf6433ebbb7d1ad01))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ec6a82b`](https://github.com/canonhq/canon-private/commit/ec6a82b668855b8e3d9c02b0c192679bbe741b33))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`5712532`](https://github.com/canonhq/canon-private/commit/5712532b145bfdc217696b690170a8b3588ac7e3))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`d825afc`](https://github.com/canonhq/canon-private/commit/d825afc5568eba574e455f70e71684142fc935ff))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`3f92286`](https://github.com/canonhq/canon-private/commit/3f92286795cdc9cdccc600eb5362e154eae8194a))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`16d20b9`](https://github.com/canonhq/canon-private/commit/16d20b9c0afc893c8caf3569d8a6507f4a24c600))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`0797dd2`](https://github.com/canonhq/canon-private/commit/0797dd2f4e31c29748d5be93ca162f2453519a2f))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ab9b738`](https://github.com/canonhq/canon-private/commit/ab9b7383c1b62415339647c15ff9395880daffed))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7fb2815`](https://github.com/canonhq/canon-private/commit/7fb2815365e07857a2cf1cea69238d786ee3506d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`3a14cad`](https://github.com/canonhq/canon-private/commit/3a14cad7f23ef06a25ba32f6f7215e3daf2ba675))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`40c8b60`](https://github.com/canonhq/canon-private/commit/40c8b606fc70a637f3471858a866c260cfc7dc5e))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7912121`](https://github.com/canonhq/canon-private/commit/79121211aa5c6213678bf078533f9837bf91b13f))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`7f6ba92`](https://github.com/canonhq/canon-private/commit/7f6ba92dc4949ca5d85fb47bfe2d809856dac4da))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ba3b771`](https://github.com/canonhq/canon-private/commit/ba3b7712a66cfe260d2cf6f124830f627215571f))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`868c897`](https://github.com/canonhq/canon-private/commit/868c897e1c8a5da73244a59f81435ecda76a10d4))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`3ba31de`](https://github.com/canonhq/canon-private/commit/3ba31de35554071b137471b47a98c581079e379c))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`6fa082d`](https://github.com/canonhq/canon-private/commit/6fa082de8363c7218eff1ce1933ca8e23cc6eae9))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`eb5ea59`](https://github.com/canonhq/canon-private/commit/eb5ea5988c4b2fc1f117de44c852a026ccc586b2))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`d358f0e`](https://github.com/canonhq/canon-private/commit/d358f0e6e618d0a1c94106e0e041fd97d8b24f66))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`e547858`](https://github.com/canonhq/canon-private/commit/e547858b0934e00bf593f83599fd1a8ba6ac0c8c))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`5b8dd66`](https://github.com/canonhq/canon-private/commit/5b8dd6639b3f28664f4d891a63366165e2b688c6))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`c398261`](https://github.com/canonhq/canon-private/commit/c398261cdedaf3ad9727b110f44ef9be7d4e2f6a))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`fad57ee`](https://github.com/canonhq/canon-private/commit/fad57eee830274ffd5a82952ce093f04979a86e8))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`ae6b7b4`](https://github.com/canonhq/canon-private/commit/ae6b7b43626cb4ee4eee34e6702dd0ba4a91df54))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`af08b87`](https://github.com/canonhq/canon-private/commit/af08b87cd15643065ba88bb331066705937f6040))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`e8224aa`](https://github.com/canonhq/canon-private/commit/e8224aaf8fa5e0bed3c66af52de31c0661f65b43))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`621f510`](https://github.com/canonhq/canon-private/commit/621f510c4636953cba6f312ce82bf66d7efd124d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`8fdf09b`](https://github.com/canonhq/canon-private/commit/8fdf09b08838c90b1037402ae3d71f2cb384b822))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`9f7668b`](https://github.com/canonhq/canon-private/commit/9f7668bbd8e0553cfa5896a570516884bf61e1c5))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`9af92af`](https://github.com/canonhq/canon-private/commit/9af92af6dd2fa8dfb73cf76d1ee4629eb13676b5))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`27d5218`](https://github.com/canonhq/canon-private/commit/27d52180bca73d90fba3bfb6e856a006245f8825))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`aeb73c1`](https://github.com/canonhq/canon-private/commit/aeb73c19515ff56d9c41c0c953ee4bd521af82cd))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`36749d1`](https://github.com/canonhq/canon-private/commit/36749d12cf450ceaa686e48991359ef0af9aa43d))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`110523c`](https://github.com/canonhq/canon-private/commit/110523cc74458b94a40a4d1ebed0ba4be964f1cd))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`2adde2f`](https://github.com/canonhq/canon-private/commit/2adde2f678db95fbc41fb7ef2cae8aa323e62e40))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`9068b2e`](https://github.com/canonhq/canon-private/commit/9068b2e18419635eb80d78cf8f7a3789f72ab2d7))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`f9a1039`](https://github.com/canonhq/canon-private/commit/f9a10395488352ca3c5343cab5ee928bf2d1b7c0))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`22adb09`](https://github.com/canonhq/canon-private/commit/22adb094d816411c8849820d65d3f13057ed15fd))

- **canon**: Sync ticket statuses in docs/specs/marketing-site-revamp.md
  ([`59a0ed5`](https://github.com/canonhq/canon-private/commit/59a0ed5db1a1f2341e2e70c53e9d6fd7a2fad18c))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`0ce3d61`](https://github.com/canonhq/canon-private/commit/0ce3d6139b5f62f862e1ee94c93d82ed8468e8e9))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`971a26e`](https://github.com/canonhq/canon-private/commit/971a26ed7daa7b23b7ffeb311c087a63bcf8726c))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`e9ad445`](https://github.com/canonhq/canon-private/commit/e9ad4451213524fd5fe42094578216925cbab0cf))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`d933234`](https://github.com/canonhq/canon-private/commit/d93323409ad36a1930bcaa57735b41971c087f78))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`3a0977a`](https://github.com/canonhq/canon-private/commit/3a0977ace928ee67bedc7a9f9d50403bba4c8828))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`fcc62d0`](https://github.com/canonhq/canon-private/commit/fcc62d07d51dcfa2d578781ecb192b9592604b7d))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`4d3c71f`](https://github.com/canonhq/canon-private/commit/4d3c71f67aa210b72b00d8623e4b8150d43bb16f))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`dc07956`](https://github.com/canonhq/canon-private/commit/dc07956091c6cabc4e906f9e6742bc5e1badbf3a))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`6dd3f70`](https://github.com/canonhq/canon-private/commit/6dd3f7027cac59c7b84071a959c06efb41cc485f))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`639309a`](https://github.com/canonhq/canon-private/commit/639309a62f09e4a107be68791918b933870d2ad2))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`92d463e`](https://github.com/canonhq/canon-private/commit/92d463e1b69845492871b8019a2180750e790c69))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`3dc551e`](https://github.com/canonhq/canon-private/commit/3dc551e342418f2f5bd2303f54162de11e3f8b7b))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`64f954b`](https://github.com/canonhq/canon-private/commit/64f954bf73639f6a11127aec08e75983ef351499))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`541e50f`](https://github.com/canonhq/canon-private/commit/541e50f009d1f137afa9dd103e4c4907a4f25a35))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`3a93e42`](https://github.com/canonhq/canon-private/commit/3a93e423d55cbe1730e7451428253b634899a05a))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`782a798`](https://github.com/canonhq/canon-private/commit/782a798be0819a1da471c2458b930bca50ba5c2e))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`d026d94`](https://github.com/canonhq/canon-private/commit/d026d94c40d92ae6da55f509fc13bd480f952b2e))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`7fe743a`](https://github.com/canonhq/canon-private/commit/7fe743aa2836ec6892d779b5e31ec0c97bca153a))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`2e0f161`](https://github.com/canonhq/canon-private/commit/2e0f161c43f7172807b6fd69185104eb9564faf5))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`4043e3b`](https://github.com/canonhq/canon-private/commit/4043e3b5f512b4068c67fa423e90b8b26cdfcb0a))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`42fc77a`](https://github.com/canonhq/canon-private/commit/42fc77a924c4f210476cd2b33a967d6cbd653682))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`389b616`](https://github.com/canonhq/canon-private/commit/389b61690b697600e7eb2c3ad28c56afdb6cd536))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`5cc34eb`](https://github.com/canonhq/canon-private/commit/5cc34ebc7bbc3b716a437de86aff71b327d35a37))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`cd79a25`](https://github.com/canonhq/canon-private/commit/cd79a25907cfad0d97cc3d9f4eab03c6d6c333d9))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`d31a4bd`](https://github.com/canonhq/canon-private/commit/d31a4bd9bbefdfddb90a53f22700b6b635e89342))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`04ad369`](https://github.com/canonhq/canon-private/commit/04ad3697f0357284509829cec534467810fcfe80))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`bf8d818`](https://github.com/canonhq/canon-private/commit/bf8d818088e24d3caa984831fd72fbe81d146baa))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`d1542c1`](https://github.com/canonhq/canon-private/commit/d1542c1cd9fb23b9a1cbe6484548575df85592d7))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`e3cd01e`](https://github.com/canonhq/canon-private/commit/e3cd01ef9b7dec3145aa30bc31423a0d08f97eb8))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`b1a6124`](https://github.com/canonhq/canon-private/commit/b1a6124e953c9f25df8255c65ad58c1965b001ad))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`6fa58c2`](https://github.com/canonhq/canon-private/commit/6fa58c26394c7391cf8f72f5e1542e762672a0cc))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`25906e4`](https://github.com/canonhq/canon-private/commit/25906e4de53a0a703d14d5b817f16a299bdca424))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`37afd52`](https://github.com/canonhq/canon-private/commit/37afd52c4f8f9111814c36c9c3226642956c4fc0))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`b092294`](https://github.com/canonhq/canon-private/commit/b092294686025ffc016f22fe032e751ff8bf0279))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`22a7c9e`](https://github.com/canonhq/canon-private/commit/22a7c9e7d761ccbb3c49f4cead03066a3737c12f))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`6b1aaba`](https://github.com/canonhq/canon-private/commit/6b1aaba801d135d4480522de335d3d5618b99be5))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`bb75f87`](https://github.com/canonhq/canon-private/commit/bb75f876ad28523b645ac360c5f801785e754798))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`06e38d5`](https://github.com/canonhq/canon-private/commit/06e38d55f283c15affecef655fce14faec5160c6))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`71fa808`](https://github.com/canonhq/canon-private/commit/71fa808f235623d3dcc17c261a89824ed3f7db7b))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`e5665f4`](https://github.com/canonhq/canon-private/commit/e5665f46e22d6b8af119c4083d2a0ef39dd281a4))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`91d2e98`](https://github.com/canonhq/canon-private/commit/91d2e981105b70337c92a386b5d9504766f3c1fe))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`c94746e`](https://github.com/canonhq/canon-private/commit/c94746e26e857811cd5919f52b0ad74c94036473))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`4fa19d1`](https://github.com/canonhq/canon-private/commit/4fa19d1bc2ba6fd6830ba9d55eb6e219135edc25))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`5a1f7d7`](https://github.com/canonhq/canon-private/commit/5a1f7d72b74bb2a73f13c6181afdc30b43e88010))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`c7cdf78`](https://github.com/canonhq/canon-private/commit/c7cdf784bc3a400e0edcf308b3db4228a07d9887))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`fc51a43`](https://github.com/canonhq/canon-private/commit/fc51a43a81da33a7cd8aef72473523a0ba920f63))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`e5313be`](https://github.com/canonhq/canon-private/commit/e5313bead1f7388621d039cabf380cc52b8d4394))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`266cb22`](https://github.com/canonhq/canon-private/commit/266cb227c5bb8b6ed90b74038ae850247a595a6c))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`dd73209`](https://github.com/canonhq/canon-private/commit/dd73209f273c4568a89d1ffc64fdbdba7581edbd))

- **canon**: Sync ticket statuses in docs/specs/oidc-migration.md
  ([`e65ce16`](https://github.com/canonhq/canon-private/commit/e65ce16b736452d4da325524473906d5256fa1ed))

- **canon**: Sync ticket statuses in docs/specs/security-vulnerabilities.md
  ([`bf611c0`](https://github.com/canonhq/canon-private/commit/bf611c02b70212a05f19c6f5618470244076934f))

- **canon**: Sync ticket statuses in docs/specs/setup-ux-improvements.md
  ([`4f731ef`](https://github.com/canonhq/canon-private/commit/4f731eff25bdf468bd877a8a163e9f75b943bdf6))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`ad8bdb8`](https://github.com/canonhq/canon-private/commit/ad8bdb8f490d1853fa0dec530620e0ffb4bf691f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`047b7d6`](https://github.com/canonhq/canon-private/commit/047b7d6399e26ec8d7c6f79ad4677b1e1ac37a8c))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`8432a2a`](https://github.com/canonhq/canon-private/commit/8432a2a3f780f0fd002a4288f7fdf7daea82a833))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`6d06809`](https://github.com/canonhq/canon-private/commit/6d0680995cbd9833bb3874ecd42e005e4c631e0a))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`22ae80e`](https://github.com/canonhq/canon-private/commit/22ae80e2a8c08fc2315bd114916cef26f9d0106b))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`99d743b`](https://github.com/canonhq/canon-private/commit/99d743b9bd0f513b1ebcb3d5e8185e3722cf061e))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`04ff2cd`](https://github.com/canonhq/canon-private/commit/04ff2cd0ea7dfb2deae3d188ac6c0d01407f8946))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`4c3ce3e`](https://github.com/canonhq/canon-private/commit/4c3ce3e65008c76f6702aee1ee4a97f2d03e8b55))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`72f4fae`](https://github.com/canonhq/canon-private/commit/72f4fae9617cbe56a28fd59390ca306876678b47))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`c0443e5`](https://github.com/canonhq/canon-private/commit/c0443e581d9bf34ba2b82792106bd79e7cea3047))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`eb5df14`](https://github.com/canonhq/canon-private/commit/eb5df142a9e52e0ae333f512eb2296575ab12221))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`7f9919b`](https://github.com/canonhq/canon-private/commit/7f9919b60f2085d5e2d5ef5512253e417cdaf0f6))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`59255c9`](https://github.com/canonhq/canon-private/commit/59255c945f6a840efffc2e722b661d21ef23908d))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`b69e9b9`](https://github.com/canonhq/canon-private/commit/b69e9b9f2421f1c07b4743229ba7665b652678ab))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`0eaf30a`](https://github.com/canonhq/canon-private/commit/0eaf30ae16f8425008c4897c1602598dca4fde14))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`0768305`](https://github.com/canonhq/canon-private/commit/076830562e929ac635524ba7a0ff2ddb5be04617))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`75036be`](https://github.com/canonhq/canon-private/commit/75036be8f440304002672cd1ce59d08233e6337b))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`b389dca`](https://github.com/canonhq/canon-private/commit/b389dca1975eb16cbfadc4c6a3db6f7e1aadb732))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`1cc3807`](https://github.com/canonhq/canon-private/commit/1cc3807c935bc42d007d9cd71420fb6d6fbc47da))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`9d6c595`](https://github.com/canonhq/canon-private/commit/9d6c595e4102e34e89e8d677fd9d72a497ac2d85))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`9a028d2`](https://github.com/canonhq/canon-private/commit/9a028d259639206b31a4ff0f993623b429826a91))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`7a17356`](https://github.com/canonhq/canon-private/commit/7a173560a8d353011c85c5631f188236c6d866fe))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`095b3fd`](https://github.com/canonhq/canon-private/commit/095b3fd4ed7318a040966ee846bdb7b389dba42d))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`0ce5fa1`](https://github.com/canonhq/canon-private/commit/0ce5fa17c7111038d11fd6108b03c32d32a09aa6))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`cd2e674`](https://github.com/canonhq/canon-private/commit/cd2e6745aa3bc3a3fb9dea8ef8fbb7e4d3527b45))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`48736b7`](https://github.com/canonhq/canon-private/commit/48736b716596d8437337ca4e1d668f85075b4bd1))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`3f2ea85`](https://github.com/canonhq/canon-private/commit/3f2ea85994b2dfe057f7abcfff91b56ba26af630))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`9210c36`](https://github.com/canonhq/canon-private/commit/9210c36b85c779b14ce736f054c86b8f4dca5113))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`e5a0726`](https://github.com/canonhq/canon-private/commit/e5a0726226984d78a9d40926358aaa9ade7b4db4))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`b914444`](https://github.com/canonhq/canon-private/commit/b9144449901eca45568cf237487428899d1bfc9f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`b46a245`](https://github.com/canonhq/canon-private/commit/b46a245be60e1ff450276c1703ea3a10fa23dee9))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`bcc6a94`](https://github.com/canonhq/canon-private/commit/bcc6a94d814a8e5ed5c003a9b371f646855fec77))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`ec562f8`](https://github.com/canonhq/canon-private/commit/ec562f8c5f856c48bbf759b1a47497804cf19675))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`7bf7ad0`](https://github.com/canonhq/canon-private/commit/7bf7ad0b1be1417f17b0697e556ff15834a2d342))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`8456e23`](https://github.com/canonhq/canon-private/commit/8456e23e6f648baef6ac5858b2f92a889f216450))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`7ef4180`](https://github.com/canonhq/canon-private/commit/7ef4180dbe890c17b88872027706ebc3b50b9ac4))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`f377a4f`](https://github.com/canonhq/canon-private/commit/f377a4fc45f664b3f740aa4f29e14e5a10c37533))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`d9a5984`](https://github.com/canonhq/canon-private/commit/d9a59841ee30112a1c4dfda50bb436d9bc1ebc0b))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`5246c1b`](https://github.com/canonhq/canon-private/commit/5246c1b92f9311c5a08d11b5eec97b578887a2f2))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`145a7a3`](https://github.com/canonhq/canon-private/commit/145a7a398ccc69456c26e567b4b1f4c3534edde6))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`882b185`](https://github.com/canonhq/canon-private/commit/882b185d35c322f2b761c27e05f91a6482bc25ac))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`c9ca07a`](https://github.com/canonhq/canon-private/commit/c9ca07aec80819e051feb51a03506209f838ecd9))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`c650b3c`](https://github.com/canonhq/canon-private/commit/c650b3cb62bcfd44031e87de2058784b9650603f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`a204ba7`](https://github.com/canonhq/canon-private/commit/a204ba7b05a655fe4c4e23d8e3c2e0f4f53d0ddf))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`4f70025`](https://github.com/canonhq/canon-private/commit/4f70025ef597ef5f059bc500c1b9d8c968de5310))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`84b81d2`](https://github.com/canonhq/canon-private/commit/84b81d2ea205b8648560aae5bc1be6a27639eff2))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`50f705c`](https://github.com/canonhq/canon-private/commit/50f705c1344399ac0d167c0915b181b98fba1735))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`ae6a4da`](https://github.com/canonhq/canon-private/commit/ae6a4da46e098cf39d6b1004a2e06f0dad072f34))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`fc791c7`](https://github.com/canonhq/canon-private/commit/fc791c71b4cedd18590f7d0e4c854bdf4d99666f))

- **canon**: Sync ticket statuses in docs/specs/spec-review-workflow.md
  ([`702856d`](https://github.com/canonhq/canon-private/commit/702856d4169263b9897cd1ab10971e781c8965f6))

- **canon**: Sync ticket statuses in docs/specs/theme-toggle-light-mode.md
  ([`ae3de99`](https://github.com/canonhq/canon-private/commit/ae3de99ff2452bfd571b20550027ecc7fb0deb4a))

- **canon**: Sync ticket statuses in docs/specs/ticket-sync-enhancements.md
  ([`815bf67`](https://github.com/canonhq/canon-private/commit/815bf6781b15647777fa87ee1ca81e68dc2e3623))

- **canon**: Sync ticket statuses in docs/specs/ticket-sync-reliability.md
  ([`0f9e556`](https://github.com/canonhq/canon-private/commit/0f9e5561ec4a1491bdbdb5cbb74f5ad9fe58b1e7))

- **canon**: Sync ticket statuses in docs/specs/user-profile-page.md
  ([`6c740e3`](https://github.com/canonhq/canon-private/commit/6c740e3e55fe6f95a2575da6d3b39542cf125539))


## v1.52.4 (2026-04-15)

### Bug Fixes

- Env var / auth_profile credentials take precedence over installation token
  ([`fcdc410`](https://github.com/canonhq/canon-private/commit/fcdc410e7b87fe9679c857494a8028d01443a729))

### Chores

- Sync uv.lock with main (v1.52.3)
  ([`720a8fa`](https://github.com/canonhq/canon-private/commit/720a8fa8dfa04763d22af48c8a1de865b87ac461))

- **canon**: Update specs from PR #512
  ([`21dd786`](https://github.com/canonhq/canon-private/commit/21dd786ffaa35af3229efe73216ad3063a66f05e))

- **canon**: Update specs from PR #512
  ([`df9423b`](https://github.com/canonhq/canon-private/commit/df9423b78e0e21c94ff6e27cd5ed960bbe6b4c7d))

### Code Style

- Fix ruff format in test_on_push_sync_instrumentation.py
  ([`85235f5`](https://github.com/canonhq/canon-private/commit/85235f5120601b66655b48cf8fe4d7bf23d152ef))


## v1.52.3 (2026-04-15)

### Bug Fixes

- **admin**: Cast IPv4Address to str in audit event response
  ([#511](https://github.com/canonhq/canon-private/pull/511),
  [`2b33439`](https://github.com/canonhq/canon-private/commit/2b334394f99773ce4a90f54c2c95a62bfe45714e))


## v1.52.2 (2026-04-15)

### Bug Fixes

- Choose-org page returns HTML instead of JSON for org list
  ([#510](https://github.com/canonhq/canon-private/pull/510),
  [`561615e`](https://github.com/canonhq/canon-private/commit/561615ea3849da457ef110a12e9aa78ed0ee14e6))

- Choose-org page shows no orgs due to SPA intercepting JSON fetch
  ([#510](https://github.com/canonhq/canon-private/pull/510),
  [`561615e`](https://github.com/canonhq/canon-private/commit/561615ea3849da457ef110a12e9aa78ed0ee14e6))

### Chores

- Sync uv.lock version with pyproject.toml
  ([#510](https://github.com/canonhq/canon-private/pull/510),
  [`561615e`](https://github.com/canonhq/canon-private/commit/561615ea3849da457ef110a12e9aa78ed0ee14e6))

- Update uv.lock for v1.52.1 ([#510](https://github.com/canonhq/canon-private/pull/510),
  [`561615e`](https://github.com/canonhq/canon-private/commit/561615ea3849da457ef110a12e9aa78ed0ee14e6))

- **canon**: Update specs from PR #510
  ([`1d916f7`](https://github.com/canonhq/canon-private/commit/1d916f734d6ae0a921a522210b6aee3ff1677c09))

### Documentation

- Snapshot v1.52 docs
  ([`5b7d256`](https://github.com/canonhq/canon-private/commit/5b7d25618c1fb366fd8e15e6a59d2c3669445604))


## v1.52.1 (2026-04-15)

### Bug Fixes

- Sync missing OSS modules and guard cloud-only imports
  ([#509](https://github.com/canonhq/canon-private/pull/509),
  [`6a337f3`](https://github.com/canonhq/canon-private/commit/6a337f3c8006619b66cb7faf88ea2c6588834e72))

- Sync transitive dependencies missed in first pass
  ([#509](https://github.com/canonhq/canon-private/pull/509),
  [`6a337f3`](https://github.com/canonhq/canon-private/commit/6a337f3c8006619b66cb7faf88ea2c6588834e72))

- Use find_spec instead of bare ImportError for cloud-only modules
  ([#509](https://github.com/canonhq/canon-private/pull/509),
  [`6a337f3`](https://github.com/canonhq/canon-private/commit/6a337f3c8006619b66cb7faf88ea2c6588834e72))

### Chores

- Regenerate uv.lock after rebase ([#509](https://github.com/canonhq/canon-private/pull/509),
  [`6a337f3`](https://github.com/canonhq/canon-private/commit/6a337f3c8006619b66cb7faf88ea2c6588834e72))

- **canon**: Update specs from PR #509
  ([`cc4bf4a`](https://github.com/canonhq/canon-private/commit/cc4bf4aa57f4a53dd64842e691d713fcd16bede2))

- **canon**: Update specs from PR #509
  ([`01c6349`](https://github.com/canonhq/canon-private/commit/01c6349b54c128810fada5e1843b576675e052b1))

- **canon**: Update specs from PR #509
  ([`c86194e`](https://github.com/canonhq/canon-private/commit/c86194e4368803082e7adccde746bfeef20ff3a9))

### Code Style

- Ruff format main.py ([#509](https://github.com/canonhq/canon-private/pull/509),
  [`6a337f3`](https://github.com/canonhq/canon-private/commit/6a337f3c8006619b66cb7faf88ea2c6588834e72))

### Documentation

- Snapshot v1.52 docs
  ([`e4c36e1`](https://github.com/canonhq/canon-private/commit/e4c36e10b56759f9488fd3f383eb1a6b40be83fe))


## v1.52.0 (2026-04-15)

### Bug Fixes

- Address PR review findings for org_memberships fallback
  ([#507](https://github.com/canonhq/canon-private/pull/507),
  [`31cd5f4`](https://github.com/canonhq/canon-private/commit/31cd5f4b03423b8270b3052cf91e10773d00df0d))

### Chores

- Regenerate uv.lock after rebase on v1.51.1
  ([#507](https://github.com/canonhq/canon-private/pull/507),
  [`31cd5f4`](https://github.com/canonhq/canon-private/commit/31cd5f4b03423b8270b3052cf91e10773d00df0d))

### Documentation

- Snapshot v1.51 docs
  ([`ee2a75c`](https://github.com/canonhq/canon-private/commit/ee2a75cd0c67e180c8cd4d46ab6995a383efb8d4))

### Features

- Add 56 more integration tests + per-module coverage breakdown
  ([#507](https://github.com/canonhq/canon-private/pull/507),
  [`31cd5f4`](https://github.com/canonhq/canon-private/commit/31cd5f4b03423b8270b3052cf91e10773d00df0d))

- Expand integration test coverage to 192 tests + fix 3 auth bugs
  ([#507](https://github.com/canonhq/canon-private/pull/507),
  [`31cd5f4`](https://github.com/canonhq/canon-private/commit/31cd5f4b03423b8270b3052cf91e10773d00df0d))


## v1.51.1 (2026-04-15)

### Bug Fixes

- Add status_code and LLM cost tracking to PostHog events
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- Address PR review — consistent property names, tests, unknown model warning
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- Align prod subscriptions schema and harden JWT validation
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- Block sensitive path probes (.git, .env, wp-admin)
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- Lockfile sync + migration safety guards from CI review
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- PostHog reliability gaps — schema, JWT, instrumentation, security
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

- Protect finally block from estimate_cost failure masking exceptions
  ([#508](https://github.com/canonhq/canon-private/pull/508),
  [`0fe103a`](https://github.com/canonhq/canon-private/commit/0fe103a4b56c4267769ef67d301edf9f05cd2a72))

### Documentation

- Snapshot v1.51 docs
  ([`663fdae`](https://github.com/canonhq/canon-private/commit/663fdae0bb78295fb82f08f827cfefce7fbc2418))


## v1.51.0 (2026-04-15)

### Bug Fixes

- Ruff format violations in 6 files after rebase
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **db**: Renumber session_evidence migration from 0007 to 0009
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **evidence**: Catch ValidationError in _append_session_record and run_show
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: PR #501 important findings — concurrency, types, hook tests, docstrings
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: PR #501 review round 2 — lint + remaining security gates
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: PR #501 review round 3 — gate semantics, type safety, silent failures
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: PR #501 review round 5 — push error handling, gate bypass, timestamp comparison
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Security + bug fixes from PR #501 review
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **security**: Normalize evidence spec slug before ai_exposure lookup
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **security**: Normalize spec slug in acs_addressed loop too
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **test**: Update MCP tool count for new record_session_evidence tool
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

### Chores

- Refresh uv.lock after rebase (1.50.0 → 1.50.1)
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Evidence pipeline follow-ups — ai_exposure filter, version check, docs
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Manifest hygiene + README polish (plugin-product-polish §2)
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

### Documentation

- Snapshot v1.50 docs
  ([`e34cb96`](https://github.com/canonhq/canon-private/commit/e34cb961796440be9e63b82eddf6a4e87d03517d))

- **specs**: Convert plugin-evidence-pipeline realization markers to symbol form
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **specs**: Reconcile plugin specs and add product polish + evidence pipeline
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

### Features

- **plugin**: Canon plugin product polish + dev→PR evidence pipeline
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Evidence pipeline foundation — schema, capture, verify trail (plugin-evidence-pipeline
  §2-4) ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Evidence pipeline §5 — push hook persistence + .gitignore automation
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Evidence pipeline §6+§7 — MCP tool + GitHub App analyzer hint
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Reviewer auto-dispatch + e2e test + canon verify --gate (plugin-product-polish §7-9)
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Slash commands, output style, statusline (plugin-product-polish §5, §6)
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))

- **plugin**: Structured hook config + Iron Laws SessionStart (plugin-product-polish §3, §4)
  ([#501](https://github.com/canonhq/canon-private/pull/501),
  [`f382140`](https://github.com/canonhq/canon-private/commit/f38214098e458ae0073d22a1fa2b80931555f5c5))


## v1.50.1 (2026-04-15)

### Bug Fixes

- **agent**: Upgrade to Sonnet 4.6 + dynamic prompt budgeting
  ([#506](https://github.com/canonhq/canon-private/pull/506),
  [`a9750ef`](https://github.com/canonhq/canon-private/commit/a9750effde47e2fbf3ddccb480b613a5ebb8bd1b))

- **agent**: Upgrade to Sonnet 4.6 and add dynamic prompt budgeting
  ([#506](https://github.com/canonhq/canon-private/pull/506),
  [`a9750ef`](https://github.com/canonhq/canon-private/commit/a9750effde47e2fbf3ddccb480b613a5ebb8bd1b))

### Chores

- Update uv.lock for v1.50.0 ([#506](https://github.com/canonhq/canon-private/pull/506),
  [`a9750ef`](https://github.com/canonhq/canon-private/commit/a9750effde47e2fbf3ddccb480b613a5ebb8bd1b))

- **canon**: Update specs from PR #506
  ([`6d43baa`](https://github.com/canonhq/canon-private/commit/6d43baa691d302480deb569c3011544214a68119))

### Documentation

- Snapshot v1.50 docs
  ([`56e7038`](https://github.com/canonhq/canon-private/commit/56e7038906bc4eb7fe7fc544263bdc5e1973a2b7))


## v1.50.0 (2026-04-14)

### Bug Fixes

- **actions**: Address PR review — event loop blocking, silent failures, stale bug
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Address PR review — security, data loss, metering bugs
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Address second PR review pass — pipefail, env injection, supply chain pinning, python
  heredoc ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **ci**: Make claude-review advisory and increase max turns
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **ci**: Scope actionlint to suite workflows, drop unused LINT_EXIT
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

### Chores

- Regenerate uv.lock for canonhq 1.46.4 ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- Regenerate uv.lock for canonhq 1.47.0 ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- Regenerate uv.lock for canonhq 1.48.0 ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- Regenerate uv.lock for canonhq 1.49.0 ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- Regenerate uv.lock for canonhq 1.49.1 ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

### Code Style

- Apply ruff format to slice 1-13 source and tests
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

### Documentation

- Snapshot v1.49 docs
  ([`e49b558`](https://github.com/canonhq/canon-private/commit/e49b5581ea41171caed2395c0b5ef774980b8ebc))

### Features

- **actions**: Add audit action — scheduled drift detection (issue/pr/summary)
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add compliance-export and upgrade actions, canon export CLI
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add coverage-delta action — per-PR base-vs-head coverage diff
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add coverage-report action and GitHub Actions docs section
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add dedup and stale-spec-check actions, canon stale CLI
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add plan and new-spec actions, canon new CLI
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add release-notes action and canon release-notes CLI
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add sync action and weekly-audit reusable workflow
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Add verify action and pr-checks reusable workflow
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: GitHub Actions Suite — 14 actions, 2 reusable workflows, full V1.2 spec
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Publishing pipeline + CI smoke tests for the action suite
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Scaffold GitHub Actions suite with canon lint and spec-lint action
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

- **actions**: Wire canon audit through backend /v1/actions/audit endpoint
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))

### Testing

- **actions**: Add actionlint + nektos/act runtime test, mark §3.20 done
  ([#500](https://github.com/canonhq/canon-private/pull/500),
  [`bed6941`](https://github.com/canonhq/canon-private/commit/bed69410075e358db80694092bea2f1f9659835d))


## v1.49.1 (2026-04-14)

### Bug Fixes

- **admin**: Address 7 review findings + test gaps from PR #502 review
  ([`6db39f3`](https://github.com/canonhq/canon-private/commit/6db39f3ab78165100588330567607e56d97056e1))

- **admin**: Address review findings from PR #502
  ([`6db39f3`](https://github.com/canonhq/canon-private/commit/6db39f3ab78165100588330567607e56d97056e1))

- **admin**: Log registry lookup failures in org membership endpoints
  ([`6db39f3`](https://github.com/canonhq/canon-private/commit/6db39f3ab78165100588330567607e56d97056e1))

- **admin**: Restore rightmost X-Forwarded-For as fallback for single-proxy topology
  ([`6db39f3`](https://github.com/canonhq/canon-private/commit/6db39f3ab78165100588330567607e56d97056e1))

### Documentation

- Mark P0 admin UI sections as shipped
  ([`380149e`](https://github.com/canonhq/canon-private/commit/380149e375494d9af86735b91def5ba6420f7e2c))

- Snapshot v1.49 docs
  ([`74962d8`](https://github.com/canonhq/canon-private/commit/74962d8e24290ab0e173366aede591103b2ec663))


## v1.49.0 (2026-04-14)

### Bug Fixes

- **admin**: Actionable 502 message for Auth0 orphan + filter expired API keys
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Address 3 critical review findings + add test coverage
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Concurrent member count fetches + DB-before-Auth0 in org PATCH
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: False audit on null meta fields + quote all Auth0 URL params
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Include oidc_org_id in org list so membership dropdown populates
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Path injection in org routes + GDPR delete for empty-profile users
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Show Auth0 member counts in org list instead of phantom user_count
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

### Chores

- Apply ruff format
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- Regenerate uv.lock after main merge
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- Sync uv.lock with main 1.48.0
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

### Code Style

- Fix ruff format violation in test_admin_store
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

### Documentation

- Snapshot v1.48 docs
  ([`9c47d27`](https://github.com/canonhq/canon-private/commit/9c47d2793bf1b1603a4117f1be04780ace39e281))

### Features

- **admin**: Editable org metadata in admin UI
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: GDPR user delete with Auth0 rollback
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Manage Auth0 org memberships from user detail page
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Per-session and per-key revocation in admin UI
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Repair-auth0 endpoint for failed org provisioning
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: Spec admin UI user/org management + Auth0 update_organization
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: User & organization management — P0 spec implementation
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))

- **admin**: User invitation and password reset endpoints
  ([`f5c12c8`](https://github.com/canonhq/canon-private/commit/f5c12c851bf4447083f51cb5c6a5184feca9bff7))


## v1.48.0 (2026-04-11)

### Chores

- **canon**: Update specs from PR #503
  ([`42046df`](https://github.com/canonhq/canon-private/commit/42046df65ea80bc1f737f57df14d3126a89cdae7))

### Documentation

- Snapshot v1.47 docs
  ([`69c036b`](https://github.com/canonhq/canon-private/commit/69c036b18229fa589bf49ce08636eb95468e6af0))

### Features

- **observability**: Per-spec sync events with adapter tagging for ticket sync dashboard
  ([#503](https://github.com/canonhq/canon-private/pull/503),
  [`ffe628f`](https://github.com/canonhq/canon-private/commit/ffe628fd399eef9882b9f3c985df1c03a98a5c9c))


## v1.47.0 (2026-04-11)

### Bug Fixes

- **observability**: Emit device_auth_completed in 3 post-token-exchange error paths
  ([#499](https://github.com/canonhq/canon-private/pull/499),
  [`875a744`](https://github.com/canonhq/canon-private/commit/875a744d1ca570a2c7f2484721d2270b76f548b7))

### Chores

- Sync uv.lock to main's 1.46.4 ([#499](https://github.com/canonhq/canon-private/pull/499),
  [`875a744`](https://github.com/canonhq/canon-private/commit/875a744d1ca570a2c7f2484721d2270b76f548b7))

### Documentation

- Snapshot v1.46 docs
  ([`1d8ed17`](https://github.com/canonhq/canon-private/commit/1d8ed17a6ecb2e02bc487178dd658f0e5af8bf2d))

### Features

- **observability**: Apply tracked_cron to 6 missing crons + instrument device auth flow
  ([#499](https://github.com/canonhq/canon-private/pull/499),
  [`875a744`](https://github.com/canonhq/canon-private/commit/875a744d1ca570a2c7f2484721d2270b76f548b7))


## v1.46.4 (2026-04-11)

### Bug Fixes

- **cli**: Stop pytest from spawning chromium tabs on every run
  ([#498](https://github.com/canonhq/canon-private/pull/498),
  [`34952e7`](https://github.com/canonhq/canon-private/commit/34952e73950b19db09bf0f09c51f766cdc59e6db))

### Chores

- Sync uv.lock with pyproject.toml 1.46.3
  ([#498](https://github.com/canonhq/canon-private/pull/498),
  [`34952e7`](https://github.com/canonhq/canon-private/commit/34952e73950b19db09bf0f09c51f766cdc59e6db))

- **canon**: Update specs from PR #498
  ([`9d09851`](https://github.com/canonhq/canon-private/commit/9d09851a53f13228ca5193b892794f4d5260695b))

### Documentation

- Snapshot v1.46 docs
  ([`5b8dacd`](https://github.com/canonhq/canon-private/commit/5b8dacd5c60ae7183e0f4961f2ecd3e06a248567))


## v1.46.3 (2026-04-11)

### Bug Fixes

- Jira search endpoint and parser start_line off-by-one
  ([#497](https://github.com/canonhq/canon-private/pull/497),
  [`a570fc9`](https://github.com/canonhq/canon-private/commit/a570fc94e58598abf4de6a5403e93d34445d8c99))

### Chores

- Update lockfile after merge from main (v1.46.0 → v1.46.2)
  ([#497](https://github.com/canonhq/canon-private/pull/497),
  [`a570fc9`](https://github.com/canonhq/canon-private/commit/a570fc94e58598abf4de6a5403e93d34445d8c99))

- **canon**: Update specs from PR #497
  ([`213aa0c`](https://github.com/canonhq/canon-private/commit/213aa0c4b82451176f86e9b4ee6f2ab2f54b0545))

- **canon**: Update specs from PR #497
  ([`16c46bd`](https://github.com/canonhq/canon-private/commit/16c46bd110a8f59e0cfdbe7de45ba36ec06dec1f))

### Documentation

- Snapshot v1.46 docs
  ([`7bdf363`](https://github.com/canonhq/canon-private/commit/7bdf363ddd56a7999e5418d184da55f408c52e22))

### Testing

- Address PR review feedback ([#497](https://github.com/canonhq/canon-private/pull/497),
  [`a570fc9`](https://github.com/canonhq/canon-private/commit/a570fc94e58598abf4de6a5403e93d34445d8c99))


## v1.46.2 (2026-04-11)

### Bug Fixes

- **agent**: Robust parser for Claude analysis responses + structured failure reporting
  ([#496](https://github.com/canonhq/canon-private/pull/496),
  [`3223dbe`](https://github.com/canonhq/canon-private/commit/3223dbe0c077c918313b7ee7cb1c10b9b1fd03bf))

### Chores

- **canon**: Update specs from PR #496
  ([`17b208b`](https://github.com/canonhq/canon-private/commit/17b208bc4831a39b944aa4ca639f5081a2bdef3b))

- **canon**: Update specs from PR #496
  ([`a3da264`](https://github.com/canonhq/canon-private/commit/a3da26482576d1354b4685b0f2143aea174781c0))


## v1.46.1 (2026-04-11)

### Bug Fixes

- **oidc**: Basic auth for confidential clients at device endpoint, localhost issuer exception,
  close spec AC ([#495](https://github.com/canonhq/canon-private/pull/495),
  [`241fac4`](https://github.com/canonhq/canon-private/commit/241fac448bb27dfc48bf02ac03eaa71271a69ecd))

### Chores

- Sync uv.lock to pyproject.toml 1.46.0 ([#495](https://github.com/canonhq/canon-private/pull/495),
  [`241fac4`](https://github.com/canonhq/canon-private/commit/241fac448bb27dfc48bf02ac03eaa71271a69ecd))

### Continuous Integration

- **oidc**: Add live Keycloak smoke-test job with extension points for Zitadel/Okta/Google
  ([#495](https://github.com/canonhq/canon-private/pull/495),
  [`241fac4`](https://github.com/canonhq/canon-private/commit/241fac448bb27dfc48bf02ac03eaa71271a69ecd))

### Documentation

- Snapshot v1.46 docs
  ([`d39642c`](https://github.com/canonhq/canon-private/commit/d39642ce70739971f0ee87d6a3677cb3cd62393c))

### Testing

- **oidc**: Add live-provider smoke harness and surface device auth errors
  ([#495](https://github.com/canonhq/canon-private/pull/495),
  [`241fac4`](https://github.com/canonhq/canon-private/commit/241fac448bb27dfc48bf02ac03eaa71271a69ecd))


## v1.46.0 (2026-04-11)

### Bug Fixes

- Address PR review — auto-detect, logging, error messages
  ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))

- JQL injection and broken OAuth ticket URLs
  ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))

- Validate project_key at API boundary for defense in depth
  ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))

- **security**: Remove env-var fallback from from_org
  ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))

### Chores

- Sync uv.lock to 1.45.1 ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))

### Documentation

- Snapshot v1.45 docs
  ([`17da114`](https://github.com/canonhq/canon-private/commit/17da1144f4f10bdb9dc483d58393a2f9750d4eb1))

### Features

- Centralize Jira/Linear sync through Canon backend
  ([#488](https://github.com/canonhq/canon-private/pull/488),
  [`cba2266`](https://github.com/canonhq/canon-private/commit/cba226664369e5f629f8820cb545d11d49af4304))


## v1.45.2 (2026-04-10)

### Bug Fixes

- **ui**: Wire class-based dark mode in Tailwind v4
  ([#494](https://github.com/canonhq/canon-private/pull/494),
  [`1b7f591`](https://github.com/canonhq/canon-private/commit/1b7f59136ae9fb344b36b8122971835e80449b37))

### Chores

- Sync uv.lock to 1.45.1 ([#494](https://github.com/canonhq/canon-private/pull/494),
  [`1b7f591`](https://github.com/canonhq/canon-private/commit/1b7f59136ae9fb344b36b8122971835e80449b37))

### Documentation

- Snapshot v1.45 docs
  ([`a3138b5`](https://github.com/canonhq/canon-private/commit/a3138b58ed38f8e83f75a3d6c5bfa7ee7970cfd9))


## v1.45.1 (2026-04-10)

### Bug Fixes

- **auth0**: Enable GitHub/Google/email connections for CLI client
  ([#490](https://github.com/canonhq/canon-private/pull/490),
  [`7110707`](https://github.com/canonhq/canon-private/commit/71107079365c8489e04d383283d77e4d2fb510e1))

### Chores

- Sync uv.lock to 1.44.1 ([#490](https://github.com/canonhq/canon-private/pull/490),
  [`7110707`](https://github.com/canonhq/canon-private/commit/71107079365c8489e04d383283d77e4d2fb510e1))

- **canon**: Update specs from PR #490
  ([`64a3250`](https://github.com/canonhq/canon-private/commit/64a32505f9149e760a752a27a7769671412cddd0))

### Documentation

- Snapshot v1.45 docs
  ([`71059d7`](https://github.com/canonhq/canon-private/commit/71059d79688af2e9b05d9c9d5e4ccec232deb24f))


## v1.45.0 (2026-04-10)

### Bug Fixes

- Address PR review findings — 6 issues fixed
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- Address review feedback — JWT deactivation, TOCTOU super_admin, suspension false positive
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **auth**: Enforce deactivation on session auth + org suspension in middleware
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **auth**: Fail open on DB errors in session deactivation check
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **auth**: Return 401 for API requests + add read:org to GitHub OAuth scope
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **migration**: Correct revision IDs to match existing chain (0005, not 0005_audit_events)
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

### Chores

- Sync uv.lock after merging main (1.44.1)
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

### Documentation

- Audit canon-rebrand spec — 5 sections upgraded to done, 27 ACs checked
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- Snapshot v1.44 docs
  ([`eaedd1a`](https://github.com/canonhq/canon-private/commit/eaedd1a5d33a35f63bc7e0d2d805b4f96cf623b5))

### Features

- Admin UI enhancements — user deactivation, org suspension, auth fixes
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **admin**: Add deactivate/reactivate user and suspend/reactivate org endpoints
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **admin**: Add status field to UserSummary and OrgSummary models
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **admin-store**: Add deactivate/reactivate user and suspend/reactivate org
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **auth**: Block deactivated users from API key access
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **db**: Add users.status column for deactivation support
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **frontend**: Add admin action API functions and status fields
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **frontend**: Add deactivation/reactivation UI to user detail page
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **frontend**: Add status badges to user and org list pages
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **frontend**: Add suspension/reactivation UI to org detail page
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))

- **user-store**: Add revoke_all_api_keys for bulk revocation
  ([#487](https://github.com/canonhq/canon-private/pull/487),
  [`9591257`](https://github.com/canonhq/canon-private/commit/9591257f28de308e83aaa9911f1637dbfdcf23c5))


## v1.44.1 (2026-04-10)

### Bug Fixes

- Address review feedback on device-flow error handling
  ([#489](https://github.com/canonhq/canon-private/pull/489),
  [`847d2c2`](https://github.com/canonhq/canon-private/commit/847d2c286c6bb0b7a05a0d6cf207e431df650bee))

- Bound unauthenticated DeviceCodeRequest.org input
  ([#489](https://github.com/canonhq/canon-private/pull/489),
  [`847d2c2`](https://github.com/canonhq/canon-private/commit/847d2c286c6bb0b7a05a0d6cf207e431df650bee))

- Resolve org in device auth flow for multi-org tenants
  ([#489](https://github.com/canonhq/canon-private/pull/489),
  [`847d2c2`](https://github.com/canonhq/canon-private/commit/847d2c286c6bb0b7a05a0d6cf207e431df650bee))

### Code Style

- Apply ruff format ([#489](https://github.com/canonhq/canon-private/pull/489),
  [`847d2c2`](https://github.com/canonhq/canon-private/commit/847d2c286c6bb0b7a05a0d6cf207e431df650bee))

### Documentation

- Add admin-actions spec (impersonation, deactivation, suspension)
  ([#486](https://github.com/canonhq/canon-private/pull/486),
  [`408acc0`](https://github.com/canonhq/canon-private/commit/408acc0cd631cd47badac3494431883c21a663b1))

- Snapshot v1.44 docs
  ([`c95c994`](https://github.com/canonhq/canon-private/commit/c95c99486c886b03a3bbcb76ae443afd2cffdc1a))


## v1.44.0 (2026-04-03)

### Bug Fixes

- Format admin files with ruff ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Format auth provider files ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Lint fixes and add missing preview CronJob disables
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Sort imports in main.py ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Sort imports in test_models.py ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Update profile test for new PLATFORM_MANAGE permission
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Align AdminStore queries with actual database schema
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Align Vue views with updated TypeScript types
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Chain require_super_admin on get_current_user dependency
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Constrain RoleUpdate to valid roles, bound limit/offset params
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Constrain updateUserRole role param to valid values
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Filter billing detail through model, paginate org members
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Handle null created_at in audit date formatter
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Type selectedRole as ValidRole union in AdminUserDetail
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Use Literal type for AdminConfig.mode
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Use rightmost X-Forwarded-For IP, enforce min retention days
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

### Chores

- Regenerate uv.lock for 1.43.1 ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Update uv.lock for version 1.43.0 ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

### Documentation

- Add super admin interface design spec ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Add super admin interface implementation plan
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Snapshot v1.43 docs
  ([`708d933`](https://github.com/canonhq/canon-private/commit/708d9333d5f5fc5afb7da998d2385286f4346b4e))

### Features

- Add audit_events migration (0005) for admin action logging
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Add AuditStore for admin action logging
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Add deployment_mode and admin_audit_retention_days to Settings
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Add require_super_admin FastAPI dependency
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Add SUPER_ADMIN role and PLATFORM_MANAGE permission
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- AdminConfig, AdminStore, routes, and main.py wiring (Tasks 6-8)
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Audit retention CronJob and Helm chart wiring (Tasks 9-10)
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Super admin interface for platform management
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- Super admin UI frontend (Tasks 11-17) ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Enrich admin views with Auth0 Management API data
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Implement billing, AI ops, integrations, and health checks
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Implement billing, AI ops, integrations, and health subsystem checks
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

### Refactoring

- Add patch() to API client, use it in updateUserRole
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

- **admin**: Integrate admin UI with app shell and design system
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))

### Testing

- **admin**: Add missing endpoint tests for full route coverage
  ([#485](https://github.com/canonhq/canon-private/pull/485),
  [`c8f99e3`](https://github.com/canonhq/canon-private/commit/c8f99e36e01b1825b2ec5769bb7b44863006aaa6))


## v1.43.1 (2026-04-03)

### Bug Fixes

- Address PR review feedback ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Clear pending_org_choices on logout and fresh login
  ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Close auth bypass allowing any user to access any org
  ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Close auth bypass allowing any user to access any org's data
  ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Multi-org redirect bug + add github_membership tests
  ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

### Chores

- Add audit log for org selection ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Apply ruff formatting ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Regenerate uv.lock for v1.43.0 ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

- Remove unused pytest import ([#484](https://github.com/canonhq/canon-private/pull/484),
  [`e07dbb1`](https://github.com/canonhq/canon-private/commit/e07dbb153474ed1290780df038e1e93998d5be3f))

### Documentation

- Snapshot v1.43 docs
  ([`01619e3`](https://github.com/canonhq/canon-private/commit/01619e3d847831102c152a57bc7be8295f6fc29c))


## v1.43.0 (2026-04-01)

### Bug Fixes

- Address PR review findings ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

- Update plugin description, skill count, and implement allowed-tools
  ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

### Chores

- Update uv.lock for v1.42.0 ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

### Code Style

- Format test file ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

### Documentation

- Snapshot v1.42 docs
  ([`cda4cbf`](https://github.com/canonhq/canon-private/commit/cda4cbf5402fdb8e687a587c7c24241e5b94ecd2))

- Update docs site and marketing site for new plugin capabilities
  ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

### Features

- Add development execution workflow skills to Canon plugin
  ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

- Development execution workflow skills for Canon plugin
  ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))

### Testing

- Add tests for new plugin skills, agent, hooks, and workflow chains
  ([#483](https://github.com/canonhq/canon-private/pull/483),
  [`b152222`](https://github.com/canonhq/canon-private/commit/b1522220645b0f32e7e9ec7bcbba9f4103f76789))


## v1.42.0 (2026-04-01)

### Bug Fixes

- Add missing disconnectIntegration import, restore specs:write grant
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- COALESCE refresh token on update, remove phantom Jira webhook secret
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- Show GitHub as connected when authenticated via SSO
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- Show reauth warning badge, use TTLCache for rate limiting
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- SPA bootstrap now uses session permissions instead of recomputing
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- **security**: Block backslash open redirect in redirect_to
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- **security**: Org ownership checks and Linear webhook secret encryption
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- **security**: Reject protocol-relative URLs in redirect_to
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- **security**: Validate redirect_to and encrypt webhook secret
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

### Chores

- Regenerate uv.lock for v1.41.1 ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

### Code Style

- Run ruff format on new files ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

### Documentation

- Snapshot v1.41 docs
  ([`bac73db`](https://github.com/canonhq/canon-private/commit/bac73db3a730d6f33e995f0755b0a05eeb1e75f6))

### Features

- Add integration management UI with OAuth for Jira and Linear
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- Add Manage links and Disconnect buttons to integration cards
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- Auto-register webhooks on Jira/Linear OAuth connect
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))

- Integration management UI with OAuth for Jira and Linear
  ([#482](https://github.com/canonhq/canon-private/pull/482),
  [`010897c`](https://github.com/canonhq/canon-private/commit/010897c3d6da6ff1640706eff73aaded3bf9452d))


## v1.41.1 (2026-03-31)

### Bug Fixes

- **infra**: Wire GitHub OAuth App into Auth0 social connection
  ([#481](https://github.com/canonhq/canon-private/pull/481),
  [`84f2a4f`](https://github.com/canonhq/canon-private/commit/84f2a4fe32be731fc0d5d4427e62165409a59fbc))

### Chores

- **canon**: Update specs from PR #481
  ([`dd85b48`](https://github.com/canonhq/canon-private/commit/dd85b48d659e1747f0f1038d86e89f51699d6df2))

### Documentation

- Snapshot v1.41 docs
  ([`de247fc`](https://github.com/canonhq/canon-private/commit/de247fc920072383d2a614c99c49f6c9e14f7bf3))


## v1.41.0 (2026-03-29)

### Bug Fixes

- **infra**: Address PR review — GitHub OAuth, Google org, stale headers
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- **infra**: Decouple auth0 from shared services gate, fix apply errors
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- **infra**: Import core infra into terraform state
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- **infra**: Remove github connection scopes to avoid persistent drift
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- **infra**: Restructure k8s providers and import core infra
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

### Chores

- Regenerate uv.lock for v1.39.0 ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- Sync uv.lock ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- Sync uv.lock after merge ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- Trigger CI ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))

- **canon**: Update specs from PR #480
  ([`d8777cc`](https://github.com/canonhq/canon-private/commit/d8777ccf979ab791446a59a328e023026e526f8a))

### Documentation

- Snapshot v1.40 docs
  ([`905d577`](https://github.com/canonhq/canon-private/commit/905d5771ff0cdd300cc83a3431d6453a4722e43a))

### Features

- **infra**: Migrate Auth0 from gv-os to canonhq tenant
  ([#480](https://github.com/canonhq/canon-private/pull/480),
  [`47c096d`](https://github.com/canonhq/canon-private/commit/47c096dc9a165e0b6f66ef75c071d2b12c91698c))


## v1.40.0 (2026-03-29)

### Bug Fixes

- **infra**: Address PR review — GitHub OAuth, Google org, stale headers
  ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))

- **infra**: Decouple auth0 from shared services gate, fix apply errors
  ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))

- **infra**: Remove github connection scopes to avoid persistent drift
  ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))

### Chores

- Regenerate uv.lock for v1.39.0 ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))

- Sync uv.lock ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))

- **canon**: Update specs from PR #479
  ([`f2194c9`](https://github.com/canonhq/canon-private/commit/f2194c9781c125fe8f89e7edaa3d34fe043895cd))

- **canon**: Update specs from PR #479
  ([`90aa815`](https://github.com/canonhq/canon-private/commit/90aa815f76dc61a2ae223d548bafcb4ad8cd491e))

### Documentation

- Snapshot v1.39 docs
  ([`fb4ebb0`](https://github.com/canonhq/canon-private/commit/fb4ebb0fb7f6473335dbd2d55cfa069d10e6dd35))

### Features

- **infra**: Migrate Auth0 from gv-os to canonhq tenant
  ([#479](https://github.com/canonhq/canon-private/pull/479),
  [`7bf204b`](https://github.com/canonhq/canon-private/commit/7bf204bfc34db0d8e5b26e22e60b5d7066c76ba2))


## v1.39.0 (2026-03-28)

### Bug Fixes

- Address PR review findings — bugs and test coverage gaps
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- Guard db_pool access in lifespan for environments without database
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Address review feedback — path traversal and fail-closed linking
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Address security and bug findings from code review
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Escape braces in spec template and gate WRITE on collaborator check
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Use correct IdentityStore.get_github_login() API
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

### Chores

- Add data/ to gitignore for Slack runtime stores
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- Sync uv.lock after merge ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **canon**: Update specs from PR #478
  ([`16a48fb`](https://github.com/canonhq/canon-private/commit/16a48fbc136fbc31e6139d5f5661037ed22b1146))

### Code Style

- Apply ruff format to all modified files
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- Fix ruff format on test files ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

### Documentation

- Snapshot v1.38 docs
  ([`8bce2f6`](https://github.com/canonhq/canon-private/commit/8bce2f601607b28cd84a20509af10fcf4ec36a5f))

- Update slack-product-experience spec — mark all 57 ACs as done
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **specs**: Add Slack product experience spec
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

### Features

- **slack**: Add Home Tab, spec creation from Slack, and notification preferences
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Add intent shortcuts, deferred responses, digests, and stale spec cron
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Add persistent stores, channel routing, and interest tracking
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Complete Slack product experience — 57 ACs across 9 systems
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Implement workflow actions — approve, request changes, sync tickets, dashboard refresh
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Wire foundation for Slack product experience
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))

- **slack**: Wire proactive notifications into event handlers
  ([#478](https://github.com/canonhq/canon-private/pull/478),
  [`2966823`](https://github.com/canonhq/canon-private/commit/29668238bd0aba3d8503e649b01221e23e292a9c))


## v1.38.0 (2026-03-28)

### Bug Fixes

- **slack**: Add missing permission checks, use hour-level digest match
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Address inline review — HKDF, org scope, slug regex
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Address PR review — filename match, digest window, XML escaping
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Distinguish API errors from missing PRs in feedback posting
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: DM user on permission denied in modal submit
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Handle InvalidToken on decrypt, blockquote user feedback
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Restore exact-minute match for digest scheduling
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Revert digest to exact-minute match to prevent duplicates
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Use correct GitHubClient methods for PR lookup
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Use Search API for PR lookup, add digest tolerance window
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

### Chores

- Sync uv.lock
  ([`95e4fcd`](https://github.com/canonhq/canon-private/commit/95e4fcda1acb8d64a728cde155005405ba48b30e))

- **specs**: Audit and check off 137 verified acceptance criteria
  ([`fc12e32`](https://github.com/canonhq/canon-private/commit/fc12e327d464c83a9be82738618a90fa5ea3f3ca))

- **specs**: Verify and check off 41 implemented Slack App ACs
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

### Code Style

- Format test_slack_actions.py ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

### Documentation

- Snapshot v1.37 docs
  ([`785dcd6`](https://github.com/canonhq/canon-private/commit/785dcd6eef636379d6e198765b8cf4866790d9e0))

### Features

- **slack**: Complete Slack App spec — 68/68 ACs implemented
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))

- **slack**: Implement remaining code gaps for sections 4, 6-9
  ([#477](https://github.com/canonhq/canon-private/pull/477),
  [`be0da3b`](https://github.com/canonhq/canon-private/commit/be0da3bfe6ccd412ea92d633a27cddf69c034fb7))


## v1.37.0 (2026-03-28)

### Bug Fixes

- Add missing Stripe and SMTP secrets to preview workflow
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Add Zitadel Helm repo to CI workflow ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Prefix unused unpacked variables with underscore
  ([#475](https://github.com/canonhq/canon-private/pull/475),
  [`689274d`](https://github.com/canonhq/canon-private/commit/689274df6bbbf35157216fd34adb7b78dc970003))

- Remove unused Any import to pass ruff lint
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **ci**: Add helm repo before dependency build in publish workflow
  ([#476](https://github.com/canonhq/canon-private/pull/476),
  [`20187b2`](https://github.com/canonhq/canon-private/commit/20187b2b8896777480299b5c43a82bb31f7e3a06))

- **slack**: Add Request type annotation to route handler
  ([`cbf658d`](https://github.com/canonhq/canon-private/commit/cbf658d0504e8cbda5a1cfa554aa75968afed688))

- **slack**: Address PR review findings ([#475](https://github.com/canonhq/canon-private/pull/475),
  [`689274d`](https://github.com/canonhq/canon-private/commit/689274df6bbbf35157216fd34adb7b78dc970003))

- **slack**: Format test file and add spec cache invalidation on push
  ([#475](https://github.com/canonhq/canon-private/pull/475),
  [`689274d`](https://github.com/canonhq/canon-private/commit/689274df6bbbf35157216fd34adb7b78dc970003))

- **slack**: Use slug for button values and add cache TTL
  ([#475](https://github.com/canonhq/canon-private/pull/475),
  [`689274d`](https://github.com/canonhq/canon-private/commit/689274df6bbbf35157216fd34adb7b78dc970003))

- **slack**: Use Starlette Request handler instead of raw ASGI mount
  ([`174ac50`](https://github.com/canonhq/canon-private/commit/174ac5022239ca36b174826245998fc004a7578a))

### Chores

- Regenerate uv.lock for v1.33.1 ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Regenerate uv.lock for v1.35.0 ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Regenerate uv.lock for v1.36.0 ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Update uv.lock for v1.35.0 ([#474](https://github.com/canonhq/canon-private/pull/474),
  [`0a0381e`](https://github.com/canonhq/canon-private/commit/0a0381eefecfbfe31bd3c1f1376f0ad0a398bf1d))

- **canon**: Update specs from PR #474
  ([`7040d49`](https://github.com/canonhq/canon-private/commit/7040d49adc71e5b47cf57f2a172c21258cd4ad21))

- **canon**: Update specs from PR #475
  ([`9d755c4`](https://github.com/canonhq/canon-private/commit/9d755c4f2ec995c15f43bc7039d2667680826a7b))

### Code Style

- Apply ruff format to frontend and web files
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Format settings.py with ruff ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

### Continuous Integration

- Trigger CI re-run ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

### Documentation

- Add web-app-ux-polish implementation plan
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- Audit spec statuses and migrate legacy specwright prefixes
  ([`919b95b`](https://github.com/canonhq/canon-private/commit/919b95b0516d4277b124a97290729000805b1a66))

- Fix Claude Code plugin installation instructions
  ([#474](https://github.com/canonhq/canon-private/pull/474),
  [`0a0381e`](https://github.com/canonhq/canon-private/commit/0a0381eefecfbfe31bd3c1f1376f0ad0a398bf1d))

- Snapshot v1.36 docs
  ([`1266495`](https://github.com/canonhq/canon-private/commit/1266495e9a25b35f1b83f4af27aa24bc21c70851))

### Features

- **api**: Add expand=acs param to tasks API for inline AC expansion
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add active page indicator to nav bar
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add expandable spec cards with section detail and progress bars
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add grouped view for tasks board
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add inline AC expansion panel for tasks
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add Kanban board view for tasks
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add skeleton loaders for tasks and dashboard
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add tasks view toggle with localStorage persistence
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add ticket link badges and cross-view links
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Add toast notification system with composable and container
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Enhance empty states with icons and CTA buttons
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Enhanced keyboard shortcuts with two-key combos and help modal
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Route-aware auto-generating breadcrumbs
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Web app UX polish ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **frontend**: Web app UX polish — Tasks 14-21
  ([#472](https://github.com/canonhq/canon-private/pull/472),
  [`d22341d`](https://github.com/canonhq/canon-private/commit/d22341d22e0fd5eca295370d44f38f0d9d493d69))

- **slack**: Implement /canon slash command handlers
  ([#475](https://github.com/canonhq/canon-private/pull/475),
  [`689274d`](https://github.com/canonhq/canon-private/commit/689274df6bbbf35157216fd34adb7b78dc970003))


## v1.36.0 (2026-03-27)

### Bug Fixes

- **slack**: Address PR review findings — error handling, tests, and safety
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Address second round of PR review findings
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Escape XML tags in thread context, add url to link buttons
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Mitigate prompt injection via thread history, add comment on DM filter
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

### Chores

- Regenerate uv.lock for v1.35.0 ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

### Code Style

- Apply ruff format to all slack files ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

### Documentation

- Add multi-org & personal account support spec
  ([`8542b79`](https://github.com/canonhq/canon-private/commit/8542b79babcf0bfe5aa3b0d6618875f530d3b08b))

- Snapshot v1.35 docs
  ([`8c8fe20`](https://github.com/canonhq/canon-private/commit/8c8fe2073382bcb72a5b3d7c222e1d009b870374))

- Update slack-integration spec statuses to reflect implementation
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- Update specs based on #471
  ([`55f1978`](https://github.com/canonhq/canon-private/commit/55f19781b430d5caaa4b8fbd74c13fac871f31a2))

### Features

- **slack**: Add Block Kit utilities, slash commands, and spec loader
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Add interactive Slack app (§2-§9)
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Add mentions, notifications, actions, permissions, digest, install, dashboard (§3-§9)
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))

- **slack**: Add Slack Bolt app factory and FastAPI mount (§2)
  ([#470](https://github.com/canonhq/canon-private/pull/470),
  [`81592eb`](https://github.com/canonhq/canon-private/commit/81592eb056afdd025c67c7bba07831bfad4c092e))


## v1.35.0 (2026-03-27)

### Code Style

- Format settings.py with ruff
  ([`b69f241`](https://github.com/canonhq/canon-private/commit/b69f2418c29465bc45a07a96f1ed4acd47432178))

### Documentation

- Snapshot v1.34 docs
  ([`9cf59dc`](https://github.com/canonhq/canon-private/commit/9cf59dc78cb09241922a4d8a9b3de21e512f6985))


## v1.34.0 (2026-03-27)

### Bug Fixes

- Address PR review findings for multi-target ticket sync
  ([`e0eaa10`](https://github.com/canonhq/canon-private/commit/e0eaa10859b01be236deaea8c99b33667a5a397f))

- Log warning when section not found during shadow sync
  ([`11f89f3`](https://github.com/canonhq/canon-private/commit/11f89f3d8b3bc752dc6dfd0bbc0ba46445eae2d7))

- Prevent project_key mutation from bleeding into fallback path
  ([`919a12f`](https://github.com/canonhq/canon-private/commit/919a12f92e19012871fb33a068e333d5038b49ae))

- Remove blocked/deprecated from drift status order
  ([`8680f9f`](https://github.com/canonhq/canon-private/commit/8680f9f315167ab300806831c62b840d66593ade))

- Update lockfile and address claude-review feedback
  ([`a26599c`](https://github.com/canonhq/canon-private/commit/a26599cf0f377e23ca8900fcba5314ed60f3ab12))

- Use original file SHA for auto-commit to prevent data loss
  ([`6ad5ee5`](https://github.com/canonhq/canon-private/commit/6ad5ee5c9934c168cede936bf705503650ad521c))

### Chores

- Regenerate uv.lock after merge from main
  ([`c64eac7`](https://github.com/canonhq/canon-private/commit/c64eac79155f6a3bcf6d34ba79dd8ada6d0ffe95))

- Regenerate uv.lock after merge from main (v1.33.0)
  ([`204e848`](https://github.com/canonhq/canon-private/commit/204e8484c53d0c4cc2e080c12a462fa6f3cc0e45))

### Documentation

- Snapshot v1.33 docs
  ([`6e0805c`](https://github.com/canonhq/canon-private/commit/6e0805c71f10ba1836034344a3d4e50f93507ada))

- Update multi-target ticket sync spec statuses to in_progress
  ([`bc309e1`](https://github.com/canonhq/canon-private/commit/bc309e15833a2d073a83ed353f718cdd9ef80a0c))

### Features

- Add shadow_targets to routing rules and resolve_all_targets()
  ([`101bab6`](https://github.com/canonhq/canon-private/commit/101bab6aecebbea10b829fc4ff5b799a322543d6))

- Auto-commit spec updates directly to default branch on merge
  ([`849ec55`](https://github.com/canonhq/canon-private/commit/849ec55e920569ae69a323727bf08a0b2b06125c))

- Configure multi-target routing rules in CANON.yaml
  ([`f1a56e2`](https://github.com/canonhq/canon-private/commit/f1a56e22f5657a391e29ed544636a73659cc06a5))

- Cross-system drift detection for multi-target sync
  ([`2c9056e`](https://github.com/canonhq/canon-private/commit/2c9056ef858c40ca5cf361ed71b4e5fe00da3384))

- Make sync failures loud with PostHog tracking and detailed logging
  ([`76caf6a`](https://github.com/canonhq/canon-private/commit/76caf6a78c2125ad3fbfea3364fe8b3580b51b2f))

- Make sync failures loud with PostHog tracking and detailed logging
  ([`fc996e3`](https://github.com/canonhq/canon-private/commit/fc996e397ba1a7f3813f029ca59ceb27885599aa))

- Multi-target forward sync with shadow ticket creation
  ([`d78cf7e`](https://github.com/canonhq/canon-private/commit/d78cf7ed87b7e6b3e952191a7c9f92c2f25796d0))

- Wire multi-target sync into push handler
  ([`165a70d`](https://github.com/canonhq/canon-private/commit/165a70db22f1d3d1993f20b476035bab66122b99))


## v1.33.1 (2026-03-26)

### Bug Fixes

- Add Zitadel Helm repo before dependency build in CI workflows
  ([`ae84690`](https://github.com/canonhq/canon-private/commit/ae84690da22a52d1482bbfb8be4cd274579393dc))

### Documentation

- Snapshot v1.33 docs
  ([`1195a50`](https://github.com/canonhq/canon-private/commit/1195a50fd2d9871d7e8a285828232bc4ddcbdfc6))


## v1.33.0 (2026-03-26)

### Documentation

- Add web-app-ux-polish spec for Tasks, Explorer, Nav, Editor, and Global UX improvements
  ([`16744bf`](https://github.com/canonhq/canon-private/commit/16744bf82626c776575a339a99ab2041b4f7db8b))

- Snapshot v1.32 docs
  ([`32b0bce`](https://github.com/canonhq/canon-private/commit/32b0bced037cfc0f756203d4fb7d98a62df40b8b))

### Features

- Add Stripe, SMTP, and Auth0 M2M secrets to Helm chart and deploy workflow
  ([`b149e02`](https://github.com/canonhq/canon-private/commit/b149e02299e6c7a36c8c526a625b9658c10d7fcb))


## v1.32.2 (2026-03-26)

### Bug Fixes

- Retry on stale SHA conflict (409) in reverse sync webhook processor
  ([`02cd1e7`](https://github.com/canonhq/canon-private/commit/02cd1e7d0c7b549ba226d700e08fec7a4d2ee314))

### Documentation

- Audit canon-rebrand spec — update §10 and §14 to in_progress
  ([`e04e64e`](https://github.com/canonhq/canon-private/commit/e04e64eef5f25414c0f17a299af236c005be7963))

- Audit infra-enablement-billing-email spec — normalize markers and update statuses
  ([`c8672dc`](https://github.com/canonhq/canon-private/commit/c8672dcd076ee3f7e4f5a1730bb9c102f1b0a068))

- Audit sre-alerting-monitoring spec — mark all sections done
  ([`95192b0`](https://github.com/canonhq/canon-private/commit/95192b0c0cd80fc9cb7a61558b425177db59c790))

- Audit ticket sync specs — update statuses and normalize markers
  ([`0455354`](https://github.com/canonhq/canon-private/commit/0455354e6c7283d3d727c634b0cb9412c43c0300))

- Snapshot v1.32 docs
  ([`aae21d0`](https://github.com/canonhq/canon-private/commit/aae21d0ce56d929cf4149c2389641ad996d4f326))


## v1.32.1 (2026-03-26)

### Bug Fixes

- Lint errors in test_github_client integration tests
  ([`6002803`](https://github.com/canonhq/canon-private/commit/60028034ac74af34037e9b6372a555e61c089d16))

### Chores

- **canon**: Github ticket 393 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`23a89a4`](https://github.com/canonhq/canon-private/commit/23a89a4d9a69c72035f3e11ff6ae65b42bcfc7f3))

- **canon**: Github ticket 393 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`b8aa5e9`](https://github.com/canonhq/canon-private/commit/b8aa5e9b0781e3a29e5441fd3da79aac51947226))

- **canon**: Github ticket 394 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`10601bf`](https://github.com/canonhq/canon-private/commit/10601bfe57915ea5843b974fe441d5d09d94616d))

- **canon**: Github ticket 395 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`616abef`](https://github.com/canonhq/canon-private/commit/616abef19755eda97ede7847e2f8e7777d86aea6))

- **canon**: Github ticket 396 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`cb5f379`](https://github.com/canonhq/canon-private/commit/cb5f379cca8dc0c7638989f1110fb5f88de16d3c))

- **canon**: Github ticket 397 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`e028636`](https://github.com/canonhq/canon-private/commit/e0286364d2376787d6bcf96a4a155e3230271790))

- **canon**: Github ticket 398 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`dc018f2`](https://github.com/canonhq/canon-private/commit/dc018f2f997fa6356f08c885808449f3829106ca))

- **canon**: Github ticket 398 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`96d1205`](https://github.com/canonhq/canon-private/commit/96d12059b8aa78f5350551bd8158933f86aa13c1))

- **canon**: Github ticket 399 → in_progress in docs/specs/enhanced-platform-testing.md
  ([`9f611e3`](https://github.com/canonhq/canon-private/commit/9f611e3ddb6bf89dfa8bb44382aa2b752f35ec6b))

- **canon**: Github ticket 401 → in_progress in docs/specs/integration-testing.md
  ([`37ffa3e`](https://github.com/canonhq/canon-private/commit/37ffa3e54b6956d93b72c0d60f8582e48751b2a1))

### Code Style

- Format test_github_client.py with ruff
  ([`0bf7165`](https://github.com/canonhq/canon-private/commit/0bf7165cd6745e8b21b0fd0bf1ac8a4ec650ec16))

### Documentation

- Add spec for closing SDLC loop + multi-target ticket sync
  ([`bdc3702`](https://github.com/canonhq/canon-private/commit/bdc3702f20a78066e2f62817bdd30b8f6bfc23b2))

- Audit analytics-dashboard spec statuses based on codebase evidence
  ([`b1dc9e0`](https://github.com/canonhq/canon-private/commit/b1dc9e062a039328735dc47f74f98afa2a90057d))

- Audit auth specs — update security-vulnerabilities §2 to in_progress
  ([`8642c51`](https://github.com/canonhq/canon-private/commit/8642c51ae1d38c6b78a2aa7ae866e2fa6bbb1e63))

- Audit auth-related spec statuses based on codebase evidence
  ([`6c5f71c`](https://github.com/canonhq/canon-private/commit/6c5f71cac05b5235d41d0549864a6ff5163c0637))

- Audit developer-docs-site spec statuses
  ([`3b95889`](https://github.com/canonhq/canon-private/commit/3b95889206db53aa56d9ec06089a4cd2d83e2c9d))

- Audit ide-integration spec — check off 41 realized ACs
  ([`d3476c8`](https://github.com/canonhq/canon-private/commit/d3476c83301500817d5ecfbce39685b436e3a6f8))

- Audit infrastructure-independence spec statuses based on codebase evidence
  ([`91dcef6`](https://github.com/canonhq/canon-private/commit/91dcef6a7ccdefc4f50b17c75b77f5a32581e39d))

- Audit setup-ux-improvements spec — update statuses and normalize comments
  ([`0d26b27`](https://github.com/canonhq/canon-private/commit/0d26b27b5b44fcf557acd9720897487e66cc3045))

- Audit spec statuses based on codebase evidence
  ([`501d32a`](https://github.com/canonhq/canon-private/commit/501d32a849b4a6851cf4f30e14a663768075c477))

- Expand slack-integration spec into full Slack app design
  ([`6ad36f9`](https://github.com/canonhq/canon-private/commit/6ad36f932e928d0e19026a67af54fdc36bff2c34))

- Mark integration-testing spec as done
  ([`a17ead7`](https://github.com/canonhq/canon-private/commit/a17ead7da0dc8c94ef3bdea569222dc1e740d5b1))

- Mark integration-testing spec as done
  ([`9d8bb33`](https://github.com/canonhq/canon-private/commit/9d8bb3369f70ad32122a55e83c9bd8992035071e))

- Snapshot v1.32 docs
  ([`8619719`](https://github.com/canonhq/canon-private/commit/8619719a54e335c6efc5b702a15fb4fe5e8b857a))

- Update enhanced-platform-testing section statuses to in_progress
  ([`77d4b08`](https://github.com/canonhq/canon-private/commit/77d4b086361545c6dbbcc5ab9a49ae6569ef40ec))

- Update enhanced-platform-testing section statuses to in_progress
  ([`5ec5453`](https://github.com/canonhq/canon-private/commit/5ec54534fd44063e5e5dbd93113d6ff98c8e2f39))

- Update specs based on #466 ([#467](https://github.com/canonhq/canon-private/pull/467),
  [`f21ed17`](https://github.com/canonhq/canon-private/commit/f21ed1759e187eb967bd292750c14a2a2871c60c))

### Testing

- Add GitHub API client integration tests (spec section 3)
  ([`f3460a3`](https://github.com/canonhq/canon-private/commit/f3460a3c8f08a600188b01719841409aaab8224d))


## v1.32.0 (2026-03-25)

### Bug Fixes

- Add /app prefix to analytics routes and remove PostHog mentions from UI
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Add TF_VAR env vars and correct Doppler secret names in Terraform workflow
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Address critical review findings — sanitize HogQL params, align API response shapes
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Address PR review comments — validate team param, fix status tracking
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Address PR review feedback — health score, analytics security, and query bugs
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Address PR review feedback — idempotent provisioning, missing scope, error handling
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Address PR review feedback — reinstall safety, connection permissions, CI providers
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Address PR review findings — error handling, auth, cleanup
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Address PR review findings — org access check, error handling, input validation
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Cast PostHog properties to float before aggregate functions
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Increase PostHog query timeout and reuse HTTP client
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Lint SIM910 and remove duplicate Terraform workflows
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Make Auth0 org provisioning fully idempotent on reinstall
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Remove invalid limit param from PostHog HogQL query payload
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Resolve AWS/GCP provider auth in CI and simplify plan comment
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Restart preview pod after deploy to pick up secret changes
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Return 200 for expected analytics states, add startup log
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Use dummy access_token for GCP provider when credentials unavailable
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Use null fallback for GCP credentials instead of empty JSON
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Use toFloatOrDefault instead of toFloat64OrNull in HogQL
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Wire PostHog analytics secrets through Helm chart and deploy workflows
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

### Chores

- Regenerate uv.lock after merge with main (v1.31.3)
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Regenerate uv.lock for version 1.31.2 ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Sync lockfile with main (v1.31.4) ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Sync uv.lock after rebase on main
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Update uv.lock for v1.31.3
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

### Code Style

- Fix import sorting in analytics tests and main module
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Fix ruff formatting in on_installation and tests
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Run ruff format on all analytics files ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Run ruff format on analytics_query.py and on_push.py
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

### Continuous Integration

- Add terraform apply workflow with production approval gate
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Add terraform plan workflow for infra/ PRs
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Add terraform validate job to CI pipeline
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Retrigger terraform plan after state bucket creation
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

### Documentation

- Add analytics dashboard implementation plan
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Add Phase 1 infrastructure independence implementation plan
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Snapshot v1.31 docs
  ([`5b577e6`](https://github.com/canonhq/canon-private/commit/5b577e678108e1c9595bd9b7ff3592e8c4f714f4))

- Update infrastructure independence spec — sections 1-3 progress
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Update infrastructure independence spec — sections 4-7, 10-11 in progress
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

### Features

- Add Auth0 org auto-provisioning on GitHub App install (Phase 3)
  ([`37152f7`](https://github.com/canonhq/canon-private/commit/37152f7bdaeabe5cb8b483736044acd938fdb463))

- Add health score algorithm and analytics API endpoints
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- Analytics dashboard with health score, events, and frontend
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- **analytics**: Add PostHogQueryClient and settings for analytics dashboard
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- **analytics**: Emit ticket lifecycle, spec, AC, config, and MCP group events
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))

- **analytics**: Implement frontend dashboard — types, API client, route, and chart components
  ([#465](https://github.com/canonhq/canon-private/pull/465),
  [`ef3239a`](https://github.com/canonhq/canon-private/commit/ef3239a4faa1ffcfb6950d54adb3a88d29c856ff))


## v1.31.5 (2026-03-25)

### Bug Fixes

- Make Claude code review more robust
  ([`8427777`](https://github.com/canonhq/canon-private/commit/8427777864e6bbc33438940d9fdf872b29874582))

### Documentation

- Snapshot v1.31 docs
  ([`d24c607`](https://github.com/canonhq/canon-private/commit/d24c607cfdf6fa1a29d048d3d4bbdca78f713932))


## v1.31.4 (2026-03-25)

### Bug Fixes

- Increase Claude code review max-turns from 15 to 25
  ([`5d9c48c`](https://github.com/canonhq/canon-private/commit/5d9c48ca960c12415185f3adce191eb637cc67d2))

### Documentation

- Snapshot v1.31 docs
  ([`d160b8f`](https://github.com/canonhq/canon-private/commit/d160b8ff0982ce1c3af64f67f1ef60100baf801e))


## v1.31.3 (2026-03-25)

### Bug Fixes

- Add comment-posting tools to Claude code review workflow
  ([`d8acc3e`](https://github.com/canonhq/canon-private/commit/d8acc3e9d579a5282b58000a545b7098faacbd24))

### Documentation

- Expand infrastructure independence spec with Stripe, PostHog, Auth0 provisioning, and GitHub App
  sections
  ([`f87f184`](https://github.com/canonhq/canon-private/commit/f87f1846edeafea1db3ffa21230c978c68b106f8))

- Snapshot v1.31 docs
  ([`4184389`](https://github.com/canonhq/canon-private/commit/41843891d02adb4096e49f1c7b7ce89d9821a1ab))


## v1.31.2 (2026-03-24)

### Bug Fixes

- Make 0002 migration idempotent when target column already exists
  ([#466](https://github.com/canonhq/canon-private/pull/466),
  [`f2bd1db`](https://github.com/canonhq/canon-private/commit/f2bd1db5bbd3a54c87a461911990f75d0277b8df))

### Documentation

- Snapshot v1.31 docs
  ([`ee60f59`](https://github.com/canonhq/canon-private/commit/ee60f59c881e34e980b464c792fd0c965b0daa86))

- Update specs based on #461 ([#463](https://github.com/canonhq/canon-private/pull/463),
  [`ac0e56d`](https://github.com/canonhq/canon-private/commit/ac0e56d26c85d36427402e5dd407d43bbdd2d4e9))


## v1.31.1 (2026-03-24)

### Bug Fixes

- Remove canon-github-tickets secret ref that breaks deploy
  ([#464](https://github.com/canonhq/canon-private/pull/464),
  [`fa5ceaa`](https://github.com/canonhq/canon-private/commit/fa5ceaa7f10866b9f4502d9d2665d02778055536))

### Documentation

- Snapshot v1.31 docs
  ([`42cf241`](https://github.com/canonhq/canon-private/commit/42cf241b9a58913381506cc095378b25f6596da3))


## v1.31.0 (2026-03-24)

### Bug Fixes

- Improve error handling and documentation from PR review
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))

- Narrow exception catch for opaque token handling
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))

- Override githubTickets secret in preview to prevent pod crash
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))

- Reduce PostHog log noise from opaque tokens and missing web_org
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))

### Chores

- Update uv.lock to match pyproject.toml v1.30.2
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))

### Documentation

- Snapshot v1.30 docs
  ([`7a094e8`](https://github.com/canonhq/canon-private/commit/7a094e885403ac466d908cd16c9d01827fcddb3d))

### Features

- Wire AUTH0_ORGS_ENABLED through Helm chart and update .env.example
  ([#461](https://github.com/canonhq/canon-private/pull/461),
  [`e52316f`](https://github.com/canonhq/canon-private/commit/e52316f6b3dea8e4945896c3358779878ba12b62))


## v1.30.2 (2026-03-24)

### Bug Fixes

- Address spec review findings for analytics dashboard
  ([#462](https://github.com/canonhq/canon-private/pull/462),
  [`bfc76fd`](https://github.com/canonhq/canon-private/commit/bfc76fda1415a891e04270a6dbd26ec834625a7f))

- Polish spec from second review pass ([#462](https://github.com/canonhq/canon-private/pull/462),
  [`bfc76fd`](https://github.com/canonhq/canon-private/commit/bfc76fda1415a891e04270a6dbd26ec834625a7f))

### Chores

- Regenerate uv.lock for v1.30.1 ([#462](https://github.com/canonhq/canon-private/pull/462),
  [`bfc76fd`](https://github.com/canonhq/canon-private/commit/bfc76fda1415a891e04270a6dbd26ec834625a7f))

- Sync uv.lock with main branch version ([#462](https://github.com/canonhq/canon-private/pull/462),
  [`bfc76fd`](https://github.com/canonhq/canon-private/commit/bfc76fda1415a891e04270a6dbd26ec834625a7f))

### Documentation

- Add analytics dashboard spec ([#462](https://github.com/canonhq/canon-private/pull/462),
  [`bfc76fd`](https://github.com/canonhq/canon-private/commit/bfc76fda1415a891e04270a6dbd26ec834625a7f))

- Snapshot v1.30 docs
  ([`dbd6518`](https://github.com/canonhq/canon-private/commit/dbd6518214f1b2041dc1c16da1d46e1b60adc621))

- Update specs based on #459 ([#460](https://github.com/canonhq/canon-private/pull/460),
  [`2920b27`](https://github.com/canonhq/canon-private/commit/2920b27893a4b5fea091d785e41222b9c1558844))


## v1.30.1 (2026-03-21)

### Bug Fixes

- Detect opaque JWT tokens and add GitHub ticket sync Helm plumbing
  ([#459](https://github.com/canonhq/canon-private/pull/459),
  [`563f37b`](https://github.com/canonhq/canon-private/commit/563f37b476d15bf7daa6015741a04b9132d1c25f))

### Documentation

- Add infrastructure independence spec
  ([`76eb05b`](https://github.com/canonhq/canon-private/commit/76eb05b0e8f0d51b60375b9d0963f8fd80a1fcff))

- Snapshot v1.30 docs
  ([`ea970cf`](https://github.com/canonhq/canon-private/commit/ea970cf6f3b7a7d5de383cbbc2fba406057dcfdb))

- Update specs based on #456 ([#457](https://github.com/canonhq/canon-private/pull/457),
  [`00501b7`](https://github.com/canonhq/canon-private/commit/00501b754e4230b293502a143eb510094f4283a5))


## v1.30.0 (2026-03-21)

### Chores

- Regenerate uv.lock for v1.29.2 ([#456](https://github.com/canonhq/canon-private/pull/456),
  [`eb36ff1`](https://github.com/canonhq/canon-private/commit/eb36ff1dc2ead59e8a78b52587bcb0305281496c))

### Code Style

- Format gen-changelog files with ruff ([#456](https://github.com/canonhq/canon-private/pull/456),
  [`eb36ff1`](https://github.com/canonhq/canon-private/commit/eb36ff1dc2ead59e8a78b52587bcb0305281496c))

### Documentation

- Add platform observability coverage spec
  ([`7f0b677`](https://github.com/canonhq/canon-private/commit/7f0b677eec92f7c6246d0591a2144fdd153e8a9b))

- Snapshot v1.29 docs
  ([`b42d034`](https://github.com/canonhq/canon-private/commit/b42d034b63472dfe0463b050dc587f78d97976b4))

### Features

- Add Auth0 M2M credentials to deploy and preview workflows
  ([`86f0ff3`](https://github.com/canonhq/canon-private/commit/86f0ff328500b9f3d83bdb50b13a902fb093515a))

- Add changelog automation for docs site ([#456](https://github.com/canonhq/canon-private/pull/456),
  [`eb36ff1`](https://github.com/canonhq/canon-private/commit/eb36ff1dc2ead59e8a78b52587bcb0305281496c))


## v1.29.2 (2026-03-21)

### Bug Fixes

- Strip libpq-only params (channel_binding) from asyncpg URLs
  ([`6838173`](https://github.com/canonhq/canon-private/commit/68381730fc15fd882e9a6ed5873c5600a5b7c95d))

### Documentation

- Update specs based on #452 ([#455](https://github.com/canonhq/canon-private/pull/455),
  [`cb7d7c7`](https://github.com/canonhq/canon-private/commit/cb7d7c724636f1dd141a8e68b648691c234736d4))


## v1.29.1 (2026-03-21)

### Bug Fixes

- Restore allowedTools for claude code review gh commands
  ([`f802b3a`](https://github.com/canonhq/canon-private/commit/f802b3ae23aced24bcf4be10e0ac594fe9f48d98))


## v1.29.0 (2026-03-21)

### Bug Fixes

- Address PR review findings ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

- Use .value keys in PERMISSION_DESCRIPTIONS, deduplicate includes
  ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

- **auth**: Fall back to ID token org_id when access token decode fails
  ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

- **web**: Fall back to session org when WEB_ORG is empty
  ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

### Chores

- Retrigger CI with updated claude review config
  ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

- Update uv.lock after rebase ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))

### Documentation

- Snapshot v1.28 docs
  ([`cb50d6c`](https://github.com/canonhq/canon-private/commit/cb50d6c086a608952c12b56c5ccbc7905e710148))

### Features

- **profile**: Complete user profile page spec
  ([#452](https://github.com/canonhq/canon-private/pull/452),
  [`c0b5d1c`](https://github.com/canonhq/canon-private/commit/c0b5d1ce4523fa70cd70403a08846010594176b3))


## v1.28.0 (2026-03-21)

### Bug Fixes

- Address PR review feedback ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Address PR review — error handling, caching tests, comment accuracy
  ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Address PR review — path traversal guard, error handling, caching
  ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Address second round of PR feedback ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

### Chores

- Regenerate uv.lock for v1.26.0 ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Regenerate uv.lock for v1.26.3 ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Retrigger CI with updated claude review config
  ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Trigger preview rebuild ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Update uv.lock ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Update uv.lock after merge from main ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

### Code Style

- Fix ruff lint and format issues ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

### Documentation

- Snapshot v1.27 docs
  ([`1fe9e8f`](https://github.com/canonhq/canon-private/commit/1fe9e8f5855c66efa7ca6487fb1cb7300947c578))

- Update specs based on #451 ([#454](https://github.com/canonhq/canon-private/pull/454),
  [`d67afe4`](https://github.com/canonhq/canon-private/commit/d67afe4a1c08669f13565d3cbca86b1dceb6833e))

### Features

- Add vite-ssg prerendering and SSG route serving
  ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))

- Add vite-ssg prerendering, SSG route serving, and integration tests
  ([#451](https://github.com/canonhq/canon-private/pull/451),
  [`59ea1d1`](https://github.com/canonhq/canon-private/commit/59ea1d1bcd09261709f847b8db5396e5c53f86c8))


## v1.27.0 (2026-03-21)

### Bug Fixes

- Address code review findings
  ([`1f5c29e`](https://github.com/canonhq/canon-private/commit/1f5c29ea4aab2445c4a5e2fadca6deba9cc4bcf6))

- Address PR review feedback (10 issues)
  ([`d68addc`](https://github.com/canonhq/canon-private/commit/d68addc3aec4dec87e4efd2c27be151080cd23e7))

- Address PR review round 2 — error handling, tests, config
  ([`97b8927`](https://github.com/canonhq/canon-private/commit/97b8927749b3e4e981f29222a81a144146c9b266))

- Resolve ruff lint errors in SRE alerting modules
  ([`c1a0032`](https://github.com/canonhq/canon-private/commit/c1a0032baf83827da62d9d345ae18d0e27666644))

- **helm**: Set imagePullPolicy Always for preview deployments
  ([`fad4a8e`](https://github.com/canonhq/canon-private/commit/fad4a8ef6c788010718864a05a0afb9833bbc593))

### Chores

- Regenerate uv.lock for v1.26.0
  ([`e45c3cf`](https://github.com/canonhq/canon-private/commit/e45c3cf1f4664b006c4db20fbfc351001cbb5193))

- Retrigger CI with updated claude review config
  ([`70b18fa`](https://github.com/canonhq/canon-private/commit/70b18fadc321a4477e3d54acbf7aa75e598f6f64))

- Update uv.lock
  ([`2cf1785`](https://github.com/canonhq/canon-private/commit/2cf1785b0850616e48c8430904bc096627137faf))

- Update uv.lock
  ([`167984e`](https://github.com/canonhq/canon-private/commit/167984ea604b57a6038c45795bb371eda94cadc1))

- Update uv.lock after merge from main
  ([`c2d152b`](https://github.com/canonhq/canon-private/commit/c2d152ba6d6032d32103c99dbc5b02a3d6815288))

### Code Style

- Apply ruff formatting to SRE modules
  ([`820d470`](https://github.com/canonhq/canon-private/commit/820d47045e88bc8ac7520b3d6aa1585534ef909a))

### Documentation

- Add changelog automation spec
  ([`4a4e7c6`](https://github.com/canonhq/canon-private/commit/4a4e7c61376f22c8241631e7a65f7b3abbcdce61))

- Add preview environment Auth0 configuration spec
  ([`70dda0d`](https://github.com/canonhq/canon-private/commit/70dda0dc3c0425297c8538fb2e6851ae91f9af5c))

- Snapshot v1.26 docs
  ([`344948d`](https://github.com/canonhq/canon-private/commit/344948d6825f9277a962dfe398cb1972a0210a8f))

- Update SRE alerting spec section statuses
  ([`0ff25e2`](https://github.com/canonhq/canon-private/commit/0ff25e236c1f5b52cffbea8e0a5b91d94839d87b))

### Features

- **sre**: Add @tracked_cron decorator for cron job instrumentation
  ([`27ebc35`](https://github.com/canonhq/canon-private/commit/27ebc3550bbbb99e06dd3d1141a175eb6e4fb107))

- **sre**: Add agent_call_completed PostHog event tracking
  ([`8a0fa3a`](https://github.com/canonhq/canon-private/commit/8a0fa3aab577308ac2d8ebeb72fcbea8916d27bd))

- **sre**: Add alert severity and message models
  ([`39ce52a`](https://github.com/canonhq/canon-private/commit/39ce52adedb3f4d3411b960915862330d4d03d2a))

- **sre**: Add bot spec-context comments on auto-created issues
  ([`9d15279`](https://github.com/canonhq/canon-private/commit/9d1527949cdb0ad49a6681ebb69a518c0bf1439a))

- **sre**: Add db_query_slow detection hook
  ([`fdd2d39`](https://github.com/canonhq/canon-private/commit/fdd2d397d243f26854d981a599061d34c26dfb12))

- **sre**: Add environment context to all PostHog events
  ([`29de95a`](https://github.com/canonhq/canon-private/commit/29de95a620c4bff692d3d9710ba57882a1026b29))

- **sre**: Add error triage module for auto-creating GitHub issues
  ([`eba00d5`](https://github.com/canonhq/canon-private/commit/eba00d5786b630dd0edcb30a50cff896e0125604))

- **sre**: Add error_issue_map database migration
  ([`f3edd3a`](https://github.com/canonhq/canon-private/commit/f3edd3a12dbbf8431b67d1999c337f7fbe9f8442))

- **sre**: Add ErrorStore for error fingerprint to issue mapping
  ([`3e03bdb`](https://github.com/canonhq/canon-private/commit/3e03bdb56ebfdfab229a1d60d4a25fb40625e329))

- **sre**: Add health_check_failed PostHog event tracking
  ([`f6685a4`](https://github.com/canonhq/canon-private/commit/f6685a4555beabd0de47aafb8db98eb6b4c1b251))

- **sre**: Add PostHog alert and dashboard setup script
  ([`396644f`](https://github.com/canonhq/canon-private/commit/396644f9ab6c558b6065ab94146cc1bf20e6f43a))

- **sre**: Add request_completed and rate_limit_hit PostHog event tracking
  ([`a9af15d`](https://github.com/canonhq/canon-private/commit/a9af15d022c2c5b735eb691091d9aac0436ea51a))

- **sre**: Add Slack incoming webhook delivery module
  ([`c745084`](https://github.com/canonhq/canon-private/commit/c745084836eccb17b7718678e22d1672c71fc020))

- **sre**: Add Slack webhook secret and SRE config to Helm chart
  ([`e79004e`](https://github.com/canonhq/canon-private/commit/e79004edaf284f1d0c6c4896c858f589c403fe67))

- **sre**: Add SRE alerting environment variables to Settings
  ([`799847a`](https://github.com/canonhq/canon-private/commit/799847a57c929f693432a3ca224f58e5be7e89ba))

- **sre**: Add SRE section to CANON.yaml config parser
  ([`f9cde00`](https://github.com/canonhq/canon-private/commit/f9cde0003ccda66ddadf8216ee0e40b92c179640))

- **sre**: Add weekly digest CronJob Helm template
  ([`d94b939`](https://github.com/canonhq/canon-private/commit/d94b93929f0056f6ed5648f3f2b7e520f4ac8e7d))

- **sre**: Add weekly SRE digest module and cron job
  ([`a9391ce`](https://github.com/canonhq/canon-private/commit/a9391ceb973985d83bb51cf8b2c260c0efab6e97))


## v1.26.5 (2026-03-21)

### Bug Fixes

- Add lockfile check to pre-push hook
  ([`e98d6d9`](https://github.com/canonhq/canon-private/commit/e98d6d913da7c3e82d266001ef759fdf242e99ea))

### Chores

- Update uv.lock
  ([`885fbbb`](https://github.com/canonhq/canon-private/commit/885fbbbd9bf8cfed0645cbc3028ca46f44315473))

### Documentation

- Snapshot v1.26 docs
  ([`25105e6`](https://github.com/canonhq/canon-private/commit/25105e6a98ed03a808b958146758986fe4b87baa))


## v1.26.4 (2026-03-21)

### Bug Fixes

- Improve claude code review prompt with project-specific context
  ([`6ab49ed`](https://github.com/canonhq/canon-private/commit/6ab49edad09547d0c96596723a0fc24303a6edc6))

### Documentation

- Snapshot v1.26 docs
  ([`2db6b25`](https://github.com/canonhq/canon-private/commit/2db6b254530e2b39c576d806a6dedf99369e26a5))


## v1.26.3 (2026-03-21)

### Bug Fixes

- Remove allowedTools override that blocked default claude review tools
  ([`6c0d991`](https://github.com/canonhq/canon-private/commit/6c0d991b43009d53c148fc681f8a82e174e2f904))

### Documentation

- Snapshot v1.26 docs
  ([`d8d5a77`](https://github.com/canonhq/canon-private/commit/d8d5a778015ccd7cd1a7c8ebe1e15d5d7dc06355))


## v1.26.2 (2026-03-21)

### Bug Fixes

- Remove inline comment tool from claude review to prevent comment spam
  ([`157c10f`](https://github.com/canonhq/canon-private/commit/157c10f1e8f8c4ae54d0aa32cbcb107e8320625e))

### Documentation

- Snapshot v1.26 docs
  ([`67cf3e5`](https://github.com/canonhq/canon-private/commit/67cf3e5abb2cf093da35a1b008ef457dcf40cc68))


## v1.26.1 (2026-03-21)

### Bug Fixes

- Reduce claude code review noise with sticky comments and focused prompt
  ([`733b574`](https://github.com/canonhq/canon-private/commit/733b57496bf3cc4e05097e70cac3353bd45c313f))

### Documentation

- Add infra enablement spec for billing, email, and auth0 m2m
  ([`ef7a54b`](https://github.com/canonhq/canon-private/commit/ef7a54b7c7202560915111325a0334e74fe14a3a))

- Snapshot v1.26 docs
  ([`51ebc5d`](https://github.com/canonhq/canon-private/commit/51ebc5d1ba0eca757f724e8b82c6ee1b374a9320))


## v1.26.0 (2026-03-21)

### Bug Fixes

- Add helm dependency build to deploy, publish, and preview workflows
  ([`532a30f`](https://github.com/canonhq/canon-private/commit/532a30f7094647bd7907835194969857cea9ae74))

- Address PR review findings ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Address reviewer feedback on PR #390 ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Address round-2 PR feedback + fix Zitadel test
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Address round-3 PR feedback ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Address round-4 PR feedback ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Address round-5 PR feedback ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Use core.hooksPath so git hooks work in worktrees automatically
  ([`9dbc053`](https://github.com/canonhq/canon-private/commit/9dbc053bc58324e389eaf99b4e61f81258eedb71))

- **ci**: Add helm dep build to check job for Helm template tests
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- **ci**: Add helm dependency build before lint and template tests
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- **sync**: Use single event loop for all specs + fresh ticket sync
  ([`59a844d`](https://github.com/canonhq/canon-private/commit/59a844d95af26e7bc14bc6d81597fd51ce31e6bf))

- **test**: Disambiguate Canon vs Zitadel setup jobs + add git hooks
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- **test**: Filter Canon setup job by post-install hook + add make install-hooks
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- **test**: Use correct nested path for Zitadel subchart masterkey
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

### Chores

- Add CANON.yaml to OSS export pipeline
  ([`04009de`](https://github.com/canonhq/canon-private/commit/04009de8086a24b1a228ad23467c3de4cd956cf2))

- Remove docs/*.md from spec doc_paths
  ([`d690b69`](https://github.com/canonhq/canon-private/commit/d690b69ac1bf044e18ed7280443a1e2725135d12))

- Update CANON.yaml with IDE integration, auto-tickets, and lifecycle sync
  ([`fb1748c`](https://github.com/canonhq/canon-private/commit/fb1748caf9e907e9e2d1ab814e9246b7c3ecf0a1))

- **canon**: Github ticket 300 → todo in docs/specs/auth-hardening.md
  ([`7bd2123`](https://github.com/canonhq/canon-private/commit/7bd21237502ae5d862172f3c3cb3e0553136eef7))

- **canon**: Github ticket 301 → todo in docs/specs/auth-hardening.md
  ([`edf23a3`](https://github.com/canonhq/canon-private/commit/edf23a3ab65af8b7ea3b0d2c9fdb713b92049ab7))

- **canon**: Github ticket 302 → in_progress in docs/specs/auth-hardening.md
  ([`7d333bd`](https://github.com/canonhq/canon-private/commit/7d333bdb69564553e031cada7636f92ad44df626))

- **canon**: Github ticket 305 → in_progress in docs/specs/developer-docs-site.md
  ([`57c4960`](https://github.com/canonhq/canon-private/commit/57c4960b470ae6e1ce2310a4f792146c7e0ff859))

- **canon**: Github ticket 307 → todo in docs/specs/spec-view-redesign.md
  ([`de6a2c0`](https://github.com/canonhq/canon-private/commit/de6a2c0d10bfbb0878671e071c44d08f0b441b2c))

- **canon**: Github ticket 346 → todo in docs/specs/canon-rebrand.md
  ([`eb7a776`](https://github.com/canonhq/canon-private/commit/eb7a776d6bda97bf48248c4294125914e712e8ff))

- **canon**: Github ticket 349 → in_progress in docs/specs/developer-docs-site.md
  ([`0926f21`](https://github.com/canonhq/canon-private/commit/0926f21baa9c702d48ecdc8c0c5e4c3fabe9078f))

- **canon**: Github ticket 353 → todo in docs/specs/setup-ux-improvements.md
  ([`919f099`](https://github.com/canonhq/canon-private/commit/919f0990dd23ddf4fa8e8bd3f907fc3466059d42))

- **canon**: Github ticket 364 → in_progress in docs/specs/setup-ux-improvements.md
  ([`1c1f699`](https://github.com/canonhq/canon-private/commit/1c1f699e0d149be326157af23ab8178568e55b59))

- **canon**: Github ticket 367 → in_progress in docs/specs/theme-toggle-light-mode.md
  ([`13c7ce2`](https://github.com/canonhq/canon-private/commit/13c7ce27164aea960acdb2a0ccba3b51656a7fd9))

- **canon**: Github ticket 370 → in_progress in docs/specs/user-profile-page.md
  ([`3be9be8`](https://github.com/canonhq/canon-private/commit/3be9be852eff310afb53e87df08746e9c9ed0771))

- **canon**: Github ticket 376 → todo in docs/specs/ticket-sync-reliability.md
  ([`e06c084`](https://github.com/canonhq/canon-private/commit/e06c0847f7dcb1c62266d6da67af8bb3cb64103f))

- **canon**: Github ticket 5 → done in docs/specs/slack-integration.md
  ([`21fe07e`](https://github.com/canonhq/canon-private/commit/21fe07eff0b95bfdedfbd1431750533c25a5b9e8))

### Code Style

- Fix ruff format on agent/client.py ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

- Fix ruff format on test_template_rendering.py
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))

### Documentation

- Add enterprise adoption and scale infrastructure specs
  ([`2744077`](https://github.com/canonhq/canon-private/commit/2744077e930429ac1e0fb4f7d171c5a5520eb493))

- Add SRE alerting & monitoring spec
  ([`f4c0c5c`](https://github.com/canonhq/canon-private/commit/f4c0c5cd52fc246e19ffecd33aa26eef628ec388))

- Audit and update spec statuses for auth-hardening and canon-rebrand
  ([`8aace22`](https://github.com/canonhq/canon-private/commit/8aace22bce1f5e11c42f722766b989487216d792))

- Snapshot v1.25 docs
  ([`10d702e`](https://github.com/canonhq/canon-private/commit/10d702ee4e20ac90878507299ae8dc3019fbc48f))

- Update specs based on #390 ([#450](https://github.com/canonhq/canon-private/pull/450),
  [`117e6b7`](https://github.com/canonhq/canon-private/commit/117e6b707e3004c03af5e882499e36850b7c6f0f))

### Features

- Implement remaining OIDC migration + pricing gaps
  ([#390](https://github.com/canonhq/canon-private/pull/390),
  [`819d781`](https://github.com/canonhq/canon-private/commit/819d781abb0770c24506e1327dda6f066f50b642))


## v1.25.0 (2026-03-20)

### Bug Fixes

- Address code review findings for OIDC migration
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review feedback ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review feedback (5 items) ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review findings — security, error handling, comments
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review round 2 — migration, issuer, TOCTOU, discovery
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review round 3 — tenant isolation, session fallback, device flow
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review round 4 — JWT validation, auth_mode, provider cleanup
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Address PR review round 5 — auth_mode, role fallback, migration ordering
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Migration test ConfigParser escaping and export-oss rsync traversal
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Migration tests — use cfg.attributes for schema, run Alembic in thread
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Resolve CI failures — format auth files and fix Helm CronJob name
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Update integration test for slow_down field in pending response
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Use pgvector/pgvector:pg16 image for CI integration tests
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Address PR comment — device bootstrap, ES256, slow_down, downgrade guards
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Address PR review — security, error handling, type safety
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **helm**: Comment out Zitadel subchart dep until integration is ready
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Chores

- Fix unused imports and add implementation plan
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Sync uv.lock with pyproject.toml v1.23.0
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Sync uv.lock with pyproject.toml v1.24.0
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Code Style

- Collapse nested if per ruff SIM102 ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Fix ruff format in test_template_rendering.py
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Ruff format on 16 files ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Continuous Integration

- Add workflow_dispatch trigger for manual CI runs
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Documentation

- Snapshot v1.24 docs
  ([`561bad6`](https://github.com/canonhq/canon-private/commit/561bad6806070c41ce5ed387b84062f5de0b5ff8))

- Update OIDC migration spec statuses to reflect implementation
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Update specs based on #385 ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Update specs based on #385 ([#387](https://github.com/canonhq/canon-private/pull/387),
  [`ae1cfb0`](https://github.com/canonhq/canon-private/commit/ae1cfb0e3871be3d1d5d4d6890f1c482a1324b41))

- Update specs based on #388 ([#389](https://github.com/canonhq/canon-private/pull/389),
  [`76892de`](https://github.com/canonhq/canon-private/commit/76892ded6a7c1825290e2f918f6da3acbe8205e8))

### Features

- Enhanced platform testing ecosystem ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Add OIDC settings and provider factory with auto-detection
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Add OIDCProvider protocol and data models
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Implement Auth0Provider wrapping existing auth logic
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: Implement GenericOIDCProvider with discovery-based OIDC
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **auth**: OIDC provider abstraction — Auth0 to open-source auth
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **db**: Rename auth0_sub/auth0_org_id to oidc_sub/oidc_org_id, add users.role
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **frontend**: Update auth labels and add generic OIDC login view
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **helm**: Add OIDC secret support alongside Auth0
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **helm**: Add optional Zitadel subchart for self-hosted auth
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- **oss**: Include auth module in OSS export (excluding cloud-only files)
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Refactoring

- **auth**: Use OIDCProvider abstraction across all auth modules
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

### Testing

- Add enhanced platform testing ecosystem
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Add unit tests for auth/jwt.py — 21 tests covering all 3 functions
  ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))

- Fill OIDC migration coverage gaps ([#386](https://github.com/canonhq/canon-private/pull/386),
  [`93cbc59`](https://github.com/canonhq/canon-private/commit/93cbc597d1f36411a13753fac919d33b761d281c))


## v1.24.0 (2026-03-19)

### Bug Fixes

- Address second round of PR feedback ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2b4cdce`](https://github.com/canonhq/canon-private/commit/2b4cdce0022410d0708d90e42320e0a162e67605))

- Address second round of PR feedback ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2322096`](https://github.com/canonhq/canon-private/commit/23220966b41eef42b4bc682585cd2745e462c2f5))

- Resolve critical bugs found in PR review
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2b4cdce`](https://github.com/canonhq/canon-private/commit/2b4cdce0022410d0708d90e42320e0a162e67605))

- Resolve critical bugs found in PR review
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2322096`](https://github.com/canonhq/canon-private/commit/23220966b41eef42b4bc682585cd2745e462c2f5))

### Chores

- Merge main and update lockfile to v1.23.0
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2b4cdce`](https://github.com/canonhq/canon-private/commit/2b4cdce0022410d0708d90e42320e0a162e67605))

- Merge main and update lockfile to v1.23.0
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2322096`](https://github.com/canonhq/canon-private/commit/23220966b41eef42b4bc682585cd2745e462c2f5))

### Documentation

- Snapshot v1.23 docs
  ([`a719ba0`](https://github.com/canonhq/canon-private/commit/a719ba0db44df219200df0c41fdb447d306d7a04))

### Features

- Implement ticket sync reliability spec (§2-§6)
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2b4cdce`](https://github.com/canonhq/canon-private/commit/2b4cdce0022410d0708d90e42320e0a162e67605))

- Implement ticket sync reliability spec (§2-§6)
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2322096`](https://github.com/canonhq/canon-private/commit/23220966b41eef42b4bc682585cd2745e462c2f5))

### Refactoring

- Address PR feedback — capabilities protocol, double-fingerprint fix, type safety
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2b4cdce`](https://github.com/canonhq/canon-private/commit/2b4cdce0022410d0708d90e42320e0a162e67605))

- Address PR feedback — capabilities protocol, double-fingerprint fix, type safety
  ([#385](https://github.com/canonhq/canon-private/pull/385),
  [`2322096`](https://github.com/canonhq/canon-private/commit/23220966b41eef42b4bc682585cd2745e462c2f5))


## v1.23.0 (2026-03-19)

### Bug Fixes

- Address PR review feedback ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))

- Address PR review feedback for IDE integration
  ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))

- Address second round of PR review feedback
  ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))

- Update list_specs tests for paginated response format
  ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))

### Chores

- Add .worktrees/ to .gitignore ([#375](https://github.com/canonhq/canon-private/pull/375),
  [`45b0f48`](https://github.com/canonhq/canon-private/commit/45b0f48619ee3ce7fc7d6f29190b69bd0f319ba7))

- Add .worktrees/ to .gitignore
  ([`8225617`](https://github.com/canonhq/canon-private/commit/822561737a3504c7238fb3c3c4c214d3b5f0fd32))

- Enable canon skill in repo
  ([`7b56584`](https://github.com/canonhq/canon-private/commit/7b5658421a388ac77de290fced749901749c31bc))

- **canon**: Github ticket 266 → in_progress in docs/specs/ticket-mapping-model.md
  ([`4655cc3`](https://github.com/canonhq/canon-private/commit/4655cc3cf6f0c4cb952a8aba98e103ddeb8c3759))

- **canon**: Github ticket 283 → todo in docs/specs/auth-hardening.md
  ([`b45d4f3`](https://github.com/canonhq/canon-private/commit/b45d4f3a882ca52e7d0096563fbeb06f813677f1))

- **canon**: Github ticket 284 → todo in docs/specs/auth-hardening.md
  ([`6d2d9c6`](https://github.com/canonhq/canon-private/commit/6d2d9c6f1f1c2b1b4d6519d1f38200a82aaae23f))

- **canon**: Github ticket 285 → in_progress in docs/specs/auth-hardening.md
  ([`2a56839`](https://github.com/canonhq/canon-private/commit/2a568392c98d492c9cb5b95d4ca5007e2835cec7))

- **canon**: Github ticket 286 → in_progress in docs/specs/developer-docs-site.md
  ([`84b2f34`](https://github.com/canonhq/canon-private/commit/84b2f347ce82c63d47a68faee995197c2fdf91ad))

- **canon**: Github ticket 287 → todo in docs/specs/developer-docs-site.md
  ([`4cec0d1`](https://github.com/canonhq/canon-private/commit/4cec0d1001809649904087d72ebfa625841e67fa))

- **canon**: Github ticket 288 → in_progress in docs/specs/developer-docs-site.md
  ([`189d2c0`](https://github.com/canonhq/canon-private/commit/189d2c0de91aeee71a145e72ee5015e9b18c8d8e))

- **canon**: Github ticket 289 → in_progress in docs/specs/ticket-mapping-model.md
  ([`6725793`](https://github.com/canonhq/canon-private/commit/672579345ece90160ad73b6977cbd19d1657b242))

- **canon**: Github ticket 290 → in_progress in docs/specs/ticket-mapping-model.md
  ([`eece1d0`](https://github.com/canonhq/canon-private/commit/eece1d029bd9e3b3b3209b86231f94bb17e0c330))

- **canon**: Github ticket 98 → todo in docs/specs/security-vulnerabilities.md
  ([`6be1278`](https://github.com/canonhq/canon-private/commit/6be1278ca721eb3da74dd9fc7a98acdd99dc8abc))

- **canon**: Github ticket 99 → todo in docs/specs/security-vulnerabilities.md
  ([`11c3122`](https://github.com/canonhq/canon-private/commit/11c3122ad76cbc45ad2a958227089cbb323ce712))

### Code Style

- Fix ruff format on 6 files ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))

### Documentation

- Add IDE Agent Integration spec ([#374](https://github.com/canonhq/canon-private/pull/374),
  [`2be5751`](https://github.com/canonhq/canon-private/commit/2be57514460cc17db72794bfeccfb8ce301aeee4))

- Add OIDC migration spec for Auth0 to open-source auth
  ([#375](https://github.com/canonhq/canon-private/pull/375),
  [`45b0f48`](https://github.com/canonhq/canon-private/commit/45b0f48619ee3ce7fc7d6f29190b69bd0f319ba7))

- Add ticket links for ticket-sync-reliability spec (#376-#383)
  ([`a7783d1`](https://github.com/canonhq/canon-private/commit/a7783d12e1f778c0c5146a189c1021cc94f49b38))

- Add ticket sync reliability spec
  ([`1a34085`](https://github.com/canonhq/canon-private/commit/1a34085bac64159a1195cb6388fe1c25a54d1d8f))

- Remove duplicate ticket links and close stale issues
  ([`15991de`](https://github.com/canonhq/canon-private/commit/15991de097c657413391dd01e0d55514fd66467b))

- Snapshot v1.22 docs
  ([`262c3d7`](https://github.com/canonhq/canon-private/commit/262c3d7dd3dc42e2f2c20f6ecc15a47dff4740ce))

- Sync spec ticket links and clean up issue tracking
  ([`c6bdd6e`](https://github.com/canonhq/canon-private/commit/c6bdd6e480735f1cb4125f38b28c0da86e46c7ae))

- Update spec statuses based on codebase audit
  ([`2af64bb`](https://github.com/canonhq/canon-private/commit/2af64bb15d9114452e5c77a9fb51bfa532e8991f))

### Features

- Implement IDE Agent Integration spec (§2-§6)
  ([#384](https://github.com/canonhq/canon-private/pull/384),
  [`d5427ff`](https://github.com/canonhq/canon-private/commit/d5427ffc34f9d93d16e2c804bf09e3a19ab9c69b))


## v1.22.0 (2026-03-19)

### Bug Fixes

- Add missing type:stdio to oss MCP config, silence comment echo
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

- Address PR feedback and update stale lockfile
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

- Address second round of PR feedback ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

- Clarify oss target help text, add .gitignore tip for .mcp.json
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

- Differentiate oss setup-claude from setup, add --force to install-cli
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

### Documentation

- Snapshot v1.21 docs
  ([`a290438`](https://github.com/canonhq/canon-private/commit/a2904386541934014fdbd5d039a59d61dd806b5e))

### Features

- Add setup, install-cli, and setup-claude Makefile targets
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))

- Add setup, install-cli, and setup-claude targets to Makefiles
  ([#338](https://github.com/canonhq/canon-private/pull/338),
  [`cae433c`](https://github.com/canonhq/canon-private/commit/cae433c9b1ef49e71f17b5343ad4a8ec9c93000b))


## v1.21.0 (2026-03-18)

### Chores

- Remove broken canon plugin refs, gitignore .superpowers/
  ([`488f0cb`](https://github.com/canonhq/canon-private/commit/488f0cb9a9a7533982454afe4f8b43bb0129ed57))

### Documentation

- Regenerate API/CLI/MCP reference docs (58 → 74 endpoints)
  ([`649252e`](https://github.com/canonhq/canon-private/commit/649252e560afaa7e115b0d40a0acf42b58493e52))

- Snapshot v1.20 docs
  ([`2db3f2c`](https://github.com/canonhq/canon-private/commit/2db3f2c967f4b3e86a058a7201c9d27d821cbeb7))

- Update specs based on #336 ([#337](https://github.com/canonhq/canon-private/pull/337),
  [`241dae9`](https://github.com/canonhq/canon-private/commit/241dae9c695d4e70bf4dcbe355c310df7dbbb284))

### Features

- Add logo SVG as favicon across all sites
  ([`b286f59`](https://github.com/canonhq/canon-private/commit/b286f59fb3661bdeb9818024a8db03434f699384))


## v1.20.6 (2026-03-18)

### Bug Fixes

- Address PR review — SPDX identifier, license version, restore mypy
  ([#336](https://github.com/canonhq/canon-private/pull/336),
  [`b4e5f62`](https://github.com/canonhq/canon-private/commit/b4e5f62186957c31a3e343226572b4dd64112003))

- Fix OSS CI, broken logo, and improve quick start
  ([#336](https://github.com/canonhq/canon-private/pull/336),
  [`b4e5f62`](https://github.com/canonhq/canon-private/commit/b4e5f62186957c31a3e343226572b4dd64112003))

- OSS CI, broken logo, quick start rewrite; license MIT → BSL 1.1
  ([#336](https://github.com/canonhq/canon-private/pull/336),
  [`b4e5f62`](https://github.com/canonhq/canon-private/commit/b4e5f62186957c31a3e343226572b4dd64112003))

### Chores

- Update uv.lock to match v1.20.5 ([#336](https://github.com/canonhq/canon-private/pull/336),
  [`b4e5f62`](https://github.com/canonhq/canon-private/commit/b4e5f62186957c31a3e343226572b4dd64112003))

### Documentation

- Snapshot v1.20 docs
  ([`de83f9a`](https://github.com/canonhq/canon-private/commit/de83f9a5feb5b16b098106f72d44a0135bfeea40))

- Update specs based on #334 ([#335](https://github.com/canonhq/canon-private/pull/335),
  [`cf1b7b2`](https://github.com/canonhq/canon-private/commit/cf1b7b2b2c4c73426a1c2130be7d1087a5311b16))


## v1.20.5 (2026-03-18)

### Bug Fixes

- Add missing ANTHROPIC_API_KEY to Docker run example in FAQ
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

- Address PR review findings across all new docs
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

- Replace internal registry URL with public ghcr.io reference in FAQ
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

### Chores

- Update uv.lock to match v1.20.4 ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

### Documentation

- Add FAQ, troubleshooting, example specs page, and improve CONTRIBUTING
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

- Overhaul README for public launch and add community files
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

- Public launch package — README, community files, FAQ, troubleshooting
  ([#334](https://github.com/canonhq/canon-private/pull/334),
  [`686912a`](https://github.com/canonhq/canon-private/commit/686912a0a0a165959f3ef3b4fb145fbb51c19f78))

- Snapshot v1.20 docs
  ([`d0ae9ec`](https://github.com/canonhq/canon-private/commit/d0ae9ec0c0acf7f54b2789d8f05f7cb14553a703))


## v1.20.4 (2026-03-18)

### Bug Fixes

- Update stale plugin paths missed during plugin directory flattening
  ([`6b7637f`](https://github.com/canonhq/canon-private/commit/6b7637fb84ece63f60d2695ec0df68da863dfc9a))


## v1.20.3 (2026-03-18)

### Bug Fixes

- Explicitly remove sensitive specs and stale plugin dirs from OSS target
  ([`dfc7124`](https://github.com/canonhq/canon-private/commit/dfc7124578787b738e489e464c276d545cbbe9bf))


## v1.20.2 (2026-03-18)

### Bug Fixes

- Flatten plugin structure and consolidate OSS sync
  ([`ca4d71d`](https://github.com/canonhq/canon-private/commit/ca4d71d2b8f95269732de260a8be20308a54fa8c))

- Prepare canonhq/canon for public visibility
  ([`e352730`](https://github.com/canonhq/canon-private/commit/e3527300b0e5e9c43564936532cb5699bb78b98c))

### Documentation

- Snapshot v1.20 docs
  ([`3497a45`](https://github.com/canonhq/canon-private/commit/3497a456af87be846feb0e29e4144ea060d1eafa))


## v1.20.1 (2026-03-18)

### Bug Fixes

- Address PR review — use 503 for unconfigured, check settings before body
  ([#331](https://github.com/canonhq/canon-private/pull/331),
  [`a23edca`](https://github.com/canonhq/canon-private/commit/a23edcac337b293bb893eef24fd6897adc23fd59))

- Change webhook endpoints to fail-closed when secrets are unconfigured
  ([#331](https://github.com/canonhq/canon-private/pull/331),
  [`a23edca`](https://github.com/canonhq/canon-private/commit/a23edcac337b293bb893eef24fd6897adc23fd59))

- Convert sslmode to ssl for asyncpg dialect
  ([#332](https://github.com/canonhq/canon-private/pull/332),
  [`3527771`](https://github.com/canonhq/canon-private/commit/3527771d5b50c2e1f6486648951e51dec14a38a3))

- Convert sslmode to ssl param for SQLAlchemy asyncpg dialect
  ([#332](https://github.com/canonhq/canon-private/pull/332),
  [`3527771`](https://github.com/canonhq/canon-private/commit/3527771d5b50c2e1f6486648951e51dec14a38a3))

- Correct settings.py comments to say 503, not 501
  ([#331](https://github.com/canonhq/canon-private/pull/331),
  [`a23edca`](https://github.com/canonhq/canon-private/commit/a23edcac337b293bb893eef24fd6897adc23fd59))

- Fail-closed webhook endpoints when secrets unconfigured
  ([#331](https://github.com/canonhq/canon-private/pull/331),
  [`a23edca`](https://github.com/canonhq/canon-private/commit/a23edcac337b293bb893eef24fd6897adc23fd59))

- Handle unknown sslmode values safely, document allow→require upgrade
  ([#332](https://github.com/canonhq/canon-private/pull/332),
  [`3527771`](https://github.com/canonhq/canon-private/commit/3527771d5b50c2e1f6486648951e51dec14a38a3))

### Chores

- Sync uv.lock with pyproject.toml version 1.20.0
  ([#332](https://github.com/canonhq/canon-private/pull/332),
  [`3527771`](https://github.com/canonhq/canon-private/commit/3527771d5b50c2e1f6486648951e51dec14a38a3))

- Sync uv.lock with pyproject.toml version 1.20.0
  ([#331](https://github.com/canonhq/canon-private/pull/331),
  [`a23edca`](https://github.com/canonhq/canon-private/commit/a23edcac337b293bb893eef24fd6897adc23fd59))

### Documentation

- Snapshot v1.20 docs
  ([`8dd481e`](https://github.com/canonhq/canon-private/commit/8dd481e05d659db89b0dfdda2792f44d5f999fed))

- Update specs based on #328 ([#333](https://github.com/canonhq/canon-private/pull/333),
  [`24643da`](https://github.com/canonhq/canon-private/commit/24643da2f8ca3a064f24772be6de4119d80adbde))

### Testing

- Add edge case for sslmode=disable with existing ssl param
  ([#332](https://github.com/canonhq/canon-private/pull/332),
  [`3527771`](https://github.com/canonhq/canon-private/commit/3527771d5b50c2e1f6486648951e51dec14a38a3))


## v1.20.0 (2026-03-18)

### Bug Fixes

- Address PR review feedback ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Address PR review feedback on multi-tenant org discovery
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Handle stale GitHub installations, reduce log noise
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Lazy installation validation to avoid extra API roundtrip
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Production error handling + multi-tenant org isolation
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Set OTel service.name to "canon" instead of "unknown_service"
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

### Chores

- Sync uv.lock with 1.19.1 after merge from main
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Sync uv.lock with 1.19.2 after merge from main
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Sync uv.lock with pyproject.toml version 1.19.0
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

### Code Style

- Format auth routes list comprehension ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

### Documentation

- Snapshot v1.19 docs
  ([`2ec64c8`](https://github.com/canonhq/canon-private/commit/2ec64c8f6cf67095ca79d6eb0ff06bcc7d2ea777))

### Features

- Enable multi-org discovery and switching with Auth0
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Filter org dropdown by Auth0 membership in multi-tenant mode
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))

- Support dedicated M2M credentials for Auth0 Management API
  ([#328](https://github.com/canonhq/canon-private/pull/328),
  [`078aa52`](https://github.com/canonhq/canon-private/commit/078aa525c03f3d4b82f48dc41758bb34892fd81f))


## v1.19.2 (2026-03-18)

### Bug Fixes

- Guard cleanup against valid symlinks, move import to top-level
  ([#330](https://github.com/canonhq/canon-private/pull/330),
  [`a11b2dd`](https://github.com/canonhq/canon-private/commit/a11b2dd8c25563e01d96bad9978f2c3802e0d0b4))

- Remove installed skill files, add .claude/skills/ to gitignore
  ([#330](https://github.com/canonhq/canon-private/pull/330),
  [`a11b2dd`](https://github.com/canonhq/canon-private/commit/a11b2dd8c25563e01d96bad9978f2c3802e0d0b4))

- Update plugin config to GitHub repo, fix setup crash on dangling symlink
  ([#330](https://github.com/canonhq/canon-private/pull/330),
  [`a11b2dd`](https://github.com/canonhq/canon-private/commit/a11b2dd8c25563e01d96bad9978f2c3802e0d0b4))

- Update plugin config, fix setup crash on dangling symlink
  ([#330](https://github.com/canonhq/canon-private/pull/330),
  [`a11b2dd`](https://github.com/canonhq/canon-private/commit/a11b2dd8c25563e01d96bad9978f2c3802e0d0b4))

### Documentation

- Snapshot v1.19 docs
  ([`96ffcc2`](https://github.com/canonhq/canon-private/commit/96ffcc2bf601800c5a3b6ddbec9208189166ee1e))

- Update specs based on #327 ([#329](https://github.com/canonhq/canon-private/pull/329),
  [`3c7f2c9`](https://github.com/canonhq/canon-private/commit/3c7f2c94bc5ea88e1607fbd4212cd4278c266c4b))

### Refactoring

- Remove skill installation from setup, add cleanup migration
  ([#330](https://github.com/canonhq/canon-private/pull/330),
  [`a11b2dd`](https://github.com/canonhq/canon-private/commit/a11b2dd8c25563e01d96bad9978f2c3802e0d0b4))


## v1.19.1 (2026-03-18)

### Bug Fixes

- Address PR review — use uv latest in OSS CI, add comment on --delete-excluded scope
  ([#327](https://github.com/canonhq/canon-private/pull/327),
  [`483e3cd`](https://github.com/canonhq/canon-private/commit/483e3cd1bad250fc07ad9fb1604c11549405c9b6))

- Clean stale files from FOSS repo and add CI/.gitignore
  ([#327](https://github.com/canonhq/canon-private/pull/327),
  [`483e3cd`](https://github.com/canonhq/canon-private/commit/483e3cd1bad250fc07ad9fb1604c11549405c9b6))

- Clean stale files from FOSS repo, add CI and .gitignore
  ([#327](https://github.com/canonhq/canon-private/pull/327),
  [`483e3cd`](https://github.com/canonhq/canon-private/commit/483e3cd1bad250fc07ad9fb1604c11549405c9b6))

### Chores

- Update uv.lock to match pyproject.toml v1.19.0
  ([#327](https://github.com/canonhq/canon-private/pull/327),
  [`483e3cd`](https://github.com/canonhq/canon-private/commit/483e3cd1bad250fc07ad9fb1604c11549405c9b6))

### Documentation

- Snapshot v1.19 docs
  ([`f9fa252`](https://github.com/canonhq/canon-private/commit/f9fa2524e7dcd5a90d7101a8dfdeb9cf30149cc8))


## v1.19.0 (2026-03-18)

### Bug Fixes

- Address PR review round 2 — period dates, invoice org_login, open redirect
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Address PR review round 3 — idempotency retries, pricing model, broken hrefs
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Address PR review — idempotency, trial dates, seat sync, URL validation
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Address PR review — security, idempotency, encapsulation, permissions
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Address PR review — trial UNIQUE bug, PII leak, webhook retries, stale copy
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Align billing code with correct schema fields and add seat-based pricing model
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Align billing routes with org-scoped URL pattern and fix response field mismatches
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Harden billing module error handling and add comprehensive tests
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

### Code Style

- Format migrate.py, baseline migration, and settings.py
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Format test_service.py ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

### Documentation

- Add schema migration for nullable stripe_customer_id and update spec
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Snapshot v1.18 docs
  ([`39eb3bc`](https://github.com/canonhq/canon-private/commit/39eb3bce590f8db5208a1fc924c03c8e2d56c391))

- Update specs based on #321 ([#326](https://github.com/canonhq/canon-private/pull/326),
  [`62c5d79`](https://github.com/canonhq/canon-private/commit/62c5d79418266e64205d839f8c4d15b8025a27cf))

- Update specs based on #323 ([#325](https://github.com/canonhq/canon-private/pull/325),
  [`f39480b`](https://github.com/canonhq/canon-private/commit/f39480b90ce2d9ff4878eb516086d8ff7b7bd27b))

### Features

- Adopt Alembic for database migrations ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Gate public signup behind PostHog feature flag
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Implement managed cloud pricing with Stripe billing and BYOK support
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))

- Managed cloud pricing with Stripe billing and BYOK
  ([#321](https://github.com/canonhq/canon-private/pull/321),
  [`360ad64`](https://github.com/canonhq/canon-private/commit/360ad64969b60d37166ffb5223a40743b3223897))


## v1.18.7 (2026-03-18)

### Bug Fixes

- Address PR review feedback ([#323](https://github.com/canonhq/canon-private/pull/323),
  [`8c5fa45`](https://github.com/canonhq/canon-private/commit/8c5fa458c03ced98e48b0eb6b098e28a630b0849))

- Repair FOSS export pipeline for canonhq/canon
  ([#323](https://github.com/canonhq/canon-private/pull/323),
  [`8c5fa45`](https://github.com/canonhq/canon-private/commit/8c5fa458c03ced98e48b0eb6b098e28a630b0849))

### Chores

- Update uv.lock to match pyproject.toml v1.18.6
  ([#323](https://github.com/canonhq/canon-private/pull/323),
  [`8c5fa45`](https://github.com/canonhq/canon-private/commit/8c5fa458c03ced98e48b0eb6b098e28a630b0849))

### Documentation

- Snapshot v1.18 docs
  ([`dbf314a`](https://github.com/canonhq/canon-private/commit/dbf314ab569d3c857338f25e58061ce4e0d1d9b8))

- Update specs based on #322
  ([`acb1627`](https://github.com/canonhq/canon-private/commit/acb162743a0d2a28bd3ffb3587ca7571a05810cf))


## v1.18.6 (2026-03-18)

### Bug Fixes

- Add --extra cloud to local dev install and use bash in Makefile
  ([`5daa650`](https://github.com/canonhq/canon-private/commit/5daa6509de8d732fa70e8900f5879d147b7b094e))

### Documentation

- Remove outdated specwright/openspec references from docs site
  ([`ed4bf50`](https://github.com/canonhq/canon-private/commit/ed4bf5000ae8814d0302cec15d528548d051e14c))

- Snapshot v1.18 docs
  ([`df00c14`](https://github.com/canonhq/canon-private/commit/df00c14feb11eae79bd7c7170a73eacde6266aad))


## v1.18.5 (2026-03-14)

### Bug Fixes

- Format _local.py after config class rename
  ([`951dccd`](https://github.com/canonhq/canon-private/commit/951dccdb46ec4778a4e8113f43b7690df3947a4c))

- Rename SpecwrightApiAdapter to CanonApiAdapter in test file
  ([`28b33f3`](https://github.com/canonhq/canon-private/commit/28b33f3a7692ebd97c12c2cd764eb0071f7eb5a8))

### Documentation

- Snapshot v1.18 docs
  ([`c89276c`](https://github.com/canonhq/canon-private/commit/c89276cf90e465228db2f1759837f25796035ddf))


## v1.18.4 (2026-03-14)

### Bug Fixes

- Remove duplicate wheel force-include causing PyPI upload rejection
  ([`4ba4eba`](https://github.com/canonhq/canon-private/commit/4ba4eba19bd1a658a47f62a61cb6ba6f6ece55d3))


## v1.18.3 (2026-03-14)

### Bug Fixes

- Add verbose logging to PyPI publish for debugging
  ([`3e4cba4`](https://github.com/canonhq/canon-private/commit/3e4cba4ae309d9eb9d6e6c77e30810277e37dcd0))


## v1.18.2 (2026-03-14)

### Bug Fixes

- Update Dockerfile COPY path for restructured plugin directory
  ([`e49be47`](https://github.com/canonhq/canon-private/commit/e49be47a5e511a80d13ef2f4ada87990d19f07e2))


## v1.18.1 (2026-03-14)

### Bug Fixes

- Create all target directories in export script
  ([`20f0939`](https://github.com/canonhq/canon-private/commit/20f0939a1720634e4f498c1209919b3914f55c1f))

- Create target directories before rsync in export script
  ([`d0f2edb`](https://github.com/canonhq/canon-private/commit/d0f2edb40084e0a5b80934cd50a00dfe1ba8af0e))


## v1.18.0 (2026-03-14)

### Bug Fixes

- Add cloud extra to CI workflows and format test files
  ([`1c43a62`](https://github.com/canonhq/canon-private/commit/1c43a627403b67c64b60a23c657a11268b1f4ec8))

- Update plugin_data/skills symlink to new plugin directory
  ([`9489716`](https://github.com/canonhq/canon-private/commit/9489716e24df6fd39e62c76c777fb2918b815c36))

### Features

- Prepare for canonhq org migration and open-source split
  ([`b463a41`](https://github.com/canonhq/canon-private/commit/b463a418c621c36515fd4261a0e50627f008b01f))


## v1.17.1 (2026-03-08)

### Bug Fixes

- Add Home link in docs nav bar pointing to marketing site
  ([`3b68672`](https://github.com/canonhq/canon-private/commit/3b6867207bde2db2bd1fb7255d351bd76937781f))


## v1.17.0 (2026-03-08)

### Code Style

- Align docs site branding with Canon marketing site
  ([`9105215`](https://github.com/canonhq/canon-private/commit/9105215d6f43ca02214af726eada5dc5ae2e1747))

### Features

- Add GitHub App post-install redirect flow
  ([`5784c1a`](https://github.com/canonhq/canon-private/commit/5784c1ab4cce1f9a555981bc282b71b2d0f1d704))


## v1.16.1 (2026-03-08)

### Bug Fixes

- Correct broken specwright references in Makefile, Dockerfile.dev, setup.py, routes
  ([`aeba3ce`](https://github.com/canonhq/canon-private/commit/aeba3ce17148785148aeb03db5453be998b792e3))

- Correct GitHub App install URLs to use canon-hq slug
  ([`9d6421d`](https://github.com/canonhq/canon-private/commit/9d6421d2e585466775e2bd7d73e4f17c66bd7370))

### Code Style

- Fix ruff formatting in auth and CLI modules
  ([`3e83d63`](https://github.com/canonhq/canon-private/commit/3e83d63bf08c62cd786521fe9096613b178bafbe))

### Testing

- Update test fixtures for Canon rebrand
  ([`e133fb5`](https://github.com/canonhq/canon-private/commit/e133fb57685af7309727213ea1794892d6b71541))


## v1.16.0 (2026-03-07)

### Bug Fixes

- Lint issues
  ([`ac8cc0d`](https://github.com/canonhq/canon-private/commit/ac8cc0de29a4ecddfeabb9568fbb9138fb535cbe))

- Ruff format 8 files
  ([`bb7a752`](https://github.com/canonhq/canon-private/commit/bb7a752ffdeca009aeca1a78d18b2a64a0454d6c))

- Sync window.__CANON__ global and plugin MCP config
  ([`6ee9a24`](https://github.com/canonhq/canon-private/commit/6ee9a242c6d9730efa62c309b521309fe849ca31))

### Documentation

- Add Canon rebrand Phase 2 implementation plan
  ([`dd060a1`](https://github.com/canonhq/canon-private/commit/dd060a1422697815b480b57d1060c69c88e7ea1b))

- Canon "Warm Machine" visual identity design
  ([`5cf1223`](https://github.com/canonhq/canon-private/commit/5cf1223fcb5b6dbe29882f8194ff81e29fc47c1a))

- Mark GitHub App creation as done (App ID: 3012101)
  ([`41937ff`](https://github.com/canonhq/canon-private/commit/41937ffe6d6f77c76167eb9dcc000b9f7aec47cf))

- Mark PyPI reservation as done in Canon rebrand spec
  ([`a4a7590`](https://github.com/canonhq/canon-private/commit/a4a7590120c6c05099d8d85ac92c61e1b74c3a3d))

- Rebrand all documentation to Canon
  ([`da8f85c`](https://github.com/canonhq/canon-private/commit/da8f85c109dd0f54be4144b50c2c88b2425c3265))

- Snapshot v1.15 docs
  ([`aa45df9`](https://github.com/canonhq/canon-private/commit/aa45df9b0852bf729e494d85d1de80f3e8d09939))

- Update docs/specs/new-spec.md
  ([`64d1c25`](https://github.com/canonhq/canon-private/commit/64d1c25228abdca0b9aa1c32be52fe3180f37b68))

- Update docs/specs/new-spec.md
  ([`8207bbe`](https://github.com/canonhq/canon-private/commit/8207bbee49a165e36428171e2949d34e359d7092))

- Warm Machine visual identity implementation plan
  ([`5d7258e`](https://github.com/canonhq/canon-private/commit/5d7258efcbf1ddc3dce130809a8bbf0c6214842c))

### Features

- Rebrand Claude Code plugin and skills to canon:*
  ([`21481af`](https://github.com/canonhq/canon-private/commit/21481af571202536ef943016131374c8f077ed85))

- Rebrand GitHub Action from Specwright to Canon
  ([`093ea17`](https://github.com/canonhq/canon-private/commit/093ea171e343fb34845d089c63074f5b02c5da75))

- Rebrand HTML templates from Specwright to Canon
  ([`eda9033`](https://github.com/canonhq/canon-private/commit/eda9033b15e2b82234cd134dc44ce4b52f731fa8))

- Rebrand Vue SPA marketing components and app UI to Canon
  ([`31dd610`](https://github.com/canonhq/canon-private/commit/31dd610b10c626cab96e11546a0747fc9892ccd2))

- Update all user-facing strings and test assertions to Canon
  ([`9f1d46a`](https://github.com/canonhq/canon-private/commit/9f1d46a5eacf371d6219bc95e03a17bb04225e70))

- **ui**: CTA section dark background inversion
  ([`6124a9b`](https://github.com/canonhq/canon-private/commit/6124a9ba6f2667fcbf9c516c873be15c39c9fed6))

- **ui**: Redesign hero section — left-aligned, solid saffron CTA
  ([`3215c10`](https://github.com/canonhq/canon-private/commit/3215c1063ce7a97cf3f56ad1e9c880b06d06ef31))

- **ui**: Replace @theme tokens with Warm Machine palette
  ([`34bb7c4`](https://github.com/canonhq/canon-private/commit/34bb7c4adb8060062f91779672233f381d8f0617))

- **ui**: Replace all marketing gradients with solid saffron
  ([`60c4ac6`](https://github.com/canonhq/canon-private/commit/60c4ac64331d7fcaa814fa5d0224e4ba5cbdb758))

- **ui**: Sweep remaining hardcoded color values
  ([`3bd7b91`](https://github.com/canonhq/canon-private/commit/3bd7b915b5aab7e292350fbf9615a4ebd64cc69a))

- **ui**: Update brand.css tokens to Warm Machine palette
  ([`3df56e7`](https://github.com/canonhq/canon-private/commit/3df56e7d98b3596168b1b280c4bcbe8315c82d69))

- **ui**: Update font loading to Fraunces/DM Sans/IBM Plex Mono
  ([`e5751c6`](https://github.com/canonhq/canon-private/commit/e5751c6697b8961ec711b07cb8acc4d58b390d7a))

- **ui**: Update LoginView scoped styles to warm palette
  ([`40e37fb`](https://github.com/canonhq/canon-private/commit/40e37fbfa34c7e9f3dd7f188929c9b20f4f72e3d))

- **ui**: Update Monaco editor font to IBM Plex Mono
  ([`7aeb27c`](https://github.com/canonhq/canon-private/commit/7aeb27ca4f3f045dd148174a74e42ab8001cf67f))

- **ui**: Update navigation and footer to solid saffron wordmarks
  ([`30273c4`](https://github.com/canonhq/canon-private/commit/30273c43ce74472457840cacb3572aae1bbcce31))

### Refactoring

- Rename Helm chart specwright → canon
  ([`6fdd77d`](https://github.com/canonhq/canon-private/commit/6fdd77dfad6fe07b636349e981399558fe3e8941))

- Rename src/specwright/ → src/canon/ and update all imports
  ([`91aa637`](https://github.com/canonhq/canon-private/commit/91aa637791e99de6ffe217ff53c066a9200170d1))

- Update CI/CD workflows for canon rebrand
  ([`be95945`](https://github.com/canonhq/canon-private/commit/be95945f8a52c71f6238ba9a4ddd8582db483452))

- Update pyproject.toml, ruff.toml, Dockerfile for canonhq
  ([`b838abf`](https://github.com/canonhq/canon-private/commit/b838abfcdc8a34184fc8909840eb2ee3e74fd867))


## v1.15.0 (2026-03-05)

### Documentation

- Add gv-infra infrastructure rebrand section to Canon spec
  ([`90becce`](https://github.com/canonhq/canon-private/commit/90beccec1bdd10a1c16abb389d45c134f7976372))

- Add setup UX improvements spec
  ([`03c9800`](https://github.com/canonhq/canon-private/commit/03c9800d8d8de17d1ac71bec96a15e2415825ea3))

- Snapshot v1.14 docs
  ([`83f50cd`](https://github.com/canonhq/canon-private/commit/83f50cdf7595e863e043766fb5bcd7a94320b7f7))

- Update domain to canonhq.co, mark as acquired
  ([`8b9fdb3`](https://github.com/canonhq/canon-private/commit/8b9fdb3515261b445265c785a3a0b647b2fb4c0b))

### Features

- Add Canon brand assets — icon, favicon, OG image
  ([`9261d76`](https://github.com/canonhq/canon-private/commit/9261d76dff2dc7e520f16e808a7678e44a66127c))


## v1.14.0 (2026-03-05)

### Chores

- Update app manifest and lockfile
  ([`674c51e`](https://github.com/canonhq/canon-private/commit/674c51eae2732406f81d04d3413ff7785e64688b))

### Documentation

- Add Canon rebrand design document
  ([`540546d`](https://github.com/canonhq/canon-private/commit/540546dc61279571a9da9d9131c80f99cf7cda5e))

- Add Canon rebrand spec with acceptance criteria
  ([`0662389`](https://github.com/canonhq/canon-private/commit/0662389d05da5a71e265d701de4ccc6cd326521b))

- Add repo transfer section, mark canonhq org as done
  ([`987abfa`](https://github.com/canonhq/canon-private/commit/987abfa2c2d8fb38f70ab8725010e287fcefb4e2))

- Update specs based on #314 ([#319](https://github.com/canonhq/canon-private/pull/319),
  [`4f9d505`](https://github.com/canonhq/canon-private/commit/4f9d50548536c723cbbb9a0b181fb02c7b2f40de))

### Features

- Improve ticket sync product experience
  ([`e9d5161`](https://github.com/canonhq/canon-private/commit/e9d5161692e6be9aa18a346d5ef488488b716fe7))


## v1.13.1 (2026-03-05)

### Bug Fixes

- Harden auto-advance on PR merge, mark ticket mapping spec done
  ([#314](https://github.com/canonhq/canon-private/pull/314),
  [`b529eee`](https://github.com/canonhq/canon-private/commit/b529eee6998de4eb7b91c33e9a8fc2ee4425dd9d))

- **docs**: Address PR review — fix Section 2.2 field_map schema, unmark §9
  ([#314](https://github.com/canonhq/canon-private/pull/314),
  [`b529eee`](https://github.com/canonhq/canon-private/commit/b529eee6998de4eb7b91c33e9a8fc2ee4425dd9d))

### Chores

- Update lockfile version to 1.13.0
  ([#314](https://github.com/canonhq/canon-private/pull/314),
  [`b529eee`](https://github.com/canonhq/canon-private/commit/b529eee6998de4eb7b91c33e9a8fc2ee4425dd9d))

### Documentation

- Mark ticket mapping model spec as done
  ([#314](https://github.com/canonhq/canon-private/pull/314),
  [`b529eee`](https://github.com/canonhq/canon-private/commit/b529eee6998de4eb7b91c33e9a8fc2ee4425dd9d))

- Snapshot v1.13 docs
  ([`57627c1`](https://github.com/canonhq/canon-private/commit/57627c1155cee34e542b56586b04feeb353c2ddf))

- Update specs based on #312 ([#313](https://github.com/canonhq/canon-private/pull/313),
  [`a955a25`](https://github.com/canonhq/canon-private/commit/a955a25bc0d61f1c434829b3ccabb5aff9cec111))


## v1.13.0 (2026-03-04)

### Bug Fixes

- Exclude blocked sections from auto-advance, guard duplicate ACs
  ([#312](https://github.com/canonhq/canon-private/pull/312),
  [`f759d09`](https://github.com/canonhq/canon-private/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

### Chores

- Update lockfile version to 1.12.0
  ([#312](https://github.com/canonhq/canon-private/pull/312),
  [`f759d09`](https://github.com/canonhq/canon-private/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

### Documentation

- Mark ticket sync §3 (real-time reverse sync) as done
  ([#312](https://github.com/canonhq/canon-private/pull/312),
  [`f759d09`](https://github.com/canonhq/canon-private/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

- Snapshot v1.12 docs
  ([`73b7ae0`](https://github.com/canonhq/canon-private/commit/73b7ae0860e3491a41a072aa81308855980bcfc3))

- Update specs based on #298 ([#299](https://github.com/canonhq/canon-private/pull/299),
  [`77d81e5`](https://github.com/canonhq/canon-private/commit/77d81e50232b369d4f546ac2201f2b4bff11d7bc))

### Features

- Auto-advance section status to done on PR merge
  ([#312](https://github.com/canonhq/canon-private/pull/312),
  [`f759d09`](https://github.com/canonhq/canon-private/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))

- Auto-advance spec section status on PR merge
  ([#312](https://github.com/canonhq/canon-private/pull/312),
  [`f759d09`](https://github.com/canonhq/canon-private/commit/f759d0917e2cfe3905e6291ba94a30edbb01c02f))


## v1.12.0 (2026-03-04)

### Bug Fixes

- Address final PR review round
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address final review — logging, test coverage, race comment
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address PR review feedback ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Address second PR review round
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Unify preview workflow trigger and fix comment formatting
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Code Style

- Ruff format client.py debug log line
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Continuous Integration

- Lint Helm chart with preview values in CI
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Re-trigger CI workflow ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

### Documentation

- Add preview deployments implementation plan
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Mark PR comment & preview spec as done
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Preview deployment design and spec status updates
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Snapshot v1.11 docs
  ([`79a2b9f`](https://github.com/canonhq/canon-private/commit/79a2b9f9e9e1d1b5b900d900c98d27f8d0c583f0))

### Features

- Add Helm values override for preview deployments
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Add PLATFORM_URL to Helm configmap for preview links
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Add preview deployment workflow for PR UI changes
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Preview deployments for Spec Explorer
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))

- Surface preview deployment URL in Specwright bot comment
  ([#298](https://github.com/canonhq/canon-private/pull/298),
  [`f23023b`](https://github.com/canonhq/canon-private/commit/f23023bb3209d6dc5e50e87dcf698a9ec1b5506a))


## v1.11.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback for webhook reverse sync
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 2 — error handling, security, code quality
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 3 — Linear type filter, public API, clarity
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Address PR review round 4 — Linear ID, HMAC case, error codes
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Base64-encode embedded analysis JSON to prevent HTML comment leak
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Structured error classification and webhook hardening
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Webhook response classification, error leaking, and logging
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Chores

- Update uv.lock for v1.10.1 ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Code Style

- Run ruff format on 5 files ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

### Documentation

- Snapshot v1.10 docs
  ([`ced354c`](https://github.com/canonhq/canon-private/commit/ced354c9933621c2ae37164726909bde8c001e10))

### Features

- Real-time reverse sync via webhooks
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))

- Real-time reverse sync via webhooks for all ticket systems
  ([#295](https://github.com/canonhq/canon-private/pull/295),
  [`1e41eae`](https://github.com/canonhq/canon-private/commit/1e41eaef36064c60ecca50f394771d023c0a1614))


## v1.10.1 (2026-03-04)

### Bug Fixes

- **ci**: Make uv install conditional on release in publish workflow
  ([`af78920`](https://github.com/canonhq/canon-private/commit/af78920a976845f22b4100d94e990db665106832))

### Chores

- Add spec-view-redesign spec and gitignore frontend build artifacts
  ([`cf9e3c7`](https://github.com/canonhq/canon-private/commit/cf9e3c71d0087a7f56618d33dbb5fc436382cb6c))

- Repo level settings
  ([`5530e88`](https://github.com/canonhq/canon-private/commit/5530e888f92e8abc802aac199b31b1a1305ae1de))

### Documentation

- Snapshot v1.10 docs
  ([`02367b9`](https://github.com/canonhq/canon-private/commit/02367b9b2bc4a4cd02abca877f1d49ec3a1185ba))

- Update specs based on #296 ([#297](https://github.com/canonhq/canon-private/pull/297),
  [`5a31eb4`](https://github.com/canonhq/canon-private/commit/5a31eb47f27f24d91c09a12db681ebdf59661079))


## v1.10.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback across spec view components
  ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Chores

- Update uv.lock after merge ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Documentation

- Check off verified ACs across 6 specs (11% → 58% coverage)
  ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

- Snapshot v1.9 docs
  ([`56e7371`](https://github.com/canonhq/canon-private/commit/56e7371f3b80f7719ad986310308baa4fffe754e))

### Features

- Status-aware progress indicator for spec list views
  ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

- Structured spec detail view with collapsible section cards
  ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))

### Refactoring

- Replace getStatusState() with sectionStatus computed
  ([#296](https://github.com/canonhq/canon-private/pull/296),
  [`af5a518`](https://github.com/canonhq/canon-private/commit/af5a518e677ac10ff3b5b5f4bf509cd34ceb394c))


## v1.9.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback — deep merge bug, system detection, CLI config
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- GitHub reverse sync bug, auto-parent warning, review nits
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Recursive flatten, org config cache, dead code removal
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Reduce auto-parent warning noise, note 404 detection debt
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Chores

- Update uv.lock to match 1.7.0
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Code Style

- Apply ruff format ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

### Documentation

- Update specs based on #291 ([#294](https://github.com/canonhq/canon-private/pull/294),
  [`8da29bb`](https://github.com/canonhq/canon-private/commit/8da29bbd24b15c2e6fc9b5d28fb170da298df2d3))

- Update specs based on #292 ([#293](https://github.com/canonhq/canon-private/pull/293),
  [`1fe6f1e`](https://github.com/canonhq/canon-private/commit/1fe6f1ec64713c65acb112076033a5d881febd06))

### Features

- Add issue type labels and title prefix for hierarchy visibility
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Wire ticket mapping config into sync engine
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))

- Wire ticket mapping config into sync engine (§2-§8)
  ([#291](https://github.com/canonhq/canon-private/pull/291),
  [`fa502e0`](https://github.com/canonhq/canon-private/commit/fa502e011f31961c2ccf25cd37d0fab8e076a67d))


## v1.8.0 (2026-03-04)

### Bug Fixes

- Add uv/python to docs CI and commit lockfile
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Resolve ruff lint errors in gen scripts
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Skip gen-refs prebuild when uv is not available
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

### Code Style

- Format gen scripts with ruff
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Ruff format 6 pre-existing unformatted files
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

### Documentation

- Add cross-links to concept pages and verify content migration
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Check off verified ACs across 6 specs (11% → 58% coverage)
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Update spec statuses based on codebase audit
  ([`dc889c3`](https://github.com/canonhq/canon-private/commit/dc889c39544426e689bfac5df6a25877f2c70a02))

### Features

- Auto-generate CLI, MCP, and API reference docs at build time
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Auto-generate reference docs + concept cross-links
  ([#292](https://github.com/canonhq/canon-private/pull/292),
  [`a74e301`](https://github.com/canonhq/canon-private/commit/a74e301b1b2279ddcf2863d05c98357fa8a73993))

- Configurable spec paths, sitemap/SEO, and versioned docs (§2, §11, §10)
  ([`ea685a8`](https://github.com/canonhq/canon-private/commit/ea685a8b1552ed552add76cda93a42f434d9bd12))


## v1.7.0 (2026-03-04)

### Bug Fixes

- Apply AC updates even when section status is unchanged
  ([#282](https://github.com/canonhq/canon-private/pull/282),
  [`1219f41`](https://github.com/canonhq/canon-private/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Chores

- Update uv.lock to match 1.6.0
  ([#282](https://github.com/canonhq/canon-private/pull/282),
  [`1219f41`](https://github.com/canonhq/canon-private/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Code Style

- Ruff format ([#282](https://github.com/canonhq/canon-private/pull/282),
  [`1219f41`](https://github.com/canonhq/canon-private/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Documentation

- Fix ticket links and set ticket_project on all specs
  ([`b923d39`](https://github.com/canonhq/canon-private/commit/b923d3952a9a80af41ee5a77a9800e59a038851a))

- Update spec statuses based on codebase audit
  ([`e85eff1`](https://github.com/canonhq/canon-private/commit/e85eff152ce50c3e571f98dbff1633c8f6cead20))

### Features

- Audit checks off realized ACs and inserts evidence
  ([#282](https://github.com/canonhq/canon-private/pull/282),
  [`1219f41`](https://github.com/canonhq/canon-private/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

- Audit checks off realized ACs and inserts evidence comments
  ([#282](https://github.com/canonhq/canon-private/pull/282),
  [`1219f41`](https://github.com/canonhq/canon-private/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))


## v1.6.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback ([#271](https://github.com/canonhq/canon-private/pull/271),
  [`b344ee7`](https://github.com/canonhq/canon-private/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Chores

- Regenerate uv.lock for v1.5.0
  ([#271](https://github.com/canonhq/canon-private/pull/271),
  [`b344ee7`](https://github.com/canonhq/canon-private/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Code Style

- Ruff format ([#271](https://github.com/canonhq/canon-private/pull/271),
  [`b344ee7`](https://github.com/canonhq/canon-private/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Documentation

- Update specs based on #269 ([#270](https://github.com/canonhq/canon-private/pull/270),
  [`6e9e414`](https://github.com/canonhq/canon-private/commit/6e9e414c8641eb3a6fead2e540f1cc9da405b943))

### Features

- Add production hardening for web app
  ([#271](https://github.com/canonhq/canon-private/pull/271),
  [`b344ee7`](https://github.com/canonhq/canon-private/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

- Production hardening for web app
  ([#271](https://github.com/canonhq/canon-private/pull/271),
  [`b344ee7`](https://github.com/canonhq/canon-private/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))


## v1.5.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback on audit command
  ([#269](https://github.com/canonhq/canon-private/pull/269),
  [`bc17748`](https://github.com/canonhq/canon-private/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Address second round of PR review feedback
  ([#269](https://github.com/canonhq/canon-private/pull/269),
  [`bc17748`](https://github.com/canonhq/canon-private/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Chores

- Update uv.lock to match current version
  ([#269](https://github.com/canonhq/canon-private/pull/269),
  [`bc17748`](https://github.com/canonhq/canon-private/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Documentation

- Add ticket links from specwright sync
  ([`925d4f9`](https://github.com/canonhq/canon-private/commit/925d4f9cb848c35c1dd9894f683b88fbf44c7731))

- Mark Background sections as done, fix parent section statuses
  ([`b284ff5`](https://github.com/canonhq/canon-private/commit/b284ff5c889687115cf6846d2b95dc9ac7e71ad3))

- Update spec statuses based on codebase implementation audit
  ([`ff42ab2`](https://github.com/canonhq/canon-private/commit/ff42ab28687ce2c9866754bac9d773defa8395fb))

### Features

- Add /sw-audit skill for full spec audit workflow
  ([`60c4e72`](https://github.com/canonhq/canon-private/commit/60c4e726c38bb3a9a4b532694016e4fdfc4ec178))

- Add `specwright audit` CLI command for Claude-powered spec status auditing
  ([#269](https://github.com/canonhq/canon-private/pull/269),
  [`bc17748`](https://github.com/canonhq/canon-private/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Add specwright audit CLI command
  ([#269](https://github.com/canonhq/canon-private/pull/269),
  [`bc17748`](https://github.com/canonhq/canon-private/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))


## v1.4.5 (2026-03-04)

### Bug Fixes

- **auth**: Decouple auth0_orgs_enabled from auth0_audience
  ([`5a7887b`](https://github.com/canonhq/canon-private/commit/5a7887bdb4d668ca408a57cfe85bee4d23db0c61))

- **lint**: Remove unused SyncResult import in test_engine
  ([`7c70fbb`](https://github.com/canonhq/canon-private/commit/7c70fbb7d19a2f3ba922743a59ba9951dafeb10b))

- **sync**: Only create tickets for todo/in_progress sections
  ([`449a202`](https://github.com/canonhq/canon-private/commit/449a2020caeee102c32d0e08cf330444b2548dc1))

### Chores

- Remove temporary debug-org endpoint
  ([`a6e1bd6`](https://github.com/canonhq/canon-private/commit/a6e1bd65e0437df201c400e8a36c9d6d474e3a27))

### Code Style

- Fix ruff formatting in test_engine.py
  ([`47059c9`](https://github.com/canonhq/canon-private/commit/47059c97de8e8fcac84890becc03089fabc1410e))

### Documentation

- Fix configuration reference to match actual parser
  ([`7ebe983`](https://github.com/canonhq/canon-private/commit/7ebe983bf6ee915c46e4c920852cbb1ce76d6442))

- Update docs for server-proxied sync, device auth, and AUTH0_AUDIENCE
  ([`23e0957`](https://github.com/canonhq/canon-private/commit/23e0957b9686325e15e27cfdbb2251b64a765fce))


## v1.4.4 (2026-03-04)

### Bug Fixes

- **auth**: Resolve org for device auth JWTs without org_id claim
  ([`2b8b8e4`](https://github.com/canonhq/canon-private/commit/2b8b8e4af8e9337d055d660b6535e8249c7d47fe))


## v1.4.3 (2026-03-04)

### Bug Fixes

- **deploy**: Include AUTH0_AUDIENCE in K8s secret
  ([`22cd8c0`](https://github.com/canonhq/canon-private/commit/22cd8c0e6d0d44d850a4ed03332950e8d06942c1))


## v1.4.2 (2026-03-04)

### Bug Fixes

- **auth**: Fail fast on missing AUTH0_AUDIENCE and use correct status codes
  ([`0400cc6`](https://github.com/canonhq/canon-private/commit/0400cc65cc73515d2f68381e7c3d733508832f92))


## v1.4.1 (2026-03-04)

### Bug Fixes

- **ci**: Fail if uv.lock is out of sync with pyproject.toml
  ([`b798442`](https://github.com/canonhq/canon-private/commit/b798442c30253cf517659b6e92aeab7b213e7200))

### Chores

- Sync uv.lock with pyproject.toml v1.3.0
  ([`c4fde9c`](https://github.com/canonhq/canon-private/commit/c4fde9cf35ea79dd7f8dfbe007ce6634d90f1aa3))


## v1.4.0 (2026-03-04)

### Bug Fixes

- Address PR security feedback
  ([#201](https://github.com/canonhq/canon-private/pull/201),
  [`ce7dfe2`](https://github.com/canonhq/canon-private/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- Address round 2 PR review feedback
  ([#201](https://github.com/canonhq/canon-private/pull/201),
  [`ce7dfe2`](https://github.com/canonhq/canon-private/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- **ci**: Prevent duplicate claude review comments
  ([#201](https://github.com/canonhq/canon-private/pull/201),
  [`ce7dfe2`](https://github.com/canonhq/canon-private/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Code Style

- Format test_ticket_routes.py
  ([#201](https://github.com/canonhq/canon-private/pull/201),
  [`ce7dfe2`](https://github.com/canonhq/canon-private/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Documentation

- Update specs based on #118 ([#120](https://github.com/canonhq/canon-private/pull/120),
  [`2abefec`](https://github.com/canonhq/canon-private/commit/2abefec28cd029636da9f4e22078d5e16d79e492))

### Features

- Server-proxied ticket sync via GitHub App tokens
  ([#201](https://github.com/canonhq/canon-private/pull/201),
  [`ce7dfe2`](https://github.com/canonhq/canon-private/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))


## v1.3.0 (2026-03-01)

### Bug Fixes

- Ruff format on integration conftest
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address PR review — permissions, marker conflict, coverage paths
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address round 2 review feedback
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Format integration tests and fix set -e in combine step
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))

### Documentation

- Update specs based on #117 ([#119](https://github.com/canonhq/canon-private/pull/119),
  [`b7a6def`](https://github.com/canonhq/canon-private/commit/b7a6defc6c30dbe7095fc27d0902a9ba6aa2410c))

### Features

- **ci**: Add coverage reporting for unit and integration tests
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Coverage reporting for unit & integration tests
  ([#118](https://github.com/canonhq/canon-private/pull/118),
  [`781438b`](https://github.com/canonhq/canon-private/commit/781438b3f14049496fa19423d2265e8e73c01916))


## v1.2.0 (2026-03-01)

### Bug Fixes

- Default platform_url to empty, use module-level Settings, drop redundant path
  ([#117](https://github.com/canonhq/canon-private/pull/117),
  [`a65b2cb`](https://github.com/canonhq/canon-private/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

- URL-encode spec paths and add links to reanalyze handler
  ([#117](https://github.com/canonhq/canon-private/pull/117),
  [`a65b2cb`](https://github.com/canonhq/canon-private/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Chores

- Lock updates
  ([`566ee0a`](https://github.com/canonhq/canon-private/commit/566ee0aa09fbbf9d62a67fa0a204541000003be9))

### Code Style

- Fix ruff formatting ([#117](https://github.com/canonhq/canon-private/pull/117),
  [`a65b2cb`](https://github.com/canonhq/canon-private/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Documentation

- Update specs based on #112 ([#114](https://github.com/canonhq/canon-private/pull/114),
  [`a47ece3`](https://github.com/canonhq/canon-private/commit/a47ece3fc43189a0b043018237d53bd8dd2b9f52))

### Features

- Add Specwright web app links to PR comments
  ([#117](https://github.com/canonhq/canon-private/pull/117),
  [`a65b2cb`](https://github.com/canonhq/canon-private/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))


## v1.1.0 (2026-02-28)

### Documentation

- Update install commands to use gv-specwright package name
  ([`8536e8b`](https://github.com/canonhq/canon-private/commit/8536e8bdd3261f6cf2a68ed4be41d2ce92008064))

### Features

- **docs-site**: Logo links to main site + gradient wordmark
  ([`7e55c6b`](https://github.com/canonhq/canon-private/commit/7e55c6ba18aee0b5569382afcc14793850cf4b13))


## v1.0.3 (2026-02-28)

### Bug Fixes

- Add AUTH0_DEVICE_CLIENT_ID to deploy K8s secret
  ([#116](https://github.com/canonhq/canon-private/pull/116),
  [`fc8b3a8`](https://github.com/canonhq/canon-private/commit/fc8b3a8c21b14a4e9e0cfa21d1942c826976a7c7))


## v1.0.2 (2026-02-28)

### Bug Fixes

- Rename PyPI package to gv-specwright (specwright was taken)
  ([`44e3af3`](https://github.com/canonhq/canon-private/commit/44e3af3397bb8c4deba4da6f4a11edf89edf3433))


## v1.0.1 (2026-02-28)

### Bug Fixes

- Use version tag for pypi-publish action (Docker-based, SHA pinning unsupported)
  ([`b48f730`](https://github.com/canonhq/canon-private/commit/b48f730f7f8d066135010f9ff72b8cb1e55e3df9))


## v1.0.0 (2026-02-28)

- Initial Release
