from splent_framework.seeders.BaseSeeder import BaseSeeder


class PublicSeeder(BaseSeeder):
    def run(self):
        data = [
            # Create any Model object you want to make seed
        ]

        self.seed(data)
