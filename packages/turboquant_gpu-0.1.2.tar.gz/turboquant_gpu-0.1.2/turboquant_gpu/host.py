"""
host-side engine: compress / decompress KV caches, run generation.

tries cutile kernels first; falls back to pytorch if the driver or
import is unavailable.
"""

import math
import torch

from .codebook import LloydMaxCodebook
from .constants import BLOCK_S, DEFAULT_SEED, DEFAULT_TOTAL_BITS, HEAD_DIM


def _rotation_matrix(d, seed, device="cpu"):
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    G = torch.randn(d, d, generator=gen)
    Q, R = torch.linalg.qr(G)
    diag_sign = torch.sign(torch.diag(R))
    diag_sign[diag_sign == 0] = 1.0
    return (Q * diag_sign.unsqueeze(0)).to(device)


def _qjl_matrix(d, seed, device="cpu"):
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed + 10000)
    return torch.randn(d, d, generator=gen).to(device)


class TurboQuantEngine:
    def __init__(self, head_dim=HEAD_DIM, total_bits=DEFAULT_TOTAL_BITS,
                 seed=DEFAULT_SEED, device="cpu"):
        self.head_dim   = head_dim
        self.total_bits = total_bits
        self.mse_bits   = max(total_bits - 1, 1)
        self.device     = device

        self.Pi  = _rotation_matrix(head_dim, seed, device)
        self.PiT = self.Pi.T.contiguous()
        self.S   = _qjl_matrix(head_dim, seed, device)
        self.ST  = self.S.T.contiguous()

        self.key_codebook = LloydMaxCodebook(head_dim, self.mse_bits)
        self.val_codebook = LloydMaxCodebook(head_dim, total_bits)

    # ── public api ───────────────────────────────────────────────────

    @torch.no_grad()
    def compress_kv_cache(self, past_key_values):
        """compress a full KV cache from a huggingface model forward pass."""
        kv_keys, kv_vals = self._extract_kv(past_key_values)

        layers = []
        for li in range(len(kv_keys)):
            n_heads = kv_keys[li].shape[1]
            ck = [self._compress_keys(kv_keys[li][0, h].half().contiguous())
                  for h in range(n_heads)]
            cv = [self._compress_values(kv_vals[li][0, h].half().contiguous())
                  for h in range(n_heads)]
            layers.append((ck, cv))

        return {"layers": layers}

    @torch.no_grad()
    def build_cache(self, compressed):
        """reconstruct a DynamicCache from compressed K (via k_mse) and V."""
        from transformers import DynamicCache
        cache = DynamicCache()
        for li, (ck_list, cv_list) in enumerate(compressed["layers"]):
            k_heads = [ck["k_mse"] for ck in ck_list]
            k_layer = torch.stack(k_heads).unsqueeze(0)
            v_heads = [self._decompress_values(cv) for cv in cv_list]
            v_layer = torch.stack(v_heads).unsqueeze(0)
            cache.update(k_layer, v_layer, li)
        return cache

    @torch.no_grad()
    def generate(self, model, tokenizer, prompt, max_new_tokens=100,
                 repetition_penalty=1.3):
        """prefill → compress KV → decode with repetition penalty."""
        inputs = tokenizer(prompt, return_tensors="pt").to(self.device)
        out = model(**inputs, use_cache=True)

        compressed = self.compress_kv_cache(out.past_key_values)
        stats = self.compression_stats(out.past_key_values)
        cache = self.build_cache(compressed)

        seq_len = inputs["input_ids"].shape[1]
        all_ids = inputs["input_ids"][0].tolist()

        next_tok = out.logits[:, -1:].argmax(dim=-1)
        all_ids.append(next_tok.item())

        for step in range(max_new_tokens - 1):
            o = model(input_ids=next_tok, past_key_values=cache,
                      position_ids=torch.tensor([[seq_len + step]],
                                                device=self.device),
                      use_cache=True)
            cache = o.past_key_values
            logits = o.logits[:, -1, :]

            if repetition_penalty != 1.0:
                for tid in set(all_ids):
                    if logits[0, tid] > 0:
                        logits[0, tid] /= repetition_penalty
                    else:
                        logits[0, tid] *= repetition_penalty

            next_tok = logits.argmax(dim=-1, keepdim=True)
            all_ids.append(next_tok.item())
            if next_tok.item() == tokenizer.eos_token_id:
                break

        n_new = len(all_ids) - seq_len
        text = tokenizer.decode(all_ids, skip_special_tokens=True)
        return {"text": text, "tokens": n_new, "stats": stats}

    def compression_stats(self, past_key_values):
        """return compression ratio and byte counts."""
        kv_keys, kv_vals = self._extract_kv(past_key_values)
        n_layers = len(kv_keys)
        n_heads  = kv_keys[0].shape[1]
        seq_len  = kv_keys[0].shape[2]

        fp16_bytes = sum(k.nbytes + v.nbytes for k, v in zip(kv_keys, kv_vals))
        tq_bytes   = self._compressed_bytes(seq_len) * n_heads * n_layers

        return {
            "seq_len": seq_len, "n_layers": n_layers, "n_heads": n_heads,
            "fp16_bytes": fp16_bytes, "tq_bytes": tq_bytes,
            "ratio": fp16_bytes / tq_bytes,
        }

    # ── internals ────────────────────────────────────────────────────

    @staticmethod
    def _extract_kv(past_key_values):
        """handle both DynamicCache and list-of-tuples formats."""
        try:
            return past_key_values.key_cache, past_key_values.value_cache
        except AttributeError:
            keys = [kv[0] for kv in past_key_values]
            vals = [kv[1] for kv in past_key_values]
            return keys, vals

    def _compress_keys(self, K):
        try:
            from .compress import turboquant_compress_2bit, turboquant_compress_3bit
            import cuda.tile as ct

            seq_k, d = K.shape
            indices = torch.empty(seq_k, d, dtype=torch.uint8, device=K.device)
            signs   = torch.empty(seq_k, d, dtype=torch.int8,  device=K.device)
            norms   = torch.empty(seq_k, dtype=torch.float16,  device=K.device)
            r_norms = torch.empty(seq_k, dtype=torch.float16,  device=K.device)

            grid = (self._cdiv(seq_k, BLOCK_S), 1, 1)
            c = self.key_codebook.centroids.tolist()
            b = self.key_codebook.boundaries.tolist()
            stream = torch.cuda.current_stream()

            if self.mse_bits == 2:
                ct.launch(stream, grid, turboquant_compress_2bit, (
                    K, self.PiT.half(), self.Pi.half(), self.ST.half(),
                    indices, signs, norms, r_norms, *c, *b, seq_k))
            elif self.mse_bits == 3:
                ct.launch(stream, grid, turboquant_compress_3bit, (
                    K, self.PiT.half(), self.Pi.half(), self.ST.half(),
                    indices, signs, norms, r_norms, *c, *b, seq_k))
            else:
                return self._compress_keys_pt(K)

            k_mse = self._dequant_keys(indices, norms)
            return {"indices": indices, "k_mse": k_mse, "qjl_signs": signs,
                    "vec_norms": norms, "residual_norms": r_norms}
        except (ImportError, RuntimeError):
            return self._compress_keys_pt(K)

    def _compress_values(self, V):
        try:
            from .compress import (turboquant_compress_values_3bit,
                                   turboquant_compress_values_2bit)
            import cuda.tile as ct

            seq_v, d = V.shape
            indices = torch.empty(seq_v, d, dtype=torch.uint8, device=V.device)
            norms   = torch.empty(seq_v, dtype=torch.float16,  device=V.device)

            grid = (self._cdiv(seq_v, BLOCK_S), 1, 1)
            c = self.val_codebook.centroids.tolist()
            b = self.val_codebook.boundaries.tolist()
            stream = torch.cuda.current_stream()

            if self.total_bits == 3:
                ct.launch(stream, grid, turboquant_compress_values_3bit, (
                    V, self.PiT.half(), indices, norms, *c, *b, seq_v))
            elif self.total_bits == 2:
                ct.launch(stream, grid, turboquant_compress_values_2bit, (
                    V, self.PiT.half(), indices, norms, *c, *b, seq_v))
            else:
                return self._compress_values_pt(V)

            return {"indices": indices, "vec_norms": norms}
        except (ImportError, RuntimeError):
            return self._compress_values_pt(V)

    def _decompress_values(self, cv):
        try:
            from .decompress import (turboquant_decompress_3bit,
                                     turboquant_decompress_2bit)
            import cuda.tile as ct

            indices = cv["indices"]
            norms   = cv["vec_norms"]
            seq_v   = indices.shape[0]
            output  = torch.empty(seq_v, self.head_dim, dtype=torch.float16,
                                  device=indices.device)

            grid = (self._cdiv(seq_v, BLOCK_S), 1, 1)
            c = self.val_codebook.centroids.tolist()
            stream = torch.cuda.current_stream()

            if self.total_bits == 3:
                ct.launch(stream, grid, turboquant_decompress_3bit, (
                    indices, norms, self.Pi.half(), output, *c, seq_v))
            elif self.total_bits == 2:
                ct.launch(stream, grid, turboquant_decompress_2bit, (
                    indices, norms, self.Pi.half(), output, *c, seq_v))
            else:
                return self._decompress_values_pt(cv)
            return output
        except (ImportError, RuntimeError):
            return self._decompress_values_pt(cv)

    # ── pytorch fallbacks ────────────────────────────────────────────

    def _compress_keys_pt(self, K):
        K_f = K.float()
        norms = torch.norm(K_f, dim=-1, keepdim=True)
        K_normed = K_f / (norms + 1e-8)
        rotated = K_normed @ self.PiT.float()

        c = self.key_codebook.centroids.to(K.device)
        indices = (rotated.unsqueeze(-1) - c).abs().argmin(dim=-1).to(torch.uint8)

        y_hat = c[indices.long()]
        k_mse = (y_hat @ self.Pi.float()) * norms
        residual = K_f - k_mse
        r_norms = torch.norm(residual, dim=-1)

        signs = torch.sign(residual @ self.ST.float()).to(torch.int8)
        signs[signs == 0] = 1

        return {"indices": indices, "k_mse": k_mse.half(), "qjl_signs": signs,
                "vec_norms": norms.squeeze(-1).half(),
                "residual_norms": r_norms.half()}

    def _compress_values_pt(self, V):
        V_f = V.float()
        norms = torch.norm(V_f, dim=-1, keepdim=True)
        V_normed = V_f / (norms + 1e-8)
        rotated = V_normed @ self.PiT.float()

        c = self.val_codebook.centroids.to(V.device)
        indices = (rotated.unsqueeze(-1) - c).abs().argmin(dim=-1).to(torch.uint8)

        return {"indices": indices, "vec_norms": norms.squeeze(-1).half()}

    def _decompress_values_pt(self, cv):
        c = self.val_codebook.centroids.to(cv["indices"].device)
        y_hat = c[cv["indices"].long()]
        norms = cv["vec_norms"].float().unsqueeze(-1)
        return ((y_hat @ self.Pi.float()) * norms).half()

    def _dequant_keys(self, indices, norms):
        c = self.key_codebook.centroids.to(indices.device)
        y_hat = c[indices.long()]
        return ((y_hat.float() @ self.Pi.float()) * norms.float().unsqueeze(-1)).half()

    def _cdiv(self, a, b):
        return (a + b - 1) // b

    def _compressed_bytes(self, seq_len):
        d = self.head_dim
        key_bytes = (seq_len * d * self.mse_bits + seq_len * d + seq_len * 32) / 8
        val_bytes = (seq_len * d * self.total_bits + seq_len * 16) / 8
        return key_bytes + val_bytes
